# ANET notes — 0001596532-25-000106


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-25-000106:notes:1]
[same as prior period, unchanged from 0001596532-24-000368:notes:1]

[0001596532-25-000106:notes:2]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus and routing environments. Our cloud networking solutions consist of our Extensible Operating System ("EOS®"), a set of network applications and our Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-25-000106:notes:3]
[same as prior period, unchanged from 0001596532-24-000368:notes:3]

[0001596532-25-000106:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2025, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2024 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated. Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.

[0001596532-25-000106:notes:5]
On November 7, 2024, the Company announced a four-for-one forward stock split ("Stock Split") of the Company’s common stock that was effected through the filing of an amendment to the Company's Amended and Restated Certificate of Incorporation ("Amendment") on December 3, 2024. The Stock Split proportionately increased the authorized shares of common stock, and all share and per share amounts presented herein have been retroactively adjusted to reflect the impact of the Stock Split.

[0001596532-25-000106:notes:6]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2024, filed with the SEC on February 18, 2025.

[0001596532-25-000106:notes:7]
[same as prior period, unchanged from 0001596532-24-000368:notes:6]

[0001596532-25-000106:notes:8]
[same as prior period, unchanged from 0001596532-24-000368:notes:7]

[0001596532-25-000106:notes:9]
[same as prior period, unchanged from 0001596532-24-000368:notes:14]

[0001596532-25-000106:notes:10]
In December 2023, the Financial Accounting Standards Board ("FASB")  issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2024. Early adoption is permitted for annual financial statements that have not yet been issued. The amendments should be applied on a prospective basis although retrospective

[0001596532-25-000106:notes:11]
application is permitted. We will adopt the standard in our 2025 annual period and are currently evaluating the impact that the updated standard will have on our financial statement disclosures.

[0001596532-25-000106:notes:12]
In November 2024, the FASB issued ASU No. 2024-03, Disaggregation of Income Statement Expenses (Subtopic 220-40). The ASU requires the disaggregated disclosure of specific expense categories, including purchases of inventory, employee compensation, depreciation, and amortization, within relevant income statement captions. This ASU also requires disclosure of the total amount of selling expenses along with the definition of selling expenses. The ASU is effective for annual periods beginning after December 15, 2026, and interim periods within fiscal years beginning after December 15, 2027. Adoption of this ASU can either be applied prospectively to consolidated financial statements issued for reporting periods after the effective date of this ASU or retrospectively to any or all prior periods presented in the consolidated financial statements. Early adoption is also permitted. This ASU will likely result in the required additional disclosures being included in our consolidated financial statements, once adopted. We are currently evaluating the impact of future adoption on our financial statement disclosures.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-25-000106:notes:13]
[same as prior period, unchanged from 0001596532-24-000368:notes:17]

[0001596532-25-000106:notes:14]
We measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value on a recurring basis. We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs. The two-tiers of the fair value hierarchy are as follows: Level I—Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date and Level II—Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities. We don't have any level III financial assets measured at fair value on a recurring basis. The following tables summarize the fair value of these financial assets by significant investment category and their levels within the fair value hierarchy (in millions):

[0001596532-25-000106:notes:15]
|  |  | March 31, 2025 |  | December 31, 2024 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 782.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 782.7 |  |  | $ | 1,707.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,707.5 |  |
| Commercial paper |  | — |  |  | 62.1 |  |  | — |  |  | 62.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government notes |  | 288.9 |  |  | — |  |  | — |  |  | 288.9 |  |  | 31.4 |  |  | — |  |  | — |  |  | 31.4 |  |
| Agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3.0 |  |  | — |  |  | 3.0 |  |
|  |  | 1,071.6 |  |  | 62.1 |  |  | — |  |  | 1,133.7 |  |  | 1,738.9 |  |  | 3.0 |  |  | — |  |  | 1,741.9 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 43.3 |  |  | — |  |  | 43.3 |  |  | — |  |  | 48.8 |  |  | — |  |  | 48.8 |  |
| U.S. government notes |  | 2,094.8 |  |  | — |  |  | — |  |  | 2,094.8 |  |  | 1,921.5 |  |  | — |  |  | — |  |  | 1,921.5 |  |
| Corporate bonds |  | — |  |  | 3,111.8 |  |  | — |  |  | 3,111.8 |  |  | — |  |  | 2,593.6 |  |  | — |  |  | 2,593.6 |  |
| Agency securities |  | — |  |  | 1,054.6 |  |  | — |  |  | 1,054.6 |  |  | — |  |  | 977.2 |  |  | — |  |  | 977.2 |  |
|  |  | 2,094.8 |  |  | 4,209.7 |  |  | — |  |  | 6,304.5 |  |  | 1,921.5 |  |  | 3,619.6 |  |  | — |  |  | 5,541.1 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 1.4 |  |  | — |  |  | — |  |  | 1.4 |  |  | 1.4 |  |  | — |  |  | — |  |  | 1.4 |  |
| Total Financial Assets |  | $ | 3,167.8 |  |  | $ | 4,271.8 |  |  | $ | — |  |  | $ | 7,439.6 |  |  | $ | 3,661.8 |  |  | $ | 3,622.6 |  |  | $ | — |  |  | $ | 7,284.4 |  |

[0001596532-25-000106:notes:16]
During the three months ended March 31, 2025, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-25-000106:notes:17]
Debt securities

[0001596532-25-000106:notes:18]
The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities measured at fair value on a recurring basis (in millions):

[0001596532-25-000106:notes:19]
|  |  | March 31, 2025 |  | December 31, 2024 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 105.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 105.4 |  |  | $ | 48.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 48.8 |  |
| U.S. government |  | 2,380.1 |  |  | 5.2 |  |  | (1.6) |  |  | 2,383.7 |  |  | 1,954.8 |  |  | 2.7 |  |  | (4.6) |  |  | 1,952.9 |  |
| Corporate bonds |  | 3,107.2 |  |  | 7.3 |  |  | (2.7) |  |  | 3,111.8 |  |  | 2,595.7 |  |  | 4.4 |  |  | (6.5) |  |  | 2,593.5 |  |
| Agency securities |  | 1,053.7 |  |  | 1.8 |  |  | (0.9) |  |  | 1,054.6 |  |  | 981.0 |  |  | 1.6 |  |  | (2.4) |  |  | 980.3 |  |
| Total |  | $ | 6,646.4 |  |  | $ | 14.3 |  |  | $ | (5.2) |  |  | $ | 6,655.5 |  |  | $ | 5,580.3 |  |  | $ | 8.7 |  |  | $ | (13.5) |  |  | $ | 5,575.5 |  |

[0001596532-25-000106:notes:20]
For debt securities in unrealized loss positions, it is not likely that we will be required to sell such securities before recovery of their amortized cost basis nor do we have the intent to sell such securities before maturity. We invest in debt securities that have maximum maturities of three years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. Given the short-term and conservative nature of our portfolio, our debt securities are generally not subject to credit risk; therefore, we did not recognize any credit losses or non-credit-related impairments related to such securities for the three months ended March 31, 2025. All unrealized losses were recognized in other comprehensive income (loss). Realized gains or losses were immaterial for the three months ended March 31, 2025.

[0001596532-25-000106:notes:21]
The following table is an analysis of our debt securities in unrealized loss positions (in millions):

[0001596532-25-000106:notes:22]
|  |  | March 31, 2025 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 859.3 |  |  | $ | (1.6) |  |  | $ | — |  |  | $ | — |  |  | $ | 859.3 |  |  | $ | (1.6) |  |
| Corporate bonds |  | 896.6 |  |  | (2.7) |  |  | 2.8 |  |  | — |  |  | 899.4 |  |  | (2.7) |  |
| Agency securities |  | 483.5 |  |  | (0.9) |  |  | — |  |  | — |  |  | 483.5 |  |  | (0.9) |  |
| Total |  | $ | 2,239.4 |  |  | $ | (5.2) |  |  | $ | 2.8 |  |  | $ | — |  |  | $ | 2,242.2 |  |  | $ | (5.2) |  |

[0001596532-25-000106:notes:23]
As of March 31, 2025, we had no marketable debt securities with contractual maturities that exceeded three years. The fair values of marketable debt securities, by remaining contractual maturities, are as follows (in millions):

[0001596532-25-000106:notes:24]
|  |  | March 31, 2025 |
|  |  | Fair Value |
| Due in 1 year or less |  | $ | 2,534.6 |  |
| Due in 1 to 3 years |  | 3,769.9 |  |
| Total debt securities |  | $ | 6,304.5 |  |

[0001596532-25-000106:notes:25]
The weighted-average remaining duration of our marketable debt securities is approximately 1.3 years as of March 31, 2025. As we view these marketable debt securities as available to support current operations, we classify marketable debt securities with maturities beyond 12 months as current assets under the caption "Marketable securities" on the condensed consolidated balance sheets.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-25-000106:notes:26]
The following tables summarize the fair value of these financial assets by significant investment category and their levels within the fair value hierarchy (in millions):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-25-000106:notes:27]
[same as prior period, unchanged from 0001596532-24-000368:notes:41]

[0001596532-25-000106:notes:28]
Inventories consist of the following (in millions):

[0001596532-25-000106:notes:29]
|  |  | March 31, 2025 |  | December 31, 2024 |
| Raw materials |  | $ | 576.2 |  |  | $ | 565.4 |  |
| Finished goods(1) |  | 1,381.1 |  |  | 1,269.2 |  |
| Total inventories |  | $ | 1,957.3 |  |  | $ | 1,834.6 |  |

[0001596532-25-000106:notes:30]
(1) The balance includes evaluation inventory held at customers or partners totaling $435.8 million and $422.1 million as of March 31, 2025 and December 31, 2024, respectively.

[0001596532-25-000106:notes:31]
[same as prior period, unchanged from 0001596532-24-000368:notes:47]

[0001596532-25-000106:notes:32]
Property and equipment, net consists of the following (in millions):

[0001596532-25-000106:notes:33]
|  |  | March 31, 2025 |  | December 31, 2024 |
| Land |  | $ | 47.3 |  |  | $ | 47.2 |  |
| Equipment and machinery |  | 167.9 |  |  | 160.7 |  |
| Computer hardware and software |  | 64.9 |  |  | 63.9 |  |
| Leasehold improvements |  | 34.8 |  |  | 34.7 |  |
| Furniture and fixtures |  | 3.5 |  |  | 3.5 |  |
| Construction-in-process |  | 32.9 |  |  | 8.2 |  |
| Property and equipment, gross |  | 351.3 |  |  | 318.2 |  |
| Less: accumulated depreciation |  | (227.4) |  |  | (219.4) |  |
| Property and equipment, net |  | $ | 123.9 |  |  | $ | 98.8 |  |

[0001596532-25-000106:notes:34]
Depreciation expense was $8.0 million and $8.6 million for the three months ended March 31, 2025 and 2024, respectively.

[0001596532-25-000106:notes:35]
[same as prior period, unchanged from 0001596532-24-000368:notes:53]

[0001596532-25-000106:notes:36]
[same as prior period, unchanged from 0001596532-24-000368:notes:54]

[0001596532-25-000106:notes:37]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a cancellable contract. The following table summarizes the activity related to our contract liabilities (in millions):

[0001596532-25-000106:notes:38]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Contract liabilities, beginning balance |  | $ | 160.8 |  |  | $ | 133.2 |  |  |  |  |  |
| Less: Revenue recognized from beginning balance |  | (12.9) |  |  | (12.0) |  |  |  |  |  |
| Less: Beginning balance reclassified to deferred revenue |  | (6.4) |  |  | (6.5) |  |  |  |  |  |
| Add: Contract liabilities recognized |  | 19.0 |  |  | 24.9 |  |  |  |  |  |
| Contract liabilities, ending balance |  | $ | 160.5 |  |  | $ | 139.6 |  |  |  |  |  |

[0001596532-25-000106:notes:39]
As of March 31, 2025 and December 31, 2024, $66.3 million and $65.7 million of our contract liabilities, respectively, were included in "Other current liabilities" with the remaining balances included in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001596532-25-000106:notes:40]
[same as prior period, unchanged from 0001596532-24-000368:notes:58]

[0001596532-25-000106:notes:41]
Deferred revenue is comprised mainly of unearned revenue related to multi-year post-contract support ("PCS") contracts, services and product deferrals related to contracts with acceptance clauses. The following table summarizes the activity related to our deferred revenue (in millions):

[0001596532-25-000106:notes:42]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Deferred revenue, beginning balance |  | $ | 2,791.4 |  |  | $ | 1,506.2 |  |  |  |  |  |
| Less: Revenue recognized from beginning balance |  | (418.3) |  |  | (284.3) |  |  |  |  |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 715.7 |  |  | 441.3 |  |  |  |  |  |
| Deferred revenue, ending balance |  | $ | 3,088.8 |  |  | $ | 1,663.2 |  |  |  |  |  |

[0001596532-25-000106:notes:43]
[same as prior period, unchanged from 0001596532-24-000368:notes:61]

[0001596532-25-000106:notes:44]
Other performance obligations totaling $419.9 million as of March 31, 2025 include unbilled multi-year PCS and service contract amounts of $357.2 million and $62.7 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-25-000106:notes:45]
[same as prior period, unchanged from 0001596532-24-000368:notes:63]

[0001596532-25-000106:notes:46]
Total revenue from our contract liabilities, deferred revenue and other performance obligations that is expected to be recognized in future periods amounts to $3.7 billion as of March 31, 2025. Approximately 86% of this future revenue is expected to be recognized over the next two years and the remaining 14% is expected to be recognized during the third to the fifth year.

[0001596532-25-000106:notes:47]
[same as prior period, unchanged from 0001596532-24-000368:notes:65]

[0001596532-25-000106:notes:48]
Other income (expense), net consists of the following (in millions):

[0001596532-25-000106:notes:49]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Interest income |  | $ | 90.2 |  |  | $ | 63.8 |  |  |  |  |  |
| Other income (expense), net |  | 6.0 |  |  | (1.2) |  |  |  |  |  |
| Total |  | $ | 96.2 |  |  | $ | 62.6 |  |  |  |  |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-25-000106:notes:50]
The following table summarizes the activity related to our contract liabilities (in millions):

[0001596532-25-000106:notes:51]
The following table summarizes the activity related to our deferred revenue (in millions):


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-25-000106:notes:52]
Acquisition, Goodwill and Acquisition-Related Intangible Assets
Acquisitions

[0001596532-25-000106:notes:53]
We had no business acquisitions during the three months ended March 31, 2025 and 2024.

[0001596532-25-000106:notes:54]
Goodwill

[0001596532-25-000106:notes:55]
No changes were made to the carrying values of goodwill for the three months ended March 31, 2025 and 2024.

[0001596532-25-000106:notes:56]
Acquisition-Related Intangible Assets

[0001596532-25-000106:notes:57]
Acquisition-related intangible assets, excluding those that are fully amortized, were as follows (in millions, except years):

[0001596532-25-000106:notes:58]
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life (in years) |
|  | December 31, 2024 |  | Additions |  | March 31, 2025 |  | December 31, 2024 |  | Amortization |  | March 31, 2025 |  | December 31, 2024 |  | March 31, 2025 |  |
| Developed technology | $ | 154.9 |  |  | $ | — |  |  | $ | 154.9 |  |  | $ | (119.2) |  |  | $ | (3.2) |  |  | $ | (122.4) |  |  | $ | 35.7 |  |  | $ | 32.5 |  |  | 3.2 |
| Customer relationships | 54.6 |  |  | — |  |  | 54.6 |  |  | (29.5) |  |  | (1.9) |  |  | (31.4) |  |  | 25.1 |  |  | 23.2 |  |  | 3.7 |
| Trade name | 12.4 |  |  | — |  |  | 12.4 |  |  | (11.2) |  |  | (0.5) |  |  | (11.7) |  |  | 1.2 |  |  | 0.7 |  |  | 0.4 |
| Total | $ | 221.9 |  |  | $ | — |  |  | $ | 221.9 |  |  | $ | (159.9) |  |  | $ | (5.6) |  |  | $ | (165.5) |  |  | $ | 62.0 |  |  | $ | 56.4 |  |  | 3.4 |

[0001596532-25-000106:notes:59]
Amortization expense related to acquisition-related intangible assets was $5.6 million and $6.7 million for the three months ended March 31, 2025 and 2024, respectively.

[0001596532-25-000106:notes:60]
As of March 31, 2025, future estimated amortization expense related to the acquisition-related intangible assets is as follows (in millions):

[0001596532-25-000106:notes:61]
|  |  | Future Amortization Expense |
| Remainder of 2025 |  | $ | 14.1 |  |
| 2026 |  | 17.3 |  |
| 2027 |  | 13.4 |  |
| 2028 |  | 10.0 |  |
| 2029 |  | 1.6 |  |
| Total |  | $ | 56.4 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-25-000106:notes:62]
Commitments and Contingencies
Purchase Commitments

[0001596532-25-000106:notes:63]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of purchase orders to our contract manufacturers for finished products consist of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2025, we had non-cancellable purchase commitments not recorded on our balance sheet of $3.5 billion, of which $3.0 billion have expected receipt dates within 12 months, and $0.5 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-25-000106:notes:64]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $80.1 million and $95.8 million as of March 31, 2025 and December 31, 2024, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

[0001596532-25-000106:notes:65]
Property project

[0001596532-25-000106:notes:66]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. The estimated remaining capital expenditures related to this project are expected to be approximately $215.0 million to $240.0 million for the next two years, with construction expected to be completed by the end of fiscal 2026.

[0001596532-25-000106:notes:67]
Guarantees

[0001596532-25-000106:notes:68]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-25-000106:notes:69]
Legal Proceedings

[0001596532-25-000106:notes:70]
WSOU Investments, LLC

[0001596532-25-000106:notes:71]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement. On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit. On May 30, 2023, the US Patent Trial and Appeal Board (“PTAB”) ruled all challenged claims in the inter partes review unpatentable. On March 10, 2025, the Federal Circuit affirmed the PTAB’s decision. The parties subsequently agreed to stay the litigation for an additional 90 days to allow WSOU to change counsel.

[0001596532-25-000106:notes:72]
We intend to vigorously defend against the claims brought against us by WSOU; however, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-25-000106:notes:73]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated; however, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-25-000106:notes:74]
Other matters

[0001596532-25-000106:notes:75]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-25-000106:notes:76]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2025, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-25-000106:notes:77]
Stockholders’ Equity and Stock-Based Compensation
Stock Repurchase Programs

[0001596532-25-000106:notes:78]
Our current repurchase program (the "Existing Repurchase Program") allows for stock repurchases of up to $1.2 billion through May 2027. In May 2025, our board of directors authorized and announced a new $1.5 billion stock repurchase program (the “New Repurchase Program” and together with the Existing Repurchase Program, the "Repurchase Programs"). This authorization allows us to repurchase shares of our common stock that will be funded from working capital. Repurchases may be made at management's discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the "Exchange Act"), or a combination of the foregoing. The Repurchase Programs do not obligate us to acquire any of our common stock and may be suspended or discontinued by the Company at any time without prior notice. During the three months ended March 31, 2025, we repurchased a total of $787.1 million of our common stock under our Existing Repurchase Program. As of March 31, 2025, the remaining authorized amount for repurchases under the Existing Repurchase Program was $133.9 million. In April 2025, we repurchased an additional $100.0 million of our common stock authorized under the Existing Repurchase Program.

[0001596532-25-000106:notes:79]
A summary of the stock repurchase activity under the Existing Repurchase Program for the three months ended March 31, 2025 is as follows (in millions, except per share amounts):

[0001596532-25-000106:notes:80]
|  |  |  |  | Three Months Ended |
|  |  |  |  | March 31, 2025 |
| Aggregate purchase price |  |  |  | $ | 787.1 |  |
| Shares repurchased |  |  |  | 8.7 |  |
| Average price paid per share |  |  |  | $ | 90.5 |  |

[0001596532-25-000106:notes:81]
[same as prior period, unchanged from 0001596532-24-000368:notes:97]

[0001596532-25-000106:notes:82]
[same as prior period, unchanged from 0001596532-24-000368:notes:98]

[0001596532-25-000106:notes:83]
[same as prior period, unchanged from 0001596532-24-000368:notes:99]

[0001596532-25-000106:notes:84]
On April 16, 2024, our board of directors adopted an amended and restated Arista Networks, Inc. 2014 Equity Plan ("Restated Plan"), effective April 17, 2024 ("Effective Date") subject to the approval of our stockholders, which was approved at the 2024 Annual Meeting of Stockholders on June 7, 2024.

[0001596532-25-000106:notes:85]
The Restated Plan provides for the grant of equity-based awards, including stock options, restricted stock units, restricted stock, stock appreciation rights, and performance awards. The share pool available under the prior version of the Company's 2014 Equity Incentive Plan ("Prior Plan") was extinguished, and the Restated Plan provides for a new share pool not to exceed (i) 52.8 million shares of our Common Stock (“Shares”), plus (ii) any Shares subject to awards under the Prior Plan that, on or after the Effective Date, expired or otherwise terminated without having been exercised in full, or that were forfeited to or repurchased by us, including net settlement of Shares subject to restricted stock units, with the maximum number of Shares to be added to the Restated Plan as a result of clause (ii) equal to 40.2 million Shares. The Restated Plan’s terms are substantially similar to the Prior Plan’s terms, including with respect to treatment of equity awards in the event of a “change in control” as defined under the Restated Plan, but with certain modifications, including the elimination of the automatic “evergreen” share reserve increase provided for under the Prior Plan. As of March 31, 2025, there remained approximately 52.3 million shares available for grant under the Restated Plan.

[0001596532-25-000106:notes:86]
[same as prior period, unchanged from 0001596532-24-000368:notes:102]

[0001596532-25-000106:notes:87]
In April 2014, our board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (“ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares reserved for

[0001596532-25-000106:notes:88]
issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding on the immediately preceding December 31, but not to exceed 40 million shares, unless our board of directors, in its discretion, determines to make a smaller increase. As of March 31, 2025, there remained approximately 104.5 million shares available for issuance under the ESPP.

[0001596532-25-000106:notes:89]
Under our ESPP, eligible employees are permitted to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the exercise date. Each offering period lasts approximately two years starting on the first trading date after February 15 and August 15 of each year, and includes purchase dates every six months on or after February 15 and August 15 of each year. Participants may purchase shares of common stock through payroll deductions up to 15% of their eligible compensation, subject to Internal Revenue Service mandated purchase limits.

[0001596532-25-000106:notes:90]
During the three months ended March 31, 2025, we issued 0.4 million shares at a weighted-average purchase price of $62.31 per share under the ESPP.

[0001596532-25-000106:notes:91]
[same as prior period, unchanged from 0001596532-24-000368:notes:105]

[0001596532-25-000106:notes:92]
The following table summarizes the option activity under our stock plans and related information (in millions, except years and per share amounts):

[0001596532-25-000106:notes:93]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2024 |  | 3.1 |  |  | $ | 6.71 |  |  | 1.5 |  | $ | 320.9 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (1.0) |  |  | 4.03 |  |  |  |  |  |
| Options canceled |  | (0.1) |  |  | 14.49 |  |  |  |  |  |
| Balance—March 31, 2025 |  | 2.0 |  |  | $ | 7.92 |  |  | 1.8 |  | $ | 137.8 |  |
| Vested and exercisable—March 31, 2025 |  | 1.9 |  |  | $ | 7.74 |  |  | 1.8 |  | $ | 134.8 |  |

[0001596532-25-000106:notes:94]
[same as prior period, unchanged from 0001596532-24-000368:notes:108]

[0001596532-25-000106:notes:95]
A summary of the RSU activity is presented below (in millions, except years and per share amounts):

[0001596532-25-000106:notes:96]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |
| Unvested balance—December 31, 2024 |  | 28.6 |  |  | $ | 45.46 |  |
| RSUs and PRSUs granted |  | 1.5 |  |  | 96.18 |  |
| RSUs and PRSUs vested |  | (2.8) |  |  | 38.11 |  |
| RSUs and PRSUs forfeited/canceled |  | (0.9) |  |  | 43.37 |  |
| Unvested balance—March 31, 2025 |  | 26.4 |  |  | $ | 49.36 |  |

[0001596532-25-000106:notes:97]
[same as prior period, unchanged from 0001596532-24-000368:notes:111]

[0001596532-25-000106:notes:98]
The following table summarizes the stock-based compensation expense related to our equity awards (in millions):

[0001596532-25-000106:notes:99]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Cost of revenue |  | $ | 5.5 |  |  | $ | 3.4 |  |  |  |  |  |
| Research and development |  | 57.0 |  |  | 43.8 |  |  |  |  |  |
| Sales and marketing |  | 19.9 |  |  | 18.9 |  |  |  |  |  |
| General and administrative |  | 10.6 |  |  | 11.1 |  |  |  |  |  |
| Total stock-based compensation |  | $ | 93.0 |  |  | $ | 77.2 |  |  |  |  |  |

[0001596532-25-000106:notes:100]
As of March 31, 2025, there were $1.1 billion of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 4.4 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-25-000106:notes:101]
Net Income Per Share
    Basic net income per share is computed using the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed using the weighted-average number of shares of common stock outstanding during the period, including potential common shares assuming the dilutive effect of outstanding stock options, restricted stock units, and the employee stock purchase plan using the treasury stock method. Potential common shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share. The following table sets forth the computation of our basic and diluted net income per share (in millions, except per share amounts):

[0001596532-25-000106:notes:102]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 813.8 |  |  | $ | 637.7 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic weighted-average shares outstanding |  | 1,260.0 |  |  | 1,252.1 |  |  |  |  |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity awards |  | 19.2 |  |  | 27.3 |  |  |  |  |  |
| Diluted weighted-average shares outstanding |  | 1,279.2 |  |  | 1,279.4 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.65 |  |  | $ | 0.51 |  |  |  |  |  |
| Diluted |  | $ | 0.64 |  |  | $ | 0.50 |  |  |  |  |  |

[0001596532-25-000106:notes:103]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share for the periods presented because their effect would have been anti-dilutive for the periods presented (in millions):

[0001596532-25-000106:notes:104]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Employee equity awards |  | 0.9 |  |  | 0.7 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-25-000106:notes:105]
Income Taxes (in millions, except percentages)

[0001596532-25-000106:notes:106]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Income before income taxes |  | $ | 955.0 |  |  | $ | 722.8 |  |  |  |  |  |
| Provision for income taxes |  | 141.2 |  |  | 85.1 |  |  |  |  |  |
| Effective tax rate |  | 14.8 | % |  | 11.8 | % |  |  |  |  |

[0001596532-25-000106:notes:107]
The increase in the effective tax rates in the three months ended March 31, 2025, as compared to the same period in 2024, was primarily due to a decrease in the proportion of tax benefits attributable to equity-based compensation versus total pre-tax income.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-25-000106:notes:108]
Segment and Geographical Information 
We operate as one reportable segment. The accounting policies of the reportable segment are the same as those described in the summary of significant accounting policies. Our chief operating decision maker ("CODM") is our President, Chief Executive Officer and Chairperson of the Board, who reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance. The financial information reviewed by the CODM reflects quarterly and year-to-date operating results, with a primary focus on revenue, gross margin, operating margin and net income as reported on the consolidated statements of income. Consolidated financial information is used by the CODM to evaluate performance and make decisions regarding resource allocation and other strategic initiatives. This consolidated financial information is also what is used to establish and approve operating budgets and forecasts. The measure of segment assets is reported on the consolidated balance sheets in total. There was no change for each of the periods presented in the measurement methods used to determine reported segment profit and loss.

[0001596532-25-000106:notes:109]
The CODM reviews the following significant segment expenses, which are presented separately on the Company’s consolidated statements of income: cost of product, cost of services, selling and marketing expenses, general and administrative expenses, and research and development expenses. Other segment items that are included in the calculation of the Company’s net income include other income (expense), net, which is further described in Note 3. Financial Statements Details and income taxes, which is further described in Note 8. Income Taxes. Other segment disclosures such as depreciation and amortization and stock-based compensation are disclosed in the Consolidated Statements of Cash Flows.

[0001596532-25-000106:notes:110]
The following table represents revenue based on customers’ shipping addresses (in millions):

[0001596532-25-000106:notes:111]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Americas(1) |  | $ | 1,598.5 |  |  | $ | 1,255.4 |  |  |  |  |  |
| Europe, Middle East and Africa |  | 174.6 |  |  | 141.6 |  |  |  |  |  |
| Asia-Pacific |  | 231.7 |  |  | 174.4 |  |  |  |  |  |
| Total revenue |  | $ | 2,004.8 |  |  | $ | 1,571.4 |  |  |  |  |  |

[0001596532-25-000106:notes:112]
(1) Includes $1,581.5 million and $1,232.8 million revenue generated from the U.S. for the three months ended March 31, 2025 and March 31, 2024, respectively.

[0001596532-25-000106:notes:113]
Long-lived assets, net, excluding intercompany receivables, investments in subsidiaries, privately-held equity investments and deferred tax assets, by location are summarized as follows (in millions):

[0001596532-25-000106:notes:114]
|  |  | March 31, 2025 |  | December 31, 2024 |
| United States |  | $ | 108.3 |  |  | $ | 83.5 |  |
| International |  | 15.6 |  |  | 15.3 |  |
| Total |  | $ | 123.9 |  |  | $ | 98.8 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001596532-25-000106:notes:115]
On March 13, 2025, Kenneth Duda, our Chief Technology Officer, Senior Vice President, Software Engineering and Director, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 680,000 shares of our common stock held in various trusts for the benefit of Mr. Duda’s family, for which Mr. Duda is the beneficial owner and which is intended to be treated as a single plan. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until June 18, 2026, or earlier if all transactions under the trading arrangement are completed.
