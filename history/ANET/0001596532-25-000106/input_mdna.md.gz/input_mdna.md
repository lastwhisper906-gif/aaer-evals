# ANET MD&A — 0001596532-25-000106


## mdna

[0001596532-25-000106:mdna:1]
[same as prior period, unchanged from 0001596532-24-000368:mdna:1]

[0001596532-25-000106:mdna:2]
[same as prior period, unchanged from 0001596532-24-000368:mdna:2]

[0001596532-25-000106:mdna:3]
Arista Networks is an industry leader in data-driven, client to cloud networking for large AI, data center, campus and routing environments. Arista's platforms deliver availability, agility, automation, analytics and security through an advanced network operating stack. Since Arista’s inception, our founders have reimagined cloud networks for performance, scale and programmability with a focus on differentiating in three ways: uncompromising reliability built on the foundation of robust quality assurance capabilities with a suite of automated diagnostics, advanced open and standards-based technology and intelligent automation to decrease the manual workload on the operator. At the core of Arista’s platform is Arista EOS, a modernized publish-subscribe state-sharing networking operating system. Arista EOS, combined with a set of network

[0001596532-25-000106:mdna:4]
applications and our Ethernet switching and routing platforms using best of breed merchant silicon, provides customers with a highly competitive and diversified portfolio of products with improved price/performance and time to market.

[0001596532-25-000106:mdna:5]
[same as prior period, unchanged from 0001596532-24-000368:mdna:8]

[0001596532-25-000106:mdna:6]
The markets for cloud networking solutions are highly competitive and characterized by rapidly changing technology, changing end-customer needs, evolving industry standards, frequent introductions of new products and services, and industry consolidation. We expect competition to intensify in the future as the market for cloud networking expands and existing competitors and new market entrants introduce new products or enhance existing products. Our future success is dependent upon our ability to continue to evolve and adapt to our rapidly changing environment. We must also continue to develop market-leading products and software features that address the changing needs of our existing and new customers, and increase sales in the cloud, AI and enterprise data center Ethernet switching/routing markets, and campus workspace markets. We believe one of our greatest strengths lies in our ability to rapidly develop new features and applications. In addition, we intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new customers more effectively, increase sales to existing customers, and provide services and support. Furthermore, we expect to continue to make substantial investments to introduce new products and services and enhance the functionality of our existing cloud networking platform through investments in our research and development organization, and investments in or acquisitions of complementary companies, products and technologies to expand our product offerings and build upon our technology leadership.

[0001596532-25-000106:mdna:7]
The expansion of generative AI computing and distributed applications is further pushing the boundary of predictable scale and performance in the network. A common characteristic of these AI workloads is that they are both data and compute intensive. A typical AI workload involves large sparse matrix computations, distributed across hundreds or thousands of processors (CPU, GPU, TPU, etc.) with intense computations for a period of time and requires a high-bandwidth, scalable, lossless network in order to service these workloads. With the exponential growth of AI applications, the need for standardized transport like Ethernet becomes paramount, enabling a power-efficient interconnect while overcoming the complexities of traditional approaches. Our AI strategy is based on achieving two key objectives: (1) deliver network switching products intended to provide a robust interconnect that seamlessly links GPUs, compute and storage to deliver fast job completion time for training and generative AI workloads; and (2) offer customers the Arista Autonomous Virtual Assist ("AVATM") which uses natural processing language to provide AI-assisted outcomes for network operations, security and observability.

[0001596532-25-000106:mdna:8]
Historically, large purchases by a relatively limited number of customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large customers primarily due to the time it takes these customers to evaluate, test, qualify and accept our newer products, the overall complexity of these large orders and changes in demand patterns specific to these customers, including reductions in or changes in mix of capital expenditures by these customers and the impact of cost reduction and other efficiency efforts by these customers. For example, sales to our end customer Microsoft represented 20%, 18% and 16% of our total revenue for the years ended 2024, 2023 and 2022 respectively. And sales to our end customer Meta Platforms represented 15%, 21% and 26% of our total revenue, respectively for the years ended 2024, 2023 and 2022. This variability in customer concentration has been linked to the timing of new product deployments and spending cycles with these customers, and we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, we typically provide pricing discounts to large customers, which reduces gross margins for the period in which such sales occur.

[0001596532-25-000106:mdna:9]
We believe an increased focus on the deployment of AI enabled solutions by our large customers has accelerated the need for advanced technology offerings including some offerings from potential new market entrants.  This prioritization and acceleration of AI related infrastructure investment has at times come in conjunction with a reduction or changes in the mix of previously planned purchases and various cost reduction measures by these customers, including optimization and increased efficiency in non-AI related capital expenditures. In addition, although the focus on deployment of AI enabled solutions has driven increased demand for networking, the long-term trajectory is unknown. As such, demand estimates for our new products are difficult to forecast and can create volatility in our revenue. In some instances, such measures have had, and may continue to have, an impact on certain current or future projects and have reduced our visibility to customer demand and may result in a reduction or uncertainty in the timing of orders from these large customers and increase the risk of charges for excess and obsolete inventory. We remain in a period of new product introductions and expanded use cases, particularly in the AI Ethernet market. This has resulted in increased customer trials and contracts with acceptance periods, and an increase in the volatility and magnitude of our product deferred revenue balances, which in turn may create variability in our revenue results on a quarterly and annual basis. In addition, if we are not able to satisfy the requirements under customer trials or contracts with

[0001596532-25-000106:mdna:10]
acceptance periods, we may be required to accept product returns from our customers, which would prevent us from recognizing revenue on such transactions and may result in the write-down of inventory.

[0001596532-25-000106:mdna:11]
[same as prior period, unchanged from 0001596532-24-000368:mdna:12]

[0001596532-25-000106:mdna:12]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including the effects of, among other things, inflation, monetary policy shifts, recession risks, potential supply chain disruptions, changes in government administration policy positions, and geopolitical pressures, including escalating international trade measures and tariff uncertainty.

[0001596532-25-000106:mdna:13]
We are working closely with our contract manufacturers and suppliers to optimize our supply chain and production efforts in response to the uncertainty around international trade policy and tariff rates. While our supply chain has currently not experienced a significant disruption as a result of the recent trade measures, the extent of such policies and tariffs that will ultimately be implemented is unknown at this time, and the future impact to our supply chain and cost of our products is uncertain. We continue to ship products against previously committed demand/deployment plans and accelerate some deployments where needed, while trying to balance our customers' requirements and lead times with the availability of key components and products and lead times of our key suppliers and contract manufacturers. As a result, some shipments against these previously committed demand/deployment plans have extended into 2025. Given the timing and prioritization of customer orders and shipment patterns, as well as the timing and outcome of customer trials and contracts with acceptance periods, near term revenue trends may not be reflective of current demand levels, and as discussed above will also benefit from demand/deployment plans that have been previously committed. We expect that our inventory and purchase commitments will remain volatile as we ramp new product introductions. The magnitude of these balances, combined with a reduction in customer demand-planning horizons and shifting customer product priorities, has resulted in an increased risk that we may not be able to sell all of this inventory, which in turn has resulted in additional excess and obsolete inventory and supplier liability charges. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. These cost pressures may be increased if escalating tariff and non-tariff international trade measures continue to affect our supply chain. We also may not be able to fully mitigate the cost impacts of escalating tariff and non-tariff international trade measures or be able to pass on the full burden of the increase in trade-related costs to our customers, which could further negatively impact our gross margin. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods.

[0001596532-25-000106:mdna:14]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply and uncertainty about international trade policy and tariff rates could negatively impact our business, and as a result we may face challenges in implementing countermeasures and responding to these changing trading conditions. Furthermore, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.

[0001596532-25-000106:mdna:15]
18

[0001596532-25-000106:mdna:16]
[same as prior period, unchanged from 0001596532-24-000368:mdna:17]

[0001596532-25-000106:mdna:17]
Three Months Ended March 31, 2025 Compared to Three Months Ended March 31, 2024

[0001596532-25-000106:mdna:18]
Revenue, Cost of Revenue and Gross Margin (in millions, except percentages)

[0001596532-25-000106:mdna:19]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2025 |  | 2024 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,692.5 |  |  | $ | 1,328.8 |  |  | $ | 363.7 |  |  | 27.4 | % |  |  |  |  |  |  |  |  |
| Service |  | 312.3 |  |  | 242.6 |  |  | 69.7 |  |  | 28.7 |  |  |  |  |  |  |  |  |  |
| Total revenue |  | 2,004.8 |  |  | 1,571.4 |  |  | 433.4 |  |  | 27.6 |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 672.7 |  |  | 521.7 |  |  | 151.0 |  |  | 28.9 |  |  |  |  |  |  |  |  |  |
| Service |  | 56.0 |  |  | 48.3 |  |  | 7.7 |  |  | 15.9 |  |  |  |  |  |  |  |  |  |
| Total cost of revenue |  | 728.7 |  |  | 570.0 |  |  | 158.7 |  |  | 27.8 |  |  |  |  |  |  |  |  |  |
| Gross profit |  | $ | 1,276.1 |  |  | $ | 1,001.4 |  |  | $ | 274.7 |  |  | 27.4 | % |  |  |  |  |  |  |  |  |
| Gross margin |  | 63.7 | % |  | 63.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001596532-25-000106:mdna:20]
Revenue by Geography (in millions, except percentages)

[0001596532-25-000106:mdna:21]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2025 |  | % of Total |  | 2024 |  | % of Total |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,598.5 |  |  | 79.7 | % |  | $ | 1,255.4 |  |  | 79.9 | % |  |  |  |  |  |  |  |  |
| Europe, Middle East and Africa |  | 174.6 |  |  | 8.7 |  |  | 141.6 |  |  | 9.0 |  |  |  |  |  |  |  |  |  |
| Asia-Pacific |  | 231.7 |  |  | 11.6 |  |  | 174.4 |  |  | 11.1 |  |  |  |  |  |  |  |  |  |
| Total revenue |  | $ | 2,004.8 |  |  | 100.0 | % |  | $ | 1,571.4 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

[0001596532-25-000106:mdna:22]
[same as prior period, unchanged from 0001596532-24-000368:mdna:23]

[0001596532-25-000106:mdna:23]
[same as prior period, unchanged from 0001596532-24-000368:mdna:24]

[0001596532-25-000106:mdna:24]
Product revenue increased by $363.7 million, or 27.4% for the three months ended March 31, 2025, compared to the same period in 2024. This increase reflects increased demand for our switching and routing platforms across our customer base. In addition, service revenue increased by $69.7 million, or 28.7% for the three months ended March 31, 2025, compared to the same period in 2024, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenue represented 20.3% of total revenue for the three months ended March 31, 2025, increasing from 20.1% for the same period in the prior year, which was primarily influenced by changes in the geographic mix of sales to our large global customers.

[0001596532-25-000106:mdna:25]
[same as prior period, unchanged from 0001596532-24-000368:mdna:26]

[0001596532-25-000106:mdna:26]
Cost of product revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs of our manufacturing operations, including freight, and other costs associated with manufacturing our products and managing our inventory and supply chain, including costs related to tariffs on our products that are manufactured internationally. Cost of service revenue primarily consists of personnel and other costs associated with our global customer support and services organizations.

[0001596532-25-000106:mdna:27]
Cost of revenue increased by $158.7 million, or 27.8% for the three months ended March 31, 2025, compared to the same period in 2024. These increases were primarily driven by a corresponding increase in product and service revenues.

[0001596532-25-000106:mdna:28]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including pricing pressure on our products and services due to competition, the mix of sales to large end customers who generally receive lower pricing, the mix of products sold, manufacturing-related costs, including costs associated with supply chain sourcing activities, merchant silicon costs, and excess/obsolete inventory charges, including charges for excess/obsolete

[0001596532-25-000106:mdna:29]
component inventory held by our contract manufacturers and suppliers. We expect our gross margin to fluctuate over time depending on the factors described above and may be adversely impacted by unpredictable international trade policy and tariff rates.

[0001596532-25-000106:mdna:30]
Gross margin was 63.7% for the three months ended March 31, 2025, consistent with the amount in the same period in 2024.

[0001596532-25-000106:mdna:31]
Operating Expenses (in millions, except percentages)

[0001596532-25-000106:mdna:32]
[same as prior period, unchanged from 0001596532-24-000368:mdna:32]

[0001596532-25-000106:mdna:33]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2025 |  | 2024 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 266.4 |  |  | $ | 208.4 |  |  | $ | 58.0 |  |  | 27.8 | % |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 116.6 |  |  | 105.1 |  |  | 11.5 |  |  | 10.9 |  |  |  |  |  |  |  |  |  |
| General and administrative |  | 34.3 |  |  | 27.7 |  |  | 6.6 |  |  | 23.8 |  |  |  |  |  |  |  |  |  |
| Total operating expenses |  | $ | 417.3 |  |  | $ | 341.2 |  |  | $ | 76.1 |  |  | 22.3 | % |  |  |  |  |  |  |  |  |

[0001596532-25-000106:mdna:34]
[same as prior period, unchanged from 0001596532-24-000368:mdna:34]

[0001596532-25-000106:mdna:35]
[same as prior period, unchanged from 0001596532-24-000368:mdna:35]

[0001596532-25-000106:mdna:36]
Research and development expenses increased by $58.0 million, or 27.8% for the three months ended March 31, 2025, compared to the same period in 2024. The increase was primarily driven by a $25.1 million increase in personnel costs due to headcount growth, and a $19.3 million increase in new product introduction costs, including non-recurring engineering costs as we expand our product portfolio.

[0001596532-25-000106:mdna:37]
[same as prior period, unchanged from 0001596532-24-000368:mdna:37]

[0001596532-25-000106:mdna:38]
[same as prior period, unchanged from 0001596532-24-000368:mdna:38]

[0001596532-25-000106:mdna:39]
Sales and marketing expenses increased by $11.5 million, or 10.9% for the three months ended March 31, 2025, compared to the same period in 2024, which was primarily driven by increased personnel costs due to headcount growth.

[0001596532-25-000106:mdna:40]
[same as prior period, unchanged from 0001596532-24-000368:mdna:40]

[0001596532-25-000106:mdna:41]
[same as prior period, unchanged from 0001596532-24-000368:mdna:41]

[0001596532-25-000106:mdna:42]
General and administrative expenses increased by $6.6 million, or 23.8% for the three months ended March 31, 2025, compared to the same period in 2024, impacted by an increase in personnel costs.

[0001596532-25-000106:mdna:43]
Other Income (Expense), Net (in millions, except percentages)

[0001596532-25-000106:mdna:44]
Other income (expense), net consists primarily of interest income from our cash, cash equivalents and marketable securities. We expect other income (expense), net may fluctuate in the future as a result of changes in interest rates and changes in our cash, cash equivalents and marketable securities balances.

[0001596532-25-000106:mdna:45]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2025 |  | 2024 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 90.2 |  |  | $ | 63.8 |  |  | $ | 26.4 |  |  | 41.4 | % |  |  |  |  |  |  |  |  |
| Other income (expense), net |  | 6.0 |  |  | (1.2) |  |  | 7.2 |  |  | 600.0 |  |  |  |  |  |  |  |  |  |
| Total other income (expense), net |  | $ | 96.2 |  |  | $ | 62.6 |  |  | $ | 33.6 |  |  | 53.7 | % |  |  |  |  |  |  |  |  |

[0001596532-25-000106:mdna:46]
The favorable movement in other income (expense), net, during the three months ended March 31, 2025 compared to the same period in 2024 was primarily driven by increased interest income of $26.4 million due to an increase in our cash and marketable securities balances.

[0001596532-25-000106:mdna:47]
Provision for Income Taxes (in millions, except percentages)

[0001596532-25-000106:mdna:48]
[same as prior period, unchanged from 0001596532-24-000368:mdna:49]

[0001596532-25-000106:mdna:49]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2025 |  | 2024 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Income before income taxes |  | $ | 955.0 |  |  | $ | 722.8 |  |  | $ | 232.2 |  |  | 32.1 | % |  |  |  |  |  |  |  |  |
| Provision for income taxes |  | 141.2 |  |  | 85.1 |  |  | 56.1 |  |  | 65.9 | % |  |  |  |  |  |  |  |  |
| Effective tax rate |  | 14.8 | % |  | 11.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001596532-25-000106:mdna:50]
The increase in the effective tax rates in the three months ended March 31, 2025, as compared to the same period in 2024, was primarily due to a decrease in the proportion of tax benefits attributable to equity-based compensation versus total pre-tax income.

[0001596532-25-000106:mdna:51]
[same as prior period, unchanged from 0001596532-24-000368:mdna:52]

[0001596532-25-000106:mdna:52]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of March 31, 2025, our total balance of cash, cash equivalents and marketable securities was approximately $8.1 billion, of which approximately $796.4 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-25-000106:mdna:53]
Our cash, cash equivalents and marketable securities are held for general business purposes, including the funding of working capital. Our marketable securities investment portfolio is primarily invested in highly-rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, stock repurchases, and capital expenditures, including the planned construction of a building for office, lab and data center space. In addition, we expect that our inventory and purchase commitments will remain volatile as we ramp new product introductions. In particular, we have increased our purchase commitments to respond to the rapid deployment of AI networks and reduce overall lead times which may increase our working capital requirements. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-25-000106:mdna:54]
Cash Flows (in millions)

[0001596532-25-000106:mdna:55]
|  |  | Three Months Ended March 31, |
|  |  | 2025 |  | 2024 |
| Cash provided by operating activities |  | $ | 641.7 |  |  | $ | 513.8 |  |
| Cash used in investing activities |  | (765.9) |  |  | (295.6) |  |
| Cash used in financing activities |  | (793.8) |  |  | (63.1) |  |
| Effect of exchange rate changes |  | 0.7 |  |  | (1.6) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | (917.3) |  |  | $ | 153.5 |  |

[0001596532-25-000106:mdna:56]
[same as prior period, unchanged from 0001596532-24-000368:mdna:58]

[0001596532-25-000106:mdna:57]
During the three months ended March 31, 2025, cash provided by operating activities was $641.7 million, consisting of net income of $813.8 million, offset by a net increase of $159.7 million in working capital requirements. The increase in working capital requirements primarily consisted of an increase in accounts receivable of $295.4 million due to increased product and service billings, a $173.3 million decrease in other liabilities primarily due to timing of inventory-related receipts and payments, a $122.7 million increase in inventory and $113.7 million increase in other assets driven by increased deferred cost of sales associated with higher product revenue deferrals. These cash outflows were partly offset by a $241.3 million increase in income tax payables related to timing of payments, and an increase in deferred revenue of $297.4 million primarily resulting from an increase in customer PCS contracts and an increase in product deferred revenue related to customer contracts with acceptance terms.

[0001596532-25-000106:mdna:58]
During the three months ended March 31, 2024, cash provided by operating activities was $513.8 million, consisting of net income of $637.7 million, non-cash adjustments to net income of $7.2 million and offset by a net increase of $131.1 million in working capital requirements. The non-cash adjustments to net income were driven by stock-based compensation and depreciation and amortization, largely offset by an increase in deferred taxes primarily due to the capitalization of research and development costs under Section 174 of the Internal Revenue Code ("IRC"). The increase in working capital requirements primarily consisted of a $207.2 million decrease in accounts payable primarily due to timing of payments, an $80.0 million increase in inventory and an increase in accounts receivable of $65.5 million. These cash outflows were partly offset by a $157.5 million increase in income tax payables related to timing of payments, and an increase in deferred revenue of $157.0 million primarily resulting from an increase in customer PCS contracts, partly offset by a reduction in product deferred revenue related to customer contracts with acceptance terms, and a $38.1 million decrease in prepaid and other assets.

[0001596532-25-000106:mdna:59]
[same as prior period, unchanged from 0001596532-24-000368:mdna:61]

[0001596532-25-000106:mdna:60]
During the three months ended March 31, 2025, cash used in investing activities was $765.9 million, consisting of  purchases of marketable securities of $1,545.5 million. These amounts were partially offset by proceeds from maturities and sales of marketable securities of $808.0 million.

[0001596532-25-000106:mdna:61]
During the three months ended March 31, 2024, cash used in investing activities was $295.6 million, consisting of  purchases of marketable securities of $912.4 million, and purchases of property and equipment of $9.4 million. These amounts were partially offset by proceeds from maturities and sales of marketable securities of $627.2 million.

[0001596532-25-000106:mdna:62]
[same as prior period, unchanged from 0001596532-24-000368:mdna:64]

[0001596532-25-000106:mdna:63]
During the three months ended March 31, 2025, cash used in financing activities was $793.8 million, consisting of payments for repurchases of our common stock from the open market of $787.1 million.

[0001596532-25-000106:mdna:64]
During the three months ended March 31, 2024, cash used in financing activities was $63.1 million, consisting of payments for repurchases of our common stock from the open market of $62.7 million, and employee taxes withheld and paid of $25.5 million upon vesting of restricted stock units, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $25.1 million.

[0001596532-25-000106:mdna:65]
[same as prior period, unchanged from 0001596532-24-000368:mdna:67]

[0001596532-25-000106:mdna:66]
From time to time, we repurchase shares of our common stock pursuant to repurchase programs that are funded from working capital. Our current repurchase program (the "Existing Repurchase Program") allows for stock repurchases of up to $1.2 billion through May 2027. In May 2025, our board of directors authorized and announced a new $1.5 billion stock repurchase program (the “New Repurchase Program” and together with the Existing Repurchase Program, the "Repurchase Programs"). The Repurchase Programs do not obligate us to acquire any of our common stock and may be suspended or discontinued by the Company at any time without prior notice. During the three months ended March 31, 2025, we repurchased a total of $787.1 million of our common stock under our Existing Repurchase Program. As of March 31, 2025, the remaining authorized amount for repurchases under the Existing Repurchase Program was $133.9 million. In April 2025, we repurchased

[0001596532-25-000106:mdna:67]
an additional $100.0 million of our common stock authorized under the Existing Repurchase Program. Refer to Note 6. Stockholders' Equity and Stock-Based Compensation of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-25-000106:mdna:68]
[same as prior period, unchanged from 0001596532-24-000368:mdna:73]

[0001596532-25-000106:mdna:69]
[same as prior period, unchanged from 0001596532-24-000368:mdna:74]

[0001596532-25-000106:mdna:70]
[same as prior period, unchanged from 0001596532-24-000368:mdna:75]

[0001596532-25-000106:mdna:71]
[same as prior period, unchanged from 0001596532-24-000368:mdna:76]

[0001596532-25-000106:mdna:72]
Purchase obligations not recorded on our balance sheet represent an estimate of all non-cancellable open purchase orders and contractual obligations, made either directly by Arista or by our contract manufacturers on our behalf, in the ordinary course of business for which we have not received the goods or services. As of March 31, 2025, we had $3.5 billion of such purchase obligations, of which $3.0 billion are expected to be received within one year, and $0.5 billion are expected to be received after one year. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-25-000106:mdna:73]
[same as prior period, unchanged from 0001596532-24-000368:mdna:80]

[0001596532-25-000106:mdna:74]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office, lab and data center space. The estimated remaining capital expenditures related to this project are expected to be approximately $215.0 million to $240.0 million for the next two years, with construction expected to be completed by the end of fiscal 2026.

[0001596532-25-000106:mdna:75]
[same as prior period, unchanged from 0001596532-24-000368:mdna:85]

[0001596532-25-000106:mdna:76]
As of March 31, 2025, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-25-000106:mdna:77]
[same as prior period, unchanged from 0001596532-24-000368:mdna:87]

[0001596532-25-000106:mdna:78]
Our management’s discussion and analysis of financial condition and results of operations are based on our unaudited condensed consolidated financial statements, which have been prepared in accordance with GAAP. The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting estimates in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our Annual Report on Form 10-K filed with the SEC on February 18, 2025 reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as disclosed in our Annual Report on Form 10-K.

[0001596532-25-000106:mdna:79]
[same as prior period, unchanged from 0001596532-24-000368:mdna:89]

[0001596532-25-000106:mdna:80]
Refer to the subheading titled “Recent Accounting Pronouncements Not Yet Effective” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
