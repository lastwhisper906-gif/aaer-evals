# ANET MD&A — 0001596532-18-000233


## mdna

[0001596532-18-000233:mdna:1]
[same as prior period, unchanged from 0001596532-18-000174:mdna:1]

[0001596532-18-000233:mdna:2]
[same as prior period, unchanged from 0001596532-18-000174:mdna:2]

[0001596532-18-000233:mdna:3]
We are a leading supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation data centers for enterprise support. Our cloud networking solutions consist of our Extensible Operating System, or EOS, a set of network applications and our Ethernet switching and routing platforms. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. At the core of our cloud networking platform is EOS, which was purpose-built to be fully programmable and highly modular. The programmability of EOS has allowed us to create a set of software applications that address the requirements of cloud networking, including workflow automation, network visibility and analytics, and has also allowed us to rapidly integrate with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001596532-18-000233:mdna:4]
We believe that cloud networks will continue to replace legacy network technologies, and that our cloud networking platform addresses the large and growing cloud networking segment of data center switching, which remains in the early stage of

[0001596532-18-000233:mdna:5]
adoption. Cloud networks are subject to increasing performance requirements due to the growing number of connected devices, as well as new enterprise and consumer applications. Computing architectures are evolving to meet the need for constant connectivity and access to data and applications. We expect to continue growing our organization to meet the needs of new and existing customers as they increasingly realize the performance and cost benefits of our cloud networking solutions and as they expand their cloud networks. Accordingly, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our rapid development of new features and applications.

[0001596532-18-000233:mdna:6]
[same as prior period, unchanged from 0001596532-18-000174:mdna:6]

[0001596532-18-000233:mdna:7]
[same as prior period, unchanged from 0001596532-18-000174:mdna:7]

[0001596532-18-000233:mdna:8]
[same as prior period, unchanged from 0001596532-18-000174:mdna:8]

[0001596532-18-000233:mdna:9]
[same as prior period, unchanged from 0001596532-18-000174:mdna:9]

[0001596532-18-000233:mdna:10]
On August 6, 2018, we entered into a binding term sheet with Cisco ("Term Sheet"). Under the Term Sheet, we paid Cisco $400.0 million on August 20, 2018, and the parties obtained dismissals of all ongoing district court and USITC litigation between them. Cisco granted us a release for all past claims relating to the patents Cisco asserted against us in the district court and USITC, and we granted Cisco a release from all past antitrust and unfair competition claims. These mutual releases extended to the Company's and Cisco’s customers, contract manufacturers, and partners. The parties further agreed to a five-year stand-down period for any utility patent infringement claims either may have against features currently implemented in the other party’s products and services, with some carve-outs for products stemming from acquired companies. The parties further agreed to a three-year dispute resolution process for allegations by either party against new and/or modified features in the other party’s products. We also agreed to make certain modifications to our Command Line Interface (“CLI”).

[0001596532-18-000233:mdna:11]
Furthermore, in order to comply with USITC exclusion and cease and desist orders previously issued in relation to the Cisco legal matter, we made certain design changes to our products for sale in the United States. Following the expiration and invalidation of related patent claims, effective July 1, 2018, certain features previously covered by the orders could be re-incorporated into our products.  We are working with customers to complete any remaining re-qualification procedures related to the reintroduction of these features, the timing of which could result in an impact to our revenue and our deferred revenue balances.

[0001596532-18-000233:mdna:12]
Acquisitions

[0001596532-18-000233:mdna:13]
On August 2, 2018, we completed the acquisition of Mojo Networks, Inc. (“Mojo”), a provider of Cognitive WiFi and cloud-managed wireless networking solutions headquartered in Mountain View, California. We expect to extend our cognitive cloud networking architecture with the addition of Mojo by providing secure, high performance cognitive WiFi at cloud scale. On September 12, 2018, we completed the acquisition of Metamako Holding PTY LTD. (“Metamako”). Headquartered in Sydney,

[0001596532-18-000233:mdna:14]
Australia, Metamako was a leader in solutions for latency sensitive business applications. We expect this acquisition to play a key role in the delivery of our next generation platforms for low-latency applications.

[0001596532-18-000233:mdna:15]
[same as prior period, unchanged from 0001596532-18-000174:mdna:13]

[0001596532-18-000233:mdna:16]
The following table summarizes historical results of operations for the periods presented and as a percentage of revenue for those periods.  We have derived the data for the three and nine months ended September 30, 2018 and 2017 from our unaudited condensed consolidated financial statements included in this Quarterly Report on Form 10-Q.

[0001596532-18-000233:mdna:17]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  |  | (in thousands) |
| Consolidated Statements of Operations Data: |  |  |  |  |  |  |  |  |
| Revenue |  |  |  |  |  |  |  |  |
| Product |  | $ | 485,481 |  |  | $ | 380,344 |  |  | $ | 1,337,865 |  |  | $ | 1,025,615 |  |
| Service |  | 77,828 |  |  | 57,289 |  |  | 217,778 |  |  | 152,704 |  |
| Total revenue |  | 563,309 |  |  | 437,633 |  |  | 1,555,643 |  |  | 1,178,319 |  |
| Cost of revenue (1) |  |  |  |  |  |  |  |  |
| Product |  | 187,764 |  |  | 145,874 |  |  | 516,077 |  |  | 390,116 |  |
| Service |  | 13,962 |  |  | 11,142 |  |  | 41,181 |  |  | 33,599 |  |
| Total cost of revenue |  | 201,726 |  |  | 157,016 |  |  | 557,258 |  |  | 423,715 |  |
| Gross profit |  | 361,583 |  |  | 280,617 |  |  | 998,385 |  |  | 754,604 |  |
| Operating expenses (1) |  |  |  |  |  |  |  |  |
| Research and development |  | 117,589 |  |  | 79,610 |  |  | 324,029 |  |  | 242,414 |  |
| Sales and marketing |  | 47,903 |  |  | 40,640 |  |  | 136,231 |  |  | 116,297 |  |
| General and administrative |  | 15,321 |  |  | 19,535 |  |  | 53,420 |  |  | 65,009 |  |
| Legal settlement |  | — |  |  | — |  |  | 405,000 |  |  | — |  |
| Total operating expenses |  | 180,813 |  |  | 139,785 |  |  | 918,680 |  |  | 423,720 |  |
| Income from operations |  | 180,770 |  |  | 140,832 |  |  | 79,705 |  |  | 330,884 |  |
| Other income (expense), net |  |  |  |  |  |  |  |  |
| Interest expense |  | (673 | ) |  | (701 | ) |  | (2,040 | ) |  | (2,039 | ) |
| Other income (expense), net |  | 9,292 |  |  | 2,136 |  |  | 12,646 |  |  | 4,280 |  |
| Total other income (expense), net |  | 8,619 |  |  | 1,435 |  |  | 10,606 |  |  | 2,241 |  |
| Income before income taxes |  | 189,389 |  |  | 142,267 |  |  | 90,311 |  |  | 333,125 |  |
| Provision for (benefit from) income taxes |  | 20,865 |  |  | 8,545 |  |  | (67,482 | ) |  | 13,757 |  |
| Net income |  | $ | 168,524 |  |  | $ | 133,722 |  |  | $ | 157,793 |  |  | $ | 319,368 |  |
| __________________________ |  |  |  |  |  |  |  |  |

[0001596532-18-000233:mdna:18]
[same as prior period, unchanged from 0001596532-18-000174:mdna:16]

[0001596532-18-000233:mdna:19]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  |  | (in thousands) |
| Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,268 |  |  | $ | 1,113 |  |  | $ | 3,706 |  |  | $ | 3,224 |  |
| Research and development |  | 12,010 |  |  | 11,048 |  |  | 34,700 |  |  | 30,977 |  |
| Sales and marketing |  | 6,537 |  |  | 5,115 |  |  | 18,771 |  |  | 12,651 |  |
| General and administrative |  | 3,439 |  |  | 2,876 |  |  | 9,406 |  |  | 8,139 |  |
| Total stock-based compensation |  | $ | 23,254 |  |  | $ | 20,152 |  |  | $ | 66,583 |  |  | $ | 54,991 |  |

[0001596532-18-000233:mdna:20]
26

[0001596532-18-000233:mdna:21]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  |  | (as a percentage of revenue) |
| Revenue |  |  |  |  |  |  |  |  |
| Product |  | 86.2 | % |  | 86.9 | % |  | 86.0 | % |  | 87.0 | % |
| Service |  | 13.8 |  |  | 13.1 |  |  | 14.0 |  |  | 13.0 |  |
| Total revenue |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |
| Product |  | 33.3 |  |  | 33.4 |  |  | 33.2 |  |  | 33.1 |  |
| Service |  | 2.5 |  |  | 2.5 |  |  | 2.6 |  |  | 2.9 |  |
| Total cost of revenue |  | 35.8 |  |  | 35.9 |  |  | 35.8 |  |  | 36.0 |  |
| Gross margin |  | 64.2 |  |  | 64.1 |  |  | 64.2 |  |  | 64.0 |  |
| Operating expenses |  |  |  |  |  |  |  |  |
| Research and development |  | 20.9 |  |  | 18.2 |  |  | 20.9 |  |  | 20.5 |  |
| Sales and marketing |  | 8.5 |  |  | 9.2 |  |  | 8.8 |  |  | 9.9 |  |
| General and administrative |  | 2.7 |  |  | 4.5 |  |  | 3.4 |  |  | 5.5 |  |
| Legal settlement |  | — |  |  | — |  |  | 26.0 |  |  | — |  |
| Total operating expenses |  | 32.1 |  |  | 31.9 |  |  | 59.1 |  |  | 35.9 |  |
| Income from operations |  | 32.1 |  |  | 32.2 |  |  | 5.1 |  |  | 28.1 |  |
| Interest expense |  | (0.1 | ) |  | (0.1 | ) |  | (0.1 | ) |  | (0.2 | ) |
| Other income (expense), net |  | 1.6 |  |  | 0.5 |  |  | 0.8 |  |  | 0.4 |  |
| Total other income (expense), net |  | 1.5 |  |  | 0.4 |  |  | 0.7 |  |  | 0.2 |  |
| Income before income taxes |  | 33.6 |  |  | 32.6 |  |  | 5.8 |  |  | 28.3 |  |
| Provision for (benefit from) income taxes |  | 3.7 |  |  | 2.0 |  |  | (4.3 | ) |  | 1.2 |  |
| Net income |  | 29.9 | % |  | 30.6 | % |  | 10.1 | % |  | 27.1 | % |

[0001596532-18-000233:mdna:22]
Three and Nine Months Ended September 30, 2018 Compared to Three and Nine Months Ended September 30, 2017

[0001596532-18-000233:mdna:23]
[same as prior period, unchanged from 0001596532-18-000174:mdna:21]

[0001596532-18-000233:mdna:24]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | Change in |  | 2018 |  | 2017 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 485,481 |  |  | $ | 380,344 |  |  | $ | 105,137 |  |  | 27.6 | % |  | $ | 1,337,865 |  |  | $ | 1,025,615 |  |  | $ | 312,250 |  |  | 30.4 | % |
| Service |  | 77,828 |  |  | 57,289 |  |  | 20,539 |  |  | 35.9 |  |  | 217,778 |  |  | 152,704 |  |  | 65,074 |  |  | 42.6 |  |
| Total revenue |  | 563,309 |  |  | 437,633 |  |  | 125,676 |  |  | 28.7 |  |  | 1,555,643 |  |  | 1,178,319 |  |  | 377,324 |  |  | 32.0 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 187,764 |  |  | 145,874 |  |  | 41,890 |  |  | 28.7 |  |  | 516,077 |  |  | 390,116 |  |  | 125,961 |  |  | 32.3 |  |
| Service |  | 13,962 |  |  | 11,142 |  |  | 2,820 |  |  | 25.3 |  |  | 41,181 |  |  | 33,599 |  |  | 7,582 |  |  | 22.6 |  |
| Total cost of revenue |  | 201,726 |  |  | 157,016 |  |  | 44,710 |  |  | 28.5 |  |  | 557,258 |  |  | 423,715 |  |  | 133,543 |  |  | 31.5 |  |
| Gross profit |  | $ | 361,583 |  |  | $ | 280,617 |  |  | $ | 80,966 |  |  | 28.9 | % |  | $ | 998,385 |  |  | $ | 754,604 |  |  | $ | 243,781 |  |  | 32.3 | % |
| Gross margin |  | 64.2% |  | 64.1% |  |  |  |  |  | 64.2% |  | 64.0% |  |  |  |  |

[0001596532-18-000233:mdna:25]
[same as prior period, unchanged from 0001596532-18-000174:mdna:23]

[0001596532-18-000233:mdna:26]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2018 |  | % of Total |  | 2017 |  | % of Total |  | 2018 |  | % of Total |  | 2017 |  | % of Total |
| Americas |  | $ | 406,666 |  |  | 72.2 | % |  | $ | 309,318 |  |  | 70.7 | % |  | $ | 1,099,624 |  |  | 70.7 | % |  | $ | 878,201 |  |  | 74.5 | % |
| Europe, Middle East and Africa |  | 92,911 |  |  | 16.5 |  |  | 79,143 |  |  | 18.1 |  |  | 316,608 |  |  | 20.4 |  |  | 199,244 |  |  | 16.9 |  |
| Asia-Pacific |  | 63,732 |  |  | 11.3 |  |  | 49,172 |  |  | 11.2 |  |  | 139,411 |  |  | 8.9 |  |  | 100,874 |  |  | 8.6 |  |
| Total revenue |  | $ | 563,309 |  |  | 100.0 | % |  | $ | 437,633 |  |  | 100.0 | % |  | $ | 1,555,643 |  |  | 100.0 | % |  | $ | 1,178,319 |  |  | 100.0 | % |

[0001596532-18-000233:mdna:27]
[same as prior period, unchanged from 0001596532-18-000174:mdna:25]

[0001596532-18-000233:mdna:28]
Product revenue increased $105.1 million, or 27.6%, and $312.3 million, or 30.4%, in the three and nine months ended September 30, 2018, respectively, compared to the same periods in 2017. The increases were primarily driven by sales to our existing customers as they continued to expand their businesses. In addition, our newer switch products have continued to gain market acceptance, which has contributed to our revenue growth.  Service revenue increased $20.5 million, or 35.9%, and $65.1 million, or 42.6% in the three and nine months ended September 30, 2018, respectively, compared to the same periods in 2017 as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. We continue to experience pricing pressure on our products and services due to competition, but demand for our products and growth in our installed base has more than offset this pricing pressure.

[0001596532-18-000233:mdna:29]
[same as prior period, unchanged from 0001596532-18-000174:mdna:28]

[0001596532-18-000233:mdna:30]
[same as prior period, unchanged from 0001596532-18-000174:mdna:29]

[0001596532-18-000233:mdna:31]
Cost of revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs in our manufacturing operations department, and other manufacturing-related costs associated with manufacturing our products and managing our inventory.  Cost of revenue increased $44.7 million, or 28.5%, and $133.5 million, or 31.5%, in the three and nine months ended September 30, 2018 compared to the same periods in 2017. The increases in cost of revenue were primarily due to the corresponding increases in product revenues. We expect our cost of product revenue to continue to increase as our product revenue increases. Cost of providing PCS and other services consists primarily of personnel costs for our global customer support organization.

[0001596532-18-000233:mdna:32]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including sales to large end customers who generally receive lower pricing, manufacturing-related costs including costs associated with supply chain sourcing activities, merchant silicon costs, the mix of products sold, and excess/obsolete inventory write-downs, including charges for excess/obsolete component inventory held by our contract manufacturers. Gross margin remained consistent, increasing slightly from 64.1% to 64.2% for the three months ended September 30, 2018, and from 64.0% to 64.2% for the nine months ended September 30, 2018 compared to the same periods in 2017. These increases were primarily driven by relatively fixed manufacturing overhead and service costs as we scaled our business, partially offset by a decrease in product margins primarily due to customer mix. We expect our gross margins to fluctuate over time, depending on the factors described above.

[0001596532-18-000233:mdna:33]
[same as prior period, unchanged from 0001596532-18-000174:mdna:32]

[0001596532-18-000233:mdna:34]
[same as prior period, unchanged from 0001596532-18-000174:mdna:33]

[0001596532-18-000233:mdna:35]
28

[0001596532-18-000233:mdna:36]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | Change in |  | 2018 |  | 2017 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 117,589 |  |  | $ | 79,610 |  |  | $ | 37,979 |  |  | 47.7 | % |  | $ | 324,029 |  |  | $ | 242,414 |  |  | $ | 81,615 |  |  | 33.7 | % |
| Sales and marketing |  | 47,903 |  |  | 40,640 |  |  | 7,263 |  |  | 17.9 |  |  | 136,231 |  |  | 116,297 |  |  | 19,934 |  |  | 17.1 |  |
| General and administrative |  | 15,321 |  |  | 19,535 |  |  | (4,214 | ) |  | (21.6 | ) |  | 53,420 |  |  | 65,009 |  |  | (11,589 | ) |  | (17.8 | ) |
| Legal settlement |  | — |  |  | — |  |  | — |  |  | * |  | 405,000 |  |  | — |  |  | 405,000 |  |  | * |
| Total operating expenses |  | $ | 180,813 |  |  | $ | 139,785 |  |  | $ | 41,028 |  |  | 29.4 | % |  | $ | 918,680 |  |  | $ | 423,720 |  |  | $ | 494,960 |  |  | 116.8 | % |
| ____________________ |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| * Not meaningful. |

[0001596532-18-000233:mdna:37]
[same as prior period, unchanged from 0001596532-18-000174:mdna:35]

[0001596532-18-000233:mdna:38]
Research and development expenses increased $38.0 million, or 47.7%, and $81.6 million, or 33.7%, for the three and nine months ended September 30, 2018, respectively, compared to the same periods in 2017. The increases in the three and nine months ended September 30, 2018 included a $11.5 million and a $35.2 million increase in personnel costs, including stock-based compensation and corporate bonuses, driven primary by headcount growth from normal hiring process and from the two acquisitions we completed in the third quarter of 2018, and a $20.4 million and a $32.9 million increase in new product introduction costs, driven by additional development projects. In addition, research and development related facilities and IT costs increased $2.1 million and $6.7 million in each period accommodating our acquired businesses and also reflecting ongoing headcount growth and higher IT and other consulting costs.

[0001596532-18-000233:mdna:39]
[same as prior period, unchanged from 0001596532-18-000174:mdna:37]

[0001596532-18-000233:mdna:40]
[same as prior period, unchanged from 0001596532-18-000174:mdna:38]

[0001596532-18-000233:mdna:41]
Sales and marketing expenses increased $7.3 million, or 17.9%, and $19.9 million, or 17.1%, for the three and nine months ended September 30, 2018, respectively, compared to the same periods in 2017. The increase in each period was primarily driven by personnel costs which increased by $7.7 million and $17.8 million due to growth in headcount from normal hiring process and from the two acquisitions completed in the third quarter of 2018.

[0001596532-18-000233:mdna:42]
[same as prior period, unchanged from 0001596532-18-000174:mdna:40]

[0001596532-18-000233:mdna:43]
[same as prior period, unchanged from 0001596532-18-000174:mdna:41]

[0001596532-18-000233:mdna:44]
General and administrative expenses decreased $4.2 million, or 21.6%, and $11.6 million, or 17.8%, for the three and nine months ended September 30, 2018, respectively, compared to the same periods in 2017. The decrease in each period was primarily related to a reduced level of litigation activity and bond fee requirement as a result of the settlement of the Cisco litigation in August 2018. These decreases were partially offset by a $1.7 million and a $3.9 million increase in each period in other legal and professional fees, and a $1.1 million and a $2.7 million increase in each period in personnel costs, including increased stock-based compensation, driven by increased headcount.

[0001596532-18-000233:mdna:45]
We expect our general and administrative expenses to fluctuate in absolute dollars from period to period depending on the timing and progress of our litigation activities.

[0001596532-18-000233:mdna:46]
[same as prior period, unchanged from 0001596532-18-000174:mdna:44]

[0001596532-18-000233:mdna:47]
During the three months ended June 30, 2018, we recorded $405.0 million in legal settlement expenses in connection with a binding term sheet that was entered into on August 6, 2018 between the Company and Cisco. The amount was paid to Cisco in August of 2018. See Note 11 of Notes to Condensed Consolidated Financial Statements for further discussion.

[0001596532-18-000233:mdna:48]
[same as prior period, unchanged from 0001596532-18-000174:mdna:46]

[0001596532-18-000233:mdna:49]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | Change in |  | 2018 |  | 2017 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | $ | (673 | ) |  | $ | (701 | ) |  | $ | 28 |  |  | (4.0 | )% |  | $ | (2,040 | ) |  | $ | (2,039 | ) |  | $ | (1 | ) |  | — | % |
| Other income (expense), net |  | 9,292 |  |  | 2,136 |  |  | 7,156 |  |  | 335.0 |  |  | 12,646 |  |  | 4,280 |  |  | 8,366 |  |  | 195.5 |  |
| Total other income (expense), net |  | $ | 8,619 |  |  | $ | 1,435 |  |  | $ | 7,184 |  |  | 500.6 | % |  | $ | 10,606 |  |  | $ | 2,241 |  |  | $ | 8,365 |  |  | 373.3 | % |

[0001596532-18-000233:mdna:50]
The increases in other income (expense), net during the three and nine months ended September 30, 2018 as compared to the same periods of 2017 were primarily driven by a $6.3 million and a $17.0 million increase in interest income, respectively, as we continued to generate cash and expand our marketable securities portfolios. In addition, during the nine months ended September 2018, we recorded a $9.1 million net unrealized loss on our investments in privately-held companies. See Note 5 of Notes to Condensed Consolidated Financial Statements for further discussion.

[0001596532-18-000233:mdna:51]
We expect our interest income to continue to grow in 2018 as we continue to grow our cash balance and invest our excess cash in marketable securities. We expect our foreign currency gains and losses continue to fluctuate in the future due to changes in foreign currency exchange rates. In connection with our adoption of ASU 2016-01 in the first quarter of 2018, other income (expense) may fluctuate in the future as a result of the re-measurement of our private company equity investments upon the occurrence of observable price changes and/or impairments.  See Note 1 of Notes to Condensed Consolidated Financial Statements for details of this new guidance.

[0001596532-18-000233:mdna:52]
[same as prior period, unchanged from 0001596532-18-000174:mdna:50]

[0001596532-18-000233:mdna:53]
[same as prior period, unchanged from 0001596532-18-000174:mdna:51]

[0001596532-18-000233:mdna:54]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | Change in |  | 2018 |  | 2017 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 189,389 |  |  | $ | 142,267 |  |  | $ | 47,122 |  |  | 33.1 | % |  | $ | 90,311 |  |  | $ | 333,125 |  |  | $ | (242,814 | ) |  | (72.9 | )% |
| Provision for (benefit from) income taxes |  | 20,865 |  |  | 8,545 |  |  | 12,320 |  |  | 144.2 | % |  | (67,482 | ) |  | 13,757 |  |  | (81,239 | ) |  | (590.5 | )% |
| Effective tax rate |  | 11.0% |  | 6.0% |  |  |  |  |  | (74.7)% |  | 4.1% |  |  |  |  |

[0001596532-18-000233:mdna:55]
The effective tax rates above reflect tax expense recorded on pre-tax income in the three months ended September 30, 2018 and an overall tax benefit recorded on pre-tax income in the nine months ended September 30, 2018. The tax expense recorded in the three months ended September 30, 2018 includes a lower U.S. corporate tax and U.S. tax on foreign earnings as a result of the Tax Cuts and Jobs Act (“Tax Act”), and the tax effect of acquisitions, including integration. For the nine months ended September 30, 2018, the rate also includes a federal and state tax discrete benefit on the $405.0 million charge related to the legal settlement with Cisco recorded in the three months ended June 30, 2018.  In all periods, excess tax benefits attributable to equity compensation also significantly benefit the effective tax rate.

[0001596532-18-000233:mdna:56]
Integrating intellectual property from acquisitions into our business generally involves intercompany transactions and legal entity restructurings that have the impact of increasing our provision for income taxes. Consequently, our provision for income taxes and our effective tax rate may initially increase in the period of and shortly after an acquisition and integration. The magnitude of this impact will depend upon the specific type, size, and taxing jurisdictions of the intellectual property as well as the relative contribution to income in subsequent periods.

[0001596532-18-000233:mdna:57]
On December 22, 2017, the U.S. government enacted comprehensive tax legislation. The Tax Act makes broad and complex changes to the U.S. tax code, including, but not limited to, (1) reducing the U.S. federal corporate tax rate from 35 percent to 21 percent; (2) requiring companies to pay a one-time transition tax on certain unrepatriated earnings of foreign subsidiaries; (3) generally eliminating U.S. federal income taxes on dividends from foreign subsidiaries; (4) requiring a current inclusion in

[0001596532-18-000233:mdna:58]
U.S. federal taxable income of certain earnings of controlled foreign corporations; and (5) creating the BEAT, a new minimum tax.

[0001596532-18-000233:mdna:59]
The Tax Act includes provisions for GILTI wherein taxes on foreign income are imposed in excess of a deemed return on tangible assets of foreign corporations. This income will effectively be taxed at a 10.5% tax rate in general. Our deferred tax assets and liabilities are still being evaluated to determine if they should be recognized for the basis differences expected to reverse as a result of GILTI provisions that are effective for us after the calendar year ending December 31, 2017. Because of the complexity of the new provisions, we are continuing to evaluate how the provisions will be accounted for under U.S. GAAP wherein companies are allowed to make an accounting policy election of either (i) account for GILTI as a component of tax expense in the period in which we are subject to the rules (the “period cost method”), or (ii) account for GILTI in our measurement of deferred taxes (the “deferred method”). Currently, we have not elected a method but we have included an estimate of the impact to our effective tax rate for the year ended December 31, 2018.  A formal election will only be made  after our completion of the analysis of the GILTI provisions and our election method will depend, in part, on analyzing our global income to determine whether we expect to have future U.S. inclusions in our taxable income related to GILTI and, if so, the impact that is expected.

[0001596532-18-000233:mdna:60]
As of September 30, 2018, we have not yet completed our accounting for the tax effects of the enactment of the Tax Act.  We recognized a provisional tax amount of $51.8 million in the fourth quarter of 2017 for the transition tax liability and the revaluation of our deferred income taxes as a result of the rate change. In the nine months ended September 30, 2018, we did not revise this estimate.  In addition, we recorded a reasonable estimate for the effect of the new legislation as discussed above, which impacts our U.S. income tax liabilities for the year ending December 31, 2018. Our estimates may also be affected as we gain a more thorough understanding of the tax law. These changes could be material to income tax expense. We will continue to refine our estimates related to the impact of the Tax Act during the one-year measurement period allowed under SAB 118.

[0001596532-18-000233:mdna:61]
On July 24, 2018, in the case of Altera Corp. v. Commissioner, the U.S. Court of Appeals for the Ninth Circuit (“Ninth Circuit”) reversed a 2015 decision of the U.S. Tax Court that had found U.S. Treasury Regulations requiring the inclusion of stock-based compensation in intercompany cost-sharing arrangements to be invalid (“Tax Court Decision”).  On August 7, 2018, the Ninth Circuit withdrew its opinion to reverse the Tax Court Decision to allow time for a reconstituted panel to confer on the appeal.  We are currently evaluating the impact of these decisions on our financial statements, which may adversely affect our effective tax rate in future periods.

[0001596532-18-000233:mdna:62]
[same as prior period, unchanged from 0001596532-18-000174:mdna:59]

[0001596532-18-000233:mdna:63]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of September 30, 2018, our total balance of cash, cash equivalents and marketable securities was $1.7 billion, of which approximately $265.9 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-18-000233:mdna:64]
Our cash, cash equivalents and marketable securities are held for working capital purposes. Our marketable securities investment portfolio is primarily invested in highly-rated securities with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities together with cash generated from operations will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and costs incurred related to outstanding litigation claims. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-18-000233:mdna:65]
[same as prior period, unchanged from 0001596532-18-000174:mdna:62]

[0001596532-18-000233:mdna:66]
|  |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 As Adjusted (1) |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 207,300 |  |  | $ | 447,963 |  |
| Cash used in investing activities (1) |  | (583,452 | ) |  | (199,090 | ) |
| Cash provided by financing activities |  | 41,336 |  |  | 38,243 |  |
| Effect of exchange rate changes |  | (984 | ) |  | 697 |  |
| Net increase/(decrease) in cash, cash equivalents and restricted cash |  | $ | (335,800 | ) |  | $ | 287,813 |  |
| ___________________________ |  |  |  |  |
| (1) Cash used in investing activities for the nine months ended September 30, 2017 was adjusted as a result of our adoption of ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash, in the first quarter of 2018. See Note 1 of Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for more information. |

[0001596532-18-000233:mdna:67]
[same as prior period, unchanged from 0001596532-18-000174:mdna:64]

[0001596532-18-000233:mdna:68]
During the nine months ended September 30, 2018, cash provided by operating activities was $207.3 million, primarily from net income of $157.8 million, non-cash adjustments to net income of $42.6 million, and a net increase of $6.9 million in cash from changes in our operating assets and liabilities. The increase in cash from changes in operating assets and liabilities was primarily due to cash inflows of $98.3 million from a decrease in inventories driven by improved inventory management and timing of receipts, $30.5 million from an increase in accounts payable due to timing of inventory receipts and payments, $13.2 million from an increase in deferred revenue primarily from growth in customer PCS contracts, $10.3 million from an increase in income taxes payable, and $10.0 million from increases in other liabilities primarily driven by increased customer prepayments under concealable contracts. These cash inflows were  partially offset by cash outflows of $68.2 million from an increase in accounts receivable due to increased billing and timing of customer shipments, $50.5 million from an increase in prepaid expenses and other current assets primarily due to higher prepaid income taxes in connection with an income tax benefit associated with the Cisco legal settlement charges referenced above, and $35.9 million from a decline in accrued liabilities due primarily to a decline in supplier liabilities and the completion of product development projects.

[0001596532-18-000233:mdna:69]
During the nine months ended September 30, 2017, cash provided by operating activities was $448.0 million, resulting from net income of $319.4 million, non-cash adjustments to net income of $48.7 million, and a net increase in cash from changes in our operating assets and liabilities of $79.9 million. Our operating cash benefited from increased deferred revenue of $192.2 million resulting from growth in product and service deferred revenue related to contract acceptance terms and ongoing growth in PCS contracts. We also experienced strong cash collections on accounts receivable during the period generating $40.5 million in cash. These increases were partially offset by growth in inventory of $96.7 million, supporting overall growth in the business and the expansion of our manufacturing and supply chain activities, with a decline in accounts payable of $46.1 million related to timing of vendor payments related to inventory purchases. Prepaid expenses and other assets increased by $22.5 million primarily due to higher deferred cost of inventory associated with the increased product revenue deferrals referenced above, partially offset by a reduction in inventory deposits.

[0001596532-18-000233:mdna:70]
[same as prior period, unchanged from 0001596532-18-000174:mdna:67]

[0001596532-18-000233:mdna:71]
During the nine months ended September 30, 2018, cash used in investing activities was $583.5 million, consisting of purchases of available-for-sale securities of $827.2 million, offset by proceeds of $367.0 million from maturities of marketable securities, $95.6 million for business acquisitions, and purchases of property and equipment of $17.6 million.

[0001596532-18-000233:mdna:72]
During the nine months ended September 30, 2017, cash used in investing activities was $199.1 million, consisting of purchases of available-for-sale securities of $325.4 million, offset by proceeds of $135.5 million and purchases of property, equipment and other assets of $12.2 million.

[0001596532-18-000233:mdna:73]
[same as prior period, unchanged from 0001596532-18-000174:mdna:70]

[0001596532-18-000233:mdna:74]
During the nine months ended September 30, 2018, cash provided by financing activities was $41.3 million, consisting primarily of proceeds from the issuance of common stock under employee equity incentive plans of $49.6 million, offset by minimum tax withheld for employees of $6.9 million and payments for lease financing obligations of $1.4 million.

[0001596532-18-000233:mdna:75]
During the nine months ended September 30, 2017, cash provided by financing activities was $38.2 million, consisting primarily of proceeds from the issuance of common stock under employee equity incentive plans of $41.9 million, offset by minimum tax withheld for employees of $2.5 million and payments for lease financing obligations of $1.2 million.

[0001596532-18-000233:mdna:76]
[same as prior period, unchanged from 0001596532-18-000174:mdna:73]

[0001596532-18-000233:mdna:77]
As of September 30, 2018, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-18-000233:mdna:78]
[same as prior period, unchanged from 0001596532-18-000174:mdna:75]

[0001596532-18-000233:mdna:79]
Our contractual obligations represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalent and marketable securities. As of September 30, 2018, our principal commitments consist primarily of obligations under operating and financing leases for offices and data centers and purchase commitments with our contract manufacturers and suppliers. There have been no significant changes to these obligations during the nine months ended September 30, 2018, compared to the contractual obligations disclosed in our “Management's Discussion and Analysis of Financial Condition and Results of Operations” included in our Annual Report on Form 10-K, filed with the SEC on February 20, 2018, other than the new operating leases entered into in 2018 and the purchase commitments described in Note 6 of Notes to Condensed Consolidated Financial Statements of this Quarterly Report on Form 10-Q.

[0001596532-18-000233:mdna:80]
[same as prior period, unchanged from 0001596532-18-000174:mdna:77]

[0001596532-18-000233:mdna:81]
[same as prior period, unchanged from 0001596532-18-000174:mdna:78]

[0001596532-18-000233:mdna:82]
Effective January 1, 2018, we adopted the new revenue recognition guidance under ASC 606 as discussed in the section titled Recently Adopted Accounting Pronouncements in  Note 1 of the Notes to Condensed Consolidated Financial Statements of this Quarterly Report on Form 10-Q. As a result, we updated our critical accounting policy on revenue recognition as follows. There have been no changes to our other critical accounting policies and estimates discussed in the section titled Management's Discussion and Analysis of Financial Condition and Results of Operations under PART II, Item 7, of our Annual Report on Form 10-K filed with the SEC on February 20, 2018. We believe our critical accounting policies and estimates reflect our significant judgments and estimates used in the preparation of the condensed consolidated financial statements in this Quarterly Report on Form 10-Q.

[0001596532-18-000233:mdna:83]
[same as prior period, unchanged from 0001596532-18-000174:mdna:80]

[0001596532-18-000233:mdna:84]
The following revenue recognition policy was effective January 1, 2018 following our adoption of the new revenue recognition guidance under ASC 606 using the modified retrospective method as discussed in the section titled Recently Adopted Accounting Pronouncements of Note 1 of Notes to Condensed Consolidated Financial Statements of this Quarterly Report on Form 10-Q.  Prior to 2018, our revenue recognition policy was under ASC 605, Revenue Recognition, and is described in Note 1 of Notes to Consolidated Financial Statements under PART II, Item 8, of our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

[0001596532-18-000233:mdna:85]
[same as prior period, unchanged from 0001596532-18-000174:mdna:82]

[0001596532-18-000233:mdna:86]
[same as prior period, unchanged from 0001596532-18-000174:mdna:83]

[0001596532-18-000233:mdna:87]
[same as prior period, unchanged from 0001596532-18-000174:mdna:84]

[0001596532-18-000233:mdna:88]
[same as prior period, unchanged from 0001596532-18-000174:mdna:85]

[0001596532-18-000233:mdna:89]
[same as prior period, unchanged from 0001596532-18-000174:mdna:86]

[0001596532-18-000233:mdna:90]
[same as prior period, unchanged from 0001596532-18-000174:mdna:87]

[0001596532-18-000233:mdna:91]
[same as prior period, unchanged from 0001596532-18-000174:mdna:88]

[0001596532-18-000233:mdna:92]
[same as prior period, unchanged from 0001596532-18-000174:mdna:89]

[0001596532-18-000233:mdna:93]
[same as prior period, unchanged from 0001596532-18-000174:mdna:90]

[0001596532-18-000233:mdna:94]
[same as prior period, unchanged from 0001596532-18-000174:mdna:91]

[0001596532-18-000233:mdna:95]
[same as prior period, unchanged from 0001596532-18-000174:mdna:92]

[0001596532-18-000233:mdna:96]
[same as prior period, unchanged from 0001596532-18-000174:mdna:93]

[0001596532-18-000233:mdna:97]
[same as prior period, unchanged from 0001596532-18-000174:mdna:94]

[0001596532-18-000233:mdna:98]
[same as prior period, unchanged from 0001596532-18-000174:mdna:95]

[0001596532-18-000233:mdna:99]
[same as prior period, unchanged from 0001596532-18-000174:mdna:96]

[0001596532-18-000233:mdna:100]
[same as prior period, unchanged from 0001596532-18-000174:mdna:97]

[0001596532-18-000233:mdna:101]
[same as prior period, unchanged from 0001596532-18-000174:mdna:98]

[0001596532-18-000233:mdna:102]
Refer to the sections titled “Recently Adopted Accounting Pronouncements” and “Recent Accounting Pronouncements Not Yet Effective” in Note 1 of Notes to Condensed Consolidated Financial Statements of this Quarterly Report on Form 10-Q.
