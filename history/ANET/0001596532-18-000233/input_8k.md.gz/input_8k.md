# ANET 8-K — 0001596532-18-000230 filed 2018-11-01

## item codes, every 8-K on or before 2018-11-05

- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2018-11-05

- none on or before 2018-11-05

## item 2.02 — earnings release, exhibit 99.1

[0001596532-18-000230:8k_2_02:1]
EX-99.1
2
ex991q318-earningsrelease.htm
EXHIBIT 99.1

[0001596532-18-000230:8k_2_02:2]
Exhibit

[0001596532-18-000230:8k_2_02:3]
Exhibit 99.1

[0001596532-18-000230:8k_2_02:4]
Arista Networks, Inc. Reports Third Quarter 2018 Financial Results

[0001596532-18-000230:8k_2_02:5]
Delivers Record Earnings while Exceeding Cumulative Shipments of 20 Million Cloud Networking Ports

[0001596532-18-000230:8k_2_02:6]
SANTA CLARA, Calif.-- November 1, 2018 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven, cognitive cloud networking for large-scale datacenter and campus environments, today announced financial results for its third quarter ended September 30, 2018.

[0001596532-18-000230:8k_2_02:7]
Third Quarter Financial Highlights

[0001596532-18-000230:8k_2_02:8]
| • | Revenue of $563.3 million, an increase of 8.4% compared to the second quarter of 2018, and an increase of 28.7% from the third quarter of 2017. |

[0001596532-18-000230:8k_2_02:9]
| • | GAAP gross margin of 64.2%, compared to GAAP gross margin of 64.2% in the second quarter of 2018 and 64.1% in the third quarter of 2017. |

[0001596532-18-000230:8k_2_02:10]
| • | Non-GAAP gross margin of 64.6%, compared to non-GAAP gross margin of 64.5% in the second quarter of 2018 and 64.4% in the third quarter of 2017. |

[0001596532-18-000230:8k_2_02:11]
| • | GAAP net income of $168.5 million, or $2.08 per diluted share, compared to GAAP net income of $133.7 million, or $1.68 per diluted share, in the third quarter of 2017. |

[0001596532-18-000230:8k_2_02:12]
| • | Non-GAAP net income of $171.3 million, or $2.11 per diluted share, compared to non-GAAP net income of $128.2 million, or $1.62 per diluted share, in the third quarter of 2017. |

[0001596532-18-000230:8k_2_02:13]
"As Arista completes its first decade of customer shipments, I am proud of the many milestones we have achieved. These include our entry into the prestigious S&P 500, cumulative shipments of more than 20 million cloud networking ports and another quarter of record earnings in Q3 2018.”  stated Jayshree Ullal, Arista President and CEO.

[0001596532-18-000230:8k_2_02:14]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, “The business continued to execute well across key financial metrics in the quarter, with continued healthy revenue growth and earnings expansion”.

[0001596532-18-000230:8k_2_02:15]
Company Highlights

[0001596532-18-000230:8k_2_02:16]
| • | Arista completes its first two acquisitions, Mojo Networks for Cloud Networking Expansion, and MetaMako, a leader in low-latency FPGA-enabled network solutions. |

[0001596532-18-000230:8k_2_02:17]
| • | Arista introduces 400 Gigabit Platforms, addressing growing bandwidth demands of cloud networks. |

[0001596532-18-000230:8k_2_02:18]
| • | Arista Extends Hybrid Cloud Networking Solution for Microsoft Azure Stack. |

[0001596532-18-000230:8k_2_02:19]
| • | Arista ranked #8 on the Fortune 100 Fastest Growing Companies 2018. |

[0001596532-18-000230:8k_2_02:20]
| • | Arista completes its first decade of customer shipments. |

[0001596532-18-000230:8k_2_02:21]
Financial Outlook

[0001596532-18-000230:8k_2_02:22]
For the fourth quarter of 2018, we expect:

[0001596532-18-000230:8k_2_02:23]
| • | Revenue between $582 and $594 million |

[0001596532-18-000230:8k_2_02:24]
| • | Non-GAAP gross margin between 63% to 65%, and |

[0001596532-18-000230:8k_2_02:25]
| • | Non-GAAP operating margin of approximately 35% |

[0001596532-18-000230:8k_2_02:26]
Guidance for non-GAAP financial measures excludes estimated legal expenses of approximately $1 million associated with the OptumSoft litigation, stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below).

[0001596532-18-000230:8k_2_02:27]
Prepared Materials and Conference Call Information

[0001596532-18-000230:8k_2_02:28]
Arista executives will discuss third quarter 2018 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (833) 287-7905 in the United States or (647) 689-4469 from outside the US. The Conference ID is 5078518.

[0001596532-18-000230:8k_2_02:29]
The financial results conference call will also be available via live webcast on our investor relations website at http://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s Investor Relations website.

[0001596532-18-000230:8k_2_02:30]
Forward-Looking Statements

[0001596532-18-000230:8k_2_02:31]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the fourth quarter of fiscal 2018, and statements regarding the benefits from the introduction of new products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: Arista Networks’ limited operating history; Arista Networks’ rapid growth; Arista Networks’ customer concentration;  the evolution and growth of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; changes in our customer’s demand for our products and services; requests for more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; customer order patterns or customer mix; the timing of orders and manufacturing and customer lead times; increased competition in our products and service markets; dependence on the introduction and market acceptance of new product offerings and standards; the benefits and impact of acquisitions; rapid technological and market change; Arista Networks’ dispute with OptumSoft; and general market, political, economic and business conditions. Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s most recent Quarterly Report on Form 10-Q filed with the SEC on August 8, 2018, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at http://investors.arista.com/ and on the SEC’s website at http://www.sec.gov/.  All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-18-000230:8k_2_02:32]
Non-GAAP Financial Measures

[0001596532-18-000230:8k_2_02:33]
The company reports certain non-GAAP financial measures that exclude stock-based compensation expense, legal fees and bond costs and recoveries associated with the OptumSoft and Cisco litigation, acquisition-related costs, including external professional fees and severance costs, amortization of acquisition-related intangible assets, other non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, other discrete indirect effects of such awards, and acquisition-related tax expense.  The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-18-000230:8k_2_02:34]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP net income, net income per diluted share, gross margin, or operating margin. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. A description of these non-GAAP financial measures and a reconciliation of the company’s

[0001596532-18-000230:8k_2_02:35]
non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-18-000230:8k_2_02:36]
The Company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, expenses associated with the OptumSoft litigation, amortization of acquisition-related intangible assets, and other non-recurring items. The Company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. Stock-based compensation expense is impacted by the Company’s future hiring and retention needs and the future fair market value of the Company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the Company’s GAAP gross margin and GAAP operating margin. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measure is not available without unreasonable effort.

[0001596532-18-000230:8k_2_02:37]
About Arista Networks

[0001596532-18-000230:8k_2_02:38]
Arista Networks pioneered software-driven, cognitive cloud networking for large-scale datacenter and campus environments. Arista's award-winning platforms redefine and deliver availability, agility, automation, analytics and security.  Arista has shipped more than twenty million cloud networking ports worldwide with CloudVision and EOS, an advanced network operating system. Committed to open standards across private, public and hybrid cloud solutions, Arista products are supported worldwide directly and through partners.

[0001596532-18-000230:8k_2_02:39]
ARISTA, EOS, CloudVision, and Cognitive WiFi are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners. Additional information and resources can be found at www.arista.com.

[0001596532-18-000230:8k_2_02:40]
| Investor Contacts: |
| Charles YagerProduct and Investor Advocacy(408) 547-5892cyager@arista.com |  | Chuck ElliottBusiness and Investor Development(408) 547-5549chuck@arista.com |

[0001596532-18-000230:8k_2_02:41]
3

[0001596532-18-000230:8k_2_02:42]
ARISTA NETWORKS, INC.

[0001596532-18-000230:8k_2_02:43]
Condensed Consolidated Statements of Operations

[0001596532-18-000230:8k_2_02:44]
(Unaudited in thousands, except per share amounts)

[0001596532-18-000230:8k_2_02:45]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 485,481 |  |  | $ | 380,344 |  |  | $ | 1,337,865 |  |  | $ | 1,025,615 |  |
| Service |  | 77,828 |  |  | 57,289 |  |  | 217,778 |  |  | 152,704 |  |
| Total revenue |  | 563,309 |  |  | 437,633 |  |  | 1,555,643 |  |  | 1,178,319 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 187,764 |  |  | 145,874 |  |  | 516,077 |  |  | 390,116 |  |
| Service |  | 13,962 |  |  | 11,142 |  |  | 41,181 |  |  | 33,599 |  |
| Total cost of revenue |  | 201,726 |  |  | 157,016 |  |  | 557,258 |  |  | 423,715 |  |
| Total gross profit |  | 361,583 |  |  | 280,617 |  |  | 998,385 |  |  | 754,604 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 117,589 |  |  | 79,610 |  |  | 324,029 |  |  | 242,414 |  |
| Sales and marketing |  | 47,903 |  |  | 40,640 |  |  | 136,231 |  |  | 116,297 |  |
| General and administrative |  | 15,321 |  |  | 19,535 |  |  | 53,420 |  |  | 65,009 |  |
| Legal settlement |  | — |  |  | — |  |  | 405,000 |  |  | — |  |
| Total operating expenses |  | 180,813 |  |  | 139,785 |  |  | 918,680 |  |  | 423,720 |  |
| Income from operations |  | 180,770 |  |  | 140,832 |  |  | 79,705 |  |  | 330,884 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |
| Interest expense |  | (673 | ) |  | (701 | ) |  | (2,040 | ) |  | (2,039 | ) |
| Other income (expense), net |  | 9,292 |  |  | 2,136 |  |  | 12,646 |  |  | 4,280 |  |
| Total other income (expense), net |  | 8,619 |  |  | 1,435 |  |  | 10,606 |  |  | 2,241 |  |
| Income before income taxes |  | 189,389 |  |  | 142,267 |  |  | 90,311 |  |  | 333,125 |  |
| Provision for (benefit from) income taxes |  | 20,865 |  |  | 8,545 |  |  | (67,482 | ) |  | 13,757 |  |
| Net income |  | $ | 168,524 |  |  | $ | 133,722 |  |  | $ | 157,793 |  |  | $ | 319,368 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 168,439 |  |  | $ | 133,540 |  |  | $ | 157,706 |  |  | $ | 318,643 |  |
| Diluted |  | $ | 168,445 |  |  | $ | 133,555 |  |  | $ | 157,713 |  |  | $ | 318,704 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.25 |  |  | $ | 1.84 |  |  | $ | 2.12 |  |  | $ | 4.43 |  |
| Diluted |  | $ | 2.08 |  |  | $ | 1.68 |  |  | $ | 1.95 |  |  | $ | 4.06 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | 75,011 |  |  | 72,588 |  |  | 74,506 |  |  | 71,903 |  |
| Diluted |  | 81,018 |  |  | 79,322 |  |  | 80,844 |  |  | 78,528 |  |

[0001596532-18-000230:8k_2_02:46]
ARISTA NETWORKS, INC.

[0001596532-18-000230:8k_2_02:47]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-18-000230:8k_2_02:48]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-18-000230:8k_2_02:49]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| GAAP gross profit |  | $ | 361,583 |  |  | $ | 280,617 |  |  | $ | 998,385 |  |  | $ | 754,604 |  |
| GAAP gross margin |  | 64.2 | % |  | 64.1 | % |  | 64.2 | % |  | 64.0 | % |
| Stock-based compensation expense |  | 1,268 |  |  | 1,113 |  |  | 3,706 |  |  | 3,224 |  |
| Intangible asset amortization |  | 1,198 |  |  | — |  |  | 1,198 |  |  | — |  |
| Non-GAAP gross profit |  | $ | 364,049 |  |  | $ | 281,730 |  |  | $ | 1,003,289 |  |  | $ | 757,828 |  |
| Non-GAAP gross margin |  | 64.6 | % |  | 64.4 | % |  | 64.5 | % |  | 64.3 | % |
| GAAP income from operations |  | $ | 180,770 |  |  | $ | 140,832 |  |  | $ | 79,705 |  |  | $ | 330,884 |  |
| Stock-based compensation expense |  | 23,254 |  |  | 20,152 |  |  | 66,583 |  |  | 54,991 |  |
| Litigation expense (benefit) (1) |  | (100 | ) |  | 7,857 |  |  | 10,554 |  |  | 31,280 |  |
| Legal settlement (2) |  | — |  |  | — |  |  | 405,000 |  |  | — |  |
| Intangible asset amortization |  | 1,610 |  |  | — |  |  | 1,610 |  |  | — |  |
| Acquisition-related costs |  | 3,432 |  |  | — |  |  | 3,432 |  |  | — |  |
| Non-GAAP income from operations |  | $ | 208,966 |  |  | $ | 168,841 |  |  | $ | 566,884 |  |  | $ | 417,155 |  |
| Non-GAAP operating margin |  | 37.1 | % |  | 38.6 | % |  | 36.4 | % |  | 35.4 | % |
| GAAP net income |  | $ | 168,524 |  |  | $ | 133,722 |  |  | $ | 157,793 |  |  | $ | 319,368 |  |
| Stock-based compensation expense |  | 23,254 |  |  | 20,152 |  |  | 66,583 |  |  | 54,991 |  |
| Litigation expense (benefit) (1) |  | (100 | ) |  | 7,857 |  |  | 10,554 |  |  | 31,280 |  |
| Legal settlement (2) |  | — |  |  | — |  |  | 405,000 |  |  | — |  |
| Intangible asset amortization |  | 1,610 |  |  | — |  |  | 1,610 |  |  | — |  |
| Acquisition-related costs |  | 3,432 |  |  | — |  |  | 3,432 |  |  | — |  |
| Unrealized loss on investments in privately-held companies, net |  | — |  |  | — |  |  | 9,100 |  |  | — |  |
| Acquisition-related tax expense |  | 5,853 |  |  | — |  |  | 5,853 |  |  | — |  |
| Tax benefit on stock-based awards |  | (26,130 | ) |  | (24,562 | ) |  | (84,448 | ) |  | (73,255 | ) |
| Income tax effect on non-GAAP exclusions |  | (5,149 | ) |  | (8,947 | ) |  | (114,340 | ) |  | (26,885 | ) |
| Non-GAAP net income |  | $ | 171,294 |  |  | $ | 128,222 |  |  | $ | 461,137 |  |  | $ | 305,499 |  |
| GAAP diluted net income per share attributable to common stockholders |  | $ | 2.08 |  |  | $ | 1.68 |  |  | $ | 1.95 |  |  | $ | 4.06 |  |
| Non-GAAP adjustments to net income |  | 0.03 |  |  | (0.06 | ) |  | 3.75 |  |  | (0.17 | ) |
| Non-GAAP diluted net income per share |  | $ | 2.11 |  |  | $ | 1.62 |  |  | $ | 5.70 |  |  | $ | 3.89 |  |
| Weighted-average shares used in computing diluted net income per share attributable to common stockholders |  | 81,018 |  |  | 79,322 |  |  | 80,844 |  |  | 78,528 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,268 |  |  | $ | 1,113 |  |  | $ | 3,706 |  |  | $ | 3,224 |  |
| Research and development |  | 12,010 |  |  | 11,048 |  |  | 34,700 |  |  | 30,977 |  |
| Sales and marketing |  | 6,537 |  |  | 5,115 |  |  | 18,771 |  |  | 12,651 |  |
| General and administrative |  | 3,439 |  |  | 2,876 |  |  | 9,406 |  |  | 8,139 |  |
| Total |  | $ | 23,254 |  |  | $ | 20,152 |  |  | $ | 66,583 |  |  | $ | 54,991 |  |

[0001596532-18-000230:8k_2_02:50]
| (1) | Includes legal fees and bond costs and recoveries associated with the Optumsoft and Cisco litigation. |

[0001596532-18-000230:8k_2_02:51]
| (2) | Represents one-time charges associated with the settlement of our lawsuit with Cisco on August 6, 2018. |

[0001596532-18-000230:8k_2_02:52]
5

[0001596532-18-000230:8k_2_02:53]
ARISTA NETWORKS, INC.

[0001596532-18-000230:8k_2_02:54]
Condensed Consolidated Balance Sheets

[0001596532-18-000230:8k_2_02:55]
(Unaudited, in thousands)

[0001596532-18-000230:8k_2_02:56]
|  |  | September 30, 2018 |  | December 31, 2017 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 524,687 |  |  | $ | 859,192 |  |
| Marketable securities |  | 1,137,112 |  |  | 676,363 |  |
| Accounts receivable |  | 322,053 |  |  | 247,346 |  |
| Inventories |  | 216,313 |  |  | 306,198 |  |
| Prepaid expenses and other current assets |  | 235,881 |  |  | 177,330 |  |
| Total current assets |  | 2,436,046 |  |  | 2,266,429 |  |
| Property and equipment, net |  | 75,397 |  |  | 74,279 |  |
| Acquisition-related intangible assets, net |  | 62,110 |  |  | — |  |
| Goodwill |  | 55,168 |  |  | — |  |
| Investments |  | 35,036 |  |  | 36,136 |  |
| Deferred tax assets |  | 114,282 |  |  | 65,125 |  |
| Other assets |  | 20,199 |  |  | 18,891 |  |
| TOTAL ASSETS |  | $ | 2,798,238 |  |  | $ | 2,460,860 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 85,097 |  |  | $ | 52,200 |  |
| Accrued liabilities |  | 103,108 |  |  | 133,827 |  |
| Deferred revenue |  | 318,850 |  |  | 327,706 |  |
| Other current liabilities |  | 32,727 |  |  | 16,172 |  |
| Total current liabilities |  | 539,782 |  |  | 529,905 |  |
| Income taxes payable |  | 42,470 |  |  | 34,067 |  |
| Lease financing obligations, non-current |  | 36,040 |  |  | 37,673 |  |
| Deferred revenue, non-current |  | 211,005 |  |  | 187,556 |  |
| Other long-term liabilities |  | 23,065 |  |  | 9,745 |  |
| TOTAL LIABILITIES |  | 852,362 |  |  | 798,946 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 8 |  |  | 7 |  |
| Additional paid-in capital |  | 929,829 |  |  | 804,731 |  |
| Retained earnings (1) |  | 1,020,481 |  |  | 859,114 |  |
| Accumulated other comprehensive loss |  | (4,442 | ) |  | (1,938 | ) |
| TOTAL STOCKHOLDERS’ EQUITY |  | 1,945,876 |  |  | 1,661,914 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 2,798,238 |  |  | $ | 2,460,860 |  |
| ____________________________ |  |  |  |  |
| (1) The adoption of ASU 2014-09, Revenue from Contracts with Customers (Topic 606), and ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, in the first quarter of 2018 resulted in an adjustment to increase the retained earnings balance by $3.6 million as of January 1, 2018. |

[0001596532-18-000230:8k_2_02:57]
ARISTA NETWORKS, INC.

[0001596532-18-000230:8k_2_02:58]
Condensed Consolidated Statements of Cash Flows

[0001596532-18-000230:8k_2_02:59]
(Unaudited, in thousands)

[0001596532-18-000230:8k_2_02:60]
|  |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 As Adjusted (1) |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 157,793 |  |  | $ | 319,368 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 18,440 |  |  | 15,355 |  |
| Stock-based compensation |  | 66,583 |  |  | 54,991 |  |
| Deferred income taxes |  | (49,615 | ) |  | (22,743 | ) |
| Unrealized loss on investments in privately-held companies, net |  | 9,100 |  |  | — |  |
| Amortization (accretion) of investment premiums (discounts) |  | (1,863 | ) |  | 1,106 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (68,192 | ) |  | 40,508 |  |
| Inventories |  | 98,284 |  |  | (96,667 | ) |
| Prepaid expenses and other current assets |  | (50,507 | ) |  | (20,973 | ) |
| Other assets |  | (767 | ) |  | (1,560 | ) |
| Accounts payable |  | 30,515 |  |  | (46,075 | ) |
| Accrued liabilities |  | (35,917 | ) |  | 4,175 |  |
| Deferred revenue |  | 13,161 |  |  | 192,210 |  |
| Income taxes payable |  | 10,311 |  |  | 7,421 |  |
| Other liabilities |  | 9,974 |  |  | 847 |  |
| Net cash provided by operating activities |  | 207,300 |  |  | 447,963 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 366,999 |  |  | 135,483 |  |
| Purchases of marketable securities |  | (827,198 | ) |  | (325,414 | ) |
| Business acquisitions, net of cash acquired |  | (95,640 | ) |  | — |  |
| Purchases of property and equipment |  | (17,613 | ) |  | (12,159 | ) |
| Investments in privately-held companies |  | (8,000 | ) |  | — |  |
| Proceeds from repayment of notes receivable |  | — |  |  | 3,000 |  |
| Other investing activities |  | (2,000 | ) |  | — |  |
| Net cash used in investing activities (1) |  | (583,452 | ) |  | (199,090 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Principal payments of lease financing obligations |  | (1,392 | ) |  | (1,170 | ) |
| Proceeds from issuance of common stock under equity plans |  | 49,642 |  |  | 41,870 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (6,914 | ) |  | (2,457 | ) |
| Net cash provided by financing activities |  | 41,336 |  |  | 38,243 |  |
| Effect of exchange rate changes |  | (984 | ) |  | 697 |  |
| NET INCREASE/(DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | (335,800 | ) |  | 287,813 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period (1) |  | 864,697 |  |  | 572,168 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period (1) |  | $ | 528,897 |  |  | $ | 859,981 |  |
| ____________________________________ |  |  |  |  |
| (1) The adoption of ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash ("ASU 2016-18"), in the first quarter of 2018 requires the Company to include restricted cash together with cash and cash equivalents when reconciling the beginning-of-period and end-of-period amounts presented on the statements of cash flows. As a result, for the nine months ended September 30, 2017, the beginning-of-period and end-of-period amounts increased by $4.2 million and $5.5 million, respectively, and net cash used in investing activities decreased by $1.3 million. |

[0001596532-18-000230:8k_2_02:61]
7
