# ANET notes — 0001596532-18-000233


## anet:InvestmentsPrivatelyHeldCompaniesPolicyTextBlock

[0001596532-18-000233:notes:1]
Our equity investments in privately-held companies without readily determinable fair values are measured using the measurement alternative, defined by Accounting Standards Codification (“ASC”) 321-Investments-Equity Securities as cost, less impairments, and adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded as “Other income (expense), net” in our condensed consolidated statements of operations. Prior to 2018, such investments were accounted for under the cost method and were recorded at historical cost at the time of investment, with adjustments to the balance only in the event of an impairment.

[0001596532-18-000233:notes:2]
Our equity investments in privately-held companies are included in “Investments” in our condensed consolidated balance sheets.


## anet:ScheduleofSharebasedCompensationSharesAvailableForGrantActivityTableTextBlock

[0001596532-18-000233:notes:3]
The following table presents the stock activity and the total number of shares available for grant under the 2014 Plan as of September 30, 2018 (in thousands):

[0001596532-18-000233:notes:4]
|  |  | Number of Shares |
| Balance—December 31, 2017 |  | 13,512 |  |
| Authorized |  | 2,211 |  |
| Options granted |  | (82 | ) |
| RSUs granted |  | (231 | ) |
| Options canceled |  | 41 |  |
| RSUs forfeited |  | 56 |  |
| Shares traded for taxes |  | 27 |  |
| Balance—September 30, 2018 |  | 15,534 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001596532-18-000233:notes:5]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2018, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2017 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant intercompany accounts and transactions have been eliminated.

[0001596532-18-000233:notes:6]
[same as prior period, unchanged from 0001596532-18-000174:notes:6]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-18-000233:notes:7]
2.    Business Combinations

[0001596532-18-000233:notes:8]
In the three months ended September 30, 2018, we acquired Mojo Networks, Inc. (“Mojo”) and Metamako Holding PTY LTD. (“Metamako”) in order to extend our cognitive cloud networking architecture and to improve our next generation platforms for low-latency applications.

[0001596532-18-000233:notes:9]
The total consideration transferred for these acquisitions was approximately $116.5 million, which consisted of $100.9 million in cash and $15.6 million for the fair value of 58,072 shares of our common stock issued. The following table summarizes our preliminary purchase price allocation of the two acquisitions, in aggregate, based on the estimated fair value of the assets acquired and liabilities assumed at their respective acquisition dates (in thousands):

[0001596532-18-000233:notes:10]
|  |  | Purchase Price Allocation |
| Cash and cash equivalents |  | $ | 4,953 |  |
| Other tangible assets |  | 22,445 |  |
| Liabilities |  | (29,780 | ) |
| Intangible assets |  | 63,720 |  |
| Goodwill |  | 55,168 |  |
| Net assets acquired |  | $ | 116,506 |  |

[0001596532-18-000233:notes:11]
The acquired intangible assets are amortized on a straight-line basis over their estimated useful lives as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. The following table shows the valuation of the intangible assets acquired (in thousands) along with their estimated useful lives.

[0001596532-18-000233:notes:12]
|  |  | Acquisition Date Fair Value |  | Estimated Useful Life(year) |
| Developed technology |  | $ | 52,510 |  |  | 5 years |
| Customer relationships |  | 7,080 |  |  | 7 years |
| Trade name |  | 2,470 |  |  | 3 years |
| Others |  | 1,660 |  |  | 1 year |
| Total intangible assets acquired |  | $ | 63,720 |  |  |  |

[0001596532-18-000233:notes:13]
The goodwill of $55.2 million is primarily attributable to the expected synergies created by incorporating the solutions of the acquired businesses into our technology platform, and the value of the assembled workforce. We operate under a single reportable segment. The goodwill is not deductible for income taxes purposes.

[0001596532-18-000233:notes:14]
For the three and nine months ended September 30, 2018, revenue and earnings from the acquired businesses included in our condensed consolidated statements of operations were immaterial. Pro forma results of operations for these acquisitions have not been presented because they are not material to the consolidated results of operations, either individually or in aggregate.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-18-000233:notes:15]
6.    Commitments and Contingencies

[0001596532-18-000233:notes:16]
Operating Leases

[0001596532-18-000233:notes:17]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2025. There have been no material changes in our future minimum payment obligations under our operating leases that existed as of December 31, 2017, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2017, except as follows. During the nine months ended September 30, 2018, we entered into new leases primarily related to additional data center capacity and co-location services. As of September 30, 2018, the total minimum future payment commitment under these new leases was approximately $47.7 million, of which $1.2 million is due in 2018, with the remainder due in 2021 through 2028.

[0001596532-18-000233:notes:18]
We recognize rent expense under these arrangements on a straight-line basis over the term of the leases. For the three months ended September 30, 2018 and 2017, rent expense for all operating leases amounted to $2.8 million and $2.5 million, respectively, and to $7.9 million and $7.5 million for the nine months ended September 30, 2018 and 2017, respectively.

[0001596532-18-000233:notes:19]
Financing Obligation—Build-to-Suit Lease

[0001596532-18-000233:notes:20]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013. The lease is accounted for as a financing obligation and the lease payments are attributed to (1) a reduction of the principal financing obligation; (2) imputed interest expense; and (3) land lease expense, representing an imputed cost to lease the underlying land of the building. There have been no material changes in our future minimum payment obligations under this financing lease, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2017. Land lease expense related to our lease financing obligation is classified as rent expense in our unaudited condensed consolidated statements of operations, and amounted to $0.3 million for the three months ended September 30, 2018 and 2017, and $1.0 million for the nine months ended September 30, 2018 and 2017, respectively.

[0001596532-18-000233:notes:21]
Purchase Commitments

[0001596532-18-000233:notes:22]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2018, we had non-cancellable purchase commitments of $423.1 million, of which $370.4 million was to our contract manufacturers and suppliers. We have not recorded a liability related to these purchase commitments. In addition, we have provided deposits to secure our obligations to purchase inventory. We had $22.0 million and $36.9 million in deposits as of September 30, 2018 and December 31, 2017, respectively. These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.

[0001596532-18-000233:notes:23]
Guarantees

[0001596532-18-000233:notes:24]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-18-000233:notes:25]
Legal Proceedings

[0001596532-18-000233:notes:26]
Cisco Systems, Inc. (“Cisco”) Matters

[0001596532-18-000233:notes:27]
On August 6, 2018, we entered into a settlement agreement with Cisco Systems, Inc. (“Cisco”) as described in Note 11 relating to several litigation matters which are summarized below.

[0001596532-18-000233:notes:28]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 4:14-cv-05343) (“’43 Case”)

[0001596532-18-000233:notes:29]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the ’875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”). Pursuant to the settlement with Cisco, as described in Note 11, the ’43 Case was dismissed on August 27, 2018.

[0001596532-18-000233:notes:30]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 5:14-cv-05344) (“’44 Case”)

[0001596532-18-000233:notes:31]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI” and U.S. Patent Nos. 7,047,526 and 7,953,886 (respectively, “the ’526 patent” and “the ’886 patent”). As relief for our alleged copyright infringement, Cisco sought monetary damages for alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees, and associated costs. The ’526 patent is subject to a non-appealable final judgment of non-infringement and the ’886 patent was dismissed with prejudice.

[0001596532-18-000233:notes:32]
On December 14, 2016, following a two-week trial, a jury found that we had proven our copyright defense of scenes a faire. Cisco filed a notice of appeal on June 6, 2017. Cisco did not appeal the jury’s noninfringement verdict on the ’526 patent but did appeal the jury’s finding that we established the defense of scenes a faire. On October 1, 2018, at the parties’ request and pursuant to the settlement agreement, the District Court vacated the jury verdict regarding our copyright defense and dismissed the case.

[0001596532-18-000233:notes:33]
Arista Networks, Inc. v. Cisco Systems, Inc. (Case No. 5:16-cv-00923) (“’23 Case”)

[0001596532-18-000233:notes:34]
On February 24, 2016, we filed a complaint against Cisco in the District Court for the Northern District of California alleging antitrust violations and unfair competition. On August 6, 2018, the Court vacated trial in light of the settlement with Cisco as describe in Note 11. Pursuant to the settlement with Cisco, the ’23 Case was dismissed.

[0001596532-18-000233:notes:35]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-944) (“944 Investigation”)

[0001596532-18-000233:notes:36]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated 19 U.S.C. § 1337 (“Section 337”). The USITC instituted Cisco’s complaint as Investigation No. 337-TA-944. Cisco initially alleged that certain of our switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.

[0001596532-18-000233:notes:37]
On February 2, 2016, the Administrative Law Judge (“ALJ”) issued his initial determination finding a violation of Section 337. The ALJ found that a violation had occurred in the importation into the United States, the sale for importation or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringed asserted claims 1, 2, 8-11, and 17-19 of the ’537 patent; asserted claims 6, 7, 20, and 21 of the ’592 patent; and asserted claims 5, 7, 45, and 46 of the ’145 patent. The ALJ did not find a violation of Section 337 with respect to any asserted claims of the ’597 and ’164 patents. Cisco dropped the ’296 patent before the hearing. On June 23, 2016, the USITC issued its Final Determination, which found a violation with respect to the ’537, ’592, and ’145 patents, and found no violation with respect to the ’597 and ’164 patents. The USITC also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software, and components thereof that infringe one or more of claims 1, 2, 8-11, and 17-19 of the ’537 patent; claims 6, 7, 20, and 21 of the ’592 patent; and claims 5, 7, 45, and 46 of the ’145 patent. On August 22, 2016, the Presidential review period for the 944 Investigation expired. The USITC orders will be in effect until the expiration of the ’537, ’592, and ’145 patents.

[0001596532-18-000233:notes:38]
Both we and Cisco filed petitions for review of the USITC’s Final Determination to the Federal Circuit. The appeal was fully briefed and oral argument was held on June 6, 2017. On September 27, 2017, the Federal Circuit affirmed the USITC’s Final Determination.

[0001596532-18-000233:notes:39]
In response to the USITC’s findings in the 944 Investigation, we made design changes to our products for sale in the United States to address the features that were found to infringe the ’537, ’592, and ’145 patents. Following the issuance of the final determination in the 944 Investigation, we submitted a Section 177 ruling request to CBP seeking approval to import these redesigned products into the United States.

[0001596532-18-000233:notes:40]
On August 26, 2016, Cisco filed an enforcement complaint under Section 337 with the USITC. Cisco alleged that we violated the cease and desist and limited exclusion orders issued in the 944 Investigation by engaging in the “marketing, distribution, offering for sale, selling, advertising, and/or aiding or abetting other entities in the sale and/or distribution of products that Cisco alleges continue to infringe claims 1-2, 8-11, and 17-19 of the ’537 patent,” despite the design changes we made to those products. On September 28, 2016, the USITC instituted the enforcement proceeding.

[0001596532-18-000233:notes:41]
On April 7, 2017, we received a 177 ruling from CBP finding that our redesigned products did not infringe the relevant claims of the ’537, ’592, and ʼ145 patents, and approving the importation of those redesigned products into the United States.

[0001596532-18-000233:notes:42]
On June 20, 2017, the ALJ issued his initial determination finding that we did not violate the June 23, 2016 cease and desist order. The initial determination also recommended a civil penalty of $307 million if the USITC decided to overturn the finding of no violation. On July 3, 2017, the parties filed petitions for review of certain findings in the initial determination.

[0001596532-18-000233:notes:43]
On August 4, 2017, the USITC issued an order remanding the investigation to the ALJ to make additional findings on certain issues and issue a remand initial determination. The USITC ordered the ALJ to set a schedule for completion of any necessary remand proceedings and a new target date for the enforcement action (the “944 Enforcement Action”). The ALJ held a hearing on February 1, 2018 and issued a remand initial determination on June 4, 2018, again finding that we did not violate the June 23, 2016 cease and desist order. Pursuant to the settlement with Cisco, the 944 Enforcement Investigation was terminated on September 17, 2018.  The parties have jointly requested suspension of the remedial orders in the 944 Investigation, and on October 23, 2018, the ITC instituted a modification proceeding to determine how to modify the orders consistent with the parties’ request.

[0001596532-18-000233:notes:44]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-945) (“945 Investigation”)

[0001596532-18-000233:notes:45]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated Section 337. The USITC instituted Cisco’s complaint as Investigation No. 337-TA-945. The remedial orders from the 945 Investigation are no longer in effect and will terminate when the USPTO issues a certificate cancelling the asserted claims of the ’668 patent based on the IPR proceeding described below.

[0001596532-18-000233:notes:46]
Inter Partes Reviews

[0001596532-18-000233:notes:47]
We have filed petitions for Inter Partes Review of the ’597, ’211, ’668, ’853, ’537, ’577, ’886, and ’526 patents. IPRs relating to the ’597 (IPR No. 2015-00978) and ’211 (IPR No. 2015-00975) patents were instituted in October 2015 and hearings on these IPRs were completed in July 2016. On September 28, 2016, the PTAB issued a final written decision finding claims 1, 14, 39-42, 71, 72, 84, and 85 of the ’597 patent unpatentable. The PTAB also found that claims 29, 63, 64, 73, and 86 of the ’597 patent had not been shown to be unpatentable. On October 5, 2016, the PTAB issued a final written decision finding claims 1 and 12 of the ’211 patent unpatentable. The PTAB also found that claims 2, 6-9, 13, and 17-20 of the ’211 patent had not been shown to be unpatentable. Both parties have appealed the final written decisions on the ’211 and ’537 patent IPRs.  The hearing for the ’211 IPR appeal was held in March 2018, and on March 28, 2018, the Federal Circuit remanded the matter back to the PTAB for further proceedings.

[0001596532-18-000233:notes:48]
IPRs relating to the ’668 (IPR No. 2016-00309), ’577 (IPR No. 2016-00303), ’853 (IPR No. 2016-0306), and ’537 (IPR No. 2016-0308) patents were instituted in June 2016 and hearings were held on March 7, 2017. On May 25, 2017, the PTAB issued final written decisions finding claims 1, 7-10, 12-16, 18-22, 25, and 28-31 of ’577 patent unpatentable, and that claim 2 of the ’577 patent, claim 63 of the ’853 patent, and claims 1, 10, 19, and 21 of the ’537 patent had not been shown to be unpatentable. On June 1, 2017, the PTAB issued a final written decision finding claims 1-10, 12-13, 15-28, 30-31, 33-36, 55-64, 66-67, and 69-72 of the ’668 patent unpatentable. We filed a Notice of Appeal concerning the ’577 patent on July 21, 2017, and Notices of Appeal concerning the ‘853 and ’537 patents on July 26, 2017. Cisco cross-appealed concerning the ’577 patent on July 26, 2017 and filed a Notice of Appeal concerning the ’668 patent on August 1, 2017. For the appeals of the IPRs on the ’668 and ’577 patents, the Federal Circuit granted our motion for an expedited briefing schedule, and the hearings were held on February 9, 2018. On February 14, 2018, the Federal Circuit affirmed the PTAB’s final written decision on the ’668 patent.

[0001596532-18-000233:notes:49]
OptumSoft, Inc. Matters

[0001596532-18-000233:notes:50]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies; and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-18-000233:notes:51]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft access to our software for evaluation by OptumSoft; (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches; (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers; (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us; and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors, who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dated July 28, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

[0001596532-18-000233:notes:52]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we asserted our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we asserted that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We asked the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also asserted that, even if we are found not to own certain components, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have meritorious defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-18-000233:notes:53]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II, including the application of the Court’s interpretation of the 2004 agreement to any other source code that OptumSoft claims to own and the trade secret misappropriation and confidentiality claims. The Phase II Trial is set for September 23, 2019 by the judge.

[0001596532-18-000233:notes:54]
We intend to vigorously defend against any claims brought against us by OptumSoft.  However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor.  For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft.  If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license.  An adverse litigation ruling could result in a significant damages award against us and injunctive relief. In addition, OptumSoft could assert additional or different claims against us, including claims that our license from OptumSoft is invalid.

[0001596532-18-000233:notes:55]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain. Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-18-000233:notes:56]
Other Matters

[0001596532-18-000233:notes:57]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-18-000233:notes:58]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2018, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-18-000233:notes:59]
[same as prior period, unchanged from 0001596532-18-000174:notes:55]

[0001596532-18-000233:notes:60]
|  |  | Three Months EndedSeptember 30, 2018 |  | Nine Months EndedSeptember 30, 2018 |
| Contract assets, beginning balance |  | $ | 6,959 |  |  | $ | — |  |
| Less: Beginning balance reclassified to accounts receivable upon invoice |  | (1,505 | ) |  | — |  |
| Add: Contract assets recognized |  | 3,963 |  |  | 9,417 |  |
| Contract assets, ending balance |  | $ | 9,417 |  |  | $ | 9,417 |  |

[0001596532-18-000233:notes:61]
[same as prior period, unchanged from 0001596532-18-000174:notes:57]

[0001596532-18-000233:notes:62]
|  |  | Three Months EndedSeptember 30, 2018 |  | Nine Months EndedSeptember 30, 2018 |
| Contract liabilities, beginning balance |  | $ | 21,842 |  |  | $ | 16,521 |  |
| Less: Revenue recognized from beginning balance |  | (2,157 | ) |  | (6,107 | ) |
| Less: Beginning balance reclassified to deferred revenue |  | (970 | ) |  | (521 | ) |
| Add: Contract liabilities recognized |  | 6,580 |  |  | 15,402 |  |
| Contract liabilities, ending balance |  | $ | 25,295 |  |  | $ | 25,295 |  |


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001596532-18-000233:notes:63]
[same as prior period, unchanged from 0001596532-18-000174:notes:59]

[0001596532-18-000233:notes:64]
|  |  | Three Months EndedSeptember 30, 2018 |  | Nine Months EndedSeptember 30, 2018 |  |
| Deferred revenue, beginning balance |  | $ | 448,644 |  |  | $ | 498,740 |  | (1) |
| Less: Revenue recognized from beginning balance |  | (97,995 | ) |  | (306,350 | ) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 179,206 |  |  | 337,465 |  |  |
| Deferred revenue, ending balance |  | $ | 529,855 |  |  | $ | 529,855 |  |  |
| _________________________________ |  |  |  |  |  |
| (1) The beginning balance of the nine months ended September 30, 2018 excluded the $16.5 million that was reclassified to other current liabilities and other long-term liabilities at January 1, 2018 as a result of our adoption of ASC 606. See Note 1 for details. |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-18-000233:notes:65]
7.    Equity Award Plan Activities

[0001596532-18-000233:notes:66]
[same as prior period, unchanged from 0001596532-18-000174:notes:62]

[0001596532-18-000233:notes:67]
Effective January 1, 2018, our board of directors authorized an increase of 2,211,176 shares to the shares available for issuance under the 2014 Equity Incentive Plan (the “2014 Plan”).  Pursuant to the 2014 Plan, the 2018 share increase is determined based on the lesser of 3% of total shares of common stock outstanding as of December 31, 2017, 12,500,000 shares, or such amount as determined by our board of directors. As of September 30, 2018, there remained approximately 22.9 million shares available for issuance under the 2014 Plan.

[0001596532-18-000233:notes:68]
[same as prior period, unchanged from 0001596532-18-000174:notes:64]

[0001596532-18-000233:notes:69]
Effective January 1, 2018, our board of directors authorized an increase of 737,058 shares to shares available for issuance under our 2014 Employee Stock Purchase Plan (the “ESPP”).  Pursuant to the ESPP, the 2018 share increase is determined based the lesser of 1% of the total shares of common stock outstanding on December 31, 2017, 2,500,000 shares, or such amount as determined by our board of directors. As of September 30, 2018, there remained 2,533,438 shares available for issuance under the ESPP.

[0001596532-18-000233:notes:70]
During the three and nine months ended September 30, 2018, we issued 81,769 shares and 190,659 shares at a weighted-average purchase price of $98.00 and $80.35 per share, respectively, under the ESPP.

[0001596532-18-000233:notes:71]
[same as prior period, unchanged from 0001596532-18-000174:notes:67]

[0001596532-18-000233:notes:72]
[same as prior period, unchanged from 0001596532-18-000174:notes:68]

[0001596532-18-000233:notes:73]
|  |  | Options Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding |
| Balance—December 31, 2017 |  | 7,024 |  |  | $ | 33.05 |  |  | 6.1 |  | $ | 1,422,637 |  |
| Options granted |  | 82 |  |  | 244.20 |  |  |  |  |  |
| Options exercised |  | (1,038 | ) |  | 33.07 |  |  |  |  |  |
| Options canceled |  | (41 | ) |  | 53.44 |  |  |  |  |  |
| Balance—September 30, 2018 |  | 6,027 |  |  | $ | 35.78 |  |  | 5.4 |  | $ | 1,386,807 |  |
| Vested and exercisable—September 30, 2018 |  | 2,734 |  |  | $ | 22.39 |  |  | 4.8 |  | $ | 665,576 |  |

[0001596532-18-000233:notes:74]
[same as prior period, unchanged from 0001596532-18-000174:notes:70]

[0001596532-18-000233:notes:75]
[same as prior period, unchanged from 0001596532-18-000174:notes:71]

[0001596532-18-000233:notes:76]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2017 |  | 1,537 |  |  | $ | 104.29 |  |  | 1.6 |  | $ | 362,119 |  |
| RSUs granted |  | 231 |  |  | 274.46 |  |  |  |  |  |
| RSUs vested |  | (405 | ) |  | 93.92 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (56 | ) |  | 127.57 |  |  |  |  |  |
| Unvested balance—September 30, 2018 |  | 1,307 |  |  | $ | 136.63 |  |  | 1.5 |  | $ | 347,386 |  |

[0001596532-18-000233:notes:77]
[same as prior period, unchanged from 0001596532-18-000174:notes:73]

[0001596532-18-000233:notes:78]
[same as prior period, unchanged from 0001596532-18-000174:notes:74]

[0001596532-18-000233:notes:79]
[same as prior period, unchanged from 0001596532-18-000174:notes:75]

[0001596532-18-000233:notes:80]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Cost of revenue |  | $ | 1,268 |  |  | $ | 1,113 |  |  | $ | 3,706 |  |  | $ | 3,224 |  |
| Research and development |  | 12,010 |  |  | 11,048 |  |  | 34,700 |  |  | 30,977 |  |
| Sales and marketing |  | 6,537 |  |  | 5,115 |  |  | 18,771 |  |  | 12,651 |  |
| General and administrative |  | 3,439 |  |  | 2,876 |  |  | 9,406 |  |  | 8,139 |  |
| Total stock-based compensation |  | $ | 23,254 |  |  | $ | 20,152 |  |  | $ | 66,583 |  |  | $ | 54,991 |  |

[0001596532-18-000233:notes:81]
As of September 30, 2018, unrecognized stock-based compensation expenses by award type and their expected weighted-average recognition periods are summarized in the following table (in thousands, except years).

[0001596532-18-000233:notes:82]
|  |  | September 30, 2018 |
|  |  | Stock Option |  | RSU |  | ESPP |  | Restricted Stock |
| Unrecognized stock-based compensation expense |  | $ | 60,754 |  |  | $ | 161,733 |  |  | $ | 9,722 |  |  | $ | 5,825 |  |
| Weighted-average amortization period |  | 3.6 years |  |  | 3.2 years |  |  | 1.2 years |  |  | 4.0 years |  |

[0001596532-18-000233:notes:83]
Restricted Stock

[0001596532-18-000233:notes:84]
Pursuant to the close of an acquisition during the current quarter (see Note 2), we issued 21,749 restricted shares of our common stock to certain key employees. These restricted shares vest over 4 years from the acquisition date and any unvested shares will be forfeited upon termination of such employees under certain conditions. The acquisition date fair value of these shares will be recognized as stock-based compensation over their vesting period.


## us-gaap:EarningsPerShareTextBlock

[0001596532-18-000233:notes:85]
8.    Net Income Per Share Available to Common Stock

[0001596532-18-000233:notes:86]
The following table sets forth the computation of our basic and diluted net income per share available to common stock (in thousands, except per share amounts):

[0001596532-18-000233:notes:87]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Numerator: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 168,524 |  |  | $ | 133,722 |  |  | $ | 157,793 |  |  | $ | 319,368 |  |
| Less: undistributed earnings allocated to participating securities |  | (85 | ) |  | (182 | ) |  | (87 | ) |  | (725 | ) |
| Net income available to common stockholders, basic |  | $ | 168,439 |  |  | $ | 133,540 |  |  | $ | 157,706 |  |  | $ | 318,643 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Net income attributable to common stockholders, basic |  | $ | 168,439 |  |  | $ | 133,540 |  |  | $ | 157,706 |  |  | $ | 318,643 |  |
| Add: undistributed earnings allocated to participating securities |  | 6 |  |  | 15 |  |  | 7 |  |  | 61 |  |
| Net income attributable to common stockholders, diluted |  | $ | 168,445 |  |  | $ | 133,555 |  |  | $ | 157,713 |  |  | $ | 318,704 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 75,011 |  |  | 72,588 |  |  | 74,506 |  |  | 71,903 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 75,011 |  |  | 72,588 |  |  | 74,506 |  |  | 71,903 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Stock options and RSUs |  | 5,967 |  |  | 6,636 |  |  | 6,298 |  |  | 6,528 |  |
| Employee stock purchase plan |  | 40 |  |  | 98 |  |  | 40 |  |  | 97 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted |  | 81,018 |  |  | 79,322 |  |  | 80,844 |  |  | 78,528 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.25 |  |  | $ | 1.84 |  |  | $ | 2.12 |  |  | $ | 4.43 |  |
| Diluted |  | $ | 2.08 |  |  | $ | 1.68 |  |  | $ | 1.95 |  |  | $ | 4.06 |  |

[0001596532-18-000233:notes:88]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share available to common stockholders for the periods presented because including them would have been anti-dilutive (in thousands):

[0001596532-18-000233:notes:89]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Stock options and RSUs to purchase common stock |  | 82 |  |  | 14 |  |  | 87 |  |  | 73 |  |
| Employee stock purchase plan |  | 98 |  |  | — |  |  | 59 |  |  | — |  |
| Total |  | 180 |  |  | 14 |  |  | 146 |  |  | 73 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-18-000233:notes:90]
[same as prior period, unchanged from 0001596532-18-000174:notes:84]

[0001596532-18-000233:notes:91]
|  |  | September 30, 2018 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 170,604 |  |  | $ | — |  |  | $ | — |  |  | $ | 170,604 |  |  | $ | 170,604 |  |  | $ | — |  |  | $ | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 46,572 |  |  | — |  |  | — |  |  | 46,572 |  |  | — |  |  | 46,572 |  |  | — |  |
| U.S. government notes |  | 227,086 |  |  | — |  |  | (513 | ) |  | 226,573 |  |  | 226,573 |  |  | — |  |  | — |  |
| Corporate bonds |  | 581,093 |  |  | 19 |  |  | (1,408 | ) |  | 579,704 |  |  | — |  |  | 579,704 |  |  | — |  |
| Agency securities |  | 285,261 |  |  | — |  |  | (998 | ) |  | 284,263 |  |  | — |  |  | 284,263 |  |  | — |  |
|  |  | 1,140,012 |  |  | 19 |  |  | (2,919 | ) |  | 1,137,112 |  |  | 226,573 |  |  | 910,539 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,210 |  |  | — |  |  | — |  |  | 4,210 |  |  | 4,210 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 1,314,826 |  |  | $ | 19 |  |  | $ | (2,919 | ) |  | $ | 1,311,926 |  |  | $ | 401,387 |  |  | $ | 910,539 |  |  | $ | — |  |

[0001596532-18-000233:notes:92]
[same as prior period, unchanged from 0001596532-18-000174:notes:86]


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-18-000233:notes:93]
3.    Fair Value Measurements

[0001596532-18-000233:notes:94]
[same as prior period, unchanged from 0001596532-18-000174:notes:88]

[0001596532-18-000233:notes:95]
[same as prior period, unchanged from 0001596532-18-000174:notes:89]

[0001596532-18-000233:notes:96]
[same as prior period, unchanged from 0001596532-18-000174:notes:90]

[0001596532-18-000233:notes:97]
[same as prior period, unchanged from 0001596532-18-000174:notes:91]

[0001596532-18-000233:notes:98]
[same as prior period, unchanged from 0001596532-18-000174:notes:92]

[0001596532-18-000233:notes:99]
We did not realize any other-than-temporary losses on our marketable securities for the three and nine months ended September 30, 2018 and 2017. We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a lower yield show a mark-to-market unrealized loss. The unrealized losses are due primarily to changes in credit spreads and interest rates. We expect to realize the full value of these investments upon maturity or sale and therefore, we do not consider any of our marketable securities to be other-than-temporarily impaired as of September 30, 2018.

[0001596532-18-000233:notes:100]
As of September 30, 2018, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale marketable securities, by remaining contractual maturity, are as follows (in thousands):

[0001596532-18-000233:notes:101]
|  |  | September 30, 2018 |
| Due in 1 year or less |  | $ | 792,542 |  |
| Due in 1 year through 2 years |  | 344,570 |  |
| Total marketable securities |  | $ | 1,137,112 |  |

[0001596532-18-000233:notes:102]
The weighted-average remaining duration of our current marketable securities is approximately 0.7 years as of September 30, 2018.  As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying unaudited condensed consolidated balance sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-18-000233:notes:103]
9.    Income Taxes

[0001596532-18-000233:notes:104]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
|  |  | (in thousands, except percentages) |
| Income before income taxes |  | $ | 189,389 |  |  | $ | 142,267 |  |  | $ | 90,311 |  |  | $ | 333,125 |  |
| Provision for (benefit from) income taxes |  | $ | 20,865 |  |  | $ | 8,545 |  |  | $ | (67,482 | ) |  | $ | 13,757 |  |
| Effective tax rate |  | 11.0 | % |  | 6.0 | % |  | (74.7 | )% |  | 4.1 | % |

[0001596532-18-000233:notes:105]
The effective tax rates above reflect tax expense recorded on pre-tax income in the three months ended September 30, 2018 and an overall tax benefit recorded on pre-tax income in the nine months ended September 30, 2018. The tax expense recorded in the three months ended September 30, 2018 includes a lower U.S. corporate tax and U.S. tax on foreign earnings, as a result of the Tax Cuts and Jobs Act (“Tax Act”), and the tax effects of business acquisitions, including integration. For the nine months ended September 30, 2018, the rate also includes a federal and state tax discrete benefit on a $405.0 million charge related to our legal settlement with Cisco recorded in the three months ended June 30, 2018.  In all periods, excess tax benefits attributable to equity compensation also significantly benefit the effective tax rate.

[0001596532-18-000233:notes:106]
Integrating intellectual property from acquisitions into our business generally involves intercompany transactions and legal entity restructurings that have the impact of increasing our provision for income taxes. Consequently, our provision for income taxes and our effective tax rate may initially increase in the period of and shortly after an acquisition and integration. The magnitude of this impact will depend upon the specific type, size, and taxing jurisdictions of the intellectual property as well as the relative contribution to income in subsequent periods.

[0001596532-18-000233:notes:107]
[same as prior period, unchanged from 0001596532-18-000174:notes:100]

[0001596532-18-000233:notes:108]
[same as prior period, unchanged from 0001596532-18-000174:notes:101]

[0001596532-18-000233:notes:109]
[same as prior period, unchanged from 0001596532-18-000174:notes:102]

[0001596532-18-000233:notes:110]
As of September 30, 2018, we have not yet completed our accounting for the tax effects of the enactment of the Tax Act.  We recognized a provisional tax amount of $51.8 million in the fourth quarter of 2017 for the transition tax liability and the revaluation of our deferred income taxes as a result of the rate change. In the nine months ended September 30, 2018, we did not revise this estimate.  In addition, we recorded a reasonable estimate for the effect of the new legislation as discussed above, which impacts our US income tax liabilities for the year ending December 31, 2018. Our estimates may also be affected as we gain a more thorough understanding of the tax law. These changes could be material to income tax expense. We will continue to refine our estimates related to the impact of the Tax Act during the one-year measurement period allowed under Staff Accounting Bulletin 118 (“SAB 118”).


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-18-000233:notes:111]
5.    Investments

[0001596532-18-000233:notes:112]
[same as prior period, unchanged from 0001596532-18-000174:notes:106]

[0001596532-18-000233:notes:113]
We adopted ASU 2016-01 in the three months ended March 31, 2018 (refer to Note 1). As of September 30, 2018 and December 31, 2017, we held non-marketable equity investments of approximately $35.0 million and $36.1 million, respectively, in privately-held companies. These investments do not have readily determinable fair values and are measured using the measurement alternative.  As of September 30, 2018, $27.0 million of the total investment amount of $35.0 million was re-measured as further described below, and are classified within Level III of the fair value hierarchy.

[0001596532-18-000233:notes:114]
Prior to 2018, we did not record any impairment losses for these investments. During the three months ended September 30, 2018, no impairment or adjustment was recorded. During the nine months ended September 30, 2018, we recorded $1.2 million of unrealized gain on investments in one company after they were re-measured to fair value as of the date observable transactions occurred. In addition, during the nine months ended September 30, 2018, we recorded $10.3 million of impairment loss on an investment.  The unrealized gain and loss are classified in “Other income (expense), net” in our accompanying unaudited condensed consolidated statements of operations.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001596532-18-000233:notes:115]
11.    Legal Settlement

[0001596532-18-000233:notes:116]
On August 6, 2018, we entered into a binding term sheet with Cisco (“Term Sheet”). Under the Term Sheet, we paid Cisco $400.0 million on August 20, 2018, and the parties obtained dismissals of all ongoing district court and USITC litigation between them. Cisco granted us a release for all past claims relating to the patents Cisco asserted against us in the district court and USITC, and we granted Cisco a release from all past antitrust and unfair competition claims. These mutual releases extended to the Company's and Cisco’s customers, contract manufacturers, and partners. The parties further agreed to a five-year stand-down period for any utility patent infringement claims either may have against features currently implemented in the other party’s products and services, with some carve-outs for products stemming from acquired companies. The parties further agreed to a three-year dispute resolution process for allegations by either party against new and/or modified features in the other party’s products. We also agreed to make certain modifications to our Command Line Interface (“CLI”).

[0001596532-18-000233:notes:117]
Upon signing the Term Sheet, we recorded a legal settlement charge of $405.0 million to operating expenses, which included legal fees associated with the settlement in the three months ended June 30, 2018. We have also recorded a corresponding income tax benefit of $0.9 million and $99.9 million for the three and nine months ended September 30, 2018.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-18-000233:notes:118]
Recently Adopted Accounting Pronouncements

[0001596532-18-000233:notes:119]
Revenue Recognition

[0001596532-18-000233:notes:120]
During May 2014, the Financial Accounting Standards Board (“FASB”) issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606). In 2016, the FASB issued ASU No. 2016-08, ASU No. 2016-10 and ASU No. 2016-12, which provide interpretive clarifications on the new guidance in Topic 606 (collectively, “the new standard”). Under the new standard, the recognition of revenue is based on consideration we expect to be entitled to from the transfer of goods or services to a customer.

[0001596532-18-000233:notes:121]
The primary impact of the new standard is related to the deferral of incremental commission costs of obtaining customer service contracts, which were previously expensed as incurred. Under the new standard, we defer all such costs and amortize them over the expected period of benefit. The new standard also requires companies to account for termination clauses at the onset of an arrangement. While there is limited history of cancellations, our prepaid subscription offerings are generally cancellable by customers with 30 days’ notice, therefore, the subscription contracts are considered month-to-month. While these prepaid amounts have historically been recorded to deferred revenue, the new standard requires that we record these amounts as other liabilities.  In addition, the new standard may impact the amount and timing of revenue recognition of certain sales arrangements and the related disclosures on our consolidated financial statements.

[0001596532-18-000233:notes:122]
We adopted the new standard in our first quarter of 2018 using the modified retrospective method, which resulted in a cumulative effect adjustment of $3.5 million that increased retained earnings to capitalize certain commission costs that were expensed in the prior year. Correspondingly, we increased prepaid expenses and other current assets by $2.0 million, other assets by $2.2 million, and decreased deferred tax assets by $0.7 million as of January 1, 2018. In addition, we reclassified $16.5 million of deferred revenue as of January 1, 2018 to other current liabilities and other long-term liabilities related to our prepaid subscription offerings. The impact of adopting the new standard was not material to our financial results for the three and nine months ended September 30, 2018 and we do not expect the impact to be material to the financial results for our fiscal 2018.

[0001596532-18-000233:notes:123]
We apply a practical expedient to expense costs as incurred for costs to obtain a contract with a customer when the amortization period would have been one year or less, as well as the portfolio approach for the contracts reviewed. These costs include a portion of our sales force compensation program as we have determined annual compensation is commensurate with recurring sales activities.

[0001596532-18-000233:notes:124]
Financial Instruments

[0001596532-18-000233:notes:125]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which enhances the reporting model for financial instruments to provide users of financial statements with more decision-useful information. In February 2018, the FASB issued ASU 2018-03, Technical Corrections and Improvements to Financial Instruments, to clarify certain aspects of ASU 2016-01. ASU 2016-01 and ASU 2018-03 (collectively, the “new guidance”) address certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. We adopted this new guidance in our first quarter of fiscal 2018. Under the new guidance, there was no change in the accounting of our marketable securities as our investment policy only allows investments in debt securities. For our cost method equity investments in privately-held companies without readily determinable fair value, we elected to use the measurement alternative, defined as cost, less impairments, as adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer, which was adopted prospectively. Adjustments resulting from impairments and/or observable price changes are to be recorded as other income (expense) on a prospective basis.

[0001596532-18-000233:notes:126]
The carrying amount of our equity investments and any related gain or loss may fluctuate in the future as a result of the re-measurement of such equity investments upon the occurrence of observable price changes and/or impairments.

[0001596532-18-000233:notes:127]
Income Taxes on Intra-Entity Transfers of Assets

[0001596532-18-000233:notes:128]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which addresses recognition of current and deferred income taxes for intra-entity asset transfers when assets are sold to an outside party. Current GAAP prohibits the recognition of current and deferred income taxes until the asset has been sold to an outside party. This prohibition on recognition is considered an exception to the principle of comprehensive recognition of current and deferred income taxes in GAAP. The new guidance requires an entity to recognize the income tax consequences when the transfer occurs eliminating the exception. The guidance must be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. We adopted this guidance in our first quarter of fiscal 2018. As a result, we recognized a cumulative effect adjustment in the condensed consolidated balance sheet as of September 30, 2018 by increasing the retained earnings and the deferred tax assets as of January 1, 2018 by approximately $0.1 million, respectively.

[0001596532-18-000233:notes:129]
Restricted Cash in Statement of Cash Flows

[0001596532-18-000233:notes:130]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force (“ASU 2016-18”), which requires that amounts generally described as restricted cash or restricted cash equivalents be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows.  This standard is required to be applied using a retrospective transition method to each period presented.  We retrospectively adopted ASU 2016-18 in our first quarter of fiscal 2018. As a result of the adoption, we adjusted the condensed consolidated statement of cash flows for the nine months ended September 30, 2017 to increase the beginning-of-period and end-of-period cash amounts by $4.2 million and $5.5 million, respectively, and to decrease net cash used in investing activities by $1.3 million.

[0001596532-18-000233:notes:131]
Recent Accounting Pronouncements Not Yet Effective

[0001596532-18-000233:notes:132]
Nonemployee Share-Based Payments

[0001596532-18-000233:notes:133]
In June 2018, the FASB issued ASU 2018-07, Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting (“ASU 2018-07”), to simplify the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees with certain exceptions. Under the guidance, the measurement of equity-classified nonemployee awards will be fixed at the grant date, which may lower their cost and reduce volatility in the income statement. The guidance is effective for us for our first quarter of 2019. Early adoption is permitted. ASU 2018-07 shall be applied on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of the beginning of the fiscal year in which the guidance is adopted. We are currently assessing the impact this guidance may have on our consolidated financial statements.

[0001596532-18-000233:notes:134]
Leases

[0001596532-18-000233:notes:135]
In February 2016, the FASB issued ASU No. 2016-02, Leases (“ASU 2016-02”). In July 2018, the FASB issued ASU No. 2018-11, Leases (Topic 842): Targeted Improvements (“ASU 2018-11”). Under the guidance, lessees are required to recognize assets and lease liabilities on the balance sheet for most leases including operating leases and provide enhanced disclosures. There are optional practical expedients that a company may elect to apply. The guidance is effective for our first quarter of 2019 and may be early adopted. Companies can adopt this guidance using a modified retrospective approach or, pursuant to ASU 2018-11, using an additional optional transition method. Under the optional transition method, a company initially applies the new leases standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption. We plan to adopt the guidance in the first quarter of 2019 using the additional optional transition method. Management’s evaluation of the new standard is underway, and we have identified the significant changes between the current guidance and the new guidance and expect to elect certain available transitional practical expedients.  In addition, we have developed a project plan, performed a risk assessment, and have summarized the terms of our major lease agreements. We are in the process of reviewing our existing lease agreements to assess the impact this guidance may have on our consolidated financial statements. We currently anticipate that the adoption of ASU 2016-02 will materially affect our consolidated balance sheets by recognizing new right-of-use assets and lease liabilities for operating leases, but will not have a material impact on our consolidated statements of operations.

[0001596532-18-000233:notes:136]
Credit Losses of Financial Instruments

[0001596532-18-000233:notes:137]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. Credit losses relating to available-for-sale debt securities should be recorded through an allowance for credit losses. This standard is effective for us for our first quarter of 2020. We are currently assessing the impact this guidance may have on our consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-18-000233:notes:138]
[same as prior period, unchanged from 0001596532-18-000174:notes:130]

[0001596532-18-000233:notes:139]
[same as prior period, unchanged from 0001596532-18-000174:notes:131]

[0001596532-18-000233:notes:140]
[same as prior period, unchanged from 0001596532-18-000174:notes:132]

[0001596532-18-000233:notes:141]
[same as prior period, unchanged from 0001596532-18-000174:notes:133]

[0001596532-18-000233:notes:142]
[same as prior period, unchanged from 0001596532-18-000174:notes:134]

[0001596532-18-000233:notes:143]
The preparation of the accompanying condensed consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; valuation of goodwill and acquisition-related intangible assets, accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; estimate of useful lives of long-lived assets including intangible assets; valuation of inventory and contract manufacturer/supplier liabilities; recognition and measurement of contingent liabilities; valuation of equity investments in privately-held companies; determination of fair value for stock-based awards; and valuation of warranty accruals. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

[0001596532-18-000233:notes:144]
[same as prior period, unchanged from 0001596532-18-000174:notes:136]

[0001596532-18-000233:notes:145]
During the nine months ended September 30, 2018, we completed two business acquisitions (see Note 2) and adopted several recent accounting pronouncements as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. As a result, we updated certain significant accounting policies as described below. There have been no other significant changes to our accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

[0001596532-18-000233:notes:146]
[same as prior period, unchanged from 0001596532-18-000174:notes:138]

[0001596532-18-000233:notes:147]
Effective January 1, 2018, we adopted a new revenue recognition policy in accordance with ASC 606 - Revenue from Contracts with Customers (“ASC 606”) using the modified retrospective method as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1.  Prior to 2018, our revenue recognition policy was based on ASC 605 - Revenue Recognition (“ASC 605”), and is described in Note 1 of Notes to Consolidated Financial Statements under Item 8 of our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

[0001596532-18-000233:notes:148]
[same as prior period, unchanged from 0001596532-18-000174:notes:140]

[0001596532-18-000233:notes:149]
[same as prior period, unchanged from 0001596532-18-000174:notes:141]

[0001596532-18-000233:notes:150]
[same as prior period, unchanged from 0001596532-18-000174:notes:142]

[0001596532-18-000233:notes:151]
[same as prior period, unchanged from 0001596532-18-000174:notes:143]

[0001596532-18-000233:notes:152]
[same as prior period, unchanged from 0001596532-18-000174:notes:144]

[0001596532-18-000233:notes:153]
[same as prior period, unchanged from 0001596532-18-000174:notes:145]

[0001596532-18-000233:notes:154]
[same as prior period, unchanged from 0001596532-18-000174:notes:146]

[0001596532-18-000233:notes:155]
[same as prior period, unchanged from 0001596532-18-000174:notes:147]

[0001596532-18-000233:notes:156]
[same as prior period, unchanged from 0001596532-18-000174:notes:148]

[0001596532-18-000233:notes:157]
[same as prior period, unchanged from 0001596532-18-000174:notes:149]

[0001596532-18-000233:notes:158]
[same as prior period, unchanged from 0001596532-18-000174:notes:150]

[0001596532-18-000233:notes:159]
[same as prior period, unchanged from 0001596532-18-000174:notes:151]

[0001596532-18-000233:notes:160]
[same as prior period, unchanged from 0001596532-18-000174:notes:152]

[0001596532-18-000233:notes:161]
[same as prior period, unchanged from 0001596532-18-000174:notes:153]

[0001596532-18-000233:notes:162]
[same as prior period, unchanged from 0001596532-18-000174:notes:154]

[0001596532-18-000233:notes:163]
[same as prior period, unchanged from 0001596532-18-000174:notes:155]

[0001596532-18-000233:notes:164]
[same as prior period, unchanged from 0001596532-18-000174:notes:156]

[0001596532-18-000233:notes:165]
A contract asset is recognized when we have performed under the contract, but our right to consideration is conditional on something other than the passage of time. Contract assets are included in “Other current assets” on our condensed consolidated balance sheets.

[0001596532-18-000233:notes:166]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a contract that is cancellable. Contract liabilities are included in “Other current liabilities” and “Other long-term liabilities” on our condensed consolidated balance sheets.

[0001596532-18-000233:notes:167]
[same as prior period, unchanged from 0001596532-18-000174:notes:159]

[0001596532-18-000233:notes:168]
[same as prior period, unchanged from 0001596532-18-000174:notes:160]

[0001596532-18-000233:notes:169]
Business Combinations

[0001596532-18-000233:notes:170]
We use the acquisition method to account for our business combinations in accordance with ASC 805 - Business Combinations (“ASC 805”). We allocate the total purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the consideration transferred over the fair values of the assets acquired and liabilities assumed is recorded as goodwill. The results of operations of the acquired businesses are included in our consolidated financial statements from the date of acquisition. Acquisition-related costs and restructuring costs are expensed as incurred.

[0001596532-18-000233:notes:171]
Goodwill

[0001596532-18-000233:notes:172]
We perform our annual goodwill impairment analysis in the fourth quarter of each year or more frequently if there are any events or circumstances that would indicate the carrying amount is not recoverable. We first perform a qualitative assessment to determine if it’s necessary to perform a quantitative assessment.  If after our qualitative assessment, we determine it is more likely than not that the fair value of the Company is less than its carrying amount, then a quantitative test is performed by comparing the fair value of the Company with its carrying amount in accordance with Accounting Standard Update (“ASU”) No. 2017-04, Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. We would recognize an impairment loss for the amount by which the carrying amount exceeds the fair value.

[0001596532-18-000233:notes:173]
Intangible Assets

[0001596532-18-000233:notes:174]
Intangible assets are carried at cost less accumulated amortization. All intangible assets have been determined to have definite lives and are amortized on a straight-line basis over their estimated remaining useful lives, ranging from one to seven years. Intangible assets are tested for impairment annually in the fourth quarter of each year or whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001596532-18-000233:notes:175]
[same as prior period, unchanged from 0001596532-18-000174:notes:161]

[0001596532-18-000233:notes:176]
|  |  | September 30, 2018 |  | December 31, 2017 |
| Equipment and machinery |  | $ | 54,169 |  |  | $ | 47,711 |  |
| Computer hardware and software |  | 28,549 |  |  | 22,124 |  |
| Furniture and fixtures |  | 3,641 |  |  | 3,020 |  |
| Leasehold improvements |  | 36,350 |  |  | 30,548 |  |
| Building |  | 35,154 |  |  | 35,154 |  |
| Construction-in-process |  | 1,931 |  |  | 4,742 |  |
| Property and equipment, gross |  | 159,794 |  |  | 143,299 |  |
| Less: accumulated depreciation |  | (84,397 | ) |  | (69,020 | ) |
| Property and equipment, net |  | $ | 75,397 |  |  | $ | 74,279 |  |


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001596532-18-000233:notes:177]
[same as prior period, unchanged from 0001596532-18-000174:notes:163]

[0001596532-18-000233:notes:178]
|  |  | September 30, 2018 |  | December 31, 2017 |
| Accounts receivable |  | $ | 333,304 |  |  | $ | 254,881 |  |
| Allowance for doubtful accounts |  | (498 | ) |  | (112 | ) |
| Product sales rebate and returns reserve |  | (10,753 | ) |  | (7,423 | ) |
| Accounts receivable, net |  | $ | 322,053 |  |  | $ | 247,346 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001596532-18-000233:notes:179]
[same as prior period, unchanged from 0001596532-18-000174:notes:165]

[0001596532-18-000233:notes:180]
|  |  | September 30, 2018 |  | December 31, 2017 |
| Accrued payroll related costs |  | $ | 55,422 |  |  | $ | 56,626 |  |
| Accrued manufacturing costs |  | 21,282 |  |  | 35,703 |  |
| Accrued product development costs |  | 7,552 |  |  | 21,201 |  |
| Accrued warranty costs |  | 10,115 |  |  | 7,415 |  |
| Accrued professional fees |  | 6,262 |  |  | 7,086 |  |
| Accrued taxes |  | 770 |  |  | 794 |  |
| Other |  | 1,705 |  |  | 5,002 |  |
| Total accrued liabilities |  | $ | 103,108 |  |  | $ | 133,827 |  |


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001596532-18-000233:notes:181]
[same as prior period, unchanged from 0001596532-18-000174:notes:167]

[0001596532-18-000233:notes:182]
|  |  | September 30, 2018 |  | September 30, 2017 |
| Cash and cash equivalents |  | $ | 524,687 |  |  | $ | 854,479 |  |
| Restricted cash included in other assets |  | 4,210 |  |  | 5,502 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 528,897 |  |  | $ | 859,981 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001596532-18-000233:notes:183]
[same as prior period, unchanged from 0001596532-18-000174:notes:169]

[0001596532-18-000233:notes:184]
|  |  | September 30, 2018 |  | December 31, 2017 |
| Raw materials |  | $ | 48,697 |  |  | $ | 69,673 |  |
| Finished goods |  | 167,616 |  |  | 236,525 |  |
| Total inventories |  | $ | 216,313 |  |  | $ | 306,198 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001596532-18-000233:notes:185]
[same as prior period, unchanged from 0001596532-18-000174:notes:171]

[0001596532-18-000233:notes:186]
|  |  | September 30, 2018 |  | December 31, 2017 |
| Inventory deposit |  | $ | 19,290 |  |  | $ | 34,141 |  |
| Prepaid income taxes |  | 83,598 |  |  | 38,134 |  |
| Other current assets |  | 118,262 |  |  | 96,215 |  |
| Other prepaid expenses and deposits |  | 14,731 |  |  | 8,840 |  |
| Total prepaid expenses and other current assets |  | $ | 235,881 |  |  | $ | 177,330 |  |


## us-gaap:ScheduleOfOtherNonoperatingIncomeExpenseTableTextBlock

[0001596532-18-000233:notes:187]
[same as prior period, unchanged from 0001596532-18-000174:notes:173]

[0001596532-18-000233:notes:188]
|  |  | Three Months Ended September 30, 2018 |  | Nine Months Ended September 30, 2018 |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Interest income |  | $ | 8,585 |  |  | $ | 2,332 |  |  | $ | 21,933 |  |  | $ | 4,889 |  |
| Unrealized loss on investments in privately-held companies, net |  | — |  |  | — |  |  | (9,100 | ) |  | — |  |
| Other income (expense) |  | 707 |  |  | (196 | ) |  | (187 | ) |  | (609 | ) |
| Total |  | $ | 9,292 |  |  | $ | 2,136 |  |  | $ | 12,646 |  |  | $ | 4,280 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001596532-18-000233:notes:189]
[same as prior period, unchanged from 0001596532-18-000174:notes:175]

[0001596532-18-000233:notes:190]
|  |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |
| Warranty accrual, beginning of period |  | $ | 7,415 |  |  | $ | 6,744 |  |
| Liabilities accrued for warranties issued during the period |  | 6,898 |  |  | 5,020 |  |
| Warranty costs incurred during the period |  | (4,198 | ) |  | (3,478 | ) |
| Warranty accrual, end of period |  | $ | 10,115 |  |  | $ | 8,286 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001596532-18-000233:notes:191]
[same as prior period, unchanged from 0001596532-18-000174:notes:177]

[0001596532-18-000233:notes:192]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Americas |  | $ | 406,666 |  |  | $ | 309,318 |  |  | $ | 1,099,624 |  |  | $ | 878,201 |  |
| Europe, Middle East and Africa |  | 92,911 |  |  | 79,143 |  |  | 316,608 |  |  | 199,244 |  |
| Asia-Pacific |  | 63,732 |  |  | 49,172 |  |  | 139,411 |  |  | 100,874 |  |
| Total revenue |  | $ | 563,309 |  |  | $ | 437,633 |  |  | $ | 1,555,643 |  |  | $ | 1,178,319 |  |

[0001596532-18-000233:notes:193]
[same as prior period, unchanged from 0001596532-18-000174:notes:179]

[0001596532-18-000233:notes:194]
|  |  | September 30, 2018 |  | December 31, 2017 |
| United States |  | $ | 69,093 |  |  | $ | 69,128 |  |
| International |  | 6,304 |  |  | 5,151 |  |
| Total |  | $ | 75,397 |  |  | $ | 74,279 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-18-000233:notes:195]
10.    Segment Information

[0001596532-18-000233:notes:196]
[same as prior period, unchanged from 0001596532-18-000174:notes:182]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-18-000233:notes:197]
4.    Financial Statements Details

[0001596532-18-000233:notes:198]
[same as prior period, unchanged from 0001596532-18-000174:notes:190]

[0001596532-18-000233:notes:199]
Restricted cash included in other assets as of September 30, 2018 and September 30, 2017 primarily included $4.0 million pledged as collateral representing a security deposit required for a facility lease.  In addition, September 30, 2017 included $1.1 million related to a letter of credit issued to a business partner.

[0001596532-18-000233:notes:200]
[same as prior period, unchanged from 0001596532-18-000174:notes:192]

[0001596532-18-000233:notes:201]
[same as prior period, unchanged from 0001596532-18-000174:notes:193]

[0001596532-18-000233:notes:202]
[same as prior period, unchanged from 0001596532-18-000174:notes:194]

[0001596532-18-000233:notes:203]
[same as prior period, unchanged from 0001596532-18-000174:notes:195]

[0001596532-18-000233:notes:204]
Depreciation expense was $5.4 million and $5.2 million for the three months ended September 30, 2018 and 2017, respectively, and $16.0 million and $15.0 million for the nine months ended September 30, 2018 and 2017, respectively.

[0001596532-18-000233:notes:205]
[same as prior period, unchanged from 0001596532-18-000174:notes:197]

[0001596532-18-000233:notes:206]
[same as prior period, unchanged from 0001596532-18-000174:notes:198]

[0001596532-18-000233:notes:207]
As of September 30, 2018, $10.9 million of our contract liabilities was included in “Other current liabilities” with the remaining balance included in “Other long-term liabilities”.

[0001596532-18-000233:notes:208]
[same as prior period, unchanged from 0001596532-18-000174:notes:200]

[0001596532-18-000233:notes:209]
[same as prior period, unchanged from 0001596532-18-000174:notes:201]

[0001596532-18-000233:notes:210]
Revenue from remaining performance obligations represents contracted revenue that has not yet been recognized, which includes contract liabilities and deferred revenue that will be recognized as revenue in future periods. As of September 30, 2018, approximately $555.2 million of revenue is expected to be recognized from remaining performance obligations. We expect to recognize revenue on approximately 84% of these remaining performance obligations over the next 2 years and 16% during the 3rd to the 5th year.

[0001596532-18-000233:notes:211]
[same as prior period, unchanged from 0001596532-18-000174:notes:203]
