# ANET note change history — 0001596532-18-000174 → 0001596532-18-000233


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-05):
[0001596532-18-000233:note_history:1]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2025. There have been no material changes in our future minimum payment obligations under our operating leases that existed as of December 31, 2017, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2017, except as follows. During the nine months ended September 30, 2018, we entered into new leases primarily related to additional data center capacity and co-location services. As of September 30, 2018, the total minimum future payment commitment under these new leases was approximately $47.7 million, of which $1.2 million is due in 2018, with the remainder due in 2021 through 2028.
  (was, 2018-08-08, similarity 0.9588):
[0001596532-18-000174:note_history:1]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2025. There have been no material changes in our future minimum payment obligations under our operating leases that existed as of December 31, 2017, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2017, except as follows. During the six months ended June 30, 2018, we entered into new leases primarily related to additional data center capacity and co-location services. As of June 30, 2018, the total minimum future payment commitment under these new leases was approximately $46.4 million, of which $1.0 million is due in 2018, with the remainder due in 2021 through 2028.

- changed (2018-11-05):
[0001596532-18-000233:note_history:2]
We recognize rent expense under these arrangements on a straight-line basis over the term of the leases. For the three months ended September 30, 2018 and 2017, rent expense for all operating leases amounted to $2.8 million and $2.5 million, respectively, and to $7.9 million and $7.5 million for the nine months ended September 30, 2018 and 2017, respectively.
  (was, 2018-08-08, similarity 0.9074):
[0001596532-18-000174:note_history:2]
We recognize rent expense under these arrangements on a straight-line basis over the term of the leases. For the three months ended June 30, 2018 and 2017, rent expense for all operating leases amounted to $2.6 million and $2.6 million, respectively, and to $5.1 million and $5.0 million for the six months ended June 30, 2018 and 2017, respectively.

- changed (2018-11-05):
[0001596532-18-000233:note_history:3]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013. The lease is accounted for as a financing obligation and the lease payments are attributed to (1) a reduction of the principal financing obligation; (2) imputed interest expense; and (3) land lease expense, representing an imputed cost to lease the underlying land of the building. There have been no material changes in our future minimum payment obligations under this financing lease, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2017. Land lease expense related to our lease financing obligation is classified as rent expense in our unaudited condensed consolidated statements of operations, and amounted to $0.3 million for the three months ended September 30, 2018 and 2017, and $1.0 million for the nine months ended September 30, 2018 and 2017, respectively.
  (was, 2018-08-08, similarity 0.9494):
[0001596532-18-000174:note_history:3]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013. The lease is accounted for as a financing obligation and the lease payments are attributed to (1) a reduction of the principal financing obligation; (2) imputed interest expense; and (3) land lease expense, representing an imputed cost to lease the underlying land of the building. There have been no material changes in our future minimum payment obligations under this financing lease, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2017. Land lease expense related to our lease financing obligation is classified as rent expense in our unaudited condensed consolidated statements of operations, and amounted to $0.3 million for the three months ended June 30, 2018 and 2017, and $0.6 million for the six months ended June 30, 2018 and 2017.

- changed (2018-11-05):
[0001596532-18-000233:note_history:4]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2018, we had non-cancellable purchase commitments of $423.1 million, of which $370.4 million was to our contract manufacturers and suppliers. We have not recorded a liability related to these purchase commitments. In addition, we have provided deposits to secure our obligations to purchase inventory. We had $22.0 million and $36.9 million in deposits as of September 30, 2018 and December 31, 2017, respectively. These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.
  (was, 2018-08-08, similarity 0.9891):
[0001596532-18-000174:note_history:4]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished product and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of June 30, 2018, we had non-cancellable purchase commitments of $269.6 million, of which $215.4 million was to our contract manufacturers and suppliers. We have not recorded a liability related to these purchase commitments. In addition, we have provided deposits to secure our obligations to purchase inventory. We had $28.0 million and $36.9 million in deposits as of June 30, 2018 and December 31, 2017, respectively. These deposits are classified in “Prepaid expenses and other current assets” and “Other assets” in our accompanying unaudited condensed consolidated balance sheets.

- changed (2018-11-05):
[0001596532-18-000233:note_history:5]
On August 6, 2018, we entered into a settlement agreement with Cisco Systems, Inc. (“Cisco”) as described in Note 11 relating to several litigation matters which are summarized below.
  (was, 2018-08-08, similarity 0.6612):
[0001596532-18-000174:note_history:5]
Although we have reached a settlement with Cisco, as described in Note 10, we are currently involved in several litigation matters with Cisco Systems, Inc. These matters are summarized below.

- changed (2018-11-05):
[0001596532-18-000233:note_history:6]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the ’875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”). Pursuant to the settlement with Cisco, as described in Note 11, the ’43 Case was dismissed on August 27, 2018.
  (was, 2018-08-08, similarity 0.9363):
[0001596532-18-000174:note_history:6]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the ’875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”). Pursuant to the settlement with Cisco, as described in Note 10, the ’43 Case will be dismissed following execution of a final agreement with Cisco.

- changed (2018-11-05):
[0001596532-18-000233:note_history:7]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI” and U.S. Patent Nos. 7,047,526 and 7,953,886 (respectively, “the ’526 patent” and “the ’886 patent”). As relief for our alleged copyright infringement, Cisco sought monetary damages for alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees, and associated costs. The ’526 patent is subject to a non-appealable final judgment of non-infringement and the ’886 patent was dismissed with prejudice.
  (was, 2018-08-08, similarity 0.9928):
[0001596532-18-000174:note_history:7]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI” and U.S. Patent Nos. 7,047,526 and 7,953,886 (respectively, “the ’526 patent” and “the ’886 patent”). As relief for our alleged copyright infringement, Cisco seeks monetary damages for alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees, and associated costs. The ’526 patent is subject to a non-appealable final judgment of non-infringement and the ’886 patent was dismissed with prejudice.

- added (2018-11-05):
[0001596532-18-000233:note_history:8]
On December 14, 2016, following a two-week trial, a jury found that we had proven our copyright defense of scenes a faire. Cisco filed a notice of appeal on June 6, 2017. Cisco did not appeal the jury’s noninfringement verdict on the ’526 patent but did appeal the jury’s finding that we established the defense of scenes a faire. On October 1, 2018, at the parties’ request and pursuant to the settlement agreement, the District Court vacated the jury verdict regarding our copyright defense and dismissed the case.

- changed (2018-11-05):
[0001596532-18-000233:note_history:9]
On February 24, 2016, we filed a complaint against Cisco in the District Court for the Northern District of California alleging antitrust violations and unfair competition. On August 6, 2018, the Court vacated trial in light of the settlement with Cisco as describe in Note 11. Pursuant to the settlement with Cisco, the ’23 Case was dismissed.
  (was, 2018-08-08, similarity 0.8883):
[0001596532-18-000174:note_history:9]
On February 24, 2016, we filed a complaint against Cisco in the District Court for the Northern District of California alleging antitrust violations and unfair competition. On August 6, 2018, the Court vacated trial in light of the settlement with Cisco as describe in Note 10. Pursuant to the settlement with Cisco, the ’23 Case will be dismissed following execution of a final agreement with Cisco.

- added (2018-11-05):
[0001596532-18-000233:note_history:10]
On August 26, 2016, Cisco filed an enforcement complaint under Section 337 with the USITC. Cisco alleged that we violated the cease and desist and limited exclusion orders issued in the 944 Investigation by engaging in the “marketing, distribution, offering for sale, selling, advertising, and/or aiding or abetting other entities in the sale and/or distribution of products that Cisco alleges continue to infringe claims 1-2, 8-11, and 17-19 of the ’537 patent,” despite the design changes we made to those products. On September 28, 2016, the USITC instituted the enforcement proceeding.

- added (2018-11-05):
[0001596532-18-000233:note_history:11]
On August 4, 2017, the USITC issued an order remanding the investigation to the ALJ to make additional findings on certain issues and issue a remand initial determination. The USITC ordered the ALJ to set a schedule for completion of any necessary remand proceedings and a new target date for the enforcement action (the “944 Enforcement Action”). The ALJ held a hearing on February 1, 2018 and issued a remand initial determination on June 4, 2018, again finding that we did not violate the June 23, 2016 cease and desist order. Pursuant to the settlement with Cisco, the 944 Enforcement Investigation was terminated on September 17, 2018.  The parties have jointly requested suspension of the remedial orders in the 944 Investigation, and on October 23, 2018, the ITC instituted a modification proceeding to determine how to modify the orders consistent with the parties’ request.

- changed (2018-11-05):
[0001596532-18-000233:note_history:12]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II, including the application of the Court’s interpretation of the 2004 agreement to any other source code that OptumSoft claims to own and the trade secret misappropriation and confidentiality claims. The Phase II Trial is set for September 23, 2019 by the judge.
  (was, 2018-08-08, similarity 0.7087):
[0001596532-18-000174:note_history:12]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On December 16, 2015, the Court issued a Proposed Statement of Decision Following Phase 1 Trial, and on January 8, 2016, OptumSoft filed objections to that Proposed Statement of Decision. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II, including the application of the Court’s interpretation of the 2004 agreement as set forth in the Final Statement of Decision Following Phase I Trial to any other source code that OptumSoft claims to own following a review and the trade secret misappropriation and confidentiality claims.  The Phase II Trial is set to begin on March 4, 2019.

- changed (2018-11-05):
[0001596532-18-000233:note_history:13]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2018, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.
  (was, 2018-08-08, similarity 0.9937):
[0001596532-18-000174:note_history:13]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of June 30, 2018, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.

- removed (2018-11-05):
[0001596532-18-000174:note_history:14]
On December 14, 2016, following a two-week trial, a jury found that we had proven our copyright defense of scenes a faire. Cisco filed a notice of appeal on June 6, 2017. Cisco did not appeal the jury’s noninfringement verdict on the ’526 patent but did appeal the jury’s finding that we established the defense of scenes a faire. The matter is fully briefed, and the U.S. Court of Appeals for the Federal Circuit (the “Federal Circuit”) heard oral argument on June 6, 2018. The Federal Circuit has not yet issued a decision. Pursuant to the settlement with Cisco, the ’44 Case will continue until either the judge vacates the judgment or all appeals on the judgment are exhausted, at which time the case will be dismissed, and if the Federal Circuit overturns the scenes a faire verdict or remands the case to the district court for further proceedings Arista will make certain limited changes to its CLI and no further settlement amounts will be paid.

- removed (2018-11-05):
[0001596532-18-000174:note_history:15]
On August 26, 2016, Cisco filed an enforcement complaint under Section 337 with the USITC. Cisco alleges that we are violating the cease and desist and limited exclusion orders issued in the 944 Investigation by engaging in the “marketing, distribution, offering for sale, selling, advertising, and/or aiding or abetting other entities in the sale and/or distribution of products that Cisco alleges continue to infringe claims 1-2, 8-11, and 17-19 of the ’537 patent,” despite the design changes we have made to those products. Cisco asks the USITC to (1) enforce the cease and desist order; (2) modify the USITC’s limited exclusion order and/or cease and desist order “in any manner that would assist in the prevention of the unfair practices that were originally the basis for issuing such Order or assist in the detection of violations of such Order”; (3) impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000 or twice the domestic value of the articles entered or sold, whichever is higher”; (4) bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order”; and (5) impose “such other remedies and sanctions as are appropriate and within the USITC’s authority.” On September 28, 2016, the USITC instituted the enforcement proceeding. The proceeding has been assigned to ALJ Shaw, who presided over the underlying investigation.

- removed (2018-11-05):
[0001596532-18-000174:note_history:16]
On August 4, 2017, the USITC issued an order remanding the investigation to the ALJ to make additional findings on certain issues and issue a remand initial determination. The USITC ordered the ALJ to set a schedule for completion of any necessary remand proceedings and a new target date for the enforcement action (the “944 Enforcement Action”). The ALJ held a hearing on February 1, 2018 and issued a remand initial determination on June 4, 2018, again finding that we did not violate the June 23, 2016 cease and desist order. The parties have submitted additional petition for review briefing and the USITC is scheduled to issue a final determination on September 11, 2018. In light of the settlement with Cisco, the parties have filed a joint request to stay the remaining briefing and target dates in the 944 Enforcement Action to halt further activity.  Pursuant to the settlement with Cisco, the 944 Enforcement Investigation will be terminated and the remedial orders suspended following execution of a final agreement with Cisco.

- removed (2018-11-05):
[0001596532-18-000174:note_history:17]
* * * * *

- removed (2018-11-05):
[0001596532-18-000174:note_history:18]
Although we have reached a settlement with Cisco, as describe in Note 10, the Cisco lawsuits, as summarized in the preceding paragraphs, remain active subject to a final agreement with Cisco and we remain subject to the exclusion order issued in the 944 Investigation. In light of the settlement with Cisco, the parties are planning to seek suspension of this enforcement proceeding.

- removed (2018-11-05):
[0001596532-18-000174:note_history:19]
If the 944 Enforcement Action is not stayed and/or terminated and if the USITC determines that our redesigned products infringe any of the patents that are the subject of USITC remedial orders, those redesigned products will also be barred from import into the United States, or sale after importation. In addition, the USITC may impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000 or twice the domestic value of the articles entered or sold, whichever is higher,” bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order,” or impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.” In the 944 Enforcement Action, the ALJ recommended a civil penalty of $307 million if the USITC were to reverse the ALJ’s finding of no violation. Any such finding by the USITC in the 944 Enforcement Action could materially and adversely affect our business, prospects, reputation, results of operations and financial condition.

- removed (2018-11-05):
[0001596532-18-000174:note_history:20]
An adverse finding in the 944 Enforcement Action would take effect immediately upon USITC’s issuance of the final determination, without any Presidential review period. To address such a finding, we would have to further redesign our products to make them non-infringing, and until we made such changes we would not be able to import or ship our products to customers in the United States. Our further redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.  We may not be able to further redesign the products in a manner that does not continue to infringe the patents or that is acceptable to customers. We may not be able to complete, and our customers may not be able to qualify, such further redesigned products in a timely fashion, if at all, following the issuance of an adverse final determination, leading to a delay or cancellation of purchases by some customers until those redesigned products are qualified or accepted by such customers, a rejection or return of our redesigned products by some customers or a loss of sales to some customers who are unable to qualify or accept the redesigned products. Our redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.


## us-gaap:LegalMattersAndContingenciesTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2018-11-05):
[0001596532-18-000233:note_history:21]
11.    Legal Settlement

- added (2018-11-05):
[0001596532-18-000233:note_history:22]
On August 6, 2018, we entered into a binding term sheet with Cisco (“Term Sheet”). Under the Term Sheet, we paid Cisco $400.0 million on August 20, 2018, and the parties obtained dismissals of all ongoing district court and USITC litigation between them. Cisco granted us a release for all past claims relating to the patents Cisco asserted against us in the district court and USITC, and we granted Cisco a release from all past antitrust and unfair competition claims. These mutual releases extended to the Company's and Cisco’s customers, contract manufacturers, and partners. The parties further agreed to a five-year stand-down period for any utility patent infringement claims either may have against features currently implemented in the other party’s products and services, with some carve-outs for products stemming from acquired companies. The parties further agreed to a three-year dispute resolution process for allegations by either party against new and/or modified features in the other party’s products. We also agreed to make certain modifications to our Command Line Interface (“CLI”).

- added (2018-11-05):
[0001596532-18-000233:note_history:23]
Upon signing the Term Sheet, we recorded a legal settlement charge of $405.0 million to operating expenses, which included legal fees associated with the settlement in the three months ended June 30, 2018. We have also recorded a corresponding income tax benefit of $0.9 million and $99.9 million for the three and nine months ended September 30, 2018.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-05):
[0001596532-18-000233:note_history:24]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2018, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2017 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant intercompany accounts and transactions have been eliminated.
  (was, 2018-08-08, similarity 0.9811):
[0001596532-18-000174:note_history:24]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2018, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2017 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant intercompany accounts and transactions have been eliminated.

- changed (2018-11-05):
[0001596532-18-000233:note_history:25]
The preparation of the accompanying condensed consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; valuation of goodwill and acquisition-related intangible assets, accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; estimate of useful lives of long-lived assets including intangible assets; valuation of inventory and contract manufacturer/supplier liabilities; recognition and measurement of contingent liabilities; valuation of equity investments in privately-held companies; determination of fair value for stock-based awards; and valuation of warranty accruals. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.
  (was, 2018-08-08, similarity 0.8338):
[0001596532-18-000174:note_history:25]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; valuation of inventory and contract manufacturer/supplier liabilities; recognition and measurement of contingent liabilities; valuation of equity investments in privately-held companies; determination of fair value for stock-based awards; and valuation of warranty accruals. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

- changed (2018-11-05):
[0001596532-18-000233:note_history:26]
During the nine months ended September 30, 2018, we completed two business acquisitions (see Note 2) and adopted several recent accounting pronouncements as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. As a result, we updated certain significant accounting policies as described below. There have been no other significant changes to our accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.
  (was, 2018-08-08, similarity 0.9234):
[0001596532-18-000174:note_history:26]
During the six months ended June 30, 2018, we adopted several recent accounting pronouncements as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. As a result, we updated certain significant accounting policies as described below. There have been no other significant changes to our accounting policies described in our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

- changed (2018-11-05):
[0001596532-18-000233:note_history:27]
Our equity investments in privately-held companies without readily determinable fair values are measured using the measurement alternative, defined by Accounting Standards Codification (“ASC”) 321-Investments-Equity Securities as cost, less impairments, and adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded as “Other income (expense), net” in our condensed consolidated statements of operations. Prior to 2018, such investments were accounted for under the cost method and were recorded at historical cost at the time of investment, with adjustments to the balance only in the event of an impairment.
  (was, 2018-08-08, similarity 0.9974):
[0001596532-18-000174:note_history:27]
Our equity investments in privately-held companies without readily determinable fair values are measured using the measurement alternative, defined by Accounting Standards Codification (“ASC”) 321-Investments-Equity Securities as cost, less impairments, and adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded as "Other income (expense), net" in our condensed consolidated statements of operations. Prior to 2018, such investments were accounted for under the cost method and were recorded at historical cost at the time of investment, with adjustments to the balance only in the event of an impairment.

- changed (2018-11-05):
[0001596532-18-000233:note_history:28]
Our equity investments in privately-held companies are included in “Investments” in our condensed consolidated balance sheets.
  (was, 2018-08-08, similarity 0.9841):
[0001596532-18-000174:note_history:28]
Our equity investments in privately-held companies are included in "Investments" in our condensed consolidated balance sheets.

- added (2018-11-05):
[0001596532-18-000233:note_history:29]
Effective January 1, 2018, we adopted a new revenue recognition policy in accordance with ASC 606 - Revenue from Contracts with Customers (“ASC 606”) using the modified retrospective method as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1.  Prior to 2018, our revenue recognition policy was based on ASC 605 - Revenue Recognition (“ASC 605”), and is described in Note 1 of Notes to Consolidated Financial Statements under Item 8 of our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

- changed (2018-11-05):
[0001596532-18-000233:note_history:30]
A contract asset is recognized when we have performed under the contract, but our right to consideration is conditional on something other than the passage of time. Contract assets are included in “Other current assets” on our condensed consolidated balance sheets.
  (was, 2018-08-08, similarity 0.917):
[0001596532-18-000174:note_history:30]
A contract asset is recognized when we have performed under the contract, but our right to consideration is conditional on something other than the passage of time. Contract assets are included in "Other current assets" on our condensed consolidated balance sheets.

- changed (2018-11-05):
[0001596532-18-000233:note_history:31]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a contract that is cancellable. Contract liabilities are included in “Other current liabilities” and “Other long-term liabilities” on our condensed consolidated balance sheets.
  (was, 2018-08-08, similarity 0.8924):
[0001596532-18-000174:note_history:31]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a contract that is cancellable. Contract liabilities are included in "Other current liabilities" and "Other long-term liabilities" on our condensed consolidated balance sheets.

- added (2018-11-05):
[0001596532-18-000233:note_history:32]
Business Combinations

- added (2018-11-05):
[0001596532-18-000233:note_history:33]
We use the acquisition method to account for our business combinations in accordance with ASC 805 - Business Combinations (“ASC 805”). We allocate the total purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the consideration transferred over the fair values of the assets acquired and liabilities assumed is recorded as goodwill. The results of operations of the acquired businesses are included in our consolidated financial statements from the date of acquisition. Acquisition-related costs and restructuring costs are expensed as incurred.

- added (2018-11-05):
[0001596532-18-000233:note_history:34]
Goodwill

- added (2018-11-05):
[0001596532-18-000233:note_history:35]
We perform our annual goodwill impairment analysis in the fourth quarter of each year or more frequently if there are any events or circumstances that would indicate the carrying amount is not recoverable. We first perform a qualitative assessment to determine if it’s necessary to perform a quantitative assessment.  If after our qualitative assessment, we determine it is more likely than not that the fair value of the Company is less than its carrying amount, then a quantitative test is performed by comparing the fair value of the Company with its carrying amount in accordance with Accounting Standard Update (“ASU”) No. 2017-04, Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. We would recognize an impairment loss for the amount by which the carrying amount exceeds the fair value.

- added (2018-11-05):
[0001596532-18-000233:note_history:36]
Intangible Assets

- added (2018-11-05):
[0001596532-18-000233:note_history:37]
Intangible assets are carried at cost less accumulated amortization. All intangible assets have been determined to have definite lives and are amortized on a straight-line basis over their estimated remaining useful lives, ranging from one to seven years. Intangible assets are tested for impairment annually in the fourth quarter of each year or whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable.

- changed (2018-11-05):
[0001596532-18-000233:note_history:38]
We adopted the new standard in our first quarter of 2018 using the modified retrospective method, which resulted in a cumulative effect adjustment of $3.5 million that increased retained earnings to capitalize certain commission costs that were expensed in the prior year. Correspondingly, we increased prepaid expenses and other current assets by $2.0 million, other assets by $2.2 million, and decreased deferred tax assets by $0.7 million as of January 1, 2018. In addition, we reclassified $16.5 million of deferred revenue as of January 1, 2018 to other current liabilities and other long-term liabilities related to our prepaid subscription offerings. The impact of adopting the new standard was not material to our financial results for the three and nine months ended September 30, 2018 and we do not expect the impact to be material to the financial results for our fiscal 2018.
  (was, 2018-08-08, similarity 0.865):
[0001596532-18-000174:note_history:38]
We adopted the new standard in our first quarter of 2018 using the modified retrospective method, which resulted in a cumulative effect adjustment of $3.5 million that increased retained earnings to capitalize certain commission costs that were expensed in the prior year. Correspondingly, we increased prepaid expenses and other current assets by $2.0 million, other assets by $2.2 million, and decreased deferred tax assets by $0.7 million as of January 1, 2018. In addition, we reclassified $16.5 million of deferred revenue as of January 1, 2018 to other current liabilities and other long-term liabilities related to our prepaid subscription offerings. The impact of adopting the new standard was not material to our financial results for the three and six months ended June 30, 2018 and we do not expect the impact to be material to the financial results for our fiscal 2018.

- changed (2018-11-05):
[0001596532-18-000233:note_history:39]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which addresses recognition of current and deferred income taxes for intra-entity asset transfers when assets are sold to an outside party. Current GAAP prohibits the recognition of current and deferred income taxes until the asset has been sold to an outside party. This prohibition on recognition is considered an exception to the principle of comprehensive recognition of current and deferred income taxes in GAAP. The new guidance requires an entity to recognize the income tax consequences when the transfer occurs eliminating the exception. The guidance must be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. We adopted this guidance in our first quarter of fiscal 2018. As a result, we recognized a cumulative effect adjustment in the condensed consolidated balance sheet as of September 30, 2018 by increasing the retained earnings and the deferred tax assets as of January 1, 2018 by approximately $0.1 million, respectively.
  (was, 2018-08-08, similarity 0.9943):
[0001596532-18-000174:note_history:39]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which addresses recognition of current and deferred income taxes for intra-entity asset transfers when assets are sold to an outside party. Current GAAP prohibits the recognition of current and deferred income taxes until the asset has been sold to an outside party. This prohibition on recognition is considered an exception to the principle of comprehensive recognition of current and deferred income taxes in GAAP. The new guidance requires an entity to recognize the income tax consequences when the transfer occurs eliminating the exception. The guidance must be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. We adopted this guidance in our first quarter of fiscal 2018. As a result, we recognized a cumulative effect adjustment in the condensed consolidated balance sheet as of June 30, 2018 by increasing the retained earnings and the deferred tax assets as of January 1, 2018 by approximately $0.1 million, respectively.

- changed (2018-11-05):
[0001596532-18-000233:note_history:40]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force (“ASU 2016-18”), which requires that amounts generally described as restricted cash or restricted cash equivalents be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows.  This standard is required to be applied using a retrospective transition method to each period presented.  We retrospectively adopted ASU 2016-18 in our first quarter of fiscal 2018. As a result of the adoption, we adjusted the condensed consolidated statement of cash flows for the nine months ended September 30, 2017 to increase the beginning-of-period and end-of-period cash amounts by $4.2 million and $5.5 million, respectively, and to decrease net cash used in investing activities by $1.3 million.
  (was, 2018-08-08, similarity 0.966):
[0001596532-18-000174:note_history:40]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force, which requires that amounts generally described as restricted cash or restricted cash equivalents be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows.  This standard is required to be applied using a retrospective transition method to each period presented.  We retrospectively adopted ASU 2016-18 in our first quarter of fiscal 2018. As a result of the adoption, we adjusted the condensed consolidated statement of cash flows for the six months ended June 30, 2017 to increase the beginning-of-period and end-of-period cash amounts by $4.2 million and $5.5 million, respectively, and to decrease net cash used in investing activities by $1.3 million.

- added (2018-11-05):
[0001596532-18-000233:note_history:41]
In June 2018, the FASB issued ASU 2018-07, Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting (“ASU 2018-07”), to simplify the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees with certain exceptions. Under the guidance, the measurement of equity-classified nonemployee awards will be fixed at the grant date, which may lower their cost and reduce volatility in the income statement. The guidance is effective for us for our first quarter of 2019. Early adoption is permitted. ASU 2018-07 shall be applied on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of the beginning of the fiscal year in which the guidance is adopted. We are currently assessing the impact this guidance may have on our consolidated financial statements.

- added (2018-11-05):
[0001596532-18-000233:note_history:42]
In February 2016, the FASB issued ASU No. 2016-02, Leases (“ASU 2016-02”). In July 2018, the FASB issued ASU No. 2018-11, Leases (Topic 842): Targeted Improvements (“ASU 2018-11”). Under the guidance, lessees are required to recognize assets and lease liabilities on the balance sheet for most leases including operating leases and provide enhanced disclosures. There are optional practical expedients that a company may elect to apply. The guidance is effective for our first quarter of 2019 and may be early adopted. Companies can adopt this guidance using a modified retrospective approach or, pursuant to ASU 2018-11, using an additional optional transition method. Under the optional transition method, a company initially applies the new leases standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption. We plan to adopt the guidance in the first quarter of 2019 using the additional optional transition method. Management’s evaluation of the new standard is underway, and we have identified the significant changes between the current guidance and the new guidance and expect to elect certain available transitional practical expedients.  In addition, we have developed a project plan, performed a risk assessment, and have summarized the terms of our major lease agreements. We are in the process of reviewing our existing lease agreements to assess the impact this guidance may have on our consolidated financial statements. We currently anticipate that the adoption of ASU 2016-02 will materially affect our consolidated balance sheets by recognizing new right-of-use assets and lease liabilities for operating leases, but will not have a material impact on our consolidated statements of operations.

- removed (2018-11-05):
[0001596532-18-000174:note_history:43]
Effective January 1, 2018, we adopted a new revenue recognition policy in accordance with ASC 606 using the modified retrospective method as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1.  Prior to 2018, our revenue recognition policy was based on ASC 605 Revenue Recognition, and is described in Note 1 of Notes to Consolidated Financial Statements under Item 8 of our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

- removed (2018-11-05):
[0001596532-18-000174:note_history:44]
In June 2018, the FASB issued ASU 2018-07, Compensation—Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting, to simplify the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees with certain exceptions. Under the guidance, the measurement of equity-classified nonemployee awards will be fixed at the grant date, which may lower their cost and reduce volatility in the income statement. The guidance is effective for us for our first quarter of 2019. Early adoption is permitted. ASU 2018-07 shall be applied on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of the beginning of the fiscal year in which the guidance is adopted. We are currently assessing the impact this guidance may have on our consolidated financial statements.

- removed (2018-11-05):
[0001596532-18-000174:note_history:45]
In February 2016, the FASB issued ASU No. 2016-02, Leases. Under the guidance, lessees are required to recognize assets and lease liabilities on the balance sheet for most leases including operating leases and provide enhanced disclosures. There are optional practical expedients that a company may elect to apply. The guidance is effective for our first quarter of 2019 and may be early adopted.  As currently issued, companies are required to adopt this guidance to the earliest period presented using a modified retrospective approach. Management’s evaluation of the new standard is underway, and we have identified the significant changes between the current guidance and the new guidance and expect to elect certain available transitional practical expedients.  In addition, we have developed a project plan, performed a risk assessment, and have summarized the terms of our major lease agreements. We are in the process of reviewing our existing lease agreements to assess the impact this guidance may have on our consolidated financial statements. We currently anticipate that the adoption of ASU 2016-02 will materially affect our consolidated balance sheets by recognizing new right-of-use assets and lease liabilities for operating leases, but will not have a material impact on our consolidated statements of operations.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-11-05):
[0001596532-18-000233:note_history:46]
Effective January 1, 2018, we adopted a new revenue recognition policy in accordance with ASC 606 - Revenue from Contracts with Customers (“ASC 606”) using the modified retrospective method as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1.  Prior to 2018, our revenue recognition policy was based on ASC 605 - Revenue Recognition (“ASC 605”), and is described in Note 1 of Notes to Consolidated Financial Statements under Item 8 of our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

- added (2018-11-05):
[0001596532-18-000233:note_history:47]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with post-contract customer support (“PCS”). We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

- added (2018-11-05):
[0001596532-18-000233:note_history:48]
| • | Identification of the contract, or contracts, with a customer |

- added (2018-11-05):
[0001596532-18-000233:note_history:49]
| • | Identification of the performance obligations in the contract |

- added (2018-11-05):
[0001596532-18-000233:note_history:50]
| • | Determination of the transaction price |

- added (2018-11-05):
[0001596532-18-000233:note_history:51]
| • | Allocation of the transaction price to the performance obligations in the contract |

- added (2018-11-05):
[0001596532-18-000233:note_history:52]
| • | Recognition of revenue when (or as) we satisfy the performance obligation |

- added (2018-11-05):
[0001596532-18-000233:note_history:53]
Post-Contract Customer Support

- added (2018-11-05):
[0001596532-18-000233:note_history:54]
Post-contract support, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernable pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and addresses customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

- added (2018-11-05):
[0001596532-18-000233:note_history:55]
Contracts with Multiple Performance Obligations

- added (2018-11-05):
[0001596532-18-000233:note_history:56]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts which contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

- added (2018-11-05):
[0001596532-18-000233:note_history:57]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

- added (2018-11-05):
[0001596532-18-000233:note_history:58]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

- added (2018-11-05):
[0001596532-18-000233:note_history:59]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

- added (2018-11-05):
[0001596532-18-000233:note_history:60]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

- added (2018-11-05):
[0001596532-18-000233:note_history:61]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

- added (2018-11-05):
[0001596532-18-000233:note_history:62]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

- added (2018-11-05):
[0001596532-18-000233:note_history:63]
Contract Balances

- added (2018-11-05):
[0001596532-18-000233:note_history:64]
A contract asset is recognized when we have performed under the contract, but our right to consideration is conditional on something other than the passage of time. Contract assets are included in “Other current assets” on our condensed consolidated balance sheets.

- added (2018-11-05):
[0001596532-18-000233:note_history:65]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a contract that is cancellable. Contract liabilities are included in “Other current liabilities” and “Other long-term liabilities” on our condensed consolidated balance sheets.

- added (2018-11-05):
[0001596532-18-000233:note_history:66]
Assets Recognized from Costs to Obtain a Contract with a Customer

- added (2018-11-05):
[0001596532-18-000233:note_history:67]
Effective January 1, 2018 in connection with the adoption of ASC 606, we recognize an asset for the incremental costs of obtaining a contract with a customer if we expect the benefit of those costs to be longer than one year. We have determined that certain sales commissions earned by our sales force meet the requirements for capitalization. These costs are deferred and then amortized over a period of benefit that we have determined to be five years. Total capitalized costs to obtain a contract are included in other current and long-term assets on our condensed consolidated balance sheets.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2018-11-05):
[0001596532-18-000174:note_history:68]
Effective January 1, 2018, we adopted a new revenue recognition policy in accordance with ASC 606 using the modified retrospective method as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1.  Prior to 2018, our revenue recognition policy was based on ASC 605 Revenue Recognition, and is described in Note 1 of Notes to Consolidated Financial Statements under Item 8 of our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

- removed (2018-11-05):
[0001596532-18-000174:note_history:69]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with post-contract customer support (“PCS”). We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

- removed (2018-11-05):
[0001596532-18-000174:note_history:70]
| • | Identification of the contract, or contracts, with a customer |

- removed (2018-11-05):
[0001596532-18-000174:note_history:71]
| • | Identification of the performance obligations in the contract |

- removed (2018-11-05):
[0001596532-18-000174:note_history:72]
| • | Determination of the transaction price |

- removed (2018-11-05):
[0001596532-18-000174:note_history:73]
| • | Allocation of the transaction price to the performance obligations in the contract |

- removed (2018-11-05):
[0001596532-18-000174:note_history:74]
| • | Recognition of revenue when (or as) we satisfy the performance obligation |

- removed (2018-11-05):
[0001596532-18-000174:note_history:75]
Post-Contract Customer Support

- removed (2018-11-05):
[0001596532-18-000174:note_history:76]
Post-contract support, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernable pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and addresses customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

- removed (2018-11-05):
[0001596532-18-000174:note_history:77]
Contracts with Multiple Performance Obligations

- removed (2018-11-05):
[0001596532-18-000174:note_history:78]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts which contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

- removed (2018-11-05):
[0001596532-18-000174:note_history:79]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

- removed (2018-11-05):
[0001596532-18-000174:note_history:80]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

- removed (2018-11-05):
[0001596532-18-000174:note_history:81]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

- removed (2018-11-05):
[0001596532-18-000174:note_history:82]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

- removed (2018-11-05):
[0001596532-18-000174:note_history:83]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

- removed (2018-11-05):
[0001596532-18-000174:note_history:84]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

- removed (2018-11-05):
[0001596532-18-000174:note_history:85]
Contract Balances

- removed (2018-11-05):
[0001596532-18-000174:note_history:86]
A contract asset is recognized when we have performed under the contract, but our right to consideration is conditional on something other than the passage of time. Contract assets are included in "Other current assets" on our condensed consolidated balance sheets.

- removed (2018-11-05):
[0001596532-18-000174:note_history:87]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a contract that is cancellable. Contract liabilities are included in "Other current liabilities" and "Other long-term liabilities" on our condensed consolidated balance sheets.

- removed (2018-11-05):
[0001596532-18-000174:note_history:88]
Assets Recognized from Costs to Obtain a Contract with a Customer

- removed (2018-11-05):
[0001596532-18-000174:note_history:89]
Effective January 1, 2018 in connection with the adoption of ASC 606, we recognize an asset for the incremental costs of obtaining a contract with a customer if we expect the benefit of those costs to be longer than one year. We have determined that certain sales commissions earned by our sales force meet the requirements for capitalization. These costs are deferred and then amortized over a period of benefit that we have determined to be five years. Total capitalized costs to obtain a contract are included in other current and long-term assets on our condensed consolidated balance sheets.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2018-11-05):
[0001596532-18-000174:note_history:90]
10.    Subsequent Events

- removed (2018-11-05):
[0001596532-18-000174:note_history:91]
Acquisition of Mojo Networks, Inc.

- removed (2018-11-05):
[0001596532-18-000174:note_history:92]
On August 2, 2018, we completed the acquisition of Mojo Networks, Inc., a provider of Cognitive WiFi and cloud-managed wireless networking solutions. The transaction will be included in our condensed consolidated financial statements in the quarter ended September 30, 2018 and will be financed from our existing cash balance.

- removed (2018-11-05):
[0001596532-18-000174:note_history:93]
Settlement of Cisco Lawsuits

- removed (2018-11-05):
[0001596532-18-000174:note_history:94]
On August 6, 2018, we entered into a binding term sheet with Cisco which, upon execution of a final agreement, will result in the dismissal of all pending district court and USITC litigation between the parties. Under the binding term sheet, we will pay Cisco $400.0 million by August 20, 2018. Cisco will grant us a release for all claims of infringement with respect to the patent infringement allegations against us in the pending litigation, and we will grant Cisco a release from all past antitrust claims. These mutual releases will extend to the Company's and Cisco’s customers, contract manufacturers, and partners. The parties have further agreed to a five-year stand-down period as to any utility patent infringement claims either may have against features currently implemented in the other party’s products and services, with some carve-outs for products stemming from acquired companies. The parties further agreed to a three-year dispute resolution process for allegations by either party against new and/or modified features in the other party’s products. We also agreed to make certain modifications to our Command Line Interface (“CLI”).

- removed (2018-11-05):
[0001596532-18-000174:note_history:95]
As a result of the agreement described above, we recorded a legal settlement charge of $405.0 million to operating expenses, which included legal fees associated with the settlement, and a corresponding income tax benefit of $99.0 million in the three and six months ended June 30, 2018.  Correspondingly, we recorded $405.0 million in accrued legal settlement charges, $85.0 million in prepaid expenses and other current assets relating to prepaid income taxes, and $14.0 million in deferred tax assets in our condensed consolidated balance sheet as of June 30, 2018.
