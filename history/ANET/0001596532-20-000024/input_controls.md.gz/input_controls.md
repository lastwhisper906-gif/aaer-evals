# ANET 10-K controls and the auditor's report


## auditors_report

[0001596532-20-000024:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001596532-20-000024:auditors_report:2]
To the Stockholders and Board of Directors of Arista Networks, Inc.

[0001596532-20-000024:auditors_report:3]
Opinion on the Financial Statements

[0001596532-20-000024:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Arista Networks, Inc. (the Company) as of December 31, 2019 and 2018, the related consolidated statements of operations, comprehensive income, stockholders’ equity and cash flows for each of the three years in the period ended December 31, 2019, and the related notes (collectively referred to as the “consolidated financial statements”). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company at December 31, 2019 and 2018, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2019, in conformity with U.S. generally accepted accounting principles.

[0001596532-20-000024:auditors_report:5]
We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the Company's internal control over financial reporting as of December 31, 2019, based on criteria established in Internal Control - Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework) and our report dated February 13, 2020 expressed an unqualified opinion thereon.

[0001596532-20-000024:auditors_report:6]
Basis for Opinion

[0001596532-20-000024:auditors_report:7]
These financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s financial statements based on our audits. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001596532-20-000024:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the financial statements are free of material misstatement, whether due to error or fraud. Our audits included performing procedures to assess the risks of material misstatement of the financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001596532-20-000024:auditors_report:9]
Critical Audit Matters

[0001596532-20-000024:auditors_report:10]
The critical audit matters communicated below are matters arising from the current period audit of the financial statements that were communicated or required to be communicated to the audit committee and that: (1) relate to accounts or disclosures that are material to the financial statements and (2) involved our especially challenging, subjective or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001596532-20-000024:auditors_report:11]
|  | Inventory Valuation & Contract Manufacturer/Supplier Liabilities |

[0001596532-20-000024:auditors_report:12]
| Description of the Matter | As discussed in Note 1 of the consolidated financial statements, the Company’s inventories are stated at the lower of cost (computed using the first-in, first-out method) and net realizable value. The Company’s inventory balance totaled $244 million on December 31, 2019. The Company records a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value. The Company records a contract manufacturer/supplier liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with contract manufacturers or suppliers for quantities in excess of the Company’s demand forecasts, or that are considered obsolete. Auditing management’s assessment of net realizable value for inventory and contract manufacturer/supplier liabilities was complex and highly judgmental due to the assessment of management’s estimates of forecasted product demand, which can be impacted by changes in overall customer demand, changes in the timing of the introduction and customer adoption of new products, adjustments to manufacturing and engineering schedules, and overall general economic and market conditions. |
| How We Addressed the Matter in Our Audit | We obtained an understanding, evaluated the design and tested the operating effectiveness of controls over the Company’s determination of the net realizable value of inventory and the contract manufacturer/supplier liability. This included controls over the preparation of the demand and production forecasts, and the evaluation of the accuracy and completeness of the inventory provision and contract manufacturer/supplier liability.To test the inventory provision and contract manufacturer/supplier liability, we performed audit procedures that included, among others, assessing the Company’s methodology over the computation of the provision and liability, testing the significant assumptions and the underlying inputs used by the Company in its analysis including historical sales trends, expectations regarding future sales, changes in the Company’s business, customer base, product roadmap and other relevant factors. |
|  | Income Taxes - Intra-entity transfer of intellectual property |
| Description of the Matter | As discussed in Note 10 to the consolidated financial statements, on December 31, 2019, the Company completed an intra-entity transaction to sell its non-Americas economic and beneficial intellectual property ("IP") rights in exchange for a non-interest-bearing note of $3.4 billion. As a result of the transaction, tax basis in the IP transferred equal to the fair market value of the qualifying IP resulted in the recognition of a deferred tax asset of $429.1 million, which was largely offset by a deferred tax liability of $343.3 million associated with future US tax on foreign earnings for the difference in the local tax basis and US GAAP book basis of the IP rights.Auditing the tax basis resulting from the intra-entity transfer of intellectual property was complex and highly judgmental due to the significant estimation required to determine the fair value of the intellectual property transferred. In particular, the fair value estimate was sensitive to significant assumptions, such as changes in the revenue growth rate, gross margin, profit before tax margin, tax rate discount for non-exclusivity, terminal value and weighted average cost of capital, which are affected by expectations about future market or economic conditions, particularly those in emerging markets. |

[0001596532-20-000024:auditors_report:13]
71

[0001596532-20-000024:auditors_report:14]
| How We Addressed the Matter in Our Audit | We obtained an understanding, evaluated the design and tested the operating effectiveness of controls over the accounting for the intra-entity transfer of intellectual property, including controls over management’s review of underlying agreements, estimation of fair value and evaluation of the related tax laws applicable to the transfer of intellectual property.To test the estimated fair value of intellectual property transferred, we performed audit procedures that included, among others, assessing methodologies and testing the significant assumptions discussed above and the underlying data used by the Company in its analysis. We involved our valuation specialists in assessing the valuation methodology applied and evaluating certain significant assumptions. When evaluating the significant assumptions used to determine the fair value of intellectual property, we compared the assumptions to the past performance, selected guideline companies, third party analyst expectations for the industry, and current and forecasted market trends. We also assessed the historical accuracy of management’s estimates and performed sensitivity analyses of significant assumptions to evaluate the changes in the fair value of intellectual property transferred that would result from changes in the assumptions.We involved our tax professionals, who assisted in evaluating the Company’s interpretation and application of tax laws and regulations, and the Company’s compliance with the intercompany agreements, which were executed as part of the transfer. |

[0001596532-20-000024:auditors_report:15]
/s/ Ernst & Young LLP

[0001596532-20-000024:auditors_report:16]
We have served as the Company's auditor since 2008.

[0001596532-20-000024:auditors_report:17]
San Jose, California

[0001596532-20-000024:auditors_report:18]
February 13, 2020

[0001596532-20-000024:auditors_report:19]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001596532-20-000024:auditors_report:20]
To the Stockholders and Board of Directors of Arista Networks, Inc.

[0001596532-20-000024:auditors_report:21]
Opinion on Internal Control over Financial Reporting

[0001596532-20-000024:auditors_report:22]
We have audited Arista Networks, Inc.’s internal control over financial reporting as of December 31, 2019, based on criteria established in Internal Control - Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework) (the COSO criteria). In our opinion, Arista Networks, Inc. (the Company) maintained, in all material respects, effective internal control over financial reporting as of December 31, 2019, based on the COSO criteria. We also have audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated balance sheets of Arista Networks Inc. as of December 31, 2019 and 2018, the related consolidated statements of operations, comprehensive income, stockholders’ equity and cash flows for each of the three years in the period ended December 31, 2019, and the related notes of the Company and our report dated February 13, 2020 expressed an unqualified opinion thereon.

[0001596532-20-000024:auditors_report:23]
Basis for Opinion

[0001596532-20-000024:auditors_report:24]
The Company's management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting included in the accompanying Management’s Annual Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001596532-20-000024:auditors_report:25]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects.

[0001596532-20-000024:auditors_report:26]
Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001596532-20-000024:auditors_report:27]
Definition and Limitations of Internal Control Over Financial Reporting

[0001596532-20-000024:auditors_report:28]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001596532-20-000024:auditors_report:29]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001596532-20-000024:auditors_report:30]
/s/ Ernst & Young LLP

[0001596532-20-000024:auditors_report:31]
San Jose, California

[0001596532-20-000024:auditors_report:32]
February 13, 2020

[0001596532-20-000024:auditors_report:33]
ARISTA NETWORKS, INC.


## item_9a

[0001596532-20-000024:item_9a:1]
Item 9A. Controls and Procedures

[0001596532-20-000024:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001596532-20-000024:item_9a:3]
Management, with the participation of our Chief Executive Officer (“CEO”) and our Chief Financial Officer (“CFO”), evaluated the effectiveness of our disclosure controls and procedures as of December 31, 2019. The term “disclosure controls and procedures,” as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act, means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported, within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the company’s management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure.

[0001596532-20-000024:item_9a:4]
Based on the evaluation of our disclosure controls and procedures as of December 31, 2019, our CEO and CFO concluded that, as of such date, our disclosure controls and procedures are designed at a reasonable assurance level and are effective to provide reasonable assurance that information we are required to disclose in reports that we file or submit under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in Securities and Exchange Commission (SEC) rules and forms, and that such information is accumulated and communicated to our management, including our chief executive officer and chief financial officer, as appropriate, to allow timely decisions regarding required disclosure.

[0001596532-20-000024:item_9a:5]
Changes in Internal Control over Financial Reporting

[0001596532-20-000024:item_9a:6]
There were no changes in our internal control over financial reporting identified in connection with the evaluation required by Rule 13a-15(d) and 15d-15(d) of the Securities and Exchange Act of 1934, as amended, that occurred during the year ended December 31, 2019 that materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001596532-20-000024:item_9a:7]
In connection with our adoption of ASC 842, the new lease accounting standard, on January 1, 2019, we implemented internal controls to ensure we adequately evaluated our contracts and properly assessed the impact of ASC 842 on our financial statements and disclosures.

[0001596532-20-000024:item_9a:8]
Inherent Limitations of Internal Controls

[0001596532-20-000024:item_9a:9]
Our management, including our CEO and CFO, does not expect that our disclosure controls and procedures or our internal controls over financial reporting will prevent or detect all errors and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system are met. Because of the inherent limitations in all control systems, no evaluation of controls can provide absolute assurance that all control issues and instances of fraud, if any, within the Company have been detected. These inherent limitations include the realities that judgments in decision-making can be faulty, and that breakdowns can occur because of a simple error or mistake. Additionally, controls can be circumvented by the individual acts of some persons, by collusion of two or more people, or by management override of the controls.

[0001596532-20-000024:item_9a:10]
109

[0001596532-20-000024:item_9a:11]
The design of any system of controls also is based in part upon certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. Over time, controls may become inadequate because of changes in conditions, or the degree of compliance with the policies or procedures may deteriorate. Because of the inherent limitations in a cost-effective control system, misstatements due to error or fraud may occur and not be detected.

[0001596532-20-000024:item_9a:12]
Management's Report on Internal Control Over Financial Reporting

[0001596532-20-000024:item_9a:13]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act. Our internal control over financial reporting is a process designed under the supervision of our principal executive and principal financial officers to provide reasonable assurance regarding the reliability of financial reporting and the preparation of our financial statements for external purposes in accordance with U.S. generally accepted accounting principles.

[0001596532-20-000024:item_9a:14]
Our internal control over financial reporting includes those policies and procedures that: (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of our assets; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with U.S. generally accepted accounting principles, and that our receipts and expenditures are being made only in accordance with authorizations of our management and directors; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of our assets that could have a material effect on the Consolidated Financial Statements.

[0001596532-20-000024:item_9a:15]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate. Management assessed the effectiveness of our internal control over financial reporting as of December 31, 2019, based on the framework set forth by the Committee of Sponsoring Organizations of the Treadway Commission (COSO) in Internal Control - Integrated Framework (2013 framework). Based on that assessment, management concluded that, as of December 31, 2019, our internal control over financial reporting was effective.

[0001596532-20-000024:item_9a:16]
The effectiveness of our internal control over financial reporting as of December 31, 2019, has been audited by Ernst & Young LLP, the independent registered public accounting firm that audits our Consolidated Financial Statements, as stated in their report included in Item 8 of this Annual Report on Form 10-K, which expresses an unqualified opinion on the effectiveness of our internal control over financial reporting as of December 31, 2019.
