# ANET notes — 0001596532-20-000024


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001596532-20-000024:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to its 2020 Annual Meeting of Stockholders to be filed pursuant to Regulation 14A within 120 days after the registrant’s fiscal year end of December 31, 2019 are incorporated by reference into Part III of this Annual Report on Form 10-K.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-20-000024:notes:2]
Organization and Summary of Significant Accounting Policies
Organization

[0001596532-20-000024:notes:3]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our EOS, a set of network applications and our 1/2.5/5/10/25/40/50/100/400 Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-20-000024:notes:4]
Basis of Presentation and Principles of Consolidation

[0001596532-20-000024:notes:5]
The accompanying consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and are prepared in accordance with GAAP. All significant intercompany accounts and transactions have been eliminated.

[0001596532-20-000024:notes:6]
Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.

[0001596532-20-000024:notes:7]
Use of Estimates

[0001596532-20-000024:notes:8]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; valuation of goodwill and acquisition-related intangible assets, accounting for income taxes, including the recognition of deferred tax assets and liabilities related to an intra-entity transaction to sell our non-Americas economic and beneficial intellectual property, valuation allowance on deferred tax assets and reserves for uncertain tax positions; estimate of useful lives of long-lived assets including intangible assets; valuation of inventory and contract manufacturer/supplier liabilities; and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

[0001596532-20-000024:notes:9]
Concentrations of Business and Credit Risk

[0001596532-20-000024:notes:10]
We work closely with third-party contract manufacturers to manufacture our products. As of December 31, 2019, we had two contract manufacturing partners, who provided substantially all of our electronic manufacturing services. Our contract manufacturing partners deliver our products to our third party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers. Our products rely on key components, including certain integrated circuit components and power supplies, some of which our contract manufacturing partners purchase on our behalf from a limited number of suppliers, including certain sole source providers. We generally do not have guaranteed supply contracts with our component suppliers, and our manufacturing partners could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, or if we are unable to obtain alternative sources for these components, sales of our products could be delayed or halted entirely, or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.

[0001596532-20-000024:notes:11]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, marketable securities, restricted cash, and accounts receivable. Our cash equivalents, restricted cash and marketable securities are invested in high quality financial instruments with banks and financial institutions. Such deposits may be in excess of insured limits provided on such deposits.

[0001596532-20-000024:notes:12]
Our accounts receivable are unsecured and represent amounts due to us based on contractual obligations

[0001596532-20-000024:notes:13]
of our customers. We mitigate credit risk with respect to accounts receivable by performing ongoing credit evaluations of our customers to assess the probability of collection based on a number of factors, including past transaction experience with the customer, evaluation of their credit history, the credit limits extended, and review of the invoicing terms of the arrangement. In situations where a customer may be thinly capitalized and we have limited payment history with it, we will either establish a small credit limit or require it to prepay its purchases. We generally do not require our customers to provide collateral to support accounts receivable. We have recorded an allowance for doubtful accounts for those receivables that we have determined not to be collectible. We mitigate credit risk in respect to the notes receivable by performing ongoing credit evaluations of the borrower to assess the probability of collecting all amounts due to us under the existing contractual terms.

[0001596532-20-000024:notes:14]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators and original equipment manufacturer (“OEM”) partners, and in conjunction with various technology partners.  Significant customers are those which represent more than 10% of our total net revenue during the period or net accounts receivable balance at each respective balance sheet date. As of December 31, 2019, we had one customer who represented 39% of total accounts receivable. As of December 31, 2018, we had two customers who represented 35% and 10% of total accounts receivable, respectively. For the year ended December 31, 2019, there were two customers who represented 23% and 17% of our total revenue, respectively. For the years ended December 31, 2018 and 2017, there was one customer who represented 27% and 16% of our total revenue, respectively.

[0001596532-20-000024:notes:15]
Cash and Cash Equivalents

[0001596532-20-000024:notes:16]
We consider all highly liquid investments with maturities of three months or less at the time of purchase to be cash equivalents. Cash and cash equivalents consist of cash on deposit with various financial institutions and highly liquid investments in money market funds. Interest is accrued as earned. As of December 31, 2019 and 2018, we had restricted cash of $4.2 million for each year and that primarily included $4.0 million pledged as collateral representing a security deposit required for a facility lease. Our restricted cash is classified as other assets in our consolidated balance sheets.

[0001596532-20-000024:notes:17]
Marketable Securities

[0001596532-20-000024:notes:18]
We classify all highly liquid investments in debt and equity securities with maturities of greater than three months at the date of purchase as marketable securities. We have classified and accounted for our marketable securities as available-for-sale. We determine the appropriate classification of these investments at the time of purchase and reevaluate such designation at each balance sheet date. We may or may not hold securities with stated maturities greater than 12 months until maturity. After consideration of our risk versus reward objectives, as well as our liquidity requirements, we may sell these securities prior to their stated maturities. As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets. We carry these securities at fair value, and report the unrealized gains and losses, net of taxes, as a component of stockholders’ equity, except for unrealized losses determined to be other-than-temporary, which we record as other income (expense), net. We determine any realized gains or losses on the sale of marketable securities on a specific identification method, and we record such gains and losses as a component of interest and other income, net.

[0001596532-20-000024:notes:19]
Accounts Receivable

[0001596532-20-000024:notes:20]
Accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts, and sales rebates and returns reserves. We estimate our allowance for doubtful accounts based upon the collectability of the receivables in light of historical trends, adverse situations that may affect our customers’ ability to pay and prevailing economic conditions. This evaluation is done in order to identify issues which may impact the collectability of receivables and related estimated required allowance. Revisions to the allowance are recorded as an adjustment to bad debt expense. After appropriate collection efforts are exhausted, specific accounts receivable deemed to be uncollectible are charged against the allowance in the period they are deemed uncollectible. Recoveries of accounts receivable previously written-off are recorded as credits to bad debt expense. We primarily estimate our sales rebates and returns reserves based on historical rates applied against current period billings. Specific customer returns, rebates and allowances are considered when determining our estimates. Revisions to the reserves are recorded as adjustments to revenue.

[0001596532-20-000024:notes:21]
Fair Value Measurements

[0001596532-20-000024:notes:22]
Fair value is defined as the exchange price that would be received for an asset or an exit price that would be paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. These assets and liabilities include cash and cash equivalents, marketable securities, accounts receivable, accounts payable, and accrued liabilities. Cash equivalents, accounts receivable, accounts payable and accrued liabilities are stated at carrying amounts as reported in the consolidated financial statements, which approximate fair value due to their short-term nature.

[0001596532-20-000024:notes:23]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value.  We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs.  The three-tiers of the fair value hierarchy are as follows:

[0001596532-20-000024:notes:24]
Level I—Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date;

[0001596532-20-000024:notes:25]
Level II—Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities; and

[0001596532-20-000024:notes:26]
Level III—Unobservable inputs that are supported by little or no market data for the related assets or liabilities and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.

[0001596532-20-000024:notes:27]
Foreign Currency

[0001596532-20-000024:notes:28]
The functional currency of our foreign subsidiaries is either the U.S. dollar or their local currency.

[0001596532-20-000024:notes:29]
Transaction re-measurement - Assets and liabilities denominated in a currency other than a subsidiary’s functional currency are re-measured into the subsidiary's functional currency using exchange rates in effect at the end of the reporting period, with gains and losses recorded in other income (expense), net in the consolidated statements of operations. To date, foreign currency transaction gains and losses and exchange rate fluctuations have not been material to our financial statements.

[0001596532-20-000024:notes:30]
Translation - Assets and liabilities of subsidiaries denominated in foreign functional currencies are translated into U.S. dollars at the closing exchange rate on the balance sheet date and equity related balances are translated at historical exchange rates.  Revenues, costs and expenses in foreign functional currencies are translated using average exchange rates that approximate those in effect during the period. Translation adjustments are accumulated as a separate component of accumulated other comprehensive income within stockholders’ equity.

[0001596532-20-000024:notes:31]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-20-000024:notes:32]
Inventories primarily consist of finished goods and strategic components, primarily integrated circuits. Inventories are stated at the lower of cost (computed using the first-in, first-out method) and net realizable value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value. For the years ended December 31, 2019, 2018 and 2017, we recorded charges of $41.2 million, $20.8 million and $28.1 million, respectively, within cost of product revenue for inventory write-downs.

[0001596532-20-000024:notes:33]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts. We record a liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with our contract manufacturers or suppliers for quantities in excess of our demand forecasts or that are considered obsolete due to manufacturing and engineering change orders resulting from design changes. For the year ended December 31, 2019 and 2017, we recorded a charge of $11.7 million and $21.2 million,

[0001596532-20-000024:notes:34]
respectively, within cost of product revenue for such liabilities with our contract manufacturers and suppliers. For the year ended December 31, 2018, we did not incur a net loss on such supplier liabilities.

[0001596532-20-000024:notes:35]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer liabilities.

[0001596532-20-000024:notes:36]
Property and Equipment

[0001596532-20-000024:notes:37]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is calculated using the straight-line method over the estimated useful lives of the related assets, generally three years. Our leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term.

[0001596532-20-000024:notes:38]
Investments in Privately-Held Companies

[0001596532-20-000024:notes:39]
Our equity investments in privately-held companies without readily determinable fair values are measured using the measurement alternative, defined by ASC 321-Investments-Equity Securities as cost, less impairments, and adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded as “Other income (expense), net” in our consolidated statements of operations.

[0001596532-20-000024:notes:40]
Impairment of Long-Lived Assets and Investments

[0001596532-20-000024:notes:41]
The carrying amounts of our long-lived assets, including property and equipment and investments in privately held companies, are periodically reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. Recoverability of these assets is measured by comparison of the carrying amount of each asset to the future undiscounted cash flows the asset is expected to generate over their remaining lives. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. We recognized impairment losses on certain private company investments during 2018.  Refer to Note 5 for further discussion.  No impairment of any other long-lived assets was identified for any of the periods presented.

[0001596532-20-000024:notes:42]
Loss Contingencies

[0001596532-20-000024:notes:43]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgment and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We will record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.

[0001596532-20-000024:notes:44]
Revenue Recognition

[0001596532-20-000024:notes:45]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with post-contract customer support (“PCS”). We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control

[0001596532-20-000024:notes:46]
of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

[0001596532-20-000024:notes:47]
| • | Identification of the contract, or contracts, with a customer |

[0001596532-20-000024:notes:48]
| • | Identification of the performance obligations in the contract |

[0001596532-20-000024:notes:49]
| • | Determination of the transaction price |

[0001596532-20-000024:notes:50]
| • | Allocation of the transaction price to the performance obligations in the contract |

[0001596532-20-000024:notes:51]
| • | Recognition of revenue when (or as) we satisfy the performance obligation |

[0001596532-20-000024:notes:52]
Post-Contract Customer Support

[0001596532-20-000024:notes:53]
Post-contract support, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernable pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and addresses customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-20-000024:notes:54]
Contracts with Multiple Performance Obligations

[0001596532-20-000024:notes:55]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts which contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

[0001596532-20-000024:notes:56]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

[0001596532-20-000024:notes:57]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

[0001596532-20-000024:notes:58]
Most of our contracts with customers have payment terms of 30 days with some large high volume customers having terms of up to 60 days. We have determined our contracts generally do not include a significant financing component because the Company and the customer have specific business reasons other than financing for entering into such contracts. Specifically, both we and our customers seek to ensure the customer has a simplified way of purchasing Arista products and services.

[0001596532-20-000024:notes:59]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

[0001596532-20-000024:notes:60]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical returns

[0001596532-20-000024:notes:61]
rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-20-000024:notes:62]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

[0001596532-20-000024:notes:63]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

[0001596532-20-000024:notes:64]
Contract Balances

[0001596532-20-000024:notes:65]
A contract asset is recognized when we have a contractual right to consideration for both completed and partially completed performance obligations that have not yet been invoiced.  Contract assets are included in “Other current assets” on our consolidated balance sheets.

[0001596532-20-000024:notes:66]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a contract that is cancellable. Contract liabilities are included in “Other current liabilities” and “Other long-term liabilities” on our consolidated balance sheets.

[0001596532-20-000024:notes:67]
Assets Recognized from Costs to Obtain a Contract with a Customer

[0001596532-20-000024:notes:68]
Effective January 1, 2018 in connection with the adoption of ASC 606, we recognize an asset for the incremental costs of obtaining a contract with a customer if we expect the benefit of those costs to be longer than one year. We have determined that certain sales commissions earned by our sales force meet the requirements for capitalization. These costs are deferred and then amortized over a period of benefit that we have determined to be five years. Total capitalized costs to obtain a contract are included in other current and long-term assets on our consolidated balance sheets. As of December 31, 2019 and 2018, total capitalized costs to obtain contracts was $8.9 million and $6.4 million, respectively.

[0001596532-20-000024:notes:69]
Research and Development Expenses

[0001596532-20-000024:notes:70]
Costs related to the research, design and development of our products are charged to research and development expenses as incurred. Software development costs are capitalized beginning when a product’s technological feasibility has been established and ending when the product is available for general release to customers. Generally, our products are released soon after technological feasibility has been established. As a result, costs incurred subsequent to achieving technological feasibility have not been significant and accordingly, all software development costs have been expensed as incurred.

[0001596532-20-000024:notes:71]
Warranty

[0001596532-20-000024:notes:72]
We offer a one-year warranty on all of our hardware products and a 90-day warranty against defects in the software embedded in the products. We use judgment and estimates when determining warranty costs based on historical costs to replace product returns within the warranty period at the time we recognize revenue. We accrue for potential warranty claims at the time of shipment as a component of cost of revenues based on historical experience and other relevant information. We reserve for specifically identified products if and when we determine we have a systemic product failure. Although we engage in extensive product quality programs, if actual product failure rates or use of materials differ from estimates, additional warranty costs may be incurred, which could reduce our gross margin. The accrued warranty liability is recorded in accrued liabilities in the accompanying consolidated balance sheets.

[0001596532-20-000024:notes:73]
Segment Reporting

[0001596532-20-000024:notes:74]
We develop, market and sell cloud networking solutions, which consist of our Gigabit Ethernet switches and related software. We engage in one business activity and there are no segment managers who are held accountable for operations or operating results below the Company level. Our chief operating decision maker is

[0001596532-20-000024:notes:75]
our Chief Executive Officer, who reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.  Accordingly, we have determined that we operate as one reportable segment.

[0001596532-20-000024:notes:76]
Stock-Based Compensation

[0001596532-20-000024:notes:77]
Compensation expense related to stock-based transactions is measured and recognized in the financial statements based on the fair value of the equity granted on a straight-line basis over the requisite service periods of the awards, which typically ranges from two to five years. We account for forfeitures on all stock-based transactions as they occur.

[0001596532-20-000024:notes:78]
Income Taxes

[0001596532-20-000024:notes:79]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-20-000024:notes:80]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-20-000024:notes:81]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-20-000024:notes:82]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.

[0001596532-20-000024:notes:83]
Net Income per Share of Common Stock

[0001596532-20-000024:notes:84]
Basic and diluted net income per share attributable to common stockholders is calculated in conformity with the two-class method required for participating securities. Our shares of common stock subject to repurchase are considered participating securities. Under the two-class method, net income attributable to common stockholders is calculated as net income less earnings attributable to participating securities. In computing diluted net income attributable to common stockholders, undistributed earnings are re-allocated to reflect the potential impact of dilutive securities. Basic net income per common share is computed by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding during the period. Diluted net income per share attributable to common stockholders is computed by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding, including potential dilutive common shares assuming the dilutive effect of outstanding stock options, restricted stock units, and employee stock purchase plan using the treasury stock method. For purposes of this calculation, these amounts are excluded from the calculation of diluted net income per share of common stock if their effect is antidilutive.

[0001596532-20-000024:notes:85]
Business Combinations

[0001596532-20-000024:notes:86]
We use the acquisition method to account for our business combinations in accordance with ASC 805 - Business Combinations (“ASC 805”). We allocate the total fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the consideration transferred over the fair values of the assets acquired and liabilities assumed is recorded as goodwill. The results of operations of the acquired businesses are included in our consolidated financial statements from the date of acquisition. Acquisition-related costs and restructuring costs are expensed as incurred.

[0001596532-20-000024:notes:87]
During the measurement period, which is not to exceed one year from the acquisition date, we may record adjustments to the acquired assets and liabilities assumed, with a corresponding offset to goodwill or the preliminary purchase price, to reflect new information obtained about facts and circumstances that existed as of the acquisition date. Upon the conclusion of the measurement period, any subsequent adjustments are recorded to earnings.

[0001596532-20-000024:notes:88]
Goodwill and Intangible Assets

[0001596532-20-000024:notes:89]
We perform our annual goodwill impairment analysis in the fourth quarter of each year or more frequently if there are any events or circumstances that would indicate the carrying amount is not recoverable. We first perform a qualitative assessment to determine if it’s necessary to perform a quantitative assessment.  If after our qualitative assessment we determine it is more likely than not that the fair value of the Company is less than its carrying amount, then a quantitative test is performed by comparing the fair value of the Company with its carrying amount.  We would recognize an impairment loss for the amount by which the carrying amount exceeds the fair value.

[0001596532-20-000024:notes:90]
Intangible assets are carried at cost less accumulated amortization. All intangible assets have been determined to have definite lives and are amortized on a straight-line basis over their estimated useful lives, ranging from one to seven years. Intangible assets are reviewed for impairment periodically or whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable.

[0001596532-20-000024:notes:91]
Recently Adopted Accounting Pronouncements

[0001596532-20-000024:notes:92]
Leases

[0001596532-20-000024:notes:93]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance on lease accounting (“ASC 842”). Under the guidance, lessees are required to recognize assets and lease liabilities on the balance sheet for most leases, including operating leases, and provide enhanced disclosures. We adopted the guidance on January 1, 2019 using the modified retrospective transition method and initially applied the transition provisions at January 1, 2019, which allows us to continue to apply the legacy guidance in ASC 840 - Leases ("ASC 840') for periods prior to 2019, and recognized a cumulative-effect adjustment to retained earnings on the date of adoption. We elected the package of transition practical expedients, which, among other things, allows us to keep the historical lease classifications and not have to reassess the lease classification for any existing leases as of the date of adoption. We also made the following accounting policy elections as allowed by ASC 842:

[0001596532-20-000024:notes:94]
| • | to apply the short-term lease exception, which allows us to keep leases with an initial term of twelve months or less off the balance sheet. |

[0001596532-20-000024:notes:95]
| • | to account for each separate lease component of a contract and its associated non-lease components as a single lease component for all our leases. |

[0001596532-20-000024:notes:96]
As a result of the adoption, we recognized operating leases that were previously not recognized on the consolidated balance sheets. In addition, we derecognized the assets and the lease financing liabilities previously recorded for our headquarters building under a build-to-suit lease. Under ASC 842, this lease is recognized as an operating lease in our condensed consolidated financial statements beginning in the first quarter of 2019. The table below summarizes the impact of the adoption of ASC 842 on the condensed consolidated balance sheet as of January 1, 2019 (in thousands).

[0001596532-20-000024:notes:97]
|  |  |  |  | Adjustments for the Adoption of ASC 842 |  |  |
| Balance Sheet Line Item |  | December 31, 2018 |  | Derecognition of Build-to-Suit Lease |  | Recognition of Operating Leases (1) |  | January 1, 2019 |
| Property and equipment, net |  | $ | 75,355 |  |  | $ | (32,806 | ) |  | $ | — |  |  | $ | 42,549 |  |
| Operating lease right-of-use assets |  | — |  |  | — |  |  | 93,207 |  |  | 93,207 |  |
| Deferred tax assets |  | 126,492 |  |  | (1,165 | ) |  | — |  |  | 125,327 |  |
| Other current liabilities |  | 30,907 |  |  | (2,242 | ) |  | 12,391 |  |  | 41,056 |  |
| Operating lease liabilities, non-current |  | — |  |  | — |  |  | 88,230 |  |  | 88,230 |  |
| Finance lease liabilities, non-current |  | 35,431 |  |  | (35,431 | ) |  | — |  |  | — |  |
| Other long-term liabilities |  | 31,851 |  |  | — |  |  | (7,414 | ) |  | 24,437 |  |
| Retained earnings |  | 1,190,803 |  |  | 3,702 |  |  | — |  |  | 1,194,505 |  |
| __________________ |
| (1) Includes an operating lease for our corporate headquarters building under the build-to-suit arrangement, which was accounted for as a financing lease prior to 2019 and derecognized on January 1, 2019 upon the adoption of ASC 842. |

[0001596532-20-000024:notes:98]
Recent Accounting Pronouncements Not Yet Effective

[0001596532-20-000024:notes:99]
Credit Losses of Financial Instruments

[0001596532-20-000024:notes:100]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  The proposed standard requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. For trade receivables, we will be required to estimate lifetime expected credit losses. For available-for-sale debt securities, we will be required to recognize an allowance for credit losses rather than a reduction to the carrying value of the asset.  The guidance will be effective for us in our first quarter of 2020, and will be applied on a modified retrospective basis. We have evaluated the new accounting guidance and do not anticipate that it will have a material impact on our consolidated statement of operations or consolidated statements of cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-20-000024:notes:101]
Business Combinations
During fiscal 2018, we acquired Mojo and Metamako in order to extend our cognitive cloud networking architecture and to improve our next generation platforms for low-latency applications.

[0001596532-20-000024:notes:102]
The total fair value of consideration transferred for these acquisitions was approximately $118.7 million, which consisted of $103.1 million in cash and $15.6 million for the fair value of 58,072 shares of our common stock issued. The following table summarizes our final purchase price allocation of the two acquisitions, in aggregate, based on the estimated fair value of the assets acquired and liabilities assumed at their respective acquisition dates (in thousands):

[0001596532-20-000024:notes:103]
|  |  | Purchase Price Allocation |
| Cash and cash equivalents |  | $ | 4,953 |  |
| Other tangible assets |  | 23,872 |  |
| Liabilities |  | (28,707 | ) |
| Intangible assets |  | 63,720 |  |
| Goodwill |  | 54,855 |  |
| Net assets acquired |  | $ | 118,693 |  |

[0001596532-20-000024:notes:104]
The acquired intangible assets are amortized on a straight-line basis over their estimated useful lives as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. The following table shows the valuation of the intangible assets acquired (in thousands) along with their estimated useful lives.

[0001596532-20-000024:notes:105]
|  |  | Acquisition Date Fair Value |  | Estimated Useful Life |
| Developed technology |  | $ | 52,510 |  |  | 5 years |
| Customer relationships |  | 7,080 |  |  | 7 years |
| Trade name |  | 2,470 |  |  | 3 years |
| Others |  | 1,660 |  |  | 1 year |
| Total intangible assets acquired |  | $ | 63,720 |  |  |  |

[0001596532-20-000024:notes:106]
The goodwill of 54.9 million is primarily attributable to the expected synergies created by incorporating the solutions of the acquired businesses into our technology platform, and the value of the assembled workforce. The goodwill is not deductible for income taxes purposes.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-20-000024:notes:107]
Fair Value Measurements
We measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value on a recurring basis. The following tables summarize the amortized costs, unrealized gains and losses, and fair value of these financial assets by significant investment category and their level within the fair value hierarchy (in thousands):

[0001596532-20-000024:notes:108]
|  |  | December 31, 2019 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 562,580 |  |  | $ | — |  |  | $ | — |  |  | $ | 562,580 |  |  | $ | 562,580 |  |  | $ | — |  |  | $ | — |  |
| Certificates of deposits (1) |  | 4,001 |  |  | — |  |  | — |  |  | 4,001 |  |  | — |  |  | 4,001 |  |  | — |  |
|  |  | 566,581 |  |  | — |  |  | — |  |  | 566,581 |  |  | 562,580 |  |  | 4,001 |  |  | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 66,717 |  |  | — |  |  | — |  |  | 66,717 |  |  | — |  |  | 66,717 |  |  | — |  |
| Certificates of deposits (1) |  | 3,000 |  |  | — |  |  | — |  |  | 3,000 |  |  | — |  |  | 3,000 |  |  | — |  |
| U.S. government notes |  | 518,884 |  |  | 414 |  |  | (20 | ) |  | 519,278 |  |  | 519,278 |  |  | — |  |  | — |  |
| Corporate bonds |  | 787,741 |  |  | 2,392 |  |  | (73 | ) |  | 790,060 |  |  | — |  |  | 790,060 |  |  | — |  |
| Agency securities |  | 233,491 |  |  | 577 |  |  | (41 | ) |  | 234,027 |  |  | — |  |  | 234,027 |  |  | — |  |
|  |  | 1,609,833 |  |  | 3,383 |  |  | (134 | ) |  | 1,613,082 |  |  | 519,278 |  |  | 1,093,804 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,229 |  |  | — |  |  | — |  |  | 4,229 |  |  | 4,229 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 2,180,643 |  |  | $ | 3,383 |  |  | $ | (134 | ) |  | $ | 2,183,892 |  |  | $ | 1,086,087 |  |  | $ | 1,097,805 |  |  | $ | — |  |
| ____________________ |
| (1) As of December 31, 2019, all of our certificates of deposits were domestic deposits. |

[0001596532-20-000024:notes:109]
|  |  | December 31, 2018 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 322,080 |  |  | $ | — |  |  | $ | — |  |  | $ | 322,080 |  |  | $ | 322,080 |  |  | $ | — |  |  | $ | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 59,479 |  |  | — |  |  | — |  |  | 59,479 |  |  | — |  |  | 59,479 |  |  | — |  |
| Certificates of deposits (1) |  | 5,000 |  |  | — |  |  | — |  |  | 5,000 |  |  | — |  |  | 5,000 |  |  | — |  |
| U.S. government notes |  | 308,946 |  |  | 118 |  |  | (286 | ) |  | 308,778 |  |  | 308,778 |  |  | — |  |  | — |  |
| Corporate bonds |  | 660,353 |  |  | 264 |  |  | (1,399 | ) |  | 659,218 |  |  | — |  |  | 659,218 |  |  | — |  |
| Agency securities |  | 273,993 |  |  | 240 |  |  | (511 | ) |  | 273,722 |  |  | — |  |  | 273,722 |  |  | — |  |
|  |  | 1,307,771 |  |  | 622 |  |  | (2,196 | ) |  | 1,306,197 |  |  | 308,778 |  |  | 997,419 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,214 |  |  | — |  |  | — |  |  | 4,214 |  |  | 4,214 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 1,634,065 |  |  | $ | 622 |  |  | $ | (2,196 | ) |  | $ | 1,632,491 |  |  | $ | 635,072 |  |  | $ | 997,419 |  |  | $ | — |  |
| ____________________ |
| (1) As of December 31, 2018, all of our certificates of deposits were domestic deposits. |

[0001596532-20-000024:notes:110]
We did not realize any other-than-temporary losses on our marketable securities for the years ended December 31, 2019 and 2018. As of December 31, 2019 and 2018, total unrealized losses of our marketable securities that had been in a continuous unrealized loss portion were immaterial. We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a time with lower interest rates show a mark-to-market unrealized loss. We expect to realize the full value of these investments upon maturity or sale and therefore, we do not consider any of our marketable securities to be other-than-temporarily impaired as of December 31, 2019.

[0001596532-20-000024:notes:111]
As of December 31, 2019, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale marketable securities, by remaining contractual maturity, are as follows (in thousands):

[0001596532-20-000024:notes:112]
|  |  | December 31, 2019 |
| Due in 1 year or less |  | $ | 915,069 |  |
| Due in 1 year through 2 years |  | 698,013 |  |
| Total marketable securities |  | $ | 1,613,082 |  |

[0001596532-20-000024:notes:113]
The weighted-average remaining duration of our current marketable securities is approximately 0.8 years as of December 31, 2019.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-20-000024:notes:114]
Financial Statements Details
Cash, Cash Equivalents and Restricted Cash

[0001596532-20-000024:notes:115]
The following table is a reconciliation of cash, cash equivalents and restricted cash reported within the accompanying consolidated balance sheets that sum to the total of the same such amounts shown in the accompanying consolidated statements of cash flows (in thousands):

[0001596532-20-000024:notes:116]
|  |  | December 31, |
|  |  | 2019 |  | 2018 |
| Cash and cash equivalents |  | $ | 1,111,286 |  |  | $ | 649,950 |  |
| Restricted cash included in other assets |  | 4,229 |  |  | 4,214 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 1,115,515 |  |  | $ | 654,164 |  |

[0001596532-20-000024:notes:117]
Accounts Receivable, net

[0001596532-20-000024:notes:118]
Accounts receivable, net consists of the following (in thousands):

[0001596532-20-000024:notes:119]
|  |  | December 31, |
|  |  | 2019 |  | 2018 |
| Accounts receivable |  | $ | 398,147 |  |  | $ | 340,897 |  |
| Allowance for doubtful accounts |  | (638 | ) |  | (507 | ) |
| Product sales rebate and returns reserve |  | (5,522 | ) |  | (8,613 | ) |
| Accounts receivable, net |  | $ | 391,987 |  |  | $ | 331,777 |  |

[0001596532-20-000024:notes:120]
Allowance for Doubtful Accounts

[0001596532-20-000024:notes:121]
Activity in the allowance for doubtful accounts consists of the following (in thousands):

[0001596532-20-000024:notes:122]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Balance at the beginning of year |  | $ | 507 |  |  | $ | 112 |  |  | $ | 204 |  |
| Additions charged to expense |  | 221 |  |  | 500 |  |  | 17 |  |
| Deductions/write-offs |  | (90 | ) |  | (105 | ) |  | (109 | ) |
| Balance at the end of year |  | $ | 638 |  |  | $ | 507 |  |  | $ | 112 |  |

[0001596532-20-000024:notes:123]
Product Sales Rebate and Returns Reserve

[0001596532-20-000024:notes:124]
Activity in the product sales rebate and returns reserve consists of the following (in thousands):

[0001596532-20-000024:notes:125]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Balance at the beginning of year |  | $ | 8,613 |  |  | $ | 7,423 |  |  | $ | 1,317 |  |
| Additions charged against revenue |  | 2,032 |  |  | 4,269 |  |  | 17,371 |  |
| Consumption |  | (5,123 | ) |  | (3,079 | ) |  | (11,265 | ) |
| Balance at the end of year |  | $ | 5,522 |  |  | $ | 8,613 |  |  | $ | 7,423 |  |

[0001596532-20-000024:notes:126]
Inventories

[0001596532-20-000024:notes:127]
Inventories consist of the following (in thousands):

[0001596532-20-000024:notes:128]
|  |  | December 31, |
|  |  | 2019 |  | 2018 |
| Raw materials |  | $ | 96,712 |  |  | $ | 76,795 |  |
| Finished goods |  | 147,113 |  |  | 187,762 |  |
| Total inventories |  | $ | 243,825 |  |  | $ | 264,557 |  |

[0001596532-20-000024:notes:129]
Prepaid Expenses and Other Current Assets

[0001596532-20-000024:notes:130]
Prepaid expenses and other current assets consists of the following (in thousands):

[0001596532-20-000024:notes:131]
|  |  | December 31, |
|  |  | 2019 |  | 2018 |
| Inventory deposit |  | $ | 13,716 |  |  | $ | 14,639 |  |
| Prepaid income taxes |  | 20,153 |  |  | 38,636 |  |
| Other current assets |  | 64,464 |  |  | 95,730 |  |
| Other prepaid expenses and deposits |  | 13,123 |  |  | 13,316 |  |
| Total prepaid expenses and other current assets |  | $ | 111,456 |  |  | $ | 162,321 |  |

[0001596532-20-000024:notes:132]
Property and Equipment, net

[0001596532-20-000024:notes:133]
Property and equipment, net consists of the following (in thousands):

[0001596532-20-000024:notes:134]
|  |  | December 31, |
|  |  | 2019 |  | 2018 |
| Equipment and machinery |  | $ | 64,748 |  |  | $ | 55,912 |  |
| Computer hardware and software |  | 36,627 |  |  | 30,566 |  |
| Furniture and fixtures |  | 3,774 |  |  | 3,697 |  |
| Leasehold improvements |  | 31,235 |  |  | 36,447 |  |
| Building |  | — |  |  | 35,154 |  |
| Construction-in-process |  | 265 |  |  | 3,591 |  |
| Property and equipment, gross |  | 136,649 |  |  | 165,367 |  |
| Less: accumulated depreciation |  | (97,376 | ) |  | (90,012 | ) |
| Property and equipment, net |  | $ | 39,273 |  |  | $ | 75,355 |  |

[0001596532-20-000024:notes:135]
Depreciation expense was $19.0 million, $21.6 million and $20.2 million for the years ended December 31, 2019, 2018 and 2017, respectively. On January 1, 2019, upon the adoption of ASC 842, we derecognized the building and certain leasehold improvements for our corporate headquarters that were previously capitalized under a build-to-suit arrangement. See Note 7 for further details.

[0001596532-20-000024:notes:136]
Accrued Liabilities

[0001596532-20-000024:notes:137]
Accrued liabilities consist of the following (in thousands):

[0001596532-20-000024:notes:138]
|  |  | December 31, |
|  |  | 2019 |  | 2018 |
| Accrued payroll related costs |  | $ | 80,133 |  |  | $ | 70,755 |  |
| Accrued manufacturing costs |  | 31,920 |  |  | 31,336 |  |
| Accrued product development costs |  | 11,410 |  |  | 6,988 |  |
| Accrued warranty costs |  | 6,742 |  |  | 5,362 |  |
| Accrued professional fees |  | 6,335 |  |  | 5,678 |  |
| Accrued taxes |  | 1,716 |  |  | 839 |  |
| Other |  | 1,993 |  |  | 2,296 |  |
| Total accrued liabilities |  | $ | 140,249 |  |  | $ | 123,254 |  |

[0001596532-20-000024:notes:139]
Warranty Accrual

[0001596532-20-000024:notes:140]
The following table summarizes the activity related to our accrued liability for estimated future warranty costs (in thousands):

[0001596532-20-000024:notes:141]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |
| Warranty accrual, beginning of year |  | $ | 5,362 |  |  | $ | 7,415 |  |
| Liabilities accrued for warranties issued during the year |  | 7,169 |  |  | 3,565 |  |
| Warranty costs incurred during the year |  | (5,789 | ) |  | (5,618 | ) |
| Warranty accrual, end of year |  | $ | 6,742 |  |  | $ | 5,362 |  |

[0001596532-20-000024:notes:142]
The following table summarizes the beginning and ending balances of our contract assets (in thousands):

[0001596532-20-000024:notes:143]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |
| Contract assets, beginning balance |  | $ | 6,341 |  |  | $ | — |  |
| Contract assets, ending balance |  | 25,565 |  |  | 6,341 |  |

[0001596532-20-000024:notes:144]
The following table summarizes the activity related to our contract liabilities (in thousands):

[0001596532-20-000024:notes:145]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |
| Contract liabilities, beginning balance |  | $ | 32,595 |  |  | $ | 16,521 |  |
| Less: Revenue recognized from beginning balance |  | (12,887 | ) |  | (7,561 | ) |
| Less: Beginning balance reclassified to deferred revenue |  | (894 | ) |  | (371 | ) |
| Add: Contract liabilities recognized |  | 42,236 |  |  | 24,006 |  |
| Contract liabilities, ending balance |  | $ | 61,050 |  |  | $ | 32,595 |  |

[0001596532-20-000024:notes:146]
As of December 31, 2019 and 2018, $23.4 million and $13.5 million of our contract liabilities was included in “Other current liabilities” with the remaining balance included in “Other long-term liabilities”.

[0001596532-20-000024:notes:147]
Deferred Revenue and Performance Obligations

[0001596532-20-000024:notes:148]
Deferred revenue is comprised mainly of unearned revenue related to multi-year PCS contracts, services and product deferrals related to acceptance clauses. The following table summarizes the activity related to our deferred revenue (in thousands):

[0001596532-20-000024:notes:149]
|  |  | Year Ended December 31, 2019 |
| Deferred revenue, beginning balance |  | $ | 587,227 |  |
| Less: Revenue recognized from beginning balance |  | (351,617 | ) |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 339,678 |  |
| Deferred revenue, ending balance |  | $ | 575,288 |  |
| _________________________________ |  |  |

[0001596532-20-000024:notes:150]
Revenue from Remaining Performance Obligations

[0001596532-20-000024:notes:151]
Revenue from remaining performance obligations represents contracted revenue that has not yet been recognized, which primarily includes contract liabilities and deferred revenue that will be recognized as revenue in future periods. As of December 31, 2019, approximately $691.9 million of revenue is expected to be recognized from remaining performance obligations. We expect to recognize revenue on approximately 78% of these remaining performance obligations over the next 2 years and 22% during years 3 to 5.

[0001596532-20-000024:notes:152]
Other Income (Expense), Net

[0001596532-20-000024:notes:153]
Other income (expense), net consists of the following (in thousands):

[0001596532-20-000024:notes:154]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Other income (expense), net: |  |  |  |  |  |  |
| Interest income |  | $ | 51,144 |  |  | $ | 31,666 |  |  | $ | 8,093 |  |
| Interest expense |  | — |  |  | (2,701 | ) |  | (2,780 | ) |
| Gain (loss) on investments in privately-held companies |  | 5,427 |  |  | (13,800 | ) |  | — |  |
| Other income (expense) |  | (75 | ) |  | 289 |  |  | (825 | ) |
| Total other income (expense), net |  | $ | 56,496 |  |  | $ | 15,454 |  |  | $ | 4,488 |  |


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-20-000024:notes:155]
Investments
Investments in Privately-Held Companies

[0001596532-20-000024:notes:156]
Our investments are in the equity of privately-held companies, which do not have readily determinable fair values. These non-marketable equity securities are initially recorded at cost, and subsequently remeasured to fair value on a non-recurring basis based on observable price changes in orderly transactions for similar investments of the same issuer, or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to those investments. In addition, the valuation requires management judgment due to the absence of market price and inherent lack of liquidity. The following table summarizes the activity related to our investments in privately-held companies held as of December 31, 2019 and 2018 (in thousands):

[0001596532-20-000024:notes:157]
|  |  | December 31, 2019 |  | December 31, 2018 |
| Cost of investment |  | $ | 3,000 |  |  | $ | 44,136 |  |
| Cumulative impairment |  | — |  |  | (15,000 | ) |
| Cumulative upward adjustment |  | 1,150 |  |  | 1,200 |  |
| Carrying amount of investment |  | $ | 4,150 |  |  | $ | 30,336 |  |

[0001596532-20-000024:notes:158]
During the year ended December 31, 2019, we recorded a realized gain of $4.3 million upon the sale of one of our investments. In each of the years ended December 31, 2019 and 2018, we recorded $1.2 million of unrealized gains.  These unrealized gains were recorded on investments that were re-measured to fair value as of the date observable transactions occurred. In addition, during the year ended December 31, 2018, we recorded an impairment of $15.0 million on one of our investments.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001596532-20-000024:notes:159]
Goodwill and Acquisition-Related Intangible Assets 
Goodwill

[0001596532-20-000024:notes:160]
Goodwill was recorded as a result of our acquisition of Mojo and Metamako in the third quarter of 2018. See Note 2 for details.

[0001596532-20-000024:notes:161]
In the fourth quarter of 2019, we completed an annual goodwill impairment analysis. Based on our assessment of the qualitative factors, management concluded that the fair value of the Company was not more likely than not less than its carrying amount as of December 31, 2019. Subsequent to this 2019 annual impairment test, we have not identified significant events or circumstances negatively affecting the valuation of goodwill. As of December 31, 2019, there was no impairment to the carrying value of our goodwill.

[0001596532-20-000024:notes:162]
Acquisition-Related Intangible Assets

[0001596532-20-000024:notes:163]
The following table presents details of our acquisition-related intangible assets as of December 31, 2019 and 2018 (in thousands):

[0001596532-20-000024:notes:164]
|  |  | December 31, 2019 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life(In Years) |
| Developed technology |  | $ | 52,510 |  |  | $ | (14,326 | ) |  | $ | 38,184 |  |  | 3.7 |
| Customer relationships |  | 7,080 |  |  | (1,387 | ) |  | 5,693 |  |  | 5.8 |
| Trade name |  | 2,470 |  |  | (1,112 | ) |  | 1,358 |  |  | 1.7 |
| Others |  | 1,660 |  |  | (1,660 | ) |  | — |  |  | 0.0 |
| Total |  | $ | 63,720 |  |  | $ | (18,485 | ) |  | $ | 45,235 |  |  | 3.9 |

[0001596532-20-000024:notes:165]
|  |  | December 31, 2018 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life(In Years) |
| Developed technology |  | $ | 52,510 |  |  | $ | (3,824 | ) |  | $ | 48,686 |  |  | 4.6 |
| Customer relationships |  | 7,080 |  |  | (375 | ) |  | 6,705 |  |  | 6.6 |
| Trade name |  | 2,470 |  |  | (289 | ) |  | 2,181 |  |  | 2.7 |
| Others |  | 1,660 |  |  | (622 | ) |  | 1,038 |  |  | 0.6 |
| Total |  | $ | 63,720 |  |  | $ | (5,110 | ) |  | $ | 58,610 |  |  | 4.7 |

[0001596532-20-000024:notes:166]
Amortization expense related to acquisition-related intangible assets was $13.4 million and $5.1 million for the years ended December 31, 2019 and 2018, respectively.

[0001596532-20-000024:notes:167]
As of December 31, 2019, future estimated amortization expense related to the acquired-related intangible assets is as follows (in thousands):

[0001596532-20-000024:notes:168]
| Years Ending December 31, |  | Future Amortization Expense |
| 2020 |  | $ | 12,337 |  |
| 2021 |  | 12,048 |  |
| 2022 |  | 11,513 |  |
| 2023 |  | 7,690 |  |
| 2024 |  | 1,011 |  |
| Thereafter |  | 636 |  |
| Total |  | $ | 45,235 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-20-000024:notes:169]
Commitments and Contingencies
Operating Leases

[0001596532-20-000024:notes:170]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2028. Some of our leases include options to extend the term of such leases for a period from three months to up to 10 years and/or options to early terminate the leases. As of December 31, 2019, we did not include any such options in determining the lease terms because we were not reasonably certain that we would exercise those options. Most of our leases require us to pay certain operating expenses in addition to base rent, such as taxes, repairs, and insurance, and contain renewal and escalation clauses.

[0001596532-20-000024:notes:171]
Build-to-Suit Lease

[0001596532-20-000024:notes:172]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013. Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction, we were deemed the accounting owner of the building during the construction period in accordance with ASC 840. As a result, we recognized assets under construction and corresponding liabilities on the consolidated balance sheet. Upon completion of the construction in 2013, we concluded that we had forms of continued economic involvement in the facility, and therefore did not meet with the provisions for sale-leaseback accounting. Pursuant to ASC 840, we continued to carry the assets and liabilities capitalized during the construction period and accounted for the lease as a capital lease for the building and an operating lease for the underlying land.

[0001596532-20-000024:notes:173]
The following table summarizes the supplemental balance sheet information related to our operating leases as of December 31, 2019 (in thousands).

[0001596532-20-000024:notes:174]
|  |  | Financial Statement Classification |  | December 31, 2019 |
| Right-of-use assets: |  |  |  |  |
| Operating lease right-of-use assets |  | Operating lease right-of-use assets |  | $ | 87,770 |  |
| Lease liabilities: |  |  |  |  |
| Operating lease liabilities, current |  | Other current liabilities |  | 16,052 |  |
| Operating lease liabilities, non-current |  | Operating lease liabilities, non-current |  | 83,022 |  |
| Total operating lease liabilities |  |  |  | $ | 99,074 |  |

[0001596532-20-000024:notes:175]
The following table summarizes our lease costs for the year ended December 31, 2019 (in thousands).

[0001596532-20-000024:notes:176]
|  |  |  |  | Year Ended December 31, |
|  |  | Financial Statement Classification |  | 2019 |
| Operating lease costs: |  |  |  |  |
| Fixed lease costs |  | Operating expenses |  | $ | 22,544 |  |
| Variable lease costs |  | Operating expenses |  | 6,255 |  |
| Total operating lease costs |  |  |  | $ | 28,799 |  |

[0001596532-20-000024:notes:177]
The operating lease costs in the table above include costs for long-term leases and short-term leases. Total short-term lease costs were immaterial. Fixed lease costs include expenses recognized for base rent payments on a straight-lined basis. Variable lease costs primarily include maintenance, utilities and operating expenses that are incremental to the fixed base rent payments, and are excluded from the calculation of operating lease liabilities and ROU assets.  For the year ended December 31, 2019, cash paid for amounts associated with our operating lease liabilities were approximately $18.6 million which were classified as operating activities in the condensed consolidated statements of cash flows.

[0001596532-20-000024:notes:178]
Prior to 2019, we recognized rent expense for our operating leases under the legacy guidance ASC 840. For the year ended December 31, 2018, rent expense for all operating leases amounted to $12.9 million, and did not include maintenance, utilities and other operating expenses in accordance with ASC 840.

[0001596532-20-000024:notes:179]
The following table shows our undiscounted future fixed payment obligations under our recognized operating leases and a reconciliation to the operating lease liabilities as of December 31, 2019 (in thousands).

[0001596532-20-000024:notes:180]
|  |  | December 31, 2019 |
| 2020 |  | $ | 20,563 |  |
| 2021 |  | 21,303 |  |
| 2022 |  | 21,491 |  |
| 2023 |  | 17,702 |  |
| 2024 |  | 9,786 |  |
| 2025 and thereafter |  | 26,220 |  |
| Total future fixed operating lease payments |  | 117,065 |  |
| Less: |  |  |
| Imputed interest |  | (17,991 | ) |
| Total operating lease liabilities |  | $ | 99,074 |  |

[0001596532-20-000024:notes:181]
|  |  | December 31, 2019 |
| Weighted-average remaining lease term — operating leases |  | 6.0 years |
| Weighted-average discount rate — operating leases |  | 5.1% |

[0001596532-20-000024:notes:182]
Purchase Commitments

[0001596532-20-000024:notes:183]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished product and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of December 31, 2019, we had non-cancellable purchase commitments of $294.7

[0001596532-20-000024:notes:184]
million, of which $279.2 million was to our contract manufacturers and suppliers.  In addition, we have provided deposits to secure our obligations to purchase inventory. We had $16.5 million and $17.4 million in deposits as of December 31, 2019 and 2018, respectively. These deposits are classified in 'Prepaid expenses and other current assets' and 'Other assets' in our accompanying consolidated balance sheets.

[0001596532-20-000024:notes:185]
Guarantees

[0001596532-20-000024:notes:186]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-20-000024:notes:187]
Legal Proceedings

[0001596532-20-000024:notes:188]
OptumSoft, Inc. Settlement

[0001596532-20-000024:notes:189]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies; and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-20-000024:notes:190]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial were set to be tried in Phase II, including the application of the Court’s interpretation of the 2004 agreement to any other source code that OptumSoft claims to own and the trade secret misappropriation and confidentiality claims.

[0001596532-20-000024:notes:191]
On September 24, 2019, the Company and OptumSoft entered into a settlement agreement resolving all the issues that were set to be tried in Phase II of the litigation. Under the settlement agreement, OptumSoft could still pursue its appeal of the Court’s Final Statement of Decision Following Phase I Trial, and pursue any further litigation that may result, but granted the Company a release on all other outstanding claims.

[0001596532-20-000024:notes:192]
On December 6, 2019, the Company and OptumSoft entered into a settlement agreement resolving the remaining issues in the litigation.

[0001596532-20-000024:notes:193]
GlobalFoundries Litigation

[0001596532-20-000024:notes:194]
On August 26, 2019, GlobalFoundries U.S. Inc. (“GlobalFoundries”) filed complaints in the International Trade Commission and federal court against TSMC and numerous companies that sell products incorporating semiconductor devices manufactured by TSMC, including Arista, Broadcom, NVIDIA, Apple, Asus, Cisco, and Lenovo. The complaints allege that these semiconductor devices infringe four GlobalFoundries patents relating to semiconductor manufacturing techniques. In our case, GlobalFoundries has accused the merchant silicon we purchase from Broadcom of infringement. On October 28, 2019, TSMC and GlobalFoundries entered into a cross-license agreement to settle the litigation.

[0001596532-20-000024:notes:195]
Other Matters

[0001596532-20-000024:notes:196]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-20-000024:notes:197]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of December 31, 2019, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-20-000024:notes:198]
Stockholders' Equity
Stock Repurchase Program

[0001596532-20-000024:notes:199]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program.  This authorization allows us to repurchase shares of our common stock opportunistically and is funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Exchange Act, or a combination of the foregoing. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of December 31, 2019, the remaining authorized amount for stock repurchases under this program was approximately $733.9 million.

[0001596532-20-000024:notes:200]
A summary of the stock repurchase activity under the Repurchase Program for the year ended December 31, 2019 is as follows (in thousands, except per share amounts):

[0001596532-20-000024:notes:201]
|  |  | Year Ended December 31, |
|  |  | 2019 |
| Aggregate purchase price |  | $ | 266,142 |  |
| Shares repurchased |  | 1,189 |  |
| Average price paid per share |  | $ | 223.57 |  |

[0001596532-20-000024:notes:202]
The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings.  All shares repurchased under the Repurchase Program have been retired.

[0001596532-20-000024:notes:203]
2014 Equity Incentive Plan

[0001596532-20-000024:notes:204]
In April 2014, the board of directors and stockholders approved the 2014 Equity Incentive Plan (the “2014 Plan”), effective on the first day that our common stock was publicly traded, and simultaneously terminated the 2004 and 2011 equity plans as to future grants.  However, these plans will continue to govern the terms and conditions of the outstanding options previously granted thereunder.

[0001596532-20-000024:notes:205]
Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”).  The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of the outstanding shares of our common stock on the immediately preceding December 31, but not to exceed 12,500,000 shares (the “2014 Plan Evergreen Increase”), unless the board of directors, in its discretion, determines to make a smaller increase. Our board of directors determined not to authorize the 2014 Plan Evergreen Increase that would have occurred on January 1, 2019. As of December 31, 2019, there remained approximately 20.8 million

[0001596532-20-000024:notes:206]
shares available for issuance under the 2014 Plan.  On February 3, 2020, our board of directors authorized an increase of 2,291,660 shares to shares available for issuance under the 2014 Plan effective January 1, 2020.

[0001596532-20-000024:notes:207]
2014 Employee Stock Purchase Plan

[0001596532-20-000024:notes:208]
In April 2014, the board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded.  The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding immediately preceding December 31, but not to exceed 2,500,000 shares, unless the board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2019, our board of directors authorized an increase of 756,679 shares to shares available for issuance under the ESPP. As of December 31, 2019, there remained 3,192,774 shares available for issuance under the ESPP. On February 3, 2020, our board of directors authorized an increase of 763,886 shares to shares available for issuance under the ESPP effective January 1, 2020.

[0001596532-20-000024:notes:209]
Under our 2014 ESPP eligible employees are permitted to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the exercise date. Each offering period will be approximately two years starting on the first trading date after February 15 and August 15 of each year. Participants may purchase shares of common stock through payroll deductions up to 10% of their eligible compensation, subject to Internal Revenue Service mandated purchase limits.

[0001596532-20-000024:notes:210]
During the year ended December 31, 2019, we issued 97,343 shares at an average purchase price of $184.70 under our ESPP.

[0001596532-20-000024:notes:211]
Stock Option Activities

[0001596532-20-000024:notes:212]
The following table summarizes the option activities under our stock plans and related information (in thousands, except years and per share amounts):

[0001596532-20-000024:notes:213]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (In Years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2018 |  | 5,899 |  |  | $ | 37.09 |  |  | 5.2 |  | $ | 1,027,741 |  |
| Options granted |  | 76 |  |  | 226.53 |  |  |  |  |  |
| Options exercised |  | (1,341 | ) |  | 29.38 |  |  |  |  |  |
| Options canceled |  | (70 | ) |  | 37.86 |  |  |  |  |  |
| Balance—December 31, 2019 |  | 4,564 |  |  | $ | 42.50 |  |  | 4.4 |  | $ | 740,387 |  |
| Vested and exercisable—December 31, 2019 |  | 2,755 |  |  | $ | 28.22 |  |  | 3.9 |  | $ | 482,712 |  |

[0001596532-20-000024:notes:214]
The weighted-average grant-date fair value of options granted during the year ended December 31, 2019, 2018 and 2017 was $107.42, $121.18 and $40.17 per share, respectively. The aggregate intrinsic value of options exercised during the year ended December 31, 2019, 2018 and 2017 was $323.1 million, $283.8 million and $307.7 million. The total fair value of options vested for the years ended December 31, 2019, 2018 and 2017 was approximately $23.0 million, $31.9 million and $30.7 million, respectively.

[0001596532-20-000024:notes:215]
Restricted Stock Unit (RSU) Activities

[0001596532-20-000024:notes:216]
A summary of the RSU activities under our 2014 Plan and changes during the reporting period and a summary of related information are presented below (in thousands, except years and per share amounts):

[0001596532-20-000024:notes:217]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |
| Unvested balance—December 31, 2018 |  | 1,308 |  |  | $ | 150.60 |  |
| RSUs granted |  | 360 |  |  | 242.13 |  |
| RSUs vested |  | (513 | ) |  | 126.36 |  |
| RSUs forfeited/canceled |  | (85 | ) |  | 183.90 |  |
| Unvested balance—December 31, 2019 |  | 1,070 |  |  | $ | 190.35 |  |

[0001596532-20-000024:notes:218]
The total fair value of RSUs vested for the years ended December 31, 2019, 2018 and 2017 was approximately $65.7 million, $52.5 million, and $35.4 million, respectively.

[0001596532-20-000024:notes:219]
Shares Available for Grant

[0001596532-20-000024:notes:220]
The following table presents the stock activities and the total number of shares available for grant as of December 31, 2019 (in thousands):

[0001596532-20-000024:notes:221]
|  |  | Number of Shares |
| Balance—December 31, 2018 |  | 15,386 |  |
| Authorized |  | — |  |
| Options granted |  | (76 | ) |
| RSUs granted |  | (360 | ) |
| Options canceled |  | 70 |  |
| RSUs forfeited |  | 85 |  |
| Shares traded for taxes |  | 41 |  |
| Balance—December 31, 2019 |  | 15,146 |  |

[0001596532-20-000024:notes:222]
Stock-Based Compensation Expense

[0001596532-20-000024:notes:223]
Total following table summarizes stock-based compensation expense related to our equity awards (in thousands):

[0001596532-20-000024:notes:224]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Cost of revenue |  | $ | 4,637 |  |  | $ | 5,087 |  |  | $ | 4,353 |  |
| Research and development |  | 53,068 |  |  | 48,205 |  |  | 42,184 |  |
| Sales and marketing |  | 29,168 |  |  | 24,995 |  |  | 17,953 |  |
| General and administrative |  | 14,407 |  |  | 12,915 |  |  | 10,937 |  |
| Total stock-based compensation |  | $ | 101,280 |  |  | $ | 91,202 |  |  | $ | 75,427 |  |

[0001596532-20-000024:notes:225]
Determination of Fair Value

[0001596532-20-000024:notes:226]
We record stock-based compensation awards based on fair value as of the grant date. We value RSUs at the market close price of our common stock on the date of grant. For option awards and ESPP offerings we use the Black-Scholes option pricing model to determine fair value. We recognize such costs as compensation expense generally on a straight-line basis over the requisite service period of the award.

[0001596532-20-000024:notes:227]
Stock Options

[0001596532-20-000024:notes:228]
For the years ended December 31, 2019, 2018 and 2017, the fair value of each stock option granted under our plans was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001596532-20-000024:notes:229]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Expected term (in years) |  | 6.9 |  |  | 7.0 |  |  | 6.3 |  |
| Risk-free interest rate |  | 2.5 | % |  | 2.9 | % |  | 2.1 | % |
| Expected volatility |  | 42.8 | % |  | 44.6 | % |  | 38.9 | % |
| Dividend rate |  | — | % |  | — | % |  | — | % |

[0001596532-20-000024:notes:230]
ESPP

[0001596532-20-000024:notes:231]
The following table summarizes the assumptions relating to our ESPP:

[0001596532-20-000024:notes:232]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Expected term (in years) |  | 1.1 |  |  | 1.1 |  |  | 1.2 |  |
| Risk-free interest rate |  | 1.8 | % |  | 2.4 | % |  | 1.1 | % |
| Expected volatility |  | 42.5 | % |  | 41.9 | % |  | 31.7 | % |
| Dividend rate |  | — | % |  | — | % |  | — | % |

[0001596532-20-000024:notes:233]
As of December 31, 2019, unrecognized stock-based compensation expenses by award type and their expected weighted-average recognition periods are summarized in the following table (in thousands, except years).

[0001596532-20-000024:notes:234]
|  |  | December 31, 2019 |
|  |  | Stock Option |  | RSU |  | ESPP |  | Restricted Stock |
| Unrecognized stock-based compensation expense |  | $ | 43,928 |  |  | $ | 179,986 |  |  | $ | 10,401 |  |  | $ | 3,931 |  |
| Weighted-average amortization period |  | 3.3 years |  |  | 3.2 years |  |  | 1.1 years |  |  | 2.7 years |  |


## us-gaap:EarningsPerShareTextBlock

[0001596532-20-000024:notes:235]
Net Income Per Share Available to Common Stock 
The following table sets forth the computation of our basic and diluted net income per share available to common stock (in thousands, except per share amounts):

[0001596532-20-000024:notes:236]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Numerator: |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |
| Net income |  | $ | 859,867 |  |  | $ | 328,115 |  |  | $ | 423,201 |  |
| Less: undistributed earnings allocated to participating securities |  | (423 | ) |  | (189 | ) |  | (801 | ) |
| Net income available to common stockholders, basic |  | $ | 859,444 |  |  | $ | 327,926 |  |  | $ | 422,400 |  |
| Diluted: |  |  |  |  |  |  |
| Net income attributable to common stockholders, basic |  | $ | 859,444 |  |  | $ | 327,926 |  |  | $ | 422,400 |  |
| Add: undistributed earnings allocated to participating securities |  | 24 |  |  | 15 |  |  | 68 |  |
| Net income attributable to common stockholders, diluted |  | $ | 859,468 |  |  | $ | 327,941 |  |  | $ | 422,468 |  |
| Denominator: |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 76,312 |  |  | 74,750 |  |  | 72,258 |  |
| Diluted: |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 76,312 |  |  | 74,750 |  |  | 72,258 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |
| Stock options, RSUs and RSAs |  | 4,565 |  |  | 6,083 |  |  | 6,599 |  |
| Employee stock purchase plan |  | 2 |  |  | 11 |  |  | 120 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted |  | 80,879 |  |  | 80,844 |  |  | 78,977 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |
| Basic |  | $ | 11.26 |  |  | $ | 4.39 |  |  | $ | 5.85 |  |
| Diluted |  | $ | 10.63 |  |  | $ | 4.06 |  |  | $ | 5.35 |  |

[0001596532-20-000024:notes:237]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share available to common stockholders for the periods presented because including them would have been anti-dilutive (in thousands):

[0001596532-20-000024:notes:238]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Stock options and RSUs to purchase common stock |  | 318 |  |  | 140 |  |  | 58 |  |
| Employee stock purchase plan |  | 82 |  |  | 71 |  |  | — |  |
| Total |  | 400 |  |  | 211 |  |  | 58 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-20-000024:notes:239]
Income Taxes 
The geographical breakdown of income before provision for income taxes is as follows (in thousands):

[0001596532-20-000024:notes:240]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Domestic |  | $ | 727,632 |  |  | $ | 136,818 |  |  | $ | 373,221 |  |
| Foreign |  | 134,638 |  |  | 151,983 |  |  | 101,539 |  |
| Income before income taxes |  | $ | 862,270 |  |  | $ | 288,801 |  |  | $ | 474,760 |  |

[0001596532-20-000024:notes:241]
The components of the provision for income taxes are as follows (in thousands):

[0001596532-20-000024:notes:242]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Current provision for income taxes: |  |  |  |  |  |  |
| Federal |  | $ | 58,187 |  |  | $ | 6,113 |  |  | $ | 31,935 |  |
| State |  | 19,067 |  |  | 2,018 |  |  | 3,645 |  |
| Foreign |  | 928 |  |  | 10,451 |  |  | 7,322 |  |
| Total current |  | 78,182 |  |  | 18,582 |  |  | 42,902 |  |
| Deferred tax expense/(benefit): |  |  |  |  |  |  |
| Federal |  | 362,056 |  |  | (57,726 | ) |  | 12,795 |  |
| State |  | (4,511 | ) |  | (4,164 | ) |  | (3,404 | ) |
| Foreign |  | (433,324 | ) |  | 3,994 |  |  | (734 | ) |
| Total deferred |  | (75,779 | ) |  | (57,896 | ) |  | 8,657 |  |
| Total provision for (benefit from) income taxes |  | $ | 2,403 |  |  | $ | (39,314 | ) |  | $ | 51,559 |  |

[0001596532-20-000024:notes:243]
The reconciliation of the statutory federal income tax rate and our effective income tax rate is as follows:

[0001596532-20-000024:notes:244]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| U.S. federal statutory income tax rate |  | 21.00 | % |  | 21.00 | % |  | 35.00 | % |
| State tax, net of federal benefit |  | 1.30 |  |  | (0.59 | ) |  | 0.03 |  |
| Taxes on foreign earnings differential |  | (2.59 | ) |  | (3.37 | ) |  | (5.18 | ) |
| Tax credits |  | (3.10 | ) |  | (7.68 | ) |  | (3.23 | ) |
| Change in valuation allowance |  | (0.10 | ) |  | 1.00 |  |  | — |  |
| Intra-Entity Sale |  | (9.95 | ) |  | — |  |  | — |  |
| Stock-based compensation |  | (6.56 | ) |  | (24.90 | ) |  | (25.86 | ) |
| Tax Cuts and Jobs Act |  | — |  |  | (1.72 | ) |  | 11.14 |  |
| Acquisition and integration costs |  | 0.04 |  |  | 2.12 |  |  | — |  |
| Other, net |  | 0.24 |  |  | 0.53 |  |  | (1.04 | ) |
| Effective tax rate |  | 0.28 | % |  | (13.61 | )% |  | 10.86 | % |

[0001596532-20-000024:notes:245]
Excess tax benefits resulting from stock awards were $77.9 million, $75.5 million and $110.0 million for the years ended December 31, 2019, 2018 and 2017, respectively.

[0001596532-20-000024:notes:246]
We have operations and a taxable presence in numerous jurisdictions outside the U.S.  In 2019, a few of these countries have a lower tax rate than the U.S. The significant jurisdictions in which we have a presence include Cayman Islands, Ireland, and the United Kingdom.

[0001596532-20-000024:notes:247]
On December 31, 2019, we completed an intra-entity transaction to sell our non-Americas economic and beneficial intellectual property ("IP") rights in exchange for a non-interest-bearing note of $3.4 billion.  As a result of the transaction, tax basis in the IP transferred equaled the fair market value of the qualifying IP that resulted in the recognition of a deferred tax asset of $429.1 million, which was largely offset by a deferred tax liability of $343.3 million associated with the future US tax on foreign earnings arising from the transaction for the difference in the local tax basis and US GAAP book basis of the IP rights.

[0001596532-20-000024:notes:248]
The tax effects of temporary differences that give rise to significant portions of deferred tax assets (liabilities) are as follows (in thousands):

[0001596532-20-000024:notes:249]
|  |  | December 31, |
|  |  | 2019 |  | 2018 |
| Deferred tax assets: |  |  |  |  |
| Intangible assets |  | 419,911 |  |  | — |  |
| Reserves and accruals not currently deductible |  | 71,945 |  |  | 77,373 |  |
| Tax credits |  | 54,867 |  |  | 57,793 |  |
| Lease financing obligation |  | 22,547 |  |  | — |  |
| Capitalized R&D expenses |  | 16,169 |  |  | 30,027 |  |
| Stock-based compensation |  | 15,856 |  |  | 19,186 |  |
| Net operating losses |  | 8,857 |  |  | 11,052 |  |
| Other |  | 3,950 |  |  | 3,943 |  |
| Gross deferred tax assets |  | 614,102 |  |  | 199,374 |  |
| Valuation allowance |  | (67,331 | ) |  | (56,724 | ) |
| Total deferred tax assets |  | 546,771 |  |  | 142,650 |  |
| Deferred tax liabilities: |  |  |  |  |
| US tax on foreign earnings |  | (326,967 | ) |  | — |  |
| Right of use asset |  | (20,038 | ) |  | — |  |
| Acquired intangibles |  | — |  |  | (13,401 | ) |
| Accrued liabilities |  | — |  |  | (5,190 | ) |
| Other |  | (2,451 | ) |  | (1,320 | ) |
| Total deferred tax liabilities |  | (349,456 | ) |  | (19,911 | ) |
| Net deferred tax assets |  | $ | 197,315 |  |  | $ | 122,739 |  |

[0001596532-20-000024:notes:250]
The following table presents the breakdown between non-current deferred tax assets and liabilities (in thousands):

[0001596532-20-000024:notes:251]
|  |  | December 31, |
|  |  | 2019 |  | 2018 |
| Deferred tax assets, non-current |  | $ | 452,025 |  |  | $ | 126,492 |  |
| Deferred tax liabilities, non-current |  | (254,710 | ) |  | (3,753 | ) |
| Total net deferred tax assets |  | $ | 197,315 |  |  |  | $122,739 |  |

[0001596532-20-000024:notes:252]
Recognition of deferred tax assets is appropriate when realization of these assets is more likely than not. We believe that all of the deferred tax assets were realizable with the exception of U.S. Federal capital losses, California, Canadian, and U.K. deferred tax assets. Therefore, a valuation allowance of $67.3 million and $56.7 million was recorded as of December 31, 2019 and 2018, respectively, against the U.S. Federal capital losses, California, Canadian, U.K. deferred tax assets as it is more likely than not that these assets will be not be recognized.

[0001596532-20-000024:notes:253]
As of December 31, 2019, we had $72.5 million and $38.4 million of net operating loss carryforwards for federal and state income tax purposes, from the acquisition of Mojo. These losses began to expire in 2019. For foreign jurisdictions, we had combined foreign net operating loss carryforwards of $12.2 million, which do not expire.

[0001596532-20-000024:notes:254]
We had state credit carryforwards of $109.0 million, which can be carried over indefinitely. For foreign jurisdictions, we had $1.6 million of Canadian scientific research and experimental development tax credit carry-forwards, which begin to expire in 2033.

[0001596532-20-000024:notes:255]
Utilization of the net operating losses and tax credit carryforwards may be subject to limitations due to ownership changes limitations provided in the Internal Revenue code and similar state or foreign provisions.

[0001596532-20-000024:notes:256]
The Tax Cuts and Jobs Act enacted on December 22, 2017 required a Transition Tax on previously untaxed accumulated and current foreign earnings.  Correspondingly, all undistributed earnings were deemed to be taxed and distributions of the unremitted earnings will not have any significant U.S. federal income tax impact.  We have not provided for any remaining tax effect, if any, of limited outside basis differences of our foreign subsidiaries based upon plans of future reinvestment. The determination of the future tax consequences of the remittance of these earnings is not practicable.

[0001596532-20-000024:notes:257]
Uncertain Tax Positions

[0001596532-20-000024:notes:258]
We recognize uncertain tax positions only to the extent that management believes that it is more likely than not the position will be sustained. The reconciliation of the beginning and ending amount of gross unrecognized tax benefits as of December 31, 2019, 2018 and 2017 was as follows (in thousands):

[0001596532-20-000024:notes:259]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Gross unrecognized tax benefits—beginning balance |  | $ | 74,436 |  |  | $ | 48,835 |  |  | $ | 26,915 |  |
| Increases related to tax positions taken in a prior year |  | 11,171 |  |  | 330 |  |  | 1,243 |  |
| Increases related to tax positions taken during current year |  | 22,714 |  |  | 27,413 |  |  | 22,202 |  |
| Decreases related to tax positions taken in a prior year |  | (89 | ) |  | (675 | ) |  | (21 | ) |
| Decreases related to settlements with taxing authorities |  | (12,388 | ) |  | — |  |  | — |  |
| Decreases related to lapse of statute of limitations |  | (2,120 | ) |  | (2,173 | ) |  | (1,504 | ) |
| Adjustment for acquisition |  | 82 |  |  | 706 |  |  | — |  |
| Gross unrecognized tax benefits—ending balance |  | $ | 93,806 |  |  | $ | 74,436 |  |  | $ | 48,835 |  |

[0001596532-20-000024:notes:260]
As of December 31, 2019, 2018 and 2017, the total amount of gross unrecognized tax benefits was $93.8 million, $74.4 million and $48.8 million, of which $28.5 million, $35.7 million and $26.8 million would affect our effective tax rate if recognized.

[0001596532-20-000024:notes:261]
Our policy is to recognize interest and penalties accrued on any unrecognized tax benefits as a component of income tax expense. We have recorded a net expense for interest and penalties of $0.2 million and $0.9 million in the years ended December 31, 2019 and 2018, respectively. As of December 31, 2019 and 2018, we recognized a liability for interest and penalties of $2.2 million and $1.9 million, respectively. 
The statute of limitations for Federal and most states remain open for 2016 and forward. Some states have net operating loss and tax credit carryforwards, and therefore remain open to examination. The majority of our foreign tax returns are open to audit under the statute of limitations of the respective foreign countries, in which the subsidiaries are located. It is possible that the amount of existing unrecognized tax benefits may decrease within the next 12 months as a result of statute of limitation lapses or payments to tax authorities in certain jurisdictions, however, an estimate of the range cannot be made.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-20-000024:notes:262]
Segment Information 
We have determined that we operate as one reportable segment. The following table represents revenue based on the customer’s location, as determined by the customer’s shipping address (in thousands):

[0001596532-20-000024:notes:263]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Americas |  | $ | 1,833,163 |  |  | $ | 1,550,453 |  |  | $ | 1,192,289 |  |
| Europe, Middle East and Africa |  | 381,651 |  |  | 414,069 |  |  | 299,547 |  |
| Asia Pacific |  | 195,892 |  |  | 186,847 |  |  | 154,350 |  |
| Total revenue |  | $ | 2,410,706 |  |  | $ | 2,151,369 |  |  | $ | 1,646,186 |  |

[0001596532-20-000024:notes:264]
Long lived assets, excluding intercompany receivables, investments in subsidiaries, privately held equity investments and deferred tax assets, net by location are summarized as follows (in thousands):

[0001596532-20-000024:notes:265]
|  |  | December 31, |
|  |  | 2019 |  | 2018 |
| United States |  | $ | 32,565 |  |  | $ | 69,238 |  |
| International |  | 6,708 |  |  | 6,117 |  |
| Total |  | $ | 39,273 |  |  | $ | 75,355 |  |


## us-gaap:PostemploymentBenefitsDisclosureTextBlock

[0001596532-20-000024:notes:266]
Post-Employment Benefits 
We have a 401(k) Plan that covers substantially all of our employees in the U.S.  Effective January 1, 2017, we have elected to match 100% of employees' contributions up to a maximum of 3% of an employee's annual salary. Matching contributions will be immediately vested. For the years ended December 31, 2019, 2018 and 2017 we contributed approximately $5.1 million, $4.6 million and $3.5 million for the matching contributions, respectively.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001596532-20-000024:notes:267]
Selected Quarterly Financial Information (Unaudited)
The following table sets forth selected unaudited quarterly consolidated statements of operations data for each of the quarters in the years ended December 31, 2019 and 2018:

[0001596532-20-000024:notes:268]
|  |  | Three Months Ended |
|  |  | Dec. 31, 2019 |  | Sep. 30, 2019 |  | Jun. 30, 2019 |  | Mar. 31, 2019 |  | Dec. 31, 2018 |  | Sep. 30, 2018 |  | Jun. 30, 2018 |  | Mar. 31, 2018 |
|  |  | (in thousands) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 447,498 |  |  | $ | 555,066 |  |  | $ | 513,171 |  |  | $ | 505,415 |  |  | $ | 503,235 |  |  | $ | 485,481 |  |  | $ | 444,767 |  |  | $ | 407,617 |  |
| Service |  | 105,048 |  |  | 99,349 |  |  | 95,150 |  |  | 90,009 |  |  | 92,491 |  |  | 77,828 |  |  | 75,078 |  |  | 64,872 |  |
| Total revenue |  | 552,546 |  |  | 654,415 |  |  | 608,321 |  |  | 595,424 |  |  | 595,726 |  |  | 563,309 |  |  | 519,845 |  |  | 472,489 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 175,476 |  |  | 218,220 |  |  | 200,534 |  |  | 198,152 |  |  | 204,507 |  |  | 187,764 |  |  | 171,622 |  |  | 156,691 |  |
| Service |  | 20,767 |  |  | 18,921 |  |  | 17,596 |  |  | 16,702 |  |  | 16,227 |  |  | 13,962 |  |  | 14,340 |  |  | 12,879 |  |
| Total cost of revenue |  | 196,243 |  |  | 237,141 |  |  | 218,130 |  |  | 214,854 |  |  | 220,734 |  |  | 201,726 |  |  | 185,962 |  |  | 169,570 |  |
| Gross profit |  | 356,303 |  |  | 417,274 |  |  | 390,191 |  |  | 380,570 |  |  | 374,992 |  |  | 361,583 |  |  | 333,883 |  |  | 302,919 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | 110,063 |  |  | 118,732 |  |  | 114,295 |  |  | 119,669 |  |  | 118,439 |  |  | 117,589 |  |  | 104,078 |  |  | 102,362 |  |
| Sales and marketing |  | 54,535 |  |  | 55,279 |  |  | 53,040 |  |  | 51,053 |  |  | 50,911 |  |  | 47,903 |  |  | 46,188 |  |  | 42,140 |  |
| General and administrative |  | 15,716 |  |  | 14,657 |  |  | 16,019 |  |  | 15,506 |  |  | 12,000 |  |  | 15,321 |  |  | 18,420 |  |  | 19,679 |  |
| Legal settlement |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 405,000 |  |  | — |  |
| Total operating expenses |  | 180,314 |  |  | 188,668 |  |  | 183,354 |  |  | 186,228 |  |  | 181,350 |  |  | 180,813 |  |  | 573,686 |  |  | 164,181 |  |
| Income (loss) from operations |  | 175,989 |  |  | 228,606 |  |  | 206,837 |  |  | 194,342 |  |  | 193,642 |  |  | 180,770 |  |  | (239,803 | ) |  | 138,738 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | — |  |  | — |  |  | — |  |  | — |  |  | (661 | ) |  | (673 | ) |  | (680 | ) |  | (687 | ) |
| Other income (expense), net |  | 11,183 |  |  | 19,169 |  |  | 13,811 |  |  | 12,333 |  |  | 5,509 |  |  | 9,292 |  |  | (1,489 | ) |  | 4,843 |  |
| Total other income (expense), net |  | 11,183 |  |  | 19,169 |  |  | 13,811 |  |  | 12,333 |  |  | 4,848 |  |  | 8,619 |  |  | (2,169 | ) |  | 4,156 |  |
| Income before income taxes |  | 187,172 |  |  | 247,775 |  |  | 220,648 |  |  | 206,675 |  |  | 198,490 |  |  | 189,389 |  |  | (241,972 | ) |  | 142,894 |  |
| Provision for (benefit from) income taxes |  | (73,520 | ) |  | 38,880 |  |  | 31,397 |  |  | 5,646 |  |  | 28,168 |  |  | 20,865 |  |  | (86,703 | ) |  | (1,644 | ) |
| Net income (loss) |  | $ | 260,692 |  |  | $ | 208,895 |  |  | $ | 189,251 |  |  | $ | 201,029 |  |  | $ | 170,322 |  |  | $ | 168,524 |  |  | $ | (155,269 | ) |  | $ | 144,538 |  |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.41 |  |  | $ | 2.73 |  |  | $ | 2.47 |  |  | $ | 2.65 |  |  | $ | 2.26 |  |  | $ | 2.25 |  |  | $ | (2.08 | ) |  | $ | 1.95 |  |
| Diluted |  | $ | 3.25 |  |  | $ | 2.59 |  |  | $ | 2.33 |  |  | $ | 2.47 |  |  | $ | 2.10 |  |  | $ | 2.08 |  |  | $ | (2.08 | ) |  | $ | 1.79 |  |


## us-gaap:SubsequentEventsTextBlock

[0001596532-20-000024:notes:269]
Subsequent Event (Unaudited)
Acquisition of Big Switch Networks

[0001596532-20-000024:notes:270]
On February 5, 2020, we completed the acquisition of Big Switch Networks, a network monitoring and Software Defined Networking (SDN) pioneer. The transaction will be included in our condensed consolidated financial statements in the quarter ended March 31, 2020 and will be financed from our existing cash balance.
