# ANET 8-K — 0001596532-20-000019 filed 2020-02-13

## item codes, every 8-K on or before 2020-02-14

- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2020-02-14

- none on or before 2020-02-14

## item 2.02 — earnings release, exhibit 99.1

[0001596532-20-000019:8k_2_02:1]
EX-99.1
2
ex991q419-earningsrele.htm
EXHIBIT 99.1

[0001596532-20-000019:8k_2_02:2]
Exhibit

[0001596532-20-000019:8k_2_02:3]
Exhibit 99.1

[0001596532-20-000019:8k_2_02:4]
Arista Networks, Inc. Reports Fourth Quarter and Year End 2019 Financial Results

[0001596532-20-000019:8k_2_02:5]
Acquires Big Switch Networks for Cloud Networking & Monitoring

[0001596532-20-000019:8k_2_02:6]
SANTA CLARA, Calif.- February 13, 2020 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large datacenter and campus environments, today announced financial results for its fourth quarter and year ended December 31, 2019.

[0001596532-20-000019:8k_2_02:7]
Fourth Quarter Financial Highlights

[0001596532-20-000019:8k_2_02:8]
| • | Revenue of $552.5 million, a decrease of 15.6% compared to the third quarter of 2019, and a decrease of 7.2% from the fourth quarter of 2018. |

[0001596532-20-000019:8k_2_02:9]
| • | GAAP gross margin of 64.5%, compared to GAAP gross margin of 63.8% in the third quarter of 2019 and 62.9% in the fourth quarter of 2018. |

[0001596532-20-000019:8k_2_02:10]
| • | Non-GAAP gross margin of 65.2%, compared to non-GAAP gross margin of 64.4% in the third quarter of 2019 and 64.1% in the fourth quarter of 2018. |

[0001596532-20-000019:8k_2_02:11]
| • | GAAP net income of $260.7 million, or $3.25 per diluted share, compared to GAAP net income of $170.3 million, or $2.10 per diluted share in the fourth quarter of 2018. |

[0001596532-20-000019:8k_2_02:12]
| • | Non-GAAP net income of $183.4 million, or $2.29 per diluted share, compared to non-GAAP net income of $182.2 million, or $2.25 per diluted share in the fourth quarter of 2018. |

[0001596532-20-000019:8k_2_02:13]
Full Year Financial Highlights

[0001596532-20-000019:8k_2_02:14]
| • | Revenue of $2.41 billion, an increase of 12.1% compared to fiscal year 2018. |

[0001596532-20-000019:8k_2_02:15]
| • | GAAP gross margin of 64.1%, compared to GAAP gross margin of 63.8% in fiscal year 2018. |

[0001596532-20-000019:8k_2_02:16]
| • | Non-GAAP gross margin of 64.7%, compared to non-GAAP gross margin of 64.4% in fiscal year 2018. |

[0001596532-20-000019:8k_2_02:17]
| • | GAAP net income of $859.9 million, or $10.63 per diluted share, compared to GAAP net income of $328.1 million, or $4.06 per diluted share, in fiscal year 2018. |

[0001596532-20-000019:8k_2_02:18]
| • | Non-GAAP net income of $786.8 million or $9.73 per diluted share, compared to non-GAAP net income of $643.3 million, or $7.96 per diluted share, in fiscal year 2018. |

[0001596532-20-000019:8k_2_02:19]
"Despite the volatility of cloud spend, 2019 marked the entry of Arista in the campus and mainstream enterprise.  Our cloud networking technology is being accepted in thousands of diverse enterprise customers. We are excited by our prospects in 2020 and committed to a multi-year foundation of growth, innovation and profitability,” stated Jayshree Ullal, Arista's President and CEO.

[0001596532-20-000019:8k_2_02:20]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, “We were pleased with the solid execution on earnings and cash flow in the quarter.”

[0001596532-20-000019:8k_2_02:21]
Arista today also announced that it has acquired Big Switch Networks, a network monitoring and SDN (Software Defined Networking) pioneer for the past decade.

[0001596532-20-000019:8k_2_02:22]
Fourth Quarter Company Highlights

[0001596532-20-000019:8k_2_02:23]
| • | Arista Enhances Cloud Networking with CloudEOS - Arista introduced Arista CloudEOS™, delivering two new offerings that solve critical networking challenges in multi cloud and cloud native environments: enabling an enterprise-class networking experience with consistent segmentation, telemetry, monitoring, provisioning and troubleshooting from campus to data center to cloud. |

[0001596532-20-000019:8k_2_02:24]
| • | Arista Networks Provides SK Telecom With High-Speed Platforms for 5G-Based Data Transmission Service - Arista announced that it is providing network platforms for SK Telecom’s 5G network. SK Telecom will be building a high capacity leaf-spine based data center network environment leveraging VXLAN/EVPN for virtualization, scalability and availability, providing customers with reliable high-speed network services. |

[0001596532-20-000019:8k_2_02:25]
| • | Vocus Group, Australia’s specialist fibre and network solutions provider announced Arista Networks has been appointed the supplier of Vocus’ Layer 2 and Layer 3 network equipment. |

[0001596532-20-000019:8k_2_02:26]
2019 Company Highlights

[0001596532-20-000019:8k_2_02:27]
| • | This is the fifth consecutive year Arista Networks has been recognized in the Leaders Quadrant of the 2019 Magic Quadrant for Data Center Networking, published on 15 July 2019. |

[0001596532-20-000019:8k_2_02:28]
| • | Arista Introduced Open Cloud-Scale Platform - The Arista 7360X Series is a radically new and disruptive platform that doubles system density while reducing power consumption and cost; codeveloped with Facebook. |

[0001596532-20-000019:8k_2_02:29]
| • | Arista Delivers Universal 400G Platforms for Cloud Network Transformation - The new Arista 7800R family addresses the needs of the most demanding 400G cloud networks together with the next generation of the Arista 7500R and 7280R Series. The new platforms support 100G and 400G Ethernet with compelling throughput, density and price-performance and offer new telemetry and intelligence. |

[0001596532-20-000019:8k_2_02:30]
| • | Arista Cognitive Cloud Networking Redefines the Campus - Arista Networks announced an expansion of the cognitive campus portfolio with unified wired and wireless campus edge products designed to address transitional changes as the enterprise moves to an IoT (Internet of Things)-ready campus. |

[0001596532-20-000019:8k_2_02:31]
| • | Arista Networks announced CloudVision 2019, building upon Arista’s cognitive management plane. The CloudVision 2019 release brings new capabilities and integrations, helping customers with operational cost reduction, risk management, and agility in network operations. |

[0001596532-20-000019:8k_2_02:32]
| • | Arista Introduced Enhanced Ultra-low Latency, High-precision Network Application Platforms - the Arista 7130L Series is the next-generation ultra-low latency, high-precision network application platform, with deterministic 5 nanosecond switching and virtually undetectable jitter. |

[0001596532-20-000019:8k_2_02:33]
Financial Outlook

[0001596532-20-000019:8k_2_02:34]
For the first quarter of 2020, we expect:

[0001596532-20-000019:8k_2_02:35]
| • | Revenue between $522 million to $532 million; |

[0001596532-20-000019:8k_2_02:36]
| • | Non-GAAP gross margin of approximately 63%, and |

[0001596532-20-000019:8k_2_02:37]
| • | Non-GAAP operating margin of approximately 34%. |

[0001596532-20-000019:8k_2_02:38]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below under "Non-GAAP Financial Measures").

[0001596532-20-000019:8k_2_02:39]
Prepared Materials and Conference Call Information

[0001596532-20-000019:8k_2_02:40]
Arista executives will discuss the fourth quarter and year end 2019 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (833) 287-7905 in the United States or (647) 689-4469 from outside the US. The Conference ID is 1579521.

[0001596532-20-000019:8k_2_02:41]
The financial results conference call will also be available via live webcast on our investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-20-000019:8k_2_02:42]
Forward-Looking Statements

[0001596532-20-000019:8k_2_02:43]
This press release contains “forward-looking statements” regarding our future performance, including quotations from  management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the first quarter of fiscal year 2020, and statements regarding the introduction of new products and our leadership in cloud networking. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: the evolution and growth of the cloud networking market and the adoption by end customers of Arista's cloud networking solutions; rapid technological and market change; Arista’s customer concentration; our ability to attract new large end customers or sell additional products and services to existing customers; competition in our products and services markets; changes in Arista's customers’ demand for our products and services; changes in customer order patterns or customer mix; requests by large end customers for more favorable terms and conditions; general market, political, economic and business conditions such as the recent U.S. trade wars with China and the impact of public health epidemics like the coronavirus currently affecting China; dependence on the introduction and market acceptance of new product offerings and standards including our 400G products as well as our campus and WiFi products; declines in the sales prices of our products and services; the timing of orders and manufacturing and customer lead times; and the benefits and impact of acquisitions; and other future events. Additional risks and uncertainties that could affect Arista can be found in our most recent Quarterly Report on Form 10-Q filed with the SEC on November 1, 2019, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/.  All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-20-000019:8k_2_02:44]
Source: Gartner, Magic Quadrant for Data Center Networking, Andrew Lerner, Mike Toussaint, Jonathan Forest, 15 July 2019.  Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001596532-20-000019:8k_2_02:45]
Non-GAAP Financial Measures

[0001596532-20-000019:8k_2_02:46]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, litigation-related expenses, amortization of acquisition-related intangible assets, other non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-20-000019:8k_2_02:47]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures

[0001596532-20-000019:8k_2_02:48]
3

[0001596532-20-000019:8k_2_02:49]
presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-20-000019:8k_2_02:50]
The company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. The company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. A reconciliation of the non-GAAP financial measures guidance to the corresponding GAAP measures on a forward-looking basis is not available because stock-based compensation expense is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-20-000019:8k_2_02:51]
About Arista Networks

[0001596532-20-000019:8k_2_02:52]
Arista Networks pioneered software-driven, cognitive cloud networking for large-scale datacenter and campus environments. Arista’s award-winning platforms redefine and deliver availability, agility, automation, analytics, and security. Arista has shipped more than twenty million cloud networking ports worldwide with CloudVision and EOS, an advanced network operating system. Committed to open standards across private, public and hybrid cloud solutions, Arista products are supported worldwide directly and through partners.

[0001596532-20-000019:8k_2_02:53]
ARISTA, EOS, CloudEOS and CloudVision are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners. Additional information and resources can be found at https://www.arista.com.

[0001596532-20-000019:8k_2_02:54]
| Investor Contacts |
| Curtis McKeeCorporate and Investor Development(408) 547-5701curtism@arista.com |
| Charles YagerProduct and Investor Advocacy(408) 547-5892cyager@arista.com |

[0001596532-20-000019:8k_2_02:55]
ARISTA NETWORKS, INC.

[0001596532-20-000019:8k_2_02:56]
Condensed Consolidated Statements of Operations

[0001596532-20-000019:8k_2_02:57]
(Unaudited in thousands, except per share amounts)

[0001596532-20-000019:8k_2_02:58]
|  |  | Three Months Ended December 31, |  | Twelve Months Ended December 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 447,498 |  |  | $ | 503,235 |  |  | $ | 2,021,150 |  |  | $ | 1,841,100 |  |
| Service |  | 105,048 |  |  | 92,491 |  |  | 389,556 |  |  | 310,269 |  |
| Total revenue |  | 552,546 |  |  | 595,726 |  |  | 2,410,706 |  |  | 2,151,369 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 175,476 |  |  | 204,507 |  |  | 792,382 |  |  | 720,584 |  |
| Service |  | 20,767 |  |  | 16,227 |  |  | 73,986 |  |  | 57,408 |  |
| Total cost of revenue |  | 196,243 |  |  | 220,734 |  |  | 866,368 |  |  | 777,992 |  |
| Total gross profit |  | 356,303 |  |  | 374,992 |  |  | 1,544,338 |  |  | 1,373,377 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 110,063 |  |  | 118,439 |  |  | 462,759 |  |  | 442,468 |  |
| Sales and marketing |  | 54,535 |  |  | 50,911 |  |  | 213,907 |  |  | 187,142 |  |
| General and administrative |  | 15,716 |  |  | 12,000 |  |  | 61,898 |  |  | 65,420 |  |
| Legal settlement |  | — |  |  | — |  |  | — |  |  | 405,000 |  |
| Total operating expenses |  | 180,314 |  |  | 181,350 |  |  | 738,564 |  |  | 1,100,030 |  |
| Income from operations |  | 175,989 |  |  | 193,642 |  |  | 805,774 |  |  | 273,347 |  |
| Other income (expense), net |  | 11,183 |  |  | 4,848 |  |  | 56,496 |  |  | 15,454 |  |
| Income before income taxes |  | 187,172 |  |  | 198,490 |  |  | 862,270 |  |  | 288,801 |  |
| Provision for (benefit from) income taxes |  | (73,520 | ) |  | 28,168 |  |  | 2,403 |  |  | (39,314 | ) |
| Net income |  | $ | 260,692 |  |  | $ | 170,322 |  |  | $ | 859,867 |  |  | $ | 328,115 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 260,589 |  |  | $ | 170,211 |  |  | $ | 859,444 |  |  | $ | 327,926 |  |
| Diluted |  | $ | 260,594 |  |  | $ | 170,218 |  |  | $ | 859,468 |  |  | $ | 327,941 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.41 |  |  | $ | 2.26 |  |  | $ | 11.26 |  |  | $ | 4.39 |  |
| Diluted |  | $ | 3.25 |  |  | $ | 2.10 |  |  | $ | 10.63 |  |  | $ | 4.06 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | 76,345 |  |  | 75,473 |  |  | 76,312 |  |  | 74,750 |  |
| Diluted |  | 80,261 |  |  | 80,928 |  |  | 80,879 |  |  | 80,844 |  |

[0001596532-20-000019:8k_2_02:59]
5

[0001596532-20-000019:8k_2_02:60]
ARISTA NETWORKS, INC.

[0001596532-20-000019:8k_2_02:61]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-20-000019:8k_2_02:62]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-20-000019:8k_2_02:63]
|  |  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| GAAP gross profit |  | $ | 356,303 |  |  | $ | 374,992 |  |  | $ | 1,544,338 |  |  | $ | 1,373,377 |  |
| GAAP gross margin |  | 64.5 | % |  | 62.9 | % |  | 64.1 | % |  | 63.8 | % |
| Stock-based compensation expense |  | 1,253 |  |  | 1,381 |  |  | 4,637 |  |  | 5,087 |  |
| Intangible asset amortization |  | 2,626 |  |  | 2,626 |  |  | 10,503 |  |  | 3,824 |  |
| Acquisition-related costs |  | — |  |  | 3,138 |  |  | — |  |  | 3,138 |  |
| Non-GAAP gross profit |  | $ | 360,182 |  |  | $ | 382,137 |  |  | $ | 1,559,478 |  |  | $ | 1,385,426 |  |
| Non-GAAP gross margin |  | 65.2 | % |  | 64.1 | % |  | 64.7 | % |  | 64.4 | % |
| GAAP income from operations |  | $ | 175,989 |  |  | $ | 193,642 |  |  | $ | 805,774 |  |  | $ | 273,347 |  |
| Stock-based compensation expense |  | 26,435 |  |  | 24,619 |  |  | 101,280 |  |  | 91,202 |  |
| Litigation expense (benefit) |  | 333 |  |  | (3,988 | ) |  | 2,295 |  |  | 6,566 |  |
| Legal settlement (1) |  | — |  |  | — |  |  | — |  |  | 405,000 |  |
| Intangible asset amortization |  | 3,084 |  |  | 3,500 |  |  | 13,375 |  |  | 5,110 |  |
| Acquisition-related costs |  | — |  |  | 4,313 |  |  | — |  |  | 7,745 |  |
| Non-GAAP income from operations |  | $ | 205,841 |  |  | $ | 222,086 |  |  | $ | 922,724 |  |  | $ | 788,970 |  |
| Non-GAAP operating margin |  | 37.3 | % |  | 37.3 | % |  | 38.3 | % |  | 36.7 | % |
| GAAP net income |  | $ | 260,692 |  |  | $ | 170,322 |  |  | $ | 859,867 |  |  | $ | 328,115 |  |
| Stock-based compensation expense |  | 26,435 |  |  | 24,619 |  |  | 101,280 |  |  | 91,202 |  |
| Litigation expense (benefit) |  | 333 |  |  | (3,988 | ) |  | 2,295 |  |  | 6,566 |  |
| Legal settlement (1) |  | — |  |  | — |  |  | — |  |  | 405,000 |  |
| Intangible asset amortization |  | 3,084 |  |  | 3,500 |  |  | 13,375 |  |  | 5,110 |  |
| Acquisition-related costs |  | — |  |  | 4,313 |  |  | — |  |  | 7,745 |  |
| (Gain) loss on investment in privately-held companies |  | — |  |  | 4,700 |  |  | (5,427 | ) |  | 13,800 |  |
| Acquisition-related tax expense |  | — |  |  | — |  |  | — |  |  | 5,853 |  |
| Altera stock-based tax charge (2) |  | — |  |  | — |  |  | 9,781 |  |  | — |  |
| Tax benefit on intra-entity IP transfer (3) |  | (85,819 | ) |  | — |  |  | (85,819 | ) |  | — |  |
| Tax benefit on stock-based awards |  | (16,232 | ) |  | (8,227 | ) |  | (89,415 | ) |  | (92,675 | ) |
| Impact of the U.S. Tax Cuts and Jobs Act |  | — |  |  | (12,632 | ) |  | — |  |  | (12,632 | ) |
| Income tax effect on non-GAAP exclusions |  | (5,045 | ) |  | (429 | ) |  | (19,093 | ) |  | (114,769 | ) |
| Non-GAAP net income |  | $ | 183,448 |  |  | $ | 182,178 |  |  | $ | 786,844 |  |  | $ | 643,315 |  |
| GAAP diluted net income per share attributable to common stockholders |  | $ | 3.25 |  |  | $ | 2.10 |  |  | $ | 10.63 |  |  | $ | 4.06 |  |
| Non-GAAP adjustments to net income |  | (0.96 | ) |  | 0.15 |  |  | (0.90 | ) |  | 3.90 |  |
| Non-GAAP diluted net income per share |  | $ | 2.29 |  |  | $ | 2.25 |  |  | $ | 9.73 |  |  | $ | 7.96 |  |
| Weighted-average shares used in computing GAAP and Non-GAAP diluted net income per share attributable to common stockholders |  | 80,261 |  |  | 80,928 |  |  | 80,879 |  |  | 80,844 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,253 |  |  | $ | 1,381 |  |  | $ | 4,637 |  |  | $ | 5,087 |  |
| Research and development |  | 13,897 |  |  | 13,505 |  |  | 53,068 |  |  | 48,205 |  |
| Sales and marketing |  | 7,705 |  |  | 6,224 |  |  | 29,168 |  |  | 24,995 |  |
| General and administrative |  | 3,580 |  |  | 3,509 |  |  | 14,407 |  |  | 12,915 |  |
| Total |  | $ | 26,435 |  |  | $ | 24,619 |  |  | $ | 101,280 |  |  | $ | 91,202 |  |

[0001596532-20-000019:8k_2_02:64]
___________________

[0001596532-20-000019:8k_2_02:65]
(1) Represents one-time charges associated with the settlement of our lawsuit with Cisco on August 6, 2018.

[0001596532-20-000019:8k_2_02:66]
(2) Represents a discrete income tax expense related to stock-based compensation as a result of an opinion on Altera Corporation and Subsidiaries vs. Commissioner on Internal Revenue issued by the Court of Appeals for the Ninth Circuit on June 7, 2019.

[0001596532-20-000019:8k_2_02:67]
(3) Represents a one-time tax benefit of $85.8 million upon completion of an intra-entity transaction to sell our non-Americas economic and beneficial intellectual property rights in the current quarter.

[0001596532-20-000019:8k_2_02:68]
7

[0001596532-20-000019:8k_2_02:69]
ARISTA NETWORKS, INC.

[0001596532-20-000019:8k_2_02:70]
Condensed Consolidated Balance Sheets

[0001596532-20-000019:8k_2_02:71]
(Unaudited, in thousands)

[0001596532-20-000019:8k_2_02:72]
|  |  | December 31, 2019 |  | December 31, 2018 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,111,286 |  |  | $ | 649,950 |  |
| Marketable securities |  | 1,613,082 |  |  | 1,306,197 |  |
| Accounts receivable |  | 391,987 |  |  | 331,777 |  |
| Inventories |  | 243,825 |  |  | 264,557 |  |
| Prepaid expenses and other current assets |  | 111,456 |  |  | 162,321 |  |
| Total current assets |  | 3,471,636 |  |  | 2,714,802 |  |
| Property and equipment, net |  | 39,273 |  |  | 75,355 |  |
| Acquisition-related intangible assets, net |  | 45,235 |  |  | 58,610 |  |
| Goodwill |  | 54,855 |  |  | 53,684 |  |
| Investments |  | 4,150 |  |  | 30,336 |  |
| Operating lease right-of-use assets |  | 87,770 |  |  | — |  |
| Deferred tax assets |  | 452,025 |  |  | 126,492 |  |
| Other assets |  | 30,346 |  |  | 22,704 |  |
| TOTAL ASSETS |  | $ | 4,185,290 |  |  | $ | 3,081,983 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 92,105 |  |  | $ | 93,757 |  |
| Accrued liabilities |  | 140,249 |  |  | 123,254 |  |
| Deferred revenue |  | 312,668 |  |  | 358,586 |  |
| Other current liabilities |  | 52,052 |  |  | 30,907 |  |
| Total current liabilities |  | 597,074 |  |  | 606,504 |  |
| Income taxes payable |  | 55,485 |  |  | 36,167 |  |
| Operating lease liabilities, non-current |  | 83,022 |  |  | — |  |
| Finance lease liabilities, non-current |  | — |  |  | 35,431 |  |
| Deferred revenue, non-current |  | 262,620 |  |  | 228,641 |  |
| Deferred tax liabilities, non-current |  | 254,710 |  |  | 3,753 |  |
| Other long-term liabilities |  | 37,693 |  |  | 28,098 |  |
| TOTAL LIABILITIES |  | 1,290,604 |  |  | 938,594 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 8 |  |  | 8 |  |
| Additional paid-in capital |  | 1,106,305 |  |  | 956,572 |  |
| Retained earnings (1) |  | 1,788,230 |  |  | 1,190,803 |  |
| Accumulated other comprehensive income (loss) |  | 143 |  |  | (3,994 | ) |
| TOTAL STOCKHOLDERS’ EQUITY |  | 2,894,686 |  |  | 2,143,389 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 4,185,290 |  |  | $ | 3,081,983 |  |
| ______________________ |  |  |  |  |
| (1) We adopted new lease accounting guidance under Accounting Standard Codification Topic 842 - Leases (“ASC 842”), which resulted in a cumulative-effect adjustment of $3.7 million to retained earnings as of January 1, 2019. |

[0001596532-20-000019:8k_2_02:73]
8

[0001596532-20-000019:8k_2_02:74]
ARISTA NETWORKS, INC.

[0001596532-20-000019:8k_2_02:75]
Condensed Consolidated Statements of Cash Flows

[0001596532-20-000019:8k_2_02:76]
(Unaudited, in thousands)

[0001596532-20-000019:8k_2_02:77]
|  |  | Twelve Months Ended December 31, |
|  |  | 2019 |  | 2018 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 859,867 |  |  | $ | 328,115 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 32,849 |  |  | 27,671 |  |
| Noncash lease expense |  | 16,179 |  |  | — |  |
| Stock-based compensation |  | 101,280 |  |  | 91,202 |  |
| Deferred income taxes |  | (75,741 | ) |  | (57,896 | ) |
| (Gain) loss on investments in privately-held companies, net |  | (5,427 | ) |  | 13,800 |  |
| Amortization (accretion) of investment premiums (discounts) |  | (6,771 | ) |  | (3,360 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (60,210 | ) |  | (77,916 | ) |
| Inventories |  | 20,927 |  |  | 51,054 |  |
| Prepaid expenses and other current assets |  | 54,259 |  |  | 21,411 |  |
| Other assets |  | (8,112 | ) |  | (3,389 | ) |
| Accounts payable |  | (1,937 | ) |  | 39,337 |  |
| Accrued liabilities |  | 16,366 |  |  | (14,786 | ) |
| Deferred revenue |  | (11,939 | ) |  | 70,533 |  |
| Income taxes payable |  | 23,523 |  |  | (112 | ) |
| Other liabilities |  | 7,921 |  |  | 17,455 |  |
| Net cash provided by operating activities |  | 963,034 |  |  | 503,119 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 1,208,717 |  |  | 547,797 |  |
| Purchases of marketable securities |  | (1,503,893 | ) |  | (1,174,259 | ) |
| Business acquisitions, net of cash acquired |  | (1,365 | ) |  | (96,821 | ) |
| Purchases of property and equipment |  | (15,751 | ) |  | (23,830 | ) |
| Investments in privately-held companies |  | 28,220 |  |  | (8,000 | ) |
| Net cash used in investing activities |  | (284,072 | ) |  | (755,113 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Principal payments of lease financing obligations |  | — |  |  | (1,929 | ) |
| Proceeds from issuance of common stock under equity plans |  | 57,378 |  |  | 53,658 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (9,200 | ) |  | (8,878 | ) |
| Repurchase of common stock |  | (266,142 | ) |  | — |  |
| Net cash provided by (used in) financing activities |  | (217,964 | ) |  | 42,851 |  |
| Effect of exchange rate changes |  | 353 |  |  | (1,390 | ) |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 461,351 |  |  | (210,533 | ) |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 654,164 |  |  | 864,697 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 1,115,515 |  |  | $ | 654,164 |  |

[0001596532-20-000019:8k_2_02:78]
9
