# ANET MD&A — 0001596532-22-000026


## mdna

[0001596532-22-000026:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001596532-22-000026:mdna:2]
Overview

[0001596532-22-000026:mdna:3]
Arista Networks pioneered data-driven, cognitive cloud networking for large-scale data center and campus workspace environments. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our Ethernet switching and routing platforms. We are a leader in cloud networking solutions delivering high performance, scalability, availability, programmability, workload orchestration, automation and visibility. In recent years, we have sought to bring the operational consistency and principles of cloud networking to the broader enterprise and campus markets with our Cognitive Cloud Networking, extending EOS across the enterprise data center and campus wired and wireless workspaces.

[0001596532-22-000026:mdna:4]
We generate revenue primarily from sales of our switching and routing platforms, which incorporate our EOS software, and related network applications. We also generate revenue from post-contract support ("PCS"), which end customers typically purchase in conjunction with our products, and renewals of PCS. We sell our products through both our direct sales force and our channel partners. As of December 31, 2021, we had delivered our cloud networking solutions to over 8,000 end customers worldwide. Our end customers span a range of industries and include large internet companies, service providers, financial services organizations, government agencies, media and entertainment companies, and others.

[0001596532-22-000026:mdna:5]
Historically, large purchases by a relatively limited number of end customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large end customers primarily due to changes in demand patterns specific to these customers, the time it takes these end customers to evaluate, test, qualify and accept our products, and the overall complexity of these large orders. We expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis.  For example, sales to our end customers Microsoft and Meta Platforms in fiscal 2019 collectively represented 40% of our total revenue, whereas sales to our end customer Microsoft in fiscal 2020 and 2021 amounted to 21.5% and 15.0% of our revenues, respectively, with our end customer Meta Platforms representing less than 10% of our revenues in both fiscal 2020 and 2021. While we experienced some decline in overall revenue in 2020, the decline in revenue from these large end customers in 2021 was more than offset by stronger sales to our enterprise and other cloud and service provider customers.  In addition, we typically provide pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur. We expect customer concentration with these large end customers to be cyclical and linked to new product introductions and customer investment cycles.

[0001596532-22-000026:mdna:6]
We believe that cloud computing represents a fundamental shift from traditional legacy network architectures. As organizations of all sizes have moved workloads to the cloud, spending on cloud and next-generation data centers has increased rapidly, while traditional legacy IT spending has grown more slowly. Our cloud networking platforms are well positioned to address the growing cloud networking market, and to address increasing performance requirements driven by the growing number of connected devices, as well as the need for constant connectivity and access to data and applications.

[0001596532-22-000026:mdna:7]
The markets for cloud networking solutions are highly competitive and characterized by rapidly changing technology, changing end-customer needs, evolving industry standards, frequent introductions of new products and services, and industry consolidation. We expect competition to intensify in the future as the market for cloud networking expands and existing competitors and new market entrants introduce new products or enhance existing products.  Our future success is dependent upon our ability to continue to evolve and adapt to our rapidly changing environment.   We must also continue to develop market-leading products and features that address the needs of our existing and new customers, and increase sales in the enterprise data center switching, and campus workspace markets.  We intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new end customers more effectively, increase sales to existing customers, and provide services and support.  In addition, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our ability to rapidly develop new features and applications.

[0001596532-22-000026:mdna:8]
Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic with respect to the underlying merchant silicon architecture. The programmability of EOS has allowed us to expand our software applications to address the ever-increasing demands of cloud networking, including workflow automation, network visibility, analytics and network detection and response, and has further allowed us to integrate rapidly with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.  This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We work closely with third-party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third-party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-22-000026:mdna:9]
COVID-19 Update

[0001596532-22-000026:mdna:10]
The global coronavirus (“COVID-19”) pandemic continues to disrupt and have unpredictable impacts to our global society, economies, financial markets and business activities. We are actively monitoring and evaluating developments as the situation evolves and will continue to take further actions in our approach to address COVID-19. We have prioritized the protection of our employees during this pandemic and, as a result, our offices across the globe have remained closed, limiting access to facilities-based employees and a limited number of employees on a voluntary basis, and continue to impose some travel restrictions.  In addition, our manufacturing and supply chain operations have experienced significant constraints, with component shortages, increased supply chain costs and delays broadly impacting the industry as a whole. We continue to work closely with our contract manufacturers and supply chain partners who have experienced delays in component sourcing, workforce disruptions and governmental restrictions on the production and export of their products. Although we have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, these delays have negatively impacted our ability to supply products to our customers on a timely basis. We have increased our purchase commitments and expect to continue to invest in working capital to address delays in component sourcing and the risk of future COVID-19 related supply chain disruptions, but we cannot be certain that such delays or disruptions will not occur.

[0001596532-22-000026:mdna:11]
The extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, including the duration of the pandemic, the breadth and duration of governmental containment measures such as workplace, travel and social distancing restrictions, as well as the reauthorization of or increase in such measures in the event of spikes in COVID-19 infection rates, the success of the COVID-19 vaccination deployment, and the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which are uncertain and cannot be predicted. However, any continued or renewed disruption in manufacturing and supply resulting from the COVID-19 pandemic or related containment measures could negatively impact our business. We also believe that any extended or renewed COVID-19 related economic disruption could have a negative impact on demand from our customers in future periods. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

[0001596532-22-000026:mdna:12]
Results of Operations

[0001596532-22-000026:mdna:13]
Year Ended December 31, 2021 Compared to Year Ended December 31, 2020

[0001596532-22-000026:mdna:14]
Revenue, Cost of Revenue and Gross Margin (in thousands, except percentages)

[0001596532-22-000026:mdna:15]
|  |  | Year Ended December 31, |  |  |
|  |  | 2021 |  | 2020 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,377,727 |  |  | 80.7 | % |  | $ | 1,830,842 |  |  | 79.0 | % |  | $ | 546,885 |  |  | 29.9 | % |
| Service |  | 570,310 |  |  | 19.3 |  |  | 486,670 |  |  | 21.0 |  |  | 83,640 |  |  | 17.2 |  |
| Total revenue |  | 2,948,037 |  |  | 100.0 |  |  | 2,317,512 |  |  | 100.0 |  |  | 630,525 |  |  | 27.2 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 958,363 |  |  | 32.5 |  |  | 749,962 |  |  | 32.4 |  |  | 208,401 |  |  | 27.8 |  |
| Service |  | 108,895 |  |  | 3.7 |  |  | 85,664 |  |  | 3.7 |  |  | 23,231 |  |  | 27.1 |  |
| Total cost of revenue |  | 1,067,258 |  |  | 36.2 |  |  | 835,626 |  |  | 36.1 |  |  | 231,632 |  |  | 27.7 |  |
| Gross profit |  | $ | 1,880,779 |  |  | 63.8 | % |  | $ | 1,481,886 |  |  | 63.9 | % |  | $ | 398,893 |  |  | 26.9 | % |
| Gross margin |  | 63.8 | % |  |  |  | 63.9 | % |  |  |  |  |  |  |

[0001596532-22-000026:mdna:16]
Revenue by Geography (in thousands, except percentages)

[0001596532-22-000026:mdna:17]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | % of Total |  | 2020 |  | % of Total |
| Americas |  | $ | 2,156,183 |  |  | 73.2 | % |  | $ | 1,771,992 |  |  | 76.5 | % |
| Europe, Middle East and Africa |  | 486,836 |  |  | 16.5 |  |  | 326,729 |  |  | 14.1 |  |
| Asia-Pacific |  | 305,018 |  |  | 10.3 |  |  | 218,791 |  |  | 9.4 |  |
| Total revenue |  | $ | 2,948,037 |  |  | 100.0 | % |  | $ | 2,317,512 |  |  | 100.0 | % |

[0001596532-22-000026:mdna:18]
Revenue

[0001596532-22-000026:mdna:19]
Product revenue primarily consists of sales of our switching and routing products, and software licenses.  Service revenue is primarily derived from sales of PCS contracts, which is typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing, size, and complexity of orders, especially with respect to our large end customers.

[0001596532-22-000026:mdna:20]
Product revenue increased by $546.9 million, or 29.9%, in the year ended December 31, 2021 compared to 2020, which reflected stronger demand for our products from new and existing customers, and broader market acceptance of our enterprise and campus products.  Service revenue increased by $83.6 million, or 17.2%, in the year ended December 31, 2021 compared to 2020, as a result of continued growth in initial and renewal PCS contracts as our customer installed base continued to expand. International revenues increased from 23.5% in 2020 to 26.8% in 2021, which was mostly driven by increased shipments to our large end customers in the EMEA region.

[0001596532-22-000026:mdna:21]
Cost of Revenue and Gross Margin

[0001596532-22-000026:mdna:22]
Cost of product revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs of our manufacturing operations, and other costs associated with manufacturing our products and managing our inventory. Cost of service revenue primarily consists of personnel and other costs associated with our global customer support and services organizations.

[0001596532-22-000026:mdna:23]
Cost of revenue increased by $231.6 million or 27.7% for the year ended December 31, 2021 compared to 2020. These increases were primarily driven by a corresponding increase in product and service revenues, coupled with an increase in supply chain costs due to increased production capacity and higher volumes.

[0001596532-22-000026:mdna:24]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a

[0001596532-22-000026:mdna:25]
variety of factors, including pricing pressure on our products and services due to competition, the mix of sales to large end customers who generally receive lower pricing, manufacturing-related costs, including costs associated with supply chain sourcing activities, merchant silicon costs, the mix of products sold, and excess/obsolete inventory write-downs, including charges for excess/obsolete component inventory held by our contract manufacturers. We expect our gross margins to fluctuate over time, depending on the factors described above.

[0001596532-22-000026:mdna:26]
Gross margin slightly decreased from 63.9% for the year ended December 31, 2020 to 63.8% for the year ended December 31, 2021. The change in gross margin was unfavorably impacted by higher supply chain costs, as well as increased service costs to support our growing installed base. These unfavorable impacts were mostly offset by improved product margins due to a reduced proportion of our sales to larger end customers who generally receive larger discounts.

[0001596532-22-000026:mdna:27]
Operating Expenses (in thousands, except percentages)

[0001596532-22-000026:mdna:28]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. The largest component of our operating expenses is personnel costs. Personnel costs consist of wages, benefits, bonuses and, with respect to sales and marketing expenses, sales commissions. Personnel costs also include stock-based compensation and travel expenses.

[0001596532-22-000026:mdna:29]
|  |  | Year Ended December 31, |  |  |
|  |  | 2021 |  | 2020 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 586,752 |  |  | 19.9 | % |  | $ | 486,594 |  |  | 20.9 | % |  | $ | 100,158 |  |  | 20.6 | % |
| Sales and marketing |  | 286,171 |  |  | 9.7 |  |  | 229,366 |  |  | 9.9 |  |  | 56,805 |  |  | 24.8 |  |
| General and administrative |  | 83,117 |  |  | 2.8 |  |  | 66,242 |  |  | 2.9 |  |  | 16,875 |  |  | 25.5 |  |
| Total operating expenses |  | $ | 956,040 |  |  | 32.4 | % |  | $ | 782,202 |  |  | 33.7 | % |  | $ | 173,838 |  |  | 22.2 | % |

[0001596532-22-000026:mdna:30]
Research and development.

[0001596532-22-000026:mdna:31]
Research and development expenses consist primarily of personnel costs, prototype expenses, third-party engineering costs, and an allocated portion of facility and IT costs. Our research and development efforts are focused on new product development and maintaining and developing additional functionality for our existing products, including new releases and upgrades to our EOS software and applications. We expect our research and development expenses to increase in absolute dollars as we continue to invest in software development in order to expand the capabilities of our cloud networking platform, introduce new products and features, and continue to invest in our technology.

[0001596532-22-000026:mdna:32]
Research and development expenses increased by $100.2 million, or 20.6%, for the year ended December 31, 2021 compared to 2020. The increase was primarily due to a $67.0 million increase in personnel costs driven by an increase in headcount, and a $32.3 million increase in new product introduction costs, including third-party engineering and other product development costs.

[0001596532-22-000026:mdna:33]
Sales and marketing.

[0001596532-22-000026:mdna:34]
Sales and marketing expenses consist primarily of personnel costs, marketing, trade shows, and other promotional activities, and an allocated portion of facility and IT costs. We expect our sales and marketing expenses to increase in absolute dollars as we continue to expand our sales and marketing efforts worldwide.

[0001596532-22-000026:mdna:35]
Sales and marketing expenses increased by $56.8 million, or 24.8%, for the year ended December 31, 2021 compared to 2020. The increase was primarily driven by increased headcount and higher sales volume resulting in increased compensation costs, including salaries, sales incentive compensation and stock-based compensation.

[0001596532-22-000026:mdna:36]
General and administrative.

[0001596532-22-000026:mdna:37]
General and administrative expenses consist primarily of personnel costs and professional services costs. General and administrative personnel costs include those for our executive, finance, human resources and legal functions. Our professional services costs are primarily related to external legal, accounting, and tax services.

[0001596532-22-000026:mdna:38]
General and administrative expenses increased by $16.9 million, or 25.5%, for the year ended December 31, 2021 compared to 2020. The increase was driven by a $17.7 million increase in personnel costs, primarily stock-based compensation, which was partially offset by a decrease in non-recurring acquisition-related expenses of $4.2 million resulting from the acquisitions of Big Switch and Awake Security in 2020.

[0001596532-22-000026:mdna:39]
Other Income, Net (in thousands, except percentages)

[0001596532-22-000026:mdna:40]
Other income, net consists primarily of interest income from our cash, cash equivalents and marketable securities, gains and losses on our investments in privately-held companies and marketable securities, and foreign currency transaction gains and losses.  We expect other income, net may fluctuate in the future as a result of the re-measurement of our private company equity investments upon the occurrence of either observable price changes or impairments, changes in interest rates or returns on our cash and cash equivalents and marketable securities, and foreign currency exchange rate fluctuations.

[0001596532-22-000026:mdna:41]
|  |  | Year Ended December 31, |  |  |
|  |  | 2021 |  | 2020 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Other income, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 7,215 |  |  | 0.2 | % |  | $ | 27,139 |  |  | 1.2 | % |  | $ | (19,924) |  |  | (73.4) | % |
| Gain on sale of marketable securities |  | — |  |  | — |  |  | 9,432 |  |  | 0.4 |  |  | (9,432) |  |  | (100.0) |  |
| Gain on investments in privately-held companies |  | — |  |  | — |  |  | 4,164 |  |  | 0.2 |  |  | (4,164) |  |  | (100.0) |  |
| Other income (expense) |  | (1,075) |  |  | — |  |  | (1,556) |  |  | (0.1) |  |  | 481 |  |  | (30.9) |  |
| Total other income, net |  | $ | 6,140 |  |  | 0.2 | % |  | $ | 39,179 |  |  | 1.7 | % |  | $ | (33,039) |  |  | (84.3) | % |

[0001596532-22-000026:mdna:42]
The unfavorable change in other income, net, during the year ended December 31, 2021 as compared to 2020 was driven by a $19.9 million decrease in interest income, which was primarily caused by significant declines in the yields of government and corporate bonds in our investment portfolio. In addition, we recorded a gain on sale of marketable securities and a gain on investments in privately-held companies in 2020, which did not recur in 2021.

[0001596532-22-000026:mdna:43]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-22-000026:mdna:44]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may also be subject to U.S. income tax. Generally, our U.S. tax obligations are reduced by a credit for foreign income taxes paid on these foreign earnings, which avoids double taxation. Our tax expense to date consists of federal, state and foreign current and deferred income taxes.

[0001596532-22-000026:mdna:45]
|  |  | Year Ended December 31, |  |  |
|  |  | 2021 |  | 2020 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Provision for income taxes |  | $ | 90,025 |  |  | 3.1 | % |  | $ | 104,306 |  |  | 4.5 | % |  | $ | (14,281) |  |  | (13.7) | % |
| Effective tax rate |  | 9.7 | % |  |  |  | 14.1 | % |  |  |  |  |  |  |

[0001596532-22-000026:mdna:46]
Despite an increase in pre-tax income in 2021 as compared to 2020, our provision for income taxes and effective tax rate decreased in 2021 as compared to 2020. The decrease in our income taxes and effective tax

[0001596532-22-000026:mdna:47]
rate was largely attributable to increased tax benefits from stock-based compensation, combined with a favorable change in jurisdictional mix of earnings. These two factors are variable in nature and past results may not be indicative of future results. For further information regarding income taxes and the impact on our results of operations and financial position, refer to Note 10. Income Taxes of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K.

[0001596532-22-000026:mdna:48]
Year Ended December 31, 2020 Compared to Year Ended December 31, 2019

[0001596532-22-000026:mdna:49]
Revenue, Cost of Revenue and Gross Margin (in thousands, except percentages)

[0001596532-22-000026:mdna:50]
|  |  | Year Ended December 31, |  |  |
|  |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,830,842 |  |  | 79.0 | % |  | $ | 2,021,150 |  |  | 83.8 | % |  | $ | (190,308) |  |  | (9.4) | % |
| Service |  | 486,670 |  |  | 21.0 |  |  | 389,556 |  |  | 16.2 |  |  | 97,114 |  |  | 24.9 |  |
| Total revenue |  | 2,317,512 |  |  | 100.0 |  |  | 2,410,706 |  |  | 100.0 |  |  | (93,194) |  |  | (3.9) |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 749,962 |  |  | 32.4 |  |  | 792,382 |  |  | 32.9 |  |  | (42,420) |  |  | (5.4) |  |
| Service |  | 85,664 |  |  | 3.7 |  |  | 73,986 |  |  | 3.0 |  |  | 11,678 |  |  | 15.8 |  |
| Total cost of revenue |  | 835,626 |  |  | 36.1 |  |  | 866,368 |  |  | 35.9 |  |  | (30,742) |  |  | (3.5) |  |
| Gross profit |  | $ | 1,481,886 |  |  | 63.9 | % |  | $ | 1,544,338 |  |  | 64.1 | % |  | $ | (62,452) |  |  | (4.0) | % |
| Gross margin |  | 63.9 | % |  |  |  | 64.1 | % |  |  |  |  |  |  |

[0001596532-22-000026:mdna:51]
Revenue by Geography (in thousands, except percentages)

[0001596532-22-000026:mdna:52]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | % of Total |  | 2019 |  | % of Total |
| Americas |  | $ | 1,771,992 |  |  | 76.5 | % |  | $ | 1,833,163 |  |  | 76.1 | % |
| Europe, Middle East and Africa |  | 326,729 |  |  | 14.1 |  |  | 381,651 |  |  | 15.8 |  |
| Asia-Pacific |  | 218,791 |  |  | 9.4 |  |  | 195,892 |  |  | 8.1 |  |
| Total revenue |  | $ | 2,317,512 |  |  | 100.0 | % |  | $ | 2,410,706 |  |  | 100.0 | % |

[0001596532-22-000026:mdna:53]
Revenue

[0001596532-22-000026:mdna:54]
Product revenue decreased by $190.3 million, or 9.4%, in the year ended December 31, 2020 compared to 2019. The decrease was primarily due to the recognition of $125.1 million of deferred product revenue in the year ended December 31, 2019 related to customer acceptance of products shipped in prior periods. In addition, we experienced reduced sales to our larger customers during fiscal 2020, combined with the impact of some COVID-19 related supply constraints. Service revenue increased by $97.1 million, or 24.9% in the year ended December 31, 2020 compared to 2019 as a result of continued growth in initial and renewal support contracts as our customer installed base continued to expand. International revenues remained relatively constant at 23.5% of total revenues in the year ended December 31, 2020, compared to 23.9% in 2019, with a slight decrease in growth in the EMEA region, mostly offset by an increase in growth in our Asia-Pacific region. International revenue generally fluctuates based on the timing of deployments by certain of our large end customers.

[0001596532-22-000026:mdna:55]
Cost of Revenue and Gross Margin

[0001596532-22-000026:mdna:56]
Cost of revenue decreased by $30.7 million or 3.5% for the year ended December 31, 2020 compared to 2019. The decrease in cost of revenue was primarily due to a corresponding decrease in product revenues,

[0001596532-22-000026:mdna:57]
and was partially offset by incremental COVID-19 related supply chain costs and increased product transition costs.

[0001596532-22-000026:mdna:58]
Gross margin slightly decreased from 64.1% for the year ended December 31, 2019 to 63.9% in 2020. Gross margin was negatively impacted by incremental COVID-19 related supply chain costs and some increased product transition costs, combined with the impact of fixed overhead costs on a lower revenue base. These negative impacts were partially offset by a reduction in sales to our larger end customers who generally receive larger discounts, and improved service margins as we scale our services organization.

[0001596532-22-000026:mdna:59]
Operating Expenses (in thousands, except percentages)

[0001596532-22-000026:mdna:60]
|  |  | Year Ended December 31, |  |  |
|  |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 486,594 |  |  | 20.9 | % |  | $ | 462,759 |  |  | 19.2 | % |  | $ | 23,835 |  |  | 5.2 | % |
| Sales and marketing |  | 229,366 |  |  | 9.9 |  |  | 213,907 |  |  | 8.9 |  |  | 15,459 |  |  | 7.2 |  |
| General and administrative |  | 66,242 |  |  | 2.9 |  |  | 61,898 |  |  | 2.6 |  |  | 4,344 |  |  | 7.0 |  |
| Total operating expenses |  | $ | 782,202 |  |  | 33.7 | % |  | $ | 738,564 |  |  | 30.7 | % |  | $ | 43,638 |  |  | 5.9 | % |

[0001596532-22-000026:mdna:61]
Research and development

[0001596532-22-000026:mdna:62]
Research and development expenses increased by $23.8 million, or 5.2%, for the year ended December 31, 2020 compared to 2019. The increase was primarily due to a $26.8 million increase in stock-based compensation from new and refresh grants during fiscal 2020, and a $7.8 million increase in acquisition-related expenses and amortization of acquired intangible assets from our acquisition of Big Switch and Awake Security, partially offset by an $11.4 million decrease in new product introduction costs, including third-party engineering and other product development costs.

[0001596532-22-000026:mdna:63]
Sales and marketing

[0001596532-22-000026:mdna:64]
Sales and marketing expenses increased by $15.5 million, or 7.2%, for the year ended December 31, 2020 compared to 2019. The increase was driven by increased headcount, resulting in increased compensation costs, including salaries and stock-based compensation, partially offset by a decrease in travel and other sales and marketing activities due to COVID-19.

[0001596532-22-000026:mdna:65]
General and administrative

[0001596532-22-000026:mdna:66]
General and administrative expenses increased by $4.3 million, or 7.0%, for the year ended December 31, 2020 compared to 2019. The increase was primarily driven by acquisition-related costs from our acquisitions of Big Switch and Awake Security in fiscal year 2020.

[0001596532-22-000026:mdna:67]
Other Income, Net (in thousands, except percentages)

[0001596532-22-000026:mdna:68]
|  |  | Year Ended December 31, |  |  |
|  |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Other income, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 27,139 |  |  | 1.2 | % |  | $ | 51,144 |  |  | 2.2 | % |  | $ | (24,005) |  |  | (46.9) | % |
| Gain on sale of marketable securities |  | 9,432 |  |  | 0.4 |  |  | — |  |  | — |  |  | 9,432 |  |  | 100.0 |  |
| Gain on investments in privately-held companies |  | 4,164 |  |  | 0.2 |  |  | 5,427 |  |  | 0.2 |  |  | (1,263) |  |  | (23.3) |  |
| Other income (expense) |  | (1,556) |  |  | (0.1) |  |  | (75) |  |  | — |  |  | (1,481) |  |  | 1,974.7 |  |
| Total other income, net |  | $ | 39,179 |  |  | 1.7 | % |  | $ | 56,496 |  |  | 2.4 | % |  | $ | (17,317) |  |  | (30.7) | % |

[0001596532-22-000026:mdna:69]
The unfavorable change in other income, net, during the year ended December 31, 2020 as compared to 2019 was driven by a $24.0 million decrease in interest income largely due to lower interest rates. This was partially offset by a realized gain of $9.4 million on the sale of marketable securities in the third quarter of the year ended December 31, 2020.

[0001596532-22-000026:mdna:70]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-22-000026:mdna:71]
|  |  | Year Ended December 31, |  |  |
|  |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Provision for income taxes |  | $ | 104,306 |  |  | 4.5 | % |  | $ | 2,403 |  |  | 0.1 | % |  | $ | 101,903 |  |  | 4,240.7 | % |
| Effective tax rate |  | 14.1 | % |  |  |  | 0.3 | % |  |  |  |  |  |  |

[0001596532-22-000026:mdna:72]
For the years ended December 31, 2020 and 2019, we recorded an expense of $104.3 million and $2.4 million for income taxes, respectively, and our effective tax rate increased from 0.3% in 2019 to 14.1% in 2020. The change in our income taxes was largely attributable to a net tax benefit of $86 million in 2019 resulting from an intra-entity transaction to sell our non-Americas economic and beneficial intellectual property rights. Further, while we experienced a decrease in worldwide profit before tax in 2020 compared to 2019, the tax benefits attributable to stock-based compensation also decreased, along with an increase in foreign earnings taxed in non-zero rate jurisdictions, resulting in overall higher tax expense. For further information regarding income taxes and the impact on our results of operations and financial position, refer to Note 10. Income Taxes of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K.

[0001596532-22-000026:mdna:73]
Liquidity and Capital Resources

[0001596532-22-000026:mdna:74]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of December 31, 2021, our total balance of cash, cash equivalents and marketable securities was $3.4 billion, of which approximately $576.0 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-22-000026:mdna:75]
Our cash, cash equivalents and marketable securities are held for general business purposes, including the funding of working capital. Our marketable securities investment portfolio is primarily invested in highly-rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing

[0001596532-22-000026:mdna:76]
capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and stock repurchases. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-22-000026:mdna:77]
Cash Flows

[0001596532-22-000026:mdna:78]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 1,015,856 |  |  | $ | 735,114 |  |  | $ | 963,034 |  |
| Cash (used in) investing activities |  | (925,562) |  |  | (608,802) |  |  | (284,072) |  |
| Cash (used in) financing activities |  | (360,882) |  |  | (346,339) |  |  | (217,964) |  |
| Effect of exchange rate changes |  | (1,816) |  |  | 1,966 |  |  | 353 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | (272,404) |  |  | $ | (218,061) |  |  | $ | 461,351 |  |

[0001596532-22-000026:mdna:79]
Cash Flows from Operating Activities

[0001596532-22-000026:mdna:80]
Our operating activities consist of net income, adjusted for certain non-cash items, and changes in assets and liabilities.

[0001596532-22-000026:mdna:81]
During the year ended December 31, 2021, cash provided by operating activities was $1.0 billion, primarily from net income of $840.9 million and net non-cash adjustments to net income of $181.9 million, partially offset by a net increase of $6.9 million in working capital requirements.  The net non-cash adjustments primarily consist of $186.9 million of stock-based compensation expenses, $50.3 million of depreciation and amortization expenses and $26.8 million of amortization of investment premiums (discounts), all of which were offset by the deferred income tax adjustment of $99.3 million. The increase in working capital primarily consisted of a $170.5 million increase in inventory to help mitigate the impact of COVID-19 related supply chain disruptions, a $134.8 million increase in prepaid and other current assets primarily driven by an increase in deferred cost of sales associated with higher product revenue deferrals, increased inventory deposits to our contract manufacturers, and higher prepaid taxes and other assets.  In addition, we had an increase of $127.0 million in accounts receivables due to increased product and service billings. These cash outflows were largely offset by a $278.5 million increase in deferred revenue reflecting ongoing growth in PCS contracts and increased product deferred revenue related to contracts with acceptance terms. In addition, we had a $66.7 million increase in accounts payable related to the volume and timing of production receipts, and an $83.5 million increase in accrued expenses primarily driven by increased supply chain and development costs, as well as accrued compensation-related costs.

[0001596532-22-000026:mdna:82]
During the year ended December 31, 2020, cash provided by operating activities was $735.1 million, primarily from net income of $634.6 million and net non-cash adjustments to net income of $186.2 million, partially offset by a net increase of $85.7 million in working capital requirements. The net non-cash adjustments primarily consisted of $137.0 million of stock-based compensation expenses and $44.6 million of depreciation and amortization expenses. The increase in working capital primarily consisted of a $235.3 million increase in inventory to help mitigate the impact of COVID-19 related supply chain disruptions, partially offset by a $50.4 million increase in deferred revenue, a $41.1 million increase in accounts payable related to the timing of production receipts, and a $17.1 million increase in other liabilities primarily due to an increase in customer contract liabilities.

[0001596532-22-000026:mdna:83]
Cash Flows from Investing Activities

[0001596532-22-000026:mdna:84]
Our investing activities consist of our marketable securities investments, business combinations, investments in privately-held companies, and capital expenditures.

[0001596532-22-000026:mdna:85]
During the year ended December 31, 2021, cash used in investing activities was $925.6 million, primarily consisting of purchases of available-for-sale securities of $2.3 billion, investments and notes receivable in private companies of $19.9 million, and purchases of property, equipment and intangible assets of $64.7 million, partially offset by proceeds of $1.5 billion from maturities of marketable securities, proceeds from the sale of marketable securities of $19.6 million, and the receipt of escrow payments of $1.3 million.

[0001596532-22-000026:mdna:86]
During the year ended December 31, 2020, cash used in investing activities was $608.8 million, primarily consisting of purchases of available-for-sale securities of $2.7 billion, $227.4 million for the acquisitions of Big Switch and Awake Security, and purchases of property, equipment and intangible assets of $15.4 million, partially offset by proceeds of $1.5 billion from maturities of marketable securities, proceeds from the sale of marketable securities of $773.0 million and proceeds from the sale of one of our investments in privately-held companies of $3.4 million.

[0001596532-22-000026:mdna:87]
Cash Flows from Financing Activities

[0001596532-22-000026:mdna:88]
Our financing activities consist of proceeds from the issuance of our common stock under employee equity incentive plans, offset by repurchases of our common stock.

[0001596532-22-000026:mdna:89]
During the year ended December 31, 2021, cash used in financing activities was $360.9 million, consisting primarily of payments for repurchases of our common stock of $411.6 million and taxes paid of $16.5 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $67.2 million.

[0001596532-22-000026:mdna:90]
During the year ended December 31, 2020, cash used in financing activities was $346.3 million, consisting primarily of payments for repurchases of our common stock of $395.2 million and taxes paid of $8.7 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $57.6 million.

[0001596532-22-000026:mdna:91]
Stock Repurchase Programs

[0001596532-22-000026:mdna:92]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”).  This authorization allowed us to repurchase shares of our common stock over three years, and we completed our repurchases under the Repurchase Program during the fourth quarter of 2021.  Also in the fourth quarter of 2021, our board of directors authorized an additional $1.0 billion stock repurchase program (the "New Repurchase Program"). This authorization allows us to repurchase shares of our common stock and will be funded from working capital. The New Repurchase Program commenced in the fourth quarter of 2021 and expires on the three-year anniversary thereof. The New Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the company at any time without prior notice. As of December 31, 2021, the remaining authorized amount for repurchases under the New Repurchase Program was $927.0 million. Refer to Note 8. Stockholders' Equity and Stock-Based Compensation of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K for further discussion.

[0001596532-22-000026:mdna:93]
Material cash requirements

[0001596532-22-000026:mdna:94]
Our material cash requirements will have an impact on our future liquidity. Our material cash requirements represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalents and marketable securities.

[0001596532-22-000026:mdna:95]
Our material cash requirements include the following contractual and other obligations:

[0001596532-22-000026:mdna:96]
Leases

[0001596532-22-000026:mdna:97]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of December 31, 2021, we had lease payment obligations, net of immaterial sublease income, of $87.0 million, with $23.5 million payable within 12 months.

[0001596532-22-000026:mdna:98]
Purchase Obligations

[0001596532-22-000026:mdna:99]
Purchase obligations represent an estimate of all open purchase orders and contractual obligations, made either directly by Arista or by our contract manufacturers on our behalf, in the ordinary course of business for which we have not received the goods or services. As of December 31, 2021, we had $2.5 billion of such purchase obligations, with $2.3 billion payable within 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-22-000026:mdna:100]
In addition to the purchase obligations outlined above, we also entered into an agreement covering an additional $275 million of extended lead-time component purchase commitments in support of 2023 forecasted demand, for which purchase orders had not been issued as of December 31, 2021.

[0001596532-22-000026:mdna:101]
Long Term Accrued Income Taxes

[0001596532-22-000026:mdna:102]
In connection with the Tax Cuts and Jobs Act of 2017, we recorded a federal income tax payable for transition tax on the mandatory deemed repatriation of foreign earnings that will be payable over an eight-year period.  As of December 31, 2021, $6.3 million of long-term transition tax payable represents the remaining federal income tax payable due between one and three years. In addition to the long-term transition tax payable, as of December 31, 2021 we have recorded long-term tax liabilities of $63.6 million related to uncertain tax positions; however, we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-22-000026:mdna:103]
Off-balance sheet arrangements

[0001596532-22-000026:mdna:104]
As of December 31, 2021, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-22-000026:mdna:105]
Critical Accounting Estimates

[0001596532-22-000026:mdna:106]
We have prepared our consolidated financial statements in accordance with accounting principles generally accepted in the United States ("GAAP" or "U.S. GAAP") and include our accounts and the accounts of our wholly owned subsidiaries. The preparation of these consolidated financial statements requires our management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities at the date of the financial statements, disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the applicable periods.  Note 1, “Organization and Summary of Significant Accounting Policies,” of the Notes to Consolidated Financial Statements in Part II, Item 8 of this Form 10-K describes the significant accounting policies and methods used in the preparation of the Company’s consolidated financial statements.  We base our estimates, assumptions and judgments on historical experience and on various other factors that we believe to be reasonable under the circumstances. Different assumptions and judgments would change the estimates used in the preparation of our consolidated financial statements, which, in turn, could change the results from those reported. We evaluate our estimates, assumptions and judgments on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001596532-22-000026:mdna:107]
Revenue Recognition

[0001596532-22-000026:mdna:108]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with PCS. We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or

[0001596532-22-000026:mdna:109]
services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts which contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

[0001596532-22-000026:mdna:110]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information, such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to, the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

[0001596532-22-000026:mdna:111]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at-risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

[0001596532-22-000026:mdna:112]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical return rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-22-000026:mdna:113]
We have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

[0001596532-22-000026:mdna:114]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-22-000026:mdna:115]
Inventories primarily consist of finished goods and strategic components, primarily integrated circuits. Inventories are stated at the lower of cost (computed using the first-in, first-out method) and net realizable value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value.

[0001596532-22-000026:mdna:116]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts. We record a liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with our contract manufacturers or suppliers for quantities in excess of our demand forecasts or that are considered obsolete due to manufacturing and engineering change orders resulting from design changes.

[0001596532-22-000026:mdna:117]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels. In addition, current industry-wide supply chain shortages have resulted in extended lead times for components and have required us to extend the time horizon of our demand forecasts. There is however no guarantee that all suppliers will meet their commitments in the time frame committed or that actual customer demand will directly match our demand forecasts. If actual market demand conditions or supplier execution on commitments are less favorable than those projected by management, which may be caused by factors within and/or outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have

[0001596532-22-000026:mdna:118]
an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer and supplier liabilities.

[0001596532-22-000026:mdna:119]
Income Taxes

[0001596532-22-000026:mdna:120]
Significant management judgment is required in developing our provision for or benefit from income taxes, including the determination of deferred tax assets and liabilities and any valuation allowances that might be required against the deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results and estimates of our ability to generate sufficient future taxable income in certain foreign and state tax jurisdictions, future reversals of taxable temporary differences, and potential tax planning strategies. An adjustment to the valuation allowance will either increase or decrease our provision for or benefit from income taxes in the period such determination is made.

[0001596532-22-000026:mdna:121]
We are subject to income taxes in the U.S. and numerous foreign jurisdictions, which involves significant judgment in the interpretation of complex domestic and international tax laws and may give rise to uncertain tax positions. We recognize potential liabilities for anticipated tax audit issues in the U.S. and other tax jurisdictions based on our estimate of whether it is more likely than not that additional taxes, interest, and penalties will be due. Although management believes our unrecognized tax benefits are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our unrecognized tax benefits. Our unrecognized tax benefits are adjusted considering changing facts and circumstances, such as the closing of a tax examination or the refinement of an estimate. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on our financial condition and operating results.

[0001596532-22-000026:mdna:122]
Recent Accounting Pronouncements

[0001596532-22-000026:mdna:123]
Refer to “Recent Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K.
