# ANET notes — 0001596532-22-000026


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001596532-22-000026:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001596532-22-000026:notes:2]
Portions of the registrant’s definitive Proxy Statement relating to its 2022 Annual Meeting of Stockholders to be filed pursuant to Regulation 14A within 120 days after the registrant’s fiscal year end of December 31, 2021 are incorporated by reference into Part III of this Annual Report on Form 10-K.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-22-000026:notes:3]
Organization and Summary of Significant Accounting Policies
Organization

[0001596532-22-000026:notes:4]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale internet companies, cloud service providers and next-generation enterprises. Our cloud networking solutions consist of our EOS, a set of network applications and our Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-22-000026:notes:5]
Basis of Presentation and Principles of Consolidation

[0001596532-22-000026:notes:6]
The accompanying consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and are prepared in accordance with accounting principles generally accepted in the United States ("GAAP"). All significant intercompany accounts and transactions have been eliminated.

[0001596532-22-000026:notes:7]
On November 1, 2021, we announced a four-for-one split of the Company’s common stock effected in the form of a stock dividend (the “Stock Split”). Each stockholder of record on November 11, 2021 received three additional shares of common stock for each then-held share, and such shares were distributed after close of trading on November 17, 2021. All share and per share amounts presented herein have been retroactively adjusted to reflect the impact of the Stock Split.

[0001596532-22-000026:notes:8]
Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.

[0001596532-22-000026:notes:9]
Risk and Uncertainties

[0001596532-22-000026:notes:10]
The global coronavirus ("COVID-19") pandemic and resulting mitigation efforts by governments around the world to contain or slow its spread have negatively impacted the global economy and disrupted business activities.

[0001596532-22-000026:notes:11]
Our contract manufacturers and suppliers have experienced workforce disruptions, delays in component sourcing, production, and export of their products, which have disrupted our supply chain and have impacted and likely will continue to impact our ability to supply products to our customers on a timely basis. While we have experienced improvements in overall demand from customers during 2021, we believe ongoing COVID-19 related disruptions, combined with other supply-chain related constraints, could impact our ability to fulfill this increased demand, and as a result could negatively impact our business in future periods. However, the extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, including the duration and spread of the pandemic and related mitigation efforts, the impact to our customers, partners, contract manufacturers and supply chain, as well as restrictions on travel and transport, all of which continue to evolve and are unpredictable. Management continues to actively monitor the impact of the pandemic on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

[0001596532-22-000026:notes:12]
Use of Estimates

[0001596532-22-000026:notes:13]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, valuation of inventory and contract manufacturer/supplier liabilities, accounting for income taxes, including the recognition of deferred tax assets and liabilities, valuation allowance on deferred tax assets and reserves for uncertain tax positions, revenue recognition and deferred revenue, allowance for doubtful accounts,

[0001596532-22-000026:notes:14]
sales rebates and return reserves, valuation of goodwill and acquisition-related intangible assets, estimate of useful lives of long-lived assets including intangible assets, and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust these estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from these estimates.

[0001596532-22-000026:notes:15]
Concentrations of Business and Credit Risk

[0001596532-22-000026:notes:16]
We work closely with third-party contract manufacturers to manufacture our products. As of December 31, 2021, we had two primary contract manufacturing partners, who provided the vast majority of our electronic manufacturing services. Our contract manufacturing partners deliver our products to our third-party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers. Our products rely on key components, including certain integrated circuit components and power supplies, some of which our contract manufacturing partners purchase on our behalf from a limited number of suppliers, including certain sole-source providers. We generally do not have guaranteed supply contracts with our component suppliers, and our manufacturing partners could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, or if we are unable to obtain alternative sources for these components, sales of our products could be delayed or halted entirely, or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.

[0001596532-22-000026:notes:17]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, marketable securities, restricted cash, and accounts receivable. Our cash equivalents, restricted cash and marketable securities are invested in high quality financial instruments with banks and financial institutions. Such deposits may be in excess of insured limits provided on such deposits.

[0001596532-22-000026:notes:18]
Our accounts receivable are unsecured and represent amounts due to us based on contractual obligations of our customers. We mitigate credit risk with respect to accounts receivable by performing ongoing credit evaluations of our customers to assess the probability of collection based on a number of factors, including past transaction experience with the customer, evaluation of their credit history, the credit limits extended, review of the invoicing terms of the arrangement, and current economic conditions that may affect a customer’s ability to pay. In situations where a customer may be thinly capitalized and we have limited payment history with it, we will either establish a small credit limit or require it to prepay its purchases. We generally do not require our customers to provide collateral to support accounts receivable. We have recorded an allowance for doubtful accounts for accounts receivables that we have determined to be uncollectible. We mitigate credit risk with respect to accounts receivables by performing ongoing credit evaluations of the borrower to assess the probability of collecting all amounts due to us under the existing contractual terms.

[0001596532-22-000026:notes:19]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators and OEM partners, and in conjunction with various technology partners.  Significant customers are those that represent more than 10% of our total net revenue during the period or net accounts receivable balance at each respective balance sheet date. As of December 31, 2021, we had three customers who represented 37%, 13% and 12% of total accounts receivable. As of December 31, 2020, we had two customers who represented 31% and 15% of total accounts receivable.  For the years ended December 31, 2021 and 2020, there was one customer who represented 15% and 22% of our total revenue, respectively. For the year ended December 31, 2019, there were two customers who represented 23% and 17% of our total revenue.

[0001596532-22-000026:notes:20]
Cash and Cash Equivalents

[0001596532-22-000026:notes:21]
We consider all highly liquid investments with original or remaining maturities of three months or less at the time of purchase to be cash equivalents. Cash and cash equivalents consist of cash on deposit with various

[0001596532-22-000026:notes:22]
financial institutions and highly liquid investments in money market funds. Interest is accrued as earned. As of December 31, 2021 and 2020, we had restricted cash of $4.2 million, respectively, and that primarily included $4.0 million pledged as collateral representing a security deposit required for a facility lease. Our restricted cash is classified as other assets in the accompanying consolidated balance sheets.

[0001596532-22-000026:notes:23]
Marketable Securities

[0001596532-22-000026:notes:24]
We classify all highly liquid investments in debt and equity securities with maturities of greater than three months at the date of purchase as marketable securities. We have classified and accounted for our marketable securities as available-for-sale. We determine the appropriate classification of these investments at the time of purchase and reevaluate such designation at each balance sheet date. We may or may not hold securities with stated maturities greater than 12 months until maturity. After consideration of our risk versus reward objectives, as well as our liquidity requirements, we may sell these securities prior to their stated maturities. As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets. We carry these securities at fair value, and report the unrealized gains and losses, net of taxes, as a component of stockholders’ equity. We determine the cost of the debt investment sold based on an average cost basis at the individual security level, and record the interest income in other income, net in the accompanying consolidated statements of operations. We determine any realized gains or losses on the sale of marketable securities using the specific identification method, and record such gains and losses in other income, net in the accompanying consolidated statements of operations.

[0001596532-22-000026:notes:25]
For our debt securities in an unrealized loss position, we determine whether a credit loss exists by considering information about the collectability of the instrument and current market conditions. We recognize an allowance for credit losses, up to the amount of the unrealized loss when appropriate, and write down the amortized cost basis of the investment if it is more likely than not we will be required to sell or we intend to sell the investment before recovery of its amortized cost basis.

[0001596532-22-000026:notes:26]
Accounts Receivable

[0001596532-22-000026:notes:27]
Accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts, sales rebates and returns reserves. We estimate our allowance for doubtful accounts based upon the collectability of the receivables in light of historical trends, reasonable and supportable information of our customers' economic conditions that may affect our customers’ ability to pay, and prevailing economic conditions. This evaluation is done in order to identify issues that may impact the collectability of receivables and related estimated required allowance. Revisions to the allowance are recorded as an adjustment to bad debt expense. After appropriate collection efforts are exhausted, specific accounts receivable deemed to be uncollectible are charged against the allowance in the period they are deemed uncollectible. Recoveries of accounts receivable previously written-off are recorded as credits to bad debt expense. We primarily estimate our sales rebates and returns reserves based on historical rates applied against current period billings. Specific customer returns, rebates and allowances are considered when determining our estimates. Revisions to sales rebate and return reserves are recorded as adjustments to revenue.

[0001596532-22-000026:notes:28]
Fair Value Measurements

[0001596532-22-000026:notes:29]
Fair value is defined as the exchange price that would be received for an asset or an exit price that would be paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. These assets and liabilities include cash and cash equivalents, marketable securities, accounts receivable, accounts payable, and accrued liabilities. Cash equivalents, accounts receivable, accounts payable and accrued liabilities are stated at carrying values in our consolidated financial statements, which approximate their fair value due to the short-term nature of these instruments.

[0001596532-22-000026:notes:30]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their

[0001596532-22-000026:notes:31]
fair value.  We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs.  The three-tiers of the fair value hierarchy are as follows:

[0001596532-22-000026:notes:32]
Level I—Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date;

[0001596532-22-000026:notes:33]
Level II—Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities; and

[0001596532-22-000026:notes:34]
Level III—Unobservable inputs that are supported by little or no market data for the related assets or liabilities and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.

[0001596532-22-000026:notes:35]
Foreign Currency

[0001596532-22-000026:notes:36]
The functional currency of our foreign subsidiaries is either the U.S. dollar or their local currency depending on the nature of the subsidiaries’ activities.

[0001596532-22-000026:notes:37]
Transaction re-measurement - Assets and liabilities denominated in a currency other than a subsidiary’s functional currency are re-measured into the subsidiary's functional currency using exchange rates in effect at the end of the reporting period, with gains and losses recorded in other income, net in the consolidated statements of operations. To date, foreign currency transaction gains and losses and exchange rate fluctuations have not been material to our consolidated financial statements.

[0001596532-22-000026:notes:38]
Translation - Assets and liabilities of subsidiaries denominated in foreign functional currencies are translated into U.S. dollars at the closing exchange rate on the balance sheet date and equity-related balances are translated at historical exchange rates.  Revenues, costs and expenses in foreign functional currencies are translated using average exchange rates that approximate those in effect during the period. Translation adjustments are recorded within accumulated other comprehensive income, a separate component of total stockholders’ equity.

[0001596532-22-000026:notes:39]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-22-000026:notes:40]
Inventories primarily consist of finished goods and strategic components, primarily integrated circuits. Inventories are stated at the lower of cost (computed using the first-in, first-out method) and net realizable value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value. For the years ended December 31, 2021, 2020 and 2019, we recorded charges of $61.8 million, $50.5 million and $41.2 million, respectively, within cost of product revenue for inventory write-downs.

[0001596532-22-000026:notes:41]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts. We record a liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with our contract manufacturers or suppliers for quantities in excess of our demand forecasts or that are considered obsolete due to manufacturing and engineering change orders resulting from design changes. For the years ended December 31, 2020 and 2019, we recorded charges of $14.9 million and $11.7 million, respectively, within cost of product revenue for such liabilities with our contract manufacturers and suppliers. For the year ended December 31, 2021, we did not incur any additional losses on such liabilities.

[0001596532-22-000026:notes:42]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels.  In addition, due to current  industry-wide supply shortages, we have had to extend our demand planning horizon and increase our purchase commitments for long lead time components. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and/or outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our

[0001596532-22-000026:notes:43]
gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer and supplier liabilities.

[0001596532-22-000026:notes:44]
Property and Equipment

[0001596532-22-000026:notes:45]
Property and equipment are stated at cost, less accumulated depreciation, except for land which is not depreciated. We capitalize any additions and improvements and expense maintenance and repairs as incurred. Depreciation is calculated using the straight-line method over the estimated useful lives of the related assets, generally three years. Our leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term.

[0001596532-22-000026:notes:46]
Leases

[0001596532-22-000026:notes:47]
We lease office space, data centers, and equipment under non-cancellable operating leases with various expiration dates through 2028. We determine if an arrangement contains a lease at inception. Operating leases are included in operating lease right-of-use (“ROU”) assets, other current liabilities, and operating lease liabilities, non-current in our consolidated balance sheets. We do not have any finance leases in any of the periods presented.

[0001596532-22-000026:notes:48]
ROU assets and lease liabilities are recognized at the commencement date based on the present value of remaining lease payments over the lease term. The interest rate implicit in our operating leases is not readily available, and therefore, an incremental borrowing rate is estimated based on a hypothetical interest rate on a collateralized basis with similar terms, payments, and economic environments. Operating lease right-of-use assets also include any prepaid lease payments and lease incentives.

[0001596532-22-000026:notes:49]
Our operating lease agreements may contain rent concession, rent escalation, and option to renew provisions.  Lease expense is recognized on a straight-line basis over the lease term commencing on the date we have the right to use the leased property. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that the option will be exercised. In addition, certain of our operating lease agreements contain tenant improvement allowances from landlords. These allowances are accounted for as lease incentives and decrease our right-of-use asset and reduce lease expense over the lease term.

[0001596532-22-000026:notes:50]
Our lease agreements may contain lease and non-lease components, which are combined and accounted for as a single lease component. We also elect to apply the short-term lease measurement and recognition exemption in which ROU assets and lease liabilities are not recognized for leases with terms of 12 months or less.

[0001596532-22-000026:notes:51]
Business Combinations

[0001596532-22-000026:notes:52]
We use the acquisition method to account for our business combinations in accordance with Accounting Standards Codification ("ASC") 805 - Business Combinations. We allocate the total fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the consideration transferred over the fair values of the assets acquired and liabilities assumed is recorded as goodwill. The results of operations of the acquired businesses are included in our consolidated financial statements from the date of acquisition. Acquisition-related transaction and restructuring costs are expensed as incurred.

[0001596532-22-000026:notes:53]
During the measurement period, which is not to exceed one year from the acquisition date, we may record adjustments to the acquired assets and liabilities assumed, with a corresponding offset to goodwill or the preliminary purchase price, to reflect new information obtained about facts and circumstances that existed as of the acquisition date. Upon the conclusion of the measurement period, any subsequent adjustments are recorded to earnings.

[0001596532-22-000026:notes:54]
Goodwill and Acquired Intangible Assets

[0001596532-22-000026:notes:55]
Goodwill represents the excess of the purchase price over the fair value of net assets acquired in a business combination. The Company has one reporting unit and tests goodwill for impairment at least annually in the fourth quarter or more frequently if indicators of potential impairment exist. We first perform a qualitative assessment to determine whether it is more likely than not that the fair value of our reporting unit is less than its

[0001596532-22-000026:notes:56]
carrying amount. If the reporting unit does not pass the qualitative assessment, a quantitative test is performed by comparing the fair value of our reporting unit with its carrying amount.  We would recognize an impairment loss for the amount by which the carrying amount exceeds the fair value. There were no impairment charges in any of the periods presented in the consolidated financial statements. See Note 6. Goodwill and Acquisition-Related Intangible Assets for additional information.

[0001596532-22-000026:notes:57]
Acquired intangible assets are carried at cost less accumulated amortization. All acquired intangible assets have been determined to have definite lives and are amortized on a straight-line basis over their estimated useful lives, ranging from one to eight years. Acquired intangible assets are reviewed for impairment under the long-lived asset model described below. There were no impairment charges in any of the periods presented in the consolidated financial statements. See Note 6. Goodwill and Acquisition-Related Intangible Assets for additional information.

[0001596532-22-000026:notes:58]
Investments in Privately-Held Companies

[0001596532-22-000026:notes:59]
Our equity investments in privately-held companies without readily determinable fair values are measured using the measurement alternative, defined by ASC 321 - Investments-Equity Securities as cost, less impairments, and remeasured based on observable price changes from orderly transactions of identical or similar securities of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded within other income, net in our consolidated statements of operations. This election is reassessed each reporting period to determine whether investments in privately-held companies have a readily determinable fair value, in which case they would no longer be eligible for this election. The Company did not hold investments in privately-held companies whose fair value was readily determinable as of December 31, 2021 and 2020.

[0001596532-22-000026:notes:60]
Impairment of Long-Lived Assets and Investments in Privately-Held Companies

[0001596532-22-000026:notes:61]
The carrying amounts of our long-lived assets, including property and equipment, intangible assets, ROU assets and investments in privately-held companies, are periodically reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. Recoverability of these assets is measured by comparison of the carrying amount of each asset to the future undiscounted cash flows the asset is expected to generate over its remaining life. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. No impairment of any other long-lived assets was identified for any of the periods presented in the consolidated financial statements.

[0001596532-22-000026:notes:62]
Loss Contingencies

[0001596532-22-000026:notes:63]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgments and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements, and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.

[0001596532-22-000026:notes:64]
Revenue Recognition

[0001596532-22-000026:notes:65]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with post-contract customer support (“PCS”). We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be

[0001596532-22-000026:notes:66]
entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

[0001596532-22-000026:notes:67]
•Identification of the contract, or contracts, with a customer

[0001596532-22-000026:notes:68]
•Identification of the performance obligations in the contract

[0001596532-22-000026:notes:69]
•Determination of the transaction price

[0001596532-22-000026:notes:70]
•Allocation of the transaction price to the performance obligations in the contract

[0001596532-22-000026:notes:71]
•Recognition of revenue when (or as) we satisfy the performance obligation

[0001596532-22-000026:notes:72]
Post-Contract Customer Support ("PCS")

[0001596532-22-000026:notes:73]
PCS, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernible pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and address customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-22-000026:notes:74]
Contracts with Multiple Performance Obligations

[0001596532-22-000026:notes:75]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts that contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

[0001596532-22-000026:notes:76]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to, the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

[0001596532-22-000026:notes:77]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at-risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

[0001596532-22-000026:notes:78]
Most of our contracts with customers have payment terms of 30 days with some large high-volume customers having terms of up to 90 days. We have determined our contracts generally do not include a significant financing component because the Company and the customer have specific business reasons other than financing for entering into such contracts. Specifically, both we and our customers seek to ensure the customer has a simplified way of purchasing Arista products and services.

[0001596532-22-000026:notes:79]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

[0001596532-22-000026:notes:80]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on

[0001596532-22-000026:notes:81]
historical return rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-22-000026:notes:82]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

[0001596532-22-000026:notes:83]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

[0001596532-22-000026:notes:84]
Contract Balances

[0001596532-22-000026:notes:85]
A contract asset is recognized when we have a contractual right to consideration for both completed and partially completed performance obligations that have not yet been invoiced.  Contract assets are included in other current assets in the accompanying consolidated balance sheets.

[0001596532-22-000026:notes:86]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a contract that is cancellable. Contract liabilities are included in other current liabilities and other long-term liabilities in the accompanying consolidated balance sheets.

[0001596532-22-000026:notes:87]
Assets Recognized from Costs to Obtain a Contract with a Customer

[0001596532-22-000026:notes:88]
We recognize an asset for the incremental costs of obtaining a contract with a customer if we expect the benefit of those costs to be longer than one year. We have determined that certain sales commissions earned by our sales force meet the requirements for capitalization. These costs are deferred and then amortized over a period of benefit that we have determined to be five years. Total capitalized costs to obtain a contract are included in other current and long-term assets on our consolidated balance sheets. As of December 31, 2021 and 2020, total capitalized costs to obtain contracts were $11.5 million and $10.1 million, respectively.

[0001596532-22-000026:notes:89]
Research and Development Expenses

[0001596532-22-000026:notes:90]
Costs related to the research, design and development of our products are charged to research and development expenses as incurred. Software development costs are capitalized beginning when a product’s technological feasibility has been established and ending when the product is available for general release to customers. Generally, our products are released soon after technological feasibility has been established. As a result, costs incurred subsequent to achieving technological feasibility have not been significant and accordingly, all software development costs have been expensed as incurred.

[0001596532-22-000026:notes:91]
Warranty

[0001596532-22-000026:notes:92]
We generally offer a one-year warranty on all of our hardware products and a 90-day warranty against defects in the software embedded in the products. We use judgment and estimates when determining warranty costs based on historical costs to replace product returns within the warranty period at the time we recognize revenue. We accrue for potential warranty claims at the time of shipment as a component of cost of revenues based on historical experience and other relevant information. We reserve for specifically identified products if and when we determine we have a systemic product failure. Although we engage in extensive product quality programs, if actual product failure rates or use of materials differ from estimates, additional warranty costs may be incurred, which could reduce our gross margin. The accrued warranty liability is recorded in accrued liabilities in the accompanying consolidated balance sheets.

[0001596532-22-000026:notes:93]
Segment Reporting

[0001596532-22-000026:notes:94]
We develop, market and sell cloud networking solutions, which primarily consist of our switching and routing platforms and related network applications, and there are no segment managers who are held accountable for operations or operating results below the Company level. Our chief operating decision maker is

[0001596532-22-000026:notes:95]
our Chief Executive Officer, who reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.  Accordingly, we have determined that we operate as one reportable segment.

[0001596532-22-000026:notes:96]
Stock-Based Compensation

[0001596532-22-000026:notes:97]
Stock-based compensation cost for equity awards is measured at the grant-date fair value using appropriate valuation techniques and recognized as expense over the requisite service or performance period.  We account for forfeitures when they occur.

[0001596532-22-000026:notes:98]
Stock-based compensation costs for stock options and restricted stock units ("RSUs") are recognized on a straight-line basis over the requisite service period, which is generally two to five years. The Company has granted RSUs that vest upon the satisfaction of both service-based and performance-based conditions. The service-based condition for these awards is generally satisfied over four years. The performance-based conditions are satisfied upon achieving specified performance targets, such as financial or operating metrics. We record stock-based compensation expense for performance-based equity awards on an accelerated attribution method over the requisite service period, and only if performance-based conditions are considered probable to be satisfied.

[0001596532-22-000026:notes:99]
See Note 8. Stockholders' Equity and Stock-Based Compensation for a detailed discussion of the Company’s stock plans, assumptions to the valuation techniques, and stock-based compensation expense.

[0001596532-22-000026:notes:100]
Income Taxes

[0001596532-22-000026:notes:101]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-22-000026:notes:102]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-22-000026:notes:103]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-22-000026:notes:104]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.

[0001596532-22-000026:notes:105]
The U.S. tax rules require U.S. tax on foreign earnings, known as global intangible low taxed income (“GILTI”). Under U.S. GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”).  We selected the deferred method of accounting and recorded the associated basis differences anticipated to influence prospective GILTI calculations.

[0001596532-22-000026:notes:106]
Net Income per Share Attributable to Common Stockholders

[0001596532-22-000026:notes:107]
Basic and diluted net income per share attributable to common stockholders are calculated in conformity with the two-class method required for participating securities. Our shares of common stock subject to repurchase are considered participating securities. Under the two-class method, net income attributable to common stockholders is calculated as net income less earnings attributable to participating securities. In computing diluted net income attributable to common stockholders, undistributed earnings are re-allocated to reflect the potential impact of dilutive securities. Basic net income per common share is computed by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding during the period. Diluted net income per share attributable to common stockholders is computed by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding, including potentially dilutive common shares assuming the dilutive effect of outstanding stock options, restricted stock units, and employee stock purchase plan using the treasury stock method. Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001596532-22-000026:notes:108]
Recently Adopted Accounting Pronouncements

[0001596532-22-000026:notes:109]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for incomes taxes by removing certain exceptions to the general principles in Topic 740 and amending existing guidance to improve consistent application. This new standard is effective for our interim and annual periods beginning January 1, 2021 with earlier adoption permitted. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. We adopted this new standard on January 1, 2021, with no material impact on our consolidated financial statements.

[0001596532-22-000026:notes:110]
Recent Accounting Pronouncements Not Yet Effective

[0001596532-22-000026:notes:111]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which requires contract assets and contract liabilities acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers, as if the acquirer had originated the contracts. This approach differs from the current requirement to measure contract assets and contract liabilities acquired in a business combination at fair value. This new standard is effective for our interim and annual periods beginning January 1, 2023, with early adoption permitted. We are currently evaluating the adoption impacts on our consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-22-000026:notes:112]
Business Combinations
On February 5, 2020, the Company completed its acquisition of Big Switch Networks, Inc. (“Big Switch”), a network monitoring and software-defined networking pioneer headquartered in Santa Clara, California. With the acquisition of Big Switch, we expect to expand our data center networking solutions and further strengthen our network monitoring and observability suite delivered through Arista’s software platform CloudVision and DANZ (DataANalyZer) capabilities.

[0001596532-22-000026:notes:113]
We paid an aggregate of $73.3 million in cash for the acquisition of Big Switch, of which $5.3 million was severance and other costs accounted for as a post-combination expense and excluded from the purchase consideration. We also incurred certain acquisition-related expenses and restructuring costs of $6.6 million, which primarily consisted of retention bonuses to continuing employees, professional and consulting fees, and facilities restructuring costs.

[0001596532-22-000026:notes:114]
On October 7, 2020, the Company completed its acquisition of Awake Security, Inc. (“Awake Security”), a network detection and response (“NDR”) platform provider headquartered in Santa Clara, California. With the acquisition of Awake Security, we added an NDR platform to our product portfolio that combines artificial intelligence (AI) with human expertise to autonomously hunt for and respond to insider and external security threats.

[0001596532-22-000026:notes:115]
The Company acquired all outstanding shares of Awake Security for a total purchase consideration of $180.5 million with cash. The acquisition-related costs were immaterial.

[0001596532-22-000026:notes:116]
Certain unvested stock options held by Awake Security employees were assumed by the Company in connection with the acquisition. The portion of the fair value of the assumed stock options associated with pre-acquisition services of Awake employees was immaterial. The fair value of $21.3 million of the unvested replacement options was excluded from the purchase price. These awards, which are subject to the recipients’ continued service with the Company, will be recognized ratably as stock-based compensation expense over the requisite service period.

[0001596532-22-000026:notes:117]
Both acquisitions were accounted for as a business combination with the aggregate purchase price allocated to the assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date. The following table summarizes the final purchase price allocation for the two acquisitions (in thousands):

[0001596532-22-000026:notes:118]
|  |  | Amount |
| Cash and cash equivalents |  | $ | 21,051 |  |
| Other tangible assets |  | 19,580 |  |
| Liabilities |  | (28,598) |  |
| Intangible assets |  | 101,640 |  |
| Goodwill |  | 134,841 |  |
| Net assets acquired |  | $ | 248,514 |  |

[0001596532-22-000026:notes:119]
The acquired intangible assets are amortized on a straight-line basis over their estimated useful lives, as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. The following table shows the valuation of the intangible assets acquired (in thousands) along with their weighted average estimated useful lives:

[0001596532-22-000026:notes:120]
|  |  | Acquisition Date Fair Value |  | Weighted Average Estimated Useful Life |
| Developed technology |  | $ | 72,220 |  |  | 7 years |
| Customer relationships |  | 18,840 |  |  | 7 years |
| Trade name |  | 6,520 |  |  | 5 years |
| Others |  | 4,060 |  |  | 2 years |
| Total intangible assets acquired |  | $ | 101,640 |  |  |  |

[0001596532-22-000026:notes:121]
The goodwill of $134.8 million is primarily attributable to the expected synergies created by incorporating the solutions of the acquired businesses into our technology platform, and the value of the assembled workforce. The goodwill is not deductible for income taxes purposes. The Company’s consolidated financial statements include the accounts of Big Switch and Awake Security starting as of the acquisition date. Pro forma and historical post-acquisition results of operations for these acquisitions were not material to the Company’s consolidated financial statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-22-000026:notes:122]
Fair Value MeasurementsWe measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value on a recurring basis. The following tables summarize the amortized costs, unrealized gains and losses, and fair values of these financial assets by significant investment category and their levels within the fair value hierarchy (in thousands):

[0001596532-22-000026:notes:123]
|  |  | December 31, 2021 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 221,382 |  |  | $ | — |  |  | $ | — |  |  | $ | 221,382 |  |  | $ | 221,382 |  |  | $ | — |  |  | $ | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 141,274 |  |  | — |  |  | — |  |  | 141,274 |  |  | — |  |  | 141,274 |  |  | — |  |
| Certificates of deposits (1) |  | 44,931 |  |  | — |  |  | — |  |  | 44,931 |  |  | — |  |  | 44,931 |  |  | — |  |
| U.S. government notes |  | 1,060,716 |  |  | 3 |  |  | (2,909) |  |  | 1,057,810 |  |  | 1,057,810 |  |  | — |  |  | — |  |
| Corporate bonds |  | 1,255,149 |  |  | 105 |  |  | (3,028) |  |  | 1,252,226 |  |  | — |  |  | 1,252,226 |  |  | — |  |
| Agency securities |  | 291,558 |  |  | 36 |  |  | (333) |  |  | 291,261 |  |  | — |  |  | 291,261 |  |  | — |  |
|  |  | 2,793,628 |  |  | 144 |  |  | (6,270) |  |  | 2,787,502 |  |  | 1,057,810 |  |  | 1,729,692 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,237 |  |  | — |  |  | — |  |  | 4,237 |  |  | 4,237 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 3,019,247 |  |  | $ | 144 |  |  | $ | (6,270) |  |  | $ | 3,013,121 |  |  | $ | 1,283,429 |  |  | $ | 1,729,692 |  |  | $ | — |  |
| ____________________ |
| (1) As of December 31, 2021, all of our certificates of deposits were domestic deposits. |

[0001596532-22-000026:notes:124]
|  |  | December 31, 2020 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 438,854 |  |  | $ | — |  |  | $ | — |  |  | $ | 438,854 |  |  | $ | 438,854 |  |  | $ | — |  |  | $ | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 51,211 |  |  | — |  |  | — |  |  | 51,211 |  |  | — |  |  | 51,211 |  |  | — |  |
| Certificates of deposits (1) |  | 50,136 |  |  | 3 |  |  | — |  |  | 50,139 |  |  | — |  |  | 50,139 |  |  | — |  |
| U.S. government notes |  | 523,320 |  |  | 187 |  |  | (1) |  |  | 523,506 |  |  | 523,506 |  |  | — |  |  | — |  |
| Corporate bonds |  | 878,484 |  |  | 1,167 |  |  | (330) |  |  | 879,321 |  |  | — |  |  | 879,321 |  |  | — |  |
| Agency securities |  | 475,132 |  |  | 343 |  |  | (3) |  |  | 475,472 |  |  | — |  |  | 475,472 |  |  | — |  |
|  |  | 1,978,283 |  |  | 1,700 |  |  | (334) |  |  | 1,979,649 |  |  | 523,506 |  |  | 1,456,143 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,235 |  |  | — |  |  | — |  |  | 4,235 |  |  | 4,235 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 2,421,372 |  |  | $ | 1,700 |  |  | $ | (334) |  |  | $ | 2,422,738 |  |  | $ | 966,595 |  |  | $ | 1,456,143 |  |  | $ | — |  |
| ____________________ |
| (1) As of December 31, 2020, all of our certificates of deposits were domestic deposits. |

[0001596532-22-000026:notes:125]
As of December 31, 2021 and 2020, total unrealized losses of our marketable securities were $6.3 million and $0.3 million, respectively, none of which have been in a continuous unrealized loss position for more than 12 months. We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. We expect to realize the full value of these investments upon maturity or sale and therefore, we do not consider any of our marketable securities to be impaired as of December 31, 2021 and December 31, 2020. We did not recognize any credit losses or non-credit-related impairments related to our available-for-sale marketable securities for the years ended December 31, 2021, 2020, and 2019.

[0001596532-22-000026:notes:126]
As of December 31, 2021, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale marketable securities, by remaining contractual maturity, are as follows (in thousands):

[0001596532-22-000026:notes:127]
|  |  | December 31, 2021 |
| Due in 1 year or less |  | $ | 1,691,472 |  |
| Due in 1 year through 2 years |  | 1,096,030 |  |
| Total marketable securities |  | $ | 2,787,502 |  |

[0001596532-22-000026:notes:128]
The weighted-average remaining duration of our current marketable securities is approximately 0.8 years as of December 31, 2021.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-22-000026:notes:129]
Financial Statements Details
Cash, Cash Equivalents and Restricted Cash

[0001596532-22-000026:notes:130]
The reconciliation of cash, cash equivalents and restricted cash reported in the accompanying consolidated balance sheets to the total of the same such amounts in the accompanying consolidated statements of cash flows is as follows (in thousands):

[0001596532-22-000026:notes:131]
|  |  | December 31, |
|  |  | 2021 |  | 2020 |
| Cash and cash equivalents |  | $ | 620,813 |  |  | $ | 893,219 |  |
| Restricted cash included in other assets |  | 4,237 |  |  | 4,235 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 625,050 |  |  | $ | 897,454 |  |

[0001596532-22-000026:notes:132]
Accounts Receivable, net

[0001596532-22-000026:notes:133]
Accounts receivable, net consists of the following (in thousands):

[0001596532-22-000026:notes:134]
|  |  | December 31, |
|  |  | 2021 |  | 2020 |
| Accounts receivable |  | $ | 521,597 |  |  | $ | 394,037 |  |
| Allowance for doubtful accounts |  | (132) |  |  | (659) |  |
| Product sales rebate and returns reserve |  | (4,956) |  |  | (3,838) |  |
| Accounts receivable, net |  | $ | 516,509 |  |  | $ | 389,540 |  |

[0001596532-22-000026:notes:135]
Allowance for Doubtful Accounts

[0001596532-22-000026:notes:136]
Activities in the allowance for doubtful accounts consist of the following (in thousands):

[0001596532-22-000026:notes:137]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Balance at the beginning of year |  | $ | 659 |  |  | $ | 638 |  |  | $ | 507 |  |
| Additions charged to expense |  | (154) |  |  | 397 |  |  | 221 |  |
| Deductions/write-offs |  | (373) |  |  | (376) |  |  | (90) |  |
| Balance at the end of year |  | $ | 132 |  |  | $ | 659 |  |  | $ | 638 |  |

[0001596532-22-000026:notes:138]
Product Sales Rebate and Returns Reserve

[0001596532-22-000026:notes:139]
Activities in the product sales rebate and returns reserve consist of the following (in thousands):

[0001596532-22-000026:notes:140]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Balance at the beginning of year |  | $ | 3,838 |  |  | $ | 5,522 |  |  | $ | 8,613 |  |
| Additions charged against revenue |  | 7,104 |  |  | 9,454 |  |  | 2,032 |  |
| Consumption |  | (5,986) |  |  | (11,138) |  |  | (5,123) |  |
| Balance at the end of year |  | $ | 4,956 |  |  | $ | 3,838 |  |  | $ | 5,522 |  |

[0001596532-22-000026:notes:141]
Inventories

[0001596532-22-000026:notes:142]
Inventories consist of the following (in thousands):

[0001596532-22-000026:notes:143]
|  |  | December 31, |
|  |  | 2021 |  | 2020 |
| Raw materials |  | $ | 316,737 |  |  | $ | 219,218 |  |
| Finished goods |  | 333,380 |  |  | 260,450 |  |
| Total inventories |  | $ | 650,117 |  |  | $ | 479,668 |  |

[0001596532-22-000026:notes:144]
Prepaid Expenses and Other Current Assets

[0001596532-22-000026:notes:145]
Prepaid expenses and other current assets consist of the following (in thousands):

[0001596532-22-000026:notes:146]
|  |  | December 31, |
|  |  | 2021 |  | 2020 |
| Inventory deposits |  | $ | 46,311 |  |  | $ | 18,783 |  |
| Prepaid income taxes |  | 8,977 |  |  | 267 |  |
| Other current assets |  | 163,916 |  |  | 60,556 |  |
| Other prepaid expenses and deposits |  | 18,531 |  |  | 15,316 |  |
| Total prepaid expenses and other current assets |  | $ | 237,735 |  |  | $ | 94,922 |  |

[0001596532-22-000026:notes:147]
Property and Equipment, net

[0001596532-22-000026:notes:148]
Property and equipment, net consists of the following (in thousands):

[0001596532-22-000026:notes:149]
|  |  | December 31, |
|  |  | 2021 |  | 2020 |
| Land |  | $ | 40,145 |  |  | $ | — |  |
| Equipment and machinery |  | 90,915 |  |  | 70,655 |  |
| Computer hardware and software |  | 44,083 |  |  | 40,081 |  |
| Furniture and fixtures |  | 3,634 |  |  | 3,787 |  |
| Leasehold improvements |  | 30,502 |  |  | 31,448 |  |
| Construction-in-process |  | 2,378 |  |  | 1,441 |  |
| Property and equipment, gross |  | 211,657 |  |  | 147,412 |  |
| Less: accumulated depreciation |  | (133,023) |  |  | (115,181) |  |
| Property and equipment, net |  | $ | 78,634 |  |  | $ | 32,231 |  |

[0001596532-22-000026:notes:150]
Depreciation expense was $19.5 million, $20.1 million and $19.0 million for the years ended December 31, 2021, 2020 and 2019, respectively.

[0001596532-22-000026:notes:151]
Accrued Liabilities

[0001596532-22-000026:notes:152]
Accrued liabilities consist of the following (in thousands):

[0001596532-22-000026:notes:153]
|  |  | December 31, |
|  |  | 2021 |  | 2020 |
| Accrued payroll related costs |  | $ | 99,571 |  |  | $ | 73,634 |  |
| Accrued manufacturing costs |  | 80,213 |  |  | 43,181 |  |
| Accrued product development costs |  | 22,188 |  |  | 6,733 |  |
| Accrued warranty costs |  | 10,414 |  |  | 9,314 |  |
| Other |  | 14,257 |  |  | 10,495 |  |
| Total accrued liabilities |  | $ | 226,643 |  |  | $ | 143,357 |  |

[0001596532-22-000026:notes:154]
Warranty Accrual

[0001596532-22-000026:notes:155]
The following table summarizes the activity related to our accrued liability for estimated future warranty costs (in thousands):

[0001596532-22-000026:notes:156]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |
| Warranty accrual, beginning of year |  | $ | 9,314 |  |  | $ | 6,742 |  |
| Liabilities accrued for warranties issued during the year |  | 12,659 |  |  | 9,737 |  |
| Warranty costs incurred during the year |  | (11,559) |  |  | (7,165) |  |
| Warranty accrual, end of year |  | $ | 10,414 |  |  | $ | 9,314 |  |

[0001596532-22-000026:notes:157]
Contract Assets

[0001596532-22-000026:notes:158]
The following table summarizes the beginning and ending balances of our contract assets (in thousands):

[0001596532-22-000026:notes:159]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |
| Contract assets, beginning balance |  | $ | 16,380 |  |  | $ | 25,565 |  |
| Contract assets, ending balance |  | 24,388 |  |  | 16,380 |  |

[0001596532-22-000026:notes:160]
Contract Liabilities

[0001596532-22-000026:notes:161]
The following table summarizes the activity related to our contract liabilities (in thousands):

[0001596532-22-000026:notes:162]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |
| Contract liabilities, beginning balance |  | $ | 85,957 |  |  | $ | 61,050 |  |
| Less: Revenue recognized from beginning balance |  | (34,177) |  |  | (23,394) |  |
| Less: Beginning balance reclassified to deferred revenue |  | (1,945) |  |  | (1,638) |  |
| Add: Contract liabilities recognized |  | 43,547 |  |  | 49,939 |  |
| Contract liabilities, ending balance |  | $ | 93,382 |  |  | $ | 85,957 |  |

[0001596532-22-000026:notes:163]
As of December 31, 2021 and 2020, $38.7 million and $34.5 million, respectively, of our contract liabilities were recorded within other current liabilities with the remaining balance recorded within other long-term liabilities in the accompanying consolidated balance sheets.

[0001596532-22-000026:notes:164]
Deferred Revenue

[0001596532-22-000026:notes:165]
Deferred revenue is comprised mainly of unearned revenue related to multi-year PCS contracts, services and product deferrals related to acceptance clauses. The following table summarizes the activity related to our deferred revenue (in thousands):

[0001596532-22-000026:notes:166]
|  |  | Year Ended December 31, 2021 |
| Deferred revenue, beginning balance |  | $ | 650,827 |  |
| Less: Revenue recognized from beginning balance |  | (373,881) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 652,366 |  |
| Deferred revenue, ending balance |  | $ | 929,312 |  |

[0001596532-22-000026:notes:167]
Other Performance Obligations

[0001596532-22-000026:notes:168]
Other performance obligations include unbilled contract revenue for services and products that will be recognized in future periods. As of December 30, 2021, other performance obligations of $187.0 million were comprised of unbilled multi-year PCS contract amounts.

[0001596532-22-000026:notes:169]
Revenue from Total Remaining Performance Obligations

[0001596532-22-000026:notes:170]
Revenue from total remaining performance obligations represents contract liabilities, deferred revenue and other performance obligations. As of December 31, 2021, approximately $1,209.7 million of revenue is expected to be recognized from remaining performance obligations. We expect to recognize revenue on approximately 82% of these remaining performance obligations over the next 2 years and 18% during years 3 to 5.

[0001596532-22-000026:notes:171]
Other Income, Net

[0001596532-22-000026:notes:172]
Other income, net consists of the following (in thousands):

[0001596532-22-000026:notes:173]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Other income, net: |  |  |  |  |  |  |
| Interest income |  | $ | 7,215 |  |  | $ | 27,139 |  |  | $ | 51,144 |  |
| Gain on sale of marketable securities |  | — |  |  | 9,432 |  |  | — |  |
| Gain on investments in privately-held companies |  | — |  |  | 4,164 |  |  | 5,427 |  |
| Other expense |  | (1,075) |  |  | (1,556) |  |  | (75) |  |
| Total other income, net |  | $ | 6,140 |  |  | $ | 39,179 |  |  | $ | 56,496 |  |


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-22-000026:notes:174]
Investments
Investments in Privately-Held Companies

[0001596532-22-000026:notes:175]
Our investments in privately-held companies do not have readily determinable fair values. Their initial cost is subsequently adjusted to fair value on a non-recurring basis based on observable price changes from orderly transactions of identical or similar securities of the same issuer or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to these securities. In addition, the valuation requires management judgment due to the absence of market price and lack of liquidity. The following table summarizes the activity related to our investments in privately-held companies held as of December 31, 2021 and 2020 (in thousands):

[0001596532-22-000026:notes:176]
|  |  | December 31, 2021 |  | December 31, 2020 |
| Cost of investments |  | $ | 14,933 |  |  | $ | 3,000 |  |
| Cumulative impairment |  | — |  |  | — |  |
| Cumulative upward adjustments |  | 5,314 |  |  | 5,314 |  |
| Carrying amount of investments |  | $ | 20,247 |  |  | $ | 8,314 |  |

[0001596532-22-000026:notes:177]
During the year ended December 31, 2019, we recorded a realized gain of $4.3 million upon the sale of one of our investments. In the year ended December 31, 2021, we did not record any adjustments to our investments, and in the years ended December 31, 2020 and 2019, we recorded $4.2 million and $1.2 million of unrealized gains, respectively. These unrealized gains were recorded on investments that were re-measured to fair value as of the date observable transactions occurred. The aforementioned realized and unrealized gains were recorded within other income, net in the accompanying consolidated statements of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001596532-22-000026:notes:178]
Goodwill and Acquisition-Related Intangible Assets 
Goodwill

[0001596532-22-000026:notes:179]
The changes in the carrying values of goodwill for the years ended December 31, 2021 and 2020 are as follows (in thousands):

[0001596532-22-000026:notes:180]
|  |  | Amount |
| Balance at December 31, 2019 |  | $ | 54,855 |  |
| Additions related to acquisitions (See Note 2 for additional information) |  | 134,841 |  |
| Balance at December 31, 2020 |  | 189,696 |  |
| Escrow receipts from past acquisitions |  | (1,299) |  |
| Balance at December 31, 2021 |  | $ | 188,397 |  |

[0001596532-22-000026:notes:181]
The Company performed an annual test for goodwill impairment in the fourth quarter of the fiscal years ended December 31, 2021 and 2020 and determined that goodwill was not impaired.

[0001596532-22-000026:notes:182]
Acquisition-Related Intangible Assets

[0001596532-22-000026:notes:183]
The following table presents details of our acquisition-related intangible assets as of December 31, 2021 and 2020 (in thousands, except for years):

[0001596532-22-000026:notes:184]
|  |  | December 31, 2021 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life(In Years) |
| Developed technology |  | $ | 124,730 |  |  | $ | (53,663) |  |  | $ | 71,067 |  |  | 4.5 |
| Customer relationships |  | 25,920 |  |  | (7,899) |  |  | 18,021 |  |  | 5.2 |
| Trade name |  | 8,990 |  |  | (4,693) |  |  | 4,297 |  |  | 3.8 |
| Others |  | 5,720 |  |  | (5,550) |  |  | 170 |  |  | 0.1 |
| Total |  | $ | 165,360 |  |  | $ | (71,805) |  |  | $ | 93,555 |  |  | 4.6 |

[0001596532-22-000026:notes:185]
|  |  | December 31, 2020 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life(In Years) |
| Developed technology |  | $ | 124,730 |  |  | $ | (31,805) |  |  | $ | 92,925 |  |  | 5.2 |
| Customer relationships |  | 25,920 |  |  | (4,298) |  |  | 21,622 |  |  | 6.2 |
| Trade name |  | 8,990 |  |  | (2,946) |  |  | 6,044 |  |  | 4.3 |
| Others |  | 5,720 |  |  | (3,521) |  |  | 2,199 |  |  | 1.1 |
| Total |  | $ | 165,360 |  |  | $ | (42,570) |  |  | $ | 122,790 |  |  | 5.3 |

[0001596532-22-000026:notes:186]
Amortization expense related to acquisition-related intangible assets was $29.2 million, $24.1 million and $13.4 million for the years ended December 31, 2021, 2020 and 2019, respectively.

[0001596532-22-000026:notes:187]
As of December 31, 2021, future estimated amortization expense related to the acquired-related intangible assets is as follows (in thousands):

[0001596532-22-000026:notes:188]
| Years Ending December 31, |  | Future Amortization Expense |
| 2022 |  | $ | 26,774 |  |
| 2023 |  | 22,781 |  |
| 2024 |  | 16,103 |  |
| 2025 |  | 9,750 |  |
| 2026 |  | 7,737 |  |
| Thereafter |  | 10,410 |  |
| Total |  | $ | 93,555 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-22-000026:notes:189]
Commitments and Contingencies
Operating Leases

[0001596532-22-000026:notes:190]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancellable operating lease arrangements that expire on various dates through 2028. Some of our leases include options to extend the term of such leases for a period from three months to up to 10 years and/or options to early

[0001596532-22-000026:notes:191]
terminate the leases. As of December 31, 2021, we did not include any such options in determining the lease terms because we were not reasonably certain that we would exercise these options.

[0001596532-22-000026:notes:192]
The following table summarizes the supplemental balance sheet information related to our operating leases (in thousands):

[0001596532-22-000026:notes:193]
|  |  | December 31, 2021 |  | December 31, 2020 |
| Right-of-use assets: |  |  |  |  |
| Operating lease right-of-use assets |  | $ | 65,182 |  |  | $ | 77,288 |  |
| Lease liabilities: |  |  |  |  |
| Operating lease liabilities, current (included in other current liabilities) |  | 20,298 |  |  | 17,773 |  |
| Operating lease liabilities, non-current |  | 56,527 |  |  | 72,397 |  |
| Total operating lease liabilities |  | $ | 76,825 |  |  | $ | 90,170 |  |

[0001596532-22-000026:notes:194]
The following table summarizes our lease costs (in thousands):

[0001596532-22-000026:notes:195]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |
| Operating lease costs: |  |  |  |  |
| Fixed lease costs |  | $ | 23,230 |  |  | $ | 23,392 |  |
| Variable lease costs |  | 7,781 |  |  | 7,459 |  |
| Total operating lease costs |  | $ | 31,011 |  |  | $ | 30,851 |  |

[0001596532-22-000026:notes:196]
The operating lease costs in the table above include costs for long-term and short-term leases. Total short-term lease costs were immaterial. Fixed lease costs include expenses recognized for base rent payments on a straight-line basis. Variable lease costs primarily include maintenance, utilities and operating expenses that are incremental to the fixed base rent payments, and are excluded from the calculation of operating lease liabilities and ROU assets. For the years ended December 31, 2021 and 2020, cash paid for amounts associated with our operating lease liabilities were approximately $22.3 million and $20.2 million, respectively, which were classified as operating activities in the accompanying consolidated statements of cash flows.

[0001596532-22-000026:notes:197]
Maturities of operating lease liabilities as of December 31, 2021 are presented in the table below (in thousands):

[0001596532-22-000026:notes:198]
| Years ending December 31, |  | Amount |
| 2022 |  | $ | 23,527 |  |  |  |
| 2023 |  | 21,132 |  |  |  |
| 2024 |  | 12,796 |  |  |  |
| 2025 |  | 9,564 |  |  |  |
| 2026 |  | 7,730 |  |  |  |
| 2027 and thereafter |  | 12,254 |  |  |  |
| Total undiscounted operating lease payments (excluding non-lease components) |  | 87,003 |  |  |  |
| Less: imputed interest |  | (10,178) |  |  |  |
| Present value of operating lease payments as of December 31, 2021 |  | $ | 76,825 |  |  |  |

[0001596532-22-000026:notes:199]
|  |  | December 31, 2021 |  | December 31, 2020 |
| Weighted-average remaining lease term — operating leases |  | 4.6 years |  | 5.4 years |
| Weighted-average discount rate — operating leases |  | 5.0% |  | 5.0% |

[0001596532-22-000026:notes:200]
Purchase Commitments

[0001596532-22-000026:notes:201]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf.  In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of December 31, 2021, we had non-cancellable purchase commitments of $2,540.1 million, with $2,318.6 million payable within 12 months and the majority of the remaining $221.5 million payable within 2023. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-22-000026:notes:202]
In addition to the purchase obligations outlined above, we also entered into an agreement covering an additional $275 million of extended lead time component purchase commitments in support of 2023 forecasted demand, for which purchase orders had not been issued as of December 31, 2021.

[0001596532-22-000026:notes:203]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $49.1 million and $21.5 million as of December 31, 2021 and 2020, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the accompanying consolidated balance sheets. In January 2022, we paid an additional cash deposit of $50.0 million to one of our contract manufacturers to secure our purchase commitments.

[0001596532-22-000026:notes:204]
Guarantees

[0001596532-22-000026:notes:205]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third-party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions, and our guarantee and indemnification arrangements have not had any material impact on our consolidated financial statements to date.

[0001596532-22-000026:notes:206]
Legal Proceedings

[0001596532-22-000026:notes:207]
WSOU Investments, LLC

[0001596532-22-000026:notes:208]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California; trial has been set for October 23, 2023.

[0001596532-22-000026:notes:209]
We intend to vigorously defend against the claims brought against us by WSOU. However, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-22-000026:notes:210]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated. However, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-22-000026:notes:211]
Other matters

[0001596532-22-000026:notes:212]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-22-000026:notes:213]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. Based on currently available information, management does not believe that any liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. If an unfavorable outcome were to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-22-000026:notes:214]
Stockholders' Equity and Stock-Based Compensation
Stock Repurchase Programs

[0001596532-22-000026:notes:215]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the "Repurchase Program").  This authorization allowed us to repurchase shares of our common stock over three years, and we completed our repurchases under the Repurchase Program during the fourth quarter of 2021. In the fourth quarter of 2021, our board of directors authorized an additional $1.0 billion stock repurchase program (the “New Repurchase Program”), which allows us to repurchase shares of our common stock to be funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Exchange Act, or a combination of the foregoing. The New Repurchase Program commenced in November 2021 and expires on the three year anniversary thereof. The New Repurchase Program does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of December 31, 2021, the remaining authorized amount for stock repurchases under the New Repurchase Program was approximately $927.0 million.

[0001596532-22-000026:notes:216]
A summary of the stock repurchase activity under the Repurchase Programs is as follows, as adjusted to give effect to the Stock Split (in thousands, except per share amounts):

[0001596532-22-000026:notes:217]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |
| Aggregate purchase price |  | $ | 411,645 |  |  | $ | 395,173 |  |
| Shares repurchased |  | 4,537 |  |  | 8,048 |  |
| Average price paid per share |  | $ | 90.73 |  |  | $ | 49.11 |  |

[0001596532-22-000026:notes:218]
The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings.  All shares repurchased under the Repurchase Programs have been retired.

[0001596532-22-000026:notes:219]
2014 Equity Incentive Plan

[0001596532-22-000026:notes:220]
In April 2014, the board of directors and stockholders approved the 2014 Equity Incentive Plan (the “2014 Plan”), effective on the first day that our common stock was publicly traded, and simultaneously terminated the 2004 and 2011 equity plans as to future grants.  However, these plans will continue to govern the terms and conditions of the outstanding options previously granted thereunder.

[0001596532-22-000026:notes:221]
Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”).  The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of the outstanding shares of our common stock on the immediately preceding December 31, but not to exceed 50,000,000 shares (the “2014 Plan Evergreen Increase”), unless the board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2021, our board of directors authorized an increase

[0001596532-22-000026:notes:222]
of 9,140,912 shares to the shares available for issuance under the 2014 Plan, as adjusted to give effect to the Stock Split. In fiscal 2020, in connection with our acquisition of Awake Security, we assumed the stock options outstanding under the Awake Security 2014 Equity Incentive Plan and registered an additional 461,352 shares to be available for future issuance, as adjusted to give effect to the Stock Split. As of December 31, 2021, there remained approximately 88.0 million shares available for issuance under the 2014 Plan. In February, 2022, our board of directors authorized an increase of 9,230,434 shares to shares available for future issuance under the 2014 Plan effective January 1, 2022.

[0001596532-22-000026:notes:223]
2014 Employee Stock Purchase Plan

[0001596532-22-000026:notes:224]
In April 2014, the board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded.  The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding immediately preceding December 31, but not to exceed 10,000,000 shares, unless the board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2021, our board of directors authorized an increase of 3,046,968 shares as adjusted to give effect to the Stock Split to shares available for issuance under the ESPP. As of December 31, 2021, there remained 18.0 million shares available for issuance under the ESPP. In February, 2022, our board of directors authorized an increase of 3,076,811 shares to shares available for issuance under the ESPP effective January 1, 2022.

[0001596532-22-000026:notes:225]
Under our ESPP, eligible employees are permitted to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the exercise date. Each offering period lasts approximately two years starting on the first trading date after February 15 and August 15 of each year. Participants may purchase shares of common stock through payroll deductions up to 10% of their eligible compensation, subject to Internal Revenue Service mandated purchase limits.

[0001596532-22-000026:notes:226]
During the year ended December 31, 2021, we issued 458,284 shares at an average purchase price of $46.50 under our ESPP, as adjusted to give effect to the Stock Split.

[0001596532-22-000026:notes:227]
Stock Option Activities

[0001596532-22-000026:notes:228]
The following table summarizes the option activities and related information, as adjusted to give effect to the Stock Split (in thousands, except years and per share amounts):

[0001596532-22-000026:notes:229]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (In Years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2020 |  | 13,719 |  |  | $ | 11.29 |  |  | 3.6 |  | $ | 841,659 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (4,941) |  |  | 9.30 |  |  |  |  |  |
| Options canceled |  | (93) |  |  | 9.55 |  |  |  |  |  |
| Balance—December 31, 2021 |  | 8,685 |  |  | $ | 12.45 |  |  | 2.8 |  | $ | 1,140,369 |  |
| Vested and exercisable—December 31, 2021 |  | 6,650 |  |  | $ | 9.70 |  |  | 2.4 |  | $ | 891,466 |  |

[0001596532-22-000026:notes:230]
We did not grant any stock options in the year ended December 31, 2021. The weighted-average grant-date fair value of options granted during the years ended December 31, 2020 and 2019 was $46.24 and $26.86 per share, respectively, as adjusted to give effect to the Stock Split. The aggregate intrinsic value of options exercised during the years ended December 31, 2021, 2020 and 2019 was $410.9 million, $245.9 million and $323.1 million, respectively. The total fair value of options vested for the years ended December 31, 2021, 2020 and 2019 was approximately $25.3 million, $20.0 million and $23.0 million, respectively.

[0001596532-22-000026:notes:231]
Restricted Stock Unit (RSU) Activities

[0001596532-22-000026:notes:232]
The following table summarizes the RSU activities and related information, as adjusted to give effect to the Stock Split (in thousands, except per share amounts):

[0001596532-22-000026:notes:233]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |
| Unvested balance—December 31, 2020 |  | 7,263 |  |  | $ | 53.92 |  |
| RSUs granted (1) |  | 3,487 |  |  | 93.18 |  |
| RSUs vested |  | (2,265) |  |  | 53.15 |  |
| RSUs forfeited/canceled |  | (664) |  |  | 61.74 |  |
| Unvested balance—December 31, 2021 |  | 7,821 |  |  | $ | 70.98 |  |

[0001596532-22-000026:notes:234]
(1) Included in this amount are 268,000 performance-based RSUs (“PRSUs”, as adjusted to give effect to the Stock Split) to our CEO and other executive officers that include both service and performance-based conditions. These PRSUs will vest over three to four years, and the ultimate number of shares eligible to vest will vary between 0% and 200% of the amount granted based on the achievement of certain performance metrics over the performance period and each holder’s continued employment with Arista. As of December 31, 2021 we expect the achievement level of such awards to be at the higher end of the performance range.

[0001596532-22-000026:notes:235]
The weighted-average grant-date fair value of RSUs granted during the years ended December 31, 2021, 2020 and 2019 was $93.18, $54.11 and $60.53 per share, respectively, as adjusted to give effect to the Stock Split. The total fair value of RSUs vested for the years ended December 31, 2021, 2020 and 2019 was approximately $120.4 million, $85.4 million, and $65.7 million, respectively.

[0001596532-22-000026:notes:236]
Stock-Based Compensation Expense

[0001596532-22-000026:notes:237]
The following table summarizes the stock-based compensation expense related to our equity awards (in thousands):

[0001596532-22-000026:notes:238]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Cost of revenue |  | $ | 7,444 |  |  | $ | 6,272 |  |  | $ | 4,637 |  |
| Research and development |  | 99,770 |  |  | 79,913 |  |  | 53,068 |  |
| Sales and marketing |  | 46,521 |  |  | 34,944 |  |  | 29,168 |  |
| General and administrative |  | 33,140 |  |  | 15,913 |  |  | 14,407 |  |
| Total stock-based compensation |  | $ | 186,875 |  |  | $ | 137,042 |  |  | $ | 101,280 |  |

[0001596532-22-000026:notes:239]
Determination of Fair Value

[0001596532-22-000026:notes:240]
We record stock-based compensation awards based on fair value as of the grant date. We value RSUs at the market close price of our common stock on the grant date. For option awards and ESPP offerings, we use the Black-Scholes option pricing model to determine fair value. We recognize such costs as compensation expense generally on a straight-line basis over the requisite service period of the award.

[0001596532-22-000026:notes:241]
Stock Options

[0001596532-22-000026:notes:242]
We did not grant any stock options in the year ended December 31, 2021. For the years ended December 31, 2020 and 2019, the fair value of each stock option granted under our plans was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001596532-22-000026:notes:243]
|  |  |  | Year Ended December 31 |
|  |  |  | 2020 |  | 2019 |
| Expected term (in years) |  |  | 5.0 |  | 6.9 |
| Risk-free interest rate |  |  | 0.4 | % |  | 2.5 | % |
| Expected volatility |  |  | 43.5 | % |  | 42.8 | % |
| Dividend rate |  |  | — | % |  | — | % |

[0001596532-22-000026:notes:244]
ESPP

[0001596532-22-000026:notes:245]
The following table summarizes the assumptions relating to our ESPP:

[0001596532-22-000026:notes:246]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Expected term (in years) |  | 1.2 |  | 1.6 |  | 1.1 |
| Risk-free interest rate |  | 0.1 | % |  | 0.4 | % |  | 1.8 | % |
| Expected volatility |  | 40.2 | % |  | 45.1 | % |  | 42.5 | % |
| Dividend rate |  | — | % |  | — | % |  | — | % |

[0001596532-22-000026:notes:247]
As of December 31, 2021, there were $519.7 million of unrecognized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 3.3 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-22-000026:notes:248]
Net Income Per Share 
The following table sets forth the computation of our basic and diluted net income per share attributable to common stockholders, as adjusted to give effect to the Stock Split (in thousands, except per share amounts):

[0001596532-22-000026:notes:249]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Numerator: |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |
| Net income |  | $ | 840,854 |  |  | $ | 634,557 |  |  | $ | 859,867 |  |
| Less: undistributed earnings allocated to participating securities |  | — |  |  | — |  |  | (423) |  |
| Net income attributable to common stockholders, basic |  | $ | 840,854 |  |  | $ | 634,557 |  |  | $ | 859,444 |  |
| Diluted: |  |  |  |  |  |  |
| Net income attributable to common stockholders, basic |  | $ | 840,854 |  |  | $ | 634,557 |  |  | $ | 859,444 |  |
| Add: undistributed earnings allocated to participating securities |  | — |  |  | — |  |  | 24 |  |
| Net income attributable to common stockholders, diluted |  | $ | 840,854 |  |  | $ | 634,557 |  |  | $ | 859,468 |  |
| Denominator: |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders, basic |  | 306,512 |  |  | 303,936 |  |  | 305,248 |  |
| Diluted: |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders, basic |  | 306,512 |  |  | 303,936 |  |  | 305,248 |  |
| Add weighted-average effects of dilutive securities: |  |  |  |  |  |  |
| Stock options and RSUs |  | 12,464 |  |  | 13,848 |  |  | 18,260 |  |
| Employee stock purchase plan |  | 262 |  |  | 76 |  |  | 8 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders, diluted |  | 319,238 |  |  | 317,860 |  |  | 323,516 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |
| Basic |  | $ | 2.74 |  |  | $ | 2.09 |  |  | $ | 2.82 |  |
| Diluted |  | $ | 2.63 |  |  | $ | 2.00 |  |  | $ | 2.66 |  |

[0001596532-22-000026:notes:250]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share attributable to common stockholders because their effects would have been anti-dilutive for the periods presented, as adjusted to give effect to the Stock Split (in thousands):

[0001596532-22-000026:notes:251]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Stock options and RSUs |  | 298 |  |  | 1,380 |  |  | 1,272 |  |
| Employee stock purchase plan |  | 37 |  |  | 332 |  |  | 328 |  |
| Total |  | 335 |  |  | 1,712 |  |  | 1,600 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-22-000026:notes:252]
Income Taxes
The components of income before provision for income taxes are as follows (in thousands):

[0001596532-22-000026:notes:253]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Domestic |  | $ | 737,620 |  |  | $ | 621,838 |  |  | $ | 727,632 |  |
| Foreign |  | 193,259 |  |  | 117,025 |  |  | 134,638 |  |
| Income before income taxes |  | $ | 930,879 |  |  | $ | 738,863 |  |  | $ | 862,270 |  |

[0001596532-22-000026:notes:254]
The components of the provision for income taxes are as follows (in thousands):

[0001596532-22-000026:notes:255]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Current provision for income taxes: |  |  |  |  |  |  |
| Federal |  | $ | 137,203 |  |  | $ | 78,843 |  |  | $ | 58,187 |  |
| State |  | 38,478 |  |  | 21,135 |  |  | 19,067 |  |
| Foreign |  | 13,391 |  |  | 12,891 |  |  | 928 |  |
| Total current |  | 189,072 |  |  | 112,869 |  |  | 78,182 |  |
| Deferred tax expense (benefit): |  |  |  |  |  |  |
| Federal |  | (98,534) |  |  | (17,592) |  |  | 362,056 |  |
| State |  | (16,289) |  |  | (849) |  |  | (4,511) |  |
| Foreign |  | 15,776 |  |  | 9,878 |  |  | (433,324) |  |
| Total deferred tax expense (benefit) |  | (99,047) |  |  | (8,563) |  |  | (75,779) |  |
| Total provision for income taxes |  | $ | 90,025 |  |  | $ | 104,306 |  |  | $ | 2,403 |  |

[0001596532-22-000026:notes:256]
The reconciliation of the statutory federal income tax rate and our effective income tax rate is as follows (in percentages):

[0001596532-22-000026:notes:257]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| U.S. federal statutory income tax rate |  | 21.00 | % |  | 21.00 | % |  | 21.00 | % |
| State tax, net of federal benefit |  | 1.89 |  |  | 2.23 |  |  | 1.30 |  |
| Taxes on foreign earnings differential |  | (2.13) |  |  | (0.92) |  |  | (2.59) |  |
| Tax credits |  | (2.70) |  |  | (2.64) |  |  | (3.10) |  |
| Change in valuation allowance |  | 0.01 |  |  | (0.18) |  |  | (0.10) |  |
| Intra-Entity Sale |  | — |  |  | — |  |  | (9.95) |  |
| Stock-based compensation |  | (8.32) |  |  | (5.65) |  |  | (6.56) |  |
| Acquisition and integration costs |  | 0.03 |  |  | 0.27 |  |  | 0.04 |  |
| Other, net |  | (0.11) |  |  | 0.01 |  |  | 0.24 |  |
| Effective tax rate |  | 9.67 | % |  | 14.12 | % |  | 0.28 | % |

[0001596532-22-000026:notes:258]
The change in our income taxes was largely attributable to increased tax benefits from stock-based compensation, combined with a favorable change in jurisdictional mix of earnings. Excess tax benefits resulting from stock awards were $105.8 million, $58.7 million and $77.9 million for the years ended December 31, 2021, 2020 and 2019, respectively.

[0001596532-22-000026:notes:259]
The tax effects of temporary differences that give rise to significant portions of deferred tax assets (liabilities) are as follows (in thousands):

[0001596532-22-000026:notes:260]
|  |  | December 31, |
|  |  | 2021 |  | 2020 |
| Deferred tax assets: |  |  |  |  |
| Intangible assets |  | $ | 385,291 |  |  | $ | 392,053 |  |
| Reserves and accruals not currently deductible |  | 34,648 |  |  | 32,866 |  |
| Deferred revenue |  | 146,745 |  |  | 47,740 |  |
| Tax credits |  | 85,390 |  |  | 68,592 |  |
| Lease financing obligation |  | 17,845 |  |  | 22,080 |  |
| Capitalized research and development expenses |  | 28,012 |  |  | 28,009 |  |
| Stock-based compensation |  | 19,760 |  |  | 18,548 |  |
| Net operating losses |  | 21,284 |  |  | 23,998 |  |
| Other |  | 3,430 |  |  | 204 |  |
| Gross deferred tax assets |  | 742,405 |  |  | 634,090 |  |
| Valuation allowance |  | (109,985) |  |  | (82,638) |  |
| Total deferred tax assets |  | 632,420 |  |  | 551,452 |  |
| Deferred tax liabilities: |  |  |  |  |
| US tax on foreign earnings |  | (302,746) |  |  | (317,970) |  |
| Right of use asset |  | (14,892) |  |  | (18,764) |  |
| Other |  | (1,561) |  |  | (1,123) |  |
| Total deferred tax liabilities |  | (319,199) |  |  | (337,857) |  |
| Net deferred tax assets |  | $ | 313,221 |  |  | $ | 213,595 |  |

[0001596532-22-000026:notes:261]
The following table presents the breakdown between non-current deferred tax assets and liabilities (in thousands):

[0001596532-22-000026:notes:262]
|  |  | December 31, |
|  |  | 2021 |  | 2020 |
| Deferred tax assets, non-current |  | $ | 442,295 |  |  | $ | 441,531 |  |
| Deferred tax liabilities, non-current |  | (129,074) |  |  | (227,936) |  |
| Total net deferred tax assets |  | $ | 313,221 |  |  | $ | 213,595 |  |

[0001596532-22-000026:notes:263]
Recognition of deferred tax assets is appropriate when realization of these assets is more likely than not. We believe, more likely than not, that we will have sufficient taxable income after deductions related to share-based awards to utilize our remaining deferred tax assets, with the exception of California, Canada, and U.K. deferred tax assets. In 2021, we increased our R&D tax credit carryforwards and capitalization in California and Canada, and increased our NOL carryforward in the U.K., which resulted in an increase of our valuation allowance on our deferred tax assets by $27.4 million. Therefore, we recorded a valuation allowance of $110.0 million and $82.6 million as of December 31, 2021 and 2020, respectively, against California, Canada, and U.K. deferred tax assets, since it is more likely than not that these assets will be not be recognized.

[0001596532-22-000026:notes:264]
As of December 31, 2021, we had $227.5 million and $94.0 million of net operating loss carryforwards for federal and state income tax purposes, respectively, from the acquisition of Mojo Networks, Big Switch Networks and Awake Security. These federal and state losses will begin to expire in 2028 and 2029, respectively. For foreign jurisdictions, we had combined foreign net operating loss carryforwards of $14.4 million, which do not expire.

[0001596532-22-000026:notes:265]
We had a federal credit of $2.0 million from the acquisition of Awake Security, which will begin to expire in 2038, and a California state credit of $156.2 million, which can be carried over indefinitely. For foreign jurisdictions, we had $0.6 million of Canadian scientific research and experimental development tax credit carry-forwards, which will begin to expire in 2034.

[0001596532-22-000026:notes:266]
Utilization of the net operating losses and tax credit carryforwards may be subject to limitations due to ownership change limitations provided in the Internal Revenue code and similar state or foreign provisions.

[0001596532-22-000026:notes:267]
The Tax Cuts and Jobs Act enacted on December 22, 2017 requires a Transition Tax on previously untaxed accumulated and current foreign earnings.  Correspondingly, all undistributed earnings are deemed to be taxed and distributions of the unremitted earnings do not have any significant U.S. federal income tax impact.  We have not provided for any remaining tax effect, if any, of limited outside basis differences of our foreign subsidiaries based upon plans of future reinvestment. The determination of the future tax consequences of the remittance of these earnings is not practicable.

[0001596532-22-000026:notes:268]
Uncertain Tax Positions

[0001596532-22-000026:notes:269]
We recognize uncertain tax positions only to the extent that management believes that it is more likely than not that the position will be sustained. The reconciliation of the beginning and ending amount of gross unrecognized tax benefits as of December 31, 2021, 2020 and 2019 is as follows (in thousands):

[0001596532-22-000026:notes:270]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Gross unrecognized tax benefits—beginning balance |  | $ | 92,500 |  |  | $ | 93,806 |  |  | $ | 74,436 |  |
| Increases related to tax positions taken in a prior year |  | 2,476 |  |  | 3,103 |  |  | 11,171 |  |
| Increases related to tax positions taken during current year |  | 21,104 |  |  | 20,274 |  |  | 22,714 |  |
| Decreases related to tax positions taken in a prior year |  | (853) |  |  | (18,029) |  |  | (89) |  |
| Decreases related to settlements with taxing authorities |  | — |  |  | — |  |  | (12,388) |  |
| Decreases related to lapse of statute of limitations |  | (414) |  |  | (6,654) |  |  | (2,120) |  |
| Adjustment for acquisition |  | — |  |  | — |  |  | 82 |  |
| Gross unrecognized tax benefits—ending balance |  | $ | 114,813 |  |  | $ | 92,500 |  |  | $ | 93,806 |  |

[0001596532-22-000026:notes:271]
As of December 31, 2021, 2020 and 2019, the total amount of gross unrecognized tax benefits was $114.8 million, $92.5 million and $93.8 million, respectively, of which $60.9 million, $44.7 million and $28.5 million would affect our effective tax rate if recognized.

[0001596532-22-000026:notes:272]
Our policy is to recognize interest and penalties accrued on any unrecognized tax benefits as a component of income tax expense. We have recorded a net expense for interest and penalties of $1.6 million and $0.1 million in the years ended December 31, 2021 and 2020, respectively. As of December 31, 2021 and 2020, we recognized a liability for interest and penalties of $3.6 million and $2.0 million, respectively. 
The statute of limitations for Federal and most states remains open for 2017 and forward. Some states have net operating loss and tax credit carryforwards, and therefore remain open to examination. The majority of our foreign tax returns are open to audit under the statute of limitations of the respective foreign countries, where the subsidiaries are located. It is possible that the amount of existing unrecognized tax benefits may decrease within the next 12 months as a result of statute of limitation lapses or payments to tax authorities in certain jurisdictions; however, an estimate of the range cannot be made.


## anet:GeographicInformationTextBlock

[0001596532-22-000026:notes:273]
Geographical Information 
We operate as one reportable segment. The following table represents revenue based on customers' shipping addresses (in thousands):

[0001596532-22-000026:notes:274]
|  |  | Year Ended December 31, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Americas |  | $ | 2,156,183 |  |  | $ | 1,771,992 |  |  | $ | 1,833,163 |  |
| Europe, Middle East and Africa |  | 486,836 |  |  | 326,729 |  |  | 381,651 |  |
| Asia Pacific |  | 305,018 |  |  | 218,791 |  |  | 195,892 |  |
| Total revenue |  | $ | 2,948,037 |  |  | $ | 2,317,512 |  |  | $ | 2,410,706 |  |

[0001596532-22-000026:notes:275]
Long-lived assets, excluding intercompany receivables, investments in subsidiaries, investments in privately-held companies and deferred tax assets, net by location are summarized as follows (in thousands):

[0001596532-22-000026:notes:276]
|  |  | December 31, |
|  |  | 2021 |  | 2020 |
| United States |  | $ | 62,163 |  |  | $ | 24,110 |  |
| International |  | 16,471 |  |  | 8,121 |  |
| Total |  | $ | 78,634 |  |  | $ | 32,231 |  |


## us-gaap:PostemploymentBenefitsDisclosureTextBlock

[0001596532-22-000026:notes:277]
Post-Employment Benefits We have a 401(k) Plan that covers substantially all of our employees in the U.S.  Effective January 1, 2017, we have elected to match 100% of employees' contributions up to a maximum of 3% of an employee's annual salary. Matching contributions are immediately vested. For the years ended December 31, 2021, 2020 and 2019, we contributed approximately $9.8 million, $7.4 million and $5.1 million for the matching contributions, respectively.
