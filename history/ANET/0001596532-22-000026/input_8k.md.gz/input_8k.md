# ANET 8-K — 0001596532-22-000025 filed 2022-02-14

## item codes, every 8-K on or before 2022-02-15

- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2022-02-15

- none on or before 2022-02-15

## item 2.02 — earnings release, exhibit 99.1

[0001596532-22-000025:8k_2_02:1]
EX-99.1
2
ex991q421-earningsrelease.htm
EX-99.1

[0001596532-22-000025:8k_2_02:2]
Document

[0001596532-22-000025:8k_2_02:3]
Exhibit 99.1

[0001596532-22-000025:8k_2_02:4]
Arista Networks, Inc. Reports Fourth Quarter and Year End 2021 Financial Results

[0001596532-22-000025:8k_2_02:5]
SANTA CLARA, Calif.- February 14, 2022 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments, today announced financial results for its fourth quarter and the full year ended December 31, 2021.

[0001596532-22-000025:8k_2_02:6]
Fourth Quarter Financial Results

[0001596532-22-000025:8k_2_02:7]
•Revenue of $824.5 million, an increase of 10.1% compared to the third quarter of 2021, and an increase of 27.1% from the fourth quarter of 2020.

[0001596532-22-000025:8k_2_02:8]
•GAAP gross margin of 63.4%, compared to GAAP gross margin of 63.9% in the third quarter of 2021 and 63.9% in the fourth quarter of 2020.

[0001596532-22-000025:8k_2_02:9]
•Non-GAAP gross margin of 64.3%, compared to non-GAAP gross margin of 64.9% in the third quarter of 2021 and 65.0% in the fourth quarter of 2020.

[0001596532-22-000025:8k_2_02:10]
•GAAP net income of $239.3 million, or $0.75 per diluted share, compared to GAAP net income of $183.0 million, or $0.58 per diluted share, in the fourth quarter of 2020.

[0001596532-22-000025:8k_2_02:11]
•Non-GAAP net income of $262.4 million, or $0.82 per diluted share, compared to non-GAAP net income of $197.7 million, or $0.62 per diluted share, in the fourth quarter of 2020.

[0001596532-22-000025:8k_2_02:12]
Full Year Financial Results

[0001596532-22-000025:8k_2_02:13]
•Revenue of $2.95 billion, an increase of 27.2% compared to fiscal year 2020.

[0001596532-22-000025:8k_2_02:14]
•GAAP gross margin of 63.8%, compared to GAAP gross margin of 63.9% in fiscal year 2020.

[0001596532-22-000025:8k_2_02:15]
•Non-GAAP gross margin of 64.8%, compared to non-GAAP gross margin of 65.0% in fiscal year 2020.

[0001596532-22-000025:8k_2_02:16]
•GAAP net income of $840.9 million, or $2.63 per diluted share, compared to GAAP net income of $634.6 million, or $2.00 per diluted share, in fiscal year 2020.

[0001596532-22-000025:8k_2_02:17]
•Non-GAAP net income of $915.0 million or $2.87 per diluted share, compared to non-GAAP net income of $718.4 million or $2.26 per diluted share, in fiscal year 2020.

[0001596532-22-000025:8k_2_02:18]
“I am delighted with Arista's record 2021 milestones in innovation, diversified customer momentum and earnings. We have executed well to establish Arista among the fastest growing networking companies in this decade," stated Jayshree Ullal, President and CEO of Arista Networks.

[0001596532-22-000025:8k_2_02:19]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO said, “The Arista team has shown great resilience and flexibility throughout 2021, maintaining operational excellence in the face of industry-wide challenges and delivering our first billion-dollar cash flow year.”

[0001596532-22-000025:8k_2_02:20]
Fourth Quarter Company Highlights

[0001596532-22-000025:8k_2_02:21]
•Arista Expands Extensible Operating System for Data-Driven Cloud Networking - Arista Networks announced the next major expansion of the Arista EOS® network stack with the introduction of the EOS Network Data Lake (NetDL™). Coupled with the AI/ML-driven Autonomous Virtual Assist (Arista AVA™) and a broad ecosystem of industry leaders, Arista is extending the EOS network stack architecture to provide a high-fidelity data lake capability for the next era of data-driven networking.

[0001596532-22-000025:8k_2_02:22]
•Arista Expands 400G for Enterprise and Cloud Customers - Arista, a leader in data-driven networking, announced the next generation of the widely deployed 7050X and 7060X Series, providing performance and cost benefits for customers of all sizes as they transition to 400G networks.

[0001596532-22-000025:8k_2_02:23]
•Arista Joins Microsoft Intelligent Security Association for Integration with Microsoft Azure Sentinel to Help Improve Customer Security – Arista announced it has joined the Microsoft Intelligent Security Association (MISA), an ecosystem of independent software vendors and managed security service providers that have integrated solutions to better defend against a world of increasing threats. Arista was nominated based on an integration between Arista’s NDR platform and Microsoft Azure Sentinel. This integration enables faster remediation of threats by combining network context and threat detection with log-based and endpoint insights within Azure Sentinel.

[0001596532-22-000025:8k_2_02:24]
Full Year Company Highlights

[0001596532-22-000025:8k_2_02:25]
•Arista Networks delivers Multi-domain Segmentation for Zero Trust Enterprise - Simplified network segmentation with dynamic partner integrations.

[0001596532-22-000025:8k_2_02:26]
•Arista Networks Expands its Cognitive Campus with the Latest Generation Wi-Fi 6E Solution - New access point extends the benefits of Arista’s cognitive unified edge to meet enterprise IoT and collaborative applications requirements.

[0001596532-22-000025:8k_2_02:27]
•Arista Expands Extensible Operating System for Data-Driven Cloud Networking - EOS Network Data Lake architecture endorsed by Equinix, Palo Alto Networks, Red Hat, Slack, Splunk, VMware, and Zscaler.

[0001596532-22-000025:8k_2_02:28]
•Arista Expands 400G for Enterprise and Cloud Customers - Next-generation 7050X and 7060X delivers two times the performance.

[0001596532-22-000025:8k_2_02:29]
•KuppingerCole has recognized Arista NDR as a leader in the 2021 Leadership Compass for Network Detection and Response (NDR).

[0001596532-22-000025:8k_2_02:30]
Financial Outlook

[0001596532-22-000025:8k_2_02:31]
For the first quarter of 2022, we expect:

[0001596532-22-000025:8k_2_02:32]
•Revenue between $840 million to $860 million;

[0001596532-22-000025:8k_2_02:33]
•Non-GAAP gross margin of 63% to 64%; and

[0001596532-22-000025:8k_2_02:34]
•Non-GAAP operating margin of approximately 38%.

[0001596532-22-000025:8k_2_02:35]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and certain non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below under “Non-GAAP Financial Measures”).

[0001596532-22-000025:8k_2_02:36]
Prepared Materials and Conference Call Information

[0001596532-22-000025:8k_2_02:37]
Arista's executives will discuss the fourth quarter and year end 2021 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-22-000025:8k_2_02:38]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-22-000025:8k_2_02:39]
Forward-Looking Statements

[0001596532-22-000025:8k_2_02:40]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the first quarter of 2022 and statements regarding the benefits of Arista's products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: the impact of

[0001596532-22-000025:8k_2_02:41]
the COVID-19 pandemic on our business; the impact of supply shortages and manufacturing constraints on our business including lead time and inventory purchases, increased costs of components, interruptions or delays in shipments; the rapid evolution of the networking market; any failure to successfully pursue new products and service offerings and expand into adjacent markets; a decline in our revenue growth rate; unpredictability of our results of operations; adverse economic conditions or reduced information technology and network infrastructure spending; excess inventory; deferral, reduction or cancellation of orders from end customers; intense competition; expansion of our international sales and operations; investment or acquisition in other businesses; seasonality; our ability to attract new large end customers or sell products and services to existing end customers; our ability to increase market awareness of our company and new products and services; product quality problems; our ability to anticipate technological shifts and develop products to meet those technological shifts; our ability to protect, defend and maintain our intellectual property rights; vulnerabilities in our products and failure of our products to detect security breaches our intellectual property rights; and tax, tariff, import/export restrictions; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-22-000025:8k_2_02:42]
Non-GAAP Financial Measures

[0001596532-22-000025:8k_2_02:43]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangible assets, certain non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-22-000025:8k_2_02:44]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-22-000025:8k_2_02:45]
The company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. The company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. A reconciliation of the non-GAAP financial measures guidance to the corresponding GAAP measures on a forward-looking basis is not available because stock-based compensation expense is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock, all of which are difficult to predict and

[0001596532-22-000025:8k_2_02:46]
3

[0001596532-22-000025:8k_2_02:47]
subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-22-000025:8k_2_02:48]
About Arista Networks

[0001596532-22-000025:8k_2_02:49]
Arista Networks is an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments. Arista’s award-winning platforms deliver availability, agility, automation, analytics and security through CloudVision® and Arista EOS®, an advanced network operating system. For more information, visit www.arista.com.

[0001596532-22-000025:8k_2_02:50]
ARISTA, CloudVision, CloudEOS and MSS are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners. Additional information and resources can be found at www.arista.com.

[0001596532-22-000025:8k_2_02:51]
Investor Contacts:

[0001596532-22-000025:8k_2_02:52]
| Arista Networks, Inc. |  |  |  |  |
| Liz Stine, 408-547-5885 |  | Venk Nathamuni, 408-547-5959 |
| Director, Investor Relations |  | Head of Corporate Finance, M&A, IR |
| liz@arista.com |  |  | venk@arista.com |  |

[0001596532-22-000025:8k_2_02:53]
ARISTA NETWORKS, INC.

[0001596532-22-000025:8k_2_02:54]
Condensed Consolidated Statements of Operations

[0001596532-22-000025:8k_2_02:55]
(Unaudited, in thousands, except per share amounts)

[0001596532-22-000025:8k_2_02:56]
|  |  | Three Months Ended December 31, |  | Twelve Months Ended December 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 667,955 |  |  | $ | 518,281 |  |  | $ | 2,377,727 |  |  | $ | 1,830,842 |  |
| Service |  | 156,504 |  |  | 130,201 |  |  | 570,310 |  |  | 486,670 |  |
| Total revenue |  | 824,459 |  |  | 648,482 |  |  | 2,948,037 |  |  | 2,317,512 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 270,809 |  |  | 210,436 |  |  | 958,363 |  |  | 749,962 |  |
| Service |  | 30,936 |  |  | 23,462 |  |  | 108,895 |  |  | 85,664 |  |
| Total cost of revenue |  | 301,745 |  |  | 233,898 |  |  | 1,067,258 |  |  | 835,626 |  |
| Total gross profit |  | 522,714 |  |  | 414,584 |  |  | 1,880,779 |  |  | 1,481,886 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 157,879 |  |  | 133,847 |  |  | 586,752 |  |  | 486,594 |  |
| Sales and marketing |  | 74,786 |  |  | 67,671 |  |  | 286,171 |  |  | 229,366 |  |
| General and administrative |  | 24,261 |  |  | 18,428 |  |  | 83,117 |  |  | 66,242 |  |
| Total operating expenses |  | 256,926 |  |  | 219,946 |  |  | 956,040 |  |  | 782,202 |  |
| Income from operations |  | 265,788 |  |  | 194,638 |  |  | 924,739 |  |  | 699,684 |  |
| Other income, net |  | 1,500 |  |  | 5,542 |  |  | 6,140 |  |  | 39,179 |  |
| Income before income taxes |  | 267,288 |  |  | 200,180 |  |  | 930,879 |  |  | 738,863 |  |
| Provision for income taxes |  | 27,993 |  |  | 17,222 |  |  | 90,025 |  |  | 104,306 |  |
| Net income |  | $ | 239,295 |  |  | $ | 182,958 |  |  | $ | 840,854 |  |  | $ | 634,557 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 239,295 |  |  | $ | 182,958 |  |  | $ | 840,854 |  |  | $ | 634,557 |  |
| Diluted |  | $ | 239,295 |  |  | $ | 182,958 |  |  | $ | 840,854 |  |  | $ | 634,557 |  |
| Net income per share attributable to common stockholders (1): |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.78 |  |  | $ | 0.60 |  |  | $ | 2.74 |  |  | $ | 2.09 |  |
| Diluted |  | $ | 0.75 |  |  | $ | 0.58 |  |  | $ | 2.63 |  |  | $ | 2.00 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders (1): |  |  |  |  |  |  |  |  |
| Basic |  | 307,521 |  |  | 303,456 |  |  | 306,512 |  |  | 303,936 |  |
| Diluted |  | 319,753 |  |  | 317,044 |  |  | 319,238 |  |  | 317,860 |  |

[0001596532-22-000025:8k_2_02:57]
_____________________

[0001596532-22-000025:8k_2_02:58]
(1) Prior period results have been adjusted to reflect the four-for-one stock split effected in the form of a stock dividend in November 2021.

[0001596532-22-000025:8k_2_02:59]
5

[0001596532-22-000025:8k_2_02:60]
ARISTA NETWORKS, INC.

[0001596532-22-000025:8k_2_02:61]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-22-000025:8k_2_02:62]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-22-000025:8k_2_02:63]
|  |  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| GAAP gross profit |  | $ | 522,714 |  |  | $ | 414,584 |  |  | $ | 1,880,779 |  |  | $ | 1,481,886 |  |
| GAAP gross margin |  | 63.4 | % |  | 63.9 | % |  | 63.8 | % |  | 63.9 | % |
| Stock-based compensation expense |  | 2,246 |  |  | 1,554 |  |  | 7,444 |  |  | 6,272 |  |
| Intangible asset amortization |  | 5,464 |  |  | 5,464 |  |  | 21,857 |  |  | 17,480 |  |
| Non-GAAP gross profit |  | $ | 530,424 |  |  | $ | 421,602 |  |  | $ | 1,910,080 |  |  | $ | 1,505,638 |  |
| Non-GAAP gross margin |  | 64.3 | % |  | 65.0 | % |  | 64.8 | % |  | 65.0 | % |
| GAAP income from operations |  | $ | 265,788 |  |  | $ | 194,638 |  |  | $ | 924,739 |  |  | $ | 699,684 |  |
| Stock-based compensation expense |  | 51,243 |  |  | 40,095 |  |  | 186,875 |  |  | 137,042 |  |
| Intangible asset amortization |  | 7,159 |  |  | 7,562 |  |  | 29,235 |  |  | 24,086 |  |
| Acquisition-related costs(1) |  | — |  |  | 1,215 |  |  | — |  |  | 13,933 |  |
| Non-GAAP income from operations |  | $ | 324,190 |  |  | $ | 243,510 |  |  | $ | 1,140,849 |  |  | $ | 874,745 |  |
| Non-GAAP operating margin |  | 39.3 | % |  | 37.6 | % |  | 38.7 | % |  | 37.7 | % |
| GAAP net income |  | $ | 239,295 |  |  | $ | 182,958 |  |  | $ | 840,854 |  |  | $ | 634,557 |  |
| Stock-based compensation expense |  | 51,243 |  |  | 40,095 |  |  | 186,875 |  |  | 137,042 |  |
| Intangible asset amortization |  | 7,159 |  |  | 7,562 |  |  | 29,235 |  |  | 24,086 |  |
| Acquisition-related costs |  | — |  |  | 1,215 |  |  | — |  |  | 13,933 |  |
| Gain on investment in privately-held companies |  | — |  |  | (4,164) |  |  | — |  |  | (4,164) |  |
| Tax benefit on stock-based awards |  | (30,470) |  |  | (19,802) |  |  | (115,154) |  |  | (60,880) |  |
| Income tax effect on non-GAAP exclusions |  | (4,814) |  |  | (10,188) |  |  | (26,813) |  |  | (26,163) |  |
| Non-GAAP net income |  | $ | 262,413 |  |  | $ | 197,676 |  |  | $ | 914,997 |  |  | $ | 718,411 |  |
| GAAP diluted net income per share attributable to common stockholders (2) |  | $ | 0.75 |  |  | $ | 0.58 |  |  | $ | 2.63 |  |  | $ | 2.00 |  |
| Non-GAAP adjustments to net income |  | 0.07 |  |  | 0.04 |  |  | 0.24 |  |  | 0.26 |  |
| Non-GAAP diluted net income per share |  | $ | 0.82 |  |  | $ | 0.62 |  |  | $ | 2.87 |  |  | $ | 2.26 |  |
| Weighted-average shares used in computing diluted net income per share (2) |  | 319,753 |  |  | 317,044 |  |  | 319,238 |  |  | 317,860 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 2,246 |  |  | $ | 1,554 |  |  | $ | 7,444 |  |  | $ | 6,272 |  |
| Research and development |  | 27,097 |  |  | 23,184 |  |  | 99,770 |  |  | 79,913 |  |
| Sales and marketing |  | 12,388 |  |  | 11,188 |  |  | 46,521 |  |  | 34,944 |  |
| General and administrative |  | 9,512 |  |  | 4,169 |  |  | 33,140 |  |  | 15,913 |  |
| Total |  | $ | 51,243 |  |  | $ | 40,095 |  |  | $ | 186,875 |  |  | $ | 137,042 |  |

[0001596532-22-000025:8k_2_02:64]
___________________

[0001596532-22-000025:8k_2_02:65]
(1) Represents non-recurring costs associated with our acquisitions, which primarily include retention bonuses, professional and consulting fees, and restructuring costs.

[0001596532-22-000025:8k_2_02:66]
(2) Prior period results have been adjusted to reflect the four-for-one stock split effected in the form of a stock dividend in November 2021.

[0001596532-22-000025:8k_2_02:67]
ARISTA NETWORKS, INC.

[0001596532-22-000025:8k_2_02:68]
Condensed Consolidated Balance Sheets

[0001596532-22-000025:8k_2_02:69]
(Unaudited, in thousands)

[0001596532-22-000025:8k_2_02:70]
|  |  | December 31, 2021 |  | December 31, 2020 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 620,813 |  |  | $ | 893,219 |  |
| Marketable securities |  | 2,787,502 |  |  | 1,979,649 |  |
| Accounts receivable |  | 516,509 |  |  | 389,540 |  |
| Inventories |  | 650,117 |  |  | 479,668 |  |
| Prepaid expenses and other current assets |  | 237,735 |  |  | 94,922 |  |
| Total current assets |  | 4,812,676 |  |  | 3,836,998 |  |
| Property and equipment, net |  | 78,634 |  |  | 32,231 |  |
| Acquisition-related intangible assets, net |  | 93,555 |  |  | 122,790 |  |
| Goodwill |  | 188,397 |  |  | 189,696 |  |
| Investments |  | 20,247 |  |  | 8,314 |  |
| Operating lease right-of-use assets |  | 65,182 |  |  | 77,288 |  |
| Deferred tax assets |  | 442,295 |  |  | 441,531 |  |
| Other assets |  | 33,443 |  |  | 30,071 |  |
| TOTAL ASSETS |  | $ | 5,734,429 |  |  | $ | 4,738,919 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 202,636 |  |  | $ | 134,235 |  |
| Accrued liabilities |  | 226,643 |  |  | 143,357 |  |
| Deferred revenue |  | 593,578 |  |  | 396,259 |  |
| Other current liabilities |  | 86,972 |  |  | 94,392 |  |
| Total current liabilities |  | 1,109,829 |  |  | 768,243 |  |
| Income taxes payable |  | 69,916 |  |  | 53,053 |  |
| Operating lease liabilities, non-current |  | 56,527 |  |  | 72,397 |  |
| Deferred revenue, non-current |  | 335,734 |  |  | 254,568 |  |
| Deferred tax liabilities, non-current |  | 129,074 |  |  | 227,936 |  |
| Other long-term liabilities |  | 54,749 |  |  | 42,431 |  |
| TOTAL LIABILITIES |  | 1,755,829 |  |  | 1,418,628 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock (1) |  | 31 |  |  | 30 |  |
| Additional paid-in capital (1) |  | 1,530,046 |  |  | 1,292,409 |  |
| Retained earnings |  | 2,456,823 |  |  | 2,027,614 |  |
| Accumulated other comprehensive income |  | (8,300) |  |  | 238 |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 3,978,600 |  |  | 3,320,291 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 5,734,429 |  |  | $ | 4,738,919 |  |
| ______________________ |  |  |  |  |
| (1) Prior period results have been adjusted to reflect the four-for-one stock split effected in the form of a stock dividend in November 2021. |

[0001596532-22-000025:8k_2_02:71]
7

[0001596532-22-000025:8k_2_02:72]
ARISTA NETWORKS, INC.

[0001596532-22-000025:8k_2_02:73]
Condensed Consolidated Statements of Cash Flows

[0001596532-22-000025:8k_2_02:74]
(Unaudited, in thousands)

[0001596532-22-000025:8k_2_02:75]
|  |  | Twelve Months Ended December 31, |
|  |  | 2021 |  | 2020 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 840,854 |  |  | $ | 634,557 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 50,334 |  |  | 44,590 |  |
| Noncash lease expense |  | 17,112 |  |  | 16,970 |  |
| Stock-based compensation |  | 186,875 |  |  | 137,042 |  |
| Deferred income taxes |  | (99,290) |  |  | (9,144) |  |
| (Gain) on investments in privately-held companies, net |  | — |  |  | (4,164) |  |
| (Gain) on sale of marketable securities |  | — |  |  | (9,432) |  |
| Amortization of investment premiums |  | 26,847 |  |  | 10,381 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (126,969) |  |  | 10,673 |  |
| Inventories |  | (170,449) |  |  | (235,318) |  |
| Prepaid expenses and other current assets |  | (134,814) |  |  | 13,846 |  |
| Other assets |  | (4,220) |  |  | 4,965 |  |
| Accounts payable |  | 66,681 |  |  | 41,161 |  |
| Accrued liabilities |  | 83,524 |  |  | 2,728 |  |
| Deferred revenue |  | 278,485 |  |  | 50,352 |  |
| Income taxes payable |  | 6,223 |  |  | 8,805 |  |
| Other liabilities |  | (5,337) |  |  | 17,102 |  |
| Net cash provided by operating activities |  | 1,015,856 |  |  | 735,114 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 1,455,465 |  |  | 1,545,689 |  |
| Purchases of marketable securities |  | (2,317,264) |  |  | (2,688,064) |  |
| Business combinations, net of cash acquired |  | — |  |  | (227,420) |  |
| Purchases of property, equipment and intangible assets |  | (64,736) |  |  | (15,384) |  |
| Escrow receipts from past business acquisitions |  | 1,299 |  |  | — |  |
| Investments and notes receivable in privately-held companies |  | (19,933) |  |  | 3,399 |  |
| Proceeds from sale of marketable securities |  | 19,607 |  |  | 772,978 |  |
| Net cash used in investing activities |  | (925,562) |  |  | (608,802) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 67,245 |  |  | 57,556 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (16,482) |  |  | (8,722) |  |
| Repurchase of common stock |  | (411,645) |  |  | (395,173) |  |
| Net cash used in financing activities |  | (360,882) |  |  | (346,339) |  |
| Effect of exchange rate changes |  | (1,816) |  |  | 1,966 |  |
| NET DECREASE IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | (272,404) |  |  | (218,061) |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 897,454 |  |  | 1,115,515 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 625,050 |  |  | $ | 897,454 |  |
