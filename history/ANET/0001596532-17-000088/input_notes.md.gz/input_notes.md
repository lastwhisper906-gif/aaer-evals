# ANET notes — 0001596532-17-000088


## anet:ScheduleofSharebasedCompensationSharesAvailableForGrantActivityTableTextBlock

[0001596532-17-000088:notes:1]
The following table presents the stock activity and the total number of shares available for grant as of March 31, 2017 (in thousands):

[0001596532-17-000088:notes:2]
|  |  | Number of Shares |
| Balance—December 31, 2016 |  | 11,754 |  |
| Authorized |  | 2,124 |  |
| Options granted |  | (165 | ) |
| RSUs granted |  | (283 | ) |
| Options canceled |  | 223 |  |
| Options repurchased |  | 2 |  |
| RSUs forfeited |  | 20 |  |
| Shares traded for taxes |  | 5 |  |
| Balance—March 31, 2017 |  | 13,680 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001596532-17-000088:notes:3]
As of March 31, 2017, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale investments, by remaining contractual maturity, are as follows (in thousands):

[0001596532-17-000088:notes:4]
|  |  | March 31, 2017 |
| Due in 1 year or less |  | $ | 168,732 |  |
| Due in 1 year through 2 years |  | 127,943 |  |
| Total marketable securities |  | $ | 296,675 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001596532-17-000088:notes:5]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles ("GAAP") and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2017, are not necessarily indicative of the results expected for the full fiscal year.  The condensed consolidated balance sheet as of December 31, 2016 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements.  Our unaudited condensed consolidated financial statements ("consolidated financial statements") include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and are prepared in accordance with GAAP.  All significant intercompany accounts and transactions have been eliminated.

[0001596532-17-000088:notes:6]
Our consolidated financial statements and related financial information should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2016, filed with the SEC on February 17, 2017.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-17-000088:notes:7]
Commitments and Contingencies

[0001596532-17-000088:notes:8]
Operating Leases

[0001596532-17-000088:notes:9]
We lease various operating spaces in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2025. We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.  Rent expense for all operating leases amounted to $2.4 million and $2.0 million, for the three months ended March 31, 2017 and 2016, respectively.  There have been no material changes in our operating lease commitments under contractual obligation, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2016.

[0001596532-17-000088:notes:10]
Financing Obligation—Build-to-Suit Lease

[0001596532-17-000088:notes:11]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013.  The underlying building asset is depreciated over the building’s estimated useful life of 30 years.  At the conclusion of the initial lease term, we will de-recognize both the net book values of the asset and the remaining financing obligation.  There have been no material changes in our operating lease commitments under contractual obligation, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2016.

[0001596532-17-000088:notes:12]
As of March 31, 2017 and December 31, 2016, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $40.8 million and $41.2 million, respectively. As of March 31, 2017, $1.7 million and $39.1 million were recorded as short-term and long-term financing obligations, respectively.

[0001596532-17-000088:notes:13]
Land lease expense related to our lease financing obligation is classified as rent expense in our unaudited condensed consolidated statements of income, and amounted to $0.3 million for both the three months ended March 31, 2017 and 2016.

[0001596532-17-000088:notes:14]
Purchase Commitments

[0001596532-17-000088:notes:15]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply.  We issue purchase orders to our contract manufacturers for finished product and a significant portion of these orders consist of firm non-cancelable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancelable, including integrated circuits, which are consigned to our contract manufacturers.   As of March 31, 2017, we had non-cancelable purchase commitments of $362.6 million.  In addition, we have provided deposits to secure our obligations to purchase inventory. We had $42.0 million and $63.1 million in deposits as of March 31, 2017 and December 31, 2016, respectively. These deposits are classified in other current and long term assets in our accompanying unaudited condensed consolidated balance sheets.

[0001596532-17-000088:notes:16]
Guarantees

[0001596532-17-000088:notes:17]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for lease facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-17-000088:notes:18]
Legal Proceedings

[0001596532-17-000088:notes:19]
OptumSoft, Inc. Matters

[0001596532-17-000088:notes:20]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies; and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-17-000088:notes:21]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft access to our software for evaluation by OptumSoft; (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches; (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers; (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us; and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors, who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dtd July 28, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

[0001596532-17-000088:notes:22]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we assert our ownership of the software components at issue and our interpretation of the 2004 agreement.  Among other things, we assert that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components.  We ask the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also assert that, even if we are found not to own certain components, such components are licensed to us under the terms of the 2004 agreement.  However, there can be no assurance that our assertions will ultimately prevail in litigation.  On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue.  We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information.  While we believe we have meritorious defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-17-000088:notes:23]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015.  On December 16, 2015, the Court issued a Proposed Statement of Decision Following Phase 1 Trial, and on January 8, 2016, OptumSoft filed objections to that Proposed Statement of Decision.  On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I.  The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II including the application of the Court’s interpretation of the 2004 agreement as set forth in the Final Statement of Decision Following Phase I Trial to any other source code that OptumSoft claims to own following a review.  Phase II was previously scheduled to be tried in April 2016; however, that trial date has been vacated and a new trial date has not yet been set.

[0001596532-17-000088:notes:24]
We intend to vigorously defend against any claims brought against us by OptumSoft.  However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor.  For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft.  If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license.  An adverse litigation ruling could result in a significant damages award against us and injunctive relief.  In addition, OptumSoft could assert additional or different claims against us, including claims that our license from OptumSoft is invalid.

[0001596532-17-000088:notes:25]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible.  Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain.  Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-17-000088:notes:26]
Cisco Systems, Inc. (“Cisco”) Matters

[0001596532-17-000088:notes:27]
We are currently involved in several litigation matters with Cisco Systems, Inc. These matters are summarized below.

[0001596532-17-000088:notes:28]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 4:14-cv-05343) (“’43 Case”)

[0001596532-17-000088:notes:29]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the 875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”).  Cisco seeks, as relief for our alleged infringement in the ’43 Case, lost profits and/or reasonable royalty damages in an unspecified amount, including treble damages, attorney’s fees, and associated costs.  Cisco also seeks injunctive relief in the ’43 Case.  On February 10, 2015, the Court granted our unopposed motion to stay the ’43 Case until the proceedings before the United States International Trade Commission (“USITC”) pertaining to the same patents (as discussed below) became final.  Trial has not been scheduled in the ’43 Case.

[0001596532-17-000088:notes:30]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 5:14-cv-05344) (“’44 Case”)

[0001596532-17-000088:notes:31]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI” and U.S. Patent Nos. 7,047,526 and 7,953,886 (respectively, “the ’526 patent” and “the ’886 patent”).  As relief for our alleged patent infringement in the ’44 Case, Cisco seeks lost profits and/or reasonable royalty damages in an unspecified amount including treble damages, attorney’s fees, and associated costs as well as injunctive relief.  As relief for our alleged copyright infringement, Cisco seeks monetary damages for alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees, and associated costs.

[0001596532-17-000088:notes:32]
As described below, on May 25, 2016, our petition for Inter Partes Review (“IPR”) of the ’886 patent was instituted by the United States Patent Trial and Appeal Board (“PTAB”). Cisco subsequently agreed to dismiss its claims as to the ‘886 patent with prejudice.

[0001596532-17-000088:notes:33]
Trial began on November 28, 2016, and the jury rendered its verdict on December 14, 2016.  The jury found that Arista had proven its copyright defense of scenes a faire and that Cisco had failed to prove infringement of the ’526 patent, and on that basis judgment was entered in Arista’s favor on all claims on December 19, 2016.

[0001596532-17-000088:notes:34]
On January 17, 2017, Cisco filed a motion for judgment as a matter of law, challenging the sufficiency of the evidence in support of Arista's scenes a faire defense.  Cisco did not file any post-trial motion regarding the ’526 patent, nor did it file a motion for a new trial.  We also filed a motion for judgment as a matter of law on several issues.  The hearing on both parties’ motions was held on April 27, 2017.

[0001596532-17-000088:notes:35]
Arista Networks, Inc. v. Cisco Systems, Inc. (Case No. 5:16-cv-00923) (“’23 Case”)

[0001596532-17-000088:notes:36]
On February 24, 2016, we filed a complaint against Cisco in the District Court for the Northern District of California alleging antitrust violations and unfair competition.  On August 23, 2016, the Court granted Cisco’s motion to stay the ’23 Case until judgment has been entered on Cisco’s copyright claims in the ’44 Case.  On March 2, 2017, the Court lifted the stay and trial is set for August 3, 2018.

[0001596532-17-000088:notes:37]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-944) (“944 Investigation”)

[0001596532-17-000088:notes:38]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we have violated 19 U.S.C. § 1337 (“Section 337”).  The USITC instituted Cisco’s complaint as Investigation No. 337-TA-944. Cisco initially alleged that certain of our switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.  Cisco subsequently dropped the ’296 patent from the 944 Investigation.  Cisco sought, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) and components and software therein and a cease and desist order against us restricting our activities with respect to our imported accused switch products and components and software therein.

[0001596532-17-000088:notes:39]
On February 2, 2016, the Administrative Law Judge (“ALJ”) issued his initial determination finding a violation of Section 337. More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringe asserted claims 1, 2, 8-11, and 17-19 of the ’537 patent; asserted claims 6, 7, 20, and 21 of the ’592 patent; and asserted claims 5, 7, 45, and 46 of the ’145 patent.  The ALJ did not find a violation of Section 337 with respect to any asserted claims of the ’597 and ’164 patents.  On June 23, 2016, the Commission issued its Final Determination, which found a violation with respect to the ’537, ’592, and ’145 patents, and found no violation with respect to the ’597 and ’164 patents.  The Commission also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 2, 8-11, and 17-19 of the ’537 patent; claims 6, 7, 20, and 21 of the ’592 patent; and claims 5, 7, 45, and 46 of the ’145 patent.  On August 22, 2016, the Presidential review period for the 944 investigation expired.  The USITC orders will be in effect until the expiration of the ’537, ’592, and ’145 patents.

[0001596532-17-000088:notes:40]
Both we and Cisco filed petitions for review of the USITC’s Final Determination to the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”).  The appeal is fully briefed and oral argument has not been scheduled.

[0001596532-17-000088:notes:41]
On August 26, 2016, Cisco filed an enforcement complaint under Section 337 with the USITC.  Cisco alleges that we are violating the cease and desist and limited exclusion orders issued in the 944 Investigation by engaging in the “marketing, distribution, offering for sale, selling, advertising, and/or aiding or abetting other entities in the sale and/or distribution of products that Cisco alleges continue to infringe claims 1-2, 8-11, and 17-19 of the ’537 patent,” despite the design changes we have made to those products.  Cisco asks the USITC to (1) enforce the cease and desist order; (2) modify the Commission’s limited exclusion order and/or cease and desist order “in any manner that would assist in the prevention of the unfair practices that were originally the basis for issuing such Order or assist in the detection of violations of such Order”; (3) impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000 or twice the domestic value of the articles entered or sold, whichever is higher”; (4) bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order”; and (5) impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.”  On September 28, 2016, the Commission instituted the enforcement proceeding.  The proceeding has been assigned to ALJ Judge Shaw, who presided over the underlying investigation.  On October 14, 2016, we responded to the complaint by, among other things, denying the patent infringement allegations and raising affirmative defenses.  On November 2, 2016, the ALJ issued an order setting the deadline for the initial determination for June 20, 2017 and the Target Date for September 20, 2017.  On April 4 and 5, 2017, the ALJ held the evidentiary hearing in this proceeding.

[0001596532-17-000088:notes:42]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-945) (“945 Investigation”)

[0001596532-17-000088:notes:43]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated Section 337.  The USITC instituted Cisco’s complaint as Investigation No. 337-TA-945.  Cisco alleges that certain of our switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents.  Cisco seeks, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) related software, and components thereof and a cease and desist order against us restricting our activities with respect to our imported accused switch products, related software, and components thereof.

[0001596532-17-000088:notes:44]
On December 9, 2016, the ALJ issued her initial determination finding a violation of Section 337. More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringe asserted claims 1, 7, 9, 10, and 15 of the ’577 patent; and asserted claims 1, 2, 4, 5, 7, 8, 10, 13, 19, 56, and 64 of the ’668 patent.  The ALJ did not find a violation of Section 337 with respect to asserted claim 2 of the ’577 patent or any asserted claims of the ’853, ’492, ’875, and ’211 patents.  On December 29, 2016, Arista, Cisco and the Office of Unfair Importation Investigation ("OUII") filed petitions for review of certain findings contained in the initial determination.  On March 1, 2017, the Commission issued a notice that it was reviewing the final initial determination in part on certain issues.

[0001596532-17-000088:notes:45]
On May 4, 2017, the Commission issued its Final Determination, which found a violation with respect to the ’577 and ’668 patents, and found no violation with respect to the ’211, ’853, ’875 and ’492 patents.  The Commission also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 7, 9, 10, and 15 of the ’577 patent and 1, 2, 4, 5, 7, 8, 10, 13, 18, 56, and 64 of the ’668 patent. The Commission’s final determination is subject to a 60-day Presidential review period, during which the United States Trade Representative will decide whether to disapprove the decision. During the Presidential review period, we must pay a 5% bond on any imports of any products and components subject to the order, and on any sales of previously imported products and components subject to the order.

[0001596532-17-000088:notes:46]
Inter Partes Reviews

[0001596532-17-000088:notes:47]
We have filed petitions for Inter Partes Review of the ’597, ’211, ’668, ’853, ’537, ’577, ’886, and ’526 patents.  IPRs relating to the ’597 (IPR No. 2015-00978) and ’211 (IPR No. 2015-00975) patents were instituted in October 2015 and hearings on these IPRs were completed in July 2016.  On September 28, 2016, the PTAB issued a final written decision finding claims 1, 14, 39-42, 71, 72, 84, and 85 of the ’597 patent unpatentable.  The PTAB also found that claims 29, 63, 64, 73, and 86 of the ’597 patent had not been shown to be unpatentable.  On October 5, 2016, the PTAB issued a final written decision finding claims 1 and 12 of the ’211 patent unpatentable.  The PTAB also found that claims 2, 6-9, 13, 17-20 of the ’211 patent had not been shown to be unpatentable.  Both parties have appealed the final written decisions on the ’211 and ’537 patents IPRs.

[0001596532-17-000088:notes:48]
The IPR relating to the ’886 patent was instituted on May 25, 2016.  Following that decision, Cisco agreed to dismiss its claims as to the ʼ886 patent with prejudice, and we dismissed our counterclaims as to the ʼ886 patent without prejudice.

[0001596532-17-000088:notes:49]
IPRs relating to the ’668 (IPR No. 2016-00309), ’577 (IPR No. 2016-00303), ’853 (IPR No. 2016-0306), and ’537 (IPR No. 2016-0308) patents were instituted in June 2016 and hearings were held on March 7, 2017.  Final Written Decisions on these IPRs are expected to be issued by June 2017.

[0001596532-17-000088:notes:50]
*  *  *  *  *

[0001596532-17-000088:notes:51]
We intend to vigorously defend against each of the Cisco’s lawsuits, as summarized in the preceding paragraphs.  However, we cannot be certain that any claims by Cisco would be resolved in our favor regardless of the merit of the claims.  Any adverse litigation ruling could result in the above described injunctive relief, could require a significant damages award against us or a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products.

[0001596532-17-000088:notes:52]
For example, in the 944 Investigation, the USITC has issued a limited exclusion order barring entry into the United States of our network devices (including our 7000 Series of switches), related software, and components thereof that infringe one or more of the claims of the ʼ537, ʼ592, and ʼ145 patents specified above and a cease and desist order restricting our activities with respect to such imported products.  In addition, in the 945 Investigation, the Commission has issued its Final Determination, finding a violation of section 337 of the Tariff Act with respect to the ʼ668 and ʼ577 patents.

[0001596532-17-000088:notes:53]
To comply with these orders, we have sought to develop technical design-arounds that no longer infringe the patents that are the subject of the orders.  In any efforts to develop technical design-arounds for our products, we may be unable to do so in a manner that does not continue to infringe the patents or that is acceptable to our customers.  Our redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.  Moreover, in the 944 Investigation and 945 Investigation, such design-arounds would require us to obtain approval of either the USITC or U.S. Customs and Border Protection (“CBP”) to resume the importation of the redesigned products into the United States.  We may not be successful in our efforts to obtain such approvals to import such modified products in a timely manner, or at all.  While a favorable ruling from the CBP would allow us to resume importation of our redesigned products into the United States, the USITC could still determine in an enforcement action that our redesigned products continue to infringe the patents that are the subject of any USITC orders.  Any failure to effectively redesign our products, to obtain timely clearance from USITC or CBP to import such redesigned products, or to address the USITC findings in a manner that complies with the USITC orders, may cause a disruption to our product shipments and materially and adversely affect our business, prospects, reputation, results of operations, and financial condition.

[0001596532-17-000088:notes:54]
Specifically, in response to the USITC’s findings in the 944 Investigation, we have made design changes to our products for sale in the United States to address the features that were found to infringe the ’537, ’592, and ’145 patents.  Following the issuance of the final determination in the 944 Investigation, we submitted a Section 177 ruling request to CBP seeking approval to import these redesigned products into the United States.  On November 18, 2016, we received a 177 ruling from CBP finding that our redesigned products did not infringe the relevant claims of the ʼ537, ’592, and ʼ145 patents, and approving the importation of these redesigned products into the United States.  However, on January 13, 2017, at the request of Cisco and without our input, CBP issued a letter to us revoking its prior November 18 ruling.  CBP subsequently conducted an inter partes proceeding between Arista and Cisco to determine whether our redesigned products infringe and whether to approve them for importation into the United States. On April 7, 2017, following the inter partes proceeding, CBP again ruled that our design around products do not infringe the relevant claims of the ’537, ’592, and ’145 patents and again approved those design arounds for importation into the United States.

[0001596532-17-000088:notes:55]
Similarly, on May 4, 2017, the USITC issued a limited exclusion order and cease and desist order in the 945 Investigation with respect to the ‘668 and ‘577 patents.  If such orders are not disapproved by the United States Trade Representative, we would need to further modify our products to take our products outside the scope of the ‘668 and ‘577 patents and obtain the USITC and/or CBP approvals described above to resume importation of our redesigned products into the United States.  For example, we submitted a technical design-around for the ‘668 patent into the 945 Investigation. However, in the Final Determination, the Commission found that this design around continues to infringe the patent. This will require us to implement an alternative redesign for our products to make them non-infringing.  We may not be able to do so in a manner that does not continue to infringe the patent or that is acceptable to customers. We may not be able to complete, and our customers may not be able to qualify, such redesigned products in a timely fashion, if at all, following the end of the Presidential review period, leading to an inability to ship products to customers. Our redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management. In addition, during the Presidential review period, we must pay a 5% bond on imports of any products and components subject to the order, and on any sales of previously imported products and components subject to the order.

[0001596532-17-000088:notes:56]
If the USITC determines that our redesigned products continue to infringe the patents subject to any USITC limited exclusion order or cease and desist order in an enforcement action for either the 944 Investigation or the 945 Investigation, the USITC may impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000 or twice the domestic value of the articles entered or sold, whichever is higher,” bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order,” or impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.”

[0001596532-17-000088:notes:57]
An adverse finding in an enforcement action would take effect immediately upon USITC’s issuance of the final determination, without any Presidential review period.  To address such a finding, we would have to further redesign our products to make them non-infringing, and until we made such changes we would not be able to import or ship our products to customers.  We may not be able to do so in a manner that does not continue to infringe the patents or that is acceptable to customers.  We may not be able to complete, and our customers may not be able to qualify, such redesigned products in a timely fashion, if at all, following the issuance of an adverse final determination, leading to an inability to ship products to customers.  Our redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.  We would also need to obtain USITC or CBP approval to resume importation of such redesigned products into the United States.  In addition, the USITC would not provide a service and support exception for our previously redesigned products, and customers may be required to upgrade to new products to obtain service and support.

[0001596532-17-000088:notes:58]
To comply with the USITC’s remedial orders, we have also made certain changes to our manufacturing, importation and shipping workflows. These changes have included shifting manufacturing and integration of our products to be sold in the United States to U.S. facilities. Such changes may be extremely costly, time consuming, and we may not be able to implement such changes successfully.  Any failure to successfully change our manufacturing and importation processes or shipping workflows in a manner that is compliant with the limited exclusion order and cease and desist order may cause a disruption in our product shipments and materially and adversely affect our business, prospects, reputation, results of operations, and financial condition.

[0001596532-17-000088:notes:59]
In connection with these changes, to the extent that we are required to make further modifications to our supply chain to obtain alternative U.S. sources for subcomponents, we may be unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, if at all, which could delay or halt entirely production of our products or require us to make further modifications to our products to incorporate new components that are available in the United States. Any of these events could result in lost sales, reduced gross margins or damage to our end-customer relationships, which would materially and adversely impact our business, financial condition, results of operations and prospects.

[0001596532-17-000088:notes:60]
Additionally, the existence of Ciscoʼs lawsuits against us could cause concern among our customers and partners and could adversely affect our business and results of operations.  Many of our customers and partners require us to indemnify and defend them against third party infringement claims and pay damages in the case of adverse rulings. These claims could harm our relationships with our customers or channel partners, cause them to delay or defer purchasing decisions or deter them from doing business with us. From time to time, we may also be required to provide additional assurances beyond our standard terms.  Whether or not we prevail in the lawsuit, we expect that the litigation will be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-17-000088:notes:61]
With respect to the various legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain.  Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-17-000088:notes:62]
In the Matter of Certain Semiconductor Devices, Semiconductor Device Packages, and Products Containing Same (337-TA-1010)

[0001596532-17-000088:notes:63]
On May 23, 2016, Tessera Technologies, Inc., Tessera, Inc., and Invensas Corp. (“Tessera”) filed a complaint in the USITC alleging that Broadcom Limited, Broadcom Corporation, Avago Technologies Limited, and Avago Technologies U.S. Inc. (“Broadcom”) violated 19 U.S.C. § 1337 (“Section 337”).  On June 10, 2016, the USITC instituted Tessera’s complaint as Investigation No. 337-TA-1010 on June 20, 2016.

[0001596532-17-000088:notes:64]
Tessera alleges that certain Broadcom semiconductor devices infringe U.S. Patent No. 6,856,007; U.S. Patent No. 6,849,946; and U.S. Patent No. 6,133,136.  Tessera further alleged that Broadcom's downstream customers, Arista Networks, Inc.; ARRIS International plc; ARRIS Group, Inc.; ARRIS Technology, Inc.; ARRIS Enterprises LLC; ARRIS Solutions, Inc.; Pace Ltd.; Pace Americas, LLC; Pace USA; LLC, ASUSteK Computer Inc.; ASUS Computer International; Comcast Cable Communications, LLC; Comcast Cable Communications Management, LLC; Comcast Business Communications, LLC; HTC Corporation; HTC America, Inc.; NETGEAR, Inc.; Technicolor S.A.; Technicolor USA, Inc.; and Technicolor Connected Home USA LLC (“Downstream Respondents”), were violating Section 337 by importing, selling after importation, or selling for importation products that incorporate the accused Broadcom semiconductor devices.  The accused Company products include certain models of our switching products.

[0001596532-17-000088:notes:65]
Tessera seeks the following relief: (1) a permanent limited exclusion order excluding from importation into the U.S. all of Tessera’s semiconductor devices and semiconductor device packages and Downstream Respondents’ products containing Broadcom’s semiconductor devices that infringe one or more of the three patents-in-suit and (2) a permanent cease and desist order prohibiting Broadcom and Downstream Respondents and related companies from importing, marketing, advertising, demonstrating, warehousing inventory for distribution, offering for sale, selling, qualifying for use in the products of others, distributing, or using the accused Broadcom semiconductor devices Downstream Respondents’ products containing Respondents’ semiconductor devices and semiconductor device packages that infringe one or more of the three patents subject to the ITC Investigation.

[0001596532-17-000088:notes:66]
The evidentiary hearing was held on March 27 through March 31, 2017, and the target date for completion of the Investigation is October 24, 2017.

[0001596532-17-000088:notes:67]
To the extent claims made by Tessera in the ITC Investigation against Arista are based solely on functionality residing in Broadcom’s products, Broadcom has agreed to defend Arista at no cost to Arista.

[0001596532-17-000088:notes:68]
Plectrum, Inc. v. Arista Networks, Inc. (Case No. 4:17-cv-76)

[0001596532-17-000088:notes:69]
On February 2, 2017, Plectrum LLC (“Plectrum”) filed a complaint against Arista Networks, Inc. in the U.S. District Court for the Eastern District of Texas alleging infringement of the U.S. Patent Nos. 6,205,149 (“the ‘149 Patent”), 5,978,951 (“the ‘951 Patent”), and 6,751,677 (“the ‘677 Patent”) based upon our manufacture, use, by sale and/or offer for sale of our 7150 series and 7500 series switches.  Plectrum seeks a permanent injunction or ongoing royalty, unspecified damages and costs, pre-judgement and post-judgement interest on the damages, and attorneys’ fees.  In addition to Arista, Plectrum has also sued some of our competitors, customers, and suppliers.  Plectrum has filed lawsuits against sixteen (16) parties in total related to this effort.  We believe that the claims are without merit and intend to defend ourselves vigorously against the claims.

[0001596532-17-000088:notes:70]
Other Matters

[0001596532-17-000088:notes:71]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.  We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated.   As of March 31, 2017, provisions recorded for contingent losses related to other claims and matters have not been significant.  Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows.  However, litigation is subject to inherent uncertainties and our view of these matters may change in the future.  Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-17-000088:notes:72]
[same as prior period, unchanged from 0001596532-16-000331:notes:61]

[0001596532-17-000088:notes:73]
[same as prior period, unchanged from 0001596532-16-000331:notes:62]

[0001596532-17-000088:notes:74]
|  | Three Months EndedMarch 31, |
|  | 2017 |  | 2016 |
| Cost of revenue | $ | 1,024 |  |  | $ | 793 |  |
| Research and development | 9,587 |  |  | 7,457 |  |
| Sales and marketing | 3,456 |  |  | 3,647 |  |
| General and administrative | 2,372 |  |  | 1,463 |  |
| Total stock-based compensation | $ | 16,439 |  |  | $ | 13,360 |  |

[0001596532-17-000088:notes:75]
[same as prior period, unchanged from 0001596532-16-000331:notes:64]

[0001596532-17-000088:notes:76]
[same as prior period, unchanged from 0001596532-16-000331:notes:65]

[0001596532-17-000088:notes:77]
|  |  | Options and RSAs Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options and RSAs (in thousands) |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding (in thousands) |
| Outstanding—December 31, 2016 |  | 9,509 |  |  | $ | 28.79 |  |  | 6.9 |  | $ | 646,394 |  |
| Options granted |  | 165 |  |  | 95.51 |  |  |  |  |  |
| Options exercised |  | (882 | ) |  | 15.32 |  |  |  |  |  |
| Options canceled |  | (223 | ) |  | 32.10 |  |  |  |  |  |
| Outstanding—March 31, 2017 |  | 8,569 |  |  | $ | 31.38 |  |  | 6.8 |  | $ | 864,597 |  |
| Vested and exercisable—March 31, 2017 |  | 3,144 |  |  | $ | 16.75 |  |  | 6.0 |  | $ | 363,194 |  |
| Vested and expected to vest—March 31, 2017 |  | 8,569 |  |  | $ | 31.38 |  |  | 6.8 |  | $ | 864,597 |  |

[0001596532-17-000088:notes:78]
As of March 31, 2017, the total unrecognized stock-based compensation expense related to unvested stock options was $90.8 million, which is expected to be recognized over a weighted-average period of 3.8 years.

[0001596532-17-000088:notes:79]
[same as prior period, unchanged from 0001596532-16-000331:notes:68]

[0001596532-17-000088:notes:80]
[same as prior period, unchanged from 0001596532-16-000331:notes:69]

[0001596532-17-000088:notes:81]
|  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2016 | 1,375 |  |  | $ | 74.23 |  |  | 1.8 |  | $ | 133,081 |  |
| RSUs granted | 283 |  |  | 109.51 |  |  |  |  |  |
| RSUs vested | (119 | ) |  | 72.85 |  |  |  |  |  |
| RSUs forfeited | (20 | ) |  | 69.30 |  |  |  |  |  |
| Unvested balance—March 31, 2017 | 1,519 |  |  | $ | 80.97 |  |  | 1.8 |  | $ | 200,947 |  |
| Vested and expected to vest—March 31, 2017 | 1,519 |  |  | $ | 80.97 |  |  | 1.8 |  | $ | 200,947 |  |

[0001596532-17-000088:notes:82]
As of March 31, 2017, there was $115.1 million of unrecognized stock-based compensation cost related to unvested RSUs. This amount is expected to be recognized over a weighted-average period of 3.5 years.

[0001596532-17-000088:notes:83]
[same as prior period, unchanged from 0001596532-16-000331:notes:72]

[0001596532-17-000088:notes:84]
During the three months ended March 31, 2017, we issued 99,804 shares at a weighted average purchase price of $60.03 under the 2014 Employee Stock Purchase Plan ("ESPP"). On February 6, 2016, the board authorized an increase to shares available for future issuance under the ESPP.  Per the ESPP, the increase is determined based on the lesser of 1% of total shares outstanding as of the first day of each fiscal year, 2,500,000 shares, or such amount as determined by our board of directors. The approved increase for 2017 amounted to 708,111 shares.  As of March 31, 2017, there remain 2,092,153 shares available for issuance under the ESPP.

[0001596532-17-000088:notes:85]
As of March 31, 2017, the total unrecognized stock-based compensation expense related to unvested ESPP options was $3.8 million, which is expected to be recognized over a weighted-average period of 1.4 years.

[0001596532-17-000088:notes:86]
[same as prior period, unchanged from 0001596532-16-000331:notes:75]


## us-gaap:EarningsPerShareTextBlock

[0001596532-17-000088:notes:87]
[same as prior period, unchanged from 0001596532-16-000331:notes:76]

[0001596532-17-000088:notes:88]
[same as prior period, unchanged from 0001596532-16-000331:notes:77]

[0001596532-17-000088:notes:89]
|  | Three Months EndedMarch 31, |
|  | 2017 |  | 2016 |
| Numerator: |  |  |  |
| Basic: |  |  |  |
| Net income | $ | 82,961 |  |  | $ | 35,245 |  |
| Less: undistributed earnings allocated to participating securities | (267 | ) |  | (324 | ) |
| Net income available to common stockholders, basic | $ | 82,694 |  |  | $ | 34,921 |  |
| Diluted: |  |  |  |
| Net income attributable to common stockholders, basic | $ | 82,694 |  |  | $ | 34,921 |  |
| Add: undistributed earnings allocated to participating securities | 22 |  |  | 20 |  |
| Net income attributable to common stockholders, diluted | $ | 82,716 |  |  | $ | 34,941 |  |
| Denominator: |  |  |  |
| Basic: |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 71,114 |  |  | 67,737 |  |
| Diluted: |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 71,114 |  |  | 67,737 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |
| Stock options and RSUs | 6,321 |  |  | 4,443 |  |
| Employee stock purchase plan | 81 |  |  | 34 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted | 77,516 |  |  | 72,214 |  |
| Net income per share attributable to common stockholders: |  |  |  |
| Basic | $ | 1.16 |  |  | $ | 0.52 |  |
| Diluted | $ | 1.07 |  |  | $ | 0.48 |  |

[0001596532-17-000088:notes:90]
[same as prior period, unchanged from 0001596532-16-000331:notes:79]

[0001596532-17-000088:notes:91]
|  | Three Months EndedMarch 31, |
|  | 2017 |  | 2016 |
| Stock options and RSUs to purchase common stock | 188 |  |  | 3,763 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-17-000088:notes:92]
[same as prior period, unchanged from 0001596532-16-000331:notes:81]

[0001596532-17-000088:notes:93]
|  | March 31, 2017 |
|  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 309,438 |  |  | $ | — |  |  | $ | — |  |  | $ | 309,438 |  |
| Money market funds-restricted | 5,497 |  |  | — |  |  | — |  |  | 5,497 |  |
| Commercial Paper | 29,883 |  |  | — |  |  | — |  |  | 29,883 |  |
| U.S. government notes | 98,377 |  |  | — |  |  | — |  |  | 98,377 |  |
| Corporate bonds | — |  |  | 168,415 |  |  | — |  |  | 168,415 |  |
| Total financial assets | $ | 443,195 |  |  | $ | 168,415 |  |  | $ | — |  |  | $ | 611,610 |  |

[0001596532-17-000088:notes:94]
|  | December 31, 2016 |
|  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 305,182 |  |  | $ | — |  |  | $ | — |  |  | $ | 305,182 |  |
| Money market funds-restricted | 4,245 |  |  | — |  |  | — |  |  | 4,245 |  |
| Commercial Paper | 5,962 |  |  | — |  |  | — |  |  | 5,962 |  |
| U.S. government notes | 110,756 |  |  | — |  |  | — |  |  | 110,756 |  |
| Corporate bonds | — |  |  | 183,192 |  |  | — |  |  | 183,192 |  |
| Total financial assets | $ | 426,145 |  |  | $ | 183,192 |  |  | $ | — |  |  | $ | 609,337 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-17-000088:notes:95]
[same as prior period, unchanged from 0001596532-16-000331:notes:84]

[0001596532-17-000088:notes:96]
[same as prior period, unchanged from 0001596532-16-000331:notes:85]

[0001596532-17-000088:notes:97]
[same as prior period, unchanged from 0001596532-16-000331:notes:86]

[0001596532-17-000088:notes:98]
[same as prior period, unchanged from 0001596532-16-000331:notes:87]

[0001596532-17-000088:notes:99]
[same as prior period, unchanged from 0001596532-16-000331:notes:88]

[0001596532-17-000088:notes:100]
[same as prior period, unchanged from 0001596532-16-000331:notes:89]

[0001596532-17-000088:notes:101]
[same as prior period, unchanged from 0001596532-16-000331:notes:90]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-17-000088:notes:102]
[same as prior period, unchanged from 0001596532-16-000331:notes:91]

[0001596532-17-000088:notes:103]
We had an income tax benefit of $9.2 million in the three months ended March 31, 2017, as compared to an income tax provision of $14.1 million in the three months ended March 31, 2016. The significant reduction in our income taxes was primarily due to the recognition of excess tax benefits of $28.8 million as a component of the provision for income taxes resulting from the adoption of ASU 2016-09, offset by an increase in the tax provision driven by higher profits before income taxes.

[0001596532-17-000088:notes:104]
[same as prior period, unchanged from 0001596532-16-000331:notes:93]

[0001596532-17-000088:notes:105]
We have been selected for examination by the Internal Revenue Service ("IRS") for our 2013 and 2014 tax years and the subsequent years remain open for audit. It is difficult to determine when the examinations will be settled or their final outcomes in the foreseeable future.  We believe that we have adequately provided reserves for any reasonably foreseeable adjustment to our tax returns.   It is likely that within the next 12 months that either the IRS examination for tax year 2013 and 2014 will be settled or the statute of limitations will run for jurisdictions in which we have unrecognized tax benefits recorded.  The settlement or statute lapse would result in a reduction of the unrecognized tax benefit recorded.  The reduction may range from no change up to approximately $3.7 million.

[0001596532-17-000088:notes:106]
Our gross unrecognized tax benefits as of March 31, 2017 were $29.9 million.  If the gross unrecognized tax benefits as of March 31, 2017 were realized in future periods, this could result in a tax benefit of $16.9 million within our provision of income taxes.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001596532-17-000088:notes:107]
[same as prior period, unchanged from 0001596532-16-000331:notes:96]

[0001596532-17-000088:notes:108]
[same as prior period, unchanged from 0001596532-16-000331:notes:97]

[0001596532-17-000088:notes:109]
As of March 31, 2017 and December 31, 2016, we held non-marketable equity investments of approximately $36.1 million in privately-held companies which are accounted for under the cost method. To date, we have not recognized any impairment losses on our investments.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-17-000088:notes:110]
In May 2014, the FASB issued ASU No. 2014-09, Revenue From Contracts With Customers (Topic 606), (as amended in June 2016, by ASU No. 2016-12-Revenue-Narrow-Scope Improvements and Practical Expedients), which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The new standard provides principles for recognizing revenue for the transfer of promised goods or services to customers with the consideration to which the entity expects to be entitled in exchange for those goods or services. The standard also requires significantly expanded disclosures about revenue recognition.

[0001596532-17-000088:notes:111]
In July 2015, the FASB issued ASU No. 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date, deferring the effective date of the new revenue standard by one year. In March 2016, the FASB issued ASU No. 2016-08, Revenue From Contracts With Customers-Principal versus Agent Considerations (Reporting Revenue Gross versus Net), and ASU No. 2016-10, Revenue From Contracts With Customers-Identifying Performance Obligations and Licensing. ASU No. 2016-08 clarifies the implementation guidance regarding principal versus agent identification and related considerations. Specifically, the guidance provides clarification around performance obligations for goods or services provided by another entity, assisting in determining whether the entity is the provider of the goods or services, the principal, or whether the entity is providing for the arrangement of the goods or services, the agent.  ASU No. 2016-10 provides guidance around identifying whether promised goods or services are distinct and separately identifiable, whether promised goods or services are material or immaterial to the contract, and whether shipping and handling is considered an activity to fulfill a promise or an additional promised service. ASU No. 2016-10 also provides guidance around an entity's promise to grant a license providing a customer with either a right to use or a right to access the license, which then determines whether the obligation is satisfied at a point in time or over time, respectively.

[0001596532-17-000088:notes:112]
In May 2016, the FASB issued ASU No. 2016-11, Revenue Recognition (Topic 605) and Derivatives and Hedging (Topic 815): Rescission of SEC Guidance Because of Accounting Standards Updates 2014-09 and 2014-16 Pursuant to Staff Announcements at the March 3, 2016 EITF Meeting (SEC Update)") ("ASU 2016-11"), which rescinds various standards codified as part of Topic 605, Revenue Recognition in relation to the future adoption of Topic 606. These rescissions include changes to topics pertaining to revenue and expense recognition including accounting for shipping and handling fees and costs and accounting for consideration given by a vendor to a customer.

[0001596532-17-000088:notes:113]
The above standards are effective for fiscal years (and interim reporting periods within those years) beginning after December 15, 2017.  The guidance is effective for us beginning in our first quarter of fiscal 2018. Early adoption would be permitted for all entities but not until the fiscal year beginning after December 15, 2016. The standard permits the use of either the retrospective or cumulative effect transition method. The retrospective method requires a retrospective approach to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance. The cumulative approach requires a retrospective approach with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance.

[0001596532-17-000088:notes:114]
Management’s assessments of potential impacts of the standards are underway. The standards are expected to impact the amount and timing of revenue recognized and the related disclosures on our consolidated financial statements.  We will adopt ASU 2014-09 during the first quarter of 2018 and expect to adopt the guidance under the modified retrospective method which we anticipate will result in a cumulative effect adjustments as of the date of adoption.

[0001596532-17-000088:notes:115]
In January 2016, the FASB issued ASU No, 2016-01, Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities, which enhances the reporting model for financial instruments to provide users of financial statements with more decision-useful information. The guidance will address certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. The standard is effective for us for our first quarter of fiscal 2018.  The guidance may be early adopted under early application guidance. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-17-000088:notes:116]
In February 2016, the FASB issued ASU No, 2016-02, Leases, which addresses the classification and recognition of lease assets and liabilities formerly classified as operating leases under GAAP. The guidance will address certain aspects of recognition and measurement, and quantitative and qualitative aspects of presentation and disclosure. The guidance is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. The standard is effective for us for our first quarter of fiscal 2019.  The guidance will be applied to the earliest period presented using a modified retrospective approach. The guidance includes practical expedients that relate to identification, classification, and initial direct costs associated with leases commencing prior to the effective date, and the ability to apply hindsight in evaluating lease options related to extensions, terminations or asset purchases.  A practical expedient also exists to treat leases entered into prior effective date under existing GAAP unless the lease has been modified. The guidance may be early adopted. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.

[0001596532-17-000088:notes:117]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. Credit losses relating to available-for-sale debt securities should be recorded through an allowance for credit losses. This standard is effective for us for our first quarter of 2020.  We are currently assessing the impact this guidance may have on our consolidated financial statements.

[0001596532-17-000088:notes:118]
In August 2016, the FASB issued ASU 2016-15, Statement of Cash Flows: Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Task Force), which addresses eight specific cash flow issues with the objective of reducing the existing diversity in practice in how certain transactions are presented and classified in the statement of cash flows. The guidance may be adopted early as of the beginning of an annual reporting period.  The guidance will be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  The standard is effective for us for our first quarter of fiscal 2018.  We are currently assessing the impact this guidance may have on our consolidated financial statements.

[0001596532-17-000088:notes:119]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which addresses recognition of current and deferred income taxes for intra-entity asset transfers when assets are sold to an outside party. Current GAAP prohibits the recognition of current and deferred income taxes until the asset has been sold to an outside party. This prohibition on recognition is considered an exception to the principle of comprehensive recognition of current and deferred income taxes in GAAP.  The new guidance requires an entity to recognize the income tax consequences when the transfer occurs eliminating the exception.  The guidance will be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  The standard is effective for us for our first quarter of fiscal 2018, and may be early adopted under early application guidance.  We are currently assessing the impact this guidance may have on our consolidated financial statements.

[0001596532-17-000088:notes:120]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force which requires that amounts generally described as restricted cash or restricted cash equivalents be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. This standard is effective for us for our first quarter of fiscal 2018, and may be early adopted. We do not anticipate this standard will have a material impact on our consolidated financial statements.

[0001596532-17-000088:notes:121]
In March 2016, the Financial Accounting Standards Board (the “FASB”) amended the existing accounting standard for stock-based compensation, issuing Accounting Standards Update (“ASU”) 2016-09, Compensation-Stock Compensation: Improvements to Employee Share-Based Payment Accounting, which impacts several aspects of accounting for share-based payment transactions, including the income tax consequences, forfeitures, classification of awards as either equity or liabilities, and classification on the statement of cash flows. We adopted this standard during our first fiscal quarter of 2017. The impact of the adoption was as follows:

[0001596532-17-000088:notes:122]
| • | Income tax accounting - The standard eliminates additional paid-in-capital (“APIC”) pools and requires excess tax benefits and tax deficiencies on share-based awards to be recognized in the income statement prospectively as discrete items upon exercise or vesting of such awards. The standard also requires excess tax benefits to be recognized regardless of whether the benefit reduces taxes payable. We adopted the guidance related to the timing of previously unrecognized excess tax benefits on a modified retrospective basis, which resulted in the recognition of a cumulative effect adjustment of $1.8 million that increased retained earnings and increased our long-term deferred income tax as of January 1, 2017. |

[0001596532-17-000088:notes:123]
| • | Earnings per share - Because excess benefits are no longer recognized in APIC, the assumed proceeds from applying the treasury stock method when calculating dilutive shares was amended to exclude the amount of excess tax benefits that would be recognized upon exercise or vesting of such awards. As a result, this reduces the assumed shares to be repurchased under the treasury stock method, thereby increasing the amount of dilutive shares used to compute earnings per share. We adopted the guidance related to the exclusion of excess tax benefits in calculating earnings per share on a prospective basis. |

[0001596532-17-000088:notes:124]
| • | Forfeitures of stock options and awards - Under the new standard, we can make an accounting policy election to either estimate the number of share-based awards that are expected to vest, or account for forfeitures when they occur. We elected to account for forfeitures when they occur and adopted this change on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as a $1.0 million decrease to retained earnings as of January 1, 2017. |

[0001596532-17-000088:notes:125]
| • | Cash flow presentation of excess tax benefits - Prior to the new standard, we were required to present excess tax benefits on share-based awards as a cash inflow from financing activities with a corresponding cash outflow from operating activities. The new standard required that these excess tax benefits be classified with other income tax cash flows as an operating activity. We elected to adopt the guidance related to the presentation of excess tax benefits in our condensed consolidated statements of cash flows on a retrospective basis, which increased net cash provided by operating activities by $6.0 million for the three months ended March 31, 2016, with a corresponding decrease to net cash provided by financing activities. |

[0001596532-17-000088:notes:126]
In April 2015, the FASB issued ASU 2015-05, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement, providing guidance on fees paid in a cloud computing arrangement.  If a cloud computing arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted this standard in our first quarter of fiscal 2017 on a prospective basis, and the adoption did not have a material impact on our consolidated financial statements.

[0001596532-17-000088:notes:127]
In July 2015, the FASB issued ASU No, 2015-11, Inventory: Simplifying the Measurement of Inventory, which simplifies the measurement of inventory to be measured at the lower of cost or net realizable value.  The guidance is effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. We adopted this standard in our first quarter of fiscal 2017 on a prospective basis. We adopted this standard in our first quarter of fiscal 2017 on a prospective basis, and the adoption did not have a material impact on our consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-17-000088:notes:128]
Organization and Summary of Significant Accounting Policies

[0001596532-17-000088:notes:129]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our” or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System (“EOS”), a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switching and routing platforms. We were incorporated in October 2004 in the State of California under the name Arastra, Inc. In March 2008, we reincorporated in the State of Nevada and in October 2008 changed our name to Arista Networks, Inc. We reincorporated in the state of Delaware in March 2014. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-17-000088:notes:130]
Basis of Presentation and Principles of Consolidation

[0001596532-17-000088:notes:131]
[same as prior period, unchanged from 0001596532-16-000331:notes:112]

[0001596532-17-000088:notes:132]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts and sales return reserve; determination of fair value for stock-based awards; accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; valuation of inventory; valuation of warranty accruals; contract manufacturing liabilities; and recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

[0001596532-17-000088:notes:133]
Recently Adopted Accounting Pronouncements

[0001596532-17-000088:notes:134]
[same as prior period, unchanged from 0001596532-16-000331:notes:115]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001596532-17-000088:notes:135]
[same as prior period, unchanged from 0001596532-16-000331:notes:116]

[0001596532-17-000088:notes:136]
|  | March 31, 2017 |  | December 31, 2016 |
| Equipment and machinery | $ | 42,581 |  |  | $ | 40,721 |  |
| Computer hardware and software | 18,676 |  |  | 17,420 |  |
| Furniture and fixtures | 2,969 |  |  | 2,879 |  |
| Leasehold improvements | 29,619 |  |  | 29,498 |  |
| Building | 35,154 |  |  | 35,154 |  |
| Construction-in-process | 1,039 |  |  | 421 |  |
| Property and equipment, gross | 130,038 |  |  | 126,093 |  |
| Less: accumulated depreciation | (53,719 | ) |  | (49,132 | ) |
| Property and equipment, net | $ | 76,319 |  |  | $ | 76,961 |  |


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001596532-17-000088:notes:137]
[same as prior period, unchanged from 0001596532-16-000331:notes:118]

[0001596532-17-000088:notes:138]
|  | March 31, 2017 |  | December 31, 2016 |
| Accounts receivable | $ | 211,134 |  |  | $ | 254,640 |  |
| Allowance for doubtful accounts | (66 | ) |  | (204 | ) |
| Sales return reserve | (2,006 | ) |  | (1,317 | ) |
| Accounts receivable, net | $ | 209,062 |  |  | $ | 253,119 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001596532-17-000088:notes:139]
[same as prior period, unchanged from 0001596532-16-000331:notes:120]

[0001596532-17-000088:notes:140]
|  | March 31, 2017 |  | December 31, 2016 |
| Accrued compensation costs | $ | 30,008 |  |  | $ | 52,854 |  |
| Accrued warranty costs | 7,658 |  |  | 6,744 |  |
| Accrued manufacturing costs | 21,785 |  |  | 14,824 |  |
| Accrued professional fees | 8,852 |  |  | 6,829 |  |
| Accrued taxes | 914 |  |  | 1,098 |  |
| Other | 6,074 |  |  | 8,602 |  |
| Total accrued liabilities | $ | 75,291 |  |  | $ | 90,951 |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001596532-17-000088:notes:141]
[same as prior period, unchanged from 0001596532-16-000331:notes:122]

[0001596532-17-000088:notes:142]
|  | March 31, 2017 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper | $ | 29,844 |  |  | $ | 39 |  |  | $ | — |  |  | $ | 29,883 |  |
| U.S. government notes | 98,591 |  |  | — |  |  | (214 | ) |  | 98,377 |  |
| Corporate bonds | 168,621 |  |  | 118 |  |  | (324 | ) |  | 168,415 |  |
| Total marketable securities | $ | 297,056 |  |  | $ | 157 |  |  | $ | (538 | ) |  | $ | 296,675 |  |

[0001596532-17-000088:notes:143]
|  | December 31, 2016 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper | $ | 5,962 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,962 |  |
| U.S. government notes | 110,945 |  |  | 5 |  |  | (194 | ) |  | 110,756 |  |
| Corporate bonds | 183,455 |  |  | 109 |  |  | (372 | ) |  | 183,192 |  |
| Total marketable securities | $ | 300,362 |  |  | $ | 114 |  |  | $ | (566 | ) |  | $ | 299,910 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001596532-17-000088:notes:144]
[same as prior period, unchanged from 0001596532-16-000331:notes:124]

[0001596532-17-000088:notes:145]
|  | March 31, 2017 |  | December 31, 2016 |
| Raw materials | $ | 108,066 |  |  | $ | 99,190 |  |
| Finished goods | 178,720 |  |  | 137,300 |  |
| Total inventories | $ | 286,786 |  |  | $ | 236,490 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001596532-17-000088:notes:146]
[same as prior period, unchanged from 0001596532-16-000331:notes:126]

[0001596532-17-000088:notes:147]
|  | March 31, 2017 |  | December 31, 2016 |
| Inventory deposit | $ | 39,296 |  |  | $ | 60,315 |  |
| Prepaid income taxes | 34,386 |  |  | 17,383 |  |
| Other current assets | 112,216 |  |  | 79,140 |  |
| Other prepaid expenses and deposits | 11,837 |  |  | 11,846 |  |
| Total prepaid expenses and other current assets | $ | 197,735 |  |  | $ | 168,684 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001596532-17-000088:notes:148]
[same as prior period, unchanged from 0001596532-16-000331:notes:128]

[0001596532-17-000088:notes:149]
|  | Three Months EndedMarch 31, |
|  | 2017 |  | 2016 |
| Warranty accrual, beginning of period | $ | 6,744 |  |  | $ | 4,718 |  |
| Liabilities accrued for warranties issued during the period | 1,859 |  |  | 693 |  |
| Warranty costs incurred during the period | (945 | ) |  | (528 | ) |
| Warranty accrual, end of period | $ | 7,658 |  |  | $ | 4,883 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001596532-17-000088:notes:150]
[same as prior period, unchanged from 0001596532-16-000331:notes:130]

[0001596532-17-000088:notes:151]
|  | Three Months EndedMarch 31, |
|  | 2017 |  | 2016 |
| United States | $ | 262,389 |  |  | $ | 180,876 |  |
| Other Americas | 2,474 |  |  | 1,765 |  |
| Europe, Middle East and Africa | 42,734 |  |  | 43,739 |  |
| Asia-Pacific | 27,878 |  |  | 15,816 |  |
| Total revenue | $ | 335,475 |  |  | $ | 242,196 |  |

[0001596532-17-000088:notes:152]
[same as prior period, unchanged from 0001596532-16-000331:notes:132]

[0001596532-17-000088:notes:153]
|  | March 31, 2017 |  | December 31, 2016 |
| United States | $ | 68,802 |  |  | $ | 69,352 |  |
| International | 7,517 |  |  | 7,609 |  |
| Total | $ | 76,319 |  |  | $ | 76,961 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-17-000088:notes:154]
[same as prior period, unchanged from 0001596532-16-000331:notes:134]

[0001596532-17-000088:notes:155]
[same as prior period, unchanged from 0001596532-16-000331:notes:135]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-17-000088:notes:156]
[same as prior period, unchanged from 0001596532-16-000331:notes:136]

[0001596532-17-000088:notes:157]
[same as prior period, unchanged from 0001596532-16-000331:notes:137]

[0001596532-17-000088:notes:158]
As of March 31, 2017 and December 31, 2016, there have been no other-than-temporary losses on our marketable securities. None of our marketable securities have been in continuous unrealized loss positions for greater than twelve months as of March 31, 2017.

[0001596532-17-000088:notes:159]
[same as prior period, unchanged from 0001596532-16-000331:notes:139]

[0001596532-17-000088:notes:160]
The weighted average remaining duration of our current marketable securities is approximately 0.9 years as of March 31, 2017.  As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying unaudited condensed consolidated balance sheets.

[0001596532-17-000088:notes:161]
[same as prior period, unchanged from 0001596532-16-000331:notes:141]

[0001596532-17-000088:notes:162]
[same as prior period, unchanged from 0001596532-16-000331:notes:142]

[0001596532-17-000088:notes:163]
[same as prior period, unchanged from 0001596532-16-000331:notes:143]

[0001596532-17-000088:notes:164]
[same as prior period, unchanged from 0001596532-16-000331:notes:144]

[0001596532-17-000088:notes:165]
Depreciation and amortization expense was $4.8 million and $4.8 million for the three months ended March 31, 2017 and 2016, respectively.

[0001596532-17-000088:notes:166]
[same as prior period, unchanged from 0001596532-16-000331:notes:147]

[0001596532-17-000088:notes:167]
[same as prior period, unchanged from 0001596532-16-000331:notes:148]

[0001596532-17-000088:notes:168]
We offer a one-year warranty on all of our hardware products and a 90-day warranty against defects in the software embedded in the products. The accrued warranty liability is recorded in accrued liabilities in the accompanying unaudited condensed consolidated balance sheets.
