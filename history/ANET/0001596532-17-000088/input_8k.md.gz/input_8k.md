# ANET 8-K — 0001596532-17-000085 filed 2017-05-04

## item codes, every 8-K on or before 2017-05-08

- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2017-05-08

- none on or before 2017-05-08

## item 2.02 — earnings release, exhibit 99.1

[0001596532-17-000085:8k_2_02:1]
EX-99.1
2
ex991q117-earnings.htm
EXHIBIT 99.1

[0001596532-17-000085:8k_2_02:2]
Exhibit

[0001596532-17-000085:8k_2_02:3]
Exhibit 99.1

[0001596532-17-000085:8k_2_02:4]
Arista Networks, Inc. Reports First Quarter 2017 Financial Results

[0001596532-17-000085:8k_2_02:5]
Cloud Networking Adoption Continues Momentum with Record Revenue

[0001596532-17-000085:8k_2_02:6]
SANTA CLARA, Calif., May 4, 2017-- Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large data center and computing environments, today announced financial results for its first quarter ended March 31, 2017.

[0001596532-17-000085:8k_2_02:7]
First Quarter Financial Highlights

[0001596532-17-000085:8k_2_02:8]
| • | Revenue of $335.5 million, an increase of 2.3% compared to the fourth quarter of 2016, and an increase of 38.5% from the first quarter of 2016. |

[0001596532-17-000085:8k_2_02:9]
| • | GAAP gross margin of 63.9%, compared to GAAP gross margin of 64.1% in the fourth quarter of 2016 and 64.0% in the first quarter of 2016. |

[0001596532-17-000085:8k_2_02:10]
| • | Non-GAAP gross margin of 64.2%, compared to non-GAAP gross margin of 64.4% in the fourth quarter of 2016 and 64.4% in the first quarter of 2016. |

[0001596532-17-000085:8k_2_02:11]
| • | GAAP net income of $83.0 million, or $1.07 per diluted share, compared to GAAP net income of $35.2 million, or $0.48 per diluted share, in the first quarter of 2016. |

[0001596532-17-000085:8k_2_02:12]
| • | Non-GAAP net income of $71.8 million, or $0.93 per diluted share, compared to non-GAAP net income of $49.1 million, or $0.68 per diluted share, in the first quarter of 2016. |

[0001596532-17-000085:8k_2_02:13]
"As we kick off 2017, I am pleased with our performance this quarter,” stated Jayshree Ullal, Arista President and CEO. “We continue to experience meaningful relevance as customers shift to cloud networking.”

[0001596532-17-000085:8k_2_02:14]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, "We are pleased with our consistent execution in the first quarter and with our outlook for Q2, reflecting continued strong customer demand for our products.”

[0001596532-17-000085:8k_2_02:15]
Company Highlights

[0001596532-17-000085:8k_2_02:16]
| • | Introduced Containerized EOS (cEOS™) supporting alternate models of procuring, packaging and deploying Arista’s EOS® across cloud, enterprises and service providers. |

[0001596532-17-000085:8k_2_02:17]
| • | Arista Data ANalyZer DANZ 2017 R-Series Universal Leaf and Spine platforms support improved visibility to 25G and 100G networks. DANZ, powered by Arista EOS® (Extensible Operating System) and combined with Arista CloudVision® for automation and telemetry, delivers the hyperscale visibility platform required to secure today’s cloud centric applications and workflows. |

[0001596532-17-000085:8k_2_02:18]
| • | Several platforms achieved information assurance (IA) interoperability (IO) certification from the Joint Interoperability Command (JITC) and are now included on the U.S. Department of Defense (DoD) Unified Capabilities Approved Products List (UC APL) |

[0001596532-17-000085:8k_2_02:19]
Financial Outlook

[0001596532-17-000085:8k_2_02:20]
For the second quarter of 2017, we expect:

[0001596532-17-000085:8k_2_02:21]
| • | Revenue between $354 and $364 million. |

[0001596532-17-000085:8k_2_02:22]
| • | Non-GAAP gross margin between 61% to 64%. |

[0001596532-17-000085:8k_2_02:23]
| • | Non-GAAP operating margin of approximately 28%. |

[0001596532-17-000085:8k_2_02:24]
Guidance for non-GAAP financial measures excludes legal expenses of approximately $12 million associated with the OptumSoft and Cisco litigation, stock-based compensation and other non-recurring expenses. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below).

[0001596532-17-000085:8k_2_02:25]
Prepared Materials and Conference Call Information

[0001596532-17-000085:8k_2_02:26]
Arista executives will discuss first quarter 2017 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial 1-877-201-0168 in the United States or 1-647-788-4901 from outside the US. The Conference ID is 3928812.

[0001596532-17-000085:8k_2_02:27]
The financial results conference call will also be available via live webcast on our investor relations website at investors.arista.com. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s Investor Relations website.

[0001596532-17-000085:8k_2_02:28]
Forward-Looking Statements

[0001596532-17-000085:8k_2_02:29]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the second quarter of fiscal 2017, and statements regarding the benefits from the introduction of new products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements

[0001596532-17-000085:8k_2_02:30]
including risks associated with: Arista Networks’ limited operating history; risks associated with Arista Networks’ rapid growth; Arista Networks’ customer concentration; Arista Networks’ dispute with Cisco Systems, Inc.  including the issuance of any ITC remedial orders prohibiting the importation of Arista products (or components thereof) into the U.S., Arista Networks’ ability to obtain a determination that alternative product implementations are not covered by such ITC remedial orders, any penalties assess by the ITC if Arista does not obtain such a determination and Arista Networks’ ability to manage our manufacturing and supply chain including the sourcing of components on commercially reasonable terms, if at all; risks associated with our customer’s adoption of our redesigned products and services; requests for more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; changes in customer order patterns or customer mix; increased competition in our products and service markets, including the data center market; dependence on the introduction and market acceptance of new product offerings and standards; rapid technological and market change; the evolution of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; Arista Networks’ dispute with OptumSoft; and general market, political, economic and business conditions. Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s Annual Report on Form 10-K filed with the SEC on February 17, 2017, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at http://investors.arista.com/and on the SEC’s website at http://www.sec.gov/.  All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-17-000085:8k_2_02:31]
Non-GAAP Financial Measures

[0001596532-17-000085:8k_2_02:32]
The company reports certain non-GAAP financial measures that exclude stock-based compensation and related excess tax benefits, expenses associated with the OptumSoft and Cisco litigation, other non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-17-000085:8k_2_02:33]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP net income, net income per diluted share, gross margin, or operating margin. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-17-000085:8k_2_02:34]
The Company’s guidance for non-GAAP financial measures excludes stock-based compensation, expenses associated with the OptumSoft and Cisco litigation, and other non-recurring charges. The Company has not reconciled its non-GAAP gross margin or its non-GAAP operating margin guidance to GAAP gross margin or GAAP operating margin, because we do not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling cash and non-cash items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. Stock-based compensation expense is impacted by the Company’s future hiring and retention needs and the future fair market value of the Company’s common stock.  In addition, excess tax benefits on share-based awards will fluctuate based on these same factors, as well as the timing of exercise or vesting of such awards, all of which are difficult to predict and subject to constant change. The actual amount of stock-based and excess tax benefits will have a significant impact on the Company’s GAAP gross margin and GAAP operating margin. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measure is not available without unreasonable effort.

[0001596532-17-000085:8k_2_02:35]
About Arista Networks

[0001596532-17-000085:8k_2_02:36]
Arista Networks was founded to pioneer and deliver software-driven cloud networking solutions for large datacenter storage and computing environments. Arista’s award-winning platforms, ranging in Ethernet speeds from 10 to 100 gigabits per second, redefine scalability, agility and resilience. Arista has shipped more than ten million cloud networking ports worldwide with CloudVision and EOS, an advanced network operating system. Committed to open standards, Arista is a founding member of the 25/50GbE consortium. Arista Networks products are available worldwide directly and through partners.

[0001596532-17-000085:8k_2_02:37]
ARISTA, EOS CloudVision and cEOS, are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-17-000085:8k_2_02:38]
Additional information and resources can be found at: http://www.arista.com

[0001596532-17-000085:8k_2_02:39]
| Media ContactAmanda JaramilloCorporate Communications(408) 547-5798amanda@arista.com |  | Investor ContactCharles YagerProduct and Investor Advocacy(408) 547-5892cyager@arista.com |

[0001596532-17-000085:8k_2_02:40]
ARISTA NETWORKS, INC.

[0001596532-17-000085:8k_2_02:41]
Consolidated Statements of Income

[0001596532-17-000085:8k_2_02:42]
(Unaudited in thousands, except per share amounts)

[0001596532-17-000085:8k_2_02:43]
|  | Three Months Ended March 31, |
|  | 2017 |  | 2016 |
| Revenue: |  |  |  |
| Product | $ | 291,367 |  |  | $ | 212,475 |  |
| Service | 44,108 |  |  | 29,721 |  |
| Total revenue | 335,475 |  |  | 242,196 |  |
| Cost of revenue: |  |  |  |
| Product | 109,836 |  |  | 78,913 |  |
| Service | 11,429 |  |  | 8,193 |  |
| Total cost of revenue | 121,265 |  |  | 87,106 |  |
| Gross profit | 214,210 |  |  | 155,090 |  |
| Operating expenses: |  |  |  |
| Research and development | 81,610 |  |  | 62,515 |  |
| Sales and marketing | 37,027 |  |  | 27,606 |  |
| General and administrative | 22,155 |  |  | 15,234 |  |
| Total operating expenses | 140,792 |  |  | 105,355 |  |
| Income from operations | 73,418 |  |  | 49,735 |  |
| Other income (expense), net: |  |  |  |
| Interest expense | (715 | ) |  | (751 | ) |
| Other income (expense), net | 1,025 |  |  | 337 |  |
| Total other income (expense), net | 310 |  |  | (414 | ) |
| Income before provision (benefit) for income taxes | 73,728 |  |  | 49,321 |  |
| Provision (benefit) for income taxes | (9,233 | ) |  | 14,076 |  |
| Net income | $ | 82,961 |  |  | $ | 35,245 |  |
| Net income attributable to common stockholders: |  |  |  |
| Basic | $ | 82,694 |  |  | $ | 34,921 |  |
| Diluted | $ | 82,716 |  |  | $ | 34,941 |  |
| Net income per share attributable to common stockholders: |  |  |  |
| Basic | $ | 1.16 |  |  | $ | 0.52 |  |
| Diluted | $ | 1.07 |  |  | $ | 0.48 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |
| Basic | 71,114 |  |  | 67,737 |  |
| Diluted | 77,516 |  |  | 72,214 |  |

[0001596532-17-000085:8k_2_02:44]
ARISTA NETWORKS, INC.

[0001596532-17-000085:8k_2_02:45]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-17-000085:8k_2_02:46]
(Unaudited in thousands, except percentages and per share amounts)

[0001596532-17-000085:8k_2_02:47]
|  | Three Months Ended March 31, |
|  | 2017 |  | 2016 |
| GAAP gross profit | $ | 214,210 |  |  | $ | 155,090 |  |
| GAAP gross margin | 63.9 | % |  | 64.0 | % |
| Stock-based compensation expense | 1,024 |  |  | 793 |  |
| Non-GAAP gross profit | $ | 215,234 |  |  | $ | 155,883 |  |
| Non-GAAP gross margin | 64.2 | % |  | 64.4 | % |
| GAAP income from operations | $ | 73,418 |  |  | $ | 49,735 |  |
| Stock-based compensation expense | 16,439 |  |  | 13,360 |  |
| Litigation expense | 11,466 |  |  | 7,005 |  |
| Non-GAAP income from operations | $ | 101,323 |  |  | $ | 70,100 |  |
| Non-GAAP operating margin | 30.2 | % |  | 28.9 | % |
| GAAP net income | $ | 82,961 |  |  | $ | 35,245 |  |
| Stock-based compensation expense | 16,439 |  |  | 13,360 |  |
| Litigation expense | 11,466 |  |  | 7,005 |  |
| Excess tax benefit on share based awards (1) | (28,790 | ) |  | — |  |
| Income tax effect on non-GAAP exclusions | (10,269 | ) |  | (6,524 | ) |
| Non-GAAP net income | $ | 71,807 |  |  | $ | 49,086 |  |
| GAAP diluted net income per share attributable to common stockholders | $ | 1.07 |  |  | $ | 0.48 |  |
| Non-GAAP adjustments to net income | (0.14 | ) |  | 0.20 |  |
| Non-GAAP diluted net income per share | $ | 0.93 |  |  | $ | 0.68 |  |
| Weighted-average shares used in computing diluted net income per share attributable to common stockholders (2) | 77,516 |  |  | 72,214 |  |
| Summary of Stock-Based Compensation Expense |  |  |  |
| Cost of revenue | $ | 1,024 |  |  | $ | 793 |  |
| Research and development | 9,587 |  |  | 7,457 |  |
| Sales and marketing | 3,456 |  |  | 3,647 |  |
| General and administrative | 2,372 |  |  | 1,463 |  |
| Total | $ | 16,439 |  |  | $ | 13,360 |  |

[0001596532-17-000085:8k_2_02:48]
| (1) | The adoption of ASU 2016-09 Compensation-Stock Compensation: Improvements to Employee Share-Based Payment Accounting resulted in a $28.8 million excess tax benefits on share-based awards that are recognized as a reduction to our GAAP provision for income taxes. These amounts have been excluded from our Non-GAAP net income as they relate to our stock based compensation. |

[0001596532-17-000085:8k_2_02:49]
| (2) | The adoption of ASU 2016-09 also removed the excess tax benefits from the diluted share calculation, reducing the assumed shares to be repurchased under the treasury stock method and increasing our diluted share count by approximately 2 million shares. This increase is recorded on a GAAP and Non-GAAP basis and reduced our Non-GAAP EPS by approximately $0.02 in the current quarter. |

[0001596532-17-000085:8k_2_02:50]
ARISTA NETWORKS, INC.

[0001596532-17-000085:8k_2_02:51]
Consolidated Balance Sheets

[0001596532-17-000085:8k_2_02:52]
(Unaudited in thousands)

[0001596532-17-000085:8k_2_02:53]
|  | March 31, 2017 |  | December 31, 2016 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 746,567 |  |  | $ | 567,923 |  |
| Marketable securities | 296,675 |  |  | 299,910 |  |
| Accounts receivable | 209,062 |  |  | 253,119 |  |
| Inventories | 286,786 |  |  | 236,490 |  |
| Prepaid expenses and other current assets | 197,735 |  |  | 168,684 |  |
| Total current assets | 1,736,825 |  |  | 1,526,126 |  |
| Property and equipment, net | 76,319 |  |  | 76,961 |  |
| Investments | 36,136 |  |  | 36,136 |  |
| Deferred tax assets | 70,433 |  |  | 70,960 |  |
| Other assets | 19,885 |  |  | 18,824 |  |
| TOTAL ASSETS | $ | 1,939,598 |  |  | $ | 1,729,007 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 60,984 |  |  | $ | 79,457 |  |
| Accrued liabilities | 75,291 |  |  | 90,951 |  |
| Deferred revenue | 383,245 |  |  | 273,350 |  |
| Other current liabilities | 12,993 |  |  | 15,795 |  |
| Total current liabilities | 532,513 |  |  | 459,553 |  |
| Income taxes payable | 17,581 |  |  | 14,498 |  |
| Lease financing obligations, non-current | 39,136 |  |  | 39,593 |  |
| Deferred revenue, non-current | 113,925 |  |  | 99,585 |  |
| Other long-term liabilities | 8,069 |  |  | 7,958 |  |
| TOTAL LIABILITIES | 711,224 |  |  | 621,187 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 7 |  |  | 7 |  |
| Additional paid-in capital | 711,123 |  |  | 674,183 |  |
| Retained earnings | 518,874 |  |  | 435,105 |  |
| Accumulated other comprehensive loss | (1,630 | ) |  | (1,475 | ) |
| TOTAL STOCKHOLDERS’ EQUITY | 1,228,374 |  |  | 1,107,820 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 1,939,598 |  |  | $ | 1,729,007 |  |

[0001596532-17-000085:8k_2_02:54]
ARISTA NETWORKS, INC.

[0001596532-17-000085:8k_2_02:55]
Consolidated Statements of Cash Flows

[0001596532-17-000085:8k_2_02:56]
(Unaudited in thousands)

[0001596532-17-000085:8k_2_02:57]
|  | Three Months EndedMarch 31, |
|  | 2017 |  | 2016 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 82,961 |  |  | $ | 35,245 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 4,939 |  |  | 4,779 |  |
| Stock-based compensation | 16,439 |  |  | 13,360 |  |
| Deferred income taxes | 2,521 |  |  | (1,597 | ) |
| Amortization of investment premiums | 330 |  |  | — |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | 44,057 |  |  | 9,144 |  |
| Inventories | (50,296 | ) |  | 8,099 |  |
| Prepaid expenses and other current assets | (29,051 | ) |  | 8,878 |  |
| Other assets | 69 |  |  | 533 |  |
| Accounts payable | (18,648 | ) |  | (16,123 | ) |
| Accrued liabilities | (15,143 | ) |  | (14,868 | ) |
| Deferred revenue | 124,236 |  |  | 22,412 |  |
| Income taxes payable | 2,923 |  |  | 6,802 |  |
| Other liabilities | (2,475 | ) |  | 464 |  |
| Net cash provided by operating activities | 162,862 |  |  | 77,128 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Proceeds from maturity of marketable securities | 64,488 |  |  | — |  |
| Purchases of marketable securities | (61,511 | ) |  | (51,638 | ) |
| Purchases of property and equipment | (4,645 | ) |  | (8,632 | ) |
| Changes in restricted cash | (1,252 | ) |  | — |  |
| Net cash used in investing activities | (2,920 | ) |  | (60,270 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Principal payments of lease financing obligations | (383 | ) |  | (314 | ) |
| Proceeds from issuance of common stock under equity plans | 19,481 |  |  | 6,750 |  |
| Minimum tax withholding paid on behalf of employees for net share settlement | (580 | ) |  | — |  |
| Net cash provided by financing activities | 18,518 |  |  | 6,436 |  |
| Effect of exchange rate changes | 184 |  |  | 43 |  |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 178,644 |  |  | 23,337 |  |
| CASH AND CASH EQUIVALENTS—Beginning of year | 567,923 |  |  | 687,326 |  |
| CASH AND CASH EQUIVALENTS—End of year | $ | 746,567 |  |  | $ | 710,663 |  |
