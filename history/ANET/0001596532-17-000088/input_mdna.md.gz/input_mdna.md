# ANET MD&A — 0001596532-17-000088


## mdna

[0001596532-17-000088:mdna:1]
[same as prior period, unchanged from 0001596532-16-000331:mdna:1]

[0001596532-17-000088:mdna:2]
[same as prior period, unchanged from 0001596532-16-000331:mdna:2]

[0001596532-17-000088:mdna:3]
We are a leading supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation data centers for enterprise support. Our cloud networking solutions consist of our Extensible Operating System, or EOS, a set of network applications and our Ethernet switching and routing platforms. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. At the core of our cloud networking platform is EOS, which was purpose-built to be fully programmable and highly modular. The programmability of EOS has allowed us to create a set of software applications that address the requirements of cloud networking, including workflow automation, network visibility and analytics, and has also allowed us to rapidly integrate with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001596532-17-000088:mdna:4]
We believe that cloud networks will continue to replace legacy network technologies, and that our cloud networking platform addresses the large and growing cloud networking segment of data center switching, which remains in the early stage of adoption.  Cloud networks are subject to increasing performance requirements due to the growing number of connected devices, as well as new enterprise and consumer applications.  Computing architectures are evolving to meet the need for constant connectivity and access to data and applications. We expect to continue growing our organization to meet the needs of new and existing customers as they increasingly realize the performance and cost benefits of our cloud networking solutions and as they expand their cloud networks. Accordingly, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our rapid development of new features and applications.

[0001596532-17-000088:mdna:5]
We generate revenue primarily from sales of our switching products which incorporate our EOS software. We generate the majority of our services revenue from post contract support, or PCS, which end customers typically purchase in conjunction with our products.  Our end customers span a range of industries and include large Internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others.  As we have grown the functionality of our EOS software, expanded the range of our product portfolio and increased the size of our sales force, our revenue has continued to grow rapidly.  We have also been profitable and cash flow positive for each year since 2010.

[0001596532-17-000088:mdna:6]
To continue to grow our revenue, it is important that we both obtain new customers and sell additional products to existing customers.  We expect that a substantial portion of our future sales will be follow-on sales to existing customers.  We intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new end customers more effectively, increase sales to existing customers, and provide services and support effectively.  In order to support our strong growth, we have and may continue to accelerate our investment in infrastructure, such as enterprise resource planning software and other technologies to improve the efficiency of our operations.

[0001596532-17-000088:mdna:7]
Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic to the underlying merchant silicon architecture. Today, we combine our EOS software with merchant silicon into a family of switching and routing products. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We currently procure certain merchant silicon components from multiple vendors, and we continue to expand our relationships with these and other vendors. We work closely with third party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-17-000088:mdna:8]
Historically, large purchases by a relatively limited number of end customers have accounted for significant portion of our revenue. We have experienced unpredictability in the timing of large orders, especially with respect to our large end customers, due to the complexity of orders, the time it takes end customers to evaluate, test, qualify and accept our products and factors specific to our end customers. Due to these factors, we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, we have provided, and may in the future provide, pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur. Our gross margins may also fluctuate as a result of the timing of such sales to large end customers.

[0001596532-17-000088:mdna:9]
[same as prior period, unchanged from 0001596532-16-000331:mdna:46]

[0001596532-17-000088:mdna:10]
The following table summarizes historical results of operations for the periods presented and as a percentage of revenue for those periods.  We have derived the data for the three months ended March 31, 2017 and 2016 from our unaudited condensed consolidated financial statements (in thousands, except for percentages).

[0001596532-17-000088:mdna:11]
|  | Three Months EndedMarch 31, |
|  | 2017 |  | 2016 |
| Revenue: |  |  |  |
| Product | $ | 291,367 |  |  | $ | 212,475 |  |
| Service | 44,108 |  |  | 29,721 |  |
| Total revenue | 335,475 |  |  | 242,196 |  |
| Cost of revenue (1): |  |  |  |
| Product | 109,836 |  |  | 78,913 |  |
| Service | 11,429 |  |  | 8,193 |  |
| Total cost of revenue | 121,265 |  |  | 87,106 |  |
| Gross profit | 214,210 |  |  | 155,090 |  |
| Operating expenses (1): |  |  |  |
| Research and development | 81,610 |  |  | 62,515 |  |
| Sales and marketing | 37,027 |  |  | 27,606 |  |
| General and administrative | 22,155 |  |  | 15,234 |  |
| Total operating expenses | 140,792 |  |  | 105,355 |  |
| Income from operations | 73,418 |  |  | 49,735 |  |
| Interest expense | (715 | ) |  | (751 | ) |
| Other income (expense), net | 1,025 |  |  | 337 |  |
| Total other income (expense), net | 310 |  |  | (414 | ) |
| Income before provision (benefit) for income taxes | 73,728 |  |  | 49,321 |  |
| Provision (benefit) for income taxes | (9,233 | ) |  | 14,076 |  |
| Net income | $ | 82,961 |  |  | $ | 35,245 |  |

[0001596532-17-000088:mdna:12]
25

[0001596532-17-000088:mdna:13]
|  | Three Months EndedMarch 31, |
|  | 2017 |  | 2016 |
|  | (as a percentage of revenue) |
| Revenue: |  |  |  |
| Product | 86.9 | % |  | 87.7 | % |
| Service | 13.1 |  |  | 12.3 |  |
| Total revenue | 100.0 |  |  | 100.0 |  |
| Cost of revenue: |  |  |  |
| Product | 32.7 |  |  | 32.6 |  |
| Service | 3.4 |  |  | 3.4 |  |
| Total cost of revenue | 36.1 |  |  | 36.0 |  |
| Gross margin | 63.9 |  |  | 64.0 |  |
| Operating expenses: |  |  |  |
| Research and development | 24.4 |  |  | 25.8 |  |
| Sales and marketing | 11.0 |  |  | 11.4 |  |
| General and administrative | 6.6 |  |  | 6.3 |  |
| Total operating expenses | 42.0 |  |  | 43.5 |  |
| Income from operations | 21.9 |  |  | 20.5 |  |
| Interest expense | (0.2 | ) |  | (0.2 | ) |
| Other income (expense), net | 0.3 |  |  | 0.1 |  |
| Total other income (expense), net | 0.1 |  |  | (0.1 | ) |
| Income before provision (benefit) for income taxes | 22.0 |  |  | 20.4 |  |
| Provision (benefit) for income taxes | (2.8 | ) |  | 5.8 |  |
| Net income | 24.8 | % |  | 14.6 | % |

[0001596532-17-000088:mdna:14]
[same as prior period, unchanged from 0001596532-16-000331:mdna:51]

[0001596532-17-000088:mdna:15]
[same as prior period, unchanged from 0001596532-16-000331:mdna:52]

[0001596532-17-000088:mdna:16]
|  | Three Months EndedMarch 31, |
|  | 2017 |  | 2016 |
| Cost of revenue | $ | 1,024 |  |  | $ | 793 |  |
| Research and development | 9,587 |  |  | 7,457 |  |
| Sales and marketing | 3,456 |  |  | 3,647 |  |
| General and administrative | 2,372 |  |  | 1,463 |  |
| Total stock-based compensation | $ | 16,439 |  |  | $ | 13,360 |  |

[0001596532-17-000088:mdna:17]
Three Months Ended March 31, 2017 Compared to Three Months Ended March 31, 2016

[0001596532-17-000088:mdna:18]
Revenue, Cost of Revenue and Gross Margin

[0001596532-17-000088:mdna:19]
We generate revenue primarily from sales of our switching products, and a portion of our revenue from sales of PCS.  We expect our revenue may vary from period to period based on, among other things, the timing and size of orders, the delivery and acceptance of products, and the impact of significant transactions with unique terms and conditions that may require deferral of revenue.

[0001596532-17-000088:mdna:20]
Cost of revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs in our manufacturing operations department, and other manufacturing-related costs associated with manufacturing our products and managing our inventory. We expect our cost of product revenue to increase as our product revenue increases. Cost of providing PCS and other services consists primarily of personnel costs for our global customer support organization.

[0001596532-17-000088:mdna:21]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including sales to large end customers who generally receive lower pricing, manufacturing-related costs, including costs associated with the introduction of additional contract manufacturing capacity, merchant silicon costs, supply chain sourcing and the mix of products sold. We expect our gross margins to fluctuate over time, depending on the factors described above and others.

[0001596532-17-000088:mdna:22]
| (in thousands, except percentages) | Three Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | Change in |
|  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |
| Product | $ | 291,367 |  |  | $ | 212,475 |  |  | $ | 78,892 |  |  | 37.1% |
| Service | 44,108 |  |  | 29,721 |  |  | 14,387 |  |  | 48.4 |
| Total revenue | 335,475 |  |  | 242,196 |  |  | 93,279 |  |  | 38.5 |
| Cost of revenue |  |  |  |  |  |  |  |
| Product | 109,836 |  |  | 78,913 |  |  | 30,923 |  |  | 39.2 |
| Service | 11,429 |  |  | 8,193 |  |  | 3,236 |  |  | 39.5 |
| Total cost of revenue | 121,265 |  |  | 87,106 |  |  | 34,159 |  |  | 39.2 |
| Gross profit | $ | 214,210 |  |  | $ | 155,090 |  |  | $ | 59,120 |  |  | 38.1% |
| Gross margin | 63.9 | % |  | 64.0 | % |  |  |  |  |

[0001596532-17-000088:mdna:23]
Revenue by Geography

[0001596532-17-000088:mdna:24]
| (in thousands, except percentages) | Three Months EndedMarch 31, |
|  | 2017 |  | % of Total |  | 2016 |  | % of Total |
| Americas | $ | 264,863 |  |  | 79.0 | % |  | $ | 182,641 |  |  | 75.4 | % |
| Europe, Middle East and Africa | 42,734 |  |  | 12.7 |  |  | 43,739 |  |  | 18.1 |  |
| Asia-Pacific | 27,878 |  |  | 8.3 |  |  | 15,816 |  |  | 6.5 |  |
| Total revenue | $ | 335,475 |  |  | 100.0 | % |  | $ | 242,196 |  |  | 100.0 | % |

[0001596532-17-000088:mdna:25]
[same as prior period, unchanged from 0001596532-16-000331:mdna:22]

[0001596532-17-000088:mdna:26]
Product revenue increased $78.9 million or 37.1% in the three months ended March 31, 2017 compared to the same period in 2016.  The increase was primarily driven by increased shipments to our existing customers as they continue to grow and expand their businesses, increasing their demand for our switch products and related accessories.  In addition, our newer products have continued to gain market acceptance, which has contributed to our revenue growth.  Service revenue increased $14.4 million or 48.4% in the three months ended March 31, 2017 compared to the same period in 2016, as a result of continued growth in initial and renewal support contracts as our customer installed base continued to expand.  We continue to experience pressure in product and service pricing due to competitive market conditions.  However, this pricing pressure was more than offset by the increased demand drivers outlined above.

[0001596532-17-000088:mdna:27]
[same as prior period, unchanged from 0001596532-16-000331:mdna:62]

[0001596532-17-000088:mdna:28]
Cost of revenue increased $34.2 million or 39.2% in the three months ended March 31, 2017 compared to the same period in 2016. The increase in cost of revenue was primarily due to an increase in product shipment volumes and the corresponding increase in product revenue.  In addition, we incurred increased costs as we added capacity to our U.S. based manufacturing and operations infrastructure.  Gross margin remained generally consistent, decreasing slightly from 64.0% to 63.9% for the three months ended March 31, 2017 compared to the same period in 2016.

[0001596532-17-000088:mdna:29]
[same as prior period, unchanged from 0001596532-16-000331:mdna:54]

[0001596532-17-000088:mdna:30]
[same as prior period, unchanged from 0001596532-16-000331:mdna:28]

[0001596532-17-000088:mdna:31]
[same as prior period, unchanged from 0001596532-16-000331:mdna:29]

[0001596532-17-000088:mdna:32]
| (in thousands, except percentages) | Three Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | Change in |
|  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | $ | 81,610 |  |  | $ | 62,515 |  |  | $ | 19,095 |  |  | 30.5% |
| Sales and marketing | 37,027 |  |  | 27,606 |  |  | 9,421 |  |  | 34.1 |
| General and administrative | 22,155 |  |  | 15,234 |  |  | 6,921 |  |  | 45.4 |
| Total operating expenses | $ | 140,792 |  |  | $ | 105,355 |  |  | $ | 35,437 |  |  | 33.6% |

[0001596532-17-000088:mdna:33]
[same as prior period, unchanged from 0001596532-16-000331:mdna:66]

[0001596532-17-000088:mdna:34]
Research and development expenses consist primarily of personnel costs, prototype expenses, third-party engineering and contractor support costs, and an allocated portion of facility and IT costs. Our research and development efforts are focused on maintaining and developing additional functionality for our existing products and on new product development, including new releases and upgrades to our EOS software and applications. We expect our research and development expenses to increase in absolute dollars as we continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products and features and build upon our technology leadership.

[0001596532-17-000088:mdna:35]
Research and development expenses increased $19.1 million or 30.5% for the three months ended March 31, 2017 compared to the same period in 2016.  This increase was primarily due to an increase of $10.7 million in prototype and third-party engineering and consulting costs and increased personnel costs of $8.0 million primarily driven by headcount growth, resulting in additional compensation costs including stock-based compensation.

[0001596532-17-000088:mdna:36]
[same as prior period, unchanged from 0001596532-16-000331:mdna:68]

[0001596532-17-000088:mdna:37]
Sales and marketing expenses consist primarily of personnel costs, marketing and promotional activities, and an allocated portion of facility and IT costs. We expect our sales and marketing expenses to increase in absolute dollars as we expand our sales and marketing efforts worldwide, and our relationships with current and future channel partners and end customers.

[0001596532-17-000088:mdna:38]
Sales and marketing expenses increased $9.4 million or 34.1% for the three months ended March 31, 2017 compared to the same period in 2016. The increase was primarily due to an increase in personnel costs of $7.0 million, reflecting increased compensation costs, including commissions, primarily driven by headcount growth and higher sales volumes.  Sales support costs increased by $2.0 million reflecting increased professional services and field demonstration costs.

[0001596532-17-000088:mdna:39]
[same as prior period, unchanged from 0001596532-16-000331:mdna:70]

[0001596532-17-000088:mdna:40]
General and administrative expenses consist primarily of personnel costs, legal and professional fees, and an allocated portion of facility and IT costs. General and administrative personnel costs include those for our executive, finance, human resources and legal functions. Our professional services costs are primarily due to external legal, accounting, and tax services.

[0001596532-17-000088:mdna:41]
General and administrative expenses increased $6.9 million or 45.4% for the three months ended March 31, 2017 compared to the same period in 2016.  The increase was primarily due to an increase in litigation expenses of $4.5 million.  This increase was primarily related to the timing of litigation activities associated with the Cisco legal matters outlined Note 5 to these Condensed Consolidated Financial Statements.  In addition personnel costs increased by $1.2 million as compared to the same period in 2016, primarily reflecting increased stock-based compensation.

[0001596532-17-000088:mdna:42]
[same as prior period, unchanged from 0001596532-16-000331:mdna:36]

[0001596532-17-000088:mdna:43]
Other income (expense), net primarily consists of interest income on marketable securities and foreign currency transaction gains and losses, and interest expense from our lease financing obligation.

[0001596532-17-000088:mdna:44]
| (in thousands, except percentages) | Three Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | Change in |
|  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (715 | ) |  | $ | (751 | ) |  | $ | 36 |  |  | 4.8% |
| Other income (expense), net | 1,025 |  |  | 337 |  |  | 688 |  |  | 204.2 |
| Total other income (expense), net | $ | 310 |  |  | $ | (414 | ) |  | $ | 724 |  |  | 174.9% |

[0001596532-17-000088:mdna:45]
[same as prior period, unchanged from 0001596532-16-000331:mdna:74]

[0001596532-17-000088:mdna:46]
Other income (expense), net improved during the three months ended March 31, 2017 compared to the same period in 2016 primarily due to a net increase in interest income resulting from an increase in our marketable securities portfolio.

[0001596532-17-000088:mdna:47]
Provision (Benefit) for Income Taxes

[0001596532-17-000088:mdna:48]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may be subject to U.S. income tax. Generally, our U.S. tax obligations are reduced by a credit for foreign income taxes paid on these earnings which avoids double taxation. Our tax expense to date consists of federal, state and foreign current and deferred income taxes.

[0001596532-17-000088:mdna:49]
| (in thousands, except percentages) | Three Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | Change in |
|  | $ |  | $ |  | $ |  | % |
| Provision (benefit) for income taxes | $ | (9,233 | ) |  | $ | 14,076 |  |  | $ | (23,309 | ) |  | (165.6)% |
| Effective tax rate | (12.5 | )% |  | 28.5 | % |  |  |  |  |

[0001596532-17-000088:mdna:50]
The effective tax rate for the three months ended March 31, 2017 was significantly lower than the U.S federal statutory rate primarily due to the recognition of excess tax benefits resulting from the adoption of ASU 2016-09, and earnings taxed at lower rates in foreign jurisdictions. The decrease in the effective tax rate in the three months ended March 31, 2017, as compared to the same period in 2016, was primarily due to the recognition of excess tax benefits as a component of the provision for income taxes attributable to the adoption of ASU 2016-09.  Prior to the adoption, these benefits were recorded as a component of shareholders' equity. Our future effective tax rate may fluctuate based upon our stock price and the amount of stock options exercised and equity awards vested in the quarter.

[0001596532-17-000088:mdna:51]
[same as prior period, unchanged from 0001596532-16-000331:mdna:81]

[0001596532-17-000088:mdna:52]
Our principal sources of liquidity are cash and cash equivalents, marketable securities, and cash generated from operations. As of March 31, 2017, cash and cash equivalents, and marketable securities were $1.0 billion, of which approximately $112.1 million was held outside the U.S. in our foreign subsidiaries.  We have not repatriated, nor do we currently have plans to repatriate these funds, but if we were to repatriate cash held outside of the U.S. for domestic cash operations, we would be required to accrue and pay U.S. income taxes to repatriate these funds, less any previously paid foreign income taxes. We consider the undistributed earnings of our foreign subsidiaries as of March 31, 2017 to be indefinitely reinvested, and, accordingly, no U.S. income taxes have been provided thereon.

[0001596532-17-000088:mdna:53]
Our cash and cash equivalents, and marketable securities are held for working capital purposes. We plan to continue to invest for long-term growth. We believe that our existing cash and cash equivalents together with cash flows from operations will be sufficient to meet our working capital requirements and our growth strategies for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs and access to outsourcing our manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and costs incurred related to outstanding litigation claims. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-17-000088:mdna:54]
[same as prior period, unchanged from 0001596532-16-000331:mdna:84]

[0001596532-17-000088:mdna:55]
|  | Three Months EndedMarch 31, |
|  | 2017 |  | 2016 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 162,862 |  |  | $ | 77,128 |  |
| Cash used in by investing activities | (2,920 | ) |  | (60,270 | ) |
| Cash provided by financing activities | 18,518 |  |  | 6,436 |  |
| Effect of exchange rate changes | 184 |  |  | 43 |  |
| Net increase in cash and cash equivalents | $ | 178,644 |  |  | $ | 23,337 |  |

[0001596532-17-000088:mdna:56]
[same as prior period, unchanged from 0001596532-16-000331:mdna:87]

[0001596532-17-000088:mdna:57]
During the three months ended March 31, 2017, cash provided by operating activities was $162.9 million, resulting from net income of $83.0 million, non-cash adjustments to net income of $24.2 million, and a net increase in cash from changes in our operating assets and liabilities of $55.7 million.  Our operating cash benefited from increased deferred revenue of $124.2 million resulting from growth in product deferred revenue related to contract acceptance terms and ongoing growth in PCS contracts.  In addition, we experienced strong cash collections in the period, generating $44.1 million of cash.  These increases were partially offset by growth in inventory of $50.3 million, supporting overall growth in the business and the expansion of our manufacturing and supply chain activities.  In addition, accounts payable and accrued liabilities declined $33.8 million primarily due to corporate bonus payments and the timing of vendor payments related to inventory purchases.  Prepaid expenses and current assets increased by $29.1 million primarily due to higher deferred cost of inventory associated with the increased product revenue deferrals referenced above, and an increase in income taxes receivable from excess tax benefits generated from stock option exercises and vesting of stock awards.

[0001596532-17-000088:mdna:58]
During the three months ended March 31, 2016, cash provided by operating activities was $77.1 million, primarily from net income of $35.2 million, a net increase in cash from changes in our operating assets and liabilities of $25.3 million, and net non-cash charges of $10.5 million. The net increase in cash from changes in operating assets and liabilities was primarily due to an increase in deferred revenue of $22.4 million mostly related to additional PCS contracts. In addition, we experienced an increase in cash of $6.8 million from changes in income tax payable, a decrease in our accounts receivable of $9.1 million resulting from strong collections during the period, a decrease in inventory of $8.1 million due to reductions in our finished goods inventory, and a reduction in prepaid expenses and current assets of $8.9 million primarily from a decrease in prepaid income taxes during the period. Operating cash flow increases were offset by a decrease in our accounts payable and accrued liabilities of $31.0 million primarily due to corporate bonus payments and the timing of vendor payments.

[0001596532-17-000088:mdna:59]
[same as prior period, unchanged from 0001596532-16-000331:mdna:91]

[0001596532-17-000088:mdna:60]
During the three months ended March 31, 2017, cash used in investing activities was $2.9 million, consisting of purchases of available-for-sale securities of $61.5 million, offset by proceeds of $64.5 million and purchases of property, equipment and other assets of $4.6 million.

[0001596532-17-000088:mdna:61]
During the three months ended March 31, 2016, cash used in investing activities was $60.3 million, consisting of purchases of available-for-sale securities of $0.0 million and purchases of property, equipment and other assets of $8.6 million.

[0001596532-17-000088:mdna:62]
[same as prior period, unchanged from 0001596532-16-000331:mdna:96]

[0001596532-17-000088:mdna:63]
During the three months ended March 31, 2017, cash provided by financing activities was $18.5 million, consisting primarily of proceeds from the issuance of common stock under employee equity incentive plans of $19.5 million.

[0001596532-17-000088:mdna:64]
During the three months ended March 31, 2016, cash provided by financing activities was $6.4 million, consisting primarily of proceeds from the issuance of common stock from our ESPP of 4.9 million, and the exercise of stock options, net of repurchases of 1.8 million, offset by payments of $0.3 million for lease financing obligations.

[0001596532-17-000088:mdna:65]
[same as prior period, unchanged from 0001596532-16-000331:mdna:100]

[0001596532-17-000088:mdna:66]
As of March 31, 2017, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-17-000088:mdna:67]
[same as prior period, unchanged from 0001596532-16-000331:mdna:102]

[0001596532-17-000088:mdna:68]
As of March 31, 2017, our principal commitments consist of obligations under operating leases and purchase commitments. There have been no significant changes to these obligations during the three months ended March 31, 2017, compared to the contractual

[0001596532-17-000088:mdna:69]
obligations disclosed in our "Management's Discussion and Analysis of Financial Condition and Results of Operations" included in our Annual Report on Form 10-K, filed with the SEC on February 17, 2017, other than the purchase commitments described in Note 5. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements of this Quarterly Report on Form 10-Q.

[0001596532-17-000088:mdna:70]
[same as prior period, unchanged from 0001596532-16-000331:mdna:104]

[0001596532-17-000088:mdna:71]
Our management’s discussion and analysis of financial condition and results of operations is based on our unaudited condensed consolidated financial statements, which have been prepared in accordance with GAAP.  The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting policies and estimates discussed in the "Management's Discussion and Analysis of Financial Condition and Results of Operations" section of our Annual Report on Form 10-K filed with the SEC on February 17, 2017, reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting policies and estimates as disclosed in our Annual Report on Form 10-K.

[0001596532-17-000088:mdna:72]
[same as prior period, unchanged from 0001596532-16-000331:mdna:106]

[0001596532-17-000088:mdna:73]
[same as prior period, unchanged from 0001596532-16-000331:mdna:107]

[0001596532-17-000088:mdna:74]
31
