# ANET note change history — 0001596532-16-000331 → 0001596532-17-000088


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-08):
[0001596532-17-000088:note_history:1]
We lease various operating spaces in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2025. We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.  Rent expense for all operating leases amounted to $2.4 million and $2.0 million, for the three months ended March 31, 2017 and 2016, respectively.  There have been no material changes in our operating lease commitments under contractual obligation, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2016.
  (was, 2016-11-03, similarity 0.7441):
[0001596532-16-000331:note_history:1]
We lease various operating spaces in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2024. There have been no material changes in our operating lease commitments under contractual obligation, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2015.

- changed (2017-05-08):
[0001596532-17-000088:note_history:2]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013.  The underlying building asset is depreciated over the building’s estimated useful life of 30 years.  At the conclusion of the initial lease term, we will de-recognize both the net book values of the asset and the remaining financing obligation.  There have been no material changes in our operating lease commitments under contractual obligation, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2016.
  (was, 2016-11-03, similarity 0.9711):
[0001596532-16-000331:note_history:2]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013.  The underlying building asset is depreciated over the building’s estimated useful life of 30 years. At the conclusion of the initial lease term, we will de-recognize both the net book values of the asset and the remaining financing obligation. There have been no material changes in our financing obligation commitments under contractual obligation, as disclosed in our Annual Report on Form 10-K for the year ended December 31, 2015.

- changed (2017-05-08):
[0001596532-17-000088:note_history:3]
As of March 31, 2017 and December 31, 2016, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $40.8 million and $41.2 million, respectively. As of March 31, 2017, $1.7 million and $39.1 million were recorded as short-term and long-term financing obligations, respectively.
  (was, 2016-11-03, similarity 0.9703):
[0001596532-16-000331:note_history:3]
As of September 30, 2016 and December 31, 2015, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $41.6 million and $42.5 million, respectively. As of September 30, 2016, $1.5 million and $40.0 million were recorded as short-term and long-term financing obligations, respectively.

- changed (2017-05-08):
[0001596532-17-000088:note_history:4]
Land lease expense related to our lease financing obligation is classified as rent expense in our unaudited condensed consolidated statements of income, and amounted to $0.3 million for both the three months ended March 31, 2017 and 2016.
  (was, 2016-11-03, similarity 0.7944):
[0001596532-16-000331:note_history:4]
Land lease expense related to our lease financing obligation is classified in rent expense in our unaudited condensed consolidated statements of income, and amounted to $0.3 million and $1.0 million for both the three and nine months ended September 30, 2016 and 2015, respectively.

- changed (2017-05-08):
[0001596532-17-000088:note_history:5]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply.  We issue purchase orders to our contract manufacturers for finished product and a significant portion of these orders consist of firm non-cancelable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancelable, including integrated circuits, which are consigned to our contract manufacturers.   As of March 31, 2017, we had non-cancelable purchase commitments of $362.6 million.  In addition, we have provided deposits to secure our obligations to purchase inventory. We had $42.0 million and $63.1 million in deposits as of March 31, 2017 and December 31, 2016, respectively. These deposits are classified in other current and long term assets in our accompanying unaudited condensed consolidated balance sheets.
  (was, 2016-11-03, similarity 0.9868):
[0001596532-16-000331:note_history:5]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply.  We issue purchase orders to our contract manufacturers for finished product and a significant portion of these orders consist of firm non-cancelable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancelable, including integrated circuits, which are consigned to our contract manufacturers.   As of September 30, 2016, we had non-cancelable purchase commitments of $226.2 million.  In addition, we have provided deposits to secure our obligations to purchase inventory. We had $64.9 million and $2.3 million in deposits as of September 30, 2016 and December 31, 2015, respectively. These deposits are classified in other current and long term assets in our accompanying unaudited condensed consolidated balance sheets.

- changed (2017-05-08):
[0001596532-17-000088:note_history:6]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI” and U.S. Patent Nos. 7,047,526 and 7,953,886 (respectively, “the ’526 patent” and “the ’886 patent”).  As relief for our alleged patent infringement in the ’44 Case, Cisco seeks lost profits and/or reasonable royalty damages in an unspecified amount including treble damages, attorney’s fees, and associated costs as well as injunctive relief.  As relief for our alleged copyright infringement, Cisco seeks monetary damages for alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees, and associated costs.
  (was, 2016-11-03, similarity 0.9973):
[0001596532-16-000331:note_history:6]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI” and U.S. Patent Nos.  7,047,526 and 7,953,886 (respectively, “the 526 patent” and “the 886 patent”).  As relief for our alleged patent infringement in the ’44 Case, Cisco seeks lost profits and/or reasonable royalty damages in an unspecified amount including treble damages, attorney’s fees, and associated costs as well as injunctive relief.  As relief for our alleged copyright infringement, Cisco seeks monetary damages for alleged lost profits, profits from our alleged infringement, statutory damages, attorney's fees, and associated costs.

- added (2017-05-08):
[0001596532-17-000088:note_history:7]
As described below, on May 25, 2016, our petition for Inter Partes Review (“IPR”) of the ’886 patent was instituted by the United States Patent Trial and Appeal Board (“PTAB”). Cisco subsequently agreed to dismiss its claims as to the ‘886 patent with prejudice.

- added (2017-05-08):
[0001596532-17-000088:note_history:8]
Trial began on November 28, 2016, and the jury rendered its verdict on December 14, 2016.  The jury found that Arista had proven its copyright defense of scenes a faire and that Cisco had failed to prove infringement of the ’526 patent, and on that basis judgment was entered in Arista’s favor on all claims on December 19, 2016.

- added (2017-05-08):
[0001596532-17-000088:note_history:9]
On January 17, 2017, Cisco filed a motion for judgment as a matter of law, challenging the sufficiency of the evidence in support of Arista's scenes a faire defense.  Cisco did not file any post-trial motion regarding the ’526 patent, nor did it file a motion for a new trial.  We also filed a motion for judgment as a matter of law on several issues.  The hearing on both parties’ motions was held on April 27, 2017.

- added (2017-05-08):
[0001596532-17-000088:note_history:10]
On February 24, 2016, we filed a complaint against Cisco in the District Court for the Northern District of California alleging antitrust violations and unfair competition.  On August 23, 2016, the Court granted Cisco’s motion to stay the ’23 Case until judgment has been entered on Cisco’s copyright claims in the ’44 Case.  On March 2, 2017, the Court lifted the stay and trial is set for August 3, 2018.

- added (2017-05-08):
[0001596532-17-000088:note_history:11]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we have violated 19 U.S.C. § 1337 (“Section 337”).  The USITC instituted Cisco’s complaint as Investigation No. 337-TA-944. Cisco initially alleged that certain of our switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.  Cisco subsequently dropped the ’296 patent from the 944 Investigation.  Cisco sought, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) and components and software therein and a cease and desist order against us restricting our activities with respect to our imported accused switch products and components and software therein.

- changed (2017-05-08):
[0001596532-17-000088:note_history:12]
On February 2, 2016, the Administrative Law Judge (“ALJ”) issued his initial determination finding a violation of Section 337. More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringe asserted claims 1, 2, 8-11, and 17-19 of the ’537 patent; asserted claims 6, 7, 20, and 21 of the ’592 patent; and asserted claims 5, 7, 45, and 46 of the ’145 patent.  The ALJ did not find a violation of Section 337 with respect to any asserted claims of the ’597 and ’164 patents.  On June 23, 2016, the Commission issued its Final Determination, which found a violation with respect to the ’537, ’592, and ’145 patents, and found no violation with respect to the ’597 and ’164 patents.  The Commission also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 2, 8-11, and 17-19 of the ’537 patent; claims 6, 7, 20, and 21 of the ’592 patent; and claims 5, 7, 45, and 46 of the ’145 patent.  On August 22, 2016, the Presidential review period for the 944 investigation expired.  The USITC orders will be in effect until the expiration of the ’537, ’592, and ’145 patents.
  (was, 2016-11-03, similarity 0.8597):
[0001596532-16-000331:note_history:12]
On February 2, 2016, the ALJ issued his initial determination finding a violation of section 337 of the Tariff Act. More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringe asserted claims 1, 2, 8-11, and 17-19 of the ’537 patent; asserted claims 6, 7, 20, and 21 of the ’592 patent; and asserted claims 5, 7, 45, and 46 of the ’145 patent.  The ALJ did not find a violation of section 337 with respect to any asserted claims of the ’597 and ’164 patents.  On April 11, 2016, the Commission decided to review certain findings contained in the initial determination.  On June 23, 2016, the Commission issued its Final Determination, which found a violation with respect to the ’537, ’592, and ’145 patents, and found no violation with respect to the ’597 and ’164 patents.  The Commission also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 2, 8-11, and 17-19 of the ’537 patent; claims 6, 7, 20, and 21 of the ’592 patent; and claims 5, 7, 45, and 46 of the ’145 patent.  On August 22, 2016, the Presidential review period for the 944 investigation expired.  The USITC orders are currently in effect.

- added (2017-05-08):
[0001596532-17-000088:note_history:13]
Both we and Cisco filed petitions for review of the USITC’s Final Determination to the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”).  The appeal is fully briefed and oral argument has not been scheduled.

- changed (2017-05-08):
[0001596532-17-000088:note_history:14]
On August 26, 2016, Cisco filed an enforcement complaint under Section 337 with the USITC.  Cisco alleges that we are violating the cease and desist and limited exclusion orders issued in the 944 Investigation by engaging in the “marketing, distribution, offering for sale, selling, advertising, and/or aiding or abetting other entities in the sale and/or distribution of products that Cisco alleges continue to infringe claims 1-2, 8-11, and 17-19 of the ’537 patent,” despite the design changes we have made to those products.  Cisco asks the USITC to (1) enforce the cease and desist order; (2) modify the Commission’s limited exclusion order and/or cease and desist order “in any manner that would assist in the prevention of the unfair practices that were originally the basis for issuing such Order or assist in the detection of violations of such Order”; (3) impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000 or twice the domestic value of the articles entered or sold, whichever is higher”; (4) bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order”; and (5) impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.”  On September 28, 2016, the Commission instituted the enforcement proceeding.  The proceeding has been assigned to ALJ Judge Shaw, who presided over the underlying investigation.  On October 14, 2016, we responded to the complaint by, among other things, denying the patent infringement allegations and raising affirmative defenses.  On November 2, 2016, the ALJ issued an order setting the deadline for the initial determination for June 20, 2017 and the Target Date for September 20, 2017.  On April 4 and 5, 2017, the ALJ held the evidentiary hearing in this proceeding.
  (was, 2016-11-03, similarity 0.9146):
[0001596532-16-000331:note_history:14]
On August 26, 2016, Cisco filed an enforcement complaint under Section 337 of the Tariff Act of 1930, as amended, with the USITC.  Cisco alleges that we are violating the cease and desist order issued in the 944 Investigation by engaging in the “marketing, distribution, offering for sale, selling, advertising, and/or aiding or abetting other entities in the sale and/or distribution of products that Cisco alleges continue to infringe claims 1-2, 8-11, and 17-19 of the ’537 patent”, despite the design changes we have made to those products.  Cisco asks the USTIC to (1) enforce the cease and desist order; (2) modify the Commission’s limited exclusion order and/or cease and desist order “in any manner that would assist in the prevention of the unfair practices that were originally the basis for issuing such Order or assist in the detection of violations of such Order”; (3) impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000.00 or twice the domestic value of the articles entered or sold, whichever is higher”; (4) bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order”; and (5) impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.”  On September 28, 2016, the Commission instituted the enforcement proceeding.  The proceeding has been assigned to Administrative Law Judge Shaw, who presided over the underlying investigation.  On October 14, 2016, we responded to the complaint by, among other things, denying the patent infringement allegations and raising numerous affirmative defenses.

- added (2017-05-08):
[0001596532-17-000088:note_history:15]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated Section 337.  The USITC instituted Cisco’s complaint as Investigation No. 337-TA-945.  Cisco alleges that certain of our switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents.  Cisco seeks, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) related software, and components thereof and a cease and desist order against us restricting our activities with respect to our imported accused switch products, related software, and components thereof.

- added (2017-05-08):
[0001596532-17-000088:note_history:16]
On December 9, 2016, the ALJ issued her initial determination finding a violation of Section 337. More specifically, the ALJ found that a violation has occurred in the importation into the United States, the sale for importation, or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringe asserted claims 1, 7, 9, 10, and 15 of the ’577 patent; and asserted claims 1, 2, 4, 5, 7, 8, 10, 13, 19, 56, and 64 of the ’668 patent.  The ALJ did not find a violation of Section 337 with respect to asserted claim 2 of the ’577 patent or any asserted claims of the ’853, ’492, ’875, and ’211 patents.  On December 29, 2016, Arista, Cisco and the Office of Unfair Importation Investigation ("OUII") filed petitions for review of certain findings contained in the initial determination.  On March 1, 2017, the Commission issued a notice that it was reviewing the final initial determination in part on certain issues.

- added (2017-05-08):
[0001596532-17-000088:note_history:17]
On May 4, 2017, the Commission issued its Final Determination, which found a violation with respect to the ’577 and ’668 patents, and found no violation with respect to the ’211, ’853, ’875 and ’492 patents.  The Commission also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software and components thereof that infringe one or more of claims 1, 7, 9, 10, and 15 of the ’577 patent and 1, 2, 4, 5, 7, 8, 10, 13, 18, 56, and 64 of the ’668 patent. The Commission’s final determination is subject to a 60-day Presidential review period, during which the United States Trade Representative will decide whether to disapprove the decision. During the Presidential review period, we must pay a 5% bond on any imports of any products and components subject to the order, and on any sales of previously imported products and components subject to the order.

- added (2017-05-08):
[0001596532-17-000088:note_history:18]
We have filed petitions for Inter Partes Review of the ’597, ’211, ’668, ’853, ’537, ’577, ’886, and ’526 patents.  IPRs relating to the ’597 (IPR No. 2015-00978) and ’211 (IPR No. 2015-00975) patents were instituted in October 2015 and hearings on these IPRs were completed in July 2016.  On September 28, 2016, the PTAB issued a final written decision finding claims 1, 14, 39-42, 71, 72, 84, and 85 of the ’597 patent unpatentable.  The PTAB also found that claims 29, 63, 64, 73, and 86 of the ’597 patent had not been shown to be unpatentable.  On October 5, 2016, the PTAB issued a final written decision finding claims 1 and 12 of the ’211 patent unpatentable.  The PTAB also found that claims 2, 6-9, 13, 17-20 of the ’211 patent had not been shown to be unpatentable.  Both parties have appealed the final written decisions on the ’211 and ’537 patents IPRs.

- added (2017-05-08):
[0001596532-17-000088:note_history:19]
The IPR relating to the ’886 patent was instituted on May 25, 2016.  Following that decision, Cisco agreed to dismiss its claims as to the ʼ886 patent with prejudice, and we dismissed our counterclaims as to the ʼ886 patent without prejudice.

- changed (2017-05-08):
[0001596532-17-000088:note_history:20]
IPRs relating to the ’668 (IPR No. 2016-00309), ’577 (IPR No. 2016-00303), ’853 (IPR No. 2016-0306), and ’537 (IPR No. 2016-0308) patents were instituted in June 2016 and hearings were held on March 7, 2017.  Final Written Decisions on these IPRs are expected to be issued by June 2017.
  (was, 2016-11-03, similarity 0.6953):
[0001596532-16-000331:note_history:20]
IPRs relating to the ‘668 (IPR No. 2016-00309), ‘577 (IPR No. 2016-00303), ‘853 (IPR No. 2016-0306), and ‘537 (IPR No. 2016-0308) patents were instituted in June 2016 and are set for hearing in March 2017.  Final Written Decisions on these IPRs will be issued by June 2017.

- added (2017-05-08):
[0001596532-17-000088:note_history:21]
*  *  *  *  *

- added (2017-05-08):
[0001596532-17-000088:note_history:22]
We intend to vigorously defend against each of the Cisco’s lawsuits, as summarized in the preceding paragraphs.  However, we cannot be certain that any claims by Cisco would be resolved in our favor regardless of the merit of the claims.  Any adverse litigation ruling could result in the above described injunctive relief, could require a significant damages award against us or a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products.

- changed (2017-05-08):
[0001596532-17-000088:note_history:23]
For example, in the 944 Investigation, the USITC has issued a limited exclusion order barring entry into the United States of our network devices (including our 7000 Series of switches), related software, and components thereof that infringe one or more of the claims of the ʼ537, ʼ592, and ʼ145 patents specified above and a cease and desist order restricting our activities with respect to such imported products.  In addition, in the 945 Investigation, the Commission has issued its Final Determination, finding a violation of section 337 of the Tariff Act with respect to the ʼ668 and ʼ577 patents.
  (was, 2016-11-03, similarity 0.7935):
[0001596532-16-000331:note_history:23]
In particular, in the 944 Investigation, the USITC has issued a limited exclusion order barring entry into the United States of our network devices (including our 7000 Series of switches), related software and components thereof that infringe one or more of the claims of the ʼ537, ʼ592, and ʼ145 patents specified above and a cease and desist order restricting our activities with respect to such imported products.

- added (2017-05-08):
[0001596532-17-000088:note_history:24]
To comply with these orders, we have sought to develop technical design-arounds that no longer infringe the patents that are the subject of the orders.  In any efforts to develop technical design-arounds for our products, we may be unable to do so in a manner that does not continue to infringe the patents or that is acceptable to our customers.  Our redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.  Moreover, in the 944 Investigation and 945 Investigation, such design-arounds would require us to obtain approval of either the USITC or U.S. Customs and Border Protection (“CBP”) to resume the importation of the redesigned products into the United States.  We may not be successful in our efforts to obtain such approvals to import such modified products in a timely manner, or at all.  While a favorable ruling from the CBP would allow us to resume importation of our redesigned products into the United States, the USITC could still determine in an enforcement action that our redesigned products continue to infringe the patents that are the subject of any USITC orders.  Any failure to effectively redesign our products, to obtain timely clearance from USITC or CBP to import such redesigned products, or to address the USITC findings in a manner that complies with the USITC orders, may cause a disruption to our product shipments and materially and adversely affect our business, prospects, reputation, results of operations, and financial condition.

- added (2017-05-08):
[0001596532-17-000088:note_history:25]
Specifically, in response to the USITC’s findings in the 944 Investigation, we have made design changes to our products for sale in the United States to address the features that were found to infringe the ’537, ’592, and ’145 patents.  Following the issuance of the final determination in the 944 Investigation, we submitted a Section 177 ruling request to CBP seeking approval to import these redesigned products into the United States.  On November 18, 2016, we received a 177 ruling from CBP finding that our redesigned products did not infringe the relevant claims of the ʼ537, ’592, and ʼ145 patents, and approving the importation of these redesigned products into the United States.  However, on January 13, 2017, at the request of Cisco and without our input, CBP issued a letter to us revoking its prior November 18 ruling.  CBP subsequently conducted an inter partes proceeding between Arista and Cisco to determine whether our redesigned products infringe and whether to approve them for importation into the United States. On April 7, 2017, following the inter partes proceeding, CBP again ruled that our design around products do not infringe the relevant claims of the ’537, ’592, and ’145 patents and again approved those design arounds for importation into the United States.

- added (2017-05-08):
[0001596532-17-000088:note_history:26]
Similarly, on May 4, 2017, the USITC issued a limited exclusion order and cease and desist order in the 945 Investigation with respect to the ‘668 and ‘577 patents.  If such orders are not disapproved by the United States Trade Representative, we would need to further modify our products to take our products outside the scope of the ‘668 and ‘577 patents and obtain the USITC and/or CBP approvals described above to resume importation of our redesigned products into the United States.  For example, we submitted a technical design-around for the ‘668 patent into the 945 Investigation. However, in the Final Determination, the Commission found that this design around continues to infringe the patent. This will require us to implement an alternative redesign for our products to make them non-infringing.  We may not be able to do so in a manner that does not continue to infringe the patent or that is acceptable to customers. We may not be able to complete, and our customers may not be able to qualify, such redesigned products in a timely fashion, if at all, following the end of the Presidential review period, leading to an inability to ship products to customers. Our redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management. In addition, during the Presidential review period, we must pay a 5% bond on imports of any products and components subject to the order, and on any sales of previously imported products and components subject to the order.

- changed (2017-05-08):
[0001596532-17-000088:note_history:27]
If the USITC determines that our redesigned products continue to infringe the patents subject to any USITC limited exclusion order or cease and desist order in an enforcement action for either the 944 Investigation or the 945 Investigation, the USITC may impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000 or twice the domestic value of the articles entered or sold, whichever is higher,” bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order,” or impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.”
  (was, 2016-11-03, similarity 0.7816):
[0001596532-16-000331:note_history:27]
For example, if the USITC determines that our redesigned products continue to infringe the ‘537, ‘592 or ‘145 patents, the USITC may impose the maximum statutory civil penalties for violation of the cease and desist order “including monetary sanctions for each day’s violation of the cease and desist order of the greater of $100,000.00 or twice the domestic value of the articles entered or sold, whichever is higher,” bring a civil action in U.S. district court “requesting collection of such civil penalties and the issuance of a mandatory injunction preventing further violation of Cease and Desist Order” or impose “such other remedies and sanctions as are appropriate and within the Commission’s authority.”

- added (2017-05-08):
[0001596532-17-000088:note_history:28]
An adverse finding in an enforcement action would take effect immediately upon USITC’s issuance of the final determination, without any Presidential review period.  To address such a finding, we would have to further redesign our products to make them non-infringing, and until we made such changes we would not be able to import or ship our products to customers.  We may not be able to do so in a manner that does not continue to infringe the patents or that is acceptable to customers.  We may not be able to complete, and our customers may not be able to qualify, such redesigned products in a timely fashion, if at all, following the issuance of an adverse final determination, leading to an inability to ship products to customers.  Our redesign efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.  We would also need to obtain USITC or CBP approval to resume importation of such redesigned products into the United States.  In addition, the USITC would not provide a service and support exception for our previously redesigned products, and customers may be required to upgrade to new products to obtain service and support.

- added (2017-05-08):
[0001596532-17-000088:note_history:29]
To comply with the USITC’s remedial orders, we have also made certain changes to our manufacturing, importation and shipping workflows. These changes have included shifting manufacturing and integration of our products to be sold in the United States to U.S. facilities. Such changes may be extremely costly, time consuming, and we may not be able to implement such changes successfully.  Any failure to successfully change our manufacturing and importation processes or shipping workflows in a manner that is compliant with the limited exclusion order and cease and desist order may cause a disruption in our product shipments and materially and adversely affect our business, prospects, reputation, results of operations, and financial condition.

- added (2017-05-08):
[0001596532-17-000088:note_history:30]
In connection with these changes, to the extent that we are required to make further modifications to our supply chain to obtain alternative U.S. sources for subcomponents, we may be unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, if at all, which could delay or halt entirely production of our products or require us to make further modifications to our products to incorporate new components that are available in the United States. Any of these events could result in lost sales, reduced gross margins or damage to our end-customer relationships, which would materially and adversely impact our business, financial condition, results of operations and prospects.

- added (2017-05-08):
[0001596532-17-000088:note_history:31]
Additionally, the existence of Ciscoʼs lawsuits against us could cause concern among our customers and partners and could adversely affect our business and results of operations.  Many of our customers and partners require us to indemnify and defend them against third party infringement claims and pay damages in the case of adverse rulings. These claims could harm our relationships with our customers or channel partners, cause them to delay or defer purchasing decisions or deter them from doing business with us. From time to time, we may also be required to provide additional assurances beyond our standard terms.  Whether or not we prevail in the lawsuit, we expect that the litigation will be expensive, time-consuming and a distraction to management in operating our business.

- added (2017-05-08):
[0001596532-17-000088:note_history:32]
In the Matter of Certain Semiconductor Devices, Semiconductor Device Packages, and Products Containing Same (337-TA-1010)

- added (2017-05-08):
[0001596532-17-000088:note_history:33]
On May 23, 2016, Tessera Technologies, Inc., Tessera, Inc., and Invensas Corp. (“Tessera”) filed a complaint in the USITC alleging that Broadcom Limited, Broadcom Corporation, Avago Technologies Limited, and Avago Technologies U.S. Inc. (“Broadcom”) violated 19 U.S.C. § 1337 (“Section 337”).  On June 10, 2016, the USITC instituted Tessera’s complaint as Investigation No. 337-TA-1010 on June 20, 2016.

- added (2017-05-08):
[0001596532-17-000088:note_history:34]
Tessera alleges that certain Broadcom semiconductor devices infringe U.S. Patent No. 6,856,007; U.S. Patent No. 6,849,946; and U.S. Patent No. 6,133,136.  Tessera further alleged that Broadcom's downstream customers, Arista Networks, Inc.; ARRIS International plc; ARRIS Group, Inc.; ARRIS Technology, Inc.; ARRIS Enterprises LLC; ARRIS Solutions, Inc.; Pace Ltd.; Pace Americas, LLC; Pace USA; LLC, ASUSteK Computer Inc.; ASUS Computer International; Comcast Cable Communications, LLC; Comcast Cable Communications Management, LLC; Comcast Business Communications, LLC; HTC Corporation; HTC America, Inc.; NETGEAR, Inc.; Technicolor S.A.; Technicolor USA, Inc.; and Technicolor Connected Home USA LLC (“Downstream Respondents”), were violating Section 337 by importing, selling after importation, or selling for importation products that incorporate the accused Broadcom semiconductor devices.  The accused Company products include certain models of our switching products.

- added (2017-05-08):
[0001596532-17-000088:note_history:35]
Tessera seeks the following relief: (1) a permanent limited exclusion order excluding from importation into the U.S. all of Tessera’s semiconductor devices and semiconductor device packages and Downstream Respondents’ products containing Broadcom’s semiconductor devices that infringe one or more of the three patents-in-suit and (2) a permanent cease and desist order prohibiting Broadcom and Downstream Respondents and related companies from importing, marketing, advertising, demonstrating, warehousing inventory for distribution, offering for sale, selling, qualifying for use in the products of others, distributing, or using the accused Broadcom semiconductor devices Downstream Respondents’ products containing Respondents’ semiconductor devices and semiconductor device packages that infringe one or more of the three patents subject to the ITC Investigation.

- added (2017-05-08):
[0001596532-17-000088:note_history:36]
The evidentiary hearing was held on March 27 through March 31, 2017, and the target date for completion of the Investigation is October 24, 2017.

- added (2017-05-08):
[0001596532-17-000088:note_history:37]
To the extent claims made by Tessera in the ITC Investigation against Arista are based solely on functionality residing in Broadcom’s products, Broadcom has agreed to defend Arista at no cost to Arista.

- added (2017-05-08):
[0001596532-17-000088:note_history:38]
Plectrum, Inc. v. Arista Networks, Inc. (Case No. 4:17-cv-76)

- added (2017-05-08):
[0001596532-17-000088:note_history:39]
On February 2, 2017, Plectrum LLC (“Plectrum”) filed a complaint against Arista Networks, Inc. in the U.S. District Court for the Eastern District of Texas alleging infringement of the U.S. Patent Nos. 6,205,149 (“the ‘149 Patent”), 5,978,951 (“the ‘951 Patent”), and 6,751,677 (“the ‘677 Patent”) based upon our manufacture, use, by sale and/or offer for sale of our 7150 series and 7500 series switches.  Plectrum seeks a permanent injunction or ongoing royalty, unspecified damages and costs, pre-judgement and post-judgement interest on the damages, and attorneys’ fees.  In addition to Arista, Plectrum has also sued some of our competitors, customers, and suppliers.  Plectrum has filed lawsuits against sixteen (16) parties in total related to this effort.  We believe that the claims are without merit and intend to defend ourselves vigorously against the claims.

- added (2017-05-08):
[0001596532-17-000088:note_history:40]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.  We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated.   As of March 31, 2017, provisions recorded for contingent losses related to other claims and matters have not been significant.  Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows.  However, litigation is subject to inherent uncertainties and our view of these matters may change in the future.  Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.

- removed (2017-05-08):
[0001596532-16-000331:note_history:41]
We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.  Rent expense for all operating leases amounted to $2.3 million, $2.0 million, $7.0 million, and $4.7 million for the three and nine months ended September 30, 2016 and 2015, respectively.

- removed (2017-05-08):
[0001596532-16-000331:note_history:42]
On February 13, 2015, we answered the complaint in the ’44 Case, denying the patent and copyright infringement allegations and raising numerous affirmative defenses.  On March 6, 2015, Cisco filed an amended complaint against us in the ’44 Case.  In response, we moved to dismiss Cisco’s allegations of willful patent infringement and pre-suit indirect patent infringement.  The Court granted the motion with leave to amend on July 2, 2015.  On July 23, 2015, Cisco filed an amended complaint. On May 25, 2016, the Patent and Trademark Appeals Board ("PTAB") issued an order initiating inter partes review of U.S. Patent No. 7,953,886 (“the ʼ886 patent).  Following that order Cisco agreed to dismiss its claims as to the ʼ886 patent with prejudice, and we dismissed our counterclaims as to the ʼ886 patent without prejudice.

- removed (2017-05-08):
[0001596532-16-000331:note_history:43]
Summary judgment cross-motions in the ’44 Case were heard on August 4, 2016, and the Court denied all motions brought by both sides.  A final pre-trial conference is set for November 3, 2016 and trial has been set for November 21, 2016.

- removed (2017-05-08):
[0001596532-16-000331:note_history:44]
On February 24, 2016, we filed a complaint against Cisco in the District Court for the Northern District of California alleging antitrust violations and unfair competition.  On April 13, 2016, Cisco filed a motion to stay the ’23 Case, or in the alternative, to dismiss the complaint.  On August 23, 2016, the Court granted Cisco’s motion to stay until judgment has been entered on Cisco’s copyright claims in the ’44 Case, which the Court anticipated by December 22, 2016.  Trial in the ’23 Case is set for August 3, 2018, and is not affected by the Court’s granting of the interim stay.

- removed (2017-05-08):
[0001596532-16-000331:note_history:45]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we have violated Section 337 of the Tariff Act of 1930, as amended.  The USITC instituted Cisco's complaint as Investigation No. 337-TA-944. Cisco initially alleged that certain of our switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.  Cisco subsequently dropped the ’296 patent from the 944 Investigation.  Cisco sought, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) and components and software therein and a cease and desist order against us restricting our activities with respect to our imported accused switch products and components and software therein.  On February 11, 2015, we responded to the complaint in the 944 Investigation by, among other things, denying the patent infringement allegations and raising numerous affirmative defenses.

- removed (2017-05-08):
[0001596532-16-000331:note_history:46]
The Administrative Law Judge ("ALJ") assigned to the 944 Investigation issued a procedural schedule calling for, among other events: an evidentiary hearing on September 9-11 and 15-17, 2015; issuance of an initial determination regarding our alleged violations on January 27, 2016; and a Target Date for completion of the investigation on May 27, 2016.  On January 27, 2016, the ALJ issued a revised procedural schedule extending the date for issuance of an initial determination to February 2, 2016 and extending the Target Date to June 2, 2016.

- removed (2017-05-08):
[0001596532-16-000331:note_history:47]
Both we and Cisco filed petitions for review of the USITCs Final Determination to the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”).  On August 26, 2016, the Federal Circuit consolidated the appeals and, on September 23, 2016, it issued an order setting an expedited briefing schedule.  Under this schedule, we filed our opening brief on September 23, 2016; Cisco’s opening brief is due November 2, 2016; the USITC’s brief is due on December 2, 2016; our response/reply brief is due December 19, 2016; and Cisco’s reply brief is due January 2, 2017.

- removed (2017-05-08):
[0001596532-16-000331:note_history:48]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated Section 337 of the Tariff Act of 1930, as amended.  The USITC instituted Cisco’s complaint as Investigation No. 337-TA-945.  Cisco alleges that certain of our switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents.  Cisco seeks, among other things, a limited exclusion order barring entry into the United States of accused switch products (including our 7000 Series of switches) and components and software therein and a cease and desist order against us restricting our activities with respect to our imported accused switch products and components and software therein.  On February 11, 2015, we responded to the notice of investigation and complaint in the 945 Investigation by, among other things, denying the patent infringement allegations and raising numerous affirmative defenses.

- removed (2017-05-08):
[0001596532-16-000331:note_history:49]
The ALJ issued a procedural schedule calling for, among other events: an evidentiary hearing on November 9-20, 2015; issuance of an initial determination regarding our alleged violations on April 26, 2016; and a Target Date for completion on August 26, 2016.  On March 29, 2016, the ALJ issued a revised procedural schedule extending the deadline for issuance of an initial determination to August 26, 2016, and extending the Target Date to December 26, 2016.  On April 19, 2016, the Commission determined not to review this decision.  On August 24, 2016, the ALJ issued a revised procedural schedule extending the deadline for issuance of an initial determination to November 7, 2016, and extending the Target Date to March 7, 2016.  On September 7, 2016, the Commission determined not to review this decision.  The Initial Determination will be subject to review by the Commission, which will then issue a Final Determination and any remedial orders by March 7, 2017.  If the Final Determination finds a violation, it will be subject to Presidential review.

- removed (2017-05-08):
[0001596532-16-000331:note_history:50]
We have filed petitions for Inter Partes Review (“IPR”) of the ‘597, ‘211, ‘668, ‘853, ‘537, ‘577, ‘886, and ‘526 patents.  IPRs relating to the ‘597 (IPR No. 2015-00978) and ‘211 (IPR No. 2015-00975) patents were instituted in October 2015 and hearings on these IPRs were completed in July 2016.  On September 28, 2016, the PTAB issued a final written decision finding claims 1, 14, 39-42, 71, 72, 84, and 85 of the ’597 patent unpatentable.  The PTAB also found that claims 29, 63, 64, 73, and 86 of the ’597 patent had not been shown to be unpatentable.  We filed a notice of appeal with respect to this decision regarding claims 29, 63, 64, 73, and 86 on October 11, 2016, and Cisco requested rehearing of the PTAB’s Final Written Decision on October 28, 2016.  On October 5, 2016, the PTAB issued a final written decision finding claims 1 and 12 of the ’211 patent unpatentable.  The PTAB also found that claims 2, 6-9, 13, 17-20 of the ’211 patent had not been shown to be unpatentable.

- removed (2017-05-08):
[0001596532-16-000331:note_history:51]
We intend to vigorously defend against Cisco’s lawsuits, as summarized in the preceding paragraphs.  However, we cannot be certain that any claims by Cisco would be resolved in our favor regardless of the merit of the claims.  For example, an adverse litigation ruling could result in a significant damages award against us, could further result in the above described injunctive relief, could result in a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products to the extent that we are found to infringe any valid claims asserted against us by Cisco.  Any such adverse ruling could materially adversely affect our business, prospects, reputation, results of operation and financial condition.

- removed (2017-05-08):
[0001596532-16-000331:note_history:52]
In response to the USITC’s findings in the 944 Investigation, we have made design changes to our products for sale in the United States to address the features that were found to infringe the ‘537, ’592, ’145 patents.  Following the issuance of the final determination in the 944 Investigation, we submitted a Section 177 ruling request to U.S. Customs and Border Protection (“CBP”) seeking approval to import these redesigned products into the United States, and we are awaiting CBP’s decision.  If the USITC finds that we infringe any patent in the 945 Investigation, the USITC is likely to issue remedial orders in that investigation as well.  If such orders are not disapproved by the United States Trade Representative, we would need to further modify our products to take our products outside the scope of any patents we are found to have infringed in the 945 Investigation.  We may not be successful in developing technical design-arounds that do not infringe the patents or that are acceptable to our customers.  Our development efforts could be extremely costly and time consuming as well as disruptive to our other development activities and distracting to management.  We may not be successful in our efforts to obtain clearance from CBP to import such modified products in a timely manner, or at all.  While clearance from CBP will allow us to resume importation of our redesigned products into the United States, the USITC could still determine in the enforcement action that our redesigned products continue to infringe the ‘537, ‘592 or ‘145 patents.  Any failure to effectively redesign our products to obtain timely clearance from CBP to import such redesigned products, or to address the USITC’s findings in a manner that is compliant with the limited exclusion order and cease and desist order may cause a disruption in our product shipments and materially and adversely affect our business, prospects, reputation, results of operations, and financial condition.

- removed (2017-05-08):
[0001596532-16-000331:note_history:53]
We have also made certain changes to our manufacturing, importation and shipping workflows to comply with the USITC’s remedial orders. These changes have included shifting manufacturing and integration of our products to be sold in the United States to U.S. facilities. Such changes may be extremely costly, time consuming, and we may not be able to implement such changes successfully.  Any failure to successfully change our manufacturing and importation processes or shipping workflows in a manner that is compliant with the limited exclusion order and cease and desist order may cause a disruption in our product shipments and materially and adversely affect our business, prospects, reputation, results of operations, and financial condition.

- removed (2017-05-08):
[0001596532-16-000331:note_history:54]
Additionally, the existence of Cisco's lawsuits against us could cause concern among our customers and partners and could adversely affect our business and results of operations.  Whether or not we prevail in the lawsuit, we expect that the litigation will be expensive, time-consuming and a distraction to management in operating our business.

- removed (2017-05-08):
[0001596532-16-000331:note_history:55]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.  We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated.  Based on currently available information, management does not believe that liability relating to these other unresolved matters is probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows.  However, litigation is subject to inherent uncertainties and our view of these matters may change in the future.  Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-08):
[0001596532-17-000088:note_history:56]
Organization and Summary of Significant Accounting Policies
  (was, 2016-11-03, similarity 0.6889):
[0001596532-16-000331:note_history:56]
Significant Accounting Policies

- changed (2017-05-08):
[0001596532-17-000088:note_history:57]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our” or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System (“EOS”), a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switching and routing platforms. We were incorporated in October 2004 in the State of California under the name Arastra, Inc. In March 2008, we reincorporated in the State of Nevada and in October 2008 changed our name to Arista Networks, Inc. We reincorporated in the state of Delaware in March 2014. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.
  (was, 2016-11-03, similarity 0.8678):
[0001596532-16-000331:note_history:57]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our” or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprises. Our cloud networking solutions consist of our Extensible Operating System, a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switches. We were incorporated in October 2004 and reincorporated in the state of Delaware in March 2014. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

- added (2017-05-08):
[0001596532-17-000088:note_history:58]
Basis of Presentation and Principles of Consolidation

- changed (2017-05-08):
[0001596532-17-000088:note_history:59]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles ("GAAP") and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2017, are not necessarily indicative of the results expected for the full fiscal year.  The condensed consolidated balance sheet as of December 31, 2016 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements.  Our unaudited condensed consolidated financial statements ("consolidated financial statements") include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and are prepared in accordance with GAAP.  All significant intercompany accounts and transactions have been eliminated.
  (was, 2016-11-03, similarity 0.6991):
[0001596532-16-000331:note_history:59]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP" or "GAAP") and following the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by U.S. GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2016, are not necessarily indicative of the results expected for the full fiscal year.

- changed (2017-05-08):
[0001596532-17-000088:note_history:60]
Our consolidated financial statements and related financial information should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2016, filed with the SEC on February 17, 2017.
  (was, 2016-11-03, similarity 0.9364):
[0001596532-16-000331:note_history:60]
The accompanying unaudited condensed consolidated financial statements and related financial information should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2015, filed with the SEC on February 25, 2016.

- changed (2017-05-08):
[0001596532-17-000088:note_history:61]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts and sales return reserve; determination of fair value for stock-based awards; accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; valuation of inventory; valuation of warranty accruals; contract manufacturing liabilities; and recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.
  (was, 2016-11-03, similarity 0.6289):
[0001596532-16-000331:note_history:61]
The preparation of the accompanying unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the unaudited condensed consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts and sales return reserve; determination of fair value for stock-based awards; accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; valuation of inventory; valuation of warranty accruals; and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions on an ongoing basis using historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. As future events and their effects cannot be determined with precision, actual results could differ from these estimates, and those differences could be material to the unaudited condensed consolidated financial statements.

- added (2017-05-08):
[0001596532-17-000088:note_history:62]
Recently Adopted Accounting Pronouncements

- added (2017-05-08):
[0001596532-17-000088:note_history:63]
In March 2016, the Financial Accounting Standards Board (the “FASB”) amended the existing accounting standard for stock-based compensation, issuing Accounting Standards Update (“ASU”) 2016-09, Compensation-Stock Compensation: Improvements to Employee Share-Based Payment Accounting, which impacts several aspects of accounting for share-based payment transactions, including the income tax consequences, forfeitures, classification of awards as either equity or liabilities, and classification on the statement of cash flows. We adopted this standard during our first fiscal quarter of 2017. The impact of the adoption was as follows:

- added (2017-05-08):
[0001596532-17-000088:note_history:64]
| • | Income tax accounting - The standard eliminates additional paid-in-capital (“APIC”) pools and requires excess tax benefits and tax deficiencies on share-based awards to be recognized in the income statement prospectively as discrete items upon exercise or vesting of such awards. The standard also requires excess tax benefits to be recognized regardless of whether the benefit reduces taxes payable. We adopted the guidance related to the timing of previously unrecognized excess tax benefits on a modified retrospective basis, which resulted in the recognition of a cumulative effect adjustment of $1.8 million that increased retained earnings and increased our long-term deferred income tax as of January 1, 2017. |

- added (2017-05-08):
[0001596532-17-000088:note_history:65]
| • | Earnings per share - Because excess benefits are no longer recognized in APIC, the assumed proceeds from applying the treasury stock method when calculating dilutive shares was amended to exclude the amount of excess tax benefits that would be recognized upon exercise or vesting of such awards. As a result, this reduces the assumed shares to be repurchased under the treasury stock method, thereby increasing the amount of dilutive shares used to compute earnings per share. We adopted the guidance related to the exclusion of excess tax benefits in calculating earnings per share on a prospective basis. |

- added (2017-05-08):
[0001596532-17-000088:note_history:66]
| • | Forfeitures of stock options and awards - Under the new standard, we can make an accounting policy election to either estimate the number of share-based awards that are expected to vest, or account for forfeitures when they occur. We elected to account for forfeitures when they occur and adopted this change on a modified retrospective basis. As a result, we recorded the cumulative effect of the change as a $1.0 million decrease to retained earnings as of January 1, 2017. |

- added (2017-05-08):
[0001596532-17-000088:note_history:67]
| • | Cash flow presentation of excess tax benefits - Prior to the new standard, we were required to present excess tax benefits on share-based awards as a cash inflow from financing activities with a corresponding cash outflow from operating activities. The new standard required that these excess tax benefits be classified with other income tax cash flows as an operating activity. We elected to adopt the guidance related to the presentation of excess tax benefits in our condensed consolidated statements of cash flows on a retrospective basis, which increased net cash provided by operating activities by $6.0 million for the three months ended March 31, 2016, with a corresponding decrease to net cash provided by financing activities. |

- added (2017-05-08):
[0001596532-17-000088:note_history:68]
In April 2015, the FASB issued ASU 2015-05, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement, providing guidance on fees paid in a cloud computing arrangement.  If a cloud computing arrangement includes a software license, the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If the arrangement does not include a software license, the customer should account for the arrangement as a service contract. We adopted this standard in our first quarter of fiscal 2017 on a prospective basis, and the adoption did not have a material impact on our consolidated financial statements.

- added (2017-05-08):
[0001596532-17-000088:note_history:69]
In July 2015, the FASB issued ASU No, 2015-11, Inventory: Simplifying the Measurement of Inventory, which simplifies the measurement of inventory to be measured at the lower of cost or net realizable value.  The guidance is effective for fiscal years beginning after December 15, 2016, including interim periods within those fiscal years. We adopted this standard in our first quarter of fiscal 2017 on a prospective basis. We adopted this standard in our first quarter of fiscal 2017 on a prospective basis, and the adoption did not have a material impact on our consolidated financial statements.

- changed (2017-05-08):
[0001596532-17-000088:note_history:70]
The above standards are effective for fiscal years (and interim reporting periods within those years) beginning after December 15, 2017.  The guidance is effective for us beginning in our first quarter of fiscal 2018. Early adoption would be permitted for all entities but not until the fiscal year beginning after December 15, 2016. The standard permits the use of either the retrospective or cumulative effect transition method. The retrospective method requires a retrospective approach to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance. The cumulative approach requires a retrospective approach with the cumulative effect of initially applying the guidance recognized at the date of initial application and providing certain additional disclosures as defined per the guidance.
  (was, 2016-11-03, similarity 0.7676):
[0001596532-16-000331:note_history:70]
The above standards are effective for fiscal years (and interim reporting periods within those years) beginning after December 15, 2017.  The guidance is effective for us beginning in our first quarter of fiscal 2018. Early adoption would be permitted for all entities but not until the fiscal year beginning after December 15, 2016. The standard permits the use of either the retrospective or cumulative effect transition method. The retrospective method requires a retrospective approach to each prior reporting period presented with the option to elect certain practical expedients as defined within the guidance. The cumulative approach requires a retrospective approach with the cumulative effect of initially applying the guidance recognized at the date. of initial application and providing certain additional disclosures as defined per the guidance. We plan to adopt the standards our first quarter of fiscal 2018. We are currently reviewing the provisions of the standard and have not yet selected a transition method nor have we determined the effect of the standard on our consolidated financial statements.

- added (2017-05-08):
[0001596532-17-000088:note_history:71]
Management’s assessments of potential impacts of the standards are underway. The standards are expected to impact the amount and timing of revenue recognized and the related disclosures on our consolidated financial statements.  We will adopt ASU 2014-09 during the first quarter of 2018 and expect to adopt the guidance under the modified retrospective method which we anticipate will result in a cumulative effect adjustments as of the date of adoption.

- added (2017-05-08):
[0001596532-17-000088:note_history:72]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. Credit losses relating to available-for-sale debt securities should be recorded through an allowance for credit losses. This standard is effective for us for our first quarter of 2020.  We are currently assessing the impact this guidance may have on our consolidated financial statements.

- added (2017-05-08):
[0001596532-17-000088:note_history:73]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force which requires that amounts generally described as restricted cash or restricted cash equivalents be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. This standard is effective for us for our first quarter of fiscal 2018, and may be early adopted. We do not anticipate this standard will have a material impact on our consolidated financial statements.

- removed (2017-05-08):
[0001596532-16-000331:note_history:74]
Overview and Basis of Presentation

- removed (2017-05-08):
[0001596532-16-000331:note_history:75]
Organization

- removed (2017-05-08):
[0001596532-16-000331:note_history:76]
Basis of Presentation

- removed (2017-05-08):
[0001596532-16-000331:note_history:77]
The condensed consolidated balance sheet as of December 31, 2015 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by generally accepted accounting principles for complete financial statements.

- removed (2017-05-08):
[0001596532-16-000331:note_history:78]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and are prepared in accordance with GAAP. All significant intercompany accounts and transactions have been eliminated.

- removed (2017-05-08):
[0001596532-16-000331:note_history:79]
There have been no material changes to our significant accounting policies as of and for the nine months ended September 30, 2016, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended December 31, 2015.

- removed (2017-05-08):
[0001596532-16-000331:note_history:80]
In March 2016, the FASB amended the existing accounting standards for stock-based compensation, ASU 2016-09, Compensation-Stock Compensation: Improvements to Employee Share-Based Payment Accounting, which impact several aspects of accounting for share-based payment transactions, including the income tax consequences, forfeitures, classification of awards as either equity or liabilities, and classification on the statement of cash flows. The standard is effective for us for our first quarter of fiscal 2017.  The guidance may be early adopted under early application guidance. If early adoption is elected, all amendments must be adopted in the same period. The manner of application varies by the various provisions of the guidance, with certain provisions applied on a retrospective or modified retrospective approach, while others are applied prospectively.  We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.
