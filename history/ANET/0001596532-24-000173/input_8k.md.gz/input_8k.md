# ANET 8-K — 0001596532-24-000171 filed 2024-05-07

## item codes, every 8-K on or before 2024-05-08

- 2024-05-07 0001596532-24-000171 — 2.02, 8.01, 9.01
- 2024-04-23 0001596532-24-000155 — 5.02, 9.01
- 2024-04-19 0001596532-24-000152 — 5.02, 8.01
- 2024-02-28 0001596532-24-000095 — 8.01
- 2024-02-12 0001596532-24-000041 — 2.02, 9.01
- 2023-12-20 0001596532-23-000349 — 5.03, 9.01
- 2023-12-01 0001596532-23-000324 — 5.02, 8.01, 9.01
- 2023-10-30 0001596532-23-000272 — 2.02, 9.01
- 2023-07-31 0001596532-23-000196 — 2.02, 5.02, 9.01
- 2023-06-16 0001596532-23-000168 — 5.07
- 2023-05-01 0001596532-23-000101 — 2.02, 9.01
- 2023-02-13 0001596532-23-000015 — 2.02, 9.01
- 2022-10-31 0001596532-22-000292 — 2.02, 9.01
- 2022-10-25 0001596532-22-000282 — 5.03, 9.01
- 2022-08-01 0001596532-22-000218 — 2.02, 9.01
- 2022-07-25 0001596532-22-000205 — 5.02
- 2022-06-03 0001596532-22-000179 — 5.07
- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2024-05-08

- none on or before 2024-05-08

## item 2.02 — earnings release, exhibit 99.1

[0001596532-24-000171:8k_2_02:1]
EX-99.1
2
ex991q124-earningsrelease.htm
EX-99.1

[0001596532-24-000171:8k_2_02:2]
Document

[0001596532-24-000171:8k_2_02:3]
Exhibit 99.1

[0001596532-24-000171:8k_2_02:4]
Arista Networks, Inc. Reports First Quarter 2024 Financial Results

[0001596532-24-000171:8k_2_02:5]
Board of Directors Authorizes Additional $1.2B Stock Repurchase Program

[0001596532-24-000171:8k_2_02:6]
SANTA CLARA, Calif.- May 7, 2024 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client to cloud networking for large data center/AI, campus and routing environments, today announced financial results for its first quarter ended March 31, 2024.

[0001596532-24-000171:8k_2_02:7]
First Quarter Financial Highlights

[0001596532-24-000171:8k_2_02:8]
“Arista is off to a strong start to 2024 with solid first quarter results,” said Jayshree Ullal, Chairperson and CEO of Arista Networks. “As we get ready to celebrate the 10th anniversary of our IPO in June, I am pleased with our progress in the Arista 2.0 journey as seen in breakthrough innovations, customer traction and building our next generation leaders.”

[0001596532-24-000171:8k_2_02:9]
•Revenue of $1.571 billion, an increase of 2.0% compared to the fourth quarter of 2023, and an increase of 16.3% from the first quarter of 2023.

[0001596532-24-000171:8k_2_02:10]
•GAAP gross margin of 63.7%, compared to GAAP gross margin of 64.9% in the fourth quarter of 2023 and 59.5% in the first quarter of 2023.

[0001596532-24-000171:8k_2_02:11]
•Non-GAAP gross margin of 64.2%, compared to non-GAAP gross margin of 65.4% in the fourth quarter of 2023 and 60.3% in the first quarter of 2023.

[0001596532-24-000171:8k_2_02:12]
•GAAP net income of $637.7 million, or $1.99 per diluted share, compared to GAAP net income of $436.5 million, or $1.38 per diluted share in the first quarter of 2023.

[0001596532-24-000171:8k_2_02:13]
•Non-GAAP net income of $637.7 million, or $1.99 per diluted share, compared to non-GAAP net income of $452.5 million, or $1.43 per diluted share in the first quarter of 2023.

[0001596532-24-000171:8k_2_02:14]
Commenting on the company's financial results, Chantelle Breithaupt, Arista’s CFO said, "We are pleased with our performance this quarter, which exceeded expectations across key financial metrics. Our commitment remains to deliver long-term value to our shareholders through sustained financial performance and strategic investments."

[0001596532-24-000171:8k_2_02:15]
Stock Repurchase Programs

[0001596532-24-000171:8k_2_02:16]
Arista has now completed repurchases of its common stock totaling $2 billion under previous stock repurchase programs. On May 3, 2024, Arista’s Board of Directors authorized an additional program to repurchase up to $1.2 billion.  The actual timing and amount of repurchases will be dependent on market and business conditions, capital requirements, stock price, acquisition opportunities and other factors.

[0001596532-24-000171:8k_2_02:17]
Company Highlights

[0001596532-24-000171:8k_2_02:18]
•Arista Introduces Universal Network Observability – Arista announces CloudVisionⓇ Universal Network ObservabilityTM (CV UNOTM), a modern network observability software offering merging network infrastructure performance and data from compute and server systems-of-record to deliver keen insights into application and workload performance across data center, campus, and wide area networks.

[0001596532-24-000171:8k_2_02:19]
•The New AI Era: Networking for AI and AI for Networking – Arista is delivering both optimal Networking for AI platforms and AI for networking outcomes. AI Etherlink platforms deliver high performance, low latency, fully scheduled, lossless networking as the new unit of currency for AI networks. At the same time AI for networking drives positive outcomes such as security, root cause analysis and observability through AVA.

[0001596532-24-000171:8k_2_02:20]
Financial Outlook

[0001596532-24-000171:8k_2_02:21]
For the second quarter of 2024, we expect:

[0001596532-24-000171:8k_2_02:22]
•Revenue between $1.62 billion to $1.65 billion

[0001596532-24-000171:8k_2_02:23]
•Non-GAAP gross margin of approximately 64%; and

[0001596532-24-000171:8k_2_02:24]
•Non-GAAP operating margin of approximately 44%.

[0001596532-24-000171:8k_2_02:25]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and potential non-recurring charges or benefits. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis because these exclusions can be uncertain or difficult to predict, including stock-based compensation expense which is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock. The actual amount of these exclusions will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-24-000171:8k_2_02:26]
Prepared Materials and Conference Call Information

[0001596532-24-000171:8k_2_02:27]
Arista's executives will discuss the first quarter 2024 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-24-000171:8k_2_02:28]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-24-000171:8k_2_02:29]
Forward-Looking Statements

[0001596532-24-000171:8k_2_02:30]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the second quarter of 2024 and statements regarding the benefits of Arista's products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: large purchases by a limited number of customers who represent a substantial portion of our revenue; adverse economic and geopolitical conditions and conflicts, including inflationary pressures which result in increased component costs and reduced information technology and network infrastructure spending, the Russia/Ukraine, Israel/Hamas conflicts and the Houthi attacks on marine vessels in the Red Sea; changes in our customers technology roadmaps and priorities including the need for the deployment of artificial intelligence (“AI”) and related technologies; the impact of sole or limited sources of supply, supply shortages and extended lead times or supply changes; volatility in our revenue growth rate; variations in our results of operations; the rapid evolution of the networking market; failure to successfully carry out new products and service offerings and expand into adjacent markets; variability in our gross margins; intense competition and industry consolidation; expansion of our international sales and operations; investments in or acquisitions of other businesses; seasonality and industry cyclicality; fluctuations in currency exchange rates; failure to raise additional capital on favorable terms; our inability to attract new large customers or sell additional products and services to our existing customers; sales of our switches generating most of our product revenue; large customers requiring more favorable terms; inability to increase market awareness or acceptance of our new products and services; decreases in the sales prices of our products and services; long and unpredictable sales cycles; declines in maintenance renewals by customers; product quality problems; failure to anticipate technological shifts; managing the supply of our products and product components; our dependence on third-party manufacturers to build our products; assertions by third parties of intellectual property rights infringement;

[0001596532-24-000171:8k_2_02:31]
failure to protect or assert our intellectual property rights; defects, errors or vulnerabilities in our products, the failure of our products to detect security breaches or incidents, the misuse of our products or the risks or product liability; enhanced U.S. tax, tariff, import/export restrictions, Chinese regulations or other trade barriers; failure to comply with government law and regulations; issues in the development and use of artificial intelligence, combined with an uncertain regulatory environment; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-24-000171:8k_2_02:32]
Non-GAAP Financial Measures

[0001596532-24-000171:8k_2_02:33]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangibles, gains/losses on strategic investments, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-24-000171:8k_2_02:34]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-24-000171:8k_2_02:35]
About Arista Networks

[0001596532-24-000171:8k_2_02:36]
Arista Networks is an industry leader in data-driven, client to cloud networking for large data center/AI, campus and routing environments. Arista’s award-winning platforms deliver availability, agility, automation, analytics and security through an advanced network operating stack. For more information, visit www.arista.com.

[0001596532-24-000171:8k_2_02:37]
ARISTA, CloudVision, CV UNO, AVA and Etherlink are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-24-000171:8k_2_02:38]
ARISTA NETWORKS, INC.

[0001596532-24-000171:8k_2_02:39]
Condensed Consolidated Income Statements

[0001596532-24-000171:8k_2_02:40]
(Unaudited, in thousands, except per share amounts)

[0001596532-24-000171:8k_2_02:41]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,328,845 |  |  | $ | 1,172,094 |  |  |  |  |  |
| Service |  | 242,529 |  |  | 179,257 |  |  |  |  |  |
| Total revenue |  | 1,571,374 |  |  | 1,351,351 |  |  |  |  |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 521,679 |  |  | 508,862 |  |  |  |  |  |
| Service |  | 48,316 |  |  | 37,982 |  |  |  |  |  |
| Total cost of revenue |  | 569,995 |  |  | 546,844 |  |  |  |  |  |
| Gross profit |  | 1,001,379 |  |  | 804,507 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 208,395 |  |  | 201,408 |  |  |  |  |  |
| Sales and marketing |  | 105,080 |  |  | 93,492 |  |  |  |  |  |
| General and administrative |  | 27,763 |  |  | 25,029 |  |  |  |  |  |
| Total operating expenses |  | 341,238 |  |  | 319,929 |  |  |  |  |  |
| Income from operations |  | 660,141 |  |  | 484,578 |  |  |  |  |  |
| Other income (expense), net |  | 62,620 |  |  | 12,146 |  |  |  |  |  |
| Income before income taxes |  | 722,761 |  |  | 496,724 |  |  |  |  |  |
| Provision for income taxes |  | 85,069 |  |  | 60,251 |  |  |  |  |  |
| Net income |  | $ | 637,692 |  |  | $ | 436,473 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.04 |  |  | $ | 1.42 |  |  |  |  |  |
| Diluted |  | $ | 1.99 |  |  | $ | 1.38 |  |  |  |  |  |
| Weighted-average shares used in computing net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 313,032 |  |  | 306,985 |  |  |  |  |  |
| Diluted |  | 319,865 |  |  | 315,578 |  |  |  |  |  |

[0001596532-24-000171:8k_2_02:42]
4

[0001596532-24-000171:8k_2_02:43]
ARISTA NETWORKS, INC.

[0001596532-24-000171:8k_2_02:44]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-24-000171:8k_2_02:45]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-24-000171:8k_2_02:46]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| GAAP gross profit |  | $ | 1,001,379 |  |  | $ | 804,507 |  |  |  |  |  |
| GAAP gross margin |  | 63.7 | % |  | 59.5 | % |  |  |  |  |
| Stock-based compensation expense |  | 3,450 |  |  | 2,975 |  |  |  |  |  |
| Intangible asset amortization |  | 4,195 |  |  | 6,820 |  |  |  |  |  |
| Non-GAAP gross profit |  | $ | 1,009,024 |  |  | $ | 814,302 |  |  |  |  |  |
| Non-GAAP gross margin |  | 64.2 | % |  | 60.3 | % |  |  |  |  |
| GAAP income from operations |  | $ | 660,141 |  |  | $ | 484,578 |  |  |  |  |  |
| Stock-based compensation expense |  | 77,215 |  |  | 62,881 |  |  |  |  |  |
| Intangible asset amortization |  | 6,690 |  |  | 9,315 |  |  |  |  |  |
| Non-GAAP income from operations |  | $ | 744,046 |  |  | $ | 556,774 |  |  |  |  |  |
| Non-GAAP operating margin |  | 47.4 | % |  | 41.2 | % |  |  |  |  |
| GAAP net income |  | $ | 637,692 |  |  | $ | 436,473 |  |  |  |  |  |
| Stock-based compensation expense |  | 77,215 |  |  | 62,881 |  |  |  |  |  |
| Intangible asset amortization |  | 6,690 |  |  | 9,315 |  |  |  |  |  |
| (Gains)/losses on strategic investments |  | — |  |  | 5,571 |  |  |  |  |  |
| Tax benefits on stock-based awards |  | (70,833) |  |  | (50,062) |  |  |  |  |  |
| Income tax effect on non-GAAP exclusions |  | (13,048) |  |  | (11,716) |  |  |  |  |  |
| Non-GAAP net income |  | $ | 637,716 |  |  | $ | 452,462 |  |  |  |  |  |
| GAAP diluted net income per share |  | $ | 1.99 |  |  | $ | 1.38 |  |  |  |  |  |
| Non-GAAP adjustments to net income |  | — |  |  | 0.05 |  |  |  |  |  |
| Non-GAAP diluted net income per share |  | $ | 1.99 |  |  | $ | 1.43 |  |  |  |  |  |
| Weighted-average shares used in computing diluted net income per share |  | 319,865 |  |  | 315,578 |  |  |  |  |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 3,450 |  |  | $ | 2,975 |  |  |  |  |  |
| Research and development |  | 43,788 |  |  | 36,569 |  |  |  |  |  |
| Sales and marketing |  | 18,901 |  |  | 15,138 |  |  |  |  |  |
| General and administrative |  | 11,076 |  |  | 8,199 |  |  |  |  |  |
| Total |  | $ | 77,215 |  |  | $ | 62,881 |  |  |  |  |  |

[0001596532-24-000171:8k_2_02:47]
ARISTA NETWORKS, INC.

[0001596532-24-000171:8k_2_02:48]
Condensed Consolidated Balance Sheets

[0001596532-24-000171:8k_2_02:49]
(Unaudited, in thousands)

[0001596532-24-000171:8k_2_02:50]
|  |  | March 31, 2024 |  | December 31, 2023 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,092,101 |  |  | $ | 1,938,606 |  |
| Marketable securities |  | 3,357,597 |  |  | 3,069,362 |  |
| Accounts receivable |  | 1,090,041 |  |  | 1,024,569 |  |
| Inventories |  | 2,025,204 |  |  | 1,945,180 |  |
| Prepaid expenses and other current assets |  | 361,340 |  |  | 412,518 |  |
| Total current assets |  | 8,926,283 |  |  | 8,390,235 |  |
| Property and equipment, net |  | 97,949 |  |  | 101,580 |  |
| Acquisition-related intangible assets, net |  | 82,078 |  |  | 88,768 |  |
| Goodwill |  | 268,531 |  |  | 268,531 |  |
| Deferred tax assets |  | 1,025,861 |  |  | 945,792 |  |
| Other assets |  | 149,477 |  |  | 151,900 |  |
| TOTAL ASSETS |  | $ | 10,550,179 |  |  | $ | 9,946,806 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 223,305 |  |  | $ | 435,059 |  |
| Accrued liabilities |  | 270,586 |  |  | 407,302 |  |
| Deferred revenue |  | 997,914 |  |  | 915,204 |  |
| Other current liabilities |  | 291,259 |  |  | 152,041 |  |
| Total current liabilities |  | 1,783,064 |  |  | 1,909,606 |  |
| Income taxes payable |  | 107,179 |  |  | 95,751 |  |
| Deferred revenue, non-current |  | 665,328 |  |  | 591,000 |  |
| Other long-term liabilities |  | 132,293 |  |  | 131,390 |  |
| TOTAL LIABILITIES |  | 2,687,864 |  |  | 2,727,747 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 31 |  |  | 31 |  |
| Additional paid-in capital |  | 2,185,149 |  |  | 2,108,331 |  |
| Retained earnings |  | 5,689,064 |  |  | 5,114,025 |  |
| Accumulated other comprehensive income (loss) |  | (11,929) |  |  | (3,328) |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 7,862,315 |  |  | 7,219,059 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 10,550,179 |  |  | $ | 9,946,806 |  |

[0001596532-24-000171:8k_2_02:51]
6

[0001596532-24-000171:8k_2_02:52]
ARISTA NETWORKS, INC.

[0001596532-24-000171:8k_2_02:53]
Condensed Consolidated Statements of Cash Flows

[0001596532-24-000171:8k_2_02:54]
(Unaudited, in thousands)

[0001596532-24-000171:8k_2_02:55]
|  |  | Three Months Ended March 31, |
|  |  | 2024 |  | 2023 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 637,692 |  |  | $ | 436,473 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 15,614 |  |  | 20,905 |  |
| Stock-based compensation |  | 77,215 |  |  | 62,881 |  |
| Noncash lease expense |  | 4,580 |  |  | 4,633 |  |
| Deferred income taxes |  | (77,822) |  |  | (71,153) |  |
| Loss on strategic investments |  | — |  |  | 5,571 |  |
| Amortization (accretion) of investment premiums (discounts) |  | (12,418) |  |  | (4,220) |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (65,472) |  |  | 60,221 |  |
| Inventories |  | (80,024) |  |  | (392,997) |  |
| Other assets |  | 38,082 |  |  | (55,917) |  |
| Accounts payable |  | (207,234) |  |  | 94,564 |  |
| Accrued liabilities |  | (136,554) |  |  | 58,655 |  |
| Deferred revenue |  | 157,038 |  |  | 51,028 |  |
| Income taxes, net |  | 157,537 |  |  | 108,200 |  |
| Other liabilities |  | 5,571 |  |  | (4,361) |  |
| Net cash provided by operating activities |  | 513,805 |  |  | 374,483 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 590,436 |  |  | 824,021 |  |
| Proceeds from sale of marketable securities |  | 36,750 |  |  | 21,725 |  |
| Purchases of marketable securities |  | (912,441) |  |  | (861,612) |  |
| Purchases of property and equipment |  | (9,395) |  |  | (5,631) |  |
| Investments in notes and privately-held companies |  | (1,000) |  |  | (250) |  |
| Net cash used in investing activities |  | (295,650) |  |  | (21,747) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 25,144 |  |  | 23,096 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (25,541) |  |  | (9,224) |  |
| Repurchases of common stock |  | (62,653) |  |  | (82,275) |  |
| Net cash used in financing activities |  | (63,050) |  |  | (68,403) |  |
| Effect of exchange rate changes |  | (1,608) |  |  | 314 |  |
| NET INCREASE IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 153,497 |  |  | 284,647 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 1,939,464 |  |  | 675,978 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 2,092,961 |  |  | $ | 960,625 |  |

[0001596532-24-000171:8k_2_02:56]
Investor Contacts:

[0001596532-24-000171:8k_2_02:57]
Arista Networks, Inc.

[0001596532-24-000171:8k_2_02:58]
Liz Stine, 408-547-5885

[0001596532-24-000171:8k_2_02:59]
Investor Relations

[0001596532-24-000171:8k_2_02:60]
liz@arista.com
