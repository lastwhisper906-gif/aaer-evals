# ANET MD&A — 0001596532-24-000173


## mdna

[0001596532-24-000173:mdna:1]
[same as prior period, unchanged from 0001596532-23-000274:mdna:1]

[0001596532-24-000173:mdna:2]
[same as prior period, unchanged from 0001596532-23-000274:mdna:2]

[0001596532-24-000173:mdna:3]
Arista Networks is an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments. Arista's platforms deliver availability, agility, automation, analytics and security through an advanced network operating stack. Since Arista’s inception, our founders have reimagined cloud networks for performance, scale and

[0001596532-24-000173:mdna:4]
programmability with a focus on differentiating in three ways: uncompromising quality, advanced open and standards-based technology and a robust quality assurance capability built on a suite of automated diagnostics. At the core of Arista’s platform is Arista’s EOS, a modernized publish-subscribe state-sharing networking operating system. Arista EOS, combined with a set of network applications and our Ethernet switching and routing platforms using best of breed merchant silicon, provides customers with a highly competitive and diversified portfolio of products with improved price/performance and time to market.

[0001596532-24-000173:mdna:5]
We generate revenue primarily from sales of our switching and routing platforms, which incorporate Arista's EOS software, and related network applications. We also generate revenue from post-contract support ("PCS"), which customers typically purchase in conjunction with our products, and renewals of PCS. We sell our products through both our direct sales force and our channel partners. Our customers span a range of industries and geographies including large cloud customers or hyperscalers, other internet providers, service providers, financial services organizations, government agencies and a cross section of enterprise customers. Over the past five years, we have diversified the types of enterprise customers we sell to and have continued to expand our presence across a wide spectrum of industries including media and entertainment, healthcare, oil and gas, education, manufacturing, industrial, and more.

[0001596532-24-000173:mdna:6]
Historically, large purchases by a relatively limited number of customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large customers primarily due to the time it takes these customers to evaluate, test, qualify and accept our newer products, the overall complexity of these large orders and changes in demand patterns specific to these customers, including reductions in capital expenditures by these customers and the impact of cost reduction and other efficiency efforts by these customers. For example, sales to our end customers Microsoft and Meta Platforms represented 18% and 21% of our total revenue, respectively, in fiscal 2023, 16% and 26% of our total revenue, respectively, in fiscal 2022 and, 15% and less than 10% of our total revenue, respectively in fiscal 2021. This variability in customer concentration has been linked to the timing of new product deployments and spending cycles with these customers, and we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, an increased focus on the deployment of AI enabled solutions by these customers has accelerated the need for advanced technology offerings including some offerings from potential new market entrants.  This prioritization of AI related infrastructure investment has come in conjunction with the announcement of various cost reduction measures, including optimization and increased efficiency in non-AI related capital expenditures.  In some instances, such measures have had, and may continue to have, an impact on certain current or future projects and have reduced our visibility to customer demand, increased our risk of excess and obsolescence charges on existing products, and may result in reductions in future demand and negatively impact our revenue, financial condition, business or prospects. Furthermore, we typically provide pricing discounts to large customers, which reduces gross margins for the period in which such sales occur.

[0001596532-24-000173:mdna:7]
We believe that cloud computing represents a fundamental shift from traditional legacy network architectures. As organizations of all sizes have moved workloads to the cloud, spending on cloud and next-generation data centers has increased rapidly, while traditional legacy IT spending has grown at a slower rate. Our cloud networking platforms are well positioned to address the growing cloud networking market, and to address increasing performance requirements driven by the growing number of connected devices, as well as the need for constant connectivity and access to data and applications.

[0001596532-24-000173:mdna:8]
The markets for cloud networking solutions are highly competitive and characterized by rapidly changing technology, changing end-customer needs, evolving industry standards, frequent introductions of new products and services, and industry consolidation. We expect competition to intensify in the future as the market for cloud networking expands and existing competitors and new market entrants introduce new products or enhance existing products. Our future success is dependent upon our ability to continue to evolve and adapt to our rapidly changing environment. We must also continue to develop market-leading products and features that address the needs of our existing and new customers, and increase sales in the enterprise data center switching, and campus workspace markets. We intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new customers more effectively, increase sales to existing customers, and provide services and support. In addition, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our ability to rapidly develop new features and applications.

[0001596532-24-000173:mdna:9]
Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic with respect to the underlying merchant silicon architecture. The programmability of EOS has allowed us to expand our software applications to address the ever-increasing demands of cloud networking, including workflow automation, network visibility, analytics and network detection and response, and has further allowed us to integrate rapidly with a wide range of third-party applications for virtualization, management, automation, orchestration and network services. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We work closely with third-party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to

[0001596532-24-000173:mdna:10]
our third-party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-24-000173:mdna:11]
[same as prior period, unchanged from 0001596532-23-000274:mdna:9]

[0001596532-24-000173:mdna:12]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including inflation, monetary policy shifts, recession risks, and potential supply chain and other disruptions such as the Russia-Ukraine and Israel-Hamas conflicts, the Houthi attacks on marine vessels in the Red Sea, and the U.S. trade war with China.

[0001596532-24-000173:mdna:13]
Our business is emerging from a period of unprecedented global supply chain disruptions.  Throughout this period, we made significant supply chain investments, including funding additional working capital and incremental purchase commitments in response to extended visibility to deployment plans from our customers. We have worked closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. Increased capacity has allowed us to ship products against previously committed demand/deployment plans and accelerate some deployments where needed, while trying to limit building customer inventory, and to some extent balancing customer lead times with those currently experienced from our key suppliers. As a result, some shipments against these previously committed demand/deployment plans have extended into 2024.

[0001596532-24-000173:mdna:14]
As the global supply chain has experienced some improvements and as customer lead times have been reduced from their peak, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to shorter demand-planning horizons resulting in lower demand levels. Given these shipment and order patterns, near term revenue trends may not be solely reflective of current demand levels, but as discussed above will benefit from demand/deployment plans that had been previously committed. While inventory and working capital levels may remain elevated in the near term, we expect that purchase commitments will begin to level off as supplier lead times shorten, but will remain volatile as we ramp new product introductions. The larger magnitude of these balances, combined with a reduction in customer demand-planning horizons and shifting customer product priorities, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted, and may in the future result, in additional excess and obsolete inventory and supplier liability charges.

[0001596532-24-000173:mdna:15]
In addition, inflation pressure in our supply chain, scarcity of some materials needed to build our products and disruptions to our manufacturing process have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. Our operating cash flows have also been and may continue to be negatively impacted by significant component inventories on hand or at our contract manufacturers. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the Russia-Ukraine conflict, continued escalation of this conflict as well as the Israeli-Hamas conflict and Houthi movement in the Red Sea may negatively impact the global economy and our future operating results and financial condition.

[0001596532-24-000173:mdna:16]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that some of our customers, following a year of elevated purchases, must now consider changing technology roadmaps and priorities, including the need for the deployment of AI and related technologies, resulting in some uncertainty as to future investment plans and a more constrained approach to some forecasts and orders in the near term. In addition, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.

[0001596532-24-000173:mdna:17]
[same as prior period, unchanged from 0001596532-23-000274:mdna:14]

[0001596532-24-000173:mdna:18]
Three Months Ended March 31, 2024 Compared to Three Months Ended March 31, 2023

[0001596532-24-000173:mdna:19]
[same as prior period, unchanged from 0001596532-23-000274:mdna:16]

[0001596532-24-000173:mdna:20]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2024 |  | 2023 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,328,845 |  |  | $ | 1,172,094 |  |  | $ | 156,751 |  |  | 13.4 | % |  |  |  |  |  |  |  |  |
| Service |  | 242,529 |  |  | 179,257 |  |  | 63,272 |  |  | 35.3 |  |  |  |  |  |  |  |  |  |
| Total revenue |  | 1,571,374 |  |  | 1,351,351 |  |  | 220,023 |  |  | 16.3 |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 521,679 |  |  | 508,862 |  |  | 12,817 |  |  | 2.5 |  |  |  |  |  |  |  |  |  |
| Service |  | 48,316 |  |  | 37,982 |  |  | 10,334 |  |  | 27.2 |  |  |  |  |  |  |  |  |  |
| Total cost of revenue |  | 569,995 |  |  | 546,844 |  |  | 23,151 |  |  | 4.2 |  |  |  |  |  |  |  |  |  |
| Gross profit |  | $ | 1,001,379 |  |  | $ | 804,507 |  |  | $ | 196,872 |  |  | 24.5 | % |  |  |  |  |  |  |  |  |
| Gross margin |  | 63.7 | % |  | 59.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001596532-24-000173:mdna:21]
[same as prior period, unchanged from 0001596532-23-000274:mdna:18]

[0001596532-24-000173:mdna:22]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2024 |  | % of Total |  | 2023 |  | % of Total |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,255,391 |  |  | 79.9 | % |  | $ | 1,115,011 |  |  | 82.5 | % |  |  |  |  |  |  |  |  |
| Europe, Middle East and Africa |  | 141,554 |  |  | 9.0 |  |  | 128,316 |  |  | 9.5 |  |  |  |  |  |  |  |  |  |
| Asia-Pacific |  | 174,429 |  |  | 11.1 |  |  | 108,024 |  |  | 8.0 |  |  |  |  |  |  |  |  |  |
| Total revenue |  | $ | 1,571,374 |  |  | 100.0 | % |  | $ | 1,351,351 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

[0001596532-24-000173:mdna:23]
[same as prior period, unchanged from 0001596532-23-000274:mdna:20]

[0001596532-24-000173:mdna:24]
Product revenue primarily consists of sales of our switching and routing products, and related network applications. Service revenue is primarily derived from sales of PCS contracts, which are typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing, size, and complexity of orders, especially with respect to our large customers.

[0001596532-24-000173:mdna:25]
Product revenue increased by $156.8 million, or 13.4% for the three months ended March 31, 2024, compared to the same period in 2023. This increase reflects higher demand and shipments of our switching and routing platforms across our customer base, in particular a strong contribution from our enterprise customers. In addition, service revenue increased by $63.3 million, or 35.3% for the three months ended March 31, 2024, compared to the same period in 2023, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenue represented 20.1% of total revenue for the three months ended March 31, 2024, increasing from 17.5% for the same period in the prior year, which was primarily driven by a reduction in the mix of sales to our large global customers in the Americas region.

[0001596532-24-000173:mdna:26]
[same as prior period, unchanged from 0001596532-23-000274:mdna:24]

[0001596532-24-000173:mdna:27]
[same as prior period, unchanged from 0001596532-23-000274:mdna:25]

[0001596532-24-000173:mdna:28]
Cost of revenue increased by $23.2 million, or 4.2% for the three months ended March 31, 2024, compared to the same period in 2023. These increases were primarily driven by a corresponding increase in product and service revenues, partially offset by a decrease in logistics costs and excess/obsolete inventory and supplier liability charges.

[0001596532-24-000173:mdna:29]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including pricing pressure on our products and services due to competition, the mix of sales to large end customers who generally receive lower pricing, the mix of products sold, manufacturing-related costs, including costs associated with supply

[0001596532-24-000173:mdna:30]
chain sourcing activities, merchant silicon costs, and excess/obsolete inventory charges, including charges for excess/obsolete component inventory held by our contract manufacturers and suppliers. We expect our gross margin to fluctuate over time, depending on the factors described above.

[0001596532-24-000173:mdna:31]
Gross margin increased from 59.5% to 63.7% for the three months ended March 31, 2024, compared to the same period in 2023. These changes reflect an improvement in product margins driven by a decrease in logistics costs and excess/obsolete inventory and supplier liability charges, combined with the leverage of fixed overhead costs on a higher revenue base, and a lower mix of revenue from our larger customers.

[0001596532-24-000173:mdna:32]
[same as prior period, unchanged from 0001596532-23-000274:mdna:29]

[0001596532-24-000173:mdna:33]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. The largest component of our operating expenses is personnel costs. Personnel costs consist of wages, benefits, bonuses and, with respect to sales and marketing expenses, sales commissions. Personnel costs also include stock-based compensation and travel-related expenses.

[0001596532-24-000173:mdna:34]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2024 |  | 2023 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 208,395 |  |  | $ | 201,408 |  |  | $ | 6,987 |  |  | 3.5 | % |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 105,080 |  |  | 93,492 |  |  | 11,588 |  |  | 12.4 |  |  |  |  |  |  |  |  |  |
| General and administrative |  | 27,763 |  |  | 25,029 |  |  | 2,734 |  |  | 10.9 |  |  |  |  |  |  |  |  |  |
| Total operating expenses |  | $ | 341,238 |  |  | $ | 319,929 |  |  | $ | 21,309 |  |  | 6.7 | % |  |  |  |  |  |  |  |  |

[0001596532-24-000173:mdna:35]
[same as prior period, unchanged from 0001596532-23-000274:mdna:32]

[0001596532-24-000173:mdna:36]
[same as prior period, unchanged from 0001596532-23-000274:mdna:33]

[0001596532-24-000173:mdna:37]
Research and development expenses increased by $7.0 million, or 3.5% for the three months ended March 31, 2024, compared to the same period in 2023. The increase was primarily driven by an increase in personnel costs due to headcount growth, and partially offset by a decrease in new product introduction costs primarily due to timing of third-party engineering projects and deliverables.

[0001596532-24-000173:mdna:38]
[same as prior period, unchanged from 0001596532-23-000274:mdna:36]

[0001596532-24-000173:mdna:39]
[same as prior period, unchanged from 0001596532-23-000274:mdna:37]

[0001596532-24-000173:mdna:40]
Sales and marketing expenses increased by $11.6 million, or 12.4% for the three months ended March 31, 2024, compared to the same period in 2023, which was primarily driven by increased personnel costs due to headcount growth.

[0001596532-24-000173:mdna:41]
[same as prior period, unchanged from 0001596532-23-000274:mdna:39]

[0001596532-24-000173:mdna:42]
General and administrative expenses consist primarily of personnel costs and professional services costs for our finance, human resources, legal and certain executive functions. Our professional services costs are primarily related to external legal, accounting and tax services.

[0001596532-24-000173:mdna:43]
General and administrative expenses increased by $2.7 million, or 10.9% for the three months ended March 31, 2024, compared to the same period in 2023, which was primarily attributable to an increase in personnel costs, in particular stock-based compensation.

[0001596532-24-000173:mdna:44]
[same as prior period, unchanged from 0001596532-23-000274:mdna:42]

[0001596532-24-000173:mdna:45]
Other income (expense), net consists primarily of interest income from our cash, cash equivalents and marketable securities, gains and losses on our marketable equity securities and strategic investments, and foreign currency transaction gains and losses. We expect other income (expense), net may fluctuate in the future as a result of the re-measurement of our equity investments upon the occurrence of either observable price changes or impairments, changes in interest rates or returns on our

[0001596532-24-000173:mdna:46]
cash and cash equivalents and marketable securities, and foreign currency exchange rate fluctuations.

[0001596532-24-000173:mdna:47]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2024 |  | 2023 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 63,823 |  |  | $ | 22,509 |  |  | $ | 41,314 |  |  | 183.5 | % |  |  |  |  |  |  |  |  |
| Gain (loss) on strategic investments |  | — |  |  | (5,571) |  |  | 5,571 |  |  | (100.0) |  |  |  |  |  |  |  |  |  |
| Other income (expense), net |  | (1,203) |  |  | (4,792) |  |  | 3,589 |  |  | (74.9) |  |  |  |  |  |  |  |  |  |
| Total other income (expense), net |  | $ | 62,620 |  |  | $ | 12,146 |  |  | $ | 50,474 |  |  | 415.6 | % |  |  |  |  |  |  |  |  |

[0001596532-24-000173:mdna:48]
The favorable movement in other income (expense), net, during the three months ended March 31, 2024 compared to the same period in 2023 was primarily driven by increased interest income of $41.3 million due to an increase in our cash and investment balances, coupled with higher interest rates.

[0001596532-24-000173:mdna:49]
[same as prior period, unchanged from 0001596532-23-000274:mdna:46]

[0001596532-24-000173:mdna:50]
[same as prior period, unchanged from 0001596532-23-000274:mdna:47]

[0001596532-24-000173:mdna:51]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2024 |  | 2023 |  | Change in |  |  |  |  |  |  |
|  |  | $ |  | $ |  | $ |  | % |  |  |  |  |  |  |  |  |
| Income before income taxes |  | $ | 722,761 |  |  | $ | 496,724 |  |  | $ | 226,037 |  |  | 45.5 | % |  |  |  |  |  |  |  |  |
| Provision for income taxes |  | 85,069 |  |  | 60,251 |  |  | 24,818 |  |  | 41.2 | % |  |  |  |  |  |  |  |  |
| Effective tax rate |  | 11.8 | % |  | 12.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001596532-24-000173:mdna:52]
The decrease in the effective tax rates for the three months ended March 31, 2024, as compared to the same period in 2023, was primarily due to a favorable change in the jurisdictional mix of earnings.

[0001596532-24-000173:mdna:53]
[same as prior period, unchanged from 0001596532-23-000274:mdna:50]

[0001596532-24-000173:mdna:54]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of March 31, 2024, our total balance of cash, cash equivalents and marketable securities was approximately $5.45 billion, of which approximately $801.1 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-24-000173:mdna:55]
Our cash, cash equivalents and marketable securities are held for general business purposes, including the funding of working capital. Our marketable securities investment portfolio is primarily invested in highly-rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, stock repurchases, and capital expenditures, including the planned construction of an office for office and lab space. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-24-000173:mdna:56]
[same as prior period, unchanged from 0001596532-23-000274:mdna:53]

[0001596532-24-000173:mdna:57]
|  |  | Three Months Ended March 31, |
|  |  | 2024 |  | 2023 |
| Cash provided by operating activities |  | $ | 513,805 |  |  | $ | 374,483 |  |
| Cash provided by (used in) investing activities |  | (295,650) |  |  | (21,747) |  |
| Cash used in financing activities |  | (63,050) |  |  | (68,403) |  |
| Effect of exchange rate changes |  | (1,608) |  |  | 314 |  |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 153,497 |  |  | $ | 284,647 |  |

[0001596532-24-000173:mdna:58]
[same as prior period, unchanged from 0001596532-23-000274:mdna:55]

[0001596532-24-000173:mdna:59]
During the three months ended March 31, 2024, cash provided by operating activities was $513.8 million, consisting of net income of $637.7 million, non-cash adjustments to net income of $7.2 million and offset by a net increase of $131.1 million in working capital requirements. The non-cash adjustments to net income were driven by stock-based compensation and depreciation and amortization, largely offset by an increase in deferred taxes primarily due to the capitalization of research and development costs under Section 174 of the Internal Revenue Code ("IRC"). The increase in working capital requirements primarily consisted of a $343.8 million decrease in accounts payable and accrued liabilities primarily due to timing of inventory-related receipts and payments, an $80.0 million increase in inventory and an increase in accounts receivable of $65.5 million. These cash outflows were partly offset by a $157.5 million increase in income tax payables related to timing of payments, and an increase in deferred revenue of $157.0 million primarily resulting from an increase in customer PCS contracts, partly offset by a reduction in product deferred revenue related to customer contracts with acceptance terms, and a $38.1 million decrease in prepaid and other assets.

[0001596532-24-000173:mdna:60]
During the three months ended March 31, 2023, cash provided by operating activities was $374.5 million, primarily from net income of $436.5 million and non-cash adjustments to net income of $18.6 million driven by stock-based compensation and depreciation and amortization, largely offset by an increase in deferred taxes associated with the capitalization of research and development costs under IRC Section 174. These increases were partly offset by a net increase of $80.6 million in working capital requirements, which primarily consisted of a $393.0 million increase in inventory and an $81.9 million increase in inventory deposits to our contract manufacturers in response to a significant increase in business volume and increased product lead times.  These operating cash outflows were largely offset by cash inflows from a $153.2 million increase in accounts payable and accrued liabilities and a $108.2 million increase in income tax payables related to significant business volume and timing of payments. In addition, we had cash inflows resulting from a decrease in accounts receivable of $60.2 million driven by strong collections, and an increase in deferred revenue of $51.0 million primarily resulting from an increase in customer PCS contracts.

[0001596532-24-000173:mdna:61]
[same as prior period, unchanged from 0001596532-23-000274:mdna:58]

[0001596532-24-000173:mdna:62]
During the three months ended March 31, 2024, cash used in investing activities was $295.7 million, consisting of  purchases of available-for-sale securities of $912.4 million, and purchases of property and equipment of $9.4 million. These amounts were partially offset by proceeds from maturities and sales of marketable securities of $627.2 million.

[0001596532-24-000173:mdna:63]
During the three months ended March 31, 2023, cash used in investing activities was $21.7 million, consisting of  purchases of available-for-sale securities of $861.6 million, and purchases of property and equipment of $5.6 million. These amounts were partially offset by proceeds from maturities and sales of marketable securities of $845.7 million.

[0001596532-24-000173:mdna:64]
[same as prior period, unchanged from 0001596532-23-000274:mdna:61]

[0001596532-24-000173:mdna:65]
During the three months ended March 31, 2024, cash used in financing activities was $63.1 million, consisting of payments for repurchases of our common stock from the open market of $62.7 million, and employee taxes withheld and paid of $25.5 million upon vesting of restricted stock units, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $25.1 million.

[0001596532-24-000173:mdna:66]
During the three months ended March 31, 2023, cash used in financing activities was $68.4 million, consisting of payments for repurchases of our common stock from the open market of $82.3 million, and employee taxes withheld and paid of $9.2 million upon vesting of restricted stock units, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $23.1 million.

[0001596532-24-000173:mdna:67]
Stock Repurchase Programs

[0001596532-24-000173:mdna:68]
From time to time, we repurchase shares of our common stock pursuant to our Repurchase Programs that are funded from working capital. The Existing Repurchase Program allowed for stock repurchases of up to $1.0 billion through October 2024 and was completed in April 2024, and the New Repurchase Program will allow for repurchases of an additional $1.2

[0001596532-24-000173:mdna:69]
billion through May 2027. The New Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the company at any time without prior notice. During the three months ended March 31, 2024, we repurchased a total of $62.7 million of our common stock under our Existing Repurchase Program and no repurchases have been made under our New Repurchase Program. As of March 31, 2024, the remaining authorized amount for repurchases under the Existing Repurchase Program was $82.0 million. In April 2024, we repurchased the remaining $82.0 million of our common stock authorized under the Existing Repurchase Program. Refer to Note 6. Stockholders' Equity and Stock-Based Compensation and Note 10. Subsequent Events of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-24-000173:mdna:70]
[same as prior period, unchanged from 0001596532-23-000274:mdna:66]

[0001596532-24-000173:mdna:71]
[same as prior period, unchanged from 0001596532-23-000274:mdna:67]

[0001596532-24-000173:mdna:72]
[same as prior period, unchanged from 0001596532-23-000274:mdna:68]

[0001596532-24-000173:mdna:73]
[same as prior period, unchanged from 0001596532-23-000274:mdna:71]

[0001596532-24-000173:mdna:74]
Purchase obligations not recorded on our balance sheet represent an estimate of all non-cancellable open purchase orders and contractual obligations, made either directly by Arista or by our contract manufacturers on our behalf, in the ordinary course of business for which we have not received the goods or services. As of March 31, 2024, we had $1,457.7 million of such purchase obligations, of which $1,425.1 million are expected to be received within one year, and $32.6 million are expected to be received after one year.  These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-24-000173:mdna:75]
[same as prior period, unchanged from 0001596532-23-000274:mdna:69]

[0001596532-24-000173:mdna:76]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of March 31, 2024, we had lease payment obligations, net of immaterial sublease income, of $65.9 million, with $23.7 million payable within one year.

[0001596532-24-000173:mdna:77]
Property project

[0001596532-24-000173:mdna:78]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office and lab space. The estimated capital expenditures related to this project is estimated to be approximately $80.0 to $100.0 million for the year ending 2024, with construction expected to commence in the second half of 2024.

[0001596532-24-000173:mdna:79]
[same as prior period, unchanged from 0001596532-23-000274:mdna:73]

[0001596532-24-000173:mdna:80]
As of March 31, 2024, we have recorded long-term tax liabilities of $107.2 million related to uncertain tax positions; however, we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-24-000173:mdna:81]
In connection with the Tax Cuts and Jobs Act of 2017 (“TCJA”), effective January 1, 2022, the TCJA eliminated the option to deduct research and development expenditures currently and requires taxpayers to capitalize and amortize them over five or fifteen years pursuant to IRC Section 174. We estimate the incremental cash tax impact resulting from these regulations to be approximately $200.0 million for 2024. It is anticipated that IRC Section 174 will result in cash tax outlays exceeding our income tax expense over the next two years unless the current legislation is changed. There has been no material change to our effective tax rate as a result of this legislation.

[0001596532-24-000173:mdna:82]
[same as prior period, unchanged from 0001596532-23-000274:mdna:78]

[0001596532-24-000173:mdna:83]
As of March 31, 2024, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-24-000173:mdna:84]
[same as prior period, unchanged from 0001596532-23-000274:mdna:80]

[0001596532-24-000173:mdna:85]
Our management’s discussion and analysis of financial condition and results of operations are based on our unaudited condensed consolidated financial statements, which have been prepared in accordance with GAAP. The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on

[0001596532-24-000173:mdna:86]
various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting estimates in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our Annual Report on Form 10-K filed with the SEC on February 12, 2024 reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as disclosed in our Annual Report on Form 10-K.

[0001596532-24-000173:mdna:87]
[same as prior period, unchanged from 0001596532-23-000274:mdna:82]

[0001596532-24-000173:mdna:88]
Refer to the subheading titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
