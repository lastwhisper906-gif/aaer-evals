# ANET note change history — 0001596532-23-000274 → 0001596532-24-000173


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-08):
[0001596532-24-000173:note_history:1]
Commitments and Contingencies
Leases
  (was, 2023-10-31, similarity 0.7907):
[0001596532-23-000274:note_history:1]
Commitments and Contingencies
Purchase Commitments

- added (2024-05-08):
[0001596532-24-000173:note_history:2]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of March 31, 2024, we had lease payment obligations, net of immaterial sublease income, of $65.9 million, with $23.7 million payable within one year.

- added (2024-05-08):
[0001596532-24-000173:note_history:3]
Purchase Commitments

- changed (2024-05-08):
[0001596532-24-000173:note_history:4]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2024, we had non-cancellable purchase commitments not recorded on our balance sheet of $1,457.7 million, of which $1,425.1 million have expected receipt dates within 12 months, and $32.6 million have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.
  (was, 2023-10-31, similarity 0.9746):
[0001596532-23-000274:note_history:4]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2023, we had non-cancellable purchase commitments of $2.0 billion, of which $1.7 billion have expected receipt dates within 12 months, and $0.3 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

- changed (2024-05-08):
[0001596532-24-000173:note_history:5]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $131.8 million and $133.3 million as of March 31, 2024 and December 31, 2023, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.
  (was, 2023-10-31, similarity 0.9779):
[0001596532-23-000274:note_history:5]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $201.1 million and $192.5 million as of September 30, 2023 and December 31, 2022, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

- added (2024-05-08):
[0001596532-24-000173:note_history:6]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2024, provisions recorded for contingent losses related to other claims

- changed (2024-05-08):
[0001596532-24-000173:note_history:7]
and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.
  (was, 2023-10-31, similarity 0.8653):
[0001596532-23-000274:note_history:7]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2023, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse 
impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-08):
[0001596532-24-000173:note_history:8]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of next generation data center, campus and routing environments. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.
  (was, 2023-10-31, similarity 0.9806):
[0001596532-23-000274:note_history:8]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of next generation data center and campus workspace environments. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

- changed (2024-05-08):
[0001596532-24-000173:note_history:9]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2024, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2023 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.
  (was, 2023-10-31, similarity 0.9807):
[0001596532-23-000274:note_history:9]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2023, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2022 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

- changed (2024-05-08):
[0001596532-24-000173:note_history:10]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including inflation, monetary policy shifts, recession risks, and potential supply chain and other disruptions such as the Russia-Ukraine and Israel-Hamas conflicts, the Houthi attacks on marine vessels in the Red Sea and the U.S. trade war with China.
  (was, 2023-10-31, similarity 0.8269):
[0001596532-23-000274:note_history:10]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including inflation, monetary policy shifts, the recent banking crisis, recession risks, and potential supply chain and other disruptions from the Russia-Ukraine and Israel-Hamas conflicts, and the U.S. trade war with China.

- added (2024-05-08):
[0001596532-24-000173:note_history:11]
Our business is emerging from a period of unprecedented global supply chain disruptions.  Throughout this period, we made significant supply chain investments, including funding additional working capital and incremental purchase commitments in response to extended visibility to deployment plans from our customers. We have worked closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. Increased capacity has allowed us to ship products against previously committed demand/deployment plans and accelerate some deployments where needed, while trying to limit building customer inventory and to some extent balancing customer lead times with those currently experienced from our key suppliers. As a result, some shipments against these previously committed demand/deployment plans have extended into 2024.

- added (2024-05-08):
[0001596532-24-000173:note_history:12]
As the global supply chain has experienced some improvements and as customer lead times have been reduced from their peak, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to shorter demand-planning horizons resulting in lower demand levels.  Given these shipment and order patterns, near

- added (2024-05-08):
[0001596532-24-000173:note_history:13]
term revenue trends may not be solely reflective of current demand levels, but as discussed above will benefit from demand/deployment plans that had been previously committed. While inventory and working capital levels may remain elevated in the near term, we expect that purchase commitments will begin to level off as supplier lead times shorten, but will remain volatile as we ramp new product introductions. The larger magnitude of these balances, combined with a reduction in customer demand-planning horizons and shifting customer product priorities, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted, and may in the future result, in additional excess and obsolete inventory and supplier liability charges.

- added (2024-05-08):
[0001596532-24-000173:note_history:14]
In addition, inflation pressure in our supply chain, scarcity of some materials needed to build our products and disruptions to our manufacturing process have increased our cost of revenue and have impacted, and may continue to negatively impact, our gross margin. Our operating cash-flows have also been and may continue to be negatively impacted by significant component inventories on hand or at our contract manufacturers. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the Russia-Ukraine conflict, continued escalation of this conflict as well as the Israeli-Hamas conflict and Houthi movement in the Red Sea may negatively impact the global economy and our future operating results and financial condition.

- added (2024-05-08):
[0001596532-24-000173:note_history:15]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that some of our customers, following a year of elevated purchases, must now consider changing technology roadmaps and priorities, including the need for the deployment of AI and related technologies, resulting in some uncertainty as to future investment plans and a more constrained approach to some forecasts and orders in the near term. In addition, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.

- added (2024-05-08):
[0001596532-24-000173:note_history:16]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2024. Early adoption is permitted for annual financial statements that have not yet been issued. The amendments should be applied on a prospective basis although retrospective application is permitted. As of March 31, 2024, we have not early adopted ASU 2023-09 and we are currently evaluating the impact of future adoption on our financial disclosures.

- added (2024-05-08):
[0001596532-24-000173:note_history:17]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280)-Improvements to Reportable Segment Disclosures. The ASU requires that an entity disclose significant segment expenses impacting profit and loss that are regularly provided to the chief operating decision maker. The update is required to be applied retrospectively to prior periods presented, based on the significant segment expense categories identified and disclosed in the period of adoption. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. As of March 31, 2024, we have not early adopted ASU 2023-07 and we are currently evaluating the impact of future adoption on our financial disclosures.

- removed (2024-05-08):
[0001596532-23-000274:note_history:18]
We have worked closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. We have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, and have begun to see some reduction in customer lead times on certain products. Over time, the recovery of capacity should allow us to ship products against previously committed deployment plans and accelerate some deployments where needed, while trying to limit building customer inventory.  On this basis, we expect some shipments against these deployment plans to extend into 2024. As customer lead times reduce more broadly, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to somewhat shorter demand-planning horizons which has resulted in lower demand levels.  Given the shipment and order patterns described above, near term revenue trends may not be reflective of current demand levels, but will benefit from deployment plans that had been previously committed. While inventory and working capital levels may continue to increase and remain elevated in the near term, we expect that purchase commitments will continue to decline as supplier lead times shorten.  Although these elevated inventory positions and purchase commitments are largely related to

- removed (2024-05-08):
[0001596532-23-000274:note_history:19]
relatively early life cycle products, the larger magnitude of these balances, combined with a reduction in customer demand-planning horizons, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted, and may in the future result, in the need for us to incur excess and obsolete inventory-related charges.

- removed (2024-05-08):
[0001596532-23-000274:note_history:20]
In addition, inflation pressure in our supply chain, scarcity of some materials needed to build our products and disruptions to our manufacturing process have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. Our operating cash-flows have also been and may continue to be negatively impacted by significant component inventories on hand or at our contract manufacturers. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the recent conflicts between Russia-Ukraine, continued escalation of this conflict as well as the Israeli-Hamas conflict may negatively impact the global economy and our future operating results and financial condition.

- removed (2024-05-08):
[0001596532-23-000274:note_history:21]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable; however, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that some of our customers, following a year of elevated purchases, must now consider changing technology roadmaps and priorities, including the need for the rapid deployment of AI and related technologies, resulting in some uncertainty as to future investment plans and a more constrained approach to some forecasts and orders in the near term. In addition, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

- removed (2024-05-08):
[0001596532-23-000274:note_history:22]
We believe that all recently issued accounting pronouncements from the FASB will not have a material impact on our Consolidated Financial Statements or do not apply to our operations.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-05-08):
[0001596532-24-000173:note_history:23]
|  |  | March 31, 2024 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 730,912 |  |  | $ | (2,688) |  |  | $ | — |  |  | $ | — |  |  | $ | 730,912 |  |  | $ | (2,688) |  |
| Corporate bonds |  | 1,330,835 |  |  | (3,944) |  |  | 68,345 |  |  | (198) |  |  | 1,399,180 |  |  | (4,142) |  |
| Agency securities |  | 424,306 |  |  | (1,124) |  |  | 9,979 |  |  | (53) |  |  | 434,285 |  |  | (1,177) |  |
| Total |  | $ | 2,486,053 |  |  | $ | (7,756) |  |  | $ | 78,324 |  |  | $ | (251) |  |  | $ | 2,564,377 |  |  | $ | (8,007) |  |

- removed (2024-05-08):
[0001596532-23-000274:note_history:24]
|  |  | September 30, 2023 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 688,395 |  |  | $ | (3,625) |  |  | $ | 182,156 |  |  | $ | (1,702) |  |  | $ | 870,551 |  |  | $ | (5,327) |  |
| Corporate bonds |  | 925,541 |  |  | (5,928) |  |  | 163,152 |  |  | (1,789) |  |  | 1,088,693 |  |  | (7,717) |  |
| Agency securities |  | 542,013 |  |  | (3,158) |  |  | 62,479 |  |  | (582) |  |  | 604,492 |  |  | (3,740) |  |
| Total |  | $ | 2,155,949 |  |  | $ | (12,711) |  |  | $ | 407,787 |  |  | $ | (4,073) |  |  | $ | 2,563,736 |  |  | $ | (16,784) |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2024-05-08):
[0001596532-24-000173:note_history:25]
Subsequent Events
Stock Repurchases

- added (2024-05-08):
[0001596532-24-000173:note_history:26]
On May 3, 2024, our board of directors authorized a new $1.2 billion stock repurchase program (the “New Repurchase Program”, together with the “Existing Repurchase Program,” the “Repurchase Programs”), which commences in May 2024 and expires in May 2027. This authorization allows us to repurchase shares of our common stock that will be funded from working capital. Repurchases may be made at management's discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Exchange Act, or a combination of the foregoing. In April 2024, we repurchased an additional $82.0 million shares of our common stock which completed our repurchases under the Existing Repurchase Program. The Repurchase Programs do not obligate Arista to acquire any of its common stock, and may be suspended or discontinued by the company at any time without prior notice.

- added (2024-05-08):
[0001596532-24-000173:note_history:27]
Equity Incentive Plan

- added (2024-05-08):
[0001596532-24-000173:note_history:28]
On April 17, 2024, our board of directors, acting upon the recommendation of the Compensation Committee of our board of directors, adopted an amendment, restatement and extension of the Arista Networks, Inc. 2014 Equity Incentive Plan (the “Restated Plan”), effective April 17, 2024 (the “Effective Date”), subject to approval of our stockholders at our 2024 Annual Meeting of Stockholders.

- added (2024-05-08):
[0001596532-24-000173:note_history:29]
The Restated Plan provides for the grant of equity-based awards, including stock options, restricted stock units, restricted stock, stock appreciation rights, and performance awards.  The share pool available under the prior version of our 2014 Equity Incentive Plan (the “Prior Plan”) was extinguished as of the Effective Date, and the Restated Plan provides for a new share pool not to exceed (i) 13,200,000 shares of our Common Stock (“Shares”), plus (ii) any Shares subject to awards under the Prior Plan that, on or after the Effective Date, expire or otherwise terminate without having been exercised in full, or that are forfeited to or repurchased by us, including net settlement of Shares subject to restricted stock units, with the maximum number of Shares to be added to the Restated Plan as a result of clause (ii) equal to 10,039,657 Shares. The Restated Plan’s terms are substantially similar to the Prior Plan’s terms, including with respect to treatment of equity awards in the event of a “change in control” as defined under the Restated Plan, but with certain modifications, including the elimination of the automatic “evergreen” share reserve increase provided for under the Prior Plan.

- added (2024-05-08):
[0001596532-24-000173:note_history:30]
The Restated Plan will be subject to approval of our stockholders at the 2024 Annual Meeting of Stockholders. If stockholder approval of the Restated Plan is not obtained at the 2024 Annual Meeting of Stockholders, then any award granted under the Restated Plan will be forfeited. In accordance with New York Stock Exchange Listing Rule 303A.08, no Shares underlying awards granted on or after the Effective Date shall be issued until stockholder approval is obtained.
The foregoing description of the Restated Plan is not complete and is qualified in its entirety by reference to the full text thereof, a copy of which is attached as Exhibit 3.1 to our Current Report on Form 8-K filed on April 23, 2024
