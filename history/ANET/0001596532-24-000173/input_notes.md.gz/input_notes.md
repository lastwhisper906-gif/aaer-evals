# ANET notes — 0001596532-24-000173


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-24-000173:notes:1]
[same as prior period, unchanged from 0001596532-23-000274:notes:1]

[0001596532-24-000173:notes:2]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of next generation data center, campus and routing environments. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-24-000173:notes:3]
[same as prior period, unchanged from 0001596532-23-000274:notes:3]

[0001596532-24-000173:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three months ended March 31, 2024, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2023 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

[0001596532-24-000173:notes:5]
Our condensed consolidated financial statements and related financial information in this Quarterly Report on Form 10-Q should be read in conjunction with the audited consolidated financial statements and related footnotes included in our Annual Report on Form 10-K for the fiscal year ended December 31, 2023, filed with the SEC on February 12, 2024.

[0001596532-24-000173:notes:6]
[same as prior period, unchanged from 0001596532-23-000274:notes:6]

[0001596532-24-000173:notes:7]
[same as prior period, unchanged from 0001596532-23-000274:notes:7]

[0001596532-24-000173:notes:8]
[same as prior period, unchanged from 0001596532-23-000274:notes:8]

[0001596532-24-000173:notes:9]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including inflation, monetary policy shifts, recession risks, and potential supply chain and other disruptions such as the Russia-Ukraine and Israel-Hamas conflicts, the Houthi attacks on marine vessels in the Red Sea and the U.S. trade war with China.

[0001596532-24-000173:notes:10]
Our business is emerging from a period of unprecedented global supply chain disruptions.  Throughout this period, we made significant supply chain investments, including funding additional working capital and incremental purchase commitments in response to extended visibility to deployment plans from our customers. We have worked closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. Increased capacity has allowed us to ship products against previously committed demand/deployment plans and accelerate some deployments where needed, while trying to limit building customer inventory and to some extent balancing customer lead times with those currently experienced from our key suppliers. As a result, some shipments against these previously committed demand/deployment plans have extended into 2024.

[0001596532-24-000173:notes:11]
As the global supply chain has experienced some improvements and as customer lead times have been reduced from their peak, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to shorter demand-planning horizons resulting in lower demand levels.  Given these shipment and order patterns, near

[0001596532-24-000173:notes:12]
term revenue trends may not be solely reflective of current demand levels, but as discussed above will benefit from demand/deployment plans that had been previously committed. While inventory and working capital levels may remain elevated in the near term, we expect that purchase commitments will begin to level off as supplier lead times shorten, but will remain volatile as we ramp new product introductions. The larger magnitude of these balances, combined with a reduction in customer demand-planning horizons and shifting customer product priorities, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted, and may in the future result, in additional excess and obsolete inventory and supplier liability charges.

[0001596532-24-000173:notes:13]
In addition, inflation pressure in our supply chain, scarcity of some materials needed to build our products and disruptions to our manufacturing process have increased our cost of revenue and have impacted, and may continue to negatively impact, our gross margin. Our operating cash-flows have also been and may continue to be negatively impacted by significant component inventories on hand or at our contract manufacturers. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the Russia-Ukraine conflict, continued escalation of this conflict as well as the Israeli-Hamas conflict and Houthi movement in the Red Sea may negatively impact the global economy and our future operating results and financial condition.

[0001596532-24-000173:notes:14]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that some of our customers, following a year of elevated purchases, must now consider changing technology roadmaps and priorities, including the need for the deployment of AI and related technologies, resulting in some uncertainty as to future investment plans and a more constrained approach to some forecasts and orders in the near term. In addition, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.

[0001596532-24-000173:notes:15]
[same as prior period, unchanged from 0001596532-23-000274:notes:14]

[0001596532-24-000173:notes:16]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2024. Early adoption is permitted for annual financial statements that have not yet been issued. The amendments should be applied on a prospective basis although retrospective application is permitted. As of March 31, 2024, we have not early adopted ASU 2023-09 and we are currently evaluating the impact of future adoption on our financial disclosures.

[0001596532-24-000173:notes:17]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280)-Improvements to Reportable Segment Disclosures. The ASU requires that an entity disclose significant segment expenses impacting profit and loss that are regularly provided to the chief operating decision maker. The update is required to be applied retrospectively to prior periods presented, based on the significant segment expense categories identified and disclosed in the period of adoption. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. As of March 31, 2024, we have not early adopted ASU 2023-07 and we are currently evaluating the impact of future adoption on our financial disclosures.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-24-000173:notes:18]
[same as prior period, unchanged from 0001596532-23-000274:notes:16]

[0001596532-24-000173:notes:19]
We measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value on a recurring basis. The following tables summarize the fair value of these financial assets by significant investment category and their levels within the fair value hierarchy (in thousands):

[0001596532-24-000173:notes:20]
|  |  | March 31, 2024 |  | December 31, 2023 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,035,025 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,035,025 |  |  | $ | 1,015,705 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,015,705 |  |
| Commercial paper |  | — |  |  | 8,980 |  |  | — |  |  | 8,980 |  |  | — |  |  | 1,999 |  |  | — |  |  | 1,999 |  |
| Corporate bonds |  | — |  |  | 1,988 |  |  | — |  |  | 1,988 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government notes |  | 310,801 |  |  | — |  |  | — |  |  | 310,801 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | 1,345,826 |  |  | 10,968 |  |  | — |  |  | 1,356,794 |  |  | 1,015,705 |  |  | 1,999 |  |  | — |  |  | 1,017,704 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 15,640 |  |  | — |  |  | 15,640 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposits(1) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5,000 |  |  | — |  |  | 5,000 |  |
| U.S. government notes |  | 1,236,709 |  |  | — |  |  | — |  |  | 1,236,709 |  |  | 1,044,859 |  |  | — |  |  | — |  |  | 1,044,859 |  |
| Corporate bonds |  | — |  |  | 1,554,965 |  |  | — |  |  | 1,554,965 |  |  | — |  |  | 1,362,124 |  |  | — |  |  | 1,362,124 |  |
| Agency securities |  | — |  |  | 550,283 |  |  | — |  |  | 550,283 |  |  | — |  |  | 657,379 |  |  | — |  |  | 657,379 |  |
|  |  | 1,236,709 |  |  | 2,120,888 |  |  | — |  |  | 3,357,597 |  |  | 1,044,859 |  |  | 2,024,503 |  |  | — |  |  | 3,069,362 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 860 |  |  | — |  |  | — |  |  | 860 |  |  | 858 |  |  | — |  |  | — |  |  | 858 |  |
| Total Financial Assets |  | $ | 2,583,395 |  |  | $ | 2,131,856 |  |  | $ | — |  |  | $ | 4,715,251 |  |  | $ | 2,061,422 |  |  | $ | 2,026,502 |  |  | $ | — |  |  | $ | 4,087,924 |  |

[0001596532-24-000173:notes:21]
[same as prior period, unchanged from 0001596532-23-000274:notes:19]

[0001596532-24-000173:notes:22]
(1) As of December 31, 2023, all of our certificates of deposits were domestic deposits.

[0001596532-24-000173:notes:23]
During the three months ended March 31, 2024, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-24-000173:notes:24]
[same as prior period, unchanged from 0001596532-23-000274:notes:23]

[0001596532-24-000173:notes:25]
[same as prior period, unchanged from 0001596532-23-000274:notes:24]

[0001596532-24-000173:notes:26]
|  |  | March 31, 2024 |  | December 31, 2023 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 15,640 |  |  | $ | — |  |  | $ | — |  |  | $ | 15,640 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| U.S. government |  | 1,238,929 |  |  | 468 |  |  | (2,688) |  |  | 1,236,709 |  |  | 1,043,445 |  |  | 2,874 |  |  | (1,460) |  |  | 1,044,859 |  |
| Corporate bonds |  | 1,558,489 |  |  | 618 |  |  | (4,142) |  |  | 1,554,965 |  |  | 1,361,132 |  |  | 2,810 |  |  | (1,818) |  |  | 1,362,124 |  |
| Agency securities |  | 551,315 |  |  | 145 |  |  | (1,177) |  |  | 550,283 |  |  | 657,118 |  |  | 1,143 |  |  | (882) |  |  | 657,379 |  |
| Total |  | $ | 3,364,373 |  |  | $ | 1,231 |  |  | $ | (8,007) |  |  | $ | 3,357,597 |  |  | $ | 3,061,695 |  |  | $ | 6,827 |  |  | $ | (4,160) |  |  | $ | 3,064,362 |  |

[0001596532-24-000173:notes:27]
For debt securities in unrealized loss positions, it is not likely that we will be required to sell such securities before recovery of their amortized cost basis nor do we have the intent to sell such securities before maturity. We invest in debt securities that have maximum maturities of two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. Given the short-term and conservative nature of our portfolio, our debt securities are generally not subject to credit risk; therefore, we did not recognize any credit losses or non-credit-related impairments related to

[0001596532-24-000173:notes:28]
such securities for the three months ended March 31, 2024. All unrealized losses were recognized in other comprehensive income (loss). Realized gains or losses were immaterial for the three months ended March 31, 2024.

[0001596532-24-000173:notes:29]
[same as prior period, unchanged from 0001596532-23-000274:notes:27]

[0001596532-24-000173:notes:30]
|  |  | March 31, 2024 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 730,912 |  |  | $ | (2,688) |  |  | $ | — |  |  | $ | — |  |  | $ | 730,912 |  |  | $ | (2,688) |  |
| Corporate bonds |  | 1,330,835 |  |  | (3,944) |  |  | 68,345 |  |  | (198) |  |  | 1,399,180 |  |  | (4,142) |  |
| Agency securities |  | 424,306 |  |  | (1,124) |  |  | 9,979 |  |  | (53) |  |  | 434,285 |  |  | (1,177) |  |
| Total |  | $ | 2,486,053 |  |  | $ | (7,756) |  |  | $ | 78,324 |  |  | $ | (251) |  |  | $ | 2,564,377 |  |  | $ | (8,007) |  |

[0001596532-24-000173:notes:31]
As of March 31, 2024, we had no marketable debt securities with contractual maturities that exceeded 24 months. The fair values of marketable debt securities, by remaining contractual maturities, are as follows (in thousands):

[0001596532-24-000173:notes:32]
|  |  | March 31, 2024 |
|  |  | Fair Value |
| Due in 1 year or less |  | $ | 1,774,688 |  |
| Due in 1 to 2 years |  | 1,582,909 |  |
| Total debt securities |  | $ | 3,357,597 |  |

[0001596532-24-000173:notes:33]
The weighted-average remaining duration of our marketable debt securities is approximately 0.9 years as of March 31, 2024. As we view these marketable debt securities as available to support current operations, we classify marketable debt securities with maturities beyond 12 months as current assets under the caption "Marketable securities" on the condensed consolidated balance sheets.

[0001596532-24-000173:notes:34]
[same as prior period, unchanged from 0001596532-23-000274:notes:32]

[0001596532-24-000173:notes:35]
[same as prior period, unchanged from 0001596532-23-000274:notes:33]

[0001596532-24-000173:notes:36]
[same as prior period, unchanged from 0001596532-23-000274:notes:34]

[0001596532-24-000173:notes:37]
We did not record any realized or unrealized gains, or realized losses for our non-marketable equity securities during the three months ended March 31, 2024 and March 31, 2023, and we recorded nil and an immaterial amount of unrealized losses for the three months ended  March 31, 2024 and March 31, 2023, respectively.

[0001596532-24-000173:notes:38]
[same as prior period, unchanged from 0001596532-23-000274:notes:38]

[0001596532-24-000173:notes:39]
The following table summarizes the activity related to our non-marketable equity securities as of March 31, 2024 and December 31, 2023 (in thousands):

[0001596532-24-000173:notes:40]
|  |  | March 31, 2024 |  | December 31, 2023 |
| Cost of investments |  | $ | 32,656 |  |  | $ | 31,656 |  |
| Cumulative impairment and downward adjustment |  | — |  |  | — |  |
| Cumulative upward adjustment |  | 30,632 |  |  | 30,632 |  |
| Carrying amount of investments |  | $ | 63,288 |  |  | $ | 62,288 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-24-000173:notes:41]
[same as prior period, unchanged from 0001596532-23-000274:notes:42]

[0001596532-24-000173:notes:42]
(1) As of December 31, 2023, all of our certificates of deposits were domestic deposits.
The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities measured at fair value on a recurring basis (in thousands):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-24-000173:notes:43]
[same as prior period, unchanged from 0001596532-23-000274:notes:44]

[0001596532-24-000173:notes:44]
[same as prior period, unchanged from 0001596532-23-000274:notes:45]

[0001596532-24-000173:notes:45]
|  |  | March 31, 2024 |  | December 31, 2023 |
| Cash and cash equivalents |  | $ | 2,092,101 |  |  | $ | 1,938,606 |  |
| Restricted cash included in other assets |  | 860 |  |  | 858 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 2,092,961 |  |  | $ | 1,939,464 |  |

[0001596532-24-000173:notes:46]
[same as prior period, unchanged from 0001596532-23-000274:notes:47]

[0001596532-24-000173:notes:47]
[same as prior period, unchanged from 0001596532-23-000274:notes:48]

[0001596532-24-000173:notes:48]
|  |  | March 31, 2024 |  | December 31, 2023 |
| Accounts receivable |  | $ | 1,098,983 |  |  | $ | 1,034,480 |  |
| Product sales rebate and returns reserve |  | (8,942) |  |  | (9,911) |  |
| Accounts receivable, net |  | $ | 1,090,041 |  |  | $ | 1,024,569 |  |

[0001596532-24-000173:notes:49]
[same as prior period, unchanged from 0001596532-23-000274:notes:50]

[0001596532-24-000173:notes:50]
[same as prior period, unchanged from 0001596532-23-000274:notes:51]

[0001596532-24-000173:notes:51]
|  |  | March 31, 2024 |  | December 31, 2023 |
| Raw materials |  | $ | 979,947 |  |  | $ | 930,777 |  |
| Finished goods |  | 1,045,257 |  |  | 1,014,403 |  |
| Total inventories |  | $ | 2,025,204 |  |  | $ | 1,945,180 |  |

[0001596532-24-000173:notes:52]
[same as prior period, unchanged from 0001596532-23-000274:notes:56]

[0001596532-24-000173:notes:53]
[same as prior period, unchanged from 0001596532-23-000274:notes:57]

[0001596532-24-000173:notes:54]
|  |  | March 31, 2024 |  | December 31, 2023 |
| Land |  | $ | 45,160 |  |  | $ | 44,645 |  |
| Equipment and machinery |  | 152,410 |  |  | 144,850 |  |
| Computer hardware and software |  | 58,448 |  |  | 57,761 |  |
| Leasehold improvements |  | 34,706 |  |  | 34,584 |  |
| Furniture and fixtures |  | 3,563 |  |  | 3,576 |  |
| Construction-in-process |  | 338 |  |  | 4,242 |  |
| Property and equipment, gross |  | 294,625 |  |  | 289,658 |  |
| Less: accumulated depreciation |  | (196,676) |  |  | (188,078) |  |
| Property and equipment, net |  | $ | 97,949 |  |  | $ | 101,580 |  |

[0001596532-24-000173:notes:55]
Depreciation expense was $8.6 million and $7.1 million for the three months ended March 31, 2024 and 2023, respectively.

[0001596532-24-000173:notes:56]
[same as prior period, unchanged from 0001596532-23-000274:notes:60]

[0001596532-24-000173:notes:57]
[same as prior period, unchanged from 0001596532-23-000274:notes:61]

[0001596532-24-000173:notes:58]
|  |  | March 31, 2024 |  | December 31, 2023 |
| Accrued compensation-related costs |  | $ | 62,920 |  |  | $ | 134,225 |  |
| Accrued supplier liability |  | 95,392 |  |  | 167,878 |  |
| Accrued manufacturing costs |  | 61,036 |  |  | 61,491 |  |
| Accrued product development costs |  | 10,063 |  |  | 1,041 |  |
| Other |  | 41,175 |  |  | 42,667 |  |
| Total accrued liabilities |  | $ | 270,586 |  |  | $ | 407,302 |  |

[0001596532-24-000173:notes:59]
[same as prior period, unchanged from 0001596532-23-000274:notes:63]

[0001596532-24-000173:notes:60]
[same as prior period, unchanged from 0001596532-23-000274:notes:64]

[0001596532-24-000173:notes:61]
[same as prior period, unchanged from 0001596532-23-000274:notes:65]

[0001596532-24-000173:notes:62]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Contract liabilities, beginning balance |  | $ | 133,239 |  |  | $ | 103,448 |  |  |  |  |  |
| Less: Revenue recognized from beginning balance |  | (12,000) |  |  | (9,243) |  |  |  |  |  |
| Less: Beginning balance reclassified to deferred revenue |  | (6,498) |  |  | (4,382) |  |  |  |  |  |
| Add: Contract liabilities recognized |  | 24,877 |  |  | 15,224 |  |  |  |  |  |
| Contract liabilities, ending balance |  | $ | 139,618 |  |  | $ | 105,047 |  |  |  |  |  |

[0001596532-24-000173:notes:63]
As of March 31, 2024 and December 31, 2023, $59.4 million and $59.2 million of our contract liabilities, respectively, were included in "Other current liabilities" with the remaining balances included in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001596532-24-000173:notes:64]
[same as prior period, unchanged from 0001596532-23-000274:notes:68]

[0001596532-24-000173:notes:65]
Deferred revenue is comprised mainly of unearned revenue related to multi-year post-contract support ("PCS") contracts, services and product deferrals related to contracts with acceptance clauses. The following table summarizes the activity related to our deferred revenue (in thousands):

[0001596532-24-000173:notes:66]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Deferred revenue, beginning balance |  | $ | 1,506,204 |  |  | $ | 1,041,246 |  |  |  |  |  |
| Less: Revenue recognized from beginning balance |  | (284,283) |  |  | (214,450) |  |  |  |  |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 441,321 |  |  | 265,478 |  |  |  |  |  |
| Deferred revenue, ending balance |  | $ | 1,663,242 |  |  | $ | 1,092,274 |  |  |  |  |  |

[0001596532-24-000173:notes:67]
[same as prior period, unchanged from 0001596532-23-000274:notes:71]

[0001596532-24-000173:notes:68]
Other performance obligations totaling $809.0 million as of March 31, 2024 include unbilled multi-year PCS and service contract amounts of $543.5 million and $265.5 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-24-000173:notes:69]
[same as prior period, unchanged from 0001596532-23-000274:notes:73]

[0001596532-24-000173:notes:70]
Total revenue from our contract liabilities, deferred revenue and other performance obligations that is expected to be recognized in future periods amounts to $2.6 billion as of March 31, 2024. Approximately 79% of this future revenue is expected to be recognized over the next two years and the remaining 21% is expected to be recognized during the third to the fifth year.

[0001596532-24-000173:notes:71]
[same as prior period, unchanged from 0001596532-23-000274:notes:75]

[0001596532-24-000173:notes:72]
[same as prior period, unchanged from 0001596532-23-000274:notes:76]

[0001596532-24-000173:notes:73]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Interest income |  | $ | 63,823 |  |  | $ | 22,509 |  |  |  |  |  |
| Gain (loss) on strategic investments |  | — |  |  | (5,571) |  |  |  |  |  |
| Other income (expense), net |  | (1,203) |  |  | (4,792) |  |  |  |  |  |
| Total |  | $ | 62,620 |  |  | $ | 12,146 |  |  |  |  |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-24-000173:notes:74]
[same as prior period, unchanged from 0001596532-23-000274:notes:78]

[0001596532-24-000173:notes:75]
[same as prior period, unchanged from 0001596532-23-000274:notes:79]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-24-000173:notes:76]
[same as prior period, unchanged from 0001596532-23-000274:notes:80]

[0001596532-24-000173:notes:77]
We had no business acquisitions during the three months ended March 31, 2024 and 2023.

[0001596532-24-000173:notes:78]
[same as prior period, unchanged from 0001596532-23-000274:notes:83]

[0001596532-24-000173:notes:79]
No changes were made to the carrying values of goodwill for the three months ended March 31, 2024 and 2023.

[0001596532-24-000173:notes:80]
[same as prior period, unchanged from 0001596532-23-000274:notes:85]

[0001596532-24-000173:notes:81]
[same as prior period, unchanged from 0001596532-23-000274:notes:86]

[0001596532-24-000173:notes:82]
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life (in years) |
|  | December 31, 2023 |  | Additions |  | March 31, 2024 |  | December 31, 2023 |  | Amortization |  | March 31, 2024 |  | December 31, 2023 |  | March 31, 2024 |  |
| Developed technology | $ | 154,930 |  |  | $ | — |  |  | $ | 154,930 |  |  | $ | (102,493) |  |  | $ | (4,194) |  |  | $ | (106,687) |  |  | $ | 52,437 |  |  | $ | 48,243 |  |  | 3.8 |
| Customer relationships | 54,620 |  |  | — |  |  | 54,620 |  |  | (21,797) |  |  | (1,926) |  |  | (23,723) |  |  | 32,823 |  |  | 30,897 |  |  | 4.5 |
| Trade name | 12,390 |  |  | — |  |  | 12,390 |  |  | (8,882) |  |  | (570) |  |  | (9,452) |  |  | 3,508 |  |  | 2,938 |  |  | 1.3 |
| Total | $ | 221,940 |  |  | $ | — |  |  | $ | 221,940 |  |  | $ | (133,172) |  |  | $ | (6,690) |  |  | $ | (139,862) |  |  | $ | 88,768 |  |  | $ | 82,078 |  |  | 4.0 |

[0001596532-24-000173:notes:83]
Amortization expense related to acquisition-related intangible assets was $6.7 million and $9.3 million for the three months ended March 31, 2024 and 2023, respectively.

[0001596532-24-000173:notes:84]
As of March 31, 2024, future estimated amortization expense related to the acquisition-related intangible assets is as follows (in thousands):

[0001596532-24-000173:notes:85]
|  |  | Future Amortization Expense |
| Remainder of 2024 |  | $ | 20,069 |  |
| 2025 |  | 19,642 |  |
| 2026 |  | 17,260 |  |
| 2027 |  | 13,436 |  |
| 2028 |  | 10,037 |  |
| Thereafter |  | 1,634 |  |
| Total |  | $ | 82,078 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-24-000173:notes:86]
Commitments and Contingencies
Leases

[0001596532-24-000173:notes:87]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of March 31, 2024, we had lease payment obligations, net of immaterial sublease income, of $65.9 million, with $23.7 million payable within one year.

[0001596532-24-000173:notes:88]
Purchase Commitments

[0001596532-24-000173:notes:89]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of March 31, 2024, we had non-cancellable purchase commitments not recorded on our balance sheet of $1,457.7 million, of which $1,425.1 million have expected receipt dates within 12 months, and $32.6 million have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-24-000173:notes:90]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $131.8 million and $133.3 million as of March 31, 2024 and December 31, 2023, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

[0001596532-24-000173:notes:91]
Guarantees

[0001596532-24-000173:notes:92]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-24-000173:notes:93]
Legal Proceedings

[0001596532-24-000173:notes:94]
WSOU Investments, LLC

[0001596532-24-000173:notes:95]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement. On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit. On May 30, 2023, the US Patent Trial and Appeal Board (“PTAB”) ruled all challenged claims in the inter partes review unpatentable. The district court case remains stayed pending appeal and/or final resolution of the PTAB ruling.

[0001596532-24-000173:notes:96]
We intend to vigorously defend against the claims brought against us by WSOU; however, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-24-000173:notes:97]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated; however, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-24-000173:notes:98]
Other matters

[0001596532-24-000173:notes:99]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-24-000173:notes:100]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of March 31, 2024, provisions recorded for contingent losses related to other claims

[0001596532-24-000173:notes:101]
and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-24-000173:notes:102]
[same as prior period, unchanged from 0001596532-23-000274:notes:104]

[0001596532-24-000173:notes:103]
In October 2021, our board of directors authorized a $1.0 billion stock repurchase program (the “Existing Repurchase Program”). This authorization allows us to repurchase shares of our common stock that will be funded from working capital and expires in October 2024. Repurchases may be made at management's discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the "Exchange Act"), or a combination of the foregoing. The Existing Repurchase Program, does not obligate us to acquire any of our common stock and may be suspended or discontinued by the company at any time without prior notice. As of March 31, 2024, the remaining authorized amount for stock repurchases under the Existing Repurchase Program was approximately $82.0 million. In April 2024, we repurchased the remaining $82.0 million of our common stock authorized under the Existing Repurchase Program.

[0001596532-24-000173:notes:104]
A summary of the stock repurchase activity under the Existing Repurchase Program for the three months ended March 31, 2024 is as follows (in thousands, except per share amounts):

[0001596532-24-000173:notes:105]
|  |  |  |  | Three Months Ended |
|  |  |  |  | March 31, 2024 |
| Aggregate purchase price |  |  |  | $ | 62,653 |  |
| Shares repurchased |  |  |  | 228 |  |
| Average price paid per share |  |  |  | $ | 274.82 |  |

[0001596532-24-000173:notes:106]
[same as prior period, unchanged from 0001596532-23-000274:notes:108]

[0001596532-24-000173:notes:107]
[same as prior period, unchanged from 0001596532-23-000274:notes:109]

[0001596532-24-000173:notes:108]
[same as prior period, unchanged from 0001596532-23-000274:notes:110]

[0001596532-24-000173:notes:109]
[same as prior period, unchanged from 0001596532-23-000274:notes:111]

[0001596532-24-000173:notes:110]
Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”). The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of the outstanding shares of our common stock on the immediately preceding December 31, but not to exceed 50 million shares, unless our board of directors, in its discretion, determines to make a smaller increase. As of March 31, 2024, there remained approximately 84.8 million shares available for grant under the 2014 Plan. The 2014 Plan (the “Existing Plan”) expired on April 17, 2024, and our board of directors have approved the amendment, restatement and extension of the 2014 Plan (the “Restated Plan”), reducing the number of shares available for future grants, subject to the approval of our stockholders at our 2024 Annual Meeting of Stockholders on June 7, 2024. Refer to Note 10 Subsequent Events of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10Q for future discussion.

[0001596532-24-000173:notes:111]
[same as prior period, unchanged from 0001596532-23-000274:notes:113]

[0001596532-24-000173:notes:112]
In April 2014, our board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding on the immediately preceding December 31, but not to exceed 10 million shares, unless our board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2024, our board of directors authorized an increase of 3.1 million shares to the shares available for issuance under the ESPP. During the three months ended March 31,

[0001596532-24-000173:notes:113]
2024, we issued 140,162 shares at a weighted-average purchase price of $114.40 per share under the ESPP. As of March 31, 2024, there remained approximately 26.4 million shares available for issuance under the ESPP.

[0001596532-24-000173:notes:114]
[same as prior period, unchanged from 0001596532-23-000274:notes:115]

[0001596532-24-000173:notes:115]
[same as prior period, unchanged from 0001596532-23-000274:notes:116]

[0001596532-24-000173:notes:116]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2023 |  | 2,457 |  |  | $ | 19.83 |  |  | 1.7 |  | $ | 529,931 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (679) |  |  | 13.41 |  |  |  |  |  |
| Options canceled |  | (24) |  |  | 20.07 |  |  |  |  |  |
| Balance—March 31, 2024 |  | 1,754 |  |  | $ | 22.32 |  |  | 1.8 |  | $ | 469,404 |  |
| Vested and exercisable—March 31, 2024 |  | 1,629 |  |  | $ | 20.98 |  |  | 1.6 |  | $ | 438,107 |  |

[0001596532-24-000173:notes:117]
[same as prior period, unchanged from 0001596532-23-000274:notes:118]

[0001596532-24-000173:notes:118]
[same as prior period, unchanged from 0001596532-23-000274:notes:119]

[0001596532-24-000173:notes:119]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |
| Unvested balance—December 31, 2023 |  | 7,900 |  |  | $ | 112.76 |  |
| RSUs and PRSUs granted |  | 508 |  |  | 262.15 |  |
| RSUs and PRSUs vested |  | (855) |  |  | 96.35 |  |
| RSUs and PRSUs forfeited/canceled |  | (195) |  |  | 106.54 |  |
| Unvested balance—March 31, 2024 |  | 7,358 |  |  | $ | 125.15 |  |

[0001596532-24-000173:notes:120]
[same as prior period, unchanged from 0001596532-23-000274:notes:121]

[0001596532-24-000173:notes:121]
[same as prior period, unchanged from 0001596532-23-000274:notes:122]

[0001596532-24-000173:notes:122]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Cost of revenue |  | $ | 3,450 |  |  | $ | 2,975 |  |  |  |  |  |
| Research and development |  | 43,788 |  |  | 36,569 |  |  |  |  |  |
| Sales and marketing |  | 18,901 |  |  | 15,138 |  |  |  |  |  |
| General and administrative |  | 11,076 |  |  | 8,199 |  |  |  |  |  |
| Total stock-based compensation |  | $ | 77,215 |  |  | $ | 62,881 |  |  |  |  |  |

[0001596532-24-000173:notes:123]
As of March 31, 2024, there were $746.0 million of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 3.6 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-24-000173:notes:124]
Net Income Per Share
    Basic net income per share is computed using the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed using the weighted-average number of shares of common stock outstanding during the period, including potential common shares assuming the dilutive effect of outstanding stock options, restricted stock units, and the employee stock purchase plan using the treasury stock method. Potential common shares whose

[0001596532-24-000173:notes:125]
effect would have been antidilutive are excluded from the computation of diluted net income per share. The following table sets forth the computation of our basic and diluted net income per share (in thousands, except per share amounts):

[0001596532-24-000173:notes:126]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 637,692 |  |  | $ | 436,473 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic weighted-average shares outstanding |  | 313,032 |  |  | 306,985 |  |  |  |  |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity awards |  | 6,833 |  |  | 8,593 |  |  |  |  |  |
| Diluted weighted-average shares outstanding |  | 319,865 |  |  | 315,578 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.04 |  |  | $ | 1.42 |  |  |  |  |  |
| Diluted |  | $ | 1.99 |  |  | $ | 1.38 |  |  |  |  |  |

[0001596532-24-000173:notes:127]
[same as prior period, unchanged from 0001596532-23-000274:notes:127]

[0001596532-24-000173:notes:128]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Employee equity awards |  | 166 |  |  | 374 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-24-000173:notes:129]
[same as prior period, unchanged from 0001596532-23-000274:notes:129]

[0001596532-24-000173:notes:130]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Income before income taxes |  | $ | 722,761 |  |  | $ | 496,724 |  |  |  |  |  |
| Provision for income taxes |  | 85,069 |  |  | 60,251 |  |  |  |  |  |
| Effective tax rate |  | 11.8 | % |  | 12.1 | % |  |  |  |  |

[0001596532-24-000173:notes:131]
The decrease in the effective tax rates in the three months ended March 31, 2024, as compared to the same period in 2023, was primarily due to a favorable change in the jurisdictional mix of earnings.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-24-000173:notes:132]
Geographical Information  
    We operate in one reportable segment. The following table represents revenue based on customers’ shipping addresses (in thousands):

[0001596532-24-000173:notes:133]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Americas(1) |  | $ | 1,255,391 |  |  | $ | 1,115,011 |  |  |  |  |  |
| Europe, Middle East and Africa |  | 141,554 |  |  | 128,316 |  |  |  |  |  |
| Asia-Pacific |  | 174,429 |  |  | 108,024 |  |  |  |  |  |
| Total revenue |  | $ | 1,571,374 |  |  | $ | 1,351,351 |  |  |  |  |  |

[0001596532-24-000173:notes:134]
(1) Includes $1,232.8 million and $1,094.6 million revenue generated from the U.S. for the three months ended March 31, 2024 and March 31, 2023, respectively.

[0001596532-24-000173:notes:135]
[same as prior period, unchanged from 0001596532-23-000274:notes:135]

[0001596532-24-000173:notes:136]
|  |  | March 31, 2024 |  | December 31, 2023 |
| United States |  | $ | 76,782 |  |  | $ | 79,728 |  |
| International |  | 21,167 |  |  | 21,852 |  |
| Total |  | $ | 97,949 |  |  | $ | 101,580 |  |


## us-gaap:SubsequentEventsTextBlock

[0001596532-24-000173:notes:137]
Subsequent Events
Stock Repurchases

[0001596532-24-000173:notes:138]
On May 3, 2024, our board of directors authorized a new $1.2 billion stock repurchase program (the “New Repurchase Program”, together with the “Existing Repurchase Program,” the “Repurchase Programs”), which commences in May 2024 and expires in May 2027. This authorization allows us to repurchase shares of our common stock that will be funded from working capital. Repurchases may be made at management's discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Exchange Act, or a combination of the foregoing. In April 2024, we repurchased an additional $82.0 million shares of our common stock which completed our repurchases under the Existing Repurchase Program. The Repurchase Programs do not obligate Arista to acquire any of its common stock, and may be suspended or discontinued by the company at any time without prior notice.

[0001596532-24-000173:notes:139]
Equity Incentive Plan

[0001596532-24-000173:notes:140]
On April 17, 2024, our board of directors, acting upon the recommendation of the Compensation Committee of our board of directors, adopted an amendment, restatement and extension of the Arista Networks, Inc. 2014 Equity Incentive Plan (the “Restated Plan”), effective April 17, 2024 (the “Effective Date”), subject to approval of our stockholders at our 2024 Annual Meeting of Stockholders.

[0001596532-24-000173:notes:141]
The Restated Plan provides for the grant of equity-based awards, including stock options, restricted stock units, restricted stock, stock appreciation rights, and performance awards.  The share pool available under the prior version of our 2014 Equity Incentive Plan (the “Prior Plan”) was extinguished as of the Effective Date, and the Restated Plan provides for a new share pool not to exceed (i) 13,200,000 shares of our Common Stock (“Shares”), plus (ii) any Shares subject to awards under the Prior Plan that, on or after the Effective Date, expire or otherwise terminate without having been exercised in full, or that are forfeited to or repurchased by us, including net settlement of Shares subject to restricted stock units, with the maximum number of Shares to be added to the Restated Plan as a result of clause (ii) equal to 10,039,657 Shares. The Restated Plan’s terms are substantially similar to the Prior Plan’s terms, including with respect to treatment of equity awards in the event of a “change in control” as defined under the Restated Plan, but with certain modifications, including the elimination of the automatic “evergreen” share reserve increase provided for under the Prior Plan.

[0001596532-24-000173:notes:142]
The Restated Plan will be subject to approval of our stockholders at the 2024 Annual Meeting of Stockholders. If stockholder approval of the Restated Plan is not obtained at the 2024 Annual Meeting of Stockholders, then any award granted under the Restated Plan will be forfeited. In accordance with New York Stock Exchange Listing Rule 303A.08, no Shares underlying awards granted on or after the Effective Date shall be issued until stockholder approval is obtained.
The foregoing description of the Restated Plan is not complete and is qualified in its entirety by reference to the full text thereof, a copy of which is attached as Exhibit 3.1 to our Current Report on Form 8-K filed on April 23, 2024


## ecd:MtrlTermsOfTrdArrTextBlock

[0001596532-24-000173:notes:143]
On March 14, 2024, Kenneth Duda, our Chief Technology Officer, Senior Vice President, Software Engineering and Director, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 480,000 shares of our common stock held in various trusts for the benefit of Mr. Duda’s family, for which Mr. Duda is the beneficial owner and which is intended to be treated as a single plan. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until June 16, 2025, or earlier if all transactions under the trading arrangement are completed.

[0001596532-24-000173:notes:144]
On March 13, 2024, Anshul Sadana, our Chief Operating Officer, modified his Rule 10b5-1 trading arrangement previously adopted on December 14, 2023 providing for the sale from time to time of an aggregate of up to 126,861 shares of our common stock to reduce the aggregate number of shares of our common stock to up to 110,172 to reflect reduced vesting of previously issued grants due to Mr. Sadana’s previous leave of absence, which was announced February 16, 2024. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until June 12, 2025, or earlier if all transactions under the trading arrangement are completed. On April 18, 2024, Anshul Sadana notified us of his intention to resign from the Company, effective May 21, 2024.

[0001596532-24-000173:notes:145]
On March 13, 2024, Daniel Scheinman, a member of our Board of Directors, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of 1,000 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until June 16, 2025, or earlier if all transactions under the trading arrangement are completed.
