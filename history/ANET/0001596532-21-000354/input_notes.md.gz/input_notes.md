# ANET notes — 0001596532-21-000354


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-21-000354:notes:1]
[same as prior period, unchanged from 0001596532-21-000255:notes:1]

[0001596532-21-000354:notes:2]
[same as prior period, unchanged from 0001596532-21-000255:notes:2]

[0001596532-21-000354:notes:3]
[same as prior period, unchanged from 0001596532-21-000255:notes:3]

[0001596532-21-000354:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments of a normal recurring nature necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2021, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2020 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

[0001596532-21-000354:notes:5]
[same as prior period, unchanged from 0001596532-21-000255:notes:5]

[0001596532-21-000354:notes:6]
[same as prior period, unchanged from 0001596532-21-000255:notes:6]

[0001596532-21-000354:notes:7]
[same as prior period, unchanged from 0001596532-21-000255:notes:7]

[0001596532-21-000354:notes:8]
[same as prior period, unchanged from 0001596532-21-000255:notes:8]

[0001596532-21-000354:notes:9]
[same as prior period, unchanged from 0001596532-21-000255:notes:9]

[0001596532-21-000354:notes:10]
Our contract manufacturers and suppliers have experienced workforce disruptions, delays in component sourcing, production, and export of their products, which have disrupted our supply chain and has impacted and likely will continue to impact our ability to supply products to our customers on a timely basis. While we have experienced improvements in overall demand from customers in recent quarters, we believe ongoing COVID-19 related disruptions combined with other supply chain related constraints, could impact our ability to fulfill this increased demand and as a result could negatively impact our business in future periods. However, the extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, including the duration and spread of the pandemic and related mitigation efforts, the impact to our customers, partners, contract manufacturers and supply chain, as well as restrictions on travel and transport, all of which continue to evolve and are unpredictable. Management continues to actively monitor the impact of the pandemic on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

[0001596532-21-000354:notes:11]
Recently Adopted Accounting Pronouncements

[0001596532-21-000354:notes:12]
[same as prior period, unchanged from 0001596532-21-000255:notes:12]

[0001596532-21-000354:notes:13]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in Topic 740 and amending existing guidance to improve consistent application. This new standard is effective for our interim and annual periods beginning January 1, 2021. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. We adopted this new standard on January 1, 2021 with no material impact on our condensed consolidated financial statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-21-000354:notes:14]
[same as prior period, unchanged from 0001596532-21-000255:notes:14]

[0001596532-21-000354:notes:15]
|  |  | September 30, 2021 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 277,510 |  |  | $ | — |  |  | $ | — |  |  | $ | 277,510 |  |  | $ | 277,510 |  |  | $ | — |  |  | $ | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 127,925 |  |  | — |  |  | — |  |  | 127,925 |  |  | — |  |  | 127,925 |  |  | — |  |
| Certificate of deposits(1) |  | 86,685 |  |  | — |  |  | — |  |  | 86,685 |  |  | — |  |  | 86,685 |  |  | — |  |
| U.S. government notes |  | 1,079,140 |  |  | 120 |  |  | (205) |  |  | 1,079,055 |  |  | 1,079,055 |  |  | — |  |  | — |  |
| Corporate bonds |  | 1,190,273 |  |  | 377 |  |  | (533) |  |  | 1,190,117 |  |  | — |  |  | 1,190,117 |  |  | — |  |
| Agency securities |  | 271,589 |  |  | 147 |  |  | (19) |  |  | 271,717 |  |  | — |  |  | 271,717 |  |  | — |  |
|  |  | 2,755,612 |  |  | 644 |  |  | (757) |  |  | 2,755,499 |  |  | 1,079,055 |  |  | 1,676,444 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,236 |  |  | — |  |  | — |  |  | 4,236 |  |  | 4,236 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 3,037,358 |  |  | $ | 644 |  |  | $ | (757) |  |  | $ | 3,037,245 |  |  | $ | 1,360,801 |  |  | $ | 1,676,444 |  |  | $ | — |  |

[0001596532-21-000354:notes:16]
[same as prior period, unchanged from 0001596532-21-000255:notes:16]

[0001596532-21-000354:notes:17]
[same as prior period, unchanged from 0001596532-21-000255:notes:17]

[0001596532-21-000354:notes:18]
(1) As of September 30, 2021 and December 31, 2020, all of our certificates of deposits were domestic deposits.

[0001596532-21-000354:notes:19]
As of September 30, 2021 and December 31, 2020, total unrealized losses of our marketable securities were immaterial. We invest in marketable securities that have maximum maturities of two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. We expect to realize the full value of these investments upon maturity or sale and therefore, we do not consider any of our marketable securities to be impaired as of September 30, 2021. We did not recognize any credit losses or non-credit-related impairments related to our available-for-sale marketable securities during the three and nine months ended September 30, 2021.

[0001596532-21-000354:notes:20]
As of September 30, 2021, we had no investments with contractual maturities that exceed 24 months. The fair values of available-for-sale marketable securities, by remaining contractual maturities, are as follows (in thousands):

[0001596532-21-000354:notes:21]
|  |  | September 30, 2021 |
| Due in 1 year or less |  | $ | 1,559,405 |  |
| Due in 1 year through 2 years |  | 1,196,094 |  |
| Total marketable securities |  | $ | 2,755,499 |  |

[0001596532-21-000354:notes:22]
The weighted-average remaining duration of our marketable securities is approximately 1.0 year as of September 30, 2021. As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption "Marketable securities" on the condensed consolidated balance sheets.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-21-000354:notes:23]
[same as prior period, unchanged from 0001596532-21-000255:notes:23]

[0001596532-21-000354:notes:24]
[same as prior period, unchanged from 0001596532-21-000255:notes:24]

[0001596532-21-000354:notes:25]
|  |  | September 30, 2021 |  | December 31, 2020 |
| Cash and cash equivalents |  | $ | 630,982 |  |  | $ | 893,219 |  |
| Restricted cash included in other assets |  | 4,236 |  |  | 4,235 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 635,218 |  |  | $ | 897,454 |  |

[0001596532-21-000354:notes:26]
[same as prior period, unchanged from 0001596532-21-000255:notes:26]

[0001596532-21-000354:notes:27]
[same as prior period, unchanged from 0001596532-21-000255:notes:27]

[0001596532-21-000354:notes:28]
|  |  | September 30, 2021 |  | December 31, 2020 |
| Accounts receivable |  | $ | 398,689 |  |  | $ | 394,037 |  |
| Allowance for doubtful accounts |  | (108) |  |  | (659) |  |
| Product sales rebate and returns reserve |  | (2,991) |  |  | (3,838) |  |
| Accounts receivable, net |  | $ | 395,590 |  |  | $ | 389,540 |  |

[0001596532-21-000354:notes:29]
[same as prior period, unchanged from 0001596532-21-000255:notes:29]

[0001596532-21-000354:notes:30]
[same as prior period, unchanged from 0001596532-21-000255:notes:30]

[0001596532-21-000354:notes:31]
|  |  | September 30, 2021 |  | December 31, 2020 |
| Raw materials |  | $ | 312,418 |  |  | $ | 219,218 |  |
| Finished goods |  | 263,247 |  |  | 260,450 |  |
| Total inventories |  | $ | 575,665 |  |  | $ | 479,668 |  |

[0001596532-21-000354:notes:32]
[same as prior period, unchanged from 0001596532-21-000255:notes:32]

[0001596532-21-000354:notes:33]
[same as prior period, unchanged from 0001596532-21-000255:notes:33]

[0001596532-21-000354:notes:34]
|  |  | September 30, 2021 |  | December 31, 2020 |
| Inventory deposits |  | $ | 24,322 |  |  | $ | 18,783 |  |
| Prepaid income taxes |  | 34,080 |  |  | 267 |  |
| Other current assets |  | 90,181 |  |  | 60,556 |  |
| Other prepaid expenses and deposits |  | 17,639 |  |  | 15,316 |  |
| Total prepaid expenses and other current assets |  | $ | 166,222 |  |  | $ | 94,922 |  |

[0001596532-21-000354:notes:35]
[same as prior period, unchanged from 0001596532-21-000255:notes:35]

[0001596532-21-000354:notes:36]
[same as prior period, unchanged from 0001596532-21-000255:notes:36]

[0001596532-21-000354:notes:37]
|  |  | September 30, 2021 |  | December 31, 2020 |
| Land |  | $ | 40,064 |  |  | $ | — |  |
| Equipment and machinery |  | 82,173 |  |  | 70,655 |  |
| Computer hardware and software |  | 43,894 |  |  | 40,081 |  |
| Leasehold improvements |  | 30,503 |  |  | 31,448 |  |
| Furniture and fixtures |  | 3,604 |  |  | 3,787 |  |
| Construction-in-process |  | 3,213 |  |  | 1,441 |  |
| Property and equipment, gross |  | 203,451 |  |  | 147,412 |  |
| Less: accumulated depreciation |  | (128,078) |  |  | (115,181) |  |
| Property and equipment, net |  | $ | 75,373 |  |  | $ | 32,231 |  |

[0001596532-21-000354:notes:38]
In August 2021, we executed a purchase agreement to acquire land and all improvements thereon for total cash consideration of approximately $40.1 million. Depreciation expense on our property and equipment totaled $4.9 million for the three months ended September 30, 2021 and 2020, respectively, and $14.6 million and $15.1 million for the nine months ended September 30, 2021 and 2020, respectively.

[0001596532-21-000354:notes:39]
[same as prior period, unchanged from 0001596532-21-000255:notes:39]

[0001596532-21-000354:notes:40]
[same as prior period, unchanged from 0001596532-21-000255:notes:40]

[0001596532-21-000354:notes:41]
|  |  | September 30, 2021 |  | December 31, 2020 |
| Accrued payroll related costs |  | $ | 62,836 |  |  | $ | 73,634 |  |
| Accrued manufacturing costs |  | 65,843 |  |  | 43,181 |  |
| Accrued product development costs |  | 23,647 |  |  | 6,733 |  |
| Accrued warranty costs |  | 9,528 |  |  | 9,314 |  |
| Other |  | 12,571 |  |  | 10,495 |  |
| Total accrued liabilities |  | $ | 174,425 |  |  | $ | 143,357 |  |

[0001596532-21-000354:notes:42]
[same as prior period, unchanged from 0001596532-21-000255:notes:42]

[0001596532-21-000354:notes:43]
[same as prior period, unchanged from 0001596532-21-000255:notes:43]

[0001596532-21-000354:notes:44]
|  |  | Nine Months Ended September 30, |
|  |  | 2021 |  | 2020 |
| Warranty accrual, beginning of period |  | $ | 9,314 |  |  | $ | 6,742 |  |
| Liabilities accrued for warranties issued during the period |  | 8,643 |  |  | 4,507 |  |
| Warranty costs incurred during the period |  | (8,429) |  |  | (4,517) |  |
| Warranty accrual, end of period |  | $ | 9,528 |  |  | $ | 6,732 |  |

[0001596532-21-000354:notes:45]
[same as prior period, unchanged from 0001596532-21-000255:notes:45]

[0001596532-21-000354:notes:46]
[same as prior period, unchanged from 0001596532-21-000255:notes:46]

[0001596532-21-000354:notes:47]
|  |  | Nine Months Ended September 30, |
|  |  | 2021 |  |
| Contract assets, beginning balance |  | $ | 16,380 |  |  |
| Contract assets, ending balance |  | 6,038 |  |  |

[0001596532-21-000354:notes:48]
Contract Liabilities

[0001596532-21-000354:notes:49]
[same as prior period, unchanged from 0001596532-21-000255:notes:49]

[0001596532-21-000354:notes:50]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Contract liabilities, beginning balance |  | $ | 83,354 |  |  | $ | 67,268 |  |  | $ | 85,957 |  |  | $ | 61,050 |  |
| Less: Revenue recognized from beginning balance |  | (8,763) |  |  | (6,525) |  |  | (27,251) |  |  | (17,946) |  |
| Less: Beginning balance reclassified to deferred revenue |  | (3,996) |  |  | (2,828) |  |  | (2,443) |  |  | (1,942) |  |
| Add: Contract liabilities recognized |  | 16,976 |  |  | 12,362 |  |  | 31,308 |  |  | 29,115 |  |
| Contract liabilities, ending balance |  | $ | 87,571 |  |  | $ | 70,277 |  |  | $ | 87,571 |  |  | $ | 70,277 |  |

[0001596532-21-000354:notes:51]
As of September 30, 2021 and December 31, 2020, $36.4 million and $34.5 million of our contract liabilities, respectively, were included in "Other current liabilities" with the remaining balances included in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001596532-21-000354:notes:52]
Deferred Revenue

[0001596532-21-000354:notes:53]
[same as prior period, unchanged from 0001596532-21-000255:notes:52]

[0001596532-21-000354:notes:54]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Deferred revenue, beginning balance |  | $ | 746,090 |  |  | $ | 577,511 |  |  | $ | 650,827 |  |  | $ | 575,288 |  |
| Less: Revenue recognized from beginning balance |  | (164,188) |  |  | (103,889) |  |  | (327,300) |  |  | (243,422) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 218,538 |  |  | 88,682 |  |  | 476,913 |  |  | 230,438 |  |
| Deferred revenue, ending balance |  | $ | 800,440 |  |  | $ | 562,304 |  |  | $ | 800,440 |  |  | $ | 562,304 |  |

[0001596532-21-000354:notes:55]
Other Performance Obligations

[0001596532-21-000354:notes:56]
Other performance obligations include unbilled contract revenue for services and product that will be recognized in future periods.  As of September 30, 2021, other performance obligations of $243.1 million were comprised mainly of unbilled multi-year PCS contract amounts.

[0001596532-21-000354:notes:57]
[same as prior period, unchanged from 0001596532-21-000255:notes:55]

[0001596532-21-000354:notes:58]
Revenue from total remaining performance obligations represents contract liabilities, deferred revenue and other performance obligations. As of September 30, 2021, approximately $1,131.1 million of revenue is expected to be recognized from remaining performance obligations, of which approximately 80% is expected to be recognized over the next two years and approximately 20% is expected to be recognized during the third to the fifth year.

[0001596532-21-000354:notes:59]
[same as prior period, unchanged from 0001596532-21-000255:notes:57]

[0001596532-21-000354:notes:60]
[same as prior period, unchanged from 0001596532-21-000255:notes:58]

[0001596532-21-000354:notes:61]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Interest income |  | $ | 1,636 |  |  | $ | 4,319 |  |  | $ | 5,553 |  |  | $ | 24,649 |  |
| Gain on sale of marketable securities |  | — |  |  | 9,432 |  |  | — |  |  | 9,432 |  |
| Other income (expense), net |  | (290) |  |  | (527) |  |  | (913) |  |  | (444) |  |
| Total |  | $ | 1,346 |  |  | $ | 13,224 |  |  | $ | 4,640 |  |  | $ | 33,637 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-21-000354:notes:62]
[same as prior period, unchanged from 0001596532-21-000255:notes:60]


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-21-000354:notes:63]
[same as prior period, unchanged from 0001596532-21-000255:notes:61]

[0001596532-21-000354:notes:64]
Our investments in privately-held companies do not have readily-determinable fair values. Their initial cost is adjusted to fair value on a non-recurring basis based on observable price changes from orderly transactions of identical or similar securities of the same issuer, or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to these securities. In addition, the valuation requires management judgment due to the absence of market price and lack of liquidity. The following table summarizes the activity related to our investments in privately-held companies as of September 30, 2021 and December 31, 2020 (in thousands):

[0001596532-21-000354:notes:65]
|  |  | September 30, 2021 |  | December 31, 2020 |
| Cost of investments |  | $ | 12,933 |  |  | $ | 3,000 |  |
| Cumulative impairment |  | — |  |  | — |  |
| Cumulative upward adjustment |  | 5,314 |  |  | 5,314 |  |
| Carrying amount of investments |  | $ | 18,247 |  |  | $ | 8,314 |  |

[0001596532-21-000354:notes:66]
During the three and nine months ended September 30, 2021 and September 30, 2020, there were no realized or unrealized gains or losses recorded.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-21-000354:notes:67]
Commitments and Contingencies
Purchase Commitments

[0001596532-21-000354:notes:68]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2021, we had non-cancellable purchase commitments of $2,147.0 million, of which $2,109.5 million was to our contract manufacturers and suppliers. In addition, we had deposits to our contract manufacturers to secure our purchase commitments in the amount of $27.1 million and $21.5 million as of September 30, 2021 and December 31, 2020, respectively. These deposits are included in “Prepaid expenses and other current assets” and “Other assets” on the condensed consolidated balance sheets.

[0001596532-21-000354:notes:69]
Guarantees

[0001596532-21-000354:notes:70]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-21-000354:notes:71]
Legal Proceedings

[0001596532-21-000354:notes:72]
WSOU Investments, LLC

[0001596532-21-000354:notes:73]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. The court has set a trial date for August 8, 2022.

[0001596532-21-000354:notes:74]
We intend to vigorously defend against the claims brought against us by WSOU. However, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-21-000354:notes:75]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated. However, the

[0001596532-21-000354:notes:76]
outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-21-000354:notes:77]
Other matters

[0001596532-21-000354:notes:78]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-21-000354:notes:79]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2021, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-21-000354:notes:80]
[same as prior period, unchanged from 0001596532-21-000255:notes:78]

[0001596532-21-000354:notes:81]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the "Existing Repurchase Program").  This authorization allows us to repurchase shares of our common stock and is funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the "Exchange Act") or a combination of the foregoing. The Existing Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of September 30, 2021, the remaining authorized amount for stock repurchases under this program was approximately $103.2 million.

[0001596532-21-000354:notes:82]
A summary of the stock repurchase activity under the Existing Repurchase Program for the nine months ended September 30, 2021 is as follows (in thousands, except per share amounts):

[0001596532-21-000354:notes:83]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 30, 2021 |  | September 30, 2021 |
| Aggregate purchase price |  | $ | 134,157 |  |  | $ | 235,512 |  |
| Shares repurchased |  | 376 |  |  | 743 |  |
| Average price paid per share |  | $ | 356.72 |  |  | $ | 316.98 |  |

[0001596532-21-000354:notes:84]
The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings and common stock in our condensed consolidated statements of stockholders' equity. All shares repurchased under the Existing Repurchase Program have been retired.

[0001596532-21-000354:notes:85]
[same as prior period, unchanged from 0001596532-21-000255:notes:83]

[0001596532-21-000354:notes:86]
[same as prior period, unchanged from 0001596532-21-000255:notes:84]

[0001596532-21-000354:notes:87]
The 2014 Equity Incentive Plan (the “2014 Plan”) provides for the granting of Incentive Stock Options (“ISOs”), Non-statutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”).  The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year by the lesser of (i) 12,500,000 shares, (ii) 3% of the outstanding shares of our common stock on the last day of our immediately preceding fiscal year, or (iii) such other amount as determined by our board of directors. Effective January 1, 2021, our board of directors authorized an increase of 2,285,228 shares to the shares available for issuance under the 2014 Plan.  As of September 30, 2021, there remained approximately 22.4 million shares available for issuance under the 2014 Plan.

[0001596532-21-000354:notes:88]
[same as prior period, unchanged from 0001596532-21-000255:notes:86]

[0001596532-21-000354:notes:89]
Effective January 1, 2021, our board of directors authorized an increase of 761,742 shares to the shares available for issuance under our 2014 Employee Stock Purchase Plan (the “ESPP”). Pursuant to the ESPP, the 2021 share increase was determined based on the lesser of 1% of the total shares of common stock outstanding on December 31, 2020, 2,500,000 shares, or such amount as determined by our board of directors. During the nine months ended September 30, 2021, we issued 114,571

[0001596532-21-000354:notes:90]
shares at a weighted-average purchase price of $186.01 per share under the ESPP. As of September 30, 2021, there remained 4.5 million shares available for issuance under the ESPP.

[0001596532-21-000354:notes:91]
[same as prior period, unchanged from 0001596532-21-000255:notes:88]

[0001596532-21-000354:notes:92]
[same as prior period, unchanged from 0001596532-21-000255:notes:89]

[0001596532-21-000354:notes:93]
|  |  | Options Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding |
| Balance—December 31, 2020 |  | 3,430 |  |  | $ | 45.17 |  |  | 3.6 |  | $ | 841,659 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (947) |  |  | 36.81 |  |  |  |  |  |
| Options canceled |  | (22) |  |  | 38.54 |  |  |  |  |  |
| Balance—September 30, 2021 |  | 2,461 |  |  | $ | 48.44 |  |  | 3.0 |  | $ | 726,600 |  |
| Vested and exercisable—September 30, 2021 |  | 1,814 |  |  | $ | 36.95 |  |  | 2.6 |  | $ | 556,227 |  |

[0001596532-21-000354:notes:94]
[same as prior period, unchanged from 0001596532-21-000255:notes:91]

[0001596532-21-000354:notes:95]
[same as prior period, unchanged from 0001596532-21-000255:notes:92]

[0001596532-21-000354:notes:96]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2020 |  | 1,816 |  |  | $ | 215.68 |  |  | 1.8 |  | $ | 527,574 |  |
| RSUs granted |  | 726 |  |  | 348.85 |  |  |  |  |  |
| RSUs vested |  | (420) |  |  | 207.96 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (131) |  |  | 241.98 |  |  |  |  |  |
| Unvested balance—September 30, 2021 |  | 1,991 |  |  | $ | 264.14 |  |  | 1.8 |  | $ | 684,133 |  |

[0001596532-21-000354:notes:97]
In the nine months ended September 30, 2021, we granted 69,620 performance-based RSUs (“PRSUs”) to our CEO and other key employees that include both service and performance-based conditions. These PRSUs will vest over three to four years and the ultimate number of shares eligible to vest will vary between 0% and 200% of the amount granted based on the achievement of certain performance metrics over the vesting period and each holder’s continued employment with Arista.

[0001596532-21-000354:notes:98]
[same as prior period, unchanged from 0001596532-21-000255:notes:96]

[0001596532-21-000354:notes:99]
[same as prior period, unchanged from 0001596532-21-000255:notes:97]

[0001596532-21-000354:notes:100]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cost of revenue |  | $ | 2,002 |  |  | $ | 1,806 |  |  | $ | 5,198 |  |  | $ | 4,718 |  |
| Research and development |  | 27,552 |  |  | 21,423 |  |  | 72,673 |  |  | 56,729 |  |
| Sales and marketing |  | 12,680 |  |  | 9,083 |  |  | 34,133 |  |  | 23,756 |  |
| General and administrative |  | 10,901 |  |  | 4,157 |  |  | 23,628 |  |  | 11,744 |  |
| Total stock-based compensation |  | $ | 53,135 |  |  | $ | 36,469 |  |  | $ | 135,632 |  |  | $ | 96,947 |  |

[0001596532-21-000354:notes:101]
As of September 30, 2021, there were $512.8 million of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 3.3 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-21-000354:notes:102]
[same as prior period, unchanged from 0001596532-21-000255:notes:100]

[0001596532-21-000354:notes:103]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |  |  |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 224,305 |  |  | $ | 168,375 |  |  | $ | 601,559 |  |  | $ | 451,599 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share, basic |  | 76,864 |  |  | 75,999 |  |  | 76,544 |  |  | 76,024 |  |  |  |  |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options and RSUs |  | 3,002 |  |  | 3,308 |  |  | 3,157 |  |  | 3,489 |  |  |  |  |  |
| Employee stock purchase plan |  | 43 |  |  | 6 |  |  | 43 |  |  | 6 |  |  |  |  |  |
| Weighted-average shares used in computing net income per share, diluted |  | 79,909 |  |  | 79,313 |  |  | 79,744 |  |  | 79,519 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.92 |  |  | $ | 2.22 |  |  | $ | 7.86 |  |  | $ | 5.94 |  |  |  |  |  |
| Diluted |  | $ | 2.81 |  |  | $ | 2.12 |  |  | $ | 7.54 |  |  | $ | 5.68 |  |  |  |  |  |

[0001596532-21-000354:notes:104]
[same as prior period, unchanged from 0001596532-21-000255:notes:102]

[0001596532-21-000354:notes:105]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |  |  |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |
| Stock options and RSUs |  | 9 |  |  | 251 |  |  | 80 |  |  | 395 |  |  |  |  |  |
| Employee stock purchase plan |  | 6 |  |  | 17 |  |  | 12 |  |  | 84 |  |  |  |  |  |
| Total |  | 15 |  |  | 268 |  |  | 92 |  |  | 479 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-21-000354:notes:106]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |  |  |  |  |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |
|  |  | (in thousands, except percentages) |  | (in thousands, except percentages) |  |  |  |  |
| Income before income taxes |  | $ | 234,640 |  |  | $ | 201,619 |  |  | $ | 663,591 |  |  | $ | 538,683 |  |  |  |  |  |
| Provision for income taxes |  | 10,335 |  |  | 33,244 |  |  | 62,032 |  |  | 87,084 |  |  |  |  |  |
| Effective tax rate |  | 4.4 | % |  | 16.5 | % |  | 9.3 | % |  | 16.2 | % |  |  |  |  |

[0001596532-21-000354:notes:107]
The change in effective tax rates in the three and nine months ended September 30, 2021, as compared to the same periods in 2020, was primarily due to an increase in tax benefits attributable to stock-based compensation, combined with a favorable change in jurisdictional mix of earnings.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-21-000354:notes:108]
Geographical Information      We operate in one reportable segment. The following table represents revenue based on customers’ shipping addresses (in thousands):

[0001596532-21-000354:notes:109]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Americas |  | $ | 557,814 |  |  | $ | 452,693 |  |  | $ | 1,573,835 |  |  | $ | 1,289,182 |  |
| Europe, Middle East and Africa |  | 121,722 |  |  | 89,588 |  |  | 330,044 |  |  | 226,189 |  |
| Asia-Pacific |  | 69,161 |  |  | 63,150 |  |  | 219,699 |  |  | 153,659 |  |
| Total revenue |  | $ | 748,697 |  |  | $ | 605,431 |  |  | $ | 2,123,578 |  |  | $ | 1,669,030 |  |

[0001596532-21-000354:notes:110]
[same as prior period, unchanged from 0001596532-21-000255:notes:108]

[0001596532-21-000354:notes:111]
|  |  | September 30, 2021 |  | December 31, 2020 |
| United States |  | $ | 66,238 |  |  | $ | 24,110 |  |
| International |  | 9,135 |  |  | 8,121 |  |
| Total |  | $ | 75,373 |  |  | $ | 32,231 |  |


## us-gaap:SubsequentEventsTextBlock

[0001596532-21-000354:notes:112]
Subsequent event 
Common Stock Split

[0001596532-21-000354:notes:113]
On November 1, 2021, the Company announced a four-for-one split of its common stock effected in the form of a stock dividend to shareholders of record as of the close of business on November 11, 2021. The stock dividend payment date is expected to be on or about November 17, 2021, and trading of the Company’s common stock will begin on a split-adjusted basis on or about November 18, 2021.

[0001596532-21-000354:notes:114]
Stock Repurchases

[0001596532-21-000354:notes:115]
Subsequent to September 30, 2021, our board of directors authorized a new $1.0 billion stock repurchase program (the “New Repurchase Program”, together with the “Existing Repurchase Program,” the “Repurchase Programs”). This authorization allows the Company to repurchase shares of its common stock and will be funded from working capital. Repurchases may be made at management's discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The New Repurchase Program commences upon the earlier of the use of all dollar amounts authorized under the Existing Repurchase Program and April 2022, and it expires on the three year anniversary thereof. The Repurchase Programs do not obligate Arista to acquire any of its common stock, and may be suspended or discontinued by the company at any time without prior notice.
