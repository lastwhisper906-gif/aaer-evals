# ANET note change history — 0001596532-21-000255 → 0001596532-21-000354


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001596532-21-000354:note_history:1]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2021, we had non-cancellable purchase commitments of $2,147.0 million, of which $2,109.5 million was to our contract manufacturers and suppliers. In addition, we had deposits to our contract manufacturers to secure our purchase commitments in the amount of $27.1 million and $21.5 million as of September 30, 2021 and December 31, 2020, respectively. These deposits are included in “Prepaid expenses and other current assets” and “Other assets” on the condensed consolidated balance sheets.
  (was, 2021-08-03, similarity 0.987):
[0001596532-21-000255:note_history:1]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of June 30, 2021, we had non-cancellable purchase commitments of $1,057.5 million, of which $1,019.0 million was to our contract manufacturers and suppliers.  In addition, we had deposits to our contract manufacturers to secure our purchase commitments in the amount of $25.1 million and $21.5 million as of June 30, 2021 and December 31, 2020, respectively. These deposits are included in “Prepaid expenses and other current assets” and “Other assets” on the condensed consolidated balance sheets.

- changed (2021-11-02):
[0001596532-21-000354:note_history:2]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.
  (was, 2021-08-03, similarity 0.9178):
[0001596532-21-000255:note_history:2]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions

- changed (2021-11-02):
[0001596532-21-000354:note_history:3]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. The court has set a trial date for August 8, 2022.
  (was, 2021-08-03, similarity 0.946):
[0001596532-21-000255:note_history:3]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations.

- changed (2021-11-02):
[0001596532-21-000354:note_history:4]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated. However, the
  (was, 2021-08-03, similarity 0.6622):
[0001596532-21-000255:note_history:4]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated. However, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

- added (2021-11-02):
[0001596532-21-000354:note_history:5]
outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

- changed (2021-11-02):
[0001596532-21-000354:note_history:6]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2021, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.
  (was, 2021-08-03, similarity 0.9937):
[0001596532-21-000255:note_history:6]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of June 30, 2021, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.

- removed (2021-11-02):
[0001596532-21-000255:note_history:7]
and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001596532-21-000354:note_history:8]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments of a normal recurring nature necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2021, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2020 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.
  (was, 2021-08-03, similarity 0.964):
[0001596532-21-000255:note_history:8]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2021, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2020 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

- changed (2021-11-02):
[0001596532-21-000354:note_history:9]
Our contract manufacturers and suppliers have experienced workforce disruptions, delays in component sourcing, production, and export of their products, which have disrupted our supply chain and has impacted and likely will continue to impact our ability to supply products to our customers on a timely basis. While we have experienced improvements in overall demand from customers in recent quarters, we believe ongoing COVID-19 related disruptions combined with other supply chain related constraints, could impact our ability to fulfill this increased demand and as a result could negatively impact our business in future periods. However, the extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, including the duration and spread of the pandemic and related mitigation efforts, the impact to our customers, partners, contract manufacturers and supply chain, as well as restrictions on travel and transport, all of which continue to evolve and are unpredictable. Management continues to actively monitor the impact of the pandemic on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.
  (was, 2021-08-03, similarity 0.696):
[0001596532-21-000255:note_history:9]
Our contract manufacturers and suppliers have experienced delays in component sourcing, production and export of their products, which have negatively impacted our supply chain and could negatively impact our business in the future. While we have experienced some recovery in demand from our customers in recent quarters, we believe any renewed COVID-19- related disruptions could result in negative impacts on demand in future periods. However, the extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, including the duration and spread of the pandemic and related mitigation efforts, the impact to our customers, partners, contract manufacturers and supply chain, as well as restrictions on travel and transport, all of which are uncertain and cannot be predicted. Management continues to actively monitor the impact of the pandemic on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2021-11-02):
[0001596532-21-000354:note_history:10]
Subsequent event 
Common Stock Split

- added (2021-11-02):
[0001596532-21-000354:note_history:11]
On November 1, 2021, the Company announced a four-for-one split of its common stock effected in the form of a stock dividend to shareholders of record as of the close of business on November 11, 2021. The stock dividend payment date is expected to be on or about November 17, 2021, and trading of the Company’s common stock will begin on a split-adjusted basis on or about November 18, 2021.

- added (2021-11-02):
[0001596532-21-000354:note_history:12]
Stock Repurchases

- added (2021-11-02):
[0001596532-21-000354:note_history:13]
Subsequent to September 30, 2021, our board of directors authorized a new $1.0 billion stock repurchase program (the “New Repurchase Program”, together with the “Existing Repurchase Program,” the “Repurchase Programs”). This authorization allows the Company to repurchase shares of its common stock and will be funded from working capital. Repurchases may be made at management's discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchase techniques, 10b5-1 trading plans, or a combination of the foregoing. The New Repurchase Program commences upon the earlier of the use of all dollar amounts authorized under the Existing Repurchase Program and April 2022, and it expires on the three year anniversary thereof. The Repurchase Programs do not obligate Arista to acquire any of its common stock, and may be suspended or discontinued by the company at any time without prior notice.

- removed (2021-11-02):
[0001596532-21-000255:note_history:14]
Subsequent event     Subsequent to the end of the quarter, on July 20, 2021, we finalized a commitment to acquire land and all improvements thereon for a total consideration of approximately $40.0 million. We expect to fund payment of this amount in the third quarter of 2021.
