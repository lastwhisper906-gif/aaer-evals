# ANET 8-K — 0001596532-21-000351 filed 2021-11-01

## item codes, every 8-K on or before 2021-11-02

- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2021-11-02

- none on or before 2021-11-02

## item 2.02 — earnings release, exhibit 99.1

[0001596532-21-000351:8k_2_02:1]
EX-99.1
2
ex991q321-earningsrelease.htm
EX-99.1

[0001596532-21-000351:8k_2_02:2]
Document

[0001596532-21-000351:8k_2_02:3]
Exhibit 99.1

[0001596532-21-000351:8k_2_02:4]
Arista Networks, Inc. Reports Third Quarter 2021 Financial Results

[0001596532-21-000351:8k_2_02:5]
SANTA CLARA, Calif.- November 1, 2021 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments, today announced financial results for its third quarter ended September 30, 2021.

[0001596532-21-000351:8k_2_02:6]
Third Quarter Financial Highlights

[0001596532-21-000351:8k_2_02:7]
•Revenue of $748.7 million, an increase of 5.8% compared to the second quarter of 2021, and an increase of 23.7% from the third quarter of 2020.

[0001596532-21-000351:8k_2_02:8]
•GAAP gross margin of 63.9%, compared to GAAP gross margin of 64.2% in the second quarter of 2021 and 63.6% in the third quarter of 2020.

[0001596532-21-000351:8k_2_02:9]
•Non-GAAP gross margin of 64.9%, compared to non-GAAP gross margin of 65.2% in the second quarter of 2021 and 64.6% in the third quarter of 2020.

[0001596532-21-000351:8k_2_02:10]
•GAAP net income of $224.3 million, or $2.81 per diluted share, compared to GAAP net income of $168.4 million, or $2.12 per diluted share in the third quarter of 2020.

[0001596532-21-000351:8k_2_02:11]
•Non-GAAP net income of $236.9 million, or $2.96 per diluted share, compared to non-GAAP net income of $192.0 million, or $2.42 per diluted share in the third quarter of 2020.

[0001596532-21-000351:8k_2_02:12]
"We are experiencing strong demand for our pioneering client-to-cloud networking portfolio across all of our customer sectors. Despite a challenging supply chain environment, I am pleased with our delivery of another record quarter of Arista's financial results in Q3 2021," stated Jayshree Ullal, Arista’s President and CEO.

[0001596532-21-000351:8k_2_02:13]
Commenting on the company’s financial results, Ita Brennan, Arista’s CFO said, “The business continued to perform well in the quarter, exceeding on all key financial metrics, while the team navigates a difficult supply environment.”

[0001596532-21-000351:8k_2_02:14]
Third Quarter Company Highlights

[0001596532-21-000351:8k_2_02:15]
•Arista Extends Cloud-Grade Routing to the Network Edge - Arista announced the expansion of its cloud-grade routing solutions for next generation network edge roles in the multi cloud era. Arista’s EOS® (Extensible Operating System) enhancements for cloud and service provider customers transform edge and backbone routing, migrating from legacy routers to software-driven, highly available and scale-out architectures for faster time to revenue and lower operating expenses.

[0001596532-21-000351:8k_2_02:16]
•Arista Selected to Build Australian Securities Exchange Next Generation Campus Network - Arista to build next generation national campus network for Australian Securities Exchange (ASX), providing ultra high-performance networking for corporate sites in Sydney, Melbourne and Perth

[0001596532-21-000351:8k_2_02:17]
•Arista Expands Its Cognitive Campus With the Latest Generation Wi-Fi 6E Solution - Arista announced today the expansion of its cognitive campus edge portfolio with a new Wi-Fi 6E access point. As a result, customers can take advantage of the greater capacity, higher bandwidth and lower latency of Wi-Fi 6E to support high definition video collaboration applications and IoT proliferation.

[0001596532-21-000351:8k_2_02:18]
Share Repurchase Program

[0001596532-21-000351:8k_2_02:19]
In October 2021, Arista’s Board of Directors increased the prior authorization to repurchase shares by authorizing an additional $1 billion.  The actual timing and amount of repurchases will be dependent on market and business conditions, business requirements, stock price, acquisition opportunities and other factors.

[0001596532-21-000351:8k_2_02:20]
Stock Split Authorization

[0001596532-21-000351:8k_2_02:21]
Arista’s board of directors has also approved a four-for-one stock split to make the stock more accessible to a broader base of investors. Each Arista shareholder of record at the close of business on November 11, 2021 will receive three additional shares for every share held on the record date, and trading will begin on a split-adjusted basis on or about November 18, 2021.

[0001596532-21-000351:8k_2_02:22]
Financial Outlook

[0001596532-21-000351:8k_2_02:23]
For the fourth quarter of 2021, we expect:

[0001596532-21-000351:8k_2_02:24]
•Revenue between $775 million to $795 million;

[0001596532-21-000351:8k_2_02:25]
•Non-GAAP gross margin of 63% to 65%; and

[0001596532-21-000351:8k_2_02:26]
•Non-GAAP operating margin of approximately 37%

[0001596532-21-000351:8k_2_02:27]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and certain non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below under “Non-GAAP Financial Measures”).

[0001596532-21-000351:8k_2_02:28]
Prepared Materials and Conference Call Information

[0001596532-21-000351:8k_2_02:29]
Arista executives will discuss the third quarter financial results on a conference call at 1:15 p.m. Pacific Time today. To listen to the call via telephone, dial (833) 968-2211 in the United States or +1 (778) 560-2896 from international locations. The Conference ID is 1552223.

[0001596532-21-000351:8k_2_02:30]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-21-000351:8k_2_02:31]
Following the financial results conference call, Arista Networks will host its Analyst Day 2021 on Monday, November 1st, 2021 beginning at 3:00 p.m. PT (6:00 p.m. ET). Interested participants will be able to join the virtual event through the Investor Relations section of the Arista website at https://investors.arista.com/Events/Events/Event-Details/2021/Analyst-Day-placeholder/default.aspx

[0001596532-21-000351:8k_2_02:32]
Forward-Looking Statements

[0001596532-21-000351:8k_2_02:33]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the fourth quarter of 2021 and statements regarding the benefits of new products and product enhancements, our plans to repurchase our stock, and our leadership in cloud networking. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: the impact of the COVID-19 pandemic on our business; insufficient component supply and inventory and increased costs of components; manufacturing capacity impacted by COVID-19 and increased lead times; interruptions or delays in shipments; excess inventory; deferral, reduction or cancellation of orders from end customers; the rapid evolution of the networking market; any failure to successfully pursue new products and service offerings and expand into adjacent markets; a decline in our revenue growth rate; unpredictability of our results of operations; adverse economic conditions or reduced information technology and network infrastructure spending; intense competition; expansion of our international sales and operations; investment or acquisition in other businesses; seasonality; our ability to attract new large end customers or sell products and services to existing end customers; our ability to increase market awareness of our company and new products and services; product quality problems; our ability to

[0001596532-21-000351:8k_2_02:34]
anticipate technological shifts and develop products to meet those technological shifts; our ability to protect, defend and maintain our intellectual property rights; vulnerabilities in our products and failure of our products to detect security breaches our intellectual property rights; and tax, tariff, import/export restrictions; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-21-000351:8k_2_02:35]
Non-GAAP Financial Measures

[0001596532-21-000351:8k_2_02:36]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangible assets, certain non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-21-000351:8k_2_02:37]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-21-000351:8k_2_02:38]
The company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. The company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. A reconciliation of the non-GAAP financial measures guidance to the corresponding GAAP measures on a forward-looking basis is not available because stock-based compensation expense is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-21-000351:8k_2_02:39]
About Arista Networks

[0001596532-21-000351:8k_2_02:40]
Arista Networks is an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments. Arista’s award-winning platforms deliver availability, agility, automation, analytics and security through CloudVision® and Arista EOS®, an advanced network operating system. For more information, visit www.arista.com.

[0001596532-21-000351:8k_2_02:41]
ARISTA, CloudVision, CloudEOS and MSS are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners. Additional information and resources can be found at www.arista.com.

[0001596532-21-000351:8k_2_02:42]
Investor Contacts:

[0001596532-21-000351:8k_2_02:43]
| Arista Networks, Inc. |  |  |  |  |
| Liz Stine, 408-547-5885 |  | Charles Yager, 408-547-5892 |
| Director, Investor Relations |  | Product and Investor Advocacy |
| liz@arista.com |  |  | cyager@arista.com |  |

[0001596532-21-000351:8k_2_02:44]
4

[0001596532-21-000351:8k_2_02:45]
ARISTA NETWORKS, INC.

[0001596532-21-000351:8k_2_02:46]
Condensed Consolidated Statements of Operations

[0001596532-21-000351:8k_2_02:47]
(Unaudited, in thousands, except per share amounts)

[0001596532-21-000351:8k_2_02:48]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 604,160 |  |  | $ | 480,242 |  |  | $ | 1,709,772 |  |  | $ | 1,312,561 |  |
| Service |  | 144,537 |  |  | 125,189 |  |  | 413,806 |  |  | 356,469 |  |
| Total revenue |  | 748,697 |  |  | 605,431 |  |  | 2,123,578 |  |  | 1,669,030 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 243,342 |  |  | 199,465 |  |  | 687,554 |  |  | 539,526 |  |
| Service |  | 26,740 |  |  | 21,004 |  |  | 77,959 |  |  | 62,202 |  |
| Total cost of revenue |  | 270,082 |  |  | 220,469 |  |  | 765,513 |  |  | 601,728 |  |
| Gross profit |  | 478,615 |  |  | 384,962 |  |  | 1,358,065 |  |  | 1,067,302 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 153,093 |  |  | 128,049 |  |  | 428,873 |  |  | 352,747 |  |
| Sales and marketing |  | 69,740 |  |  | 53,372 |  |  | 211,385 |  |  | 161,695 |  |
| General and administrative |  | 22,488 |  |  | 15,146 |  |  | 58,856 |  |  | 47,814 |  |
| Total operating expenses |  | 245,321 |  |  | 196,567 |  |  | 699,114 |  |  | 562,256 |  |
| Income from operations |  | 233,294 |  |  | 188,395 |  |  | 658,951 |  |  | 505,046 |  |
| Other income, net |  | 1,346 |  |  | 13,224 |  |  | 4,640 |  |  | 33,637 |  |
| Income before income taxes |  | 234,640 |  |  | 201,619 |  |  | 663,591 |  |  | 538,683 |  |
| Provision for income taxes |  | 10,335 |  |  | 33,244 |  |  | 62,032 |  |  | 87,084 |  |
| Net income |  | $ | 224,305 |  |  | $ | 168,375 |  |  | $ | 601,559 |  |  | $ | 451,599 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.92 |  |  | $ | 2.22 |  |  | $ | 7.86 |  |  | $ | 5.94 |  |
| Diluted |  | $ | 2.81 |  |  | $ | 2.12 |  |  | $ | 7.54 |  |  | $ | 5.68 |  |
| Weighted-average shares used in computing net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 76,864 |  |  | 75,999 |  |  | 76,544 |  |  | 76,024 |  |
| Diluted |  | 79,909 |  |  | 79,313 |  |  | 79,744 |  |  | 79,519 |  |

[0001596532-21-000351:8k_2_02:49]
5

[0001596532-21-000351:8k_2_02:50]
ARISTA NETWORKS, INC.

[0001596532-21-000351:8k_2_02:51]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-21-000351:8k_2_02:52]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-21-000351:8k_2_02:53]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| GAAP gross profit |  | $ | 478,615 |  |  | $ | 384,962 |  |  | $ | 1,358,065 |  |  | $ | 1,067,302 |  |
| GAAP gross margin |  | 63.9 | % |  | 63.6 | % |  | 64.0 | % |  | 63.9 | % |
| Stock-based compensation expense |  | 2,002 |  |  | 1,806 |  |  | 5,198 |  |  | 4,718 |  |
| Intangible asset amortization |  | 5,464 |  |  | 4,178 |  |  | 16,393 |  |  | 12,016 |  |
| Non-GAAP gross profit |  | $ | 486,081 |  |  | $ | 390,946 |  |  | $ | 1,379,656 |  |  | $ | 1,084,036 |  |
| Non-GAAP gross margin |  | 64.9 | % |  | 64.6 | % |  | 65.0 | % |  | 65.0 | % |
| GAAP income from operations |  | $ | 233,294 |  |  | $ | 188,395 |  |  | $ | 658,951 |  |  | $ | 505,046 |  |
| Stock-based compensation expense |  | 53,135 |  |  | 36,469 |  |  | 135,632 |  |  | 96,947 |  |
| Intangible asset amortization |  | 7,281 |  |  | 5,811 |  |  | 22,076 |  |  | 16,524 |  |
| Acquisition-related costs (1) |  | — |  |  | 858 |  |  | — |  |  | 12,718 |  |
| Non-GAAP income from operations |  | $ | 293,710 |  |  | $ | 231,533 |  |  | $ | 816,659 |  |  | $ | 631,235 |  |
| Non-GAAP operating margin |  | 39.2 | % |  | 38.2 | % |  | 38.5 | % |  | 37.8 | % |
| GAAP net income |  | $ | 224,305 |  |  | $ | 168,375 |  |  | $ | 601,559 |  |  | $ | 451,599 |  |
| Stock-based compensation expense |  | 53,135 |  |  | 36,469 |  |  | 135,632 |  |  | 96,947 |  |
| Intangible asset amortization |  | 7,281 |  |  | 5,811 |  |  | 22,076 |  |  | 16,524 |  |
| Acquisition-related costs (1) |  | — |  |  | 858 |  |  | — |  |  | 12,718 |  |
| Tax benefit on stock-based awards |  | (39,665) |  |  | (14,894) |  |  | (84,684) |  |  | (41,078) |  |
| Income tax effect on non-GAAP exclusions |  | (8,137) |  |  | (4,624) |  |  | (21,999) |  |  | (15,975) |  |
| Non-GAAP net income |  | $ | 236,919 |  |  | $ | 191,995 |  |  | $ | 652,584 |  |  | $ | 520,735 |  |
| GAAP diluted net income per share |  | $ | 2.81 |  |  | $ | 2.12 |  |  | $ | 7.54 |  |  | $ | 5.68 |  |
| Non-GAAP adjustments to net income |  | 0.15 |  |  | 0.30 |  |  | 0.64 |  |  | 0.87 |  |
| Non-GAAP diluted net income per share |  | $ | 2.96 |  |  | $ | 2.42 |  |  | $ | 8.18 |  |  | $ | 6.55 |  |
| Weighted-average shares used in computing diluted net income per share |  | 79,909 |  |  | 79,313 |  |  | 79,744 |  |  | 79,519 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 2,002 |  |  | $ | 1,806 |  |  | $ | 5,198 |  |  | $ | 4,718 |  |
| Research and development |  | 27,552 |  |  | 21,423 |  |  | 72,673 |  |  | 56,729 |  |
| Sales and marketing |  | 12,680 |  |  | 9,083 |  |  | 34,133 |  |  | 23,756 |  |
| General and administrative |  | 10,901 |  |  | 4,157 |  |  | 23,628 |  |  | 11,744 |  |
| Total |  | $ | 53,135 |  |  | $ | 36,469 |  |  | $ | 135,632 |  |  | $ | 96,947 |  |

[0001596532-21-000351:8k_2_02:54]
___________________

[0001596532-21-000351:8k_2_02:55]
(1) Represents non-recurring costs associated with our acquisition of Big Switch, and primarily includes severance, retention bonuses, professional and consulting fees, and facilities restructuring costs.

[0001596532-21-000351:8k_2_02:56]
ARISTA NETWORKS, INC.

[0001596532-21-000351:8k_2_02:57]
Condensed Consolidated Balance Sheets

[0001596532-21-000351:8k_2_02:58]
(Unaudited, in thousands)

[0001596532-21-000351:8k_2_02:59]
|  |  | September 30, 2021 |  | December 31, 2020 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 630,982 |  |  | $ | 893,219 |  |
| Marketable securities |  | 2,755,499 |  |  | 1,979,649 |  |
| Accounts receivable |  | 395,590 |  |  | 389,540 |  |
| Inventories |  | 575,665 |  |  | 479,668 |  |
| Prepaid expenses and other current assets |  | 166,222 |  |  | 94,922 |  |
| Total current assets |  | 4,523,958 |  |  | 3,836,998 |  |
| Property and equipment, net |  | 75,373 |  |  | 32,231 |  |
| Acquisition-related intangible assets, net |  | 100,713 |  |  | 122,790 |  |
| Goodwill |  | 188,397 |  |  | 189,696 |  |
| Investments |  | 18,247 |  |  | 8,314 |  |
| Operating lease right-of-use assets |  | 69,374 |  |  | 77,288 |  |
| Deferred tax assets |  | 428,764 |  |  | 441,531 |  |
| Other assets |  | 32,524 |  |  | 30,071 |  |
| TOTAL ASSETS |  | $ | 5,437,350 |  |  | $ | 4,738,919 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 135,252 |  |  | $ | 134,235 |  |
| Accrued liabilities |  | 174,425 |  |  | 143,357 |  |
| Deferred revenue |  | 511,354 |  |  | 396,259 |  |
| Other current liabilities |  | 72,356 |  |  | 94,392 |  |
| Total current liabilities |  | 893,387 |  |  | 768,243 |  |
| Income taxes payable |  | 62,563 |  |  | 53,053 |  |
| Operating lease liabilities, non-current |  | 61,628 |  |  | 72,397 |  |
| Deferred revenue, non-current |  | 289,086 |  |  | 254,568 |  |
| Deferred tax liabilities, non-current |  | 214,261 |  |  | 227,936 |  |
| Other long-term liabilities |  | 51,165 |  |  | 42,431 |  |
| TOTAL LIABILITIES |  | 1,572,090 |  |  | 1,418,628 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 8 |  |  | 8 |  |
| Additional paid-in capital |  | 1,473,595 |  |  | 1,292,431 |  |
| Retained earnings |  | 2,393,661 |  |  | 2,027,614 |  |
| Accumulated other comprehensive income (loss) |  | (2,004) |  |  | 238 |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 3,865,260 |  |  | 3,320,291 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 5,437,350 |  |  | $ | 4,738,919 |  |

[0001596532-21-000351:8k_2_02:60]
7

[0001596532-21-000351:8k_2_02:61]
ARISTA NETWORKS, INC.

[0001596532-21-000351:8k_2_02:62]
Condensed Consolidated Statements of Cash Flows

[0001596532-21-000351:8k_2_02:63]
(Unaudited, in thousands)

[0001596532-21-000351:8k_2_02:64]
|  |  | Nine Months Ended September 30, |
|  |  | 2021 |  | 2020 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 601,559 |  |  | $ | 451,599 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 37,864 |  |  | 31,975 |  |
| Stock-based compensation |  | 135,632 |  |  | 96,947 |  |
| Noncash lease expense |  | 12,738 |  |  | 12,606 |  |
| Deferred income taxes |  | (573) |  |  | 3,261 |  |
| Gain on sale of marketable securities |  | — |  |  | (9,432) |  |
| Amortization of investment premiums |  | 19,193 |  |  | 6,030 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (6,050) |  |  | 98,271 |  |
| Inventories |  | (95,997) |  |  | (193,996) |  |
| Prepaid expenses and other current assets |  | (71,300) |  |  | 38,654 |  |
| Other assets |  | (2,915) |  |  | 7,850 |  |
| Accounts payable |  | (1,075) |  |  | 71,803 |  |
| Accrued liabilities |  | 31,316 |  |  | (29,811) |  |
| Deferred revenue |  | 149,613 |  |  | (34,449) |  |
| Income taxes payable |  | (3,565) |  |  | (1,667) |  |
| Other liabilities |  | (15,820) |  |  | (1,451) |  |
| Net cash provided by operating activities |  | 790,620 |  |  | 548,190 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 1,158,723 |  |  | 1,183,601 |  |
| Purchases of marketable securities |  | (1,974,853) |  |  | (2,216,436) |  |
| Purchases of property and equipment |  | (55,455) |  |  | (7,701) |  |
| Business acquisitions, net of cash acquired |  | — |  |  | (66,317) |  |
| Escrow receipts from past business acquisitions |  | 1,299 |  |  | — |  |
| Sale (purchase) of investments in privately-held companies and intangible assets |  | (10,684) |  |  | 3,399 |  |
| Proceeds from sale of marketable securities |  | 19,607 |  |  | 772,978 |  |
| Net cash used in investing activities |  | (861,363) |  |  | (330,476) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 56,154 |  |  | 42,704 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (10,622) |  |  | (5,932) |  |
| Repurchase of common stock |  | (235,512) |  |  | (395,173) |  |
| Net cash used in financing activities |  | (189,980) |  |  | (358,401) |  |
| Effect of exchange rate changes |  | (1,513) |  |  | (246) |  |
| NET DECREASE IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | (262,236) |  |  | (140,933) |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 897,454 |  |  | 1,115,515 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 635,218 |  |  | $ | 974,582 |  |

[0001596532-21-000351:8k_2_02:65]
8
