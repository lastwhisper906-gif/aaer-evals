# ANET MD&A — 0001596532-21-000354


## mdna

[0001596532-21-000354:mdna:1]
[same as prior period, unchanged from 0001596532-21-000255:mdna:1]

[0001596532-21-000354:mdna:2]
[same as prior period, unchanged from 0001596532-21-000255:mdna:2]

[0001596532-21-000354:mdna:3]
Arista Networks pioneered software-driven, cognitive cloud networking for large-scale data center and campus workspace environments. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our Ethernet switching and routing platforms. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. In recent years, we have sought to bring the operational consistency and principles of cloud networking to the broader enterprise and campus markets with our Cognitive Cloud Networking approach. Our cognitive single-tier SplineTM campus network extends EOS across the campus workspace and the data center. In addition, we have added Cognitive WiFiTM to our portfolio to extend these same cognitive principles to the wireless network. CloudVision®, our network-wide approach for workload orchestration and automation, leverages EOS and Cognitive WiFiTM features, to deliver a turnkey workflow orchestration and automation solution for cloud networking to our enterprise customers.

[0001596532-21-000354:mdna:4]
We generate revenue primarily from sales of our switching and routing platforms, which incorporate our EOS software, and related network applications. We also generate revenue from post-contract support ("PCS"), which end customers typically purchase in conjunction with our products and renewals of PCS. We sell our products through both our direct sales force and our channel partners. As of December 31, 2020, we had delivered our cloud networking solutions to over 7,000 end customers worldwide. Our end customers span a range of industries and include large internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others.

[0001596532-21-000354:mdna:5]
[same as prior period, unchanged from 0001596532-21-000255:mdna:6]

[0001596532-21-000354:mdna:6]
[same as prior period, unchanged from 0001596532-21-000255:mdna:7]

[0001596532-21-000354:mdna:7]
[same as prior period, unchanged from 0001596532-21-000255:mdna:8]

[0001596532-21-000354:mdna:8]
Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic with respect to the underlying merchant silicon architecture. The programmability of EOS has allowed us to expand our software applications to address the ever increasing demands of cloud networking, including workflow automation, network visibility, analytics and network detection and response, and has further allowed us to integrate rapidly with a wide range of third-party applications for virtualization, management, automation, orchestration and network services. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We work closely with third-party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third-party direct fulfillment facilities. We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-21-000354:mdna:9]
[same as prior period, unchanged from 0001596532-21-000255:mdna:10]

[0001596532-21-000354:mdna:10]
The global coronavirus (“COVID-19”) pandemic continues to disrupt and have unpredictable impacts to our global society, economies, financial markets and business activities. We are actively monitoring and evaluating the developments as the situation evolves and will continue to take further actions in our approach to address COVID-19. We have prioritized the protection of our employees during this pandemic and, as a result, our offices across the globe have remained closed since March 2020, limiting access to facilities-based employees and a limited number of employees on a voluntary basis; in addition, we continue to impose some travel restrictions.  In addition, our manufacturing and supply chain operations have experienced significant constraints, with component shortages and delays broadly impacting the industry as a whole. We continue to work closely with our contract manufacturers and supply chain partners who have experienced delays in component sourcing, workforce disruptions and governmental restrictions on the production and export of their products. Although we have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, these delays have negatively impacted our ability to supply products to our customers on a timely basis. We have increased our purchase commitments and expect to continue to invest in working capital to address delays in component

[0001596532-21-000354:mdna:11]
sourcing and the risk of future COVID-19 related supply chain disruptions, but we cannot be certain that such delays or disruptions will not occur.

[0001596532-21-000354:mdna:12]
[same as prior period, unchanged from 0001596532-21-000255:mdna:13]

[0001596532-21-000354:mdna:13]
[same as prior period, unchanged from 0001596532-21-000255:mdna:14]

[0001596532-21-000354:mdna:14]
Three and Nine Months Ended September 30, 2021 Compared to Three and Nine Months Ended September 30, 2020

[0001596532-21-000354:mdna:15]
[same as prior period, unchanged from 0001596532-21-000255:mdna:16]

[0001596532-21-000354:mdna:16]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2021 |  | 2020 |  | Change in |  | 2021 |  | 2020 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 604,160 |  |  | $ | 480,242 |  |  | $ | 123,918 |  |  | 25.8 | % |  | $ | 1,709,772 |  |  | $ | 1,312,561 |  |  | $ | 397,211 |  |  | 30.3 | % |
| Service |  | 144,537 |  |  | 125,189 |  |  | 19,348 |  |  | 15.5 |  |  | 413,806 |  |  | 356,469 |  |  | 57,337 |  |  | 16.1 |  |
| Total revenue |  | 748,697 |  |  | 605,431 |  |  | 143,266 |  |  | 23.7 |  |  | 2,123,578 |  |  | 1,669,030 |  |  | 454,548 |  |  | 27.2 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 243,342 |  |  | 199,465 |  |  | 43,877 |  |  | 22.0 |  |  | 687,554 |  |  | 539,526 |  |  | 148,028 |  |  | 27.4 |  |
| Service |  | 26,740 |  |  | 21,004 |  |  | 5,736 |  |  | 27.3 |  |  | 77,959 |  |  | 62,202 |  |  | 15,757 |  |  | 25.3 |  |
| Total cost of revenue |  | 270,082 |  |  | 220,469 |  |  | 49,613 |  |  | 22.5 |  |  | 765,513 |  |  | 601,728 |  |  | 163,785 |  |  | 27.2 |  |
| Gross profit |  | $ | 478,615 |  |  | $ | 384,962 |  |  | $ | 93,653 |  |  | 24.3 | % |  | $ | 1,358,065 |  |  | $ | 1,067,302 |  |  | $ | 290,763 |  |  | 27.2 | % |
| Gross margin |  | 63.9 | % |  | 63.6 | % |  |  |  |  |  | 64.0 | % |  | 63.9 | % |  |  |  |  |

[0001596532-21-000354:mdna:17]
[same as prior period, unchanged from 0001596532-21-000255:mdna:18]

[0001596532-21-000354:mdna:18]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2021 |  | % of Total |  | 2020 |  | % of Total |  | 2021 |  | % of Total |  | 2020 |  | % of Total |
| Americas |  | $ | 557,814 |  |  | 74.5 | % |  | $ | 452,693 |  |  | 74.8 | % |  | $ | 1,573,835 |  |  | 74.2 | % |  | $ | 1,289,182 |  |  | 77.2 | % |
| Europe, Middle East and Africa |  | 121,722 |  |  | 16.3 |  |  | 89,588 |  |  | 14.8 |  |  | 330,044 |  |  | 15.5 |  |  | 226,189 |  |  | 13.6 |  |
| Asia-Pacific |  | 69,161 |  |  | 9.2 |  |  | 63,150 |  |  | 10.4 |  |  | 219,699 |  |  | 10.3 |  |  | 153,659 |  |  | 9.2 |  |
| Total revenue |  | $ | 748,697 |  |  | 100.0 | % |  | $ | 605,431 |  |  | 100.0 | % |  | $ | 2,123,578 |  |  | 100.0 | % |  | $ | 1,669,030 |  |  | 100.0 | % |

[0001596532-21-000354:mdna:19]
[same as prior period, unchanged from 0001596532-21-000255:mdna:20]

[0001596532-21-000354:mdna:20]
[same as prior period, unchanged from 0001596532-21-000255:mdna:21]

[0001596532-21-000354:mdna:21]
Product revenue increased $123.9 million, or 25.8%, and $397.2 million, or 30.3%, for the three and nine months ended September 30, 2021, respectively, compared to the same periods in 2020. These increases reflected increased demand for our products from new and existing customers, including broader market acceptance of our enterprise and campus products.  Service revenue increased $19.3 million, or 15.5%, and $57.3 million, or 16.1%, in the three and nine months ended September 30, 2021, compared to the same periods in 2020, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenues represented 25.5% and 25.8% of total revenues in the three and nine months ended September 30, 2021, respectively, increasing from 25.2% and 22.8% compared to

[0001596532-21-000354:mdna:22]
the same periods in the prior year. These changes reflected increased international purchases by our large global end customers in addition to increased demand from our in-region end customers. We continued to experience competitive pricing pressure on our products and services.

[0001596532-21-000354:mdna:23]
[same as prior period, unchanged from 0001596532-21-000255:mdna:24]

[0001596532-21-000354:mdna:24]
[same as prior period, unchanged from 0001596532-21-000255:mdna:25]

[0001596532-21-000354:mdna:25]
Cost of revenue increased $49.6 million, or 22.5%, and $163.8 million, or 27.2%, for the three and nine months ended September 30, 2021, respectively, compared to the same periods in 2020. These increases were primarily driven by a corresponding increase in product and service revenues, coupled with an increase in component expedite and manufacturing capacity related costs.

[0001596532-21-000354:mdna:26]
[same as prior period, unchanged from 0001596532-21-000255:mdna:27]

[0001596532-21-000354:mdna:27]
Gross margin increased from 63.6% to 63.9% for the three months ended September 30, 2021, and slightly increased from 63.9% to 64.0% for the nine months ended September 30, 2021, compared to the same periods in 2020. The increases in each period were favorably impacted by a reduced proportion of our sales to larger end customers who generally receive larger discounts, and adversely impacted by increased supply chain and product transition-related costs, including some excess and obsolete inventory-related charges.

[0001596532-21-000354:mdna:28]
[same as prior period, unchanged from 0001596532-21-000255:mdna:29]

[0001596532-21-000354:mdna:29]
[same as prior period, unchanged from 0001596532-21-000255:mdna:30]

[0001596532-21-000354:mdna:30]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2021 |  | 2020 |  | Change in |  | 2021 |  | 2020 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 153,093 |  |  | $ | 128,049 |  |  | $ | 25,044 |  |  | 19.6 | % |  | $ | 428,873 |  |  | $ | 352,747 |  |  | $ | 76,126 |  |  | 21.6 | % |
| Sales and marketing |  | 69,740 |  |  | 53,372 |  |  | 16,368 |  |  | 30.7 |  |  | 211,385 |  |  | 161,695 |  |  | 49,690 |  |  | 30.7 |  |
| General and administrative |  | 22,488 |  |  | 15,146 |  |  | 7,342 |  |  | 48.5 |  |  | 58,856 |  |  | 47,814 |  |  | 11,042 |  |  | 23.1 |  |
| Total operating expenses |  | $ | 245,321 |  |  | $ | 196,567 |  |  | $ | 48,754 |  |  | 24.8 | % |  | $ | 699,114 |  |  | $ | 562,256 |  |  | $ | 136,858 |  |  | 24.3 | % |

[0001596532-21-000354:mdna:31]
[same as prior period, unchanged from 0001596532-21-000255:mdna:32]

[0001596532-21-000354:mdna:32]
[same as prior period, unchanged from 0001596532-21-000255:mdna:33]

[0001596532-21-000354:mdna:33]
Research and development expenses increased $25.0 million, or 19.6%, and $76.1 million, or 21.6%, in the three and nine months ended September 30, 2021, respectively, compared to the same periods in 2020. The increases were primarily driven by an increase in personnel costs of $17.9 million and $53.6 million for the three and nine months ended September 30, 2021, respectively, compared to the same periods in 2020 mainly due to headcount growth. In addition, new product introduction costs increased by $3.2 million and $24.1 million for the three and nine months ended September 30, 2021,

[0001596532-21-000354:mdna:34]
respectively, compared to the same periods in 2020. These increases were partly offset by a decrease in merger-related costs of $5.9 million for the nine months ended September 30, 2021, compared to the same period in 2020, associated with our acquisition of Big Switch Networks ("Big Switch") in 2020.

[0001596532-21-000354:mdna:35]
[same as prior period, unchanged from 0001596532-21-000255:mdna:36]

[0001596532-21-000354:mdna:36]
[same as prior period, unchanged from 0001596532-21-000255:mdna:37]

[0001596532-21-000354:mdna:37]
Sales and marketing expenses increased $16.4 million, or 30.7%, and $49.7 million, or 30.7%, for the three and nine months ended September 30, 2021, respectively, compared to the same periods in 2020, which was primarily caused by increased personnel costs driven by headcount growth.

[0001596532-21-000354:mdna:38]
[same as prior period, unchanged from 0001596532-21-000255:mdna:39]

[0001596532-21-000354:mdna:39]
[same as prior period, unchanged from 0001596532-21-000255:mdna:40]

[0001596532-21-000354:mdna:40]
General and administrative expenses increased $7.3 million, or 48.5%, and $11.0 million, or 23.1%, in the three and nine months ended September 30, 2021 compared to the same periods in 2020, which was primarily driven by increased personnel costs which primarily consists of increased stock-based compensation expenses.

[0001596532-21-000354:mdna:41]
[same as prior period, unchanged from 0001596532-21-000255:mdna:42]

[0001596532-21-000354:mdna:42]
[same as prior period, unchanged from 0001596532-21-000255:mdna:43]

[0001596532-21-000354:mdna:43]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2021 |  | 2020 |  | Change in |  | 2021 |  | 2020 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 1,636 |  |  | $ | 4,319 |  |  | $ | (2,683) |  |  | (62.1) | % |  | $ | 5,553 |  |  | $ | 24,649 |  |  | $ | (19,096) |  |  | (77.5) | % |
| Gain on sale of marketable securities |  | — |  |  | 9,432 |  |  | (9,432) |  |  | (100.0) |  |  | — |  |  | 9,432 |  |  | (9,432) |  |  | (100.0) |  |
| Other income (expense), net |  | (290) |  |  | (527) |  |  | 237 |  |  | (45.0) |  |  | (913) |  |  | (444) |  |  | (469) |  |  | 105.6 |  |
| Total other income, net |  | $ | 1,346 |  |  | $ | 13,224 |  |  | $ | (11,878) |  |  | (89.8) | % |  | $ | 4,640 |  |  | $ | 33,637 |  |  | $ | (28,997) |  |  | (86.2) | % |

[0001596532-21-000354:mdna:44]
The unfavorable change in other income, net, during the three and nine months ended September 30, 2021 as compared to the same periods in 2020 was primarily caused by significant declines in the yields of government and corporate bonds in our investment portfolio. In addition, we recorded a gain on sale of marketable securities in the three and nine months ended September 30, 2020, which did not recur in the current periods presented.

[0001596532-21-000354:mdna:45]
[same as prior period, unchanged from 0001596532-21-000255:mdna:46]

[0001596532-21-000354:mdna:46]
[same as prior period, unchanged from 0001596532-21-000255:mdna:47]

[0001596532-21-000354:mdna:47]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  |  | 2021 |  | 2020 |  | Change in |  | 2021 |  | 2020 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 234,640 |  |  | $ | 201,619 |  |  | $ | 33,021 |  |  | 16.4 | % |  | $ | 663,591 |  |  | $ | 538,683 |  |  | $ | 124,908 |  |  | 23.2 | % |
| Provision for income taxes |  | 10,335 |  |  | 33,244 |  |  | (22,909) |  |  | (68.9) | % |  | 62,032 |  |  | 87,084 |  |  | (25,052) |  |  | (28.8) | % |
| Effective tax rate |  | 4.4 | % |  | 16.5 | % |  |  |  |  |  | 9.3 | % |  | 16.2 | % |  |  |  |  |

[0001596532-21-000354:mdna:48]
Despite an increase in pre-tax income in each period of 2021 as compared to 2020, our provision for income taxes for the three and nine months ended September 30, 2021, as compared to the same periods in 2020, decreased due to higher tax benefits attributable to stock-based awards, combined with a favorable change in jurisdictional mix of earnings.

[0001596532-21-000354:mdna:49]
[same as prior period, unchanged from 0001596532-21-000255:mdna:50]

[0001596532-21-000354:mdna:50]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of September 30, 2021, our total balance of cash, cash equivalents and marketable securities was approximately $3.4 billion, of which approximately $493.8 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-21-000354:mdna:51]
[same as prior period, unchanged from 0001596532-21-000255:mdna:52]

[0001596532-21-000354:mdna:52]
[same as prior period, unchanged from 0001596532-21-000255:mdna:53]

[0001596532-21-000354:mdna:53]
|  |  | Nine Months Ended September 30, |
|  |  | 2021 |  | 2020 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 790,620 |  |  | $ | 548,190 |  |
| Cash used in investing activities |  | (861,363) |  |  | (330,476) |  |
| Cash used in financing activities |  | (189,980) |  |  | (358,401) |  |
| Effect of exchange rate changes |  | (1,513) |  |  | (246) |  |
| Net decrease in cash, cash equivalents and restricted cash |  | $ | (262,236) |  |  | $ | (140,933) |  |

[0001596532-21-000354:mdna:54]
[same as prior period, unchanged from 0001596532-21-000255:mdna:55]

[0001596532-21-000354:mdna:55]
During the nine months ended September 30, 2021, cash provided by operating activities was $790.6 million, primarily from net income of $601.6 million and non-cash adjustments to net income of $204.8 million driven by stock-based compensation and depreciation and amortization, and a net increase of $15.8 million in working capital requirements. The increase in working capital requirements primarily consisted of a $96.0 million increase in inventory and a $71.3 million increase in prepaid expenses primarily due to prepaid income taxes and deferred product cost of revenue. These cash outflows were largely offset by a $149.6 million increase in product and service deferred revenue driven by customer contracts with acceptance terms and growth in PCS contracts, and a $31.3 million increase in accrued liabilities due to additional supply chain and software development costs.

[0001596532-21-000354:mdna:56]
During the nine months ended September 30, 2020, cash provided by operating activities was $548.2 million, primarily from net income of $451.6 million and non-cash adjustments to net income of $141.4 million driven by stock-based compensation and depreciation and amortization, and a net $44.8 million increase in working capital requirements. This increase in working capital primarily consisted of a $194.0 million increase in inventory to help mitigate COVID-19 related

[0001596532-21-000354:mdna:57]
supply chain disruptions, a $34.4 million decrease in deferred revenue, and a $29.8 million decrease in accrued liabilities related to the timing of corporate bonus payouts. These working capital increases were partially offset by a $98.3 million decrease in accounts receivable due to strong collections, a $71.8 million increase in accounts payable related to the timing of production receipts, and a $38.7 million decrease in prepaid expenses.

[0001596532-21-000354:mdna:58]
[same as prior period, unchanged from 0001596532-21-000255:mdna:58]

[0001596532-21-000354:mdna:59]
During the nine months ended September 30, 2021, cash used in investing activities was $861.4 million, consisting of purchases of available-for-sale marketable securities of $1,974.9 million, and purchases of property and equipment of $55.5 million, partially offset by proceeds from maturities of marketable securities of $1,158.7 million and proceeds from sale of marketable securities of $19.6 million.

[0001596532-21-000354:mdna:60]
During the nine months ended September 30, 2020, cash used in investing activities was $330.5 million, consisting of purchases of available-for-sale marketable securities of $2,216.5 million, $66.3 million for the acquisition of Big Switch, and purchases of property and equipment of $7.7 million, partially offset by proceeds from maturities of marketable securities of $1,183.6 million, proceeds from the sale of marketable securities of $773.0 million and proceeds from the sale of one of our investments in privately-held companies of $3.4 million.

[0001596532-21-000354:mdna:61]
[same as prior period, unchanged from 0001596532-21-000255:mdna:61]

[0001596532-21-000354:mdna:62]
During the nine months ended September 30, 2021, cash used in financing activities was $190.0 million, consisting of payments for repurchases of our common stock from the open market of $235.5 million, and employee taxes withheld and paid of $10.6 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $56.1 million.

[0001596532-21-000354:mdna:63]
During the nine months ended September 30, 2020, cash used in financing activities was $358.4 million, consisting of payments for repurchases of our common stock from the open market of $395.2 million and taxes paid of $5.9 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $42.7 million.

[0001596532-21-000354:mdna:64]
Stock Repurchase Programs

[0001596532-21-000354:mdna:65]
From time to time, we repurchase our common stock pursuant to our stock Repurchase Programs. The Existing Repurchase Program allows for stock repurchases of up to $1.0 billion through April 2022 and the New Repurchase Program allows for additional stock repurchases of up to $1.0 billion, and these repurchases are funded from working capital. The Repurchase Programs do not obligate us to acquire any of our common stock and may be suspended or discontinued by us at any time without prior notice. During the quarter ended September 30, 2021, we repurchased a total of $134.2 million of our common stock. As of September 30, 2021, the remaining authorized amount for repurchases under the Existing Repurchase Program was $103.2 million and no repurchases have been made under the New Repurchase Program. Refer to Note 6. Stockholders' Equity and Stock-based Compensation and Note 10. Subsequent Events of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-21-000354:mdna:66]
Common Stock Split

[0001596532-21-000354:mdna:67]
On November 1, 2021, the Company announced a four-for-one split of its common stock effected in the form of a stock dividend to shareholders of record as of the close of business on November 11, 2021. The stock dividend payment date is expected to be on or about November 17, 2021, and trading of the Company’s common stock will begin on a split-adjusted basis on or about November 18, 2021.

[0001596532-21-000354:mdna:68]
[same as prior period, unchanged from 0001596532-21-000255:mdna:66]

[0001596532-21-000354:mdna:69]
As of September 30, 2021, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-21-000354:mdna:70]
[same as prior period, unchanged from 0001596532-21-000255:mdna:68]

[0001596532-21-000354:mdna:71]
Our contractual commitments will have an impact on our future liquidity. Our contractual obligations represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalent and marketable securities. As of September 30, 2021, our principal commitments consist primarily of obligations under operating leases for offices and data centers and purchase commitments with our contract manufacturers and suppliers. See Note 5. Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for our purchase commitments as of September 30, 2021.

[0001596532-21-000354:mdna:72]
[same as prior period, unchanged from 0001596532-21-000255:mdna:70]

[0001596532-21-000354:mdna:73]
[same as prior period, unchanged from 0001596532-21-000255:mdna:71]

[0001596532-21-000354:mdna:74]
[same as prior period, unchanged from 0001596532-21-000255:mdna:72]

[0001596532-21-000354:mdna:75]
Refer to the subheading titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
