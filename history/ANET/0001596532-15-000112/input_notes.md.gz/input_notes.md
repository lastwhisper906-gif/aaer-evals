# ANET notes — 0001596532-15-000112


## anet:ConcentrationRiskComponentsSupplierRiskPolicyTextBlock

[0001596532-15-000112:notes:1]
[same as prior period, unchanged from 0001596532-15-000013:notes:1]


## anet:ScheduleofLeaseFinancingObligationsTableTextBlock

[0001596532-15-000112:notes:2]
[same as prior period, unchanged from 0001596532-15-000013:notes:2]

[0001596532-15-000112:notes:3]
[same as prior period, unchanged from 0001596532-15-000013:notes:3]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001596532-15-000112:notes:4]
[same as prior period, unchanged from 0001596532-15-000013:notes:4]

[0001596532-15-000112:notes:5]
[same as prior period, unchanged from 0001596532-15-000013:notes:5]

[0001596532-15-000112:notes:6]
[same as prior period, unchanged from 0001596532-15-000013:notes:6]

[0001596532-15-000112:notes:7]
[same as prior period, unchanged from 0001596532-15-000013:notes:7]

[0001596532-15-000112:notes:8]
[same as prior period, unchanged from 0001596532-15-000013:notes:8]

[0001596532-15-000112:notes:9]
[same as prior period, unchanged from 0001596532-15-000013:notes:9]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-15-000112:notes:10]
Commitments and Contingencies

[0001596532-15-000112:notes:11]
Operating Leases

[0001596532-15-000112:notes:12]
We lease various operating spaces in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2023. These arrangements require us to pay certain operating expenses, such as taxes, repairs, and insurance and contain renewal and escalation clauses. We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.

[0001596532-15-000112:notes:13]
As of December 31, 2014, the aggregate future minimum payments under non-cancelable operating leases consist of the following (in thousands):

[0001596532-15-000112:notes:14]
| Years Ending December 31, |  |
| 2015 | $ | 2,583 |  |
| 2016 | 4,297 |  |
| 2017 | 5,155 |  |
| 2018 | 5,378 |  |
| 2019 | 5,369 |  |
| Thereafter | 22,407 |  |
| Total minimum future lease payments | $ | 45,189 |  |

[0001596532-15-000112:notes:15]
Rent expense for all operating leases amounted to $0.8 million and $0.6 million for the three months ended March 31, 2015 and 2014, respectively.

[0001596532-15-000112:notes:16]
Financing Obligation—Build-to-Suit Lease

[0001596532-15-000112:notes:17]
In August 2012, we executed a lease for a building under construction in Santa Clara, California which will serve as our new headquarters. The lease term is 120 months and commenced in August 2013.

[0001596532-15-000112:notes:18]
Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction such as our financial involvement in structural elements of asset construction, making decisions related to tenant improvement costs and purchasing insurance not reimbursable by the buyer-lessor (the Landlord), we are deemed the owner of the building (for accounting purposes only) during the construction period. We maintained continued involvement in the property after construction was completed and lack transferability of the risks and rewards of ownership, primarily due to our required maintenance of a $4.0 million letter of credit. Due to our continuing involvement in the property post construction and lack of transferability of related risks and rewards of ownership to the Landlord after construction is complete, we account for the building and related improvements as a lease financing obligation. Accordingly, as of March 31, 2015 and December 31, 2014, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $43.4 million and $43.6 million, respectively. As of March 31, 2015, $1.2 million and $42.2 million were recorded as short-term and long-term financing obligations, respectively.

[0001596532-15-000112:notes:19]
Land lease expense under our lease financing obligation amounted to $0.3 million and $0.3 million for the three months ended March 31, 2015 and 2014, respectively.

[0001596532-15-000112:notes:20]
Upon completion of construction in the third quarter of 2013, we evaluated the de-recognition of the asset and liability under the sale-leaseback accounting guidance. We concluded that we have forms of continued economic involvement in the facility, and therefore did not meet with the provisions for sale-leaseback accounting. Therefore, the lease is accounted for as a financing obligation and lease payments will be attributed to (1) a reduction of the principal financing obligation; (2) imputed interest expense; and (3) land lease expense (which is considered an operating lease and a component of cost of goods sold and operating expenses) representing an imputed cost to lease the underlying land of the building. In addition, the underlying building asset is depreciated over the building’s estimated useful life of 30 years. At the conclusion of the initial lease term, we will de-recognize both the net book values of the asset and the remaining financing obligation.

[0001596532-15-000112:notes:21]
Purchase Commitments

[0001596532-15-000112:notes:22]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. These forecasts are based on estimates of future demand for our products, historical trend analysis provided by our sales and product marketing organizations and adjusted for overall market conditions. We incur a liability when the contract manufacturer has converted the component inventory to a finished product.  However, historically we have reimbursed our contract manufacturer for component inventory purchases when this inventory has been rendered excess or obsolete due to manufacturing and engineering change orders resulting from design changes, or in cases where inventory levels greatly exceed our forecasts. As of March 31, 2015 and December 31, 2014, $0.2 million and $0.3 million related to the excess and obsolete component inventory liability to our contract manufacturers.  We have provided restricted deposits to our third-party contract manufacturers and vendors to secure our obligations to purchase inventory. We had $2.3 million in restricted deposits as of March 31, 2015 and December 31, 2014. Restricted deposits are classified in other assets in our accompanying unaudited condensed consolidated balance sheets.

[0001596532-15-000112:notes:23]
Guarantees

[0001596532-15-000112:notes:24]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers the unamortized value of the product based on its estimated useful life. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for lease facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-15-000112:notes:25]
Legal Proceedings

[0001596532-15-000112:notes:26]
OptumSoft, Inc. Matters

[0001596532-15-000112:notes:27]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-15-000112:notes:28]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft copies of certain components of our software for evaluation by OptumSoft, (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches, (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers, (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us, and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dtd July 27, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders. OptumSoft has identified in confidential documents certain software components it claims to own, which are generally applicable tools and utility subroutines and not networking specific code. We cannot assure which software components OptumSoft may ultimately claim to own in the litigation or whether such claimed components are material.

[0001596532-15-000112:notes:29]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we assert our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we assert that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We ask the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also assert that, even if we are found not to own any particular components at issue, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have strong defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-15-000112:notes:30]
The Court set a trial date for Phase I of the proceedings, relating to contract interpretation and application of the contract to certain claimed source code for September 14, 2015.  The remaining issues are currently scheduled to be tried in April 2016.

[0001596532-15-000112:notes:31]
At this stage of the litigation, we are unable to determine whether a loss is probable or estimate a possible or range of possible loss.

[0001596532-15-000112:notes:32]
We intend to vigorously defend against any action brought against us by OptumSoft. However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor. For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft. If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license. In addition, if OptumSoft were to bring actual litigation, it could assert additional or different claims against us, including claims that our license from OptumSoft is invalid. An adverse litigation ruling could result in a significant damages award against us and injunctive relief. In addition, if our license was ruled to have been terminated, and we were not able to negotiate a new license from OptumSoft on reasonable terms, we could be prohibited from selling products that incorporate OptumSoft intellectual property. Any such adverse ruling could materially adversely affect our business, prospects, results of operations and financial condition. Whether or not we prevail in a lawsuit, we expect that any litigation would be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-15-000112:notes:33]
Cisco Systems, Inc. (“Cisco”) Matters

[0001596532-15-000112:notes:34]
On December 5, 2014, Cisco filed two complaints against us in District Court for the Northern District of California, which are proceeding as Case No. 4-14-cv-05343 (“’43 Case”) and Case No. 4-14-cv-05344 (“’44 Case”).  In the ’43 Case, Cisco alleges that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the 875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”).  Cisco seeks, as relief for our alleged infringement in the ’43 Case, lost profits and/or reasonable royalty damages in an unspecified amount, including treble damages, attorney’s fees, and associated costs.  Cisco also seeks injunctive relief in the ’43 Case.  On February 10, 2015, the court granted our unopposed motion to stay the ’43 Case until the proceedings before the United States International Trade Commission (“USITC”) pertaining to the same patents (as discussed below) become final.  In the ’44 Case, Cisco’s complaint alleges that we infringe U.S. Patent Nos. 7,047,526 and 7,953,886 and further alleges that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI.”  As relief for our alleged patent infringement in the ’44 Case, Cisco seeks lost profits and/or reasonable royalty damages in an unspecified amount including treble damages, attorney’s fees, and associated costs as well as injunctive relief.  As relief from our alleged copyright infringement, Cisco seeks damages in an unspecified amount in the form of alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees and associated costs.  Cisco also seeks injunctive relief against our alleged copyright infringement.  On February 13, 2015, we answered the complaint in the ’44 Case, denying the patent and copyright infringement allegations and also raising numerous affirmative defenses.  On March 6, 2015, Cisco filed an amended complaint against in the ’44 Case.  In response, we moved to dismiss Cisco’s allegations of willful patent infringement and pre-suit indirect patent infringement.  A hearing on our motion to dismiss is scheduled for July 2, 2015.  Trial has not been scheduled in either the ’43 or ’44 Cases.

[0001596532-15-000112:notes:35]
On December 19, 2014, Cisco filed two complaints against us in the USITC alleging that Arista has violated section 337 of the Tariff Act of 1930, as amended. The complaints have been instituted as ITC Inv. Nos. 337-TA-944 (“’944 Investigation”) and 337-TA-945 (“’945 Investigation).   In the ’944 Investigation, Cisco alleges that certain Arista switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.  In the ’945 Investigation, Cisco alleges that certain Arista switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents.  In both the ’944 and ’945 Investigations, Cisco seeks, among other things, a limited exclusion order barring entry into the United States of accused switch products (including 7000 Series of switches) and a cease and desist order against us restricting our activities with respect to our imported accused switch products.  On January 28, 2015, the Administrative Law Judge assigned to the ’944 Investigation set May 27, 2016 as the target date for completion of the ’944 Investigation.  On February 11, 2015, we responded to the notices of investigation and complaints in the ’944 and ’945 Investigations by, among other things, denying any violation of section 337 of the Tariff Act and the patent infringement allegations, and raising numerous additional defenses.  On February 19, 2015, the Administrative Law Judge assigned to the ’945 Investigation issued a procedural schedule calling for, among other events:  issuance of an order construing the claims of the ’577, ’853, ’875, ’668, ’492, and ’211 patents tentatively on July 17, 2015; an evidentiary hearing on November 9-20, 2015; issuance of an initial determination regarding our alleged violations on April 26, 2016; and the target date for completion of the ’945 Investigation on August 26, 2016. On March 9, 2015, the Administrative Law Judge assigned to the ’944 Investigation issued a procedural schedule calling for, among other events:  an evidentiary hearing on Sept. 9-11 & 15-17, 2015 and issuance of an initial determination regarding our alleged violations on January 27, 2016.

[0001596532-15-000112:notes:36]
On April 1, 2015, we filed petitions for Inter Partes Review with the United States Patent Trial and Appeal Board (“PTAB”) seeking to invalidate Cisco’s ’597, ’211, and ’668 patents.  On April 10, 2015, we filed petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853 and ’577 patents.  On April 16, 2015, we filed additional petitions for Inter Partes Review with the PTAB seeking to invalidate Cisco’s ’853 and ’577 patents.  We expect that the PTAB will determine whether or not to institute review of the validity with respect to each of our petitions for Inter Partes Review within six months of the filing dates for those petitions.  To the extent that the PTAB grants our petitions and institutes review, the PTAB must issue its final written decision on validity within twelve months of its institution decision.

[0001596532-15-000112:notes:37]
We intend to vigorously defend against Cisco’s lawsuits, as summarized in the preceding paragraphs.  However, we cannot be certain that, if litigated, any claims by Cisco would be resolved in our favor.  For example, an adverse litigation ruling could result in a significant damages award against us, could further result in the above described injunctive relief (including, among other things, an order excluding our products from importation into the United States), could result in a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products to the extent that we are found to infringe any valid claims asserted against us by Cisco. In particular, with respect to the ‘944 and ‘945 Investigations, if our products are found to infringe any patents that are the subject of those investigations, the USITC would likely issue a limited exclusion order barring entry into the United States of accused switch products (including 7000 Series of switches) and a cease and desist order restricting our activities with respect to our imported accused switch products. In the case that we attempt to modify our manufacturing and importation processes to comply with such orders, we may not be able to do so successfully or without substantial expense. Moreover, in the case we attempt to modify our products, to the extent we are found to infringe on any valid claims asserted against us, we may not be able to successfully modify our products in a substantial manner and any modified products may not be well received in the market.  Any such adverse ruling could materially adversely affect our business, prospects, results of operation and financial condition.  To the extent that we reached a negotiated settlement with Cisco, the settlement could require payment of substantial royalties.  Additionally, the existence of this lawsuit could cause concern among our customers and potential customers and could adversely affect our business and results of operations.  Whether or not we prevail in the lawsuit, we expect that the litigation will be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-15-000112:notes:38]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. Based on currently available information, management does not believe that the ultimate outcome of these other unresolved matters is probable or estimable and not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001596532-15-000112:notes:39]
[same as prior period, unchanged from 0001596532-15-000013:notes:39]

[0001596532-15-000112:notes:40]
[same as prior period, unchanged from 0001596532-15-000013:notes:40]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-15-000112:notes:41]
[same as prior period, unchanged from 0001596532-15-000013:notes:41]

[0001596532-15-000112:notes:42]
[same as prior period, unchanged from 0001596532-15-000013:notes:42]

[0001596532-15-000112:notes:43]
[same as prior period, unchanged from 0001596532-15-000013:notes:43]

[0001596532-15-000112:notes:44]
[same as prior period, unchanged from 0001596532-15-000013:notes:44]

[0001596532-15-000112:notes:45]
[same as prior period, unchanged from 0001596532-15-000013:notes:45]

[0001596532-15-000112:notes:46]
[same as prior period, unchanged from 0001596532-15-000013:notes:46]

[0001596532-15-000112:notes:47]
[same as prior period, unchanged from 0001596532-15-000013:notes:47]

[0001596532-15-000112:notes:48]
[same as prior period, unchanged from 0001596532-15-000013:notes:48]

[0001596532-15-000112:notes:49]
[same as prior period, unchanged from 0001596532-15-000013:notes:49]

[0001596532-15-000112:notes:50]
[same as prior period, unchanged from 0001596532-15-000013:notes:50]

[0001596532-15-000112:notes:51]
[same as prior period, unchanged from 0001596532-15-000013:notes:51]

[0001596532-15-000112:notes:52]
[same as prior period, unchanged from 0001596532-15-000013:notes:52]

[0001596532-15-000112:notes:53]
[same as prior period, unchanged from 0001596532-15-000013:notes:53]

[0001596532-15-000112:notes:54]
[same as prior period, unchanged from 0001596532-15-000013:notes:54]

[0001596532-15-000112:notes:55]
[same as prior period, unchanged from 0001596532-15-000013:notes:55]

[0001596532-15-000112:notes:56]
[same as prior period, unchanged from 0001596532-15-000013:notes:56]

[0001596532-15-000112:notes:57]
[same as prior period, unchanged from 0001596532-15-000013:notes:57]


## us-gaap:EarningsPerShareTextBlock

[0001596532-15-000112:notes:58]
[same as prior period, unchanged from 0001596532-15-000013:notes:58]

[0001596532-15-000112:notes:59]
[same as prior period, unchanged from 0001596532-15-000013:notes:59]

[0001596532-15-000112:notes:60]
[same as prior period, unchanged from 0001596532-15-000013:notes:60]

[0001596532-15-000112:notes:61]
[same as prior period, unchanged from 0001596532-15-000013:notes:61]

[0001596532-15-000112:notes:62]
[same as prior period, unchanged from 0001596532-15-000013:notes:62]


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-15-000112:notes:63]
[same as prior period, unchanged from 0001596532-15-000013:notes:63]

[0001596532-15-000112:notes:64]
[same as prior period, unchanged from 0001596532-15-000013:notes:64]

[0001596532-15-000112:notes:65]
[same as prior period, unchanged from 0001596532-15-000013:notes:65]


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-15-000112:notes:66]
[same as prior period, unchanged from 0001596532-15-000013:notes:66]

[0001596532-15-000112:notes:67]
[same as prior period, unchanged from 0001596532-15-000013:notes:67]

[0001596532-15-000112:notes:68]
[same as prior period, unchanged from 0001596532-15-000013:notes:68]

[0001596532-15-000112:notes:69]
[same as prior period, unchanged from 0001596532-15-000013:notes:69]

[0001596532-15-000112:notes:70]
[same as prior period, unchanged from 0001596532-15-000013:notes:70]

[0001596532-15-000112:notes:71]
[same as prior period, unchanged from 0001596532-15-000013:notes:71]

[0001596532-15-000112:notes:72]
[same as prior period, unchanged from 0001596532-15-000013:notes:72]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-15-000112:notes:73]
[same as prior period, unchanged from 0001596532-15-000013:notes:73]

[0001596532-15-000112:notes:74]
[same as prior period, unchanged from 0001596532-15-000013:notes:74]

[0001596532-15-000112:notes:75]
[same as prior period, unchanged from 0001596532-15-000013:notes:75]

[0001596532-15-000112:notes:76]
[same as prior period, unchanged from 0001596532-15-000013:notes:76]

[0001596532-15-000112:notes:77]
[same as prior period, unchanged from 0001596532-15-000013:notes:77]


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001596532-15-000112:notes:78]
[same as prior period, unchanged from 0001596532-15-000013:notes:78]

[0001596532-15-000112:notes:79]
[same as prior period, unchanged from 0001596532-15-000013:notes:79]

[0001596532-15-000112:notes:80]
[same as prior period, unchanged from 0001596532-15-000013:notes:80]

[0001596532-15-000112:notes:81]
[same as prior period, unchanged from 0001596532-15-000013:notes:81]

[0001596532-15-000112:notes:82]
[same as prior period, unchanged from 0001596532-15-000013:notes:82]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-15-000112:notes:83]
In May 2014, the FASB issued ASU No. 2014-09, Revenue From Contracts With Customers, which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The standard is effective for fiscal years (and interim reporting periods within those years) beginning after December 15, 2016. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. We are currently reviewing the provisions of the standard and have not yet selected a transition method nor have we determined the effect of the standard on our consolidated financial statements.

[0001596532-15-000112:notes:84]
In April 2015, the FASB issued ASU No. 2015-05, Intangibles—Goodwill and Other—Internal-Use Software, which  clarifies the circumstances under which a cloud computing customer would account for the arrangement as a license of internal-use software. A cloud computing arrangement would include a software license if (1) the customer has a contractual right to take possession of the software at any time during the hosting period without significant penalty and (2) it is feasible for the customer to either run the software on its own hardware or contract with another party unrelated to the vendor to host the software. If the arrangement does not contain a software license, it would be accounted for as a service contract. The guidance is effective for fiscal years beginning after December 15, 2015. Early adoption is permitted. The guidance can be applied retrospectively to each prior reporting period presented or prospectively to arrangements entered into, or materially modified, after the effective date. We are currently assessing the impact this guidance may have on our consolidated financial statements as well as the transition method that we will use to adopt the guidance.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-15-000112:notes:85]
[same as prior period, unchanged from 0001596532-15-000013:notes:85]

[0001596532-15-000112:notes:86]
[same as prior period, unchanged from 0001596532-15-000013:notes:86]

[0001596532-15-000112:notes:87]
[same as prior period, unchanged from 0001596532-15-000013:notes:87]

[0001596532-15-000112:notes:88]
[same as prior period, unchanged from 0001596532-15-000013:notes:88]

[0001596532-15-000112:notes:89]
[same as prior period, unchanged from 0001596532-15-000013:notes:89]

[0001596532-15-000112:notes:90]
[same as prior period, unchanged from 0001596532-15-000013:notes:90]

[0001596532-15-000112:notes:91]
[same as prior period, unchanged from 0001596532-15-000013:notes:91]

[0001596532-15-000112:notes:92]
[same as prior period, unchanged from 0001596532-15-000013:notes:92]

[0001596532-15-000112:notes:93]
[same as prior period, unchanged from 0001596532-15-000013:notes:93]

[0001596532-15-000112:notes:94]
[same as prior period, unchanged from 0001596532-15-000013:notes:94]

[0001596532-15-000112:notes:95]
[same as prior period, unchanged from 0001596532-15-000013:notes:95]

[0001596532-15-000112:notes:96]
[same as prior period, unchanged from 0001596532-15-000013:notes:96]


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001596532-15-000112:notes:97]
[same as prior period, unchanged from 0001596532-15-000013:notes:97]

[0001596532-15-000112:notes:98]
[same as prior period, unchanged from 0001596532-15-000013:notes:98]


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001596532-15-000112:notes:99]
[same as prior period, unchanged from 0001596532-15-000013:notes:99]

[0001596532-15-000112:notes:100]
[same as prior period, unchanged from 0001596532-15-000013:notes:100]


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001596532-15-000112:notes:101]
[same as prior period, unchanged from 0001596532-15-000013:notes:101]

[0001596532-15-000112:notes:102]
[same as prior period, unchanged from 0001596532-15-000013:notes:102]


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001596532-15-000112:notes:103]
[same as prior period, unchanged from 0001596532-15-000013:notes:103]

[0001596532-15-000112:notes:104]
[same as prior period, unchanged from 0001596532-15-000013:notes:104]

[0001596532-15-000112:notes:105]
[same as prior period, unchanged from 0001596532-15-000013:notes:105]


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001596532-15-000112:notes:106]
[same as prior period, unchanged from 0001596532-15-000013:notes:106]

[0001596532-15-000112:notes:107]
[same as prior period, unchanged from 0001596532-15-000013:notes:107]


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001596532-15-000112:notes:108]
[same as prior period, unchanged from 0001596532-15-000013:notes:108]

[0001596532-15-000112:notes:109]
[same as prior period, unchanged from 0001596532-15-000013:notes:109]


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001596532-15-000112:notes:110]
[same as prior period, unchanged from 0001596532-15-000013:notes:110]

[0001596532-15-000112:notes:111]
[same as prior period, unchanged from 0001596532-15-000013:notes:111]


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001596532-15-000112:notes:112]
[same as prior period, unchanged from 0001596532-15-000013:notes:112]

[0001596532-15-000112:notes:113]
[same as prior period, unchanged from 0001596532-15-000013:notes:113]

[0001596532-15-000112:notes:114]
[same as prior period, unchanged from 0001596532-15-000013:notes:114]

[0001596532-15-000112:notes:115]
[same as prior period, unchanged from 0001596532-15-000013:notes:115]

[0001596532-15-000112:notes:116]
[same as prior period, unchanged from 0001596532-15-000013:notes:116]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-15-000112:notes:117]
[same as prior period, unchanged from 0001596532-15-000013:notes:117]

[0001596532-15-000112:notes:118]
[same as prior period, unchanged from 0001596532-15-000013:notes:118]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-15-000112:notes:119]
[same as prior period, unchanged from 0001596532-15-000013:notes:119]

[0001596532-15-000112:notes:120]
[same as prior period, unchanged from 0001596532-15-000013:notes:120]

[0001596532-15-000112:notes:121]
[same as prior period, unchanged from 0001596532-15-000013:notes:121]

[0001596532-15-000112:notes:122]
[same as prior period, unchanged from 0001596532-15-000013:notes:122]

[0001596532-15-000112:notes:123]
[same as prior period, unchanged from 0001596532-15-000013:notes:123]

[0001596532-15-000112:notes:124]
[same as prior period, unchanged from 0001596532-15-000013:notes:124]

[0001596532-15-000112:notes:125]
[same as prior period, unchanged from 0001596532-15-000013:notes:125]

[0001596532-15-000112:notes:126]
[same as prior period, unchanged from 0001596532-15-000013:notes:126]

[0001596532-15-000112:notes:127]
[same as prior period, unchanged from 0001596532-15-000013:notes:127]

[0001596532-15-000112:notes:128]
Building consists of capitalized construction costs of our leased building in Santa Clara, California. Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction, such as our financial involvement in structural elements of asset construction, making decisions related to tenant improvement costs and purchasing insurance not reimbursable by the buyer-lessor (the Landlord), we are deemed the owner of the building (for accounting purposes only) during the construction period. We maintain continued involvement in the property after construction was completed and lack transferability of the risks and rewards of ownership, primarily due to our required maintenance of a $4.0 million letter of credit.  Due to our continuing involvement in the property post construction and lack of transferability of related risks and rewards of ownership to the Landlord after construction is complete, we account for the building as a financing obligation. See “Note 5-Commitments and Contingencies". Accordingly, as of March 31, 2015 and December 31, 2014, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the Landlord. The building was completed in 2014.

[0001596532-15-000112:notes:129]
[same as prior period, unchanged from 0001596532-15-000013:notes:129]

[0001596532-15-000112:notes:130]
[same as prior period, unchanged from 0001596532-15-000013:notes:130]

[0001596532-15-000112:notes:131]
[same as prior period, unchanged from 0001596532-15-000013:notes:131]

[0001596532-15-000112:notes:132]
[same as prior period, unchanged from 0001596532-15-000013:notes:132]

[0001596532-15-000112:notes:133]
[same as prior period, unchanged from 0001596532-15-000013:notes:133]
