# ANET MD&A — 0001596532-15-000112


## mdna

[0001596532-15-000112:mdna:1]
[same as prior period, unchanged from 0001596532-15-000013:mdna:1]

[0001596532-15-000112:mdna:2]
[same as prior period, unchanged from 0001596532-15-000013:mdna:2]

[0001596532-15-000112:mdna:3]
We are a leading supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation data centers for enterprise support. Our cloud networking solutions consist of our Extensible Operating System, or EOS, a set of network applications and our 10/40/100 Gigabit Ethernet switches. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. At the core of our cloud networking platform is EOS, which was purpose-built to be fully programmable and highly modular. The programmability of EOS has allowed us to create a set of software applications that address the requirements of cloud networking, including workflow automation, network visibility and analytics, and has also allowed us to rapidly integrate with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001596532-15-000112:mdna:4]
We were founded in 2004 to address the limitations of legacy networking products and to create a cloud networking platform that is open and programmable. From 2004 to 2008, our activities were focused on the development of our software, which resulted in the commercial release of our first product, the 7100 Series switches based on our EOS software, in 2008. Since then, we have continued to introduce new products utilizing EOS, including our 7500 Series switch and our 7050 Series switch in 2010, the second generation of our 7500 Series switch, called the 7500E modular switch, in May 2013, our 7300 Series switch in November 2013 and our 7280E in July 2014.  In December 2014 we introduced our EOS+ software platform for networking programmability and automation, and in June 2015 we introduced CloudVision, a network-wide approach for workload orchestration and workflow automation.

[0001596532-15-000112:mdna:5]
As of June 30, 2015, we have shipped more than five million switch ports. We have experienced rapid revenue growth over the last several years, increasing our revenue at a compound annual growth rate of 68.9% from 2010 to 2014. As we have grown the functionality of our EOS software, expanded the range of our switching portfolio and increased the size of our sales force, our revenue has continued to grow rapidly. To support our customers and revenue growth, we have expanded our international presence to include 19 foreign subsidiaries as of June 30, 2015, including for example Australia, Canada, France, Germany, India, Ireland, Japan, South Korea and the United Kingdom. Our revenue for the three and six months ended June 30, 2015 was $195.6 million and $374.6 million an increase of 41.8% and 46.8%, respectively, compared to the same period in 2014. We have been profitable and cash flow positive for each year since 2010.

[0001596532-15-000112:mdna:6]
We believe that our cloud networking platform addresses the large and growing cloud networking segment of data center switching, which remains in the early stage of adoption. We expect to continue rapidly growing our organization to meet the needs of new and existing customers as they increasingly realize the performance and cost benefits of our cloud networking solutions and as they expand their cloud networks. We intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features and build upon our technology leadership. We believe one of our greatest strengths lies in our rapid development of new features and applications. We intend to continue expanding our sales and marketing teams and programs and carrying out associated marketing activities in key geographies. In order to support our strong growth, we have and may continue to accelerate our investment in infrastructure, such as enterprise resource planning software and other technologies to improve the efficiency of our operations. As a result, our levels of operating profit as a percentage of revenue could decline in the short to medium term. For a description of factors that may impact our future performance, see the disclosure in the section titled "Factors Affecting Our Performance" below.

[0001596532-15-000112:mdna:7]
[same as prior period, unchanged from 0001596532-15-000013:mdna:6]

[0001596532-15-000112:mdna:8]
We derive revenue from sales of products and services. We generate revenue primarily from sales of our switching products which incorporate our EOS software. We generate the majority of our services revenue from post contract support, or PCS, which end customers typically purchase in conjunction with our products. In addition, we have recently added software subscription services to our service offerings which will also add to services revenue in the future.

[0001596532-15-000112:mdna:9]
[same as prior period, unchanged from 0001596532-15-000013:mdna:8]

[0001596532-15-000112:mdna:10]
To continue to grow our revenue, it is important that we both obtain new customers and sell additional products to existing customers. Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic to the underlying merchant silicon architecture. Today, we combine our EOS software with merchant silicon into a family of switching products. This enables us to focus our research and development resources on our software

[0001596532-15-000112:mdna:11]
core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We currently procure certain merchant silicon components from multiple vendors, and we continue to expand our relationships with these and other vendors. We work closely with third party contract manufacturing suppliers to manufacture our products. Our contract manufacturing suppliers deliver our products to one of three third party direct fulfillment facilities where our EOS software is installed on our products.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-15-000112:mdna:12]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators, original equipment manufacturer (“OEM”) partners and in conjunction with various technology partners. To facilitate channel coordination and increase productivity, we have created a partner program, the Arista Partner Program, to engage partners who provide value-added services and extend our reach into the marketplace. Authorized training partners provide technical training to our channel partners. Our partners commonly receive an order from an end customer prior to placing an order with us, and we confirm the identification of the end customer prior to accepting such orders. Our partners generally do not stock inventory received from us. Our sales organization is supported by systems engineers with deep technical expertise and responsibility for pre-sales technical support and engineering for our end customers. Each sales team is responsible for a geographic territory, has responsibility for a number of major direct end-customer accounts or has assigned accounts in a specific vertical market.

[0001596532-15-000112:mdna:13]
[same as prior period, unchanged from 0001596532-15-000013:mdna:12]

[0001596532-15-000112:mdna:14]
[same as prior period, unchanged from 0001596532-15-000013:mdna:13]

[0001596532-15-000112:mdna:15]
[same as prior period, unchanged from 0001596532-15-000013:mdna:14]

[0001596532-15-000112:mdna:16]
[same as prior period, unchanged from 0001596532-15-000013:mdna:15]

[0001596532-15-000112:mdna:17]
[same as prior period, unchanged from 0001596532-15-000013:mdna:16]

[0001596532-15-000112:mdna:18]
[same as prior period, unchanged from 0001596532-15-000013:mdna:17]

[0001596532-15-000112:mdna:19]
Leveraging Channel Partners. We expect to continue to derive a growing portion of our sales through our channel partners as they develop new end customers and expand sales to our existing end customers. We plan to continue to invest in our network of channel partners to empower them to reach new end customers more effectively, increase sales to existing customers and provide services and support effectively. We believe that increasing channel leverage will extend and improve our engagement with a broad set of customers.

[0001596532-15-000112:mdna:20]
[same as prior period, unchanged from 0001596532-15-000013:mdna:19]

[0001596532-15-000112:mdna:21]
[same as prior period, unchanged from 0001596532-15-000013:mdna:20]

[0001596532-15-000112:mdna:22]
[same as prior period, unchanged from 0001596532-15-000013:mdna:21]

[0001596532-15-000112:mdna:23]
[same as prior period, unchanged from 0001596532-15-000013:mdna:22]

[0001596532-15-000112:mdna:24]
We generate revenue primarily from sales of our switching products which incorporate our EOS software. We also derive a portion of our revenue from CloudVision software subscription and sales of post contract support, or PCS, and to a lesser extent professional services. We generate PCS revenue from sales of technical support services contracts that are typically purchased in conjunction with our products and subsequent renewals of those contracts. We offer PCS services under renewable, fee-based contracts, which include 24-hour technical support, hardware repair and replacement parts, bug fixes, patches and unspecified upgrades on a when-and-if available basis. We expect our revenue may vary from period to period based on, among other things, the timing and size of orders, the delivery and acceptance of products, the impact of significant transactions with unique terms and conditions that may require deferral of revenue and cyclicality of orders being placed by our customers. Additionally, we expect our software subscription and PCS revenue to increase in absolute dollars as we expand our installed base. Our ability to expand our installed base and increase our revenue is subject to numerous risks and uncertainties. See the section titled “Risk Factors.” We report revenue net of sales taxes.

[0001596532-15-000112:mdna:25]
[same as prior period, unchanged from 0001596532-15-000013:mdna:24]

[0001596532-15-000112:mdna:26]
[same as prior period, unchanged from 0001596532-15-000013:mdna:25]

[0001596532-15-000112:mdna:27]
[same as prior period, unchanged from 0001596532-15-000013:mdna:26]

[0001596532-15-000112:mdna:28]
[same as prior period, unchanged from 0001596532-15-000013:mdna:27]

[0001596532-15-000112:mdna:29]
[same as prior period, unchanged from 0001596532-15-000013:mdna:28]

[0001596532-15-000112:mdna:30]
[same as prior period, unchanged from 0001596532-15-000013:mdna:29]

[0001596532-15-000112:mdna:31]
[same as prior period, unchanged from 0001596532-15-000013:mdna:30]

[0001596532-15-000112:mdna:32]
[same as prior period, unchanged from 0001596532-15-000013:mdna:31]

[0001596532-15-000112:mdna:33]
[same as prior period, unchanged from 0001596532-15-000013:mdna:32]

[0001596532-15-000112:mdna:34]
[same as prior period, unchanged from 0001596532-15-000013:mdna:33]

[0001596532-15-000112:mdna:35]
[same as prior period, unchanged from 0001596532-15-000013:mdna:34]

[0001596532-15-000112:mdna:36]
General and administrative expenses consist primarily of personnel costs, legal and professional fees, and an allocated portion of facility and IT costs and depreciation. General and administrative personnel costs include those for our executive, finance, IT, human resources and legal functions. Our professional fees consist primarily of accounting, external legal and IT and other consulting costs. We expect our general and administrative expenses to increase in absolute dollars to support our growing infrastructure needs and as we assume the reporting requirements and compliance obligations of a public company. In addition, we expect legal expense to increase significantly in absolute dollars for the foreseeable future due to legal costs related to ongoing IP litigation and potential future litigation claims. Refer to the discussion under “Legal Proceedings” subheading in Note 5. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 10-Q for information related to pending litigation.

[0001596532-15-000112:mdna:37]
[same as prior period, unchanged from 0001596532-15-000013:mdna:36]

[0001596532-15-000112:mdna:38]
[same as prior period, unchanged from 0001596532-15-000013:mdna:37]

[0001596532-15-000112:mdna:39]
Interest expense consists of interest expense on our subordinated convertible promissory notes, including our related party subordinated convertible promissory notes which were converted during fiscal 2014 and interest expense from our lease financing obligation.

[0001596532-15-000112:mdna:40]
[same as prior period, unchanged from 0001596532-15-000013:mdna:39]

[0001596532-15-000112:mdna:41]
[same as prior period, unchanged from 0001596532-15-000013:mdna:40]

[0001596532-15-000112:mdna:42]
[same as prior period, unchanged from 0001596532-15-000013:mdna:41]

[0001596532-15-000112:mdna:43]
[same as prior period, unchanged from 0001596532-15-000013:mdna:42]

[0001596532-15-000112:mdna:44]
[same as prior period, unchanged from 0001596532-15-000013:mdna:43]

[0001596532-15-000112:mdna:45]
[same as prior period, unchanged from 0001596532-15-000013:mdna:44]

[0001596532-15-000112:mdna:46]
[same as prior period, unchanged from 0001596532-15-000013:mdna:45]

[0001596532-15-000112:mdna:47]
The following table summarizes historical results of operations for the periods presented and as a percentage of revenue for those periods.  We have derived the data for the three and six months ended June 30, 2015 and 2014 from our unaudited condensed consolidated financial statements (in thousands, except for percentage of revenue).

[0001596532-15-000112:mdna:48]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 174,072 |  |  | $ | 126,390 |  |  | $ | 334,213 |  |  | $ | 232,883 |  |
| Service | 21,480 |  |  | 11,557 |  |  | 40,384 |  |  | 22,271 |  |
| Total revenue | 195,552 |  |  | 137,947 |  |  | 374,597 |  |  | 255,154 |  |
| Cost of revenue (1): |  |  |  |  |  |  |  |
| Product | 60,014 |  |  | 40,032 |  |  | 114,453 |  |  | 73,059 |  |
| Service | 7,648 |  |  | 4,535 |  |  | 14,500 |  |  | 7,401 |  |
| Total cost of revenue | 67,662 |  |  | 44,567 |  |  | 128,953 |  |  | 80,460 |  |
| Gross profit | 127,890 |  |  | 93,380 |  |  | 245,644 |  |  | 174,694 |  |
| Operating expenses (1): |  |  |  |  |  |  |  |
| Research and development | 49,947 |  |  | 34,888 |  |  | 93,287 |  |  | 68,334 |  |
| Sales and marketing | 26,681 |  |  | 20,711 |  |  | 51,268 |  |  | 39,366 |  |
| General and administrative | 18,403 |  |  | 7,126 |  |  | 32,475 |  |  | 14,357 |  |
| Total operating expenses | 95,031 |  |  | 62,725 |  |  | 177,030 |  |  | 122,057 |  |
| Income from operations | 32,859 |  |  | 30,655 |  |  | 68,614 |  |  | 52,637 |  |
| Interest expense | (832 | ) |  | (2,204 | ) |  | (1,653 | ) |  | (4,747 | ) |
| Other income (expense), net | 417 |  |  | 3,241 |  |  | (51 | ) |  | 3,249 |  |
| Total other income (expense), net | (415 | ) |  | 1,037 |  |  | (1,704 | ) |  | (1,498 | ) |
| Income before provision for income taxes | 32,444 |  |  | 31,692 |  |  | 66,910 |  |  | 51,139 |  |
| Provision for income taxes | 8,448 |  |  | 10,074 |  |  | 18,422 |  |  | 17,192 |  |
| Net income | $ | 23,996 |  |  | $ | 21,618 |  |  | $ | 48,488 |  |  | $ | 33,947 |  |

[0001596532-15-000112:mdna:49]
[same as prior period, unchanged from 0001596532-15-000013:mdna:52]

[0001596532-15-000112:mdna:50]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
|  | (as a percentage of revenue) |
| Revenue: |  |  |  |  |  |  |  |
| Product | 89.0 | % |  | 91.6 | % |  | 89.2 | % |  | 91.3 | % |
| Service | 11.0 |  |  | 8.4 |  |  | 10.8 |  |  | 8.7 |  |
| Total revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 30.7 |  |  | 29.0 |  |  | 30.6 |  |  | 28.6 |  |
| Service | 3.9 |  |  | 3.3 |  |  | 3.8 |  |  | 2.9 |  |
| Total cost of revenue | 34.6 |  |  | 32.3 |  |  | 34.4 |  |  | 31.5 |  |
| Gross profit | 65.4 |  |  | 67.7 |  |  | 65.6 |  |  | 68.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 25.5 |  |  | 25.3 |  |  | 24.9 |  |  | 26.8 |  |
| Sales and marketing | 13.6 |  |  | 15.0 |  |  | 13.7 |  |  | 15.4 |  |
| General and administrative | 9.5 |  |  | 5.2 |  |  | 8.7 |  |  | 5.6 |  |
| Total operating expenses | 48.6 |  |  | 45.5 |  |  | 47.3 |  |  | 47.8 |  |
| Income from operations | 16.8 |  |  | 22.2 |  |  | 18.3 |  |  | 20.7 |  |
| Interest expense | (0.4 | ) |  | (1.6 | ) |  | (0.4 | ) |  | (1.9 | ) |
| Other income (expense), net | 0.2 |  |  | 2.4 |  |  | 0.0 |  |  | 1.3 |  |
| Total other income (expense), net | (0.2 | ) |  | 0.8 |  |  | (0.4 | ) |  | (0.6 | ) |
| Income before provision for income taxes | 16.6 |  |  | 23.0 |  |  | 17.9 |  |  | 20.1 |  |
| Provision for income taxes | 4.3 |  |  | 7.3 |  |  | 5.0 |  |  | 6.7 |  |
| Net income | 12.3 | % |  | 15.7 | % |  | 12.9 | % |  | 13.4 | % |

[0001596532-15-000112:mdna:51]
________________________________________________________________________

[0001596532-15-000112:mdna:52]
[same as prior period, unchanged from 0001596532-15-000013:mdna:50]

[0001596532-15-000112:mdna:53]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Cost of revenue | $ | 784 |  |  | $ | 301 |  |  | $ | 1,420 |  |  | $ | 512 |  |
| Research and development | 6,379 |  |  | 3,527 |  |  | 11,307 |  |  | 5,994 |  |
| Sales and marketing | 2,865 |  |  | 1,931 |  |  | 5,274 |  |  | 3,359 |  |
| General and administrative | 1,180 |  |  | 946 |  |  | 2,046 |  |  | 1,622 |  |
| Total stock-based compensation | $ | 11,208 |  |  | $ | 6,705 |  |  | $ | 20,047 |  |  | $ | 11,487 |  |

[0001596532-15-000112:mdna:54]
27

[0001596532-15-000112:mdna:55]
Three and Six Months Ended June 30, 2015 Compared to Three and Six Months Ended June 30, 2014

[0001596532-15-000112:mdna:56]
[same as prior period, unchanged from 0001596532-15-000013:mdna:54]

[0001596532-15-000112:mdna:57]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | Change in |  | 2015 |  | 2014 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 174,072 |  |  | $ | 126,390 |  |  | $ | 47,682 |  |  | 37.7% |  | $ | 334,213 |  |  | $ | 232,883 |  |  | $ | 101,330 |  |  | 43.5% |
| Service | 21,480 |  |  | 11,557 |  |  | 9,923 |  |  | 85.9 |  | 40,384 |  |  | 22,271 |  |  | 18,113 |  |  | 81.3 |
| Total revenue | $ | 195,552 |  |  | $ | 137,947 |  |  | $ | 57,605 |  |  | 41.8% |  | $ | 374,597 |  |  | $ | 255,154 |  |  | $ | 119,443 |  |  | 46.8% |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 60,014 |  |  | $ | 40,032 |  |  | $ | 19,982 |  |  | 49.9% |  | $ | 114,453 |  |  | $ | 73,059 |  |  | $ | 41,394 |  |  | 56.7% |
| Service | 7,648 |  |  | 4,535 |  |  | 3,113 |  |  | 68.6 |  | 14,500 |  |  | 7,401 |  |  | 7,099 |  |  | 95.9 |
| Total cost of revenue | $ | 67,662 |  |  | $ | 44,567 |  |  | $ | 23,095 |  |  | 51.8% |  | $ | 128,953 |  |  | $ | 80,460 |  |  | $ | 48,493 |  |  | 60.3% |
| Gross profit | $ | 127,890 |  |  | $ | 93,380 |  |  | $ | 34,510 |  |  | 37.0% |  | $ | 245,644 |  |  | $ | 174,694 |  |  | $ | 70,950 |  |  | 40.6% |
| Gross margin | 65.4 | % |  | 67.7 | % |  |  |  |  |  | 65.6 | % |  | 68.5 | % |  |  |  |  |

[0001596532-15-000112:mdna:58]
Revenue by Geography (in thousands, except percentages)

[0001596532-15-000112:mdna:59]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2015 |  | % of Total |  | 2014 |  | % of Total |  | 2015 |  | % of Total |  | 2014 |  | % of Total |
| Americas | $ | 150,863 |  |  | 77.1 % |  | $ | 103,158 |  |  | 74.8 % |  | $ | 277,620 |  |  | 74.1 % |  | $ | 199,358 |  |  | 78.1 % |
| Europe, Middle East and Africa | 24,782 |  |  | 12.7% |  | 20,628 |  |  | 15.0% |  | 64,872 |  |  | 17.3% |  | 32,342 |  |  | 12.7% |
| Asia-Pacific | 19,907 |  |  | 10.2% |  | 14,161 |  |  | 10.2% |  | 32,105 |  |  | 8.6% |  | 23,454 |  |  | 9.2% |
| Total revenue | $ | 195,552 |  |  | 100.0 % |  | $ | 137,947 |  |  | 100.0 % |  | $ | 374,597 |  |  | 100.0 % |  | $ | 255,154 |  |  | 100.0 % |

[0001596532-15-000112:mdna:60]
[same as prior period, unchanged from 0001596532-15-000013:mdna:56]

[0001596532-15-000112:mdna:61]
Revenue increased 41.8% in the three months ended June 30, 2015 and 46.8% in the six months ended June 30, 2015, compared to the same periods in 2014. We increased shipments to our existing customers in these periods as they continued to grow their businesses and increased their demand for our switch products and related accessories. In addition, we added new customers as we expanded our market presence and increased our customer count. Service revenue also increased in each of the periods presented primarily due to an increase in new and renewed support contracts for our switch products as a result of our growing customer install base. We continue to experience changes in product and services pricing due to competitive market pressures, however, these were more than offset by the increased demand drivers outlined above.

[0001596532-15-000112:mdna:62]
Cost of Revenue and Gross Margin

[0001596532-15-000112:mdna:63]
Gross margin decreased from 67.7% to 65.4% for the three months ended June 30, 2014 and June 30, 2015, and from 68.5% to 65.6% for the six months ended June 30, 2014 and June 30, 2015, respectively. The decrease in gross margin in these periods is primarily the result of changes in customer mix and to lesser extent product mix, as we expanded our business and increased the contribution of larger customers who typically receive higher discount levels.  In addition we invested in manufacturing and operations infrastructure as our revenues increased, adding capacity and expanding our footprint geographically.

[0001596532-15-000112:mdna:64]
[same as prior period, unchanged from 0001596532-15-000013:mdna:62]

[0001596532-15-000112:mdna:65]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | Change in |  | 2015 |  | 2014 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 49,947 |  |  | $ | 34,888 |  |  | $ | 15,059 |  |  | 43.2% |  | $ | 93,287 |  |  | $ | 68,334 |  |  | $ | 24,953 |  |  | 36.5% |
| Sales and marketing | 26,681 |  |  | 20,711 |  |  | 5,970 |  |  | 28.8 |  | 51,268 |  |  | 39,366 |  |  | 11,902 |  |  | 30.2 |
| General and administrative | 18,403 |  |  | 7,126 |  |  | 11,277 |  |  | 158.3 |  | 32,475 |  |  | 14,357 |  |  | 18,118 |  |  | 126.2 |
| Total operating expenses | $ | 95,031 |  |  | $ | 62,725 |  |  | $ | 32,306 |  |  | 51.5% |  | $ | 177,030 |  |  | $ | 122,057 |  |  | $ | 54,973 |  |  | 45.0% |

[0001596532-15-000112:mdna:66]
[same as prior period, unchanged from 0001596532-15-000013:mdna:64]

[0001596532-15-000112:mdna:67]
Research and development expenses increased $15.1 million, or 43.2%, for the three months ended June 30, 2015 compared to the same period in 2014. The increase was primarily due to an increase in personnel costs of $8.2 million, resulting from an increase in headcount from June 30, 2014 to June 30, 2015 and increased bonus expense under our corporate bonus plan.  In addition, research and development related facilities and IT infrastructure expenses increased $2.9 million and prototype spend and third-party engineering costs increased $2.8 million as a result of new product introductions and continued expansion and support of our research and development activities.

[0001596532-15-000112:mdna:68]
Research and development expenses increased $25.0 million, or 36.5%, for the six months ended June 30, 2015 compared to the same period in 2014. The increase was primarily due to an increase in personnel costs of $16.4 million, resulting from an increase in headcount from June 30, 2014 to June 30, 2015 and increased bonus expense under our corporate bonus plan. In addition, research and development related facilities and IT infrastructure expenses increased $4.6 million and prototype spend and third-party engineering costs increased $2.9 million as a result of new product introductions and continued expansion and support of our research and development activities.

[0001596532-15-000112:mdna:69]
[same as prior period, unchanged from 0001596532-15-000013:mdna:66]

[0001596532-15-000112:mdna:70]
Sales and marketing expenses increased $6.0 million, or 28.8%, for the three months ended June 30, 2015 compared to the same period in 2014. The increase was primarily due to an increase in personnel costs of $3.7 million, resulting from an increase in headcount from June 30, 2014 to June 30, 2015 and an increase in sales commissions resulting from higher sales volume. The increase was also due to an increase of $2.2 million in product demonstration costs.

[0001596532-15-000112:mdna:71]
Sales and marketing expenses increased $11.9 million, or 30.2%, for the six months ended June 30, 2015 compared to the same period in 2014. The increase was primarily due to an increase in personnel costs of $7.6 million, resulting from an increase in headcount from June 30, 2014 to June 30, 2015 and an increase in sales commissions resulting from higher sales volume. The increase was also due to an increase of $4.0 million in product demonstration costs.

[0001596532-15-000112:mdna:72]
[same as prior period, unchanged from 0001596532-15-000013:mdna:68]

[0001596532-15-000112:mdna:73]
General and administrative expenses increased $11.3 million, or 158.3%, for the three months ended June 30, 2015 compared to the same period in 2014. The increase was primarily due to an increase in litigation fees of $9.9 million primarily related to the Cisco and OptumSoft matters, increased personnel costs of $0.9 million resulting from increased bonus expense under our corporate bonus plan, and increased insurance expense of $0.3 million associated with being a public company.

[0001596532-15-000112:mdna:74]
General and administrative expenses increased $18.1 million, or 126.2%, for the six months ended June 30, 2015 compared to the same period in 2014. The increase was primarily due to an increase in litigation fees of $16.6 million primarily related to the Cisco and OptumSoft matters, increased personnel costs of $1.7 million resulting from increased bonus expense under our corporate bonus plan, as well as increased insurance expense of $0.7 million associated with being a public company.  These expenses were partially offset by a decrease in professional service fees of $1.0 million primarily attributed to accounting and other legal fees incurred during the first half of 2014 in preparation of becoming a public company.

[0001596532-15-000112:mdna:75]
[same as prior period, unchanged from 0001596532-15-000013:mdna:70]

[0001596532-15-000112:mdna:76]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | Change in |  | 2015 |  | 2014 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | $ | (832 | ) |  | $ | (2,204 | ) |  | $ | 1,372 |  |  | (62.3)% |  | $ | (1,653 | ) |  | $ | (4,747 | ) |  | $ | 3,094 |  |  | (65.2)% |
| Other income (expense), net | 417 |  |  | 3,241 |  |  | (2,824 | ) |  | (87.1)% |  | (51 | ) |  | 3,249 |  |  | (3,300 | ) |  | (101.6)% |
| Total other income (expense), net | $ | (415 | ) |  | $ | 1,037 |  |  | $ | (1,452 | ) |  | (140.0)% |  | $ | (1,704 | ) |  | $ | (1,498 | ) |  | $ | (206 | ) |  | 13.8% |

[0001596532-15-000112:mdna:77]
Interest expense

[0001596532-15-000112:mdna:78]
Interest expense decreased during the three and six months ended June 30, 2015 compared to the same period in 2014 as a result of repayment and conversion of all our notes payable upon closing of our initial public offering during the second quarter of 2014.

[0001596532-15-000112:mdna:79]
Other income (expense), net.

[0001596532-15-000112:mdna:80]
Other income (expense), net decreased during the three ands six months ended June 30, 2015, compared to the same period in 2014 due to a one-time gain on our notes receivable of $4.0 million offset by a $0.7 million write-off related to the debt discount on notes payable during the second quarter of 2014, and partially offset by an increase in net transactional exchange rate gain variances.

[0001596532-15-000112:mdna:81]
[same as prior period, unchanged from 0001596532-15-000013:mdna:74]

[0001596532-15-000112:mdna:82]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | Change in |  | 2015 |  | 2014 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Provision for income taxes | $ | 8,448 |  |  | $ | 10,074 |  |  | $ | (1,626 | ) |  | (16.1)% |  | $ | 18,422 |  |  | $ | 17,192 |  |  | $ | 1,230 |  |  | 7.2% |
| Effective tax rate | 26.0 | % |  | 31.8 | % |  |  |  |  |  | 27.5 | % |  | 33.6 | % |  |  |  |  |

[0001596532-15-000112:mdna:83]
Provision for income taxes

[0001596532-15-000112:mdna:84]
Provision for income taxes was approximately $8.4 million and $10.1 million for the three months ended June 30, 2015 and 2014, respectively. The change in our provision for income taxes was primarily due to increase in profit before income tax and the decrease in the effective tax rate based on our current geographical distribution of the earnings.

[0001596532-15-000112:mdna:85]
Provision for income taxes was approximately $18.4 million and $17.2 million for the six months ended June 30, 2015 and 2014, respectively. The change in our provision for income taxes was primarily due to increase in profit before income tax and the decrease in the effective tax rate based on our current geographical distribution of the earnings.

[0001596532-15-000112:mdna:86]
[same as prior period, unchanged from 0001596532-15-000013:mdna:77]

[0001596532-15-000112:mdna:87]
Our principal sources of liquidity are cash and cash equivalents, marketable securities, and cash generated from operations. As of June 30, 2015, cash and cash equivalents and marketable securities were $551.8 million, of which approximately $96.0 million was held outside the U.S. in our foreign subsidiaries. We have not repatriated nor do we currently have plans to repatriate these funds, but if we were to repatriate cash held outside of the U.S. for domestic cash operations, we would be required to accrue and pay U.S. income taxes to repatriate these funds less any previously paid foreign income taxes. We consider the undistributed earnings of our foreign subsidiaries as of June 30, 2015 to be indefinitely reinvested, and, accordingly, no U.S. income taxes have been provided thereon.

[0001596532-15-000112:mdna:88]
Our cash and cash equivalents and marketable securities are held for working capital purposes.  We plan to continue to invest for long-term growth. We believe that our existing cash and cash equivalents together with cash flow from operations will be sufficient to meet our working capital requirements and our growth strategies for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs and access to outsourcing our manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and the timely settlement of outstanding litigation claims. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-15-000112:mdna:89]
[same as prior period, unchanged from 0001596532-15-000013:mdna:80]

[0001596532-15-000112:mdna:90]
|  | June 30, 2015 |  | December 31, 2014 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 342,958 |  |  | $ | 240,031 |  |

[0001596532-15-000112:mdna:91]
|  | Six Months Ended June 30, |
|  | 2015 |  | 2014 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 73,373 |  |  | $ | 63,946 |  |
| Cash used in investing activities | (9,473 | ) |  | (4,539 | ) |
| Cash provided by financing activities | 39,047 |  |  | 224,064 |  |
| Effect of exchange rate changes | (20 | ) |  | 63 |  |
| Net increase in cash and cash equivalents | $ | 102,927 |  |  | $ | 283,534 |  |

[0001596532-15-000112:mdna:92]
[same as prior period, unchanged from 0001596532-15-000013:mdna:83]

[0001596532-15-000112:mdna:93]
Our primary source of cash from operating activities has been from cash collections from our customers. We expect cash inflows from operating activities to be affected by increased sales and timing of collections. Our primary uses of cash from operating activities have been for personnel costs and investment in sales and marketing and research and development.

[0001596532-15-000112:mdna:94]
During the six months ended June 30, 2015, cash provided by operating activities was $73.4 million, primarily from net income of $48.5 million, net non-cash charges of $2.4 million and a net increase in our operating assets and liabilities of $22.5 million. The net increase in operating assets and liabilities was primarily due to an increase in deferred revenue of $58.0 million, largely related to short and long-term services contracts and product revenue deferrals related to contract acceptance terms and future deliverables. In addition, we experienced a net increase in our income tax payable of $21.8 million related to tax benefits from stock-based activities and an increase in our accounts payable of $11.8 million due to the timing of our payments. These increases were partially offset by an increase in our accounts receivable of $25.8 million resulting from an increase in sales, an increase in inventory of $22.3 million due to increased shipment volume and an increase of $20.7 million in our prepaids and current assets.

[0001596532-15-000112:mdna:95]
During the six months ended June 30, 2014, cash provided by operating activities was $63.9 million primarily from net income of $33.9 million, net non-cash charges of $14.0 million and a net increase in our operating assets and liabilities of $16.0 million. The change in our operating assets and liabilities was primarily due to a decrease in our accounts receivable of $9.7 million resulting from an increase in our collection efforts, an increase in our accounts payables of $4.8 million from the timing of our payments, an increase in our deferred revenue of $2.8 million resulting from the increase in sales. Inventories also decreased by $2.3 million as a result of improvements in the management of our consigned and finished goods inventory. These changes were partially offset by an increase in our prepaid expenses and other current assets of $5.6 million primarily from the prepayments for taxes and renewals of our insurance and licenses and a $1.0 million net decrease in interest payable attributable to our outstanding subordinated convertible promissory notes,

[0001596532-15-000112:mdna:96]
including our related party subordinated convertible promissory notes before their conversion or repayment upon the completion of our initial public offering.

[0001596532-15-000112:mdna:97]
[same as prior period, unchanged from 0001596532-15-000013:mdna:88]

[0001596532-15-000112:mdna:98]
[same as prior period, unchanged from 0001596532-15-000013:mdna:89]

[0001596532-15-000112:mdna:99]
During the six months ended June 30, 2015, cash used in investing activities was $9.5 million, consisting of purchases of property and equipment of $8.8 million, and purchases of intangible assets of $0.7 million.

[0001596532-15-000112:mdna:100]
During the six months ended June 30, 2014, cash used in investing activities was $4.5 million, which primarily consisted of purchases of property and equipment of $8.6 million partially offset by the release of our restricted cash into cash and cash equivalents of $4.0 million.

[0001596532-15-000112:mdna:101]
[same as prior period, unchanged from 0001596532-15-000013:mdna:92]

[0001596532-15-000112:mdna:102]
[same as prior period, unchanged from 0001596532-15-000013:mdna:93]

[0001596532-15-000112:mdna:103]
During the six months ended June 30, 2015, cash provided by financing activities was $39.0 million, consisting primarily of the excess tax benefit on stock-based compensation of $23.0 million, proceeds from the exercise of stock options, net of repurchases of $12.0 million and the proceeds from the issuance of common stock from our ESPP of $4.9 million.

[0001596532-15-000112:mdna:104]
During the six months ended June 30, 2014, cash provided by financing activities was $224.1 million, consisting primarily of net proceeds raised from our initial public offering of $241.9 million and proceeds from the exercise of stock options, net of repurchases of $2.1 million. These proceeds were partially offset by the repayment of our notes payable of $20.0 million.

[0001596532-15-000112:mdna:105]
[same as prior period, unchanged from 0001596532-15-000013:mdna:96]

[0001596532-15-000112:mdna:106]
As of June 30, 2015, we did not have any relationships with any unconsolidated entities or financial partnerships, including entities often referred to as structured finance or special purpose, entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-15-000112:mdna:107]
[same as prior period, unchanged from 0001596532-15-000013:mdna:98]

[0001596532-15-000112:mdna:108]
There have been no significant changes during the six months ended June 30, 2015 impacting our contractual obligations disclosed in our "Management's Discussion and Analysis of Financial Condition and Results of Operations" included in our Annual Report on Form 10-K, filed with the SEC on March 12, 2015 and our Amended Annual Report on Form 10-K/A, filed with the SEC on May 15, 2015.

[0001596532-15-000112:mdna:109]
[same as prior period, unchanged from 0001596532-15-000013:mdna:100]

[0001596532-15-000112:mdna:110]
[same as prior period, unchanged from 0001596532-15-000013:mdna:101]

[0001596532-15-000112:mdna:111]
[same as prior period, unchanged from 0001596532-15-000013:mdna:102]

[0001596532-15-000112:mdna:112]
[same as prior period, unchanged from 0001596532-15-000013:mdna:103]
