# ANET 8-K — 0001596532-15-000110 filed 2015-08-06

## item codes, every 8-K on or before 2015-08-07

- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2015-08-07

- none on or before 2015-08-07

## item 2.02 — earnings release, exhibit 99.1

[0001596532-15-000110:8k_2_02:1]
EX-99.1
2
ex991q22015.htm
EXHIBIT 99.1

[0001596532-15-000110:8k_2_02:2]
EX. 99.1 Q22015

[0001596532-15-000110:8k_2_02:3]
Exhibit 99.1

[0001596532-15-000110:8k_2_02:4]
Arista Networks, Inc. Reports Second Quarter 2015 Financial Results

[0001596532-15-000110:8k_2_02:5]
Cloud Networking Adoption Drives Record Revenue and non-GAAP Net Income

[0001596532-15-000110:8k_2_02:6]
SANTA CLARA, Calif., August 6, 2015 - Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large data center and computing environments, today announced financial results for its second quarter ended June 30, 2015.

[0001596532-15-000110:8k_2_02:7]
Second Quarter Financial Highlights

[0001596532-15-000110:8k_2_02:8]
| • | Revenue of $195.6 million, an increase of 41.8% compared to the second quarter of 2014, and an increase of 9.2% from the first quarter of 2015. |

[0001596532-15-000110:8k_2_02:9]
| • | Non-GAAP gross margin of 65.8%, compared to non-GAAP gross margin of 67.9% in the second quarter of 2014 and 66.1% in the first quarter of 2015. |

[0001596532-15-000110:8k_2_02:10]
| • | GAAP gross margin of 65.4%, compared to GAAP gross margin of 67.7% in the second quarter of 2014 and 65.8% in the first quarter of 2015. |

[0001596532-15-000110:8k_2_02:11]
| • | Non-GAAP net income of $38.8 million, or $0.54 per diluted share, compared to non-GAAP net income of $23.7 million, or $0.35 per diluted share, in the second quarter of 2014. |

[0001596532-15-000110:8k_2_02:12]
| • | GAAP net income of $24.0 million, or $0.33 per diluted share, compared to GAAP net income of $21.6 million, or $0.34 per diluted share, in the second quarter of 2014. |

[0001596532-15-000110:8k_2_02:13]
| • | Operating cash flow of $52.6 million, compared to $46.3 million of operating cash flow in the second quarter of 2014. |

[0001596532-15-000110:8k_2_02:14]
"Arista has now shipped a cumulative five million cloud networking ports worldwide,” stated Jayshree Ullal, Arista President and CEO. “I am pleased with this important milestone for the company combined with our continued Q2 2015 customer momentum and solid profitable growth."

[0001596532-15-000110:8k_2_02:15]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, "We continued to execute well in Q2 2015, achieving record revenue with strong growth from our cloud and service provider customers, while increasing non-GAAP diluted earnings per share by more than 50% year-over-year.”

[0001596532-15-000110:8k_2_02:16]
Company Highlights

[0001596532-15-000110:8k_2_02:17]
| • | Announced CloudVision®, a network-wide approach for workload orchestration and workflow automation delivering a turnkey solution for cloud networking. This enables enterprises to more easily realize the benefits of cloud-class automation. |

[0001596532-15-000110:8k_2_02:18]
| • | Partnership with HP for a converged cloud networking solution; delivering a path to cloud economics and agility, via the integration of the Arista Extensible Operating System (EOS®) based 7000 series, with HP OneView. |

[0001596532-15-000110:8k_2_02:19]
| • | CloudVision was endorsed by many leading partners including VMware, Microsoft, Dell, F5, HP, Infinera, Nuage, Palo Alto Networks, Rackspace and Supermicro, Inc. |

[0001596532-15-000110:8k_2_02:20]
Financial Outlook

[0001596532-15-000110:8k_2_02:21]
For the third quarter of 2015, we expect:

[0001596532-15-000110:8k_2_02:22]
| • | Revenue between $208 and $212 million. |

[0001596532-15-000110:8k_2_02:23]
| • | Non-GAAP gross margin in the range of 63% to 65%, and |

[0001596532-15-000110:8k_2_02:24]
| • | Non-GAAP operating margin of approximately 25%. |

[0001596532-15-000110:8k_2_02:25]
Guidance for non-GAAP financial measures excludes legal expenses associated with the OptumSoft and Cisco litigation, stock-based compensation and other non-recurring expenses. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis.

[0001596532-15-000110:8k_2_02:26]
Prepared Materials and Conference Call Information

[0001596532-15-000110:8k_2_02:27]
Arista executives will discuss second quarter 2015 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial 1-877-201-0168 in the United States or 1-647-788-4901 from outside the US. The Conference ID is 79004789.

[0001596532-15-000110:8k_2_02:28]
The financial results conference call will also be available via live webcast on our investor relations website at investors.arista.com. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s Investor Relations website.

[0001596532-15-000110:8k_2_02:29]
Forward-Looking Statements

[0001596532-15-000110:8k_2_02:30]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the third quarter of FY 2015.  Forward-looking statements are subject to a number of uncertainties and risks that could cause actual results to differ materially from those anticipated in the forward-looking statements including: Arista Networks’ limited operating history; risks associated with Arista Networks’ rapid growth; Arista Networks’ customer concentration; requests for more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; changes in customer order patterns or customer mix; increased competition in our products and service markets, including the data center market; dependence on the introduction and market acceptance of new product offerings and standards; rapid technological and market change; the dispute with Cisco Systems, Inc. and OptumSoft, Inc.; the evolution of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; and general market, political, economic and business conditions. Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s Quarterly Report on Form 10-Q filed with the SEC on May 15, 2015, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at http://investors.arista.com and on the SEC’s website at www.sec.gov. All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-15-000110:8k_2_02:31]
Non-GAAP Financial Measures

[0001596532-15-000110:8k_2_02:32]
The company reports certain non-GAAP financial measures that exclude stock-based compensation expenses, expenses associated with the OptumSoft and Cisco litigation, and other non-recurring charges. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends.  In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-15-000110:8k_2_02:33]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP net income, net income per diluted share, gross margin, or operating margin.  Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-15-000110:8k_2_02:34]
About Arista Networks

[0001596532-15-000110:8k_2_02:35]
Arista Networks was founded to deliver software-driven cloud networking solutions for large data center and computing environments. Arista’s award-winning 10/40/100 GbE switches redefine scalability, robustness, and price-performance. At the core of Arista’s platform is EOS, an advanced network operating system. Arista Networks products are available worldwide through distribution partners, systems integrators and resellers.

[0001596532-15-000110:8k_2_02:36]
ARISTA, EOS, CloudVision and Spline are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-15-000110:8k_2_02:37]
Additional information and resources can be found at: http://www.arista.com.

[0001596532-15-000110:8k_2_02:38]
| Media ContactAmanda JaramilloCorporate Communications(408) 547-5798amanda@arista.com |  | Investor ContactChuck ElliottProduct and Investor Advocacy(408) 547-5549chuck@arista.com |

[0001596532-15-000110:8k_2_02:39]
ARISTA NETWORKS, INC.

[0001596532-15-000110:8k_2_02:40]
Condensed Consolidated Statements of Income

[0001596532-15-000110:8k_2_02:41]
(Unaudited in thousands, except per share amounts)

[0001596532-15-000110:8k_2_02:42]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 174,072 |  |  | $ | 126,390 |  |  | $ | 334,213 |  |  | $ | 232,883 |  |
| Service | 21,480 |  |  | 11,557 |  |  | 40,384 |  |  | 22,271 |  |
| Total revenue | 195,552 |  |  | 137,947 |  |  | 374,597 |  |  | 255,154 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 60,014 |  |  | 40,032 |  |  | 114,453 |  |  | 73,059 |  |
| Service | 7,648 |  |  | 4,535 |  |  | 14,500 |  |  | 7,401 |  |
| Total cost of revenue | 67,662 |  |  | 44,567 |  |  | 128,953 |  |  | 80,460 |  |
| Total gross profit | 127,890 |  |  | 93,380 |  |  | 245,644 |  |  | 174,694 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 49,947 |  |  | 34,888 |  |  | 93,287 |  |  | 68,334 |  |
| Sales and marketing | 26,681 |  |  | 20,711 |  |  | 51,268 |  |  | 39,366 |  |
| General and administrative | 18,403 |  |  | 7,126 |  |  | 32,475 |  |  | 14,357 |  |
| Total operating expenses | 95,031 |  |  | 62,725 |  |  | 177,030 |  |  | 122,057 |  |
| Income from operations | 32,859 |  |  | 30,655 |  |  | 68,614 |  |  | 52,637 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense—related party | — |  |  | (350 | ) |  | — |  |  | (782 | ) |
| Interest expense | (832 | ) |  | (1,854 | ) |  | (1,653 | ) |  | (3,965 | ) |
| Other income (expense), net | 417 |  |  | 3,241 |  |  | (51 | ) |  | 3,249 |  |
| Total other income (expense), net | (415 | ) |  | 1,037 |  |  | (1,704 | ) |  | (1,498 | ) |
| Income before provision for income taxes | 32,444 |  |  | 31,692 |  |  | 66,910 |  |  | 51,139 |  |
| Provision for income taxes | 8,448 |  |  | 10,074 |  |  | 18,422 |  |  | 17,192 |  |
| Net income | $ | 23,996 |  |  | $ | 21,618 |  |  | $ | 48,488 |  |  | $ | 33,947 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 23,607 |  |  | $ | 14,212 |  |  | $ | 47,594 |  |  | $ | 19,985 |  |
| Diluted | $ | 23,638 |  |  | $ | 14,851 |  |  | $ | 47,667 |  |  | $ | 21,121 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.36 |  |  | $ | 0.37 |  |  | $ | 0.73 |  |  | $ | 0.59 |  |
| Diluted | $ | 0.33 |  |  | $ | 0.34 |  |  | $ | 0.67 |  |  | $ | 0.54 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | 65,524 |  |  | 38,491 |  |  | 65,018 |  |  | 33,834 |  |
| Diluted | 71,215 |  |  | 44,057 |  |  | 70,919 |  |  | 38,962 |  |

[0001596532-15-000110:8k_2_02:43]
ARISTA NETWORKS, INC.

[0001596532-15-000110:8k_2_02:44]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-15-000110:8k_2_02:45]
(Unaudited in thousands, except percentages and per share amounts)

[0001596532-15-000110:8k_2_02:46]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| GAAP gross profit | $ | 127,890 |  |  | $ | 93,380 |  |  | $ | 245,644 |  |  | $ | 174,694 |  |
| GAAP gross margin | 65.4 | % |  | 67.7 | % |  | 65.6 | % |  | 68.5 | % |
| Stock-based compensation expense | 784 |  |  | 301 |  |  | 1,420 |  |  | 512 |  |
| Non-GAAP gross profit | $ | 128,674 |  |  | $ | 93,681 |  |  | $ | 247,064 |  |  | $ | 175,206 |  |
| Non-GAAP gross margin | 65.8 | % |  | 67.9 | % |  | 66.0 | % |  | 68.7 | % |
| GAAP income from operations | $ | 32,859 |  |  | $ | 30,655 |  |  | $ | 68,614 |  |  | $ | 52,637 |  |
| Stock-based compensation expense | 11,208 |  |  | 6,705 |  |  | 20,047 |  |  | 11,487 |  |
| Litigation expense | 9,909 |  |  | — |  |  | 16,579 |  |  | — |  |
| Non-GAAP income from operations | $ | 53,976 |  |  | $ | 37,360 |  |  | $ | 105,240 |  |  | $ | 64,124 |  |
| Non-GAAP operating margin | 27.6 | % |  | 27.1 | % |  | 28.1 | % |  | 25.1 | % |
| GAAP net income | $ | 23,996 |  |  | $ | 21,618 |  |  | $ | 48,488 |  |  | $ | 33,947 |  |
| Stock-based compensation expense | 11,208 |  |  | 6,705 |  |  | 20,047 |  |  | 11,487 |  |
| Litigation expense | 9,909 |  |  | — |  |  | 16,579 |  |  | — |  |
| Unrealized gain on note receivable | — |  |  | (4,000 | ) |  | — |  |  | (4,000 | ) |
| Income tax effect on non-GAAP exclusions | (6,335 | ) |  | (600 | ) |  | (10,804 | ) |  | (1,305 | ) |
| Non-GAAP net income | $ | 38,778 |  |  | $ | 23,723 |  |  | $ | 74,310 |  |  | $ | 40,129 |  |
| Weighted average shares used in computing GAAP diluted income per share attributable to common stockholders | 71,215 |  |  | 44,057 |  |  | 70,919 |  |  | 38,962 |  |
| Additional weighted average dilutive shares1 | — |  |  | 23,413 |  |  | — |  |  | 27,823 |  |
| Non-GAAP weighted average diluted shares | 71,215 |  |  | 67,470 |  |  | 70,919 |  |  | 66,785 |  |
| GAAP diluted net income per share attributable to common stockholders | $ | 0.33 |  |  | $ | 0.34 |  |  | $ | 0.67 |  |  | $ | 0.54 |  |
| Net income attributable to participating securities | — |  |  | 0.15 |  |  | 0.01 |  |  | 0.33 |  |
| Non-GAAP adjustments to net income | 0.21 |  |  | 0.05 |  |  | 0.37 |  |  | 0.16 |  |
| Non-GAAP adjustments to diluted shares | — |  |  | (0.19 | ) |  | — |  |  | (0.43 | ) |
| Non-GAAP diluted net income per share | $ | 0.54 |  |  | $ | 0.35 |  |  | $ | 1.05 |  |  | $ | 0.60 |  |
| Summary of Stock-Based Compensation Expense |  |  |  |  |  |  |  |
| Cost of revenue | $ | 784 |  |  | $ | 301 |  |  | $ | 1,420 |  |  | $ | 512 |  |
| Research and development | 6,379 |  |  | 3,527 |  |  | 11,307 |  |  | 5,994 |  |
| Sales and marketing | 2,865 |  |  | 1,931 |  |  | 5,274 |  |  | 3,359 |  |
| General and administrative | 1,180 |  |  | 946 |  |  | 2,046 |  |  | 1,622 |  |
| Total | $ | 11,208 |  |  | $ | 6,705 |  |  | $ | 20,047 |  |  | $ | 11,487 |  |

[0001596532-15-000110:8k_2_02:47]
______________________________

[0001596532-15-000110:8k_2_02:48]
1Includes weighted average shares from the issuance of shares upon our IPO and the assumed conversion of preferred stock and notes payable at the beginning of the quarter.

[0001596532-15-000110:8k_2_02:49]
ARISTA NETWORKS, INC.

[0001596532-15-000110:8k_2_02:50]
Condensed Consolidated Balance Sheets

[0001596532-15-000110:8k_2_02:51]
(Unaudited in thousands)

[0001596532-15-000110:8k_2_02:52]
|  | June 30, 2015 |  | December 31, 2014 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 342,958 |  |  | $ | 240,031 |  |
| Marketable securities | 208,805 |  |  | 209,426 |  |
| Accounts receivable, net | 122,342 |  |  | 96,982 |  |
| Inventories | 100,304 |  |  | 78,006 |  |
| Deferred tax assets | 12,268 |  |  | 12,252 |  |
| Prepaid expenses and other current assets | 63,535 |  |  | 42,782 |  |
| Total current assets | 850,212 |  |  | 679,479 |  |
| Property and equipment, net | 73,178 |  |  | 71,558 |  |
| Investments | 36,636 |  |  | 36,636 |  |
| Deferred tax assets | 13,760 |  |  | 11,510 |  |
| Other assets | 17,053 |  |  | 11,840 |  |
| TOTAL ASSETS | $ | 990,839 |  |  | $ | 811,023 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 43,831 |  |  | $ | 32,428 |  |
| Accrued liabilities | 43,347 |  |  | 40,369 |  |
| Deferred revenue | 107,245 |  |  | 60,327 |  |
| Other current liabilities | 8,075 |  |  | 11,249 |  |
| Total current liabilities | 202,498 |  |  | 144,373 |  |
| Income taxes payable | 17,850 |  |  | 17,323 |  |
| Lease financing obligations, non-current | 41,912 |  |  | 42,547 |  |
| Deferred revenue, non-current | 57,198 |  |  | 46,141 |  |
| Other long-term liabilities | 5,839 |  |  | 4,981 |  |
| TOTAL LIABILITIES | 325,297 |  |  | 255,365 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Preferred stock | — |  |  | — |  |
| Common stock | 7 |  |  | 7 |  |
| Additional paid-in capital | 487,376 |  |  | 426,171 |  |
| Retained earnings | 178,302 |  |  | 129,814 |  |
| Accumulated other comprehensive loss | (143) |  |  | (334 | ) |
| TOTAL STOCKHOLDERS’ EQUITY | 665,542 |  |  | 555,658 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 990,839 |  |  | $ | 811,023 |  |

[0001596532-15-000110:8k_2_02:53]
ARISTA NETWORKS, INC.

[0001596532-15-000110:8k_2_02:54]
Condensed Consolidated Statements of Cash Flows

[0001596532-15-000110:8k_2_02:55]
(Unaudited in thousands)

[0001596532-15-000110:8k_2_02:56]
|  | Six Months Ended June 30, |
|  | 2015 |  | 2014 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 48,488 |  |  | $ | 33,947 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 6,246 |  |  | 4,713 |  |
| Stock-based compensation | 20,047 |  |  | 11,487 |  |
| Deferred income taxes | (2,266 | ) |  | 703 |  |
| Provision for bad debts | 481 |  |  | 374 |  |
| Excess tax benefit on stock based-compensation | (22,975 | ) |  | (459 | ) |
| Amortization of investment premiums | 883 |  |  | — |  |
| Unrealized gain on notes receivable | — |  |  | (4,000 | ) |
| Amortization of debt discount | — |  |  | 527 |  |
| Write-off of debt discount on notes payable | — |  |  | 680 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | (25,841 | ) |  | 9,678 |  |
| Inventories | (22,297 | ) |  | 2,291 |  |
| Prepaid expenses and other current assets | (20,747 | ) |  | (5,621 | ) |
| Other assets | (3,257 | ) |  | (596 | ) |
| Accounts payable | 11,822 |  |  | 4,789 |  |
| Accrued liabilities | 3,082 |  |  | 626 |  |
| Deferred revenue | 57,975 |  |  | 2,779 |  |
| Income taxes payable | 21,846 |  |  | 372 |  |
| Other liabilities | (114 | ) |  | 2,616 |  |
| Interest payable | — |  |  | (1,630 | ) |
| Interest payable—related party | — |  |  | 670 |  |
| Net cash provided by operating activities | 73,373 |  |  | 63,946 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of property and equipment | (8,768 | ) |  | (8,579 | ) |
| Change in restricted cash | — |  |  | 4,040 |  |
| Purchases of intangible assets | (705 | ) |  | — |  |
| Net cash used in investing activities | (9,473 | ) |  | (4,539 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Principal payments of lease financing obligations | (514 | ) |  | (335 | ) |
| Payments—deferred offering costs | (261 | ) |  | — |  |
| Proceeds from issuance of common stock upon exercising options, net of repurchases | 11,991 |  |  | 2,078 |  |
| Proceeds from issuance of common stock under employee stock purchase plan | 4,856 |  |  | — |  |
| Excess tax benefit on stock-based compensation | 22,975 |  |  | 459 |  |
| Proceeds from initial public offering, net of issuance cost | — |  |  | 241,862 |  |
| Repayment on notes payable | — |  |  | (20,000 | ) |
| Net cash provided by financing activities | 39,047 |  |  | 224,064 |  |
| Effect of exchange rate changes | (20 | ) |  | 63 |  |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 102,927 |  |  | 283,534 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 240,031 |  |  | 113,664 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 342,958 |  |  | $ | 397,198 |  |
