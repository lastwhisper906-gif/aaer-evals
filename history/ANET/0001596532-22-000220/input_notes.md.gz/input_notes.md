# ANET notes — 0001596532-22-000220


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-22-000220:notes:1]
[same as prior period, unchanged from 0001596532-22-000112:notes:1]

[0001596532-22-000220:notes:2]
[same as prior period, unchanged from 0001596532-22-000112:notes:2]

[0001596532-22-000220:notes:3]
[same as prior period, unchanged from 0001596532-22-000112:notes:3]

[0001596532-22-000220:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2022, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2021 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

[0001596532-22-000220:notes:5]
[same as prior period, unchanged from 0001596532-22-000112:notes:5]

[0001596532-22-000220:notes:6]
[same as prior period, unchanged from 0001596532-22-000112:notes:6]

[0001596532-22-000220:notes:7]
[same as prior period, unchanged from 0001596532-22-000112:notes:7]

[0001596532-22-000220:notes:8]
[same as prior period, unchanged from 0001596532-22-000112:notes:8]

[0001596532-22-000220:notes:9]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including supply chain and labor shortages, inflation and monetary policy shifts, recession risks, the ongoing global coronavirus ("COVID-19") pandemic and potential disruptions from the Russia-Ukraine conflict.

[0001596532-22-000220:notes:10]
Our contract manufacturers and suppliers have experienced workforce disruptions, delays in component sourcing, production and export of their products as well as component shortages and increased component costs, which have disrupted our supply chain and have impacted and will likely continue to impact our ability to supply products to our customers on a timely basis. While we continue to experience strong overall demand from customers, we believe ongoing supply disruptions combined with other supply chain related constraints could impact our ability to fulfill this increased demand and as a result could negatively impact our business in future periods. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. The extent of the impact on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, the impact to our customers, partners, employees, contract manufacturers and supply chain, as well as restrictions on travel and transport, all of which continue to evolve and are unpredictable. Management continues to actively monitor the impact of these macroeconomic factors

[0001596532-22-000220:notes:11]
on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which these factors may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

[0001596532-22-000220:notes:12]
Recently Adopted Accounting Pronouncements

[0001596532-22-000220:notes:13]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. ASU 2021-08 requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC 606. Under previous GAAP, an acquirer generally recognizes assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 results in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption impact was immaterial to the condensed consolidated financial statements. The standard will not impact acquired contract assets or liabilities from business combinations occurring prior to the adoption date.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-22-000220:notes:14]
Fair Value Measurements 
    Assets measured at fair values on a recurring basis

[0001596532-22-000220:notes:15]
[same as prior period, unchanged from 0001596532-22-000112:notes:15]

[0001596532-22-000220:notes:16]
|  |  | As of June 30, 2022 |  | As of December 31, 2021 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 274,754 |  |  | $ | — |  |  | $ | — |  |  | $ | 274,754 |  |  | $ | 221,382 |  |  | $ | — |  |  | $ | — |  |  | $ | 221,382 |  |
| Commercial paper |  | — |  |  | 3,642 |  |  | — |  |  | 3,642 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | 274,754 |  |  | 3,642 |  |  | — |  |  | 278,396 |  |  | 221,382 |  |  | — |  |  | — |  |  | 221,382 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 18,462 |  |  | — |  |  | 18,462 |  |  | — |  |  | 141,274 |  |  | — |  |  | 141,274 |  |
| Certificate of deposits(1) |  | — |  |  | 13,030 |  |  | — |  |  | 13,030 |  |  | — |  |  | 44,931 |  |  | — |  |  | 44,931 |  |
| U.S. government notes |  | 1,082,084 |  |  | — |  |  | — |  |  | 1,082,084 |  |  | 1,057,810 |  |  | — |  |  | — |  |  | 1,057,810 |  |
| Corporate bonds |  | — |  |  | 1,066,585 |  |  | — |  |  | 1,066,585 |  |  | — |  |  | 1,252,226 |  |  | — |  |  | 1,252,226 |  |
| Agency securities |  | — |  |  | 211,768 |  |  | — |  |  | 211,768 |  |  | — |  |  | 291,261 |  |  | — |  |  | 291,261 |  |
| Marketable equity securities(2) |  | 16,727 |  |  | — |  |  | — |  |  | 16,727 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | 1,098,811 |  |  | 1,309,845 |  |  | — |  |  | 2,408,656 |  |  | 1,057,810 |  |  | 1,729,692 |  |  | — |  |  | 2,787,502 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,258 |  |  | — |  |  | — |  |  | 4,258 |  |  | 4,237 |  |  | — |  |  | — |  |  | 4,237 |  |
| Total Financial Assets |  | $ | 1,377,823 |  |  | $ | 1,313,487 |  |  | $ | — |  |  | $ | 2,691,310 |  |  | $ | 1,283,429 |  |  | $ | 1,729,692 |  |  | $ | — |  |  | $ | 3,013,121 |  |

[0001596532-22-000220:notes:17]
[same as prior period, unchanged from 0001596532-22-000112:notes:17]

[0001596532-22-000220:notes:18]
(1) As of June 30, 2022 and December 31, 2021, all of our certificates of deposits were domestic deposits.

[0001596532-22-000220:notes:19]
(2) The $16.7 million represents the fair value of marketable equity securities as of June 30, 2022. This amount includes $8.3 million that was reclassified from Investments on our condensed consolidated balance sheet following the commencement of public market trading of the issuer in January 2022. This publicly-traded equity investment generated an unrealized gain of $8.4 million for the six months ended June 30, 2022, and an unrealized loss of $5.1 million for the three months ended June 30, 2022.  The unrealized gains and losses are included in Other income (expense), net on the Condensed Consolidated Statements of Operations. Refer to Note 3. Financial Statements Details.

[0001596532-22-000220:notes:20]
During the three and six months ended on June 30, 2022, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-22-000220:notes:21]
[same as prior period, unchanged from 0001596532-22-000112:notes:21]

[0001596532-22-000220:notes:22]
The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities measured at fair value on a recurring basis (in thousands):

[0001596532-22-000220:notes:23]
|  |  | As of June 30, 2022 |  | As of December 31, 2021 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 18,462 |  |  | $ | — |  |  | $ | — |  |  | $ | 18,462 |  |  | $ | 141,274 |  |  | $ | — |  |  | $ | — |  |  | $ | 141,274 |  |
| U.S. government |  | 1,098,360 |  |  | — |  |  | (16,276) |  |  | 1,082,084 |  |  | 1,060,716 |  |  | 3 |  |  | (2,909) |  |  | 1,057,810 |  |
| Corporate bonds |  | 1,083,803 |  |  | 6 |  |  | (17,224) |  |  | 1,066,585 |  |  | 1,255,149 |  |  | 105 |  |  | (3,028) |  |  | 1,252,226 |  |
| Agency securities |  | 214,687 |  |  | 1 |  |  | (2,920) |  |  | 211,768 |  |  | 291,558 |  |  | 36 |  |  | (333) |  |  | 291,261 |  |
| Total |  | $ | 2,415,312 |  |  | $ | 7 |  |  | $ | (36,420) |  |  | $ | 2,378,899 |  |  | $ | 2,748,697 |  |  | $ | 144 |  |  | $ | (6,270) |  |  | $ | 2,742,571 |  |

[0001596532-22-000220:notes:24]
For debt securities in unrealized loss positions, it is not likely that we will be required to sell such securities before recovery of their amortized cost basis nor do we have the intent to sell such securities before maturity; we invest in debt securities that have maximum maturities of two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. Given the short-term and conservative nature of our portfolio, the unrealized losses are not related to credit risk; therefore, we did not recognize any credit losses or non-credit-related impairments related to our available-for-sale marketable debt securities for the three and six months ended June 30, 2022. All unrealized losses were recognized in other comprehensive income (loss). Realized losses were immaterial for the three and six months ended June 30, 2022.

[0001596532-22-000220:notes:25]
The following table is an analysis of our marketable debt securities in unrealized loss positions (in thousands):

[0001596532-22-000220:notes:26]
|  |  | As of June 30, 2022 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 1,082,084 |  |  | $ | (16,276) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,082,084 |  |  | $ | (16,276) |  |
| Corporate bonds |  | 995,771 |  |  | (16,075) |  |  | 65,373 |  |  | (1,149) |  |  | 1,061,144 |  |  | (17,224) |  |
| Agency securities |  | 206,768 |  |  | (2,920) |  |  | — |  |  | — |  |  | 206,768 |  |  | (2,920) |  |
| Total |  | $ | 2,284,623 |  |  | $ | (35,271) |  |  | $ | 65,373 |  |  | $ | (1,149) |  |  | $ | 2,349,996 |  |  | $ | (36,420) |  |

[0001596532-22-000220:notes:27]
As of June 30, 2022, we had no marketable debt securities with contractual maturities that exceed 24 months. The fair values of marketable debt securities, by remaining contractual maturities, are as follows (in thousands):

[0001596532-22-000220:notes:28]
|  |  | As of June 30, 2022 |
|  |  | Fair Value |
| Due in 1 year or less |  | $ | 1,700,701 |  |
| Due in 1 to 2 years |  | 678,198 |  |
| Total debt securities |  | $ | 2,378,899 |  |

[0001596532-22-000220:notes:29]
The weighted-average remaining duration of our marketable debt securities is approximately 0.8 years as of June 30, 2022. As we view these marketable debt securities as available to support current operations, we classify marketable debt securities with maturities beyond 12 months as current assets under the caption "Marketable securities" on the condensed consolidated balance sheets.

[0001596532-22-000220:notes:30]
[same as prior period, unchanged from 0001596532-22-000112:notes:30]

[0001596532-22-000220:notes:31]
[same as prior period, unchanged from 0001596532-22-000112:notes:31]

[0001596532-22-000220:notes:32]
We have non-marketable equity securities in privately-held companies that do not have readily-determinable fair values. These equity securities are included in Investments on the condensed consolidated balance sheets. Their initial cost is adjusted to fair value on a non-recurring basis based on observable price changes from orderly transactions of identical or similar securities of the same issuer, or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to these securities. In addition, the valuation requires management judgment due to the absence of market price and lack of liquidity.

[0001596532-22-000220:notes:33]
We did not record any realized gains or losses for our non-marketable equity securities measured at fair value on a non-recurring basis during the three and six months ended June 30, 2022 and June 30, 2021. We recorded an unrealized gain of $15.0 million on non-marketable equity securities based on observable price changes from orderly transactions of identical or similar securities of the same issuer in the six months ended June 30, 2022, but did not record any unrealized losses or additional unrealized gains in the three months ended June 30, 2022 and the three and six months ended June 30, 2021. We evaluate our non-marketable equity securities for impairment at each reporting period via a qualitative assessment with various potential impairment indicators, including, but not limited to, an assessment of a significant adverse change in the economic environment, significant adverse changes in the general market condition of the geographies and industries in which our investees operate, and other publicly-available information that affected the value of the its non-marketable equity securities.

[0001596532-22-000220:notes:34]
The following table summarizes the activity related to our non-marketable equity securities as of June 30, 2022 and December 31, 2021 (in thousands):

[0001596532-22-000220:notes:35]
|  |  | June 30, 2022 |  | December 31, 2021 |
| Cost of investments (1) |  | $ | 23,263 |  |  | $ | 14,933 |  |
| Cumulative impairment |  | — |  |  | — |  |
| Cumulative upward adjustment (1) |  | 15,000 |  |  | 5,314 |  |
| Carrying amount of investments |  | $ | 38,263 |  |  | $ | 20,247 |  |

[0001596532-22-000220:notes:36]
(1) During the six months ended June 30, 2022, $3.0 million previously included in the Cost of investments and $5.3 million previously included in the Cumulative upward adjustment, or $8.3 million in aggregate, were reclassified from Investments to Marketable securities on our condensed consolidated balance sheet following the commencement of public market trading of the issuer. There was no such activity in the three months ended June 30, 2022.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-22-000220:notes:37]
The following tables summarize the fair value of these financial assets by significant investment category and their levels within the fair value hierarchy (in thousands):

[0001596532-22-000220:notes:38]
(2) The $16.7 million represents the fair value of marketable equity securities as of June 30, 2022. This amount includes $8.3 million that was reclassified from Investments on our condensed consolidated balance sheet following the commencement of public market trading of the issuer in January 2022. This publicly-traded equity investment generated an unrealized gain of $8.4 million for the six months ended June 30, 2022, and an unrealized loss of $5.1 million for the three months ended June 30, 2022.  The unrealized gains and losses are included in Other income (expense), net on the Condensed Consolidated Statements of Operations. Refer to Note 3. Financial Statements Details. 
The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities measured at fair value on a recurring basis (in thousands):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-22-000220:notes:39]
[same as prior period, unchanged from 0001596532-22-000112:notes:37]

[0001596532-22-000220:notes:40]
The reconciliation of cash, cash equivalents and restricted cash reported on the unaudited condensed consolidated balance sheets to the total of the same such amounts in the unaudited condensed consolidated statements of cash flows is as follows (in thousands):

[0001596532-22-000220:notes:41]
|  |  | June 30, 2022 |  | December 31, 2021 |
| Cash and cash equivalents |  | $ | 493,246 |  |  | $ | 620,813 |  |
| Restricted cash included in other assets |  | 4,258 |  |  | 4,237 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 497,504 |  |  | $ | 625,050 |  |

[0001596532-22-000220:notes:42]
[same as prior period, unchanged from 0001596532-22-000112:notes:40]

[0001596532-22-000220:notes:43]
[same as prior period, unchanged from 0001596532-22-000112:notes:41]

[0001596532-22-000220:notes:44]
|  |  | June 30, 2022 |  | December 31, 2021 |
| Accounts receivable |  | $ | 598,380 |  |  | $ | 521,597 |  |
| Allowance for doubtful accounts |  | (207) |  |  | (132) |  |
| Product sales rebate and returns reserve |  | (12,387) |  |  | (4,956) |  |
| Accounts receivable, net |  | $ | 585,786 |  |  | $ | 516,509 |  |

[0001596532-22-000220:notes:45]
[same as prior period, unchanged from 0001596532-22-000112:notes:43]

[0001596532-22-000220:notes:46]
[same as prior period, unchanged from 0001596532-22-000112:notes:44]

[0001596532-22-000220:notes:47]
|  |  | June 30, 2022 |  | December 31, 2021 |
| Raw materials |  | $ | 462,396 |  |  | $ | 316,737 |  |
| Finished goods |  | 390,414 |  |  | 333,380 |  |
| Total inventories |  | $ | 852,810 |  |  | $ | 650,117 |  |

[0001596532-22-000220:notes:48]
[same as prior period, unchanged from 0001596532-22-000112:notes:46]

[0001596532-22-000220:notes:49]
[same as prior period, unchanged from 0001596532-22-000112:notes:47]

[0001596532-22-000220:notes:50]
|  |  | June 30, 2022 |  | December 31, 2021 |
| Inventory deposits |  | $ | 98,099 |  |  | $ | 46,311 |  |
| Prepaid income taxes |  | 10,189 |  |  | 8,977 |  |
| Other current assets |  | 256,102 |  |  | 163,916 |  |
| Other prepaid expenses and deposits |  | 24,307 |  |  | 18,531 |  |
| Total prepaid expenses and other current assets |  | $ | 388,697 |  |  | $ | 237,735 |  |

[0001596532-22-000220:notes:51]
[same as prior period, unchanged from 0001596532-22-000112:notes:49]

[0001596532-22-000220:notes:52]
[same as prior period, unchanged from 0001596532-22-000112:notes:50]

[0001596532-22-000220:notes:53]
|  |  | June 30, 2022 |  | December 31, 2021 |
| Land |  | $ | 40,485 |  |  | $ | 40,145 |  |
| Equipment and machinery |  | 111,646 |  |  | 90,915 |  |
| Computer hardware and software |  | 47,376 |  |  | 44,083 |  |
| Leasehold improvements |  | 30,208 |  |  | 30,502 |  |
| Furniture and fixtures |  | 3,612 |  |  | 3,634 |  |
| Construction-in-process |  | 2,207 |  |  | 2,378 |  |
| Property and equipment, gross |  | 235,534 |  |  | 211,657 |  |
| Less: accumulated depreciation |  | (143,711) |  |  | (133,023) |  |
| Property and equipment, net |  | $ | 91,823 |  |  | $ | 78,634 |  |

[0001596532-22-000220:notes:54]
Depreciation expense was $6.2 million and $4.8 million for the three months ended June 30, 2022 and 2021, respectively, and $11.8 million and $9.7 million for the six months ended June 30, 2022 and 2021, respectively.

[0001596532-22-000220:notes:55]
[same as prior period, unchanged from 0001596532-22-000112:notes:53]

[0001596532-22-000220:notes:56]
[same as prior period, unchanged from 0001596532-22-000112:notes:54]

[0001596532-22-000220:notes:57]
|  |  | June 30, 2022 |  | December 31, 2021 |
| Accrued payroll related costs |  | $ | 78,066 |  |  | $ | 99,571 |  |
| Accrued manufacturing costs |  | 79,949 |  |  | 80,213 |  |
| Accrued product development costs |  | 24,311 |  |  | 22,188 |  |
| Accrued warranty costs |  | 13,288 |  |  | 10,414 |  |
| Other |  | 14,720 |  |  | 14,257 |  |
| Total accrued liabilities |  | $ | 210,334 |  |  | $ | 226,643 |  |

[0001596532-22-000220:notes:58]
[same as prior period, unchanged from 0001596532-22-000112:notes:56]

[0001596532-22-000220:notes:59]
[same as prior period, unchanged from 0001596532-22-000112:notes:57]

[0001596532-22-000220:notes:60]
|  |  | Six Months Ended June 30, |
|  |  | 2022 |  | 2021 |
| Warranty accrual, beginning of period |  | $ | 10,414 |  |  | $ | 9,314 |  |
| Liabilities accrued for warranties issued during the period |  | 8,441 |  |  | 5,603 |  |
| Warranty costs incurred during the period |  | (5,567) |  |  | (5,922) |  |
| Warranty accrual, end of period |  | $ | 13,288 |  |  | $ | 8,995 |  |

[0001596532-22-000220:notes:61]
[same as prior period, unchanged from 0001596532-22-000112:notes:59]

[0001596532-22-000220:notes:62]
[same as prior period, unchanged from 0001596532-22-000112:notes:60]

[0001596532-22-000220:notes:63]
|  |  | Six Months Ended June 30, |
|  |  | 2022 |  |  |  |  |
| Contract assets, beginning balance |  | $ | 24,388 |  |  |  |  |  |
| Contract assets, ending balance |  | 29,237 |  |  |  |  |  |

[0001596532-22-000220:notes:64]
Contract Liabilities, Deferred Revenue and Other Performance Obligations

[0001596532-22-000220:notes:65]
[same as prior period, unchanged from 0001596532-22-000112:notes:62]

[0001596532-22-000220:notes:66]
[same as prior period, unchanged from 0001596532-22-000112:notes:63]

[0001596532-22-000220:notes:67]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Contract liabilities, beginning balance |  | $ | 98,422 |  |  | $ | 80,465 |  |  | $ | 93,382 |  |  | $ | 85,957 |  |
| Less: Revenue recognized from beginning balance |  | (8,589) |  |  | (8,482) |  |  | (19,076) |  |  | (18,482) |  |
| Less: Beginning balance reclassified to deferred revenue |  | (4,338) |  |  | (3,856) |  |  | (3,606) |  |  | (12,710) |  |
| Add: Contract liabilities recognized |  | 16,105 |  |  | 15,227 |  |  | 30,900 |  |  | 28,589 |  |
| Contract liabilities, ending balance |  | $ | 101,600 |  |  | $ | 83,354 |  |  | $ | 101,600 |  |  | $ | 83,354 |  |

[0001596532-22-000220:notes:68]
As of June 30, 2022 and December 31, 2021, $41.4 million and $38.7 million of our contract liabilities, respectively, were included in "Other current liabilities" with the remaining balances included in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001596532-22-000220:notes:69]
[same as prior period, unchanged from 0001596532-22-000112:notes:66]

[0001596532-22-000220:notes:70]
[same as prior period, unchanged from 0001596532-22-000112:notes:67]

[0001596532-22-000220:notes:71]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Deferred revenue, beginning balance |  | $ | 1,123,746 |  |  | $ | 720,031 |  |  | $ | 929,312 |  |  | $ | 650,827 |  |
| Less: Revenue recognized from beginning balance |  | (309,594) |  |  | (145,556) |  |  | (322,954) |  |  | (222,865) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 219,338 |  |  | 171,615 |  |  | 427,132 |  |  | 318,128 |  |
| Deferred revenue, ending balance |  | $ | 1,033,490 |  |  | $ | 746,090 |  |  | $ | 1,033,490 |  |  | $ | 746,090 |  |

[0001596532-22-000220:notes:72]
[same as prior period, unchanged from 0001596532-22-000112:notes:69]

[0001596532-22-000220:notes:73]
Other performance obligations include unbilled contract revenue for services and products that will be recognized in future periods. As of June 30, 2022, other performance obligations of $178.1 million were comprised mainly of unbilled multi-year PCS contract amounts that will be recognized as revenue in future periods. In addition, as of June 30, 2022 the company had entered into $762.7 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-22-000220:notes:74]
[same as prior period, unchanged from 0001596532-22-000112:notes:71]

[0001596532-22-000220:notes:75]
Revenue from total remaining performance obligations represents contract liabilities, deferred revenue and unbilled contract revenue that will be recognized in future periods. As of June 30, 2022, approximately $1,313.3 million of revenue is expected to be recognized from remaining performance obligations, of which approximately 83% is expected to be recognized over the next two years and approximately 17% is expected to be recognized during the third to the fifth year. These amounts do not include the $762.7 million of binding contractual agreements related primarily to future product shipments outlined above. As of June 30, 2022, it is expected that the majority of the amounts allocated to these specific performance obligations will be recognized as revenue upon product shipment over the next two years; however, given the current uncertain supply chain environment and industry wide supply constraints, we may experience manufacturing and shipment delays or cancellations related to these performance obligations, which could impact revenue recognition.

[0001596532-22-000220:notes:76]
Other Income (Expense), net

[0001596532-22-000220:notes:77]
Other income (expense), net consists of the following (in thousands):

[0001596532-22-000220:notes:78]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Interest income |  | $ | 4,427 |  |  | $ | 1,872 |  |  | $ | 6,855 |  |  | $ | 3,917 |  |
| Unrealized gain (loss) on equity investments |  | (5,084) |  |  | — |  |  | 23,413 |  |  | — |  |
| Other income (expense), net |  | 124 |  |  | (153) |  |  | 679 |  |  | (623) |  |
| Total |  | $ | (533) |  |  | $ | 1,719 |  |  | $ | 30,947 |  |  | $ | 3,294 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-22-000220:notes:79]
The following table summarizes the activity related to our contract liabilities (in thousands):

[0001596532-22-000220:notes:80]
The following table summarizes the activity related to our deferred revenue (in thousands):


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-22-000220:notes:81]
Acquisition, Goodwill and Acquisition-Related Intangible Assets
Acquisitions

[0001596532-22-000220:notes:82]
During the six months ended June 30, 2022, we completed two acquisitions of private companies for total consideration of $158.9 million including $4.0 million in common stock and the remainder in cash. The purchase prices included $62.3 million of intangible assets, $85.1 million of goodwill and $11.5 million of net assets acquired. We also incurred certain acquisition-related expenses of $4.7 million, which primarily consisted of retention bonuses to continuing employees as well as professional and consulting fees.

[0001596532-22-000220:notes:83]
The intangible assets are amortized on a straight-line basis over their estimated useful lives, as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. The following table sets forth the components of identifiable intangible assets acquired and their estimated useful lives as of the date of acquisition (in thousands, except years):

[0001596532-22-000220:notes:84]
|  |  | Acquisition Date Fair Value |  | Weighted Average Estimated Useful Life (in years) |
| Developed technology |  | $ | 30,200 |  |  | 5.7 |
| Customer relationships |  | 28,700 |  |  | 7.0 |
| Trade name |  | 3,400 |  |  | 3.0 |
| Total intangible assets acquired |  | $ | 62,300 |  |  |  |

[0001596532-22-000220:notes:85]
Goodwill

[0001596532-22-000220:notes:86]
The changes in the carrying values of goodwill for the three and six months ended June 30, 2022 are as follows (in thousands):

[0001596532-22-000220:notes:87]
|  |  | Amount |
| Balance at December 31, 2021 |  | $ | 188,397 |  |
| Additions related to the acquisition completed in January, 2022 |  | 28,518 |  |
| Balance at March 31, 2022 |  | $ | 216,915 |  |
| Additions related to the acquisition completed in June, 2022 |  | 56,530 |  |
| Measurement-period adjustments to the acquisition completed in January, 2022 |  | 49 |  |
| Balance at June 30, 2022 |  | $ | 273,494 |  |

[0001596532-22-000220:notes:88]
[same as prior period, unchanged from 0001596532-22-000112:notes:80]

[0001596532-22-000220:notes:89]
Acquisition-related intangible assets were as follows (in thousands, except years):

[0001596532-22-000220:notes:90]
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life (in years) |
|  | December 31, 2021 |  | Additions |  | June 30, 2022 |  | December 31, 2021 |  | Amortization |  | June 30, 2022 |  | December 31, 2021 |  | June 30, 2022 |  |
| Developed technology | $ | 124,730 |  |  | $ | 30,200 |  |  | $ | 154,930 |  |  | $ | (53,663) |  |  | $ | (11,732) |  |  | $ | (65,395) |  |  | $ | 71,067 |  |  | $ | 89,535 |  |  | 4.7 |
| Customer relationships | 25,920 |  |  | 28,700 |  |  | 54,620 |  |  | (7,899) |  |  | (2,347) |  |  | (10,246) |  |  | 18,021 |  |  | 44,374 |  |  | 6.1 |
| Trade name | 8,990 |  |  | 3,400 |  |  | 12,390 |  |  | (4,693) |  |  | (770) |  |  | (5,463) |  |  | 4,297 |  |  | 6,927 |  |  | 3.1 |
| Others | 5,720 |  |  | — |  |  | 5,720 |  |  | (5,550) |  |  | (170) |  |  | (5,720) |  |  | 170 |  |  | — |  |  | 0.0 |
| Total | $ | 165,360 |  |  | $ | 62,300 |  |  | $ | 227,660 |  |  | $ | (71,805) |  |  | $ | (15,019) |  |  | $ | (86,824) |  |  | $ | 93,555 |  |  | $ | 140,836 |  |  | 5.1 |

[0001596532-22-000220:notes:91]
Amortization expense related to acquisition-related intangible assets was $7.7 million, and $7.4 million for the three months ended June 30, 2022 and 2021, and $15.0 million and $14.8 million for the six months ended June 30, 2022 and 2021, respectively.

[0001596532-22-000220:notes:92]
As of June 30, 2022, future estimated amortization expense related to the acquisition-related intangible assets is as follows (in thousands):

[0001596532-22-000220:notes:93]
|  |  | Future Amortization Expense |
| Remainder of 2022 |  | $ | 18,630 |  |
| 2023 |  | 33,438 |  |
| 2024 |  | 26,759 |  |
| 2025 |  | 19,642 |  |
| 2026 |  | 17,260 |  |
| Thereafter |  | 25,107 |  |
| Total |  | $ | 140,836 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-22-000220:notes:94]
Commitments and Contingencies
Purchase Commitments

[0001596532-22-000220:notes:95]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of June 30, 2022, we had non-cancellable purchase commitments of $4,472.2 million, out of which $2,937.6 million have confirmed receipt dates within 12 months, and $1,534.6 million have confirmed receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-22-000220:notes:96]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $100.8 million and $49.1 million as of June 30, 2022 and December 31, 2021, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

[0001596532-22-000220:notes:97]
Guarantees

[0001596532-22-000220:notes:98]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-22-000220:notes:99]
Legal Proceedings

[0001596532-22-000220:notes:100]
WSOU Investments, LLC

[0001596532-22-000220:notes:101]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement.  On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit.

[0001596532-22-000220:notes:102]
We intend to vigorously defend against the claims brought against us by WSOU; however, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-22-000220:notes:103]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated; however, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-22-000220:notes:104]
Other matters

[0001596532-22-000220:notes:105]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-22-000220:notes:106]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of June 30, 2022, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse 
impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-22-000220:notes:107]
Stockholders’ Equity and Stock-Based Compensation
Stock Repurchase Program

[0001596532-22-000220:notes:108]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the "Repurchase Program").  This authorization allowed us to repurchase shares of our common stock over three years, and we completed our repurchases under the Repurchase Program during the fourth quarter of 2021. In the fourth quarter of 2021, our board of directors authorized an additional $1.0 billion stock repurchase program (the “New Repurchase Program”), which allows us to repurchase shares of our common stock to be funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Exchange Act, or a combination of the foregoing. The New Repurchase Program commenced in November 2021 and expires on the three-year anniversary thereof. The New Repurchase Program does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of June 30, 2022, the remaining authorized amount for stock repurchases under this program was approximately $307.2 million.

[0001596532-22-000220:notes:109]
A summary of the stock repurchase activity under the New Repurchase Program for the six months ended June 30, 2022 is as follows (in thousands, except per share amounts):

[0001596532-22-000220:notes:110]
|  |  |  |  |  |  | Six Months Ended |
|  |  |  |  |  |  | June 30, 2022 |
| Aggregate purchase price |  |  |  |  |  | $ | 619,888 |  |
| Shares repurchased |  |  |  |  |  | 5,954 |  |
| Average price paid per share |  |  |  |  |  | $ | 104.11 |  |

[0001596532-22-000220:notes:111]
The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings in our condensed consolidated statements of stockholders' equity.  All shares repurchased have been retired.

[0001596532-22-000220:notes:112]
Equity Award Plan Activities

[0001596532-22-000220:notes:113]
2014 Equity Incentive Plan

[0001596532-22-000220:notes:114]
In April 2014, our board of directors and stockholders approved the 2014 Equity Incentive Plan (the “2014 Plan”), effective on the first day that our common stock was publicly traded, and simultaneously terminated the 2004 and 2011 equity plans as to future grants; however, these plans will continue to govern the terms and conditions of the outstanding options previously granted thereunder.

[0001596532-22-000220:notes:115]
Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”). The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of the outstanding shares of our common stock on the immediately preceding December 31, but not to exceed 50,000,000 shares (the “2014 Plan Evergreen Increase”), unless our board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2022, our board of directors authorized an increase of 9,230,434 shares to the shares available for issuance under the 2014 Plan. As of June 30, 2022, there remained approximately 94.7 million shares available for issuance under the 2014 Plan.

[0001596532-22-000220:notes:116]
2014 Employee Stock Purchase Plan

[0001596532-22-000220:notes:117]
In April 2014, our board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding immediately preceding December 31, but not to exceed 10,000,000 shares, unless our board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2022, our board of directors authorized an increase of 3,076,811 shares to the shares available for issuance under our 2014 Employee Stock Purchase Plan (the “ESPP”). During the six months ended June 30, 2022, we issued 240,394 shares at a weighted-average purchase price of $48.75 per share under the ESPP. As of June 30, 2022, there remained approximately 20.8 million shares available for issuance under the ESPP.

[0001596532-22-000220:notes:118]
Stock Option Activities

[0001596532-22-000220:notes:119]
The following table summarizes the option activity under our stock plans and related information (in thousands, except years and per share amounts):

[0001596532-22-000220:notes:120]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2021 |  | 8,685 |  |  | $ | 12.45 |  |  | 2.8 |  | $ | 1,140,369 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (1,230) |  |  | 9.17 |  |  |  |  |  |
| Options canceled |  | (164) |  |  | 16.44 |  |  |  |  |  |
| Balance—June 30, 2022 |  | 7,291 |  |  | $ | 12.91 |  |  | 2.4 |  | $ | 589,386 |  |
| Vested and exercisable—June 30, 2022 |  | 6,145 |  |  | $ | 10.58 |  |  | 2.0 |  | $ | 511,007 |  |

[0001596532-22-000220:notes:121]
Restricted Stock Unit (RSU) Activities

[0001596532-22-000220:notes:122]
A summary of the RSU activity is presented below (in thousands, except years and per share amounts):

[0001596532-22-000220:notes:123]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2021 |  | 7,821 |  |  | $ | 70.98 |  |  | 1.7 |  | $ | 1,124,229 |  |
| RSUs granted |  | 2,873 |  |  | 99.57 |  |  |  |  |  |
| RSUs vested |  | (1,374) |  |  | 63.72 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (272) |  |  | 74.77 |  |  |  |  |  |
| Unvested balance—June 30, 2022 |  | 9,048 |  |  | $ | 81.16 |  |  | 1.9 |  | $ | 848,123 |  |

[0001596532-22-000220:notes:124]
Stock-Based Compensation Expense

[0001596532-22-000220:notes:125]
The following table summarizes the stock-based compensation expense related to our equity awards (in thousands):

[0001596532-22-000220:notes:126]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Cost of revenue |  | $ | 2,312 |  |  | $ | 1,796 |  |  | $ | 3,621 |  |  | $ | 3,196 |  |
| Research and development |  | 28,449 |  |  | 23,139 |  |  | 56,025 |  |  | 45,121 |  |
| Sales and marketing |  | 12,827 |  |  | 11,368 |  |  | 25,936 |  |  | 21,453 |  |
| General and administrative |  | 6,636 |  |  | 8,641 |  |  | 14,921 |  |  | 12,727 |  |
| Total stock-based compensation |  | $ | 50,224 |  |  | $ | 44,944 |  |  | $ | 100,503 |  |  | $ | 82,497 |  |

[0001596532-22-000220:notes:127]
As of June 30, 2022, there were $643.6 million of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 3.6 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-22-000220:notes:128]
[same as prior period, unchanged from 0001596532-22-000112:notes:121]

[0001596532-22-000220:notes:129]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2022 |  | 2021 (1) |  | 2022 |  | 2021 (1) |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 299,099 |  |  | $ | 196,888 |  |  | $ | 571,358 |  |  | $ | 377,254 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share, basic |  | 306,754 |  |  | 305,844 |  |  | 307,399 |  |  | 305,536 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Stock options and RSUs |  | 9,695 |  |  | 12,764 |  |  | 10,509 |  |  | 12,940 |  |
| Employee stock purchase plan |  | 132 |  |  | 232 |  |  | 132 |  |  | 232 |  |
| Weighted-average shares used in computing net income per share, diluted |  | 316,581 |  |  | 318,840 |  |  | 318,040 |  |  | 318,708 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.98 |  |  | $ | 0.64 |  |  | $ | 1.86 |  |  | $ | 1.23 |  |
| Diluted |  | $ | 0.94 |  |  | $ | 0.62 |  |  | $ | 1.80 |  |  | $ | 1.18 |  |

[0001596532-22-000220:notes:130]
[same as prior period, unchanged from 0001596532-22-000112:notes:123]

[0001596532-22-000220:notes:131]
[same as prior period, unchanged from 0001596532-22-000112:notes:124]

[0001596532-22-000220:notes:132]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |  |  |
|  |  | 2022 |  | 2021 (1) |  | 2022 |  | 2021 (1) |  |  |  |  |
| Stock options and RSUs |  | 781 |  |  | 404 |  |  | 423 |  |  | 460 |  |  |  |  |  |
| Employee stock purchase plan |  | — |  |  | 80 |  |  | 8 |  |  | 60 |  |  |  |  |  |
| Total |  | 781 |  |  | 484 |  |  | 431 |  |  | 520 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-22-000220:notes:133]
Income Taxes (in thousands, except percentages)

[0001596532-22-000220:notes:134]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |  |  |  |  |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  |  |  |  |
| Income before income taxes |  | $ | 362,320 |  |  | $ | 221,084 |  |  | $ | 671,787 |  |  | $ | 428,951 |  |  |  |  |  |
| Provision for income taxes |  | 63,221 |  |  | 24,196 |  |  | 100,429 |  |  | 51,697 |  |  |  |  |  |
| Effective tax rate |  | 17.4 | % |  | 10.9 | % |  | 14.9 | % |  | 12.1 | % |  |  |  |  |

[0001596532-22-000220:notes:135]
The increase in the effective tax rates in the three and six months ended June 30, 2022, as compared to the same periods in 2021, was primarily due to a decrease in the proportion of tax benefits attributable to stock-based compensation versus total pre-tax income.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-22-000220:notes:136]
Geographical Information      We operate in one reportable segment. The following table represents revenue based on customers’ shipping addresses (in thousands):

[0001596532-22-000220:notes:137]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Americas |  | $ | 845,055 |  |  | $ | 514,149 |  |  | $ | 1,509,432 |  |  | $ | 1,016,021 |  |
| Europe, Middle East and Africa |  | 104,538 |  |  | 112,048 |  |  | 239,343 |  |  | 208,322 |  |
| Asia-Pacific |  | 102,298 |  |  | 81,122 |  |  | 180,182 |  |  | 150,538 |  |
| Total revenue |  | $ | 1,051,891 |  |  | $ | 707,319 |  |  | $ | 1,928,957 |  |  | $ | 1,374,881 |  |

[0001596532-22-000220:notes:138]
Long-lived assets, net, excluding intercompany receivables, investments in subsidiaries, privately-held equity investments and deferred tax assets, by location are summarized as follows (in thousands):

[0001596532-22-000220:notes:139]
|  |  | June 30, 2022 |  | December 31, 2021 |
| United States |  | $ | 70,216 |  |  | $ | 62,163 |  |
| International |  | 21,607 |  |  | 16,471 |  |
| Total |  | $ | 91,823 |  |  | $ | 78,634 |  |
