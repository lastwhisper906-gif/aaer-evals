# ANET MD&A — 0001596532-22-000220


## mdna

[0001596532-22-000220:mdna:1]
[same as prior period, unchanged from 0001596532-22-000112:mdna:1]

[0001596532-22-000220:mdna:2]
[same as prior period, unchanged from 0001596532-22-000112:mdna:2]

[0001596532-22-000220:mdna:3]
[same as prior period, unchanged from 0001596532-22-000112:mdna:3]

[0001596532-22-000220:mdna:4]
[same as prior period, unchanged from 0001596532-22-000112:mdna:4]

[0001596532-22-000220:mdna:5]
Historically, large purchases by a relatively limited number of end customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large end customers primarily due to changes in demand patterns specific to these customers, the time it takes these end customers to evaluate, test, qualify and accept our products, and the overall complexity of these large orders. We expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. For example, sales to our end customers Microsoft and Meta Platforms in fiscal 2019 collectively represented 40% of our total revenue, whereas sales to our end customer Microsoft in fiscal 2020 and 2021 amounted to 21.5% and 15.0% of our revenues, respectively, with our end customer Meta Platforms representing less than 10% of our revenues in both fiscal 2020 and 2021. This variability in customer concentration has been linked to the timing of new product deployments and spending cycles with these customers, and we expect their contributions to return to more elevated levels during fiscal 2022. We expect customer concentration with these large end customers to be cyclical and linked to new product introductions and customer investment cycles. Furthermore, we typically provide pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur.

[0001596532-22-000220:mdna:6]
[same as prior period, unchanged from 0001596532-22-000112:mdna:6]

[0001596532-22-000220:mdna:7]
The markets for cloud networking solutions are highly competitive and characterized by rapidly changing technology, changing end-customer needs, evolving industry standards, frequent introductions of new products and services, and industry consolidation. We expect competition to intensify in the future as the market for cloud networking expands and existing competitors and new market entrants introduce new products or enhance existing products. Our future success is dependent upon our ability to continue to evolve and adapt to our rapidly changing environment. We must also continue to develop market-leading products and features that address the needs of our existing and new customers, and increase sales in the enterprise data center switching, and campus workspace markets. We intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new end customers more effectively, increase sales to existing customers, and provide services and support. In addition, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our ability to rapidly develop new features and applications.

[0001596532-22-000220:mdna:8]
[same as prior period, unchanged from 0001596532-22-000112:mdna:9]

[0001596532-22-000220:mdna:9]
Macroeconomic Update

[0001596532-22-000220:mdna:10]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including supply chain and labor shortages, inflation and monetary supply shifts, recession risks, the ongoing global coronavirus ("COVID-19") pandemic, and potential disruptions from the Russia-Ukraine conflict.

[0001596532-22-000220:mdna:11]
Our manufacturing and supply chain operations continue to experience significant constraints, with component shortages, increased component and supply chain costs and delays broadly impacting the industry as a whole. We continue to work closely with our contract manufacturers and supply chain partners who have experienced delays in component sourcing, workforce disruptions and governmental restrictions on the production and export of their products. Although we have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, these delays have negatively impacted our ability to supply products to our customers on a timely basis. We have extended our demand planning horizon, increased our purchase commitments and expect to continue to invest in working capital to address delays in component sourcing and the risk of future supply chain disruptions, but we cannot be certain that such delays or disruptions will not occur. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. While we continue to experience strong overall demand from customers, we believe ongoing supply disruptions combined with other supply chain related constraints, could impact our ability to fulfill this increased demand and as a result could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the Russia-Ukraine conflict, continued escalation of the conflict may negatively impact the global economy and our future operating results and financial condition.

[0001596532-22-000220:mdna:12]
Management continues to actively monitor the impact of these macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which are uncertain and cannot be predicted; however, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that any extended or renewed economic disruptions or deterioration in the global economy could have a negative impact on demand from our customers in future periods. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

[0001596532-22-000220:mdna:13]
[same as prior period, unchanged from 0001596532-22-000112:mdna:14]

[0001596532-22-000220:mdna:14]
Three and Six Months Ended June 30, 2022 Compared to Three and Six Months Ended June 30, 2021

[0001596532-22-000220:mdna:15]
[same as prior period, unchanged from 0001596532-22-000112:mdna:16]

[0001596532-22-000220:mdna:16]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | Change in |  | 2022 |  | 2021 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 885,806 |  |  | $ | 566,467 |  |  | $ | 319,339 |  |  | 56.4 | % |  | $ | 1,610,524 |  |  | $ | 1,105,612 |  |  | $ | 504,912 |  |  | 45.7 | % |
| Service |  | 166,085 |  |  | 140,852 |  |  | 25,233 |  |  | 17.9 |  |  | 318,433 |  |  | 269,269 |  |  | 49,164 |  |  | 18.3 |  |
| Total revenue |  | 1,051,891 |  |  | 707,319 |  |  | 344,572 |  |  | 48.7 |  |  | 1,928,957 |  |  | 1,374,881 |  |  | 554,076 |  |  | 40.3 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 375,634 |  |  | 225,779 |  |  | 149,855 |  |  | 66.4 |  |  | 669,443 |  |  | 444,212 |  |  | 225,231 |  |  | 50.7 |  |
| Service |  | 32,992 |  |  | 27,362 |  |  | 5,630 |  |  | 20.6 |  |  | 62,404 |  |  | 51,219 |  |  | 11,185 |  |  | 21.8 |  |
| Total cost of revenue |  | 408,626 |  |  | 253,141 |  |  | 155,485 |  |  | 61.4 |  |  | 731,847 |  |  | 495,431 |  |  | 236,416 |  |  | 47.7 |  |
| Gross profit |  | $ | 643,265 |  |  | $ | 454,178 |  |  | $ | 189,087 |  |  | 41.6 | % |  | $ | 1,197,110 |  |  | $ | 879,450 |  |  | $ | 317,660 |  |  | 36.1 | % |
| Gross margin |  | 61.2 | % |  | 64.2 | % |  |  |  |  |  | 62.1 | % |  | 64.0 | % |  |  |  |  |

[0001596532-22-000220:mdna:17]
[same as prior period, unchanged from 0001596532-22-000112:mdna:18]

[0001596532-22-000220:mdna:18]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2022 |  | % of Total |  | 2021 |  | % of Total |  | 2022 |  | % of Total |  | 2021 |  | % of Total |
| Americas |  | $ | 845,055 |  |  | 80.4 | % |  | $ | 514,149 |  |  | 72.7 | % |  | $ | 1,509,432 |  |  | 78.3 | % |  | $ | 1,016,021 |  |  | 73.9 | % |
| Europe, Middle East and Africa |  | 104,538 |  |  | 9.9 |  |  | 112,048 |  |  | 15.8 |  |  | 239,343 |  |  | 12.4 |  |  | 208,322 |  |  | 15.2 |  |
| Asia-Pacific |  | 102,298 |  |  | 9.7 |  |  | 81,122 |  |  | 11.5 |  |  | 180,182 |  |  | 9.3 |  |  | 150,538 |  |  | 10.9 |  |
| Total revenue |  | $ | 1,051,891 |  |  | 100.0 | % |  | $ | 707,319 |  |  | 100.0 | % |  | $ | 1,928,957 |  |  | 100.0 | % |  | $ | 1,374,881 |  |  | 100.0 | % |

[0001596532-22-000220:mdna:19]
[same as prior period, unchanged from 0001596532-22-000112:mdna:20]

[0001596532-22-000220:mdna:20]
Product revenue primarily consists of sales of our switching and routing products, and software licenses. Service revenue is primarily derived from sales of PCS contracts, which are typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing, size, and complexity of orders, especially with respect to our large end customers.

[0001596532-22-000220:mdna:21]
Product revenue increased $319.3 million, or 56.4%, and $504.9 million, or 45.7%, for the three and six months ended June 30, 2022, respectively, compared to the same periods in 2021. These increases reflect strong demand for our switching and routing platforms from across our customer base, including healthy contributions from our large cloud customers. Supply chain constraints continued to impact our revenue performance in these periods and while changes in product deferred revenue impacted the timing of revenue recognition on a quarterly basis, it was not a net contributor to revenue growth for the six-month period ended June 30, 2022.  In addition, service revenue increased $25.2 million, or 17.9%, and $49.2 million, or 18.3%, in the three and six months ended June 30, 2022, compared to the same periods in 2021, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenues represented 19.6% and 21.7% of total revenues in the three and six months ended June 30, 2022, respectively, decreasing from 27.3% and 26.1% for the same periods in the prior year, which was primarily driven by increased purchases from large global customers in our Americas region. We continued to experience competitive pricing pressure on our products and services.

[0001596532-22-000220:mdna:22]
[same as prior period, unchanged from 0001596532-22-000112:mdna:23]

[0001596532-22-000220:mdna:23]
Cost of product revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs of our manufacturing operations, including freight, and other costs associated with manufacturing our products and managing our inventory and supply chain. Cost of service revenue primarily consists of personnel and other costs associated with our global customer support and services organizations.

[0001596532-22-000220:mdna:24]
Cost of revenue increased $155.5 million, or 61.4%, and $236.4 million, or 47.7%, for the three and six months ended June 30, 2022, respectively, compared to the same periods in 2021. These increases were primarily driven by a corresponding

[0001596532-22-000220:mdna:25]
increase in product and service revenues, combined with an increase in material and logistics costs to mitigate supply chain constraints and to meet customer demand.

[0001596532-22-000220:mdna:26]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including pricing pressure on our products and services due to competition, the mix of sales to large end customers who generally receive lower pricing, the mix of products sold, manufacturing-related costs, including costs associated with supply chain sourcing activities, merchant silicon costs, and excess/obsolete inventory write-downs, including charges for excess/obsolete component inventory held by our contract manufacturers. We expect our gross margin to fluctuate over time, depending on the factors described above.

[0001596532-22-000220:mdna:27]
Gross margin decreased from 64.2% to 61.2% for the three months ended June 30, 2022, and decreased from 64.0% to 62.1% for the six months ended June 30, 2022, compared to the same periods in 2021. The decrease in each period was primarily driven by an increased proportion of our sales to larger end customers who generally receive larger discounts and, increased material and logistics costs to mitigate supply chain constraints, partly offset by the impact of fixed overhead costs on a higher revenue base.

[0001596532-22-000220:mdna:28]
[same as prior period, unchanged from 0001596532-22-000112:mdna:29]

[0001596532-22-000220:mdna:29]
[same as prior period, unchanged from 0001596532-22-000112:mdna:30]

[0001596532-22-000220:mdna:30]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | Change in |  | 2022 |  | 2021 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 178,158 |  |  | $ | 143,293 |  |  | $ | 34,865 |  |  | 24.3 | % |  | $ | 350,164 |  |  | $ | 275,780 |  |  | $ | 74,384 |  |  | 27.0 | % |
| Sales and marketing |  | 79,372 |  |  | 70,625 |  |  | 8,747 |  |  | 12.4 |  |  | 160,111 |  |  | 141,645 |  |  | 18,466 |  |  | 13.0 |  |
| General and administrative |  | 22,882 |  |  | 20,895 |  |  | 1,987 |  |  | 9.5 |  |  | 45,995 |  |  | 36,368 |  |  | 9,627 |  |  | 26.5 |  |
| Total operating expenses |  | $ | 280,412 |  |  | $ | 234,813 |  |  | $ | 45,599 |  |  | 19.4 | % |  | $ | 556,270 |  |  | $ | 453,793 |  |  | $ | 102,477 |  |  | 22.6 | % |

[0001596532-22-000220:mdna:31]
[same as prior period, unchanged from 0001596532-22-000112:mdna:32]

[0001596532-22-000220:mdna:32]
[same as prior period, unchanged from 0001596532-22-000112:mdna:33]

[0001596532-22-000220:mdna:33]
Research and development expenses increased $34.9 million, or 24.3%, and $74.4 million, or 27.0%, in the three and six months ended June 30, 2022, respectively, compared to the same periods in 2021. The increases were primarily driven by an increase in personnel costs of $16.4 million and $25.3 million for the three and six months ended June 30, 2022, respectively, compared to the same periods in 2021 due to headcount growth. In addition, new product introduction costs increased by $10.7 million and $32.0 million for the three and six months ended June 30, 2022, respectively, compared to the same periods in 2021.

[0001596532-22-000220:mdna:34]
[same as prior period, unchanged from 0001596532-22-000112:mdna:35]

[0001596532-22-000220:mdna:35]
[same as prior period, unchanged from 0001596532-22-000112:mdna:36]

[0001596532-22-000220:mdna:36]
Sales and marketing expenses increased $8.7 million, or 12.4%, and $18.5 million, or 13.0%, for the three and six months ended June 30, 2022, respectively, compared to the same periods in 2021, which was primarily caused by increased personnel costs driven by headcount growth.

[0001596532-22-000220:mdna:37]
[same as prior period, unchanged from 0001596532-22-000112:mdna:38]

[0001596532-22-000220:mdna:38]
[same as prior period, unchanged from 0001596532-22-000112:mdna:39]

[0001596532-22-000220:mdna:39]
General and administrative expenses increased $2.0 million, or 9.5%, and $9.6 million, or 26.5%, in the three and six months ended June 30, 2022 compared to the same periods in 2021. The increase in the three and six months ended June 30, 2022 included increased legal and professional fees, primarily driven by acquisitions during the first half of 2022. The increase in the six months ended June 30, 2022 was also driven by an increase in personnel costs, including stock-based compensation.

[0001596532-22-000220:mdna:40]
Other Income (Expense), Net (in thousands, except percentages)

[0001596532-22-000220:mdna:41]
Other income (expense), net consists primarily of interest income from our cash, cash equivalents and marketable securities, gains and losses on our equity investments in privately-held companies and marketable securities, and foreign currency transaction gains and losses. We expect other income (expense), net may fluctuate in the future as a result of the re-measurement of our equity investments upon the occurrence of observable price changes and/or impairments, changes in interest rates or returns on our cash and cash equivalents and marketable securities, and foreign currency exchange rate fluctuations.

[0001596532-22-000220:mdna:42]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | Change in |  | 2022 |  | 2021 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 4,427 |  |  | $ | 1,872 |  |  | $ | 2,555 |  |  | 136.5 | % |  | $ | 6,855 |  |  | $ | 3,917 |  |  | $ | 2,938 |  |  | 75.0 | % |
| Unrealized gain (loss) on equity investments |  | (5,084) |  |  | — |  |  | (5,084) |  |  | 100.0 | % |  | 23,413 |  |  | — |  |  | 23,413 |  |  | 100.0 |  |
| Other income (expense), net |  | 124 |  |  | (153) |  |  | 277 |  |  | 181.0 |  |  | 679 |  |  | (623) |  |  | 1,302 |  |  | (209.0) |  |
| Total other income (expense), net |  | $ | (533) |  |  | $ | 1,719 |  |  | $ | (2,252) |  |  | (131.0) | % |  | $ | 30,947 |  |  | $ | 3,294 |  |  | $ | 27,653 |  |  | 839.5 | % |

[0001596532-22-000220:mdna:43]
The movements in other income (expense), net, during the three and six months ended June 30, 2022 as compared to the same periods in 2021 were primarily driven by the movements of the stock prices of our publicly-traded equity investment after its initial public offering in January 2022. In addition, our interest income has increased as we gradually replace lower-coupon-rate fixed-income marketable debt securities upon maturity with those with higher coupon rates. We expect our interest income to continue to increase for the remainder of 2022 as a result of higher interest rates.

[0001596532-22-000220:mdna:44]
[same as prior period, unchanged from 0001596532-22-000112:mdna:46]

[0001596532-22-000220:mdna:45]
[same as prior period, unchanged from 0001596532-22-000112:mdna:47]

[0001596532-22-000220:mdna:46]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | Change in |  | 2022 |  | 2021 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 362,320 |  |  | $ | 221,084 |  |  | $ | 141,236 |  |  | 63.9 | % |  | $ | 671,787 |  |  | $ | 428,951 |  |  | $ | 242,836 |  |  | 56.6 | % |
| Provision for income taxes |  | 63,221 |  |  | 24,196 |  |  | 39,025 |  |  | 161.3 | % |  | 100,429 |  |  | 51,697 |  |  | 48,732 |  |  | 94.3 | % |
| Effective tax rate |  | 17.4 | % |  | 10.9 | % |  |  |  |  |  | 14.9 | % |  | 12.1 | % |  |  |  |  |

[0001596532-22-000220:mdna:47]
The increase in the effective tax rates in the three and six months ended June 30, 2022, as compared to the same periods in 2021, was primarily due to a decrease in the proportion of tax benefits attributable to stock-based compensation versus total pre-tax income.

[0001596532-22-000220:mdna:48]
[same as prior period, unchanged from 0001596532-22-000112:mdna:50]

[0001596532-22-000220:mdna:49]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of June 30, 2022, our total balance of cash, cash equivalents and marketable securities was approximately $2.9 billion, of which approximately $381.3 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-22-000220:mdna:50]
Our cash, cash equivalents and marketable securities are held for general business purposes, including the funding of working capital. The investment portfolio of our marketable securities is primarily invested in highly-rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and stock repurchases. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-22-000220:mdna:51]
[same as prior period, unchanged from 0001596532-22-000112:mdna:53]

[0001596532-22-000220:mdna:52]
|  |  | Six Months Ended June 30, |
|  |  | 2022 |  | 2021 |
| Cash provided by operating activities |  | $ | 318,235 |  |  | $ | 518,041 |  |
| Cash provided by (used in) investing activities |  | 172,959 |  |  | (436,082) |  |
| Cash used in financing activities |  | (615,699) |  |  | (80,824) |  |
| Effect of exchange rate changes |  | (3,041) |  |  | (665) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | (127,546) |  |  | $ | 470 |  |

[0001596532-22-000220:mdna:53]
[same as prior period, unchanged from 0001596532-22-000112:mdna:55]

[0001596532-22-000220:mdna:54]
During the six months ended June 30, 2022, cash provided by operating activities was $318.2 million, primarily from net income of $571.4 million and non-cash adjustments to net income of $19.8 million driven by stock-based compensation and depreciation and amortization, and partly offset by a net increase of $272.9 million in working capital requirements. The increase in working capital requirements primarily consisted of a $202.1 million increase in inventory and a $158.1 million increase in prepaid expenses and other current assets, which reflected increased inventory purchases and inventory deposits to contract manufacturers to mitigate supply chain constraints and meet customer demand. The increase in other current assets also reflected increased deferred product cost of sales due to a corresponding increase in deferred product revenue, as well as an increase in contract assets and other miscellaneous receivables. In addition, accounts receivable increased by $64.3 million due to increased product and service billings.  These operating cash outflows were partially offset by a $91.2 million increase in product and service deferred revenue driven by customer contracts with acceptance terms and PCS contracts, a $71.2 million increase in accounts payable, and a $10.8 million increase in income tax payables.

[0001596532-22-000220:mdna:55]
During the six months ended June 30, 2021, cash provided by operating activities was $518.0 million, primarily from net income of $377.3 million and non-cash adjustments to net income of $125.2 million driven by stock-based compensation and depreciation and amortization, and a net decrease of $15.5 million in working capital requirements. The decrease in working capital requirements primarily consisted of a $95.3 million increase in product and service deferred revenue driven by customer contracts with acceptance terms and growth in PCS contracts, a $25.3 million decrease in accounts receivable due to strong collections, and a $20.0 million increase in accrued liabilities due to additional supply chain related obligations. These cash inflows were partially offset by a $63.5 million increase in inventory and a $44.4 million increase in prepaid expenses primarily due to prepaid income taxes and deferred product cost of revenue.

[0001596532-22-000220:mdna:56]
[same as prior period, unchanged from 0001596532-22-000112:mdna:58]

[0001596532-22-000220:mdna:57]
During the six months ended June 30, 2022, cash provided by investing activities was $173.0 million, consisting of proceeds from maturities of marketable securities of $829.7 million and proceeds from sale of marketable securities of $165.7 million, which was used to fund the business acquisitions and to repurchase our common stock. These amounts were partially offset by purchases of available-for-sale securities of $642.0 million, and purchases of property and equipment of $23.7 million.

[0001596532-22-000220:mdna:58]
During the six months ended June 30, 2021, cash used in investing activities was $436.1 million, consisting of purchases of available-for-sale securities of $1,241.7 million, and purchases of property and equipment of $9.6 million, partially offset by proceeds from maturities of marketable securities of $819.8 million.

[0001596532-22-000220:mdna:59]
[same as prior period, unchanged from 0001596532-22-000112:mdna:61]

[0001596532-22-000220:mdna:60]
During the six months ended June 30, 2022, cash used in financing activities was $615.7 million, consisting of payments for repurchases of our common stock from the open market of $619.9 million, and employee taxes withheld and paid of $18.8 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $23.0 million.

[0001596532-22-000220:mdna:61]
During the six months ended June 30, 2021, cash used in financing activities was $80.8 million, consisting of payments for repurchases of our common stock from the open market of $101.4 million, and employee taxes withheld and paid of $6.4 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $26.9 million.

[0001596532-22-000220:mdna:62]
[same as prior period, unchanged from 0001596532-22-000112:mdna:64]

[0001596532-22-000220:mdna:63]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”). This authorization allowed us to repurchase shares of our common stock over three years and we completed our repurchases under the Repurchase Program during the fourth quarter of 2021. In the fourth quarter of 2021, our board of directors authorized an additional $1.0 billion stock repurchase program (the "New Repurchase Program"). This authorization allows us to repurchase shares of our common stock and will be funded from working capital. The New Repurchase Program commenced in the fourth quarter of 2021, and expires on the three-year anniversary thereof. The New Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the company at any time without prior notice.  During the quarter ended June 30, 2022, we repurchased a total of $483.7 million of our common stock. As of June 30, 2022, the remaining authorized amount for repurchases under the New Repurchase Program was $307.2 million. Refer to Note 6. Stockholders' Equity and Stock-Based Compensation of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of the Quarterly Report on Form 10-Q for further discussion.

[0001596532-22-000220:mdna:64]
[same as prior period, unchanged from 0001596532-22-000112:mdna:67]

[0001596532-22-000220:mdna:65]
[same as prior period, unchanged from 0001596532-22-000112:mdna:68]

[0001596532-22-000220:mdna:66]
[same as prior period, unchanged from 0001596532-22-000112:mdna:69]

[0001596532-22-000220:mdna:67]
[same as prior period, unchanged from 0001596532-22-000112:mdna:70]

[0001596532-22-000220:mdna:68]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of June 30, 2022, we had lease payment obligations, net of immaterial sublease income, of $82.1 million, with $11.9 million payable within 12 months.

[0001596532-22-000220:mdna:69]
[same as prior period, unchanged from 0001596532-22-000112:mdna:72]

[0001596532-22-000220:mdna:70]
Purchase obligations represent an estimate of all non-cancellable open purchase orders and contractual obligations, made either directly by Arista or by our contract manufacturers on our behalf, in the ordinary course of business for which we have not received the goods or services. As of June 30, 2022, we had $4.47 billion of such purchase obligations, out of which $2.94 billion are expected to be received within 12 months, and $1.53 billion are expected to be received after one year.  These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-22-000220:mdna:71]
[same as prior period, unchanged from 0001596532-22-000112:mdna:74]

[0001596532-22-000220:mdna:72]
In connection with the Tax Cuts and Jobs Act of 2017("TCJA"), we recorded a federal income tax payable for transition tax on the mandatory deemed repatriation of foreign earnings that will be payable over an eight-year period.  As of June 30, 2022, $6.3 million of long-term transition tax payable represents the remaining federal income tax payable due between one and three years. In addition to the long-term transition tax payable, as of June 30, 2022, we have recorded long-term tax liabilities of $73.1 million related to uncertain tax positions; however, we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-22-000220:mdna:73]
In addition, beginning in 2022, the TCJA eliminates the option to deduct research and development expenditures currently and requires taxpayers to capitalize and amortize them over five or fifteen years pursuant to IRC Section 174.

[0001596532-22-000220:mdna:74]
Although there is proposed legislation that would defer the capitalization requirement to later years, we have no assurance that the provision will be repealed or otherwise modified. Consequently, we estimate the incremental cash tax impact resulting from the new regulations to be approximately $184.0 million for the year, of which the liability for the first six months of 2022 has been paid as of June 30, 2022; however, we do not anticipate any material change to our effective tax rate.

[0001596532-22-000220:mdna:75]
[same as prior period, unchanged from 0001596532-22-000112:mdna:77]

[0001596532-22-000220:mdna:76]
As of June 30, 2022, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-22-000220:mdna:77]
[same as prior period, unchanged from 0001596532-22-000112:mdna:79]

[0001596532-22-000220:mdna:78]
Our management’s discussion and analysis of financial condition and results of operations are based on our unaudited condensed consolidated financial statements, which have been prepared in accordance with GAAP.  The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting estimates in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our Annual Report on Form 10-K filed with the SEC on February 15, 2022 reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as disclosed in our Annual Report on Form 10-K.

[0001596532-22-000220:mdna:79]
[same as prior period, unchanged from 0001596532-22-000112:mdna:81]

[0001596532-22-000220:mdna:80]
Refer to the subheading titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
