# ANET 8-K — 0001596532-22-000218 filed 2022-08-01

## item codes, every 8-K on or before 2022-08-02

- 2022-08-01 0001596532-22-000218 — 2.02, 9.01
- 2022-07-25 0001596532-22-000205 — 5.02
- 2022-06-03 0001596532-22-000179 — 5.07
- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2022-08-02

- none on or before 2022-08-02

## item 2.02 — earnings release, exhibit 99.1

[0001596532-22-000218:8k_2_02:1]
EX-99.1
2
ex991q222-earningsrelease.htm
EX-99.1

[0001596532-22-000218:8k_2_02:2]
Document

[0001596532-22-000218:8k_2_02:3]
Exhibit 99.1

[0001596532-22-000218:8k_2_02:4]
Arista Networks, Inc. Reports Second Quarter 2022 Financial Results

[0001596532-22-000218:8k_2_02:5]
SANTA CLARA, Calif.- August 1, 2022 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments, today announced financial results for its second quarter ended June 30, 2022.

[0001596532-22-000218:8k_2_02:6]
“In Q2 2022, we achieved our first billion-dollar revenue quarter, despite the challenges of an uncertain supply chain environment,” said Jayshree Ullal, President and CEO of Arista Networks. “This record milestone further validates the customer value of Arista’s differentiated cloud networking platforms, now adopted by many of the largest cloud and enterprise customers around the world.”

[0001596532-22-000218:8k_2_02:7]
Second Quarter Financial Highlights

[0001596532-22-000218:8k_2_02:8]
•Revenue of $1.052 billion, an increase of 20.0% compared to the first quarter of 2022, and an increase of 48.7% from the second quarter of 2021.

[0001596532-22-000218:8k_2_02:9]
•GAAP gross margin of 61.2%, compared to GAAP gross margin of 63.1% in the first quarter of 2022 and 64.2% in the second quarter of 2021.

[0001596532-22-000218:8k_2_02:10]
•Non-GAAP gross margin of 61.9%, compared to non-GAAP gross margin of 63.9% in the first quarter of 2022 and 65.2% in the second quarter of 2021.

[0001596532-22-000218:8k_2_02:11]
•GAAP net income of $299.1 million, or $0.94 per diluted share, compared to GAAP net income of $196.9 million, or $0.62 per diluted share in the second quarter of 2021.

[0001596532-22-000218:8k_2_02:12]
•Non-GAAP net income of $342.7 million, or $1.08 per diluted share, compared to non-GAAP net income of $216.8 million, or $0.68 per diluted share in the second quarter of 2021.

[0001596532-22-000218:8k_2_02:13]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO said, “We are pleased with overall business momentum in the quarter with strong revenue growth driving significant EPS upside and demonstrating the inherent operational leverage of the business model.”

[0001596532-22-000218:8k_2_02:14]
Company Highlights

[0001596532-22-000218:8k_2_02:15]
•Arista Acquires Pluribus Networks – a leader in delivering unified cloud fabrics that provides agility, security, automation and visibility across all clouds.

[0001596532-22-000218:8k_2_02:16]
•Arista Introduces Edge as a Service with Cognitive Unified Edge Solution – Arista announces the next phase of Arista’s cognitive campus vision with the introduction of Arista CUE™ (Cognitive Unified Edge). CUE enables commercial and distributed branch customers to accelerate new services and technology innovations by consolidating multiple security and networking functions into an “edge as a service” cloud-managed solution.

[0001596532-22-000218:8k_2_02:17]
•Arista Expands EOS and CloudVision Software Platforms as a Foundation for High-Performance Media and Entertainment Networking - Arista announces the extension of its Arista EOS® (Extensible Operating System) and CloudVision® software to support high-performance switched networks for media and entertainment customers. Arista Media Control Service (MCS) makes broadcast workflows an integral function of the Arista network fabric providing customers with faster establishment of audio and video streams.

[0001596532-22-000218:8k_2_02:18]
•Arista Introduces Next Generation 7130 Series Systems for Converged Ultra Low Latency Networking - Arista announces the next generation of converged ultra low latency, highly programmable 7130 Series systems designed for demanding in-network applications. The new systems improve customer agility while consolidating multiple devices that reduce complexity, power and costs.

[0001596532-22-000218:8k_2_02:19]
Financial Outlook

[0001596532-22-000218:8k_2_02:20]
For the third quarter of 2022, we expect:

[0001596532-22-000218:8k_2_02:21]
•Revenue between $1.025 billion to $1.075 billion;

[0001596532-22-000218:8k_2_02:22]
•Non-GAAP gross margin of 60% to 62%; and

[0001596532-22-000218:8k_2_02:23]
•Non-GAAP operating margin of approximately 39%

[0001596532-22-000218:8k_2_02:24]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and certain non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below under “Non-GAAP Financial Measures”).

[0001596532-22-000218:8k_2_02:25]
Prepared Materials and Conference Call Information

[0001596532-22-000218:8k_2_02:26]
Arista's executives will discuss the second quarter 2022 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-22-000218:8k_2_02:27]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-22-000218:8k_2_02:28]
Forward-Looking Statements

[0001596532-22-000218:8k_2_02:29]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the third quarter of 2022, statements regarding Arista's business plans and its ability to execute such plans, and statements regarding the benefits of Arista's products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: interruptions or delays in shipments; the impact of supply shortages and manufacturing disruptions on our business including increased purchase commitments and extended lead times, the impact of the COVID-19 pandemic and related public safety measures on our business; the rapid evolution of the networking market; any failure to successfully pursue new products and service offerings and expand into adjacent markets; a decline in our revenue growth rate; deferral, reduction or cancellation of orders from end customers; increased component costs including as a result of global inflationary pressures and the impact of the Russian/Ukrainian conflict;  variability in our gross margins including as a result of changes in end customer mix or product mix; adverse global economic and geopolitical conditions and reduced information technology and network infrastructure spending; intense competition; expansion of our international sales and operations; investments in or acquisitions of other businesses; fluctuations in our results of operations including as a result of seasonality; our ability to attract new large end customers or sell products and services to existing end customers and dependence on large end customers; the timing of orders and their fulfillment; our ability to increase market awareness of our company and new products and services; product quality problems; our ability to anticipate technological shifts and develop products to meet those technological shifts; insufficient, excess or obsolete inventory; a decline in end customer demand for our products or services; our ability to protect, defend and maintain our intellectual property rights; vulnerabilities in our products and failure of our products to detect security breaches; and tax, tariff, import/export restrictions; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://

[0001596532-22-000218:8k_2_02:30]
www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-22-000218:8k_2_02:31]
Non-GAAP Financial Measures

[0001596532-22-000218:8k_2_02:32]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangible assets, certain non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-22-000218:8k_2_02:33]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-22-000218:8k_2_02:34]
The company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. The company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. A reconciliation of the non-GAAP financial measures guidance to the corresponding GAAP measures on a forward-looking basis is not available because stock-based compensation expense is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-22-000218:8k_2_02:35]
About Arista Networks

[0001596532-22-000218:8k_2_02:36]
Arista Networks is an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments. Arista’s award-winning platforms deliver availability, agility, automation, analytics and security through an advanced network operating stack. For more information, visit www.arista.com.

[0001596532-22-000218:8k_2_02:37]
ARISTA, EOS, CloudVision and Arista CUE  are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-22-000218:8k_2_02:38]
Investor Contacts:

[0001596532-22-000218:8k_2_02:39]
Arista Networks, Inc.

[0001596532-22-000218:8k_2_02:40]
Liz Stine, 408-547-5885

[0001596532-22-000218:8k_2_02:41]
Investor Relations

[0001596532-22-000218:8k_2_02:42]
liz@arista.com

[0001596532-22-000218:8k_2_02:43]
ARISTA NETWORKS, INC.

[0001596532-22-000218:8k_2_02:44]
Condensed Consolidated Statements of Operations

[0001596532-22-000218:8k_2_02:45]
(Unaudited, in thousands, except per share amounts)

[0001596532-22-000218:8k_2_02:46]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 885,806 |  |  | $ | 566,467 |  |  | $ | 1,610,524 |  |  | $ | 1,105,612 |  |
| Service |  | 166,085 |  |  | 140,852 |  |  | 318,433 |  |  | 269,269 |  |
| Total revenue |  | 1,051,891 |  |  | 707,319 |  |  | 1,928,957 |  |  | 1,374,881 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 375,634 |  |  | 225,779 |  |  | 669,443 |  |  | 444,212 |  |
| Service |  | 32,992 |  |  | 27,362 |  |  | 62,404 |  |  | 51,219 |  |
| Total cost of revenue |  | 408,626 |  |  | 253,141 |  |  | 731,847 |  |  | 495,431 |  |
| Gross profit |  | 643,265 |  |  | 454,178 |  |  | 1,197,110 |  |  | 879,450 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 178,158 |  |  | 143,293 |  |  | 350,164 |  |  | 275,780 |  |
| Sales and marketing |  | 79,372 |  |  | 70,625 |  |  | 160,111 |  |  | 141,645 |  |
| General and administrative |  | 22,882 |  |  | 20,895 |  |  | 45,995 |  |  | 36,368 |  |
| Total operating expenses |  | 280,412 |  |  | 234,813 |  |  | 556,270 |  |  | 453,793 |  |
| Income from operations |  | 362,853 |  |  | 219,365 |  |  | 640,840 |  |  | 425,657 |  |
| Other income (loss), net |  | (533) |  |  | 1,719 |  |  | 30,947 |  |  | 3,294 |  |
| Income before income taxes |  | 362,320 |  |  | 221,084 |  |  | 671,787 |  |  | 428,951 |  |
| Provision for income taxes |  | 63,221 |  |  | 24,196 |  |  | 100,429 |  |  | 51,697 |  |
| Net income |  | $ | 299,099 |  |  | $ | 196,888 |  |  | $ | 571,358 |  |  | $ | 377,254 |  |
| Net income per share (1): |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.98 |  |  | $ | 0.64 |  |  | $ | 1.86 |  |  | $ | 1.23 |  |
| Diluted |  | $ | 0.94 |  |  | $ | 0.62 |  |  | $ | 1.80 |  |  | $ | 1.18 |  |
| Weighted-average shares used in computing net income per share (1): |  |  |  |  |  |  |  |  |
| Basic |  | 306,754 |  |  | 305,844 |  |  | 307,399 |  |  | 305,536 |  |
| Diluted |  | 316,581 |  |  | 318,840 |  |  | 318,040 |  |  | 318,708 |  |

[0001596532-22-000218:8k_2_02:47]
_______________________

[0001596532-22-000218:8k_2_02:48]
(1) Prior periods have been adjusted to reflect the four-for-one stock split effected in the form of a stock dividend in November 2021.

[0001596532-22-000218:8k_2_02:49]
4

[0001596532-22-000218:8k_2_02:50]
ARISTA NETWORKS, INC.

[0001596532-22-000218:8k_2_02:51]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-22-000218:8k_2_02:52]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-22-000218:8k_2_02:53]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| GAAP gross profit |  | $ | 643,265 |  |  | $ | 454,178 |  |  | $ | 1,197,110 |  |  | $ | 879,450 |  |
| GAAP gross margin |  | 61.2 | % |  | 64.2 | % |  | 62.1 | % |  | 64.0 | % |
| Stock-based compensation expense |  | 2,312 |  |  | 1,796 |  |  | 3,621 |  |  | 3,196 |  |
| Intangible asset amortization |  | 6,012 |  |  | 5,465 |  |  | 11,733 |  |  | 10,929 |  |
| Non-GAAP gross profit |  | $ | 651,589 |  |  | $ | 461,439 |  |  | $ | 1,212,464 |  |  | $ | 893,575 |  |
| Non-GAAP gross margin |  | 61.9 | % |  | 65.2 | % |  | 62.9 | % |  | 65.0 | % |
| GAAP income from operations |  | $ | 362,853 |  |  | $ | 219,365 |  |  | $ | 640,840 |  |  | $ | 425,657 |  |
| Stock-based compensation expense |  | 50,224 |  |  | 44,944 |  |  | 100,503 |  |  | 82,497 |  |
| Intangible asset amortization |  | 7,708 |  |  | 7,365 |  |  | 15,019 |  |  | 14,795 |  |
| Acquisition-related costs (1) |  | 4,691 |  |  | — |  |  | 4,691 |  |  | — |  |
| Non-GAAP income from operations |  | $ | 425,476 |  |  | $ | 271,674 |  |  | $ | 761,053 |  |  | $ | 522,949 |  |
| Non-GAAP operating margin |  | 40.4 | % |  | 38.4 | % |  | 39.5 | % |  | 38.0 | % |
| GAAP net income |  | $ | 299,099 |  |  | $ | 196,888 |  |  | $ | 571,358 |  |  | $ | 377,254 |  |
| Stock-based compensation expense |  | 50,224 |  |  | 44,944 |  |  | 100,503 |  |  | 82,497 |  |
| Intangible asset amortization |  | 7,708 |  |  | 7,365 |  |  | 15,019 |  |  | 14,795 |  |
| Acquisition-related costs (1) |  | 4,691 |  |  | — |  |  | 4,691 |  |  | — |  |
| Unrealized loss (gain) on equity investments |  | 5,084 |  |  | — |  |  | (23,413) |  |  | — |  |
| Tax benefit on stock-based awards |  | (17,725) |  |  | (24,113) |  |  | (48,689) |  |  | (45,019) |  |
| Income tax effect on non-GAAP exclusions |  | (6,401) |  |  | (8,256) |  |  | (8,281) |  |  | (13,862) |  |
| Non-GAAP net income |  | $ | 342,680 |  |  | $ | 216,828 |  |  | $ | 611,188 |  |  | $ | 415,665 |  |
| GAAP diluted net income per share (2) |  | $ | 0.94 |  |  | $ | 0.62 |  |  | $ | 1.80 |  |  | $ | 1.18 |  |
| Non-GAAP adjustments to net income |  | 0.14 |  |  | 0.06 |  |  | 0.12 |  |  | 0.12 |  |
| Non-GAAP diluted net income per share |  | $ | 1.08 |  |  | $ | 0.68 |  |  | $ | 1.92 |  |  | $ | 1.30 |  |
| Weighted-average shares used in computing diluted net income per share (2) |  | 316,581 |  |  | 318,840 |  |  | 318,040 |  |  | 318,708 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 2,312 |  |  | $ | 1,796 |  |  | $ | 3,621 |  |  | $ | 3,196 |  |
| Research and development |  | 28,449 |  |  | 23,139 |  |  | 56,025 |  |  | 45,121 |  |
| Sales and marketing |  | 12,827 |  |  | 11,368 |  |  | 25,936 |  |  | 21,453 |  |
| General and administrative |  | 6,636 |  |  | 8,641 |  |  | 14,921 |  |  | 12,727 |  |
| Total |  | $ | 50,224 |  |  | $ | 44,944 |  |  | $ | 100,503 |  |  | $ | 82,497 |  |

[0001596532-22-000218:8k_2_02:54]
___________________

[0001596532-22-000218:8k_2_02:55]
(1) Represent non-recurring costs associated with business combinations, which primarily include retention bonuses, and professional and consulting fees.

[0001596532-22-000218:8k_2_02:56]
(2) Prior periods have been adjusted to reflect the four-for-one stock split effected in the form of a stock dividend in November 2021.

[0001596532-22-000218:8k_2_02:57]
ARISTA NETWORKS, INC.

[0001596532-22-000218:8k_2_02:58]
Condensed Consolidated Balance Sheets

[0001596532-22-000218:8k_2_02:59]
(Unaudited, in thousands)

[0001596532-22-000218:8k_2_02:60]
|  |  | June 30, 2022 |  | December 31, 2021 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 493,246 |  |  | $ | 620,813 |  |
| Marketable securities |  | 2,408,656 |  |  | 2,787,502 |  |
| Accounts receivable |  | 585,786 |  |  | 516,509 |  |
| Inventories |  | 852,810 |  |  | 650,117 |  |
| Prepaid expenses and other current assets |  | 388,697 |  |  | 237,735 |  |
| Total current assets |  | 4,729,195 |  |  | 4,812,676 |  |
| Property and equipment, net |  | 91,823 |  |  | 78,634 |  |
| Acquisition-related intangible assets, net |  | 140,836 |  |  | 93,555 |  |
| Goodwill |  | 273,494 |  |  | 188,397 |  |
| Investments |  | 38,263 |  |  | 20,247 |  |
| Operating lease right-of-use assets |  | 61,869 |  |  | 65,182 |  |
| Deferred tax assets |  | 442,455 |  |  | 442,295 |  |
| Other assets |  | 46,610 |  |  | 33,443 |  |
| TOTAL ASSETS |  | $ | 5,824,545 |  |  | $ | 5,734,429 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 275,093 |  |  | $ | 202,636 |  |
| Accrued liabilities |  | 210,334 |  |  | 226,643 |  |
| Deferred revenue |  | 697,762 |  |  | 593,578 |  |
| Other current liabilities |  | 94,837 |  |  | 86,972 |  |
| Total current liabilities |  | 1,278,026 |  |  | 1,109,829 |  |
| Income taxes payable |  | 79,422 |  |  | 69,916 |  |
| Operating lease liabilities, non-current |  | 51,793 |  |  | 56,527 |  |
| Deferred revenue, non-current |  | 335,728 |  |  | 335,734 |  |
| Deferred tax liabilities, non-current |  | 13,447 |  |  | 129,074 |  |
| Other long-term liabilities |  | 60,337 |  |  | 54,749 |  |
| TOTAL LIABILITIES |  | 1,818,753 |  |  | 1,755,829 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 30 |  |  | 31 |  |
| Additional paid-in capital |  | 1,638,787 |  |  | 1,530,046 |  |
| Retained earnings |  | 2,408,294 |  |  | 2,456,823 |  |
| Accumulated other comprehensive income (loss) |  | (41,319) |  |  | (8,300) |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 4,005,792 |  |  | 3,978,600 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 5,824,545 |  |  | $ | 5,734,429 |  |

[0001596532-22-000218:8k_2_02:61]
6

[0001596532-22-000218:8k_2_02:62]
ARISTA NETWORKS, INC.

[0001596532-22-000218:8k_2_02:63]
Condensed Consolidated Statements of Cash Flows

[0001596532-22-000218:8k_2_02:64]
(Unaudited, in thousands)

[0001596532-22-000218:8k_2_02:65]
|  |  | Six Months Ended June 30, |
|  |  | 2022 |  | 2021 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 571,358 |  |  | $ | 377,254 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 28,012 |  |  | 25,235 |  |
| Stock-based compensation |  | 100,503 |  |  | 82,497 |  |
| Noncash lease expense |  | 9,161 |  |  | 8,410 |  |
| Deferred income taxes |  | (105,937) |  |  | (2,998) |  |
| Unrealized gain on equity investments |  | (23,413) |  |  | — |  |
| Amortization of investment premiums |  | 11,457 |  |  | 12,121 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (64,335) |  |  | 25,326 |  |
| Inventories |  | (202,052) |  |  | (63,531) |  |
| Prepaid expenses and other current assets |  | (158,149) |  |  | (44,356) |  |
| Other assets |  | (5,543) |  |  | (3,390) |  |
| Accounts payable |  | 71,169 |  |  | 10,879 |  |
| Accrued liabilities |  | (16,210) |  |  | 20,025 |  |
| Deferred revenue |  | 91,201 |  |  | 95,263 |  |
| Income taxes payable |  | 10,792 |  |  | (9,144) |  |
| Other liabilities |  | 221 |  |  | (15,550) |  |
| Net cash provided by operating activities |  | 318,235 |  |  | 518,041 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 829,714 |  |  | 819,807 |  |
| Purchases of marketable securities |  | (641,979) |  |  | (1,241,657) |  |
| Purchases of property and equipment |  | (23,744) |  |  | (9,567) |  |
| Business acquisitions, net of cash acquired |  | (145,087) |  |  | 1,419 |  |
| Investments in privately-held companies and intangibles |  | (11,691) |  |  | (6,084) |  |
| Proceeds from sale of marketable securities |  | 165,746 |  |  | — |  |
| Net cash provided by (used in) investing activities |  | 172,959 |  |  | (436,082) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 22,991 |  |  | 26,884 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (18,802) |  |  | (6,353) |  |
| Repurchase of common stock |  | (619,888) |  |  | (101,355) |  |
| Net cash used in financing activities |  | (615,699) |  |  | (80,824) |  |
| Effect of exchange rate changes |  | (3,041) |  |  | (665) |  |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | (127,546) |  |  | 470 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 625,050 |  |  | 897,454 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 497,504 |  |  | $ | 897,924 |  |
