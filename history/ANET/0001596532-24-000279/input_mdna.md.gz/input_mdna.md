# ANET MD&A — 0001596532-24-000279


## mdna

[0001596532-24-000279:mdna:1]
[same as prior period, unchanged from 0001596532-24-000173:mdna:1]

[0001596532-24-000279:mdna:2]
[same as prior period, unchanged from 0001596532-24-000173:mdna:2]

[0001596532-24-000279:mdna:3]
Arista Networks is an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments. Arista's platforms deliver availability, agility, automation, analytics and security through an advanced network operating stack. Since Arista’s inception, our founders have reimagined cloud networks for performance, scale and programmability with a focus on differentiating in three ways: uncompromising quality, advanced open and standards-based technology and a robust quality assurance capability built on a suite of automated diagnostics. At the core of Arista’s platform is Arista’s EOS, a modernized publish-subscribe state-sharing networking operating system. Arista EOS, combined with a set of network applications and our Ethernet switching and routing platforms using best of breed merchant silicon, provides customers with a highly competitive and diversified portfolio of products with improved price/performance and time to market.

[0001596532-24-000279:mdna:4]
We generate revenue primarily from sales of our switching and routing platforms, which incorporate Arista's EOS software, and related network applications. We also generate revenue from post-contract support ("PCS"), which customers typically purchase in conjunction with our products, and renewals of PCS. We sell our products through both our direct sales force and our channel partners. Our customers span a range of industries and geographies including large cloud customers or hyperscalers, other internet providers, service providers, financial services organizations, government agencies and a cross section of enterprise customers. Over time, we have diversified the types of enterprise customers we sell to and have continued to expand our presence across a wide spectrum of industries including media and entertainment, healthcare, oil and gas, education, manufacturing, industrial, and more.

[0001596532-24-000279:mdna:5]
Historically, large purchases by a relatively limited number of customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large customers primarily due to the time it takes these customers to evaluate, test, qualify and accept our newer products, the overall complexity of these large orders and changes in demand patterns specific to these customers, including reductions in capital expenditures by these customers and the impact of cost reduction and other efficiency efforts by these customers. For example, sales to our end customers Microsoft and Meta Platforms represented 18% and 21% of our total revenue, respectively, in fiscal 2023, 16% and 26% of our total revenue, respectively, in fiscal 2022 and, 15% and less than 10% of our total revenue, respectively in fiscal 2021. This variability in customer concentration has been linked to the timing of new product deployments and spending cycles with these customers, and we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, we typically provide pricing discounts to large customers, which reduces gross margins for the period in which such sales occur.

[0001596532-24-000279:mdna:6]
We believe an increased focus on the deployment of AI enabled solutions by our large customers has accelerated the need for advanced technology offerings including some offerings from potential new market entrants.  This prioritization of AI related infrastructure investment has at times come in conjunction with the announcement of various cost reduction measures, including optimization and increased efficiency in non-AI related capital expenditures.  In some instances, such measures have had, and may continue to have, an impact on certain current or future projects and have reduced our visibility to customer demand and increased our risk of excess and obsolescence charges on existing products. In addition, we expect 2024 to be a year of new product introductions and expanded use cases, particularly in the AI Ethernet market, resulting in increased customer trials and contracts with acceptance periods, and an increase in the variability and magnitude of our product deferred revenue balances. Such measures may also result in a reduction or uncertainty in the timing of orders from these large customers and create variability in our revenue results on a quarterly and annual basis.

[0001596532-24-000279:mdna:7]
[same as prior period, unchanged from 0001596532-24-000173:mdna:7]

[0001596532-24-000279:mdna:8]
The markets for cloud networking solutions are highly competitive and characterized by rapidly changing technology, changing end-customer needs, evolving industry standards, frequent introductions of new products and services, and industry consolidation. We expect competition to intensify in the future as the market for cloud networking expands and existing competitors and new market entrants introduce new products or enhance existing products. Our future success is dependent upon our ability to continue to evolve and adapt to our rapidly changing environment. We must also continue to develop market-leading products and software features that address the changing needs of our existing and new customers, and increase sales in the cloud, AI and enterprise data center switching, and campus workspace markets. We intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new customers more effectively, increase sales to existing customers, and provide services and support. In addition, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our ability to rapidly develop new features and applications.

[0001596532-24-000279:mdna:9]
Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic with respect to the underlying merchant silicon architecture. The programmability of EOS has allowed us to expand our software applications to address the ever-increasing demands of cloud networking, including workflow automation, network visibility, analytics and network detection and response, and has further allowed us to integrate rapidly with a wide range of third-party applications for virtualization, management, automation, orchestration and network services. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We work closely with third-party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third-party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-24-000279:mdna:10]
[same as prior period, unchanged from 0001596532-24-000173:mdna:11]

[0001596532-24-000279:mdna:11]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including inflation, monetary policy shifts, recession risks, and potential supply chain and other disruptions such as the Russia-Ukraine and Israel-Hamas conflicts, the Houthi attacks on marine vessels in the Red Sea, the U.S. trade war with China and the outcome of the upcoming U.S. presidential election.

[0001596532-24-000279:mdna:12]
[same as prior period, unchanged from 0001596532-24-000173:mdna:13]

[0001596532-24-000279:mdna:13]
As the global supply chain has experienced some improvements and as customer lead times have been reduced from their peak, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to shorter demand-planning horizons. Given these shipment and order patterns, near term revenue trends may not be solely reflective of current demand levels, but as discussed above will benefit from demand/deployment plans that had been previously committed. We expect that inventory and purchase commitments will begin to stabilize in the near term, but will remain volatile as we ramp new product introductions. The magnitude of these balances, combined with a reduction in customer demand-planning horizons and shifting customer product priorities, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted in additional excess and obsolete inventory and supplier liability charges.

[0001596532-24-000279:mdna:14]
In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the Russia-Ukraine conflict, continued escalation of this conflict as well as the Israeli-Hamas conflict and Houthi movement in the Red Sea may negatively impact the global economy and our future operating results and financial condition.

[0001596532-24-000279:mdna:15]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that some of our customers must now consider changing technology roadmaps and priorities, including the need for the deployment of AI and related technologies, resulting in some uncertainty as to future investment plans and a more constrained approach to some forecasts and orders in the near term. In addition, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.

[0001596532-24-000279:mdna:16]
[same as prior period, unchanged from 0001596532-24-000173:mdna:17]

[0001596532-24-000279:mdna:17]
Three and Six Months Ended June 30, 2024 Compared to Three and Six Months Ended June 30, 2023

[0001596532-24-000279:mdna:18]
[same as prior period, unchanged from 0001596532-24-000173:mdna:19]

[0001596532-24-000279:mdna:19]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | Change in |  | 2024 |  | 2023 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,423,271 |  |  | $ | 1,261,537 |  |  | $ | 161,734 |  |  | 12.8 | % |  | $ | 2,752,116 |  |  | $ | 2,433,631 |  |  | $ | 318,485 |  |  | 13.1 | % |
| Service |  | 267,129 |  |  | 197,387 |  |  | 69,742 |  |  | 35.3 |  |  | 509,658 |  |  | 376,644 |  |  | 133,014 |  |  | 35.3 |  |
| Total revenue |  | 1,690,400 |  |  | 1,458,924 |  |  | 231,476 |  |  | 15.9 |  |  | 3,261,774 |  |  | 2,810,275 |  |  | 451,499 |  |  | 16.1 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 540,393 |  |  | 533,613 |  |  | 6,780 |  |  | 1.3 |  |  | 1,062,072 |  |  | 1,042,475 |  |  | 19,597 |  |  | 1.9 |  |
| Service |  | 52,794 |  |  | 41,182 |  |  | 11,612 |  |  | 28.2 |  |  | 101,110 |  |  | 79,164 |  |  | 21,946 |  |  | 27.7 |  |
| Total cost of revenue |  | 593,187 |  |  | 574,795 |  |  | 18,392 |  |  | 3.2 |  |  | 1,163,182 |  |  | 1,121,639 |  |  | 41,543 |  |  | 3.7 |  |
| Gross profit |  | $ | 1,097,213 |  |  | $ | 884,129 |  |  | $ | 213,084 |  |  | 24.1 | % |  | $ | 2,098,592 |  |  | $ | 1,688,636 |  |  | $ | 409,956 |  |  | 24.3 | % |
| Gross margin |  | 64.9 | % |  | 60.6 | % |  |  |  |  |  | 64.3 | % |  | 60.1 | % |  |  |  |  |

[0001596532-24-000279:mdna:20]
[same as prior period, unchanged from 0001596532-24-000173:mdna:21]

[0001596532-24-000279:mdna:21]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2024 |  | % of Total |  | 2023 |  | % of Total |  | 2024 |  | % of Total |  | 2023 |  | % of Total |
| Americas |  | $ | 1,374,257 |  |  | 81.3 | % |  | $ | 1,154,509 |  |  | 79.1 | % |  | $ | 2,629,648 |  |  | 80.6 | % |  | $ | 2,269,520 |  |  | 80.8 | % |
| Europe, Middle East and Africa |  | 178,800 |  |  | 10.6 |  |  | 167,623 |  |  | 11.5 |  |  | 320,354 |  |  | 9.8 |  |  | 295,939 |  |  | 10.5 |  |
| Asia-Pacific |  | 137,343 |  |  | 8.1 |  |  | 136,792 |  |  | 9.4 |  |  | 311,772 |  |  | 9.6 |  |  | 244,816 |  |  | 8.7 |  |
| Total revenue |  | $ | 1,690,400 |  |  | 100.0 | % |  | $ | 1,458,924 |  |  | 100.0 | % |  | $ | 3,261,774 |  |  | 100.0 | % |  | $ | 2,810,275 |  |  | 100.0 | % |

[0001596532-24-000279:mdna:22]
[same as prior period, unchanged from 0001596532-24-000173:mdna:23]

[0001596532-24-000279:mdna:23]
[same as prior period, unchanged from 0001596532-24-000173:mdna:24]

[0001596532-24-000279:mdna:24]
Product revenue increased by $161.7 million, or 12.8%, and $318.5 million, or 13.1% for the three and six months ended June 30, 2024, compared to the same periods in 2023. This increase reflects healthy demand and higher shipments of our switching and routing platforms across our customer base. In addition, service revenue increased by $69.7 million, or 35.3%, and $133.0 million, or 35.3% for the three and six months ended June 30, 2024, compared to the same periods in 2023, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenue represented 18.7% and 19.4% of total revenue for the three and six months ended June 30, 2024,

[0001596532-24-000279:mdna:25]
changing from 20.9% and 19.2% for the same periods in the prior year, which was primarily driven by changes in the geographic mix of sales to our large global customers.

[0001596532-24-000279:mdna:26]
[same as prior period, unchanged from 0001596532-24-000173:mdna:26]

[0001596532-24-000279:mdna:27]
[same as prior period, unchanged from 0001596532-24-000173:mdna:27]

[0001596532-24-000279:mdna:28]
Cost of revenue increased by $18.4 million, or 3.2%, and $41.5 million, or 3.7% for the three and six months ended June 30, 2024, compared to the same periods in 2023. These increases were primarily driven by a corresponding increase in product and service revenues, offset by a reduction in net excess/obsolete inventory and supplier liability charges.

[0001596532-24-000279:mdna:29]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including pricing pressure on our products and services due to competition, the mix of sales to large end customers who generally receive lower pricing, the mix of products sold, manufacturing-related costs, including costs associated with supply chain sourcing activities, merchant silicon costs, and excess/obsolete inventory charges, including charges for excess/obsolete component inventory held by our contract manufacturers and suppliers. We expect our gross margin to fluctuate over time, depending on the factors described above.

[0001596532-24-000279:mdna:30]
Gross margin increased from 60.6% to 64.9% for the three months ended June 30, 2024, and increased from 60.1% to 64.3% for the six months ended June 30, 2024, compared to the same periods in 2023. These changes primarily reflect an improvement in product margins driven by lower net excess/obsolete inventory and supplier liability charges.

[0001596532-24-000279:mdna:31]
[same as prior period, unchanged from 0001596532-24-000173:mdna:32]

[0001596532-24-000279:mdna:32]
[same as prior period, unchanged from 0001596532-24-000173:mdna:33]

[0001596532-24-000279:mdna:33]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | Change in |  | 2024 |  | 2023 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 267,482 |  |  | $ | 229,676 |  |  | $ | 37,806 |  |  | 16.5 | % |  | $ | 475,877 |  |  | $ | 431,084 |  |  | $ | 44,793 |  |  | 10.4 | % |
| Sales and marketing |  | 104,403 |  |  | 97,971 |  |  | 6,432 |  |  | 6.6 |  |  | 209,483 |  |  | 191,463 |  |  | 18,020 |  |  | 9.4 |  |
| General and administrative |  | 25,755 |  |  | 26,420 |  |  | (665) |  |  | (2.5) |  |  | 53,518 |  |  | 51,449 |  |  | 2,069 |  |  | 4.0 |  |
| Total operating expenses |  | $ | 397,640 |  |  | $ | 354,067 |  |  | $ | 43,573 |  |  | 12.3 | % |  | $ | 738,878 |  |  | $ | 673,996 |  |  | $ | 64,882 |  |  | 9.6 | % |

[0001596532-24-000279:mdna:34]
[same as prior period, unchanged from 0001596532-24-000173:mdna:35]

[0001596532-24-000279:mdna:35]
[same as prior period, unchanged from 0001596532-24-000173:mdna:36]

[0001596532-24-000279:mdna:36]
Research and development expenses increased by $37.8 million, or 16.5%, and $44.8 million, or 10.4% for the three and six months ended June 30, 2024, compared to the same periods in 2023. The increase was primarily driven by an increase in personnel costs due to headcount growth, and an increase in new product introduction costs.

[0001596532-24-000279:mdna:37]
[same as prior period, unchanged from 0001596532-24-000173:mdna:38]

[0001596532-24-000279:mdna:38]
[same as prior period, unchanged from 0001596532-24-000173:mdna:39]

[0001596532-24-000279:mdna:39]
Sales and marketing expenses increased by $6.4 million, or 6.6%, and $18.0 million, or 9.4% for the three and six months ended June 30, 2024, compared to the same periods in 2023, which was primarily driven by increased personnel costs due to headcount growth.

[0001596532-24-000279:mdna:40]
[same as prior period, unchanged from 0001596532-24-000173:mdna:41]

[0001596532-24-000279:mdna:41]
[same as prior period, unchanged from 0001596532-24-000173:mdna:42]

[0001596532-24-000279:mdna:42]
General and administrative expenses decreased by $0.7 million, or 2.5% for the three months ended June 30, 2024 and increased by $2.1 million, or 4.0% for the six months ended June 30, 2024, compared to the same periods in 2023.

[0001596532-24-000279:mdna:43]
[same as prior period, unchanged from 0001596532-24-000173:mdna:44]

[0001596532-24-000279:mdna:44]
Other income (expense), net consists primarily of interest income from our cash, cash equivalents and marketable securities, gains and losses on our strategic investments, and foreign currency transaction gains and losses. We expect other income (expense), net may fluctuate in the future as a result of the re-measurement of our equity investments upon the occurrence of either observable price changes or impairments, changes in interest rates or returns on our cash and cash equivalents and marketable securities, and foreign currency exchange rate fluctuations.

[0001596532-24-000279:mdna:45]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | Change in |  | 2024 |  | 2023 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 71,448 |  |  | $ | 32,206 |  |  | $ | 39,242 |  |  | 121.8 | % |  | $ | 135,271 |  |  | $ | 54,715 |  |  | $ | 80,556 |  |  | 147.2 | % |
| Gain (loss) on strategic investments |  | — |  |  | 24,743 |  |  | (24,743) |  |  | (100.0) |  |  | — |  |  | 19,172 |  |  | (19,172) |  |  | (100.0) |  |
| Other income (expense), net |  | (585) |  |  | (610) |  |  | 25 |  |  | (4.1) |  |  | (1,788) |  |  | (5,402) |  |  | 3,614 |  |  | (66.9) |  |
| Total other income (expense), net |  | $ | 70,863 |  |  | $ | 56,339 |  |  | $ | 14,524 |  |  | 25.8 | % |  | $ | 133,483 |  |  | $ | 68,485 |  |  | $ | 64,998 |  |  | 94.9 | % |

[0001596532-24-000279:mdna:46]
The improvement in other income during the three and six months ended June 30, 2024 compared to the same periods in 2023 was primarily driven by increased interest income of $39.2 million and $80.6 million due to an increase in our cash and investment balances coupled with higher investment yields, partly offset by a reduction in gains on strategic investments.

[0001596532-24-000279:mdna:47]
[same as prior period, unchanged from 0001596532-24-000173:mdna:49]

[0001596532-24-000279:mdna:48]
[same as prior period, unchanged from 0001596532-24-000173:mdna:50]

[0001596532-24-000279:mdna:49]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | Change in |  | 2024 |  | 2023 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 770,436 |  |  | $ | 586,401 |  |  | $ | 184,035 |  |  | 31.4 | % |  | $ | 1,493,197 |  |  | $ | 1,083,125 |  |  | $ | 410,072 |  |  | 37.9 | % |
| Provision for income taxes |  | 105,008 |  |  | 94,516 |  |  | 10,492 |  |  | 11.1 | % |  | 190,077 |  |  | 154,767 |  |  | 35,310 |  |  | 22.8 | % |
| Effective tax rate |  | 13.6 | % |  | 16.1 | % |  |  |  |  |  | 12.7 | % |  | 14.3 | % |  |  |  |  |

[0001596532-24-000279:mdna:50]
The decrease in the effective tax rates for the three and six months ended June 30, 2024, as compared to the same periods in 2023, was primarily due to an increase in tax benefits attributable to stock-based compensation.

[0001596532-24-000279:mdna:51]
[same as prior period, unchanged from 0001596532-24-000173:mdna:53]

[0001596532-24-000279:mdna:52]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of June 30, 2024, our total balance of cash, cash equivalents and marketable securities was approximately $6.3 billion, of which approximately $1.1 billion was held outside the U.S. in our foreign subsidiaries.

[0001596532-24-000279:mdna:53]
Our cash, cash equivalents and marketable securities are held for general business purposes, including the funding of working capital. Our marketable securities investment portfolio is primarily invested in highly-rated securities, with the primary

[0001596532-24-000279:mdna:54]
objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, stock repurchases, and capital expenditures, including the planned construction of an office and lab space. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-24-000279:mdna:55]
[same as prior period, unchanged from 0001596532-24-000173:mdna:56]

[0001596532-24-000279:mdna:56]
|  |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |
| Cash provided by operating activities |  | $ | 1,502,816 |  |  | $ | 808,573 |  |
| Cash used in investing activities |  | (773,541) |  |  | (124,653) |  |
| Cash used in financing activities |  | (236,148) |  |  | (97,635) |  |
| Effect of exchange rate changes |  | (2,692) |  |  | 429 |  |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 490,435 |  |  | $ | 586,714 |  |

[0001596532-24-000279:mdna:57]
[same as prior period, unchanged from 0001596532-24-000173:mdna:58]

[0001596532-24-000279:mdna:58]
During the six months ended June 30, 2024, cash provided by operating activities was $1.5 billion, consisting of net income of $1.3 billion along with a net decrease in working capital requirements of $259.1 million, offset partially by non-cash adjustments to net income of $59.4 million. The decrease in working capital requirements primarily consisted of an increase in deferred revenue of $612.6 million resulting from an increase in customer PCS contracts and an increase in product deferred revenue related to customer contracts with acceptance terms, a $91.4 million decrease in inventory resulting from strong product shipments, and a $74.1 million increase in income tax payables, net related to timing of payments. These cash inflows were partially offset by a $223.3 million decrease in accounts payable and accrued liabilities primarily due to timing of inventory-related receipts and payments, as well as a reduction in other accrued liabilities, an increase in accounts receivable of $202.2 million due to increased product and service billings, and a $92.6 million increase in other assets driven by increased deferred cost of sales associated with higher product revenue deferrals and an increase in contract assets and other miscellaneous receivables. The non-cash adjustments to net income were driven by a $228.5 million increase in deferred taxes primarily due to the increase in deferred revenue and the capitalization of research and development costs under Section 174 of the Internal Revenue Code ("IRC"), largely offset by stock-based compensation and depreciation and amortization.

[0001596532-24-000279:mdna:59]
During the six months ended June 30, 2023, cash provided by operating activities was $808.6 million, primarily from net income of $928.4 million and non-cash adjustments to net income of $16.9 million driven by stock-based compensation and depreciation and amortization, largely offset by an increase in deferred taxes associated with the capitalization of research and development costs under Section 174 of the IRC. These increases were partly offset by a net increase of $136.7 million in working capital requirements, which primarily consisted of a $574.6 million increase in inventory and a $137.0 million increase in inventory deposits to our contract manufacturers in response to a significant increase in business volume.  These operating cash outflows were largely offset by cash inflows from a $185.3 million increase in accounts payable and accrued liabilities due to an increase in business volume and timing of payments, and a $198.1 million increase in income tax payables related to an increase in taxable income, combined with an extension by the Internal Revenue Service ("IRS") of the due dates for estimated tax payments until October 2023. In addition, we had cash inflows resulting from a decrease in accounts receivable of $143.4 million driven by strong collections, and an increase in deferred revenue of $43.7 million primarily resulting from an increase in customer PCS contracts.

[0001596532-24-000279:mdna:60]
[same as prior period, unchanged from 0001596532-24-000173:mdna:61]

[0001596532-24-000279:mdna:61]
During the six months ended June 30, 2024, cash used in investing activities was $773.5 million, consisting of purchases of available-for-sale securities of $1.7 billion, and purchases of property and equipment of $12.6 million. These amounts were partially offset by proceeds from maturities and sales of marketable securities of $989.3 million.

[0001596532-24-000279:mdna:62]
During the six months ended June 30, 2023, cash used in investing activities was $124.7 million, consisting of purchases of available-for-sale securities of $1,392.0 million, and purchases of property and equipment of $17.2 million. These amounts were partially offset by proceeds from maturities and sales of marketable securities of $1,287.0 million.

[0001596532-24-000279:mdna:63]
[same as prior period, unchanged from 0001596532-24-000173:mdna:64]

[0001596532-24-000279:mdna:64]
During the six months ended June 30, 2024, cash used in financing activities was $236.1 million, consisting of payments for repurchases of our common stock from the open market of $234.7 million, and employee taxes withheld and paid of $36.0 million upon vesting of restricted stock units, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $34.5 million.

[0001596532-24-000279:mdna:65]
During the six months ended June 30, 2023, cash used in financing activities was $97.6 million, consisting of payments for repurchases of our common stock from the open market of $112.3 million, and employee taxes withheld and paid of $15.8 million upon vesting of restricted stock units, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $30.4 million.

[0001596532-24-000279:mdna:66]
[same as prior period, unchanged from 0001596532-24-000173:mdna:67]

[0001596532-24-000279:mdna:67]
From time to time, we repurchase shares of our common stock pursuant to repurchase programs that are funded from working capital. The Prior Repurchase Program allowed for stock repurchases of up to $1.0 billion through October 2024 and was completed in April 2024, and the New Repurchase Program allows for repurchases of an additional $1.2 billion through May 2027. The New Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the company at any time without prior notice. During the three months ended June 30, 2024, we repurchased a total of $82.0 million of our common stock under our Prior Repurchase Program and $90.0 million of repurchases have been made under our New Repurchase Program. As of June 30, 2024, the remaining authorized amount for repurchases under the New Repurchase Program was $1.1 billion. Refer to Note 6. Stockholders' Equity and Stock-based Compensation of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-24-000279:mdna:68]
[same as prior period, unchanged from 0001596532-24-000173:mdna:70]

[0001596532-24-000279:mdna:69]
[same as prior period, unchanged from 0001596532-24-000173:mdna:71]

[0001596532-24-000279:mdna:70]
[same as prior period, unchanged from 0001596532-24-000173:mdna:72]

[0001596532-24-000279:mdna:71]
[same as prior period, unchanged from 0001596532-24-000173:mdna:73]

[0001596532-24-000279:mdna:72]
Purchase obligations not recorded on our balance sheet represent an estimate of all non-cancellable open purchase orders and contractual obligations, made either directly by Arista or by our contract manufacturers on our behalf, in the ordinary course of business for which we have not received the goods or services. As of June 30, 2024, we had $2.1 billion of such purchase obligations, of which $1.7 billion are expected to be received within one year, and $0.4 billion are expected to be received after one year.  These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-24-000279:mdna:73]
[same as prior period, unchanged from 0001596532-24-000173:mdna:75]

[0001596532-24-000279:mdna:74]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of June 30, 2024, we had lease payment obligations, net of immaterial sublease income, of $61.6 million, with $23.5 million payable within one year.

[0001596532-24-000279:mdna:75]
[same as prior period, unchanged from 0001596532-24-000173:mdna:77]

[0001596532-24-000279:mdna:76]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office and lab space. The estimated capital expenditures related to this project is estimated to be approximately $50.0 million for the year ending 2024, with construction expected to commence in the second half of 2024.

[0001596532-24-000279:mdna:77]
[same as prior period, unchanged from 0001596532-24-000173:mdna:79]

[0001596532-24-000279:mdna:78]
As of June 30, 2024, we have recorded long-term tax liabilities of $107.8 million related to uncertain tax positions; however, we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-24-000279:mdna:79]
In connection with the Tax Cuts and Jobs Act of 2017 (“TCJA”), effective January 1, 2022, the TCJA eliminated the option to deduct research and development expenditures currently and requires taxpayers to capitalize and amortize them over five or fifteen years pursuant to IRC Section 174. We estimate the full year incremental cash tax impact resulting from these regulations to be approximately $210.0 million for 2024. It is anticipated that IRC Section 174 will result in cash tax outlays

[0001596532-24-000279:mdna:80]
25

[0001596532-24-000279:mdna:81]
exceeding our income tax expense over the next two years unless the current legislation is changed. There has been no material change to our effective tax rate as a result of this legislation.

[0001596532-24-000279:mdna:82]
[same as prior period, unchanged from 0001596532-24-000173:mdna:82]

[0001596532-24-000279:mdna:83]
As of June 30, 2024, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-24-000279:mdna:84]
[same as prior period, unchanged from 0001596532-24-000173:mdna:84]

[0001596532-24-000279:mdna:85]
Our management’s discussion and analysis of financial condition and results of operations are based on our unaudited condensed consolidated financial statements, which have been prepared in accordance with GAAP. The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting estimates in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our Annual Report on Form 10-K filed with the SEC on February 12, 2024 reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting estimates as disclosed in our Annual Report on Form 10-K.

[0001596532-24-000279:mdna:86]
[same as prior period, unchanged from 0001596532-24-000173:mdna:87]

[0001596532-24-000279:mdna:87]
Refer to the subheading titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
