# ANET 8-K — 0001596532-24-000277 filed 2024-07-30

## item codes, every 8-K on or before 2024-07-31

- 2024-07-30 0001596532-24-000277 — 2.02, 9.01
- 2024-06-10 0001596532-24-000233 — 5.07
- 2024-05-24 0001596532-24-000219 — 8.01
- 2024-05-07 0001596532-24-000171 — 2.02, 8.01, 9.01
- 2024-04-23 0001596532-24-000155 — 5.02, 9.01
- 2024-04-19 0001596532-24-000152 — 5.02, 8.01
- 2024-02-28 0001596532-24-000095 — 8.01
- 2024-02-12 0001596532-24-000041 — 2.02, 9.01
- 2023-12-20 0001596532-23-000349 — 5.03, 9.01
- 2023-12-01 0001596532-23-000324 — 5.02, 8.01, 9.01
- 2023-10-30 0001596532-23-000272 — 2.02, 9.01
- 2023-07-31 0001596532-23-000196 — 2.02, 5.02, 9.01
- 2023-06-16 0001596532-23-000168 — 5.07
- 2023-05-01 0001596532-23-000101 — 2.02, 9.01
- 2023-02-13 0001596532-23-000015 — 2.02, 9.01
- 2022-10-31 0001596532-22-000292 — 2.02, 9.01
- 2022-10-25 0001596532-22-000282 — 5.03, 9.01
- 2022-08-01 0001596532-22-000218 — 2.02, 9.01
- 2022-07-25 0001596532-22-000205 — 5.02
- 2022-06-03 0001596532-22-000179 — 5.07
- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2024-07-31

- none on or before 2024-07-31

## item 2.02 — earnings release, exhibit 99.1

[0001596532-24-000277:8k_2_02:1]
EX-99.1
2
ex991q224-earningsrelease.htm
EX-99.1

[0001596532-24-000277:8k_2_02:2]
Document

[0001596532-24-000277:8k_2_02:3]
Exhibit 99.1

[0001596532-24-000277:8k_2_02:4]
Arista Networks, Inc. Reports Second Quarter 2024 Financial Results

[0001596532-24-000277:8k_2_02:5]
SANTA CLARA, Calif.- July 30, 2024 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus and routing environments, today announced financial results for its second quarter ended June 30, 2024.

[0001596532-24-000277:8k_2_02:6]
Second Quarter Financial Highlights

[0001596532-24-000277:8k_2_02:7]
“On the heels of our June celebration of 10 years as a public company, I would again like to thank our customers, employees and partners for contributing to our success as we arrived at this important milestone,” said Jayshree Ullal, Chairperson and CEO of Arista Networks. “Our Q2 2024 financial results demonstrate Arista's powerful combination of growth, profitability and best of breed platforms.”

[0001596532-24-000277:8k_2_02:8]
•Revenue of $1.690 billion, an increase of 7.6% compared to the first quarter of 2024, and an increase of 15.9% from the second quarter of 2023.

[0001596532-24-000277:8k_2_02:9]
•GAAP gross margin of 64.9%, compared to GAAP gross margin of 63.7% in the first quarter of 2024 and 60.6% in the second quarter of 2023.

[0001596532-24-000277:8k_2_02:10]
•Non-GAAP gross margin of 65.4%, compared to non-GAAP gross margin of 64.2% in the first quarter of 2024 and 61.3% in the second quarter of 2023.

[0001596532-24-000277:8k_2_02:11]
•GAAP net income of $665.4 million, or $2.08 per diluted share, compared to GAAP net income of $491.9 million, or $1.55 per diluted share in the second quarter of 2023.

[0001596532-24-000277:8k_2_02:12]
•Non-GAAP net income of $672.6 million, or $2.10 per diluted share, compared to non-GAAP net income of $501.2 million, or $1.58 per diluted share in the second quarter of 2023.

[0001596532-24-000277:8k_2_02:13]
Commenting on the company's financial results, Chantelle Breithaupt, Arista’s CFO said, "We achieved an EPS increase of 33% in Q2 2024 compared to the same period last year, driven by our strong revenue and gross margin performance."

[0001596532-24-000277:8k_2_02:14]
Company Highlights

[0001596532-24-000277:8k_2_02:15]
•Arista Launches Next Generation Multi-Domain Segmentation for Zero Trust Networking - Arista announced a significant update to its Arista MSSⓇ (Multi-Domain Segmentation Service) offerings that address the challenge of creating a truly enterprise-wide zero trust network. Without the need for endpoint software agents and proprietary network protocols, Arista MSS enables effective microperimeters that restrict lateral movement in campus and data center networks and thus reduces the blast radius of security breaches such as ransomware.

[0001596532-24-000277:8k_2_02:16]
•Arista Delivers Holistic AI Solutions in Collaboration with NVIDIA - Arista announced a technology demonstration of AI Data Centers in order to align compute and network domains as a single managed AI entity, in collaboration with NVIDIA. In order to build optimal generative AI networks with lower job completion times, customers can configure, manage, and monitor AI clusters uniformly across key building blocks including networks, NICs, and servers.

[0001596532-24-000277:8k_2_02:17]
•Arista Unveils Etherlink AI Networking Platforms - Arista announced the Arista Etherlink™ AI platforms, designed to deliver optimal network performance for the most demanding AI workloads, including training and inferencing. Powered by new AI-optimized Arista EOS features, the Arista Etherlink AI portfolio supports AI cluster sizes ranging from thousands to 100,000s of XPUs with highly efficient one and 2-tier network topologies that deliver superior application performance compared to more complex multi-tier networks while offering advanced monitoring capabilities including flow-level visibility.

[0001596532-24-000277:8k_2_02:18]
Financial Outlook

[0001596532-24-000277:8k_2_02:19]
For the third quarter of 2024, we expect:

[0001596532-24-000277:8k_2_02:20]
•Revenue between $1.72 billion to $1.75 billion

[0001596532-24-000277:8k_2_02:21]
•Non-GAAP gross margin of approximately 63% - 64%; and

[0001596532-24-000277:8k_2_02:22]
•Non-GAAP operating margin of approximately 44%.

[0001596532-24-000277:8k_2_02:23]
Guidance for non-GAAP financial measures excludes certain items, including stock-based compensation expense, amortization of acquisition-related intangible assets, and potential non-recurring charges or benefits. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis without unreasonable effort because these exclusions can be uncertain or difficult to predict, including stock-based compensation expense which is impacted by the timing of employee stock transactions, the company’s future hiring and retention needs and the future fair market value of the company’s common stock. The actual amount of these exclusions will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-24-000277:8k_2_02:24]
Prepared Materials and Conference Call Information

[0001596532-24-000277:8k_2_02:25]
Arista's executives will discuss the second quarter 2024 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-24-000277:8k_2_02:26]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-24-000277:8k_2_02:27]
Forward-Looking Statements

[0001596532-24-000277:8k_2_02:28]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the third quarter of 2024 and statements regarding the benefits of Arista's products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: large purchases by a limited number of customers who represent a substantial portion of our revenue; adverse economic and geopolitical conditions and conflicts, including inflationary pressures which result in increased component costs and reduced information technology and network infrastructure spending, the Russia/Ukraine, Israel/Hamas conflicts, the Houthi attacks on marine vessels in the Red Sea and the outcome of the upcoming U.S. presidential election; changes in our customers technology roadmaps and priorities including the need for the deployment of artificial intelligence (“AI”) and related technologies; the impact of sole or limited sources of supply, supply shortages and extended lead times or supply changes; volatility in our revenue growth rate; variations in our results of operations; the rapid evolution of the networking market; failure to successfully carry out new products and service offerings and expand into adjacent markets; variability in our gross margins; intense competition and industry consolidation; expansion of our international sales and operations; investments in or acquisitions of other businesses; seasonality and industry cyclicality; fluctuations in currency exchange rates; failure to raise additional capital on favorable terms; our inability to attract new large customers or sell additional products and services to our existing customers; sales of our switches generating most of our product revenue; large customers requiring more favorable terms; inability to increase market awareness or acceptance of our new products and services; the inclusion of any acceptance provisions in our customer contracts and any delays in acceptance, or rejection, of those products; decreases in the sales prices of our products and services; long and unpredictable sales cycles; declines in maintenance renewals by customers; product quality problems; failure to anticipate technological shifts;

[0001596532-24-000277:8k_2_02:29]
managing the supply of our products and product components; our dependence on third-party manufacturers to build our products; assertions by third parties of intellectual property rights infringement; failure or inability to protect or assert our intellectual property rights; defects, errors or vulnerabilities in our products, the failure of our products to detect security breaches or incidents, the misuse of our products or the risks or product liability; enhanced U.S. tax, tariff, import/export restrictions, Chinese regulations or other trade barriers; failure to comply with government law and regulations; issues in the development and use of artificial intelligence, combined with an uncertain regulatory environment; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-24-000277:8k_2_02:30]
Non-GAAP Financial Measures

[0001596532-24-000277:8k_2_02:31]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangibles, gains/losses on strategic investments, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-24-000277:8k_2_02:32]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-24-000277:8k_2_02:33]
About Arista Networks

[0001596532-24-000277:8k_2_02:34]
Arista Networks is an industry leader in data-driven, client-to-cloud networking for large AI, data center, campus and routing environments. Its award-winning platforms deliver availability, agility, automation, analytics, and security through an advanced network operating stack. For more information, visit www.arista.com.

[0001596532-24-000277:8k_2_02:35]
ARISTA, MSS, EOS and Etherlink are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-24-000277:8k_2_02:36]
ARISTA NETWORKS, INC.

[0001596532-24-000277:8k_2_02:37]
Condensed Consolidated Income Statements

[0001596532-24-000277:8k_2_02:38]
(Unaudited, in thousands, except per share amounts)

[0001596532-24-000277:8k_2_02:39]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,423,271 |  |  | $ | 1,261,537 |  |  | $ | 2,752,116 |  |  | $ | 2,433,631 |  |
| Service |  | 267,129 |  |  | 197,387 |  |  | 509,658 |  |  | 376,644 |  |
| Total revenue |  | 1,690,400 |  |  | 1,458,924 |  |  | 3,261,774 |  |  | 2,810,275 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 540,393 |  |  | 533,613 |  |  | 1,062,072 |  |  | 1,042,475 |  |
| Service |  | 52,794 |  |  | 41,182 |  |  | 101,110 |  |  | 79,164 |  |
| Total cost of revenue |  | 593,187 |  |  | 574,795 |  |  | 1,163,182 |  |  | 1,121,639 |  |
| Gross profit |  | 1,097,213 |  |  | 884,129 |  |  | 2,098,592 |  |  | 1,688,636 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 267,482 |  |  | 229,676 |  |  | 475,877 |  |  | 431,084 |  |
| Sales and marketing |  | 104,403 |  |  | 97,971 |  |  | 209,483 |  |  | 191,463 |  |
| General and administrative |  | 25,755 |  |  | 26,420 |  |  | 53,518 |  |  | 51,449 |  |
| Total operating expenses |  | 397,640 |  |  | 354,067 |  |  | 738,878 |  |  | 673,996 |  |
| Income from operations |  | 699,573 |  |  | 530,062 |  |  | 1,359,714 |  |  | 1,014,640 |  |
| Other income (expense), net |  | 70,863 |  |  | 56,339 |  |  | 133,483 |  |  | 68,485 |  |
| Income before income taxes |  | 770,436 |  |  | 586,401 |  |  | 1,493,197 |  |  | 1,083,125 |  |
| Provision for income taxes |  | 105,008 |  |  | 94,516 |  |  | 190,077 |  |  | 154,767 |  |
| Net income |  | $ | 665,428 |  |  | $ | 491,885 |  |  | $ | 1,303,120 |  |  | $ | 928,358 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.12 |  |  | $ | 1.59 |  |  | $ | 4.16 |  |  | $ | 3.02 |  |
| Diluted |  | $ | 2.08 |  |  | $ | 1.55 |  |  | $ | 4.07 |  |  | $ | 2.94 |  |
| Weighted-average shares used in computing net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 313,711 |  |  | 308,636 |  |  | 313,372 |  |  | 307,810 |  |
| Diluted |  | 319,921 |  |  | 316,485 |  |  | 319,893 |  |  | 316,031 |  |

[0001596532-24-000277:8k_2_02:40]
4

[0001596532-24-000277:8k_2_02:41]
ARISTA NETWORKS, INC.

[0001596532-24-000277:8k_2_02:42]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-24-000277:8k_2_02:43]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-24-000277:8k_2_02:44]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| GAAP gross profit |  | $ | 1,097,213 |  |  | $ | 884,129 |  |  | $ | 2,098,592 |  |  | $ | 1,688,636 |  |
| GAAP gross margin |  | 64.9 | % |  | 60.6 | % |  | 64.3 | % |  | 60.1 | % |
| Stock-based compensation expense |  | 3,983 |  |  | 2,824 |  |  | 7,433 |  |  | 5,799 |  |
| Intangible asset amortization |  | 4,195 |  |  | 6,820 |  |  | 8,390 |  |  | 13,640 |  |
| Non-GAAP gross profit |  | $ | 1,105,391 |  |  | $ | 893,773 |  |  | $ | 2,114,415 |  |  | $ | 1,708,075 |  |
| Non-GAAP gross margin |  | 65.4 | % |  | 61.3 | % |  | 64.8 | % |  | 60.8 | % |
| GAAP income from operations |  | $ | 699,573 |  |  | $ | 530,062 |  |  | $ | 1,359,714 |  |  | $ | 1,014,640 |  |
| Stock-based compensation expense |  | 79,292 |  |  | 67,127 |  |  | 156,507 |  |  | 130,008 |  |
| Intangible asset amortization |  | 6,690 |  |  | 9,315 |  |  | 13,380 |  |  | 18,630 |  |
| Non-GAAP income from operations |  | $ | 785,555 |  |  | $ | 606,504 |  |  | $ | 1,529,601 |  |  | $ | 1,163,278 |  |
| Non-GAAP operating margin |  | 46.5 | % |  | 41.6 | % |  | 46.9 | % |  | 41.4 | % |
| GAAP net income |  | $ | 665,428 |  |  | $ | 491,885 |  |  | $ | 1,303,120 |  |  | $ | 928,358 |  |
| Stock-based compensation expense |  | 79,292 |  |  | 67,127 |  |  | 156,507 |  |  | 130,008 |  |
| Intangible asset amortization |  | 6,690 |  |  | 9,315 |  |  | 13,380 |  |  | 18,630 |  |
| Gain on strategic investments |  | — |  |  | (24,743) |  |  | — |  |  | (19,172) |  |
| Tax benefits on stock-based awards |  | (64,548) |  |  | (37,832) |  |  | (135,381) |  |  | (87,894) |  |
| Income tax effect on non-GAAP exclusions |  | (14,218) |  |  | (4,519) |  |  | (27,266) |  |  | (16,235) |  |
| Non-GAAP net income |  | $ | 672,644 |  |  | $ | 501,233 |  |  | $ | 1,310,360 |  |  | $ | 953,695 |  |
| GAAP diluted net income per share |  | $ | 2.08 |  |  | $ | 1.55 |  |  | $ | 4.07 |  |  | $ | 2.94 |  |
| Non-GAAP adjustments to net income |  | 0.02 |  |  | 0.03 |  |  | 0.03 |  |  | 0.08 |  |
| Non-GAAP diluted net income per share |  | $ | 2.10 |  |  | $ | 1.58 |  |  | $ | 4.10 |  |  | $ | 3.02 |  |
| Weighted-average shares used in computing diluted net income per share |  | 319,921 |  |  | 316,485 |  |  | 319,893 |  |  | 316,031 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 3,983 |  |  | $ | 2,824 |  |  | $ | 7,433 |  |  | $ | 5,799 |  |
| Research and development |  | 50,769 |  |  | 41,137 |  |  | 94,557 |  |  | 77,706 |  |
| Sales and marketing |  | 16,769 |  |  | 15,833 |  |  | 35,670 |  |  | 30,971 |  |
| General and administrative |  | 7,771 |  |  | 7,333 |  |  | 18,847 |  |  | 15,532 |  |
| Total |  | $ | 79,292 |  |  | $ | 67,127 |  |  | $ | 156,507 |  |  | $ | 130,008 |  |

[0001596532-24-000277:8k_2_02:45]
ARISTA NETWORKS, INC.

[0001596532-24-000277:8k_2_02:46]
Condensed Consolidated Balance Sheets

[0001596532-24-000277:8k_2_02:47]
(Unaudited, in thousands)

[0001596532-24-000277:8k_2_02:48]
|  |  | June 30, 2024 |  | December 31, 2023 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,429,031 |  |  | $ | 1,938,606 |  |
| Marketable securities |  | 3,844,923 |  |  | 3,069,362 |  |
| Accounts receivable, net |  | 1,226,795 |  |  | 1,024,569 |  |
| Inventories |  | 1,853,776 |  |  | 1,945,180 |  |
| Prepaid expenses and other current assets |  | 487,793 |  |  | 412,518 |  |
| Total current assets |  | 9,842,318 |  |  | 8,390,235 |  |
| Property and equipment, net |  | 96,282 |  |  | 101,580 |  |
| Acquisition-related intangible assets, net |  | 75,388 |  |  | 88,768 |  |
| Goodwill |  | 268,531 |  |  | 268,531 |  |
| Deferred tax assets |  | 1,177,172 |  |  | 945,792 |  |
| Other assets |  | 163,544 |  |  | 151,900 |  |
| TOTAL ASSETS |  | $ | 11,623,235 |  |  | $ | 9,946,806 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 297,832 |  |  | $ | 435,059 |  |
| Accrued liabilities |  | 320,071 |  |  | 407,302 |  |
| Deferred revenue |  | 1,329,450 |  |  | 915,204 |  |
| Other current liabilities |  | 214,526 |  |  | 152,041 |  |
| Total current liabilities |  | 2,161,879 |  |  | 1,909,606 |  |
| Income taxes payable |  | 107,833 |  |  | 95,751 |  |
| Deferred revenue, non-current |  | 789,336 |  |  | 591,000 |  |
| Other long-term liabilities |  | 133,379 |  |  | 131,390 |  |
| TOTAL LIABILITIES |  | 3,192,427 |  |  | 2,727,747 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 31 |  |  | 31 |  |
| Additional paid-in capital |  | 2,263,356 |  |  | 2,108,331 |  |
| Retained earnings |  | 6,182,479 |  |  | 5,114,025 |  |
| Accumulated other comprehensive income (loss) |  | (15,058) |  |  | (3,328) |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 8,430,808 |  |  | 7,219,059 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 11,623,235 |  |  | $ | 9,946,806 |  |

[0001596532-24-000277:8k_2_02:49]
6

[0001596532-24-000277:8k_2_02:50]
ARISTA NETWORKS, INC.

[0001596532-24-000277:8k_2_02:51]
Condensed Consolidated Statements of Cash Flows

[0001596532-24-000277:8k_2_02:52]
(Unaudited, in thousands)

[0001596532-24-000277:8k_2_02:53]
|  |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 1,303,120 |  |  | $ | 928,358 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 31,112 |  |  | 39,227 |  |
| Stock-based compensation |  | 156,507 |  |  | 130,008 |  |
| Noncash lease expense |  | 9,292 |  |  | 9,154 |  |
| Deferred income taxes |  | (228,460) |  |  | (130,287) |  |
| Gain on strategic investments |  | — |  |  | (19,172) |  |
| Amortization (accretion) of investment premiums (discounts) |  | (27,843) |  |  | (11,998) |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (202,226) |  |  | 143,370 |  |
| Inventories |  | 91,404 |  |  | (574,628) |  |
| Other assets |  | (92,577) |  |  | (120,864) |  |
| Accounts payable |  | (136,236) |  |  | 114,905 |  |
| Accrued liabilities |  | (87,063) |  |  | 70,418 |  |
| Deferred revenue |  | 612,582 |  |  | 43,658 |  |
| Income taxes, net |  | 74,067 |  |  | 198,100 |  |
| Other liabilities |  | (863) |  |  | (11,676) |  |
| Net cash provided by operating activities |  | 1,502,816 |  |  | 808,573 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 952,572 |  |  | 1,265,305 |  |
| Proceeds from sale of marketable securities |  | 36,750 |  |  | 21,725 |  |
| Purchases of marketable securities |  | (1,749,308) |  |  | (1,392,020) |  |
| Purchases of property and equipment |  | (12,555) |  |  | (17,212) |  |
| Cash paid for business combinations, net of cash acquired |  | — |  |  | 1,799 |  |
| Investments in notes and privately-held companies |  | (1,000) |  |  | (4,250) |  |
| Net cash used in investing activities |  | (773,541) |  |  | (124,653) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 34,517 |  |  | 30,410 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (35,999) |  |  | (15,766) |  |
| Repurchases of common stock |  | (234,666) |  |  | (112,279) |  |
| Net cash used in financing activities |  | (236,148) |  |  | (97,635) |  |
| Effect of exchange rate changes |  | (2,692) |  |  | 429 |  |
| NET INCREASE IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 490,435 |  |  | 586,714 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 1,939,464 |  |  | 675,978 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 2,429,899 |  |  | $ | 1,262,692 |  |

[0001596532-24-000277:8k_2_02:54]
Investor Contacts:

[0001596532-24-000277:8k_2_02:55]
Arista Networks, Inc.

[0001596532-24-000277:8k_2_02:56]
Liz Stine, 408-547-5885

[0001596532-24-000277:8k_2_02:57]
Investor Relations

[0001596532-24-000277:8k_2_02:58]
liz@arista.com
