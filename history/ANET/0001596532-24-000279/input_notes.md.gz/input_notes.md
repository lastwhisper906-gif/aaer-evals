# ANET notes — 0001596532-24-000279


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-24-000279:notes:1]
[same as prior period, unchanged from 0001596532-24-000173:notes:1]

[0001596532-24-000279:notes:2]
[same as prior period, unchanged from 0001596532-24-000173:notes:2]

[0001596532-24-000279:notes:3]
[same as prior period, unchanged from 0001596532-24-000173:notes:3]

[0001596532-24-000279:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP have been condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2024, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2023 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

[0001596532-24-000279:notes:5]
[same as prior period, unchanged from 0001596532-24-000173:notes:5]

[0001596532-24-000279:notes:6]
[same as prior period, unchanged from 0001596532-24-000173:notes:6]

[0001596532-24-000279:notes:7]
[same as prior period, unchanged from 0001596532-24-000173:notes:7]

[0001596532-24-000279:notes:8]
[same as prior period, unchanged from 0001596532-24-000173:notes:8]

[0001596532-24-000279:notes:9]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including inflation, monetary policy shifts, recession risks, and potential supply chain and other disruptions such as the Russia-Ukraine and Israel-Hamas conflicts, the Houthi attacks on marine vessels in the Red Sea, the U.S. trade war with China and the outcome of the upcoming U.S. presidential election.

[0001596532-24-000279:notes:10]
Our business is emerging from a period of unprecedented global supply chain disruptions.  Throughout this period, we made significant supply chain investments, including funding additional working capital and incremental purchase commitments in response to extended visibility to deployment plans from our customers. We have worked closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. Increased capacity has allowed us to ship products against previously committed demand/deployment plans and accelerate some deployments where needed, while trying to limit building customer inventory, and to some extent balancing customer lead times with those currently experienced from our key suppliers. As a result, some shipments against these previously committed demand/deployment plans have extended into 2024.

[0001596532-24-000279:notes:11]
As the global supply chain has experienced some improvements and as customer lead times have been reduced from their peak, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual

[0001596532-24-000279:notes:12]
return to shorter demand-planning horizons. Given these shipment and order patterns, near term revenue trends may not be solely reflective of current demand levels, but as discussed above will benefit from demand/deployment plans that had been previously committed. We expect that inventory and purchase commitments will begin to stabilize in the near term, but will remain volatile as we ramp new product introductions. The magnitude of these balances, combined with a reduction in customer demand-planning horizons and shifting customer product priorities, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted in additional excess and obsolete inventory and supplier liability charges.

[0001596532-24-000279:notes:13]
In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the Russia-Ukraine conflict, continued escalation of this conflict as well as the Israeli-Hamas conflict and Houthi movement in the Red Sea may negatively impact the global economy and our future operating results and financial condition.

[0001596532-24-000279:notes:14]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that some of our customers must now consider changing technology roadmaps and priorities, including the need for the deployment of AI and related technologies, resulting in some uncertainty as to future investment plans and a more constrained approach to some forecasts and orders in the near term. In addition, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.

[0001596532-24-000279:notes:15]
[same as prior period, unchanged from 0001596532-24-000173:notes:15]

[0001596532-24-000279:notes:16]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2024. Early adoption is permitted for annual financial statements that have not yet been issued. The amendments should be applied on a prospective basis although retrospective application is permitted. As of June 30, 2024, we have not early adopted ASU 2023-09 and we are currently evaluating the impact of future adoption on our financial disclosures.

[0001596532-24-000279:notes:17]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280)-Improvements to Reportable Segment Disclosures. The ASU requires that an entity disclose significant segment expenses impacting profit and loss that are regularly provided to the chief operating decision maker. The update is required to be applied retrospectively to prior periods presented, based on the significant segment expense categories identified and disclosed in the period of adoption. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. As of June 30, 2024, we have not early adopted ASU 2023-07 and we are currently evaluating the impact of future adoption on our financial disclosures.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-24-000279:notes:18]
[same as prior period, unchanged from 0001596532-24-000173:notes:18]

[0001596532-24-000279:notes:19]
[same as prior period, unchanged from 0001596532-24-000173:notes:19]

[0001596532-24-000279:notes:20]
|  |  | June 30, 2024 |  | December 31, 2023 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,309,104 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,309,104 |  |  | $ | 1,015,705 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,015,705 |  |
| Commercial paper |  | — |  |  | 16,413 |  |  | — |  |  | 16,413 |  |  | — |  |  | 1,999 |  |  | — |  |  | 1,999 |  |
| Corporate bonds |  | — |  |  | 2,132 |  |  | — |  |  | 2,132 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government notes |  | 390,148 |  |  | — |  |  | — |  |  | 390,148 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Agency securities |  | — |  |  | 4,953 |  |  | — |  |  | 4,953 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | 1,699,252 |  |  | 23,498 |  |  | — |  |  | 1,722,750 |  |  | 1,015,705 |  |  | 1,999 |  |  | — |  |  | 1,017,704 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | 25,680 |  |  | — |  |  | 25,680 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposits(1) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5,000 |  |  | — |  |  | 5,000 |  |
| U.S. government notes |  | 1,367,612 |  |  | — |  |  | — |  |  | 1,367,612 |  |  | 1,044,859 |  |  | — |  |  | — |  |  | 1,044,859 |  |
| Corporate bonds |  | — |  |  | 1,796,961 |  |  | — |  |  | 1,796,961 |  |  | — |  |  | 1,362,124 |  |  | — |  |  | 1,362,124 |  |
| Agency securities |  | — |  |  | 654,670 |  |  | — |  |  | 654,670 |  |  | — |  |  | 657,379 |  |  | — |  |  | 657,379 |  |
|  |  | 1,367,612 |  |  | 2,477,311 |  |  | — |  |  | 3,844,923 |  |  | 1,044,859 |  |  | 2,024,503 |  |  | — |  |  | 3,069,362 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 868 |  |  | — |  |  | — |  |  | 868 |  |  | 858 |  |  | — |  |  | — |  |  | 858 |  |
| Total Financial Assets |  | $ | 3,067,732 |  |  | $ | 2,500,809 |  |  | $ | — |  |  | $ | 5,568,541 |  |  | $ | 2,061,422 |  |  | $ | 2,026,502 |  |  | $ | — |  |  | $ | 4,087,924 |  |

[0001596532-24-000279:notes:21]
[same as prior period, unchanged from 0001596532-24-000173:notes:21]

[0001596532-24-000279:notes:22]
[same as prior period, unchanged from 0001596532-24-000173:notes:22]

[0001596532-24-000279:notes:23]
During the three and six months ended June 30, 2024, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-24-000279:notes:24]
[same as prior period, unchanged from 0001596532-24-000173:notes:25]

[0001596532-24-000279:notes:25]
|  |  | June 30, 2024 |  | December 31, 2023 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | 42,093 |  |  | $ | — |  |  | $ | — |  |  | $ | 42,093 |  |  | $ | 1,999 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,999 |  |
| U.S. government |  | 1,761,003 |  |  | 141 |  |  | (3,384) |  |  | 1,757,760 |  |  | 1,043,445 |  |  | 2,874 |  |  | (1,460) |  |  | 1,044,859 |  |
| Corporate bonds |  | 1,804,507 |  |  | 365 |  |  | (5,779) |  |  | 1,799,093 |  |  | 1,361,132 |  |  | 2,810 |  |  | (1,818) |  |  | 1,362,124 |  |
| Agency securities |  | 660,572 |  |  | 130 |  |  | (1,079) |  |  | 659,623 |  |  | 657,118 |  |  | 1,143 |  |  | (882) |  |  | 657,379 |  |
| Total |  | $ | 4,268,175 |  |  | $ | 636 |  |  | $ | (10,242) |  |  | $ | 4,258,569 |  |  | $ | 3,063,694 |  |  | $ | 6,827 |  |  | $ | (4,160) |  |  | $ | 3,066,361 |  |

[0001596532-24-000279:notes:26]
[same as prior period, unchanged from 0001596532-24-000173:notes:27]

[0001596532-24-000279:notes:27]
such securities for the three and six months ended June 30, 2024. All unrealized losses were recognized in other comprehensive income (loss). Realized gains or losses were immaterial for the three and six months ended June 30, 2024.

[0001596532-24-000279:notes:28]
The following table is an analysis of our debt securities in unrealized loss positions (in thousands):

[0001596532-24-000279:notes:29]
|  |  | June 30, 2024 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 1,445,689 |  |  | $ | (2,660) |  |  | $ | 161,063 |  |  | $ | (724) |  |  | $ | 1,606,752 |  |  | $ | (3,384) |  |
| Corporate bonds |  | 1,408,050 |  |  | (5,076) |  |  | 184,252 |  |  | (703) |  |  | 1,592,302 |  |  | (5,779) |  |
| Agency securities |  | 339,109 |  |  | (508) |  |  | 179,258 |  |  | (571) |  |  | 518,367 |  |  | (1,079) |  |
| Total |  | $ | 3,192,848 |  |  | $ | (8,244) |  |  | $ | 524,573 |  |  | $ | (1,998) |  |  | $ | 3,717,421 |  |  | $ | (10,242) |  |

[0001596532-24-000279:notes:30]
As of June 30, 2024, we had no marketable securities with contractual maturities that exceeded 24 months. The fair values of marketable securities by remaining contractual maturities, are as follows (in thousands):

[0001596532-24-000279:notes:31]
|  |  | June 30, 2024 |
|  |  | Fair Value |
| Due in 1 year or less |  | $ | 2,196,729 |  |
| Due in 1 to 2 years |  | 1,648,194 |  |
| Total debt securities |  | $ | 3,844,923 |  |

[0001596532-24-000279:notes:32]
The weighted-average remaining duration of our marketable securities is approximately 0.9 years as of June 30, 2024. As we view these marketable securities as available to support current operations, we classify marketable securities with maturities beyond 12 months as current assets under the caption "Marketable securities" on the condensed consolidated balance sheets.

[0001596532-24-000279:notes:33]
[same as prior period, unchanged from 0001596532-24-000173:notes:34]

[0001596532-24-000279:notes:34]
[same as prior period, unchanged from 0001596532-24-000173:notes:35]

[0001596532-24-000279:notes:35]
[same as prior period, unchanged from 0001596532-24-000173:notes:36]

[0001596532-24-000279:notes:36]
We did not record any realized gains or losses for our non-marketable equity securities during the three and six months ended June 30, 2024 and June 30, 2023, and we recorded nil and immaterial amounts of unrealized gains or losses for the three and six months ended June 30, 2024 and June 30, 2023, respectively.

[0001596532-24-000279:notes:37]
[same as prior period, unchanged from 0001596532-24-000173:notes:38]

[0001596532-24-000279:notes:38]
The following table summarizes the activity related to our non-marketable equity securities as of June 30, 2024 and December 31, 2023 (in thousands):

[0001596532-24-000279:notes:39]
|  |  | June 30, 2024 |  | December 31, 2023 |
| Cost of investments |  | $ | 32,656 |  |  | $ | 31,656 |  |
| Cumulative impairment and downward adjustment |  | — |  |  | — |  |
| Cumulative upward adjustment |  | 30,632 |  |  | 30,632 |  |
| Carrying amount of investments |  | $ | 63,288 |  |  | $ | 62,288 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-24-000279:notes:40]
[same as prior period, unchanged from 0001596532-24-000173:notes:41]

[0001596532-24-000279:notes:41]
[same as prior period, unchanged from 0001596532-24-000173:notes:42]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-24-000279:notes:42]
[same as prior period, unchanged from 0001596532-24-000173:notes:43]

[0001596532-24-000279:notes:43]
[same as prior period, unchanged from 0001596532-24-000173:notes:44]

[0001596532-24-000279:notes:44]
|  |  | June 30, 2024 |  | December 31, 2023 |
| Cash and cash equivalents |  | $ | 2,429,031 |  |  | $ | 1,938,606 |  |
| Restricted cash included in other assets |  | 868 |  |  | 858 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 2,429,899 |  |  | $ | 1,939,464 |  |

[0001596532-24-000279:notes:45]
[same as prior period, unchanged from 0001596532-24-000173:notes:46]

[0001596532-24-000279:notes:46]
[same as prior period, unchanged from 0001596532-24-000173:notes:47]

[0001596532-24-000279:notes:47]
|  |  | June 30, 2024 |  | December 31, 2023 |
| Accounts receivable |  | $ | 1,237,629 |  |  | $ | 1,034,480 |  |
| Product sales rebate and returns reserve |  | (10,834) |  |  | (9,911) |  |
| Accounts receivable, net |  | $ | 1,226,795 |  |  | $ | 1,024,569 |  |

[0001596532-24-000279:notes:48]
[same as prior period, unchanged from 0001596532-24-000173:notes:49]

[0001596532-24-000279:notes:49]
[same as prior period, unchanged from 0001596532-24-000173:notes:50]

[0001596532-24-000279:notes:50]
|  |  | June 30, 2024 |  | December 31, 2023 |
| Raw materials |  | $ | 771,354 |  |  | $ | 930,777 |  |
| Finished goods |  | 1,082,422 |  |  | 1,014,403 |  |
| Total inventories |  | $ | 1,853,776 |  |  | $ | 1,945,180 |  |

[0001596532-24-000279:notes:51]
[same as prior period, unchanged from 0001596532-24-000173:notes:52]

[0001596532-24-000279:notes:52]
[same as prior period, unchanged from 0001596532-24-000173:notes:53]

[0001596532-24-000279:notes:53]
|  |  | June 30, 2024 |  | December 31, 2023 |
| Land |  | $ | 45,883 |  |  | $ | 44,645 |  |
| Equipment and machinery |  | 153,755 |  |  | 144,850 |  |
| Computer hardware and software |  | 59,248 |  |  | 57,761 |  |
| Leasehold improvements |  | 34,686 |  |  | 34,584 |  |
| Furniture and fixtures |  | 3,557 |  |  | 3,576 |  |
| Construction-in-process |  | 3,391 |  |  | 4,242 |  |
| Property and equipment, gross |  | 300,520 |  |  | 289,658 |  |
| Less: accumulated depreciation |  | (204,238) |  |  | (188,078) |  |
| Property and equipment, net |  | $ | 96,282 |  |  | $ | 101,580 |  |

[0001596532-24-000279:notes:54]
Depreciation expense was $8.5 million and $7.8 million for the three months ended June 30, 2024 and 2023, respectively, and $17.1 million and $14.9 million for the six months ended June 30, 2024 and 2023, respectively.

[0001596532-24-000279:notes:55]
[same as prior period, unchanged from 0001596532-24-000173:notes:56]

[0001596532-24-000279:notes:56]
[same as prior period, unchanged from 0001596532-24-000173:notes:57]

[0001596532-24-000279:notes:57]
|  |  | June 30, 2024 |  | December 31, 2023 |
| Accrued compensation-related costs |  | $ | 103,312 |  |  | $ | 134,225 |  |
| Accrued supplier liability |  | 80,350 |  |  | 167,878 |  |
| Accrued manufacturing costs |  | 56,693 |  |  | 61,491 |  |
| Accrued product development costs |  | 36,802 |  |  | 1,041 |  |
| Other |  | 42,914 |  |  | 42,667 |  |
| Total accrued liabilities |  | $ | 320,071 |  |  | $ | 407,302 |  |

[0001596532-24-000279:notes:58]
[same as prior period, unchanged from 0001596532-24-000173:notes:59]

[0001596532-24-000279:notes:59]
[same as prior period, unchanged from 0001596532-24-000173:notes:60]

[0001596532-24-000279:notes:60]
[same as prior period, unchanged from 0001596532-24-000173:notes:61]

[0001596532-24-000279:notes:61]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Contract liabilities, beginning balance |  | $ | 139,618 |  |  | $ | 105,047 |  |  | $ | 133,239 |  |  | $ | 103,448 |  |
| Less: Revenue recognized from beginning balance |  | (12,412) |  |  | (9,941) |  |  | (29,171) |  |  | (22,105) |  |
| Less: Beginning balance reclassified to deferred revenue |  | (6,917) |  |  | (4,962) |  |  | (6,012) |  |  | (4,145) |  |
| Add: Contract liabilities recognized |  | 23,841 |  |  | 19,953 |  |  | 46,074 |  |  | 32,899 |  |
| Contract liabilities, ending balance |  | $ | 144,130 |  |  | $ | 110,097 |  |  | $ | 144,130 |  |  | $ | 110,097 |  |

[0001596532-24-000279:notes:62]
As of June 30, 2024 and December 31, 2023, contract liabilities included in "Other current liabilities" were $59.2 million for each period, with the remaining balances included in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001596532-24-000279:notes:63]
[same as prior period, unchanged from 0001596532-24-000173:notes:64]

[0001596532-24-000279:notes:64]
[same as prior period, unchanged from 0001596532-24-000173:notes:65]

[0001596532-24-000279:notes:65]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Deferred revenue, beginning balance |  | $ | 1,663,242 |  |  | $ | 1,092,274 |  |  | $ | 1,506,204 |  |  | $ | 1,041,246 |  |
| Less: Revenue recognized from beginning balance |  | (249,938) |  |  | (263,353) |  |  | (467,516) |  |  | (395,056) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 705,482 |  |  | 255,983 |  |  | 1,080,098 |  |  | 438,714 |  |
| Deferred revenue, ending balance |  | $ | 2,118,786 |  |  | $ | 1,084,904 |  |  | $ | 2,118,786 |  |  | $ | 1,084,904 |  |

[0001596532-24-000279:notes:66]
[same as prior period, unchanged from 0001596532-24-000173:notes:67]

[0001596532-24-000279:notes:67]
Other performance obligations totaling $688.1 million as of June 30, 2024 include unbilled multi-year PCS and service contract amounts of $513.0 million and $175.1 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-24-000279:notes:68]
[same as prior period, unchanged from 0001596532-24-000173:notes:69]

[0001596532-24-000279:notes:69]
Total revenue from our contract liabilities, deferred revenue and other performance obligations that is expected to be recognized in future periods was $3.0 billion as of June 30, 2024. Approximately 81% of this future revenue is expected to be recognized over the next two years and the remaining 19% is expected to be recognized during the third to the fifth year.

[0001596532-24-000279:notes:70]
[same as prior period, unchanged from 0001596532-24-000173:notes:71]

[0001596532-24-000279:notes:71]
[same as prior period, unchanged from 0001596532-24-000173:notes:72]

[0001596532-24-000279:notes:72]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Interest income |  | $ | 71,448 |  |  | $ | 32,206 |  |  | $ | 135,271 |  |  | $ | 54,715 |  |
| Gain (loss) on strategic investments |  | — |  |  | 24,743 |  |  | — |  |  | 19,172 |  |
| Other income (expense), net |  | (585) |  |  | (610) |  |  | (1,788) |  |  | (5,402) |  |
| Total |  | $ | 70,863 |  |  | $ | 56,339 |  |  | $ | 133,483 |  |  | $ | 68,485 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-24-000279:notes:73]
[same as prior period, unchanged from 0001596532-24-000173:notes:74]

[0001596532-24-000279:notes:74]
[same as prior period, unchanged from 0001596532-24-000173:notes:75]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001596532-24-000279:notes:75]
Goodwill and Acquisition-Related Intangible Assets
Acquisition-Related Intangible Assets

[0001596532-24-000279:notes:76]
Acquisition-related intangible assets, excluding those that are fully amortized, were as follows (in thousands, except years):

[0001596532-24-000279:notes:77]
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life (in years) |
|  | December 31, 2023 |  | Additions |  | June 30, 2024 |  | December 31, 2023 |  | Amortization |  | June 30, 2024 |  | December 31, 2023 |  | June 30, 2024 |  |
| Developed technology | $ | 154,930 |  |  | $ | — |  |  | $ | 154,930 |  |  | $ | (102,493) |  |  | $ | (8,390) |  |  | $ | (110,883) |  |  | $ | 52,437 |  |  | $ | 44,047 |  |  | 3.7 |
| Customer relationships | 54,620 |  |  | — |  |  | 54,620 |  |  | (21,797) |  |  | (3,851) |  |  | (25,648) |  |  | 32,823 |  |  | 28,972 |  |  | 4.3 |
| Trade name | 12,390 |  |  | — |  |  | 12,390 |  |  | (8,882) |  |  | (1,139) |  |  | (10,021) |  |  | 3,508 |  |  | 2,369 |  |  | 1.1 |
| Total | $ | 221,940 |  |  | $ | — |  |  | $ | 221,940 |  |  | $ | (133,172) |  |  | $ | (13,380) |  |  | $ | (146,552) |  |  | $ | 88,768 |  |  | $ | 75,388 |  |  | 3.8 |

[0001596532-24-000279:notes:78]
Amortization expense related to acquisition-related intangible assets was $6.7 million and $9.3 million for the three months ended June 30, 2024 and 2023, respectively, and $13.4 million and $18.6 million for the six months ended June 30, 2024 and 2023, respectively.

[0001596532-24-000279:notes:79]
As of June 30, 2024, future estimated amortization expense related to the acquisition-related intangible assets is as follows (in thousands):

[0001596532-24-000279:notes:80]
|  |  | Future Amortization Expense |
| Remainder of 2024 |  | $ | 13,379 |  |
| 2025 |  | 19,642 |  |
| 2026 |  | 17,260 |  |
| 2027 |  | 13,436 |  |
| 2028 |  | 10,037 |  |
| Thereafter |  | 1,634 |  |
| Total |  | $ | 75,388 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-24-000279:notes:81]
Commitments and Contingencies
Leases

[0001596532-24-000279:notes:82]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of June 30, 2024, we had lease payment obligations, net of immaterial sublease income, of $61.6 million, with $23.5 million payable within one year.

[0001596532-24-000279:notes:83]
Purchase Commitments

[0001596532-24-000279:notes:84]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of June 30, 2024, we had non-cancellable purchase commitments not recorded on our balance sheet of $2.1 billion, of which $1.7 billion have expected receipt dates within 12 months, and $0.4 billion have expected receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-24-000279:notes:85]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $128.0 million and $133.3 million as of June 30, 2024 and December 31, 2023, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

[0001596532-24-000279:notes:86]
Guarantees

[0001596532-24-000279:notes:87]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-24-000279:notes:88]
Legal Proceedings

[0001596532-24-000279:notes:89]
WSOU Investments, LLC

[0001596532-24-000279:notes:90]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement. On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit. On May 30, 2023, the US Patent Trial and Appeal Board (“PTAB”) ruled all challenged claims in the inter partes review unpatentable. The district court case remains stayed pending appeal and/or final resolution of the PTAB ruling.

[0001596532-24-000279:notes:91]
We intend to vigorously defend against the claims brought against us by WSOU; however, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-24-000279:notes:92]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated; however, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-24-000279:notes:93]
Other matters

[0001596532-24-000279:notes:94]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-24-000279:notes:95]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of June 30, 2024, provisions recorded for contingent losses related to other claims

[0001596532-24-000279:notes:96]
and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-24-000279:notes:97]
[same as prior period, unchanged from 0001596532-24-000173:notes:102]

[0001596532-24-000279:notes:98]
In April 2024 we completed repurchases under our previous $1.0 billion stock repurchase program (the “Prior Repurchase Program”).  In May 2024, our board of directors authorized a new $1.2 billion stock repurchase program (the “New Repurchase Program” and together with the Prior Repurchase Program, the "Repurchase Programs"), which commenced in May 2024 and expires in May 2027. This authorization allows us to repurchase shares of our common stock that will be funded from working capital. Repurchases may be made at management's discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the "Exchange Act"), or a combination of the foregoing. The New Repurchase Program does not obligate us to acquire any of our common stock, and may be suspended or discontinued by the company at any time without prior notice. During the three months ended June 30, 2024, we repurchased a total of $82.0 million of our common stock under our Prior Repurchase Program and $90.0 million of our common stock under our New Repurchase Program. As of June 30, 2024, the remaining authorized amount for stock repurchases under the New Repurchase Program was approximately $1.1 billion.

[0001596532-24-000279:notes:99]
A summary of the stock repurchase activity under the Repurchase Programs for the three and six months ended June 30, 2024 is as follows (in thousands, except per share amounts):

[0001596532-24-000279:notes:100]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | June 30, 2024 |  | June 30, 2024 |
| Aggregate purchase price |  | $ | 172,013 |  |  | $ | 234,666 |  |
| Shares repurchased |  | 614 |  |  | 842 |  |
| Average price paid per share |  | $ | 280.23 |  |  | $ | 278.77 |  |

[0001596532-24-000279:notes:101]
[same as prior period, unchanged from 0001596532-24-000173:notes:106]

[0001596532-24-000279:notes:102]
[same as prior period, unchanged from 0001596532-24-000173:notes:107]

[0001596532-24-000279:notes:103]
[same as prior period, unchanged from 0001596532-24-000173:notes:108]

[0001596532-24-000279:notes:104]
On April 16, 2024, our board of directors adopted an amended and restated Arista Networks, Inc. 2014 Equity Plan (the "Restated Plan"), effective April 17, 2024 (the "Effective Date") subject to the approval of our stockholders, which was approved at the 2024 Annual Meeting of Stockholders on June 7, 2024.

[0001596532-24-000279:notes:105]
The Restated Plan provides for the grant of equity-based awards, including stock options, restricted stock units, restricted stock, stock appreciation rights, and performance awards. The share pool available under the prior version of the Company's 2014 Equity Incentive Plan (the "Prior Plan") was extinguished, and the Restated Plan provides for a new share pool not to exceed (i) 13,200,000 shares of our Common Stock (“Shares”), plus (ii) any Shares subject to awards under the Prior Plan that, on or after the Effective Date, expired or otherwise terminated without having been exercised in full, or that were forfeited to or repurchased by us, including net settlement of Shares subject to restricted stock units, with the maximum number of Shares to be added to the Restated Plan as a result of clause (ii) equal to 10,039,657 Shares. The Restated Plan’s terms are substantially similar to the Prior Plan’s terms, including with respect to treatment of equity awards in the event of a “change in control” as defined under the Restated Plan, but with certain modifications, including the elimination of the automatic “evergreen” share reserve increase provided for under the Prior Plan. As of June 30, 2024, there remained approximately 13.1 million shares available for grant under the Restated Plan.

[0001596532-24-000279:notes:106]
[same as prior period, unchanged from 0001596532-24-000173:notes:111]

[0001596532-24-000279:notes:107]
In April 2014, our board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding on the immediately preceding December 31, but not to exceed 10 million shares, unless our board of

[0001596532-24-000279:notes:108]
directors, in its discretion, determines to make a smaller increase. Effective January 1, 2024, our board of directors authorized an increase of 3.1 million shares to the shares available for issuance under the ESPP. During the six months ended June 30, 2024, we issued 140,162 shares at a weighted-average purchase price of $114.40 per share under the ESPP. As of June 30, 2024, there remained approximately 26.4 million shares available for issuance under the ESPP.

[0001596532-24-000279:notes:109]
[same as prior period, unchanged from 0001596532-24-000173:notes:114]

[0001596532-24-000279:notes:110]
[same as prior period, unchanged from 0001596532-24-000173:notes:115]

[0001596532-24-000279:notes:111]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (in years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2023 |  | 2,457 |  |  | $ | 19.83 |  |  | 1.7 |  | $ | 529,931 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (1,152) |  |  | 16.04 |  |  |  |  |  |
| Options canceled |  | (24) |  |  | 20.07 |  |  |  |  |  |
| Balance—June 30, 2024 |  | 1,281 |  |  | $ | 23.24 |  |  | 1.6 |  | $ | 419,222 |  |
| Vested and exercisable—June 30, 2024 |  | 1,202 |  |  | $ | 22.04 |  |  | 1.5 |  | $ | 394,687 |  |

[0001596532-24-000279:notes:112]
[same as prior period, unchanged from 0001596532-24-000173:notes:117]

[0001596532-24-000279:notes:113]
[same as prior period, unchanged from 0001596532-24-000173:notes:118]

[0001596532-24-000279:notes:114]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |
| Unvested balance—December 31, 2023 |  | 7,900 |  |  | $ | 112.76 |  |
| RSUs and PRSUs granted |  | 2,151 |  |  | 271.01 |  |
| RSUs and PRSUs vested |  | (1,507) |  |  | 93.33 |  |
| RSUs and PRSUs forfeited/canceled |  | (295) |  |  | 124.10 |  |
| Unvested balance—June 30, 2024 |  | 8,249 |  |  | $ | 157.18 |  |

[0001596532-24-000279:notes:115]
[same as prior period, unchanged from 0001596532-24-000173:notes:120]

[0001596532-24-000279:notes:116]
[same as prior period, unchanged from 0001596532-24-000173:notes:121]

[0001596532-24-000279:notes:117]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cost of revenue |  | $ | 3,983 |  |  | $ | 2,824 |  |  | $ | 7,433 |  |  | $ | 5,799 |  |
| Research and development |  | 50,769 |  |  | 41,137 |  |  | 94,557 |  |  | 77,706 |  |
| Sales and marketing |  | 16,769 |  |  | 15,833 |  |  | 35,670 |  |  | 30,971 |  |
| General and administrative |  | 7,771 |  |  | 7,333 |  |  | 18,847 |  |  | 15,532 |  |
| Total stock-based compensation |  | $ | 79,292 |  |  | $ | 67,127 |  |  | $ | 156,507 |  |  | $ | 130,008 |  |

[0001596532-24-000279:notes:118]
As of June 30, 2024, there were $1,083.3 million of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 4.9 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-24-000279:notes:119]
[same as prior period, unchanged from 0001596532-24-000173:notes:124]

[0001596532-24-000279:notes:120]
[same as prior period, unchanged from 0001596532-24-000173:notes:125]

[0001596532-24-000279:notes:121]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2022 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 665,428 |  |  | $ | 491,885 |  |  | $ | 1,303,120 |  |  | $ | 928,358 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic weighted-average shares outstanding |  | 313,711 |  |  | 308,636 |  |  | 313,372 |  |  | 307,810 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Employee equity awards |  | 6,210 |  |  | 7,849 |  |  | 6,521 |  |  | 8,221 |  |
| Diluted weighted-average shares outstanding |  | 319,921 |  |  | 316,485 |  |  | 319,893 |  |  | 316,031 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.12 |  |  | $ | 1.59 |  |  | $ | 4.16 |  |  | $ | 3.02 |  |
| Diluted |  | $ | 2.08 |  |  | $ | 1.55 |  |  | $ | 4.07 |  |  | $ | 2.94 |  |

[0001596532-24-000279:notes:122]
[same as prior period, unchanged from 0001596532-24-000173:notes:127]

[0001596532-24-000279:notes:123]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2022 |
| Employee equity awards |  | 26 |  |  | 625 |  |  | 96 |  |  | 498 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-24-000279:notes:124]
[same as prior period, unchanged from 0001596532-24-000173:notes:129]

[0001596532-24-000279:notes:125]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Income before income taxes |  | $ | 770,436 |  |  | $ | 586,401 |  |  | $ | 1,493,197 |  | $ | 1,083,125 |  |
| Provision for income taxes |  | 105,008 |  |  | 94,516 |  |  | $ | 190,077 |  | 154,767 |  |
| Effective tax rate |  | 13.6 | % |  | 16.1 | % |  | 12.7 | % |  | 14.3 | % |

[0001596532-24-000279:notes:126]
The decrease in the effective tax rates in the three and six months ended June 30, 2024, as compared to the same periods in 2023, was primarily due to an increase in tax benefits attributable to stock-based compensation.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-24-000279:notes:127]
[same as prior period, unchanged from 0001596532-24-000173:notes:132]

[0001596532-24-000279:notes:128]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Americas(1) |  | $ | 1,374,257 |  |  | $ | 1,154,509 |  |  | $ | 2,629,648 |  |  | $ | 2,269,520 |  |
| Europe, Middle East and Africa |  | 178,800 |  |  | 167,623 |  |  | 320,354 |  |  | 295,939 |  |
| Asia-Pacific |  | 137,343 |  |  | 136,792 |  |  | 311,772 |  |  | 244,816 |  |
| Total revenue |  | $ | 1,690,400 |  |  | $ | 1,458,924 |  |  | $ | 3,261,774 |  |  | $ | 2,810,275 |  |

[0001596532-24-000279:notes:129]
(1) Includes $1,362.7 million and $1,121.7 million revenue generated from the U.S. for the three months ended June 30, 2024 and June 30, 2023, respectively, and $2,595.5 million and $2,216.3 million for the six months ended June 30, 2024 and June 30, 2023, respectively.

[0001596532-24-000279:notes:130]
[same as prior period, unchanged from 0001596532-24-000173:notes:135]

[0001596532-24-000279:notes:131]
|  |  | June 30, 2024 |  | December 31, 2023 |
| United States |  | $ | 77,935 |  |  | $ | 79,728 |  |
| International |  | 18,347 |  |  | 21,852 |  |
| Total |  | $ | 96,282 |  |  | $ | 101,580 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001596532-24-000279:notes:132]
On June 13, 2024, Kelly Battles, a member of our Board of Directors, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 1,706 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until September 16, 2025, or earlier if all transactions under the trading arrangement are completed.

[0001596532-24-000279:notes:133]
On June 14, 2024, Charles Giancarlo, a member of our Board of Directors, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 24,000 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until September 18, 2025, or earlier if all transactions under the trading arrangement are completed.
