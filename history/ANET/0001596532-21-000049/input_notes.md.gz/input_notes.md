# ANET notes — 0001596532-21-000049


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001596532-21-000049:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001596532-21-000049:notes:2]
Portions of the registrant’s definitive Proxy Statement relating to its 2021 Annual Meeting of Stockholders to be filed pursuant to Regulation 14A within 120 days after the registrant’s fiscal year end of December 31, 2020 are incorporated by reference into Part III of this Annual Report on Form 10-K.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-21-000049:notes:3]
Organization and Summary of Significant Accounting Policies
Organization

[0001596532-21-000049:notes:4]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale internet companies, cloud service providers and next-generation enterprises. Our cloud networking solutions consist of our EOS, a set of network applications and our Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-21-000049:notes:5]
Basis of Presentation and Principles of Consolidation

[0001596532-21-000049:notes:6]
The accompanying consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and are prepared in accordance with accounting principles generally accepted in the United States ("GAAP"). All significant intercompany accounts and transactions have been eliminated.

[0001596532-21-000049:notes:7]
Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.

[0001596532-21-000049:notes:8]
Risk and uncertainties

[0001596532-21-000049:notes:9]
The global coronavirus ("COVID-19") pandemic and resulting mitigation efforts by governments around the world to contain or slow its spread have negatively impacted the global economy, disrupted business, sales activities, global supply chains and workforce participation, including our own, and created significant volatility and disruption of financial markets.

[0001596532-21-000049:notes:10]
Our contract manufacturers and suppliers have experienced delays in the production and export of their products, which have negatively impacted our supply chain and could negatively impact our business in the future. In addition, COVID-19 related disruptions may have a negative impact on demand from our customers in future periods. However, the extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, including the duration and spread of the pandemic and related mitigation efforts, as well as restrictions on travel and transport, all of which are uncertain and cannot be predicted. Management is actively monitoring the impact of the pandemic on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

[0001596532-21-000049:notes:11]
Use of Estimates

[0001596532-21-000049:notes:12]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; valuation of goodwill and acquisition-related intangible assets, accounting for income taxes, including the recognition of deferred tax assets and liabilities related to an intra-entity transaction to sell our non-Americas economic and beneficial intellectual property, valuation allowance on deferred tax assets and reserves for uncertain tax positions; estimate of useful lives of long-lived assets including intangible assets; valuation of inventory and contract manufacturer/supplier liabilities; and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust these estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from these estimates.

[0001596532-21-000049:notes:13]
Concentrations of Business and Credit Risk

[0001596532-21-000049:notes:14]
We work closely with third-party contract manufacturers to manufacture our products. As of December 31, 2020, we had two primary contract manufacturing partners, who provided substantially all of our electronic manufacturing services. Our contract manufacturing partners deliver our products to our third-party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers. Our products rely on key components, including certain integrated circuit components and power supplies, some of which our contract manufacturing partners purchase on our behalf from a limited number of suppliers, including certain sole-source providers. We generally do not have guaranteed supply contracts with our component suppliers, and our manufacturing partners could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, or if we are unable to obtain alternative sources for these components, sales of our products could be delayed or halted entirely, or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.

[0001596532-21-000049:notes:15]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, marketable securities, restricted cash, and accounts receivable. Our cash equivalents, restricted cash and marketable securities are invested in high quality financial instruments with banks and financial institutions. Such deposits may be in excess of insured limits provided on such deposits.

[0001596532-21-000049:notes:16]
Our accounts receivable are unsecured and represent amounts due to us based on contractual obligations of our customers. We mitigate credit risk with respect to accounts receivable by performing ongoing credit evaluations of our customers to assess the probability of collection based on a number of factors, including past transaction experience with the customer, evaluation of their credit history, the credit limits extended, review of the invoicing terms of the arrangement and current economic conditions that may affect a customer’s ability to pay. In situations where a customer may be thinly capitalized and we have limited payment history with it, we will either establish a small credit limit or require it to prepay its purchases. We generally do not require our customers to provide collateral to support accounts receivable. We have recorded an allowance for doubtful accounts for accounts receivables that we have determined to be uncollectible. We mitigate credit risk with respect to accounts receivables by performing ongoing credit evaluations of the borrower to assess the probability of collecting all amounts due to us under the existing contractual terms.

[0001596532-21-000049:notes:17]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators and original equipment manufacturer (“OEM”) partners, and in conjunction with various technology partners.  Significant customers are those that represent more than 10% of our total net revenue during the period or net accounts receivable balance at each respective balance sheet date. As of December 31, 2020, we had two customers who represented 31% and 15% of total accounts receivable, respectively. As of December 31, 2019, we had one customer who represented 39% of total accounts receivable.  For the years ended December 31, 2020 and 2018, there was one customer who represented 22% and 27% of our total revenue, respectively. For the year ended December 31, 2019, there were two customers who represented 23% and 17% of our total revenue, respectively.

[0001596532-21-000049:notes:18]
Cash and Cash Equivalents

[0001596532-21-000049:notes:19]
We consider all highly liquid investments with original or remaining maturities of three months or less at the time of purchase to be cash equivalents. Cash and cash equivalents consist of cash on deposit with various financial institutions and highly liquid investments in money market funds. Interest is accrued as earned. As of December 31, 2020 and 2019, we had restricted cash of $4.2 million, respectively, and that primarily included $4.0 million pledged as collateral representing a security deposit required for a facility lease. Our restricted cash is classified as other assets in the accompanying consolidated balance sheets.

[0001596532-21-000049:notes:20]
Marketable Securities

[0001596532-21-000049:notes:21]
We classify all highly liquid investments in debt and equity securities with maturities of greater than three months at the date of purchase as marketable securities. We have classified and accounted for our marketable securities as available-for-sale. We determine the appropriate classification of these investments at the time of purchase and reevaluate such designation at each balance sheet date. We may or may not hold securities with stated maturities greater than 12 months until maturity. After consideration of our risk versus reward objectives, as well as our liquidity requirements, we may sell these securities prior to their stated maturities. As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets. We carry these securities at fair value, and report the unrealized gains and losses, net of taxes, as a component of stockholders’ equity. We determine the cost of the debt investment sold based on an average cost basis at the individual security level, and record the interest income in other income, net in the accompanying consolidated statements of operations. We determine any realized gains or losses on the sale of marketable securities using the specific identification method, and record such gains and losses in other income, net in the accompanying consolidated statements of operations.

[0001596532-21-000049:notes:22]
For our debt securities in an unrealized loss position, we determine whether a credit loss exists by considering information about the collectability of the instrument and current market conditions. We recognize an allowance for credit losses, up to the amount of the unrealized loss when appropriate, and write down the amortized cost basis of the investment if it is more likely than not we will be required to sell or we intend to sell the investment before recovery of its amortized cost basis.

[0001596532-21-000049:notes:23]
Accounts Receivable

[0001596532-21-000049:notes:24]
Accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts, sales rebates and returns reserves. We estimate our allowance for doubtful accounts based upon the collectability of the receivables in light of historical trends, reasonable and supportable information of our customers' economic conditions that may affect our customers’ ability to pay and prevailing economic conditions. This evaluation is done in order to identify issues that may impact the collectability of receivables and related estimated required allowance. Revisions to the allowance are recorded as an adjustment to bad debt expense. After appropriate collection efforts are exhausted, specific accounts receivable deemed to be uncollectible are charged against the allowance in the period they are deemed uncollectible. Recoveries of accounts receivable previously written-off are recorded as credits to bad debt expense. We primarily estimate our sales rebates and returns reserves based on historical rates applied against current period billings. Specific customer returns, rebates and allowances are considered when determining our estimates. Revisions to sales rebate and return reserves are recorded as adjustments to revenue.

[0001596532-21-000049:notes:25]
Fair Value Measurements

[0001596532-21-000049:notes:26]
Fair value is defined as the exchange price that would be received for an asset or an exit price that would be paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. These assets and liabilities include cash and cash equivalents, marketable securities, accounts receivable, accounts payable, and accrued liabilities. Cash equivalents, accounts receivable, accounts payable and accrued liabilities are stated at carrying values in our consolidated financial statements, which approximate their fair value due to the short-term nature of these instruments.

[0001596532-21-000049:notes:27]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value.  We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs.  The three-tiers of the fair value hierarchy are as follows:

[0001596532-21-000049:notes:28]
Level I—Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date;

[0001596532-21-000049:notes:29]
Level II—Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities; and

[0001596532-21-000049:notes:30]
Level III—Unobservable inputs that are supported by little or no market data for the related assets or liabilities and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.

[0001596532-21-000049:notes:31]
Foreign Currency

[0001596532-21-000049:notes:32]
The functional currency of our foreign subsidiaries is either the U.S. dollar or their local currency depending on the nature of the subsidiaries’ activities.

[0001596532-21-000049:notes:33]
Transaction re-measurement - Assets and liabilities denominated in a currency other than a subsidiary’s functional currency are re-measured into the subsidiary's functional currency using exchange rates in effect at the end of the reporting period, with gains and losses recorded in other income, net in the consolidated statements of operations. To date, foreign currency transaction gains and losses and exchange rate fluctuations have not been material to our consolidated financial statements.

[0001596532-21-000049:notes:34]
Translation - Assets and liabilities of subsidiaries denominated in foreign functional currencies are translated into U.S. dollars at the closing exchange rate on the balance sheet date and equity-related balances are translated at historical exchange rates.  Revenues, costs and expenses in foreign functional currencies are translated using average exchange rates that approximate those in effect during the period. Translation adjustments are recorded within accumulated other comprehensive income, a separate component of  total stockholders’ equity.

[0001596532-21-000049:notes:35]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-21-000049:notes:36]
Inventories primarily consist of finished goods and strategic components, primarily integrated circuits. Inventories are stated at the lower of cost (computed using the first-in, first-out method) and net realizable value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value. For the years ended December 31, 2020, 2019 and 2018, we recorded charges of $50.5 million, $41.2 million and $20.8 million, respectively, within cost of product revenue for inventory write-downs.

[0001596532-21-000049:notes:37]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts. We record a liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with our contract manufacturers or suppliers for quantities in excess of our demand forecasts or that are considered obsolete due to manufacturing and engineering change orders resulting from design changes. For the years ended December 31, 2020 and 2019, we recorded a charge of $14.9 million and $11.7 million, respectively, within cost of product revenue for such liabilities with our contract manufacturers and suppliers. For the year ended December 31, 2018, we did not incur a net loss on such supplier liabilities.

[0001596532-21-000049:notes:38]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and/or outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer/supplier liabilities.

[0001596532-21-000049:notes:39]
Property and Equipment

[0001596532-21-000049:notes:40]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is calculated using the straight-line method over the estimated useful lives of the related assets, generally three years. Our leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term.

[0001596532-21-000049:notes:41]
Leases

[0001596532-21-000049:notes:42]
We lease office space, data centers, and equipment under non-cancelable operating leases with various expiration dates through 2028. We determine if an arrangement contains a lease at inception. Operating leases are included in operating lease right-of-use (“ROU”) assets, other current liabilities, and operating lease liabilities, non-current in our consolidated balance sheets. We do not have any finance leases in any of the periods presented.

[0001596532-21-000049:notes:43]
ROU assets and lease liabilities are recognized at the commencement date based on the present value of remaining lease payments over the lease term. The interest rate implicit in our operating leases is not readily available, and therefore, an incremental borrowing rate is estimated based on a hypothetical interest rate on a collateralized basis with similar terms, payments, and economic environments. Operating lease right-of-use assets also include any prepaid lease payments and lease incentives.

[0001596532-21-000049:notes:44]
Our operating lease agreements may contain rent concession, rent escalation, and option to renew provisions.  Lease expense is recognized on a straight-line basis over the lease term commencing on the date we have the right to use the leased property. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that the option will be exercised. In addition, certain of our operating lease agreements contain tenant improvement allowances from landlords. These allowances are accounted for as lease incentives, and decrease our right-of-use asset and reduce lease expense over the lease term.

[0001596532-21-000049:notes:45]
Our lease agreements may contain lease and non-lease components, which are combined and accounted for as a single lease component. We also elect to apply the short-term lease measurement and recognition exemption in which ROU assets and lease liabilities are not recognized for leases with terms of 12 months or less.

[0001596532-21-000049:notes:46]
Business Combinations

[0001596532-21-000049:notes:47]
We use the acquisition method to account for our business combinations in accordance with Accounting Standards Codification ("ASC") 805 - Business Combinations. We allocate the total fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the consideration transferred over the fair values of the assets acquired and liabilities assumed is recorded as goodwill. The results of operations of the acquired businesses are included in our consolidated financial statements from the date of acquisition. Acquisition-related transaction and restructuring costs are expensed as incurred.

[0001596532-21-000049:notes:48]
During the measurement period, which is not to exceed one year from the acquisition date, we may record adjustments to the acquired assets and liabilities assumed, with a corresponding offset to goodwill or the preliminary purchase price, to reflect new information obtained about facts and circumstances that existed as of the acquisition date. Upon the conclusion of the measurement period, any subsequent adjustments are recorded to earnings.

[0001596532-21-000049:notes:49]
Goodwill and Acquired Intangible Assets

[0001596532-21-000049:notes:50]
Goodwill represents the excess of the purchase price over the fair value of net assets acquired in a business combination. The Company has one reporting unit and tests goodwill for impairment at least annually in the fourth quarter or more frequently if indicators of potential impairment exist. We first perform a qualitative assessment to determine whether it is more likely than not that the fair value of our reporting unit is less than its carrying amount. If the reporting unit does not pass the qualitative assessment, a quantitative test is performed by comparing the fair value of our reporting unit with its carrying amount.  We would recognize an impairment loss for the amount by which the carrying amount exceeds the fair value. There were no impairment charges in any of the periods presented in the consolidated financial statements. See Note 6 Goodwill and Acquisition-Related Intangible Assets for additional information.

[0001596532-21-000049:notes:51]
Acquired intangible assets are carried at cost less accumulated amortization. All acquired intangible assets have been determined to have definite lives and are amortized on a straight-line basis over their estimated useful lives, ranging from one to eight years. Acquired intangible assets are reviewed for impairment under the long-lived asset model described below. There were no impairment charges in any of the periods presented in

[0001596532-21-000049:notes:52]
the consolidated financial statements. See Note 6 Goodwill and Acquisition-Related Intangible Assets for additional information.

[0001596532-21-000049:notes:53]
Investments in Privately-Held Companies

[0001596532-21-000049:notes:54]
Our equity investments in privately-held companies without readily determinable fair values are measured using the measurement alternative, defined by ASC 321 - Investments-Equity Securities as cost, less impairments, and remeasured based on observable price changes from orderly transactions of identical or similar securities of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded within other income, net in our consolidated statements of operations. This election is reassessed each reporting period to determine whether investments in privately-held companies have a readily determinable fair value, in which case they would no longer be eligible for this election. The Company did not hold investments in privately-held companies whose fair value was readily determinable as of December 31, 2020 and 2019.

[0001596532-21-000049:notes:55]
Impairment of Long-Lived Assets and Investments in Privately-Held Companies

[0001596532-21-000049:notes:56]
The carrying amounts of our long-lived assets, including property and equipment, intangible assets, ROU assets and investments in privately-held companies, are periodically reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. Recoverability of these assets is measured by comparison of the carrying amount of each asset to the future undiscounted cash flows the asset is expected to generate over its remaining life. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. We recognized impairment losses on certain private company investments during 2018.  Refer to Note 5 Investments for additional information. No impairment of any other long-lived assets was identified for any of the periods presented in the consolidated financial statements.

[0001596532-21-000049:notes:57]
Loss Contingencies

[0001596532-21-000049:notes:58]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgments and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We will record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements, and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.

[0001596532-21-000049:notes:59]
Revenue Recognition

[0001596532-21-000049:notes:60]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with post-contract customer support (“PCS”). We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

[0001596532-21-000049:notes:61]
•Identification of the contract, or contracts, with a customer

[0001596532-21-000049:notes:62]
•Identification of the performance obligations in the contract

[0001596532-21-000049:notes:63]
•Determination of the transaction price

[0001596532-21-000049:notes:64]
•Allocation of the transaction price to the performance obligations in the contract

[0001596532-21-000049:notes:65]
•Recognition of revenue when (or as) we satisfy the performance obligation

[0001596532-21-000049:notes:66]
Post-Contract Customer Support

[0001596532-21-000049:notes:67]
PCS, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernible pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and address customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-21-000049:notes:68]
Contracts with Multiple Performance Obligations

[0001596532-21-000049:notes:69]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts that contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

[0001596532-21-000049:notes:70]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to, the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

[0001596532-21-000049:notes:71]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

[0001596532-21-000049:notes:72]
Most of our contracts with customers have payment terms of 30 days with some large high-volume customers having terms of up to 60 days. We have determined our contracts generally do not include a significant financing component because the Company and the customer have specific business reasons other than financing for entering into such contracts. Specifically, both we and our customers seek to ensure the customer has a simplified way of purchasing Arista products and services.

[0001596532-21-000049:notes:73]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

[0001596532-21-000049:notes:74]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical return rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-21-000049:notes:75]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

[0001596532-21-000049:notes:76]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

[0001596532-21-000049:notes:77]
Contract Balances

[0001596532-21-000049:notes:78]
A contract asset is recognized when we have a contractual right to consideration for both completed and partially completed performance obligations that have not yet been invoiced.  Contract assets are included in other current assets in the accompanying consolidated balance sheets.

[0001596532-21-000049:notes:79]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a contract that is cancellable. Contract liabilities are included in other current liabilities and other long-term liabilities in the accompanying consolidated balance sheets.

[0001596532-21-000049:notes:80]
Assets Recognized from Costs to Obtain a Contract with a Customer

[0001596532-21-000049:notes:81]
We recognize an asset for the incremental costs of obtaining a contract with a customer if we expect the benefit of those costs to be longer than one year. We have determined that certain sales commissions earned by our sales force meet the requirements for capitalization. These costs are deferred and then amortized over a period of benefit that we have determined to be five years. Total capitalized costs to obtain a contract are included in other current and long-term assets on our consolidated balance sheets. As of December 31, 2020 and 2019, total capitalized costs to obtain contracts were $10.1 million and $8.9 million, respectively.

[0001596532-21-000049:notes:82]
Research and Development Expenses

[0001596532-21-000049:notes:83]
Costs related to the research, design and development of our products are charged to research and development expenses as incurred. Software development costs are capitalized beginning when a product’s technological feasibility has been established and ending when the product is available for general release to customers. Generally, our products are released soon after technological feasibility has been established. As a result, costs incurred subsequent to achieving technological feasibility have not been significant and accordingly, all software development costs have been expensed as incurred.

[0001596532-21-000049:notes:84]
Warranty

[0001596532-21-000049:notes:85]
We offer a one-year warranty on all of our hardware products and a 90-day warranty against defects in the software embedded in the products. We use judgment and estimates when determining warranty costs based on historical costs to replace product returns within the warranty period at the time we recognize revenue. We accrue for potential warranty claims at the time of shipment as a component of cost of revenues based on historical experience and other relevant information. We reserve for specifically identified products if and when we determine we have a systemic product failure. Although we engage in extensive product quality programs, if actual product failure rates or use of materials differ from estimates, additional warranty costs may be incurred, which could reduce our gross margin. The accrued warranty liability is recorded in accrued liabilities in the accompanying consolidated balance sheets.

[0001596532-21-000049:notes:86]
Segment Reporting

[0001596532-21-000049:notes:87]
We develop, market and sell cloud networking solutions, which primarily consist of our switching and routing platforms and related network applications, and there are no segment managers who are held accountable for operations or operating results below the Company level. Our chief operating decision maker is our Chief Executive Officer, who reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.  Accordingly, we have determined that we operate as one reportable segment.

[0001596532-21-000049:notes:88]
Stock-Based Compensation

[0001596532-21-000049:notes:89]
Stock-based compensation cost for equity awards is measured at the grant-date fair value using appropriate valuation techniques and recognized as expense over the requisite service or performance period.  We account for forfeitures when they occur.

[0001596532-21-000049:notes:90]
Stock-based compensation cost for stock options and restricted stock units ("RSUs") are recognized on a straight-line basis over the requisite service period, which is generally two to five years. The Company has

[0001596532-21-000049:notes:91]
granted RSUs that vest upon the satisfaction of both service-based and performance-based conditions. The service-based condition for these awards is generally satisfied over four years. The performance-based conditions are satisfied upon achieving specified performance targets, such as financial or operating metrics. We record stock-based compensation expense for performance-based equity awards on an accelerated attribution method over the requisite service period, which is generally four years, and only if performance-based conditions are considered probable to be satisfied.

[0001596532-21-000049:notes:92]
See Note 8. Stockholders' Equity and Stock-Based Compensation for a detailed discussion of the Company’s stock plans, assumptions to the valuation techniques, and stock-based compensation expense.

[0001596532-21-000049:notes:93]
Income Taxes

[0001596532-21-000049:notes:94]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-21-000049:notes:95]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-21-000049:notes:96]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-21-000049:notes:97]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.

[0001596532-21-000049:notes:98]
The U.S. tax rules require U.S. tax on foreign earnings, known as global intangible low taxed income (“GILTI”). Under U.S. GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”).  We selected the deferred method of accounting and recorded the associated basis differences anticipated to influence prospective GILTI calculations.

[0001596532-21-000049:notes:99]
Net Income per Share Attributable to Common Stockholders

[0001596532-21-000049:notes:100]
Basic and diluted net income per share attributable to common stockholders are calculated in conformity with the two-class method required for participating securities. Our shares of common stock subject to repurchase are considered participating securities. Under the two-class method, net income attributable to common stockholders is calculated as net income less earnings attributable to participating securities. In computing diluted net income attributable to common stockholders, undistributed earnings are re-allocated to reflect the potential impact of dilutive securities. Basic net income per common share is computed by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding during the period. Diluted net income per share attributable to common stockholders is computed

[0001596532-21-000049:notes:101]
by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding, including potentially dilutive common shares assuming the dilutive effect of outstanding stock options, restricted stock units, and employee stock purchase plan using the treasury stock method. Potentially dilutive shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share.

[0001596532-21-000049:notes:102]
Recently Adopted Accounting Pronouncements

[0001596532-21-000049:notes:103]
Credit Losses of Financial Instruments

[0001596532-21-000049:notes:104]
In June 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") 2016-13 (Topic 326), Financial Instruments-Credit Losses: Measurement of Credit Losses on Financial Instruments, to replace the incurred loss impairment methodology with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The proposed standard requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. For trade receivables, we are required to estimate lifetime expected credit losses. For available-for-sale debt securities, we are required to recognize an allowance for credit losses rather than a reduction to the carrying value of the asset. We adopted the new standard on January 1, 2020 under the modified retrospective approach with no material impact on our consolidated financial statements upon adoption. In addition, we continue to monitor the financial implications of the COVID-19 pandemic on expected credit losses.

[0001596532-21-000049:notes:105]
Simplifying the Test for Goodwill Impairment

[0001596532-21-000049:notes:106]
In January 2017, the FASB issued ASU 2017-04 (Topic 350), Simplifying the test for goodwill impairment, to eliminate Step 2 of the goodwill impairment test. Entities are required to record an impairment charge based on the excess of a reporting unit’s carrying amount over its fair value. We adopted this standard prospectively on January 1, 2020 with no impact to our consolidated financial statements.

[0001596532-21-000049:notes:107]
Changes to the Disclosure Requirements for Fair Value Measurement

[0001596532-21-000049:notes:108]
In August 2018, the FASB issued ASU 2018-13 (Topic 820), Fair Value Measurement: Disclosure Framework - Changes to the Disclosure Requirements for Fair Value Measurement, which eliminates, adds, and modifies certain disclosure requirements for fair value measurements. We adopted this standard on January 1, 2020 with no material impact on our consolidated financial statements. See Note 5 Investments for additional information on our Level 3 investments.

[0001596532-21-000049:notes:109]
Recent Accounting Pronouncements Not Yet Effective

[0001596532-21-000049:notes:110]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for incomes taxes by removing certain exceptions to the general principles in Topic 740 and amending existing guidance to improve consistent application. This new standard is effective for our interim and annual periods beginning January 1, 2021 with earlier adoption permitted. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. We are currently evaluating the adoption impacts on our consolidated financial statements.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-21-000049:notes:111]
Business Combinations
On February 5, 2020, the Company completed its acquisition of Big Switch Networks, Inc. (“Big Switch”), a network monitoring and software-defined networking pioneer headquartered in Santa Clara, California. With the acquisition of Big Switch, we expect to expand our data center networking solutions and further strengthen our network monitoring and observability suite delivered through Arista’s software platform CloudVision and DANZ (DataANalyZer) capabilities.

[0001596532-21-000049:notes:112]
We paid an aggregate of $73.3 million in cash for the acquisition of Big Switch, of which $5.3 million was severance and other costs accounted for as a post-combination expense and excluded from the purchase

[0001596532-21-000049:notes:113]
consideration. We also incurred certain acquisition-related expenses and restructuring costs of $6.6 million, which primarily consisted of retention bonuses to continuing employees, professional and consulting fees, and facilities restructuring costs.

[0001596532-21-000049:notes:114]
On October 7, 2020, the Company completed its acquisition of Awake Security, Inc. (“Awake Security”), a network detection and response (“NDR”) platform provider headquartered in Santa Clara, California. With the acquisition of Awake Security, we added an NDR platform to our product portfolio that combines artificial intelligence (AI) with human expertise to autonomously hunt for and respond to insider and external threats.

[0001596532-21-000049:notes:115]
The Company acquired all outstanding shares of Awake Security for a total purchase consideration of $180.5 million with cash. The acquisition-related costs were immaterial.

[0001596532-21-000049:notes:116]
Certain unvested stock options held by Awake Security employees were assumed by the Company in connection with the acquisition. The portion of the fair value of the assumed stock options associated with pre-acquisition service of Awake employees was immaterial. The fair value of $21.3 million of the unvested replacement options was excluded from the purchase price. These awards, which are subject to the recipients’ continued service with the Company, will be recognized ratably as stock-based compensation expense over the requisite service period.

[0001596532-21-000049:notes:117]
Both acquisitions were accounted for as a business combination with the aggregate purchase price allocated to the assets acquired and liabilities assumed based on their estimated fair values as of the acquisition date. The Company prepared an initial assessment of the fair value of the assets acquired and liabilities assumed as of the acquisition date using preliminary information. Accordingly, the preliminary values reflected in the table below are subject to potential measurement period adjustments.  The fair value is as follows (in thousands):

[0001596532-21-000049:notes:118]
|  |  | Preliminary Purchase Price Allocation |
| Cash and cash equivalents |  | $ | 21,051 |  |
| Other tangible assets |  | 19,580 |  |
| Liabilities |  | (28,598) |  |
| Intangible assets |  | 101,640 |  |
| Goodwill |  | 134,841 |  |
| Net assets acquired |  | $ | 248,514 |  |

[0001596532-21-000049:notes:119]
The acquired intangible assets are amortized on a straight-line basis over their estimated useful lives, as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. The following table shows the valuation of the intangible assets acquired (in thousands) along with their weighted average estimated useful lives:

[0001596532-21-000049:notes:120]
|  |  | Acquisition Date Fair Value |  | Weighted Average Estimated Useful Life |
| Developed technology |  | $ | 72,220 |  |  | 7 years |
| Customer relationships |  | 18,840 |  |  | 7 years |
| Trade name |  | 6,520 |  |  | 5 years |
| Others |  | 4,060 |  |  | 2 years |
| Total intangible assets acquired |  | $ | 101,640 |  |  |  |

[0001596532-21-000049:notes:121]
The goodwill of $134.8 million is primarily attributable to the expected synergies created by incorporating the solutions of the acquired businesses into our technology platform, and the value of the 
assembled workforce. The goodwill is not deductible for income taxes purposes. The Company’s consolidated financial statements include the accounts of Big Switch and Awake Security starting as of the acquisition date. Pro forma and historical post-acquisition results of operations for these acquisitions were not material to the Company’s consolidated financial statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-21-000049:notes:122]
Fair Value Measurements
We measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value on a recurring basis. The following tables summarize the amortized costs, unrealized gains and losses, and fair values of these financial assets by significant investment category and their levels within the fair value hierarchy (in thousands):

[0001596532-21-000049:notes:123]
|  |  | December 31, 2020 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 438,854 |  |  | $ | — |  |  | $ | — |  |  | $ | 438,854 |  |  | $ | 438,854 |  |  | $ | — |  |  | $ | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 51,211 |  |  | — |  |  | — |  |  | 51,211 |  |  | — |  |  | 51,211 |  |  | — |  |
| Certificates of deposits (1) |  | 50,136 |  |  | 3 |  |  | — |  |  | 50,139 |  |  | — |  |  | 50,139 |  |  | — |  |
| U.S. government notes |  | 523,320 |  |  | 187 |  |  | (1) |  |  | 523,506 |  |  | 523,506 |  |  | — |  |  | — |  |
| Corporate bonds |  | 878,484 |  |  | 1,167 |  |  | (330) |  |  | 879,321 |  |  | — |  |  | 879,321 |  |  | — |  |
| Agency securities |  | 475,132 |  |  | 343 |  |  | (3) |  |  | 475,472 |  |  | — |  |  | 475,472 |  |  | — |  |
|  |  | 1,978,283 |  |  | 1,700 |  |  | (334) |  |  | 1,979,649 |  |  | 523,506 |  |  | 1,456,143 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,235 |  |  | — |  |  | — |  |  | 4,235 |  |  | 4,235 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 2,421,372 |  |  | $ | 1,700 |  |  | $ | (334) |  |  | $ | 2,422,738 |  |  | $ | 966,595 |  |  | $ | 1,456,143 |  |  | $ | — |  |
| ____________________ |
| (1) As of December 31, 2020, all of our certificates of deposits were domestic deposits. |

[0001596532-21-000049:notes:124]
|  |  | December 31, 2019 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 562,580 |  |  | $ | — |  |  | $ | — |  |  | $ | 562,580 |  |  | $ | 562,580 |  |  | $ | — |  |  | $ | — |  |
| Certificates of deposits (1) |  | 4,001 |  |  | — |  |  | — |  |  | 4,001 |  |  | — |  |  | 4,001 |  |  | — |  |
|  |  | 566,581 |  |  | — |  |  | — |  |  | 566,581 |  |  | 562,580 |  |  | 4,001 |  |  | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 66,717 |  |  | — |  |  | — |  |  | 66,717 |  |  | — |  |  | 66,717 |  |  | — |  |
| Certificates of deposits (1) |  | 3,000 |  |  | — |  |  | — |  |  | 3,000 |  |  | — |  |  | 3,000 |  |  | — |  |
| U.S. government notes |  | 518,884 |  |  | 414 |  |  | (20) |  |  | 519,278 |  |  | 519,278 |  |  | — |  |  | — |  |
| Corporate bonds |  | 787,741 |  |  | 2,392 |  |  | (73) |  |  | 790,060 |  |  | — |  |  | 790,060 |  |  | — |  |
| Agency securities |  | 233,491 |  |  | 577 |  |  | (41) |  |  | 234,027 |  |  | — |  |  | 234,027 |  |  | — |  |
|  |  | 1,609,833 |  |  | 3,383 |  |  | (134) |  |  | 1,613,082 |  |  | 519,278 |  |  | 1,093,804 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,229 |  |  | — |  |  | — |  |  | 4,229 |  |  | 4,229 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 2,180,643 |  |  | $ | 3,383 |  |  | $ | (134) |  |  | $ | 2,183,892 |  |  | $ | 1,086,087 |  |  | $ | 1,097,805 |  |  | $ | — |  |
| ____________________ |
| (1) As of December 31, 2019, all of our certificates of deposits were domestic deposits. |

[0001596532-21-000049:notes:125]
As of December 31, 2020 and 2019, total unrealized losses of our marketable securities were immaterial. We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. We expect to realize the full value of these investments upon maturity or sale and therefore, we do not consider any of our marketable securities to be impaired as of December 31, 2020. We did not recognize any credit losses or non-credit-related impairments related to our available-for-sale marketable securities for the year ended December 31, 2020.  We determined that the gross unrealized losses on our marketable fixed-income securities as of December 31, 2019 and 2018 were temporary in nature and therefore, we did not recognize any impairment of our marketable fixed-income securities for the years ended December 31, 2019 and 2018, respectively.

[0001596532-21-000049:notes:126]
As of December 31, 2020, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale marketable securities, by remaining contractual maturity, are as follows (in thousands):

[0001596532-21-000049:notes:127]
|  |  | December 31, 2020 |
| Due in 1 year or less |  | $ | 1,151,647 |  |
| Due in 1 year through 2 years |  | 828,002 |  |
| Total marketable securities |  | $ | 1,979,649 |  |

[0001596532-21-000049:notes:128]
The weighted-average remaining duration of our current marketable securities is approximately 0.9 years as of December 31, 2020.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-21-000049:notes:129]
Financial Statements Details
Cash, Cash Equivalents and Restricted Cash

[0001596532-21-000049:notes:130]
The reconciliation of cash, cash equivalents and restricted cash reported in the accompanying consolidated balance sheets to the total of the same such amounts in the accompanying consolidated statements of cash flows is as follows (in thousands):

[0001596532-21-000049:notes:131]
|  |  | December 31, |
|  |  | 2020 |  | 2019 |
| Cash and cash equivalents |  | $ | 893,219 |  |  | $ | 1,111,286 |  |
| Restricted cash included in other assets |  | 4,235 |  |  | 4,229 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 897,454 |  |  | $ | 1,115,515 |  |

[0001596532-21-000049:notes:132]
Accounts Receivable, net

[0001596532-21-000049:notes:133]
Accounts receivable, net consists of the following (in thousands):

[0001596532-21-000049:notes:134]
|  |  | December 31, |
|  |  | 2020 |  | 2019 |
| Accounts receivable |  | $ | 394,037 |  |  | $ | 398,147 |  |
| Allowance for doubtful accounts |  | (659) |  |  | (638) |  |
| Product sales rebate and returns reserve |  | (3,838) |  |  | (5,522) |  |
| Accounts receivable, net |  | $ | 389,540 |  |  | $ | 391,987 |  |

[0001596532-21-000049:notes:135]
Allowance for Doubtful Accounts

[0001596532-21-000049:notes:136]
Activities in the allowance for doubtful accounts consist of the following (in thousands):

[0001596532-21-000049:notes:137]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Balance at the beginning of year |  | $ | 638 |  |  | $ | 507 |  |  | $ | 112 |  |
| Additions charged to expense |  | 397 |  |  | 221 |  |  | 500 |  |
| Deductions/write-offs |  | (376) |  |  | (90) |  |  | (105) |  |
| Balance at the end of year |  | $ | 659 |  |  | $ | 638 |  |  | $ | 507 |  |

[0001596532-21-000049:notes:138]
Product Sales Rebate and Returns Reserve

[0001596532-21-000049:notes:139]
Activities in the product sales rebate and returns reserve consist of the following (in thousands):

[0001596532-21-000049:notes:140]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Balance at the beginning of year |  | $ | 5,522 |  |  | $ | 8,613 |  |  | $ | 7,423 |  |
| Additions charged against revenue |  | 9,454 |  |  | 2,032 |  |  | 4,269 |  |
| Consumption |  | (11,138) |  |  | (5,123) |  |  | (3,079) |  |
| Balance at the end of year |  | $ | 3,838 |  |  | $ | 5,522 |  |  | $ | 8,613 |  |

[0001596532-21-000049:notes:141]
Inventories

[0001596532-21-000049:notes:142]
Inventories consist of the following (in thousands):

[0001596532-21-000049:notes:143]
|  |  | December 31, |
|  |  | 2020 |  | 2019 |
| Raw materials |  | $ | 219,218 |  |  | $ | 96,712 |  |
| Finished goods |  | 260,450 |  |  | 147,113 |  |
| Total inventories |  | $ | 479,668 |  |  | $ | 243,825 |  |

[0001596532-21-000049:notes:144]
Prepaid Expenses and Other Current Assets

[0001596532-21-000049:notes:145]
Prepaid expenses and other current assets consist of the following (in thousands):

[0001596532-21-000049:notes:146]
|  |  | December 31, |
|  |  | 2020 |  | 2019 |
| Inventory deposits |  | $ | 18,783 |  |  | $ | 13,716 |  |
| Prepaid income taxes |  | 267 |  |  | 20,153 |  |
| Other current assets |  | 60,556 |  |  | 64,464 |  |
| Other prepaid expenses and deposits |  | 15,316 |  |  | 13,123 |  |
| Total prepaid expenses and other current assets |  | $ | 94,922 |  |  | $ | 111,456 |  |

[0001596532-21-000049:notes:147]
Property and Equipment, net

[0001596532-21-000049:notes:148]
Property and equipment, net consists of the following (in thousands):

[0001596532-21-000049:notes:149]
|  |  | December 31, |
|  |  | 2020 |  | 2019 |
| Equipment and machinery |  | $ | 70,655 |  |  | $ | 64,748 |  |
| Computer hardware and software |  | 40,081 |  |  | 36,627 |  |
| Furniture and fixtures |  | 3,787 |  |  | 3,774 |  |
| Leasehold improvements |  | 31,448 |  |  | 31,235 |  |
| Construction-in-process |  | 1,441 |  |  | 265 |  |
| Property and equipment, gross |  | 147,412 |  |  | 136,649 |  |
| Less: accumulated depreciation |  | (115,181) |  |  | (97,376) |  |
| Property and equipment, net |  | $ | 32,231 |  |  | $ | 39,273 |  |

[0001596532-21-000049:notes:150]
Depreciation expense was $20.1 million, $19.0 million and $21.6 million for the years ended December 31, 2020, 2019 and 2018, respectively.

[0001596532-21-000049:notes:151]
Accrued Liabilities

[0001596532-21-000049:notes:152]
Accrued liabilities consist of the following (in thousands):

[0001596532-21-000049:notes:153]
|  |  | December 31, |
|  |  | 2020 |  | 2019 |
| Accrued payroll related costs |  | $ | 73,634 |  |  | $ | 80,133 |  |
| Accrued manufacturing costs |  | 43,181 |  |  | 31,920 |  |
| Accrued product development costs |  | 6,733 |  |  | 11,410 |  |
| Accrued warranty costs |  | 9,314 |  |  | 6,742 |  |
| Accrued professional fees |  | 5,211 |  |  | 6,335 |  |
| Accrued taxes |  | 1,870 |  |  | 1,716 |  |
| Other |  | 3,414 |  |  | 1,993 |  |
| Total accrued liabilities |  | $ | 143,357 |  |  | $ | 140,249 |  |

[0001596532-21-000049:notes:154]
Warranty Accrual

[0001596532-21-000049:notes:155]
The following table summarizes the activity related to our accrued liability for estimated future warranty costs (in thousands):

[0001596532-21-000049:notes:156]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |
| Warranty accrual, beginning of year |  | $ | 6,742 |  |  | $ | 5,362 |  |
| Liabilities accrued for warranties issued during the year |  | 9,737 |  |  | 7,169 |  |
| Warranty costs incurred during the year |  | (7,165) |  |  | (5,789) |  |
| Warranty accrual, end of year |  | $ | 9,314 |  |  | $ | 6,742 |  |

[0001596532-21-000049:notes:157]
The following table summarizes the beginning and ending balances of our contract assets (in thousands):

[0001596532-21-000049:notes:158]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |
| Contract assets, beginning balance |  | $ | 25,565 |  |  | $ | 6,341 |  |
| Contract assets, ending balance |  | 16,380 |  |  | 25,565 |  |

[0001596532-21-000049:notes:159]
The following table summarizes the activity related to our contract liabilities (in thousands):

[0001596532-21-000049:notes:160]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |
| Contract liabilities, beginning balance |  | $ | 61,050 |  |  | $ | 32,595 |  |
| Less: Revenue recognized from beginning balance |  | (23,394) |  |  | (12,887) |  |
| Less: Beginning balance reclassified to deferred revenue |  | (1,638) |  |  | (894) |  |
| Add: Contract liabilities recognized |  | 49,939 |  |  | 42,236 |  |
| Contract liabilities, ending balance |  | $ | 85,957 |  |  | $ | 61,050 |  |

[0001596532-21-000049:notes:161]
As of December 31, 2020 and 2019, $34.5 million and $23.4 million, respectively, of our contract liabilities was recorded within other current liabilities with the remaining balance recorded within other long-term liabilities in the accompanying consolidated balance sheets.

[0001596532-21-000049:notes:162]
Deferred Revenue and Performance Obligations

[0001596532-21-000049:notes:163]
Deferred revenue is comprised mainly of unearned revenue related to multi-year PCS contracts, services and product deferrals related to acceptance clauses. The following table summarizes the activity related to our deferred revenue (in thousands):

[0001596532-21-000049:notes:164]
|  |  | Year Ended December 31, 2020 |
| Deferred revenue, beginning balance |  | $ | 575,288 |  |
| Less: Revenue recognized from beginning balance |  | (305,792) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 381,331 |  |
| Deferred revenue, ending balance |  | $ | 650,827 |  |

[0001596532-21-000049:notes:165]
Revenue from Remaining Performance Obligations

[0001596532-21-000049:notes:166]
Revenue from remaining performance obligations represents contracted revenue that has not yet been recognized, which primarily includes contract liabilities and deferred revenue that will be recognized as revenue in future periods. As of December 31, 2020, approximately $900.5 million of revenue is expected to be recognized from remaining performance obligations. We expect to recognize revenue on approximately 79% of these remaining performance obligations over the next 2 years and 21% during years 3 to 5.

[0001596532-21-000049:notes:167]
Other Income, Net

[0001596532-21-000049:notes:168]
Other income, net consists of the following (in thousands):

[0001596532-21-000049:notes:169]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Other income, net: |  |  |  |  |  |  |
| Interest income |  | $ | 27,139 |  |  | $ | 51,144 |  |  | $ | 31,666 |  |
| Interest expense |  | — |  |  | — |  |  | (2,701) |  |
| Gain on sale of marketable securities |  | 9,432 |  |  | — |  |  | — |  |
| Gain (loss) on investments in privately-held companies |  | 4,164 |  |  | 5,427 |  |  | (13,800) |  |
| Other income (expense) |  | (1,556) |  |  | (75) |  |  | 289 |  |
| Total other income, net |  | $ | 39,179 |  |  | $ | 56,496 |  |  | $ | 15,454 |  |


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-21-000049:notes:170]
Investments
Investments in Privately-Held Companies

[0001596532-21-000049:notes:171]
Our investments in privately-held companies do not have readily determinable fair values. Their initial cost is subsequently adjusted to fair value on a non-recurring basis based on observable price changes from orderly transactions of identical or similar securities of the same issuer or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to these securities. In addition, the valuation requires management judgment due to the absence of market price and lack of liquidity. The following table summarizes the activity related to our investments in privately-held companies held as of December 31, 2020 and 2019 (in thousands):

[0001596532-21-000049:notes:172]
|  |  | December 31, 2020 |  | December 31, 2019 |
| Cost of investment |  | $ | 3,000 |  |  | $ | 3,000 |  |
| Cumulative impairment |  | — |  |  | — |  |
| Cumulative upward adjustment |  | 5,314 |  |  | 1,150 |  |
| Carrying amount of investment |  | $ | 8,314 |  |  | $ | 4,150 |  |

[0001596532-21-000049:notes:173]
During the year ended December 31, 2019, we recorded a realized gain of $4.3 million upon the sale of one of our investments. In each of the years ended December 31, 2020, 2019 and 2018, we recorded $4.2 million, $1.2 million and $1.2 million of unrealized gains, respectively. These unrealized gains were recorded on investments that were re-measured to fair value as of the date observable transactions occurred. In addition, during the year ended December 31, 2018, we recorded an impairment of $15.0 million on one of our disposed investments. The aforementioned realized and unrealized gains and impairment were recorded within other income, net in the accompanying consolidated statements of operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001596532-21-000049:notes:174]
Goodwill and Acquisition-Related Intangible Assets 
Goodwill

[0001596532-21-000049:notes:175]
The changes in the carrying values of goodwill for the years ended December 31, 2020 and 2019 are as follows (in thousands):

[0001596532-21-000049:notes:176]
|  |  | Carrying Value |
| Balance at December 31, 2018 |  | $ | 53,684 |  |
| Additions related to acquisitions |  | 1,171 |  |
| Balance at December 31, 2019 |  | 54,855 |  |
| Additions related to acquisitions (See Note 2 for additional information) |  | 134,841 |  |
| Balance at December 31, 2020 |  | $ | 189,696 |  |

[0001596532-21-000049:notes:177]
The Company performed an annual test for goodwill impairment in the fourth quarter of the fiscal years ended December 31, 2020 and 2019 and determined that goodwill was not impaired.

[0001596532-21-000049:notes:178]
Acquisition-Related Intangible Assets

[0001596532-21-000049:notes:179]
The following table presents details of our acquisition-related intangible assets as of December 31, 2020 and 2019 (in thousands, except for years):

[0001596532-21-000049:notes:180]
|  |  | December 31, 2020 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life(In Years) |
| Developed technology |  | $ | 124,730 |  |  | $ | (31,805) |  |  | $ | 92,925 |  |  | 5.2 |
| Customer relationships |  | 25,920 |  |  | (4,298) |  |  | 21,622 |  |  | 6.2 |
| Trade name |  | 8,990 |  |  | (2,946) |  |  | 6,044 |  |  | 4.3 |
| Others |  | 5,720 |  |  | (3,521) |  |  | 2,199 |  |  | 1.1 |
| Total |  | $ | 165,360 |  |  | $ | (42,570) |  |  | $ | 122,790 |  |  | 5.3 |

[0001596532-21-000049:notes:181]
|  |  | December 31, 2019 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life(In Years) |
| Developed technology |  | $ | 52,510 |  |  | $ | (14,326) |  |  | $ | 38,184 |  |  | 3.7 |
| Customer relationships |  | 7,080 |  |  | (1,387) |  |  | 5,693 |  |  | 5.8 |
| Trade name |  | 2,470 |  |  | (1,112) |  |  | 1,358 |  |  | 1.7 |
| Others |  | 1,660 |  |  | (1,660) |  |  | — |  |  | 0.0 |
| Total |  | $ | 63,720 |  |  | $ | (18,485) |  |  | $ | 45,235 |  |  | 3.9 |

[0001596532-21-000049:notes:182]
Amortization expense related to acquisition-related intangible assets was $24.1 million, $13.4 million and $5.1 million for the years ended December 31, 2020, 2019 and 2018, respectively.

[0001596532-21-000049:notes:183]
As of December 31, 2020, future estimated amortization expense related to the acquired-related intangible assets is as follows (in thousands):

[0001596532-21-000049:notes:184]
| Years Ending December 31, |  | Future Amortization Expense |
| 2021 |  | $ | 29,235 |  |
| 2022 |  | 26,774 |  |
| 2023 |  | 22,781 |  |
| 2024 |  | 16,103 |  |
| 2025 |  | 9,750 |  |
| Thereafter |  | 18,147 |  |
| Total |  | $ | 122,790 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-21-000049:notes:185]
Commitments and Contingencies
Operating Leases

[0001596532-21-000049:notes:186]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2028. Some of our leases include options to extend the term of such leases for a period from three months to up to 10 years and/or options to early terminate the leases. As of December 31, 2020, we did not include any such options in determining the lease terms because we were not reasonably certain that we would exercise these options.

[0001596532-21-000049:notes:187]
The following table summarizes the supplemental balance sheet information related to our operating leases (in thousands):

[0001596532-21-000049:notes:188]
|  |  | December 31, 2020 |  | December 31, 2019 |
| Right-of-use assets: |  |  |  |  |
| Operating lease right-of-use assets |  | $ | 77,288 |  |  | $ | 87,770 |  |
| Lease liabilities: |  |  |  |  |
| Operating lease liabilities, current (included in other current liabilities) |  | 17,773 |  |  | 16,052 |  |
| Operating lease liabilities, non-current |  | 72,397 |  |  | 83,022 |  |
| Total operating lease liabilities |  | $ | 90,170 |  |  | $ | 99,074 |  |

[0001596532-21-000049:notes:189]
The following table summarizes our lease costs (in thousands):

[0001596532-21-000049:notes:190]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |
| Operating lease costs: |  |  |  |  |
| Fixed lease costs |  | $ | 23,392 |  |  | $ | 22,544 |  |
| Variable lease costs |  | 7,459 |  |  | 6,255 |  |
| Total operating lease costs |  | $ | 30,851 |  |  | $ | 28,799 |  |

[0001596532-21-000049:notes:191]
The operating lease costs in the table above include costs for long-term and short-term leases. Total short-term lease costs were immaterial. Fixed lease costs include expenses recognized for base rent payments on a straight-lined basis. Variable lease costs primarily include maintenance, utilities and operating expenses that are incremental to the fixed base rent payments, and are excluded from the calculation of operating lease liabilities and ROU assets. For the years ended December 31, 2020 and 2019, cash paid for amounts associated with our operating lease liabilities were approximately $20.2 million and $18.6 million, respectively, which were classified as operating activities in the accompanying consolidated statements of cash flows.

[0001596532-21-000049:notes:192]
Maturities of operating lease liabilities as of December 31, 2020 are presented in the table below (in thousands):

[0001596532-21-000049:notes:193]
| Years ending December 31, |  |  |
| 2021 |  | $ | 21,770 |  |  |  |
| 2022 |  | 21,890 |  |  |  |
| 2023 |  | 19,533 |  |  |  |
| 2024 |  | 11,730 |  |  |  |
| 2025 |  | 9,409 |  |  |  |
| 2026 and thereafter |  | 19,926 |  |  |  |
| Total undiscounted operating lease payments (excluding non-lease components) |  | 104,258 |  |  |  |
| Less: imputed interest |  | (14,088) |  |  |  |
| Present value of operating lease payments as of December 31, 2020 |  | $ | 90,170 |  |  |  |

[0001596532-21-000049:notes:194]
|  |  | December 31, 2020 |  | December 31, 2019 |
| Weighted-average remaining lease term — operating leases |  | 5.4 years |  | 6.0 years |
| Weighted-average discount rate — operating leases |  | 5.0% |  | 5.1% |

[0001596532-21-000049:notes:195]
Purchase Commitments

[0001596532-21-000049:notes:196]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments.  In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of December 31, 2020, we had non-cancellable purchase commitments of $454.0 million, of which $421.9 million was to our contract manufacturers and suppliers.  In addition, we had deposits to our contract manufacturers to secure our purchase commitments in the amount of $21.5 million and $16.5 million as of December 31, 2020 and 2019, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the accompanying consolidated balance sheets.

[0001596532-21-000049:notes:197]
Guarantees

[0001596532-21-000049:notes:198]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products

[0001596532-21-000049:notes:199]
infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any material impact on our consolidated financial statements to date.

[0001596532-21-000049:notes:200]
Legal Proceedings

[0001596532-21-000049:notes:201]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-21-000049:notes:202]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. Based on currently available information, management does not believe that any liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-21-000049:notes:203]
Stockholders' Equity and Stock-Based Compensation
Stock Repurchase Program

[0001596532-21-000049:notes:204]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program.  This authorization allows us to repurchase shares of our common stock over three years and is funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Exchange Act, or a combination of the foregoing. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of December 31, 2020, the remaining authorized amount for stock repurchases under this program was approximately $338.7 million.

[0001596532-21-000049:notes:205]
A summary of the stock repurchase activity under the Repurchase Program is as follows (in thousands, except per share amounts):

[0001596532-21-000049:notes:206]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |
| Aggregate purchase price |  | $ | 395,173 |  |  | $ | 266,142 |  |
| Shares repurchased |  | 2,012 |  |  | 1,189 |  |
| Average price paid per share |  | $ | 196.43 |  |  | $ | 223.57 |  |

[0001596532-21-000049:notes:207]
The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings.  All shares repurchased under the Repurchase Program have been retired.

[0001596532-21-000049:notes:208]
2014 Equity Incentive Plan

[0001596532-21-000049:notes:209]
In April 2014, the board of directors and stockholders approved the 2014 Equity Incentive Plan (the “2014 Plan”), effective on the first day that our common stock was publicly traded, and simultaneously terminated the 2004 and 2011 equity plans as to future grants.  However, these plans will continue to govern the terms and conditions of the outstanding options previously granted thereunder.

[0001596532-21-000049:notes:210]
Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”).  The number of shares available for grant and issuance under the 2014

[0001596532-21-000049:notes:211]
Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of the outstanding shares of our common stock on the immediately preceding December 31, but not to exceed 12,500,000 shares (the “2014 Plan Evergreen Increase”), unless the board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2020, our board of directors authorized an increase of 2,291,660 shares to the shares available for issuance under the 2014 Plan. In connection with our acquisition of Awake Security, Inc., we assumed the stock options outstanding under the Awake Security 2014 Equity Incentive Plan and registered an additional 115,338 shares to be available for future issuance. As of December 31, 2020, there remained approximately 21.5 million shares available for issuance under the 2014 Plan. On February 8, 2021, our board of directors authorized an increase of 2,285,228 shares to shares available for future issuance under the 2014 Plan effective January 1, 2021.

[0001596532-21-000049:notes:212]
2014 Employee Stock Purchase Plan

[0001596532-21-000049:notes:213]
In April 2014, the board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded.  The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding immediately preceding December 31, but not to exceed 2,500,000 shares, unless the board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2020, our board of directors authorized an increase of 763,886 shares to shares available for issuance under the ESPP. As of December 31, 2020, there remained 3,850,993 shares available for issuance under the ESPP. On February 8, 2021, our board of directors authorized an increase of 761,742 shares to shares available for issuance under the ESPP effective January 1, 2021.

[0001596532-21-000049:notes:214]
Under our 2014 ESPP, eligible employees are permitted to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the exercise date. Each offering period lasts approximately two years starting on the first trading date after February 15 and August 15 of each year. Participants may purchase shares of common stock through payroll deductions up to 10% of their eligible compensation, subject to Internal Revenue Service mandated purchase limits.

[0001596532-21-000049:notes:215]
During the year ended December 31, 2020, we issued 105,667 shares at an average purchase price of $183.45 under our 2014 ESPP.

[0001596532-21-000049:notes:216]
Stock Option Activities

[0001596532-21-000049:notes:217]
The following table summarizes the option activities and related information (in thousands, except years and per share amounts):

[0001596532-21-000049:notes:218]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (In Years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2019 |  | 4,564 |  |  | $ | 42.50 |  |  | 4.4 |  | $ | 740,387 |  |
| Options granted |  | 115 |  |  | 28.01 |  |  |  |  |  |
| Options exercised |  | (1,210) |  |  | 31.55 |  |  |  |  |  |
| Options canceled |  | (39) |  |  | 105.51 |  |  |  |  |  |
| Balance—December 31, 2020 |  | 3,430 |  |  | $ | 45.17 |  |  | 3.6 |  | $ | 841,659 |  |
| Vested and exercisable—December 31, 2020 |  | 2,263 |  |  | $ | 32.25 |  |  | 3.1 |  | $ | 584,598 |  |

[0001596532-21-000049:notes:219]
The weighted-average grant-date fair value of options granted during the years ended December 31, 2020, 2019 and 2018 was $184.96, $107.42 and $121.18 per share, respectively. The aggregate intrinsic value of options exercised during the years ended December 31, 2020, 2019 and 2018 was $245.9 million, $323.1 million and $283.8 million, respectively. The total fair value of options vested for the years ended December 31, 2020, 2019 and 2018 was approximately $20.0 million, $23.0 million and $31.9 million, respectively.

[0001596532-21-000049:notes:220]
Restricted Stock Unit (RSU) Activities

[0001596532-21-000049:notes:221]
The following table summarizes the RSU activities and related information (in thousands, except per share amounts):

[0001596532-21-000049:notes:222]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |
| Unvested balance—December 31, 2019 |  | 1,070 |  |  | $ | 190.35 |  |
| RSUs granted |  | 1,361 |  |  | 216.46 |  |
| RSUs vested |  | (519) |  |  | 164.46 |  |
| RSUs forfeited/canceled |  | (96) |  |  | 220.92 |  |
| Unvested balance—December 31, 2020 |  | 1,816 |  |  | $ | 215.68 |  |

[0001596532-21-000049:notes:223]
The total fair value of RSUs vested for the years ended December 31, 2020, 2019 and 2018 was approximately $85.4 million, $65.7 million, and $52.5 million, respectively.

[0001596532-21-000049:notes:224]
Shares Available for Grant

[0001596532-21-000049:notes:225]
The following table presents the stock activities and the total number of shares available for grant as of December 31, 2020 under our 2014 Equity Incentive Plan (in thousands):

[0001596532-21-000049:notes:226]
|  |  | Number of Shares |
| Balance—December 31, 2019 |  | 15,146 |  |
| Authorized (1) |  | 2,407 |  |
| Options granted |  | (115) |  |
| RSUs granted |  | (1,361) |  |
| Options canceled |  | 39 |  |
| RSUs forfeited |  | 96 |  |
| Shares traded for taxes |  | 37 |  |
| Balance—December 31, 2020 |  | 16,249 |  |

[0001596532-21-000049:notes:227]
(1): The authorized number of shares consists of 2,291,660 shares approved by our board of directors under the aforementioned 2014 Equity Incentive Plan effective January 1, 2020, and 115,338 shares assumed under the Awake Security 2014 Equity Incentive Plan in conjunction with our acquisition of Awake Security.

[0001596532-21-000049:notes:228]
Stock-Based Compensation Expense

[0001596532-21-000049:notes:229]
The following table summarizes the stock-based compensation expense related to our equity awards (in thousands):

[0001596532-21-000049:notes:230]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Cost of revenue |  | $ | 6,272 |  |  | $ | 4,637 |  |  | $ | 5,087 |  |
| Research and development |  | 79,913 |  |  | 53,068 |  |  | 48,205 |  |
| Sales and marketing |  | 34,944 |  |  | 29,168 |  |  | 24,995 |  |
| General and administrative |  | 15,913 |  |  | 14,407 |  |  | 12,915 |  |
| Total stock-based compensation |  | $ | 137,042 |  |  | $ | 101,280 |  |  | $ | 91,202 |  |

[0001596532-21-000049:notes:231]
Determination of Fair Value

[0001596532-21-000049:notes:232]
We record stock-based compensation awards based on fair value as of the grant date. We value RSUs at the market close price of our common stock on the grant date. For option awards and ESPP offerings, we use the Black-Scholes option pricing model to determine fair value. We recognize such costs as compensation expense generally on a straight-line basis over the requisite service period of the award.

[0001596532-21-000049:notes:233]
Stock Options

[0001596532-21-000049:notes:234]
For the years ended December 31, 2020, 2019 and 2018, the fair value of each stock option granted under our plans was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001596532-21-000049:notes:235]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Expected term (in years) |  | 5.0 |  | 6.9 |  | 7.0 |
| Risk-free interest rate |  | 0.4 | % |  | 2.5 | % |  | 2.9 | % |
| Expected volatility |  | 43.5 | % |  | 42.8 | % |  | 44.6 | % |
| Dividend rate |  | — | % |  | — | % |  | — | % |

[0001596532-21-000049:notes:236]
ESPP

[0001596532-21-000049:notes:237]
The following table summarizes the assumptions relating to our ESPP:

[0001596532-21-000049:notes:238]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Expected term (in years) |  | 1.6 |  | 1.1 |  | 1.1 |
| Risk-free interest rate |  | 0.4 | % |  | 1.8 | % |  | 2.4 | % |
| Expected volatility |  | 45.1 | % |  | 42.5 | % |  | 41.9 | % |
| Dividend rate |  | — | % |  | — | % |  | — | % |

[0001596532-21-000049:notes:239]
As of December 31, 2020, unrecognized stock-based compensation expenses by award type and their expected weighted-average recognition periods are summarized in the following table (in thousands, except years).

[0001596532-21-000049:notes:240]
|  |  | December 31, 2020 |
|  |  | Stock Option |  | RSU |  | ESPP |  | Restricted Stock |
| Unrecognized stock-based compensation expense |  | $ | 46,111 |  |  | $ | 337,835 |  |  | $ | 9,494 |  |  | $ | 8,309 |  |
| Weighted-average amortization period |  | 2.8 years |  | 3.4 years |  | 1.2 years |  | 3.2 years |


## us-gaap:EarningsPerShareTextBlock

[0001596532-21-000049:notes:241]
Net Income Per Share 
The following table sets forth the computation of our basic and diluted net income per share attributable to common stockholders (in thousands, except per share amounts):

[0001596532-21-000049:notes:242]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Numerator: |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |
| Net income |  | $ | 634,557 |  |  | $ | 859,867 |  |  | $ | 328,115 |  |
| Less: undistributed earnings allocated to participating securities |  | — |  |  | (423) |  |  | (189) |  |
| Net income attributable to common stockholders, basic |  | $ | 634,557 |  |  | $ | 859,444 |  |  | $ | 327,926 |  |
| Diluted: |  |  |  |  |  |  |
| Net income attributable to common stockholders, basic |  | $ | 634,557 |  |  | $ | 859,444 |  |  | $ | 327,926 |  |
| Add: undistributed earnings allocated to participating securities |  | — |  |  | 24 |  |  | 15 |  |
| Net income attributable to common stockholders, diluted |  | $ | 634,557 |  |  | $ | 859,468 |  |  | $ | 327,941 |  |
| Denominator: |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders, basic |  | 75,984 |  |  | 76,312 |  |  | 74,750 |  |
| Diluted: |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders, basic |  | 75,984 |  |  | 76,312 |  |  | 74,750 |  |
| Add weighted-average effects of dilutive securities: |  |  |  |  |  |  |
| Stock options and RSUs |  | 3,462 |  |  | 4,565 |  |  | 6,083 |  |
| Employee stock purchase plan |  | 19 |  |  | 2 |  |  | 11 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders, diluted |  | 79,465 |  |  | 80,879 |  |  | 80,844 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |
| Basic |  | $ | 8.35 |  |  | $ | 11.26 |  |  | $ | 4.39 |  |
| Diluted |  | $ | 7.99 |  |  | $ | 10.63 |  |  | $ | 4.06 |  |

[0001596532-21-000049:notes:243]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share attributable to common stockholders because their effects would have been anti-dilutive for the periods presented (in thousands):

[0001596532-21-000049:notes:244]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Stock options and RSUs |  | 345 |  |  | 318 |  |  | 140 |  |
| Employee stock purchase plan |  | 83 |  |  | 82 |  |  | 71 |  |
| Total |  | 428 |  |  | 400 |  |  | 211 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-21-000049:notes:245]
Income Taxes
The components of income before provision for income taxes are as follows (in thousands):

[0001596532-21-000049:notes:246]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Domestic |  | $ | 621,838 |  |  | $ | 727,632 |  |  | $ | 136,818 |  |
| Foreign |  | 117,025 |  |  | 134,638 |  |  | 151,983 |  |
| Income before income taxes |  | $ | 738,863 |  |  | $ | 862,270 |  |  | $ | 288,801 |  |

[0001596532-21-000049:notes:247]
The components of the provision for income taxes are as follows (in thousands):

[0001596532-21-000049:notes:248]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Current provision for income taxes: |  |  |  |  |  |  |
| Federal |  | $ | 78,843 |  |  | $ | 58,187 |  |  | $ | 6,113 |  |
| State |  | 21,135 |  |  | 19,067 |  |  | 2,018 |  |
| Foreign |  | 12,891 |  |  | 928 |  |  | 10,451 |  |
| Total current |  | 112,869 |  |  | 78,182 |  |  | 18,582 |  |
| Deferred tax expense (benefit): |  |  |  |  |  |  |
| Federal |  | (17,592) |  |  | 362,056 |  |  | (57,726) |  |
| State |  | (849) |  |  | (4,511) |  |  | (4,164) |  |
| Foreign |  | 9,878 |  |  | (433,324) |  |  | 3,994 |  |
| Total deferred tax expense (benefit) |  | (8,563) |  |  | (75,779) |  |  | (57,896) |  |
| Total provision for (benefit from) income taxes |  | $ | 104,306 |  |  | $ | 2,403 |  |  | $ | (39,314) |  |

[0001596532-21-000049:notes:249]
The reconciliation of the statutory federal income tax rate and our effective income tax rate is as follows (in percentages):

[0001596532-21-000049:notes:250]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| U.S. federal statutory income tax rate |  | 21.00 | % |  | 21.00 | % |  | 21.00 | % |
| State tax, net of federal benefit |  | 2.23 |  |  | 1.30 |  |  | (0.59) |  |
| Taxes on foreign earnings differential |  | (0.92) |  |  | (2.59) |  |  | (3.37) |  |
| Tax credits |  | (2.64) |  |  | (3.10) |  |  | (7.68) |  |
| Change in valuation allowance |  | (0.18) |  |  | (0.10) |  |  | 1.00 |  |
| Intra-Entity Sale |  | — |  |  | (9.95) |  |  | — |  |
| Stock-based compensation |  | (5.65) |  |  | (6.56) |  |  | (24.90) |  |
| Tax Cuts and Jobs Act |  | — |  |  | — |  |  | (1.72) |  |
| Acquisition and integration costs |  | 0.27 |  |  | 0.04 |  |  | 2.12 |  |
| Other, net |  | 0.01 |  |  | 0.24 |  |  | 0.53 |  |
| Effective tax rate |  | 14.12 | % |  | 0.28 | % |  | (13.61) | % |

[0001596532-21-000049:notes:251]
Excess tax benefits resulting from stock awards were $58.7 million, $77.9 million and $75.5 million for the years ended December 31, 2020, 2019 and 2018, respectively.

[0001596532-21-000049:notes:252]
We have operations and a taxable presence in numerous jurisdictions outside the U.S. On December 31, 2019, we completed an intra-entity transaction to sell our non-Americas economic and beneficial intellectual property ("IP") rights in exchange for a non-interest-bearing note of $3.4 billion. As a result of the transaction, tax basis in the IP transferred equaled the fair market value of the qualifying IP that resulted in the recognition

[0001596532-21-000049:notes:253]
of a deferred tax asset of $429.1 million, which was largely offset by a deferred tax liability of $343.3 million associated with the future US tax on foreign earnings arising from the transaction for the difference between the local tax basis and U.S. GAAP book basis of the IP rights.

[0001596532-21-000049:notes:254]
The tax effects of temporary differences that give rise to significant portions of deferred tax assets (liabilities) are as follows (in thousands):

[0001596532-21-000049:notes:255]
|  |  | December 31, |
|  |  | 2020 |  | 2019 |
| Deferred tax assets: |  |  |  |  |
| Intangible assets |  | $ | 392,053 |  |  | $ | 419,911 |  |
| Reserves and accruals not currently deductible |  | 80,550 |  |  | 71,945 |  |
| Tax credits |  | 68,592 |  |  | 54,867 |  |
| Lease financing obligation |  | 22,080 |  |  | 22,547 |  |
| Capitalized research and development expenses |  | 23,656 |  |  | 16,169 |  |
| Stock-based compensation |  | 18,548 |  |  | 15,856 |  |
| Net operating losses |  | 23,998 |  |  | 8,857 |  |
| Other |  | 3,873 |  |  | 3,950 |  |
| Gross deferred tax assets |  | 633,350 |  |  | 614,102 |  |
| Valuation allowance |  | (82,638) |  |  | (67,331) |  |
| Total deferred tax assets |  | 550,712 |  |  | 546,771 |  |
| Deferred tax liabilities: |  |  |  |  |
| US tax on foreign earnings |  | (317,970) |  |  | (326,967) |  |
| Right of use asset |  | (18,764) |  |  | (20,038) |  |
| Other |  | (383) |  |  | (2,451) |  |
| Total deferred tax liabilities |  | (337,117) |  |  | (349,456) |  |
| Net deferred tax assets |  | $ | 213,595 |  |  | $ | 197,315 |  |

[0001596532-21-000049:notes:256]
The following table presents the breakdown between non-current deferred tax assets and liabilities (in thousands):

[0001596532-21-000049:notes:257]
|  |  | December 31, |
|  |  | 2020 |  | 2019 |
| Deferred tax assets, non-current |  | $ | 441,531 |  |  | $ | 452,025 |  |
| Deferred tax liabilities, non-current |  | (227,936) |  |  | (254,710) |  |
| Total net deferred tax assets |  | $ | 213,595 |  |  | $ | 197,315 |  |

[0001596532-21-000049:notes:258]
Recognition of deferred tax assets is appropriate when realization of these assets is more likely than not. We believe that all deferred tax assets are realizable with the exception of California, Canada, and U.K. deferred tax assets. Therefore, we recorded a valuation allowance of $82.6 million and $67.3 million as of December 31, 2020 and 2019, respectively, against California, Canada, and U.K. deferred tax assets, since it is more likely than not that these assets will be not be recognized.

[0001596532-21-000049:notes:259]
As of December 31, 2020, we had $245.1 million and $97.4 million of net operating loss carryforwards for federal and state income tax purposes, respectively, from the acquisition of Mojo Networks, Big Switch Networks and Awake Security. These federal and state losses will begin to expire in 2027 and 2029, respectively. For foreign jurisdictions, we had combined foreign net operating loss carryforwards of $12.8 million, which do not expire.

[0001596532-21-000049:notes:260]
We had a federal credit of $2.0 million from the acquisition of Awake Security, which will begin to expire in 2038 and a California state credit of $128.7 million, which can be carried over indefinitely. For foreign

[0001596532-21-000049:notes:261]
jurisdictions, we had $0.5 million of Canadian scientific research and experimental development tax credit carry-forwards, which will begin to expire in 2034.

[0001596532-21-000049:notes:262]
Utilization of the net operating losses and tax credit carryforwards may be subject to limitations due to ownership change limitations provided in the Internal Revenue code and similar state or foreign provisions.

[0001596532-21-000049:notes:263]
The Tax Cuts and Jobs Act enacted on December 22, 2017 requires a Transition Tax on previously untaxed accumulated and current foreign earnings.  Correspondingly, all undistributed earnings are deemed to be taxed and distributions of the unremitted earnings do not have any significant U.S. federal income tax impact.  We have not provided for any remaining tax effect, if any, of limited outside basis differences of our foreign subsidiaries based upon plans of future reinvestment. The determination of the future tax consequences of the remittance of these earnings is not practicable.

[0001596532-21-000049:notes:264]
Uncertain Tax Positions

[0001596532-21-000049:notes:265]
We recognize uncertain tax positions only to the extent that management believes that it is more likely than not the position will be sustained. The reconciliation of the beginning and ending amount of gross unrecognized tax benefits as of December 31, 2020, 2019 and 2018 is as follows (in thousands):

[0001596532-21-000049:notes:266]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Gross unrecognized tax benefits—beginning balance |  | $ | 93,806 |  |  | $ | 74,436 |  |  | $ | 48,835 |  |
| Increases related to tax positions taken in a prior year |  | 3,103 |  |  | 11,171 |  |  | 330 |  |
| Increases related to tax positions taken during current year |  | 20,274 |  |  | 22,714 |  |  | 27,413 |  |
| Decreases related to tax positions taken in a prior year |  | (18,029) |  |  | (89) |  |  | (675) |  |
| Decreases related to settlements with taxing authorities |  | — |  |  | (12,388) |  |  | — |  |
| Decreases related to lapse of statute of limitations |  | (6,654) |  |  | (2,120) |  |  | (2,173) |  |
| Adjustment for acquisition |  | — |  |  | 82 |  |  | 706 |  |
| Gross unrecognized tax benefits—ending balance |  | $ | 92,500 |  |  | $ | 93,806 |  |  | $ | 74,436 |  |

[0001596532-21-000049:notes:267]
As of December 31, 2020, 2019 and 2018, the total amount of gross unrecognized tax benefits was $92.5 million, $93.8 million and $74.4 million, respectively, of which $44.7 million, $28.5 million and $35.7 million would affect our effective tax rate if recognized.

[0001596532-21-000049:notes:268]
Our policy is to recognize interest and penalties accrued on any unrecognized tax benefits as a component of income tax expense. We have recorded a net expense for interest and penalties of $0.1 million and $0.2 million in the years ended December 31, 2020 and 2019, respectively. As of December 31, 2020 and 2019, we recognized a liability for interest and penalties of $2.0 million and $2.2 million, respectively. 
The statute of limitations for Federal and most states remain open for 2017 and forward. Some states have net operating loss and tax credit carryforwards, and therefore remain open to examination. The majority of our foreign tax returns are open to audit under the statute of limitations of the respective foreign countries, where the subsidiaries are located. It is possible that the amount of existing unrecognized tax benefits may decrease within the next 12 months as a result of statute of limitation lapses or payments to tax authorities in certain jurisdictions; however, an estimate of the range cannot be made.


## anet:GeographicInformationTextBlock

[0001596532-21-000049:notes:269]
Geographical Information We operate as one reportable segment. The following table represents revenue based on customers' shipping addresses (in thousands):

[0001596532-21-000049:notes:270]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Americas |  | $ | 1,771,992 |  |  | $ | 1,833,163 |  |  | $ | 1,550,453 |  |
| Europe, Middle East and Africa |  | 326,729 |  |  | 381,651 |  |  | 414,069 |  |
| Asia Pacific |  | 218,791 |  |  | 195,892 |  |  | 186,847 |  |
| Total revenue |  | $ | 2,317,512 |  |  | $ | 2,410,706 |  |  | $ | 2,151,369 |  |

[0001596532-21-000049:notes:271]
Long-lived assets, excluding intercompany receivables, investments in subsidiaries, investments in privately-held companies and deferred tax assets, net by location are summarized as follows (in thousands):

[0001596532-21-000049:notes:272]
|  |  | December 31, |
|  |  | 2020 |  | 2019 |
| United States |  | $ | 24,110 |  |  | $ | 32,565 |  |
| International |  | 8,121 |  |  | 6,708 |  |
| Total |  | $ | 32,231 |  |  | $ | 39,273 |  |


## us-gaap:PostemploymentBenefitsDisclosureTextBlock

[0001596532-21-000049:notes:273]
Post-Employment Benefits We have a 401(k) Plan that covers substantially all of our employees in the U.S.  Effective January 1, 2017, we have elected to match 100% of employees' contributions up to a maximum of 3% of an employee's annual salary. Matching contributions are immediately vested. For the years ended December 31, 2020, 2019 and 2018, we contributed approximately $7.4 million, $5.1 million and $4.6 million for the matching contributions, respectively.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001596532-21-000049:notes:274]
Selected Quarterly Financial Information (Unaudited)The following table sets forth selected unaudited quarterly consolidated statements of operations data for each of the quarters in the years ended December 31, 2020 and 2019. This unaudited selected quarterly financial data has been prepared on the same basis as our audited consolidated financial statements included elsewhere in this Annual Report on Form 10-K. In the opinion of management, the financial data set forth in the tables below reflect all normal recurring adjustments necessary for the fair statement of results of operations for these periods. Our historical results are not necessarily indicative of the results that may be expected in the future and the results of a particular quarter or other interim period are not necessarily indicative of the results for a full year. This financial data should be read in conjunction with the Item 7 Management’s Discussion and 
Analysis of Financial Condition and Results of Operations, our consolidated financial statements and related notes included elsewhere in this Annual Report on Form 10-K.

[0001596532-21-000049:notes:275]
|  |  | Three Months Ended |
|  |  | Dec. 31, 2020 |  | Sep. 30, 2020 |  | Jun. 30, 2020 |  | Mar. 31, 2020 |  | Dec. 31, 2019 |  | Sep. 30, 2019 |  | Jun. 30, 2019 |  | Mar. 31, 2019 |
|  |  | (in thousands, except for per share amounts) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 518,281 |  |  | $ | 480,242 |  |  | $ | 421,413 |  |  | $ | 410,906 |  |  | $ | 447,498 |  |  | $ | 555,066 |  |  | $ | 513,171 |  |  | $ | 505,415 |  |
| Service |  | 130,201 |  |  | 125,189 |  |  | 119,157 |  |  | 112,123 |  |  | 105,048 |  |  | 99,349 |  |  | 95,150 |  |  | 90,009 |  |
| Total revenue |  | 648,482 |  |  | 605,431 |  |  | 540,570 |  |  | 523,029 |  |  | 552,546 |  |  | 654,415 |  |  | 608,321 |  |  | 595,424 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 210,436 |  |  | 199,465 |  |  | 176,432 |  |  | 163,629 |  |  | 175,476 |  |  | 218,220 |  |  | 200,534 |  |  | 198,152 |  |
| Service |  | 23,462 |  |  | 21,004 |  |  | 20,049 |  |  | 21,149 |  |  | 20,767 |  |  | 18,921 |  |  | 17,596 |  |  | 16,702 |  |
| Total cost of revenue |  | 233,898 |  |  | 220,469 |  |  | 196,481 |  |  | 184,778 |  |  | 196,243 |  |  | 237,141 |  |  | 218,130 |  |  | 214,854 |  |
| Gross profit |  | 414,584 |  |  | 384,962 |  |  | 344,089 |  |  | 338,251 |  |  | 356,303 |  |  | 417,274 |  |  | 390,191 |  |  | 380,570 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | 133,847 |  |  | 128,049 |  |  | 111,544 |  |  | 113,154 |  |  | 110,063 |  |  | 118,732 |  |  | 114,295 |  |  | 119,669 |  |
| Sales and marketing |  | 67,671 |  |  | 53,372 |  |  | 51,237 |  |  | 57,086 |  |  | 54,535 |  |  | 55,279 |  |  | 53,040 |  |  | 51,053 |  |
| General and administrative |  | 18,428 |  |  | 15,146 |  |  | 14,319 |  |  | 18,349 |  |  | 15,716 |  |  | 14,657 |  |  | 16,019 |  |  | 15,506 |  |
| Total operating expenses |  | 219,946 |  |  | 196,567 |  |  | 177,100 |  |  | 188,589 |  |  | 180,314 |  |  | 188,668 |  |  | 183,354 |  |  | 186,228 |  |
| Income from operations |  | 194,638 |  |  | 188,395 |  |  | 166,989 |  |  | 149,662 |  |  | 175,989 |  |  | 228,606 |  |  | 206,837 |  |  | 194,342 |  |
| Total other income, net |  | 5,542 |  |  | 13,224 |  |  | 8,256 |  |  | 12,157 |  |  | 11,183 |  |  | 19,169 |  |  | 13,811 |  |  | 12,333 |  |
| Income before income taxes |  | 200,180 |  |  | 201,619 |  |  | 175,245 |  |  | 161,819 |  |  | 187,172 |  |  | 247,775 |  |  | 220,648 |  |  | 206,675 |  |
| Provision for (benefit from) income taxes |  | 17,222 |  |  | 33,244 |  |  | 30,452 |  |  | 23,388 |  |  | (73,520) |  |  | 38,880 |  |  | 31,397 |  |  | 5,646 |  |
| Net income |  | $ | 182,958 |  |  | $ | 168,375 |  |  | $ | 144,793 |  |  | $ | 138,431 |  |  | $ | 260,692 |  |  | $ | 208,895 |  |  | $ | 189,251 |  |  | $ | 201,029 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.41 |  |  | $ | 2.22 |  |  | $ | 1.91 |  |  | $ | 1.82 |  |  | $ | 3.41 |  |  | $ | 2.73 |  |  | $ | 2.47 |  |  | $ | 2.65 |  |
| Diluted |  | $ | 2.31 |  |  | $ | 2.12 |  |  | $ | 1.83 |  |  | $ | 1.73 |  |  | $ | 3.25 |  |  | $ | 2.59 |  |  | $ | 2.33 |  |  | $ | 2.47 |  |
