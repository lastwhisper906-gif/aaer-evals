# ANET 8-K — 0001596532-21-000048 filed 2021-02-18

## item codes, every 8-K on or before 2021-02-19

- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2021-02-19

- none on or before 2021-02-19

## item 2.02 — earnings release, exhibit 99.1

[0001596532-21-000048:8k_2_02:1]
EX-99.1
2
ex991q420-earningsrelease.htm
EX-99.1

[0001596532-21-000048:8k_2_02:2]
Document

[0001596532-21-000048:8k_2_02:3]
Exhibit 99.1

[0001596532-21-000048:8k_2_02:4]
Arista Networks, Inc. Reports Fourth Quarter and Year End 2020 Financial Results

[0001596532-21-000048:8k_2_02:5]
SANTA CLARA, Calif.- February 18, 2021 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in cognitive cloud networking for large datacenter and campus environments, today announced financial results for its fourth quarter and year ended December 31, 2020.

[0001596532-21-000048:8k_2_02:6]
Fourth Quarter Financial Results

[0001596532-21-000048:8k_2_02:7]
•Revenue of $648.5 million, an increase of 7.1% compared to the third quarter of 2020, and an increase of 17.4% from the fourth quarter of 2019.

[0001596532-21-000048:8k_2_02:8]
•GAAP gross margin of 63.9%, compared to GAAP gross margin of 63.6% in the third quarter of 2020 and 64.5% in the fourth quarter of 2019.

[0001596532-21-000048:8k_2_02:9]
•Non-GAAP gross margin of 65.0%, compared to non-GAAP gross margin of 64.6% in the third quarter of 2020 and 65.2% in the fourth quarter of 2019.

[0001596532-21-000048:8k_2_02:10]
•GAAP net income of $183.0 million, or $2.31 per diluted share, compared to GAAP net income of $260.7 million, or $3.25 per diluted share in the fourth quarter of 2019.

[0001596532-21-000048:8k_2_02:11]
•Non-GAAP net income of $197.7 million, or $2.49 per diluted share, compared to non-GAAP net income of $183.4 million, or $2.29 per diluted share in the fourth quarter of 2019.

[0001596532-21-000048:8k_2_02:12]
Full Year Financial Results

[0001596532-21-000048:8k_2_02:13]
•Revenue of $2.32 billion, a decrease of 3.9% compared to fiscal year 2019.

[0001596532-21-000048:8k_2_02:14]
•GAAP gross margin of 63.9%, compared to GAAP gross margin of 64.1% in fiscal year 2019.

[0001596532-21-000048:8k_2_02:15]
•Non-GAAP gross margin of 65.0%, compared to non-GAAP gross margin of 64.7% in fiscal year 2019.

[0001596532-21-000048:8k_2_02:16]
•GAAP net income of $634.6 million, or $7.99 per diluted share, compared to GAAP net income of $859.9 million, or $10.63 per diluted share, in fiscal year 2019.

[0001596532-21-000048:8k_2_02:17]
•Non-GAAP net income of $718.4 million or $9.04 per diluted share, compared to non-GAAP net income of $786.8 million or $9.73 per diluted share, in fiscal year 2019.

[0001596532-21-000048:8k_2_02:18]
“I am pleased with Arista's return to growth in Q4 2020. With our laser focus on customer success, pristine financials and transformative innovations, Arista is well positioned to continue our momentum in the post pandemic era,” stated Jayshree Ullal, President and CEO of Arista Networks.

[0001596532-21-000048:8k_2_02:19]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO said, “The Arista team showed great resilience and flexibility throughout 2020, maintaining operational excellence, while executing well on our market and product diversification initiatives.”

[0001596532-21-000048:8k_2_02:20]
Fourth Quarter Company Highlights

[0001596532-21-000048:8k_2_02:21]
•Arista announced the 750 Series – Arista expands its Cognitive Campus portfolio with the new 750 Series modular chassis for enhanced security solutions and simplified automation workflows.

[0001596532-21-000048:8k_2_02:22]
•Arista Delivers Network Observability with DANZ Monitoring Fabric – Arista announced a network observability software, DANZ Monitoring Fabric (DMF), on Arista switching platforms for enterprise-wide traffic visibility and contextual insights.

[0001596532-21-000048:8k_2_02:23]
•Arista Unveils Attack Surface Assessment Service – Arista announced an Attack Surface Assessment, an advanced security service delivered through the recent acquisition of Awake Security.

[0001596532-21-000048:8k_2_02:24]
Full Year Company Highlights

[0001596532-21-000048:8k_2_02:25]
•Arista Networks acquired Awake Security, a Network Detection and Response (NDR) platform provider that combines artificial intelligence (AI) with human expertise to autonomously hunt and respond to insider and external threats.

[0001596532-21-000048:8k_2_02:26]
•Arista Networks acquired Big Switch Networks, a network monitoring and SDN (Software Defined Networking) pioneer.

[0001596532-21-000048:8k_2_02:27]
•Arista Networks recognized as a leader in The Forrester Wave™: Open, Programmable Switches for A Businesswide SDN, Q3 2020 with the top score in the strategy category.

[0001596532-21-000048:8k_2_02:28]
•Arista Networks Announced Optical Line System for 400G – The Arista OSFP-LS is a highly compact, low power and cost-effective solution for increasing bandwidth between data centers without the need for external optical line systems.

[0001596532-21-000048:8k_2_02:29]
•This is the sixth consecutive year Arista Networks has been recognized in the Leaders Quadrant of the 2020 Gartner Magic Quadrant for Data Center Networking published on 30 June 2020.

[0001596532-21-000048:8k_2_02:30]
Financial Outlook

[0001596532-21-000048:8k_2_02:31]
For the first quarter of 2021, we expect:

[0001596532-21-000048:8k_2_02:32]
•Revenue between $630 million to $650 million;

[0001596532-21-000048:8k_2_02:33]
•Non-GAAP gross margin of 63% to 65%; and

[0001596532-21-000048:8k_2_02:34]
•Non-GAAP operating margin of approximately 37%.

[0001596532-21-000048:8k_2_02:35]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and certain non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below under “Non-GAAP Financial Measures”).

[0001596532-21-000048:8k_2_02:36]
Prepared Materials and Conference Call Information

[0001596532-21-000048:8k_2_02:37]
Arista executives will discuss the fourth quarter and year end 2020 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (833) 968-2211 in the United States or +1 (778) 560-2896 from international locations. The Conference ID is 9269847.

[0001596532-21-000048:8k_2_02:38]
The financial results conference call will also be available via live webcast on our investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-21-000048:8k_2_02:39]
Forward-Looking Statements

[0001596532-21-000048:8k_2_02:40]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the first quarter of fiscal year 2021, statements regarding the benefits of the introduction of new products and our leadership in cloud networking, and statements regarding Arista’s ability to continue its momentum in the post pandemic era. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: the impact of the COVID-19 pandemic on our business; the rapid evolution of the networking market; any failure to successfully pursue new products and service offerings and expand into adjacent markets; a decline in our revenue growth rate; unpredictability of our results of operations;

[0001596532-21-000048:8k_2_02:41]
interruptions or delays in shipments; adverse economic conditions or reduced information technology and network infrastructure spending; intense competition; expansion of our international sales and operations; investment or acquisition in other businesses; seasonality; our ability to attract new large end customers or sell products and services to existing end customers; our ability to increase market awareness of our company and new products and services; product quality problems; our ability to anticipate technological shifts and develop products to meet those technological shifts; insufficient component supply and inventory; our ability to protect, defend and maintain our intellectual property rights; vulnerabilities in our products and failure of our products to detect security breaches our intellectual property rights; and tax, tariff, import/export restrictions; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, its annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-21-000048:8k_2_02:42]
Gartner “Magic Quadrant for Data Center and Cloud Networking,” Andrew Lerner, et al, 30 June 2020.  Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose. The Gartner content described herein, (the "Gartner content") represent(s) research opinion or viewpoints published, as part of a syndicated subscription service, by Gartner, Inc. ("Gartner"), and are not representations of fact. Gartner Content speaks as of its original publication date (and not as of the date of this Form 8-K) and the opinions expressed in the Gartner Content are subject to change without notice.

[0001596532-21-000048:8k_2_02:43]
Non-GAAP Financial Measures

[0001596532-21-000048:8k_2_02:44]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangible assets, certain non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-21-000048:8k_2_02:45]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-21-000048:8k_2_02:46]
The company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. The company does not provide

[0001596532-21-000048:8k_2_02:47]
3

[0001596532-21-000048:8k_2_02:48]
guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. A reconciliation of the non-GAAP financial measures guidance to the corresponding GAAP measures on a forward-looking basis is not available because stock-based compensation expense is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-21-000048:8k_2_02:49]
About Arista Networks

[0001596532-21-000048:8k_2_02:50]
Arista Networks is an industry leader in cognitive cloud networking solutions for large data center and campus environments. Arista’s award-winning platforms deliver availability, agility, automation analytics, and security through CloudVision® and Arista EOS®, an advanced network operating system.  For more information visit www.arista.com.

[0001596532-21-000048:8k_2_02:51]
ARISTA, CloudVision, CloudEOS and MSS are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners. Additional information and resources can be found at www.arista.com.

[0001596532-21-000048:8k_2_02:52]
| Investor Contacts |
| Arista Networks, Inc. Charles Yager, 408-547-5892 Product and Investor Advocacy cyager@arista.comor |
| Curtis McKee, 408-547-5549Corporate and Investor Developmentcurtism@arista.com |

[0001596532-21-000048:8k_2_02:53]
ARISTA NETWORKS, INC.

[0001596532-21-000048:8k_2_02:54]
Condensed Consolidated Statements of Operations

[0001596532-21-000048:8k_2_02:55]
(Unaudited, in thousands, except per share amounts)

[0001596532-21-000048:8k_2_02:56]
|  |  | Three Months Ended December 31, |  | Twelve Months Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 518,281 |  |  | $ | 447,498 |  |  | $ | 1,830,842 |  |  | $ | 2,021,150 |  |
| Service |  | 130,201 |  |  | 105,048 |  |  | 486,670 |  |  | 389,556 |  |
| Total revenue |  | 648,482 |  |  | 552,546 |  |  | 2,317,512 |  |  | 2,410,706 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 210,436 |  |  | 175,476 |  |  | 749,962 |  |  | 792,382 |  |
| Service |  | 23,462 |  |  | 20,767 |  |  | 85,664 |  |  | 73,986 |  |
| Total cost of revenue |  | 233,898 |  |  | 196,243 |  |  | 835,626 |  |  | 866,368 |  |
| Total gross profit |  | 414,584 |  |  | 356,303 |  |  | 1,481,886 |  |  | 1,544,338 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 133,847 |  |  | 110,063 |  |  | 486,594 |  |  | 462,759 |  |
| Sales and marketing |  | 67,671 |  |  | 54,535 |  |  | 229,366 |  |  | 213,907 |  |
| General and administrative |  | 18,428 |  |  | 15,716 |  |  | 66,242 |  |  | 61,898 |  |
| Total operating expenses |  | 219,946 |  |  | 180,314 |  |  | 782,202 |  |  | 738,564 |  |
| Income from operations |  | 194,638 |  |  | 175,989 |  |  | 699,684 |  |  | 805,774 |  |
| Other income, net |  | 5,542 |  |  | 11,183 |  |  | 39,179 |  |  | 56,496 |  |
| Income before income taxes |  | 200,180 |  |  | 187,172 |  |  | 738,863 |  |  | 862,270 |  |
| Provision for (benefit from) income taxes |  | 17,222 |  |  | (73,520) |  |  | 104,306 |  |  | 2,403 |  |
| Net income |  | $ | 182,958 |  |  | $ | 260,692 |  |  | $ | 634,557 |  |  | $ | 859,867 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 182,958 |  |  | $ | 260,589 |  |  | $ | 634,557 |  |  | $ | 859,444 |  |
| Diluted |  | $ | 182,958 |  |  | $ | 260,594 |  |  | $ | 634,557 |  |  | $ | 859,468 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.41 |  |  | $ | 3.41 |  |  | $ | 8.35 |  |  | $ | 11.26 |  |
| Diluted |  | $ | 2.31 |  |  | $ | 3.25 |  |  | $ | 7.99 |  |  | $ | 10.63 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | 75,864 |  |  | 76,345 |  |  | 75,984 |  |  | 76,312 |  |
| Diluted |  | 79,261 |  |  | 80,261 |  |  | 79,465 |  |  | 80,879 |  |

[0001596532-21-000048:8k_2_02:57]
5

[0001596532-21-000048:8k_2_02:58]
ARISTA NETWORKS, INC.

[0001596532-21-000048:8k_2_02:59]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-21-000048:8k_2_02:60]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-21-000048:8k_2_02:61]
|  |  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| GAAP gross profit |  | $ | 414,584 |  |  | $ | 356,303 |  |  | $ | 1,481,886 |  |  | $ | 1,544,338 |  |
| GAAP gross margin |  | 63.9 | % |  | 64.5 | % |  | 63.9 | % |  | 64.1 | % |
| Stock-based compensation expense |  | 1,554 |  |  | 1,253 |  |  | 6,272 |  |  | 4,637 |  |
| Intangible asset amortization |  | 5,464 |  |  | 2,626 |  |  | 17,480 |  |  | 10,503 |  |
| Non-GAAP gross profit |  | $ | 421,602 |  |  | $ | 360,182 |  |  | $ | 1,505,638 |  |  | $ | 1,559,478 |  |
| Non-GAAP gross margin |  | 65.0 | % |  | 65.2 | % |  | 65.0 | % |  | 64.7 | % |
| GAAP income from operations |  | $ | 194,638 |  |  | $ | 175,989 |  |  | $ | 699,684 |  |  | $ | 805,774 |  |
| Stock-based compensation expense |  | 40,095 |  |  | 26,435 |  |  | 137,042 |  |  | 101,280 |  |
| Litigation expense |  | — |  |  | 333 |  |  | — |  |  | 2,295 |  |
| Intangible asset amortization |  | 7,562 |  |  | 3,084 |  |  | 24,086 |  |  | 13,375 |  |
| Acquisition-related costs(1) |  | 1,215 |  |  | — |  |  | 13,933 |  |  | — |  |
| Non-GAAP income from operations |  | $ | 243,510 |  |  | $ | 205,841 |  |  | $ | 874,745 |  |  | $ | 922,724 |  |
| Non-GAAP operating margin |  | 37.6 | % |  | 37.3 | % |  | 37.7 | % |  | 38.3 | % |
| GAAP net income |  | $ | 182,958 |  |  | $ | 260,692 |  |  | $ | 634,557 |  |  | $ | 859,867 |  |
| Stock-based compensation expense |  | 40,095 |  |  | 26,435 |  |  | 137,042 |  |  | 101,280 |  |
| Litigation expense |  | — |  |  | 333 |  |  | — |  |  | 2,295 |  |
| Intangible asset amortization |  | 7,562 |  |  | 3,084 |  |  | 24,086 |  |  | 13,375 |  |
| Acquisition-related costs |  | 1,215 |  |  | — |  |  | 13,933 |  |  | — |  |
| Gain on investment in privately-held companies |  | (4,164) |  |  | — |  |  | (4,164) |  |  | (5,427) |  |
| Altera stock-based tax charge (2) |  | — |  |  | — |  |  | — |  |  | 9,781 |  |
| Tax benefit on intra-entity IP transfer (3) |  | — |  |  | (85,819) |  |  | — |  |  | (85,819) |  |
| Tax benefit on stock-based awards |  | (19,802) |  |  | (16,232) |  |  | (60,880) |  |  | (89,415) |  |
| Income tax effect on non-GAAP exclusions |  | (10,188) |  |  | (5,045) |  |  | (26,163) |  |  | (19,093) |  |
| Non-GAAP net income |  | $ | 197,676 |  |  | $ | 183,448 |  |  | $ | 718,411 |  |  | $ | 786,844 |  |
| GAAP diluted net income per share attributable to common stockholders |  | $ | 2.31 |  |  | $ | 3.25 |  |  | $ | 7.99 |  |  | $ | 10.63 |  |
| Non-GAAP adjustments to net income |  | 0.18 |  |  | (0.96) |  |  | 1.05 |  |  | (0.90) |  |
| Non-GAAP diluted net income per share |  | $ | 2.49 |  |  | $ | 2.29 |  |  | $ | 9.04 |  |  | $ | 9.73 |  |
| Weighted-average shares used in computing GAAP and Non-GAAP diluted net income per share attributable to common stockholders |  | 79,261 |  |  | 80,261 |  |  | 79,465 |  |  | 80,879 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,554 |  |  | $ | 1,253 |  |  | $ | 6,272 |  |  | $ | 4,637 |  |
| Research and development |  | 23,184 |  |  | 13,897 |  |  | 79,913 |  |  | 53,068 |  |
| Sales and marketing |  | 11,188 |  |  | 7,705 |  |  | 34,944 |  |  | 29,168 |  |
| General and administrative |  | 4,169 |  |  | 3,580 |  |  | 15,913 |  |  | 14,407 |  |
| Total |  | $ | 40,095 |  |  | $ | 26,435 |  |  | $ | 137,042 |  |  | $ | 101,280 |  |

[0001596532-21-000048:8k_2_02:62]
___________________

[0001596532-21-000048:8k_2_02:63]
(1) Represents non-recurring costs associated with our acquisitions, which primarily include retention bonuses, professional and consulting fees, and restructuring costs.

[0001596532-21-000048:8k_2_02:64]
(2) Represents a discrete income tax expense related to stock-based compensation as a result of an opinion on Altera Corporation and Subsidiaries vs. Commissioner on Internal Revenue issued by the Court of Appeals for the Ninth Circuit on June 7, 2019.

[0001596532-21-000048:8k_2_02:65]
(3) Represents a one-time tax benefit of $85.8 million upon completion of an intra-entity transaction to sell our non-Americas economic and beneficial intellectual property rights in the current quarter.

[0001596532-21-000048:8k_2_02:66]
ARISTA NETWORKS, INC.

[0001596532-21-000048:8k_2_02:67]
Condensed Consolidated Balance Sheets

[0001596532-21-000048:8k_2_02:68]
(Unaudited, in thousands)

[0001596532-21-000048:8k_2_02:69]
|  |  | December 31, 2020 |  | December 31, 2019 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 893,219 |  |  | $ | 1,111,286 |  |
| Marketable securities |  | 1,979,649 |  |  | 1,613,082 |  |
| Accounts receivable |  | 389,540 |  |  | 391,987 |  |
| Inventories |  | 479,668 |  |  | 243,825 |  |
| Prepaid expenses and other current assets |  | 94,922 |  |  | 111,456 |  |
| Total current assets |  | 3,836,998 |  |  | 3,471,636 |  |
| Property and equipment, net |  | 32,231 |  |  | 39,273 |  |
| Acquisition-related intangible assets, net |  | 122,790 |  |  | 45,235 |  |
| Goodwill |  | 189,696 |  |  | 54,855 |  |
| Investments |  | 8,314 |  |  | 4,150 |  |
| Operating lease right-of-use assets |  | 77,288 |  |  | 87,770 |  |
| Deferred tax assets |  | 441,531 |  |  | 452,025 |  |
| Other assets |  | 30,071 |  |  | 30,346 |  |
| TOTAL ASSETS |  | $ | 4,738,919 |  |  | $ | 4,185,290 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 134,235 |  |  | $ | 92,105 |  |
| Accrued liabilities |  | 143,357 |  |  | 140,249 |  |
| Deferred revenue |  | 396,259 |  |  | 312,668 |  |
| Other current liabilities |  | 94,392 |  |  | 52,052 |  |
| Total current liabilities |  | 768,243 |  |  | 597,074 |  |
| Income taxes payable |  | 53,053 |  |  | 55,485 |  |
| Operating lease liabilities, non-current |  | 72,397 |  |  | 83,022 |  |
| Deferred revenue, non-current |  | 254,568 |  |  | 262,620 |  |
| Deferred tax liabilities, non-current |  | 227,936 |  |  | 254,710 |  |
| Other long-term liabilities |  | 42,431 |  |  | 37,693 |  |
| TOTAL LIABILITIES |  | 1,418,628 |  |  | 1,290,604 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 8 |  |  | 8 |  |
| Additional paid-in capital |  | 1,292,431 |  |  | 1,106,305 |  |
| Retained earnings (1) |  | 2,027,614 |  |  | 1,788,230 |  |
| Accumulated other comprehensive income |  | 238 |  |  | 143 |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 3,320,291 |  |  | 2,894,686 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 4,738,919 |  |  | $ | 4,185,290 |  |
| ______________________ |  |  |  |  |
| (1) We adopted new lease accounting guidance under Accounting Standard Codification Topic 842 - Leases (“ASC 842”), which resulted in a cumulative-effect adjustment of $3.7 million to retained earnings as of January 1, 2019. |

[0001596532-21-000048:8k_2_02:70]
7

[0001596532-21-000048:8k_2_02:71]
ARISTA NETWORKS, INC.

[0001596532-21-000048:8k_2_02:72]
Condensed Consolidated Statements of Cash Flows

[0001596532-21-000048:8k_2_02:73]
(Unaudited, in thousands)

[0001596532-21-000048:8k_2_02:74]
|  |  | Twelve Months Ended December 31, |
|  |  | 2020 |  | 2019 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 634,557 |  |  | $ | 859,867 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 44,590 |  |  | 32,849 |  |
| Noncash lease expense |  | 16,970 |  |  | 16,179 |  |
| Stock-based compensation |  | 137,042 |  |  | 101,280 |  |
| Deferred income taxes |  | (9,144) |  |  | (75,741) |  |
| Gain on investments in privately-held companies, net |  | (4,164) |  |  | (5,427) |  |
| Gain on sale of marketable securities |  | (9,432) |  |  | — |  |
| Amortization (accretion) of investment premiums (discounts) |  | 10,381 |  |  | (6,771) |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | 10,673 |  |  | (60,210) |  |
| Inventories |  | (235,318) |  |  | 20,927 |  |
| Prepaid expenses and other current assets |  | 13,846 |  |  | 54,259 |  |
| Other assets |  | 4,965 |  |  | (8,112) |  |
| Accounts payable |  | 41,161 |  |  | (1,937) |  |
| Accrued liabilities |  | 2,728 |  |  | 16,366 |  |
| Deferred revenue |  | 50,352 |  |  | (11,939) |  |
| Income taxes payable |  | 8,805 |  |  | 23,523 |  |
| Other liabilities |  | 17,102 |  |  | 7,921 |  |
| Net cash provided by operating activities |  | 735,114 |  |  | 963,034 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 1,545,689 |  |  | 1,208,717 |  |
| Purchases of marketable securities |  | (2,688,064) |  |  | (1,503,893) |  |
| Business combinations, net of cash acquired |  | (227,420) |  |  | (1,365) |  |
| Purchases of property, equipment and intangible assets |  | (15,384) |  |  | (15,751) |  |
| Investments in privately-held companies |  | 3,399 |  |  | 28,220 |  |
| Proceeds from sale of marketable securities |  | 772,978 |  |  | — |  |
| Net cash used in investing activities |  | (608,802) |  |  | (284,072) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 57,556 |  |  | 57,378 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (8,722) |  |  | (9,200) |  |
| Repurchase of common stock |  | (395,173) |  |  | (266,142) |  |
| Net cash used in financing activities |  | (346,339) |  |  | (217,964) |  |
| Effect of exchange rate changes |  | 1,966 |  |  | 353 |  |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | (218,061) |  |  | 461,351 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 1,115,515 |  |  | 654,164 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 897,454 |  |  | $ | 1,115,515 |  |

[0001596532-21-000048:8k_2_02:75]
8
