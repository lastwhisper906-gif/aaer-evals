# ANET note change history — 0001596532-20-000148 → 0001596532-20-000226


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-11-03):
[0001596532-20-000226:note_history:1]
Commitments and Contingencies
Purchase Commitments
  (was, 2020-08-05, similarity 0.716):
[0001596532-20-000148:note_history:1]
6.    Commitments and Contingencies

- changed (2020-11-03):
[0001596532-20-000226:note_history:2]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consists of firm non-cancellable commitments. In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2020, we had non-cancellable purchase commitments of $501.5 million, of which $484.8 million were to our contract manufacturers and suppliers. In addition, we have provided suppliers with inventory deposits to secure our obligations to purchase inventory and the amount of these deposits may increase in future periods as we work to reduce product lead times and ensure adequate component supply to meet future demand. We had $12.8 million and $16.5 million in deposits as of September 30, 2020 and December 31, 2019, respectively. These deposits are included in “Prepaid expenses and other current assets” and “Other assets” on the accompanying condensed consolidated balance sheets.
  (was, 2020-08-05, similarity 0.9881):
[0001596532-20-000148:note_history:2]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments. In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of June 30, 2020, we had non-cancellable purchase commitments of $570.3 million, of which $552.5 million was to our contract manufacturers and suppliers. In addition, we have provided suppliers with inventory deposits to secure our obligations to purchase inventory and the amount of these deposits may increase in future periods as we work to reduce product lead times and ensure adequate component supply to meet future demand. We had $14.5 million and $16.5 million in deposits as of June 30, 2020 and December 31, 2019, respectively. These deposits are included in “Prepaid expenses and other current assets” and “Other assets” on the accompanying condensed consolidated balance sheets.

- changed (2020-11-03):
[0001596532-20-000226:note_history:3]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe on the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.
  (was, 2020-08-05, similarity 0.9983):
[0001596532-20-000148:note_history:3]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

- changed (2020-11-03):
[0001596532-20-000226:note_history:4]
We record a provision for contingent losses when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2020, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.
  (was, 2020-08-05, similarity 0.9913):
[0001596532-20-000148:note_history:4]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of June 30, 2020, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.

- removed (2020-11-03):
[0001596532-20-000148:note_history:5]
Purchase Commitments


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-11-03):
[0001596532-20-000226:note_history:6]
Organization and Summary of Significant Accounting Policies 
Organization
  (was, 2020-08-05, similarity 0.8872):
[0001596532-20-000148:note_history:6]
1.    Organization and Summary of Significant Accounting Policies

- changed (2020-11-03):
[0001596532-20-000226:note_history:7]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2020, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2019 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.
  (was, 2020-08-05, similarity 0.9811):
[0001596532-20-000148:note_history:7]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2020, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2019 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

- changed (2020-11-03):
[0001596532-20-000226:note_history:8]
Our contract manufacturers and suppliers have experienced delays in the production and export of their products, which have negatively impacted our supply chain and could negatively impact our business in the future. In addition, we expect that COVID-19 related disruptions may have a negative impact on demand from our customers in future periods and contribute to an expected year-over-year decline in revenues for the year ending December 31, 2020. However, the extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, including the duration and spread of the pandemic and related mitigation efforts, as well as restrictions on travel and transport, all of which are uncertain and cannot be predicted. Management is actively monitoring the impact of the pandemic on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.
  (was, 2020-08-05, similarity 0.9901):
[0001596532-20-000148:note_history:8]
Our contract manufacturers and suppliers have experienced and continue to experience delays in the production and export of their products, which have negatively impacted our supply chain and could negatively impact our business in the future. In addition, we expect that COVID-19 related disruptions may have a negative impact on demand from our customers in future periods and contribute to an expected year-over-year decline in revenues for the year ending December 31, 2020. However, the extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, including the duration and spread of the pandemic and related mitigation efforts, as well as restrictions on travel and transport, all of which are uncertain and cannot be predicted. Management is actively monitoring the impact of the pandemic on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

- removed (2020-11-03):
[0001596532-20-000148:note_history:9]
Organization


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2020-11-03):
[0001596532-20-000226:note_history:10]
Subsequent Events
    On September 21, 2020, the Company entered into a Merger Agreement to acquire Awake Security, Inc. (“Awake Security”), a network detection and response (“NDR”) platform provider headquartered in Santa Clara, California, and on October 7, 2020, we completed the acquisition of Awake Security.

- added (2020-11-03):
[0001596532-20-000226:note_history:11]
The acquisition will be included in our consolidated financial statements beginning in the fourth quarter of 2020, and will be financed from our existing cash balance.
