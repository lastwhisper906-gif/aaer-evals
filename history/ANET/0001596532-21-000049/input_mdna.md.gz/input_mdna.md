# ANET MD&A — 0001596532-21-000049


## mdna

[0001596532-21-000049:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001596532-21-000049:mdna:2]
Overview

[0001596532-21-000049:mdna:3]
Arista Networks pioneered software-driven, cognitive cloud networking for large-scale data center and campus workspace environments. Our industry-leading cloud networking platform is highly scalable and programmable, and purpose built to address the functional and performance requirements for cloud networks, including workflow automation, network visibility and analytics, and has further allowed us to integrate rapidly with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001596532-21-000049:mdna:4]
We generate revenue primarily from sales of our switching and routing platforms, which incorporate our EOS software, and related network applications. We also generate revenue from post contract support, or PCS, which end customers typically purchase in conjunction with our products, and renewals of PCS. We sell our products through both our direct sales force and our channel partners. Our end customers span a range of industries and include large internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others.

[0001596532-21-000049:mdna:5]
Historically, large purchases by a relatively limited number of end customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large end customers primarily due to changes in demand patterns specific to these customers, the time it takes these end customers to evaluate, test, qualify and accept our products, and the overall complexity of these large orders. We expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis.  For example, sales to our end customers Microsoft and Facebook in fiscal 2019 collectively represented 40% of our total revenue, whereas sales to our end customer Microsoft in fiscal 2020 amounted to 21.5% of our revenues, with our end customer Facebook representing less than 10% of our revenues in the period. These changes contributed to a year-over-year decline in our revenue for fiscal 2020.  However, this decline in revenue from these large end customers was in part offset by stronger sales to our enterprise and other cloud and service provider customers.  In addition, we typically provide pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur.

[0001596532-21-000049:mdna:6]
We believe that cloud networking will continue to replace legacy network technologies across data center and campus environments. Our cloud networking platforms are well positioned to address the growing cloud networking market, and to address increasing performance requirements driven by the growing number of connected devices, as well as the need for constant connectivity and access to data and applications.

[0001596532-21-000049:mdna:7]
The markets for cloud networking solutions are highly competitive and characterized by rapidly changing technology, changing end-customer needs, evolving industry standards, frequent introductions of new products and services and industry consolidation. We expect competition to intensify in the future as the market for cloud networking expands and existing competitors and new market entrants introduce new products or enhance existing products.  Our future success is dependent upon our ability to continue to evolve and adapt to our rapidly changing environment.   We must also continue to develop market leading products and features that address the needs of our existing and new customers, and increase sales in the enterprise data center switching, and campus workspace markets.  We intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new end customers more effectively, increase sales to existing customers, and provide services and support.  In addition, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our ability to rapidly develop new features and applications.

[0001596532-21-000049:mdna:8]
Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic with respect to the underlying merchant silicon architecture. Today, we combine our EOS software with merchant silicon into a family of switching and routing products. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We work closely with third party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-21-000049:mdna:9]
Recent Developments

[0001596532-21-000049:mdna:10]
The global coronavirus (“COVID-19”) pandemic and related shelter in place, travel and social distancing restrictions imposed by governments around the world in an effort to contain or slow its spread have negatively impacted the global economy, disrupted business, sales activities, supply chains and workforce participation, including our own, and created significant volatility and disruption of financial markets, and we expect that the global health crisis caused by COVID-19 will continue to negatively impact business activity for the foreseeable future.

[0001596532-21-000049:mdna:11]
We have taken numerous steps, and will continue to take further actions, in our approach to address COVID-19. We have prioritized the protection of our employees during this pandemic and, as a result, have closed our offices across the globe (including our corporate headquarters), limiting access to only those employees providing essential activities, instructed employees to work from home, and implemented travel restrictions. We continue to work closely with our contract manufacturers and supply chain partners who have experienced delays in component sourcing, workforce disruptions and governmental restrictions on the production and export of their products. Although we have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, these delays have negatively impacted our ability to supply products to our customers on a timely basis. We expect to continue to invest in working capital as supply availability improves in order to address the risk of future COVID-19 related supply chain disruptions, but we cannot be certain that such disruptions will not occur.  When the COVID-19 pandemic began, we initially experienced some volatility in customer demand, but sales activity subsequently stabilized and we experienced incremental improvements in overall demand as the year progressed. However, the supply chain disruptions outlined above and the earlier volatility in customer demand contributed in part to a year-over-year decline in total revenue for the year ended December 31, 2020.

[0001596532-21-000049:mdna:12]
The extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, including the duration and spread of the pandemic, the breadth and duration of governmental containment measures such as shelter in place, travel and social distancing restrictions as well as the reauthorization of or increase in such measures in the event of spikes in COVID-19 infection rates, the success of the COVID-19 vaccination deployment, and the impact on our customers, partners, contract manufacturers

[0001596532-21-000049:mdna:13]
and supply chain, all of which are uncertain and cannot be predicted. However, any continued or renewed disruption in manufacturing and supply resulting from the COVID-19 pandemic or related containment measures could negatively impact our business. We also believe that any extended or renewed COVID-19 related economic disruption could have a negative impact on demand from our customers in future periods. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

[0001596532-21-000049:mdna:14]
In response to potential future COVID-19 related disruptions to our business, we have continued to carefully review our investment and spending plans, cautiously increasing incremental spending in the second half of fiscal 2020 as overall customer demand stabilized. Although management is actively monitoring the impact of COVID-19 on the Company’s financial condition, liquidity, operations, suppliers, industry, and workforce, the full impact of the pandemic continues to evolve as of the date of this report. As such, the Company is unable to estimate the effects of COVID-19 on its future results of operations, financial condition, or liquidity.

[0001596532-21-000049:mdna:15]
Acquisitions

[0001596532-21-000049:mdna:16]
On February 5, 2020, we acquired Big Switch Networks, Inc. (“Big Switch”), a network monitoring and software-defined networking pioneer headquartered in Santa Clara, California. With the acquisition of Big Switch, we expanded our data center networking solutions and further strengthen our network monitoring and observability suite delivered through Arista’s software platform CloudVision and DANZ (DataANalyZer) capabilities. In addition, on October 7, 2020, we completed the acquisition of Awake Security Inc. (“Awake Security”), a network detection and response (“NDR”) platform provider headquartered in Santa Clara, California. With the acquisition of Awake Security, we added an NDR platform to our product portfolio that combines artificial intelligence (AI) with human expertise to autonomously hunt for and respond to insider and external threats.

[0001596532-21-000049:mdna:17]
Results of Operations

[0001596532-21-000049:mdna:18]
Year Ended December 31, 2020 Compared to Year Ended December 31, 2019

[0001596532-21-000049:mdna:19]
Revenue, Cost of Revenue and Gross Profit (in thousands, except percentages)

[0001596532-21-000049:mdna:20]
|  |  | Year Ended December 31, |  |  |
|  |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,830,842 |  |  | 79.0 | % |  | $ | 2,021,150 |  |  | 83.8 | % |  | $ | (190,308) |  |  | (9.4) | % |
| Service |  | 486,670 |  |  | 21.0 |  |  | 389,556 |  |  | 16.2 |  |  | 97,114 |  |  | 24.9 |  |
| Total revenue |  | 2,317,512 |  |  | 100.0 |  |  | 2,410,706 |  |  | 100.0 |  |  | (93,194) |  |  | (3.9) |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 749,962 |  |  | 32.4 |  |  | 792,382 |  |  | 32.9 |  |  | (42,420) |  |  | (5.4) |  |
| Service |  | 85,664 |  |  | 3.7 |  |  | 73,986 |  |  | 3.0 |  |  | 11,678 |  |  | 15.8 |  |
| Total cost of revenue |  | 835,626 |  |  | 36.1 |  |  | 866,368 |  |  | 35.9 |  |  | (30,742) |  |  | (3.5) |  |
| Gross profit |  | $ | 1,481,886 |  |  | 63.9 | % |  | $ | 1,544,338 |  |  | 64.1 | % |  | $ | (62,452) |  |  | (4.0) | % |
| Gross margin |  | 63.9 | % |  |  |  | 64.1 | % |  |  |  |  |  |  |

[0001596532-21-000049:mdna:21]
Revenue by Geography (in thousands, except percentages)

[0001596532-21-000049:mdna:22]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | % of Total |  | 2019 |  | % of Total |
| Americas |  | $ | 1,771,992 |  |  | 76.5 | % |  | $ | 1,833,163 |  |  | 76.1 | % |
| Europe, Middle East and Africa |  | 326,729 |  |  | 14.1 |  |  | 381,651 |  |  | 15.8 |  |
| Asia-Pacific |  | 218,791 |  |  | 9.4 |  |  | 195,892 |  |  | 8.1 |  |
| Total revenue |  | $ | 2,317,512 |  |  | 100.0 | % |  | $ | 2,410,706 |  |  | 100.0 | % |

[0001596532-21-000049:mdna:23]
Revenue

[0001596532-21-000049:mdna:24]
Product revenue primarily consists of sales of our switching and routing products, and software licenses.  Service revenue is primarily derived from sales of post-contract support, or PCS, which is typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing, size, and complexity of orders, especially with respect to our large end customers.

[0001596532-21-000049:mdna:25]
Product revenue decreased $190.3 million, or 9.4%, in the year ended December 31, 2020 compared to 2019.  The decrease was primarily due to the recognition of $125.1 million of deferred product revenue in the year ended December 31, 2019 related to customer acceptance of products shipped in prior periods. In addition, we experienced reduced sales to our larger customers during fiscal 2020, combined with the impact of some COVID-19 related supply constraints.  Service revenue increased $97.1 million, or 24.9% in the year ended December 31, 2020 compared to 2019 as a result of continued growth in initial and renewal support contracts as our customer installed base continued to expand. International revenues remained relatively constant at 23.5% of total revenues in the year ended December 31, 2020, compared to 23.9% in 2019, with a slight decrease in growth in our EMEA region, mostly offset by an increase in growth in our Asia-Pacific region.  International revenue generally fluctuates based on the timing of deployments by certain of our large end customers.

[0001596532-21-000049:mdna:26]
Cost of Revenue and Gross Margin

[0001596532-21-000049:mdna:27]
Cost of product revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs of our manufacturing operations, and other costs associated with manufacturing our products and managing our inventory. Cost of service revenue primarily consists of personnel and other costs associated with our global customer support and services organizations.

[0001596532-21-000049:mdna:28]
Cost of revenue decreased $30.7 million or 3.5% for the year ended December 31, 2020 compared to 2019. The decrease in cost of revenue was primarily due to a corresponding decrease in product revenues, and was partially offset by incremental COVID-19 related supply chain costs and increased product transition costs.

[0001596532-21-000049:mdna:29]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including pricing pressure on our products and services due to competition, the mix of sales to large end customers who generally receive lower pricing, manufacturing-related costs, including costs associated with supply chain sourcing activities, merchant silicon costs, the mix of products sold, and excess/obsolete inventory write-downs, including charges for excess/obsolete component inventory held by our contract manufacturers. We expect our gross margins to fluctuate over time, depending on the factors described above.

[0001596532-21-000049:mdna:30]
Gross margin slightly decreased from 64.1% for the year ended December 31, 2019 to 63.9% in 2020. Gross margin was negatively impacted by incremental COVID-19 related supply chain costs and some increased product transition costs, combined with the impact of fixed overhead costs on a lower revenue base.  These negative impacts were partially offset by a reduction in sales to our larger end customers who generally receive larger discounts, and improved service margins as we scale our services organization.

[0001596532-21-000049:mdna:31]
Operating Expenses (in thousands, except percentages)

[0001596532-21-000049:mdna:32]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. The largest component of our operating expenses is personnel costs. Personnel costs consist of wages, benefits, bonuses and, with respect to sales and marketing expenses, sales commissions. Personnel costs also include stock-based compensation and travel expenses.

[0001596532-21-000049:mdna:33]
|  |  | Year Ended December 31, |  |  |
|  |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 486,594 |  |  | 20.9 | % |  | $ | 462,759 |  |  | 19.2 | % |  | $ | 23,835 |  |  | 5.2 | % |
| Sales and marketing |  | 229,366 |  |  | 9.9 |  |  | 213,907 |  |  | 8.9 |  |  | 15,459 |  |  | 7.2 |  |
| General and administrative |  | 66,242 |  |  | 2.9 |  |  | 61,898 |  |  | 2.6 |  |  | 4,344 |  |  | 7.0 |  |
| Total operating expenses |  | $ | 782,202 |  |  | 33.7 | % |  | $ | 738,564 |  |  | 30.7 | % |  | $ | 43,638 |  |  | 5.9 | % |

[0001596532-21-000049:mdna:34]
Research and development.

[0001596532-21-000049:mdna:35]
Research and development expenses consist primarily of personnel costs, prototype expenses, third-party engineering costs, and an allocated portion of facility and IT costs. Our research and development efforts are focused on new product development and maintaining and developing additional functionality for our existing products, including new releases and upgrades to our EOS software and applications. We expect our research and development expenses to increase in absolute dollars as we continue to invest in software development in order to expand the capabilities of our cloud networking platform, introduce new products and features, and build upon our technology leadership.

[0001596532-21-000049:mdna:36]
Research and development expenses increased $23.8 million, or 5.2%, for the year ended December 31, 2020 compared to 2019. The increase was primarily due to a $26.8 million increase in stock-based compensation from new and refresh grants during the current fiscal year, and a $7.8 million increase in acquisition-related expenses and amortization of acquired intangible assets from our acquisition of Big Switch and Awake Security, partially offset by an $11.4 million decrease in new product introduction costs, including third-party engineering and other product development costs.

[0001596532-21-000049:mdna:37]
Sales and marketing.

[0001596532-21-000049:mdna:38]
Sales and marketing expenses consist primarily of personnel costs, marketing, trade shows, and other promotional activities, and an allocated portion of facility and IT costs. We expect our sales and marketing expenses to increase in absolute dollars as we continue to expand our sales and marketing efforts worldwide.

[0001596532-21-000049:mdna:39]
Sales and marketing expenses increased $15.5 million, or 7.2%, for the year ended December 31, 2020 compared to 2019. The increase was driven by increased headcount, resulting in increased compensation costs, including salaries and stock-based compensation, partially offset by a decrease in travel and other sales and marketing activities due to COVID-19.

[0001596532-21-000049:mdna:40]
General and administrative.

[0001596532-21-000049:mdna:41]
General and administrative expenses consist primarily of personnel costs and professional services costs. General and administrative personnel costs include those for our executive, finance, human resources and legal functions. Our professional services costs are primarily related to external legal, accounting, and tax services.

[0001596532-21-000049:mdna:42]
General and administrative expenses increased $4.3 million, or 7.0%, for the year ended December 31, 2020 compared to 2019. The increase was primarily driven by acquisition-related costs from our acquisitions of Big Switch and Awake Security in the current fiscal year.

[0001596532-21-000049:mdna:43]
Other Income, Net (in thousands, except percentages)

[0001596532-21-000049:mdna:44]
Other income, net consists primarily of interest income from our cash, cash equivalents and marketable securities, gains and losses on our investments in privately-held companies, and foreign currency transaction gains and losses.  We expect other income, net may fluctuate in the future as a result of the re-measurement of our private company equity investments upon the occurrence of observable price changes and/or impairments, changes in interest rates or returns on our cash and cash equivalents and marketable securities, and foreign currency exchange rate fluctuations.

[0001596532-21-000049:mdna:45]
|  |  | Year Ended December 31, |  |  |
|  |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Other income, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 27,139 |  |  | 1.2 | % |  | $ | 51,144 |  |  | 2.2 | % |  | $ | (24,005) |  |  | (46.9) | % |
| Gain on sale of marketable securities |  | 9,432 |  |  | 0.4 |  |  | — |  |  | — |  |  | 9,432 |  |  | 100.0 |  |
| Gain on investments in privately-held companies |  | 4,164 |  |  | 0.2 |  |  | 5,427 |  |  | 0.2 |  |  | (1,263) |  |  | (23.3) |  |
| Other income (expense) |  | (1,556) |  |  | (0.1) |  |  | (75) |  |  | — |  |  | (1,481) |  |  | 1,974.7 |  |
| Total other income, net |  | $ | 39,179 |  |  | 1.7 | % |  | $ | 56,496 |  |  | 2.4 | % |  | $ | (17,317) |  |  | (30.7) | % |

[0001596532-21-000049:mdna:46]
The unfavorable change in other income, net, during the year ended December 31, 2020 as compared to 2019 was driven by a $24.0 million decrease in interest income largely due to lower interest rates. This was partially offset by a realized gain of $9.4 million on the sale of marketable securities in the third quarter of the year ended December 31, 2020.

[0001596532-21-000049:mdna:47]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-21-000049:mdna:48]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may also be subject to U.S. income tax. Generally, our U.S. tax obligations are reduced by a credit for foreign income taxes paid on these foreign earnings, which avoids double taxation. Our tax expense to date consists of federal, state and foreign current and deferred income taxes.

[0001596532-21-000049:mdna:49]
|  |  | Year Ended December 31, |  |  |
|  |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Provision for income taxes |  | $ | 104,306 |  |  | 4.5 | % |  | $ | 2,403 |  |  | 0.1 | % |  | $ | 101,903 |  |  | 4,240.7 |  |
| Effective tax rate |  | 14.1 | % |  |  |  | 0.3 | % |  |  |  |  |  |  |

[0001596532-21-000049:mdna:50]
For the years ended December 31, 2020 and 2019, we recorded an expense of $104.3 million and $2.4 million for income taxes, respectively, and our effective tax rate increased from 0.3% in 2019 to 14.1% in 2020. The change in our income taxes was largely attributable to a net tax benefit of $86 million in 2019 resulting from an intra-entity transaction to sell our non-Americas economic and beneficial intellectual property rights.  Further, while we experienced a decrease in worldwide profit before tax in 2020 compared to 2019, the tax benefits attributable to stock-based compensation also decreased, along with an increase in foreign earnings taxed in non-zero rate jurisdictions, resulting in overall higher tax expense. For further information regarding income taxes and the impact on our results of operations and financial position, refer to Note 10. Income Taxes of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K.

[0001596532-21-000049:mdna:51]
Year Ended December 31, 2019 Compared to Year Ended December 31, 2018

[0001596532-21-000049:mdna:52]
Revenue, Cost of Revenue and Gross Profit (in thousands, except percentages)

[0001596532-21-000049:mdna:53]
|  |  | Year Ended December 31, |  |  |
|  |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,021,150 |  |  | 83.8 | % |  | $ | 1,841,100 |  |  | 85.6 | % |  | $ | 180,050 |  |  | 9.8 | % |
| Service |  | 389,556 |  |  | 16.2 |  |  | 310,269 |  |  | 14.4 |  |  | 79,287 |  |  | 25.6 |  |
| Total revenue |  | 2,410,706 |  |  | 100.0 |  |  | 2,151,369 |  |  | 100.0 |  |  | 259,337 |  |  | 12.1 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 792,382 |  |  | 32.9 |  |  | 720,584 |  |  | 33.5 |  |  | 71,798 |  |  | 10.0 |  |
| Service |  | 73,986 |  |  | 3.0 |  |  | 57,408 |  |  | 2.7 |  |  | 16,578 |  |  | 28.9 |  |
| Total cost of revenue |  | 866,368 |  |  | 35.9 |  |  | 777,992 |  |  | 36.2 |  |  | 88,376 |  |  | 11.4 |  |
| Gross profit |  | $ | 1,544,338 |  |  | 64.1 | % |  | $ | 1,373,377 |  |  | 63.8 | % |  | $ | 170,961 |  |  | 12.4 | % |
| Gross margin |  | 64.1 | % |  |  |  | 63.8 | % |  |  |  |  |  |  |

[0001596532-21-000049:mdna:54]
Revenue by Geography (in thousands, except percentages)

[0001596532-21-000049:mdna:55]
|  |  | Year Ended December 31, |
|  |  | 2019 |  | % of Total |  | 2018 |  | % of Total |
| Americas |  | $ | 1,833,163 |  |  | 76.1 | % |  | $ | 1,550,453 |  |  | 72.1 | % |
| Europe, Middle East and Africa |  | 381,651 |  |  | 15.8 |  |  | 414,069 |  |  | 19.2 |  |
| Asia-Pacific |  | 195,892 |  |  | 8.1 |  |  | 186,847 |  |  | 8.7 |  |
| Total revenue |  | $ | 2,410,706 |  |  | 100.0 | % |  | $ | 2,151,369 |  |  | 100.0 | % |

[0001596532-21-000049:mdna:56]
Revenue

[0001596532-21-000049:mdna:57]
Product revenue increased $180.1 million, or 9.8%, in the year ended December 31, 2019 compared to 2018. The increase was primarily driven by increased demand from both new and existing customers, and the recognition of product deferred revenue related to sales in the prior year for which revenue was recognized in 2019. Service revenue increased $79.3 million, or 25.6% in the year ended December 31, 2019 compared to 2018 as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenues represented 23.9% of total revenues in the year ended December 31, 2019, compared to 27.9% in 2018, which was primarily due to a move toward U.S. deployments by certain of our large end customers during 2019. We continue to experience pricing pressure on our products and services due to competition, but demand for our products and growth in our installed base has more than offset this pricing pressure during the year. However, we have experienced reduced and volatile demand from certain of our large end customers during 2019.

[0001596532-21-000049:mdna:58]
Cost of Revenue and Gross Margin

[0001596532-21-000049:mdna:59]
Cost of revenue increased $88.4 million or 11.4% for the year ended December 31, 2019 compared to 2018. The increase in cost of revenue was primarily due to the corresponding increases in product and service revenues.

[0001596532-21-000049:mdna:60]
Gross margin increased to 64.1% for the year ended December 31, 2019 compared to 63.8% in 2018. The increase in gross margin was primarily driven by an increase in product margins due to favorable customer mix, with lower discounts on smaller volume transactions, partially offset by increased product transition costs, including excess and obsolete inventory-related charges.

[0001596532-21-000049:mdna:61]
Operating Expenses (in thousands, except percentages)

[0001596532-21-000049:mdna:62]
|  |  | Year Ended December 31, |  |  |
|  |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 462,759 |  |  | 19.2 | % |  | $ | 442,468 |  |  | 20.6 | % |  | $ | 20,291 |  |  | 4.6 | % |
| Sales and marketing |  | 213,907 |  |  | 8.9 |  |  | 187,142 |  |  | 8.7 |  |  | 26,765 |  |  | 14.3 |  |
| General and administrative |  | 61,898 |  |  | 2.6 |  |  | 65,420 |  |  | 3.0 |  |  | (3,522) |  |  | (5.4) |  |
| Legal settlement |  | — |  |  | — |  |  | 405,000 |  |  | 18.8 |  |  | (405,000) |  |  | (100.0) |  |
| Total operating expenses |  | $ | 738,564 |  |  | 30.7 | % |  | $ | 1,100,030 |  |  | 51.1 | % |  | $ | (361,466) |  |  | (32.9) | % |

[0001596532-21-000049:mdna:63]
Research and development

[0001596532-21-000049:mdna:64]
Research and development expenses increased $20.3 million, or 4.6%, for the year ended December 31, 2019 compared to 2018. The increase was primarily due to a $17.2 million increase in personnel costs driven primarily by headcount growth, and a $7.8 million increase in development-related facilities costs due to facilities expansion and headcount growth, partially offset by a $5.9 million decrease in new product introduction costs, including third-party engineering and other product development costs.

[0001596532-21-000049:mdna:65]
Sales and marketing

[0001596532-21-000049:mdna:66]
Sales and marketing expenses increased $26.8 million, or 14.3%, for the year ended December 31, 2019 compared to 2018. The increase primarily included a $23.4 million increase in personnel costs, which was driven by increased headcount as well as higher sales volumes, resulting in increased compensation costs, including commissions and stock-based compensation.

[0001596532-21-000049:mdna:67]
General and administrative

[0001596532-21-000049:mdna:68]
General and administrative expenses decreased $3.5 million, or 5.4%, for the year ended December 31, 2019 compared to 2018. The decrease was primarily related to a reduced level of litigation activity as a result of the settlement of our litigation with Cisco in August 2018.

[0001596532-21-000049:mdna:69]
Legal settlement

[0001596532-21-000049:mdna:70]
During the three months ended June 30, 2018, we recorded $405.0 million in legal settlement expenses in connection with the Term Sheet that was entered into on August 6, 2018 between the Company and Cisco, which included a $400.0 million payment and $5.0 million of legal fees associated with the settlement. Pursuant to the Term Sheet, the Company and Cisco obtained dismissals of all then ongoing district court and USITC litigation between us. On December 3, 2018, the parties entered into a mutual release and settlement agreement, which superseded the Term Sheet but did not substantially alter the terms.

[0001596532-21-000049:mdna:71]
Other Income, Net (in thousands, except percentages)

[0001596532-21-000049:mdna:72]
|  |  | Year Ended December 31, |  |  |
|  |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Other income, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 51,144 |  |  | 2.2 | % |  | $ | 31,666 |  |  | 1.4 | % |  | $ | 19,478 |  |  | 61.5 | % |
| Interest expense |  | — |  |  | — |  |  | (2,701) |  |  | (0.1) |  |  | 2,701 |  |  | (100.0) |  |
| Gain (loss) on investments in privately-held companies |  | 5,427 |  |  | 0.2 |  |  | (13,800) |  |  | (0.6) |  |  | 19,227 |  |  | (139.3) |  |
| Other income (expense) |  | (75) |  |  | — |  |  | 289 |  |  | — |  |  | (364) |  |  | (126.0) |  |
| Total other income, net |  | $ | 56,496 |  |  | 2.4 | % |  | $ | 15,454 |  |  | 0.7 | % |  | $ | 41,042 |  |  | 265.6 | % |

[0001596532-21-000049:mdna:73]
The favorable change in other income, net, during the year ended December 31, 2019 as compared to 2018 was driven by a $19.5 million increase in interest income, as we continued to generate cash and expand our marketable securities portfolios, and a $19.2 million favorable change on our investments in privately-held companies resulting from the gain on certain investments of $5.4 million in 2019, compared to a net loss of $13.8 million on these investments during 2018. Upon adoption of Accounting Standard Codification Topic 842 - Leases (“ASC 842”) on January 1, 2019, we derecognized the finance lease obligation associated with our build-to-suit lease, and therefore ceased to incur further interest expense as it relates to this obligation.

[0001596532-21-000049:mdna:74]
Provision for (Benefit from) Income Taxes (in thousands, except percentages)

[0001596532-21-000049:mdna:75]
|  |  | Year Ended December 31, |  |  |
|  |  | 2019 |  | 2018 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Provision for (benefit from) income taxes |  | $ | 2,403 |  |  | 0.1 | % |  | $ | (39,314) |  |  | (1.9) | % |  | $ | 41,717 |  |  | (106.1) | % |
| Effective tax rate |  | 0.3 | % |  |  |  | (13.6) | % |  |  |  |  |  |  |

[0001596532-21-000049:mdna:76]
For the years ended December 31, 2019 and 2018, we recorded an expense of $2.4 million and a benefit of $39.3 million for income taxes, respectively. The change in our income taxes was largely attributable to a $96.9 million tax benefit from the Cisco settlement in 2018 and an overall increase in worldwide earnings in 2019, partially offset by a net tax benefit of $86 million in 2019 resulting from an intra-entity transaction to sell our non-Americas economic and beneficial intellectual property rights.

[0001596532-21-000049:mdna:77]
Liquidity and Capital Resources

[0001596532-21-000049:mdna:78]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of December 31, 2020, our total balance of cash, cash equivalents and marketable securities was $2.9 billion, of which approximately $421.0 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-21-000049:mdna:79]
Our cash, cash equivalents and marketable securities are held for general business purposes including the funding of working capital. Our marketable securities investment portfolio is primarily invested in highly-rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and stock repurchases. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-21-000049:mdna:80]
Cash Flows

[0001596532-21-000049:mdna:81]
|  |  | Year Ended December 31, |
|  |  | 2020 |  | 2019 |  | 2018 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 735,114 |  |  | $ | 963,034 |  |  | $ | 503,119 |  |
| Cash (used in) investing activities |  | (608,802) |  |  | (284,072) |  |  | (755,113) |  |
| Cash (used in) provided by financing activities |  | (346,339) |  |  | (217,964) |  |  | 42,851 |  |
| Effect of exchange rate changes |  | 1,966 |  |  | 353 |  |  | (1,390) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | (218,061) |  |  | $ | 461,351 |  |  | $ | (210,533) |  |

[0001596532-21-000049:mdna:82]
Cash Flows from Operating Activities

[0001596532-21-000049:mdna:83]
Our operating activities consist of net income, adjusted for certain non-cash items, and changes in assets and liabilities.

[0001596532-21-000049:mdna:84]
During the year ended December 31, 2020, cash provided by operating activities was $735.1 million, primarily from net income of $634.6 million and net non-cash adjustments to net income of $186.2 million, partially offset by a net increase of $85.7 million in working capital requirements.  The net non-cash adjustments primarily consist of $137.0 million of stock-based compensation expenses and $44.6 million of depreciation and amortization expenses. The increase in working capital primarily consisted of a $235.3 million increase in inventory to help mitigate the impact of COVID-19 related supply chain disruptions, partially offset by a $50.4 million increase in deferred revenue, a $41.1 million increase in accounts payable related to the timing of production receipts, and a $17.1 million increase in other liabilities primarily due to an increase in customer contract liabilities.

[0001596532-21-000049:mdna:85]
During the year ended December 31, 2019, cash provided by operating activities was $963.0 million, primarily from net income of $859.9 million and net non-cash adjustments to net income of $62.4 million, partially offset by a net decrease of $40.8 million in cash from changes in our operating assets and liabilities. Cash outflows from operating activities consisted of an $11.9 million decrease in deferred revenue primarily due to the recognition of product deferred revenue related to contract acceptance terms, largely offset by increased service deferred revenue related to growth in customer service and support contracts, a $60.2 million increase in accounts receivable due to timing of shipments, and an $8.1 million increase in other assets resulting from increased spares inventory to support our customer base. These cash outflows were partially offset by cash inflows of $54.3 million in prepaid expenses and other current assets from a decrease in deferred cost of inventory due to the recognition of product deferred revenue, $23.5 million from an increase in income taxes payable, $20.9 million decrease in inventories due to timing of product shipments and receipts, and $16.4 million from increased accrued liabilities primarily due to an increase in supplier liability reserves for excess and obsolete component inventory.

[0001596532-21-000049:mdna:86]
Cash Flows from Investing Activities

[0001596532-21-000049:mdna:87]
Our investing activities consist of our marketable securities investments, business combinations, investments in privately-held companies, and capital expenditures.

[0001596532-21-000049:mdna:88]
During the year ended December 31, 2020, cash used in investing activities was $608.8 million, primarily consisting of purchases of available-for-sale securities of $2.7 billion, $227.4 million for the acquisition of Big Switch and Awake Security, and purchases of property, equipment and intangible assets of 15.4 million, partially offset by proceeds of $1.5 billion from maturities of marketable securities, proceeds from the sale of marketable securities of $773.0 million and proceeds from the sale of one of our investments in privately-held companies of $3.4 million.

[0001596532-21-000049:mdna:89]
During the year ended December 31, 2019, cash used in investing activities was $284.1 million, primarily consisting of purchases of available-for-sale securities of $1.5 billion, and purchases of property and

[0001596532-21-000049:mdna:90]
equipment of 15.8 million, partially offset by proceeds of $1.2 billion from maturities of marketable securities and proceeds from the sale of one of our investments in privately-held companies of $28.2 million.

[0001596532-21-000049:mdna:91]
Cash Flows from Financing Activities

[0001596532-21-000049:mdna:92]
Our financing activities consist of proceeds from the issuance of our common stock under employee equity incentive plans, offset by repurchases of our common stock.

[0001596532-21-000049:mdna:93]
During the year ended December 31, 2020, cash used in financing activities was $346.3 million, consisting primarily of payments for repurchases of our common stock of $395.2 million and taxes paid of $8.7 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $57.6 million.

[0001596532-21-000049:mdna:94]
During the year ended December 31, 2019, cash used in financing activities was $218.0 million, consisting primarily of payments for repurchases of our common stock of $266.1 million and taxes paid of $9.2 million upon vesting of restricted stock units, partially offset by proceeds from the issuance of common stock under employee equity incentive plans of $57.4 million.

[0001596532-21-000049:mdna:95]
Stock Repurchase Program

[0001596532-21-000049:mdna:96]
We have periodically repurchased our common stock pursuant to our Repurchase Program authorized by our board of directors in April 2019. The Repurchase Program allows for stock repurchases of up to $1.0 billion over three years and these repurchases are to be funded from operating cash flows. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of December 31, 2020, the remaining authorized amount for repurchases under the Repurchase Program was $338.7 million. Refer to Note 8. Stockholders' Equity and Stock-Based Compensation of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K for further discussion.

[0001596532-21-000049:mdna:97]
Off-Balance Sheet Arrangements

[0001596532-21-000049:mdna:98]
As of December 31, 2020, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-21-000049:mdna:99]
Contractual Obligations and Commitments

[0001596532-21-000049:mdna:100]
Our contractual commitments will have an impact on our future liquidity. Our contractual obligations represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalent and marketable securities.

[0001596532-21-000049:mdna:101]
The following summarizes our contractual obligations and commitments as of December 31, 2020 (in thousands):

[0001596532-21-000049:mdna:102]
|  |  | Payments Due by Period |
|  |  | Total |  | Less than1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than5 Years |
| Operating lease obligations |  | 104,258 |  |  | 21,770 |  |  | 41,423 |  |  | 21,139 |  |  | 19,926 |  |
| Purchase commitments with contract manufacturers and suppliers |  | 421,857 |  |  | 421,857 |  |  | — |  |  | — |  |  | — |  |
| Other non-cancellable purchase obligations |  | 32,103 |  |  | 32,103 |  |  | — |  |  | — |  |  |  |
| Transition tax payable |  | 6,343 |  |  | — |  |  | — |  |  | 6,343 |  |  | — |  |
| Total |  | $ | 564,561 |  |  | $ | 475,730 |  |  | $ | 41,423 |  |  | $ | 27,482 |  |  | $ | 19,926 |  |

[0001596532-21-000049:mdna:103]
The contractual obligation table above excludes tax liabilities of $46.7 million related to uncertain tax positions because we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-21-000049:mdna:104]
In connection with the Tax Cuts and Jobs Act of 2017, we recorded a federal income tax payable for transition tax on the mandatory deemed repatriation of foreign earnings that will be payable over an eight-year period. The amounts included in the table above represent the remaining federal income tax payable after applying the first year's installment payment and early payments of future installments.

[0001596532-21-000049:mdna:105]
Critical Accounting Policies and Estimates

[0001596532-21-000049:mdna:106]
We have prepared our consolidated financial statements in accordance with accounting principles generally accepted in the United States ("GAAP" or "U.S. GAAP") and include our accounts and the accounts of our wholly owned subsidiaries. The preparation of these consolidated financial statements requires our management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities at the date of the financial statements, disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the applicable periods. We base our estimates, assumptions and judgments on historical experience and on various other factors that we believe to be reasonable under the circumstances. Different assumptions and judgments would change the estimates used in the preparation of our consolidated financial statements, which, in turn, could change the results from those reported. We evaluate our estimates, assumptions and judgments on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. The critical accounting estimates, assumptions and judgments that we believe have the most significant impact on our consolidated financial statements are the following:

[0001596532-21-000049:mdna:107]
Revenue Recognition

[0001596532-21-000049:mdna:108]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with PCS. We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

[0001596532-21-000049:mdna:109]
•Identification of the contract, or contracts, with a customer

[0001596532-21-000049:mdna:110]
•Identification of the performance obligations in the contract

[0001596532-21-000049:mdna:111]
•Determination of the transaction price

[0001596532-21-000049:mdna:112]
•Allocation of the transaction price to the performance obligations in the contract

[0001596532-21-000049:mdna:113]
•Recognition of revenue when (or as) we satisfy the performance obligation

[0001596532-21-000049:mdna:114]
Post-Contract Customer Support

[0001596532-21-000049:mdna:115]
PCS, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernible pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and address customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-21-000049:mdna:116]
Contracts with Multiple Performance Obligations

[0001596532-21-000049:mdna:117]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts which contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is

[0001596532-21-000049:mdna:118]
required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

[0001596532-21-000049:mdna:119]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to, the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

[0001596532-21-000049:mdna:120]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

[0001596532-21-000049:mdna:121]
Most of our contracts with customers have payment terms of 30 days, with some large high volume customers having terms of up to 60 days. We have determined that our contracts generally do not include a significant financing component because the Company and the customer have specific business reasons other than financing for entering into such contracts. Specifically, both we and our customers seek to ensure the customer has a simplified way of purchasing our products and services.

[0001596532-21-000049:mdna:122]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

[0001596532-21-000049:mdna:123]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical return rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-21-000049:mdna:124]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

[0001596532-21-000049:mdna:125]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

[0001596532-21-000049:mdna:126]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-21-000049:mdna:127]
Inventories primarily consist of finished goods and strategic components, primarily integrated circuits. Inventories are stated at the lower of cost (computed using the first-in, first-out method) and net realizable value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value.

[0001596532-21-000049:mdna:128]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts. We record a liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with our contract manufacturers or suppliers for quantities in excess of our demand forecasts or that are considered obsolete due to manufacturing and engineering change orders resulting from design changes.

[0001596532-21-000049:mdna:129]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and/or outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer/supplier liabilities.

[0001596532-21-000049:mdna:130]
Income Taxes

[0001596532-21-000049:mdna:131]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-21-000049:mdna:132]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-21-000049:mdna:133]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-21-000049:mdna:134]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.

[0001596532-21-000049:mdna:135]
The U.S. tax rules require U.S. tax on foreign earnings, known as global intangible low taxed income (“GILTI”). Under U.S. GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”).  We selected the deferred method of accounting and recorded the associated basis differences anticipated to influence prospective GILTI calculations.

[0001596532-21-000049:mdna:136]
Loss Contingencies

[0001596532-21-000049:mdna:137]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgment and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We will record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements and (ii) the range of loss can be

[0001596532-21-000049:mdna:138]
reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.

[0001596532-21-000049:mdna:139]
Recent Accounting Pronouncements

[0001596532-21-000049:mdna:140]
Refer to “Recent Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K.
