# ANET notes — 0001596532-21-000255


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-21-000255:notes:1]
[same as prior period, unchanged from 0001596532-21-000149:notes:1]

[0001596532-21-000255:notes:2]
[same as prior period, unchanged from 0001596532-21-000149:notes:2]

[0001596532-21-000255:notes:3]
[same as prior period, unchanged from 0001596532-21-000149:notes:3]

[0001596532-21-000255:notes:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2021, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2020 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

[0001596532-21-000255:notes:5]
[same as prior period, unchanged from 0001596532-21-000149:notes:5]

[0001596532-21-000255:notes:6]
[same as prior period, unchanged from 0001596532-21-000149:notes:6]

[0001596532-21-000255:notes:7]
The preparation of the condensed consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the condensed consolidated financial statements and accompanying notes. These estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; valuation of goodwill and acquisition-related intangible assets; accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; estimate of useful lives of long-lived assets including intangible assets; valuation of inventory and contract manufacturer/supplier liabilities; and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

[0001596532-21-000255:notes:8]
[same as prior period, unchanged from 0001596532-21-000149:notes:8]

[0001596532-21-000255:notes:9]
The global coronavirus ("COVID-19") pandemic and resulting mitigation efforts by governments around the world to contain or slow its spread have negatively impacted the global economy and disrupted business activities.

[0001596532-21-000255:notes:10]
Our contract manufacturers and suppliers have experienced delays in component sourcing, production and export of their products, which have negatively impacted our supply chain and could negatively impact our business in the future. While we have experienced some recovery in demand from our customers in recent quarters, we believe any renewed COVID-19- related disruptions could result in negative impacts on demand in future periods. However, the extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, including the duration and spread of the pandemic and related mitigation efforts, the impact to our customers, partners, contract manufacturers and supply chain, as well as restrictions on travel and transport, all of which are uncertain and cannot be predicted. Management continues to actively monitor the impact of the pandemic on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

[0001596532-21-000255:notes:11]
Recently Adopted Accounting Pronouncements

[0001596532-21-000255:notes:12]
[same as prior period, unchanged from 0001596532-21-000149:notes:12]

[0001596532-21-000255:notes:13]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in Topic 740 and amending existing guidance to improve consistent application. This new standard is effective for our interim and annual periods beginning January 1, 2021. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. We adopted this new standard on January 1, 2021 with no material impact on our condensed consolidated financial statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-21-000255:notes:14]
[same as prior period, unchanged from 0001596532-21-000149:notes:14]

[0001596532-21-000255:notes:15]
|  |  | June 30, 2021 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 443,597 |  |  | $ | — |  |  | $ | — |  |  | $ | 443,597 |  |  | $ | 443,597 |  |  | $ | — |  |  | $ | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 60,959 |  |  | — |  |  | — |  |  | 60,959 |  |  | — |  |  | 60,959 |  |  | — |  |
| Certificate of deposits(1) |  | 73,870 |  |  | — |  |  | — |  |  | 73,870 |  |  | — |  |  | 73,870 |  |  | — |  |
| U.S. government notes |  | 832,903 |  |  | 111 |  |  | (214) |  |  | 832,800 |  |  | 832,800 |  |  | — |  |  | — |  |
| Corporate bonds |  | 1,083,824 |  |  | 532 |  |  | (578) |  |  | 1,083,778 |  |  | — |  |  | 1,083,778 |  |  | — |  |
| Agency securities |  | 336,455 |  |  | 188 |  |  | (35) |  |  | 336,608 |  |  | — |  |  | 336,608 |  |  | — |  |
|  |  | 2,388,011 |  |  | 831 |  |  | (827) |  |  | 2,388,015 |  |  | 832,800 |  |  | 1,555,215 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,236 |  |  | — |  |  | — |  |  | 4,236 |  |  | 4,236 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 2,835,844 |  |  | $ | 831 |  |  | $ | (827) |  |  | $ | 2,835,848 |  |  | $ | 1,280,633 |  |  | $ | 1,555,215 |  |  | $ | — |  |

[0001596532-21-000255:notes:16]
[same as prior period, unchanged from 0001596532-21-000149:notes:16]

[0001596532-21-000255:notes:17]
[same as prior period, unchanged from 0001596532-21-000149:notes:17]

[0001596532-21-000255:notes:18]
(1) As of June 30, 2021 and December 31, 2020, all of our certificates of deposits were domestic deposits.

[0001596532-21-000255:notes:19]
As of June 30, 2021 and December 31, 2020, total unrealized losses of our marketable securities were immaterial. We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. We expect to realize the full value of these investments upon maturity or sale and therefore, we do not consider any of our marketable securities to be impaired as of June 30, 2021. We did not recognize any credit losses or non-credit-related impairments related to our available-for-sale marketable securities during the three and six months ended June 30, 2021.

[0001596532-21-000255:notes:20]
As of June 30, 2021, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale marketable securities, by remaining contractual maturity, are as follows (in thousands):

[0001596532-21-000255:notes:21]
|  |  | June 30, 2021 |
| Due in 1 year or less |  | $ | 1,258,837 |  |
| Due in 1 year through 2 years |  | 1,129,178 |  |
| Total marketable securities |  | $ | 2,388,015 |  |

[0001596532-21-000255:notes:22]
The weighted-average remaining duration of our current marketable securities is approximately 1.0 year as of June 30, 2021.  As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption "Marketable securities" on the condensed consolidated balance sheets.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-21-000255:notes:23]
[same as prior period, unchanged from 0001596532-21-000149:notes:23]

[0001596532-21-000255:notes:24]
The reconciliation of cash, cash equivalents and restricted cash reported on the condensed consolidated balance sheets to the total of the same such amounts in the condensed consolidated statements of cash flows is as follows (in thousands):

[0001596532-21-000255:notes:25]
|  |  | June 30, 2021 |  | December 31, 2020 |
| Cash and cash equivalents |  | $ | 893,688 |  |  | $ | 893,219 |  |
| Restricted cash included in other assets |  | 4,236 |  |  | 4,235 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 897,924 |  |  | $ | 897,454 |  |

[0001596532-21-000255:notes:26]
[same as prior period, unchanged from 0001596532-21-000149:notes:26]

[0001596532-21-000255:notes:27]
[same as prior period, unchanged from 0001596532-21-000149:notes:27]

[0001596532-21-000255:notes:28]
|  |  | June 30, 2021 |  | December 31, 2020 |
| Accounts receivable |  | $ | 368,817 |  |  | $ | 394,037 |  |
| Allowance for doubtful accounts |  | (587) |  |  | (659) |  |
| Product sales rebate and returns reserve |  | (4,016) |  |  | (3,838) |  |
| Accounts receivable, net |  | $ | 364,214 |  |  | $ | 389,540 |  |

[0001596532-21-000255:notes:29]
[same as prior period, unchanged from 0001596532-21-000149:notes:29]

[0001596532-21-000255:notes:30]
[same as prior period, unchanged from 0001596532-21-000149:notes:30]

[0001596532-21-000255:notes:31]
|  |  | June 30, 2021 |  | December 31, 2020 |
| Raw materials |  | $ | 271,055 |  |  | $ | 219,218 |  |
| Finished goods |  | 272,144 |  |  | 260,450 |  |
| Total inventories |  | $ | 543,199 |  |  | $ | 479,668 |  |

[0001596532-21-000255:notes:32]
[same as prior period, unchanged from 0001596532-21-000149:notes:32]

[0001596532-21-000255:notes:33]
[same as prior period, unchanged from 0001596532-21-000149:notes:33]

[0001596532-21-000255:notes:34]
|  |  | June 30, 2021 |  | December 31, 2020 |
| Inventory deposits |  | $ | 22,386 |  |  | $ | 18,783 |  |
| Prepaid income taxes |  | 18,479 |  |  | 267 |  |
| Other current assets |  | 81,017 |  |  | 60,556 |  |
| Other prepaid expenses and deposits |  | 17,397 |  |  | 15,316 |  |
| Total prepaid expenses and other current assets |  | $ | 139,279 |  |  | $ | 94,922 |  |

[0001596532-21-000255:notes:35]
[same as prior period, unchanged from 0001596532-21-000149:notes:35]

[0001596532-21-000255:notes:36]
[same as prior period, unchanged from 0001596532-21-000149:notes:36]

[0001596532-21-000255:notes:37]
|  |  | June 30, 2021 |  | December 31, 2020 |
| Equipment and machinery |  | $ | 77,361 |  |  | $ | 70,655 |  |
| Computer hardware and software |  | 43,087 |  |  | 40,081 |  |
| Leasehold improvements |  | 30,502 |  |  | 31,448 |  |
| Furniture and fixtures |  | 3,592 |  |  | 3,787 |  |
| Construction-in-process |  | 1,214 |  |  | 1,441 |  |
| Property and equipment, gross |  | 155,756 |  |  | 147,412 |  |
| Less: accumulated depreciation |  | (123,394) |  |  | (115,181) |  |
| Property and equipment, net |  | $ | 32,362 |  |  | $ | 32,231 |  |

[0001596532-21-000255:notes:38]
Depreciation expense was $4.8 million and $5.1 million for the three months ended June 30, 2021 and 2020, respectively, and $9.7 million and $10.3 million for the six months ended June 30, 2021 and 2020, respectively.

[0001596532-21-000255:notes:39]
[same as prior period, unchanged from 0001596532-21-000149:notes:39]

[0001596532-21-000255:notes:40]
[same as prior period, unchanged from 0001596532-21-000149:notes:40]

[0001596532-21-000255:notes:41]
|  |  | June 30, 2021 |  | December 31, 2020 |
| Accrued payroll related costs |  | $ | 64,028 |  |  | $ | 73,634 |  |
| Accrued manufacturing costs |  | 63,260 |  |  | 43,181 |  |
| Accrued product development costs |  | 15,355 |  |  | 6,733 |  |
| Accrued warranty costs |  | 8,995 |  |  | 9,314 |  |
| Other |  | 11,607 |  |  | 10,495 |  |
| Total accrued liabilities |  | $ | 163,245 |  |  | $ | 143,357 |  |

[0001596532-21-000255:notes:42]
[same as prior period, unchanged from 0001596532-21-000149:notes:42]

[0001596532-21-000255:notes:43]
[same as prior period, unchanged from 0001596532-21-000149:notes:43]

[0001596532-21-000255:notes:44]
|  |  | Six Months Ended June 30, |
|  |  | 2021 |  | 2020 |
| Warranty accrual, beginning of period |  | $ | 9,314 |  |  | $ | 6,742 |  |
| Liabilities accrued for warranties issued during the period |  | 5,603 |  |  | 2,181 |  |
| Warranty costs incurred during the period |  | (5,922) |  |  | (2,852) |  |
| Warranty accrual, end of period |  | $ | 8,995 |  |  | $ | 6,071 |  |

[0001596532-21-000255:notes:45]
[same as prior period, unchanged from 0001596532-21-000149:notes:45]

[0001596532-21-000255:notes:46]
The following table summarizes the beginning and ending balances of our contract assets included in "Prepaid and other current assets" on the condensed consolidated balance sheets (in thousands):

[0001596532-21-000255:notes:47]
|  |  | Six Months Ended June 30, |
|  |  | 2021 |  |  |  |  |
| Contract assets, beginning balance |  | $ | 16,380 |  |  |  |  |  |
| Contract assets, ending balance |  | 11,935 |  |  |  |  |  |

[0001596532-21-000255:notes:48]
[same as prior period, unchanged from 0001596532-21-000149:notes:48]

[0001596532-21-000255:notes:49]
[same as prior period, unchanged from 0001596532-21-000149:notes:49]

[0001596532-21-000255:notes:50]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Contract liabilities, beginning balance |  | $ | 80,465 |  |  | $ | 64,325 |  |  | $ | 85,957 |  |  | $ | 61,050 |  |
| Less: Revenue recognized from beginning balance |  | (8,482) |  |  | (5,735) |  |  | (18,482) |  |  | (11,722) |  |
| Less: Beginning balance reclassified to deferred revenue |  | (3,856) |  |  | (2,757) |  |  | (12,710) |  |  | (2,226) |  |
| Add: Contract liabilities recognized |  | 15,227 |  |  | 11,435 |  |  | 28,589 |  |  | 20,166 |  |
| Contract liabilities, ending balance |  | $ | 83,354 |  |  | $ | 67,268 |  |  | $ | 83,354 |  |  | $ | 67,268 |  |

[0001596532-21-000255:notes:51]
As of June 30, 2021 and December 31, 2020, $35.9 million and $34.5 million of our contract liabilities, respectively, were included in "Other current liabilities" with the remaining balances included in "Other long-term liabilities" on the condensed consolidated balance sheets.

[0001596532-21-000255:notes:52]
[same as prior period, unchanged from 0001596532-21-000149:notes:52]

[0001596532-21-000255:notes:53]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Deferred revenue, beginning balance |  | $ | 720,031 |  |  | $ | 596,775 |  |  | $ | 650,827 |  |  | $ | 575,288 |  |
| Less: Revenue recognized from beginning balance |  | (145,556) |  |  | (104,480) |  |  | (222,865) |  |  | (178,264) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 171,615 |  |  | 85,216 |  |  | 318,128 |  |  | 180,487 |  |
| Deferred revenue, ending balance |  | $ | 746,090 |  |  | $ | 577,511 |  |  | $ | 746,090 |  |  | $ | 577,511 |  |

[0001596532-21-000255:notes:54]
As of June 30, 2021, other performance obligations of $169.2 million were comprised mainly of unbilled multi-year PCS contract amounts that will be recognized as revenue in future periods.

[0001596532-21-000255:notes:55]
[same as prior period, unchanged from 0001596532-21-000149:notes:55]

[0001596532-21-000255:notes:56]
Revenue from total remaining performance obligations represents contract liabilities, deferred revenue and unbilled contract revenue that will be recognized in future periods. As of June 30, 2021, approximately $998.7 million of revenue is expected to be recognized from remaining performance obligations, of which approximately 83% is expected to be recognized over the next two years and approximately 17% is expected to be recognized during the third to the fifth year.

[0001596532-21-000255:notes:57]
[same as prior period, unchanged from 0001596532-21-000149:notes:58]

[0001596532-21-000255:notes:58]
[same as prior period, unchanged from 0001596532-21-000149:notes:59]

[0001596532-21-000255:notes:59]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Interest income |  | $ | 1,872 |  |  | $ | 8,668 |  |  | $ | 3,917 |  |  | $ | 20,330 |  |
| Other income (expense), net |  | (153) |  |  | (412) |  |  | (623) |  |  | 83 |  |
| Total |  | $ | 1,719 |  |  | $ | 8,256 |  |  | $ | 3,294 |  |  | $ | 20,413 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-21-000255:notes:60]
The following table summarizes the activity related to our contract liabilities (in thousands):


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-21-000255:notes:61]
[same as prior period, unchanged from 0001596532-21-000149:notes:61]

[0001596532-21-000255:notes:62]
Our investments in privately-held companies do not have readily-determinable fair values. Their initial cost is adjusted to fair value on a non-recurring basis based on observable price changes from orderly transactions of identical or similar securities of the same issuer, or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to these securities. In addition, the valuation requires management judgment due to the absence of market price and lack of liquidity. The following table summarizes the activity related to our investments in privately-held companies as of June 30, 2021 and December 31, 2020 (in thousands):

[0001596532-21-000255:notes:63]
|  |  | June 30, 2021 |  | December 31, 2020 |
| Cost of investments |  | $ | 8,333 |  |  | $ | 3,000 |  |
| Cumulative impairment |  | — |  |  | — |  |
| Cumulative upward adjustment |  | 5,314 |  |  | 5,314 |  |
| Carrying amount of investments |  | $ | 13,647 |  |  | $ | 8,314 |  |

[0001596532-21-000255:notes:64]
During the three and six months ended June 30, 2021 and June 30, 2020, there were no realized or unrealized gains or losses recorded.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-21-000255:notes:65]
Commitments and Contingencies
Purchase Commitments

[0001596532-21-000255:notes:66]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of June 30, 2021, we had non-cancellable purchase commitments of $1,057.5 million, of which $1,019.0 million was to our contract manufacturers and suppliers.  In addition, we had deposits to our contract manufacturers to secure our purchase commitments in the amount of $25.1 million and $21.5 million as of June 30, 2021 and December 31, 2020, respectively. These deposits are included in “Prepaid expenses and other current assets” and “Other assets” on the condensed consolidated balance sheets.

[0001596532-21-000255:notes:67]
Guarantees

[0001596532-21-000255:notes:68]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions

[0001596532-21-000255:notes:69]
and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-21-000255:notes:70]
Legal Proceedings

[0001596532-21-000255:notes:71]
WSOU Investments, LLC

[0001596532-21-000255:notes:72]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations.

[0001596532-21-000255:notes:73]
We intend to vigorously defend against the claims brought against us by WSOU. However, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-21-000255:notes:74]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated. However, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-21-000255:notes:75]
Other matters

[0001596532-21-000255:notes:76]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-21-000255:notes:77]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of June 30, 2021, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-21-000255:notes:78]
Stockholders’ Equity and Stock-Based Compensation
Stock Repurchase Program

[0001596532-21-000255:notes:79]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the "Repurchase Program").  This authorization allows us to repurchase shares of our common stock and is funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the "Exchange Act") or a combination of the foregoing. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of June 30, 2021, the remaining authorized amount for stock repurchases under this program was approximately $237.3 million.

[0001596532-21-000255:notes:80]
A summary of the stock repurchase activity under the Repurchase Program for the six months ended June 30, 2021 is as follows (in thousands, except per share amounts):

[0001596532-21-000255:notes:81]
|  |  |  |  | Six Months Ended |
|  |  |  |  | June 30, 2021 |
| Aggregate purchase price |  |  |  | $ | 101,355 |  |
| Shares repurchased |  |  |  | 367 |  |
| Average price paid per share |  |  |  | $ | 275.88 |  |

[0001596532-21-000255:notes:82]
There was no stock repurchase activity for the three months ended June 30, 2021. The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings and common stock in our condensed consolidated statements of stockholders' equity.  All shares repurchased under the Repurchase Program have been retired.

[0001596532-21-000255:notes:83]
Equity Award Plan Activities

[0001596532-21-000255:notes:84]
2014 Equity Incentive Plan

[0001596532-21-000255:notes:85]
The 2014 Equity Incentive Plan (the “2014 Plan”) provides for the granting of Incentive Stock Options (“ISOs”), Non-statutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”).  The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year by the lesser of (i) 12,500,000 shares, (ii) 3% of the outstanding shares of our common stock on the last day of our immediately preceding fiscal year, or (iii) such other amount as determined by our board of directors. Effective January 1, 2021, our board of directors authorized an increase of 2,285,228 shares to the shares available for issuance under the 2014 Plan.  As of June 30, 2021, there remained approximately 23.0 million shares available for issuance under the 2014 Plan.

[0001596532-21-000255:notes:86]
2014 Employee Stock Purchase Plan

[0001596532-21-000255:notes:87]
Effective January 1, 2021, our board of directors authorized an increase of 761,742 shares to the shares available for issuance under our 2014 Employee Stock Purchase Plan (the “ESPP”).  Pursuant to the ESPP, the 2021 share increase was determined based on the lesser of 1% of the total shares of common stock outstanding on December 31, 2020, 2,500,000 shares, or such amount as determined by our board of directors. During the six months ended June 30, 2021, we issued 56,326 shares at a weighted-average purchase price of $182.76 per share under the ESPP. As of June 30, 2021, there remained 4.6 million shares available for issuance under the ESPP.

[0001596532-21-000255:notes:88]
Stock Option Activities

[0001596532-21-000255:notes:89]
The following table summarizes the option activity under our stock plans and related information (in thousands, except years and per share amounts):

[0001596532-21-000255:notes:90]
|  |  | Options Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding |
| Balance—December 31, 2020 |  | 3,430 |  |  | $ | 45.17 |  |  | 3.6 |  | $ | 841,659 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (538) |  |  | 30.81 |  |  |  |  |  |
| Options canceled |  | (18) |  |  | 38.62 |  |  |  |  |  |
| Balance—June 30, 2021 |  | 2,874 |  |  | $ | 47.90 |  |  | 3.2 |  | $ | 903,398 |  |
| Vested and exercisable—June 30, 2021 |  | 2,059 |  |  | $ | 36.79 |  |  | 2.8 |  | $ | 670,147 |  |

[0001596532-21-000255:notes:91]
Restricted Stock Unit (RSU) Activities

[0001596532-21-000255:notes:92]
A summary of the RSU activity is presented below (in thousands, except years and per share amounts):

[0001596532-21-000255:notes:93]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2020 |  | 1,816 |  |  | $ | 215.68 |  |  | 1.8 |  | $ | 527,574 |  |
| RSUs granted |  | 671 |  |  | 347.89 |  |  |  |  |  |
| RSUs vested |  | (280) |  |  | 202.72 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (85) |  |  | 232.83 |  |  |  |  |  |
| Unvested balance—June 30, 2021 |  | 2,122 |  |  | $ | 258.52 |  |  | 1.9 |  | $ | 768,921 |  |

[0001596532-21-000255:notes:94]
In the six months ended June 30, 2021, we granted 69,620 performance-based RSUs (“PRSUs”) to our CEO and other key employees that include both service and performance-based conditions.

[0001596532-21-000255:notes:95]
These PRSUs will vest over three to four years and the ultimate number of shares eligible to vest will vary between 0% and 200% of the amount granted based on the achievement of certain performance metrics over the vesting period and each holder’s continued employment with Arista.

[0001596532-21-000255:notes:96]
Stock-Based Compensation Expense

[0001596532-21-000255:notes:97]
The following table summarizes the stock-based compensation expense related to our equity awards (in thousands):

[0001596532-21-000255:notes:98]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Cost of revenue |  | $ | 1,796 |  |  | $ | 1,585 |  |  | $ | 3,196 |  |  | $ | 2,912 |  |
| Research and development |  | 23,139 |  |  | 19,378 |  |  | 45,121 |  |  | 35,306 |  |
| Sales and marketing |  | 11,368 |  |  | 8,277 |  |  | 21,453 |  |  | 14,673 |  |
| General and administrative |  | 8,641 |  |  | 3,682 |  |  | 12,727 |  |  | 7,587 |  |
| Total stock-based compensation |  | $ | 44,944 |  |  | $ | 32,922 |  |  | $ | 82,497 |  |  | $ | 60,478 |  |

[0001596532-21-000255:notes:99]
As of June 30, 2021, there were $550.3 million of unamortized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 3.4 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-21-000255:notes:100]
[same as prior period, unchanged from 0001596532-21-000149:notes:100]

[0001596532-21-000255:notes:101]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |  |  |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 196,888 |  |  | $ | 144,793 |  |  | $ | 377,254 |  |  | $ | 283,224 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share, basic |  | 76,461 |  |  | 75,808 |  |  | 76,384 |  |  | 76,036 |  |  |  |  |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options and RSUs |  | 3,191 |  |  | 3,486 |  |  | 3,235 |  |  | 3,580 |  |  |  |  |  |
| Employee stock purchase plan |  | 58 |  |  | 4 |  |  | 58 |  |  | 4 |  |  |  |  |  |
| Weighted-average shares used in computing net income per share, diluted |  | 79,710 |  |  | 79,298 |  |  | 79,677 |  |  | 79,620 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.58 |  |  | $ | 1.91 |  |  | $ | 4.94 |  |  | $ | 3.72 |  |  |  |  |  |
| Diluted |  | $ | 2.47 |  |  | $ | 1.83 |  |  | $ | 4.73 |  |  | $ | 3.56 |  |  |  |  |  |

[0001596532-21-000255:notes:102]
[same as prior period, unchanged from 0001596532-21-000149:notes:102]

[0001596532-21-000255:notes:103]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |  |  |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |
| Stock options and RSUs |  | 101 |  |  | 334 |  |  | 115 |  |  | 467 |  |  |  |  |  |
| Employee stock purchase plan |  | 20 |  |  | 149 |  |  | 15 |  |  | 159 |  |  |  |  |  |
| Total |  | 121 |  |  | 483 |  |  | 130 |  |  | 626 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-21-000255:notes:104]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |  |  |  |  |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |
|  |  | (in thousands, except percentages) |  | (in thousands, except percentages) |  |  |  |  |
| Income before income taxes |  | $ | 221,084 |  |  | $ | 175,245 |  |  | $ | 428,951 |  |  | $ | 337,064 |  |  |  |  |  |
| Provision for income taxes |  | 24,196 |  |  | 30,452 |  |  | 51,697 |  |  | 53,840 |  |  |  |  |  |
| Effective tax rate |  | 10.9 | % |  | 17.4 | % |  | 12.1 | % |  | 16.0 | % |  |  |  |  |

[0001596532-21-000255:notes:105]
The change in effective tax rates in the three and six months ended June 30, 2021, as compared to the same periods in 2020, was primarily due to an increase in tax benefits attributable to stock-based compensation, combined with a favorable change in jurisdictional mix of earnings.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-21-000255:notes:106]
Geographical Information  
    We operate in one reportable segment. The following table represents revenue based on customers’ shipping addresses (in thousands):

[0001596532-21-000255:notes:107]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Americas |  | $ | 514,149 |  |  | $ | 435,829 |  |  | $ | 1,016,021 |  |  | $ | 836,489 |  |
| Europe, Middle East and Africa |  | 112,048 |  |  | 63,977 |  |  | 208,322 |  |  | 136,601 |  |
| Asia-Pacific |  | 81,122 |  |  | 40,764 |  |  | 150,538 |  |  | 90,509 |  |
| Total revenue |  | $ | 707,319 |  |  | $ | 540,570 |  |  | $ | 1,374,881 |  |  | $ | 1,063,599 |  |

[0001596532-21-000255:notes:108]
Long-lived assets, net, excluding intercompany receivables, investments in subsidiaries, privately-held equity investments and deferred tax assets, by location are summarized as follows (in thousands):

[0001596532-21-000255:notes:109]
|  |  | June 30, 2021 |  | December 31, 2020 |
| United States |  | $ | 23,097 |  |  | $ | 24,110 |  |
| International |  | 9,265 |  |  | 8,121 |  |
| Total |  | $ | 32,362 |  |  | $ | 32,231 |  |


## us-gaap:SubsequentEventsTextBlock

[0001596532-21-000255:notes:110]
Subsequent event     Subsequent to the end of the quarter, on July 20, 2021, we finalized a commitment to acquire land and all improvements thereon for a total consideration of approximately $40.0 million. We expect to fund payment of this amount in the third quarter of 2021.
