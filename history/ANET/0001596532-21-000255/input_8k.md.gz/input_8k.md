# ANET 8-K — 0001596532-21-000253 filed 2021-08-02

## item codes, every 8-K on or before 2021-08-03

- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2021-08-03

- none on or before 2021-08-03

## item 2.02 — earnings release, exhibit 99.1

[0001596532-21-000253:8k_2_02:1]
EX-99.1
2
ex991q221-earningsrelease.htm
EX-99.1

[0001596532-21-000253:8k_2_02:2]
Document

[0001596532-21-000253:8k_2_02:3]
Exhibit 99.1

[0001596532-21-000253:8k_2_02:4]
Arista Networks, Inc. Reports Second Quarter 2021 Financial Results

[0001596532-21-000253:8k_2_02:5]
SANTA CLARA, Calif.- August 2, 2021 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in cognitive cloud networking solutions for large datacenter and campus environments, today announced financial results for its second quarter ended June 30, 2021.

[0001596532-21-000253:8k_2_02:6]
Second Quarter Financial Highlights

[0001596532-21-000253:8k_2_02:7]
•Revenue of $707.3 million, an increase of 6.0% compared to the first quarter of 2021, and an increase of 30.8% from the second quarter of 2020.

[0001596532-21-000253:8k_2_02:8]
•GAAP gross margin of 64.2%, compared to GAAP gross margin of 63.7% in the first quarter of 2021 and 63.7% in the second quarter of 2020.

[0001596532-21-000253:8k_2_02:9]
•Non-GAAP gross margin of 65.2%, compared to non-GAAP gross margin of 64.7% in the first quarter of 2021 and 64.7% in the second quarter of 2020.

[0001596532-21-000253:8k_2_02:10]
•GAAP net income of $196.9 million, or $2.47 per diluted share, compared to GAAP net income of $144.8 million, or $1.83 per diluted share in the second quarter of 2020.

[0001596532-21-000253:8k_2_02:11]
•Non-GAAP net income of $216.8 million, or $2.72 per diluted share, compared to non-GAAP net income of $167.0 million, or $2.11 per diluted share in the second quarter of 2020.

[0001596532-21-000253:8k_2_02:12]
“Our record second quarter reflects continued momentum and diversification across our top verticals and product-lines,” said Jayshree Ullal, Arista's president and CEO. “We are on the cusp of network software and data driven transformation and look forward to delighting many more customers.”

[0001596532-21-000253:8k_2_02:13]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO said, “We are pleased with the strong performance of the business in the quarter, as we continued to work with customers and partners to navigate a challenging supply environment.”

[0001596532-21-000253:8k_2_02:14]
Second Quarter Company Highlights

[0001596532-21-000253:8k_2_02:15]
•In Q2 2021, Arista surpassed 50 million cloud network ports shipped cumulatively.

[0001596532-21-000253:8k_2_02:16]
•Arista Launches Sub 100ns Ultra-low Latency Switch for Financial Services – Arista announced SwitchApp for Arista 7130, a new ultra-low latency switch that cuts latency to less than a third of existing Arista solutions. SwitchApp is based on the latest programmable FPGA technology and is fully integrated with Arista EOS® (Extensible Operating System).

[0001596532-21-000253:8k_2_02:17]
•Arista Boosts Agility for Modern Enterprises - Arista announced CloudVision® 2021, a further expansion of Arista's software-driven approach for modern enterprises. CloudVision 2021 delivers new automation capabilities designed to improve network agility and streamline enterprise business outcomes.

[0001596532-21-000253:8k_2_02:18]
•Arista Networks Cognitive Campus Solutions - Campus networks are undergoing another massive transition in the post-COVID era. As administrators adapt to the shifting boundaries between the office and home around the world, the campus is evolving to distributed workspaces.

[0001596532-21-000253:8k_2_02:19]
Financial Outlook

[0001596532-21-000253:8k_2_02:20]
For the third quarter of 2021, we expect:

[0001596532-21-000253:8k_2_02:21]
•Revenue between $725 million to $745 million;

[0001596532-21-000253:8k_2_02:22]
•Non-GAAP gross margin of 63% to 65%; and

[0001596532-21-000253:8k_2_02:23]
•Non-GAAP operating margin of approximately 37%

[0001596532-21-000253:8k_2_02:24]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and certain non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below under “Non-GAAP Financial Measures”).

[0001596532-21-000253:8k_2_02:25]
Prepared Materials and Conference Call Information

[0001596532-21-000253:8k_2_02:26]
Arista executives will discuss the second quarter financial results on a conference call at 1:30 p.m. Pacific Time today. To listen to the call via telephone, dial (833) 968-2211 in the United States or +1 (778) 560-2896 from international locations. The Conference ID is 6062407.

[0001596532-21-000253:8k_2_02:27]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-21-000253:8k_2_02:28]
Forward-Looking Statements

[0001596532-21-000253:8k_2_02:29]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the third quarter of 2021 and statements regarding the benefits of new products and product enhancements, our leadership in cloud networking, the continued momentum and diversification of our top verticals and product-lines and the evolution of the campus market. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: the impact of the COVID-19 pandemic on our business; insufficient component supply and inventory; increased costs of components; manufacturing capacity impacted by COVID-19 and increased lead times; interruptions or delays in shipments; the rapid evolution of the networking market; any failure to successfully pursue new products and service offerings and expand into adjacent markets; a decline in our revenue growth rate; unpredictability of our results of operations; adverse economic conditions or reduced information technology and network infrastructure spending; intense competition; expansion of our international sales and operations; investment or acquisition in other businesses; seasonality; our ability to attract new large end customers or sell products and services to existing end customers; our ability to increase market awareness of our company and new products and services; product quality problems; our ability to anticipate technological shifts and develop products to meet those technological shifts; our ability to protect, defend and maintain our intellectual property rights; vulnerabilities in our products and failure of our products to detect security breaches our intellectual property rights; and tax, tariff, import/export restrictions; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-21-000253:8k_2_02:30]
Non-GAAP Financial Measures

[0001596532-21-000253:8k_2_02:31]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangible assets, certain non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete

[0001596532-21-000253:8k_2_02:32]
indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-21-000253:8k_2_02:33]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-21-000253:8k_2_02:34]
The company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. The company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. A reconciliation of the non-GAAP financial measures guidance to the corresponding GAAP measures on a forward-looking basis is not available because stock-based compensation expense is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-21-000253:8k_2_02:35]
About Arista Networks

[0001596532-21-000253:8k_2_02:36]
Arista Networks is an industry leader in cognitive cloud networking solutions for large data center and campus environments. Arista’s award-winning platforms deliver availability, agility, automation analytics, and security through CloudVision® and Arista EOS®, an advanced network operating system. For more information visit www.arista.com.

[0001596532-21-000253:8k_2_02:37]
ARISTA, CloudVision, CloudEOS and MSS are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners. Additional information and resources can be found at www.arista.com.

[0001596532-21-000253:8k_2_02:38]
Investor Contacts:

[0001596532-21-000253:8k_2_02:39]
Arista Networks, Inc.

[0001596532-21-000253:8k_2_02:40]
Liz Stine, 512-296-4638

[0001596532-21-000253:8k_2_02:41]
Investor Relations

[0001596532-21-000253:8k_2_02:42]
liz@arista.com

[0001596532-21-000253:8k_2_02:43]
or

[0001596532-21-000253:8k_2_02:44]
Charles Yager, 408-547-5892

[0001596532-21-000253:8k_2_02:45]
Investor Relations

[0001596532-21-000253:8k_2_02:46]
cyager@arista.com

[0001596532-21-000253:8k_2_02:47]
ARISTA NETWORKS, INC.

[0001596532-21-000253:8k_2_02:48]
Condensed Consolidated Statements of Operations

[0001596532-21-000253:8k_2_02:49]
(Unaudited, in thousands, except per share amounts)

[0001596532-21-000253:8k_2_02:50]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 566,467 |  |  | $ | 421,413 |  |  | $ | 1,105,612 |  |  | $ | 832,319 |  |
| Service |  | 140,852 |  |  | 119,157 |  |  | 269,269 |  |  | 231,280 |  |
| Total revenue |  | 707,319 |  |  | 540,570 |  |  | 1,374,881 |  |  | 1,063,599 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 225,779 |  |  | 176,432 |  |  | 444,212 |  |  | 340,061 |  |
| Service |  | 27,362 |  |  | 20,049 |  |  | 51,219 |  |  | 41,198 |  |
| Total cost of revenue |  | 253,141 |  |  | 196,481 |  |  | 495,431 |  |  | 381,259 |  |
| Gross profit |  | 454,178 |  |  | 344,089 |  |  | 879,450 |  |  | 682,340 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 143,293 |  |  | 111,544 |  |  | 275,780 |  |  | 224,698 |  |
| Sales and marketing |  | 70,625 |  |  | 51,237 |  |  | 141,645 |  |  | 108,323 |  |
| General and administrative |  | 20,895 |  |  | 14,319 |  |  | 36,368 |  |  | 32,668 |  |
| Total operating expenses |  | 234,813 |  |  | 177,100 |  |  | 453,793 |  |  | 365,689 |  |
| Income from operations |  | 219,365 |  |  | 166,989 |  |  | 425,657 |  |  | 316,651 |  |
| Other income, net |  | 1,719 |  |  | 8,256 |  |  | 3,294 |  |  | 20,413 |  |
| Income before income taxes |  | 221,084 |  |  | 175,245 |  |  | 428,951 |  |  | 337,064 |  |
| Provision for income taxes |  | 24,196 |  |  | 30,452 |  |  | 51,697 |  |  | 53,840 |  |
| Net income |  | $ | 196,888 |  |  | $ | 144,793 |  |  | $ | 377,254 |  |  | $ | 283,224 |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.58 |  |  | $ | 1.91 |  |  | $ | 4.94 |  |  | $ | 3.72 |  |
| Diluted |  | $ | 2.47 |  |  | $ | 1.83 |  |  | $ | 4.73 |  |  | $ | 3.56 |  |
| Weighted-average shares used in computing net income per share: |  |  |  |  |  |  |  |  |
| Basic |  | 76,461 |  |  | 75,808 |  |  | 76,384 |  |  | 76,036 |  |
| Diluted |  | 79,710 |  |  | 79,298 |  |  | 79,677 |  |  | 79,620 |  |

[0001596532-21-000253:8k_2_02:51]
4

[0001596532-21-000253:8k_2_02:52]
ARISTA NETWORKS, INC.

[0001596532-21-000253:8k_2_02:53]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-21-000253:8k_2_02:54]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-21-000253:8k_2_02:55]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| GAAP gross profit |  | $ | 454,178 |  |  | $ | 344,089 |  |  | $ | 879,450 |  |  | $ | 682,340 |  |
| GAAP gross margin |  | 64.2 | % |  | 63.7 | % |  | 64.0 | % |  | 64.2 | % |
| Stock-based compensation expense |  | 1,796 |  |  | 1,585 |  |  | 3,196 |  |  | 2,912 |  |
| Intangible asset amortization |  | 5,465 |  |  | 4,178 |  |  | 10,929 |  |  | 7,838 |  |
| Non-GAAP gross profit |  | $ | 461,439 |  |  | $ | 349,852 |  |  | $ | 893,575 |  |  | $ | 693,090 |  |
| Non-GAAP gross margin |  | 65.2 | % |  | 64.7 | % |  | 65.0 | % |  | 65.2 | % |
| GAAP income from operations |  | $ | 219,365 |  |  | $ | 166,989 |  |  | $ | 425,657 |  |  | $ | 316,651 |  |
| Stock-based compensation expense |  | 44,944 |  |  | 32,922 |  |  | 82,497 |  |  | 60,478 |  |
| Intangible asset amortization |  | 7,365 |  |  | 5,811 |  |  | 14,795 |  |  | 10,713 |  |
| Acquisition-related costs (1) |  | — |  |  | — |  |  | — |  |  | 11,860 |  |
| Non-GAAP income from operations |  | $ | 271,674 |  |  | $ | 205,722 |  |  | $ | 522,949 |  |  | $ | 399,702 |  |
| Non-GAAP operating margin |  | 38.4 | % |  | 38.1 | % |  | 38.0 | % |  | 37.6 | % |
| GAAP net income |  | $ | 196,888 |  |  | $ | 144,793 |  |  | $ | 377,254 |  |  | $ | 283,224 |  |
| Stock-based compensation expense |  | 44,944 |  |  | 32,922 |  |  | 82,497 |  |  | 60,478 |  |
| Intangible asset amortization |  | 7,365 |  |  | 5,811 |  |  | 14,795 |  |  | 10,713 |  |
| Acquisition-related costs (1) |  | — |  |  | — |  |  | — |  |  | 11,860 |  |
| Tax benefit on stock-based awards |  | (24,113) |  |  | (11,682) |  |  | (45,019) |  |  | (26,184) |  |
| Income tax effect on non-GAAP exclusions |  | (8,256) |  |  | (4,796) |  |  | (13,862) |  |  | (11,351) |  |
| Non-GAAP net income |  | $ | 216,828 |  |  | $ | 167,048 |  |  | $ | 415,665 |  |  | $ | 328,740 |  |
| GAAP diluted net income per share |  | $ | 2.47 |  |  | $ | 1.83 |  |  | $ | 4.73 |  |  | $ | 3.56 |  |
| Non-GAAP adjustments to net income |  | 0.25 |  |  | 0.28 |  |  | 0.49 |  |  | 0.57 |  |
| Non-GAAP diluted net income per share |  | $ | 2.72 |  |  | $ | 2.11 |  |  | $ | 5.22 |  |  | $ | 4.13 |  |
| Weighted-average shares used in computing diluted net income per share |  | 79,710 |  |  | 79,298 |  |  | 79,677 |  |  | 79,620 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,796 |  |  | $ | 1,585 |  |  | $ | 3,196 |  |  | $ | 2,912 |  |
| Research and development |  | 23,139 |  |  | 19,378 |  |  | 45,121 |  |  | 35,306 |  |
| Sales and marketing |  | 11,368 |  |  | 8,277 |  |  | 21,453 |  |  | 14,673 |  |
| General and administrative |  | 8,641 |  |  | 3,682 |  |  | 12,727 |  |  | 7,587 |  |
| Total |  | $ | 44,944 |  |  | $ | 32,922 |  |  | $ | 82,497 |  |  | $ | 60,478 |  |

[0001596532-21-000253:8k_2_02:56]
___________________

[0001596532-21-000253:8k_2_02:57]
(1) Represents non-recurring costs associated with our acquisition of Big Switch, and primarily includes severance, retention bonuses, professional and consulting fees, and facilities restructuring costs.

[0001596532-21-000253:8k_2_02:58]
ARISTA NETWORKS, INC.

[0001596532-21-000253:8k_2_02:59]
Condensed Consolidated Balance Sheets

[0001596532-21-000253:8k_2_02:60]
(Unaudited, in thousands)

[0001596532-21-000253:8k_2_02:61]
|  |  | June 30, 2021 |  | December 31, 2020 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 893,688 |  |  | $ | 893,219 |  |
| Marketable securities |  | 2,388,015 |  |  | 1,979,649 |  |
| Accounts receivable |  | 364,214 |  |  | 389,540 |  |
| Inventories |  | 543,199 |  |  | 479,668 |  |
| Prepaid expenses and other current assets |  | 139,279 |  |  | 94,922 |  |
| Total current assets |  | 4,328,395 |  |  | 3,836,998 |  |
| Property and equipment, net |  | 32,362 |  |  | 32,231 |  |
| Acquisition-related intangible assets, net |  | 107,995 |  |  | 122,790 |  |
| Goodwill |  | 188,277 |  |  | 189,696 |  |
| Investments |  | 13,647 |  |  | 8,314 |  |
| Operating lease right-of-use assets |  | 70,497 |  |  | 77,288 |  |
| Deferred tax assets |  | 433,674 |  |  | 441,531 |  |
| Other assets |  | 33,433 |  |  | 30,071 |  |
| TOTAL ASSETS |  | $ | 5,208,280 |  |  | $ | 4,738,919 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 145,159 |  |  | $ | 134,235 |  |
| Accrued liabilities |  | 163,245 |  |  | 143,357 |  |
| Deferred revenue |  | 482,112 |  |  | 396,259 |  |
| Other current liabilities |  | 69,419 |  |  | 94,392 |  |
| Total current liabilities |  | 859,935 |  |  | 768,243 |  |
| Income taxes payable |  | 57,977 |  |  | 53,053 |  |
| Operating lease liabilities, non-current |  | 64,295 |  |  | 72,397 |  |
| Deferred revenue, non-current |  | 263,978 |  |  | 254,568 |  |
| Deferred tax liabilities, non-current |  | 216,746 |  |  | 227,936 |  |
| Other long-term liabilities |  | 47,508 |  |  | 42,431 |  |
| TOTAL LIABILITIES |  | 1,510,439 |  |  | 1,418,628 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 8 |  |  | 8 |  |
| Additional paid-in capital |  | 1,395,459 |  |  | 1,292,431 |  |
| Retained earnings |  | 2,303,513 |  |  | 2,027,614 |  |
| Accumulated other comprehensive income (loss) |  | (1,139) |  |  | 238 |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 3,697,841 |  |  | 3,320,291 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 5,208,280 |  |  | $ | 4,738,919 |  |

[0001596532-21-000253:8k_2_02:62]
6

[0001596532-21-000253:8k_2_02:63]
ARISTA NETWORKS, INC.

[0001596532-21-000253:8k_2_02:64]
Condensed Consolidated Statements of Cash Flows

[0001596532-21-000253:8k_2_02:65]
(Unaudited, in thousands)

[0001596532-21-000253:8k_2_02:66]
|  |  | Six Months Ended June 30, |
|  |  | 2021 |  | 2020 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 377,254 |  |  | $ | 283,224 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 25,235 |  |  | 21,170 |  |
| Stock-based compensation |  | 82,497 |  |  | 60,478 |  |
| Noncash lease expense |  | 8,410 |  |  | 8,223 |  |
| Deferred income taxes |  | (2,998) |  |  | 2,668 |  |
| Amortization of investment premiums |  | 12,121 |  |  | 2,938 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | 25,326 |  |  | 15,263 |  |
| Inventories |  | (63,531) |  |  | (82,891) |  |
| Prepaid expenses and other current assets |  | (44,356) |  |  | 26,815 |  |
| Other assets |  | (3,390) |  |  | 5,360 |  |
| Accounts payable |  | 10,879 |  |  | 31,473 |  |
| Accrued liabilities |  | 20,025 |  |  | (39,882) |  |
| Deferred revenue |  | 95,263 |  |  | (19,242) |  |
| Income taxes payable |  | (9,144) |  |  | 16,820 |  |
| Other liabilities |  | (15,550) |  |  | 646 |  |
| Net cash provided by operating activities |  | 518,041 |  |  | 333,063 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 819,807 |  |  | 875,213 |  |
| Purchases of marketable securities |  | (1,241,657) |  |  | (1,236,477) |  |
| Purchases of property and equipment |  | (9,567) |  |  | (5,178) |  |
| Business acquisitions, net of cash acquired |  | — |  |  | (66,317) |  |
| Escrow receipts from past business acquisitions |  | 1,419 |  |  | — |  |
| Investment in privately-held companies and intangibles |  | (6,084) |  |  | — |  |
| Net cash used in investing activities |  | (436,082) |  |  | (432,759) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 26,884 |  |  | 22,228 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (6,353) |  |  | (4,000) |  |
| Repurchase of common stock |  | (101,355) |  |  | (227,895) |  |
| Net cash used in financing activities |  | (80,824) |  |  | (209,667) |  |
| Effect of exchange rate changes |  | (665) |  |  | (1,663) |  |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 470 |  |  | (311,026) |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 897,454 |  |  | 1,115,515 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 897,924 |  |  | $ | 804,489 |  |
