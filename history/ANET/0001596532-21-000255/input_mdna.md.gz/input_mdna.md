# ANET MD&A — 0001596532-21-000255


## mdna

[0001596532-21-000255:mdna:1]
[same as prior period, unchanged from 0001596532-21-000149:mdna:1]

[0001596532-21-000255:mdna:2]
[same as prior period, unchanged from 0001596532-21-000149:mdna:2]

[0001596532-21-000255:mdna:3]
Arista Networks pioneered software-driven, cognitive cloud networking for large-scale data center and campus workspace environments. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our Ethernet switching and routing platforms. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. In recent years, we have sought to bring the operational consistency and principles of cloud networking to the broader enterprise and campus markets with our Cognitive Cloud Networking approach. Our cognitive single-tier SplineTM  campus network extends EOS across the campus workspace

[0001596532-21-000255:mdna:4]
and the data center.  In addition, we have added Cognitive WiFiTM to our portfolio to extend these same cognitive principles to the wireless network. CloudVision®, our network-wide approach for workload orchestration and automation, leverages EOS and Cognitive WiFiTM features, to deliver a turnkey workflow orchestration and automation solution for cloud networking to our enterprise customers.

[0001596532-21-000255:mdna:5]
We generate revenue primarily from sales of our switching and routing platforms, which incorporate our EOS software, and related network applications. We also generate revenue from post-contract support ("PCS"), which end customers typically purchase in conjunction with our products and renewals of PCS. We sell our products through both our direct sales force and our channel partners. As of December 31, 2020, we had delivered our cloud networking solutions to over 7,000 end customers worldwide.  Our end customers span a range of industries and include large internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others.

[0001596532-21-000255:mdna:6]
Historically, large purchases by a relatively limited number of end customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large end customers primarily due to changes in demand patterns specific to these customers, the time it takes these end customers to evaluate, test, qualify and accept our products, and the overall complexity of these large orders. We expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. For example, sales to our end customers Microsoft and Facebook in fiscal 2019 collectively represented 40% of our total revenue, whereas sales to Microsoft and Facebook in fiscal 2020 amounted to 21.5% and less than 10% of our total revenues, respectively. In addition, we typically provide pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur.

[0001596532-21-000255:mdna:7]
[same as prior period, unchanged from 0001596532-21-000149:mdna:7]

[0001596532-21-000255:mdna:8]
[same as prior period, unchanged from 0001596532-21-000149:mdna:8]

[0001596532-21-000255:mdna:9]
Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic with respect to the underlying merchant silicon architecture. The programmability of EOS has allowed us to expand our software applications to address the ever increasing demands of cloud networking, including workflow automation, network visibility, analytics and network detection and response, and has further allowed us to integrate rapidly with a wide range of third-party applications for virtualization, management, automation, orchestration and network services. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We work closely with third-party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third-party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-21-000255:mdna:10]
COVID-19 Update

[0001596532-21-000255:mdna:11]
The global coronavirus (“COVID-19”) pandemic continues to negatively impact the global economy and disrupt business activities.  We are actively monitoring and evaluating the developments as the situation evolves and will continue to take further actions in our approach to address COVID-19. We have prioritized the protection of our employees during this pandemic and, as a result, our offices across the globe have remained closed since March 2020, limiting access to facilities-based employees and a limited number of employees on a voluntary basis; in addition, we continue to impose some travel restrictions. Although we did not experience significant business disruptions in the current quarter, we continue to work closely with our contract manufacturers and supply chain partners who have experienced delays in component sourcing, workforce disruptions and governmental restrictions on the production and export of their products. Although we have worked diligently

[0001596532-21-000255:mdna:12]
to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, these delays have negatively impacted our ability to supply products to our customers on a timely basis. We are currently experiencing shortages and delays relating to certain components as a result of manufacturing and supply disruptions from the COVID-19 pandemic. We expect to continue to invest in working capital to address delays in component sourcing and the risk of future COVID-19 related supply chain disruptions, but we cannot be certain that such delays or disruptions will not occur.

[0001596532-21-000255:mdna:13]
The extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, including the duration of the pandemic, the breadth and duration of governmental containment measures such as workplace, travel and social distancing restrictions, as well as the reauthorization of or increase in such measures in the event of spikes in COVID-19 infection rates, the success of the COVID-19 vaccination deployment, and the impact on our customers, partners, contract manufacturers and supply chain, all of which are uncertain and cannot be predicted. However, any continued or renewed disruption in manufacturing and supply resulting from the COVID-19 pandemic or related containment measures could negatively impact our business. We also believe that any extended or renewed COVID-19 related economic disruption could have a negative impact on demand from our customers in future periods. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

[0001596532-21-000255:mdna:14]
[same as prior period, unchanged from 0001596532-21-000149:mdna:16]

[0001596532-21-000255:mdna:15]
Three and Six Months Ended June 30, 2021 Compared to Three and Six Months Ended June 30, 2020

[0001596532-21-000255:mdna:16]
[same as prior period, unchanged from 0001596532-21-000149:mdna:18]

[0001596532-21-000255:mdna:17]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | Change in |  | 2021 |  | 2020 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 566,467 |  |  | $ | 421,413 |  |  | $ | 145,054 |  |  | 34.4 | % |  | $ | 1,105,612 |  |  | $ | 832,319 |  |  | $ | 273,293 |  |  | 32.8 | % |
| Service |  | 140,852 |  |  | 119,157 |  |  | 21,695 |  |  | 18.2 |  |  | 269,269 |  |  | 231,280 |  |  | 37,989 |  |  | 16.4 |  |
| Total revenue |  | 707,319 |  |  | 540,570 |  |  | 166,749 |  |  | 30.8 |  |  | 1,374,881 |  |  | 1,063,599 |  |  | 311,282 |  |  | 29.3 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 225,779 |  |  | 176,432 |  |  | 49,347 |  |  | 28.0 |  |  | 444,212 |  |  | 340,061 |  |  | 104,151 |  |  | 30.6 |  |
| Service |  | 27,362 |  |  | 20,049 |  |  | 7,313 |  |  | 36.5 |  |  | 51,219 |  |  | 41,198 |  |  | 10,021 |  |  | 24.3 |  |
| Total cost of revenue |  | 253,141 |  |  | 196,481 |  |  | 56,660 |  |  | 28.8 |  |  | 495,431 |  |  | 381,259 |  |  | 114,172 |  |  | 29.9 |  |
| Gross profit |  | $ | 454,178 |  |  | $ | 344,089 |  |  | $ | 110,089 |  |  | 32.0 | % |  | $ | 879,450 |  |  | $ | 682,340 |  |  | $ | 197,110 |  |  | 28.9 | % |
| Gross margin |  | 64.2 | % |  | 63.7 | % |  |  |  |  |  | 64.0 | % |  | 64.2 | % |  |  |  |  |

[0001596532-21-000255:mdna:18]
[same as prior period, unchanged from 0001596532-21-000149:mdna:20]

[0001596532-21-000255:mdna:19]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2021 |  | % of Total |  | 2020 |  | % of Total |  | 2021 |  | % of Total |  | 2020 |  | % of Total |
| Americas |  | $ | 514,149 |  |  | 72.7 | % |  | $ | 435,829 |  |  | 80.7 | % |  | $ | 1,016,021 |  |  | 73.9 | % |  | $ | 836,489 |  |  | 78.7 | % |
| Europe, Middle East and Africa |  | 112,048 |  |  | 15.8 |  |  | 63,977 |  |  | 11.8 |  |  | 208,322 |  |  | 15.2 |  |  | 136,601 |  |  | 12.8 |  |
| Asia-Pacific |  | 81,122 |  |  | 11.5 |  |  | 40,764 |  |  | 7.5 |  |  | 150,538 |  |  | 10.9 |  |  | 90,509 |  |  | 8.5 |  |
| Total revenue |  | $ | 707,319 |  |  | 100.0 | % |  | $ | 540,570 |  |  | 100.0 | % |  | $ | 1,374,881 |  |  | 100.0 | % |  | $ | 1,063,599 |  |  | 100.0 | % |

[0001596532-21-000255:mdna:20]
[same as prior period, unchanged from 0001596532-21-000149:mdna:22]

[0001596532-21-000255:mdna:21]
Product revenue primarily consists of sales of our switching and routing products, and software licenses. Service revenue is primarily derived from sales of PCS, which is typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing, size, and complexity of orders, especially with respect to our large end customers.

[0001596532-21-000255:mdna:22]
Product revenue increased $145.1 million, or 34.4%, and $273.3 million, or 32.8%, for the three and six months ended June 30, 2021, respectively, compared to the same periods in 2020. These increases reflected increased demand for our products from new and existing customers, including broader market acceptance of our enterprise and campus products. Service revenue increased $21.7 million, or 18.2%, and $38.0 million, or 16.4%, in the three and six months ended June 30, 2021, compared to

[0001596532-21-000255:mdna:23]
the same periods in 2020, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenues represented 27.3% and 26.1% of total revenues in the three and six months ended June 30, 2021, respectively, increasing from 19.3% and 21.3% compared to the same periods in the prior year. These changes reflected increased international purchases by our large global end customers in addition to increased demand from our in-region end customers. We continued to experience competitive pricing pressure on our products and services.

[0001596532-21-000255:mdna:24]
[same as prior period, unchanged from 0001596532-21-000149:mdna:25]

[0001596532-21-000255:mdna:25]
Cost of product revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs of our manufacturing operations, and other costs associated with manufacturing our products and managing our inventory. Cost of service revenue primarily consists of personnel and other costs associated with our global customer support and services organizations.

[0001596532-21-000255:mdna:26]
Cost of revenue increased $56.7 million, or 28.8%, and $114.2 million, or 29.9%, for the three and six months ended June 30, 2021, respectively, compared to the same periods in 2020. These increases were primarily driven by a corresponding increase in product and service revenues, coupled with an increase in supply chain and product transition related costs.

[0001596532-21-000255:mdna:27]
[same as prior period, unchanged from 0001596532-21-000149:mdna:29]

[0001596532-21-000255:mdna:28]
Gross margin increased from 63.7% to 64.2% for the three months ended June 30, 2021, and decreased from 64.2% to 64.0% for the six months ended June 30, 2021, compared to the same periods in 2020. The changes in each period were favorably impacted by a reduced proportion of our sales to larger end customers who generally receive larger discounts, and adversely impacted by increased supply chain and product transition-related costs, including some excess and obsolete inventory-related charges.

[0001596532-21-000255:mdna:29]
[same as prior period, unchanged from 0001596532-21-000149:mdna:31]

[0001596532-21-000255:mdna:30]
[same as prior period, unchanged from 0001596532-21-000149:mdna:32]

[0001596532-21-000255:mdna:31]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | Change in |  | 2021 |  | 2020 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 143,293 |  |  | $ | 111,544 |  |  | $ | 31,749 |  |  | 28.5 | % |  | $ | 275,780 |  |  | $ | 224,698 |  |  | $ | 51,082 |  |  | 22.7 | % |
| Sales and marketing |  | 70,625 |  |  | 51,237 |  |  | 19,388 |  |  | 37.8 |  |  | 141,645 |  |  | 108,323 |  |  | 33,322 |  |  | 30.8 |  |
| General and administrative |  | 20,895 |  |  | 14,319 |  |  | 6,576 |  |  | 45.9 |  |  | 36,368 |  |  | 32,668 |  |  | 3,700 |  |  | 11.3 |  |
| Total operating expenses |  | $ | 234,813 |  |  | $ | 177,100 |  |  | $ | 57,713 |  |  | 32.6 | % |  | $ | 453,793 |  |  | $ | 365,689 |  |  | $ | 88,104 |  |  | 24.1 | % |

[0001596532-21-000255:mdna:32]
[same as prior period, unchanged from 0001596532-21-000149:mdna:34]

[0001596532-21-000255:mdna:33]
[same as prior period, unchanged from 0001596532-21-000149:mdna:35]

[0001596532-21-000255:mdna:34]
Research and development expenses increased $31.7 million, or 28.5%, and $51.1 million, or 22.7%, in the three and six months ended June 30, 2021, respectively, compared to the same periods in 2020. The increases were primarily driven by an increase in personnel costs of $20.5 million and $35.7 million for the three and six months ended June 30, 2021, respectively, compared to the same periods in 2020 due to headcount growth. In addition, new product introduction costs increased by $9.4

[0001596532-21-000255:mdna:35]
million and $20.9 million for the three and six months ended June 30, 2021, respectively, compared to the same periods in 2020. These increases were partly offset by a decrease in merger-related costs of $5.9 million associated with our acquisition of Big Switch Networks ("Big Switch") in 2020.

[0001596532-21-000255:mdna:36]
[same as prior period, unchanged from 0001596532-21-000149:mdna:37]

[0001596532-21-000255:mdna:37]
[same as prior period, unchanged from 0001596532-21-000149:mdna:38]

[0001596532-21-000255:mdna:38]
Sales and marketing expenses increased $19.4 million, or 37.8%, and $33.3 million, or 30.8%, for the three and six months ended June 30, 2021, respectively, compared to the same periods in 2020, which was primarily caused by increased personnel costs driven by headcount growth.

[0001596532-21-000255:mdna:39]
[same as prior period, unchanged from 0001596532-21-000149:mdna:40]

[0001596532-21-000255:mdna:40]
[same as prior period, unchanged from 0001596532-21-000149:mdna:41]

[0001596532-21-000255:mdna:41]
General and administrative expenses increased $6.6 million, or 45.9%, and $3.7 million, or 11.3%, in the three and six months ended June 30, 2021 compared to the same periods in 2020, which was primarily driven by increased personnel costs, including increased stock-based compensation expenses. The increase was partly offset by a decrease in merger-related costs of $2.3 million associated with our acquisition of Big Switch in 2020.

[0001596532-21-000255:mdna:42]
[same as prior period, unchanged from 0001596532-21-000149:mdna:43]

[0001596532-21-000255:mdna:43]
[same as prior period, unchanged from 0001596532-21-000149:mdna:44]

[0001596532-21-000255:mdna:44]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | Change in |  | 2021 |  | 2020 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 1,872 |  |  | $ | 8,668 |  |  | $ | (6,796) |  |  | (78.4) | % |  | $ | 3,917 |  |  | $ | 20,330 |  |  | $ | (16,413) |  |  | (80.7) | % |
| Other income (expense), net |  | (153) |  |  | (412) |  |  | 259 |  |  | 62.9 |  |  | (623) |  |  | 83 |  |  | (706) |  |  | (850.6) |  |
| Total other income, net |  | $ | 1,719 |  |  | $ | 8,256 |  |  | $ | (6,537) |  |  | (79.2) | % |  | $ | 3,294 |  |  | $ | 20,413 |  |  | $ | (17,119) |  |  | (83.9) | % |

[0001596532-21-000255:mdna:45]
The unfavorable change in other income, net, during the three and six months ended June 30, 2021 as compared to the same periods in 2020 was primarily caused by significant declines in the yields of government and corporate bonds in our investment portfolio.

[0001596532-21-000255:mdna:46]
[same as prior period, unchanged from 0001596532-21-000149:mdna:47]

[0001596532-21-000255:mdna:47]
[same as prior period, unchanged from 0001596532-21-000149:mdna:48]

[0001596532-21-000255:mdna:48]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | Change in |  | 2021 |  | 2020 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 221,084 |  |  | $ | 175,245 |  |  | $ | 45,839 |  |  | 26.2 | % |  | $ | 428,951 |  |  | $ | 337,064 |  |  | $ | 91,887 |  |  | 27.3 | % |
| Provision for income taxes |  | 24,196 |  |  | 30,452 |  |  | (6,256) |  |  | (20.5) | % |  | 51,697 |  |  | 53,840 |  |  | (2,143) |  |  | (4.0) | % |
| Effective tax rate |  | 10.9 | % |  | 17.4 | % |  |  |  |  |  | 12.1 | % |  | 16.0 | % |  |  |  |  |

[0001596532-21-000255:mdna:49]
Despite an increase in pre-tax income in each period of 2021 as compared to 2020, our provision for income taxes for the three and six months ended June 30, 2021, as compared to the same periods in 2020, decreased due to higher tax benefits attributable to stock-based awards, combined with a favorable change in jurisdictional mix of earnings.

[0001596532-21-000255:mdna:50]
[same as prior period, unchanged from 0001596532-21-000149:mdna:51]

[0001596532-21-000255:mdna:51]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of June 30, 2021, our total balance of cash, cash equivalents and marketable securities was approximately $3.3 billion, of which approximately $442.8 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-21-000255:mdna:52]
Our cash, cash equivalents and marketable securities are held for general business purposes, including the funding of working capital. Our marketable securities investment portfolio is primarily invested in highly rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and stock repurchases. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-21-000255:mdna:53]
[same as prior period, unchanged from 0001596532-21-000149:mdna:55]

[0001596532-21-000255:mdna:54]
|  |  | Six Months Ended June 30, |
|  |  | 2021 |  | 2020 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 518,041 |  |  | $ | 333,063 |  |
| Cash used in investing activities |  | (436,082) |  |  | (432,759) |  |
| Cash used in financing activities |  | (80,824) |  |  | (209,667) |  |
| Effect of exchange rate changes |  | (665) |  |  | (1,663) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 470 |  |  | $ | (311,026) |  |

[0001596532-21-000255:mdna:55]
[same as prior period, unchanged from 0001596532-21-000149:mdna:57]

[0001596532-21-000255:mdna:56]
During the six months ended June 30, 2021, cash provided by operating activities was $518.0 million, primarily from net income of $377.3 million and non-cash adjustments to net income of $125.2 million driven by stock-based compensation and depreciation and amortization, and a net decrease of $15.5 million in working capital requirements. The decrease in working capital requirements primarily consisted of a $95.3 million increase in product and service deferred revenue driven by customer contracts with acceptance terms and growth in PCS contracts, a $25.3 million decrease in accounts receivable due to strong collections, and a $20.0 million increase in accrued liabilities due to additional supply chain related obligations. These cash inflows were partially offset by a $63.5 million increase in inventory and a $44.4 million increase in prepaid expenses primarily due to prepaid income taxes and deferred product cost of revenue.

[0001596532-21-000255:mdna:57]
During the six months ended June 30, 2020, cash provided by operating activities was $333.1 million, primarily from net income of $283.2 million and non-cash adjustments to net income of $95.5 million driven by stock-based compensation and depreciation and amortization, partially offset by a net $45.6 million increase in working capital requirements. This increase in working capital primarily consisted of an $82.9 million increase in inventory to help mitigate COVID-19 related supply chain disruptions and a $39.9 million decrease in accrued liabilities related to the timing of corporate bonus payouts. These working capital increases were partially offset by a $31.5 million increase in accounts payable related to the timing of production receipts, a $26.8 million decrease in prepaid taxes, and a $15.3 million decrease in accounts receivable due to strong collections.

[0001596532-21-000255:mdna:58]
[same as prior period, unchanged from 0001596532-21-000149:mdna:60]

[0001596532-21-000255:mdna:59]
During the six months ended June 30, 2021, cash used in investing activities was $436.1 million, consisting of purchases of available-for-sale securities of $1,241.7 million, and purchases of property and equipment of $9.6 million, partially offset by proceeds from maturities of marketable securities of $819.8 million.

[0001596532-21-000255:mdna:60]
During the six months ended June 30, 2020, cash used in investing activities was $432.8 million, consisting of purchases of available-for-sale securities of $1,236.5 million, $66.3 million for the acquisition of Big Switch, and purchases of property and equipment of $5.2 million, partially offset by proceeds from maturities of marketable securities of $875.2 million.

[0001596532-21-000255:mdna:61]
[same as prior period, unchanged from 0001596532-21-000149:mdna:63]

[0001596532-21-000255:mdna:62]
During the six months ended June 30, 2021, cash used in financing activities was $80.8 million, consisting of payments for repurchases of our common stock from the open market of $101.4 million, and employee taxes withheld and paid of $6.4 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $26.9 million.

[0001596532-21-000255:mdna:63]
During the six months ended June 30, 2020, cash used in financing activities was $209.7 million, consisting of payments for repurchases of our common stock from the open market of $227.9 million, and taxes paid of $4.0 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $22.2 million.

[0001596532-21-000255:mdna:64]
[same as prior period, unchanged from 0001596532-21-000149:mdna:66]

[0001596532-21-000255:mdna:65]
From time to time, we repurchase our common stock pursuant to our Repurchase Program authorized by our board of directors in April 2019. The Repurchase Program allows for stock repurchases of up to $1.0 billion through April 2022, and these repurchases are funded from working capital. The Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by us at any time without prior notice. During the three months ended June 30, 2021, there was no stock repurchase activity. As of June 30, 2021, the remaining authorized amount for repurchases under the Repurchase Program was $237.3 million. Refer to Note 6. Stockholders' Equity and Stock-based Compensation of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-21-000255:mdna:66]
[same as prior period, unchanged from 0001596532-21-000149:mdna:69]

[0001596532-21-000255:mdna:67]
As of June 30, 2021, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-21-000255:mdna:68]
[same as prior period, unchanged from 0001596532-21-000149:mdna:71]

[0001596532-21-000255:mdna:69]
Our contractual commitments will have an impact on our future liquidity.  Our contractual obligations represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalent and marketable securities. As of June 30, 2021, our principal commitments consist primarily of obligations under operating leases for offices and data centers and purchase commitments with our contract manufacturers and suppliers. See Note 5. Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for our purchase commitments as of June 30, 2021.

[0001596532-21-000255:mdna:70]
[same as prior period, unchanged from 0001596532-21-000149:mdna:73]

[0001596532-21-000255:mdna:71]
Our management’s discussion and analysis of financial condition and results of operations are based on our unaudited condensed consolidated financial statements, which have been prepared in accordance with GAAP.  The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting policies and estimates in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our Annual Report on Form 10-K filed with the SEC on February 19, 2021 reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting policies and estimates as disclosed in our Annual Report on Form 10-K.

[0001596532-21-000255:mdna:72]
[same as prior period, unchanged from 0001596532-21-000149:mdna:75]

[0001596532-21-000255:mdna:73]
Refer to the subheading titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
