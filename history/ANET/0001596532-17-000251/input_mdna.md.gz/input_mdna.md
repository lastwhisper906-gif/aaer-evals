# ANET MD&A — 0001596532-17-000251


## mdna

[0001596532-17-000251:mdna:1]
[same as prior period, unchanged from 0001596532-17-000201:mdna:1]

[0001596532-17-000251:mdna:2]
[same as prior period, unchanged from 0001596532-17-000201:mdna:2]

[0001596532-17-000251:mdna:3]
[same as prior period, unchanged from 0001596532-17-000201:mdna:3]

[0001596532-17-000251:mdna:4]
[same as prior period, unchanged from 0001596532-17-000201:mdna:4]

[0001596532-17-000251:mdna:5]
[same as prior period, unchanged from 0001596532-17-000201:mdna:5]

[0001596532-17-000251:mdna:6]
[same as prior period, unchanged from 0001596532-17-000201:mdna:6]

[0001596532-17-000251:mdna:7]
[same as prior period, unchanged from 0001596532-17-000201:mdna:7]

[0001596532-17-000251:mdna:8]
[same as prior period, unchanged from 0001596532-17-000201:mdna:8]

[0001596532-17-000251:mdna:9]
Furthermore, to comply with the limited exclusion order and cease and desist order in the 945 Investigation as described above in Note 5, entitled Commitments and Contingencies, we have made design changes to our products for sale in the United States

[0001596532-17-000251:mdna:10]
to address the features that were found to infringe the patent claims underlying the remedial orders in the 945 Investigation . We have also worked closely with our customers on the qualification and testing of our redesigned products.  The timing of completion of these qualification activities, some of which have extended beyond the current quarter, has impacted our business with these customers in these quarters.  We will continue to work with these customers to complete these procedures and improve these design changes with further product modifications in order to meet customer requirements. As described in Note 5, we will need to complete any outstanding product modifications and the qualification and acceptance processes of our customers and any inability to do so in a timely manner may result in an impact to our business, our revenue and our deferred revenue balances.

[0001596532-17-000251:mdna:11]
We also filed a motion with the U.S. Court of Appeals for the Federal Circuit (the "CAFC") requesting that they stay the orders of the United States International Trade Commission (“USITC”), pending completion of the appeals of the decisions of the United States Patent Trial and Appeal Board (“PTAB”), and sought an expedited schedule for those appeals.  On September 22, 2017, the CAFC denied the motion to stay, but has allowed us to import its redesigned products into the United States without being blocked by the USITC’s orders, subject to any determinations by the USITC in subsequent proceedings regarding the redesigned products.  On October 27, 2017, the USITC instituted a modification proceeding to determine whether our redesigned products infringe the patent claims underlying the remedial orders in the 945 Investigation.  The USITC has set a deadline of five months for the ALJ to issue a recommended determination, which may be extended by one month upon a showing of good cause.  The recommended determination will be subject to review by the Commission after which the Commission will issue a final determination.  The Commission has not set a target date for the final determination.

[0001596532-17-000251:mdna:12]
[same as prior period, unchanged from 0001596532-17-000201:mdna:10]

[0001596532-17-000251:mdna:13]
The following table summarizes historical results of operations for the periods presented and as a percentage of revenue for those periods.  We have derived the data for the three and nine months ended September 30, 2017 and 2016 from our unaudited condensed consolidated financial statements (in thousands, except for percentages).

[0001596532-17-000251:mdna:14]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 380,344 |  |  | $ | 254,238 |  |  | $ | 1,025,615 |  |  | $ | 702,329 |  |
| Service | 57,289 |  |  | 36,023 |  |  | 152,704 |  |  | 98,869 |  |
| Total revenue | 437,633 |  |  | 290,261 |  |  | 1,178,319 |  |  | 801,198 |  |
| Cost of revenue (1): |  |  |  |  |  |  |  |
| Product | 145,874 |  |  | 94,777 |  |  | 390,116 |  |  | 261,711 |  |
| Service | 11,142 |  |  | 9,064 |  |  | 33,599 |  |  | 26,526 |  |
| Total cost of revenue | 157,016 |  |  | 103,841 |  |  | 423,715 |  |  | 288,237 |  |
| Gross profit | 280,617 |  |  | 186,420 |  |  | 754,604 |  |  | 512,961 |  |
| Operating expenses (1): |  |  |  |  |  |  |  |
| Research and development | 79,610 |  |  | 70,648 |  |  | 242,414 |  |  | 202,183 |  |
| Sales and marketing | 40,640 |  |  | 33,216 |  |  | 116,297 |  |  | 92,566 |  |
| General and administrative | 19,535 |  |  | 19,535 |  |  | 65,009 |  |  | 52,298 |  |
| Total operating expenses | 139,785 |  |  | 123,399 |  |  | 423,720 |  |  | 347,047 |  |
| Income from operations | 140,832 |  |  | 63,021 |  |  | 330,884 |  |  | 165,914 |  |
| Interest expense | (701 | ) |  | (735 | ) |  | (2,039 | ) |  | (2,218 | ) |
| Other income (expense), net | 2,136 |  |  | 639 |  |  | 4,280 |  |  | 1,392 |  |
| Total other income (expense), net | 1,435 |  |  | (96 | ) |  | 2,241 |  |  | (826 | ) |
| Income before provision for income taxes | 142,267 |  |  | 62,925 |  |  | 333,125 |  |  | 165,088 |  |
| Provision for income taxes | 8,545 |  |  | 11,668 |  |  | 13,757 |  |  | 39,682 |  |
| Net income | $ | 133,722 |  |  | $ | 51,257 |  |  | $ | 319,368 |  |  | $ | 125,406 |  |

[0001596532-17-000251:mdna:15]
29

[0001596532-17-000251:mdna:16]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
|  | (as a percentage of revenue) |
| Revenue: |  |  |  |  |  |  |  |
| Product | 86.9 | % |  | 87.6 | % |  | 87.0 | % |  | 87.7 | % |
| Service | 13.1 |  |  | 12.4 |  |  | 13.0 |  |  | 12.3 |  |
| Total revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 33.4 |  |  | 32.7 |  |  | 33.1 |  |  | 32.7 |  |
| Service | 2.5 |  |  | 3.1 |  |  | 2.9 |  |  | 3.3 |  |
| Total cost of revenue | 35.9 |  |  | 35.8 |  |  | 36.0 |  |  | 36.0 |  |
| Gross margin | 64.1 |  |  | 64.2 |  |  | 64.0 |  |  | 64.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 18.2 |  |  | 24.3 |  |  | 20.5 |  |  | 25.2 |  |
| Sales and marketing | 9.2 |  |  | 11.5 |  |  | 9.9 |  |  | 11.6 |  |
| General and administrative | 4.5 |  |  | 6.7 |  |  | 5.5 |  |  | 6.5 |  |
| Total operating expenses | 31.9 |  |  | 42.5 |  |  | 35.9 |  |  | 43.3 |  |
| Income from operations | 32.2 |  |  | 21.7 |  |  | 28.1 |  |  | 20.7 |  |
| Interest expense | (0.1 | ) |  | (0.2 | ) |  | (0.2 | ) |  | (0.3 | ) |
| Other income (expense), net | 0.5 |  |  | 0.2 |  |  | 0.4 |  |  | 0.2 |  |
| Total other income (expense), net | 0.4 |  |  | — |  |  | 0.2 |  |  | (0.1 | ) |
| Income before provision for income taxes | 32.6 |  |  | 21.7 |  |  | 28.3 |  |  | 20.6 |  |
| Provision for income taxes | 2.0 |  |  | 4.0 |  |  | 1.2 |  |  | 5.0 |  |
| Net income | 30.6 | % |  | 17.7 | % |  | 27.1 | % |  | 15.6 | % |

[0001596532-17-000251:mdna:17]
[same as prior period, unchanged from 0001596532-17-000201:mdna:15]

[0001596532-17-000251:mdna:18]
[same as prior period, unchanged from 0001596532-17-000201:mdna:16]

[0001596532-17-000251:mdna:19]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Cost of revenue | $ | 1,113 |  |  | $ | 955 |  |  | $ | 3,224 |  |  | $ | 2,616 |  |
| Research and development | 11,048 |  |  | 8,010 |  |  | 30,977 |  |  | 23,062 |  |
| Sales and marketing | 5,115 |  |  | 3,947 |  |  | 12,651 |  |  | 11,374 |  |
| General and administrative | 2,876 |  |  | 2,204 |  |  | 8,139 |  |  | 5,656 |  |
| Total stock-based compensation | $ | 20,152 |  |  | $ | 15,116 |  |  | $ | 54,991 |  |  | $ | 42,708 |  |

[0001596532-17-000251:mdna:20]
Three and Nine Months Ended September 30, 2017 Compared to Three and Nine Months Ended September 30, 2016

[0001596532-17-000251:mdna:21]
[same as prior period, unchanged from 0001596532-17-000201:mdna:19]

[0001596532-17-000251:mdna:22]
We generate revenue primarily from sales of our switching products, and a portion of our revenue from sales of PCS.  We expect our revenue may vary from period to period based on, among other things, the timing and size of orders, the delivery and acceptance of products, and the impact of significant transactions with unique terms and conditions that may require deferral of revenue.  In the third quarter, we offered U.S. customers a contractual acceptance period associated with the qualification of our new 945 related product redesigns.  The impact of this program on revenue and deferred revenue was offset by the expiration of some new product and new customer contractual acceptance clauses from prior period arrangements.

[0001596532-17-000251:mdna:23]
Cost of revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs in our manufacturing operations department, and other manufacturing-related costs associated with manufacturing our products and managing our inventory. We expect our cost of product revenue to increase as our product revenue increases. Cost of providing PCS and other services consists primarily of personnel costs for our global customer support

[0001596532-17-000251:mdna:24]
organization.

[0001596532-17-000251:mdna:25]
[same as prior period, unchanged from 0001596532-17-000201:mdna:22]

[0001596532-17-000251:mdna:26]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2017 |  | 2016 |  | Change in |  | 2017 |  | 2016 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
|  | (in thousands, except percentages) |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 380,344 |  |  | $ | 254,238 |  |  | $ | 126,106 |  |  | 49.6% |  | $ | 1,025,615 |  |  | $ | 702,329 |  |  | $ | 323,286 |  |  | 46.0% |
| Service | 57,289 |  |  | 36,023 |  |  | 21,266 |  |  | 59.0 |  | 152,704 |  |  | 98,869 |  |  | 53,835 |  |  | 54.5 |
| Total revenue | 437,633 |  |  | 290,261 |  |  | 147,372 |  |  | 50.8 |  | 1,178,319 |  |  | 801,198 |  |  | 377,121 |  |  | 47.1 |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | 145,874 |  |  | 94,777 |  |  | 51,097 |  |  | 53.9 |  | 390,116 |  |  | 261,711 |  |  | 128,405 |  |  | 49.1 |
| Service | 11,142 |  |  | 9,064 |  |  | 2,078 |  |  | 22.9 |  | 33,599 |  |  | 26,526 |  |  | 7,073 |  |  | 26.7 |
| Total cost of revenue | 157,016 |  |  | 103,841 |  |  | 53,175 |  |  | 51.2 |  | 423,715 |  |  | 288,237 |  |  | 135,478 |  |  | 47.0 |
| Gross profit | $ | 280,617 |  |  | $ | 186,420 |  |  | $ | 94,197 |  |  | 50.5% |  | $ | 754,604 |  |  | $ | 512,961 |  |  | $ | 241,643 |  |  | 47.1% |
| Gross margin | 64.1 | % |  | 64.2 | % |  |  |  |  |  | 64.0 | % |  | 64.0 | % |  |  |  |  |

[0001596532-17-000251:mdna:27]
[same as prior period, unchanged from 0001596532-17-000201:mdna:24]

[0001596532-17-000251:mdna:28]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2017 |  | % of Total |  | 2016 |  | % of Total |  | 2017 |  | % of Total |  | 2016 |  | % of Total |
|  | (in thousands, except percentages) |
| Americas | $ | 309,318 |  |  | 70.7 | % |  | $ | 237,099 |  |  | 81.7 | % |  | $ | 878,201 |  |  | 74.5 | % |  | $ | 621,057 |  |  | 77.5 | % |
| Europe, Middle East and Africa | 79,143 |  |  | 18.1 |  |  | 37,728 |  |  | 13.0 |  |  | 199,244 |  |  | 16.9 |  |  | 124,111 |  |  | 15.5 |  |
| Asia-Pacific | 49,172 |  |  | 11.2 |  |  | 15,434 |  |  | 5.3 |  |  | 100,874 |  |  | 8.6 |  |  | 56,030 |  |  | 7.0 |  |
| Total revenue | $ | 437,633 |  |  | 100.0 | % |  | $ | 290,261 |  |  | 100.0 | % |  | $ | 1,178,319 |  |  | 100.0 | % |  | $ | 801,198 |  |  | 100.0 | % |

[0001596532-17-000251:mdna:29]
[same as prior period, unchanged from 0001596532-17-000201:mdna:26]

[0001596532-17-000251:mdna:30]
Product revenue increased 49.6% in the three months ended September 30, 2017 and 46.0% in the nine months ended September 30, 2017, compared to the same periods in 2016.  The increase in each period was primarily driven by increased product shipments to our existing customers as they continued to expand their businesses.  In addition, our newer switch products have continued to gain market acceptance, which has contributed to our revenue growth.  Service revenue increased 59.0% in the three months ended September 30, 2017 and 54.5% in the nine months ended September 30, 2017, compared to the same periods in 2016, as a result of continued growth in initial and renewal support contracts as our customer installed base continued to expand.  We continue to experience pressure on both product and service pricing due to competitive market conditions, but demand for our products and growth in our installed base has more than offset this pricing pressure.  As we enter the fourth quarter of 2017, we expect to continue to work with customers to complete the qualification of our 945 related product redesigns, and this may have some impact on our business for the quarter.

[0001596532-17-000251:mdna:31]
[same as prior period, unchanged from 0001596532-17-000201:mdna:28]

[0001596532-17-000251:mdna:32]
Cost of revenue increased $53.2 million in the three months ended September 30, 2017 and $135.5 million for the nine months ended September 30, 2017, compared to the same periods in 2016. The increase in cost of revenue was primarily due to an increase in product shipment volumes and the corresponding increase in product revenue. Gross margin remained generally consistent, decreasing slightly from 64.2% to 64.1% for the three months ended September 30, 2017 and remained the same at

[0001596532-17-000251:mdna:33]
64.0% for the nine months ended September 30, 2017, compared to the same periods in 2016.  Gross margin benefited from improved service margins as we scale our services business, on a relatively fixed cost base.  This improvement was largely offset by slightly lower product margins reflecting a somewhat higher mix of shipments to larger end customers who receive lower pricing terms due to volume discounts and some increase in inventory related costs.

[0001596532-17-000251:mdna:34]
[same as prior period, unchanged from 0001596532-17-000201:mdna:31]

[0001596532-17-000251:mdna:35]
[same as prior period, unchanged from 0001596532-17-000201:mdna:32]

[0001596532-17-000251:mdna:36]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2017 |  | 2016 |  | Change in |  | 2017 |  | 2016 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
|  | (in thousands, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 79,610 |  |  | $ | 70,648 |  |  | $ | 8,962 |  |  | 12.7% |  | $ | 242,414 |  |  | $ | 202,183 |  |  | $ | 40,231 |  |  | 19.9% |
| Sales and marketing | 40,640 |  |  | 33,216 |  |  | 7,424 |  |  | 22.4 |  | 116,297 |  |  | 92,566 |  |  | 23,731 |  |  | 25.6 |
| General and administrative | 19,535 |  |  | 19,535 |  |  | — |  |  | — |  | 65,009 |  |  | 52,298 |  |  | 12,711 |  |  | 24.3 |
| Total operating expenses | $ | 139,785 |  |  | $ | 123,399 |  |  | $ | 16,386 |  |  | 13.3% |  | $ | 423,720 |  |  | $ | 347,047 |  |  | $ | 76,673 |  |  | 22.1% |

[0001596532-17-000251:mdna:37]
[same as prior period, unchanged from 0001596532-17-000201:mdna:34]

[0001596532-17-000251:mdna:38]
[same as prior period, unchanged from 0001596532-17-000201:mdna:35]

[0001596532-17-000251:mdna:39]
Research and development expenses increased for the three and nine months ended September 30, 2017 compared to the same periods in 2016.  The increase in each period was primarily due to increased personnel costs of $11.0 million and $25.6 million in the three and nine months ended September 30, 2017, respectively as compared to the same periods in 2016.  These increases were driven by headcount growth, resulting in additional compensation costs including stock-based compensation.  In addition, prototype, third-party engineering and consulting costs declined by $2.9 million and grew $11.8 million in the three and nine months ended September 30, 2017, respectively as compared to the same periods in 2016.  The decline in the three month period was primarily due to timing of projects, while the growth in the nine month period was driven by additional outsourced development projects and costs associated with litigation-related changes in product design.

[0001596532-17-000251:mdna:40]
[same as prior period, unchanged from 0001596532-17-000201:mdna:37]

[0001596532-17-000251:mdna:41]
[same as prior period, unchanged from 0001596532-17-000201:mdna:38]

[0001596532-17-000251:mdna:42]
Sales and marketing expenses increased for the three and nine months ended September 30, 2017 compared to the same periods in 2016. The increase in each period was driven by personnel costs which increased by $4.0 million and $16.0 million in the three and nine months ended September 30, 2017, respectively as compared to the same periods in 2016.  These increases were primarily due to headcount growth and higher sales volumes, driving increased compensation costs, including commissions and stock-based compensation.  In addition, sales support costs increased by $2.8 million and $6.9 million, in the three and nine months ended September 30, 2017, respectively as compared to the same periods in 2016, reflecting increased professional services and field demonstration costs to support our sales infrastructure and expand our customer base.

[0001596532-17-000251:mdna:43]
[same as prior period, unchanged from 0001596532-17-000201:mdna:40]

[0001596532-17-000251:mdna:44]
General and administrative expenses consist primarily of Cisco and Optumsoft litigation related expenses, personnel costs, professional services, and an allocated portion of facility and IT costs. General and administrative personnel costs include those for our executive, finance, human resources and legal functions. Our professional services costs are primarily due to external legal, accounting, and tax services.

[0001596532-17-000251:mdna:45]
General and administrative expenses remained consistent for the three months ended September 30, 2017, and increased for the nine months ended September 30, 2017 compared to the same periods in 2016.  The increase in the nine month period was primarily related to Cisco litigation related expenses of $7.7 million, which included bond costs associated with the importation and sale of affected products and components during the presidential review period of the 945 investigation.  In addition, personnel costs increased by $3.4 million during the nine month period driven by increased compensation costs, including stock-based compensation costs.

[0001596532-17-000251:mdna:46]
[same as prior period, unchanged from 0001596532-17-000201:mdna:44]

[0001596532-17-000251:mdna:47]
Other income (expense), net primarily consists of interest income on cash and marketable securities and foreign currency transaction gains and losses, and interest expense from our lease financing obligation.

[0001596532-17-000251:mdna:48]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2017 |  | 2016 |  | Change in |  | 2017 |  | 2016 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
|  | (in thousands, except percentages) |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | $ | (701 | ) |  | $ | (735 | ) |  | $ | 34 |  |  | 4.6% |  | $ | (2,039 | ) |  | $ | (2,218 | ) |  | $ | 179 |  |  | 8.1% |
| Other income (expense), net | 2,136 |  |  | 639 |  |  | 1,497 |  |  | 234.3 |  | 4,280 |  |  | 1,392 |  |  | 2,888 |  |  | (207.5) |
| Total other income (expense), net | $ | 1,435 |  |  | $ | (96 | ) |  | $ | 1,531 |  |  | 1,594.8% |  | $ | 2,241 |  |  | $ | (826 | ) |  | $ | 3,067 |  |  | 371.3% |

[0001596532-17-000251:mdna:49]
[same as prior period, unchanged from 0001596532-17-000201:mdna:47]

[0001596532-17-000251:mdna:50]
Other income (expense), net improved during the three and nine months ended September 30, 2017 compared to the same periods in 2016 primarily due to an increase in interest income resulting from an increase in our marketable securities portfolio,  combined with improved returns on our portfolio.

[0001596532-17-000251:mdna:51]
[same as prior period, unchanged from 0001596532-17-000201:mdna:49]

[0001596532-17-000251:mdna:52]
[same as prior period, unchanged from 0001596532-17-000201:mdna:50]

[0001596532-17-000251:mdna:53]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2017 |  | 2016 |  | Change in |  | 2017 |  | 2016 |  | Change in |
|  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
|  | (in thousands, except percentages) |
| Provision (benefit) for income taxes | $ | 8,545 |  |  | $ | 11,668 |  |  | $ | (3,123 | ) |  | (26.8)% |  | $ | 13,757 |  |  | $ | 39,682 |  |  | $ | (25,925 | ) |  | (65.3)% |
| Effective tax rate | 6.0 | % |  | 18.5 | % |  |  |  |  |  | 4.1 | % |  | 24.0 | % |  |  |  |  |

[0001596532-17-000251:mdna:54]
The effective tax rate for the three and nine months ended September 30, 2017 was significantly lower than the U.S. federal statutory rate primarily due to the recognition of excess tax benefits resulting from the adoption of ASU 2016-09, and earnings taxed at lower rates in foreign jurisdictions.  The decrease in the effective tax rate in the three and nine months ended September 30, 2017, as compared to the same periods in 2016, was primarily due to the recognition of excess tax benefits as a component of the provision for income taxes attributable to the adoption of ASU 2016-09.  Prior to the adoption, these benefits were recorded as a component of shareholders' equity. Our future effective tax rate may fluctuate based upon our stock price and the amount of stock options exercised and equity awards vested in the quarter.

[0001596532-17-000251:mdna:55]
[same as prior period, unchanged from 0001596532-17-000201:mdna:53]

[0001596532-17-000251:mdna:56]
Our principal sources of liquidity are cash and cash equivalents, marketable securities, and cash generated from operations. As of September 30, 2017, cash and cash equivalents, and marketable securities were $1.3 billion, of which approximately $198.3

[0001596532-17-000251:mdna:57]
million was held outside the U.S. in our foreign subsidiaries.  We have not repatriated, nor do we currently have plans to repatriate these funds, but if we were to repatriate cash held outside of the U.S. for domestic cash operations, we would be required to accrue and pay U.S. income taxes to repatriate these funds, less any previously paid foreign income taxes. We consider the undistributed earnings of our foreign subsidiaries as of September 30, 2017 to be indefinitely reinvested, and, accordingly, no U.S. income taxes have been provided thereon.

[0001596532-17-000251:mdna:58]
Our cash and cash equivalents, and marketable securities are held for working capital purposes. We plan to continue to invest for long-term growth. We believe that our existing cash and cash equivalents together with cash flows from operations will be sufficient to meet our working capital requirements and our growth strategies for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs and access to outsourcing our manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and costs incurred related to outstanding litigation claims. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-17-000251:mdna:59]
[same as prior period, unchanged from 0001596532-17-000201:mdna:57]

[0001596532-17-000251:mdna:60]
|  | Nine Months EndedSeptember 30, |
|  | 2017 |  | 2016 |
|  | (in thousands) |
| Cash provided by operating activities | $ | 447,963 |  |  | $ | 108,728 |  |
| Cash used in investing activities | (200,347 | ) |  | (319,551 | ) |
| Cash provided by financing activities | 38,243 |  |  | 24,111 |  |
| Effect of exchange rate changes | 697 |  |  | (133 | ) |
| Net increase (decrease) in cash and cash equivalents | $ | 286,556 |  |  | $ | (186,845 | ) |

[0001596532-17-000251:mdna:61]
[same as prior period, unchanged from 0001596532-17-000201:mdna:59]

[0001596532-17-000251:mdna:62]
During the nine months ended September 30, 2017, cash provided by operating activities was $448.0 million, resulting from net income of $319.4 million, non-cash adjustments to net income of $48.7 million, and a net increase in cash from changes in our operating assets and liabilities of $79.9 million.  Our operating cash benefited from increased deferred revenue of $192.2 million resulting from growth in product and service deferred revenue related to contract acceptance terms and ongoing growth in PCS contracts.  We also experienced strong cash collections on accounts receivable during the period generating $40.5 million in cash.  These increases were partially offset by growth in inventory of $96.7 million, supporting overall growth in the business and the expansion of our manufacturing and supply chain activities, with a decline in accounts payable of $46.1 million related to timing of vendor payments related to inventory purchases.  Prepaid expenses and other assets increased by $22.5 million primarily due to higher deferred cost of inventory associated with the increased product revenue deferrals referenced above, partially offset by a reduction in inventory deposits.

[0001596532-17-000251:mdna:63]
During the nine months ended September 30, 2016, cash provided by operating activities was $108.7 million, primarily from net income of $125.4 million, non-cash adjustments to net income of $44.8 million, partially offset by a net decrease in cash from changes in our operating assets and liabilities of $61.5 million.  The decrease in cash from changes in operating assets and liabilities was primarily due to an increase in accounts receivable of $66.0 million related to increased shipment volume, and an increase in net inventory of $70.0 million, and deposits of $62.6 million related to the expansion of our contract manufacturing and supply chain activities. The cash outflows for inventory-related activity were primarily related to ramping production activities at our new contract manufacturer. These cash outflows were offset by cash inflows from an increase in deferred revenue of $88.0 million primarily related to new and renewed PCS contracts and product deferrals related to contract acceptance terms and future deliverables, an increase in accounts payable of $35.5 million primarily due to increased inventory purchases and timing of vendor payments, an increase in cash of $27.3 million from changes in income taxes payable and an increase in accrued liabilities of $15.9 million primarily from corporate bonus and compensation-related accruals.

[0001596532-17-000251:mdna:64]
[same as prior period, unchanged from 0001596532-17-000201:mdna:76]

[0001596532-17-000251:mdna:65]
[same as prior period, unchanged from 0001596532-17-000201:mdna:62]

[0001596532-17-000251:mdna:66]
During the nine months ended September 30, 2017, cash used in investing activities was $200.3 million, consisting primarily of purchases of available-for-sale securities of $325.4 million, offset by proceeds of $135.5 million and purchases of property, equipment and other assets of $12.2 million.

[0001596532-17-000251:mdna:67]
During the nine months ended September 30, 2016, cash used in investing activities was $319.6 million, consisting of purchases of available-for-sale securities of $342.5 million, purchases of property, equipment and other assets of $16.5 million, and an additional investment in a privately-held company of $2.5 million.

[0001596532-17-000251:mdna:68]
[same as prior period, unchanged from 0001596532-17-000201:mdna:65]

[0001596532-17-000251:mdna:69]
During the nine months ended September 30, 2017, cash provided by financing activities was $38.2 million, consisting primarily of proceeds from the issuance of common stock under employee equity incentive plans of $41.9 million, offset by minimum tax withheld for employees $2.5 million and payments for lease financing obligations of $1.2 million.

[0001596532-17-000251:mdna:70]
During the nine months ended September 30, 2016, cash provided by financing activities was $24.1 million, consisting primarily of proceeds from equity incentive plans of $25.9 million, offset by minimum tax withheld for employees and payments for lease financing obligations of $1.8 million.

[0001596532-17-000251:mdna:71]
[same as prior period, unchanged from 0001596532-17-000201:mdna:68]

[0001596532-17-000251:mdna:72]
As of September 30, 2017, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-17-000251:mdna:73]
[same as prior period, unchanged from 0001596532-17-000201:mdna:70]

[0001596532-17-000251:mdna:74]
As of September 30, 2017, our principal commitments consist of obligations under operating leases and purchase commitments. There have been no significant changes to these obligations during the nine months ended September 30, 2017, compared to the contractual obligations disclosed in our "Management's Discussion and Analysis of Financial Condition and Results of Operations" included in our Annual Report on Form 10-K, filed with the SEC on February 17, 2017, other than the purchase commitments described in Note 5. Commitments and Contingencies of Notes to Condensed Consolidated Financial Statements of this Quarterly Report on Form 10-Q.

[0001596532-17-000251:mdna:75]
[same as prior period, unchanged from 0001596532-17-000201:mdna:72]

[0001596532-17-000251:mdna:76]
[same as prior period, unchanged from 0001596532-17-000201:mdna:73]

[0001596532-17-000251:mdna:77]
[same as prior period, unchanged from 0001596532-17-000201:mdna:74]

[0001596532-17-000251:mdna:78]
[same as prior period, unchanged from 0001596532-17-000201:mdna:75]
