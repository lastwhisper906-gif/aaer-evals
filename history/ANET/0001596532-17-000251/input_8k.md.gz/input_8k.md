# ANET 8-K — 0001596532-17-000249 filed 2017-11-02

## item codes, every 8-K on or before 2017-11-03

- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2017-11-03

- none on or before 2017-11-03

## item 2.02 — earnings release, exhibit 99.1

[0001596532-17-000249:8k_2_02:1]
EX-99.1
2
ex991q317-earningsrelease.htm
EXHIBIT 99.1

[0001596532-17-000249:8k_2_02:2]
Exhibit

[0001596532-17-000249:8k_2_02:3]
Exhibit 99.1

[0001596532-17-000249:8k_2_02:4]
Arista Networks, Inc. Reports Third Quarter 2017 Financial Results

[0001596532-17-000249:8k_2_02:5]
Cloud Networking Adoption Continues with Record Revenue and EPS

[0001596532-17-000249:8k_2_02:6]
SANTA CLARA, Calif.-- November 2, 2017 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large datacenter and computing environments, today announced financial results for its third quarter ended September 30, 2017.

[0001596532-17-000249:8k_2_02:7]
Third Quarter Financial Highlights

[0001596532-17-000249:8k_2_02:8]
| • | Revenue of $437.6 million, an increase of 8.0% compared to the second quarter of 2017, and an increase of 50.8% from the third quarter of 2016. |

[0001596532-17-000249:8k_2_02:9]
| • | GAAP gross margin of 64.1%, compared to GAAP gross margin of 64.1% in the second quarter of 2017 and 64.2% in the third quarter of 2016. |

[0001596532-17-000249:8k_2_02:10]
| • | Non-GAAP gross margin of 64.4%, compared to non-GAAP gross margin of 64.4% in the second quarter of 2017 and 64.6% in the third quarter of 2016. |

[0001596532-17-000249:8k_2_02:11]
| • | GAAP net income of $133.7 million, or $1.68 per diluted share, compared to GAAP net income of $51.3 million, or $0.69 per diluted share, in the third quarter of 2016. |

[0001596532-17-000249:8k_2_02:12]
| • | Non-GAAP net income of $128.2 million, or $1.62 per diluted share, compared to non-GAAP net income of $61.2 million, or $0.83 per diluted share, in the third quarter of 2016. |

[0001596532-17-000249:8k_2_02:13]
"I am proud of our record results and profits in Q3 2017,” stated Jayshree Ullal, Arista President and CEO. “Our performance validates our meaningful traction with customers as they evolve from legacy to universal cloud networking designs.”

[0001596532-17-000249:8k_2_02:14]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, “We are pleased with our execution and strong financial performance in the quarter".

[0001596532-17-000249:8k_2_02:15]
Company Highlights

[0001596532-17-000249:8k_2_02:16]
| • | Introduced Arista Any Cloud software platform, reducing operational costs and complexity for enterprises by simplifying integration and management of hybrid clouds across private cloud datacenters and public cloud providers. |

[0001596532-17-000249:8k_2_02:17]
| • | Arista Networks makes the top 10 in FORTUNE magazine’s 100 Fastest-Growing Companies September 2017 issue. |

[0001596532-17-000249:8k_2_02:18]
Financial Outlook

[0001596532-17-000249:8k_2_02:19]
For the fourth quarter of 2017, we expect:

[0001596532-17-000249:8k_2_02:20]
| • | Revenue between $450 and $464 million. |

[0001596532-17-000249:8k_2_02:21]
| • | Non-GAAP gross margin between 63% to 65%, and |

[0001596532-17-000249:8k_2_02:22]
| • | Non-GAAP operating margin between 30% and 32% |

[0001596532-17-000249:8k_2_02:23]
Guidance for non-GAAP financial measures excludes legal expenses of approximately $12 million associated with the OptumSoft and Cisco litigation, stock-based compensation expense, including excess tax benefits on stock-based awards, and other non-recurring expenses. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below).

[0001596532-17-000249:8k_2_02:24]
Prepared Materials and Conference Call Information

[0001596532-17-000249:8k_2_02:25]
Arista executives will discuss third quarter 2017 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (833) 287-7905 in the United States or (647) 689-4469 from outside the US. The Conference ID is 94689018.

[0001596532-17-000249:8k_2_02:26]
The financial results conference call will also be available via live webcast on our investor relations website at http://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s Investor Relations website.

[0001596532-17-000249:8k_2_02:27]
Forward-Looking Statements

[0001596532-17-000249:8k_2_02:28]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the fourth quarter of fiscal 2017, and statements regarding the benefits from the introduction of new products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: Arista Networks’ dispute with Cisco Systems, Inc. including the ITC remedial orders which prohibit the importation of Arista products (or components thereof) into the U.S., or the sale of previously imported products,  that are covered by those remedial orders, Arista Networks’ ability to redesign its products in a manner not covered by such remedial

[0001596532-17-000249:8k_2_02:29]
orders and obtain appropriate governmental approvals for those redesigned products, any penalties assessed by the ITC if Arista’s redesigned products are covered by such remedial orders and Arista Networks’ ability to manage our manufacturing and supply chain including the sourcing of components on commercially reasonable terms; Arista Networks’ limited operating history; Arista Networks’ rapid growth; Arista Networks’ customer concentration;  our customer’s adoption of our redesigned products and services; requests for more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; changes in customer demand for our products and services, customer order patterns or customer mix; the timing of orders and manufacturing and customer lead times; increased competition in our products and service markets; dependence on the introduction and market acceptance of new product offerings and standards; rapid technological and market change; the evolution of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; Arista Networks’ dispute with OptumSoft; and general market, political, economic and business conditions. Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s most recent Quarterly Report on Form 10-Q filed with the SEC on August 4, 2017, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at http://investors.arista.com/and on the SEC’s website at http://www.sec.gov/.  All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-17-000249:8k_2_02:30]
Non-GAAP Financial Measures

[0001596532-17-000249:8k_2_02:31]
The company reports certain non-GAAP financial measures that exclude stock-based compensation expense and related excess tax benefits, expenses associated with the OptumSoft and Cisco litigation, other non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-17-000249:8k_2_02:32]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP net income, net income per diluted share, gross margin, or operating margin. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-17-000249:8k_2_02:33]
The Company’s guidance for non-GAAP financial measures excludes stock-based compensation expense and related excess tax benefits, expenses associated with the OptumSoft and Cisco litigation, and other non-recurring items. The Company has not reconciled its non-GAAP gross margin or its non-GAAP operating margin guidance to GAAP gross margin or GAAP operating margin, because we do not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. Stock-based compensation expense is impacted by the Company’s future hiring and retention needs and the future fair market value of the Company’s common stock.  In addition, excess tax benefits on stock-based awards will fluctuate based on these same factors, as well as the timing of exercise or vesting of such awards, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense and excess tax benefits will have a significant impact on the Company’s GAAP gross margin and GAAP operating margin. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measure is not available without unreasonable effort.

[0001596532-17-000249:8k_2_02:34]
About Arista Networks

[0001596532-17-000249:8k_2_02:35]
Arista Networks was founded to pioneer and deliver software-driven cloud networking solutions for large datacenter storage and computing environments. Arista’s award-winning platforms, ranging in Ethernet speeds from 10 to 100 gigabits per second, redefine scalability, agility and resilience. Arista has shipped more than ten million cloud networking ports worldwide with CloudVision and EOS, an advanced network operating system. Committed to open standards, Arista is a founding member of the 25/50GbE consortium. Arista Networks products are available worldwide directly and through partners.

[0001596532-17-000249:8k_2_02:36]
ARISTA, EOS, CloudVision, and AlgoMatch are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-17-000249:8k_2_02:37]
Additional information and resources can be found at: http://www.arista.com/

[0001596532-17-000249:8k_2_02:38]
| Media ContactAmanda JaramilloCorporate Communications(408) 547-5798amanda@arista.com |  | Investor ContactCharles YagerProduct and Investor Advocacy(408) 547-5892cyager@arista.com |

[0001596532-17-000249:8k_2_02:39]
ARISTA NETWORKS, INC.

[0001596532-17-000249:8k_2_02:40]
Condensed Consolidated Statements of Income

[0001596532-17-000249:8k_2_02:41]
(Unaudited in thousands, except per share amounts)

[0001596532-17-000249:8k_2_02:42]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenue: |  |  |  |  |  |  |  |
| Product | $ | 380,344 |  |  | $ | 254,238 |  |  | $ | 1,025,615 |  |  | $ | 702,329 |  |
| Service | 57,289 |  |  | 36,023 |  |  | 152,704 |  |  | 98,869 |  |
| Total revenue | 437,633 |  |  | 290,261 |  |  | 1,178,319 |  |  | 801,198 |  |
| Cost of revenue: |  |  |  |  |  |  |  |
| Product | 145,874 |  |  | 94,777 |  |  | 390,116 |  |  | 261,711 |  |
| Service | 11,142 |  |  | 9,064 |  |  | 33,599 |  |  | 26,526 |  |
| Total cost of revenue | 157,016 |  |  | 103,841 |  |  | 423,715 |  |  | 288,237 |  |
| Total gross profit | 280,617 |  |  | 186,420 |  |  | 754,604 |  |  | 512,961 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 79,610 |  |  | 70,648 |  |  | 242,414 |  |  | 202,183 |  |
| Sales and marketing | 40,640 |  |  | 33,216 |  |  | 116,297 |  |  | 92,566 |  |
| General and administrative | 19,535 |  |  | 19,535 |  |  | 65,009 |  |  | 52,298 |  |
| Total operating expenses | 139,785 |  |  | 123,399 |  |  | 423,720 |  |  | 347,047 |  |
| Income from operations | 140,832 |  |  | 63,021 |  |  | 330,884 |  |  | 165,914 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (701 | ) |  | (735 | ) |  | (2,039 | ) |  | (2,218 | ) |
| Other income (expense), net | 2,136 |  |  | 639 |  |  | 4,280 |  |  | 1,392 |  |
| Total other income (expense), net | 1,435 |  |  | (96 | ) |  | 2,241 |  |  | (826 | ) |
| Income before provision for income taxes | 142,267 |  |  | 62,925 |  |  | 333,125 |  |  | 165,088 |  |
| Provision for income taxes | 8,545 |  |  | 11,668 |  |  | 13,757 |  |  | 39,682 |  |
| Net income | $ | 133,722 |  |  | $ | 51,257 |  |  | $ | 319,368 |  |  | $ | 125,406 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 133,540 |  |  | $ | 50,962 |  |  | $ | 318,643 |  |  | $ | 124,475 |  |
| Diluted | $ | 133,555 |  |  | $ | 50,980 |  |  | $ | 318,704 |  |  | $ | 124,531 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 1.84 |  |  | $ | 0.74 |  |  | $ | 4.43 |  |  | $ | 1.82 |  |
| Diluted | $ | 1.68 |  |  | $ | 0.69 |  |  | $ | 4.06 |  |  | $ | 1.71 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | 72,588 |  |  | 69,076 |  |  | 71,903 |  |  | 68,365 |  |
| Diluted | 79,322 |  |  | 73,453 |  |  | 78,528 |  |  | 72,811 |  |

[0001596532-17-000249:8k_2_02:43]
ARISTA NETWORKS, INC.

[0001596532-17-000249:8k_2_02:44]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-17-000249:8k_2_02:45]
(Unaudited in thousands, except percentages and per share amounts)

[0001596532-17-000249:8k_2_02:46]
|  | Three Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| GAAP gross profit | $ | 280,617 |  |  | $ | 186,420 |  |  | $ | 754,604 |  |  | $ | 512,961 |  |
| GAAP gross margin | 64.1 | % |  | 64.2 | % |  | 64.0 | % |  | 64.0 | % |
| Stock-based compensation expense | 1,113 |  |  | 955 |  |  | 3,224 |  |  | 2,616 |  |
| Non-GAAP gross profit | $ | 281,730 |  |  | $ | 187,375 |  |  | $ | 757,828 |  |  | $ | 515,577 |  |
| Non-GAAP gross margin | 64.4 | % |  | 64.6 | % |  | 64.3 | % |  | 64.4 | % |
| GAAP income from operations | $ | 140,832 |  |  | $ | 63,021 |  |  | $ | 330,884 |  |  | $ | 165,914 |  |
| Stock-based compensation expense | 20,152 |  |  | 15,116 |  |  | 54,991 |  |  | 42,708 |  |
| Litigation expense | 7,857 |  |  | 9,025 |  |  | 31,280 |  |  | 23,624 |  |
| Non-GAAP income from operations | $ | 168,841 |  |  | $ | 87,162 |  |  | $ | 417,155 |  |  | $ | 232,246 |  |
| Non-GAAP operating margin | 38.6 | % |  | 30.0 | % |  | 35.4 | % |  | 29.0 | % |
| GAAP net income | $ | 133,722 |  |  | $ | 51,257 |  |  | $ | 319,368 |  |  | $ | 125,406 |  |
| Stock-based compensation expense | 20,152 |  |  | 15,116 |  |  | 54,991 |  |  | 42,708 |  |
| Litigation expense | 7,857 |  |  | 9,025 |  |  | 31,280 |  |  | 23,624 |  |
| Excess tax benefit on share based awards | (23,826 | ) |  | — |  |  | (71,695 | ) |  | — |  |
| Release of income tax reserve | — |  |  | (6,293 | ) |  | — |  |  | (6,293 | ) |
| Income tax effect on non-GAAP exclusions | (9,683 | ) |  | (7,924 | ) |  | (28,445 | ) |  | (21,504 | ) |
| Non-GAAP net income | $ | 128,222 |  |  | $ | 61,181 |  |  | $ | 305,499 |  |  | $ | 163,941 |  |
| GAAP diluted net income per share attributable to common stockholders | $ | 1.68 |  |  | $ | 0.69 |  |  | $ | 4.06 |  |  | $ | 1.71 |  |
| Non-GAAP adjustments to net income | (0.06 | ) |  | 0.14 |  |  | (0.17 | ) |  | 0.54 |  |
| Non-GAAP diluted net income per share | $ | 1.62 |  |  | $ | 0.83 |  |  | $ | 3.89 |  |  | $ | 2.25 |  |
| Weighted-average shares used in computing diluted net income per share attributable to common stockholders | 79,322 |  |  | 73,453 |  |  | 78,528 |  |  | 72,811 |  |
| Summary of Stock-Based Compensation Expense |  |  |  |  |  |  |  |
| Cost of revenue | $ | 1,113 |  |  | $ | 955 |  |  | $ | 3,224 |  |  | $ | 2,616 |  |
| Research and development | 11,048 |  |  | 8,010 |  |  | 30,977 |  |  | 23,062 |  |
| Sales and marketing | 5,115 |  |  | 3,947 |  |  | 12,651 |  |  | 11,374 |  |
| General and administrative | 2,876 |  |  | 2,204 |  |  | 8,139 |  |  | 5,656 |  |
| Total | $ | 20,152 |  |  | $ | 15,116 |  |  | $ | 54,991 |  |  | $ | 42,708 |  |

[0001596532-17-000249:8k_2_02:47]
ARISTA NETWORKS, INC.

[0001596532-17-000249:8k_2_02:48]
Condensed Consolidated Balance Sheets

[0001596532-17-000249:8k_2_02:49]
(Unaudited in thousands)

[0001596532-17-000249:8k_2_02:50]
|  | September 30, 2017 |  | December 31, 2016 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 854,479 |  |  | $ | 567,923 |  |
| Marketable securities | 488,635 |  |  | 299,910 |  |
| Accounts receivable | 212,611 |  |  | 253,119 |  |
| Inventories | 333,157 |  |  | 236,490 |  |
| Prepaid expenses and other current assets | 186,657 |  |  | 168,684 |  |
| Total current assets | 2,075,539 |  |  | 1,526,126 |  |
| Property and equipment, net | 73,061 |  |  | 76,961 |  |
| Investments | 36,136 |  |  | 36,136 |  |
| Deferred tax assets | 95,697 |  |  | 70,960 |  |
| Other assets | 21,277 |  |  | 18,824 |  |
| TOTAL ASSETS | $ | 2,301,710 |  |  | $ | 1,729,007 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 32,893 |  |  | $ | 79,457 |  |
| Accrued liabilities | 94,459 |  |  | 90,951 |  |
| Deferred revenue | 423,705 |  |  | 273,350 |  |
| Other current liabilities | 16,490 |  |  | 15,795 |  |
| Total current liabilities | 567,547 |  |  | 459,553 |  |
| Income taxes payable | 22,161 |  |  | 14,498 |  |
| Lease financing obligations, non-current | 38,199 |  |  | 39,593 |  |
| Deferred revenue, non-current | 141,440 |  |  | 99,585 |  |
| Other long-term liabilities | 7,811 |  |  | 7,958 |  |
| TOTAL LIABILITIES | 777,158 |  |  | 621,187 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Common stock | 7 |  |  | 7 |  |
| Additional paid-in capital | 770,339 |  |  | 674,183 |  |
| Retained earnings | 755,281 |  |  | 435,105 |  |
| Accumulated other comprehensive loss | (1,075 | ) |  | (1,475 | ) |
| TOTAL STOCKHOLDERS’ EQUITY | 1,524,552 |  |  | 1,107,820 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 2,301,710 |  |  | $ | 1,729,007 |  |

[0001596532-17-000249:8k_2_02:51]
ARISTA NETWORKS, INC.

[0001596532-17-000249:8k_2_02:52]
Condensed Consolidated Statements of Cash Flows

[0001596532-17-000249:8k_2_02:53]
(Unaudited in thousands)

[0001596532-17-000249:8k_2_02:54]
|  | Nine Months EndedSeptember 30, |
|  | 2017 |  | 2016 |
| Cash flows from operating activities |  |  |  |
| Net income | $ | 319,368 |  |  | $ | 125,406 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 15,355 |  |  | 14,807 |  |
| Stock-based compensation | 54,991 |  |  | 42,708 |  |
| Deferred income taxes | (22,743 | ) |  | (13,720 | ) |
| Amortization of investment premiums | 1,106 |  |  | 994 |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable, net | 40,508 |  |  | (65,980 | ) |
| Inventories | (96,667 | ) |  | (69,998 | ) |
| Prepaid expenses and other current assets | (20,973 | ) |  | (98,050 | ) |
| Other assets | (1,560 | ) |  | 3,208 |  |
| Accounts payable | (46,075 | ) |  | 35,510 |  |
| Accrued liabilities | 4,175 |  |  | 15,913 |  |
| Deferred revenue | 192,210 |  |  | 88,027 |  |
| Income taxes payable | 7,421 |  |  | 27,275 |  |
| Other liabilities | 847 |  |  | 2,628 |  |
| Net cash provided by operating activities | 447,963 |  |  | 108,728 |  |
| Cash flows from investing activities |  |  |  |
| Proceeds from marketable securities | 135,483 |  |  | 41,917 |  |
| Purchases of marketable securities | (325,414 | ) |  | (342,484 | ) |
| Purchases of property and equipment | (12,159 | ) |  | (16,484 | ) |
| Proceeds from repayment of notes receivable | 3,000 |  |  | — |  |
| Investment in privately-held companies | — |  |  | (2,500 | ) |
| Change in restricted cash | (1,257 | ) |  | — |  |
| Net cash used in investing activities | (200,347 | ) |  | (319,551 | ) |
| Cash flows from financing activities |  |  |  |
| Principal payments of lease financing obligations | (1,170 | ) |  | (960 | ) |
| Proceeds from issuance of common stock under equity plans | 41,870 |  |  | 25,882 |  |
| Minimum tax withholding paid on behalf of employees for net share settlement | (2,457 | ) |  | (811 | ) |
| Net cash provided by financing activities | 38,243 |  |  | 24,111 |  |
| Effect of exchange rate changes | 697 |  |  | (133 | ) |
| NET INCREASE (DECREASE) IN CASH AND CASH EQUIVALENTS | 286,556 |  |  | (186,845 | ) |
| CASH AND CASH EQUIVALENTS—Beginning of period | 567,923 |  |  | 687,326 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 854,479 |  |  | $ | 500,481 |  |
