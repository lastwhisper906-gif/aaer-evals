# ANET notes — 0001596532-20-000148


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-20-000148:notes:1]
[same as prior period, unchanged from 0001628280-20-006504:notes:1]

[0001596532-20-000148:notes:2]
[same as prior period, unchanged from 0001628280-20-006504:notes:2]

[0001596532-20-000148:notes:3]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System ("EOS"), a set of network applications and our 1/2.5/5/10/25/40/50/100/400 Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-20-000148:notes:4]
[same as prior period, unchanged from 0001628280-20-006504:notes:4]

[0001596532-20-000148:notes:5]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2020, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2019 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

[0001596532-20-000148:notes:6]
[same as prior period, unchanged from 0001628280-20-006504:notes:6]

[0001596532-20-000148:notes:7]
[same as prior period, unchanged from 0001628280-20-006504:notes:7]

[0001596532-20-000148:notes:8]
[same as prior period, unchanged from 0001628280-20-006504:notes:8]

[0001596532-20-000148:notes:9]
[same as prior period, unchanged from 0001628280-20-006504:notes:9]

[0001596532-20-000148:notes:10]
The global coronavirus ("COVID-19") pandemic and resulting mitigation efforts by governments around the world to contain or slow its spread have negatively impacted the global economy, disrupted business, sales activities, global supply chains and workforce participation, including our own, and created significant volatility and disruption of financial markets.

[0001596532-20-000148:notes:11]
Our contract manufacturers and suppliers have experienced and continue to experience delays in the production and export of their products, which have negatively impacted our supply chain and could negatively impact our business in the future. In addition, we expect that COVID-19 related disruptions may have a negative impact on demand from our customers in future periods and contribute to an expected year-over-year decline in revenues for the year ending December 31, 2020. However, the extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, including the duration and spread of the pandemic and related mitigation efforts, as well as restrictions on travel and transport, all of which are uncertain and cannot be predicted. Management is actively monitoring the impact of the pandemic on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which the COVID-19 pandemic may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

[0001596532-20-000148:notes:12]
Recently Adopted Accounting Pronouncements

[0001596532-20-000148:notes:13]
[same as prior period, unchanged from 0001628280-20-006504:notes:14]

[0001596532-20-000148:notes:14]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, to replace the incurred loss impairment methodology under current GAAP with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates. The standard requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. For trade receivables, we are required to estimate lifetime expected credit losses. For available-for-sale debt securities, we are required to recognize an allowance for credit losses rather than a reduction to the carrying value of the asset. We adopted the new guidance in our first quarter of 2020 under a modified retrospective approach, and there was no material impact to our financial statements upon adoption. In addition, we do not anticipate that it will have a material impact on our consolidated statement of operations or consolidated statements of cash flows going forward.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-20-000148:notes:15]
[same as prior period, unchanged from 0001628280-20-006504:notes:16]

[0001596532-20-000148:notes:16]
[same as prior period, unchanged from 0001628280-20-006504:notes:17]

[0001596532-20-000148:notes:17]
[same as prior period, unchanged from 0001628280-20-006504:notes:18]

[0001596532-20-000148:notes:18]
|  |  | Preliminary Purchase Price Allocation |
| Tangible assets |  | $ | 13,376 |  |
| Liabilities |  | (24,346 | ) |
| Intangible assets |  | 49,040 |  |
| Goodwill |  | 29,926 |  |
| Net assets acquired |  | $ | 67,996 |  |

[0001596532-20-000148:notes:19]
We continue the process of identifying and evaluating pending escrow claims related to tax and other liabilities. Accordingly, the preliminary values reflected in the table above are subject to potential measurement period adjustments.

[0001596532-20-000148:notes:20]
[same as prior period, unchanged from 0001628280-20-006504:notes:20]

[0001596532-20-000148:notes:21]
[same as prior period, unchanged from 0001628280-20-006504:notes:21]

[0001596532-20-000148:notes:22]
[same as prior period, unchanged from 0001628280-20-006504:notes:22]


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-20-000148:notes:23]
[same as prior period, unchanged from 0001628280-20-006504:notes:23]

[0001596532-20-000148:notes:24]
Assets and liabilities recorded at fair value on a recurring basis on the accompanying condensed consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value. We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs. The three-tiers of the fair value hierarchy are as follows:

[0001596532-20-000148:notes:25]
[same as prior period, unchanged from 0001628280-20-006504:notes:25]

[0001596532-20-000148:notes:26]
[same as prior period, unchanged from 0001628280-20-006504:notes:26]

[0001596532-20-000148:notes:27]
[same as prior period, unchanged from 0001628280-20-006504:notes:27]

[0001596532-20-000148:notes:28]
[same as prior period, unchanged from 0001628280-20-006504:notes:28]

[0001596532-20-000148:notes:29]
|  |  | June 30, 2020 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 355,353 |  |  | $ | — |  |  | $ | — |  |  | $ | 355,353 |  |  | $ | 355,353 |  |  | $ | — |  |  | $ | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 68,865 |  |  | — |  |  | — |  |  | 68,865 |  |  | — |  |  | 68,865 |  |  | — |  |
| Certificate of deposits(1) |  | 3,000 |  |  | — |  |  | — |  |  | 3,000 |  |  | — |  |  | 3,000 |  |  | — |  |
| U.S. government notes |  | 607,806 |  |  | 5,271 |  |  | (6 | ) |  | 613,071 |  |  | 613,071 |  |  | — |  |  | — |  |
| Corporate bonds |  | 928,562 |  |  | 7,901 |  |  | (175 | ) |  | 936,288 |  |  | — |  |  | 936,288 |  |  | — |  |
| Agency securities |  | 359,923 |  |  | 460 |  |  | (18 | ) |  | 360,365 |  |  | — |  |  | 360,365 |  |  | — |  |
|  |  | 1,968,156 |  |  | 13,632 |  |  | (199 | ) |  | 1,981,589 |  |  | 613,071 |  |  | 1,368,518 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,307 |  |  | — |  |  | — |  |  | 4,307 |  |  | 4,307 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 2,327,816 |  |  | $ | 13,632 |  |  | $ | (199 | ) |  | $ | 2,341,249 |  |  | $ | 972,731 |  |  | $ | 1,368,518 |  |  | $ | — |  |

[0001596532-20-000148:notes:30]
|  |  | December 31, 2019 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 562,580 |  |  | $ | — |  |  | $ | — |  |  | $ | 562,580 |  |  | $ | 562,580 |  |  | $ | — |  |  | $ | — |  |
| Certificate of deposits(1) |  | 4,001 |  |  |  |  |  |  | 4,001 |  |  |  |  | 4,001 |  |  |  |
|  |  | 566,581 |  |  | — |  |  | — |  |  | 566,581 |  |  | 562,580 |  |  | 4,001 |  |  | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 66,717 |  |  | — |  |  | — |  |  | 66,717 |  |  | — |  |  | 66,717 |  |  | — |  |
| Certificate of deposits(1) |  | 3,000 |  |  | — |  |  | — |  |  | 3,000 |  |  | — |  |  | 3,000 |  |  | — |  |
| U.S. government notes |  | 518,884 |  |  | 414 |  |  | (20 | ) |  | 519,278 |  |  | 519,278 |  |  | — |  |  | — |  |
| Corporate bonds |  | 787,741 |  |  | 2,392 |  |  | (73 | ) |  | 790,060 |  |  | — |  |  | 790,060 |  |  | — |  |
| Agency securities |  | 233,491 |  |  | 577 |  |  | (41 | ) |  | 234,027 |  |  | — |  |  | 234,027 |  |  | — |  |
|  |  | 1,609,833 |  |  | 3,383 |  |  | (134 | ) |  | 1,613,082 |  |  | 519,278 |  |  | 1,093,804 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,229 |  |  | — |  |  | — |  |  | 4,229 |  |  | 4,229 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 2,180,643 |  |  | $ | 3,383 |  |  | $ | (134 | ) |  | $ | 2,183,892 |  |  | $ | 1,086,087 |  |  | $ | 1,097,805 |  |  | $ | — |  |

[0001596532-20-000148:notes:31]
[same as prior period, unchanged from 0001628280-20-006504:notes:31]

[0001596532-20-000148:notes:32]
(1) As of June 30, 2020 and December 31, 2019, all of our certificates of deposits were domestic deposits.

[0001596532-20-000148:notes:33]
The unrealized losses associated with our marketable securities were immaterial as of June 30, 2020, and December 31, 2019. As of June 30, 2020 and December 31, 2019, we did not have any marketable securities that have been in a continuous unrealized loss position for more than twelve months. We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. We did not recognize any credit losses or non-credit-related impairments related to our available-for-sale marketable securities during the three and six months ended June 30, 2020.

[0001596532-20-000148:notes:34]
As of June 30, 2020, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale marketable securities, by remaining contractual maturity, are as follows (in thousands):

[0001596532-20-000148:notes:35]
|  |  | June 30, 2020 |
| Due in 1 year or less |  | $ | 1,340,607 |  |
| Due in 1 year through 2 years |  | 640,982 |  |
| Total marketable securities |  | $ | 1,981,589 |  |

[0001596532-20-000148:notes:36]
The weighted-average remaining duration of our current marketable securities is approximately 0.8 years as of June 30, 2020.  As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities on the accompanying unaudited condensed consolidated balance sheets.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-20-000148:notes:37]
[same as prior period, unchanged from 0001628280-20-006504:notes:37]

[0001596532-20-000148:notes:38]
[same as prior period, unchanged from 0001628280-20-006504:notes:38]

[0001596532-20-000148:notes:39]
[same as prior period, unchanged from 0001628280-20-006504:notes:39]

[0001596532-20-000148:notes:40]
|  |  | June 30, 2020 |  | June 30, 2019 |
| Cash and cash equivalents |  | $ | 800,182 |  |  | $ | 944,414 |  |
| Restricted cash included in Other assets |  | 4,307 |  |  | 4,222 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 804,489 |  |  | $ | 948,636 |  |

[0001596532-20-000148:notes:41]
Restricted cash, which was included in "Other assets" on the accompanying condensed consolidated balance sheets as of June 30, 2020 and June 30, 2019, primarily consisted of $4.0 million pledged as collateral representing a security deposit required for a facility lease.

[0001596532-20-000148:notes:42]
[same as prior period, unchanged from 0001628280-20-006504:notes:42]

[0001596532-20-000148:notes:43]
[same as prior period, unchanged from 0001628280-20-006504:notes:43]

[0001596532-20-000148:notes:44]
|  |  | June 30, 2020 |  | December 31, 2019 |
| Accounts receivable |  | $ | 385,005 |  |  | $ | 398,147 |  |
| Allowance for doubtful accounts |  | (501 | ) |  | (638 | ) |
| Product sales rebate and returns reserve |  | (1,279 | ) |  | (5,522 | ) |
| Accounts receivable, net |  | $ | 383,225 |  |  | $ | 391,987 |  |

[0001596532-20-000148:notes:45]
[same as prior period, unchanged from 0001628280-20-006504:notes:45]

[0001596532-20-000148:notes:46]
[same as prior period, unchanged from 0001628280-20-006504:notes:46]

[0001596532-20-000148:notes:47]
|  |  | June 30, 2020 |  | December 31, 2019 |
| Raw materials |  | $ | 171,346 |  |  | $ | 96,712 |  |
| Finished goods |  | 155,651 |  |  | 147,113 |  |
| Total inventories |  | $ | 326,997 |  |  | $ | 243,825 |  |

[0001596532-20-000148:notes:48]
[same as prior period, unchanged from 0001628280-20-006504:notes:48]

[0001596532-20-000148:notes:49]
[same as prior period, unchanged from 0001628280-20-006504:notes:49]

[0001596532-20-000148:notes:50]
|  |  | June 30, 2020 |  | December 31, 2019 |
| Prepaid income taxes |  | $ | 490 |  |  | $ | 20,153 |  |
| Inventory deposit |  | 11,740 |  |  | 13,716 |  |
| Other current assets |  | 56,980 |  |  | 64,464 |  |
| Other prepaid expenses and deposits |  | 15,675 |  |  | 13,123 |  |
| Total prepaid expenses and other current assets |  | $ | 84,885 |  |  | $ | 111,456 |  |

[0001596532-20-000148:notes:51]
[same as prior period, unchanged from 0001628280-20-006504:notes:51]

[0001596532-20-000148:notes:52]
[same as prior period, unchanged from 0001628280-20-006504:notes:52]

[0001596532-20-000148:notes:53]
|  |  | June 30, 2020 |  | December 31, 2019 |
| Equipment and machinery |  | $ | 65,950 |  |  | $ | 64,748 |  |
| Computer hardware and software |  | 39,104 |  |  | 36,627 |  |
| Leasehold improvements |  | 31,217 |  |  | 31,235 |  |
| Furniture and fixtures |  | 3,733 |  |  | 3,774 |  |
| Construction-in-process |  | 488 |  |  | 265 |  |
| Property and equipment, gross |  | 140,492 |  |  | 136,649 |  |
| Less: accumulated depreciation |  | (105,229 | ) |  | (97,376 | ) |
| Property and equipment, net |  | $ | 35,263 |  |  | $ | 39,273 |  |

[0001596532-20-000148:notes:54]
Depreciation expense was $5.1 million and $4.8 million for the three months ended June 30, 2020 and 2019, respectively, and $10.3 million and $9.5 million for the six months ended June 30, 2020 and 2019, respectively.

[0001596532-20-000148:notes:55]
[same as prior period, unchanged from 0001628280-20-006504:notes:55]

[0001596532-20-000148:notes:56]
[same as prior period, unchanged from 0001628280-20-006504:notes:56]

[0001596532-20-000148:notes:57]
|  |  | June 30, 2020 |  | December 31, 2019 |
| Accrued payroll related costs |  | $ | 44,230 |  |  | $ | 80,133 |  |
| Accrued manufacturing costs |  | 27,345 |  |  | 31,920 |  |
| Accrued product development costs |  | 10,620 |  |  | 11,410 |  |
| Accrued professional fees |  | 5,418 |  |  | 6,335 |  |
| Accrued warranty costs |  | 6,071 |  |  | 6,742 |  |
| Accrued taxes |  | 1,851 |  |  | 1,716 |  |
| Other |  | 4,535 |  |  | 1,993 |  |
| Total accrued liabilities |  | $ | 100,070 |  |  | $ | 140,249 |  |

[0001596532-20-000148:notes:58]
[same as prior period, unchanged from 0001628280-20-006504:notes:58]

[0001596532-20-000148:notes:59]
[same as prior period, unchanged from 0001628280-20-006504:notes:59]

[0001596532-20-000148:notes:60]
|  |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |
| Warranty accrual, beginning of period |  | $ | 6,742 |  |  | $ | 5,362 |  |
| Liabilities accrued for warranties issued during the period |  | 2,181 |  |  | 2,082 |  |
| Warranty costs incurred during the period |  | (2,852 | ) |  | (2,370 | ) |
| Warranty accrual, end of period |  | $ | 6,071 |  |  | $ | 5,074 |  |

[0001596532-20-000148:notes:61]
[same as prior period, unchanged from 0001628280-20-006504:notes:61]

[0001596532-20-000148:notes:62]
The following table summarizes the balances of our contract assets included in "Prepaid and other current assets" on the accompanying condensed consolidated balance sheets (in thousands):

[0001596532-20-000148:notes:63]
|  |  | Six Months Ended June 30, |
|  |  | 2020 |
| Contract assets, beginning balance |  | $ | 25,565 |  |
| Contract assets, ending balance |  | 13,648 |  |

[0001596532-20-000148:notes:64]
[same as prior period, unchanged from 0001628280-20-006504:notes:64]

[0001596532-20-000148:notes:65]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Contract liabilities, beginning balance |  | $ | 64,325 |  |  | $ | 37,314 |  |  | $ | 61,050 |  |  | $ | 32,595 |  |
| Less: Revenue recognized from beginning balance |  | (5,735 | ) |  | (3,552 | ) |  | (11,722 | ) |  | (6,766 | ) |
| Less: Beginning balance reclassified to deferred revenue |  | (2,757 | ) |  | (1,593 | ) |  | (2,226 | ) |  | (1,205 | ) |
| Add: Contract liabilities recognized |  | 11,435 |  |  | 9,857 |  |  | 20,166 |  |  | 17,402 |  |
| Contract liabilities, ending balance |  | $ | 67,268 |  |  | $ | 42,026 |  |  | $ | 67,268 |  |  | $ | 42,026 |  |

[0001596532-20-000148:notes:66]
As of June 30, 2020 and December 31, 2019, $28.6 million and $23.4 million of our contract liabilities, respectively, were included in "Other current liabilities" with the remaining balances included in "Other long-term liabilities" on the accompanying condensed consolidated balance sheets.

[0001596532-20-000148:notes:67]
[same as prior period, unchanged from 0001628280-20-006504:notes:67]

[0001596532-20-000148:notes:68]
Deferred revenue is comprised primarily of unearned revenue related to multi-year post contract support, or PCS, contracts, services and product deferrals related to acceptance clauses. The following table summarizes the activity related to our deferred revenue (in thousands):

[0001596532-20-000148:notes:69]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Deferred revenue, beginning balance |  | $ | 596,775 |  |  | $ | 536,471 |  |  | $ | 575,288 |  |  | $ | 587,227 |  |
| Less: Revenue recognized from beginning balance |  | (104,480 | ) |  | (119,542 | ) |  | (178,264 | ) |  | (253,616 | ) |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 85,216 |  |  | 85,289 |  |  | 180,487 |  |  | 168,607 |  |
| Deferred revenue, ending balance |  | $ | 577,511 |  |  | $ | 502,218 |  |  | $ | 577,511 |  |  | $ | 502,218 |  |

[0001596532-20-000148:notes:70]
[same as prior period, unchanged from 0001628280-20-006504:notes:70]

[0001596532-20-000148:notes:71]
Revenue from remaining performance obligations represents contracted revenue that has not yet been recognized, and consists of contract liabilities and deferred revenue that will be recognized as revenue in future periods. As of June 30, 2020, approximately $687.7 million of revenue is expected to be recognized from remaining performance obligations. We expect to recognize revenue on approximately 81% of these remaining performance obligations over the next two years and 19% during the third to the fifth year.

[0001596532-20-000148:notes:72]
Other Income, Net

[0001596532-20-000148:notes:73]
Other income, net consists of the following (in thousands):

[0001596532-20-000148:notes:74]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Interest income |  | $ | 8,668 |  |  | $ | 13,107 |  |  | $ | 20,330 |  |  | $ | 25,005 |  |
| Gain on investment in privately-held companies |  | — |  |  | — |  |  | — |  |  | 1,150 |  |
| Other income (expense), net |  | (412 | ) |  | 704 |  |  | 83 |  |  | (11 | ) |
| Total |  | $ | 8,256 |  |  | $ | 13,811 |  |  | $ | 20,413 |  |  | $ | 26,144 |  |


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-20-000148:notes:75]
[same as prior period, unchanged from 0001628280-20-006504:notes:75]

[0001596532-20-000148:notes:76]
[same as prior period, unchanged from 0001628280-20-006504:notes:76]

[0001596532-20-000148:notes:77]
Our investments are in the equity of privately-held companies, which do not have readily determinable fair values. These non-marketable equity securities are initially recorded at cost, and subsequently remeasured to fair value on a non-recurring basis based on observable price changes in orderly transactions for similar investments of the same issuer, or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to those investments. In addition, the valuation requires management judgment due to the absence of market price and inherent lack of liquidity. The following table summarizes the activity related to our investments in privately-held companies held as of June 30, 2020 and December 31, 2019 (in thousands):

[0001596532-20-000148:notes:78]
|  |  | June 30, 2020 |  | December 31, 2019 |
| Cost of investment |  | $ | 3,000 |  |  | $ | 3,000 |  |
| Cumulative impairment |  | — |  |  | — |  |
| Cumulative upward adjustment |  | 1,150 |  |  | 1,150 |  |
| Carrying amount of investment |  | $ | 4,150 |  |  | $ | 4,150 |  |

[0001596532-20-000148:notes:79]
During the three and six months ended June 30, 2020, there were no realized or unrealized gains or losses recorded. During the three months ended June 30, 2019, there were no realized or unrealized gains or losses recorded. During the six months ended June 30, 2019, we recorded $1.2 million of unrealized gain.  The unrealized gain was recorded on an investment that was remeasured to fair value as of the date an observable transaction occurred.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-20-000148:notes:80]
6.    Commitments and Contingencies

[0001596532-20-000148:notes:81]
Purchase Commitments

[0001596532-20-000148:notes:82]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished products and a significant portion of these orders consist of firm non-cancellable commitments. In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of June 30, 2020, we had non-cancellable purchase commitments of $570.3 million, of which $552.5 million was to our contract manufacturers and suppliers. In addition, we have provided suppliers with inventory deposits to secure our obligations to purchase inventory and the amount of these deposits may increase in future periods as we work to reduce product lead times and ensure adequate component supply to meet future demand. We had $14.5 million and $16.5 million in deposits as of June 30, 2020 and December 31, 2019, respectively. These deposits are included in “Prepaid expenses and other current assets” and “Other assets” on the accompanying condensed consolidated balance sheets.

[0001596532-20-000148:notes:83]
Guarantees

[0001596532-20-000148:notes:84]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had a significant impact on our consolidated financial statements to date.

[0001596532-20-000148:notes:85]
Legal Proceedings

[0001596532-20-000148:notes:86]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-20-000148:notes:87]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of June 30, 2020, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-20-000148:notes:88]
[same as prior period, unchanged from 0001628280-20-006504:notes:89]

[0001596532-20-000148:notes:89]
[same as prior period, unchanged from 0001628280-20-006504:notes:90]

[0001596532-20-000148:notes:90]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”).  This authorization allows us to repurchase shares of our common stock opportunistically and will be funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, trading plans under Rule 10b5-1 of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), or a combination of the foregoing. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. As of June 30, 2020, the remaining authorized amount for stock repurchases under this program was approximately $506.0 million.

[0001596532-20-000148:notes:91]
A summary of the stock repurchase activity under the Repurchase Program for the six months ended June 30, 2020 is as follows (in thousands, except per share amounts):

[0001596532-20-000148:notes:92]
|  |  | Six Months Ended |
|  |  | June 30, 2020 |
| Aggregate purchase price |  | $ | 227,895 |  |
| Shares repurchased |  | 1,209 |  |
| Average price paid per share |  | $ | 188.61 |  |

[0001596532-20-000148:notes:93]
There was no stock repurchase activity for the three months ended June 30, 2020. The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings.  All shares repurchased under the Repurchase Program have been retired.

[0001596532-20-000148:notes:94]
[same as prior period, unchanged from 0001628280-20-006504:notes:95]

[0001596532-20-000148:notes:95]
[same as prior period, unchanged from 0001628280-20-006504:notes:96]

[0001596532-20-000148:notes:96]
Effective January 1, 2020, the Company's board of directors authorized an increase of 2,291,660 shares to the shares available for issuance under the 2014 Equity Incentive Plan (the “2014 Plan”).  Pursuant to the 2014 Plan, the 2020 share increase is determined based on the lesser of 3% of total shares of common stock outstanding as of December 31, 2019, which was,12,500,000 shares, or such amount as determined by our board of directors. As of June 30, 2020, there remained approximately 22.3 million shares available for issuance under the 2014 Plan.

[0001596532-20-000148:notes:97]
[same as prior period, unchanged from 0001628280-20-006504:notes:98]

[0001596532-20-000148:notes:98]
Effective January 1, 2020, our board of directors authorized an increase of 763,886 shares to the shares available for issuance under our 2014 Employee Stock Purchase Plan (the “ESPP”).  Pursuant to the ESPP, the 2020 share increase was determined based on the lesser of 1% of the total shares of common stock outstanding on December 31, 2019, 2,500,000 shares, or such amount as determined by our board of directors. During the six months ended June 30, 2020, we issued 51,292 shares at a weighted-average purchase price of $184.19 per share under the ESPP. As of June 30, 2020, there remained 3,905,368 shares available for issuance under the ESPP.

[0001596532-20-000148:notes:99]
[same as prior period, unchanged from 0001628280-20-006504:notes:100]

[0001596532-20-000148:notes:100]
[same as prior period, unchanged from 0001628280-20-006504:notes:101]

[0001596532-20-000148:notes:101]
|  |  | Options Outstanding |  |  |  |  |
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding |
| Balance—December 31, 2019 |  | 4,564 |  |  | $ | 42.50 |  |  | 4.4 |  | $ | 740,387 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (504 | ) |  | 25.36 |  |  |  |  |  |
| Options canceled |  | (21 | ) |  | 159.36 |  |  |  |  |  |
| Balance—June 30, 2020 |  | 4,039 |  |  | $ | 44.03 |  |  | 4.0 |  | $ | 674,925 |  |
| Vested and exercisable—June 30, 2020 |  | 2,609 |  |  | $ | 30.93 |  |  | 3.6 |  | $ | 467,293 |  |

[0001596532-20-000148:notes:102]
[same as prior period, unchanged from 0001628280-20-006504:notes:103]

[0001596532-20-000148:notes:103]
[same as prior period, unchanged from 0001628280-20-006504:notes:104]

[0001596532-20-000148:notes:104]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2019 |  | 1,070 |  |  | $ | 190.35 |  |  | 1.5 |  | $ | 217,701 |  |
| RSUs granted |  | 1,150 |  |  | 213.78 |  |  |  |  |  |
| RSUs vested |  | (246 | ) |  | 152.85 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (60 | ) |  | 226.44 |  |  |  |  |  |
| Unvested balance—June 30, 2020 |  | 1,914 |  |  | $ | 208.13 |  |  | 2.0 |  | $ | 401,996 |  |

[0001596532-20-000148:notes:105]
[same as prior period, unchanged from 0001628280-20-006504:notes:106]

[0001596532-20-000148:notes:106]
The following table presents the stock activity and the total number of shares available for grant under the 2014 Plan as of June 30, 2020 (in thousands):

[0001596532-20-000148:notes:107]
|  |  | Number of Shares |
| Balance—December 31, 2019 |  | 15,146 |  |
| Authorized |  | 2,292 |  |
| Options granted |  | — |  |
| RSUs granted |  | (1,150 | ) |
| Options canceled |  | 21 |  |
| RSUs forfeited |  | 60 |  |
| Shares traded for taxes |  | 17 |  |
| Balance—June 30, 2020 |  | 16,386 |  |

[0001596532-20-000148:notes:108]
[same as prior period, unchanged from 0001628280-20-006504:notes:109]

[0001596532-20-000148:notes:109]
Total stock-based compensation expenses related to options, restricted stock units, restricted stock, and employee stock purchase rights granted were allocated as follows (in thousands):

[0001596532-20-000148:notes:110]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Cost of revenue |  | $ | 1,585 |  |  | $ | 1,028 |  |  | $ | 2,912 |  |  | $ | 2,126 |  |
| Research and development |  | 19,378 |  |  | 12,568 |  |  | 35,306 |  |  | 25,699 |  |
| Sales and marketing |  | 8,277 |  |  | 7,097 |  |  | 14,673 |  |  | 13,631 |  |
| General and administrative |  | 3,682 |  |  | 3,604 |  |  | 7,587 |  |  | 7,132 |  |
| Total stock-based compensation |  | $ | 32,922 |  |  | $ | 24,297 |  |  | $ | 60,478 |  |  | $ | 48,588 |  |

[0001596532-20-000148:notes:111]
As of June 30, 2020, unrecognized stock-based compensation expenses by award type and their expected weighted-average recognition periods are summarized in the following table (in thousands, except years):

[0001596532-20-000148:notes:112]
|  |  | June 30, 2020 |
|  |  | Stock Option |  | RSU |  | ESPP |  | Restricted Stock |
| Unrecognized stock-based compensation expense |  | $ | 35,043 |  |  | $ | 360,713 |  |  | $ | 5,793 |  |  | $ | 3,206 |  |
| Weighted-average amortization period |  | 2.9 years |  |  | 3.7 years |  |  | 0.9 years |  |  | 2.2 years |  |


## us-gaap:EarningsPerShareTextBlock

[0001596532-20-000148:notes:113]
[same as prior period, unchanged from 0001628280-20-006504:notes:114]

[0001596532-20-000148:notes:114]
The following table sets forth the computation of our basic and diluted net income per share attributable to common stockholders (in thousands, except per share amounts):

[0001596532-20-000148:notes:115]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Numerator: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 144,793 |  |  | $ | 189,251 |  |  | $ | 283,224 |  |  | $ | 390,280 |  |
| Less: undistributed earnings allocated to participating securities |  | — |  |  | (99 | ) |  | — |  |  | (217 | ) |
| Net income available to common stockholders, basic |  | $ | 144,793 |  |  | $ | 189,152 |  |  | $ | 283,224 |  |  | $ | 390,063 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Net income attributable to common stockholders, basic |  | $ | 144,793 |  |  | $ | 189,152 |  |  | $ | 283,224 |  |  | $ | 390,063 |  |
| Add: undistributed earnings allocated to participating securities |  | — |  |  | 6 |  |  | — |  |  | 13 |  |
| Net income attributable to common stockholders, diluted |  | $ | 144,793 |  |  | $ | 189,158 |  |  | $ | 283,224 |  |  | $ | 390,076 |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 75,808 |  |  | 76,552 |  |  | 76,036 |  |  | 76,238 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 75,808 |  |  | 76,552 |  |  | 76,036 |  |  | 76,238 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |  |  |
| Stock options and RSUs |  | 3,486 |  |  | 4,775 |  |  | 3,580 |  |  | 5,025 |  |
| Employee stock purchase plan |  | 4 |  |  | 8 |  |  | 4 |  |  | 8 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted |  | 79,298 |  |  | 81,335 |  |  | 79,620 |  |  | 81,271 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.91 |  |  | $ | 2.47 |  |  | $ | 3.72 |  |  | $ | 5.12 |  |
| Diluted |  | $ | 1.83 |  |  | $ | 2.33 |  |  | $ | 3.56 |  |  | $ | 4.80 |  |

[0001596532-20-000148:notes:116]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share attributable to common stockholders for the periods presented because including them would have been anti-dilutive (in thousands):

[0001596532-20-000148:notes:117]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Stock options and RSUs to purchase common stock |  | 334 |  |  | 195 |  |  | 467 |  |  | 179 |  |
| Employee stock purchase plan |  | 149 |  |  | 31 |  |  | 159 |  |  | 68 |  |
| Total |  | 483 |  |  | 226 |  |  | 626 |  |  | 247 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-20-000148:notes:118]
[same as prior period, unchanged from 0001628280-20-006504:notes:119]

[0001596532-20-000148:notes:119]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
|  |  | (in thousands, except percentages) |  | (in thousands, except percentages) |
| Income before income taxes |  | $ | 175,245 |  |  | $ | 220,648 |  |  | $ | 337,064 |  |  | $ | 427,323 |  |
| Provision for income taxes |  | 30,452 |  |  | 31,397 |  |  | 53,840 |  |  | 37,043 |  |
| Effective tax rate |  | 17.4 | % |  | 14.2 | % |  | 16.0 | % |  | 8.7 | % |

[0001596532-20-000148:notes:120]
The effective tax rates reflect tax expense recorded on pre-tax income in the three months and six months ended June 30, 2020 and June 30, 2019, respectively. The change in effective tax rates in the three months and six months ended June 30, 2020, as compared to the same periods in 2019, was primarily due to a decrease in tax benefits attributable to stock-based compensation.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-20-000148:notes:121]
[same as prior period, unchanged from 0001628280-20-006504:notes:122]

[0001596532-20-000148:notes:122]
We operate in one reportable segment. The following table represents revenue based on the customer’s location, as determined by the customer’s shipping address (in thousands):

[0001596532-20-000148:notes:123]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Americas |  | $ | 435,829 |  |  | $ | 446,370 |  |  | $ | 836,489 |  |  | $ | 886,008 |  |
| Europe, Middle East and Africa |  | 63,977 |  |  | 112,060 |  |  | 136,601 |  |  | 223,329 |  |
| Asia-Pacific |  | 40,764 |  |  | 49,891 |  |  | 90,509 |  |  | 94,408 |  |
| Total revenue |  | $ | 540,570 |  |  | $ | 608,321 |  |  | $ | 1,063,599 |  |  | $ | 1,203,745 |  |

[0001596532-20-000148:notes:124]
Long-lived assets, net, excluding intercompany receivables, investments in subsidiaries, privately-held equity investments and deferred tax assets, by location are summarized as follows (in thousands):

[0001596532-20-000148:notes:125]
|  |  | June 30, 2020 |  | December 31, 2019 |
| United States |  | $ | 26,954 |  |  | $ | 32,565 |  |
| International |  | 8,309 |  |  | 6,708 |  |
| Total |  | $ | 35,263 |  |  | $ | 39,273 |  |
