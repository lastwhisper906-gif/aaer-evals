# ANET MD&A — 0001596532-20-000148


## mdna

[0001596532-20-000148:mdna:1]
[same as prior period, unchanged from 0001628280-20-006504:mdna:1]

[0001596532-20-000148:mdna:2]
[same as prior period, unchanged from 0001628280-20-006504:mdna:2]

[0001596532-20-000148:mdna:3]
[same as prior period, unchanged from 0001628280-20-006504:mdna:3]

[0001596532-20-000148:mdna:4]
[same as prior period, unchanged from 0001628280-20-006504:mdna:4]

[0001596532-20-000148:mdna:5]
We generate revenue primarily from sales of our switching and routing products which incorporate our EOS software. We generate the majority of our services revenue from post contract support, or PCS, which end customers typically purchase in conjunction with our products. Our end customers span a range of industries and include large Internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others. As we have grown the functionality of our EOS software, expanded the range of our product portfolio and increased the size of our sales force, our revenue has grown rapidly. We have also been profitable and operating cash flow positive for each year since 2010.

[0001596532-20-000148:mdna:6]
[same as prior period, unchanged from 0001628280-20-006504:mdna:7]

[0001596532-20-000148:mdna:7]
Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic to the underlying merchant silicon architecture. Today, we combine our EOS software with merchant silicon into a family of switching and routing products. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We work closely with third-party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third-party direct fulfillment facilities. We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-20-000148:mdna:8]
Historically, large purchases by a relatively limited number of end customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large end customers primarily due to changes in demand patterns specific to these customers, the time it takes these end customers to evaluate, test, qualify and accept our products, and the overall complexity of these large orders. We expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. For example, our sales to Microsoft and Facebook as end users in fiscal 2019 collectively represented 40% of our revenue, and benefited from certain factors that are not expected to repeat in fiscal 2020. Consequently, the percentage of our revenue from these customers in fiscal 2020 is expected to decline, which will contribute to an expected year-over-year decline in our revenue for fiscal 2020. In addition, we have provided, and may in the future provide, pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur.

[0001596532-20-000148:mdna:9]
[same as prior period, unchanged from 0001628280-20-006504:mdna:10]

[0001596532-20-000148:mdna:10]
The global coronavirus (“COVID-19”) pandemic and related shelter in place, travel and social distancing restrictions imposed by governments around the world in an effort to contain or slow its spread have negatively impacted the global economy, disrupted business, sales activities, supply chains and workforce participation, including our own, and created significant volatility and disruption of financial markets, and we expect that the global health crisis caused by COVID-19 will continue to negatively impact business activity for the foreseeable future.

[0001596532-20-000148:mdna:11]
We have taken numerous steps, and will continue to take further actions, in our approach to address COVID-19. We have prioritized the protection of our employees during this pandemic and, as a result, have closed our offices across the globe (including our corporate headquarters) limiting access to only those employees providing essential activities, instructed employees to work from home, and implemented travel restrictions. We continue to work closely with our contract manufacturers and supply chain partners who have experienced delays in component sourcing and the production and export of their products. Although we have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, these delays have negatively impacted our ability to supply products to our customers on a timely basis. We expect to continue to invest in working capital as supply availability improves in order to address the risk of future COVID-19 related supply chain disruptions, but we cannot be certain that such disruptions will not occur.

[0001596532-20-000148:mdna:12]
The extent of the impact of COVID-19 on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, including the duration and spread of the pandemic, breadth and duration of containment measures such as restrictions on travel and transportation, and the impact on our customers, partners, contract manufacturers and supply chain, all of which are uncertain and cannot be predicted. However, any continued disruption in manufacturing and supply resulting from the COVID-19 pandemic or related containment

[0001596532-20-000148:mdna:13]
measures would negatively impact our business. We also expect that COVID-19 related disruptions may have a negative impact on demand from our customers in future periods. While we have experienced some strength in demand from our cloud titan customers, we expect this may be offset by longer sales cycles with new prospects in the campus and enterprise markets, contributing to an expected year-over-year decline in revenue for the year ending December 31, 2020. Accordingly, current results and financial condition discussed herein may not be indicative of future operating results and trends.

[0001596532-20-000148:mdna:14]
In response to potential future COVID-19 related disruptions to our business, we continue to carefully review our investment and spending plans, cautiously managing discretionary spending while maintaining an ongoing focus on key initiatives. Although management is actively monitoring the impact of COVID-19 on the Company’s financial condition, liquidity, operations, suppliers, industry, and workforce, the full impact of the pandemic continues to evolve as of the date of this report. As such, the Company is unable to estimate the effects of COVID-19 on its future results of operations, financial condition, or liquidity.

[0001596532-20-000148:mdna:15]
[same as prior period, unchanged from 0001628280-20-006504:mdna:16]

[0001596532-20-000148:mdna:16]
[same as prior period, unchanged from 0001628280-20-006504:mdna:17]

[0001596532-20-000148:mdna:17]
[same as prior period, unchanged from 0001628280-20-006504:mdna:18]

[0001596532-20-000148:mdna:18]
Three and Six Months Ended June 30, 2020 Compared to Three and Six Months Ended June 30, 2019

[0001596532-20-000148:mdna:19]
[same as prior period, unchanged from 0001628280-20-006504:mdna:20]

[0001596532-20-000148:mdna:20]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |  | Change in |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 421,413 |  |  | $ | 513,171 |  |  | $ | (91,758 | ) |  | (17.9 | )% |  | $ | 832,319 |  |  | $ | 1,018,586 |  |  | $ | (186,267 | ) |  | (18.3 | )% |
| Service |  | 119,157 |  |  | 95,150 |  |  | 24,007 |  |  | 25.2 |  |  | 231,280 |  |  | 185,159 |  |  | 46,121 |  |  | 24.9 |  |
| Total revenue |  | 540,570 |  |  | 608,321 |  |  | (67,751 | ) |  | (11.1 | ) |  | 1,063,599 |  |  | 1,203,745 |  |  | (140,146 | ) |  | (11.6 | ) |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 176,432 |  |  | 200,534 |  |  | (24,102 | ) |  | (12.0 | ) |  | 340,061 |  |  | 398,686 |  |  | (58,625 | ) |  | (14.7 | ) |
| Service |  | 20,049 |  |  | 17,596 |  |  | 2,453 |  |  | 13.9 |  |  | 41,198 |  |  | 34,298 |  |  | 6,900 |  |  | 20.1 |  |
| Total cost of revenue |  | 196,481 |  |  | 218,130 |  |  | (21,649 | ) |  | (9.9 | ) |  | 381,259 |  |  | 432,984 |  |  | (51,725 | ) |  | (11.9 | ) |
| Gross profit |  | $ | 344,089 |  |  | $ | 390,191 |  |  | $ | (46,102 | ) |  | (11.8 | )% |  | $ | 682,340 |  |  | $ | 770,761 |  |  | $ | (88,421 | ) |  | (11.5 | )% |
| Gross margin |  | 63.7 | % |  | 64.1 | % |  |  |  |  |  | 64.2 | % |  | 64.0 | % |  |  |  |  |

[0001596532-20-000148:mdna:21]
[same as prior period, unchanged from 0001628280-20-006504:mdna:22]

[0001596532-20-000148:mdna:22]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2020 |  | % of Total |  | 2019 |  | % of Total |  | 2020 |  | % of Total |  | 2019 |  | % of Total |
| Americas |  | $ | 435,829 |  |  | 80.7 | % |  | $ | 446,370 |  |  | 73.4 | % |  | $ | 836,489 |  |  | 78.7 | % |  | $ | 886,008 |  |  | 73.6 | % |
| Europe, Middle East and Africa |  | 63,977 |  |  | 11.8 |  |  | 112,060 |  |  | 18.4 |  |  | 136,601 |  |  | 12.8 |  |  | 223,329 |  |  | 18.6 |  |
| Asia-Pacific |  | 40,764 |  |  | 7.5 |  |  | 49,891 |  |  | 8.2 |  |  | 90,509 |  |  | 8.5 |  |  | 94,408 |  |  | 7.8 |  |
| Total revenue |  | $ | 540,570 |  |  | 100.0 | % |  | $ | 608,321 |  |  | 100.0 | % |  | $ | 1,063,599 |  |  | 100.0 | % |  | $ | 1,203,745 |  |  | 100.0 | % |

[0001596532-20-000148:mdna:23]
[same as prior period, unchanged from 0001628280-20-006504:mdna:24]

[0001596532-20-000148:mdna:24]
[same as prior period, unchanged from 0001628280-20-006504:mdna:25]

[0001596532-20-000148:mdna:25]
Product revenue decreased $91.8 million, or 17.9%, and $186.3 million, or 18.3%, for the three and six months ended June 30, 2020, respectively, compared to the same periods in 2019. These decreases were primarily driven by the recognition of $38.1 million and $121.0 million of deferred revenue related to customer acceptance of prior period sales transactions in the three

[0001596532-20-000148:mdna:26]
and six months ended June 30, 2019, respectively and some COVID-19 related supply constraints in the first half of fiscal 2020 resulting in extended lead times and constrained shipments to customers. Service revenue increased $24.0 million, or 25.2%, and $46.1 million, or 24.9%, in the three and six months ended June 30, 2020, compared to the same periods in 2019 as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenues represented 19.3% and 21.3% of total revenues in the three and six months ended June 30, 2020, respectively, down from 26.6% and 26.4% compared to the same periods in the prior year. The decrease was primarily due to lower demand in our European region, combined with a move toward U.S. deployments by certain of our large end customers. We continued to experience competitive pricing pressure on our products and services.

[0001596532-20-000148:mdna:27]
[same as prior period, unchanged from 0001628280-20-006504:mdna:27]

[0001596532-20-000148:mdna:28]
[same as prior period, unchanged from 0001628280-20-006504:mdna:28]

[0001596532-20-000148:mdna:29]
Cost of revenue decreased $21.6 million, or 9.9%, and $51.7 million, or 11.9%, for the three and six months ended June 30, 2020, respectively, compared to the same periods in 2019. These decreases were primarily driven by a corresponding decrease in revenue.

[0001596532-20-000148:mdna:30]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including sales to large end customers who generally receive lower pricing, manufacturing-related costs including costs associated with supply chain sourcing activities, merchant silicon costs, the mix of products sold, and excess and obsolete inventory write-downs, including charges for excess and obsolete component inventory held by our contract manufacturers. We expect our gross margins to fluctuate over time, depending on the factors described above.

[0001596532-20-000148:mdna:31]
Gross margin decreased from 64.1% to 63.7% for the three months ended June 30, 2020, and increased from 64.0% to 64.2% for the six months ended June 30, 2020, compared to the same periods in 2019. Gross margin in each period was negatively impacted by customer mix with higher discounts on larger volume transactions. In addition, we incurred incremental COVID-19 related supply chain costs in current periods that were largely offset by decreased product transition costs, including lower excess and obsolete inventory charges.

[0001596532-20-000148:mdna:32]
[same as prior period, unchanged from 0001628280-20-006504:mdna:32]

[0001596532-20-000148:mdna:33]
[same as prior period, unchanged from 0001628280-20-006504:mdna:33]

[0001596532-20-000148:mdna:34]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |  | Change in |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 111,544 |  |  | $ | 114,295 |  |  | $ | (2,751 | ) |  | (2.4 | )% |  | $ | 224,698 |  |  | $ | 233,964 |  |  | $ | (9,266 | ) |  | (4.0 | )% |
| Sales and marketing |  | 51,237 |  |  | 53,040 |  |  | (1,803 | ) |  | (3.4 | ) |  | 108,323 |  |  | 104,093 |  |  | 4,230 |  |  | 4.1 |  |
| General and administrative |  | 14,319 |  |  | 16,019 |  |  | (1,700 | ) |  | (10.6 | ) |  | 32,668 |  |  | 31,525 |  |  | 1,143 |  |  | 3.6 |  |
| Total operating expenses |  | $ | 177,100 |  |  | $ | 183,354 |  |  | $ | (6,254 | ) |  | (3.4 | )% |  | $ | 365,689 |  |  | $ | 369,582 |  |  | $ | (3,893 | ) |  | (1.1 | )% |

[0001596532-20-000148:mdna:35]
Research and development

[0001596532-20-000148:mdna:36]
Research and development expenses consist primarily of personnel costs, prototype expenses, third-party engineering and contractor support costs, and an allocated portion of facility and IT costs including depreciation. Our research and development efforts are focused on maintaining and developing additional functionality for our existing products and on new product development, including new releases and upgrades to our EOS software and applications. We plan to continue to expand the capabilities of our cloud networking platform, introduce new products and features and build upon our technology leadership.  However, in light of the COVID-19 pandemic, we plan to tightly manage our spending in fiscal 2020, and as a result research and development expenses in fiscal 2020 may decrease from prior year levels.

[0001596532-20-000148:mdna:37]
Research and development expenses decreased $2.8 million, or 2.4%, and $9.3 million, or 4.0%, in the three and six months ended June 30, 2020, respectively, compared to the same periods in 2019. The decrease in the three months ended June 30, 2020 was primarily due to a decrease in new product introduction costs in the period combined with some COVID-19 related reductions in travel costs. The decrease in the six months ended June 30, 2020 was primarily due to lower new product introduction costs, including third-party engineering and other product development costs. This decrease was partially offset by $5.9 million in severance and other acquisition-related expenses from the Big Switch acquisition, including facilities restructuring costs and retention bonuses.

[0001596532-20-000148:mdna:38]
Sales and marketing

[0001596532-20-000148:mdna:39]
Sales and marketing expenses consist primarily of personnel costs, marketing, trade shows, and other promotional activities, and an allocated portion of facility and IT costs, including depreciation. We intend to continue to prudently manage our sales and marketing spend in fiscal 2020 with some targeted investment in strategic sales activities and, accordingly, expect sales and marketing expenses to remain relatively flat for the remainder of the year as compared to fiscal 2019.

[0001596532-20-000148:mdna:40]
Sales and marketing expenses decreased $1.8 million, or 3.4%, for the three months ended June 30, 2020 compared to the same period in 2019. The decrease primarily resulted from COVID-19 related reductions in marketing and travel expenses, partially offset by increased salaries and stock-based compensation due to increased headcount.  The increase of $4.2 million, or 4.1%, in the six months ended June 30, 2020 compared to the same period in 2019, was primarily driven by an increase in salaries and stock-based compensation due to increased headcount, and an increase of $3.7 million in severance and other acquisition-related expenses from the Big Switch acquisition. This increase was partially offset by a reduction in travel expenses and other sales and marketing activities due to COVID-19.

[0001596532-20-000148:mdna:41]
General and administrative

[0001596532-20-000148:mdna:42]
[same as prior period, unchanged from 0001628280-20-006504:mdna:43]

[0001596532-20-000148:mdna:43]
General and administrative expenses decreased $1.7 million, or 10.6%, in the three months ended June 30, 2020 compared to the same period in 2019. The decrease was primarily driven by a decline of $1.2 million in personnel-related costs. The increase of $1.1 million, or 3.6%, for the six months ended June 30, 2020 compared to the same period in 2019 was primarily related to severance and other acquisition-related expenses from the Big Switch acquisition, partially offset by a reduction in litigation-related activities due to the settlement of our litigation with Optumsoft in December 2019.

[0001596532-20-000148:mdna:44]
Other Income, Net (in thousands, except percentages)

[0001596532-20-000148:mdna:45]
Other income consists primarily of interest income from our cash, cash equivalents and marketable securities, gains and losses on our investments in privately-held companies, and foreign currency transaction gains and losses. We expect that interest income from our fixed-income marketable securities will decline for the year ending December 31, 2020 as a result of lower interest rates. In addition, we expect other income may fluctuate in the future as a result of the re-measurement of our private company equity investments upon the occurrence of observable price changes and/or impairments, changes in returns on our cash and cash equivalents and marketable securities, and foreign currency exchange rate fluctuations.

[0001596532-20-000148:mdna:46]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |  | Change in |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Other income, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 8,668 |  |  | $ | 13,107 |  |  | $ | (4,439 | ) |  | (33.9 | )% |  | $ | 20,330 |  |  | $ | 25,005 |  |  | $ | (4,675 | ) |  | (18.7 | )% |
| Gain on investments in privately-held companies |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,150 |  |  | (1,150 | ) |  | (100.0 | ) |
| Other income (expense), net |  | (412 | ) |  | 704 |  |  | (1,116 | ) |  | (158.5 | ) |  | 83 |  |  | (11 | ) |  | 94 |  |  | 854.5 |  |
| Total other income, net |  | $ | 8,256 |  |  | $ | 13,811 |  |  | $ | (5,555 | ) |  | (40.2 | )% |  | $ | 20,413 |  |  | $ | 26,144 |  |  | $ | (5,731 | ) |  | (21.9 | )% |

[0001596532-20-000148:mdna:47]
The unfavorable change in Other income, net, during the three and six months ended June 30, 2020 as compared to the same periods in 2019 was primarily driven by a decrease in interest income from our fixed-income marketable securities caused by reduced interest rates. In addition, we recorded a gain on our investments in privately-held companies in the six months ended June 30, 2019, which did not recur in the current period.

[0001596532-20-000148:mdna:48]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-20-000148:mdna:49]
[same as prior period, unchanged from 0001628280-20-006504:mdna:50]

[0001596532-20-000148:mdna:50]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |  | Change in |  | 2020 |  | 2019 |  | Change in |
|  |  | $ |  | $ |  | $ |  | % |  | $ |  | $ |  | $ |  | % |
| Income before income taxes |  | $ | 175,245 |  |  | $ | 220,648 |  |  | $ | (45,403 | ) |  | (20.6 | )% |  | $ | 337,064 |  |  | $ | 427,323 |  |  | $ | (90,259 | ) |  | (21.1 | )% |
| Provision for income taxes |  | 30,452 |  |  | 31,397 |  |  | (945 | ) |  | (3.0 | )% |  | 53,840 |  |  | 37,043 |  |  | 16,797 |  |  | 45.3 | % |
| Effective tax rate |  | 17.4 | % |  | 14.2 | % |  |  |  |  |  | 16.0 | % |  | 8.7 | % |  |  |  |  |

[0001596532-20-000148:mdna:51]
For the three and six months ended June 30, 2020, we recorded expenses of $30.5 million and $53.8 million for income taxes, respectively. For the three and six months ended June 30, 2019, we recorded expenses of $31.4 million and $37.0 million, respectively. Income taxes for the three months ended June 30, 2020 included lower tax benefits realized from stock-based compensation. The remaining changes in the income taxes were attributable to the overall decrease in worldwide earnings.

[0001596532-20-000148:mdna:52]
[same as prior period, unchanged from 0001628280-20-006504:mdna:53]

[0001596532-20-000148:mdna:53]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of June 30, 2020, our total balance of cash, cash equivalents and marketable securities was approximately $2.8 billion, of which approximately $428.9 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-20-000148:mdna:54]
Our cash, cash equivalents and marketable securities are held for working capital purposes. Our marketable securities investment portfolio is primarily invested in highly rated securities with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities together with cash generated from operations will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and stock repurchases. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-20-000148:mdna:55]
[same as prior period, unchanged from 0001628280-20-006504:mdna:56]

[0001596532-20-000148:mdna:56]
|  |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 333,063 |  |  | $ | 366,476 |  |
| Cash used in investing activities |  | (432,759 | ) |  | (5,510 | ) |
| Cash used in financing activities |  | (209,667 | ) |  | (66,566 | ) |
| Effect of exchange rate changes |  | (1,663 | ) |  | 72 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | (311,026 | ) |  | $ | 294,472 |  |

[0001596532-20-000148:mdna:57]
[same as prior period, unchanged from 0001628280-20-006504:mdna:58]

[0001596532-20-000148:mdna:58]
During the six months ended June 30, 2020, cash provided by operating activities was $333.1 million, primarily from net income of $283.2 million and non-cash adjustments to net income of $95.5 million driven by stock-based compensation and depreciation and amortization, and a net $45.6 million increase in working capital requirements. This increase in working capital primarily consisted of an $82.9 million increase in inventory to help mitigate COVID-19 related supply chain disruptions and a

[0001596532-20-000148:mdna:59]
$39.9 million decrease in accrued liabilities related to the timing of corporate bonus payouts. These working capital increases were partially offset by a $31.5 million increase in accounts payable related to the timing of production receipts, a $26.8 million decrease in prepaid taxes, and a $15.3 million decrease in accounts receivable due to strong collections.

[0001596532-20-000148:mdna:60]
During the six months ended June 30, 2019, cash provided by operating activities was $366.5 million, primarily from net income of $390.3 million and non-cash adjustments to net income of $75.8 million, offset partially by a net $99.6 million increase in working capital requirements.  The increase in working capital included an $85.0 million decrease in deferred revenue primarily due to the recognition of product deferred revenue related to contract acceptance terms, a $49.6 million increase in inventories primarily related to upcoming product transitions, an $11.3 million increase in accounts receivable due to the timing of billing and cash collections, and a $9.5 million decline in accrued liabilities due to net payments made under our corporate bonus program, and the timing of vendor payments related to product development activities and inventory purchases, partially offset by an increase in manufacturer/supplier liability accruals.  These unfavorable changes were partially offset by a $48.9 million decrease in prepaid expenses and other current assets including a reduction in deferred cost of inventory related to recognition of product deferred revenue, and a $14.4 million increase in income taxes payable.

[0001596532-20-000148:mdna:61]
[same as prior period, unchanged from 0001628280-20-006504:mdna:61]

[0001596532-20-000148:mdna:62]
During the six months ended June 30, 2020, cash used in investing activities was $432.8 million, consisting of purchases of available-for-sale securities of $1,236.5 million, $66.3 million for the acquisition of Big Switch, and purchases of property and equipment of $5.2 million, partially offset by proceeds from maturities of marketable securities of $875.2 million.

[0001596532-20-000148:mdna:63]
During the six months ended June 30, 2019, cash used in investing activities was $5.5 million, consisting of purchases of available-for-sale securities of $549.4 million, and purchases of property and equipment of $8.6 million, partially offset by $552.5 million from maturities of marketable securities.

[0001596532-20-000148:mdna:64]
[same as prior period, unchanged from 0001628280-20-006504:mdna:64]

[0001596532-20-000148:mdna:65]
During the six months ended June 30, 2020, cash used in financing activities was $209.7 million, consisting of payments for repurchases of our common stock from the open market of $227.9 million, and taxes paid of $4.0 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $22.2 million.

[0001596532-20-000148:mdna:66]
During the six months ended June 30, 2019, cash used in financing activities was $66.6 million, consisting of payments for repurchases of our common stock from the open market of $100.0 million and taxes paid of $4.7 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $38.1 million.

[0001596532-20-000148:mdna:67]
[same as prior period, unchanged from 0001628280-20-006504:mdna:67]

[0001596532-20-000148:mdna:68]
From time to time, we repurchase our common stock opportunistically pursuant to our Repurchase Program authorized by our board of directors in April 2019. The Repurchase Program allows for stock repurchases of up to $1.0 billion and these repurchases are funded from working capital. The Repurchase Program, which expires in April 2022, does not obligate us to acquire any of our common stock, and may be suspended or discontinued by us at any time without prior notice. During the three months ended June 30, 2020, there was no stock repurchase activity. As of June 30, 2020, the remaining authorized amount for repurchases under the Repurchase Program was $506.0 million. Refer to Note 7. Stockholders' Equity of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for further discussion.

[0001596532-20-000148:mdna:69]
[same as prior period, unchanged from 0001628280-20-006504:mdna:69]

[0001596532-20-000148:mdna:70]
As of June 30, 2020, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-20-000148:mdna:71]
[same as prior period, unchanged from 0001628280-20-006504:mdna:71]

[0001596532-20-000148:mdna:72]
Our contractual commitments will have an impact on our future liquidity.  Our contractual obligations represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalent and marketable securities. As of June 30, 2020, our principal commitments consist primarily of obligations under operating leases for offices and data centers and purchase commitments with our contract manufacturers and suppliers. See Note 6. Commitments and Contingencies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q for our purchase commitments as of June 30, 2020.

[0001596532-20-000148:mdna:73]
[same as prior period, unchanged from 0001628280-20-006504:mdna:73]

[0001596532-20-000148:mdna:74]
Our management’s discussion and analysis of financial condition and results of operations are based on our unaudited condensed consolidated financial statements, which have been prepared in accordance with GAAP. The preparation of these unaudited condensed consolidated financial statements requires us to make estimates and assumptions that affect the reported amounts of assets, liabilities, revenue, expenses, and related disclosures. We base our estimates on historical experience and on various other assumptions that we believe are reasonable under the circumstances. We evaluate our estimates and assumptions on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. We believe the critical accounting policies and estimates, discussed in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our Annual Report on Form 10-K filed with the SEC on February 14, 2020, reflect our more significant judgments and estimates used in the preparation of the condensed consolidated financial statements. There have been no significant changes to our critical accounting policies and estimates as disclosed in our Annual Report on Form 10-K.

[0001596532-20-000148:mdna:75]
[same as prior period, unchanged from 0001628280-20-006504:mdna:75]

[0001596532-20-000148:mdna:76]
Refer to the section(s) titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1, of this Quarterly Report on Form 10-Q.
