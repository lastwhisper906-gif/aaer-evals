# ANET 8-K — 0001596532-20-000147 filed 2020-08-04

## item codes, every 8-K on or before 2020-08-05

- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2020-08-05

- none on or before 2020-08-05

## item 2.02 — earnings release, exhibit 99.1

[0001596532-20-000147:8k_2_02:1]
EX-99.1
2
ex991q220-earningsrele.htm
EXHIBIT 99.1

[0001596532-20-000147:8k_2_02:2]
Exhibit

[0001596532-20-000147:8k_2_02:3]
Exhibit 99.1

[0001596532-20-000147:8k_2_02:4]
Arista Networks, Inc. Reports Second Quarter 2020 Financial Results

[0001596532-20-000147:8k_2_02:5]
SANTA CLARA, Calif.- August 4, 2020 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large datacenter and campus environments, today announced financial results for its second quarter ended June 30, 2020.

[0001596532-20-000147:8k_2_02:6]
Second Quarter Financial Highlights

[0001596532-20-000147:8k_2_02:7]
| • | Revenue of $540.6 million, an increase of 3.4% compared to the first quarter of 2020, and a decrease of 11.1% from the second quarter of 2019. |

[0001596532-20-000147:8k_2_02:8]
| • | GAAP gross margin of 63.7%, compared to GAAP gross margin of 64.7% in the first quarter of 2020 and 64.1% in the second quarter of 2019. |

[0001596532-20-000147:8k_2_02:9]
| • | Non-GAAP gross margin of 64.7%, compared to non-GAAP gross margin of 65.6% in the first quarter of 2020 and 64.7% in the second quarter of 2019. |

[0001596532-20-000147:8k_2_02:10]
| • | GAAP net income of $144.8 million, or $1.83 per diluted share, compared to GAAP net income of $189.3 million, or $2.33 per diluted share in the second quarter of 2019. |

[0001596532-20-000147:8k_2_02:11]
| • | Non-GAAP net income of $167.0 million, or $2.11 per diluted share, compared to non-GAAP net income of $198.6 million, or $2.44 per diluted share in the second quarter of 2019. |

[0001596532-20-000147:8k_2_02:12]
"I am definitely pleased with our quarterly performance and proud of the tenacity shown by the Arista team in the face of the challenging pandemic era we live in," stated Jayshree Ullal, President & CEO of Arista Networks. "Arista's market position has been reinforced as we were placed in the leader’s category by two renowned market analyst firms."

[0001596532-20-000147:8k_2_02:13]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, “We are pleased with our overall business execution in the quarter, with the team continuing to work closely with customers, supply chain and other partners as we collectively navigate the COVID-19 operating environment.”

[0001596532-20-000147:8k_2_02:14]
Second Quarter Company Highlights

[0001596532-20-000147:8k_2_02:15]
| • | Arista Networks recognized as a leader in The Forrester Wave™: Open, Programmable Switches for A Businesswide SDN, Q3 2020 with the top score in the strategy category. |

[0001596532-20-000147:8k_2_02:16]
| • | Arista Extends Open Cloud Networking Software Leadership and continued partnership with Microsoft for open networking for SONIC. The Arista switches powered by SONIC offer customers the combination of benefits of open source software with Arista EOS to deliver open, high performance, highly available networks. |

[0001596532-20-000147:8k_2_02:17]
| • | Arista Networks announced a new release of its Cognitive WiFi software that seamlessly delivers intelligent application identification, performance optimization, automated troubleshooting and location services, and that also supports video conferencing applications such as Google Hangouts, Microsoft Teams and Zoom. |

[0001596532-20-000147:8k_2_02:18]
| • | Arista Networks Announced Independent Validation of Exceptional Network Monitoring Precision at picosecond granularity. Arista MetaWatch, running on the Arista 7130 L-series platform, provides customers with new insight into the behavior of critical network systems, enabling trading firms to optimize performance and exchanges to validate market fairness. |

[0001596532-20-000147:8k_2_02:19]
| • | This is the sixth consecutive year Arista Networks has been recognized in the Leaders Quadrant of the 2020 Gartner Magic Quadrant for Data Center Networking published on 30 June 2020. |

[0001596532-20-000147:8k_2_02:20]
Financial Outlook

[0001596532-20-000147:8k_2_02:21]
For the third quarter of 2020, we expect:

[0001596532-20-000147:8k_2_02:22]
| • | Revenue between $570 million to $590 million; |

[0001596532-20-000147:8k_2_02:23]
| • | Non-GAAP gross margin of 63% to 65%; and |

[0001596532-20-000147:8k_2_02:24]
| • | Non-GAAP operating margin of approximately 37% |

[0001596532-20-000147:8k_2_02:25]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and certain non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below under “Non-GAAP Financial Measures”).

[0001596532-20-000147:8k_2_02:26]
Prepared Materials and Conference Call Information

[0001596532-20-000147:8k_2_02:27]
Arista executives will discuss the second quarter financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (833) 968-2211 in the United States or +1 (778) 560-2896 from international locations. The Conference ID is 5545177.

[0001596532-20-000147:8k_2_02:28]
The financial results conference call will also be available via live webcast on our investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-20-000147:8k_2_02:29]
Forward-Looking Statements

[0001596532-20-000147:8k_2_02:30]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the third quarter of fiscal year 2020, and statements regarding the benefits of the introduction of new products and our leadership in cloud networking. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: the impact of the COVID-19 pandemic on our business, including as a result of continued volatility in the financial markets and global economy or disruption in our supply chain, the evolution and growth of the cloud networking market and the adoption by end customers of Arista’s cloud networking solutions; rapid technological and market change; Arista’s customer concentration; our ability to attract new large end customers or sell additional products and services to existing customers; competition in our products and services markets; changes in Arista’s customers’ demand for our products and services; changes in customer order patterns or customer mix; requests by large end customers for more favorable terms and conditions; general market, political, economic and business conditions such as the recent U.S. trade wars with China and the impact of public health pandemics like the COVID-19 pandemic; dependence on the introduction and market acceptance of new product offerings and standards including our 400G products as well as our campus and WiFi products; declines in the sales prices of our products and services; the timing of orders and manufacturing and customer lead times; the benefits and impact of acquisitions; and other future events. Additional risks and uncertainties that could affect Arista can be found in our most recent Quarterly Report on Form 10-Q filed with the SEC on May 6, 2020, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-20-000147:8k_2_02:31]
Gartner “Magic Quadrant for Data Center and Cloud Networking,” Andrew Lerner, et al, 30 June 2020. Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner's research organization and should not be construed as statements of fact. Gartner disclaims all warranties, expressed or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.  The Gartner content described herein, (the "Gartner content") represent(s) research opinion

[0001596532-20-000147:8k_2_02:32]
or viewpoints published, as part of a syndicated subscription service, by Gartner, Inc. ("Gartner"), and are not representations of fact. Gartner Content speaks as of its original publication date (and not as of the date of this Form 8-K) and the opinions expressed in the Gartner Content are subject to change without notice.

[0001596532-20-000147:8k_2_02:33]
Non-GAAP Financial Measures

[0001596532-20-000147:8k_2_02:34]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangible assets, certain non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-20-000147:8k_2_02:35]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-20-000147:8k_2_02:36]
The company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and certain non-recurring items. The company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. A reconciliation of the non-GAAP financial measures guidance to the corresponding GAAP measures on a forward-looking basis is not available because stock-based compensation expense is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-20-000147:8k_2_02:37]
About Arista Networks

[0001596532-20-000147:8k_2_02:38]
Arista Networks is an industry leader in software-driven cloud networking solutions for large data center and campus environments. Arista’s award-winning platforms deliver availability, agility, automation analytics and security through CloudVision® and Arista EOS®, an advanced network operating system. For more information visit www.arista.com.

[0001596532-20-000147:8k_2_02:39]
Investor Contacts:

[0001596532-20-000147:8k_2_02:40]
Arista Networks, Inc.

[0001596532-20-000147:8k_2_02:41]
Charles Yager, 408-547-5892

[0001596532-20-000147:8k_2_02:42]
Product and Investor Advocacy

[0001596532-20-000147:8k_2_02:43]
cyager@arista.com

[0001596532-20-000147:8k_2_02:44]
or

[0001596532-20-000147:8k_2_02:45]
Curtis McKee, 408-547-5549

[0001596532-20-000147:8k_2_02:46]
Corporate and Investor Development

[0001596532-20-000147:8k_2_02:47]
curtism@arista.com

[0001596532-20-000147:8k_2_02:48]
ARISTA NETWORKS, INC.

[0001596532-20-000147:8k_2_02:49]
Condensed Consolidated Statements of Operations

[0001596532-20-000147:8k_2_02:50]
(Unaudited, in thousands, except per share amounts)

[0001596532-20-000147:8k_2_02:51]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 421,413 |  |  | $ | 513,171 |  |  | $ | 832,319 |  |  | $ | 1,018,586 |  |
| Service |  | 119,157 |  |  | 95,150 |  |  | 231,280 |  |  | 185,159 |  |
| Total revenue |  | 540,570 |  |  | 608,321 |  |  | 1,063,599 |  |  | 1,203,745 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 176,432 |  |  | 200,534 |  |  | 340,061 |  |  | 398,686 |  |
| Service |  | 20,049 |  |  | 17,596 |  |  | 41,198 |  |  | 34,298 |  |
| Total cost of revenue |  | 196,481 |  |  | 218,130 |  |  | 381,259 |  |  | 432,984 |  |
| Gross profit |  | 344,089 |  |  | 390,191 |  |  | 682,340 |  |  | 770,761 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 111,544 |  |  | 114,295 |  |  | 224,698 |  |  | 233,964 |  |
| Sales and marketing |  | 51,237 |  |  | 53,040 |  |  | 108,323 |  |  | 104,093 |  |
| General and administrative |  | 14,319 |  |  | 16,019 |  |  | 32,668 |  |  | 31,525 |  |
| Total operating expenses |  | 177,100 |  |  | 183,354 |  |  | 365,689 |  |  | 369,582 |  |
| Income from operations |  | 166,989 |  |  | 206,837 |  |  | 316,651 |  |  | 401,179 |  |
| Other income, net |  | 8,256 |  |  | 13,811 |  |  | 20,413 |  |  | 26,144 |  |
| Income before income taxes |  | 175,245 |  |  | 220,648 |  |  | 337,064 |  |  | 427,323 |  |
| Provision for income taxes |  | 30,452 |  |  | 31,397 |  |  | 53,840 |  |  | 37,043 |  |
| Net income |  | $ | 144,793 |  |  | $ | 189,251 |  |  | $ | 283,224 |  |  | $ | 390,280 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 144,793 |  |  | $ | 189,152 |  |  | $ | 283,224 |  |  | $ | 390,063 |  |
| Diluted |  | $ | 144,793 |  |  | $ | 189,158 |  |  | $ | 283,224 |  |  | $ | 390,076 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.91 |  |  | $ | 2.47 |  |  | $ | 3.72 |  |  | $ | 5.12 |  |
| Diluted |  | $ | 1.83 |  |  | $ | 2.33 |  |  | $ | 3.56 |  |  | $ | 4.80 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | 75,808 |  |  | 76,552 |  |  | 76,036 |  |  | 76,238 |  |
| Diluted |  | 79,298 |  |  | 81,335 |  |  | 79,620 |  |  | 81,271 |  |

[0001596532-20-000147:8k_2_02:52]
4

[0001596532-20-000147:8k_2_02:53]
ARISTA NETWORKS, INC.

[0001596532-20-000147:8k_2_02:54]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-20-000147:8k_2_02:55]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-20-000147:8k_2_02:56]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| GAAP gross profit |  | $ | 344,089 |  |  | $ | 390,191 |  |  | $ | 682,340 |  |  | $ | 770,761 |  |
| GAAP gross margin |  | 63.7 | % |  | 64.1 | % |  | 64.2 | % |  | 64.0 | % |
| Stock-based compensation expense |  | 1,585 |  |  | 1,028 |  |  | 2,912 |  |  | 2,126 |  |
| Intangible asset amortization |  | 4,178 |  |  | 2,626 |  |  | 7,838 |  |  | 5,251 |  |
| Non-GAAP gross profit |  | $ | 349,852 |  |  | $ | 393,845 |  |  | $ | 693,090 |  |  | $ | 778,138 |  |
| Non-GAAP gross margin |  | 64.7 | % |  | 64.7 | % |  | 65.2 | % |  | 64.6 | % |
| GAAP income from operations |  | $ | 166,989 |  |  | $ | 206,837 |  |  | $ | 316,651 |  |  | $ | 401,179 |  |
| Stock-based compensation expense |  | 32,922 |  |  | 24,297 |  |  | 60,478 |  |  | 48,588 |  |
| Litigation expense |  | — |  |  | 514 |  |  | — |  |  | 1,962 |  |
| Intangible asset amortization |  | 5,811 |  |  | 3,499 |  |  | 10,713 |  |  | 6,998 |  |
| Acquisition-related costs |  | — |  |  | — |  |  | 11,860 |  |  | — |  |
| Non-GAAP income from operations |  | $ | 205,722 |  |  | $ | 235,147 |  |  | $ | 399,702 |  |  | $ | 458,727 |  |
| Non-GAAP operating margin |  | 38.1 | % |  | 38.7 | % |  | 37.6 | % |  | 38.1 | % |
| GAAP net income |  | $ | 144,793 |  |  | $ | 189,251 |  |  | $ | 283,224 |  |  | $ | 390,280 |  |
| Stock-based compensation expense |  | 32,922 |  |  | 24,297 |  |  | 60,478 |  |  | 48,588 |  |
| Litigation expense |  | — |  |  | 514 |  |  | — |  |  | 1,962 |  |
| Intangible asset amortization |  | 5,811 |  |  | 3,499 |  |  | 10,713 |  |  | 6,998 |  |
| Acquisition-related costs (1) |  | — |  |  | — |  |  | 11,860 |  |  | — |  |
| Altera stock-based tax charge (2) |  | — |  |  | 9,781 |  |  | — |  |  | 9,781 |  |
| Gain on investment in privately-held companies |  | — |  |  | — |  |  | — |  |  | (1,150 | ) |
| Tax benefit on stock-based awards |  | (11,682 | ) |  | (23,455 | ) |  | (26,184 | ) |  | (60,509 | ) |
| Income tax effect on non-GAAP exclusions |  | (4,796 | ) |  | (5,324 | ) |  | (11,351 | ) |  | (9,657 | ) |
| Non-GAAP net income |  | $ | 167,048 |  |  | $ | 198,563 |  |  | $ | 328,740 |  |  | $ | 386,293 |  |
| GAAP diluted net income per share attributable to common stockholders |  | $ | 1.83 |  |  | $ | 2.33 |  |  | $ | 3.56 |  |  | $ | 4.80 |  |
| Non-GAAP adjustments to net income |  | 0.28 |  |  | 0.11 |  |  | 0.57 |  |  | (0.05 | ) |
| Non-GAAP diluted net income per share |  | $ | 2.11 |  |  | $ | 2.44 |  |  | $ | 4.13 |  |  | $ | 4.75 |  |
| Weighted-average shares used in computing diluted net income per share attributable to common stockholders |  | 79,298 |  |  | 81,335 |  |  | 79,620 |  |  | 81,271 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,585 |  |  | $ | 1,028 |  |  | $ | 2,912 |  |  | $ | 2,126 |  |
| Research and development |  | 19,378 |  |  | 12,568 |  |  | 35,306 |  |  | 25,699 |  |
| Sales and marketing |  | 8,277 |  |  | 7,097 |  |  | 14,673 |  |  | 13,631 |  |
| General and administrative |  | 3,682 |  |  | 3,604 |  |  | 7,587 |  |  | 7,132 |  |
| Total |  | $ | 32,922 |  |  | $ | 24,297 |  |  | $ | 60,478 |  |  | $ | 48,588 |  |

[0001596532-20-000147:8k_2_02:57]
___________________

[0001596532-20-000147:8k_2_02:58]
(1) Represents non-recurring costs associated with our acquisition of Big Switch, and primarily include severance, retention bonuses, professional and consulting fees, and facilities restructuring costs.

[0001596532-20-000147:8k_2_02:59]
(2) Represents a discrete income tax expense related to stock-based compensation as a result of an opinion on Altera Corporation and Subsidiaries vs. Commissioner on Internal Revenue issued by the Court of Appeals for the Ninth Circuit on June 7, 2019.

[0001596532-20-000147:8k_2_02:60]
ARISTA NETWORKS, INC.

[0001596532-20-000147:8k_2_02:61]
Condensed Consolidated Balance Sheets

[0001596532-20-000147:8k_2_02:62]
(Unaudited, in thousands)

[0001596532-20-000147:8k_2_02:63]
|  |  | June 30, 2020 |  | December 31, 2019 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 800,182 |  |  | $ | 1,111,286 |  |
| Marketable securities |  | 1,981,589 |  |  | 1,613,082 |  |
| Accounts receivable |  | 383,225 |  |  | 391,987 |  |
| Inventories |  | 326,997 |  |  | 243,825 |  |
| Prepaid expenses and other current assets |  | 84,885 |  |  | 111,456 |  |
| Total current assets |  | 3,576,878 |  |  | 3,471,636 |  |
| Property and equipment, net |  | 35,263 |  |  | 39,273 |  |
| Acquisition-related intangible assets, net |  | 83,562 |  |  | 45,235 |  |
| Goodwill |  | 84,968 |  |  | 54,855 |  |
| Investments |  | 4,150 |  |  | 4,150 |  |
| Operating lease right-of-use assets |  | 79,283 |  |  | 87,770 |  |
| Deferred tax assets |  | 446,254 |  |  | 452,025 |  |
| Other assets |  | 25,493 |  |  | 30,346 |  |
| TOTAL ASSETS |  | $ | 4,335,851 |  |  | $ | 4,185,290 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 122,872 |  |  | $ | 92,105 |  |
| Accrued liabilities |  | 100,070 |  |  | 140,249 |  |
| Deferred revenue |  | 328,525 |  |  | 312,668 |  |
| Other current liabilities |  | 88,714 |  |  | 52,052 |  |
| Total current liabilities |  | 640,181 |  |  | 597,074 |  |
| Income taxes payable |  | 45,971 |  |  | 55,485 |  |
| Operating lease liabilities, non-current |  | 74,259 |  |  | 83,022 |  |
| Deferred revenue, non-current |  | 248,986 |  |  | 262,620 |  |
| Deferred tax liabilities, non-current |  | 251,292 |  |  | 254,710 |  |
| Other long-term liabilities |  | 38,679 |  |  | 37,693 |  |
| TOTAL LIABILITIES |  | 1,299,368 |  |  | 1,290,604 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 8 |  |  | 8 |  |
| Additional paid-in capital |  | 1,185,093 |  |  | 1,106,305 |  |
| Retained earnings |  | 1,843,559 |  |  | 1,788,230 |  |
| Accumulated other comprehensive income |  | 7,823 |  |  | 143 |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 3,036,483 |  |  | 2,894,686 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 4,335,851 |  |  | $ | 4,185,290 |  |

[0001596532-20-000147:8k_2_02:64]
6

[0001596532-20-000147:8k_2_02:65]
ARISTA NETWORKS, INC.

[0001596532-20-000147:8k_2_02:66]
Condensed Consolidated Statements of Cash Flows

[0001596532-20-000147:8k_2_02:67]
(Unaudited, in thousands)

[0001596532-20-000147:8k_2_02:68]
|  |  | Six Months Ended June 30, |
|  |  | 2020 |  | 2019 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 283,224 |  |  | $ | 390,280 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 21,170 |  |  | 16,757 |  |
| Stock-based compensation |  | 60,478 |  |  | 48,588 |  |
| Noncash lease expense |  | 8,223 |  |  | 7,955 |  |
| Deferred income taxes |  | 2,668 |  |  | 7,914 |  |
| Gain on investment in privately-held companies |  | — |  |  | (1,150 | ) |
| Amortization (accretion) of investment premiums (discounts) |  | 2,938 |  |  | (4,260 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | 15,263 |  |  | (11,303 | ) |
| Inventories |  | (82,891 | ) |  | (49,620 | ) |
| Prepaid expenses and other current assets |  | 26,815 |  |  | 48,864 |  |
| Other assets |  | 5,360 |  |  | (4,635 | ) |
| Accounts payable |  | 31,473 |  |  | (6,783 | ) |
| Accrued liabilities |  | (39,882 | ) |  | (9,476 | ) |
| Deferred revenue |  | (19,242 | ) |  | (85,009 | ) |
| Income taxes payable |  | 16,820 |  |  | 14,399 |  |
| Other liabilities |  | 646 |  |  | 3,955 |  |
| Net cash provided by operating activities |  | 333,063 |  |  | 366,476 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 875,213 |  |  | 552,512 |  |
| Purchases of marketable securities |  | (1,236,477 | ) |  | (549,383 | ) |
| Business acquisitions, net of cash acquired |  | (66,317 | ) |  | — |  |
| Purchases of property and equipment |  | (5,178 | ) |  | (8,639 | ) |
| Net cash used in investing activities |  | (432,759 | ) |  | (5,510 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 22,228 |  |  | 38,104 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (4,000 | ) |  | (4,662 | ) |
| Repurchase of common stock |  | (227,895 | ) |  | (100,008 | ) |
| Net cash used in financing activities |  | (209,667 | ) |  | (66,566 | ) |
| Effect of exchange rate changes |  | (1,663 | ) |  | 72 |  |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | (311,026 | ) |  | 294,472 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 1,115,515 |  |  | 654,164 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 804,489 |  |  | $ | 948,636 |  |
