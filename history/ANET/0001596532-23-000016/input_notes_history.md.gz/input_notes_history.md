# ANET note change history — 0001596532-22-000220 → 0001596532-22-000294


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-11-01):
[0001596532-22-000294:note_history:1]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of September 30, 2022, we had non-cancellable purchase commitments of $4.3 billion, of which $3.1 billion have confirmed receipt dates within 12 months, and $1.2 billion have confirmed receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.
  (was, 2022-08-02, similarity 0.6445):
[0001596532-22-000220:note_history:1]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of June 30, 2022, we had non-cancellable purchase commitments of $4,472.2 million, out of which $2,937.6 million have confirmed receipt dates within 12 months, and $1,534.6 million have confirmed receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

- changed (2022-11-01):
[0001596532-22-000294:note_history:2]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $124.7 million and $49.1 million as of September 30, 2022 and December 31, 2021, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.
  (was, 2022-08-02, similarity 0.9795):
[0001596532-22-000220:note_history:2]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $100.8 million and $49.1 million as of June 30, 2022 and December 31, 2021, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the condensed consolidated balance sheets.

- changed (2022-11-01):
[0001596532-22-000294:note_history:3]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of September 30, 2022, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.
  (was, 2022-08-02, similarity 0.9937):
[0001596532-22-000220:note_history:3]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of June 30, 2022, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse 
impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-11-01):
[0001596532-22-000294:note_history:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2022, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2021 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.
  (was, 2022-08-02, similarity 0.9811):
[0001596532-22-000220:note_history:4]
The accompanying unaudited condensed consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and have been prepared in accordance with U.S. Generally Accepted Accounting Principles (“GAAP”) and the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting.  As permitted under those rules, certain footnotes or other financial information that are normally required by GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2022, are not necessarily indicative of the results expected for the full fiscal year. The condensed consolidated balance sheet as of December 31, 2021 has been derived from the audited consolidated financial statements at that date but does not include all of the information and notes required by GAAP for complete financial statements. All significant inter-company accounts and transactions have been eliminated.

- changed (2022-11-01):
[0001596532-22-000294:note_history:5]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including supply chain and labor shortages, inflation and monetary policy shifts, recession risks, the ongoing global coronavirus ("COVID-19") pandemic and potential disruptions from the Russia-Ukraine conflict and the U.S. trade war with China.
  (was, 2022-08-02, similarity 0.9475):
[0001596532-22-000220:note_history:5]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including supply chain and labor shortages, inflation and monetary policy shifts, recession risks, the ongoing global coronavirus ("COVID-19") pandemic and potential disruptions from the Russia-Ukraine conflict.

- added (2022-11-01):
[0001596532-22-000294:note_history:6]
Our contract manufacturers and suppliers have experienced workforce disruptions, delays in component sourcing, production and export of their products and component shortages and increased component costs, which have disrupted our supply chain and have impacted and will likely continue to impact our ability to supply products to our customers on a timely basis. While overall demand remains strong across our customers base, we believe ongoing supply disruptions combined with other supply chain related constraints could impact our ability to fulfill this increased demand and as a result could negatively impact our business in future periods. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. Our operating cash flows have also been and may continue to be negatively impacted by increased component inventories on hand or at our contract manufacturers, awaiting supply of a limited number of scarce components necessary to build and ship the completed product. The extent of the impact on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, the impact to

- added (2022-11-01):
[0001596532-22-000294:note_history:7]
our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. Management continues to actively monitor the impact of these macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which these factors may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.

- changed (2022-11-01):
[0001596532-22-000294:note_history:8]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. ASU 2021-08 requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC 606. Under previous GAAP, an acquirer generally recognized assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 results in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption impact was immaterial to the condensed consolidated financial statements. The standard did not impact acquired contract assets or liabilities from business combinations occurring prior to the adoption date.
  (was, 2022-08-02, similarity 0.9962):
[0001596532-22-000220:note_history:8]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. ASU 2021-08 requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC 606. Under previous GAAP, an acquirer generally recognizes assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 results in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption impact was immaterial to the condensed consolidated financial statements. The standard will not impact acquired contract assets or liabilities from business combinations occurring prior to the adoption date.

- removed (2022-11-01):
[0001596532-22-000220:note_history:9]
Our contract manufacturers and suppliers have experienced workforce disruptions, delays in component sourcing, production and export of their products as well as component shortages and increased component costs, which have disrupted our supply chain and have impacted and will likely continue to impact our ability to supply products to our customers on a timely basis. While we continue to experience strong overall demand from customers, we believe ongoing supply disruptions combined with other supply chain related constraints could impact our ability to fulfill this increased demand and as a result could negatively impact our business in future periods. In addition, inflation pressure in our supply chain and scarcity of some materials needed to build our products have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. The extent of the impact on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, and the impact of any initiatives and programs we may undertake to address financial and operational challenges, will depend on future developments, the impact to our customers, partners, employees, contract manufacturers and supply chain, as well as restrictions on travel and transport, all of which continue to evolve and are unpredictable. Management continues to actively monitor the impact of these macroeconomic factors

- removed (2022-11-01):
[0001596532-22-000220:note_history:10]
on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. As of the date of issuance of these condensed consolidated financial statements, the extent to which these factors may materially impact the Company's financial condition, liquidity, or results of operations is uncertain.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-11-01):
[0001596532-22-000294:note_history:11]
|  |  | September 30, 2022 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 877,442 |  |  | $ | (13,026) |  |  | $ | 292,554 |  |  | $ | (4,976) |  |  | $ | 1,169,996 |  |  | $ | (18,002) |  |
| Corporate bonds |  | 625,577 |  |  | (13,314) |  |  | 258,208 |  |  | (5,035) |  |  | 883,785 |  |  | (18,349) |  |
| Agency securities |  | 155,296 |  |  | (2,807) |  |  | 24,176 |  |  | (491) |  |  | 179,472 |  |  | (3,298) |  |
| Total |  | $ | 1,658,315 |  |  | $ | (29,147) |  |  | $ | 574,938 |  |  | $ | (10,502) |  |  | $ | 2,233,253 |  |  | $ | (39,649) |  |

- removed (2022-11-01):
[0001596532-22-000220:note_history:12]
|  |  | As of June 30, 2022 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 1,082,084 |  |  | $ | (16,276) |  |  | $ | — |  |  | $ | — |  |  | $ | 1,082,084 |  |  | $ | (16,276) |  |
| Corporate bonds |  | 995,771 |  |  | (16,075) |  |  | 65,373 |  |  | (1,149) |  |  | 1,061,144 |  |  | (17,224) |  |
| Agency securities |  | 206,768 |  |  | (2,920) |  |  | — |  |  | — |  |  | 206,768 |  |  | (2,920) |  |
| Total |  | $ | 2,284,623 |  |  | $ | (35,271) |  |  | $ | 65,373 |  |  | $ | (1,149) |  |  | $ | 2,349,996 |  |  | $ | (36,420) |  |
