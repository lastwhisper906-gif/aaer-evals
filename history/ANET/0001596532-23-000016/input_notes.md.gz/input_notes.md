# ANET notes — 0001596532-23-000016


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001596532-23-000016:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001596532-23-000016:notes:2]
Portions of the registrant’s definitive Proxy Statement relating to its 2023 Annual Meeting of Stockholders to be filed pursuant to Regulation 14A within 120 days after the registrant’s fiscal year end of December 31, 2022 are incorporated by reference into Part III of this Annual Report on Form 10-K.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-23-000016:notes:3]
Organization and Summary of Significant Accounting Policies
Organization

[0001596532-23-000016:notes:4]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of next-generation data center and campus workspace environments. Our cloud networking solutions consist of our EOS, a set of network applications and our Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-23-000016:notes:5]
Basis of Presentation and Principles of Consolidation

[0001596532-23-000016:notes:6]
The accompanying consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and are prepared in accordance with accounting principles generally accepted in the United States ("GAAP"). All significant intercompany accounts and transactions have been eliminated.

[0001596532-23-000016:notes:7]
On November 1, 2021, we announced a four-for-one split of the Company’s common stock effected in the form of a stock dividend (the “Stock Split”). Each stockholder of record on November 11, 2021 received three additional shares of common stock for each then-held share, and such shares were distributed after close of trading on November 17, 2021. All share and per share amounts presented herein have been retroactively adjusted to reflect the impact of the Stock Split.

[0001596532-23-000016:notes:8]
Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.

[0001596532-23-000016:notes:9]
Risk and Uncertainties

[0001596532-23-000016:notes:10]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including supply chain constraints, inflation and monetary policy shifts, recession risks, the global coronavirus ("COVID-19") pandemic, and potential disruptions from the Russia-Ukraine conflict and U.S. trade war with China.

[0001596532-23-000016:notes:11]
Although we saw some improvement in our manufacturing and supply chain operations in the latter part of 2022, we continue to experience constraints, with some lingering component shortages, extended lead times, and elevated component and supply chain costs. We continue to work closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. Although we have worked diligently to drive improvements in these areas, including funding additional working capital and incremental purchase commitments, these delays have negatively impacted our ability to supply products to our customers on a timely basis. Our demand planning horizon remains extended with high levels of purchase commitments and increased investments in working capital to address delays in component sourcing and the risk of future supply chain disruptions, but we cannot be certain that such delays or disruptions will not occur, or that our extended demand planning horizon will adequately address these disruptions should they occur. In addition, inflation pressure in our supply chain, scarcity of some materials needed to build our products and disruptions to our manufacturing process have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. Our operating cash-flows have also been and may continue to be negatively impacted by increased component inventories on hand or at our contract manufacturers, awaiting supply of a limited number of scarce components necessary to build and ship the completed product. While overall demand remains stable, supply chain and manufacturing related constraints could impact our ability to fulfill this demand, and as a result could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the Russia-Ukraine conflict, continued escalation of the conflict may negatively impact the global economy and our future operating results and financial condition.

[0001596532-23-000016:notes:12]
Management continues to actively monitor the impact of these macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame,  will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable; however, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that any extended or renewed economic disruptions or deterioration in the global economy could have a negative impact on demand from our customers in future periods. Accordingly, current results and financial condition discussed herein may not be indicative of future operating

[0001596532-23-000016:notes:13]
results and trends, and as of the date of issuance of these consolidated financial statements, the extent to which these factors may materially impact the Company's financial condition, liquidity, or results of operations in the future is uncertain.

[0001596532-23-000016:notes:14]
Use of Estimates

[0001596532-23-000016:notes:15]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, valuation of inventory and contract manufacturer/supplier liabilities, accounting for income taxes, including the recognition of deferred tax assets and liabilities, valuation allowance on deferred tax assets and reserves for uncertain tax positions, revenue recognition and deferred revenue, allowance for doubtful accounts, sales rebates and return reserves, valuation of goodwill and acquisition-related intangible assets, estimate of useful lives of long-lived assets including intangible assets, and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust these estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from these estimates.

[0001596532-23-000016:notes:16]
Concentrations of Business and Credit Risk

[0001596532-23-000016:notes:17]
We work closely with third-party contract manufacturers to manufacture our products. As of December 31, 2022, we had four primary contract manufacturing partners, who provided the vast majority of our electronic manufacturing services. Our contract manufacturing partners deliver our products to our third-party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers. Our products rely on key components, including certain integrated circuit components and power supplies, some of which our contract manufacturing partners purchase on our behalf from a limited number of suppliers, including certain sole-source providers. We generally do not have guaranteed supply contracts with our component suppliers, and our manufacturing partners could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, or if we are unable to obtain alternative sources for these components, sales of our products could be delayed or halted entirely, or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.

[0001596532-23-000016:notes:18]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, marketable securities, restricted cash, and accounts receivable. Our cash equivalents, restricted cash and marketable securities are invested in high quality financial instruments with banks and financial institutions. Such deposits may be in excess of insured limits provided on such deposits.

[0001596532-23-000016:notes:19]
Our accounts receivable are unsecured and represent amounts due to us based on contractual obligations of our customers. We mitigate credit risk with respect to accounts receivable by performing ongoing credit evaluations of our customers to assess the probability of collection based on a number of factors, including past transaction experience with the customer, evaluation of their credit history, the credit limits extended, review of the invoicing terms of the arrangement, and current economic conditions that may affect a customer’s ability to pay. In situations where a customer may be thinly capitalized and we have limited payment history with it, we will either establish a small credit limit or require it to prepay its purchases. We generally do not require our customers to provide collateral to support accounts receivable. We have recorded an allowance for doubtful accounts for accounts receivables that we have determined to be uncollectible. We mitigate credit risk with respect to accounts receivables by performing ongoing credit evaluations of the borrower to assess the probability of collecting all amounts due to us under the existing contractual terms.

[0001596532-23-000016:notes:20]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators and OEM partners, and in conjunction with various technology partners.  Significant customers are those that represent more than 10% of our total net revenue during the period or net accounts receivable balance at each respective balance sheet date. As of December 31, 2022, we had two customers who represented 28% and 16% of total accounts receivable. As of December 31, 2021, we had three customers who represented 37%, 13% and 12% of total accounts receivable.  For the year ended December 31, 2022, there were two customers who represented 26% and 16% of our total revenue. For the years ended December 31, 2021 and 2020, there was one customer who represented 15% and 22% of our total revenue, respectively.

[0001596532-23-000016:notes:21]
Cash and Cash Equivalents

[0001596532-23-000016:notes:22]
We consider all highly liquid investments with original or remaining maturities of three months or less at the time of purchase to be cash equivalents. Cash and cash equivalents consist of cash on deposit with various financial institutions and highly liquid investments in money market funds. Interest is accrued as earned. As of December 31, 2022 and 2021, we had restricted cash of $4.3 million and $4.2 million respectively, and that primarily included $4.0 million pledged as collateral representing a security deposit required for a facility lease. Our restricted cash is classified as other assets in the accompanying consolidated balance sheets.

[0001596532-23-000016:notes:23]
Marketable Securities

[0001596532-23-000016:notes:24]
We classify all highly liquid investments in debt securities with maturities of greater than three months at the date of purchase as marketable securities. We have classified and accounted for our marketable debt and equity securities as available-for-sale. We determine the appropriate classification of these investments at the time of purchase and reevaluate such designation at each balance sheet date. We may or may not hold securities with stated maturities greater than 12 months until maturity. After consideration of our risk versus reward objectives, as well as our liquidity requirements, we may sell these securities prior to their stated maturities. As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets. We carry these securities at fair value. For marketable debt securities, we report the unrealized gains and losses, net of taxes, as a component of stockholders’ equity. For marketable equity securities, we report the unrealized gains and losses in other income (expense), net on the Consolidated Statements of Operations. We determine the cost of the debt investment sold based on an average cost basis at the individual security level, and record the interest income in other income, net in the accompanying consolidated statements of operations. We determine any realized gains or losses on the sale of marketable securities using the specific identification method, and record such gains and losses in other income, net in the accompanying consolidated statements of operations.

[0001596532-23-000016:notes:25]
For our debt securities in an unrealized loss position, we determine whether a credit loss exists by considering information about the collectability of the instrument and current market conditions. We recognize an allowance for credit losses, up to the amount of the unrealized loss when appropriate, and write down the amortized cost basis of the investment if it is more likely than not we will be required to sell or we intend to sell the investment before recovery of its amortized cost basis.

[0001596532-23-000016:notes:26]
Accounts Receivable

[0001596532-23-000016:notes:27]
Accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts, sales rebates and returns reserves. We estimate our allowance for doubtful accounts based upon the collectability of the receivables in light of historical trends, reasonable and supportable information of our customers' economic conditions that may affect our customers’ ability to pay, and prevailing economic conditions. This evaluation is done in order to identify issues that may impact the collectability of receivables and related estimated required allowance. Revisions to the allowance are recorded as an adjustment to bad debt expense. After appropriate collection efforts are exhausted, specific accounts receivable deemed to be uncollectible are charged against the allowance in the period they are deemed uncollectible. Recoveries of accounts receivable previously written-off are recorded as credits to bad debt expense. We primarily estimate our sales rebates and returns reserves based on historical rates applied against current period billings. Specific customer returns, rebates and allowances are considered when determining our estimates. Revisions to sales rebate and return reserves are recorded as adjustments to revenue.

[0001596532-23-000016:notes:28]
Fair Value Measurements

[0001596532-23-000016:notes:29]
Fair value is defined as the exchange price that would be received for an asset or an exit price that would be paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. These assets and liabilities include cash and cash equivalents, marketable securities, accounts receivable, accounts payable, and accrued liabilities. Cash equivalents, accounts receivable, accounts payable and accrued liabilities are stated at carrying values in our consolidated financial statements, which approximate their fair value due to the short-term nature of these instruments.

[0001596532-23-000016:notes:30]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value.  We use a fair value

[0001596532-23-000016:notes:31]
hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs.  The three-tiers of the fair value hierarchy are as follows:

[0001596532-23-000016:notes:32]
Level I—Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date;

[0001596532-23-000016:notes:33]
Level II—Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities; and

[0001596532-23-000016:notes:34]
Level III—Unobservable inputs that are supported by little or no market data for the related assets or liabilities and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.

[0001596532-23-000016:notes:35]
Foreign Currency

[0001596532-23-000016:notes:36]
The functional currency of our foreign subsidiaries is either the U.S. dollar or their local currency depending on the nature of the subsidiaries’ activities.

[0001596532-23-000016:notes:37]
Transaction re-measurement - Assets and liabilities denominated in a currency other than a subsidiary’s functional currency are re-measured into the subsidiary's functional currency using exchange rates in effect at the end of the reporting period, with gains and losses recorded in other income, net in the consolidated statements of operations. To date, foreign currency transaction gains and losses and exchange rate fluctuations have not been material to our consolidated financial statements.

[0001596532-23-000016:notes:38]
Translation - Assets and liabilities of subsidiaries denominated in foreign functional currencies are translated into U.S. dollars at the closing exchange rate on the balance sheet date and equity-related balances are translated at historical exchange rates.  Revenues, costs and expenses in foreign functional currencies are translated using average exchange rates that approximate those in effect during the period. Translation adjustments are recorded within accumulated other comprehensive income, a separate component of total stockholders’ equity.

[0001596532-23-000016:notes:39]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-23-000016:notes:40]
Inventories primarily consist of finished goods and strategic components, primarily integrated circuits. Inventories are stated at the lower of cost (computed using the first-in, first-out method) and net realizable value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value. For the years ended December 31, 2022, 2021 and 2020, we recorded charges of $71.4 million, $61.8 million and $50.5 million, respectively, within cost of product revenue for inventory write-downs.

[0001596532-23-000016:notes:41]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts. We record a liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with our contract manufacturers or suppliers for quantities in excess of our demand forecasts or that are considered obsolete due to manufacturing and engineering change orders resulting from design changes. For the years ended December 31, 2022 and 2020, we recorded charges of $43.7 million and $14.9 million, respectively, within cost of product revenue for such liabilities with our contract manufacturers and suppliers. For the year ended December 31, 2021, we did not incur any losses on such liabilities.

[0001596532-23-000016:notes:42]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels.  In addition, industry-wide supply chain shortages have resulted in extended lead times for components and have required us to extend the time horizon of our demand forecasts and increase our purchase commitments for long lead time components. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and/or outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer and supplier liabilities.

[0001596532-23-000016:notes:43]
Property and Equipment

[0001596532-23-000016:notes:44]
Property and equipment are stated at cost, less accumulated depreciation, except for land which is not depreciated. We capitalize any additions and improvements and expense maintenance and repairs as incurred. Depreciation is calculated using

[0001596532-23-000016:notes:45]
the straight-line method over the estimated useful lives of the related assets, generally three years. Our leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term.

[0001596532-23-000016:notes:46]
Leases

[0001596532-23-000016:notes:47]
We lease office space, data centers, and equipment under non-cancellable operating leases with various expiration dates through 2028. We determine if an arrangement contains a lease at inception. Operating leases are included in operating lease right-of-use (“ROU”) assets, other current liabilities, and operating lease liabilities, non-current in our consolidated balance sheets. We do not have any finance leases in any of the periods presented.

[0001596532-23-000016:notes:48]
ROU assets and lease liabilities are recognized at the commencement date based on the present value of remaining lease payments over the lease term. The interest rate implicit in our operating leases is not readily available, and therefore, an incremental borrowing rate is estimated based on a hypothetical interest rate on a collateralized basis with similar terms, payments, and economic environments. Operating lease right-of-use assets also include any prepaid lease payments and lease incentives.

[0001596532-23-000016:notes:49]
Our operating lease agreements may contain rent concession, rent escalation, and option to renew provisions.  Lease expense is recognized on a straight-line basis over the lease term commencing on the date we have the right to use the leased property. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that the option will be exercised. In addition, certain of our operating lease agreements contain tenant improvement allowances from landlords. These allowances are accounted for as lease incentives and decrease our right-of-use asset and reduce lease expense over the lease term.

[0001596532-23-000016:notes:50]
Our lease agreements may contain lease and non-lease components, which are combined and accounted for as a single lease component. We also have elected to apply the short-term lease measurement and recognition exemption in which ROU assets and lease liabilities are not recognized for leases with terms of 12 months or less.

[0001596532-23-000016:notes:51]
Business Combinations

[0001596532-23-000016:notes:52]
We use the acquisition method to account for our business combinations in accordance with Accounting Standards Codification ("ASC") 805 - Business Combinations. We allocate the total fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the consideration transferred over the fair values of the assets acquired and liabilities assumed is recorded as goodwill. The results of operations of the acquired businesses are included in our consolidated financial statements from the date of acquisition. Acquisition-related transaction and restructuring costs are expensed as incurred.

[0001596532-23-000016:notes:53]
During the measurement period, which is not to exceed one year from the acquisition date, we may record adjustments to the acquired assets and liabilities assumed, with a corresponding offset to goodwill or the preliminary purchase price, to reflect new information obtained about facts and circumstances that existed as of the acquisition date. Upon the conclusion of the measurement period, any subsequent adjustments are recorded to earnings.

[0001596532-23-000016:notes:54]
Goodwill and Acquired Intangible Assets

[0001596532-23-000016:notes:55]
Goodwill represents the excess of the purchase price over the fair value of net assets acquired in a business combination. The Company has one reporting unit and tests goodwill for impairment at least annually in the fourth quarter or more frequently if indicators of potential impairment exist. We first perform a qualitative assessment to determine whether it is more likely than not that the fair value of our reporting unit is less than its carrying amount. If the reporting unit does not pass the qualitative assessment, a quantitative test is performed by comparing the fair value of our reporting unit with its carrying amount.  We would recognize an impairment loss for the amount by which the carrying amount exceeds the fair value. There were no impairment charges in any of the periods presented in the consolidated financial statements. See Note 4. Acquisition, Goodwill and Acquisition-Related Intangible Assets for additional information.

[0001596532-23-000016:notes:56]
Acquired intangible assets are carried at cost less accumulated amortization. All acquired intangible assets have been determined to have definite lives and are amortized on a straight-line basis over their estimated useful lives, ranging from one to eight years. Acquired intangible assets are reviewed for impairment under the long-lived asset model described below. There were no impairment charges in any of the periods presented in the consolidated financial statements. See Note 4. Acquisition, Goodwill and Acquisition-Related Intangible Assets for additional information.

[0001596532-23-000016:notes:57]
Investments in Privately-Held Companies

[0001596532-23-000016:notes:58]
Our equity investments in privately-held companies without readily determinable fair values are measured using the measurement alternative, defined by ASC 321 - Investments-Equity Securities as cost, less impairments, and remeasured based on observable price changes from orderly transactions of identical or similar securities of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded within other income, net in our consolidated statements of operations. This election is reassessed each reporting period to determine whether investments in privately-held companies have a readily determinable fair value, in which case they would no longer be eligible for this election. The Company did not hold investments in privately-held companies whose fair value was readily determinable as of December 31, 2022 and 2021.

[0001596532-23-000016:notes:59]
Impairment of Long-Lived Assets and Investments in Privately-Held Companies

[0001596532-23-000016:notes:60]
The carrying amounts of our long-lived assets, including property and equipment, intangible assets, ROU assets and investments in privately-held companies, are periodically reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. Recoverability of these assets is measured by comparison of the carrying amount of each asset to the future undiscounted cash flows the asset is expected to generate over its remaining life. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. No impairment of any other long-lived assets was identified for any of the periods presented in the consolidated financial statements.

[0001596532-23-000016:notes:61]
Loss Contingencies

[0001596532-23-000016:notes:62]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgments and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements, and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.

[0001596532-23-000016:notes:63]
Revenue Recognition

[0001596532-23-000016:notes:64]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with post-contract customer support (“PCS”). We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

[0001596532-23-000016:notes:65]
•Identification of the contract, or contracts, with a customer

[0001596532-23-000016:notes:66]
•Identification of the performance obligations in the contract

[0001596532-23-000016:notes:67]
•Determination of the transaction price

[0001596532-23-000016:notes:68]
•Allocation of the transaction price to the performance obligations in the contract

[0001596532-23-000016:notes:69]
•Recognition of revenue when (or as) we satisfy the performance obligation

[0001596532-23-000016:notes:70]
Post-Contract Customer Support ("PCS")

[0001596532-23-000016:notes:71]
PCS, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernible pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and address customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-23-000016:notes:72]
Contracts with Multiple Performance Obligations

[0001596532-23-000016:notes:73]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts that contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

[0001596532-23-000016:notes:74]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to, the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

[0001596532-23-000016:notes:75]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at-risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

[0001596532-23-000016:notes:76]
Most of our contracts with customers have payment terms of 30 days with some large high-volume customers having terms of up to 90 days. We have determined our contracts generally do not include a significant financing component because the Company and the customer have specific business reasons other than financing for entering into such contracts. Specifically, both we and our customers seek to ensure the customer has a simplified way of purchasing Arista products and services.

[0001596532-23-000016:notes:77]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

[0001596532-23-000016:notes:78]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical return rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-23-000016:notes:79]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

[0001596532-23-000016:notes:80]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

[0001596532-23-000016:notes:81]
Contract Balances

[0001596532-23-000016:notes:82]
A contract asset is recognized when we have a contractual right to consideration for both completed and partially completed performance obligations that have not yet been invoiced.  Contract assets are included in other current assets in the accompanying consolidated balance sheets.

[0001596532-23-000016:notes:83]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a contract that is cancellable. Contract liabilities are included in other current liabilities and other long-term liabilities in the accompanying consolidated balance sheets.

[0001596532-23-000016:notes:84]
Assets Recognized from Costs to Obtain a Contract with a Customer

[0001596532-23-000016:notes:85]
We recognize an asset for the incremental costs of obtaining a contract with a customer if we expect the benefit of those costs to be longer than one year. We have determined that certain sales commissions earned by our sales force meet the requirements for capitalization. These costs are deferred and then amortized over a period of benefit that we have determined to be five years. Total capitalized costs to obtain a contract are included in other current and long-term assets on our consolidated balance sheets. As of December 31, 2022 and 2021, total capitalized costs to obtain contracts were $13.1 million and $11.5 million, respectively.

[0001596532-23-000016:notes:86]
Research and Development Expenses

[0001596532-23-000016:notes:87]
Costs related to the research, design and development of our products are charged to research and development expenses as incurred. Software development costs are capitalized beginning when a product’s technological feasibility has been established and ending when the product is available for general release to customers. Generally, our products are released soon after technological feasibility has been established. As a result, costs incurred subsequent to achieving technological feasibility have not been significant and accordingly, all software development costs have been expensed as incurred.

[0001596532-23-000016:notes:88]
Warranty

[0001596532-23-000016:notes:89]
We generally offer a one-year warranty on all of our hardware products and a 90-day warranty against defects in the software embedded in the products. We use judgment and estimates when determining warranty costs based on historical costs to replace product returns within the warranty period at the time we recognize revenue. We accrue for potential warranty claims at the time of shipment as a component of cost of revenues based on historical experience and other relevant information. We reserve for specifically identified products if and when we determine we have a systemic product failure. Although we engage in extensive product quality programs, if actual product failure rates or use of materials differ from estimates, additional warranty costs may be incurred, which could reduce our gross margin. The accrued warranty liability is recorded in accrued liabilities in the accompanying consolidated balance sheets.

[0001596532-23-000016:notes:90]
Segment Reporting

[0001596532-23-000016:notes:91]
We develop, market and sell cloud networking solutions, which primarily consist of our switching and routing platforms and related network applications, and there are no segment managers who are held accountable for operations or operating results below the Company level. Our chief operating decision maker is our Chief Executive Officer, who reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.  Accordingly, we have determined that we operate as one reportable segment.

[0001596532-23-000016:notes:92]
Stock-Based Compensation

[0001596532-23-000016:notes:93]
Stock-based compensation cost for equity awards is measured at the grant-date fair value using appropriate valuation techniques and recognized as expense over the requisite service or performance period.  We account for forfeitures when they occur.

[0001596532-23-000016:notes:94]
Stock-based compensation costs for stock options and restricted stock units ("RSUs") are recognized on a straight-line basis over the requisite service period, which is generally two to five years. The Company has granted RSUs that vest upon the satisfaction of both service-based and performance-based conditions ("PRSUs"). The service-based condition for these awards is generally satisfied over four years. The performance-based conditions are satisfied upon achieving specified performance targets, such as financial or operating metrics. We record stock-based compensation expense for performance-based equity awards on an accelerated attribution method over the requisite service period, and only if performance-based conditions are considered probable to be satisfied.

[0001596532-23-000016:notes:95]
See Note 6. Stockholders' Equity and Stock-Based Compensation for a detailed discussion of the Company’s stock plans, assumptions to the valuation techniques, and stock-based compensation expense.

[0001596532-23-000016:notes:96]
Income Taxes

[0001596532-23-000016:notes:97]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-23-000016:notes:98]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-23-000016:notes:99]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-23-000016:notes:100]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.

[0001596532-23-000016:notes:101]
The U.S. tax rules require U.S. tax on foreign earnings, known as global intangible low taxed income (“GILTI”). Under U.S. GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”).  We selected the deferred method of accounting and recorded the associated basis differences anticipated to influence prospective GILTI calculations.

[0001596532-23-000016:notes:102]
Recently Adopted Accounting Pronouncements

[0001596532-23-000016:notes:103]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. ASU 2021-08 requires companies to recognize and measure contract assets and contract liabilities relating to contracts with customers that are acquired in a business combination in accordance with ASC 606. Under previous GAAP, an acquirer generally recognized assets acquired and liabilities assumed in a business combination, including contract assets and contract liabilities arising from revenue contracts with customers, at fair value on the acquisition date. ASU No. 2021-08 results in the acquirer recording acquired contract assets and liabilities on the same basis that would have been recorded by the acquiree before the acquisition under ASC Topic 606. The ASU is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. The Company adopted this ASU as of January 1, 2022 on a prospective basis and the adoption impact was immaterial to the consolidated financial statements.

[0001596532-23-000016:notes:104]
Recent Accounting Pronouncements Not Yet Effective

[0001596532-23-000016:notes:105]
We believe that all recently issued accounting pronouncements from the FASB will not have a material impact on its Consolidated Financial Statements or do not apply to its operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-23-000016:notes:106]
Fair Value Measurements
Assets measured at fair values on a recurring basis

[0001596532-23-000016:notes:107]
We measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value on a recurring basis. The following tables summarize the fair value of these financial assets by significant investment category and their levels within the fair value hierarchy (in thousands):

[0001596532-23-000016:notes:108]
|  |  | December 31, 2022 |  | December 31, 2021 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 322,294 |  |  | $ | — |  |  | $ | — |  |  | $ | 322,294 |  |  | $ | 221,382 |  |  | $ | — |  |  | $ | — |  |  | $ | 221,382 |  |
| Commercial paper |  | — |  |  | 5,422 |  |  | — |  |  | 5,422 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Agency securities |  | — |  |  | 17,559 |  |  | — |  |  | 17,559 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government notes |  | 51,986 |  |  | — |  |  | — |  |  | 51,986 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | 374,280 |  |  | 22,981 |  |  | — |  |  | 397,261 |  |  | 221,382 |  |  | — |  |  | — |  |  | 221,382 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 141,274 |  |  | — |  |  | 141,274 |  |
| Certificates of deposits (1) |  | — |  |  | 10,492 |  |  | — |  |  | 10,492 |  |  | — |  |  | 44,931 |  |  | — |  |  | 44,931 |  |
| U.S. government notes |  | 993,955 |  |  | — |  |  | — |  |  | 993,955 |  |  | 1,057,810 |  |  | — |  |  | — |  |  | 1,057,810 |  |
| Corporate bonds |  | — |  |  | 1,113,134 |  |  | — |  |  | 1,113,134 |  |  | — |  |  | 1,252,226 |  |  | — |  |  | 1,252,226 |  |
| Agency securities |  | — |  |  | 215,380 |  |  | — |  |  | 215,380 |  |  | — |  |  | 291,261 |  |  | — |  |  | 291,261 |  |
| Marketable equity securities(2) |  | 19,061 |  |  | — |  |  | — |  |  | 19,061 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | 1,013,016 |  |  | 1,339,006 |  |  | — |  |  | 2,352,022 |  |  | 1,057,810 |  |  | 1,729,692 |  |  | — |  |  | 2,787,502 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,271 |  |  | — |  |  | — |  |  | 4,271 |  |  | 4,237 |  |  | — |  |  | — |  |  | 4,237 |  |
| Total Financial Assets |  | $ | 1,391,567 |  |  | $ | 1,361,987 |  |  | $ | — |  |  | $ | 2,753,554 |  |  | $ | 1,283,429 |  |  | $ | 1,729,692 |  |  | $ | — |  |  | $ | 3,013,121 |  |

[0001596532-23-000016:notes:109]
______________________________________

[0001596532-23-000016:notes:110]
(1) As of December 31, 2022 and  2021, all of our certificates of deposits were domestic deposits.

[0001596532-23-000016:notes:111]
(2) The $19.1 million represents the fair value of marketable equity securities as of December 31, 2022. This amount includes $8.3 million that was reclassified from Investments on our consolidated balance sheet following the commencement of public market trading of the issuer in January 2022. This publicly-traded equity investment generated an unrealized gain of $10.7 million for the year ended December 31, 2022.  The unrealized gains and losses are included in Other income (expense), net on the Consolidated Statements of Operations. Refer to Note 3. Financial Statements Details.

[0001596532-23-000016:notes:112]
During the year ended on December 31, 2022, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-23-000016:notes:113]
Marketable debt securities

[0001596532-23-000016:notes:114]
The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities measured at fair value on a recurring basis (in thousands):

[0001596532-23-000016:notes:115]
|  |  | December 31, 2022 |  | December 31, 2021 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| Commercial paper |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 141,274 |  |  | $ | — |  |  | $ | — |  |  | $ | 141,274 |  |
| U.S. government |  | 1,007,175 |  |  | 3 |  |  | (13,223) |  |  | 993,955 |  |  | 1,060,716 |  |  | 3 |  |  | (2,909) |  |  | 1,057,810 |  |
| Corporate bonds |  | 1,125,920 |  |  | 271 |  |  | (13,057) |  |  | 1,113,134 |  |  | 1,255,149 |  |  | 105 |  |  | (3,028) |  |  | 1,252,226 |  |
| Agency securities |  | 217,893 |  |  | 83 |  |  | (2,596) |  |  | 215,380 |  |  | 291,558 |  |  | 36 |  |  | (333) |  |  | 291,261 |  |
| Total |  | $ | 2,350,988 |  |  | $ | 357 |  |  | $ | (28,876) |  |  | $ | 2,322,469 |  |  | $ | 2,748,697 |  |  | $ | 144 |  |  | $ | (6,270) |  |  | $ | 2,742,571 |  |

[0001596532-23-000016:notes:116]
For debt securities in unrealized loss positions, it is not likely that we will be required to sell such securities before recovery of their amortized cost basis nor do we have the intent to sell such securities before maturity; we invest in debt securities that have maximum maturities of two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. Given the short-term and conservative nature of our portfolio, the unrealized losses are not subject to credit risk; therefore, we did not recognize any credit losses or non-credit-related impairments related to our available-for-sale marketable debt securities for the years ended December 31, 2022, December 31, 2021 and December 31, 2020. All unrealized losses were recognized in other comprehensive income (loss). Realized losses were immaterial for the years ended December 31, 2022, December 31, 2021 and December 31, 2020.

[0001596532-23-000016:notes:117]
The following table is an analysis of our marketable debt securities in unrealized loss positions (in thousands):

[0001596532-23-000016:notes:118]
|  |  | December 31, 2022 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 245,588 |  |  | $ | (5,603) |  |  | $ | 413,112 |  |  | $ | (7,620) |  |  | $ | 658,700 |  |  | $ | (13,223) |  |
| Corporate bonds |  | 510,603 |  |  | (7,137) |  |  | 479,727 |  |  | (5,920) |  |  | 990,330 |  |  | (13,057) |  |
| Agency securities |  | 55,687 |  |  | (804) |  |  | 78,548 |  |  | (1,792) |  |  | 134,235 |  |  | (2,596) |  |
| Total |  | $ | 811,878 |  |  | $ | (13,544) |  |  | $ | 971,387 |  |  | $ | (15,332) |  |  | $ | 1,783,265 |  |  | $ | (28,876) |  |

[0001596532-23-000016:notes:119]
As of December 31, 2022, we had no marketable debt securities with contractual maturities that exceed 24 months. The fair values of marketable debt securities, by remaining contractual maturities, are as follows (in thousands):

[0001596532-23-000016:notes:120]
|  |  | December 31, 2022 |
| Due in 1 year or less |  | $ | 1,664,174 |  |
| Due in 1 year through 2 years |  | 658,295 |  |
| Total marketable securities |  | $ | 2,322,469 |  |

[0001596532-23-000016:notes:121]
The weighted-average remaining duration of our marketable debt securities is approximately 0.6 years as of December 31, 2022.

[0001596532-23-000016:notes:122]
Assets measured at fair value on a non-recurring basis

[0001596532-23-000016:notes:123]
Non-Marketable Equity Securities

[0001596532-23-000016:notes:124]
We have non-marketable equity securities in privately-held companies that do not have readily-determinable fair values. These equity securities are included in Investments on the consolidated balance sheets. Their initial cost is adjusted to fair value on a non-recurring basis based on observable price changes from orderly transactions of identical or similar securities of the same issuer, or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to these securities. In addition, the valuation requires management judgment due to the absence of market price and lack of liquidity.

[0001596532-23-000016:notes:125]
We did not record any realized gains or losses for our non-marketable equity securities during the years ended December 31, 2022 and December 31, 2021. We recorded unrealized gains of $16.7 million on non-marketable equity securities based on observable price changes from orderly transactions of identical or similar securities in the year ended December 31, 2022. We recorded immaterial unrealized losses in the year ended December 31, 2022. We did not record any unrealized gains or losses on non-marketable equity securities in the year ended December 31, 2021. We evaluate our non-marketable equity securities for impairment at each reporting period via a qualitative assessment with various potential impairment indicators, including, but not limited to, an assessment of a significant adverse change in the economic environment, significant adverse changes in the general market condition of the geographies and industries in which our investees operate, and other publicly-available information that affected the value of the non-marketable equity securities.

[0001596532-23-000016:notes:126]
The following table summarizes the activity related to our non-marketable equity securities as of December 31, 2022 and December 31, 2021 (in thousands):

[0001596532-23-000016:notes:127]
|  |  | December 31, 2022 |  | December 31, 2021 |
| Cost of investments (1) |  | $ | 23,625 |  |  | $ | 14,933 |  |
| Cumulative impairment and downward adjustments |  | (888) |  |  | — |  |
| Cumulative upward adjustments (1) |  | 16,731 |  |  | 5,314 |  |
| Carrying amount of investments |  | $ | 39,468 |  |  | $ | 20,247 |  |

[0001596532-23-000016:notes:128]
(1) During the year ended December 31, 2022, $3.0 million previously included in the Cost of investments and $5.3 million previously included in the Cumulative upward adjustment, or $8.3 million in aggregate, were reclassified from Investments to Marketable securities on our consolidated balance sheet following the commencement of public market trading of the issuer. There was no such activity in the year ended December 31, 2021.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-23-000016:notes:129]
(2) The $19.1 million represents the fair value of marketable equity securities as of December 31, 2022. This amount includes $8.3 million that was reclassified from Investments on our consolidated balance sheet following the commencement of public market trading of the issuer in January 2022. This publicly-traded equity investment generated an unrealized gain of $10.7 million for the year ended December 31, 2022.  The unrealized gains and losses are included in Other income (expense), net on the Consolidated Statements of Operations. Refer to Note 3. Financial Statements Details. 
The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities measured at fair value on a recurring basis (in thousands):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-23-000016:notes:130]
Financial Statements Details
Cash, Cash Equivalents and Restricted Cash

[0001596532-23-000016:notes:131]
The reconciliation of cash, cash equivalents and restricted cash reported in the accompanying consolidated balance sheets to the total of the same such amounts in the accompanying consolidated statements of cash flows is as follows (in thousands):

[0001596532-23-000016:notes:132]
|  |  | December 31, |
|  |  | 2022 |  | 2021 |
| Cash and cash equivalents |  | $ | 671,707 |  |  | $ | 620,813 |  |
| Restricted cash included in other assets |  | 4,271 |  |  | 4,237 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 675,978 |  |  | $ | 625,050 |  |

[0001596532-23-000016:notes:133]
Accounts Receivable, net

[0001596532-23-000016:notes:134]
Accounts receivable, net consists of the following (in thousands):

[0001596532-23-000016:notes:135]
|  |  | December 31, |
|  |  | 2022 |  | 2021 |
| Accounts receivable |  | $ | 928,490 |  |  | $ | 521,597 |  |
| Allowance for doubtful accounts |  | (19) |  |  | (132) |  |
| Product sales rebate and returns reserve |  | (5,375) |  |  | (4,956) |  |
| Accounts receivable, net |  | $ | 923,096 |  |  | $ | 516,509 |  |

[0001596532-23-000016:notes:136]
Product Sales Rebate and Returns Reserve

[0001596532-23-000016:notes:137]
Activities in the product sales rebate and returns reserve consist of the following (in thousands):

[0001596532-23-000016:notes:138]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Balance at the beginning of year |  | $ | 4,956 |  |  | $ | 3,838 |  |  | $ | 5,522 |  |
| Additions charged against revenue |  | 4,060 |  |  | 7,104 |  |  | 9,454 |  |
| Consumption |  | (3,641) |  |  | (5,986) |  |  | (11,138) |  |
| Balance at the end of year |  | $ | 5,375 |  |  | $ | 4,956 |  |  | $ | 3,838 |  |

[0001596532-23-000016:notes:139]
Inventories

[0001596532-23-000016:notes:140]
Inventories consist of the following (in thousands):

[0001596532-23-000016:notes:141]
|  |  | December 31, |
|  |  | 2022 |  | 2021 |
| Raw materials |  | $ | 759,519 |  |  | $ | 316,737 |  |
| Finished goods |  | 530,187 |  |  | 333,380 |  |
| Total inventories |  | $ | 1,289,706 |  |  | $ | 650,117 |  |

[0001596532-23-000016:notes:142]
Prepaid Expenses and Other Current Assets

[0001596532-23-000016:notes:143]
Prepaid expenses and other current assets consist of the following (in thousands):

[0001596532-23-000016:notes:144]
|  |  | December 31, |
|  |  | 2022 |  | 2021 |
| Inventory deposits |  | $ | 162,047 |  |  | $ | 46,311 |  |
| Other current assets |  | 124,357 |  |  | 172,893 |  |
| Other prepaid expenses and deposits |  | 27,813 |  |  | 18,531 |  |
| Total prepaid expenses and other current assets |  | $ | 314,217 |  |  | $ | 237,735 |  |

[0001596532-23-000016:notes:145]
Property and Equipment, net

[0001596532-23-000016:notes:146]
Property and equipment, net consists of the following (in thousands):

[0001596532-23-000016:notes:147]
|  |  | December 31, |
|  |  | 2022 |  | 2021 |
| Land |  | $ | 41,500 |  |  | $ | 40,145 |  |
| Equipment and machinery |  | 122,407 |  |  | 90,915 |  |
| Computer hardware and software |  | 52,148 |  |  | 44,083 |  |
| Furniture and fixtures |  | 3,575 |  |  | 3,634 |  |
| Leasehold improvements |  | 30,102 |  |  | 30,502 |  |
| Construction-in-process |  | 2,124 |  |  | 2,378 |  |
| Property and equipment, gross |  | 251,856 |  |  | 211,657 |  |
| Less: accumulated depreciation |  | (156,847) |  |  | (133,023) |  |
| Property and equipment, net |  | $ | 95,009 |  |  | $ | 78,634 |  |

[0001596532-23-000016:notes:148]
Depreciation expense was $25.6 million, $19.5 million and $20.1 million for the years ended December 31, 2022, 2021 and 2020, respectively.

[0001596532-23-000016:notes:149]
Accrued Liabilities

[0001596532-23-000016:notes:150]
Accrued liabilities consist of the following (in thousands):

[0001596532-23-000016:notes:151]
|  |  | December 31, |
|  |  | 2022 |  | 2021 |
| Accrued compensation-related costs |  | $ | 117,053 |  |  | $ | 99,571 |  |
| Supplier Liability |  | 71,481 |  |  | 28,203 |  |
| Accrued manufacturing costs |  | 45,379 |  |  | 52,010 |  |
| Accrued product development costs |  | 27,380 |  |  | 22,188 |  |
| Accrued warranty costs |  | 15,510 |  |  | 10,414 |  |
| Other |  | 15,684 |  |  | 14,257 |  |
| Total accrued liabilities |  | $ | 292,487 |  |  | $ | 226,643 |  |

[0001596532-23-000016:notes:152]
Warranty Accrual

[0001596532-23-000016:notes:153]
The following table summarizes the activity related to our accrued liability for estimated future warranty costs (in thousands):

[0001596532-23-000016:notes:154]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |
| Warranty accrual, beginning of year |  | $ | 10,414 |  |  | $ | 9,314 |  |
| Liabilities accrued for warranties issued during the year |  | 19,437 |  |  | 12,659 |  |
| Warranty costs incurred during the year |  | (14,341) |  |  | (11,559) |  |
| Warranty accrual, end of year |  | $ | 15,510 |  |  | $ | 10,414 |  |

[0001596532-23-000016:notes:155]
Contract Assets

[0001596532-23-000016:notes:156]
The following table summarizes the beginning and ending balances of our contract assets (in thousands):

[0001596532-23-000016:notes:157]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |
| Contract assets, beginning balance |  | $ | 24,388 |  |  | $ | 16,380 |  |
| Contract assets, ending balance |  | 11,055 |  |  | 24,388 |  |

[0001596532-23-000016:notes:158]
Contract Liabilities, Deferred Revenue and Other Performance Obligations

[0001596532-23-000016:notes:159]
Contract Liabilities

[0001596532-23-000016:notes:160]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a cancellable contract. The following table summarizes the activity related to our contract liabilities (in thousands):

[0001596532-23-000016:notes:161]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |
| Contract liabilities, beginning balance |  | $ | 93,382 |  |  | $ | 85,957 |  |
| Less: Revenue recognized from beginning balance |  | (37,680) |  |  | (34,177) |  |
| Less: Beginning balance reclassified to deferred revenue |  | (2,693) |  |  | (1,945) |  |
| Add: Contract liabilities recognized |  | 50,439 |  |  | 43,547 |  |
| Contract liabilities, ending balance |  | $ | 103,448 |  |  | $ | 93,382 |  |

[0001596532-23-000016:notes:162]
As of December 31, 2022 and 2021, $45.2 million and $38.7 million, respectively, of our contract liabilities were recorded within other current liabilities with the remaining balance recorded within other long-term liabilities in the accompanying consolidated balance sheets.

[0001596532-23-000016:notes:163]
Deferred Revenue

[0001596532-23-000016:notes:164]
Deferred revenue is comprised mainly of unearned revenue related to multi-year PCS contracts, services and product deferrals related to acceptance clauses. The following table summarizes the activity related to our deferred revenue (in thousands):

[0001596532-23-000016:notes:165]
|  |  | Year Ended December 31, 2022 |
| Deferred revenue, beginning balance |  | $ | 929,312 |  |
| Less: Revenue recognized from beginning balance |  | (583,787) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 695,721 |  |
| Deferred revenue, ending balance |  | $ | 1,041,246 |  |

[0001596532-23-000016:notes:166]
Other Performance Obligations

[0001596532-23-000016:notes:167]
Other performance obligations totaling $1.1 billion include unbilled contract revenue for services and products that will be recognized in future periods. As of December 31, 2022, other performance obligations included $117.6 million of unbilled multi-year PCS contract amounts that will be recognized as revenue in future periods. In addition, as of December 31, 2022 the company had entered into $961.0 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-23-000016:notes:168]
Revenue from Remaining Performance Obligations

[0001596532-23-000016:notes:169]
Revenue from remaining performance obligations of $2.2 billion represents contract liabilities, deferred revenue and other performance obligations that will be recognized in future periods. As of December 31, 2022, approximately $1.3 billion of revenue is expected to be recognized from remaining performance obligations, of which approximately 81% is expected to be recognized over the next two years and approximately 19% is expected to be recognized during the third to the fifth year. These amounts do not include the $961.0 million of binding contractual agreements related primarily to future product shipments outlined above. As of December 31, 2022, it is expected that the majority of the amounts allocated to these specific performance obligations will be recognized as revenue upon product shipment over the next two years; however, given the current uncertain supply chain environment, we may experience manufacturing and shipment delays or cancellations related to these performance obligations, which could impact revenue recognition.

[0001596532-23-000016:notes:170]
Other Income, Net

[0001596532-23-000016:notes:171]
Other income, net consists of the following (in thousands):

[0001596532-23-000016:notes:172]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Other income (expense), net: |  |  |  |  |  |  |
| Interest income |  | $ | 27,556 |  |  | $ | 7,215 |  |  | $ | 27,139 |  |
| Unrealized gain on equity investments |  | 27,479 |  |  | — |  |  | 4,164 |  |
| Other income (expense) |  | (345) |  |  | (1,075) |  |  | 7,876 |  |
| Total other income, net |  | $ | 54,690 |  |  | $ | 6,140 |  |  | $ | 39,179 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-23-000016:notes:173]
The following table summarizes the activity related to our contract liabilities (in thousands):


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-23-000016:notes:174]
Acquisition, Goodwill and Acquisition-Related Intangible Assets 
Acquisitions

[0001596532-23-000016:notes:175]
During the year ended December 31, 2022, we completed two acquisitions of private companies for total consideration of $158.9 million, including $4.0 million in common stock and the remainder in cash. The purchase prices included $62.3 million of intangible assets, $77.5 million of goodwill and $19.1 million of net tangible assets acquired. We also incurred certain acquisition-related expenses of $4.7 million, which primarily consisted of retention bonuses to continuing employees as well as professional and consulting fees.

[0001596532-23-000016:notes:176]
The intangible assets are amortized on a straight-line basis over their estimated useful lives, as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. The following table sets forth the components of identifiable intangible assets acquired and their estimated useful lives as of the date of acquisition (in thousands, except years):

[0001596532-23-000016:notes:177]
|  |  | Acquisition Date Fair Value |  | Weighted Average Estimated Useful Life (in years) |
| Developed technology |  | $ | 30,200 |  |  | 5.7 |
| Customer relationships |  | 28,700 |  |  | 7.0 |
| Trade name |  | 3,400 |  |  | 3.0 |
| Total intangible assets acquired |  | $ | 62,300 |  |  |  |

[0001596532-23-000016:notes:178]
Goodwill

[0001596532-23-000016:notes:179]
The changes in the carrying values of goodwill for the years ended December 31, 2022 and 2021 are as follows (in thousands):

[0001596532-23-000016:notes:180]
|  |  | Amount |
| Balance at December 31, 2020 |  | $ | 189,696 |  |
| Escrow receipts from past acquisitions |  | (1,299) |  |
| Balance at December 31, 2021 |  | 188,397 |  |
| Additions related to current year acquisitions |  | 85,048 |  |
| Measurement-period adjustments |  | (7,521) |  |
| Balance at December 31, 2022 |  | $ | 265,924 |  |

[0001596532-23-000016:notes:181]
The Company performed an annual test for goodwill impairment in the fourth quarter of the fiscal years ended December 31, 2022 and 2021 and determined that goodwill was not impaired.

[0001596532-23-000016:notes:182]
Acquisition-Related Intangible Assets

[0001596532-23-000016:notes:183]
The following table presents details of our acquisition-related intangible assets as of December 31, 2022 and 2021 (in thousands, except for years):

[0001596532-23-000016:notes:184]
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life (in years) |
|  | December 31, 2021 |  | Additions |  | December 31, 2022 |  | December 31, 2021 |  | Amortization |  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2022 |  |
| Developed technology | $ | 124,730 |  |  | $ | 30,200 |  |  | $ | 154,930 |  |  | $ | (53,663) |  |  | $ | (25,373) |  |  | $ | (79,036) |  |  | $ | 71,067 |  |  | $ | 75,894 |  |  | 4.4 |
| Customer relationships | 25,920 |  |  | 28,700 |  |  | 54,620 |  |  | (7,899) |  |  | (6,198) |  |  | (14,097) |  |  | 18,021 |  |  | 40,523 |  |  | 5.7 |
| Trade name | 8,990 |  |  | 3,400 |  |  | 12,390 |  |  | (4,693) |  |  | (1,909) |  |  | (6,602) |  |  | 4,297 |  |  | 5,788 |  |  | 2.6 |
| Others | 5,720 |  |  | — |  |  | 5,720 |  |  | (5,550) |  |  | (170) |  |  | (5,720) |  |  | 170 |  |  | — |  |  | 0.0 |
| Total | $ | 165,360 |  |  | $ | 62,300 |  |  | $ | 227,660 |  |  | $ | (71,805) |  |  | $ | (33,650) |  |  | $ | (105,455) |  |  | $ | 93,555 |  |  | $ | 122,205 |  |  | 4.7 |

[0001596532-23-000016:notes:185]
Amortization expense related to acquisition-related intangible assets was $33.7 million, $29.2 million and $24.1 million for the years ended December 31, 2022, 2021 and 2020, respectively.

[0001596532-23-000016:notes:186]
As of December 31, 2022, future estimated amortization expense related to the acquired-related intangible assets is as follows (in thousands):

[0001596532-23-000016:notes:187]
| Years Ending December 31, |  | Future Amortization Expense |
| 2023 |  | $ | 33,438 |  |
| 2024 |  | 26,759 |  |
| 2025 |  | 19,642 |  |
| 2026 |  | 17,260 |  |
| 2027 |  | 13,436 |  |
| Thereafter |  | 11,670 |  |
| Total |  | $ | 122,205 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-23-000016:notes:188]
Commitments and Contingencies
Operating Leases

[0001596532-23-000016:notes:189]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancellable operating lease arrangements that expire on various dates through 2028. Some of our leases include options to extend the term of such leases for a period from three months to up to 10 years and/or options to early terminate the leases. As of December 31, 2022, we did not include any such options in determining the lease terms because we were not reasonably certain that we would exercise these options.

[0001596532-23-000016:notes:190]
The following table summarizes the supplemental balance sheet information related to our operating leases (in thousands):

[0001596532-23-000016:notes:191]
|  |  | December 31, 2022 |  | December 31, 2021 |
| Right-of-use assets: |  |  |  |  |
| Operating lease right-of-use assets |  | $ | 53,390 |  |  | $ | 65,182 |  |
| Lease liabilities: |  |  |  |  |
| Operating lease liabilities, current (included in other current liabilities) |  | 19,878 |  |  | 20,298 |  |
| Operating lease liabilities, non-current |  | 43,964 |  |  | 56,527 |  |
| Total operating lease liabilities |  | $ | 63,842 |  |  | $ | 76,825 |  |

[0001596532-23-000016:notes:192]
The following table summarizes our lease costs (in thousands):

[0001596532-23-000016:notes:193]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |
| Operating lease costs: |  |  |  |  |
| Fixed lease costs |  | $ | 24,134 |  |  | $ | 23,230 |  |
| Variable lease costs |  | 8,682 |  |  | 7,781 |  |
| Total operating lease costs |  | $ | 32,816 |  |  | $ | 31,011 |  |

[0001596532-23-000016:notes:194]
The operating lease costs in the table above include costs for long-term and short-term leases. Total short-term lease costs were immaterial. Fixed lease costs include expenses recognized for base rent payments on a straight-line basis. Variable lease costs primarily include maintenance, utilities and operating expenses that are incremental to the fixed base rent payments, and are excluded from the calculation of operating lease liabilities and ROU assets. For the years ended December 31, 2022 and 2021, cash paid for amounts associated with our operating lease liabilities were approximately $23.9 million and $22.3 million, respectively, which were classified as operating activities in the accompanying consolidated statements of cash flows.

[0001596532-23-000016:notes:195]
Maturities of operating lease liabilities as of December 31, 2022 are presented in the table below (in thousands):

[0001596532-23-000016:notes:196]
| Years ending December 31, |  | Amount |
| 2023 |  | $ | 22,541 |  |
| 2024 |  | 14,760 |  |
| 2025 |  | 11,682 |  |
| 2026 |  | 9,555 |  |
| 2027 |  | 8,101 |  |
| 2028 and thereafter |  | 4,757 |  |
| Total undiscounted operating lease payments (excluding non-lease components) |  | 71,396 |  |
| Less: imputed interest |  | (7,554) |  |
| Present value of operating lease payments as of December 31, 2022 |  | $ | 63,842 |  |

[0001596532-23-000016:notes:197]
|  |  | December 31, 2022 |  | December 31, 2021 |
| Other information: |  |  |  |  |
| Weighted-average remaining lease term — operating leases |  | 4.2 years |  | 4.6 years |
| Weighted-average discount rate — operating leases |  | 5.1% |  | 5.0% |

[0001596532-23-000016:notes:198]
Purchase Commitments

[0001596532-23-000016:notes:199]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of December 31, 2022, we had non-cancellable purchase commitments of $3.7 billion, of which $2.9 billion have confirmed receipt dates within 12 months, and $0.8 billion have confirmed receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-23-000016:notes:200]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $192.5 million and $49.1 million as of December 31, 2022 and 2021, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the consolidated balance sheets.

[0001596532-23-000016:notes:201]
Guarantees

[0001596532-23-000016:notes:202]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third-party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions, and our guarantee and indemnification arrangements have not had any material impact on our consolidated financial statements to date.

[0001596532-23-000016:notes:203]
Legal Proceedings

[0001596532-23-000016:notes:204]
WSOU Investments, LLC

[0001596532-23-000016:notes:205]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement.  On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit.

[0001596532-23-000016:notes:206]
We intend to vigorously defend against the claims brought against us by WSOU; however, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-23-000016:notes:207]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated; however, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-23-000016:notes:208]
Other matters

[0001596532-23-000016:notes:209]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. 
    We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of December 31, 2022, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-23-000016:notes:210]
Stockholders' Equity and Stock-Based Compensation
Stock Repurchase Programs

[0001596532-23-000016:notes:211]
In April 2019, our board of directors authorized a $1.0 billion stock repurchase program (the "Repurchase Program").  This authorization allowed us to repurchase shares of our common stock over three years, and we completed our repurchases under the Repurchase Program during the fourth quarter of 2021. In the fourth quarter of 2021, our board of directors authorized an additional $1.0 billion stock repurchase program (the “New Repurchase Program”). This authorization allows us to repurchase shares of our common stock and will be funded from working capital. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, 10b5-1 trading plans, or a combination of the foregoing. The New Repurchase Program commenced in fourth quarter of 2021, and expires on the three-year anniversary thereof. The New Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by us at any time without prior notice. As of December 31, 2022, the remaining authorized amount for stock repurchases under this program was approximately $256.8 million.

[0001596532-23-000016:notes:212]
A summary of the stock repurchase activities for the years ended December 31, 2022 and 2021 is as follows as adjusted to give effect to the Stock Split (in thousands, except per share amounts):

[0001596532-23-000016:notes:213]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |
| Aggregate purchase price |  | $ | 670,287 |  |  | $ | 411,645 |  |
| Shares repurchased |  | 6,461 |  |  | 4,537 |  |
| Average price paid per share |  | $ | 103.74 |  |  | $ | 90.73 |  |

[0001596532-23-000016:notes:214]
The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings in our consolidated statements of stockholders' equity. All shares repurchased have been retired.

[0001596532-23-000016:notes:215]
2014 Equity Incentive Plan

[0001596532-23-000016:notes:216]
In April 2014, our board of directors and stockholders approved the 2014 Equity Incentive Plan (the “2014 Plan”), effective on the first day that our common stock was publicly traded, and simultaneously terminated the 2004 and 2011 equity plans as to future grants. However, these plans will continue to govern the terms and conditions of the outstanding options previously granted thereunder.

[0001596532-23-000016:notes:217]
Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”).  The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of the outstanding shares of our common stock on the immediately preceding December 31, but not to exceed 50,000,000 shares (the “2014 Plan Evergreen Increase”), unless the board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2022, our board of directors authorized an increase of 9.2 million shares for future issuance under the 2014 Plan. As of December 31, 2022, there remained approximately 92.0 million shares available for issuance under the 2014 Plan. Furthermore, in February, 2023, our board of directors authorized an increase of 9.2 million shares for future issuance under the 2014 Plan effective January 1, 2023.

[0001596532-23-000016:notes:218]
2014 Employee Stock Purchase Plan

[0001596532-23-000016:notes:219]
In April 2014, the board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding immediately preceding December 31, but not to exceed 10,000,000 shares, unless the board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2022, our board of directors authorized an increase of 3.1 million shares for future issuance under the ESPP. As of December 31, 2022, there remained 20.6 million shares available for issuance under the ESPP. Furthermore, in February, 2023, our board of directors authorized an increase of 3.1 million shares for future issuance under the ESPP effective January 1, 2023.

[0001596532-23-000016:notes:220]
Under our ESPP, eligible employees are permitted to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the exercise date. Each offering period lasts approximately two years starting on the first trading date after February 15 and August 15 of each year, and includes purchase dates every six months on or after February 15 and August 15 of each year. Participants may purchase shares of common stock through payroll deductions up to 10% of their eligible compensation, subject to Internal Revenue Service mandated purchase limits.

[0001596532-23-000016:notes:221]
During the year ended December 31, 2022, we issued 485,303 shares at an average purchase price of $50.37 under our ESPP.

[0001596532-23-000016:notes:222]
Stock Option Activities

[0001596532-23-000016:notes:223]
The following table summarizes the option activities and related information (in thousands, except years and per share amounts):

[0001596532-23-000016:notes:224]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (In Years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2021 |  | 8,685 |  |  | $ | 12.45 |  |  | 2.8 |  | $ | 1,140,369 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (2,736) |  |  | 8.76 |  |  |  |  |  |
| Options canceled |  | (180) |  |  | 15.70 |  |  |  |  |  |
| Balance—December 31, 2022 |  | 5,769 |  |  | $ | 14.09 |  |  | 2.0 |  | $ | 618,774 |  |
| Vested and exercisable—December 31, 2022 |  | 5,276 |  |  | $ | 11.88 |  |  | 1.7 |  | $ | 577,583 |  |

[0001596532-23-000016:notes:225]
We did not grant any stock options during the years ended December 31, 2022 and 2021. The weighted-average grant-date fair value of options granted during the year ended December 31, 2020 was $46.24 per share. The aggregate intrinsic value of options exercised during the years ended December 31, 2022, 2021 and 2020 was $311.7 million, $410.9 million and $245.9 million, respectively. The total fair value of options vested for the years ended December 31, 2022, 2021 and 2020 was approximately $16.6 million, $25.3 million and $20.0 million, respectively.

[0001596532-23-000016:notes:226]
Restricted Stock Unit (RSU) Activities

[0001596532-23-000016:notes:227]
The following table summarizes the RSU activities and related information (in thousands, except per share amounts):

[0001596532-23-000016:notes:228]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |
| Unvested balance—December 31, 2021 |  | 7,821 |  |  | $ | 70.98 |  |
| RSUs and PRSUs granted |  | 3,668 |  |  | 101.35 |  |
| RSUs and PRSUs vested |  | (2,658) |  |  | 65.51 |  |
| RSUs and PRSUs forfeited/canceled |  | (471) |  |  | 78.28 |  |
| Unvested balance—December 31, 2022 |  | 8,360 |  |  | $ | 85.83 |  |

[0001596532-23-000016:notes:229]
The weighted-average grant-date fair value of RSUs granted during the years ended December 31, 2022, 2021 and 2020 was $101.35, $93.18 and $54.11 per share, respectively. The total fair value of RSUs vested for the years ended December 31, 2022, 2021 and 2020 was approximately $174.0 million, $120.4 million, and $85.4 million, respectively.

[0001596532-23-000016:notes:230]
Stock-Based Compensation Expense

[0001596532-23-000016:notes:231]
The following table summarizes the stock-based compensation expense related to our equity awards (in thousands):

[0001596532-23-000016:notes:232]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Cost of revenue |  | $ | 9,688 |  |  | $ | 7,444 |  |  | $ | 6,272 |  |
| Research and development |  | 130,897 |  |  | 99,770 |  |  | 79,913 |  |
| Sales and marketing |  | 57,571 |  |  | 46,521 |  |  | 34,944 |  |
| General and administrative |  | 32,778 |  |  | 33,140 |  |  | 15,913 |  |
| Total stock-based compensation |  | $ | 230,934 |  |  | $ | 186,875 |  |  | $ | 137,042 |  |

[0001596532-23-000016:notes:233]
Determination of Fair Value

[0001596532-23-000016:notes:234]
We record stock-based compensation awards based on fair value as of the grant date. We value RSUs at the market close price of our common stock on the grant date. For option awards and ESPP offerings, we use the Black-Scholes option pricing model to determine fair value. We recognize such costs as compensation expense generally on a straight-line basis over the requisite service period of the award.

[0001596532-23-000016:notes:235]
Stock Options

[0001596532-23-000016:notes:236]
We did not grant any stock options in the year ended December 31, 2022 and 2021. For the year ended December 31, 2020, the fair value of each stock option granted under our plans was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001596532-23-000016:notes:237]
|  |  | Year Ended December 31, |
|  |  | 2020 |
| Expected term (in years) |  | 5.0 |
| Risk-free interest rate |  | 0.4 | % |
| Expected volatility |  | 43.5 | % |
| Dividend rate |  | — | % |

[0001596532-23-000016:notes:238]
ESPP

[0001596532-23-000016:notes:239]
The following table summarizes the assumptions relating to our ESPP:

[0001596532-23-000016:notes:240]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Expected term (in years) |  | 1.3 |  | 1.2 |  | 1.6 |
| Risk-free interest rate |  | 3.0 | % |  | 0.1 | % |  | 0.4 | % |
| Expected volatility |  | 43.5 | % |  | 40.2 | % |  | 45.1 | % |
| Dividend rate |  | — | % |  | — | % |  | — | % |

[0001596532-23-000016:notes:241]
As of December 31, 2022, there were $616.0 million of unrecognized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 3.3 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-23-000016:notes:242]
Net Income Per Share 
Basic net income per share is computed using the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed using the weighted-average number of shares of common stock outstanding during the period, including potential common shares assuming the dilutive effect of outstanding stock options, restricted stock units, and the employee stock purchase plan using the treasury stock method. Potential common shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share. The following table sets forth the computation of our basic and diluted net income per share attributable to common stockholders, as adjusted to give effect to the Stock Split (in thousands, except per share amounts):

[0001596532-23-000016:notes:243]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Net income |  | $ | 1,352,446 |  |  | $ | 840,854 |  |  | $ | 634,557 |  |
| Basic weighted-average shares outstanding |  | 306,473 |  |  | 306,512 |  |  | 303,936 |  |
| Add weighted-average effects of dilutive securities: |  |  |  |  |  |  |
| Stock options and RSUs |  | 9,876 |  |  | 12,464 |  |  | 13,848 |  |
| Employee stock purchase plan |  | 110 |  |  | 262 |  |  | 76 |  |
| Diluted weighted-average shares outstanding |  | 316,459 |  |  | 319,238 |  |  | 317,860 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 4.41 |  |  | $ | 2.74 |  |  | $ | 2.09 |  |
| Diluted |  | $ | 4.27 |  |  | $ | 2.63 |  |  | $ | 2.00 |  |

[0001596532-23-000016:notes:244]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share attributable to common stockholders because their effects would have been anti-dilutive for the periods presented, as adjusted to give effect to the Stock Split (in thousands):

[0001596532-23-000016:notes:245]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Stock options and RSUs |  | 302 |  |  | 298 |  |  | 1,380 |  |
| Employee stock purchase plan |  | 200 |  |  | 37 |  |  | 332 |  |
| Total |  | 502 |  |  | 335 |  |  | 1,712 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-23-000016:notes:246]
Income Taxes
The components of income before provision for income taxes are as follows (in thousands):

[0001596532-23-000016:notes:247]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Domestic |  | $ | 1,260,614 |  |  | $ | 737,620 |  |  | $ | 621,838 |  |
| Foreign |  | 321,182 |  |  | 193,259 |  |  | 117,025 |  |
| Income before income taxes |  | $ | 1,581,796 |  |  | $ | 930,879 |  |  | $ | 738,863 |  |

[0001596532-23-000016:notes:248]
The components of the provision for income taxes are as follows (in thousands):

[0001596532-23-000016:notes:249]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Current provision for income taxes: |  |  |  |  |  |  |
| Federal |  | $ | 359,158 |  |  | $ | 137,203 |  |  | $ | 78,843 |  |
| State |  | 76,321 |  |  | 38,478 |  |  | 21,135 |  |
| Foreign |  | 38,250 |  |  | 13,391 |  |  | 12,891 |  |
| Total current |  | 473,729 |  |  | 189,072 |  |  | 112,869 |  |
| Deferred tax expense (benefit): |  |  |  |  |  |  |
| Federal |  | (219,568) |  |  | (98,534) |  |  | (17,592) |  |
| State |  | (34,689) |  |  | (16,289) |  |  | (849) |  |
| Foreign |  | 9,878 |  |  | 15,776 |  |  | 9,878 |  |
| Total deferred tax expense (benefit) |  | (244,379) |  |  | (99,047) |  |  | (8,563) |  |
| Total provision for income taxes |  | $ | 229,350 |  |  | $ | 90,025 |  |  | $ | 104,306 |  |

[0001596532-23-000016:notes:250]
The reconciliation of the statutory federal income tax rate and our effective income tax rate is as follows (in percentages):

[0001596532-23-000016:notes:251]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| U.S. federal statutory income tax rate |  | 21.00 | % |  | 21.00 | % |  | 21.00 | % |
| State tax, net of federal benefit |  | 2.09 |  |  | 1.89 |  |  | 2.23 |  |
| Taxes on foreign earnings differential |  | (2.24) |  |  | (2.13) |  |  | (0.92) |  |
| Tax credits |  | (2.24) |  |  | (2.70) |  |  | (2.64) |  |
| Change in valuation allowance |  | — |  |  | 0.01 |  |  | (0.18) |  |
| Stock-based compensation |  | (4.07) |  |  | (8.32) |  |  | (5.65) |  |
| Acquisition and integration costs |  | 0.05 |  |  | 0.03 |  |  | 0.27 |  |
| Other, net |  | (0.09) |  |  | (0.11) |  |  | 0.01 |  |
| Effective tax rate |  | 14.50 | % |  | 9.67 | % |  | 14.12 | % |

[0001596532-23-000016:notes:252]
The change in our effective tax rate was largely attributable to a decrease in the proportion of tax benefits attributable to stock-based compensation versus total pre-tax income. Excess tax benefits resulting from stock awards were $93.5 million, $105.8 million and $58.7 million for the years ended December 31, 2022, 2021 and 2020, respectively.

[0001596532-23-000016:notes:253]
The tax effects of temporary differences that give rise to significant portions of deferred tax assets (liabilities) are as follows (in thousands):

[0001596532-23-000016:notes:254]
|  |  | December 31, |
|  |  | 2022 |  | 2021 |
| Deferred tax assets: |  |  |  |  |
| Intangible assets |  | $ | 355,521 |  |  | $ | 385,291 |  |
| Reserves and accruals not currently deductible |  | 63,517 |  |  | 34,648 |  |
| Deferred revenue |  | 182,594 |  |  | 146,745 |  |
| Tax credits |  | 100,284 |  |  | 85,390 |  |
| Lease financing obligation |  | 15,072 |  |  | 17,845 |  |
| Capitalized research and development expenses |  | 228,946 |  |  | 28,012 |  |
| Stock-based compensation |  | 25,480 |  |  | 19,760 |  |
| Net operating losses |  | 29,469 |  |  | 21,284 |  |
| Other |  | 8,721 |  |  | 3,430 |  |
| Gross deferred tax assets |  | 1,009,604 |  |  | 742,405 |  |
| Valuation allowance |  | (132,689) |  |  | (109,985) |  |
| Total deferred tax assets |  | 876,915 |  |  | 632,420 |  |
| Deferred tax liabilities: |  |  |  |  |
| US tax on foreign earnings |  | (286,625) |  |  | (302,746) |  |
| Right of use asset |  | (12,383) |  |  | (14,892) |  |
| Other |  | (3,037) |  |  | (1,561) |  |
| Total deferred tax liabilities |  | (302,045) |  |  | (319,199) |  |
| Net deferred tax assets |  | $ | 574,870 |  |  | $ | 313,221 |  |

[0001596532-23-000016:notes:255]
The following table presents the breakdown between non-current deferred tax assets and liabilities (in thousands):

[0001596532-23-000016:notes:256]
|  |  | December 31, |
|  |  | 2022 |  | 2021 |
| Deferred tax assets, non-current |  | $ | 574,912 |  |  | $ | 442,295 |  |
| Deferred tax liabilities, non-current |  | (42) |  |  | (129,074) |  |
| Total net deferred tax assets |  | $ | 574,870 |  |  | $ | 313,221 |  |

[0001596532-23-000016:notes:257]
Recognition of deferred tax assets is appropriate when realization of these assets is more likely than not. We believe, more likely than not, that we will have sufficient taxable income after deductions related to share-based awards to utilize our remaining deferred tax assets, with the exception of California, Canada, and U.K. deferred tax assets. In 2022, we increased our R&D tax credit carryforwards and capitalization in California and Canada, and increased our NOL carryforward in the U.K., which resulted in an increase of our valuation allowance on our deferred tax assets by $22.7 million. Therefore, we recorded a valuation allowance of $132.7 million and $110.0 million as of December 31, 2022 and 2021, respectively, against California, Canada, and U.K. deferred tax assets, since it is more likely than not that these assets will not be recognized.

[0001596532-23-000016:notes:258]
As of December 31, 2022, we had $264.5 million and $134.7 million of net operating loss carryforwards for federal and state income tax purposes, respectively, from acquisitions, including Untangle Holdings, and Pluribus Networks, which were acquired in 2022. These federal and state losses will begin to expire in 2028 and 2029, respectively. For foreign jurisdictions, we had combined foreign net operating loss carryforwards of $14.8 million, which do not expire.

[0001596532-23-000016:notes:259]
We had a federal credit of $2.8 million from acquisitions, which will begin to expire in 2037, and a California state credit of $180.7 million, which can be carried over indefinitely. For foreign jurisdictions, we had $0.6 million of Canadian scientific research and experimental development tax credit carry-forwards, which will begin to expire in 2034.

[0001596532-23-000016:notes:260]
Utilization of the net operating losses and tax credit carryforwards may be subject to limitations due to ownership change limitations provided in the Internal Revenue code and similar state or foreign provisions.

[0001596532-23-000016:notes:261]
The Tax Cuts and Jobs Act enacted on December 22, 2017 requires a Transition Tax on previously untaxed accumulated and current foreign earnings.  Correspondingly, all undistributed earnings are deemed to be taxed and distributions of the unremitted earnings do not have any significant U.S. federal income tax impact.  We have not provided for any remaining tax effect, if any, of limited outside basis differences of our foreign subsidiaries based upon plans of future reinvestment. The determination of the future tax consequences of the remittance of these earnings is not practicable.

[0001596532-23-000016:notes:262]
Uncertain Tax Positions

[0001596532-23-000016:notes:263]
We recognize uncertain tax positions only to the extent that management believes that it is more likely than not that the position will be sustained. The reconciliation of the beginning and ending amount of gross unrecognized tax benefits as of December 31, 2022, 2021 and 2020 is as follows (in thousands):

[0001596532-23-000016:notes:264]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Gross unrecognized tax benefits—beginning balance |  | $ | 114,813 |  |  | $ | 92,500 |  |  | $ | 93,806 |  |
| Increases related to tax positions taken in a prior year |  | 1,566 |  |  | 2,476 |  |  | 3,103 |  |
| Increases related to tax positions taken during current year |  | 25,355 |  |  | 21,104 |  |  | 20,274 |  |
| Decreases related to tax positions taken in a prior year |  | (3,781) |  |  | (853) |  |  | (18,029) |  |
| Decreases related to lapse of statute of limitations |  | (596) |  |  | (414) |  |  | (6,654) |  |
| Gross unrecognized tax benefits—ending balance |  | $ | 137,357 |  |  | $ | 114,813 |  |  | $ | 92,500 |  |

[0001596532-23-000016:notes:265]
As of December 31, 2022, 2021 and 2020, the total amount of gross unrecognized tax benefits was $137.4 million, $114.8 million and $92.5 million, respectively, of which $79.3 million, $60.9 million and $44.7 million would affect our effective tax rate if recognized.

[0001596532-23-000016:notes:266]
Our policy is to recognize interest and penalties accrued on any unrecognized tax benefits as a component of income tax expense. For the years ended December 31, 2022 and 2021, the net expense for interest and penalties and the recognized liability for interest and penalties were not material. As of December 31, 2022 and 2021, we recognized a liability for interest and penalties of $6.4 million and $3.6 million, respectively. 
The statute of limitations for Federal and most states remains open for 2017 and forward. Some states have net operating loss and tax credit carryforwards, and therefore remain open to examination. The majority of our foreign tax returns are open to audit under the statute of limitations of the respective foreign countries, where the subsidiaries are located. It is possible that the amount of existing gross unrecognized tax benefits may decrease within the next 12 months by up to $17.9 million as a result of statute of limitation lapses or payments to tax authorities in certain jurisdictions


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-23-000016:notes:267]
Geographical Information 
We operate as one reportable segment. The following table represents revenue based on customers' shipping addresses (in thousands):

[0001596532-23-000016:notes:268]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Americas |  | $ | 3,462,621 |  |  | $ | 2,156,183 |  |  | $ | 1,771,992 |  |
| Europe, Middle East and Africa |  | 529,800 |  |  | 486,836 |  |  | 326,729 |  |
| Asia Pacific |  | 388,889 |  |  | 305,018 |  |  | 218,791 |  |
| Total revenue |  | $ | 4,381,310 |  |  | $ | 2,948,037 |  |  | $ | 2,317,512 |  |

[0001596532-23-000016:notes:269]
Long-lived assets, excluding intercompany receivables, investments in subsidiaries, investments in privately-held companies and deferred tax assets, net by location are summarized as follows (in thousands):

[0001596532-23-000016:notes:270]
|  |  | December 31, |
|  |  | 2022 |  | 2021 |
| United States |  | $ | 71,540 |  |  | $ | 62,163 |  |
| International |  | 23,469 |  |  | 16,471 |  |
| Total |  | $ | 95,009 |  |  | $ | 78,634 |  |


## us-gaap:PostemploymentBenefitsDisclosureTextBlock

[0001596532-23-000016:notes:271]
Post-Employment Benefits We have a 401(k) Plan that covers substantially all of our employees in the U.S.  Effective January 1, 2017, we have elected to match 100% of employees' contributions up to a maximum of 3% of an employee's annual salary. Matching contributions are immediately vested. For the years ended December 31, 2022, 2021 and 2020, we contributed approximately $12.4 million, $9.8 million and $7.4 million for the matching contributions, respectively.
