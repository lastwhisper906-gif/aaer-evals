# ANET 8-K — 0001596532-23-000015 filed 2023-02-13

## item codes, every 8-K on or before 2023-02-14

- 2023-02-13 0001596532-23-000015 — 2.02, 9.01
- 2022-10-31 0001596532-22-000292 — 2.02, 9.01
- 2022-10-25 0001596532-22-000282 — 5.03, 9.01
- 2022-08-01 0001596532-22-000218 — 2.02, 9.01
- 2022-07-25 0001596532-22-000205 — 5.02
- 2022-06-03 0001596532-22-000179 — 5.07
- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2023-02-14

- none on or before 2023-02-14

## item 2.02 — earnings release, exhibit 99.1

[0001596532-23-000015:8k_2_02:1]
EX-99.1
2
ex991q422-earningsrelease.htm
EX-99.1

[0001596532-23-000015:8k_2_02:2]
Document

[0001596532-23-000015:8k_2_02:3]
Exhibit 99.1

[0001596532-23-000015:8k_2_02:4]
Arista Networks, Inc. Reports Fourth Quarter and Year End 2022 Financial Results

[0001596532-23-000015:8k_2_02:5]
SANTA CLARA, Calif.- February 13, 2023 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments, today announced financial results for its fourth quarter and the full year ended December 31, 2022.

[0001596532-23-000015:8k_2_02:6]
"Arista continues to help our customers deliver innovative network transformation platforms for data-driven cloud networking. Despite having to navigate industry wide supply chain challenges, FY22 was a year of record performance exceeding expectations in growth, revenue and profitability,” stated Jayshree Ullal, President and CEO of Arista Networks.

[0001596532-23-000015:8k_2_02:7]
Full Year Financial Results

[0001596532-23-000015:8k_2_02:8]
•Revenue of $4,381.3 million, an increase of 48.6% compared to fiscal year 2021.

[0001596532-23-000015:8k_2_02:9]
•GAAP gross margin of 61.1%, compared to GAAP gross margin of 63.8% in fiscal year 2021.

[0001596532-23-000015:8k_2_02:10]
•Non-GAAP gross margin of 61.9%, compared to non-GAAP gross margin of 64.8% in fiscal year 2021.

[0001596532-23-000015:8k_2_02:11]
•GAAP net income of $1,352.4 million, or $4.27 per diluted share, compared to GAAP net income of $840.9 million, or $2.63 per diluted share, in fiscal year 2021.

[0001596532-23-000015:8k_2_02:12]
•Non-GAAP net income of $1,448.3 million or $4.58 per diluted share, compared to non-GAAP net income of $915.0 million or $2.87 per diluted share, in fiscal year 2021.

[0001596532-23-000015:8k_2_02:13]
Fourth Quarter Financial Results

[0001596532-23-000015:8k_2_02:14]
•Revenue of $1,275.6 million, an increase of 8.4% compared to the third quarter of 2022, and an increase of 54.7% from the fourth quarter of 2021.

[0001596532-23-000015:8k_2_02:15]
•GAAP gross margin of 60.3%, compared to GAAP gross margin of 60.3% in the third quarter of 2022 and 63.4% in the fourth quarter of 2021.

[0001596532-23-000015:8k_2_02:16]
•Non-GAAP gross margin of 61.0%, compared to non-GAAP gross margin of 61.2% in the third quarter of 2022 and 64.3% in the fourth quarter of 2021.

[0001596532-23-000015:8k_2_02:17]
•GAAP net income of $427.1 million, or $1.35 per diluted share, compared to GAAP net income of $239.3 million, or $0.75 per diluted share, in the fourth quarter of 2021.

[0001596532-23-000015:8k_2_02:18]
•Non-GAAP net income of $445.1 million, or $1.41 per diluted share, compared to non-GAAP net income of $262.4 million, or $0.82 per diluted share, in the fourth quarter of 2021.

[0001596532-23-000015:8k_2_02:19]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO said, “Our outstanding fourth quarter financial results epitomize our focus on profitable revenue growth, leveraging R&D and go-to-market investments across the business."

[0001596532-23-000015:8k_2_02:20]
Fourth Quarter Company Highlights

[0001596532-23-000015:8k_2_02:21]
•Arista Delivers Continuous Integration Pipeline for Network as a Service Automation - Arista announced a comprehensive network automation solution with the Arista Continuous Integration (CI) Pipeline. Built on Arista's EOS Network Data Lake (NetDL™), the Arista CI Pipeline helps enterprise customers adopt a modern network operating model. This approach delivers an agile, data-driven change management process for the network, enabling faster, more reliable deployment with reduced operational time and expense.

[0001596532-23-000015:8k_2_02:22]
•Arista Delivers Next Generation Switching for Compute and Storage - Arista announced the expansion of its widely deployed 7050X4 Series, adding new 100G to 400G systems, providing longevity and investment

[0001596532-23-000015:8k_2_02:23]
protection for enterprise compute and storage, colocation providers (Colo) and managed services providers (MSPs). Complementing the new 7050X4 Series, Arista also announced an expansion of the 7060X5 Series with the addition of 800G, which doubles the capacity of hyperscale backbones while reducing space and power per gigabit.

[0001596532-23-000015:8k_2_02:24]
•Arista Wins Best Company for Diversity awarded by Comparably for 2022 – Arista is named amongst the Top 100 highest-rated Companies for Diversity.

[0001596532-23-000015:8k_2_02:25]
Full Year Company Highlights

[0001596532-23-000015:8k_2_02:26]
•Arista Delivers Next Generation Cloud Routing – Expanded and accelerated EOS routing validated for cloud, carrier, and enterprise solutions.

[0001596532-23-000015:8k_2_02:27]
•Arista Introduces Next Generation 7130 Series Systems for Converged Ultra Low Latency Networking – The next generation of converged ultra low latency, highly programmable systems.

[0001596532-23-000015:8k_2_02:28]
•Arista Expands EOS and CloudVision Software Platforms as a Foundation for High-Performance Media and Entertainment Networking – Provides ultra-fast switching for multicast media and entertainment workflows.

[0001596532-23-000015:8k_2_02:29]
•Arista Introduces Edge as a Service with Cognitive Unified Edge Solution – Delivers plug and play simplicity and workflows for commercial workspaces.

[0001596532-23-000015:8k_2_02:30]
•Arista Integrates Threat Detection and Response into the Cognitive Campus – AVA solution bridges network and security gap.

[0001596532-23-000015:8k_2_02:31]
•The Next Frontier in AI Networking – Arista’s data-driven network era powered by AI spines for next generation cloud networking.

[0001596532-23-000015:8k_2_02:32]
Financial Outlook

[0001596532-23-000015:8k_2_02:33]
For the first quarter of 2023, we expect:

[0001596532-23-000015:8k_2_02:34]
•Revenue between $1,275 million to $1,325 million;

[0001596532-23-000015:8k_2_02:35]
•Non-GAAP gross margin of approximately 60%; and

[0001596532-23-000015:8k_2_02:36]
•Non-GAAP operating margin of approximately 40%.

[0001596532-23-000015:8k_2_02:37]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other acquisition-related costs. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis because these exclusions can be uncertain or difficult to predict, including stock-based compensation expense which is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock. The actual amount of these exclusions will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-23-000015:8k_2_02:38]
Prepared Materials and Conference Call Information

[0001596532-23-000015:8k_2_02:39]
Arista's executives will discuss the fourth quarter and year end 2022 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-23-000015:8k_2_02:40]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-23-000015:8k_2_02:41]
Forward-Looking Statements

[0001596532-23-000015:8k_2_02:42]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the first quarter of 2023 and statements regarding the

[0001596532-23-000015:8k_2_02:43]
benefits of Arista's products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: interruptions or delays in shipments; the impact of supply shortages and manufacturing disruptions on our business including increased purchase commitments, excess inventory and extended lead times; adverse global economic and geopolitical conditions, including inflationary pressures which result in increased component costs and reduced information technology and network infrastructure spending, and the Russia/Ukraine conflict; dependence on a limited number of customers who represent a substantial portion of our revenue; the rapid evolution of the networking market; any failure to successfully pursue new products and service offerings and expand into adjacent markets; a decline in our revenue growth rate; fluctuations in our results of operations including as a result of seasonality; variability in our gross margins including as a result of changes in customer mix or product mix; intense competition; expansion of our international sales and operations; investments in or acquisitions of other businesses; fluctuations in currency exchange rates; any failure to raise any needed capital; our ability to attract new large end customers or sell products and services to existing end customers and dependence on large end customers; our ability to increase market awareness of our company and new products and services; a decline in the sales prices of our products and services; a decline in maintenance renewals by customers; product quality problems; our ability to anticipate technological shifts and develop products to meet those technological shifts; the management of the supply of our products and product components; our dependence on third-party manufacturers to build our products; our ability to protect, defend and maintain our intellectual property rights; vulnerabilities in our products and failure of our products to detect security breaches; tax, tariff, import/export restrictions or other trade barriers; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-23-000015:8k_2_02:44]
Non-GAAP Financial Measures

[0001596532-23-000015:8k_2_02:45]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margins, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangible assets, certain acquisition-related costs, unrealized gains on equity investments, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-23-000015:8k_2_02:46]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-23-000015:8k_2_02:47]
3

[0001596532-23-000015:8k_2_02:48]
About Arista Networks

[0001596532-23-000015:8k_2_02:49]
Arista Networks is an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments. Arista’s award-winning platforms deliver availability, agility, automation, analytics and security through an advanced network operating stack. For more information, visit https://www.arista.com.

[0001596532-23-000015:8k_2_02:50]
ARISTA, EOS, CloudVision, NetDL and AVA are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners. Additional information and resources can be found at www.arista.com.

[0001596532-23-000015:8k_2_02:51]
Investor Contacts:

[0001596532-23-000015:8k_2_02:52]
| Arista Networks, Inc. |  |  |  |  |
| Liz Stine, 408-547-5885 |  |  |
| Director, Investor Relations |  |  |
| liz@arista.com |  |  |  |  |

[0001596532-23-000015:8k_2_02:53]
ARISTA NETWORKS, INC.

[0001596532-23-000015:8k_2_02:54]
Condensed Consolidated Statements of Operations

[0001596532-23-000015:8k_2_02:55]
(Unaudited, in thousands, except per share amounts)

[0001596532-23-000015:8k_2_02:56]
|  |  | Three Months Ended December 31, |  | Twelve Months Ended December 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,096,866 |  |  | $ | 667,955 |  |  | $ | 3,716,079 |  |  | $ | 2,377,727 |  |
| Service |  | 178,686 |  |  | 156,504 |  |  | 665,231 |  |  | 570,310 |  |
| Total revenue |  | 1,275,552 |  |  | 824,459 |  |  | 4,381,310 |  |  | 2,948,037 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 471,617 |  |  | 270,809 |  |  | 1,573,629 |  |  | 958,363 |  |
| Service |  | 35,329 |  |  | 30,936 |  |  | 131,985 |  |  | 108,895 |  |
| Total cost of revenue |  | 506,946 |  |  | 301,745 |  |  | 1,705,614 |  |  | 1,067,258 |  |
| Total gross profit |  | 768,606 |  |  | 522,714 |  |  | 2,675,696 |  |  | 1,880,779 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 190,423 |  |  | 157,879 |  |  | 728,394 |  |  | 586,752 |  |
| Sales and marketing |  | 85,443 |  |  | 74,786 |  |  | 326,955 |  |  | 286,171 |  |
| General and administrative |  | 23,821 |  |  | 24,261 |  |  | 93,241 |  |  | 83,117 |  |
| Total operating expenses |  | 299,687 |  |  | 256,926 |  |  | 1,148,590 |  |  | 956,040 |  |
| Income from operations |  | 468,919 |  |  | 265,788 |  |  | 1,527,106 |  |  | 924,739 |  |
| Other income, net |  | 16,926 |  |  | 1,500 |  |  | 54,690 |  |  | 6,140 |  |
| Income before income taxes |  | 485,845 |  |  | 267,288 |  |  | 1,581,796 |  |  | 930,879 |  |
| Provision for income taxes |  | 58,756 |  |  | 27,993 |  |  | 229,350 |  |  | 90,025 |  |
| Net income |  | $ | 427,089 |  |  | $ | 239,295 |  |  | $ | 1,352,446 |  |  | $ | 840,854 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.39 |  |  | $ | 0.78 |  |  | $ | 4.41 |  |  | $ | 2.74 |  |
| Diluted |  | $ | 1.35 |  |  | $ | 0.75 |  |  | $ | 4.27 |  |  | $ | 2.63 |  |
| Weighted-average common shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 306,162 |  |  | 307,521 |  |  | 306,473 |  |  | 306,512 |  |
| Diluted |  | 315,201 |  |  | 319,753 |  |  | 316,459 |  |  | 319,238 |  |

[0001596532-23-000015:8k_2_02:57]
5

[0001596532-23-000015:8k_2_02:58]
ARISTA NETWORKS, INC.

[0001596532-23-000015:8k_2_02:59]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-23-000015:8k_2_02:60]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-23-000015:8k_2_02:61]
|  |  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| GAAP gross profit |  | $ | 768,606 |  |  | $ | 522,714 |  |  | $ | 2,675,696 |  |  | $ | 1,880,779 |  |
| GAAP gross margin |  | 60.3 | % |  | 63.4 | % |  | 61.1 | % |  | 63.8 | % |
| Stock-based compensation expense |  | 3,075 |  |  | 2,246 |  |  | 9,688 |  |  | 7,444 |  |
| Intangible asset amortization |  | 6,821 |  |  | 5,464 |  |  | 25,374 |  |  | 21,857 |  |
| Non-GAAP gross profit |  | $ | 778,502 |  |  | $ | 530,424 |  |  | $ | 2,710,758 |  |  | $ | 1,910,080 |  |
| Non-GAAP gross margin |  | 61.0 | % |  | 64.3 | % |  | 61.9 | % |  | 64.8 | % |
| GAAP income from operations |  | $ | 468,919 |  |  | $ | 265,788 |  |  | $ | 1,527,106 |  |  | $ | 924,739 |  |
| Stock-based compensation expense |  | 64,954 |  |  | 51,243 |  |  | 230,934 |  |  | 186,875 |  |
| Intangible asset amortization |  | 9,316 |  |  | 7,159 |  |  | 33,650 |  |  | 29,235 |  |
| Acquisition-related costs(1) |  | — |  |  | — |  |  | 4,691 |  |  | — |  |
| Non-GAAP income from operations |  | $ | 543,189 |  |  | $ | 324,190 |  |  | $ | 1,796,381 |  |  | $ | 1,140,849 |  |
| Non-GAAP operating margin |  | 42.6 | % |  | 39.3 | % |  | 41.0 | % |  | 38.7 | % |
| GAAP net income |  | $ | 427,089 |  |  | $ | 239,295 |  |  | $ | 1,352,446 |  |  | $ | 840,854 |  |
| Stock-based compensation expense |  | 64,954 |  |  | 51,243 |  |  | 230,934 |  |  | 186,875 |  |
| Intangible asset amortization |  | 9,316 |  |  | 7,159 |  |  | 33,650 |  |  | 29,235 |  |
| Acquisition-related costs |  | — |  |  | — |  |  | 4,691 |  |  | — |  |
| Unrealized gain on equity investments |  | (3,358) |  |  | — |  |  | (27,479) |  |  | — |  |
| Tax benefit on stock-based awards |  | (37,177) |  |  | (30,470) |  |  | (113,502) |  |  | (115,154) |  |
| Income tax effect on non-GAAP exclusions |  | (15,677) |  |  | (4,814) |  |  | (32,482) |  |  | (26,813) |  |
| Non-GAAP net income |  | $ | 445,147 |  |  | $ | 262,413 |  |  | $ | 1,448,258 |  |  | $ | 914,997 |  |
| GAAP diluted net income per share |  | $ | 1.35 |  |  | $ | 0.75 |  |  | $ | 4.27 |  |  | $ | 2.63 |  |
| Non-GAAP adjustments to net income |  | 0.06 |  |  | 0.07 |  |  | 0.31 |  |  | 0.24 |  |
| Non-GAAP diluted net income per share |  | $ | 1.41 |  |  | $ | 0.82 |  |  | $ | 4.58 |  |  | $ | 2.87 |  |
| Weighted-average shares used in computing diluted net income per share |  | 315,201 |  |  | 319,753 |  |  | 316,459 |  |  | 319,238 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 3,075 |  |  | $ | 2,246 |  |  | $ | 9,688 |  |  | $ | 7,444 |  |
| Research and development |  | 37,174 |  |  | 27,097 |  |  | 130,897 |  |  | 99,770 |  |
| Sales and marketing |  | 15,532 |  |  | 12,388 |  |  | 57,571 |  |  | 46,521 |  |
| General and administrative |  | 9,173 |  |  | 9,512 |  |  | 32,778 |  |  | 33,140 |  |
| Total |  | $ | 64,954 |  |  | $ | 51,243 |  |  | $ | 230,934 |  |  | $ | 186,875 |  |

[0001596532-23-000015:8k_2_02:62]
___________________

[0001596532-23-000015:8k_2_02:63]
(1) Represents one-time costs associated with our acquisitions, which primarily include retention bonuses, professional and consulting fees.

[0001596532-23-000015:8k_2_02:64]
ARISTA NETWORKS, INC.

[0001596532-23-000015:8k_2_02:65]
Condensed Consolidated Balance Sheets

[0001596532-23-000015:8k_2_02:66]
(Unaudited, in thousands)

[0001596532-23-000015:8k_2_02:67]
|  |  | December 31, 2022 |  | December 31, 2021 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 671,707 |  |  | $ | 620,813 |  |
| Marketable securities |  | 2,352,022 |  |  | 2,787,502 |  |
| Accounts receivable |  | 923,096 |  |  | 516,509 |  |
| Inventories |  | 1,289,706 |  |  | 650,117 |  |
| Prepaid expenses and other current assets |  | 314,217 |  |  | 237,735 |  |
| Total current assets |  | 5,550,748 |  |  | 4,812,676 |  |
| Property and equipment, net |  | 95,009 |  |  | 78,634 |  |
| Acquisition-related intangible assets, net |  | 122,205 |  |  | 93,555 |  |
| Goodwill |  | 265,924 |  |  | 188,397 |  |
| Investments |  | 39,468 |  |  | 20,247 |  |
| Operating lease right-of-use assets |  | 53,390 |  |  | 65,182 |  |
| Deferred tax assets |  | 574,912 |  |  | 442,295 |  |
| Other assets |  | 73,754 |  |  | 33,443 |  |
| TOTAL ASSETS |  | $ | 6,775,410 |  |  | $ | 5,734,429 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 232,572 |  |  | $ | 202,636 |  |
| Accrued liabilities |  | 292,487 |  |  | 226,643 |  |
| Deferred revenue |  | 637,432 |  |  | 593,578 |  |
| Other current liabilities |  | 131,040 |  |  | 86,972 |  |
| Total current liabilities |  | 1,293,531 |  |  | 1,109,829 |  |
| Income taxes payable |  | 89,839 |  |  | 69,916 |  |
| Operating lease liabilities, non-current |  | 43,964 |  |  | 56,527 |  |
| Deferred revenue, non-current |  | 403,814 |  |  | 335,734 |  |
| Deferred tax liabilities, non-current |  | 42 |  |  | 129,074 |  |
| Other long-term liabilities |  | 58,400 |  |  | 54,749 |  |
| TOTAL LIABILITIES |  | 1,889,590 |  |  | 1,755,829 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 31 |  |  | 31 |  |
| Additional paid-in capital |  | 1,780,714 |  |  | 1,530,046 |  |
| Retained earnings |  | 3,138,983 |  |  | 2,456,823 |  |
| Accumulated other comprehensive income (loss) |  | (33,908) |  |  | (8,300) |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 4,885,820 |  |  | 3,978,600 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 6,775,410 |  |  | $ | 5,734,429 |  |

[0001596532-23-000015:8k_2_02:68]
7

[0001596532-23-000015:8k_2_02:69]
ARISTA NETWORKS, INC.

[0001596532-23-000015:8k_2_02:70]
Condensed Consolidated Statements of Cash Flows

[0001596532-23-000015:8k_2_02:71]
(Unaudited, in thousands)

[0001596532-23-000015:8k_2_02:72]
|  |  | Twelve Months Ended December 31, |
|  |  | 2022 |  | 2021 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 1,352,446 |  |  | $ | 840,854 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 62,700 |  |  | 50,334 |  |
| Noncash lease expense |  | 18,648 |  |  | 17,112 |  |
| Stock-based compensation |  | 230,934 |  |  | 186,875 |  |
| Deferred income taxes |  | (244,382) |  |  | (99,290) |  |
| Unrealized gain on equity investments |  | (27,479) |  |  | — |  |
| Amortization of investment premiums |  | 12,767 |  |  | 26,847 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (401,531) |  |  | (126,969) |  |
| Inventories |  | (638,948) |  |  | (170,449) |  |
| Prepaid expenses and other current assets |  | (85,166) |  |  | (126,002) |  |
| Other assets |  | (32,299) |  |  | (4,220) |  |
| Accounts payable |  | 31,436 |  |  | 66,681 |  |
| Accrued liabilities |  | 66,586 |  |  | 83,524 |  |
| Deferred revenue |  | 98,957 |  |  | 278,485 |  |
| Income taxes, net |  | 44,026 |  |  | (2,589) |  |
| Other liabilities |  | 4,118 |  |  | (5,337) |  |
| Net cash provided by operating activities |  | 492,813 |  |  | 1,015,856 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 1,643,824 |  |  | 1,455,465 |  |
| Purchases of marketable securities |  | (1,418,857) |  |  | (2,317,264) |  |
| Business combinations, net of cash acquired |  | (145,087) |  |  | — |  |
| Purchases of property, equipment and intangible assets |  | (44,644) |  |  | (64,736) |  |
| Escrow receipts from past business acquisitions |  | — |  |  | 1,299 |  |
| Investments and notes receivable in privately-held companies |  | (12,691) |  |  | (19,933) |  |
| Proceeds from sale of marketable securities |  | 193,782 |  |  | 19,607 |  |
| Net cash provided by (used in) investing activities |  | 216,327 |  |  | (925,562) |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 48,411 |  |  | 67,245 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (32,725) |  |  | (16,482) |  |
| Repurchase of common stock |  | (670,287) |  |  | (411,645) |  |
| Net cash used in financing activities |  | (654,601) |  |  | (360,882) |  |
| Effect of exchange rate changes |  | (3,611) |  |  | (1,816) |  |
| NET INCREASE/(DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 50,928 |  |  | (272,404) |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 625,050 |  |  | 897,454 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 675,978 |  |  | $ | 625,050 |  |
