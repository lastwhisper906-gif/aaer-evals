# ANET note change history — 0001350278-14-000011 → 0001596532-14-000005


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-07):
[0001596532-14-000005:note_history:1]
Rent expense for all operating leases amounted to $0.8 million, $2.5 million, $1.3 million and $3.0 million for the three and nine months ended September 30, 2014 and 2013, respectively.
  (was, 2014-08-08, similarity 0.9518):
[0001350278-14-000011:note_history:1]
Rent expense for all operating leases amounted to $0.7 million, $1.7 million, $0.9 million and $1.7 million for the three and six months ended June 30, 2014 and 2013, respectively.

- added (2014-11-07):
[0001596532-14-000005:note_history:2]
On July 30, 2014, we entered into an agreement to lease additional space to expand our headquarters in Santa Clara, California. The lease is expected to commence in phases on January 1, 2015 for a portion and subsequently on January 1, 2016 for the remainder and expiring on September 30, 2023. The minimum payments will be approximately $2.6 million per year.

- changed (2014-11-07):
[0001596532-14-000005:note_history:3]
Accordingly, as of September 30, 2014 and December 31, 2013, we have recorded assets of $53.4 million and $53.3 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $43.9 million and $44.0 million, respectively. As of September 30, 2014, $1.1 million and $42.8 million were recorded as short-term and long-term financing obligations, respectively. During the construction period, we continued to increase the asset and financing obligation as additional building and improvement costs were incurred until construction was completed.
  (was, 2014-08-08, similarity 0.981):
[0001350278-14-000011:note_history:3]
Accordingly, as of June 30, 2014 and December 31, 2013, we have recorded assets of $53.4 million and $53.3 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $44.1 million and $44.0 million, respectively. As of June 30, 2014, $1.0 million and $43.1 million were recorded as short-term and long-term financing obligations, respectively. During the construction period, we continued to increase the asset and financing obligation as additional building and improvement costs were incurred until construction was completed.

- changed (2014-11-07):
[0001596532-14-000005:note_history:4]
Our products are manufactured, assembled and tested by third-party contract manufacturers in Asia who procure components and assemble products on our behalf based on our forecasts. These forecasts are based on estimates of future demand for our products, historical trend analysis provided by our sales and product marketing organizations and adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to these third-party contract manufacturers and vendors that may not be cancelable. As of September 30, 2014 and December 31, 2013, our contract manufacturer liability was $0.9 million and $1.8 million for non-cancelable purchase commitments issued to our vendors.
  (was, 2014-08-08, similarity 0.9912):
[0001350278-14-000011:note_history:4]
Our products are manufactured, assembled and tested by third-party contract manufacturers in Asia who procure components and assemble products on our behalf based on our forecasts. These forecasts are based on estimates of future demand for our products, historical trend analysis provided by our sales and product marketing organizations and adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to these third-party contract manufacturers and vendors that may not be cancelable. As of June 30, 2014 and December 31, 2013, our contract manufacturer liability was $1.6 million and $1.8 million for non-cancelable purchase commitments issued to our vendors.

- added (2014-11-07):
[0001596532-14-000005:note_history:5]
We have provided restricted deposits to our third-party contract manufacturers and vendors to secure our obligations to purchase inventory. We had $2.3 million in restricted deposits as of September 30, 2014 and December 31, 2013. Restricted deposits are classified in deposits and other non-current assets in our accompanying unaudited condensed consolidated balance sheets.

- changed (2014-11-07):
[0001596532-14-000005:note_history:6]
On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have strong defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information. The Court set a trial date for April 2016.
  (was, 2014-08-08, similarity 0.9786):
[0001350278-14-000011:note_history:6]
On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have strong defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

- removed (2014-11-07):
[0001350278-14-000011:note_history:7]
We have provided restricted deposits to our third-party contract manufacturers and vendors to secure our obligations to purchase inventory. We had $2.3 million in restricted deposits as of June 30, 2014 and December 31, 2013. Restricted deposits are classified in deposits and other non-current assets in our accompanying unaudited condensed consolidated balance sheets.

- removed (2014-11-07):
[0001350278-14-000011:note_history:8]
On August 1, 2014, the Santa Clara Superior Court held a case management conference (CMC). At the CMC, the Court set a trial date for April 2016.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-11-07):
[0001596532-14-000005:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (" U.S. GAAP") and following the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by U.S. GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and nine months ended September 30, 2014, are not necessarily indicative of the results expected for the full fiscal year.
  (was, 2014-08-08, similarity 0.9737):
[0001350278-14-000011:note_history:9]
The accompanying unaudited condensed consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (" U.S. GAAP") and following the requirements of the U.S. Securities and Exchange Commission (the “SEC”) for interim reporting. As permitted under those rules, certain footnotes or other financial information that are normally required by U.S. GAAP can be condensed or omitted. In management’s opinion, the unaudited condensed consolidated financial statements have been prepared on the same basis as the audited consolidated financial statements and include all adjustments, which include only normal recurring adjustments, necessary for the fair presentation of our financial information. The results for the three and six months ended June 30, 2014, are not necessarily indicative of the results expected for the full fiscal year.

- changed (2014-11-07):
[0001596532-14-000005:note_history:10]
There have been no changes in our significant accounting policies from those that were disclosed in our audited consolidated financial statements for the year ended December 31, 2013 included in the Prospectus other than the following:
  (was, 2014-08-08, similarity 0.9189):
[0001350278-14-000011:note_history:10]
There have been no material changes in our significant accounting policies from those that were disclosed in our audited consolidated financial statements for the year ended December 31, 2013 included in the Prospectus.

- added (2014-11-07):
[0001596532-14-000005:note_history:11]
New Accounting Policy

- added (2014-11-07):
[0001596532-14-000005:note_history:12]
Investments

- added (2014-11-07):
[0001596532-14-000005:note_history:13]
We have recorded our equity investment in a privately-held company under the cost method. Initial measurement of our investment under the cost method is recorded at historical cost which represents our initial investment in the privately-held company.  We will periodically assess and evaluate our cost method investment for impairment and perform an assessment based on evaluation of overall financial performance, industry and market conditions, and other relevant events or factors deemed necessary that may affect carrying value. If we determine that a decrease in the equity investment should be recognized given impairment that is considered “other than temporary” in nature, we will write-down the carrying amount to its revised new fair value.

- added (2014-11-07):
[0001596532-14-000005:note_history:14]
We work closely with third parties to manufacture and deliver our products. As of September 30, 2014 and December 31, 2013, two suppliers provided all of our electronic manufacturing services. Our products rely on key components, including certain integrated circuit components and power supplies some of which our contract manufacturers purchase on our behalf from a limited number of suppliers, including certain sole source providers. We do not have guaranteed supply contracts with any of our component suppliers, and our suppliers could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, sales of our products could be delayed or halted entirely or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.

- added (2014-11-07):
[0001596532-14-000005:note_history:15]
Reclassifications

- added (2014-11-07):
[0001596532-14-000005:note_history:16]
As a result of a change in classification, we have reclassified our spare parts inventory from inventory to other current and non-current assets as of September 30, 2014. Spare parts inventory are used to satisfy our warranty obligations, and are not available for sale or used in the production process. Prior year balances have been adjusted to conform to this new classification for comparability purposes.

- removed (2014-11-07):
[0001350278-14-000011:note_history:17]
We work closely with third parties to manufacture and deliver our products. As of June 30, 2014 and December 31, 2013, two suppliers provided all of our electronic manufacturing services. Our products rely on key components, including certain integrated circuit components and power supplies some of which our contract manufacturers purchase on our behalf from a limited number of suppliers, including certain sole source providers. We do not have guaranteed supply contracts with any of our component suppliers, and our suppliers could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, sales of our products could be delayed or halted entirely or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2014-11-07):
[0001596532-14-000005:note_history:18]
New Accounting Policy

- added (2014-11-07):
[0001596532-14-000005:note_history:19]
Investments

- added (2014-11-07):
[0001596532-14-000005:note_history:20]
We have recorded our equity investment in a privately-held company under the cost method. Initial measurement of our investment under the cost method is recorded at historical cost which represents our initial investment in the privately-held company.  We will periodically assess and evaluate our cost method investment for impairment and perform an assessment based on evaluation of overall financial performance, industry and market conditions, and other relevant events or factors deemed necessary that may affect carrying value. If we determine that a decrease in the equity investment should be recognized given impairment that is considered “other than temporary” in nature, we will write-down the carrying amount to its revised new fair value.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-07):
[0001596532-14-000005:note_history:21]
|  |  | December 31, 2013 |
| Convertible notes payable—related party |  | $ | 25,000 |  |
| Convertible notes payable |  | 75,000 |  |
| Total |  | 100,000 |  |
| Less: Unamortized discount on notes payable |  | 1,207 |  |
| Less: Current portion |  | 98,793 |  |
| Total long-term portion of debt |  | $ | — |  |
  (was, 2014-08-08, similarity 0.8437):
[0001350278-14-000011:note_history:21]
|  | June 30, 2014 |  | December 31, 2013 |
| Convertible notes payable—related party | $ | — |  |  | $ | 25,000 |  |
| Convertible notes payable | — |  |  | 75,000 |  |
| Total | — |  |  | 100,000 |  |
| Less: Unamortized discount on notes payable | — |  |  | 1,207 |  |
| Less: Current portion | — |  |  | 98,793 |  |
| Total long-term portion of debt | $ | — |  |  | $ | — |  |

- added (2014-11-07):
[0001596532-14-000005:note_history:22]
In January 2011, we sold $55.0 million aggregate principal amount of subordinated convertible promissory notes (“Convertible Notes”) to outside investors and $25.0 million aggregate principal amount of Convertible Notes to two trusts that are related to two of our co-founders.  In June 2011, we sold an additional $20.0 million in Convertible Notes to outside investors.  The Convertible Notes were convertible into shares of our common stock upon a change of control, a qualified IPO, or immediately prior to when the notes are to be voluntarily prepaid. The interest rate on the Convertible Notes was 6.0% per annum, computed on the basis of the actual number of days elapsed and a year of 365 days. All unpaid principal and accrued interest on the Convertible Notes were due and payable on the earlier of December 31, 2014 or upon the occurrence of an event of default, defined as: (i) failure to pay principal or interest when due; (ii) breaches of covenants; (iii) breaches of representations and warranties; (iv) failure to make other payment obligations resulting in the acceleration of maturity of indebtedness in excess of $10.0 million; (v) voluntary bankruptcy; (vi) involuntary bankruptcy; or (vii) certain adverse judgments. We could have voluntarily prepaid the Convertible Notes, in whole or in part, before the maturity date by giving each investor 10 days’ prior written notice. We were also required to prepay the Convertible Notes upon a change of control unless the investor elected to convert its Convertible Note immediately prior to the closing of such change of control.

- removed (2014-11-07):
[0001350278-14-000011:note_history:23]
In January 2011, we sold $55.0 million aggregate principal amount of subordinated convertible promissory notes (“Convertible Notes”) to outside investors and $25.0 million aggregate principal amount of Convertible Notes to two trusts that are related to two of our co-founders. The Convertible Notes were convertible into shares of our common stock upon a change of control, a qualified IPO, or immediately prior to when the notes are to be voluntarily prepaid.  The proceeds received in the financing were used to repay the outstanding principal on the related party notes payable of $55.6 million and accrued interest of $25.9 million. The repayment of the related party notes payable and the issuance of the aggregate 25.0 million in Convertible Notes to the two trusts were determined to be a debt modification for accounting purposes; therefore, no gain or loss was recognized in our consolidated statements of income for the year ended December 31, 2011.

- removed (2014-11-07):
[0001350278-14-000011:note_history:24]
In conjunction with the Convertible Notes, we also issued 2.0 million shares of our common stock, which had an aggregate fair value of $3.0 million upon issuance. The aggregate net carrying value of the Convertible Notes on their issuance was $77.0 million ($80.0 million in Convertible Notes and $3.0 million in unamortized debt discount). The debt discount was amortized to interest expense over the term of the Convertible Notes under the effective interest method.

- removed (2014-11-07):
[0001350278-14-000011:note_history:25]
In June 2011, we sold an additional $20.0 million in Convertible Notes and also issued 500,000 shares of our common stock, which had an aggregate fair value of $1.2 million, to outside investors. The aggregate net carrying value of the Convertible Notes on issuance was $18.8 million ($20.0 million in Convertible Notes and $1.2 million in unamortized debt discount). The debt discount was amortized to interest expense over the term of the Convertible Notes under the effective interest method.

- removed (2014-11-07):
[0001350278-14-000011:note_history:26]
The interest rate on the Convertible Notes was 6.0% per annum, computed on the basis of the actual number of days elapsed and a year of 365 days. All unpaid principal and accrued interest on the Convertible Notes were due and payable on the earlier of December 31, 2014 or upon the occurrence of an event of default, defined as: (i) failure to pay principal or interest when due; (ii) breaches of covenants; (iii) breaches of representations and warranties; (iv) failure to make other payment obligations resulting in the acceleration of maturity of indebtedness in excess of $10.0 million; (v) voluntary bankruptcy; (vi) involuntary bankruptcy; or (vii) certain adverse judgments. We could have voluntarily prepaid the Convertible Notes, in whole or in part, before the maturity date by giving each investor 10 days’ prior written notice. We were also required to prepay the Convertible Notes upon a change of control unless the investor elected to convert its Convertible Note immediately prior to the closing of such change of control.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-07):
[0001596532-14-000005:note_history:27]
|  |  | December 31, 2013 |
| Convertible notes payable—related party |  | $ | 25,000 |  |
| Convertible notes payable |  | 75,000 |  |
| Total |  | 100,000 |  |
| Less: Unamortized discount on notes payable |  | 1,207 |  |
| Less: Current portion |  | 98,793 |  |
| Total long-term portion of debt |  | $ | — |  |
  (was, 2014-08-08, similarity 0.8437):
[0001350278-14-000011:note_history:27]
|  | June 30, 2014 |  | December 31, 2013 |
| Convertible notes payable—related party | $ | — |  |  | $ | 25,000 |  |
| Convertible notes payable | — |  |  | 75,000 |  |
| Total | — |  |  | 100,000 |  |
| Less: Unamortized discount on notes payable | — |  |  | 1,207 |  |
| Less: Current portion | — |  |  | 98,793 |  |
| Total long-term portion of debt | $ | — |  |  | $ | — |  |
