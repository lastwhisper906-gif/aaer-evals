# ANET 8-K — 0001596532-15-000002 filed 2015-02-19

## item codes, every 8-K on or before 2015-03-12

- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2015-03-12

- none on or before 2015-03-12

## item 2.02 — earnings release, exhibit 99.1

[0001596532-15-000002:8k_2_02:1]
EX-99.1
2
ex991q42014.htm
EXHIBIT 99.1

[0001596532-15-000002:8k_2_02:2]
EX. 99.1 Q42014

[0001596532-15-000002:8k_2_02:3]
Exhibit 99.1

[0001596532-15-000002:8k_2_02:4]
Arista Networks Reports Fourth Quarter and Full Year 2014 Financial Results

[0001596532-15-000002:8k_2_02:5]
Cloud Networking Adoption Drives Record 2014 Revenue, non-GAAP Net Income and Earnings per Diluted Share

[0001596532-15-000002:8k_2_02:6]
SANTA CLARA, Calif., February 19, 2015 - Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large data center and computing environments, today announced financial results for its fourth quarter and year ended December 31, 2014.

[0001596532-15-000002:8k_2_02:7]
Fourth Quarter Financial Highlights

[0001596532-15-000002:8k_2_02:8]
| • | Revenue of $173.5 million, an increase of 51.2% compared to the fourth quarter of 2013, and an increase of 11.6% from the third quarter of 2014. |

[0001596532-15-000002:8k_2_02:9]
| • | GAAP gross margin of 67.1%, compared to GAAP gross margin of 67.5% in the fourth quarter of 2013 and 64.9% in the third quarter of 2014. |

[0001596532-15-000002:8k_2_02:10]
| • | GAAP net income of $31.0 million, or $0.43 per diluted share, compared to GAAP net income of $13.7 million, or $0.23 per diluted share, in the fourth quarter of 2013. |

[0001596532-15-000002:8k_2_02:11]
| • | Non-GAAP net income of $37.3 million or $0.53 per diluted share, compared to non-GAAP net income of $17.5 million, or $0.27 per diluted share, in the fourth quarter of 2013. |

[0001596532-15-000002:8k_2_02:12]
| • | Operating cash flow of $15.8 million, compared to $6.0 million of operating cash used in the fourth quarter of 2013. |

[0001596532-15-000002:8k_2_02:13]
“We are pleased with our annual revenue growth in 2014 of 61.7% over 2013, with broad customer momentum across our key verticals,” stated Jayshree Ullal, Arista President and CEO. “Our pioneering innovations in EOS+, in combination with our flagship 7000 series spine and spline models have made cloud networking transition a reality.”

[0001596532-15-000002:8k_2_02:14]
Full Year Financial Highlights

[0001596532-15-000002:8k_2_02:15]
| • | Revenue of $584.1 million, an increase of 61.7% compared to fiscal year 2013. |

[0001596532-15-000002:8k_2_02:16]
| • | GAAP gross margin of 67.1%, compared to GAAP gross margin of 66.0% in fiscal year 2013. |

[0001596532-15-000002:8k_2_02:17]
| • | GAAP net income of $86.9 million, or $1.29 per diluted share, compared to GAAP net income of $42.5 million, or $0.72 per diluted share, in fiscal year 2013. |

[0001596532-15-000002:8k_2_02:18]
| • | Non-GAAP net income of $105.5 million or $1.54 per diluted share, compared to non-GAAP net income of $52.6 million, or $0.84 per diluted share, in fiscal year 2013. |

[0001596532-15-000002:8k_2_02:19]
| • | Operating cash flow of $114.5 million, compared to $34.6 million in fiscal year 2013. |

[0001596532-15-000002:8k_2_02:20]
Commenting on the company's financial results, Kelyn Brannon, CFO of Arista Networks, said, "We executed strongly on our business model throughout 2014 and achieved impressive financial results. The fourth quarter capped off a year of record revenue, EPS and operating cash flow, while we also increased non-GAAP operating margin to 26% for the year.”

[0001596532-15-000002:8k_2_02:21]
Financial Outlook

[0001596532-15-000002:8k_2_02:22]
For the first quarter of 2015, we expect:

[0001596532-15-000002:8k_2_02:23]
| • | Revenue between $164 and $172 million. |

[0001596532-15-000002:8k_2_02:24]
| • | Non-GAAP gross margin in the range of 63% to 66% and |

[0001596532-15-000002:8k_2_02:25]
| • | Non-GAAP operating margin in the range of 22% to 25%. |

[0001596532-15-000002:8k_2_02:26]
Guidance for non-GAAP financial measures excludes legal expenses associated with the OptumSoft and Cisco litigation, stock-based compensation and other non-recurring expenses. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis.

[0001596532-15-000002:8k_2_02:27]
Prepared Materials and Conference Call Information

[0001596532-15-000002:8k_2_02:28]
Arista executives will discuss fourth quarter 2014 financial results on a conference call at 1:30 p.m. Pacific time today. The conference call can be heard via webcast on our investor relations website: investors.arista.com, or by dialing 1-877-201-0168 in the United States or 1-647-788-4901 from international locations. The Conference ID is 78056197.

[0001596532-15-000002:8k_2_02:29]
Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s Investor Relations website.

[0001596532-15-000002:8k_2_02:30]
Forward-Looking Statements

[0001596532-15-000002:8k_2_02:31]
This press release contains “forward-looking statements” regarding our performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP operating margin for the first quarter of FY 2015. Forward-looking statements are subject to a number of uncertainties and risks that could cause actual results to differ materially from those anticipated in the forward-looking statements including: Arista Networks’ limited operating history; risks associated with Arista Networks’ rapid growth; Arista Networks’ customer concentration; requests for more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; changes in customer order patterns or customer mix; increased competition in our products and service markets, including the data center market; dependence on the introduction and market acceptance of new product offerings and standards; rapid technological and market change; the dispute with Cisco Systems, Inc. and OptumSoft, Inc.; the evolution of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; and general market, political, economic and business conditions. Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s Annual Report on Form 10-K that will be filed with the SEC for the year ended December 31, 2014, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at http://investors.arista.com and on the SEC’s website at www.sec.gov. All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-15-000002:8k_2_02:32]
Non-GAAP Financial Measures

[0001596532-15-000002:8k_2_02:33]
The company reports non-GAAP results for gross margins, net income and net income per share in addition to, and not as a substitute for, financial measures calculated in accordance with GAAP. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that the use of these non-GAAP financial measures is useful to investors as an additional tool to evaluate ongoing operating results and trends.

[0001596532-15-000002:8k_2_02:34]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP financial measures, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. A reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-15-000002:8k_2_02:35]
Arista Networks defines non-GAAP gross margins as total gross profit, excluding stock-based compensation expenses, divided by total revenue. Arista Networks defines non-GAAP net income as net income, excluding stock based compensation expense, realized gain on note receivable, and the related income tax effect of these exclusions. Arista Networks defines non-GAAP net income per share as non-GAAP net income divided by the diluted weighted average shares outstanding on a pro forma basis. In order to evaluate per share information on a comparative basis, the company believes it is meaningful to provide a non-GAAP financial measure that gives pro forma effect to the conversion of the preferred shares and notes payable into common shares and the issuance of common shares in connection with the company’s initial public offering as if each happened at the beginning of each period presented.

[0001596532-15-000002:8k_2_02:36]
About Arista Networks

[0001596532-15-000002:8k_2_02:37]
Arista Networks was founded to deliver software-driven cloud networking solutions for large data center and computing environments. Arista’s award-winning 10/40/100 GbE switches redefine scalability, robustness, and price-performance, with over 3,000 customers and more than three million cloud networking ports deployed worldwide. At the core of Arista’s platform is EOS, an advanced network operating system. Arista Networks products are available worldwide through distribution partners, systems integrators and resellers.

[0001596532-15-000002:8k_2_02:38]
ARISTA, EOS and Spline are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-15-000002:8k_2_02:39]
Additional information and resources can be found at: http://www.arista.com.

[0001596532-15-000002:8k_2_02:40]
| Media ContactAmanda JaramilloCorporate Communications(408) 547-5798amanda@arista.com |  | Investor ContactChuck ElliottProduct and Investor Advocacy(408) 547-5549chuck@arista.com |

[0001596532-15-000002:8k_2_02:41]
ARISTA NETWORKS, INC.

[0001596532-15-000002:8k_2_02:42]
Condensed Consolidated Statements of Income

[0001596532-15-000002:8k_2_02:43]
(Unaudited in thousands, except per share amounts)

[0001596532-15-000002:8k_2_02:44]
|  | Three Months Ended December 31, |  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Revenue | $ | 173,489 |  |  | $ | 114,766 |  |  | $ | 584,106 |  |  | $ | 361,224 |  |
| Cost of revenue | 57,049 |  |  | 37,293 |  |  | 192,015 |  |  | 122,686 |  |
| Gross profit | 116,440 |  |  | 77,473 |  |  | 392,091 |  |  | 238,538 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 44,344 |  |  | 31,352 |  |  | 148,909 |  |  | 98,587 |  |
| Sales and marketing | 25,016 |  |  | 17,412 |  |  | 85,338 |  |  | 55,115 |  |
| General and administrative | 8,078 |  |  | 6,204 |  |  | 32,331 |  |  | 18,688 |  |
| Total operating expenses | 77,438 |  |  | 54,968 |  |  | 266,578 |  |  | 172,390 |  |
| Income from operations | 39,002 |  |  | 22,505 |  |  | 125,513 |  |  | 66,148 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense—related party | — |  |  | (439 | ) |  | (782 | ) |  | (1,739 | ) |
| Interest expense | (768 | ) |  | (1,360 | ) |  | (5,498 | ) |  | (5,380 | ) |
| Other income (expense), net | (151 | ) |  | (631 | ) |  | 2,275 |  |  | (754 | ) |
| Total other income (expense), net | (919 | ) |  | (2,430 | ) |  | (4,005 | ) |  | (7,873 | ) |
| Income before provision for income taxes | 38,083 |  |  | 20,075 |  |  | 121,508 |  |  | 58,275 |  |
| Provision for income taxes | 7,046 |  |  | 6,333 |  |  | 34,658 |  |  | 15,815 |  |
| Net income | $ | 31,037 |  |  | $ | 13,742 |  |  | $ | 86,850 |  |  | $ | 42,460 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 30,251 |  |  | $ | 6,970 |  |  | $ | 68,889 |  |  | $ | 20,777 |  |
| Diluted | $ | 30,328 |  |  | $ | 7,415 |  |  | $ | 70,524 |  |  | $ | 21,780 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.48 |  |  | $ | 0.24 |  |  | $ | 1.42 |  |  | $ | 0.76 |  |
| Diluted | $ | 0.43 |  |  | $ | 0.23 |  |  | $ | 1.29 |  |  | $ | 0.72 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | 63,186 |  |  | 28,487 |  |  | 48,427 |  |  | 27,320 |  |
| Diluted | 70,219 |  |  | 32,470 |  |  | 54,590 |  |  | 30,051 |  |

[0001596532-15-000002:8k_2_02:45]
ARISTA NETWORKS, INC.

[0001596532-15-000002:8k_2_02:46]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-15-000002:8k_2_02:47]
(Unaudited in thousands, except percentages and per share amounts)

[0001596532-15-000002:8k_2_02:48]
|  | Three Months Ended December 31, |  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| GAAP gross profit | $ | 116,440 |  |  | $ | 77,473 |  |  | $ | 392,091 |  |  | $ | 238,538 |  |
| GAAP gross margin | 67.1 | % |  | 67.5 | % |  | 67.1 | % |  | 66.0 | % |
| Stock-based compensation expense | 543 |  |  | 151 |  |  | 1,535 |  |  | 408 |  |
| Non-GAAP gross profit | $ | 116,983 |  |  | $ | 77,624 |  |  | $ | 393,626 |  |  | $ | 238,946 |  |
| Non-GAAP gross margin | 67.4 | % |  | 67.6 | % |  | 67.4 | % |  | 66.1 | % |
| GAAP income from operations | $ | 39,002 |  |  | $ | 22,505 |  |  | $ | 125,513 |  |  | $ | 66,148 |  |
| Stock-based compensation expense | 8,050 |  |  | 3,760 |  |  | 27,619 |  |  | 10,159 |  |
| Non-GAAP income from operations | $ | 47,052 |  |  | $ | 26,265 |  |  | $ | 153,132 |  |  | $ | 76,307 |  |
| Non-GAAP operating margin | 27.1 | % |  | 22.9 | % |  | 26.2 | % |  | 21.1 | % |
| GAAP net income | $ | 31,037 |  |  | $ | 13,742 |  |  | $ | 86,850 |  |  | $ | 42,460 |  |
| Stock-based compensation expense | 8,050 |  |  | 3,760 |  |  | 27,619 |  |  | 10,159 |  |
| Realized gain on note receivable | — |  |  | — |  |  | (4,000 | ) |  | — |  |
| Income tax effect on non-GAAP exclusions | (1,750 | ) |  | — |  |  | (4,931 | ) |  | — |  |
| Non-GAAP net income | $ | 37,337 |  |  | $ | 17,502 |  |  | $ | 105,538 |  |  | $ | 52,619 |  |
| Weighted average shares used in computing GAAP diluted income per share attributable to common stockholders | 70,219 |  |  | 32,470 |  |  | 54,590 |  |  | 30,051 |  |
| Additional weighted average dilutive shares1 | — |  |  | 32,282 |  |  | 13,797 |  |  | 32,282 |  |
| Non-GAAP weighted average diluted shares | 70,219 |  |  | 64,752 |  |  | 68,387 |  |  | 62,333 |  |
| GAAP diluted net income per share attributable to common stockholders | $ | 0.43 |  |  | $ | 0.23 |  |  | $ | 1.29 |  |  | $ | 0.72 |  |
| Net income attributable to participating securities | 0.01 |  |  | 0.19 |  |  | 0.30 |  |  | 0.69 |  |
| Non-GAAP adjustments to net income | 0.09 |  |  | 0.12 |  |  | 0.34 |  |  | 0.34 |  |
| Non-GAAP adjustments to diluted shares | — |  |  | (0.27 | ) |  | (0.39 | ) |  | (0.91 | ) |
| Non-GAAP diluted net income per share | $ | 0.53 |  |  | $ | 0.27 |  |  | $ | 1.54 |  |  | $ | 0.84 |  |
| Summary of Stock-Based Compensation Expense |  |  |  |  |  |  |  |
| Cost of revenue | $ | 543 |  |  | $ | 151 |  |  | $ | 1,535 |  |  | $ | 408 |  |
| Research and development | 4,688 |  |  | 2,015 |  |  | 14,986 |  |  | 5,464 |  |
| Sales and marketing | 1,897 |  |  | 1,126 |  |  | 7,643 |  |  | 2,985 |  |
| General and administrative | 922 |  |  | 468 |  |  | 3,455 |  |  | 1,302 |  |
| Total | $ | 8,050 |  |  | $ | 3,760 |  |  | $ | 27,619 |  |  | $ | 10,159 |  |

[0001596532-15-000002:8k_2_02:49]
______________________

[0001596532-15-000002:8k_2_02:50]
1Includes weighted average shares from the issuance of shares upon our IPO and the assumed conversion of preferred stock and notes payable at the beginning of each quarter.

[0001596532-15-000002:8k_2_02:51]
ARISTA NETWORKS, INC.

[0001596532-15-000002:8k_2_02:52]
Condensed Consolidated Balance Sheets

[0001596532-15-000002:8k_2_02:53]
(Unaudited in thousands)

[0001596532-15-000002:8k_2_02:54]
|  | December 31, 2014 |  | December 31, 2013 |
| ASSETS |  |  |  |
| CURRENT ASSETS: |  |  |  |
| Cash and cash equivalents | $ | 240,031 |  |  | $ | 113,664 |  |
| Marketable securities | 209,426 |  |  | — |  |
| Accounts receivable, net | 96,982 |  |  | 77,999 |  |
| Inventories | 80,519 |  |  | 67,094 |  |
| Deferred tax assets | 12,252 |  |  | 12,356 |  |
| Prepaid expenses and other current assets | 40,269 |  |  | 7,653 |  |
| Notes receivable | — |  |  | 4,000 |  |
| Total current assets | 679,479 |  |  | 282,766 |  |
| Property and equipment, net | 71,558 |  |  | 67,204 |  |
| Deferred tax assets | 11,510 |  |  | 4,541 |  |
| Other assets | 48,476 |  |  | 10,009 |  |
| TOTAL ASSETS | $ | 811,023 |  |  | $ | 364,520 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| CURRENT LIABILITIES: |  |  |  |
| Accounts payable | $ | 32,428 |  |  | $ | 20,111 |  |
| Accrued liabilities | 40,369 |  |  | 21,539 |  |
| Deferred revenue | 60,327 |  |  | 41,306 |  |
| Convertible notes payable, related party | — |  |  | 24,743 |  |
| Accrued interest payable, related party | — |  |  | 4,484 |  |
| Convertible notes payable | — |  |  | 74,050 |  |
| Accrued interest payable | — |  |  | 12,967 |  |
| Other current liabilities | 11,249 |  |  | 10,144 |  |
| Total current liabilities | 144,373 |  |  | 209,344 |  |
| Income taxes payable | 17,323 |  |  | 14,716 |  |
| Lease financing obligations, non-current | 42,547 |  |  | 43,152 |  |
| Other long-term liabilities | 51,122 |  |  | 19,576 |  |
| TOTAL LIABILITIES | 255,365 |  |  | 286,788 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |
| Convertible preferred stock | — |  |  | 5,992 |  |
| Common stock | 7 |  |  | 3 |  |
| Additional paid-in capital | 426,171 |  |  | 28,737 |  |
| Retained earnings | 129,814 |  |  | 42,964 |  |
| Accumulated other comprehensive income (loss) | (334) |  |  | 36 |  |
| TOTAL STOCKHOLDERS’ EQUITY | 555,658 |  |  | 77,732 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY | $ | 811,023 |  |  | $ | 364,520 |  |

[0001596532-15-000002:8k_2_02:55]
ARISTA NETWORKS, INC.

[0001596532-15-000002:8k_2_02:56]
Condensed Consolidated Statements of Cash Flows

[0001596532-15-000002:8k_2_02:57]
(Unaudited in thousands)

[0001596532-15-000002:8k_2_02:58]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |
| Net income | $ | 86,850 |  |  | $ | 42,460 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation and amortization | 10,021 |  |  | 5,044 |  |
| Stock-based compensation | 27,619 |  |  | 10,159 |  |
| Deferred income taxes | (6,774 | ) |  | (8,831 | ) |
| Provision for bad debts | 860 |  |  | 191 |  |
| Realized gain on notes receivable | (4,000 | ) |  | — |  |
| Amortization of debt discount | 527 |  |  | 1,118 |  |
| Write-off of debt discount on notes payable | 680 |  |  | — |  |
| Excess tax benefit on stock based-compensation | (17,436 | ) |  | (882 | ) |
| Other | 348 |  |  | — |  |
| Changes in operating assets and liabilities: |  |  |  |
| Accounts receivable | (19,844 | ) |  | (28,289 | ) |
| Inventories | (13,425 | ) |  | (49,179 | ) |
| Prepaid expenses and other current assets | (32,616 | ) |  | 2,981 |  |
| Other assets | (4,261 | ) |  | (305 | ) |
| Accounts payable | 14,007 |  |  | 3,865 |  |
| Accrued liabilities | 18,874 |  |  | 11,967 |  |
| Deferred revenue | 47,564 |  |  | 34,127 |  |
| Interest payable | (1,630 | ) |  | 4,501 |  |
| Interest payable—related party | 670 |  |  | 1,500 |  |
| Income taxes payable | 4,377 |  |  | 2,141 |  |
| Other liabilities | 2,105 |  |  | 2,080 |  |
| Net cash provided by operating activities | 114,516 |  |  | 34,648 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |
| Purchases of property and equipment | (13,134 | ) |  | (20,316 | ) |
| Purchases of marketable securities | (210,019 | ) |  | — |  |
| Proceeds from repayment of notes receivable | 8,000 |  |  | 1,000 |  |
| Change in restricted cash | 4,040 |  |  | — |  |
| Other investing activities | (38,249 | ) |  | (175 | ) |
| Net cash used in investing activities | (249,362 | ) |  | (19,491 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |
| Proceeds from initial public offering, net of issuance cost | 239,315 |  |  | — |  |
| Repayment on notes payable | (20,000 | ) |  | — |  |
| Principal payments of lease financing obligations | (793 | ) |  | — |  |
| Proceeds from issuance of common stock upon exercising options, net of repurchases | 25,379 |  |  | 9,004 |  |
| Excess tax benefit on stock-based compensation | 17,436 |  |  | 882 |  |
| Net cash provided by financing activities | 261,337 |  |  | 9,886 |  |
| Effect of exchange rate changes | (124 | ) |  | (34 | ) |
| NET INCREASE IN CASH AND CASH EQUIVALENTS | 126,367 |  |  | 25,009 |  |
| CASH AND CASH EQUIVALENTS—Beginning of period | 113,664 |  |  | 88,655 |  |
| CASH AND CASH EQUIVALENTS—End of period | $ | 240,031 |  |  | $ | 113,664 |  |
