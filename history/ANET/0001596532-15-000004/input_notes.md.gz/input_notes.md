# ANET notes — 0001596532-15-000004


## anet:ConcentrationRiskComponentsSupplierRiskPolicyTextBlock

[0001596532-15-000004:notes:1]
Business Concentrations

[0001596532-15-000004:notes:2]
We work closely with third parties to manufacture and deliver our products. As of December 31, 2014 and 2013, two suppliers provided all of our electronic manufacturing services. Our products rely on key components, including certain integrated circuit components and power supplies some of which our contract manufacturers purchase on our behalf from a limited number of suppliers, including certain sole source providers. We do not have guaranteed supply contracts with any of our component suppliers, and our suppliers could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, sales of our products could be delayed or halted entirely or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.


## anet:ScheduleofLeaseFinancingObligationsTableTextBlock

[0001596532-15-000004:notes:3]
As of December 31, 2014, the future minimum payments due under the lease financing obligation were as follows (in thousands):

[0001596532-15-000004:notes:4]
| Years Ending December 31, |  |
| 2015 | $ | 5,588 |  |
| 2016 | 5,754 |  |
| 2017 | 5,933 |  |
| 2018 | 6,113 |  |
| 2019 | 6,293 |  |
| Thereafter | 25,287 |  |
| Total payments | 54,968 |  |
| Less: interest and land lease expense | (34,770 | ) |
| Total payments under facility financing obligations | 20,198 |  |
| Property reverting to landlord | 23,436 |  |
| Present value of obligation | 43,634 |  |
| Less current portion | (1,087 | ) |
| Long-term portion of obligation | $ | 42,547 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001596532-15-000004:notes:5]
Basis of Presentation

[0001596532-15-000004:notes:6]
The accompanying consolidated financial statements include the accounts of Arista Networks, Inc. and our wholly owned subsidiaries. All significant intercompany accounts and transactions have been eliminated. Our consolidated financial statements  are prepared in accordance with U.S. generally accepted accounting principles (GAAP).


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001596532-15-000004:notes:7]
Cash and Cash Equivalents

[0001596532-15-000004:notes:8]
We consider all highly liquid investments with stated maturity of three months or less at the time of purchase to be cash equivalents. Cash and cash equivalents consist of cash on deposit with various financial institutions and highly liquid investments in money market funds. Interest is accrued as earned.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-15-000004:notes:9]
Commitments and Contingencies

[0001596532-15-000004:notes:10]
Operating Leases

[0001596532-15-000004:notes:11]
We lease various operating spaces in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2023. These arrangements require us to pay certain operating expenses, such as taxes, repairs, and insurance and contain renewal and escalation clauses. We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.

[0001596532-15-000004:notes:12]
As of December 31, 2014, the aggregate future minimum payments under non-cancelable operating leases consist of the following  (in thousands):

[0001596532-15-000004:notes:13]
| Years Ending December 31, |  |
| 2015 | $ | 2,583 |  |
| 2016 | 4,297 |  |
| 2017 | 5,155 |  |
| 2018 | 5,378 |  |
| 2019 | 5,369 |  |
| Thereafter | 22,407 |  |
| Total minimum future lease payments | $ | 45,189 |  |

[0001596532-15-000004:notes:14]
Rent expense for all operating leases amounted to $3.3 million, $3.6 million and $2.0 million for the years ended December 31, 2014, 2013 and 2012, respectively.

[0001596532-15-000004:notes:15]
Financing Obligation—Build-to-Suit Lease

[0001596532-15-000004:notes:16]
In August 2012, we executed a lease for a building under construction in Santa Clara, California which will serve as our new headquarters. The lease term is 120 months and commenced in August 2013.

[0001596532-15-000004:notes:17]
Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction such as our financial involvement in structural elements of asset construction, making decisions related to tenant improvement costs and purchasing insurance not reimbursable by the buyer-lessor (the Landlord), we were deemed the owner of the building (for accounting purposes only) during the construction period. We maintained continued involvement in the property after construction was completed and lack transferability of the risks and rewards of ownership, primarily due to our required maintenance of a $4.0 million letter of credit. Due to our continuing involvement in the property post construction and lack of transferability of related risks and rewards of ownership to the Landlord after construction was complete, we account for the building and related improvements as a lease financing obligation. Accordingly, as of December 31, 2014 and December 31, 2013, we have recorded assets of $53.4 million and $53.3 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $43.6 million and $44.0 million, respectively. As of December 31, 2014, $1.1 million and $42.5 million were recorded as short-term and long-term financing obligations, respectively.

[0001596532-15-000004:notes:18]
Upon completion of construction in the third quarter of 2013, we evaluated the de-recognition of the asset and liability under the sale-leaseback accounting guidance. We concluded that we have forms of continued economic involvement in the facility, and therefore did not meet with the provisions for sale-leaseback accounting. Therefore, the lease is accounted for as a financing obligation and lease payments will be attributed to (1) a reduction of the principal financing obligation; (2) imputed interest expense; and (3) land lease expense (which is considered an operating lease and a component of cost of goods sold and operating expenses) representing an imputed cost to lease the underlying land of the building. In addition, the underlying building asset is depreciated over the building’s estimated useful life of 30 years. At the conclusion of the initial lease term, we will de-recognize both the net book values of the asset and the remaining financing obligation.

[0001596532-15-000004:notes:19]
Purchase Commitments

[0001596532-15-000004:notes:20]
Our products are manufactured, assembled and tested by third-party contract manufacturers in Asia who procure components and assemble products on our behalf based on our forecasts. These forecasts are based on estimates of future demand for our products, historical trend analysis provided by our sales and product marketing organizations and adjusted for overall market conditions. In order to reduce manufacturing lead times and plan for adequate component supply, we may issue purchase orders to these third-party contract manufacturers and vendors that may not be cancelable. As of December 31, 2014 and December 31, 2013, our contract manufacturer liability was $0.3 million and $1.8 million for non-cancelable purchase commitments issued to our vendors. We have provided deposits to our third-party contract manufacturers and vendors to secure our obligations to purchase inventory. We had $2.3 million in restricted deposits as of December 31, 2014 and December 31, 2013. Deposits are classified in other assets in our accompanying consolidated balance sheets.

[0001596532-15-000004:notes:21]
Guarantees

[0001596532-15-000004:notes:22]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers the unamortized value of the product based on its estimated useful life. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for lease facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-15-000004:notes:23]
Legal Proceedings

[0001596532-15-000004:notes:24]
OptumSoft, Inc. Matters

[0001596532-15-000004:notes:25]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-15-000004:notes:26]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft copies of certain components of our software for evaluation by OptumSoft, (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches, (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers, (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us, and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dtd July 27, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders. OptumSoft has identified in confidential documents certain software components it claims to own, which are generally applicable tools and utility subroutines and not networking specific code. We cannot assure which software components OptumSoft may ultimately claim to own in the litigation or whether such claimed components are material.

[0001596532-15-000004:notes:27]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we assert our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we assert that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We ask the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also assert that, even if we are found not to own any particular components at issue, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have strong defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-15-000004:notes:28]
The Court set a trial date for Phase I of the proceedings, relating to contract interpretation and application of the contract to certain claimed source code for September 14, 2015.  The remaining issues are currently scheduled to be tried in April 2016.

[0001596532-15-000004:notes:29]
At this stage of the litigation, we do not believe a loss is probable and we are unable to estimate a possible loss or range of possible loss.

[0001596532-15-000004:notes:30]
We intend to vigorously defend against any action brought against us by OptumSoft. However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor. For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft. If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license. In addition, if OptumSoft were to bring actual litigation, it could assert additional or different claims against us, including claims that our license from OptumSoft is invalid. An adverse litigation ruling could result in a significant damages award against us and injunctive relief. In addition, if our license was ruled to have been terminated, and we were not able to negotiate a new license from OptumSoft on reasonable terms, we could be prohibited from selling products that incorporate OptumSoft intellectual property. Any such adverse ruling could materially adversely affect our business, prospects, results of operations and financial condition. Whether or not we prevail in a lawsuit, we expect that any litigation would be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-15-000004:notes:31]
Net Navigation LLC Matters

[0001596532-15-000004:notes:32]
On April 23, 2014, Net Navigation LLC sued us for alleged infringement of U.S. Patent Nos. 5,901,147; 6,434,145; and 6,625,122 in U.S. District Court for the Eastern District of Texas. On June 30, 2014, we and Net Navigation LLC settled this dispute.

[0001596532-15-000004:notes:33]
Cisco Systems, Inc. (“Cisco”) Matters

[0001596532-15-000004:notes:34]
On December 5, 2014, Cisco filed two complaints against us in District Court for the Northern District of California, which are proceeding as Case No. 4-14-cv-0543 (“’043 Case”) and Case No. 4-14-cv-0544 (“’044 Case”).  In the ’043 Case, Cisco alleges that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the 875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”).  Cisco seeks, as relief for our alleged infringement in the ’043 Case, lost profits and/or reasonable royalty damages in an unspecified amount, including treble damages, attorney’s fees, and associated costs.  Cisco also seeks injunctive relief in the ’043 Case.  On February 10, 2015, the court granted our unopposed motion to stay the ’043 Case until the proceedings before the United States International Trade Commission (“USITC”) pertaining to the same patents (as discussed below) become final.  In the ’044 Case, Cisco’s complaint alleges that we infringe U.S. Patent Nos. 7,047,526 and 7,953,886 and further alleges that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI.”  As relief for our alleged patent infringement in the ’044 Case, Cisco seeks lost profits and/or reasonable royalty damages in an unspecified amount including treble damages, attorney’s fees, and associated costs as well as injunctive relief.  As relief from our alleged copyright infringement, Cisco seeks damages in an unspecified amount in the form of alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees and associated costs.  Cisco also seeks injunctive relief against our alleged copyright infringement.  On February 13, 2015, we answered the complaint in the ’044 Case, denying the patent and copyright infringement allegations and also raising numerous affirmative defenses.  Trial has not been scheduled in either the ’043 or ’044 Cases.

[0001596532-15-000004:notes:35]
On December 19, 2014, Cisco filed two complaints against us in the USITC alleging that Arista has violated section 337 of the Tariff Act of 1930, as amended. The complaints have been instituted as ITC Inv. Nos. 337-TA-944 (“’944 Investigation”) and 337-TA-945 (“’945 Investigation).   In the ’944 Investigation, Cisco alleges that certain Arista switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.  In the ’945 Investigation, Cisco alleges that certain Arista switching products infringe the ’577, ’853, ’875, ’668, ’492, and ’211 patents.  In both the ’944 and ’945 Investigations, Cisco seeks, among other things, a limited exclusion order barring entry into the United States of accused switch products (including 7000 Series of switches) and a cease and desist order against us regarding our accused switch products.  On January 28, 2015, the Administrative Law Judge assigned to the ’944 Investigation set May 27, 2016 as the target date for completion of the ’944 Investigation.  On February 11, 2015, we responded to the notices of investigation and complaints in the ’944 and ’945 Investigations by, among other things, denying any violation of section 337 of  the Tariff Act and the patent infringement allegations, and raising numerous additional defenses.  On February 19, 2015, the Administrative Law Judge assigned to the ’945 Investigation issued a procedural schedule calling for, among other events:  issuance of an order construing the claims of the ’577, ’853, ’875, ’668, ’492, and ’211 patents tentatively on July 17, 2015; an evidentiary hearing on November 9-20, 2015; issuance of an initial determination regarding our alleged violations on April 26, 2016; and the target date for completion of the ’945 Investigation on August 26, 2016.

[0001596532-15-000004:notes:36]
At this stage of the litigation, we do not believe a loss is probable, and we are unable to estimate a possible or range of possible loss.

[0001596532-15-000004:notes:37]
We intend to vigorously defend against Cisco’s lawsuits, as summarized in the preceding paragraphs.  However, we cannot be certain that, if litigated, any claims by Cisco would be resolved in our favor.  For example, an adverse litigation ruling could result in a significant damages award against us, could further result in the above described injunctive relief (including, among other things, an order excluding our products from importation into the United States), could result in a requirement that we make substantial royalty payments to Cisco, and/or could require that we modify our products to the extent that we are found to infringe any valid claims asserted against us Cisco. Any such adverse ruling could materially adversely affect our business, prospects, results of operation and financial condition.  To the extent that we reached a negotiated settlement with Cisco, the settlement could require payment of substantial royalties.  Additionally, the existence of this lawsuit could cause concern among our customers and potential customers and could adversely affect our business and results of operations.  Whether or not we prevail in the lawsuit, we expect that the litigation will be expensive, time-consuming and a distraction to management in operating our business.

[0001596532-15-000004:notes:38]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. Based on currently available information, management does not believe that the ultimate outcome of these other unresolved matters is probable or estimable and not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001596532-15-000004:notes:39]
Comprehensive Income

[0001596532-15-000004:notes:40]
Comprehensive income  is comprised of net income and other comprehensive income. Unrealized gains and losses on available-for-sale investments and foreign currency translation adjustments are included in our other comprehensive income or loss.


## us-gaap:DebtDisclosureTextBlock

[0001596532-15-000004:notes:41]
Debt Obligations

[0001596532-15-000004:notes:42]
Our debt obligations consist of the following (in thousands):

[0001596532-15-000004:notes:43]
|  | December 31, 2013 |
| Convertible notes payable—related party | $ | 25,000 |  |
| Convertible notes payable | 75,000 |  |
| Total | 100,000 |  |
| Less: Unamortized discount on notes payable | 1,207 |  |
| Less: Current portion | 98,793 |  |
| Total long-term portion of debt | $ | — |  |

[0001596532-15-000004:notes:44]
In January 2011, we sold $55.0 million aggregate principal amount of subordinated convertible promissory notes (“Convertible Notes”) to outside investors and $25.0 million aggregate principal amount of Convertible Notes to two trusts that are related to two of our co-founders.  In June 2011, we sold an additional $20.0 million in Convertible Notes to outside investors.  The Convertible Notes were convertible into shares of our common stock upon a change of control, a qualified IPO, or immediately prior to when the notes are to be voluntarily prepaid. The interest rate on the Convertible Notes was 6.0% per annum, computed on the basis of the actual number of days elapsed and a year of 365 days. All unpaid principal and accrued interest on the Convertible Notes were due and payable on the earlier of December 31, 2014 or upon the occurrence of an event of default, defined as: (i) failure to pay principal or interest when due; (ii) breaches of covenants; (iii) breaches of representations and warranties; (iv) failure to make other payment obligations resulting in the acceleration of maturity of indebtedness in excess of $10.0 million; (v) voluntary bankruptcy; (vi) involuntary bankruptcy; or (vii) certain adverse judgments. We could have voluntarily prepaid the Convertible Notes, in whole or in part, before the maturity date by giving each investor 10 days’ prior written notice. We were also required to prepay the Convertible Notes upon a change of control unless the investor elected to convert its Convertible Note immediately prior to the closing of such change of control.

[0001596532-15-000004:notes:45]
Upon the closing of our IPO all noteholders with the exception of one noteholder converted the principal and accrued interest amount outstanding under their subordinated convertible promissory notes into shares of our common stock at the IPO price of $43.00 per share. The noteholder, who did not elect to so convert, was paid a total of $23.6 million which included principal and accrued interest less applicable withholding taxes of $1.1 million. The remainder of the noteholders converted the remaining debt balance of approximately $96.5 million including principal and accrued interest into 2.2 million shares of our common stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-15-000004:notes:46]
Stock-Based Compensation

[0001596532-15-000004:notes:47]
Total stock-based compensation expense related to options, restricted stock awards, employee stock purchases, restricted  stock units and stock purchase rights granted were charged to the department to which the associated employee reported as follow (in thousands):

[0001596532-15-000004:notes:48]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Cost of revenue | $ | 1,535 |  |  | $ | 408 |  |  | $ | 270 |  |
| Research and development 1 | 14,986 |  |  | 5,464 |  |  | 2,590 |  |
| Sales and marketing 1 | 7,643 |  |  | 2,985 |  |  | 1,078 |  |
| General and administrative | 3,455 |  |  | 1,302 |  |  | 765 |  |
| Total stock-based compensation | $ | 27,619 |  |  | $ | 10,159 |  |  | $ | 4,703 |  |

[0001596532-15-000004:notes:49]
_________________

[0001596532-15-000004:notes:50]
1Includes modification charge of $0.5 million in 2014 related to acceleration of shares upon termination for two employees.

[0001596532-15-000004:notes:51]
Equity Award Plans

[0001596532-15-000004:notes:52]
During the year ended December 31, 2004, we adopted the 2004 Equity Incentive Plan (the “2004 Plan”) for the purpose of granting stock based awards to employees, directors and consultants.  Awards granted under the 2004 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”) or Restricted Stock Awards (“RSAs”).  With the establishment of the 2011 Plan (as defined below), the 2004 Plan was terminated with respect to the grant of future awards but the 2004 Plan continues to govern awards previously issued thereunder. During the year ended December 31, 2011, we adopted the 2011 Equity Incentive Plan (the “2011 Plan”) for the purpose of granting stock based awards to employees, directors, and consultants.  Awards granted under the 2011 Plan could have been ISOs, NSOs, RSAs, Stock Appreciation Rights (“SARs”) or Restricted Stock Units (“RSUs”).  With the establishment of the 2014 Plan (as defined below), the 2011 Plan terminated with respect to the grant of future awards but the 2011 Plan continues to govern awards previously issued thereunder.

[0001596532-15-000004:notes:53]
2014 Plan

[0001596532-15-000004:notes:54]
In April 2014, the board of directors and stockholders approved the 2014 Equity Incentive Plan (the “2014 Plan”), effective on the first day that our common stock was publicly traded. A total of 6,510,000 shares of our common stock were initially reserved for issuance under the 2014 Plan. In addition, the shares reserved for issuance under our 2014 Plan will also include (a) those shares reserved but unissued under the 2011 Plan and 2004 Plan as of the effective date and (b) shares returned to our 2011 Plan and 2004 Plan as the result of expiration or termination of options (provided that the maximum number of shares that may be added to the 2014 Plan pursuant to (a) and (b) is 20,025,189 shares).  The number of shares available for grant and issuance under the 2014 Plan will be increased automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of our shares outstanding on the immediately preceding December 31, but not to exceed 12,500,000 shares, unless the board of directors, in its discretion, determines to make a smaller increase.

[0001596532-15-000004:notes:55]
2014 Employee Stock Purchase Plan

[0001596532-15-000004:notes:56]
In April 2014, the board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. A total of 651,000 shares of our common stock are initially reserved for future issuance under the ESPP. The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year commencing with 2015 by the number of shares equal to 1% of our shares outstanding immediately preceding December 31, but not to exceed 2,500,000 shares, unless the board of directors, in its discretion, determines to make a smaller increase. On February 17, 2015, the board authorized the increase to shares available for issuance under the plan of 1% of the total shares outstanding on January1, 2015.  The increase amounted to approximately 655,139 shares.

[0001596532-15-000004:notes:57]
Determination of Fair Value

[0001596532-15-000004:notes:58]
Employee Stock Plans

[0001596532-15-000004:notes:59]
For the years ended December 31, 2014, 2013 and 2012 the fair value of each stock option granted under our plans was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions and fair value per share:

[0001596532-15-000004:notes:60]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Expected term (in years) | 7.6 |  |  | 6.5 |  |  | 5.6 |  |
| Risk-free interest rate | 2.2 | % |  | 1.7 | % |  | 0.9 | % |
| Expected volatility | 47.7 | % |  | 51.0 | % |  | 51.0 | % |
| Dividend rate | — | % |  | — | % |  | — | % |

[0001596532-15-000004:notes:61]
ESPP

[0001596532-15-000004:notes:62]
There were no stock purchases under the ESPP during the year ended December 31, 2014.  The following table summarizes the assumptions relating to our ESPP:

[0001596532-15-000004:notes:63]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Expected term (in years) | 1.4 |  |  | N/A |  | N/A |
| Risk-free interest rate | 0.3 | % |  | N/A |  | N/A |
| Expected volatility | 36.3 | % |  | N/A |  | N/A |
| Dividend rate | — | % |  | N/A |  | N/A |

[0001596532-15-000004:notes:64]
As of December 31, 2014, the total unrecognized stock-based compensation expense for unvested ESPP shares, net of expected forfeitures, was $3.0 million, which is expected to be recognized over a weighted-average period of 1.6 years.

[0001596532-15-000004:notes:65]
Stock Option Activities

[0001596532-15-000004:notes:66]
The following table summarizes the option and RSA (Restricted Stock Award) activity under the 2004 Plan, 2011 Plan and 2014 Plan and related information:

[0001596532-15-000004:notes:67]
|  |  |  | Options and RSAs Outstanding |  |  |  |  |
|  | Shares Available for Grant(in thousands) |  | Number of Shares UnderlyingOutstanding Options and RSAs (in thousands) |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (Years) of Stock Options |  | Aggregate Intrinsic Value of Stock Options Outstanding (in thousands) |
| Balance—December 31, 2013 | 8,941 |  |  | 11,245 |  |  | $ | 6.82 |  |  | 8.8 |  | $ | 254,319 |  |
| Authorized | 6,510 |  |  |  |  |  |  |  |  |  |
| Options granted | (4,521 | ) |  | 4,412 |  |  | 40.88 |  |  |  |  |  |
| Options exercised | — |  |  | (1,349 | ) |  | 6.04 |  |  |  |  |  |
| Options canceled | 654 |  |  | (654 | ) |  | 12.45 |  |  |  |  |  |
| Early exercised shares repurchased1 | 28 |  |  | — |  |  | 4.05 |  |  |  |  |  |
| Balance—December 31, 2014 | 11,612 |  |  | 13,654 |  |  | $ | 17.63 |  |  | 8.3 |  | $ | 598,775 |  |
| Vested and exercisable—December 31, 2014 |  |  | 3,397 |  |  | $ | 5.36 |  |  | 7.4 |  | $ | 188,223 |  |
| Vested and expected to vest—December 31, 2014 |  |  | 12,034 |  |  | $ | 16.12 |  |  | 8.2 |  | $ | 544,919 |  |

[0001596532-15-000004:notes:68]
1Early exercised shares repurchased includes 2,000 shares that were originally granted out of our 2004 Plan and were subsequently retired.

[0001596532-15-000004:notes:69]
The weighted-average grant-date fair value of options granted during the year ended December 31, 2014 was $24.69 per share. The aggregate intrinsic value of options exercised for the year ended December 31, 2014 was $80.5 million.

[0001596532-15-000004:notes:70]
As of December 31, 2014, the total unrecognized stock-based compensation expense for unvested stock options, net of expected forfeitures, was $106.8 million, which is expected to be recognized over a weighted-average period of 4.4 years. The total fair value of options vested for the year ended December 31, 2014 was $16.5 million.

[0001596532-15-000004:notes:71]
Under the 2004 Plan and 2011 Plan, the options outstanding and vested and exercisable by exercise price at December 31, 2014 are as follows:

[0001596532-15-000004:notes:72]
|  | Options Outstanding and Exercisable |  | Options Vested and Exercisable |
| Range of Exercise Price | Number of Shares Underlying Outstanding Options (in thousands) |  | Weighted- Average Remaining Contractual Life (Years) |  | Weighted- Average Exercise Price per Share |  | Number of Shares Underlying Outstanding Options (in thousands) |  | Weighted- Average Exercise Price per Share |
| $3.33 | 2,116 |  |  | 6.8 |  | $ | 3.33 |  |  | 1,457 |  |  | $ | 3.33 |  |
| $4.16 - $4.18 | 2,272 |  |  | 7.6 |  | 4.17 |  |  | 875 |  |  | 4.17 |  |
| $4.92 - $7.76 | 1,868 |  |  | 8.0 |  | 6.30 |  |  | 618 |  |  | 5.81 |  |
| $8.77 - $10.18 | 2,624 |  |  | 8.6 |  | 9.73 |  |  | 313 |  |  | 9.50 |  |
| $22.49 -$30.67 | 2,652 |  |  | 9.1 |  | 27.58 |  |  | 127 |  |  | 22.59 |  |
| $34.12 - $68.34 | 1,888 |  |  | 9.6 |  | 50.84 |  |  | 7 |  |  | 36.38 |  |
| $75.00 - $76.80 | 224 |  |  | 9.7 |  | 75.71 |  |  | — |  |  | — |  |
| $84.00 | 10 |  |  | 9.7 |  | 84.00 |  |  | — |  |  | — |  |
|  | 13,654 |  |  | 8.3 |  | $ | 17.63 |  |  | 3,397 |  |  | $ | 5.36 |  |

[0001596532-15-000004:notes:73]
Restricted Stock Unit (RSU) Activities

[0001596532-15-000004:notes:74]
A summary of the activity under our stock plans and changes during the reporting period and a summary of information related to RSUs are presented below (in thousands, except years and per share amounts):

[0001596532-15-000004:notes:75]
|  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (in years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2013 | — |  |  | — |  |  | 0 |  | — |  |
| RSUs granted | 109 |  |  | $ | 75.55 |  |  |  |  |  |
| RSUs vested | — |  |  | — |  |  |  |  |  |
| RSUs forfeited/canceled | (1 | ) |  | 75.00 |  |  |  |  |  |
| Unvested balance—December 31, 2014 | 108 |  |  | $ | 75.56 |  |  | 2.0 |  | $ | 6,557 |  |
| RSUs expected to vest—December 31, 2014 | 94 |  |  | $ | 75.56 |  |  | 2.0 |  | $ | 5,722 |  |

[0001596532-15-000004:notes:76]
As of December 31, 2014, there was $6.5 million of unrecognized stock-based compensation expense related to unvested RSUs, net of estimated forfeitures. This amount is expected to be recognized over a weighted-average period of 3.8 years.

[0001596532-15-000004:notes:77]
Restricted Stock Award Activities

[0001596532-15-000004:notes:78]
A summary of our RSA activity and related information is as follows (in thousands, except per share amounts):

[0001596532-15-000004:notes:79]
|  | Number of RSA’s Outstanding |  | Weighted- Average Grant Date Fair Value Per Share |
| Unvested balance—December 31, 2013 | 142 |  |  | $ | 2.42 |  |
| Vested | (57 | ) |  | 2.50 |  |
| Unvested balance—December 31, 2014 | 85 |  |  | $ | 2.50 |  |

[0001596532-15-000004:notes:80]
There were no RSAs granted during the year ended December 31, 2014. As of December 31, 2014, the total unrecognized stock-based compensation expense for outstanding RSAs, net of expected forfeitures, was $0.2 million, which is expected to be recognized over a weighted-average period of 1.8 years. As of December 31, 2014, the intrinsic value of the outstanding RSAs based on the estimated fair value of $60.76 per share was $5.0 million.

[0001596532-15-000004:notes:81]
Early Exercise of Stock Options

[0001596532-15-000004:notes:82]
We have historically allowed our employees and directors to exercise options granted under the 2011 Plan and the 2004 Plan prior to vesting. Upon an "early exercise" of these options, the unvested shares acquired through the exercise become options subject to our repurchase right that lapse in accordance with the original option vesting schedule. Upon termination of employment prior to our repurchase rights lapsing in full, we have a right to repurchase the unvested shares at the original purchase price (or the then-current fair market value, if lower). The proceeds initially are recorded in other liabilities from the early exercise of stock options and are reclassified to common stock and paid-in capital as our repurchase right lapse. For the year ended December 31, 2014, we repurchased 29,803 shares of common stock at the original exercise price due to the termination of the holders of the unvested shares. As of December 31, 2014, shares held by employees and directors that were subject to repurchase were 1.4 million with an aggregate price of $4.6 million.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001596532-15-000004:notes:83]
Net Income per Share of Common Stock

[0001596532-15-000004:notes:84]
Basic and diluted net income per share attributable to common stockholders is calculated in conformity with the two-class method required for participating securities. We considered our Series A convertible preferred stock to be participating securities. Under the two-class method, net income attributable to common stockholders is determined by allocating undistributed earnings, calculated as net income less current period convertible preferred stock non-cumulative dividends, among our common stock and convertible preferred stock. In computing diluted net income attributable to common stockholders, undistributed earnings are re-allocated to reflect the potential impact of dilutive securities. Basic net income per common share is computed by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding during the period. Shares of common stock subject to repurchase resulting from the early exercise of employee stock options are considered participating securities. Diluted net income per share attributable to common stockholders is computed by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding, including potential dilutive common shares assuming the dilutive effect of outstanding stock options using the treasury stock method. For purposes of this calculation, convertible preferred stock and options to purchase shares of common stock are considered to be common stock equivalents and are excluded from the calculation of diluted net income per share of common stock if their effect is antidilutive. Convertible notes payable were excluded from the calculation of diluted net income per share since such notes were convertible to common stock at the option of the holder only upon the occurrence of a contingent event, including change in control, initial public offering or prepayment of the convertible notes.


## us-gaap:EarningsPerShareTextBlock

[0001596532-15-000004:notes:85]
Net Income Per Share Available to Common Stock

[0001596532-15-000004:notes:86]
The following table sets forth the computation of our basic and diluted net income per share available to common stock (in thousands, except per share amounts):

[0001596532-15-000004:notes:87]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Numerator: |  |  |  |  |  |
| Basic: |  |  |  |  |  |
| Net income | $ | 86,850 |  |  | $ | 42,460 |  |  | $ | 21,349 |  |
| Less: undistributed earnings allocated to participating securities | (17,961 | ) |  | (21,683 | ) |  | (11,727 | ) |
| Net income available to common stockholders, basic | $ | 68,889 |  |  | $ | 20,777 |  |  | $ | 9,622 |  |
| Diluted: |  |  |  |  |  |
| Net income attributable to common stockholders, basic | $ | 68,889 |  |  | $ | 20,777 |  |  | $ | 9,622 |  |
| Add: undistributed earnings allocated to participating securities | 1,635 |  |  | 1,003 |  |  | 40 |  |
| Net income attributable to common stockholders, diluted | $ | 70,524 |  |  | $ | 21,780 |  |  | $ | 9,662 |  |
| Denominator: |  |  |  |  |  |
| Basic: |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 48,427 |  |  | 27,320 |  |  | 24,711 |  |
| Diluted: |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic | 48,427 |  |  | 27,320 |  |  | 24,711 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |
| Stock options, RSUs and RSAs | 6,059 |  |  | 2,726 |  |  | 187 |  |
| Employee stock purchase plan | 104 |  |  | — |  |  | — |  |
| Stock purchase rights | — |  |  | 5 |  |  | 3 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted | 54,590 |  |  | 30,051 |  |  | 24,901 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |
| Basic | $ | 1.42 |  |  | $ | 0.76 |  |  | $ | 0.39 |  |
| Diluted | $ | 1.29 |  |  | $ | 0.72 |  |  | $ | 0.39 |  |

[0001596532-15-000004:notes:88]
The following outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share available to common stockholders for the periods presented because including them would have been anti-dilutive (in thousands):

[0001596532-15-000004:notes:89]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Stock options and RSUs | 1,263 |  |  | 3,599 |  |  | 169 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-15-000004:notes:90]
We measure and report our cash equivalents, restricted cash, available-for-sale marketable securities and notes receivable at fair value. The following table set forth the fair value of our financial assets by level within the fair value hierarchy (in thousands):

[0001596532-15-000004:notes:91]
|  | December 31, 2014 |
|  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 104,216 |  |  | $ | — |  |  | $ | — |  |  | $ | 104,216 |  |
| Marketable securities: |  |  |  |  |  |  |  |
| U.S. government notes | 209,426 |  |  | — |  |  | — |  |  | 209,426 |  |
| Total financial assets | $ | 313,642 |  |  | $ | — |  |  | $ | — |  |  | $ | 313,642 |  |

[0001596532-15-000004:notes:92]
|  | December 31, 2013 |
|  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 47,036 |  |  | $ | — |  |  | $ | — |  |  | $ | 47,036 |  |
| Other assets—Restricted cash: |  |  |  |  |  |  |  |
| Money market funds | 4,040 |  |  | — |  |  | — |  |  | 4,040 |  |
| Investments: |  |  |  |  |  |  |  |
| Notes receivable(1) | — |  |  | — |  |  | 4,000 |  |  | 4,000 |  |
| Total financial assets | $ | 51,076 |  |  | $ | — |  |  | $ | 4,000 |  |  | $ | 55,076 |  |

[0001596532-15-000004:notes:93]
(1) There were no changes in the fair value of the Level III assets during the year ended December 31, 2013.  In 2014, we increased the fair value of our Notes receivable by $4.0 million (See “Note 4 – Investments”). During the year ended December 31, 2014 and 2013, we had no transfers between levels of the fair value hierarchy of its assets measured at fair value. In October 2014, we received payment in full from the borrower equal to two times our outstanding principal balance as well as the unpaid accrued interest through the payment date.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-15-000004:notes:94]
Fair Value Measurements


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001596532-15-000004:notes:95]
Our assets and liabilities which require fair value measurement consist of cash and cash equivalents, restricted cash, marketable securities, accounts receivable, investments, accounts payable, accrued liabilities and convertible notes payable. Cash equivalents, restricted cash, accounts receivable, accounts payable and accrued liabilities are stated at carrying amounts as reported in the consolidated financial statements, which approximates fair value due to their short term nature. For certain investments where we have elected the fair value option, these investments are stated at fair value. The carrying amounts of our convertible notes payable approximate fair value as the stated interest rates approximate market rates currently available to us.

[0001596532-15-000004:notes:96]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value. Fair value is defined as the exchange price that would be received for an asset or an exit price that would be paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. Valuation techniques used to measure fair value must maximize the use of observable inputs and minimize the use of unobservable inputs. The authoritative guidance on fair value measurements establishes a three-tier fair value hierarchy for disclosure of the inputs used to measure fair value instruments as follows:

[0001596532-15-000004:notes:97]
Level I—Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date;

[0001596532-15-000004:notes:98]
Level II—Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities; and

[0001596532-15-000004:notes:99]
Level III—Unobservable inputs that are supported by little or no market data for the related assets or liabilities and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.

[0001596532-15-000004:notes:100]
Our financial instruments consist of Level I and Level III assets. Level I assets include highly liquid money market funds that are included in cash and cash equivalents and U.S. government notes classified as marketable securities. Level III assets that were measured on a recurring basis consisted solely of our notes receivable. We classified the notes receivable as Level III, as we used unobservable inputs to the valuation methodology that were significant to the fair value measurement, and the valuation required management judgment due to the absence of quoted market prices. We measured the fair value for certain investments based upon the probability-weighted present value of expected future investment returns, considering each of the possible future outcomes available to us. The significant unobservable inputs used in the fair value measurement of the convertible notes are the scenario probabilities and the discount rate estimated at the valuation date. Generally, increases (decreases) in the discount rate would result in a directionally opposite impact to the fair value measurement of the notes. Also, changes in the probability scenarios would have had varying impacts depending on the weighting of each specific scenario. More weighting towards a change in control or an equity financing by the investee would result in an increase in fair value of the notes receivable.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001596532-15-000004:notes:101]
Foreign Currency

[0001596532-15-000004:notes:102]
The functional currency of our foreign subsidiaries is either the U.S. dollar or their local currency.

[0001596532-15-000004:notes:103]
Transaction re-measurement-Assets and liabilities denominated in a currency other than the foreign subsidiaries’ functional currency are re-measured into the functional currency using exchange rates in effect at the end of the reporting period, with gains and losses recorded in other income (expense), net in the consolidated statements of income. We recognized $0.6 million, $0.1 million and $0.2 million in transaction losses for the years ended December 31, 2014, 2013 and 2012, respectively.

[0001596532-15-000004:notes:104]
Translation-Assets and liabilities of subsidiaries denominated in foreign functional currencies are translated into U.S. dollars at the closing exchange rate on the balance sheet date and equity related balances are translated at historical exchange rates.  Revenues, costs and expenses in foreign functional currencies are translated using average exchange rates that approximate those in effect during the period. Translation adjustments are accumulated as a separate component of accumulated other comprehensive income within stockholders’ equity (deficit).


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001596532-15-000004:notes:105]
Impairment of Long-Lived Assets and Investments

[0001596532-15-000004:notes:106]
The carrying amounts of our long-lived assets, including property and equipment and investments in privately-held companies, are periodically reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. Recoverability of these assets is measured by comparison of the carrying amount of each asset to the future undiscounted cash flows the asset is expected to generate over their remaining lives. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. No impairment of any long-lived assets was identified for any of the periods presented.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-15-000004:notes:107]
Income Taxes

[0001596532-15-000004:notes:108]
The geographical breakdown of income before provision for income taxes is as follows (in thousands):

[0001596532-15-000004:notes:109]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Domestic | $ | 120,838 |  |  | $ | 50,455 |  |  | $ | 26,837 |  |
| Foreign | 670 |  |  | 7,820 |  |  | 6,138 |  |
| Income before provision for income taxes | $ | 121,508 |  |  | $ | 58,275 |  |  | $ | 32,975 |  |

[0001596532-15-000004:notes:110]
The components of the provision for income taxes are as follows (in thousands):

[0001596532-15-000004:notes:111]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Current provision for income taxes: |  |  |  |  |  |
| Federal | $ | 36,091 |  |  | $ | 19,708 |  |  | $ | 13,037 |  |
| State | 2,716 |  |  | 4,525 |  |  | 2,003 |  |
| Foreign | 3,306 |  |  | 413 |  |  | 308 |  |
| Total current | 42,113 |  |  | 24,646 |  |  | 15,348 |  |
| Deferred tax benefit: |  |  |  |  |  |
| Federal | (7,028 | ) |  | (8,059 | ) |  | (3,525 | ) |
| State | 153 |  |  | (938 | ) |  | (342 | ) |
| Foreign | (580 | ) |  | 166 |  |  | 145 |  |
| Total deferred | (7,455 | ) |  | (8,831 | ) |  | (3,722 | ) |
| Total provision for income taxes | $ | 34,658 |  |  | $ | 15,815 |  |  | $ | 11,626 |  |

[0001596532-15-000004:notes:112]
The reconciliation of the statutory federal income tax and our effective income tax is as follows:

[0001596532-15-000004:notes:113]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| U.S. federal statutory income tax | 35.00 | % |  | 35.00 | % |  | 35.00 | % |
| State tax, net of federal benefit | 1.19 |  |  | 0.89 |  |  | 0.26 |  |
| Foreign tax differential | 0.68 |  |  | (2.61 | ) |  | (3.21 | ) |
| Tax credits | (5.26 | ) |  | (10.64 | ) |  | (0.96 | ) |
| Change in valuation allowance | 1.92 |  |  | 3.87 |  |  | 3.04 |  |
| Permanent items | (0.86 | ) |  | (2.54 | ) |  | (2.55 | ) |
| Uncertain tax positions and associated interest | 0.37 |  |  | 0.58 |  |  | 0.44 |  |
| Stock-based compensation | (4.01 | ) |  | 2.47 |  |  | 3.21 |  |
| Other, net | (0.51 | ) |  | 0.12 |  |  | 0.03 |  |
| Total provision for income taxes | 28.52 | % |  | 27.14 | % |  | 35.26 | % |

[0001596532-15-000004:notes:114]
We have operations and a taxable presence in numerous jurisdictions outside the U.S. All of these countries except one jurisdiction have a lower tax rate than the U.S. The significant jurisdictions in which we have a presence include Cayman Islands, Ireland, and the United Kingdom.

[0001596532-15-000004:notes:115]
The tax effects of temporary differences that give rise to significant portions of deferred tax assets (liabilities) are as follows (in thousands):

[0001596532-15-000004:notes:116]
|  | December 31, |
|  | 2014 |  | 2013 |
| Deferred tax assets: |  |  |  |
| Property and equipment | $ | 504 |  |  | $ | 1,020 |  |
| Stock-based compensation | 6,365 |  |  | 1,738 |  |
| Reserves and accruals not currently deductible | 16,160 |  |  | 13,351 |  |
| Net operating losses | 721 |  |  | 1,143 |  |
| Tax credits | 9,923 |  |  | 5,156 |  |
| State taxes | 342 |  |  | 514 |  |
| Other | 1,142 |  |  | 375 |  |
| Gross deferred tax assets | 35,157 |  |  | 23,297 |  |
| Valuation allowance | (8,954 | ) |  | (6,288 | ) |
| Total deferred tax assets | 26,203 |  |  | 17,009 |  |
| Deferred tax liabilities: |  |  |  |
| Property and equipment | (2,001 | ) |  | (47 | ) |
| Accrued liabilities | (558 | ) |  | (173 | ) |
| Other | (2 | ) |  | — |  |
| Total deferred tax liabilities | (2,561 | ) |  | (220 | ) |
| Net deferred tax assets | $ | 23,642 |  |  | $ | 16,789 |  |

[0001596532-15-000004:notes:117]
The following table presents the breakdown between current and non-current deferred tax assets and liabilities (in thousands):

[0001596532-15-000004:notes:118]
|  | December 31, |
|  | 2014 |  | 2013 |
| Deferred tax assets | $ | 12,252 |  |  | $ | 12,356 |  |
| Deferred tax assets, non-current | 11,510 |  |  | 4,541 |  |
| Deferred tax liabilities, non-current | (120 | ) |  | (108 | ) |
| Total net deferred tax assets | $ | 23,642 |  |  |  | $16,789 |  |

[0001596532-15-000004:notes:119]
Recognition of deferred tax assets is appropriate when realization of these assets is more likely than not. We believe that all of the deferred tax assets were realizable with the exception of California and Canada deferred tax assets. Therefore, a valuation allowance of $9.0 million and $6.3 million was recorded as of December 31, 2014 and 2013, respectively, against the California and Canadian deferred tax assets as it was not more likely than not that these assets will be recognized. The net valuation allowance increased by $2.7 million, $2.4 million and $1.0 million as of December 31, 2014, 2013 and 2012, respectively.

[0001596532-15-000004:notes:120]
As of December 31, 2014 and 2013, we had no net operating loss carryforwards for federal income tax purposes. As of December 31, 2014 and 2013, we had no state net operating loss carryforwards and approximately $13.1 million of carryforward, respectively, which has been fully utilized.  As of December 31, 2014 and 2013, we had combined foreign net operating loss carryforwards of $7.5 million and $4.2 million, respectively, that do not expire.

[0001596532-15-000004:notes:121]
As of December 31, 2014 and 2013, we had $1.9 million and zero, respectively, U.S. federal credit carryforwards which begin to expire in 2025. As of December 31, 2014 and 2013, we had state credit carryforwards of approximately $16.4 million and $9.6 million which can be carried over indefinitely.  As of December 31, 2014 and 2013, we had $2.1 million and $1.3 million of Canadian scientific research and experimental development tax credit carry-forwards, respectively, which begin to expire in 2033.

[0001596532-15-000004:notes:122]
Utilization of the net operating losses and tax credit carryforwards may be subject to limitations due to ownership changes limitations provided in the Internal Revenue code and similar state or foreign provisions. In all years up to December 31, 2014, such limitations had no impact to our deferred tax assets.

[0001596532-15-000004:notes:123]
Our policy with respect to our undistributed foreign subsidiaries earnings is to consider those earnings to be indefinitely reinvested and, accordingly, no related provision for U.S. federal and state income taxes has been provided. Upon distribution of those earnings’ in the form of dividends or otherwise, we may be subject to both U.S. income taxes (subject to an adjustment for foreign tax credits) and withholding taxes in the various countries. As of December 31, 2014, 2013 and 2012, the undistributed earnings approximated $4.9 million, $4.9 million and $1.0 million, respectively. The determination of the future tax consequences of the remittance of these earnings is not practicable.

[0001596532-15-000004:notes:124]
Uncertain Tax Positions

[0001596532-15-000004:notes:125]
We recognize uncertain tax positions only to the extent that management believes that it is more likely than not the position will be sustained. The reconciliation of the beginning and ending amount of gross unrecognized tax benefits as of December 31, 2014, 2013 and 2012 was as follows (in thousands):

[0001596532-15-000004:notes:126]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Gross unrecognized tax benefits—beginning balance | $ | 16,973 |  |  | $ | 13,960 |  |  | $ | 13,326 |  |
| Increases related to tax positions taken in a prior year | 425 |  |  | 70 |  |  | — |  |
| Increases related to tax positions taken during current year | 4,355 |  |  | 2,975 |  |  | 634 |  |
| Decreases related to tax positions taken in a prior year | (431 | ) |  | (32 | ) |  | — |  |
| Decreases related to settlements with taxing authorities | — |  |  | — |  |  | — |  |
| Decreases related to lapse of statute of limitations | — |  |  | — |  |  | — |  |
| Gross unrecognized tax benefits—ending balance | $ | 21,322 |  |  | $ | 16,973 |  |  | $ | 13,960 |  |

[0001596532-15-000004:notes:127]
As of December 31, 2014, 2013 and 2012 the total amount of gross unrecognized tax benefits was $21.3 million, $17.0 million and $14.0 million of which $15.8 million, $13.9 million and $12.2 million would affect our effective tax rate if recognized, respectively.

[0001596532-15-000004:notes:128]
Our policy is to recognize interest and penalties accrued on any unrecognized tax benefits as a component of income tax expense. We accrued interest and penalties of $0.7 million and $0.5 million in the years ended December 31, 2014 and 2013, respectively. As of December 31, 2014 and 2013, we recognized a liability for interest and penalties of $1.5 million and $0.8 million, respectively.

[0001596532-15-000004:notes:129]
We do not anticipate that the amount of existing unrecognized tax benefits would significantly increase or decrease within the next 12 months. Because of the net operating loss and tax credit carryforwards, substantially all of our tax years remain open to federal and state tax examination. The majority of our foreign tax returns are open to audit under the statute of limitations of the respective foreign countries, in which the subsidiaries are located.


## us-gaap:IncomeTaxPolicyTextBlock

[0001596532-15-000004:notes:130]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-15-000004:notes:131]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.


## us-gaap:InventoryPolicyTextBlock

[0001596532-15-000004:notes:132]
Inventories

[0001596532-15-000004:notes:133]
Inventories primarily consist finished goods purchased from third party contract manufacturers and are stated at the lower of cost (computed using the first-in, first-out method) or market value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  In addition, we also purchase certain strategic component inventory, including integrated circuits which are consigned to our contract manufacturers.  We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value. For the years ended December 31, 2014, 2013 and 2012, we incurred inventory write-downs of $2.8 million, $5.3 million and $3.2 million, respectively.

[0001596532-15-000004:notes:134]
We outsource most of our manufacturing and supply chain management operations to two third-party contract manufacturers and as a result, a significant portion of our cost of revenue consists of payments to them. Our third-party contract manufacturers purchase and own a portion of the material used to build our switch products until they are shipped to us, at which time our third-party contract manufacturers invoice us. In addition, we also purchase certain strategic component inventory, including integrated circuits which are consigned to our third-party contract manufacturers.  As of December 31, 2014 and 2013, our strategic component inventory consigned to others was $17.1 million and $18.3 million, respectively, and are included in raw materials.

[0001596532-15-000004:notes:135]
Our finished goods inventory consists of our finished switch products and accessories.  This inventory is located principally at third-party direct fulfillment facilities in California, the Netherlands and Singapore.


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-15-000004:notes:136]
Notes Receivable

[0001596532-15-000004:notes:137]
In 2014, we entered into a $3.0 million promissory note with a privately held company which was recorded at cost. The interest rate on the promissory note is 8.0% per annum and is payable quarterly. All unpaid principal and accrued interest on the promissory note is due and payable on the earlier of August 26, 2017, or upon default.

[0001596532-15-000004:notes:138]
In 2012, we made a loan of $4.0 million to a private company. The interest rate on the notes receivable was 6.0% per annum. The notes were convertible into the private company’s preferred stock or any securities exchangeable for the private company’s preferred stock. All unpaid principal and accrued interest on the notes receivable was due and payable on the earlier of August 31, 2014, or upon default.

[0001596532-15-000004:notes:139]
On July 30, 2014, the borrower signed a definitive agreement to close a Corporate Transaction through a merger (i.e. a transaction in which 50% of the voting power is transferred) and the transaction was expected to close in the first quarter of 2015. Pursuant to this transaction and per the terms of our agreement, we increased the value of our convertible notes receivable by $4.0 million to $8.0 million in the third quarter of 2014. In October 2014, we received payment in full from the borrower equal to two times our outstanding principal balance as well as the unpaid accrued interest through the payment date.

[0001596532-15-000004:notes:140]
In conjunction with the notes receivable, we also entered into an Exclusivity and Supply Agreement (“Supply Agreement”) with the borrower. Under the terms of the Supply Agreement, the borrower has agreed to develop and produce certain products for us at mutually agreed on supply terms and with best in class pricing rights to us. In addition, any exclusive features developed between us and the borrower cannot be sold by the borrower to other customers for 24 months following the commercial availability of such production versions. The Supply Agreement does not have a maturity date. We determined that the fair value of the Supply Agreement on its inception was insignificant as the borrower is still in the development stage and there is no certainty that a commercial product will be developed.

[0001596532-15-000004:notes:141]
We determined that we had a variable interest in the borrower through our notes receivable. However, we determined that we were not the primary beneficiary as we did not have the power to direct the borrower’s activities that most significantly affect the borrower’s economic performance. We also determined that our investment in the borrower was not an equity-method investment as the notes receivable had different risk and reward characteristics than those of the borrower’s common stock. We  elected the fair value option method of accounting for our notes receivable.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001596532-15-000004:notes:142]
The following table summarizes the amortized cost and fair value of our marketable securities as of December 31, 2014, by contractual years-to-maturity (in thousands):

[0001596532-15-000004:notes:143]
|  | Amortized Cost |  | Fair Value |
| Due within one year | $ | 209,671 |  |  | $ | 209,426 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-15-000004:notes:144]
Recent Accounting Pronouncements

[0001596532-15-000004:notes:145]
In May 2014, the FASB issued ASU No. 2014-09, Revenue From Contracts With Customers, which outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The standard is effective for fiscal years (and interim reporting periods within those years) beginning after December 15, 2016. Early application is not permitted. The standard permits the use of either the retrospective or cumulative effect transition method. We are currently reviewing the provisions of the standard and have not yet selected a transition method nor have we determined the effect of the standard on our consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-15-000004:notes:146]
Organization and Summary Significant Accounting Policies

[0001596532-15-000004:notes:147]
Organization

[0001596532-15-000004:notes:148]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our” or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System, a set of network applications and our 10/40/100 Gigabit Ethernet switches. We were incorporated in October 2004 in the State of California under the name Arastra, Inc. In March 2008, we reincorporated in the State of Nevada and in October 2008 changed our name to Arista Networks, Inc. We reincorporated in the state of Delaware in March 2014. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-15-000004:notes:149]
Initial Public Offering

[0001596532-15-000004:notes:150]
On June 6, 2014, we completed our initial public offering (the “IPO”) in which we sold 6,037,500 shares of our common stock at a public offering price of $43.00 per share, which included 787,500 shares of common stock issued pursuant to the exercise in full of the over-allotment option granted to the underwriters. The IPO resulted in proceeds of $239.1 million, net of underwriting discounts and commissions of $15.6 million and other issuance costs of $5.0 million. In connection with the closing of the IPO, all of our outstanding convertible preferred stock automatically converted into 24,000,000 shares of common stock on a one-to-one basis.

[0001596532-15-000004:notes:151]
Upon the closing of our IPO, all noteholders with the exception of one noteholder converted the principal and accrued interest amount outstanding under their subordinated convertible promissory notes into shares of our common stock at the IPO price of $43.00 per share. The noteholder, who did not elect to so convert, was paid a total of $23.6 million which included principal and accrued interest less applicable withholding taxes of $1.1 million. The remainder of the noteholders converted the remaining debt balance of approximately $96.5 million including principal and accrued interest into 2.2 million shares of our common stock.

[0001596532-15-000004:notes:152]
Use of Estimates

[0001596532-15-000004:notes:153]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts and sales return reserve; determination of fair value for stock-based awards; accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; valuation of inventory; valuation of warranty accruals; and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions on an ongoing basis using historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. As future events and their effects cannot be determined with precision, actual results could differ from these estimates, and those differences could be material to the consolidated financial statements.

[0001596532-15-000004:notes:154]
Consolidation of Variable Interest Entities

[0001596532-15-000004:notes:155]
We use a qualitative approach in assessing the consolidation requirement for variable interest entities (VIEs). This approach focuses on determining whether we have the power to direct the activities of the VIE that most significantly affect the VIE’s economic performance and whether we have the obligation to absorb losses, or the right to receive benefits, that could potentially be significant to the VIE. For all periods presented in the accompanying consolidated financial statements, we have determined that we are not the primary beneficiary of any VIEs. However, in the event that we are the primary beneficiary of a VIE entity, the assets, liabilities, and results of operations of the VIE will be included in our consolidated financial statements.

[0001596532-15-000004:notes:156]
Concentrations of Credit Risk

[0001596532-15-000004:notes:157]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, marketable securities, restricted cash, accounts receivable and notes receivable. Our cash, cash equivalents and restricted cash are invested in high quality financial instruments with banks and financial institutions. Such deposits may be in excess of insured limits provided on such deposits.

[0001596532-15-000004:notes:158]
Our accounts receivable are unsecured and represent amounts due to us based on contractual obligations of our customers. We mitigate credit risk in respect to accounts receivable by performing ongoing credit evaluations of our customers to assess the probability of accounts receivable collection based on a number of factors, including past transaction experience with the customer, evaluation of their credit history, the credit limits extended and review of the invoicing terms of the contract. We generally do not require our customers to provide collateral to support accounts receivable. We have recorded an allowance for doubtful accounts for those receivables that we have determined not to be collectible. Our notes receivable are secured and represent amounts due to us from a private company. We mitigate credit risk in respect to the notes receivable by performing ongoing credit evaluations of the borrower to assess the probability of collecting all amounts due to us under the existing contractual terms.

[0001596532-15-000004:notes:159]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators and original equipment manufacturer (“OEM”) partners.  Significant customers are those which represent more than 10% of our total net revenue during the period or net accounts receivable balance at each respective balance sheet date. For each significant customer, revenue as a percentage of total revenue and accounts receivable as a percentage of total accounts receivable are as follows:

[0001596532-15-000004:notes:160]
|  |  | Revenue |  | Accounts Receivable |
|  |  | Year Ended December 31, |  | December 31, |
| Customers |  | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |
| Customer A |  | 15 | % |  | 22 | % |  | 15 | % |  | 15 | % |  | 17 | % |
| Customer B |  | * |  |  | * |  |  | * |  |  | * |  |  | 11 | % |

[0001596532-15-000004:notes:161]
*less than 10%

[0001596532-15-000004:notes:162]
Reclassifications

[0001596532-15-000004:notes:163]
As a result of a change in classification, we have reclassified our spare parts inventory from inventory to other current and non-current assets as of December 31, 2014. Spare parts inventory are used to satisfy our warranty obligations, and are not available for sale or used in the production process. Prior year balances have been adjusted to conform to this new classification for comparability purposes.

[0001596532-15-000004:notes:164]
Marketable Securities

[0001596532-15-000004:notes:165]
We invest our excess cash primarily in money market and highly liquid debt instruments of the U.S. government. We classify all highly liquid investments with stated maturities of greater than three months as marketable securities. We determine the appropriate classification of our investments in marketable securities at the time of purchase and reevaluate such designation at each balance sheet date. We have classified and accounted for our marketable securities as available-for-sale. We may or may not hold securities with stated maturities greater than 12 months until maturity. After consideration of our risk versus reward objectives, as well as our liquidity requirements, we may sell these securities prior to their stated maturities. As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets. We carry these securities at fair value, and report the unrealized gains and losses, net of taxes, as a component of stockholders’ equity, except for unrealized losses determined to be other-than-temporary, which we record as other income (expense), net. We determine any realized gains or losses on the sale of marketable securities on a specific identification method, and we record such gains and losses as a component of interest and other income, net.

[0001596532-15-000004:notes:166]
Restricted Cash

[0001596532-15-000004:notes:167]
We had restricted cash pledged as collateral representing a security deposit required for a facility lease. As of December 31, 2013, we had classified the restricted cash of $4.0 million as other assets in our accompanying consolidated balance sheet. We did not have any restricted cash as of December 31, 2014.

[0001596532-15-000004:notes:168]
Accounts Receivable, Allowance for Doubtful Accounts, and Sales Return Reserves

[0001596532-15-000004:notes:169]
Accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts, and sales return reserves. We estimate our allowance for doubtful accounts based upon the collectability of the receivables in light of historical trends, adverse situations that may affect our customers’ ability to pay and prevailing economic conditions. This evaluation is done in order to identify issues which may impact the collectability of receivables and related estimated required allowance. Revisions to the allowance are recorded as an adjustment to bad debt expense. After appropriate collection efforts are exhausted, specific accounts receivable deemed to be uncollectible are charged against the allowance in the period they are deemed uncollectible. Recoveries of accounts receivable previously written-off are recorded as credits to bad debt expense. We estimate our sales return reserves based on historical return rates applied against current period gross revenues. Specific customer returns and allowances are considered when determining our sales return reserve estimate. Revisions to the reserve are recorded as adjustments to revenue and the sales return reserves.

[0001596532-15-000004:notes:170]
We mitigate credit risk in respect to accounts receivable by performing ongoing credit evaluations of our customers and channel partners to assess the probability of accounts receivable collection based on a number of factors, including past transaction experience with the customer or channel partner, evaluation of credit history, the credit limits extended and review of the invoicing terms of the arrangement. In situations where a partner or customer may be thinly capitalized and we have limited payment history with it, we will either establish a small credit limit or require it to prepay their purchases.

[0001596532-15-000004:notes:171]
Property and Equipment

[0001596532-15-000004:notes:172]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is calculated using the straight-line method over the shorter of the estimated useful lives of the related assets, generally from one to five years, 30 years for buildings or the lease term for leasehold improvements. The leased building under our build to suit lease is capitalized and included in property and equipment as we were involved in the construction funding and did not meet the “sale-leaseback” criteria.

[0001596532-15-000004:notes:173]
Investments

[0001596532-15-000004:notes:174]
Investments in Privately-held Companies

[0001596532-15-000004:notes:175]
In 2014, we have equity investments in privately-held companies. Our investments are accounted for under the cost method and are included in investments, non-current in the accompanying consolidated balance sheets. Initial measurement of our investments under the cost method were recorded at historical cost which represents our initial investment in the privately-held companies.  We will periodically assess and evaluate our cost method investments for impairment and perform an assessment based on evaluation of overall financial performance, industry and market conditions, and other relevant events or factors deemed necessary that may affect carrying value. If we determine that a decrease in the equity investments should be recognized given impairment that is considered “other-than-temporary” in nature, we will write-down the carrying amount to its revised new fair value.

[0001596532-15-000004:notes:176]
In 2014, we also entered into an unsecured promissory note with a privately held company which was recorded at cost.

[0001596532-15-000004:notes:177]
In 2012, we entered into secured note purchase agreements with a private company to provide them with cash advances. We elected the fair value option to account for these investments and recorded unrealized gains and losses in earnings at each subsequent reporting date. Accordingly, these notes receivable were remeasured to fair value at the end of each reporting period. Upfront costs and fees incurred in conjunction with entering into notes receivable were expensed and recognized in earnings as incurred. Gains and losses from the change in fair value, as well as interest income, were recorded in other income (expense), net in the accompanying consolidated statements of income at each reporting period.  In 2014, we received payment in full from the borrower equal to two times our outstanding principal balance as well as the unpaid accrued interest through the payment date.

[0001596532-15-000004:notes:178]
Revenue Recognition

[0001596532-15-000004:notes:179]
We generate revenue from sales of switching products which incorporate our EOS software and accessories such as cables and optics to direct customers and channel partners together with post contract customer support (“PCS”). We typically sell products and PCS in a single transaction. We recognize revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery or performance has occurred; the sales price is fixed or determinable; and collectability is reasonably assured.

[0001596532-15-000004:notes:180]
We define each of the four criteria above as follows:

[0001596532-15-000004:notes:181]
| • | Persuasive evidence of an arrangement exists. Evidence of an arrangement consists of stand-alone purchase orders or purchase orders issued pursuant to the terms and conditions of a master sales agreement. It is our practice to identify an end customer prior to shipment to a reseller or distributor. |

[0001596532-15-000004:notes:182]
| • | Delivery or performance has occurred. We use shipping documents or written evidence of customer acceptance, when applicable, to verify delivery or performance. We recognize product revenue upon transfer of title and risk of loss, which primarily is upon shipment to customers. We do not have significant obligations for future performance, such as customer acceptance provisions, rights of return or pricing credits, associated with our product sales. In instances where substantive acceptance provisions are specified in the customer arrangement, revenue is deferred until all acceptance criteria have been met. |

[0001596532-15-000004:notes:183]
| • | The sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on payment terms and whether the sales price is subject to refund or adjustment. |

[0001596532-15-000004:notes:184]
| • | Collectability is reasonably assured. We assess probability of collectability on a customer-by-customer basis. Our customers and channel partners are subjected to a credit review process that evaluates their financial condition and ability to pay for products and services. |

[0001596532-15-000004:notes:185]
PCS is offered under renewable, fee-based contracts, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis. We initially defer PCS revenue and recognize it ratably over the life of the PCS contract, with the related expenses recognized as incurred. PCS contracts usually have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-15-000004:notes:186]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of goods sold.

[0001596532-15-000004:notes:187]
Multiple-Element Arrangements

[0001596532-15-000004:notes:188]
Most of our arrangements, other than renewals of PCS, are multiple element arrangements with a combination of products and PCS. Products and PCS generally qualify as separate units of accounting. Our hardware deliverables include EOS software, which together deliver the essential functionality of our products. For multiple element arrangements, we allocate revenue to each unit of accounting based on the relative selling price. The relative selling price for each element is based upon the following hierarchy: vendor-specific objective evidence (“VSOE”), if available; third-party evidence (“TPE”), if VSOE is not available; and best estimate of selling price (“BESP”), if neither VSOE nor TPE is available. As we have not been able to establish VSOE or TPE for our products and most of our services, we generally utilize BESP for the purposes of allocating revenue to each unit of accounting.

[0001596532-15-000004:notes:189]
| • | VSOE—We determine VSOE based on our historical pricing and discounting practices for the specific products and services when sold separately. In determining VSOE, we require that a substantial majority of the stand-alone selling prices fall within a reasonably narrow pricing range. |

[0001596532-15-000004:notes:190]
| • | TPE—When VSOE cannot be established for deliverables in multiple-element arrangements, we apply judgment with respect to whether we can establish a selling price based on TPE. TPE is determined based on competitor prices for interchangeable products or services when sold separately to similarly situated customers. However, as our products contain a significant element of proprietary technology and offer substantially different features and functionality, the comparable pricing of products with similar functionality typically cannot be obtained. Additionally, as we are unable to reliably determine what competitors products’ selling prices are on a stand-alone basis, we are not able to obtain reliable evidence of TPE of selling price. |

[0001596532-15-000004:notes:191]
| • | BESP—When we are unable to establish selling price using VSOE or TPE, we use BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service was sold regularly on a stand-alone basis. BESP is based on considering multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services were sold (domestic or international) and size of the end customer. |

[0001596532-15-000004:notes:192]
We limit the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations, or subject to customer-specific return, acceptance or refund privileges.

[0001596532-15-000004:notes:193]
We account for multiple agreements with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single arrangement.

[0001596532-15-000004:notes:194]
We may occasionally accept returns to address customer satisfaction issues even though there is no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period gross revenues. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-15-000004:notes:195]
Research and Development Expenses

[0001596532-15-000004:notes:196]
Costs related to the research, design and development of our products are charged to research and development expenses as incurred. Software development costs are capitalized beginning when a product’s technological feasibility has been established and ending when the product is available for general release to customers. Generally, our products are released soon after technological feasibility has been established. As a result, costs incurred subsequent to achieving technological feasibility have not been significant and accordingly, all software development costs have been expensed as incurred.

[0001596532-15-000004:notes:197]
Warranty

[0001596532-15-000004:notes:198]
We offer a one-year warranty on all of our hardware products and a 90-day warranty against defects in the software embedded in the products. We accrue for potential warranty claims at the time of shipment as a component of cost of revenues based on historical experience and other relevant information. We accrue specifically identified reserves if and when we determine we have a systemic product failure. The accrued warranty liability is recorded in accrued liabilities in the accompanying consolidated balance sheets.

[0001596532-15-000004:notes:199]
Post-Employment Benefits

[0001596532-15-000004:notes:200]
We have a 401(k) Plan that covers substantially all of our employees in the U.S. For the years ended December 31, 2014, 2013 and 2012, we did not provide a discretionary company match to employee contributions.

[0001596532-15-000004:notes:201]
Segment Reporting

[0001596532-15-000004:notes:202]
Our chief operating decision maker is our Chief Executive Officer. Our Chief Executive Officer reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance. We have one business activity and there are no segment managers who are held accountable for operations or operating results. Accordingly, we have determined that we operate as one reportable segment.

[0001596532-15-000004:notes:203]
We recognize stock-based compensation for stock-based awards, including stock options, restricted stock units (RSUs), restricted stock awards (“RSAs”), stock purchase rights from our employee stock purchase program based on the estimated fair value of the awards, net of estimated forfeitures. The fair value of each stock-based award and option is estimated on the grant date using the Black-Scholes option-pricing model. This model requires that at the date of grant we determine the fair value of the underlying common stock, the expected term of the award, the expected volatility of the price of our common stock, risk-free interest rates, and expected dividend yield of our common stock. RSUs are measured based on the fair market values of the underlying stock on the dates of grant.

[0001596532-15-000004:notes:204]
The stock-based compensation expense, net of forfeitures, is recognized on a straight-line basis over the requisite service periods of the awards, which is generally two to five years. We estimate a forfeiture rate to calculate the stock-based compensation for our awards. Our forfeiture rate is based on an analysis of our actual historical forfeitures.

[0001596532-15-000004:notes:205]
Excess tax benefits associated with stock option exercises and other equity awards are recognized in additional paid in capital. The income tax benefits resulting from stock awards that were credited to stockholders' equity were $17.4 million, $0.6 million and $39,000 for the years ended December 31, 2014, 2013 and 2012, respectively.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001596532-15-000004:notes:206]
Other current liabilities consist of the following (in thousands):

[0001596532-15-000004:notes:207]
|  | December 31, |
|  | 2014 |  | 2013 |
| Liability for early exercised shares subject to repurchase | $ | 4,616 |  |  | $ | 7,520 |  |
| Sales tax payable | 3,101 |  |  | 1,359 |  |
| Lease financing obligations, current portion | 1,087 |  |  | 818 |  |
| Other | 2,445 |  |  | 447 |  |
| Total other current liabilities | $ | 11,249 |  |  | $ | 10,144 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001596532-15-000004:notes:208]
Property and equipment, net consists of the following (in thousands):

[0001596532-15-000004:notes:209]
|  | December 31, |
|  | 2014 |  | 2013 |
| Equipment and machinery | $ | 18,265 |  |  | $ | 13,733 |  |
| Computer hardware and software | 7,772 |  |  | 3,688 |  |
| Furniture and fixtures | 1,373 |  |  | 1,352 |  |
| Leasehold improvements | 19,420 |  |  | 19,407 |  |
| Building | 35,154 |  |  | 35,154 |  |
| Construction-in-process | 6,532 |  |  | 1,056 |  |
| Property and equipment, gross | 88,516 |  |  | 74,390 |  |
| Less: accumulated depreciation | (16,958 | ) |  | (7,186 | ) |
| Property and equipment, net | $ | 71,558 |  |  | $ | 67,204 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001596532-15-000004:notes:210]
Other Related Party Transactions and Balances

[0001596532-15-000004:notes:211]
Certain members of our board of directors serve on the boards of our customers. During the years ended December 31, 2014, 2013 and 2012, we recognized revenue of $29.6 million, $11.1 million and $1.1 million, respectively, from sales transactions with these related party customers. Amounts due from these related party customers were $6.4 million and $3.8 million as of December 31, 2014 and 2013, respectively.


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001596532-15-000004:notes:212]
Accounts Receivable, net

[0001596532-15-000004:notes:213]
Accounts receivable, net consists of the following (in thousands):

[0001596532-15-000004:notes:214]
|  | December 31, |
|  | 2014 |  | 2013 |
| Accounts receivable | $ | 100,076 |  |  | $ | 80,338 |  |
| Allowance for doubtful accounts | (1,063 | ) |  | (810 | ) |
| Product sales return reserve | (2,031 | ) |  | (1,529 | ) |
| Accounts receivable, net | $ | 96,982 |  |  | $ | 77,999 |  |

[0001596532-15-000004:notes:215]
Allowance for Doubtful Accounts

[0001596532-15-000004:notes:216]
Activity in the allowance for doubtful accounts consists of the following (in thousands):

[0001596532-15-000004:notes:217]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Balance at the beginning of year | $ | 810 |  |  | $ | 1,284 |  |  | $ | 1,169 |  |
| Charged to expenses | 860 |  |  | 191 |  |  | 326 |  |
| Deductions (write-offs) | (607 | ) |  | (665 | ) |  | (211 | ) |
| Balance at the end of year | $ | 1,063 |  |  | $ | 810 |  |  | $ | 1,284 |  |

[0001596532-15-000004:notes:218]
Sales Return Reserve

[0001596532-15-000004:notes:219]
Activity in the sales return reserve consists of the following (in thousands):

[0001596532-15-000004:notes:220]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |
| Balance at the beginning of year | $ | 1,529 |  |  | $ | — |  |
| Charged against revenue | 4,063 |  |  | 1,627 |  |
| Sales returns | (3,561 | ) |  | (98 | ) |
| Balance at the end of year | $ | 2,031 |  |  | $ | 1,529 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001596532-15-000004:notes:221]
Accrued liabilities consist of the following (in thousands):

[0001596532-15-000004:notes:222]
|  | December 31, |
|  | 2014 |  | 2013 |
| Accrued payroll related costs | $ | 30,749 |  |  | $ | 9,103 |  |
| Accrued warranty costs | 3,204 |  |  | 5,075 |  |
| Accrued manufacturing costs | 1,089 |  |  | 3,835 |  |
| Accrued professional fees | 2,354 |  |  | 1,220 |  |
| Accrued taxes | 1,577 |  |  | 927 |  |
| Other | 1,396 |  |  | 1,379 |  |
| Total accrued liabilities | $ | 40,369 |  |  | $ | 21,539 |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001596532-15-000004:notes:223]
The following table summarizes the unrealized gains and losses and fair value of our available-for-sale marketable securities (in thousands):

[0001596532-15-000004:notes:224]
|  | December 31, 2014 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| U.S. government notes | $ | 209,671 |  |  | $ | — |  |  | $ | (245 | ) |  | $ | 209,426 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001596532-15-000004:notes:225]
Inventories consist of the following (in thousands):

[0001596532-15-000004:notes:226]
|  | December 31, |
|  | 2014 |  | 2013 |
| Raw materials | $ | 17,094 |  |  | $ | 18,286 |  |
| Finished goods | 63,425 |  |  | 48,808 |  |
| Total inventories | $ | 80,519 |  |  | $ | 67,094 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001596532-15-000004:notes:227]
Prepaid Expenses and Other Current Assets

[0001596532-15-000004:notes:228]
Prepaid expenses and other current assets consists of the following (in thousands):

[0001596532-15-000004:notes:229]
|  | December 31, |
|  | 2014 |  | 2013 |
| Prepaid income taxes | $ | 25,212 |  |  | $ | 134 |  |
| Other current assets | 9,820 |  |  | 5,137 |  |
| Other prepaid and deposits | 5,237 |  |  | 2,382 |  |
| Total prepaid expenses and other current assets | $ | 40,269 |  |  | $ | 7,653 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001596532-15-000004:notes:230]
The following table summarizes the activity related to our accrued liability for estimated future warranty costs (in thousands):

[0001596532-15-000004:notes:231]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |
| Warranty accrual, beginning of period | $ | 5,075 |  |  | $ | 5,314 |  |
| Liabilities accrued for warranties issued during the period | 2,611 |  |  | 4,290 |  |
| Warranty costs incurred during the period | (2,163 | ) |  | (4,529 | ) |
| Adjustments related to change in estimate | (2,319 | ) |  | — |  |
| Warranty accrual, end of period | $ | 3,204 |  |  | $ | 5,075 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001596532-15-000004:notes:232]
The following table represents revenue based on the customer’s location, as determined by the customer’s shipping address (in thousands):

[0001596532-15-000004:notes:233]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| United States | $ | 456,691 |  |  | $ | 293,579 |  |  | $ | 149,537 |  |
| Other Americas | 8,853 |  |  | 6,040 |  |  | 5,056 |  |
| Europe, Middle East and Africa | 74,555 |  |  | 40,577 |  |  | 23,012 |  |
| Asia Pacific | 44,007 |  |  | 21,028 |  |  | 15,803 |  |
| Total revenue | $ | 584,106 |  |  | $ | 361,224 |  |  | $ | 193,408 |  |

[0001596532-15-000004:notes:234]
Long lived assets, excluding intercompany receivables, investments in subsidiaries, privately-held equity investments

[0001596532-15-000004:notes:235]
and deferred tax assets, net by location are summarized as follows (in thousands):

[0001596532-15-000004:notes:236]
|  | December 31, |
|  | 2014 |  | 2013 |
| United States | $ | 67,727 |  |  | $ | 63,557 |  |
| International | 3,831 |  |  | 3,647 |  |
| Total | $ | 71,558 |  |  | $ | 67,204 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-15-000004:notes:237]
Segment Information

[0001596532-15-000004:notes:238]
We have determined that we operate as one reportable segment. The following table represents revenue based on the customer’s location, as determined by the customer’s shipping address (in thousands):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-15-000004:notes:239]
Balance Sheet Components

[0001596532-15-000004:notes:240]
We did not realized any other-than-temporary losses on our marketable securities for the year ended December 31, 2014. None of our marketable securities have been in continuous unrealized loss positions for greater than twelve months as of December 31, 2014.

[0001596532-15-000004:notes:241]
We did not hold any marketable securities as of December 31, 2013.

[0001596532-15-000004:notes:242]
We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a lower yield show a mark-to-market unrealized loss. The unrealized losses are due primarily to changes in credit spreads and interest rates. We expect to realize the full value of all these investments upon maturity or sale.  The weighted average remaining duration of our current marketable securities is approximately 0.8 years as of December 31, 2014.

[0001596532-15-000004:notes:243]
Property and Equipment, net

[0001596532-15-000004:notes:244]
Building consists of capitalized construction costs of our leased building in Santa Clara, California. Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction, such as our financial involvement in structural elements of asset construction, making decisions related to tenant improvement costs and purchasing insurance not reimbursable by the buyer-lessor (the Landlord), we were deemed the owner of the building (for accounting purposes only) during the construction period. We maintain continued involvement in the property after construction was completed and lack transferability of the risks and rewards of ownership, primarily due to our required maintenance of a $4.0 million letter of credit.  Due to our continuing involvement in the property post construction and lack of transferability of related risks and rewards of ownership to the Landlord after construction is complete, we account for the building as a financing obligation. See “Note 6-Commitments and Contingencies”. Accordingly, as of December 31, 2014 and December 31, 2013, we have recorded assets of $53.4 million and $53.3 million, respectively, representing the total costs of the building and improvements incurred, including the costs paid by the Landlord. The building was completed in 2013.

[0001596532-15-000004:notes:245]
Depreciation expense was $10.0 million, $5.0 million and $1.8 million for the years ended December 31, 2014, 2013 and 2012, respectively.

[0001596532-15-000004:notes:246]
Accrued Liabilities

[0001596532-15-000004:notes:247]
Warranty Accrual

[0001596532-15-000004:notes:248]
During the year ended December 31, 2013, we identified specific products that were failing in the field prematurely at higher than expected rates due to various component issues. There were no significant specific product warranty reserves recorded in 2014.

[0001596532-15-000004:notes:249]
Other Current Liabilities
