# ANET MD&A — 0001596532-15-000004


## mdna

[0001596532-15-000004:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001596532-15-000004:mdna:2]
Overview

[0001596532-15-000004:mdna:3]
We are a leading supplier of cloud networking solutions that use software innovations to address the needs of large-scale Internet companies, cloud service providers and next-generation data centers for enterprises, based on market share. Our cloud networking solutions consist of our Extensible Operating System, or EOS, a set of network applications and our 10/40/100 Gigabit Ethernet switches. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. At the core of our cloud networking platform is EOS, which was purpose-built to be fully programmable and highly modular. The programmability of EOS has allowed us to create a set of software applications that address the requirements of cloud networking, including workflow automation, network visibility and analytics, and has also allowed us to rapidly integrate with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001596532-15-000004:mdna:4]
We were founded in 2004 to address the limitations of legacy networking products and to create a cloud networking platform that is open and programmable. From 2004 to 2008, our activities were focused on the development of our software, which resulted in the commercial release of our first product, the 7100 Series switches based on our EOS software, in 2008. Since then, we have continued to introduce new products utilizing EOS, including our 7500 Series switch and our 7050 Series switch in 2010, the second generation of our 7500 Series switch, called the 7500E modular switch, in May 2013, our 7300 Series switch in November 2013, our 7280E in July 2014 and in December 2014 our EOS+ software platform for networking programmability and automation. As of December 31, 2014, we have shipped more than three million switch ports. We have experienced rapid revenue growth over the last several years, increasing our revenue at a compound annual growth rate of 68.9% from 2010 to 2014. As we have grown the functionality of our EOS software, expanded the range of our switching portfolio and increased the size of our sales force, our revenue has continued to grow rapidly. To support revenue growth, we have increased our international presence to include offices in 11 countries as of December 31, 2014, including Australia, Canada, China, India, Ireland, Japan, Malaysia, Singapore, South Korea, Taiwan and the United Kingdom. Our revenue for the year ended December 31, 2014 was $584.1 million an increase of 61.7% compared to 2013. We have been profitable and cash flow positive for each year since 2010.

[0001596532-15-000004:mdna:5]
We believe that our cloud networking platform addresses the large and growing cloud networking segment of data center switching, which remains in the early stage of adoption. We expect to continue rapidly growing our organization to meet the needs of new and existing customers as they increasingly realize the performance and cost benefits of our cloud networking solutions and as they expand their cloud networks. We intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features and build upon our technology leadership. We believe one of our greatest strengths lies in our rapid development of new features and applications. By investing in research and development, we believe we will be well positioned to continue our rapid growth and take advantage of our large market opportunity. We also intend to continue expanding our sales and marketing teams and programs, with a particular focus on expanding our network of international channel partners and carrying out associated marketing activities in key geographies. In order to support our strong growth, we have accelerated our investment in infrastructure, such as enterprise resource planning software and other technologies to improve the efficiency of our operations. As a result, our levels of operating profit as a percentage of revenue could decline in the short to medium term. For a description of factors that may impact our future performance, see the disclosure in the section titled "Factors Affecting Our Performance" below.

[0001596532-15-000004:mdna:6]
Our Business Model

[0001596532-15-000004:mdna:7]
We derive revenue from sales of products and services. We generate revenue primarily from sales of our switching products which incorporate our EOS software. We generate the majority of our services revenue from post contract support, or PCS, which end customers typically purchase in conjunction with our products.

[0001596532-15-000004:mdna:8]
Since shipping our first products in 2008, our cumulative end-customer base has grown rapidly. Between December 31, 2010 and December 31, 2014, our cumulative end-customer base grew from approximately 570 to over 3,000. Our end customers span a range of industries and include large Internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others.

[0001596532-15-000004:mdna:9]
To continue to grow our revenue, it is important that we both obtain new customers and sell additional products to existing customers. Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic to the underlying merchant silicon architecture. Today, we combine our EOS software with merchant silicon into a family of switching products. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We currently procure certain merchant silicon components from multiple vendors, and we continue to expand our relationships with these and other vendors. We work closely with third parties to manufacture and deliver our products. Our third-party silicon vendors deliver these components to one of three direct fulfillment facilities where our EOS software is installed on our products, and then delivered to us for labeling, quality assurance testing, final configuration and shipment to our customers.

[0001596532-15-000004:mdna:10]
We market and sell our products through our direct sales force and in partnership with channel partners, including distributors, value-added resellers, systems integrators, original equipment manufacturer, or OEM, partners and in conjunction with various technology partners, depending on the application. To facilitate channel coordination and increase productivity, we have created a partner program, the Arista Partner Program, to engage partners who provide value-added services and extend our reach into the marketplace. Authorized training partners provide technical training to our channel partners. Our partners commonly receive an order from an end customer prior to placing an order with us, and we confirm the identification of the end customer prior to accepting such orders. Our partners generally do not stock inventory received from us. Our sales organization is supported by systems engineers with deep technical expertise and responsibility for pre-sales technical support and engineering for our end customers. Each sales team is responsible for a geographic territory, has responsibility for a number of major direct end-customer accounts or has assigned accounts in a specific vertical market. During years ended December 31, 2014, 2013 and 2012, 79.7%, 82.9% and 79.9% of our revenue was generated from the Americas, substantially all from the U.S., 12.8%, 11.2% and 11.9% from Europe, the Middle East and Africa and 7.5%, 5.9% and 8.2% from the Asia-Pacific region, respectively.

[0001596532-15-000004:mdna:11]
Factors Affecting Our Performance

[0001596532-15-000004:mdna:12]
We believe that our future success will depend on many factors, including our ability to expand sales to our existing customers as well as to add new end customers. While these areas present significant opportunity, they also present risks that we must manage to ensure successful results. See the section titled “Risk Factors.” Additionally, we face intense competition especially from larger, well-established companies, and we must continue to expand the capabilities of our cloud networking platform to succeed in our market. If we are unable to address these challenges, our business could be adversely affected.

[0001596532-15-000004:mdna:13]
Increasing Adoption of Cloud Networks. Networks are subject to increasing performance requirements due to growing numbers of connected devices as well as new enterprise and consumer applications. Computing architectures are evolving to meet the need for constant connectivity and access to data and applications. We believe that cloud networks will continue to replace legacy network technologies. Our business and results of operations will be significantly affected by the speed with which organizations implement cloud networks.

[0001596532-15-000004:mdna:14]
Expanding Sales to Existing Customer Base. We expect that a substantial portion of our future sales will be follow-on sales to existing end customers. As noted above, one of our sales strategies is to target specific projects at our current end customers because they are familiar with the operational and economic benefits of our cloud networking solutions, thereby reducing the sales cycle into these customers. We believe this opportunity with current end customers to be significant given their existing and expected infrastructure spend. As of December 31, 2014, our end customers that have been with us for at least 2 years, on average made additional purchases that were approximately 11.9x more than the initial dollar amount of purchases made in the first two quarters of their purchasing history. The first 2 quarters of purchasing are typically the beginning of switch procurement for a given deployment and typically do not include time spent during initial customer testing, as most customer testing is done prior to initial purchase. Although the additional purchases for our Top 10 end customers were significantly more than our overall average, the remainder of the end customer base also showed a propensity to continue purchasing with average additional purchases of 6.7x the initial dollar purchases made in the first two quarters of their purchasing history. This analysis is based on billings, which represent amounts invoiced to customers for products shipped, or for services rendered or to be rendered, and that the vast majority of billings for any given period represent revenue, and to a far lesser extent deferred revenue. Our business and results of operations will depend on our ability to sell additional products to our growing base of customers.

[0001596532-15-000004:mdna:15]
Adding New End Customers. We believe that the cloud networking market is still in the early stages of adoption. We intend to target new end customers by continuing to invest in our field sales force and extending our relationships with channel partners. To date, we have primarily targeted end customers with the largest cloud data centers. A typical initial order involves the education of prospective customers about the technical merits and capabilities and potential cost savings of our products as compared to our competitors’ products. Our results of operations will depend on our ability to continue to add new customers. We believe that customer references have been, and will continue to be, an important factor in winning new business.

[0001596532-15-000004:mdna:16]
Selling More Complex and Higher-Performance Configurations. Our results of operations have been, and we believe will continue to be, affected by our ability to sell more complex and higher-performance configurations of our products. Going forward, we aim to grow our revenue by enabling end customers to transition from previously deployed 1 Gigabit Ethernet switches to 10, 40 and eventually 100 Gigabit Ethernet switches. Our ability to sustain our revenue growth will depend, in part, upon our continued sales of more robust configurations of our products, and quarterly results of operations can be significantly impacted by the mix of products and product configurations sold during the period.

[0001596532-15-000004:mdna:17]
Leveraging Channel Partners. We expect to continue to derive a growing portion of our sales through our channel partners as they develop new end customers and expand sales to our existing end customers. We plan to continue to invest in our network of channel partners to empower them to reach new end customers more effectively, increase sales to existing customers and provide services and support effectively. We believe that increasing channel leverage will extend and improve our engagement with a broad set of customers. Our business and results of operations will be materially affected by our success in leveraging our channel partners.

[0001596532-15-000004:mdna:18]
Investing in Research and Development for Growth. We believe that the market for cloud networking is still in the early stages of adoption and we intend to continue investing for long-term growth. We expect to continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products including new releases and upgrades to our EOS software and new applications and build upon our technology leadership. We believe one of our greatest strengths lies in the speed of our product development efforts. By investing in research and development, we believe we will be well positioned to continue our rapid growth and take advantage of our large market opportunity. We expect that our results of operations will be impacted by the timing and size of these product development investments.

[0001596532-15-000004:mdna:19]
Customer Concentration and Timing of Large Orders. Historically, large purchases by a relatively limited number of end customers have accounted for significant portion of our revenue. During the years ended December 31, 2014, 2013 and 2012, our largest end customer accounted for 14.9%, 21.9% and 15.3% of our revenue, respectively. We have also experienced and continue to experience customer concentration on a quarterly basis. In addition, we have experienced increases in the size of our orders, including orders from existing customers, which could result in future increased customer concentration, depending on the timing of the fulfillment of those orders. We have also experienced unpredictability in the timing of large orders, especially with respect to our large end customers, due to the complexity of orders, the time it takes end customers to evaluate, test, qualify and accept our products and factors specific to our end customers. Due to these factors, we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, we have provided, and may in the future provide, pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur. Our gross margins may also fluctuate as a result of the timing of such sales to large end customers.

[0001596532-15-000004:mdna:20]
45

[0001596532-15-000004:mdna:21]
Basis of Presentation

[0001596532-15-000004:mdna:22]
Revenue

[0001596532-15-000004:mdna:23]
We generate revenue primarily from sales of our switching products which incorporate our EOS software. We also derive a small but growing portion of our revenue from sales of PCS. We generate PCS revenue from sales of technical support services contracts that are typically purchased in conjunction with our products and subsequent renewals of those contracts. We offer PCS services under renewable, fee-based contracts, which include 24-hour technical support, hardware repair and replacement parts, bug fixes, patches and unspecified upgrades on a when-and-if available basis. We expect our revenue may vary from period to period based on, among other things, the timing and size of orders, the delivery and acceptance of products, the impact of significant transactions with unique terms and conditions that may require deferral of revenue and cyclicality of orders being placed by our customers. Additionally, we expect our PCS revenue to increase in absolute dollars as we expand our installed base. Our ability to expand our installed base and increase our revenue is subject to numerous risks and uncertainties. See the section titled “Risk Factors.” We report revenue net of sales taxes.

[0001596532-15-000004:mdna:24]
Cost of Revenue

[0001596532-15-000004:mdna:25]
Cost of revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs in our manufacturing operations department, and other manufacturing-related costs associated with manufacturing our products and managing our inventory. We expect our cost of product revenue to increase as our product revenue increases. Cost of providing PCS services consists of personnel costs for our global customer support organization. We expect our cost of service revenue to increase as our PCS revenue increases.

[0001596532-15-000004:mdna:26]
Gross Margin

[0001596532-15-000004:mdna:27]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including sales to large end customers who generally receive lower pricing, the average sales price of our offerings, manufacturing costs, merchant silicon costs and the mix of products sold. We expect our gross margins to fluctuate over time, depending on the factors described above and others. See Part I Item 1A, of “Risk Factors.”

[0001596532-15-000004:mdna:28]
Operating Expenses

[0001596532-15-000004:mdna:29]
Our operating expenses consist of research and development, sales and marketing and general and administrative expenses. The largest component of our operating expenses is personnel costs. Personnel costs consist of wages, benefits, bonuses and, with respect to sales and marketing expenses, sales commissions. Personnel costs also include stock-based compensation and travel expenses. We expect operating expenses to continue to increase in absolute dollars in the near term as we continue to invest in the growth of our business.

[0001596532-15-000004:mdna:30]
Research and Development Expenses

[0001596532-15-000004:mdna:31]
Research and development expenses consist primarily of personnel costs, with the remainder being prototype expenses, third-party engineering and contractor support costs, and an allocated portion of facility and IT costs and depreciation. Our research and development efforts are focused on maintaining and developing additional functionality for our existing products and on new product development, including new releases and upgrades to our EOS software and applications. We expense research and development costs as incurred. We expect our research and development expenses to increase in absolute dollars as we continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products and features and build upon our technology leadership.

[0001596532-15-000004:mdna:32]
Sales and Marketing Expenses

[0001596532-15-000004:mdna:33]
Sales and marketing expenses consist primarily of personnel costs and also include costs related to marketing and promotional activities, with the remainder being an allocated portion of facility and IT costs and depreciation. We expect our sales and marketing expenses to increase in absolute dollars as we expand our sales and marketing efforts worldwide and expand our relationships with current and future channel partners and end customers.

[0001596532-15-000004:mdna:34]
General and Administrative Expenses

[0001596532-15-000004:mdna:35]
General and administrative expenses consist primarily of personnel costs, professional fees, and an allocated portion of facility and IT costs and depreciation. General and administrative personnel costs include those for our executive, finance, IT, human resources and legal functions. Our professional fees consist primarily of accounting, external legal and IT and other consulting costs. We expect our general and administrative expenses to increase in absolute dollars to support our growing infrastructure needs and as we assume the reporting requirements and compliance obligations of a public company. In addition, we expect an increase in legal expenses to address current and potential litigation claims.

[0001596532-15-000004:mdna:36]
Other Income (Expense), Net

[0001596532-15-000004:mdna:37]
Interest Expense

[0001596532-15-000004:mdna:38]
Interest expense consists of interest expense on our subordinated convertible promissory notes, including our related party subordinated convertible promissory notes which were converted during fiscal 2014 and interest expense from our lease financing obligation.

[0001596532-15-000004:mdna:39]
Other Income (Expense)

[0001596532-15-000004:mdna:40]
Other income (expense) consists of gains on investments, write-offs of debt discount on notes payable and foreign currency exchange gains and losses. Our foreign currency exchange gains and losses relate to transactions and asset and liability balances denominated in currencies other than the U.S. dollar. We expect our foreign currency gains and losses to continue to fluctuate in the future  due to changes in foreign currency exchange rates.

[0001596532-15-000004:mdna:41]
Provision for Income Taxes

[0001596532-15-000004:mdna:42]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may be subject to U.S. income tax. Generally, the U.S. taxes are reduced by a credit for foreign income taxes paid on these earnings which avoids double taxation. Our tax expense to date consists of federal, state and foreign current and deferred income taxes. As we expand internationally, our marginal tax rate may decrease; however, there can be no certainty that our marginal tax rate will decrease, and we may experience changes in tax rates that are not reflective of actual changes in our business or operations.

[0001596532-15-000004:mdna:43]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. We measure deferred income tax assets and liabilities using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-15-000004:mdna:44]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-15-000004:mdna:45]
Results of Operations

[0001596532-15-000004:mdna:46]
The following table summarizes historical results of operations for the periods presented and as a percentage of revenue for those periods.  We have derived the data for the years ended December 31, 2014, 2013 and 2012 from our consolidated financial statements (in thousands, except for percentage of revenue).

[0001596532-15-000004:mdna:47]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Consolidated Statements of Operations Data: |  |  |  |  |  |
| Revenue | $ | 584,106 |  |  | $ | 361,224 |  |  | $ | 193,408 |  |
| Cost of revenue (1) | 192,015 |  |  | 122,686 |  |  | 61,252 |  |
| Gross profit | 392,091 |  |  | 238,538 |  |  | 132,156 |  |
| Operating expenses (1): |  |  |  |  |  |
| Research and development | 148,909 |  |  | 98,587 |  |  | 55,155 |  |
| Sales and marketing | 85,338 |  |  | 55,115 |  |  | 28,603 |  |
| General and administrative | 32,331 |  |  | 18,688 |  |  | 8,501 |  |
| Total operating expenses | 266,578 |  |  | 172,390 |  |  | 92,259 |  |
| Income from operations | 125,513 |  |  | 66,148 |  |  | 39,897 |  |
| Interest expense | (6,280 | ) |  | (7,119 | ) |  | (7,057 | ) |
| Other income (expense), net | 2,275 |  |  | (754 | ) |  | 135 |  |
| Total Other income (expense), net | (4,005 | ) |  | (7,873 | ) |  | (6,922 | ) |
| Income before provision for income taxes | 121,508 |  |  | 58,275 |  |  | 32,975 |  |
| Provision for income taxes | 34,658 |  |  | 15,815 |  |  | 11,626 |  |
| Net income | $ | 86,850 |  |  | $ | 42,460 |  |  | $ | 21,349 |  |

[0001596532-15-000004:mdna:48]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
|  | (as a percentage of revenue) |
| Revenue | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue | 32.9 |  |  | 34.0 |  |  | 31.7 |  |
| Gross margin | 67.1 |  |  | 66.0 |  |  | 68.3 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 25.5 |  |  | 27.3 |  |  | 28.5 |  |
| Sales and marketing | 14.6 |  |  | 15.3 |  |  | 14.8 |  |
| General and administrative | 5.5 |  |  | 5.2 |  |  | 4.4 |  |
| Total operating expenses | 45.6 |  |  | 47.8 |  |  | 47.7 |  |
| Income from operations | 21.5 |  |  | 18.2 |  |  | 20.6 |  |
| Interest expense | (1.1 | ) |  | (2.0 | ) |  | (3.6 | ) |
| Other income (expense), net | 0.4 |  |  | (0.2 | ) |  | 0.1 |  |
| Total other income (expense), net | (0.7 | ) |  | (2.2 | ) |  | (3.5 | ) |
| Income before provision for income taxes | 20.8 |  |  | 16.0 |  |  | 17.1 |  |
| Provision for income taxes | 5.9 |  |  | 4.4 |  |  | 6.0 |  |
| Net income | 14.9 | % |  | 11.6 | % |  | 11.1 | % |

[0001596532-15-000004:mdna:49]
(1) Includes stock-based compensation expense as follows:

[0001596532-15-000004:mdna:50]
48

[0001596532-15-000004:mdna:51]
|  | Year Ended December 31, |
|  | 2014 |  | 2013 |  | 2012 |
| Stock-Based Compensation Expense: |  |  |  |  |  |
| Cost of revenue | $ | 1,535 |  |  | $ | 408 |  |  | $ | 270 |  |
| Research and development | 14,986 |  |  | 5,464 |  |  | 2,590 |  |
| Sales and marketing | 7,643 |  |  | 2,985 |  |  | 1,078 |  |
| General and administrative | 3,455 |  |  | 1,302 |  |  | 765 |  |
| Total stock-based compensation | $ | 27,619 |  |  | $ | 10,159 |  |  | $ | 4,703 |  |

[0001596532-15-000004:mdna:52]
Year Ended December 31, 2014 Compared to Year Ended December 31, 2013

[0001596532-15-000004:mdna:53]
Revenue, Cost of Revenue and Gross Profit (in thousands, except percentages)

[0001596532-15-000004:mdna:54]
|  | Year Ended December 31, |  |  |
|  | 2014 |  | 2013 |  | Change in |
|  | $ |  | % ofrevenue |  | $ |  | % ofrevenue |  | $ |  | % |
| Revenue | $ | 584,106 |  |  | 100.0 | % |  | $ | 361,224 |  |  | 100.0 | % |  | $ | 222,882 |  |  | 61.7 | % |
| Cost of revenue | 192,015 |  |  | 32.9 |  |  | 122,686 |  |  | 34.0 |  |  | 69,329 |  |  | 56.5 |  |
| Gross profit | $ | 392,091 |  |  | 67.1 | % |  | $ | 238,538 |  |  | 66.0 | % |  | $ | 153,553 |  |  | 64.4 | % |
| Gross margin | 67.1 | % |  |  |  | 66.0 | % |  |  |  |  |  |  |

[0001596532-15-000004:mdna:55]
Revenue. Revenue increased $222.9 million, or 61.7%, for the year ended December 31, 2014 compared to 2013.  The increase in revenue predominantly included an increase in sales of switch products and related accessories of $196.0 million, or 58.9%, primarily to existing customers. The increase in product revenue was largely driven by the number of switch ports shipped, which increased by 82.4% during the year ended December 31, 2014 compared to the same period in 2013, partially offset by a reduction of 15.0% in the average selling price per port shipped. The decrease in average selling price per port was primarily attributable to product mix and lower pricing terms for sales to large end customers. Our cumulative number of customers grew approximately 33% from December 31, 2013 to December 31, 2014 as we continued to broaden our market penetration.

[0001596532-15-000004:mdna:56]
Cost of Revenue. Cost of revenue increased $69.3 million, or 56.5%, for the year ended December 31, 2014 compared to 2013. The increase in cost of revenue was primarily due to the corresponding increase in revenue as our shipment volume significantly increased during the year ended December 31, 2014 resulting in an increase in product costs of $62.1 million during the year ended December 31, 2014 compared to the same period in 2013.

[0001596532-15-000004:mdna:57]
Gross Margin. Gross margin increased from 66.0% for the year ended December 31, 2013 to 67.1% for 2014. The increase in gross margin was primarily the result of a reduction in warranty and excess and obsolete inventory-related charges of $10.3 million due to significant product quality issues and inventory obsolescence charges that did not recur during 2014.  These charges were partially offset by an increase in manufacturing overhead charges of $7.4 million to support our revenue growth.  To a lesser extent, gross margin was negatively impacted by a decrease in product margins due to product mix and an increase in the size of orders with volume discounts.

[0001596532-15-000004:mdna:58]
Operating Expenses (in thousands, except percentages)

[0001596532-15-000004:mdna:59]
|  | Year Ended December 31, |  |  |
|  | 2014 |  | 2013 |  | Change in |
|  | $ |  | % ofrevenue |  | $ |  | % ofrevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 148,909 |  |  | 25.5 | % |  | $ | 98,587 |  |  | 27.3 | % |  | $ | 50,322 |  |  | 51.0 | % |
| Sales and marketing | 85,338 |  |  | 14.6 |  |  | 55,115 |  |  | 15.3 |  |  | 30,223 |  |  | 54.8 |  |
| General and administrative | 32,331 |  |  | 5.5 |  |  | 18,688 |  |  | 5.2 |  |  | 13,643 |  |  | 73.0 |  |
| Total operating expenses | $ | 266,578 |  |  | 45.6 | % |  | $ | 172,390 |  |  | 47.8 | % |  | $ | 94,188 |  |  | 54.6 | % |

[0001596532-15-000004:mdna:60]
Research and development. Research and development expenses increased $50.3 million, or 51.0%, for the year ended December 31, 2014 compared to  2013. The increase was primarily due to an increase in personnel costs of $39.0 million, resulting from an increase of 156 employees (a 34.1% increase) from December 31, 2013 to December 31, 2014, and additional bonus expenses under our corporate bonus plan. The increase was also due to an increase of $6.6 million in research and development related facilities and IT infrastructure costs, and increases in third-party engineering costs of $5.9 million and depreciation expense of $2.0 million, as we continued to expand and support our research and development activities. These expenses were partially offset by a $4.3 million reduction in prototype spending related to project timing.

[0001596532-15-000004:mdna:61]
Sales and marketing. Sales and marketing expenses increased $30.2 million, or 54.8%, for the year ended December 31, 2014 compared to 2013. The increase was primarily due to an increase in personnel costs of $23.4 million, resulting from an increase of 45 employees (a 23.0% increase) from December 31, 2013 to December 31, 2014, as well as an increase in sales commissions resulting from higher sales volume. The increase was also due to an increase of $3.7 million in product demonstrations, expenses incurred to expand our sales engineering labs to support our growing customer base, consulting expenses, and other marketing activities, and an increase in IT and infrastructure of $1.6 million.

[0001596532-15-000004:mdna:62]
General and administrative. General and administrative expenses increased $13.6 million, or 73.0%, for the year ended December 31, 2014 compared to 2013. The increase was primarily due to an increase in personnel costs of $5.7 million, resulting from an increase of 17 employees (a 29.8% increase) from December 31, 2013 to December 31, 2014, and additional expenses under our corporate bonus plan. We also incurred higher professional service fees of $3.7 million related to outside legal, accounting and consulting services to support increased business activity, litigation and public-company activities. The increase was also attributable to higher insurance expense and property taxes of $1.5 million associated with being a public company, and a $1.0 million charitable donation through a fund established by the Company in 2014.

[0001596532-15-000004:mdna:63]
Other Income (Expense), Net (in thousands, except percentages)

[0001596532-15-000004:mdna:64]
|  | Year Ended December 31, |  | Change in |
|  | 2014 |  | 2013 |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (6,280 | ) |  | $ | (7,119 | ) |  | $ | 839 |  |  | (11.8 | )% |
| Other income (expense), net | 2,275 |  |  | (754 | ) |  | 3,029 |  |  | NM |  |
| Total other income (expense), net | $ | (4,005 | ) |  | $ | (7,873 | ) |  | $ | 3,868 |  |  | (49.1 | )% |

[0001596532-15-000004:mdna:65]
Interest expense. Interest expense decreased during the year ended December 31, 2014 compared to the same period in 2013 as a result of repayment and conversion of our notes payable upon our IPO during the second quarter of 2014.

[0001596532-15-000004:mdna:66]
Other income (expense), net. Other income (expense), net increased for the year ended December 31, 2014, compared to 2013 due to the gain on our notes receivable of $4.0 million offset by a $0.7 million write-off related to the debt discount on notes payable upon our IPO, further offset by net transactional exchange rate losses.

[0001596532-15-000004:mdna:67]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-15-000004:mdna:68]
|  | Year Ended December 31, |  | Change in |
|  | 2014 |  | 2013 |  | $ |  | % |
| Provision for income taxes | $ | 34,658 |  |  | $ | 15,815 |  |  | $ | 18,843 |  |  | 119.1 | % |
| Effective tax rate | 28.5 | % |  | 27.1 | % |  |  |  |  |

[0001596532-15-000004:mdna:69]
Provision for income taxes. Provision for income taxes was approximately $34.7 million and $15.8 million for the years ended December 31, 2014 and 2013, respectively.  Provision for income taxes increased $18.8 million, or 119.1%, for the year ended December 31, 2014 compared to 2013. The change in our provision for income taxes was primarily due to an increase in profit before income tax.  The change in the effective tax rate was a result of the geographical distribution of the earnings, the federal research and development ("R&D") tax credit for 2014 including only a current year benefit, as compared to a two-year federal R&D tax credit benefit for 2013,  and an increase in state taxes.

[0001596532-15-000004:mdna:70]
The effective tax rate for the year ended December 31, 2014 included the impact of the reinstatement of the 2014 R&D credit.  The impact of the 2014 federal R&D tax credit benefit was recorded in the fourth quarter of the year ended December 31, 2014. The effective tax rate for the year ended December 31, 2013 included the impact of the reinstatement of the 2013 and 2012 federal R&D tax credits.

[0001596532-15-000004:mdna:71]
Year Ended December 31, 2013 Compared to Year Ended December 31, 2012

[0001596532-15-000004:mdna:72]
Revenue, Cost of Revenue and Gross Profit (in thousands, except percentages)

[0001596532-15-000004:mdna:73]
|  | Year Ended December 31, |  |  |
|  | 2013 |  | 2012 |  | Change in |
|  | $ |  | % ofrevenue |  | $ |  | % ofrevenue |  | $ |  | % |
| Revenue | $ | 361,224 |  |  | 100.0 | % |  | $ | 193,408 |  |  | 100.0 | % |  | $ | 167,816 |  |  | 86.8 | % |
| Cost of revenue | 122,686 |  |  | 34.0 |  |  | 61,252 |  |  | 31.7 |  |  | 61,434 |  |  | 100.3 |  |
| Gross profit | $ | 238,538 |  |  | 66.0 | % |  | $ | 132,156 |  |  | 68.3 | % |  | $ | 106,382 |  |  | 80.5 | % |
| Gross margin | 66.0 | % |  |  |  | 68.3 | % |  |  |  |  |  |  |

[0001596532-15-000004:mdna:74]
Revenue. Revenue increased $167.8 million, or 86.8%, for the year ended December 31, 2013 compared to 2012. The increase in revenue predominantly included an increase in sales of switch products and related accessories of $153.2 million, or 85.3%, primarily to existing customers as these customers purchased our newer products to further evolve their data centers. Our revenue also increased to a lesser extent due to sales to new customers. The increase in product revenue was largely driven by number of switch ports shipped which increased by 109.2%, during 2013 compared to the prior year. This increase was partially offset by a reduction of 10% in the average selling price per port shipped. The decrease in the average selling price per port was primarily attributable to lower pricing terms for sales to our large end customers. Our cumulative number of customers grew approximately 43.2% from December 31, 2012 to December 31, 2013 as we continued to broaden our market penetration.

[0001596532-15-000004:mdna:75]
Cost of revenue. Cost of revenue increased $61.4 million, or 100.3%, for the year ended December 31, 2013 compared to 2012. The increase in cost of revenue was primarily due to the corresponding increase in revenue as our shipment volume significantly increased during the year ended December 31, 2013 resulting in an increase in product costs of $46.5 million in 2013 compared to 2012. The increase was also due to an increase of $1.8 million in excess and obsolete material charges for non-cancelable and non-returnable purchase commitments by our third-party contract manufacturers, as well as an increase in write-downs of excess and obsolete inventory of $2.1 million from the introduction of new products and product enhancements We also experienced an increase in manufacturing overhead costs of $4.3 million to support the growth in production during the year ended 2013.

[0001596532-15-000004:mdna:76]
Gross margin. Gross margin decreased approximately two percentage points from 68.3% for the year ended December 31, 2012 to 66.0% for 2013. The decrease in gross margin was primarily due to an increase in excess and obsolete inventory and material charges noted above totaling $3.9 million, and an increase in manufacturing overhead costs of $4.3 million. The decrease was also due, to a lesser extent, to an increase in the size of contracts with large end customers with lower margins, which was partially offset by cost reductions primarily due to more favorable component pricing from our contract manufacturers as we increased volume.

[0001596532-15-000004:mdna:77]
Operating Expenses (in thousands, except percentages)

[0001596532-15-000004:mdna:78]
|  | Year Ended December 31, |  |  |
|  | 2013 |  | 2012 |  | Change in |
|  | $ |  | % ofrevenue |  | $ |  | % ofrevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 98,587 |  |  | 27.3 | % |  | $ | 55,155 |  |  | 28.5 | % |  | $ | 43,432 |  |  | 78.7 | % |
| Sales and marketing | 55,115 |  |  | 15.3 |  |  | 28,603 |  |  | 14.8 |  |  | 26,512 |  |  | 92.7 |  |
| General and administrative | 18,688 |  |  | 5.2 |  |  | 8,501 |  |  | 4.4 |  |  | 10,187 |  |  | 119.8 |  |
| Total operating expenses | $ | 172,390 |  |  | 47.8 | % |  | $ | 92,259 |  |  | 47.7 | % |  | $ | 80,131 |  |  | 86.9 | % |

[0001596532-15-000004:mdna:79]
Research and development. Research and development expenses increased $43.4 million, or 78.7%, for the year ended December 31, 2013 compared to 2012. The increase was primarily due to an increase in personnel costs of $21.8 million, which was a result of an increase of 153 employees (a 50.0% increase) in research and development headcount. The increase was also due to a $10.1 million increase in prototype expenses as a result of new product introductions and an increase in facilities expenses of $4.5 million.

[0001596532-15-000004:mdna:80]
Sales and marketing. Sales and marketing expenses increased $26.5 million, or 92.7%, for the year ended December 31, 2013 compared to 2012. The increase was primarily due to an increase in personnel costs of $19.8 million, which was a result of an increase of 57 employees (a 41.3% increase) in sales and marketing headcount. The increase was also due to an increase of $3.0 million in marketing, consulting and promotional expense related to trade shows, product demonstrations and other marketing activities and an increase in sales and marketing-related IT and system engineering expenses of $2.6 million.

[0001596532-15-000004:mdna:81]
General and administrative. General and administrative expenses increased $10.2 million, or 119.8%, for the year ended December 31, 2013 compared to 2012. The increase was primarily due to a $5.5 million increase in professional service fees related to outside legal, accounting, consulting and IT services to support increased business activity and preparations for becoming a public company. The increase was also due to a $3.4 million increase in personnel costs, which was a result of an increase of 23 employees (a 67.6% increase) in general and administrative headcount.

[0001596532-15-000004:mdna:82]
Other Income (Expense), Net (in thousands, except percentages)

[0001596532-15-000004:mdna:83]
|  | Year Ended December 31, |  | Change in |
|  | 2013 |  | 2012 |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | $ | (7,119 | ) |  | $ | (7,057 | ) |  | $ | (62 | ) |  | 0.9 | % |
| Other income (expense), net | (754 | ) |  | 135 |  |  | (889 | ) |  | NM |  |
| Total other income (expense), net | $ | (7,873 | ) |  | $ | (6,922 | ) |  | $ | (951 | ) |  | 13.7 | % |

[0001596532-15-000004:mdna:84]
Interest expense. Interest expense was consistent for the year ended December 31, 2013 compared to 2012.

[0001596532-15-000004:mdna:85]
Other income (expense), net. Other income (expense), net decreased $1.0 million for the year ended December 31, 2013 compared to 2012.

[0001596532-15-000004:mdna:86]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-15-000004:mdna:87]
|  | Year Ended December 31, |  | Change in |
|  | 2013 |  | 2012 |  | $ |  | % |
| Provision for income taxes | $ | 15,815 |  |  | $ | 11,626 |  |  | $ | 4,189 |  |  | 36.0 | % |
| Effective tax rate | 27.1 | % |  | 35.3 | % |  |  |  |  |

[0001596532-15-000004:mdna:88]
Provision for income taxes. Provision for income taxes increased $4.2 million, or 36.0%, for the year ended December 31, 2013 compared to 2012. Our effective tax rate decreased 8.2 percentage points from 35.3% for the year ended December 31, 2012 to 27.1% for 2013. The decrease in the effective tax rate was primarily due to the beneficial impact of the passage of the American Tax Relief Act of 2012 signed into law on January 2, 2013, which reinstated the federal research and development credit. The prior year impact of the 2012 federal research and development tax credit benefit was recorded in the three months ended March 31, 2013.

[0001596532-15-000004:mdna:89]
Quarterly Results of Operations

[0001596532-15-000004:mdna:90]
The following tables set forth selected unaudited quarterly consolidated statements of operations data for each of the quarters in the years ended December 31, 2014 and December 31, 2013, as well as the percentage that each line item represents of total revenue. The information for each of these quarters has been prepared on the same basis as the audited annual financial statements included elsewhere in this Annual Report on Form 10-K and, in the opinion of management, includes all adjustments, which includes only normal recurring adjustments, necessary for the fair presentation of the results of operations for these periods in accordance with GAAP. This data should be read in conjunction with our audited consolidated financial statements and related notes included in Item 8 of this Annual Report on Form 10-K.

[0001596532-15-000004:mdna:91]
|  |  | Three Months Ended |
|  |  | Dec. 31, 2014 |  | Sep. 30, 2014 |  | Jun. 30, 2014 |  | Mar. 31, 2014 |  | Dec. 31, 2013 |  | Sep. 30, 2013 |  | Jun. 30, 2013 |  | Mar. 31, 2013 |
|  |  | (in thousands) |
| Consolidated Statements of Operations Data: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue |  | $ | 173,489 |  |  | $ | 155,463 |  |  | $ | 137,947 |  |  | $ | 117,207 |  |  | $ | 114,766 |  |  | $ | 101,625 |  |  | $ | 83,485 |  |  | $ | 61,348 |  |
| Cost of revenue |  | 57,049 |  |  | 54,506 |  |  | 44,567 |  |  | 35,893 |  |  | 37,293 |  |  | 36,589 |  |  | 29,584 |  |  | 19,220 |  |
| Gross profit |  | 116,440 |  |  | 100,957 |  |  | 93,380 |  |  | 81,314 |  |  | 77,473 |  |  | 65,036 |  |  | 53,901 |  |  | 42,128 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | 44,344 |  |  | 36,231 |  |  | 34,888 |  |  | 33,446 |  |  | 31,352 |  |  | 26,635 |  |  | 21,086 |  |  | 19,514 |  |
| Sales and marketing |  | 25,016 |  |  | 20,956 |  |  | 20,711 |  |  | 18,655 |  |  | 17,412 |  |  | 14,523 |  |  | 13,045 |  |  | 10,135 |  |
| General and administrative |  | 8,078 |  |  | 9,896 |  |  | 7,126 |  |  | 7,231 |  |  | 6,204 |  |  | 5,242 |  |  | 3,506 |  |  | 3,736 |  |
| Total operating expenses |  | 77,438 |  |  | 67,083 |  |  | 62,725 |  |  | 59,332 |  |  | 54,968 |  |  | 46,400 |  |  | 37,637 |  |  | 33,385 |  |
| Income from operations |  | 39,002 |  |  | 33,874 |  |  | 30,655 |  |  | 21,982 |  |  | 22,505 |  |  | 18,636 |  |  | 16,264 |  |  | 8,743 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | (768 | ) |  | (764 | ) |  | (1,435 | ) |  | (1,771 | ) |  | (1,799 | ) |  | (1,797 | ) |  | (1,772 | ) |  | (1,751 | ) |
| Other income (expense), net |  | (151 | ) |  | (824 | ) |  | 2,472 |  |  | (764 | ) |  | (631 | ) |  | (23 | ) |  | (1 | ) |  | (99 | ) |
| Total other income (expense), net |  | (919 | ) |  | (1,588 | ) |  | 1,037 |  |  | (2,535 | ) |  | (2,430 | ) |  | (1,820 | ) |  | (1,773 | ) |  | (1,850 | ) |
| Income before provision for income taxes |  | 38,083 |  |  | 32,286 |  |  | 31,692 |  |  | 19,447 |  |  | 20,075 |  |  | 16,816 |  |  | 14,491 |  |  | 6,893 |  |
| Provision for income taxes |  | 7,046 |  |  | 10,420 |  |  | 10,074 |  |  | 7,118 |  |  | 6,333 |  |  | 4,960 |  |  | 4,240 |  |  | 282 |  |
| Net income |  | $ | 31,037 |  |  | $ | 21,866 |  |  | $ | 21,618 |  |  | $ | 12,329 |  |  | $ | 13,742 |  |  | $ | 11,856 |  |  | $ | 10,251 |  |  | $ | 6,611 |  |

[0001596532-15-000004:mdna:92]
52

[0001596532-15-000004:mdna:93]
|  |  | Three Months Ended |
|  |  | Dec. 31, 2014 |  | Sep. 30, 2014 |  | Jun. 30, 2014 |  | Mar. 31, 2014 |  | Dec. 31, 2013 |  | Sep. 30, 2013 |  | Jun. 30, 2013 |  | Mar. 31, 2013 |
|  |  | (As a percentage of revenue) |
| Consolidated Statements of Operations Data: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenue |  | 32.9 |  |  | 35.1 |  |  | 32.3 |  |  | 30.6 |  |  | 32.5 |  |  | 36.0 |  |  | 35.4 |  |  | 31.3 |  |
| Gross profit |  | 67.1 |  |  | 64.9 |  |  | 67.7 |  |  | 69.4 |  |  | 67.5 |  |  | 64.0 |  |  | 64.6 |  |  | 68.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | 25.6 |  |  | 23.3 |  |  | 25.3 |  |  | 28.5 |  |  | 27.3 |  |  | 26.2 |  |  | 25.3 |  |  | 31.8 |  |
| Sales and marketing |  | 14.4 |  |  | 13.5 |  |  | 15.0 |  |  | 15.9 |  |  | 15.2 |  |  | 14.3 |  |  | 15.6 |  |  | 16.5 |  |
| General and administrative |  | 4.7 |  |  | 6.4 |  |  | 5.2 |  |  | 6.2 |  |  | 5.4 |  |  | 5.2 |  |  | 4.2 |  |  | 6.1 |  |
| Total operating expenses |  | 44.7 |  |  | 43.2 |  |  | 45.5 |  |  | 50.6 |  |  | 47.9 |  |  | 45.7 |  |  | 45.1 |  |  | 54.4 |  |
| Income from operations |  | 22.4 |  |  | 21.7 |  |  | 22.2 |  |  | 18.8 |  |  | 19.6 |  |  | 18.3 |  |  | 19.5 |  |  | 14.3 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | (0.4 | ) |  | (0.5 | ) |  | (1.0 | ) |  | (1.5 | ) |  | (1.6 | ) |  | (1.8 | ) |  | (2.1 | ) |  | (2.9 | ) |
| Other income (expense), net |  | (0.1 | ) |  | (0.5 | ) |  | 1.8 |  |  | (0.7 | ) |  | (0.5 | ) |  | — |  |  | — |  |  | (0.2 | ) |
| Total other income (expense), net |  | (0.5 | ) |  | (1.0 | ) |  | 0.8 |  |  | (2.2 | ) |  | (2.1 | ) |  | (1.8 | ) |  | (2.1 | ) |  | (3.1 | ) |
| Income before provision for income taxes |  | 21.9 |  |  | 20.7 |  |  | 23.0 |  |  | 16.6 |  |  | 17.5 |  |  | 16.5 |  |  | 17.4 |  |  | 11.2 |  |
| Provision for income taxes |  | 4.1 |  |  | 6.7 |  |  | 7.3 |  |  | 6.1 |  |  | 5.5 |  |  | 4.8 |  |  | 5.1 |  |  | 0.4 |  |
| Net income |  | 17.8 | % |  | 14.0 | % |  | 15.7 | % |  | 10.5 | % |  | 12.0 | % |  | 11.7 | % |  | 12.3 | % |  | 10.8 | % |

[0001596532-15-000004:mdna:94]
Liquidity and Capital Resources

[0001596532-15-000004:mdna:95]
Our principal sources of liquidity are cash and cash equivalents, marketable securities, and cash generated from operations. As of December 31, 2014, cash and cash equivalents and marketable securities were $449.5 million of which approximately $56.6 million was held outside the U.S. in our foreign subsidiaries. We have not repatriated nor do we currently have plans to repatriate these funds, but if we were to repatriate cash held outside of the U.S. for domestic cash operations, we would be required to accrue and pay U.S. income taxes to repatriate these funds less any previously paid foreign income taxes. We consider the undistributed earnings of our foreign subsidiaries as of December 31, 2014 to be indefinitely reinvested, and, accordingly, no U.S. income taxes have been provided thereon.

[0001596532-15-000004:mdna:96]
On June 6, 2014, we completed our IPO in which we sold 6,037,500 shares of our common stock at a public offering price of $43.00 per share, which included 787,500 shares of common stock issued pursuant to the exercise in full of the over-allotment option by the underwriters. The IPO resulted in proceeds of $239.1 million, net of underwriting discounts and commissions of $15.6 million and other issuance costs of $5.0 million. In connection with the closing of the IPO, all of our outstanding convertible preferred stock automatically converted into 24,000,000 shares of common stock on a one-to-one basis.

[0001596532-15-000004:mdna:97]
Upon the closing of our IPO, all noteholders with the exception of one noteholder converted the principal and accrued interest amount outstanding under their subordinated convertible promissory notes into shares of our common stock at the IPO price of $43.00 per share. The noteholder, who did not elect to so convert, was paid a total of $23.6 million which included principal and accrued interest less applicable withholding taxes of $1.1 million. The remainder of the noteholders converted the remaining debt balance of approximately $96.5 million including principal and accrued interest into 2.2 million shares of our common stock.

[0001596532-15-000004:mdna:98]
Our cash and cash equivalents and marketable securities are held for working capital purposes.  We plan to continue to invest for long-term growth. One of the principal purposes of our IPO was to obtain additional capital to fund the growth of our business. We believe that our existing cash and cash equivalents together with cash flow from operations will be sufficient to meet our working capital requirements and our growth strategies for the foreseeable future. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs and access to outsourcing our manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies as well as the continued market acceptance of our products. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us. If we are required and unable to raise additional capital when desired, our business, operating results, and financial condition may be adversely affected.

[0001596532-15-000004:mdna:99]
Cash Flows

[0001596532-15-000004:mdna:100]
|  | December 31, |
|  | 2014 |  | 2013 |
|  | (in thousands) |
| Cash and cash equivalents | $ | 240,031 |  |  | $ | 113,664 |  |

[0001596532-15-000004:mdna:101]
|  |  | Year Ended December 31, |
|  |  | 2014 |  | 2013 |  | 2012 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 114,516 |  |  | $ | 34,648 |  |  | $ | 26,306 |  |
| Cash used in investing activities |  | (249,362 | ) |  | (19,491 | ) |  | (12,352 | ) |
| Cash provided by financing activities |  | 261,337 |  |  | 9,886 |  |  | 3,977 |  |
| Effect of exchange rate changes |  | (124 | ) |  | (34 | ) |  | (1 | ) |
| Net increase in cash and cash equivalents |  | $ | 126,367 |  |  | $ | 25,009 |  |  | $ | 17,930 |  |

[0001596532-15-000004:mdna:102]
Cash Flows from Operating Activities

[0001596532-15-000004:mdna:103]
Our primary source of cash from operating activities has been from cash collections from our customers. We expect cash inflows from operating activities to be affected by increases in sales and timing of collections. Our primary uses of cash from operating activities have been for personnel costs and investment in sales and marketing and research and development. We expect cash outflows from operating activities to increase as a result of further investment in sales and marketing and increases in personnel costs as we grow our business.

[0001596532-15-000004:mdna:104]
During the year ended December 31, 2014, cash provided by operating activities was $114.5 million primarily from net income of $86.9 million, net non-cash charges of $11.8 million, and an increase of $15.8 million due to changes in our operating assets and liabilities. The increase in cash from operating assets and liabilities was primarily due an increase in deferred revenue of $47.6 million resulting from the increase in sales, an increase in accrued liabilities of $18.9 million largely related to our payroll and corporate bonus plan and an increase in accounts payable of $14.0 million due to the timing of our payments, partially offset by a reduction in cash from an increase in accounts receivable of $19.8 million from higher products shipments, an increase in inventories of $13.4 million to meet our customer demand and an increase in prepaid expenses and other current assets of $32.6 million primarily due to higher prepaid taxes, and supplier rebates resulting from our increased inventory purchases.

[0001596532-15-000004:mdna:105]
During the year ended December 31, 2013, cash provided by operating activities was $34.6 million, primarily from net income of $42.5 million and non-cash charges of $6.8 million, partially offset by a decrease of $14.6 million due to changes in our operating assets and liabilities. The decrease in cash from operating assets and liabilities was primarily due to a $49.2 million increase in inventory for anticipated growth in our business, a $28.3 million increase in accounts receivable due to an increase in sales partially offset by an increase in cash from a $3.0 million decrease in prepaid expenses and other current assets, partially offset by an increase in cash from a $3.9 million increase in accounts payable primarily attributable to the timing of payments, a $12.0 million increase in accrued liabilities attributable to higher warranty liabilities and higher accrued personnel costs due to growth in headcount, a $34.1 million increase in deferred revenue due to increased sales and a $6.0 million increase in interest payable attributable to our outstanding convertible promissory notes, including our related party convertible promissory notes.

[0001596532-15-000004:mdna:106]
During the year ended December 31, 2012, cash provided by operating activities was $26.3 million, consisting of net income of $21.3 million adjusted by non-cash charges of $4.0 million and a $0.9 million increase due to changes in our operating assets and liabilities. The increase in cash from operating assets and liabilities was primarily due to a $22.0 million increase in accounts receivable due to an increase in sales, a $7.2 million increase in inventory and a $5.0 million increase in prepaid expenses and other current assets, partially offset by a $13.5 million increase in deferred revenue due to increased sales, a $6.5 million increase in accrued liabilities attributable to higher warranty liabilities and higher accrued personnel costs due to growth in headcount and a $6.0 million increase in interest payable attributable to our outstanding convertible promissory notes, including our related party convertible promissory notes.

[0001596532-15-000004:mdna:107]
Cash Flows from Investing Activities

[0001596532-15-000004:mdna:108]
Our investing activities have consisted primarily of purchases of property and equipment. We expect to continue to make purchases of property and equipment to support continued growth of our business.

[0001596532-15-000004:mdna:109]
During the year ended December 31, 2014, cash used in investing activities was $249.4 million, consisting primarily of purchases of marketable securities of $210.0 million, purchases of property and equipment of $13.1 million and other investing activities of $38.2 million largely due to a $33.6 million equity investments in privately held companies, partially offset by the proceeds of the repayments of our notes receivable of $8.0 million and the release of our restricted cash into cash and cash equivalents of $4.0 million.

[0001596532-15-000004:mdna:110]
During the year ended December 31, 2013, cash used in investing activities was $19.5 million, of which $20.3 million relates to the purchase of property and equipment offset by notes receivable repayments of $1.0 million.

[0001596532-15-000004:mdna:111]
During the year ended December 31, 2012, cash used in investing activities was $12.4 million, of which $3.3 million relates to purchases of property and equipment, $5.0 million relates to an investment in a private company and $4.0 million relates to an increase in restricted cash representing a security deposit required for a facility lease.

[0001596532-15-000004:mdna:112]
Cash Flows from Financing Activities

[0001596532-15-000004:mdna:113]
Our cash flows provided by financing activities primarily consisted of proceeds from the IPO and exercises of stock options partially offset by repayment of our subordinated convertible promissory notes.

[0001596532-15-000004:mdna:114]
During the year ended December 31, 2014, cash provided by financing activities was $261.3 million, consisting primarily of net proceeds raised from our IPO of $239.3 million, proceeds from the exercise of stock options, net of repurchases of $25.4 million and excess tax benefits from our incentive plans amounting to $17.4 million. These proceeds were partially offset by the repayment of our notes payable of $20.0 million.

[0001596532-15-000004:mdna:115]
During the year ended December 31, 2013, cash provided by financing activities was $9.9 million, consisting primarily of proceeds from the exercise of stock options, net of repurchases, amounting to $9.0 million and excess tax benefits realized from our equity incentive plans amounting to $0.9 million.

[0001596532-15-000004:mdna:116]
During the year ended December 31, 2012, cash provided by financing activities was $4.0 million, consisting primarily of $3.9 million in proceeds from the exercise of common stock options, net of repurchases.

[0001596532-15-000004:mdna:117]
Debt Obligations

[0001596532-15-000004:mdna:118]
In January 2011, we sold $55.0 million aggregate principal amount of subordinated convertible promissory notes, or Convertible Notes, to outside investors and $25.0 million aggregate principal amount of Convertible Notes to two trusts that are related to two of our co-founders. In June 2011, we sold an additional $20.0 million aggregate principal amount of Convertible Notes to outside investors. The interest rate on the Convertible Notes was 6.0% per annum, computed on the basis of the actual number of days elapsed and a year of 365 days. Upon the closing of our IPO, all noteholders with the exception of one noteholder converted the principal and accrued interest amount outstanding under their subordinated convertible promissory notes into shares of our common stock at the IPO price of $43.00 per share. The noteholder, who did not elect to so convert, was paid a total of $23.6 million which included principal and accrued interest less applicable withholding taxes of $1.1 million. The remainder of the noteholders converted the remaining debt balance of approximately $96.5 million including principal and accrued interest into 2.2 million shares of our common stock.

[0001596532-15-000004:mdna:119]
Off-Balance Sheet Arrangements

[0001596532-15-000004:mdna:120]
As of December 31, 2014, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-15-000004:mdna:121]
Contractual Obligations and Commitments

[0001596532-15-000004:mdna:122]
Our contractual commitments will have an impact on our future liquidity. Our contractual obligations represent material expected or contractually committed future obligations with terms in excess of one year. We believe that we will be able to fund these obligations through cash generated from operations and from our existing cash balances.

[0001596532-15-000004:mdna:123]
The following summarizes our contractual obligations and commitments as of December 31, 2014 (in thousands):

[0001596532-15-000004:mdna:124]
|  |  | Payments Due by Period |
|  |  | Total |  | Less than1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than5 Years |
| Financing lease obligation1 |  | $ | 54,968 |  |  | $ | 5,588 |  |  | $ | 17,800 |  |  | $ | 12,769 |  |  | $ | 18,811 |  |
| Operating lease obligations |  | 45,189 |  |  | 2,583 |  |  | 14,830 |  |  | 10,901 |  |  | 16,875 |  |
| Total |  | $ | 100,157 |  |  | $ | 8,171 |  |  | $ | 32,630 |  |  | $ | 23,670 |  |  | $ | 35,686 |  |

[0001596532-15-000004:mdna:125]
_________________

[0001596532-15-000004:mdna:126]
1Includes interest and land lease

[0001596532-15-000004:mdna:127]
The contractual obligation table above excludes tax liabilities of $18.6 million related to uncertain tax positions because we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-15-000004:mdna:128]
Critical Accounting Policies and Estimates

[0001596532-15-000004:mdna:129]
We have prepared our consolidated financial statements in accordance with GAAP and include our accounts and the accounts of our wholly owned subsidiaries. The preparation of these consolidated financial statements requires our management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities at the date of the financial statements, disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the applicable periods. We base our estimates, assumptions and judgments on historical experience and on various other factors that we believe to be reasonable under the circumstances. Different assumptions and judgments would change the estimates used in the preparation of our consolidated financial statements, which, in turn, could change the results from those reported. We evaluate our estimates, assumptions and judgments on an ongoing basis. The critical accounting estimates, assumptions and judgments that we believe have the most significant impact on our consolidated financial statements are described below.

[0001596532-15-000004:mdna:130]
Revenue Recognition

[0001596532-15-000004:mdna:131]
We generate revenue from the sale of network switches which incorporate our EOS software and accessories such as cables and optics to direct customers and channel partners together with PCS. We typically sell products and PCS in a single transaction. We recognize revenue when all of the following criteria are met: persuasive evidence of an arrangement exists, delivery or performance has occurred, the sales price is fixed or determinable and collectability is reasonably assured.

[0001596532-15-000004:mdna:132]
We define each of the four criteria above as follows:

[0001596532-15-000004:mdna:133]
•Persuasive evidence of an arrangement exists. Evidence of an arrangement consists of stand-alone purchase orders or purchase orders issued pursuant to the terms and conditions of a master sales agreement. It is our practice to identify an end customer prior to shipment to a reseller or distributor.

[0001596532-15-000004:mdna:134]
•Delivery or performance has occurred. We use shipping documents or written evidence of customer acceptance, when applicable, to verify delivery or performance. We recognize product revenue upon transfer of title and risk of loss, which primarily is upon shipment to customers. We generally do not have significant obligations for future performance, rights of return, pricing credits or customer acceptance provisions associated with our product sales. In instances where substantive acceptance provisions are specified in the customer arrangement, revenue is deferred until all acceptance criteria have been met.

[0001596532-15-000004:mdna:135]
•The sales price is fixed or determinable. We assess whether the sales price is fixed or determinable based on payment terms and whether the sales price is subject to refund or adjustment.

[0001596532-15-000004:mdna:136]
•Collectability is reasonably assured. We assess probability of collectability on a customer-by-customer basis. Our customers and channel partners are subjected to a credit review process that evaluates their financial condition and ability to pay for products and services.

[0001596532-15-000004:mdna:137]
PCS is offered under renewable, fee-based contracts, which include technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis. We initially defer PCS revenue and recognize it ratably over the life of the PCS contract, with the related expenses recognized as incurred. PCS contracts usually have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-15-000004:mdna:138]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of goods sold.

[0001596532-15-000004:mdna:139]
Multiple-Element Arrangements

[0001596532-15-000004:mdna:140]
Most of our arrangements, other than renewals of PCS, are multiple-element arrangements with a combination of products and PCS. Products and PCS generally qualify as separate units of accounting. Our hardware deliverables and included EOS software together deliver the essential functionality of our products. For multiple-element arrangements, we allocate revenue to each unit of accounting based on the relative selling price. The relative selling price for each element is based upon the following hierarchy: vendor-specific objective evidence, or VSOE, if available; third-party evidence, or TPE, if VSOE is not available; and best estimate of selling price, or BESP, if neither VSOE nor TPE is available. As we have not been able to establish VSOE or TPE for our products and most of our services, we generally utilize BESP for the purposes of allocating revenue to each unit of accounting.

[0001596532-15-000004:mdna:141]
| • | VSOE—We determine VSOE based on our historical pricing and discounting practices for the specific products and services when sold separately. In determining VSOE, we require that a substantial majority of the stand-alone selling prices fall within a reasonably narrow pricing range. |

[0001596532-15-000004:mdna:142]
| • | TPE—When VSOE cannot be established for deliverables in multiple-element arrangements, we apply judgment with respect to whether we can establish a selling price based on TPE. TPE is determined based on competitor prices for interchangeable products or services when sold separately to similarly situated customers. However, as our products contain a significant element of proprietary technology and offer substantially different features and functionality, the comparable pricing of products with similar functionality typically cannot be obtained. Additionally, as we are unable to reliably determine what competitors products’ selling prices are on a stand-alone basis, we are not able to obtain reliable evidence of TPE of selling price. |

[0001596532-15-000004:mdna:143]
| • | BESP—When we are unable to establish selling price using VSOE or TPE, we use BESP in our allocation of arrangement consideration. The objective of BESP is to determine the price at which we would transact a sale if the product or service was sold regularly on a stand-alone basis. BESP is based on considering multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services were sold (domestic or international) and size of the end customer. |

[0001596532-15-000004:mdna:144]
We limit the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations, or subject to customer-specific return, acceptance or refund privileges.

[0001596532-15-000004:mdna:145]
We account for multiple agreements with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single arrangement.

[0001596532-15-000004:mdna:146]
We may occasionally accept returns to address customer satisfaction issues even though there is no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period gross revenues. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-15-000004:mdna:147]
Inventories

[0001596532-15-000004:mdna:148]
Inventories primarily consist of finished goods purchased from third party contract manufacturers and are stated at the lower of cost (computed using the first-in, first-out method) or market value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  In addition, we also purchase certain strategic component inventory, including integrated circuits which are consigned to our contract manufacturers. We record a provision when inventory is determined to be in excess of anticipated demand or obsolete to adjust inventory to its estimated realizable value.

[0001596532-15-000004:mdna:149]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and outside of our control, we may be required to increase our inventory write-downs and provisions for non-cancelable, non-returnable purchase commitments, which could have an adverse impact on our gross margins and profitability.

[0001596532-15-000004:mdna:150]
Warranty

[0001596532-15-000004:mdna:151]
We offer a one-year warranty on all of our hardware products and a 90-day warranty against defects in any software embedded in the products. We use judgment and estimates when determining warranty costs based on historical costs primarily to replace or repair product returns within the warranty period at the time we recognize revenue. We accrue specifically identified reserves if and when we determine we have a systemic product failure. Historically, we have identified specific products that failed in the field prematurely at higher than expected rates due to various component issues. Although we engage in extensive product quality programs, if actual product failure rates or use of materials differ from estimates, additional warranty costs may be incurred, which could reduce our gross margin.

[0001596532-15-000004:mdna:152]
Stock-Based Compensation

[0001596532-15-000004:mdna:153]
Compensation expense related to stock-based transactions, including stock options, restricted stock awards, or RSAs, and stock purchase rights, is measured and recognized in the financial statements based on the fair value of the awards granted. The fair value of each stock-based award is estimated on the grant date using the Black-Scholes-Merton option-pricing model. The stock-based compensation expense, net of forfeitures, is recognized on a straight-line basis over the requisite service periods of the awards, which is generally four years.

[0001596532-15-000004:mdna:154]
Our use of the Black-Scholes-Merton option-pricing model requires the input of highly subjective assumptions, including the fair value of the underlying common stock, the expected term of the option, the expected volatility of the price of our common stock, risk-free interest rates and the expected dividend yield of our common stock. The assumptions used in our option-pricing model represent management’s best estimates. These estimates involve inherent uncertainties and the application of management’s judgment. If factors change and different assumptions are used, our stock-based compensation expense could be materially different in the future.

[0001596532-15-000004:mdna:155]
These assumptions and estimates are as follows:

[0001596532-15-000004:mdna:156]
•Fair Value of Common Stock. Prior to our IPO, we estimated the fair value of common stock, based on numerous subjective and objective factors at each grant date.

[0001596532-15-000004:mdna:157]
•Expected Term. The expected term represents the period that our option awards are expected to be outstanding. We consider several factors in estimating the expected term of options granted, including the expected lives used by a peer group of companies within our industry that we consider to be comparable to our business, and the historical option exercise behavior of our employees, which we believe is representative of future behavior.

[0001596532-15-000004:mdna:158]
•Expected Volatility. The volatility is derived from the average historical stock volatilities of a peer group of public companies within our industry that we consider to be comparable to our business over a period equivalent to the expected term of the stock-based grants. We did not rely on implied volatilities of traded options in our industry peers’ common stock because the volume of activity was low. We intend to continue to consistently apply this process using the same or similar public companies

[0001596532-15-000004:mdna:159]
until a sufficient amount of historical information regarding the volatility of our own common stock share price becomes available, or unless circumstances change such that the identified companies are no longer similar to us, in which case, more suitable companies whose share prices are publicly available would be utilized in the calculation.

[0001596532-15-000004:mdna:160]
•Risk-Free Interest Rate. The risk-free interest rate is based on the U.S. Treasury yield curve in effect at the time of grant for zero-coupon U.S. Treasury notes with maturities approximately equal to the option’s expected term.

[0001596532-15-000004:mdna:161]
•Dividend Yield. We have never declared or paid any cash dividends and do not presently plan to pay cash dividends in the foreseeable future. Consequently, we used an expected dividend yield of zero.

[0001596532-15-000004:mdna:162]
In addition to the assumptions used in the Black-Scholes-Merton option-pricing model, we must also estimate a forfeiture rate to calculate the stock-based compensation expense for our awards. Our forfeiture rate is based on an analysis of our actual forfeitures. We will continue to evaluate the appropriateness of the forfeiture rate based on actual forfeiture experience, analysis of employee turnover and other factors. Changes in the estimated forfeiture rate can have a significant impact on our stock-based compensation expense as the cumulative effect of adjusting the rate is recognized in the period the forfeiture estimate is changed. We will continue to use judgment in evaluating the assumptions related to our stock-based compensation on a prospective basis. As we continue to accumulate additional data related to our common stock, we may have refinements to our estimates, which could materially impact our future stock-based compensation expense.

[0001596532-15-000004:mdna:163]
Income Taxes

[0001596532-15-000004:mdna:164]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-15-000004:mdna:165]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. We measure deferred income tax assets and liabilities using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-15-000004:mdna:166]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-15-000004:mdna:167]
Loss Contingencies

[0001596532-15-000004:mdna:168]
We use significant judgment and assumptions to estimate the likelihood of loss or the incurrence of a liability in determining loss contingencies. We accrue an estimated loss contingency when it is probable that a liability has been incurred and we can reasonably estimate the amount of loss. We record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.

[0001596532-15-000004:mdna:169]
Recent Accounting Pronouncements

[0001596532-15-000004:mdna:170]
Refer to “Recent Accounting Pronouncements” in Note 1 to Consolidated Financial Statements included in Part II, Item 8 of this Annual Report on Form 10-K.
