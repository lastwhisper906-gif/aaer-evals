# ANET MD&A — 0001596532-24-000043


## mdna

[0001596532-24-000043:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001596532-24-000043:mdna:2]
Overview

[0001596532-24-000043:mdna:3]
Arista Networks is an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments. Arista's platforms deliver availability, agility, automation, analytics and security through an advanced network operating stack. Since Arista’s inception, our founders have reimagined cloud networks for performance, scale and programmability with a focus on differentiating in three ways: uncompromising quality, advanced open and standards-based technology and a robust quality assurance capability built on a suite of automated diagnostics. At the core of Arista’s platform is Arista’s EOS, a modernized publish-subscribe state-sharing networking operating system. Arista EOS, combined with a set of network applications and our Ethernet switching and routing platforms using best of breed merchant silicon, provides customers with a highly competitive and diversified portfolio of products with improved price/performance and time to market.

[0001596532-24-000043:mdna:4]
We generate revenue primarily from sales of our switching and routing platforms, which incorporate our EOS software, and related network applications. We also generate revenue from post-contract support ("PCS"), which customers typically purchase in conjunction with our products, and renewals of PCS. We sell our products through both our direct sales force and our channel partners. Our customers span a range of industries and geographies including large cloud customers or hyperscalers, other internet providers, service providers, financial services organizations, government agencies and a cross section of enterprise customers. Over the past five years, we have diversified the types of enterprise customers we sell to and have continued to expand our presence across a wide spectrum of industries including media and entertainment, healthcare, oil and gas, education, manufacturing, industrial, and more.

[0001596532-24-000043:mdna:5]
Historically, large purchases by a relatively limited number of customers have accounted for a significant portion of our revenue. We have experienced unpredictability in the timing of orders from these large customers primarily due to the time it takes these customers to evaluate, test, qualify and accept our newer products, the overall complexity of these large orders and changes in demand patterns specific to these customers, including reductions in capital expenditures by these customers and the impact of cost reduction and other efficiency efforts by these customers. For example, sales to our end customers Microsoft and Meta Platforms represented 18% and 21% of our total revenue, respectively, in fiscal 2023, 16% and 26% of our total revenue, respectively, in fiscal 2022 and, 15% and less than 10% of our total revenue, respectively in fiscal 2021. This variability in customer concentration has been linked to the timing of new product deployments and spending cycles with these customers, and we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. In addition, an increased focus on the deployment of AI enabled solutions by these customers has accelerated the need for advanced technology offerings including some offerings from potential new market entrants.  This prioritization of AI related infrastructure investment has come in conjunction with the announcement of various cost reduction measures, including optimization and increased efficiency in non-AI related capital expenditures.  In some instances, such measures have had, and may continue to have, an impact on certain current or future projects and have reduced our visibility to customer demand, increased our risk of excess and obsolescence charges on existing products, and may result in reductions in future demand and negatively impact our revenue, financial condition, business or prospects. Furthermore, we typically provide pricing discounts to large customers, which reduces gross margins for the period in which such sales occur.

[0001596532-24-000043:mdna:6]
We believe that cloud computing represents a fundamental shift from traditional legacy network architectures. As organizations of all sizes have moved workloads to the cloud, spending on cloud and next-generation data centers has increased rapidly, while traditional legacy IT spending has grown at a slower rate. Our cloud networking platforms are well positioned to address the growing cloud networking market, and to address increasing performance requirements driven by the growing number of connected devices, as well as the need for constant connectivity and access to data and applications.

[0001596532-24-000043:mdna:7]
The markets for cloud networking solutions are highly competitive and characterized by rapidly changing technology, changing end-customer needs, evolving industry standards, frequent introductions of new products and services, and industry consolidation. We expect competition to intensify in the future as the market for cloud networking expands and existing competitors and new market entrants introduce new products or enhance existing products. Our future success is dependent upon our ability to continue to evolve and adapt to our rapidly changing environment. We must also continue to develop

[0001596532-24-000043:mdna:8]
market-leading products and features that address the needs of our existing and new customers, and increase sales in the enterprise data center switching, and campus workspace markets. We intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new customers more effectively, increase sales to existing customers, and provide services and support. In addition, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our ability to rapidly develop new features and applications.

[0001596532-24-000043:mdna:9]
Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic with respect to the underlying merchant silicon architecture. The programmability of EOS has allowed us to expand our software applications to address the ever-increasing demands of cloud networking, including workflow automation, network visibility, analytics and network detection and response, and has further allowed us to integrate rapidly with a wide range of third-party applications for virtualization, management, automation, orchestration and network services. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We work closely with third-party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third-party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-24-000043:mdna:10]
Macroeconomic Update

[0001596532-24-000043:mdna:11]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including inflation, monetary policy shifts, recession risks, and potential supply chain and other disruptions such as the Russia-Ukraine and Israel-Hamas conflicts, the Houthi attacks on marine vessels in the Red Sea, and the U.S. trade war with China.

[0001596532-24-000043:mdna:12]
As we exit 2023, the business is emerging from a period of unprecedented global supply chain disruptions.  Throughout this period, we made significant supply chain investments, including funding additional working capital and incremental purchase commitments in response to extended visibility to deployment plans from our customers. We have worked closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. This increased capacity has allowed us to ship products against previously committed demand/deployment plans and accelerate some deployments where needed, while trying to limit building customer inventory, and to some extent balancing customer lead times with those currently experienced from our key suppliers. As a result, some shipments against these previously committed demand/deployment plans have extended into 2024.

[0001596532-24-000043:mdna:13]
As the global supply chain has experienced some improvements and as customer lead times have been reduced from their peak, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to shorter demand-planning horizons resulting in lower demand levels. Given these shipment and order patterns, near term revenue trends may not be solely reflective of current demand levels, but as discussed above will benefit from demand/deployment plans that had been previously committed. While inventory and working capital levels may remain elevated in the near term, we expect that purchase commitments will continue to decline as supplier lead times shorten. The larger magnitude of these balances, combined with a reduction in customer demand-planning horizons and shifting customer product priorities, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted, and may in the future result, in additional  excess and obsolete inventory and supplier liability charges.

[0001596532-24-000043:mdna:14]
In addition, inflation pressure in our supply chain, scarcity of some materials needed to build our products and disruptions to our manufacturing process have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. Our operating cash-flows have also been and may continue to be negatively impacted by significant component inventories on hand or at our contract manufacturers. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the recent Russia-Ukraine conflict, continued escalation of this conflict as well as the Israeli-Hamas conflict and Houthi movement in the Red Sea may negatively impact the global economy and our future operating results and financial condition.

[0001596532-24-000043:mdna:15]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply

[0001596532-24-000043:mdna:16]
chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that some of our customers, following a year of elevated purchases, must now consider changing technology roadmaps and priorities, including the need for the rapid deployment of AI and related technologies, resulting in some uncertainty as to future investment plans and a more constrained approach to some forecasts and orders in the near term. In addition, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.

[0001596532-24-000043:mdna:17]
Results of Operations

[0001596532-24-000043:mdna:18]
Year Ended December 31, 2023 Compared to Year Ended December 31, 2022

[0001596532-24-000043:mdna:19]
Revenue, Cost of Revenue and Gross Margin (in thousands, except percentages)

[0001596532-24-000043:mdna:20]
|  |  | Year Ended December 31, |  |  |
|  |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,029,493 |  |  | 85.8 | % |  | $ | 3,716,079 |  |  | 84.8 | % |  | $ | 1,313,414 |  |  | 35.3 | % |
| Service |  | 830,675 |  |  | 14.2 |  |  | 665,231 |  |  | 15.2 |  |  | 165,444 |  |  | 24.9 |  |
| Total revenue |  | 5,860,168 |  |  | 100.0 |  |  | 4,381,310 |  |  | 100.0 |  |  | 1,478,858 |  |  | 33.8 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 2,061,167 |  |  | 35.2 |  |  | 1,573,629 |  |  | 35.9 |  |  | 487,538 |  |  | 31.0 |  |
| Service |  | 168,720 |  |  | 2.9 |  |  | 131,985 |  |  | 3.0 |  |  | 36,735 |  |  | 27.8 |  |
| Total cost of revenue |  | 2,229,887 |  |  | 38.1 |  |  | 1,705,614 |  |  | 38.9 |  |  | 524,273 |  |  | 30.7 |  |
| Gross profit |  | $ | 3,630,281 |  |  | 61.9 | % |  | $ | 2,675,696 |  |  | 61.1 | % |  | $ | 954,585 |  |  | 35.7 | % |
| Gross margin |  | 61.9 | % |  |  |  | 61.1 | % |  |  |  |  |  |  |

[0001596532-24-000043:mdna:21]
Revenue by Geography (in thousands, except percentages)

[0001596532-24-000043:mdna:22]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | % of Total |  | 2022 |  | % of Total |
| Americas |  | $ | 4,651,193 |  |  | 79.4 | % |  | $ | 3,462,621 |  |  | 79.0 | % |
| Europe, Middle East and Africa |  | 670,960 |  |  | 11.4 |  |  | 529,800 |  |  | 12.1 |  |
| Asia-Pacific |  | 538,015 |  |  | 9.2 |  |  | 388,889 |  |  | 8.9 |  |
| Total revenue |  | $ | 5,860,168 |  |  | 100.0 | % |  | $ | 4,381,310 |  |  | 100.0 | % |

[0001596532-24-000043:mdna:23]
Revenue

[0001596532-24-000043:mdna:24]
Product revenue primarily consists of sales of our switching and routing products, and related network applications. Service revenue is primarily derived from sales of PCS contracts, which are typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing, size, and complexity of orders, especially with respect to our large customers.

[0001596532-24-000043:mdna:25]
Product revenue increased by $1.3 billion, or 35.3%, for the year ended December 31, 2023 compared to 2022.  These increases reflect increased shipments of our switching and routing products across our customer base, including improved supply availability for our enterprise customers. In addition, service revenue increased by $165.4 million, or 24.9%, in the year ended December 31, 2023 compared to 2022, as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. International revenues as a percentage of our total revenues decreased from 21.0% in 2022 to 20.6% in 2023, which was primarily driven by changes in the geographic mix of sales to our large global customers.

[0001596532-24-000043:mdna:26]
Cost of Revenue and Gross Margin

[0001596532-24-000043:mdna:27]
Cost of product revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs of our manufacturing operations, including freight, and other costs associated with manufacturing our products and managing our inventory and supply chain. Cost of service revenue primarily consists of personnel and other costs associated with our global customer support and services organizations.

[0001596532-24-000043:mdna:28]
Cost of revenue increased by $524.3 million, or 30.7% for the year ended December 31, 2023 compared to 2022. These increases were primarily driven by a corresponding increase in product and service revenues, combined with an increase in provisions for excess/obsolete inventory and supplier liability charges.

[0001596532-24-000043:mdna:29]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including pricing pressure on our products and services due to competition, the mix of sales to large customers who generally receive lower pricing, the mix of products sold, manufacturing-related costs, including costs associated with supply chain sourcing activities, merchant silicon costs, and excess/obsolete inventory charges, including charges for excess/obsolete component inventory held by our contract manufacturers and suppliers. We expect our gross margin to fluctuate over time, depending on the factors described above.

[0001596532-24-000043:mdna:30]
Gross margin increased from 61.1% for the year ended December 31, 2022 to 61.9% for the year ended December 31, 2023. These changes reflect an improvement in product margins driven by a lower mix of revenue from our larger customers, partly offset by an increase in excess/obsolete inventory-related charges. In addition, our gross margin benefited in 2023 from the leverage of relatively fixed overhead costs on a higher revenue base.

[0001596532-24-000043:mdna:31]
Operating Expenses (in thousands, except percentages)

[0001596532-24-000043:mdna:32]
Our operating expenses consist of research and development, sales and marketing, and general and administrative expenses. The largest component of our operating expenses is personnel costs. Personnel costs consist of wages, benefits, bonuses and, with respect to sales and marketing expenses, sales commissions. Personnel costs also include stock-based compensation and travel-related expenses.

[0001596532-24-000043:mdna:33]
|  |  | Year Ended December 31, |  |  |
|  |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 854,918 |  |  | 14.6 | % |  | $ | 728,394 |  |  | 16.6 | % |  | $ | 126,524 |  |  | 17.4 | % |
| Sales and marketing |  | 399,034 |  |  | 6.8 |  |  | 326,955 |  |  | 7.5 |  |  | 72,079 |  |  | 22.0 |  |
| General and administrative |  | 119,080 |  |  | 2.0 |  |  | 93,241 |  |  | 2.1 |  |  | 25,839 |  |  | 27.7 |  |
| Total operating expenses |  | $ | 1,373,032 |  |  | 23.4 | % |  | $ | 1,148,590 |  |  | 26.2 | % |  | $ | 224,442 |  |  | 19.5 | % |

[0001596532-24-000043:mdna:34]
Research and development.

[0001596532-24-000043:mdna:35]
Research and development expenses consist primarily of personnel costs, prototype expenses, third-party engineering costs, and an allocated portion of facility and IT costs. Our research and development efforts are focused on new product development and maintaining and developing additional functionality for our existing products, including new releases and upgrades to our EOS software and applications. We expect our research and development expenses to increase in absolute dollars as we continue to invest in software development in order to expand the capabilities of our cloud networking platform, introduce new products and features, and continue to invest in our technology.

[0001596532-24-000043:mdna:36]
Research and development expenses increased by $126.5 million, or 17.4%, for the year ended December 31, 2023 compared to 2022. The increase was primarily due to a $84.1 million increase in personnel costs driven by an increase in headcount, and a $40.7 million increase in new product introduction costs, including non-recurring engineering costs and prototype expenses as we expand our product portfolio.

[0001596532-24-000043:mdna:37]
Sales and marketing.

[0001596532-24-000043:mdna:38]
Sales and marketing expenses consist primarily of personnel costs, marketing, trade shows, and other promotional activities, and an allocated portion of facility and IT costs. We expect our sales and marketing expenses to increase in absolute dollars as we continue to expand our sales and marketing efforts worldwide.

[0001596532-24-000043:mdna:39]
Sales and marketing expenses increased by $72.1 million, or 22.0%, for the year ended December 31, 2023 compared to 2022. The increase was primarily caused by increased personnel costs driven by headcount growth, in addition to increased sales and marketing events and field demonstration costs.

[0001596532-24-000043:mdna:40]
General and administrative.

[0001596532-24-000043:mdna:41]
General and administrative expenses consist primarily of personnel costs and professional services costs for our finance, human resources, legal and certain executive functions. Our professional services costs are primarily related to external legal, accounting, and tax services.

[0001596532-24-000043:mdna:42]
General and administrative expenses increased by $25.8 million, or 27.7%, for the year ended December 31, 2023 compared to 2022. The increase was primarily caused by an increase in personnel costs driven by increased stock-based compensation, and increased legal and professional fees.

[0001596532-24-000043:mdna:43]
Other Income, Net (in thousands, except percentages)

[0001596532-24-000043:mdna:44]
Other income (expense), net consists primarily of interest income from our cash, cash equivalents and marketable securities, gains and losses on our marketable securities and strategic investments, and foreign currency transaction gains and losses.  We expect other income (expense), net may fluctuate in the future as a result of the re-measurement of our equity investments upon the occurrence of either observable price changes or impairments, changes in interest rates or returns on our cash and cash equivalents and marketable securities, and foreign currency exchange rate fluctuations.

[0001596532-24-000043:mdna:45]
|  |  | Year Ended December 31, |  |  |
|  |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 152,421 |  |  | 2.6 | % |  | $ | 27,556 |  |  | 0.6 | % |  | $ | 124,865 |  |  | 453.1 | % |
| Gain (loss) on strategic investments |  | 18,699 |  | 0.3 |  |  | 27,479 |  |  | 0.6 |  |  | (8,780) |  |  | (32.0) |  |
| Other income (expense), net |  | (6,343) |  |  | (0.1) |  |  | (345) |  |  | — |  |  | (5,998) |  |  | 1,738.6 |  |
| Total other income, net |  | $ | 164,777 |  |  | 2.8 | % |  | $ | 54,690 |  |  | 1.2 | % |  | $ | 110,087 |  |  | 201.3 | % |

[0001596532-24-000043:mdna:46]
The favorable movement in other income (expense), net, during the year ended December 31, 2023 as compared to 2022 was driven by an increase in interest income of $124.9 million due to an increase in our cash and investments balances and higher interest rates.

[0001596532-24-000043:mdna:47]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-24-000043:mdna:48]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may also be subject to U.S. income tax. Generally, our U.S. tax obligations are reduced by a credit for foreign income taxes paid on these foreign earnings, which avoids double taxation. Our tax expense to date consists of federal, state and foreign current and deferred income taxes.

[0001596532-24-000043:mdna:49]
|  |  | Year Ended December 31, |  |  |
|  |  | 2023 |  | 2022 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Provision for income taxes |  | $ | 334,705 |  |  | 5.7 | % |  | $ | 229,350 |  |  | 5.2 | % |  | $ | 105,355 |  |  | 45.9 | % |
| Effective tax rate |  | 13.8 | % |  |  |  | 14.5 | % |  |  |  |  |  |  |

[0001596532-24-000043:mdna:50]
Our provision for income taxes increased in 2023, as compared to 2022, and our effective tax rate decreased in 2023, as compared to 2022. The increase in our income taxes was largely due to an increase in pre-tax income, partly offset by an increase in tax benefits attributable to stock-based compensation. The decrease in our effective tax rate was primarily due to a

[0001596532-24-000043:mdna:51]
reduction of unrecognized tax benefits on uncertain tax positions due to the expiration of the statute of limitations. For further information regarding income taxes and the impact on our results of operations and financial position, refer to Note 8. Income Taxes of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K.

[0001596532-24-000043:mdna:52]
Year Ended December 31, 2022 Compared to Year Ended December 31, 2021

[0001596532-24-000043:mdna:53]
Revenue, Cost of Revenue and Gross Margin (in thousands, except percentages)

[0001596532-24-000043:mdna:54]
|  |  | Year Ended December 31, |  |  |
|  |  | 2022 |  | 2021 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,716,079 |  |  | 84.8 | % |  | $ | 2,377,727 |  |  | 80.7 | % |  | $ | 1,338,352 |  |  | 56.3 | % |
| Service |  | 665,231 |  |  | 15.2 |  |  | 570,310 |  |  | 19.3 |  |  | 94,921 |  |  | 16.6 |  |
| Total revenue |  | 4,381,310 |  |  | 100.0 |  |  | 2,948,037 |  |  | 100.0 |  |  | 1,433,273 |  |  | 48.6 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 1,573,629 |  |  | 35.9 |  |  | 958,363 |  |  | 32.5 |  |  | 615,266 |  |  | 64.2 |  |
| Service |  | 131,985 |  |  | 3.0 |  |  | 108,895 |  |  | 3.7 |  |  | 23,090 |  |  | 21.2 |  |
| Total cost of revenue |  | 1,705,614 |  |  | 38.9 |  |  | 1,067,258 |  |  | 36.2 |  |  | 638,356 |  |  | 59.8 |  |
| Gross profit |  | $ | 2,675,696 |  |  | 61.1 | % |  | $ | 1,880,779 |  |  | 63.8 | % |  | $ | 794,917 |  |  | 42.3 | % |
| Gross margin |  | 61.1 | % |  |  |  | 63.8 | % |  |  |  |  |  |  |

[0001596532-24-000043:mdna:55]
Revenue by Geography (in thousands, except percentages)

[0001596532-24-000043:mdna:56]
|  |  | Year Ended December 31, |
|  |  | 2022 |  | % of Total |  | 2021 |  | % of Total |
| Americas |  | $ | 3,462,621 |  |  | 79.0 | % |  | $ | 2,156,183 |  |  | 73.2 | % |
| Europe, Middle East and Africa |  | 529,800 |  |  | 12.1 |  |  | 486,836 |  |  | 16.5 |  |
| Asia-Pacific |  | 388,889 |  |  | 8.9 |  |  | 305,018 |  |  | 10.3 |  |
| Total revenue |  | $ | 4,381,310 |  |  | 100.0 | % |  | $ | 2,948,037 |  |  | 100.0 | % |

[0001596532-24-000043:mdna:57]
Revenue

[0001596532-24-000043:mdna:58]
Product revenue increased by $1.3 billion, or 56.3%, in the year ended December 31, 2022 compared to 2021.  The increase reflects strong demand for our switching and routing platforms from across our customer base, including healthy contributions from our large cloud customers. Although we saw some improvement in component supply in the latter part of fiscal 2022, supply chain and manufacturing constraints limited our revenue performance throughout the year, and while changes in product deferred revenue impacted the timing of revenue recognition on a quarterly basis, the net change in product deferred revenue for the full year was an immaterial contributor to revenue for the year ended December 31, 2022. In addition, service revenue increased by $94.9 million, or 16.6%, in the year ended December 31, 2022 compared to 2021, as a result of continued growth in initial and renewal PCS contracts as our customer installed base continued to expand. International revenues as a percentage of our total revenues decreased from 26.8% in 2021 to 21.0% in 2022, which was primarily driven by increased purchases from large cloud customers in our Americas region. As a result of cost inflation in our supply chain, we implemented targeted price increases during the year, which began to benefit our revenue in late 2022. As supply chain costs improve, we expected to return to a more competitive pricing environment for our products and services.

[0001596532-24-000043:mdna:59]
Cost of Revenue and Gross Margin

[0001596532-24-000043:mdna:60]
Cost of revenue increased by $638.4 million, or 59.8% for the year ended December 31, 2022 compared to 2021. These increases were primarily driven by a corresponding increase in product and service revenues, combined with an increase in material and logistics costs to mitigate supply chain constraints and to meet customer demand, as well as an increase in provisions for excess/obsolete finished goods and component inventory.

[0001596532-24-000043:mdna:61]
Gross margin decreased from 63.8% for the year ended December 31, 2021 to 61.1% for the year ended December 31, 2022. The decrease was primarily driven by an increased proportion of our sales to larger customers who generally receive larger discounts, increased material and logistics costs, and increased excess/obsolete finished goods and component inventory charges, partly offset by the leverage of fixed overhead costs on a higher revenue base.

[0001596532-24-000043:mdna:62]
Operating Expenses (in thousands, except percentages)

[0001596532-24-000043:mdna:63]
|  |  | Year Ended December 31, |  |  |
|  |  | 2022 |  | 2021 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 728,394 |  |  | 16.6 | % |  | $ | 586,752 |  |  | 19.9 | % |  | $ | 141,642 |  |  | 24.1 | % |
| Sales and marketing |  | 326,955 |  |  | 7.5 |  |  | 286,171 |  |  | 9.7 |  |  | 40,784 |  |  | 14.3 |  |
| General and administrative |  | 93,241 |  |  | 2.1 |  |  | 83,117 |  |  | 2.8 |  |  | 10,124 |  |  | 12.2 |  |
| Total operating expenses |  | $ | 1,148,590 |  |  | 26.2 | % |  | $ | 956,040 |  |  | 32.4 | % |  | $ | 192,550 |  |  | 20.1 | % |

[0001596532-24-000043:mdna:64]
Research and development

[0001596532-24-000043:mdna:65]
Research and development expenses increased by $141.6 million, or 24.1%, for the year ended December 31, 2022 compared to 2021. The increase was primarily due to a $68.6 million increase in personnel costs driven by an increase in headcount, and a $57.5 million increase in new product introduction costs, including third-party engineering and other product development costs.

[0001596532-24-000043:mdna:66]
Sales and marketing

[0001596532-24-000043:mdna:67]
Sales and marketing expenses increased by $40.8 million, or 14.3%, for the year ended December 31, 2022 compared to 2021. The increase was primarily caused by increased personnel costs driven by headcount growth.

[0001596532-24-000043:mdna:68]
General and administrative

[0001596532-24-000043:mdna:69]
General and administrative expenses increased by $10.1 million, or 12.2%, for the year ended December 31, 2022 compared to 2021. The increase was driven by an increase in personnel costs driven by increased headcount, and increased legal and professional fees primarily driven by acquisitions during the first half of 2022.

[0001596532-24-000043:mdna:70]
Other Income, Net (in thousands, except percentages)

[0001596532-24-000043:mdna:71]
|  |  | Year Ended December 31, |  |  |
|  |  | 2022 |  | 2021 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Other income, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest income |  | $ | 27,556 |  |  | 0.6 | % |  | $ | 7,215 |  |  | 0.2 | % |  | $ | 20,341 |  |  | 281.9 | % |
| Gain on investments in privately-held companies |  | 27,479 |  |  | 0.6 |  |  | — |  |  | — |  |  | 27,479 |  |  | 100.0 |  |
| Other income (expense), net |  | (345) |  |  | — |  |  | (1,075) |  |  | — |  |  | 730 |  |  | (67.9) |  |
| Total other income, net |  | $ | 54,690 |  |  | 1.2 | % |  | $ | 6,140 |  |  | 0.2 | % |  | $ | 48,550 |  |  | 790.7 | % |

[0001596532-24-000043:mdna:72]
The movement in other income (expense), net, during the year ended December 31, 2022 as compared to 2021 was driven by an increase in interest income due to higher interest rates. In addition, we had unrealized gains of $27.5 million in the year ended December 31, 2022 related to our equity investments.

[0001596532-24-000043:mdna:73]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-24-000043:mdna:74]
|  |  | Year Ended December 31, |  |  |
|  |  | 2022 |  | 2021 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Provision for income taxes |  | $ | 229,350 |  |  | 5.2 | % |  | $ | 90,025 |  |  | 3.1 | % |  | $ | 139,325 |  |  | 154.8 | % |
| Effective tax rate |  | 14.5 | % |  |  |  | 9.7 | % |  |  |  |  |  |  |

[0001596532-24-000043:mdna:75]
Our provision for income taxes and effective tax rate increased in 2022 as compared to 2021. The increase in our income taxes was due to an increase in pre-tax income. The increase in our effective tax rate was largely attributable to a decrease in the proportion of tax benefits attributable to stock-based compensation versus total pre-tax income. For further information regarding income taxes and the impact on our results of operations and financial position, refer to Note 8. Income Taxes of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K.

[0001596532-24-000043:mdna:76]
Liquidity and Capital Resources

[0001596532-24-000043:mdna:77]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of December 31, 2023, our total balance of cash, cash equivalents and marketable securities was $5.0 billion, of which approximately $770.3 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-24-000043:mdna:78]
Our cash, cash equivalents and marketable securities are held for general business purposes, including the funding of working capital. Our marketable securities investment portfolio is primarily invested in highly-rated securities, with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities, together with cash generated from operations, will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings, our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, capital expenditures and stock repurchases. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-24-000043:mdna:79]
Cash Flows

[0001596532-24-000043:mdna:80]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 2,034,014 |  |  | $ | 492,813 |  |  | $ | 1,015,856 |  |
| Cash provided by (used in) investing activities |  | (687,454) |  |  | 216,327 |  |  | (925,562) |  |
| Cash (used in) financing activities |  | (83,749) |  |  | (654,601) |  |  | (360,882) |  |
| Effect of exchange rate changes |  | 675 |  |  | (3,611) |  |  | (1,816) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 1,263,486 |  |  | $ | 50,928 |  |  | $ | (272,404) |  |

[0001596532-24-000043:mdna:81]
Cash Flows from Operating Activities

[0001596532-24-000043:mdna:82]
Our operating activities consist of net income, adjusted for certain non-cash items, and changes in assets and liabilities.

[0001596532-24-000043:mdna:83]
During the year ended December 31, 2023, cash provided by operating activities was $2.0 billion, primarily from net income of $2.1 billion, offset by net non-cash adjustments to net income of $37.4 million, and a net change of $15.9 million in working capital requirements. Net non-cash adjustments primarily consisted of an increase in deferred income taxes of $370.8 million primarily resulting from increased deferred tax assets associated with the capitalization of research and development costs under IRC Section 174, which were largely offset by $296.8 million of stock-based compensation expenses and $70.6 million of depreciation, amortization and other expenses. The change in working capital requirements primarily

[0001596532-24-000043:mdna:84]
consisted of a $655.5 million increase in inventory in response to a significant increase in business volume, a $101.5 million increase in accounts receivable due to the larger business volume and timing of shipments in the fourth quarter of 2023, as well as a $66.4 million increase in other assets primarily driven by increased deferred cost of sales associated with higher product revenue deferrals. These cash outflows were largely offset by a $465.0 million increase in deferred revenue driven by a growth in PCS contracts and increased product deferred revenue related to customer contracts with acceptance terms, a $322.3 million increase in accounts payable and other liabilities related to significant business volume, timing of payments, and increased supplier and contract manufacturer liability reserves and a $20.2 million increase in income taxes, net, due to timing of payments.

[0001596532-24-000043:mdna:85]
During the year ended December 31, 2022, cash provided by operating activities was $492.8 million, primarily from net income of $1.4 billion and net non-cash adjustments to net income of $53.2 million, partially offset by a net increase of $912.8 million in working capital requirements. Net non-cash adjustments primarily consisted of $230.9 million of stock-based compensation expenses and $62.7 million of depreciation, amortization and other expenses, which were largely offset by an increase in deferred income taxes of $244.4 million primarily resulting from increased deferred tax assets associated with the capitalization of research and development costs under IRC Section 174. The increase in working capital requirements primarily consisted of a $638.9 million increase in inventory in response to a significant increase in business volume, increased lead times and supply chain disruptions, and a $401.5 million increase in accounts receivable due to the larger business volume and timing of shipments in the fourth quarter of 2022, as well as an $85.2 million increase in prepaid and other current assets primarily driven by increased inventory deposits to our contract manufacturers. These cash outflows were largely offset by a $99.0 million increase in deferred revenue driven by a growth in PCS contracts, a $98.0 million increase in accounts payable and accrued liabilities related to significant business volume, timing of payments, and increased supplier and contract manufacturer liability reserves and a $44 million increase in income taxes, net, due to an increase in our income tax provision and timing of payments.

[0001596532-24-000043:mdna:86]
Cash Flows from Investing Activities

[0001596532-24-000043:mdna:87]
Our investing activities consist of our marketable securities investments, business combinations, investments in privately-held companies, and capital expenditures.

[0001596532-24-000043:mdna:88]
During the year ended December 31, 2023, cash used in investing activities was $687.5 million, consisting of purchases of available-for-sale securities of $2.6 billion, and purchases of property, equipment and intangible assets of $34.4 million, partially offset by proceeds of $1.9 billion from maturities of marketable securities, and proceeds from the sale of marketable securities of $67.3 million,

[0001596532-24-000043:mdna:89]
During the year ended December 31, 2022, cash provided by investing activities was $216.3 million, consisting of proceeds of $1.6 billion from maturities of marketable securities, proceeds from the sale of marketable securities of $193.8 million, partially offset by purchases of available-for-sale securities of $1.4 billion, $145.1 million for business acquisitions, purchases of property, equipment and intangible assets of $44.6 million, and investments and notes receivable in private companies of $12.7 million.

[0001596532-24-000043:mdna:90]
Cash Flows from Financing Activities

[0001596532-24-000043:mdna:91]
Our financing activities consist of proceeds from the issuance of our common stock under employee equity incentive plans, offset by repurchases of our common stock.

[0001596532-24-000043:mdna:92]
During the year ended December 31, 2023, cash used in financing activities was $83.7 million, consisting primarily of common stock repurchases of $112.3 million and taxes paid of $33.6 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $62.1 million.

[0001596532-24-000043:mdna:93]
During the year ended December 31, 2022, cash used in financing activities was $654.6 million, consisting primarily of common stock repurchases of $670.3 million and taxes paid of $32.7 million upon vesting of restricted stock units, offset partially by proceeds from the issuance of common stock under employee equity incentive plans of $48.4 million.

[0001596532-24-000043:mdna:94]
Stock Repurchase Programs

[0001596532-24-000043:mdna:95]
In October 2021, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”). This authorization allows us to repurchase shares of our common stock funded from working capital and expires in the fourth quarter of 2024. The Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by the company at any time without prior notice. During the three months ended December 31,

[0001596532-24-000043:mdna:96]
2023, we did not repurchase any shares. As of December 31, 2023, the remaining authorized amount for repurchases under the Repurchase Program was $144.5 million. Refer to Note 6. Stockholders' Equity and Stock-Based Compensation of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K for further discussion.

[0001596532-24-000043:mdna:97]
Material cash requirements

[0001596532-24-000043:mdna:98]
Our material cash requirements will have an impact on our future liquidity. Our material cash requirements represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalents and marketable securities.

[0001596532-24-000043:mdna:99]
Our material cash requirements include the following contractual and other obligations:

[0001596532-24-000043:mdna:100]
Purchase Obligations

[0001596532-24-000043:mdna:101]
Purchase obligations not recorded on our balance sheet represent an estimate of all non-cancellable open purchase orders and contractual obligations, made either directly by Arista or by our contract manufacturers on our behalf, in the ordinary course of business for which we have not received the goods or services. As of December 31, 2023, we had $1,586.7 million of such purchase obligations, of which $1,547.2 million are expected to be received within 12 months, and $39.5 million are expected to be received after one year.  These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-24-000043:mdna:102]
Leases

[0001596532-24-000043:mdna:103]
We have operating lease arrangements for office space, data center, equipment and other corporate assets. As of December 31, 2023, we had lease payment obligations, net of immaterial sublease income, of $72.0 million, with $24.0 million payable within 12 months.

[0001596532-24-000043:mdna:104]
Property project

[0001596532-24-000043:mdna:105]
During the year ended December 31, 2021, we purchased land and the improvements thereon in Santa Clara, California to construct a building for office and lab space. The estimated capital expenditures related to this project is expected to be approximately $80.0 to $100.0 million for the year ending 2024, with construction expected to commence in the second half of 2024.

[0001596532-24-000043:mdna:106]
Accrued Income Taxes

[0001596532-24-000043:mdna:107]
As of December 31, 2023, we have recorded long-term tax liabilities of $95.8 million related to uncertain tax positions; however, we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-24-000043:mdna:108]
In connection with the TCJA, effective from January 1st, 2022, the TCJA eliminates the option to deduct research and development expenditures currently and requires taxpayers to capitalize and amortize them over five or fifteen years pursuant to IRC Section 174. As of December 31, 2023, the incremental cash tax impact resulting from the regulation was approximately $191.7 million for the year, of which substantially all the liability has been paid. It is anticipated that IRC Section 174 will result in cash tax outlays exceeding our income tax expense over the next three years unless the current legislation is changed. There is no material change to our effective tax rate as a result of this regulation.

[0001596532-24-000043:mdna:109]
Off-balance sheet arrangements

[0001596532-24-000043:mdna:110]
As of December 31, 2023, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities, that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-24-000043:mdna:111]
Critical Accounting Estimates

[0001596532-24-000043:mdna:112]
We have prepared our consolidated financial statements in accordance with accounting principles generally accepted in the United States ("GAAP" or "U.S. GAAP") and include our accounts and the accounts of our wholly owned subsidiaries. The preparation of these consolidated financial statements requires our management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities at the date of the financial statements, disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during

[0001596532-24-000043:mdna:113]
the applicable periods. Note 1, “Organization and Summary of Significant Accounting Policies,” of the Notes to Consolidated Financial Statements in Part II, Item 8 of this Form 10-K describes the significant accounting policies and methods used in the preparation of the Company’s consolidated financial statements. We base our estimates, assumptions and judgments on historical experience and on various other factors that we believe to be reasonable under the circumstances. Different assumptions and judgments would change the estimates used in the preparation of our consolidated financial statements, which, in turn, could change the results from those reported. We evaluate our estimates, assumptions and judgments on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected.

[0001596532-24-000043:mdna:114]
Revenue Recognition

[0001596532-24-000043:mdna:115]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with PCS. We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts which contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation. We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

[0001596532-24-000043:mdna:116]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information, such as gross margin objectives, market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to, product category, actual and expected volume, discounting policies, and end customer vertical and size.

[0001596532-24-000043:mdna:117]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at-risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

[0001596532-24-000043:mdna:118]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical return rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-24-000043:mdna:119]
We have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

[0001596532-24-000043:mdna:120]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-24-000043:mdna:121]
Inventories primarily consist of finished goods and strategic components, primarily integrated circuits. Inventories are stated at the lower of cost (computed using the first-in, first-out method) and net realizable value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory. We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value.

[0001596532-24-000043:mdna:122]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts. We record a liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with our contract manufacturers or suppliers for quantities in excess of our demand forecasts or that are considered obsolete due to manufacturing and engineering change orders resulting from design changes.

[0001596532-24-000043:mdna:123]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels. In addition, industry-wide supply chain shortages have resulted in extended lead times for components, and we were required to extend the time horizon of our demand forecasts. As customer lead times reduce more broadly, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to shorter demand-planning horizons resulting in lower demand levels.  While inventory and working capital levels may remain elevated in the near term, we expect that purchase commitments will continue to decline as supplier lead times shorten. There is however no guarantee that all suppliers will meet their commitments in the time frame committed or that actual customer demand will directly match our demand forecasts. If actual market demand conditions or supplier execution on commitments are less favorable than those projected by management, which may be caused by factors within and/or outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer and supplier liabilities.

[0001596532-24-000043:mdna:124]
Income Taxes

[0001596532-24-000043:mdna:125]
Significant management judgment is required in developing our provision for or benefit from income taxes, including the determination of deferred tax assets and liabilities and any valuation allowances that might be required against the deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results and estimates of our ability to generate sufficient future taxable income in certain foreign and state tax jurisdictions, future reversals of taxable temporary differences, and potential tax planning strategies. An adjustment to the valuation allowance will either increase or decrease our provision for or benefit from income taxes in the period such determination is made.

[0001596532-24-000043:mdna:126]
We are subject to income taxes in the U.S. and numerous foreign jurisdictions, which involves significant judgment in the interpretation of complex domestic and international tax laws and may give rise to uncertain tax positions. We recognize potential liabilities for anticipated tax audit issues in the U.S. and other tax jurisdictions based on our estimate of whether it is more likely than not that additional taxes, interest, and penalties will be due. Although management believes our unrecognized tax benefits are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our unrecognized tax benefits. Our unrecognized tax benefits are adjusted considering changing facts and circumstances, such as the closing of a tax examination or the refinement of an estimate. Resolution of these uncertainties in a manner inconsistent with management’s expectations could have a material impact on our financial condition and operating results.

[0001596532-24-000043:mdna:127]
Recent Accounting Pronouncements

[0001596532-24-000043:mdna:128]
Refer to the subheading titled “Recently Adopted Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K.

[0001596532-24-000043:mdna:129]
65
