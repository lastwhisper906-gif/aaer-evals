# ANET 8-K — 0001596532-24-000041 filed 2024-02-12

## item codes, every 8-K on or before 2024-02-13

- 2024-02-12 0001596532-24-000041 — 2.02, 9.01
- 2023-12-20 0001596532-23-000349 — 5.03, 9.01
- 2023-12-01 0001596532-23-000324 — 5.02, 8.01, 9.01
- 2023-10-30 0001596532-23-000272 — 2.02, 9.01
- 2023-07-31 0001596532-23-000196 — 2.02, 5.02, 9.01
- 2023-06-16 0001596532-23-000168 — 5.07
- 2023-05-01 0001596532-23-000101 — 2.02, 9.01
- 2023-02-13 0001596532-23-000015 — 2.02, 9.01
- 2022-10-31 0001596532-22-000292 — 2.02, 9.01
- 2022-10-25 0001596532-22-000282 — 5.03, 9.01
- 2022-08-01 0001596532-22-000218 — 2.02, 9.01
- 2022-07-25 0001596532-22-000205 — 5.02
- 2022-06-03 0001596532-22-000179 — 5.07
- 2022-05-02 0001596532-22-000111 — 2.02, 9.01
- 2022-03-29 0001596532-22-000100 — 5.02
- 2022-02-14 0001596532-22-000025 — 2.02, 9.01
- 2021-11-01 0001596532-21-000351 — 2.02, 8.01, 9.01
- 2021-08-02 0001596532-21-000253 — 2.02, 9.01
- 2021-07-20 0001596532-21-000242 — 5.02
- 2021-06-03 0001596532-21-000195 — 5.07
- 2021-05-04 0001596532-21-000138 — 2.02, 9.01
- 2021-02-18 0001596532-21-000048 — 2.02, 9.01
- 2020-11-02 0001596532-20-000225 — 2.02, 9.01
- 2020-08-04 0001596532-20-000147 — 2.02, 9.01
- 2020-07-13 0001596532-20-000124 — 5.02
- 2020-05-29 0001628280-20-008562 — 5.07
- 2020-05-05 0001628280-20-006442 — 2.02, 9.01
- 2020-02-13 0001596532-20-000019 — 2.02, 9.01
- 2020-01-02 0001596532-20-000003 — 2.02, 7.01
- 2019-10-31 0001596532-19-000227 — 2.02, 9.01
- 2019-08-01 0001596532-19-000181 — 2.02, 9.01
- 2019-05-29 0001596532-19-000150 — 5.07
- 2019-05-02 0001596532-19-000099 — 2.02, 8.01, 9.01
- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2024-02-13

- none on or before 2024-02-13

## item 2.02 — earnings release, exhibit 99.1

[0001596532-24-000041:8k_2_02:1]
EX-99.1
2
ex991q423-earningsrelease.htm
EX-99.1

[0001596532-24-000041:8k_2_02:2]
Document

[0001596532-24-000041:8k_2_02:3]
Exhibit 99.1

[0001596532-24-000041:8k_2_02:4]
Arista Networks, Inc. Reports Fourth Quarter and Year End 2023 Financial Results

[0001596532-24-000041:8k_2_02:5]
SANTA CLARA, Calif.- February 12, 2024 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments, today announced financial results for its fourth quarter and the full year ended December 31, 2023.

[0001596532-24-000041:8k_2_02:6]
"I am truly honored to be a part of the leadership team that will drive Arista 2.0 products and technology for enterprise, cloud and AI customers," said incoming CFO Chantelle Breithaupt. "As we enter 2024, we remain focused on satisfying their most demanding requirements with our compelling, innovative networking solutions."

[0001596532-24-000041:8k_2_02:7]
Full Year Financial Results

[0001596532-24-000041:8k_2_02:8]
•Revenue of $5,860.2 million, an increase of 33.8% compared to fiscal year 2022.

[0001596532-24-000041:8k_2_02:9]
•GAAP gross margin of 61.9%, compared to GAAP gross margin of 61.1% in fiscal year 2022.

[0001596532-24-000041:8k_2_02:10]
•Non-GAAP gross margin of 62.6%, compared to non-GAAP gross margin of 61.9% in fiscal year 2022.

[0001596532-24-000041:8k_2_02:11]
•GAAP net income of $2,087.3 million, or $6.58 per diluted share, compared to GAAP net income of $1,352.4 million, or $4.27 per diluted share, in fiscal year 2022.

[0001596532-24-000041:8k_2_02:12]
•Non-GAAP net income of $2,199.4 million or $6.94 per diluted share, compared to non-GAAP net income of $1,448.3 million or $4.58 per diluted share, in fiscal year 2022.

[0001596532-24-000041:8k_2_02:13]
Fourth Quarter Financial Results

[0001596532-24-000041:8k_2_02:14]
•Revenue of $1,540.4 million, an increase of 2.1% compared to the third quarter of 2023, and an increase of 20.8% from the fourth quarter of 2022.

[0001596532-24-000041:8k_2_02:15]
•GAAP gross margin of 64.9%, compared to GAAP gross margin of 62.4% in the third quarter of 2023 and 60.3% in the fourth quarter of 2022.

[0001596532-24-000041:8k_2_02:16]
•Non-GAAP gross margin of 65.4%, compared to non-GAAP gross margin of 63.1% in the third quarter of 2023 and 61.0% in the fourth quarter of 2022.

[0001596532-24-000041:8k_2_02:17]
•GAAP net income of $613.6 million, or $1.92 per diluted share, compared to GAAP net income of $427.1 million, or $1.35 per diluted share, in the fourth quarter of 2022.

[0001596532-24-000041:8k_2_02:18]
•Non-GAAP net income of $664.3 million, or $2.08 per diluted share, compared to non-GAAP net income of $445.1 million, or $1.41 per diluted share, in the fourth quarter of 2022.

[0001596532-24-000041:8k_2_02:19]
Commenting on the company's financial results, Ita Brennan, Arista’s outgoing CFO said, “Our outstanding performance for 2023 epitomizes our focus on profitable revenue growth, expanding our enterprise and campus footprint while leveraging R&D and go-to-market investments across the business."

[0001596532-24-000041:8k_2_02:20]
Fourth Quarter Company Highlights

[0001596532-24-000041:8k_2_02:21]
•Arista 7130 Series Leads the Way to 25G Ultra-Low Latency Networking – announcing the next generation 7130 Series for ultra-low latency switching that accelerates 25G networking. With three new 25G optimized systems, enhanced performance optics, 25G ready FPGA applications and updates to the FDK (FPGA Development Kit), Arista is addressing the needs for 25G market data distribution and High-Frequency Trading (HFT) environments.

[0001596532-24-000041:8k_2_02:22]
•Arista Networks Unveils Zero Trust Networking Vision – announcing an expanded zero trust networking architecture that uses the underlying network infrastructure to break down security silos, streamline workflows and enable an integrated zero trust program. Through a combination of Arista-developed

[0001596532-24-000041:8k_2_02:23]
technologies and strategic alliances with key partners, this approach uses the network to compensate for harder-to-implement zero trust controls across the domains of devices, workloads, identity, and data.

[0001596532-24-000041:8k_2_02:24]
•Arista Networks Appoints New CFO – announcing the appointment of Chantelle Breithaupt as the company’s CFO, effective February 2024.

[0001596532-24-000041:8k_2_02:25]
Full Year Company Highlights

[0001596532-24-000041:8k_2_02:26]
•The Arrival of Open AI Networking – Arista and the founding members of the Ultra Ethernet Consortium (UEC) have set out on the mission to enhance the capabilities of Ethernet for AI and HPC.

[0001596532-24-000041:8k_2_02:27]
•Arista Networks Introduces AI-Driven Network Identity – Arista introduced a cloud-delivered, AI-driven network identity service for enterprise security and IT operations.

[0001596532-24-000041:8k_2_02:28]
•In the first half of 2023, Arista surpassed 75 million cloud network ports shipped cumulatively.

[0001596532-24-000041:8k_2_02:29]
•Arista Named a Leader in The Forrester Wave™: Network Analysis and Visibility, Q2 2023 which notes that “Arista Networks’ deployment flexibility is second to none.”

[0001596532-24-000041:8k_2_02:30]
•Arista Modernizes Routing in the Wide Area Network - Arista introduced the Arista WAN Routing System, which combines three new networking offerings: enterprise-class routing platforms, carrier/cloud-neutral internet transit capabilities, and the CloudVision® Pathfinder Service to simplify and improve customer wide area networks.

[0001596532-24-000041:8k_2_02:31]
•Arista Showcases Next Generation Systems and Optics for Cloud, Internet Service Provider, and Enterprise Networks - Arista announced its range of products and solutions, along with perspectives on the petascale era of cloud networking and the systems and optics required to meet the demands of new AI/ML-driven network architectures.

[0001596532-24-000041:8k_2_02:32]
Financial Outlook

[0001596532-24-000041:8k_2_02:33]
For the first quarter of 2024, we expect:

[0001596532-24-000041:8k_2_02:34]
•Revenue between $1.52 billion to $1.56 billion;

[0001596532-24-000041:8k_2_02:35]
•Non-GAAP gross margin of approximately 62%; and

[0001596532-24-000041:8k_2_02:36]
•Non-GAAP operating margin of approximately 42%.

[0001596532-24-000041:8k_2_02:37]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other acquisition-related costs. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis because these exclusions can be uncertain or difficult to predict, including stock-based compensation expense which is impacted by the company’s future hiring and retention needs and the future fair market value of the company’s common stock. The actual amount of these exclusions will have a significant impact on the company’s GAAP gross margin and GAAP operating margin.

[0001596532-24-000041:8k_2_02:38]
Prepared Materials and Conference Call Information

[0001596532-24-000041:8k_2_02:39]
Arista's executives will discuss the fourth quarter and year end 2023 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (888) 330-2502 in the United States or +1 (240) 789-2713 from international locations. The Conference ID is 5655862.

[0001596532-24-000041:8k_2_02:40]
The financial results conference call will also be available via live webcast on Arista's investor relations website at https://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s investor relations website.

[0001596532-24-000041:8k_2_02:41]
Forward-Looking Statements

[0001596532-24-000041:8k_2_02:42]
This press release contains “forward-looking statements” regarding our future performance, including quotations from management, statements in the section entitled “Financial Outlook,” such as estimates regarding revenue,

[0001596532-24-000041:8k_2_02:43]
non-GAAP gross margin and non-GAAP operating margin for the first quarter of 2024 and statements regarding the benefits of Arista's products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: large purchases by a limited number of customers who represent a substantial portion of our revenue; adverse economic and geopolitical conditions and conflicts, including inflationary pressures which result in increased component costs and reduced information technology and network infrastructure spending, the Russia/Ukraine, Israel/Hamas conflicts and the Houthi attacks on marine vessels in the Red Sea; changes in our customers technology roadmaps and priorities including the need for the rapid deployment of artificial intelligence (“AI”) and related technologies; the impact of sole or limited sources of supply, supply shortages and extended lead times or supply changes; volatility in our revenue growth rate; variations in our results of operations; the rapid evolution of the networking market; failure to successfully carry out new products and service offerings and expand into adjacent markets; variability in our gross margins; intense competition and industry consolidation; expansion of our international sales and operations; investments in or acquisitions of other businesses; seasonality and industry cyclicality; fluctuations in currency exchange rates; failure to raise additional capital on favorable terms; our inability to attract new large customers or sell additional products and services to our existing customers; sales of our switches generating most of our product revenue; large customers requiring more favorable terms; inability to increase market awareness or acceptance of our new products and services; decreases in the sales prices of our products and services; long and unpredictable sales cycles; declines in maintenance renewals by customers; product quality problems; failure to anticipate technological shifts; managing the supply of our products and product components; our dependence on third-party manufacturers to build our products; assertions by third parties of intellectual property rights infringement; failure to protect or assert our intellectual property rights; defects, errors or vulnerabilities in our products, the failure of our products to detect security breaches or incidents, the misuse of our products or the risks or product liability; enhanced U.S. tax, tariff, import/export restrictions, Chinese regulations or other trade barriers; failure to comply with government law and regulations; issues in the development and use of artificial intelligence, combined with an uncertain regulatory environment; and other future events. Additional risks and uncertainties that could affect us can be found in our most recent filings with the Securities and Exchange Commission including, but not limited to, our annual report on Form 10-K and quarterly reports on Form 10-Q. You can locate these reports through our website at https://investors.arista.com/ and on the SEC’s website at https://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and we disclaim any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-24-000041:8k_2_02:44]
Non-GAAP Financial Measures

[0001596532-24-000041:8k_2_02:45]
This press release and accompanying table contain certain non-GAAP financial measures including non-GAAP gross profit, non-GAAP gross margin, non-GAAP income from operations, non-GAAP operating margin, non-GAAP net income and non-GAAP diluted net income per share. These non-GAAP financial measures exclude stock-based compensation expense, amortization of acquisition-related intangibles and other acquisition-related expenses, gains/losses on strategic investments, an intellectual property dispute settlement, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, and other discrete indirect effects of such awards. The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-24-000041:8k_2_02:46]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for the comparable GAAP financial measures. Non-GAAP financial measures are subject to limitations, and should be read only in

[0001596532-24-000041:8k_2_02:47]
3

[0001596532-24-000041:8k_2_02:48]
conjunction with the company's consolidated financial statements prepared in accordance with GAAP. Non-GAAP financial measures do not have any standardized meaning and are therefore unlikely to be comparable to similarly titled measures presented by other companies. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures have been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-24-000041:8k_2_02:49]
About Arista Networks

[0001596532-24-000041:8k_2_02:50]
Arista Networks is an industry leader in data-driven, client to cloud networking for large data center, campus and routing environments. Arista’s award-winning platforms deliver availability, agility, automation, analytics and security through an advanced network operating stack. For more information, visit https://www.arista.com.

[0001596532-24-000041:8k_2_02:51]
ARISTA, EOS, CloudVision, NetDL and AVA are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners. Additional information and resources can be found at www.arista.com.

[0001596532-24-000041:8k_2_02:52]
ARISTA NETWORKS, INC.

[0001596532-24-000041:8k_2_02:53]
Condensed Consolidated Statements of Operations

[0001596532-24-000041:8k_2_02:54]
(Unaudited, in thousands, except per share amounts)

[0001596532-24-000041:8k_2_02:55]
|  |  | Three Months Ended December 31, |  | Twelve Months Ended December 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,310,314 |  |  | $ | 1,096,866 |  |  | $ | 5,029,493 |  |  | $ | 3,716,079 |  |
| Service |  | 230,123 |  |  | 178,686 |  |  | 830,675 |  |  | 665,231 |  |
| Total revenue |  | 1,540,437 |  |  | 1,275,552 |  |  | 5,860,168 |  |  | 4,381,310 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 495,826 |  |  | 471,617 |  |  | 2,061,167 |  |  | 1,573,629 |  |
| Service |  | 45,385 |  |  | 35,329 |  |  | 168,720 |  |  | 131,985 |  |
| Total cost of revenue |  | 541,211 |  |  | 506,946 |  |  | 2,229,887 |  |  | 1,705,614 |  |
| Total gross profit |  | 999,226 |  |  | 768,606 |  |  | 3,630,281 |  |  | 2,675,696 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 211,481 |  |  | 190,423 |  |  | 854,918 |  |  | 728,394 |  |
| Sales and marketing |  | 105,538 |  |  | 85,443 |  |  | 399,034 |  |  | 326,955 |  |
| General and administrative |  | 42,293 |  |  | 23,821 |  |  | 119,080 |  |  | 93,241 |  |
| Total operating expenses |  | 359,312 |  |  | 299,687 |  |  | 1,373,032 |  |  | 1,148,590 |  |
| Income from operations |  | 639,914 |  |  | 468,919 |  |  | 2,257,249 |  |  | 1,527,106 |  |
| Other income, net |  | 54,477 |  |  | 16,926 |  |  | 164,777 |  |  | 54,690 |  |
| Income before income taxes |  | 694,391 |  |  | 485,845 |  |  | 2,422,026 |  |  | 1,581,796 |  |
| Provision for income taxes |  | 80,755 |  |  | 58,756 |  |  | 334,705 |  |  | 229,350 |  |
| Net income |  | $ | 613,636 |  |  | $ | 427,089 |  |  | $ | 2,087,321 |  |  | $ | 1,352,446 |  |
| Earnings per share: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.97 |  |  | $ | 1.39 |  |  | $ | 6.75 |  |  | $ | 4.41 |  |
| Diluted |  | $ | 1.92 |  |  | $ | 1.35 |  |  | $ | 6.58 |  |  | $ | 4.27 |  |
| Weighted-average common shares outstanding: |  |  |  |  |  |  |  |  |
| Basic |  | 311,612 |  |  | 306,162 |  |  | 309,354 |  |  | 306,473 |  |
| Diluted |  | 318,845 |  |  | 315,201 |  |  | 317,135 |  |  | 316,459 |  |

[0001596532-24-000041:8k_2_02:56]
5

[0001596532-24-000041:8k_2_02:57]
ARISTA NETWORKS, INC.

[0001596532-24-000041:8k_2_02:58]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-24-000041:8k_2_02:59]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-24-000041:8k_2_02:60]
|  |  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| GAAP gross profit |  | $ | 999,226 |  |  | $ | 768,606 |  |  | $ | 3,630,281 |  |  | $ | 2,675,696 |  |
| GAAP gross margin |  | 64.9 | % |  | 60.3 | % |  | 61.9 | % |  | 61.1 | % |
| Stock-based compensation expense |  | 3,273 |  |  | 3,075 |  |  | 12,789 |  |  | 9,688 |  |
| Intangible asset amortization |  | 4,195 |  |  | 6,821 |  |  | 23,457 |  |  | 25,374 |  |
| Non-GAAP gross profit |  | $ | 1,006,694 |  |  | $ | 778,502 |  |  | $ | 3,666,527 |  |  | $ | 2,710,758 |  |
| Non-GAAP gross margin |  | 65.4 | % |  | 61.0 | % |  | 62.6 | % |  | 61.9 | % |
| GAAP income from operations |  | $ | 639,914 |  |  | $ | 468,919 |  |  | $ | 2,257,249 |  |  | $ | 1,527,106 |  |
| Stock-based compensation expense |  | 81,358 |  |  | 64,954 |  |  | 296,756 |  |  | 230,934 |  |
| Intangible asset amortization |  | 6,690 |  |  | 9,316 |  |  | 33,437 |  |  | 33,650 |  |
| Acquisition-related costs(1) |  | — |  |  | — |  |  | — |  |  | 4,691 |  |
| Legal settlement (2) |  | 16,000 |  |  | — |  |  | 16,000 |  |  | — |  |
| Non-GAAP income from operations |  | $ | 743,962 |  |  | $ | 543,189 |  |  | $ | 2,603,442 |  |  | $ | 1,796,381 |  |
| Non-GAAP operating margin |  | 48.3 | % |  | 42.6 | % |  | 44.4 | % |  | 41.0 | % |
| GAAP net income |  | $ | 613,636 |  |  | $ | 427,089 |  |  | $ | 2,087,321 |  |  | $ | 1,352,446 |  |
| Stock-based compensation expense |  | 81,358 |  |  | 64,954 |  |  | 296,756 |  |  | 230,934 |  |
| Intangible asset amortization |  | 6,690 |  |  | 9,316 |  |  | 33,437 |  |  | 33,650 |  |
| Acquisition-related costs(1) |  | — |  |  | — |  |  | — |  |  | 4,691 |  |
| Gain on strategic investments |  | — |  |  | (3,358) |  |  | (18,699) |  |  | (27,479) |  |
| Tax benefit on stock-based awards |  | (40,561) |  |  | (37,177) |  |  | (174,122) |  |  | (113,502) |  |
| Income tax effect on non-GAAP exclusions |  | (12,795) |  |  | (15,677) |  |  | (41,283) |  |  | (32,482) |  |
| Legal settlement (2) |  | 16,000 |  |  | — |  |  | 16,000 |  |  | — |  |
| Non-GAAP net income |  | $ | 664,328 |  |  | $ | 445,147 |  |  | $ | 2,199,410 |  |  | $ | 1,448,258 |  |
| GAAP diluted net income per share |  | $ | 1.92 |  |  | $ | 1.35 |  |  | $ | 6.58 |  |  | $ | 4.27 |  |
| Non-GAAP adjustments to net income |  | 0.16 |  |  | 0.06 |  |  | 0.36 |  |  | 0.31 |  |
| Non-GAAP diluted net income per share |  | $ | 2.08 |  |  | $ | 1.41 |  |  | $ | 6.94 |  |  | $ | 4.58 |  |
| Weighted-average shares used in computing diluted net income per share |  | 318,845 |  |  | 315,201 |  |  | 317,135 |  |  | 316,459 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 3,273 |  |  | $ | 3,075 |  |  | $ | 12,789 |  |  | $ | 9,688 |  |
| Research and development |  | 46,506 |  |  | 37,174 |  |  | 172,177 |  |  | 130,897 |  |
| Sales and marketing |  | 19,613 |  |  | 15,532 |  |  | 71,074 |  |  | 57,571 |  |
| General and administrative |  | 11,966 |  |  | 9,173 |  |  | 40,716 |  |  | 32,778 |  |
| Total |  | $ | 81,358 |  |  | $ | 64,954 |  |  | $ | 296,756 |  |  | $ | 230,934 |  |

[0001596532-24-000041:8k_2_02:61]
___________________

[0001596532-24-000041:8k_2_02:62]
(1) Represents costs associated with business combinations, which primarily include retention bonuses, and professional and consulting fees.

[0001596532-24-000041:8k_2_02:63]
(2) In the quarter ended December 31, 2023, we agreed to pay $16 million to settle an intellectual property dispute and we recorded this amount to general and administrative expenses.

[0001596532-24-000041:8k_2_02:64]
ARISTA NETWORKS, INC.

[0001596532-24-000041:8k_2_02:65]
Condensed Consolidated Balance Sheets

[0001596532-24-000041:8k_2_02:66]
(Unaudited, in thousands)

[0001596532-24-000041:8k_2_02:67]
|  |  | December 31, 2023 |  | December 31, 2022 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,938,606 |  |  | $ | 671,707 |  |
| Marketable securities |  | 3,069,362 |  |  | 2,352,022 |  |
| Accounts receivable |  | 1,024,569 |  |  | 923,096 |  |
| Inventories |  | 1,945,180 |  |  | 1,289,706 |  |
| Prepaid expenses and other current assets |  | 412,518 |  |  | 314,217 |  |
| Total current assets |  | 8,390,235 |  |  | 5,550,748 |  |
| Property and equipment, net |  | 101,580 |  |  | 95,009 |  |
| Acquisition-related intangible assets, net |  | 88,768 |  |  | 122,205 |  |
| Goodwill |  | 268,531 |  |  | 265,924 |  |
| Deferred tax assets |  | 945,792 |  |  | 574,912 |  |
| Other assets |  | 151,900 |  |  | 166,612 |  |
| TOTAL ASSETS |  | $ | 9,946,806 |  |  | $ | 6,775,410 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 435,059 |  |  | $ | 232,572 |  |
| Accrued liabilities |  | 407,302 |  |  | 292,487 |  |
| Deferred revenue |  | 915,204 |  |  | 637,432 |  |
| Other current liabilities |  | 152,041 |  |  | 131,040 |  |
| Total current liabilities |  | 1,909,606 |  |  | 1,293,531 |  |
| Income taxes payable |  | 95,751 |  |  | 89,839 |  |
| Deferred revenue, non-current |  | 591,000 |  |  | 403,814 |  |
| Other long-term liabilities |  | 131,390 |  |  | 102,406 |  |
| TOTAL LIABILITIES |  | 2,727,747 |  |  | 1,889,590 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 31 |  |  | 31 |  |
| Additional paid-in capital |  | 2,108,331 |  |  | 1,780,714 |  |
| Retained earnings |  | 5,114,025 |  |  | 3,138,983 |  |
| Accumulated other comprehensive income (loss) |  | (3,328) |  |  | (33,908) |  |
| TOTAL STOCKHOLDERS’ EQUITY |  | 7,219,059 |  |  | 4,885,820 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 9,946,806 |  |  | $ | 6,775,410 |  |

[0001596532-24-000041:8k_2_02:68]
7

[0001596532-24-000041:8k_2_02:69]
ARISTA NETWORKS, INC.

[0001596532-24-000041:8k_2_02:70]
Condensed Consolidated Statements of Cash Flows

[0001596532-24-000041:8k_2_02:71]
(Unaudited, in thousands)

[0001596532-24-000041:8k_2_02:72]
|  |  | Twelve Months Ended December 31, |
|  |  | 2023 |  | 2022 |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 2,087,321 |  |  | $ | 1,352,446 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 70,630 |  |  | 62,700 |  |
| Noncash lease expense |  | 18,236 |  |  | 18,648 |  |
| Stock-based compensation |  | 296,756 |  |  | 230,934 |  |
| Deferred income taxes |  | (370,796) |  |  | (244,382) |  |
| Gain on strategic investments |  | (18,699) |  |  | (27,479) |  |
| Amortization of investment premiums |  | (33,518) |  |  | 12,767 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (101,473) |  |  | (401,531) |  |
| Inventories |  | (655,474) |  |  | (638,948) |  |
| Other assets |  | (66,401) |  |  | (117,465) |  |
| Accounts payable |  | 198,612 |  |  | 31,436 |  |
| Other liabilities |  | 123,694 |  |  | 70,704 |  |
| Deferred revenue |  | 464,958 |  |  | 98,957 |  |
| Income taxes, net |  | 20,168 |  |  | 44,026 |  |
| Net cash provided by operating activities |  | 2,034,014 |  |  | 492,813 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 1,887,939 |  |  | 1,643,824 |  |
| Proceeds from sale of marketable securities |  | 67,284 |  |  | 193,782 |  |
| Purchases of marketable securities |  | (2,606,878) |  |  | (1,418,857) |  |
| Purchases of property, equipment and intangible assets |  | (34,434) |  |  | (44,644) |  |
| Cash paid for business combination, net of cash acquired |  | 1,799 |  |  | (145,087) |  |
| Investment in notes and privately-held companies |  | (3,164) |  |  | (12,691) |  |
| Net cash provided by (used in) investing activities |  | (687,454) |  |  | 216,327 |  |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Proceeds from issuance of common stock under equity plans |  | 62,093 |  |  | 48,411 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (33,563) |  |  | (32,725) |  |
| Repurchase of common stock |  | (112,279) |  |  | (670,287) |  |
| Net cash used in financing activities |  | (83,749) |  |  | (654,601) |  |
| Effect of exchange rate changes |  | 675 |  |  | (3,611) |  |
| NET INCREASE/(DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH |  | 1,263,486 |  |  | 50,928 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period |  | 675,978 |  |  | 625,050 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period |  | $ | 1,939,464 |  |  | $ | 675,978 |  |

[0001596532-24-000041:8k_2_02:73]
| Investor Contacts: |  |
| Arista Networks, Inc. |  |
| Liz Stine, 408-547-5885 |
| Director, Investor Relations |
| liz@arista.com |  |
