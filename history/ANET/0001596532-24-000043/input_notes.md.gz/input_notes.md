# ANET notes — 0001596532-24-000043


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001596532-24-000043:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001596532-24-000043:notes:2]
Portions of the registrant’s definitive Proxy Statement relating to its 2024 Annual Meeting of Stockholders to be filed pursuant to Regulation 14A within 120 days after the registrant’s fiscal year end of December 31, 2023 are incorporated by reference into Part III of this Annual Report on Form 10-K.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-24-000043:notes:3]
Organization and Summary of Significant Accounting Policies
Organization

[0001596532-24-000043:notes:4]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our,” "Arista," "Company" or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of next-generation data center and campus workspace environments. Our cloud networking solutions consist of our EOS, a set of network applications and our Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-24-000043:notes:5]
Basis of Presentation and Principles of Consolidation

[0001596532-24-000043:notes:6]
The accompanying consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly-owned subsidiaries and are prepared in accordance with accounting principles generally accepted in the United States ("GAAP"). All significant intercompany accounts and transactions have been eliminated.

[0001596532-24-000043:notes:7]
Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.

[0001596532-24-000043:notes:8]
Risk and Uncertainties

[0001596532-24-000043:notes:9]
Global economic and business activities continue to face widespread macroeconomic uncertainties, including inflation, monetary policy shifts, recession risks, and potential supply chain and other disruptions such as the Russia-Ukraine and Israel-Hamas conflicts, the Houthi attacks on marine vessels in the Red Sea and the U.S. trade war with China.

[0001596532-24-000043:notes:10]
As we exit 2023, the business is emerging from a period of unprecedented global supply chain disruptions.  Throughout this period, we made significant supply chain investments, including funding additional working capital and incremental purchase commitments in response to extended visibility to deployment plans from our customers. We have worked closely with our contract manufacturers and supply chain partners to ramp production following a period of delayed component sourcing and workforce disruptions. This increased capacity has allowed us to ship products against previously committed demand/deployment plans and accelerate some deployments where needed, while trying to limit building customer inventory and to some extent balancing customer lead times with those currently experienced from our key suppliers. As a result, some shipments against these previously committed demand/deployment plans have extended into 2024.

[0001596532-24-000043:notes:11]
As the global supply chain has experienced some improvements and as customer lead times have been reduced from their peak, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to shorter demand-planning horizons resulting in lower demand levels.  Given these shipment and order patterns, near term revenue trends may not be solely reflective of current demand levels, but as discussed above will benefit from demand/deployment plans that had been previously committed. While inventory and working capital levels may remain elevated in the near term, we expect that purchase commitments will continue to decline as supplier lead times shorten. The larger magnitude of these balances, combined with a reduction in customer demand-planning horizons and shifting customer product priorities, has resulted in increased risk that we may not be able to sell all of this inventory, which in turn has resulted, and may in the future result, in additional excess and obsolete inventory and supplier liability charges.

[0001596532-24-000043:notes:12]
In addition, inflation pressure in our supply chain, scarcity of some materials needed to build our products and disruptions to our manufacturing process have increased our cost of revenue and have impacted, and may continue to negatively impact our gross margin. Our operating cash-flows have also been and may continue to be negatively impacted by significant component inventories on hand or at our contract manufacturers. While we have seen improvements in our supply chain and manufacturing operations, any remaining or new supply chain and manufacturing related constraints could negatively impact our business in future periods. In addition, although our business has experienced limited disruption as a result of the Russia-Ukraine conflict, continued escalation of this conflict as well as the Israeli-Hamas conflict and Houthi movement in the Red Sea may negatively impact the global economy and our future operating results and financial condition.

[0001596532-24-000043:notes:13]
Management continues to actively monitor the impact of macroeconomic factors on the Company's financial condition, liquidity, operations, suppliers, industry, and workforce. The extent of the impact of these factors on our operational

[0001596532-24-000043:notes:14]
and financial performance, including our ability to execute our business strategies and initiatives in the expected time frame, will depend on future developments, the impact on our customers, partners, employees, contract manufacturers and supply chain, all of which continue to evolve and are unpredictable. In addition, any continued or renewed disruption in manufacturing and supply resulting from these factors could negatively impact our business. We also believe that some of our customers, following a year of elevated purchases, must now consider changing technology roadmaps and priorities, including the need for the rapid deployment of AI and related technologies, resulting in some uncertainty as to future investment plans and a more constrained approach to some forecasts and orders in the near term. In addition, any prolonged economic disruptions or further deterioration in the global economy could have a negative impact on demand from our customers in future periods, particularly in the enterprise market where we are continuing to expand our penetration. Accordingly, current results and financial conditions discussed herein may not be indicative of future operating results and trends.

[0001596532-24-000043:notes:15]
Use of Estimates

[0001596532-24-000043:notes:16]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, valuation of inventory and contract manufacturer/supplier liabilities, accounting for income taxes, including the recognition of deferred tax assets and liabilities, valuation allowance on deferred tax assets and reserves for uncertain tax positions, revenue recognition and deferred revenue, allowance for doubtful accounts, sales rebates and return reserves, valuation of goodwill and acquisition-related intangible assets, estimate of useful lives of long-lived assets including intangible assets, and the recognition and measurement of contingent liabilities. We evaluate our estimates and assumptions based on historical experience and other factors and adjust these estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from these estimates.

[0001596532-24-000043:notes:17]
Concentrations of Business and Credit Risk

[0001596532-24-000043:notes:18]
We work closely with third-party contract manufacturers to manufacture our products. As of December 31, 2023, we had four primary contract manufacturing partners, who provided the vast majority of our electronic manufacturing services. Our contract manufacturing partners deliver our products to our third-party direct fulfillment facilities. We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers. Our products rely on key components, including certain integrated circuit components and power supplies, some of which our contract manufacturing partners purchase on our behalf from a limited number of suppliers, including certain sole-source providers. We generally do not have guaranteed supply contracts with our component suppliers, and our manufacturing partners could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, or if we are unable to obtain alternative sources for these components, sales of our products could be delayed or halted entirely, or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.

[0001596532-24-000043:notes:19]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, marketable securities, and accounts receivable. Our cash equivalents and marketable securities are invested in high quality financial instruments with banks and financial institutions. Such deposits may be in excess of insured limits provided on such deposits.

[0001596532-24-000043:notes:20]
Our accounts receivable are unsecured and represent amounts due to us based on contractual obligations of our customers. We mitigate credit risk with respect to accounts receivable by performing ongoing credit evaluations of our customers to assess the probability of collection based on a number of factors, including past transaction experience with the customer, evaluation of their credit history, the credit limits extended, review of the invoicing terms of the arrangement, and current economic conditions that may affect a customer’s ability to pay. In situations where a customer may be thinly capitalized and we have limited payment history with it, we will either establish a small credit limit or require it to prepay its purchases. We generally do not require our customers to provide collateral to support accounts receivable. We have recorded an allowance for doubtful accounts for accounts receivables that we have determined to be uncollectible. We mitigate credit risk with respect to accounts receivables by performing ongoing credit evaluations of the borrower to assess the probability of collecting all amounts due to us under the existing contractual terms.

[0001596532-24-000043:notes:21]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators and OEM partners, and in conjunction with various technology partners.  Significant customers are those that represent more than 10% of our total net revenue during the period or net accounts receivable balance at each respective balance sheet date. As of December 31, 2023, we had two customers who represented 28% and 11% of total accounts receivable. As of December 31, 2022, we had two customers who represented 28% and 16% of total accounts receivable. For the year ended December 31, 2023, there were two end customers who represented 21% and 18% of total revenue. For the year ended December 31, 2022, there were two end customers who represented 26% and 16% of total revenue. For the year ended December 31, 2021, there was one end customer who represented 15% of our total revenue.

[0001596532-24-000043:notes:22]
Cash and Cash Equivalents

[0001596532-24-000043:notes:23]
We consider all highly liquid investments with original or remaining maturities of three months or less at the time of purchase to be cash equivalents. Cash and cash equivalents consist of cash on deposit with various financial institutions and highly liquid investments in money market funds. Interest is accrued as earned.

[0001596532-24-000043:notes:24]
Marketable Securities

[0001596532-24-000043:notes:25]
We classify all highly liquid investments in debt securities with maturities of greater than three months at the date of purchase as marketable securities. We have classified and accounted for our marketable debt and equity securities as available-for-sale. We determine the appropriate classification of these investments at the time of purchase and reevaluate such designation at each balance sheet date. We may or may not hold securities with stated maturities greater than 12 months until maturity. After consideration of our risk versus reward objectives, as well as our liquidity requirements, we may sell these securities prior to their stated maturities. As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets. We carry these securities at fair value. For marketable debt securities, we report the unrealized gains and losses, net of taxes, as a component of stockholders’ equity. For marketable equity securities, we report the unrealized gains and losses in other income (expense), net on the Consolidated Statements of Operations. We determine the cost of the debt investment sold based on an average cost basis at the individual security level, and record the interest income in other income, net in the accompanying consolidated statements of operations. We determine any realized gains or losses on the sale of marketable securities using the specific identification method, and record such gains and losses in other income, net in the accompanying consolidated statements of operations.

[0001596532-24-000043:notes:26]
For our debt securities in an unrealized loss position, we determine whether a credit loss exists by considering, among other factors, current market conditions, credit quality of debt issuers, any changes to the rating of the security by a rating agency, and the extent to which fair value is less than cost. We recognize an allowance for credit losses, up to the amount of the unrealized loss when appropriate, and write down the amortized cost basis of the investment if it is more likely than not we will be required to sell or we intend to sell the investment before recovery of its amortized cost basis.

[0001596532-24-000043:notes:27]
Accounts Receivable

[0001596532-24-000043:notes:28]
Accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts, sales rebates and returns reserves. We estimate our allowance for doubtful accounts based upon the collectability of the receivables in light of historical trends, reasonable and supportable information of our customers' economic conditions that may affect our customers’ ability to pay, and prevailing economic conditions. This evaluation is done in order to identify issues that may impact the collectability of receivables and related estimated required allowance. Revisions to the allowance are recorded as an adjustment to bad debt expense. After appropriate collection efforts are exhausted, specific accounts receivable deemed to be uncollectible are charged against the allowance in the period they are deemed uncollectible. Recoveries of accounts receivable previously written-off are recorded as credits to bad debt expense. We primarily estimate our sales rebates and returns reserves based on historical rates applied against current period billings. Specific customer returns, rebates and allowances are considered when determining our estimates. Revisions to sales rebate and return reserves are recorded as adjustments to revenue.

[0001596532-24-000043:notes:29]
Fair Value Measurements

[0001596532-24-000043:notes:30]
Fair value is defined as the exchange price that would be received for an asset or an exit price that would be paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. These assets and liabilities include cash and cash equivalents, marketable securities, accounts receivable, accounts payable, and accrued liabilities. Cash equivalents,

[0001596532-24-000043:notes:31]
accounts receivable, accounts payable and accrued liabilities are stated at carrying values in our consolidated financial statements, which approximate their fair value due to the short-term nature of these instruments.

[0001596532-24-000043:notes:32]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value. We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs. The three-tiers of the fair value hierarchy are as follows:

[0001596532-24-000043:notes:33]
Level I—Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date;

[0001596532-24-000043:notes:34]
Level II—Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities; and

[0001596532-24-000043:notes:35]
Level III—Unobservable inputs that are supported by little or no market data for the related assets or liabilities and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.

[0001596532-24-000043:notes:36]
Foreign Currency

[0001596532-24-000043:notes:37]
The functional currency of our foreign subsidiaries is either the U.S. dollar or their local currency depending on the nature of the subsidiaries’ activities.

[0001596532-24-000043:notes:38]
Transaction re-measurement - Assets and liabilities denominated in a currency other than a subsidiary’s functional currency are re-measured into the subsidiary's functional currency using exchange rates in effect at the end of the reporting period, with gains and losses recorded in other income, net in the consolidated statements of operations. To date, foreign currency transaction gains and losses and exchange rate fluctuations have not been material to our consolidated financial statements.

[0001596532-24-000043:notes:39]
Translation - Assets and liabilities of subsidiaries denominated in foreign functional currencies are translated into U.S. dollars at the closing exchange rate on the balance sheet date and equity-related balances are translated at historical exchange rates. Revenues, costs and expenses in foreign functional currencies are translated using average exchange rates that approximate those in effect during the period. Translation adjustments are recorded within accumulated other comprehensive income, a separate component of total stockholders’ equity.

[0001596532-24-000043:notes:40]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-24-000043:notes:41]
Inventories primarily consist of finished goods and strategic components, primarily integrated circuits. Inventories are stated at the lower of cost (computed using the first-in, first-out method) and net realizable value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory. We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value. For the years ended December 31, 2023, 2022 and 2021, we recorded charges of $234.4 million, $71.4 million and $61.8 million, respectively, within cost of product revenue for inventory write-downs.

[0001596532-24-000043:notes:42]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts. We record a liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with our contract manufacturers or suppliers for quantities in excess of our demand forecasts or that are considered obsolete due to manufacturing and engineering change orders resulting from design changes. For the years ended December 31, 2023 and 2022, we recorded charges of $113.0 million and $43.7 million, respectively, within cost of product revenue for such liabilities with our contract manufacturers and suppliers. For the year ended December 31, 2021, we did not incur any losses on such liabilities.

[0001596532-24-000043:notes:43]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels.  In addition, when industry-wide supply chain shortages resulted in extended lead times for components, we were  required to extend the time horizon of our demand forecasts and increase our purchase commitments for long lead time components. As customer lead times reduce more broadly, we have seen and expect to continue to see a commensurate reduction in visibility to customer demand and a gradual return to shorter demand-planning horizons resulting in lower demand levels.  While inventory and working capital levels may remain elevated in the near term, we expect that purchase commitments will continue to decline as supplier lead times shorten. There is however no guarantee that all suppliers will meet their

[0001596532-24-000043:notes:44]
commitments in the time frame committed or that actual customer demand will directly match our demand forecasts. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and/or outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer and supplier liabilities.

[0001596532-24-000043:notes:45]
Property and Equipment

[0001596532-24-000043:notes:46]
Property and equipment are stated at cost, less accumulated depreciation, except for land which is not depreciated. We capitalize any additions and improvements and expense maintenance and repairs as incurred. Depreciation is calculated using the straight-line method over the estimated useful lives of the related assets, generally three years. Our leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term.

[0001596532-24-000043:notes:47]
Leases

[0001596532-24-000043:notes:48]
We lease office space, data centers, and equipment under non-cancellable operating leases with various expiration dates through 2029. We determine if an arrangement contains a lease at inception. Operating leases are recorded as right-of-use (“ROU”) assets and lease liabilities, and are included in other assets and other current and non-current liabilities in our consolidated balance sheets. We do not have any finance leases in any of the periods presented.

[0001596532-24-000043:notes:49]
ROU assets and lease liabilities are recognized at the commencement date based on the present value of remaining lease payments over the lease term. The interest rate implicit in our operating leases is not readily available, and therefore, an incremental borrowing rate is estimated based on a hypothetical interest rate on a collateralized basis with similar terms, payments, and economic environments. ROU assets also include any prepaid lease payments and lease incentives.

[0001596532-24-000043:notes:50]
Our operating lease agreements may contain rent concession, rent escalation, and option to renew provisions. Lease expense is recognized on a straight-line basis over the lease term commencing on the date we have the right to use the leased property. Our lease terms may include options to extend or terminate the lease when it is reasonably certain that the option will be exercised. In addition, certain of our operating lease agreements contain tenant improvement allowances from landlords. These allowances are accounted for as lease incentives and decrease our right-of-use asset and reduce lease expense over the lease term.

[0001596532-24-000043:notes:51]
Our lease agreements may contain lease and non-lease components, which are combined and accounted for as a single lease component. We also have elected to apply the short-term lease measurement and recognition exemption in which ROU assets and lease liabilities are not recognized for leases with terms of 12 months or less.

[0001596532-24-000043:notes:52]
Business Combinations

[0001596532-24-000043:notes:53]
We use the acquisition method to account for our business combinations in accordance with Accounting Standards Codification ("ASC") 805 - Business Combinations. We allocate the total fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the consideration transferred over the fair values of the assets acquired and liabilities assumed is recorded as goodwill. The results of operations of the acquired businesses are included in our consolidated financial statements from the date of acquisition. Acquisition-related transaction and restructuring costs are expensed as incurred.

[0001596532-24-000043:notes:54]
During the measurement period, which is not to exceed one year from the acquisition date, we may record adjustments to the acquired assets and liabilities assumed, with a corresponding offset to goodwill or the preliminary purchase price, to reflect new information obtained about facts and circumstances that existed as of the acquisition date. Upon the conclusion of the measurement period, any subsequent adjustments are recorded to earnings.

[0001596532-24-000043:notes:55]
Goodwill and Acquired Intangible Assets

[0001596532-24-000043:notes:56]
Goodwill represents the excess of the purchase price over the fair value of net assets acquired in a business combination. The Company has one reporting unit and tests goodwill for impairment at least annually in the fourth quarter or more frequently if indicators of potential impairment exist. We first perform a qualitative assessment to determine whether it is more likely than not that the fair value of our reporting unit is less than its carrying amount. If the reporting unit does not pass the qualitative assessment, a quantitative test is performed by comparing the fair value of our reporting unit with its carrying amount. We would recognize an impairment loss for the amount by which the carrying amount exceeds the fair value. There

[0001596532-24-000043:notes:57]
were no impairment charges in any of the periods presented in the consolidated financial statements. See Note 4. Acquisition, Goodwill and Acquisition-Related Intangible Assets for additional information.

[0001596532-24-000043:notes:58]
Acquired intangible assets are carried at cost less accumulated amortization. All acquired intangible assets have been determined to have definite lives and are amortized on a straight-line basis over their estimated useful lives, ranging from three to eight years. Acquired intangible assets are reviewed for impairment under the long-lived asset model described below. There were no impairment charges in any of the periods presented in the consolidated financial statements. See Note 4. Acquisition, Goodwill and Acquisition-Related Intangible Assets for additional information.

[0001596532-24-000043:notes:59]
Equity Investments in Privately-Held Companies

[0001596532-24-000043:notes:60]
Our equity investments in privately-held companies without readily determinable fair values are measured using the measurement alternative, defined by ASC 321 - Investments-Equity Securities as cost, less impairments, and remeasured based on observable price changes from orderly transactions of identical or similar securities of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded within other income, net, in our consolidated statements of operations. This election is reassessed each reporting period to determine whether investments in privately-held companies have a readily determinable fair value, in which case they would no longer be eligible for this election. The Company did not hold investments in privately-held companies whose fair value was readily determinable as of December 31, 2023 and 2022.

[0001596532-24-000043:notes:61]
Impairment of Long-Lived Assets and Investments in Privately-Held Companies

[0001596532-24-000043:notes:62]
The carrying amounts of our long-lived assets, including property and equipment, intangible assets, ROU assets and investments in privately-held companies, are periodically reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. Recoverability of these assets is measured by comparison of the carrying amount of each asset to the future undiscounted cash flows the asset is expected to generate over its remaining life. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. No impairment of any long-lived assets was identified for any of the periods presented in the consolidated financial statements.

[0001596532-24-000043:notes:63]
Loss Contingencies

[0001596532-24-000043:notes:64]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgments and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements, and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.

[0001596532-24-000043:notes:65]
Revenue Recognition

[0001596532-24-000043:notes:66]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with post-contract customer support (“PCS”). We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

[0001596532-24-000043:notes:67]
•Identification of the contract, or contracts, with a customer

[0001596532-24-000043:notes:68]
•Identification of the performance obligations in the contract

[0001596532-24-000043:notes:69]
•Determination of the transaction price

[0001596532-24-000043:notes:70]
•Allocation of the transaction price to the performance obligations in the contract

[0001596532-24-000043:notes:71]
•Recognition of revenue when (or as) we satisfy the performance obligation

[0001596532-24-000043:notes:72]
Post-Contract Customer Support ("PCS")

[0001596532-24-000043:notes:73]
PCS, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts. We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernible pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and address customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-24-000043:notes:74]
Contracts with Multiple Performance Obligations

[0001596532-24-000043:notes:75]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts that contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price ("SSP"). Judgment is required to determine the SSP for each distinct performance obligation. We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

[0001596532-24-000043:notes:76]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as gross margin, market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to product category, actual and expected volume, discounting policies, and end customer vertical and size.

[0001596532-24-000043:notes:77]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at-risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

[0001596532-24-000043:notes:78]
Most of our contracts with customers have standard payment terms of 30 days and the remainder generally between 30 to 90 days. We have determined our contracts generally do not include a significant financing component because the Company and the customer have specific business reasons other than financing for entering into such contracts. Specifically, both we and our customers seek to ensure the customer has a simplified way of purchasing Arista products and services.

[0001596532-24-000043:notes:79]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

[0001596532-24-000043:notes:80]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical return rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-24-000043:notes:81]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

[0001596532-24-000043:notes:82]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

[0001596532-24-000043:notes:83]
Contract Balances

[0001596532-24-000043:notes:84]
A contract asset is recognized when we have a contractual right to consideration for both completed and partially completed performance obligations that have not yet been invoiced. Contract assets are included in other current assets in the accompanying consolidated balance sheets.

[0001596532-24-000043:notes:85]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a contract that is cancellable. Contract liabilities are included in other current liabilities and other long-term liabilities in the accompanying consolidated balance sheets.

[0001596532-24-000043:notes:86]
Research and Development Expenses

[0001596532-24-000043:notes:87]
Costs related to the research, design and development of our products are charged to research and development expenses as incurred. Software development costs are capitalized beginning when a product’s technological feasibility has been established and ending when the product is available for general release to customers. Generally, our products are released soon after technological feasibility has been established. As a result, costs incurred subsequent to achieving technological feasibility have not been significant and accordingly, all software development costs have been expensed as incurred.

[0001596532-24-000043:notes:88]
Segment Reporting

[0001596532-24-000043:notes:89]
We develop, market and sell cloud networking solutions, which primarily consist of our switching and routing platforms and related network applications, and there are no segment managers who are held accountable for operations or operating results below the Company level. Our chief operating decision maker is our Chief Executive Officer, who reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance. Accordingly, we have determined that we operate as one reportable segment.

[0001596532-24-000043:notes:90]
Stock-Based Compensation

[0001596532-24-000043:notes:91]
Stock-based compensation cost for equity awards is measured at the grant-date fair value using appropriate valuation techniques and recognized as expense over the requisite service or performance period. We account for forfeitures when they occur.

[0001596532-24-000043:notes:92]
Stock-based compensation costs for stock options and restricted stock units ("RSUs") are recognized on a straight-line basis over the requisite service period, which is generally two to five years. The Company has granted RSUs that vest upon the satisfaction of both service-based and performance-based conditions ("PRSUs"). The service-based condition for these awards is generally satisfied over four years. The performance-based conditions are satisfied upon achieving specified performance targets, such as financial or operating metrics. We record stock-based compensation expense for performance-based equity awards on an accelerated attribution method over the requisite service period, and only if performance-based conditions are considered probable to be satisfied.

[0001596532-24-000043:notes:93]
See Note 6. Stockholders' Equity and Stock-Based Compensation for a detailed discussion of the Company’s stock plans, assumptions to the valuation techniques, and stock-based compensation expense.

[0001596532-24-000043:notes:94]
Income Taxes

[0001596532-24-000043:notes:95]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-24-000043:notes:96]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-24-000043:notes:97]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-24-000043:notes:98]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.

[0001596532-24-000043:notes:99]
The U.S. tax rules require U.S. tax on foreign earnings, known as global intangible low taxed income (“GILTI”). Under U.S. GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”). We selected the deferred method of accounting and recorded the associated basis differences anticipated to influence prospective GILTI calculations.

[0001596532-24-000043:notes:100]
Recent Accounting Pronouncements Not Yet Effective

[0001596532-24-000043:notes:101]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740)-Improvements to Income Tax Disclosures. The ASU requires that an entity disclose specific categories in the effective tax rate reconciliation as well as provide additional information for reconciling items that meet a quantitative threshold. Further, the ASU requires certain disclosures of state versus federal income tax expense and taxes paid. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2024. Early adoption is permitted for annual financial statements that have not yet been issued. The amendments should be applied on a prospective basis although retrospective application is permitted. we have not early adopted ASU 2023-09 for December 31, 2023. We are currently evaluating the impact of future adoption on our financial disclosures.

[0001596532-24-000043:notes:102]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280)-Improvements to Reportable Segment Disclosures. The ASU requires that an entity disclose significant segment expenses impacting profit and loss that are regularly provided to the chief operating decision maker. The update is required to be applied retrospectively to prior periods presented, based on the significant segment expense categories identified and disclosed in the period of adoption. The amendments in this ASU are required to be adopted for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024. Early adoption is permitted. We have not early adopted ASU 2023-07 for the year ended December 31, 2023. We are currently evaluating the impact of future adoption on our financial disclosures.


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-24-000043:notes:103]
Fair Value Measurements
Assets measured at fair values on a recurring basis

[0001596532-24-000043:notes:104]
We measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value on a recurring basis. The following tables summarize the fair value of these financial assets by significant investment category and their levels within the fair value hierarchy (in thousands):

[0001596532-24-000043:notes:105]
|  |  | December 31, 2023 |  | December 31, 2022 |
|  |  | Level I |  | Level II |  | Level III |  | Total |  | Level I |  | Level II |  | Level III |  | Total |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,015,705 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,015,705 |  |  | $ | 322,294 |  |  | $ | — |  |  | $ | — |  |  | $ | 322,294 |  |
| Commercial paper |  | — |  |  | 1,999 |  |  | — |  |  | 1,999 |  |  | — |  |  | 5,422 |  |  | — |  |  | 5,422 |  |
| Agency securities |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 17,559 |  |  | — |  |  | 17,559 |  |
| U.S. government notes |  | — |  |  | — |  |  | — |  |  | — |  |  | 51,986 |  |  | — |  |  | — |  |  | 51,986 |  |
|  |  | 1,015,705 |  |  | 1,999 |  |  | — |  |  | 1,017,704 |  |  | 374,280 |  |  | 22,981 |  |  | — |  |  | 397,261 |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposits (1) |  | — |  |  | 5,000 |  |  | — |  |  | 5,000 |  |  | — |  |  | 10,492 |  |  | — |  |  | 10,492 |  |
| U.S. government notes |  | 1,044,859 |  |  | — |  |  | — |  |  | 1,044,859 |  |  | 993,955 |  |  | — |  |  | — |  |  | 993,955 |  |
| Corporate bonds |  | — |  |  | 1,362,124 |  |  | — |  |  | 1,362,124 |  |  | — |  |  | 1,113,134 |  |  | — |  |  | 1,113,134 |  |
| Agency securities |  | — |  |  | 657,379 |  |  | — |  |  | 657,379 |  |  | — |  |  | 215,380 |  |  | — |  |  | 215,380 |  |
| Marketable equity securities(2) |  | — |  |  | — |  |  | — |  |  | — |  |  | 19,061 |  |  | — |  |  | — |  |  | 19,061 |  |
|  |  | 1,044,859 |  |  | 2,024,503 |  |  | — |  |  | 3,069,362 |  |  | 1,013,016 |  |  | 1,339,006 |  |  | — |  |  | 2,352,022 |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 858 |  |  | — |  |  | — |  |  | 858 |  |  | 4,271 |  |  | — |  |  | — |  |  | 4,271 |  |
| Total Financial Assets |  | $ | 2,061,422 |  |  | $ | 2,026,502 |  |  | $ | — |  |  | $ | 4,087,924 |  |  | $ | 1,391,567 |  |  | $ | 1,361,987 |  |  | $ | — |  |  | $ | 2,753,554 |  |

[0001596532-24-000043:notes:106]
______________________________________

[0001596532-24-000043:notes:107]
(1) As of December 31, 2023 and 2022, all of our certificates of deposits were domestic deposits.

[0001596532-24-000043:notes:108]
(2) During the year ended December 31, 2023, the Company sold all its shares of its marketable equity security for $23.9 million. This publicly-traded equity investment generated an unrealized gain of $4.8 million and $10.7 million for the year ended December 31, 2023 and 2022, respectively. The initial cost of this investment was $3.0 million with no changes since our initial investment. The cumulative gain from the initial purchase was $20.9 million, the majority of which has been reflected in prior periods as net unrealized gains. The realized and unrealized gains/losses are included in Other income (expense), net on the unaudited Condensed Consolidated Statements of Operations. Refer to Note 3. Financial Statements Details.

[0001596532-24-000043:notes:109]
During the year ended on December 31, 2023, the Company did not make any transfers between the levels of the fair value hierarchy.

[0001596532-24-000043:notes:110]
Marketable debt securities

[0001596532-24-000043:notes:111]
The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities measured at fair value on a recurring basis (in thousands):

[0001596532-24-000043:notes:112]
|  |  | December 31, 2023 |  | December 31, 2022 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |
| U.S. government |  | 1,043,445 |  |  | 2,874 |  |  | (1,460) |  |  | 1,044,859 |  |  | 1,007,175 |  |  | 3 |  |  | (13,223) |  |  | 993,955 |  |
| Corporate bonds |  | 1,361,132 |  |  | 2,810 |  |  | (1,818) |  |  | 1,362,124 |  |  | 1,125,920 |  |  | 271 |  |  | (13,057) |  |  | 1,113,134 |  |
| Agency securities |  | 657,118 |  |  | 1,143 |  |  | (882) |  |  | 657,379 |  |  | 217,893 |  |  | 83 |  |  | (2,596) |  |  | 215,380 |  |
| Total |  | $ | 3,061,695 |  |  | $ | 6,827 |  |  | $ | (4,160) |  |  | $ | 3,064,362 |  |  | $ | 2,350,988 |  |  | $ | 357 |  |  | $ | (28,876) |  |  | $ | 2,322,469 |  |

[0001596532-24-000043:notes:113]
For debt securities in unrealized loss positions, it is not likely that we will be required to sell such securities before recovery of their amortized cost basis nor do we have the intent to sell such securities before maturity; we invest in debt securities that have maximum maturities of two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. Given the short-term and conservative nature of our portfolio, the unrealized losses are not subject to credit risk; therefore, we did not recognize any credit losses or non-credit-related impairments related to our available-for-sale marketable debt securities for the years ended December 31, 2023, December 31, 2022 and December 31, 2021. All unrealized losses were recognized in other comprehensive income (loss). Realized losses were immaterial for the years ended December 31, 2023, December 31, 2022 and December 31, 2021.

[0001596532-24-000043:notes:114]
The following table is an analysis of our marketable debt securities in unrealized loss positions (in thousands):

[0001596532-24-000043:notes:115]
|  |  | December 31, 2023 |
|  |  | Unrealized Losses within 12 months |  | Unrealized Losses 12 months or greater |  | Total |
|  |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| U.S. government notes |  | $ | 317,376 |  |  | $ | (1,076) |  |  | $ | 108,739 |  |  | $ | (384) |  |  | $ | 426,115 |  |  | $ | (1,460) |  |
| Corporate bonds |  | 610,086 |  |  | (1,423) |  |  | 141,943 |  |  | (395) |  |  | 752,029 |  |  | (1,818) |  |
| Agency securities |  | 340,537 |  |  | (772) |  |  | 20,809 |  |  | (110) |  |  | 361,346 |  |  | (882) |  |
| Total |  | $ | 1,267,999 |  |  | $ | (3,271) |  |  | $ | 271,491 |  |  | $ | (889) |  |  | $ | 1,539,490 |  |  | $ | (4,160) |  |

[0001596532-24-000043:notes:116]
As of December 31, 2023, we had no marketable debt securities with contractual maturities that exceed 24 months. The fair values of marketable debt securities, by remaining contractual maturities, are as follows (in thousands):

[0001596532-24-000043:notes:117]
|  |  | December 31, 2023 |
| Due in 1 year or less |  | $ | 1,627,780 |  |
| Due in 1 year through 2 years |  | 1,436,582 |  |
| Total marketable securities |  | $ | 3,064,362 |  |

[0001596532-24-000043:notes:118]
The weighted-average remaining duration of our marketable debt securities is approximately 0.9 years as of December 31, 2023.

[0001596532-24-000043:notes:119]
Assets measured at fair value on a non-recurring basis

[0001596532-24-000043:notes:120]
Non-Marketable Equity Securities

[0001596532-24-000043:notes:121]
We have non-marketable equity securities in privately-held companies that do not have readily-determinable fair values. Their initial cost is adjusted to fair value on a non-recurring basis based on observable price changes from orderly transactions of identical or similar securities of the same issuer, or for impairment. These investments are classified within Level III of the fair value hierarchy as we estimate the value based on valuation methods using the observable transaction price at the transaction date and other significant unobservable inputs, such as volatility, rights, and obligations related to these securities. In addition, the valuation requires management judgment due to the absence of market price and lack of liquidity.

[0001596532-24-000043:notes:122]
We did not record any realized gains for our non-marketable equity securities during the three years ended December 31, 2023, 2022 and 2021. We recorded immaterial amounts of realized and unrealized losses during the three years ended December 31, 2023, 2022 and 2021. Unrealized gains for our non-marketable equity securities are summarized below (in thousands):

[0001596532-24-000043:notes:123]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Unrealized gains on non-marketable equity securities (1) |  | $ | 13,901 |  |  | $ | 16,731 |  |  | $ | — |  |

[0001596532-24-000043:notes:124]
(1) These unrealized gains were recorded on investments that were re-measured to fair value as of the date observable transactions occurred.

[0001596532-24-000043:notes:125]
We evaluate our non-marketable equity securities for impairment at each reporting period via a qualitative assessment with various potential impairment indicators, including, but not limited to, an assessment of a significant adverse change in the economic environment, significant adverse changes in the general market condition of the geographies and industries in which our investees operate, and other publicly-available information that may affect the value of the non-marketable equity securities.

[0001596532-24-000043:notes:126]
The following table summarizes the activity related to our non-marketable equity securities as of December 31, 2023 and December 31, 2022 (in thousands):

[0001596532-24-000043:notes:127]
|  |  | December 31, 2023 |  | December 31, 2022 |
| Cost of investments (1) |  | $ | 31,656 |  |  | $ | 23,625 |  |
| Cumulative impairment and downward adjustments |  | — |  |  | (888) |  |
| Cumulative upward adjustments |  | 30,632 |  |  | 16,731 |  |
| Carrying amount of investments (included in other assets) |  | $ | 62,288 |  |  | $ | 39,468 |  |

[0001596532-24-000043:notes:128]
(1) During the year ended December 31, 2023, we had an $8.0 million convertible note previously included in other assets, plus accrued interest of $0.6 million, that was converted to an equity investment and included in cost of investment


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-24-000043:notes:129]
The following tables summarize the fair value of these financial assets by significant investment category and their levels within the fair value hierarchy (in thousands):

[0001596532-24-000043:notes:130]
(2) During the year ended December 31, 2023, the Company sold all its shares of its marketable equity security for $23.9 million. This publicly-traded equity investment generated an unrealized gain of $4.8 million and $10.7 million for the year ended December 31, 2023 and 2022, respectively. The initial cost of this investment was $3.0 million with no changes since our initial investment. The cumulative gain from the initial purchase was $20.9 million, the majority of which has been reflected in prior periods as net unrealized gains. The realized and unrealized gains/losses are included in Other income (expense), net on the unaudited Condensed Consolidated Statements of Operations. Refer to Note 3. Financial Statements Details. 
The following table summarizes the amortized cost, unrealized gains and losses, and fair value of our debt securities measured at fair value on a recurring basis (in thousands):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-24-000043:notes:131]
Financial Statements Details
Cash, Cash Equivalents and Restricted Cash

[0001596532-24-000043:notes:132]
The reconciliation of cash, cash equivalents and restricted cash reported in the accompanying consolidated balance sheets to the total of the same such amounts in the accompanying consolidated statements of cash flows is as follows (in thousands):

[0001596532-24-000043:notes:133]
|  |  | December 31, |
|  |  | 2023 |  | 2022 |
| Cash and cash equivalents |  | $ | 1,938,606 |  |  | $ | 671,707 |  |
| Restricted cash included in other assets |  | 858 |  |  | 4,271 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 1,939,464 |  |  | $ | 675,978 |  |

[0001596532-24-000043:notes:134]
Accounts Receivable, net

[0001596532-24-000043:notes:135]
Accounts receivable, net consists of the following (in thousands):

[0001596532-24-000043:notes:136]
|  |  | December 31, |
|  |  | 2023 |  | 2022 |
| Accounts receivable |  | $ | 1,034,480 |  |  | $ | 928,490 |  |
| Product sales rebate, returns reserve and others |  | (9,911) |  |  | (5,394) |  |
| Accounts receivable, net |  | $ | 1,024,569 |  |  | $ | 923,096 |  |

[0001596532-24-000043:notes:137]
Inventories

[0001596532-24-000043:notes:138]
Inventories consist of the following (in thousands):

[0001596532-24-000043:notes:139]
|  |  | December 31, |
|  |  | 2023 |  | 2022 |
| Raw materials |  | $ | 930,777 |  |  | $ | 759,519 |  |
| Finished goods |  | 1,014,403 |  |  | 530,187 |  |
| Total inventories |  | $ | 1,945,180 |  |  | $ | 1,289,706 |  |

[0001596532-24-000043:notes:140]
Prepaid Expenses and Other Current Assets

[0001596532-24-000043:notes:141]
Prepaid expenses and other current assets consist of the following (in thousands):

[0001596532-24-000043:notes:142]
|  |  | December 31, |
|  |  | 2023 |  | 2022 |
| Inventory deposits |  | $ | 130,509 |  |  | $ | 162,047 |  |
| Other prepaid expenses and deposits |  | 282,009 |  |  | 152,170 |  |
| Total prepaid expenses and other current assets |  | $ | 412,518 |  |  | $ | 314,217 |  |

[0001596532-24-000043:notes:143]
Property and Equipment, net

[0001596532-24-000043:notes:144]
Property and equipment, net consists of the following (in thousands):

[0001596532-24-000043:notes:145]
|  |  | December 31, |
|  |  | 2023 |  | 2022 |
| Land |  | $ | 44,645 |  |  | $ | 41,500 |  |
| Equipment and machinery |  | 144,850 |  |  | 122,407 |  |
| Computer hardware and software |  | 57,761 |  |  | 52,148 |  |
| Furniture and fixtures |  | 3,576 |  |  | 3,575 |  |
| Leasehold improvements |  | 34,584 |  |  | 30,102 |  |
| Construction-in-process |  | 4,242 |  |  | 2,124 |  |
| Property and equipment, gross |  | 289,658 |  |  | 251,856 |  |
| Less: accumulated depreciation |  | (188,078) |  |  | (156,847) |  |
| Property and equipment, net |  | $ | 101,580 |  |  | $ | 95,009 |  |

[0001596532-24-000043:notes:146]
Depreciation expense was $31.7 million, $25.6 million and $19.5 million for the years ended December 31, 2023, 2022 and 2021, respectively.

[0001596532-24-000043:notes:147]
Accrued Liabilities

[0001596532-24-000043:notes:148]
Accrued liabilities consist of the following (in thousands):

[0001596532-24-000043:notes:149]
|  |  | December 31, |
|  |  | 2023 |  | 2022 |
| Accrued compensation-related costs |  | $ | 134,225 |  |  | $ | 117,053 |  |
| Supplier liability |  | 167,878 |  |  | 71,481 |  |
| Accrued manufacturing costs |  | 61,491 |  |  | 45,379 |  |
| Accrued product development costs |  | 1,041 |  |  | 27,380 |  |
| Other |  | 42,667 |  |  | 31,194 |  |
| Total accrued liabilities |  | $ | 407,302 |  |  | $ | 292,487 |  |

[0001596532-24-000043:notes:150]
Contract Liabilities, Deferred Revenue and Other Performance Obligations

[0001596532-24-000043:notes:151]
Contract Liabilities

[0001596532-24-000043:notes:152]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a cancellable contract. The following table summarizes the activity related to our contract liabilities (in thousands):

[0001596532-24-000043:notes:153]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |
| Contract liabilities, beginning balance |  | $ | 103,448 |  |  | $ | 93,382 |  |
| Less: Revenue recognized from beginning balance |  | (43,286) |  |  | (37,680) |  |
| Less: Beginning balance reclassified to deferred revenue |  | (3,185) |  |  | (2,693) |  |
| Add: Contract liabilities recognized |  | 76,262 |  |  | 50,439 |  |
| Contract liabilities, ending balance |  | $ | 133,239 |  |  | $ | 103,448 |  |

[0001596532-24-000043:notes:154]
As of December 31, 2023 and 2022, $59.2 million and $45.2 million, respectively, of our contract liabilities were recorded within other current liabilities with the remaining balance recorded within other long-term liabilities in the accompanying consolidated balance sheets.

[0001596532-24-000043:notes:155]
Deferred Revenue

[0001596532-24-000043:notes:156]
Deferred revenue is comprised mainly of unearned service revenue related to multi-year PCS contracts, and product deferrals related to contracts with acceptance clauses. The following table summarizes the activity related to our deferred revenue (in thousands):

[0001596532-24-000043:notes:157]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |
| Deferred revenue, beginning balance |  | $ | 1,041,246 |  |  | $ | 929,312 |  |
| Less: Revenue recognized from beginning balance |  | (615,681) |  |  | (583,787) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 1,080,639 |  |  | 695,721 |  |
| Deferred revenue, ending balance |  | $ | 1,506,204 |  |  | $ | 1,041,246 |  |

[0001596532-24-000043:notes:158]
Other Performance Obligations

[0001596532-24-000043:notes:159]
Other performance obligations totaling $704.1 million as of December 31, 2023 include unbilled multi-year PCS and service contract amounts of $336.4 million and $367.7 million of binding contractual agreements with certain customers that are primarily related to future product shipments.

[0001596532-24-000043:notes:160]
Revenue from Total Remaining Performance Obligations

[0001596532-24-000043:notes:161]
Total revenue from our contract liabilities, deferred revenue and other performance obligations that will be recognized in future periods amounts to $2.3 billion. Included in this amount is the $367.7 million of binding contractual agreements related primarily to future product shipments that are expected to be recognized as revenue over the next eighteen months. In addition, approximately 79% of the remaining $2.0 billion of this future revenue is expected to be recognized over the next two years and approximately 21% is expected to be recognized during the third to the fifth year.

[0001596532-24-000043:notes:162]
Other Income, Net

[0001596532-24-000043:notes:163]
Other income, net consists of the following (in thousands):

[0001596532-24-000043:notes:164]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Other income (expense), net: |  |  |  |  |  |  |
| Interest income |  | $ | 152,421 |  |  | $ | 27,556 |  |  | $ | 7,215 |  |
| Gain (loss) on strategic investments |  | 18,699 |  |  | 27,479 |  |  | — |  |
| Other income (expense) |  | (6,343) |  |  | (345) |  |  | (1,075) |  |
| Total other income, net |  | $ | 164,777 |  |  | $ | 54,690 |  |  | $ | 6,140 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-24-000043:notes:165]
The following table summarizes the activity related to our contract liabilities (in thousands):

[0001596532-24-000043:notes:166]
The following table summarizes the activity related to our deferred revenue (in thousands):


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-24-000043:notes:167]
Acquisition, Goodwill and Acquisition-Related Intangible Assets 
Acquisitions

[0001596532-24-000043:notes:168]
We had no material business acquisitions during the year ended December 31, 2023. During the year ended December 31, 2022, we completed two acquisitions of private companies for total consideration of $158.9 million, including $4.0 million in common stock and the remainder in cash. The purchase prices included $62.3 million of intangible assets, $77.5 million of goodwill and $19.1 million of net tangible assets acquired. We also incurred certain acquisition-related expenses of $4.7 million, which primarily consisted of retention bonuses to continuing employees as well as professional and consulting fees.

[0001596532-24-000043:notes:169]
The intangible assets are amortized on a straight-line basis over their estimated useful lives, as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. The following table sets forth the components of identifiable intangible assets acquired and their estimated useful lives as of the date of acquisition (in thousands, except years):

[0001596532-24-000043:notes:170]
|  |  | Acquisition Date Fair Value |  | Weighted Average Estimated Useful Life (in years) |
| Developed technology |  | $ | 30,200 |  |  | 5.7 |
| Customer relationships |  | 28,700 |  |  | 7.0 |
| Trade name |  | 3,400 |  |  | 3.0 |
| Total intangible assets acquired |  | $ | 62,300 |  |  |  |

[0001596532-24-000043:notes:171]
The purchase price allocation for the two acquisitions have been finalized. No changes were made to the purchase price allocation for the year ended December 31, 2023.

[0001596532-24-000043:notes:172]
Goodwill

[0001596532-24-000043:notes:173]
The changes in the carrying values of goodwill for the years ended December 31, 2023 and 2022 are as follows (in thousands):

[0001596532-24-000043:notes:174]
|  |  | Amount |
| Balance at December 31, 2021 |  | $ | 188,397 |  |
| Additions related to current year acquisitions |  | 85,048 |  |
| Measurement-period adjustments |  | (7,521) |  |
| Balance at December 31, 2022 |  | 265,924 |  |
| Additions related to current year acquisition |  | 2,607 |  |
| Balance at December 31, 2023 |  | $ | 268,531 |  |

[0001596532-24-000043:notes:175]
The Company performed an annual qualitative test for goodwill impairment in the fourth quarter of the fiscal years ended December 31, 2023 and 2022 and determined that goodwill was not impaired.

[0001596532-24-000043:notes:176]
Acquisition-Related Intangible Assets

[0001596532-24-000043:notes:177]
The following table presents details of our acquisition-related intangible assets as of December 31, 2023 and 2022 (in thousands, except for years):

[0001596532-24-000043:notes:178]
|  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life (in years) |
|  | December 31, 2022 |  | Additions |  | December 31, 2023 |  | December 31, 2022 |  | Amortization |  | December 31, 2023 |  | December 31, 2022 |  | December 31, 2023 |  |
| Developed technology | $ | 154,930 |  |  | $ | — |  |  | $ | 154,930 |  |  | $ | (79,036) |  |  | $ | (23,457) |  |  | $ | (102,493) |  |  | $ | 75,894 |  |  | $ | 52,437 |  |  | 4.0 |
| Customer relationships | 54,620 |  |  | — |  |  | 54,620 |  |  | (14,097) |  |  | (7,700) |  |  | (21,797) |  |  | 40,523 |  |  | 32,823 |  |  | 4.7 |
| Trade name | 12,390 |  |  | — |  |  | 12,390 |  |  | (6,602) |  |  | (2,280) |  |  | (8,882) |  |  | 5,788 |  |  | 3,508 |  |  | 1.6 |
| Total | $ | 221,940 |  |  | $ | — |  |  | $ | 221,940 |  |  | $ | (99,735) |  |  | $ | (33,437) |  |  | $ | (133,172) |  |  | $ | 122,205 |  |  | $ | 88,768 |  |  | 4.2 |

[0001596532-24-000043:notes:179]
Amortization expense related to acquisition-related intangible assets was $33.4 million, $33.7 million and $29.2 million for the years ended December 31, 2023, 2022 and 2021, respectively.

[0001596532-24-000043:notes:180]
As of December 31, 2023, future estimated amortization expense related to the acquired-related intangible assets is as follows (in thousands):

[0001596532-24-000043:notes:181]
| Years Ending December 31, |  | Future Amortization Expense |
| 2024 |  | $ | 26,759 |  |
| 2025 |  | 19,642 |  |
| 2026 |  | 17,260 |  |
| 2027 |  | 13,436 |  |
| 2028 |  | 10,037 |  |
| Thereafter |  | 1,634 |  |
| Total |  | $ | 88,768 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-24-000043:notes:182]
Commitments and Contingencies
Operating Leases

[0001596532-24-000043:notes:183]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancellable operating lease arrangements that expire on various dates through 2029. Some of our leases include options to extend the term of such leases for a period from three months to up to 10 years and/or options to early terminate the leases. As of December 31, 2023, we did not include any such options in determining the lease terms because we were not reasonably certain that we would exercise these options.

[0001596532-24-000043:notes:184]
The following table summarizes the supplemental balance sheet information related to our operating leases (in thousands):

[0001596532-24-000043:notes:185]
|  |  | December 31, 2023 |  | December 31, 2022 |
| Right-of-use assets: |  |  |  |  |
| Operating lease right-of-use assets (included in other assets) |  | $ | 55,890 |  |  | $ | 53,390 |  |
| Lease liabilities: |  |  |  |  |
| Operating lease liabilities, current (included in other current liabilities) |  | 21,106 |  |  | 19,878 |  |
| Operating lease liabilities, non-current (included in other long-term liabilities) |  | 44,413 |  |  | 43,964 |  |
| Total operating lease liabilities |  | $ | 65,519 |  |  | $ | 63,842 |  |

[0001596532-24-000043:notes:186]
The following table summarizes our lease costs (in thousands):

[0001596532-24-000043:notes:187]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |
| Operating lease costs: |  |  |  |  |
| Fixed lease costs |  | $ | 23,541 |  |  | $ | 24,134 |  |
| Variable lease costs |  | 9,717 |  |  | 8,682 |  |
| Total operating lease costs |  | $ | 33,258 |  |  | $ | 32,816 |  |

[0001596532-24-000043:notes:188]
The operating lease costs in the table above include costs for long-term and short-term leases. Total short-term lease costs were immaterial. Fixed lease costs include expenses recognized for base rent payments on a straight-line basis. Variable lease costs primarily include maintenance, utilities and operating expenses that are incremental to the fixed base rent payments, and are excluded from the calculation of operating lease liabilities and ROU assets. For the years ended December 31, 2023 and 2022, cash paid for amounts associated with our operating lease liabilities were approximately $22.7 million and $23.9 million, respectively, which were classified as operating activities in the accompanying consolidated statements of cash flows.

[0001596532-24-000043:notes:189]
Maturities of operating lease liabilities as of December 31, 2023 are presented in the table below (in thousands):

[0001596532-24-000043:notes:190]
| Years ending December 31, |  | Amount |
| 2024 |  | $ | 23,985 |  |
| 2025 |  | 21,208 |  |
| 2026 |  | 12,846 |  |
| 2027 |  | 8,694 |  |
| 2028 |  | 5,105 |  |
| 2029 and thereafter |  | 159 |  |
| Total undiscounted operating lease payments (excluding non-lease components) |  | 71,997 |  |
| Less: imputed interest |  | (6,478) |  |
| Present value of operating lease payments as of December 31, 2023 |  | $ | 65,519 |  |

[0001596532-24-000043:notes:191]
|  |  | December 31, 2023 |  | December 31, 2022 |
| Other information: |  |  |  |  |
| Weighted-average remaining lease term — operating leases |  | 3.4 years |  | 4.2 years |
| Weighted-average discount rate — operating leases |  | 5.4% |  | 5.1% |

[0001596532-24-000043:notes:192]
Purchase Commitments

[0001596532-24-000043:notes:193]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf. A significant portion of our purchase orders to our contract manufacturers for finished products consists of non-cancellable purchase commitments. In addition, we purchase strategic component inventory from certain suppliers under non-cancellable purchase commitments, including integrated circuits, which are consigned to our contract manufacturers. As of December 31, 2023, we had non-cancellable purchase commitments not recorded on our balance sheet of $1,586.7 million, of which $1,547.2 million have confirmed receipt dates within 12 months, and $39.5 million have confirmed receipt dates greater than 12 months. These open purchase orders are considered enforceable and legally binding, and while we may have some limited ability to reschedule, and adjust our requirements based on our business needs prior to the delivery of goods or performance of services, this can only occur with the agreement of the related supplier.

[0001596532-24-000043:notes:194]
We also had deposits to our contract manufacturers to secure our purchase commitments in the amount of $133.3 million and $192.5 million as of December 31, 2023 and 2022, respectively, which were recorded within prepaid expenses and other current assets, as well as other assets in the consolidated balance sheets.

[0001596532-24-000043:notes:195]
Guarantees

[0001596532-24-000043:notes:196]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third-party. We have, at our option and expense, the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions, and our guarantee and indemnification arrangements have not had any material impact on our consolidated financial statements to date.

[0001596532-24-000043:notes:197]
Legal Proceedings

[0001596532-24-000043:notes:198]
WSOU Investments, LLC

[0001596532-24-000043:notes:199]
On November 25, 2020, WSOU Investments LLC ("WSOU") filed a lawsuit against us in the Western District of Texas asserting that certain of our products infringe three WSOU patents. WSOU's allegations are directed to certain features of our wireless and switching products. WSOU seeks remedies including monetary damages, attorney's fees and costs. On February 4, 2021, we filed an answer denying WSOU's allegations. On November 5, 2021, the case was transferred to the Northern District of California.  On March 30, 2022, WSOU dismissed one of the patents with prejudice, removing Arista wireless products from those accused of infringement. On July 1, 2022, the court stayed the case pending the resolution of an inter partes review of one of the patents-in-suit. On May 30, 2023, the US Patent Trial and Appeal Board (“PTAB”) ruled all challenged claims in the inter partes review unpatentable. The district court case remains pending appeal and/or final resolution of the PTAB ruling.

[0001596532-24-000043:notes:200]
We intend to vigorously defend against the claims brought against us by WSOU; however, we cannot be certain that any of WSOU's claims will be resolved in our favor, regardless of the merits of those claims. Any adverse litigation ruling could result in a significant damages award against us and injunctive relief.

[0001596532-24-000043:notes:201]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated; however, the outcome of litigation is inherently uncertain. Therefore, if this legal matter were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-24-000043:notes:202]
Other matters

[0001596532-24-000043:notes:203]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-24-000043:notes:204]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of December 31, 2023, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently-available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows; however, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-24-000043:notes:205]
Stockholders' Equity and Stock-Based Compensation
Stock Repurchase Program

[0001596532-24-000043:notes:206]
In October 2021, our board of directors authorized a $1.0 billion stock repurchase program (the “Repurchase Program”). This authorization allows us to repurchase shares of our common stock funded from working capital. The Repurchase Program expires in the fourth quarter of 2024. Repurchases may be made at management’s discretion from time to time on the open market, through privately negotiated transactions, transactions structured through investment banking institutions, block purchases, 10b5-1 trading plans, or a combination of the foregoing. The Repurchase Program does not obligate us to acquire any of our common stock and may be suspended or discontinued by us at any time without prior notice. As of December 31, 2023, the remaining authorized amount for stock repurchases under this program was approximately $144.5 million.

[0001596532-24-000043:notes:207]
A summary of the stock repurchase activities for the years ended December 31, 2023 and 2022 is as follows (in thousands, except per share amounts):

[0001596532-24-000043:notes:208]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |
| Aggregate purchase price |  | $ | 112,279 |  |  | $ | 670,287 |  |
| Shares repurchased |  | 954 |  |  | 6,461 |  |
| Average price paid per share |  | $ | 117.70 |  |  | $ | 103.74 |  |

[0001596532-24-000043:notes:209]
The aggregate purchase price of repurchased shares of our common stock is recorded as a reduction to retained earnings in our consolidated statements of stockholders' equity. All shares repurchased have been retired.

[0001596532-24-000043:notes:210]
2014 Equity Incentive Plan

[0001596532-24-000043:notes:211]
In April 2014, our board of directors and stockholders approved the 2014 Equity Incentive Plan (the “2014 Plan”), effective on the first day that our common stock was publicly traded, and simultaneously terminated the 2004 and 2011 equity plans as to future grants. However, these plans will continue to govern the terms and conditions of the outstanding options previously granted thereunder.

[0001596532-24-000043:notes:212]
Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”).  The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of the outstanding shares of our common stock on the immediately preceding December 31, but not to exceed 50 million shares (the “2014 Plan Evergreen Increase”), unless the board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2023, our board of directors authorized an increase of 9.2 million shares for future issuance under the 2014 Plan. As of December 31, 2023, there remained approximately 95.3 million shares available for issuance under the 2014 Plan.

[0001596532-24-000043:notes:213]
2014 Employee Stock Purchase Plan

[0001596532-24-000043:notes:214]
In April 2014, the board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded. The number of shares

[0001596532-24-000043:notes:215]
reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding immediately preceding December 31, but not to exceed 10 million shares, unless the board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2023, our board of directors authorized an increase of 3.1 million shares for future issuance under the ESPP. As of December 31, 2023, there remained 23.4 million shares available for issuance under the ESPP. Furthermore, in February, 2024, our board of directors authorized an increase of 3.1 million shares for future issuance under the ESPP effective January 1, 2024.

[0001596532-24-000043:notes:216]
Under our ESPP, eligible employees are permitted to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the exercise date. Each offering period lasts approximately two years starting on the first trading date after February 15 and August 15 of each year, and includes purchase dates every six months on or after February 15 and August 15 of each year. Participants may purchase shares of common stock through payroll deductions up to 10% of their eligible compensation, subject to Internal Revenue Service mandated purchase limits.

[0001596532-24-000043:notes:217]
During the year ended December 31, 2023, we issued 279,498 shares at an average purchase price of $105.69 per share under our ESPP.

[0001596532-24-000043:notes:218]
Stock Option Activities

[0001596532-24-000043:notes:219]
The following table summarizes the option activities and related information (in thousands, except years and per share amounts):

[0001596532-24-000043:notes:220]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (In Years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2022 |  | 5,769 |  |  | $ | 14.09 |  |  | 2.0 |  | $ | 618,774 |  |
| Options granted |  | — |  |  | — |  |  |  |  |  |
| Options exercised |  | (3,310) |  |  | 9.84 |  |  |  |  |  |
| Options canceled |  | (2) |  |  | 7.82 |  |  |  |  |  |
| Balance—December 31, 2023 |  | 2,457 |  |  | $ | 19.83 |  |  | 1.7 |  | $ | 529,931 |  |
| Vested and exercisable—December 31, 2023 |  | 2,247 |  |  | $ | 18.14 |  |  | 1.5 |  | $ | 488,319 |  |

[0001596532-24-000043:notes:221]
We did not grant any stock options during the years ended December 31, 2023, 2022 and 2021. The aggregate intrinsic value of options exercised during the years ended December 31, 2023, 2022 and 2021 was $525.3 million, $311.7 million and $410.9 million, respectively. The total fair value of options vested for the years ended December 31, 2023, 2022 and 2021 was approximately $8.7 million, $16.6 million and $25.3 million, respectively.

[0001596532-24-000043:notes:222]
Restricted Stock Unit (RSU) Activities

[0001596532-24-000043:notes:223]
The following table summarizes the RSU activities and related information (in thousands, except per share amounts):

[0001596532-24-000043:notes:224]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |
| Unvested balance—December 31, 2022 |  | 8,360 |  |  | $ | 85.83 |  |
| RSUs and PRSUs granted |  | 2,664 |  |  | 157.94 |  |
| RSUs and PRSUs vested |  | (2,862) |  |  | 78.81 |  |
| RSUs and PRSUs forfeited/canceled |  | (262) |  |  | 100.46 |  |
| Unvested balance—December 31, 2023 |  | 7,900 |  |  | $ | 112.76 |  |

[0001596532-24-000043:notes:225]
The weighted-average grant-date fair value of RSUs granted during the years ended December 31, 2023, 2022 and 2021 was $157.94, $101.35 and $93.18 per share, respectively. The total fair value of RSUs vested for the years ended December 31, 2023, 2022 and 2021 was approximately $225.5 million, $174.0 million, and $120.4 million, respectively.

[0001596532-24-000043:notes:226]
Stock-Based Compensation Expense

[0001596532-24-000043:notes:227]
The following table summarizes the stock-based compensation expense related to our equity awards (in thousands):

[0001596532-24-000043:notes:228]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Cost of revenue |  | $ | 12,789 |  |  | $ | 9,688 |  |  | $ | 7,444 |  |
| Research and development |  | 172,177 |  |  | 130,897 |  |  | 99,770 |  |
| Sales and marketing |  | 71,074 |  |  | 57,571 |  |  | 46,521 |  |
| General and administrative |  | 40,716 |  |  | 32,778 |  |  | 33,140 |  |
| Total stock-based compensation |  | $ | 296,756 |  |  | $ | 230,934 |  |  | $ | 186,875 |  |

[0001596532-24-000043:notes:229]
Determination of Fair Value

[0001596532-24-000043:notes:230]
We record stock-based compensation awards based on fair value as of the grant date. We value RSUs at the market close price of our common stock on the grant date. For option awards and ESPP offerings, we use the Black-Scholes option pricing model to determine fair value. We recognize such costs as compensation expense generally on a straight-line basis over the requisite service period of the award. 
As of December 31, 2023, there were $733.7 million of unrecognized compensation costs related to all unvested awards. The unamortized compensation costs are expected to be recognized over a weighted-average period of approximately 3.4 years.


## us-gaap:EarningsPerShareTextBlock

[0001596532-24-000043:notes:231]
Net Income Per Share 
Basic net income per share is computed using the weighted-average number of shares of common stock outstanding during the period. Diluted net income per share is computed using the weighted-average number of shares of common stock outstanding during the period, including potential common shares assuming the dilutive effect of outstanding stock options, restricted stock units, and the employee stock purchase plan using the treasury stock method. Potential common shares whose effect would have been antidilutive are excluded from the computation of diluted net income per share. The following table sets forth the computation of our basic and diluted net income per share attributable to common stockholders (in thousands, except per share amounts):

[0001596532-24-000043:notes:232]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Net income |  | $ | 2,087,321 |  |  | $ | 1,352,446 |  |  | $ | 840,854 |  |
| Basic weighted-average shares outstanding |  | 309,354 |  |  | 306,473 |  |  | 306,512 |  |
| Add weighted-average effects of dilutive securities: |  |  |  |  |  |  |
| Stock options and RSUs |  | 7,724 |  |  | 9,876 |  |  | 12,464 |  |
| Employee stock purchase plan |  | 57 |  |  | 110 |  |  | 262 |  |
| Diluted weighted-average shares outstanding |  | 317,135 |  |  | 316,459 |  |  | 319,238 |  |
| Net income per share: |  |  |  |  |  |  |
| Basic |  | $ | 6.75 |  |  | $ | 4.41 |  |  | $ | 2.74 |  |
| Diluted |  | $ | 6.58 |  |  | $ | 4.27 |  |  | $ | 2.63 |  |

[0001596532-24-000043:notes:233]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share attributable to common stockholders because their effects would have been anti-dilutive for the periods presented (in thousands):

[0001596532-24-000043:notes:234]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Stock options and RSUs |  | 145 |  |  | 302 |  |  | 298 |  |
| Employee stock purchase plan |  | 103 |  |  | 200 |  |  | 37 |  |
| Total |  | 248 |  |  | 502 |  |  | 335 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-24-000043:notes:235]
Income Taxes
The components of income before provision for income taxes are as follows (in thousands):

[0001596532-24-000043:notes:236]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Domestic |  | $ | 1,977,687 |  |  | $ | 1,260,614 |  |  | $ | 737,620 |  |
| Foreign |  | 444,339 |  |  | 321,182 |  |  | 193,259 |  |
| Income before income taxes |  | $ | 2,422,026 |  |  | $ | 1,581,796 |  |  | $ | 930,879 |  |

[0001596532-24-000043:notes:237]
The components of the provision for income taxes are as follows (in thousands):

[0001596532-24-000043:notes:238]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Current provision for income taxes: |  |  |  |  |  |  |
| Federal |  | $ | 574,449 |  |  | $ | 359,158 |  |  | $ | 137,203 |  |
| State |  | 106,866 |  |  | 76,321 |  |  | 38,478 |  |
| Foreign |  | 24,186 |  |  | 38,250 |  |  | 13,391 |  |
| Total current |  | 705,501 |  |  | 473,729 |  |  | 189,072 |  |
| Deferred tax expense (benefit): |  |  |  |  |  |  |
| Federal |  | (372,270) |  |  | (219,568) |  |  | (98,534) |  |
| State |  | (41,152) |  |  | (34,689) |  |  | (16,289) |  |
| Foreign |  | 42,626 |  |  | 9,878 |  |  | 15,776 |  |
| Total deferred tax expense (benefit) |  | (370,796) |  |  | (244,379) |  |  | (99,047) |  |
| Total provision for income taxes |  | $ | 334,705 |  |  | $ | 229,350 |  |  | $ | 90,025 |  |

[0001596532-24-000043:notes:239]
The reconciliation of the statutory federal income tax rate and our effective income tax rate is as follows (in percentages):

[0001596532-24-000043:notes:240]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| U.S. federal statutory income tax rate |  | 21.00 | % |  | 21.00 | % |  | 21.00 | % |
| State tax, net of federal benefit |  | 2.13 |  |  | 2.09 |  |  | 1.89 |  |
| Taxes on foreign earnings differential |  | (1.96) |  |  | (2.24) |  |  | (2.13) |  |
| Tax credits |  | (2.74) |  |  | (2.24) |  |  | (2.70) |  |
| Change in valuation allowance |  | — |  |  | — |  |  | 0.01 |  |
| Stock-based compensation |  | (4.59) |  |  | (4.07) |  |  | (8.32) |  |
| Acquisition and integration costs |  | 0.01 |  |  | 0.05 |  |  | 0.03 |  |
| Other, net |  | (0.04) |  |  | (0.09) |  |  | (0.11) |  |
| Effective tax rate |  | 13.81 | % |  | 14.50 | % |  | 9.67 | % |

[0001596532-24-000043:notes:241]
The change in our effective tax rate was due to a change in tax benefits attributable to stock-based compensation and the reduction of unrecognized tax benefits as a result of lapse of the applicable statute of limitation in 2023. Excess tax benefits resulting from stock awards were $151.2 million, $93.5 million and $105.8 million for the years ended December 31, 2023, 2022 and 2021, respectively. The reduction of unrecognized tax benefits due to expiration of statute of limitations were immaterial for the three years ended December 31, 2023, 2022 and 2021, respectively.

[0001596532-24-000043:notes:242]
The tax effects of temporary differences that give rise to significant portions of deferred tax assets (liabilities) are as follows (in thousands):

[0001596532-24-000043:notes:243]
|  |  | December 31, |
|  |  | 2023 |  | 2022 |
| Deferred tax assets: |  |  |  |  |
| Intangible assets |  | $ | 322,325 |  |  | $ | 355,521 |  |
| Reserves and accruals not currently deductible |  | 120,973 |  |  | 63,517 |  |
| Deferred revenue |  | 295,268 |  |  | 182,594 |  |
| Tax credits |  | 118,123 |  |  | 100,284 |  |
| Lease financing obligation |  | 15,485 |  |  | 15,072 |  |
| Capitalized research and development expenses |  | 417,095 |  |  | 228,946 |  |
| Stock-based compensation |  | 28,079 |  |  | 25,480 |  |
| Net operating losses |  | 34,274 |  |  | 29,469 |  |
| Other |  | 1,328 |  |  | 8,721 |  |
| Gross deferred tax assets |  | 1,352,950 |  |  | 1,009,604 |  |
| Valuation allowance |  | (146,268) |  |  | (132,689) |  |
| Total deferred tax assets |  | 1,206,682 |  |  | 876,915 |  |
| Deferred tax liabilities: |  |  |  |  |
| US tax on foreign earnings |  | (245,074) |  |  | (286,625) |  |
| Right of use asset |  | (12,935) |  |  | (12,383) |  |
| Other |  | (2,881) |  |  | (3,037) |  |
| Total deferred tax liabilities |  | (260,890) |  |  | (302,045) |  |
| Net deferred tax assets |  | $ | 945,792 |  |  | $ | 574,870 |  |

[0001596532-24-000043:notes:244]
The following table presents the breakdown between non-current deferred tax assets and liabilities (in thousands):

[0001596532-24-000043:notes:245]
|  |  | December 31, |
|  |  | 2023 |  | 2022 |
| Deferred tax assets, non-current |  | $ | 945,792 |  |  | $ | 574,912 |  |
| Deferred tax liabilities, non-current |  | — |  |  | (42) |  |
| Total net deferred tax assets |  | $ | 945,792 |  |  | $ | 574,870 |  |

[0001596532-24-000043:notes:246]
As of December 31, 2023, we had $246.5 million and $137.6 million of net operating loss carryforwards for federal and state income tax purposes, respectively, from acquisitions. These federal and state losses will begin to expire in 2028 and 2029, respectively. We do not have any material foreign net operating losses.

[0001596532-24-000043:notes:247]
As of December 31, 2023, our federal, state and foreign tax credit carryforwards for income tax purposes before valuation allowances were approximately $2.8 million, $217.3 million and $1.2 million, respectively. Our federal tax credit will begin to expire in 2038, and our foreign tax credit will begin to expire in 2034, while our state tax credits can be carried over indefinitely. We have provided a valuation allowance of $146.3 million for deferred tax assets, primarily related to state and foreign tax credit carryforwards that we do not believe are more likely than not to be realized.

[0001596532-24-000043:notes:248]
Utilization of the net operating losses and tax credit carryforwards may be subject to limitations due to ownership change limitations provided in the Internal Revenue code and similar state or foreign provisions.

[0001596532-24-000043:notes:249]
The Tax Cuts and Jobs Act enacted on December 22, 2017 requires a Transition Tax on previously untaxed accumulated and current foreign earnings.  Correspondingly, all undistributed earnings are deemed to be taxed and distributions of the unremitted earnings do not have any significant U.S. federal income tax impact.  We have not provided for any remaining tax effect, if any, of limited outside basis differences of our foreign subsidiaries based upon plans of future reinvestment. The determination of the future tax consequences of the remittance of these earnings is not practicable.

[0001596532-24-000043:notes:250]
Uncertain Tax Positions

[0001596532-24-000043:notes:251]
We recognize uncertain tax positions only to the extent that management believes that it is more likely than not that the position will be sustained. The reconciliation of the beginning and ending amount of gross unrecognized tax benefits as of December 31, 2023, 2022 and 2021 is as follows (in thousands):

[0001596532-24-000043:notes:252]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Gross unrecognized tax benefits—beginning balance |  | $ | 137,357 |  |  | $ | 114,813 |  |  | $ | 92,500 |  |
| Increases related to tax positions taken in a prior year |  | 4,690 |  |  | 1,566 |  |  | 2,476 |  |
| Increases related to tax positions taken during current year |  | 39,895 |  |  | 25,355 |  |  | 21,104 |  |
| Decreases related to tax positions taken in a prior year |  | (513) |  |  | (3,781) |  |  | (853) |  |
| Decreases related to lapse of statute of limitations |  | (18,163) |  |  | (596) |  |  | (414) |  |
| Gross unrecognized tax benefits—ending balance |  | $ | 163,266 |  |  | $ | 137,357 |  |  | $ | 114,813 |  |

[0001596532-24-000043:notes:253]
As of December 31, 2023, 2022 and 2021, the total amount of gross unrecognized tax benefits was $163.3 million, $137.4 million and $114.8 million, respectively, of which $90.0 million, $79.3 million and $60.9 million would affect our effective tax rate if recognized.

[0001596532-24-000043:notes:254]
Our policy is to recognize interest and penalties accrued on any unrecognized tax benefits as a component of income tax expense. For the years ended December 31, 2023 and 2022, the net expense for interest and penalties and the recognized liability for interest and penalties were not material.

[0001596532-24-000043:notes:255]
The statute of limitations for Federal and most states remains open for 2017, 2020 and forward. Some states have net operating loss and tax credit carryforwards, and therefore remain open to examination. The majority of our foreign tax returns are open to audit under the statute of limitations of the respective foreign countries where the subsidiaries are located. It is possible that the amount of existing gross unrecognized tax benefits may decrease within the next 12 months as a result of statute of limitation lapses or payments to tax authorities in certain jurisdictions. However, any such changes are not anticipated to be material.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-24-000043:notes:256]
Geographical Information 
We operate as one reportable segment. The following table represents revenue based on customers' shipping addresses (in thousands):

[0001596532-24-000043:notes:257]
|  |  | Year Ended December 31, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Americas(1) |  | $ | 4,651,193 |  |  | $ | 3,462,621 |  |  | $ | 2,156,183 |  |
| Europe, Middle East and Africa |  | 670,960 |  |  | 529,800 |  |  | 486,836 |  |
| Asia Pacific |  | 538,015 |  |  | 388,889 |  |  | 305,018 |  |
| Total revenue |  | $ | 5,860,168 |  |  | $ | 4,381,310 |  |  | $ | 2,948,037 |  |

[0001596532-24-000043:notes:258]
(1) Includes $4,541.5 million, $3,424.8 million and $2,125.9 million revenue generated from the U.S. for the three years ended December 31, 2023, 2022 and 2021, respectively

[0001596532-24-000043:notes:259]
Long-lived assets, excluding intercompany receivables, investments in subsidiaries, investments in privately-held companies and deferred tax assets, net by location are summarized as follows (in thousands):

[0001596532-24-000043:notes:260]
|  |  | December 31, |
|  |  | 2023 |  | 2022 |
| United States |  | $ | 79,728 |  |  | $ | 71,540 |  |
| International |  | 21,852 |  |  | 23,469 |  |
| Total |  | $ | 101,580 |  |  | $ | 95,009 |  |


## us-gaap:PostemploymentBenefitsDisclosureTextBlock

[0001596532-24-000043:notes:261]
Post-Employment Benefits 
We have a 401(k) Plan that covers substantially all of our employees in the U.S.  Effective January 1, 2017, we have elected to match 100% of employees' contributions up to a maximum of 3% of an employee's annual salary. Matching contributions are immediately vested. For the years ended December 31, 2023, 2022 and 2021, we contributed approximately $13.1 million, $12.4 million and $9.8 million for the matching contributions, respectively.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001596532-24-000043:notes:262]
On December 5, 2023, Ita Brennan, our Senior Vice President and Chief Financial Officer, modified the  Rule 10b5-1 trading arrangement previously adopted June 8, 2023 providing for the sale from time to time of an aggregate of up to 58,000 shares of our common stock to adjust scheduled sales dates as a result of her planned departure from the Company. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until September 8, 2024, or earlier if all transactions under the trading arrangement are completed.

[0001596532-24-000043:notes:263]
On December 14, 2023, Jayshree Ullal, our Chairperson and Chief Executive Officer, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 538,270 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until March 14, 2025, or earlier if all transactions under the trading arrangement are completed.

[0001596532-24-000043:notes:264]
On December 14, 2023, Anshul Sadana, our Chief Operating Officer, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 126,861 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until March 13, 2025, or earlier if all transactions under the trading arrangement are completed.
