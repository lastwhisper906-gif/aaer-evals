# ANET notes — 0001596532-19-000027


## anet:ConcentrationRiskComponentsSupplierRiskPolicyTextBlock

[0001596532-19-000027:notes:1]
We work closely with third-party contract manufacturing suppliers to manufacture our products. As of December 31, 2018 and 2017, we had three suppliers, who provided substantially all of our electronic manufacturing services. Our contract manufacturing suppliers deliver our products to our third party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers. Our products rely on key components, including certain integrated circuit components and power supplies, some of which our contract manufacturers purchase on our behalf from a limited number of suppliers, including certain sole source providers. We generally do not have guaranteed supply contracts with our component suppliers, and our suppliers could delay shipments or cease manufacturing such products or selling them to us at any time. If we are unable to obtain a sufficient quantity of these components on commercially reasonable terms or in a timely manner, or if we are unable to obtain alternative sources for these components, sales of our products could be delayed or halted entirely or we may be required to redesign our products. Quality or performance failures of our products or changes in our contractors’ or vendors’ financial or business condition could disrupt our ability to supply quality products to our customers. Any of these events could result in lost sales and damage to our end-customer relationships, which would adversely impact our business, financial condition and results of operations.


## anet:InvestmentsPrivatelyHeldCompaniesPolicyTextBlock

[0001596532-19-000027:notes:2]
Our equity investments in privately-held companies without readily determinable fair values are measured using the measurement alternative, defined by Accounting Standards Codification (“ASC”) 321-Investments-Equity Securities as cost, less impairments, and adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer. Any adjustments resulting from impairments and/or observable price changes are recorded as “Other income (expense), net” in our consolidated statements of operations.

[0001596532-19-000027:notes:3]
Prior to 2018, such investments were accounted for under the cost method and were recorded at historical cost at the time of investment, with adjustments to the balance only in the event of an impairment.


## anet:ScheduleofLeaseFinancingObligationsTableTextBlock

[0001596532-19-000027:notes:4]
As of December 31, 2018, the future minimum payments due under our lease financing obligations were as follows (in thousands):

[0001596532-19-000027:notes:5]
| Years Ending December 31, |  |  |
| 2019 |  | $ | 6,321 |  |
| 2020 |  | 6,506 |  |
| 2021 |  | 6,686 |  |
| 2022 |  | 6,871 |  |
| 2023 |  | 5,265 |  |
| Thereafter |  | — |  |
| Total payments |  | 31,649 |  |
| Less: interest and land lease expense |  | (17,536 | ) |
| Total payments under lease financing obligations |  | 14,113 |  |
| Property reverting to landlord |  | 23,630 |  |
| Present value of obligations |  | 37,743 |  |
| Less: current portion |  | (2,312 | ) |
| Lease financing obligations, non-current |  | $ | 35,431 |  |


## anet:ScheduleofSharebasedCompensationSharesAvailableForGrantActivityTableTextBlock

[0001596532-19-000027:notes:6]
The following table presents the stock activities and the total number of shares available for grant as of December 31, 2018 (in thousands):

[0001596532-19-000027:notes:7]
|  |  | Number of Shares |
| Balance—December 31, 2017 |  | 13,512 |  |
| Authorized |  | 2,211 |  |
| Options granted |  | (113 | ) |
| RSUs granted |  | (378 | ) |
| Options canceled |  | 49 |  |
| RSUs forfeited |  | 69 |  |
| Shares traded for taxes |  | 36 |  |
| Balance—December 31, 2018 |  | 15,386 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001596532-19-000027:notes:8]
The accompanying consolidated financial statements include the accounts of Arista Networks, Inc. and its wholly owned subsidiaries and are prepared in accordance with U.S. generally accepted accounting principles (GAAP). All significant intercompany accounts and transactions have been eliminated.

[0001596532-19-000027:notes:9]
Certain reclassifications of prior period amounts were made in the current year to conform to the current period presentation.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001596532-19-000027:notes:10]
2.    Business Combinations

[0001596532-19-000027:notes:11]
In the three months ended September 30, 2018, we acquired Mojo Networks, Inc. (“Mojo”) and Metamako Holding PTY LTD. (“Metamako”) in order to extend our cognitive cloud networking architecture and to improve our next generation platforms for low-latency applications.

[0001596532-19-000027:notes:12]
The total fair value of consideration transferred for these acquisitions was approximately $117.3 million, which consisted of $101.7 million in cash and $15.6 million for the fair value of 58,072 shares of our common stock issued. The following table summarizes our preliminary purchase price allocation of the two acquisitions, in aggregate, based on the estimated fair value of the assets acquired and liabilities assumed at their respective acquisition dates (in thousands):

[0001596532-19-000027:notes:13]
|  |  | Purchase Price Allocation |
| Cash and cash equivalents |  | $ | 4,953 |  |
| Other tangible assets |  | 23,677 |  |
| Liabilities |  | (28,706 | ) |
| Intangible assets |  | 63,720 |  |
| Goodwill |  | 53,684 |  |
| Net assets acquired |  | $ | 117,328 |  |

[0001596532-19-000027:notes:14]
We continue the process of identifying and evaluating pending escrow claims related to inventory, tax and other liabilities.  Accordingly, the preliminary values reflected in the table above are subject to potential measurement period adjustments.

[0001596532-19-000027:notes:15]
The acquired intangible assets are amortized on a straight-line basis over their estimated useful lives as we believe this method most closely reflects the pattern in which the economic benefits of the assets will be consumed. The following table shows the valuation of the intangible assets acquired (in thousands) along with their estimated useful lives.

[0001596532-19-000027:notes:16]
|  |  | Acquisition Date Fair Value |  | Estimated Useful Life |
| Developed technology |  | $ | 52,510 |  |  | 5 years |
| Customer relationships |  | 7,080 |  |  | 7 years |
| Trade name |  | 2,470 |  |  | 3 years |
| Others |  | 1,660 |  |  | 1 year |
| Total intangible assets acquired |  | $ | 63,720 |  |  |  |

[0001596532-19-000027:notes:17]
The goodwill of $53.7 million is primarily attributable to the expected synergies created by incorporating the solutions of the acquired businesses into our technology platform, and the value of the assembled workforce. We operate under a single reportable segment. The goodwill is not deductible for income taxes purposes.

[0001596532-19-000027:notes:18]
For the year ended December 31, 2018, revenue and earnings from the acquired businesses included in our consolidated statements of operations were immaterial. Pro forma results of operations for these acquisitions have not been presented because they are not material to the consolidated results of operations, either individually or in aggregate.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001596532-19-000027:notes:19]
We consider all highly liquid investments with maturities of three months or less at the time of purchase to be cash equivalents. Cash and cash equivalents consist of cash on deposit with various financial institutions and highly liquid investments in money market funds. Interest is accrued as earned. As of December 31, 2018 and 2017, we had restricted cash of $4.2 million and $5.5 million that primarily included $4.0 million pledged as collateral representing a security deposit required for a facility lease. As of December 31, 2017, we also had $1.1 million restricted cash related to a letter of credit issued to a business partner. Our restricted cash is classified as other assets in our consolidated balance sheets.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001596532-19-000027:notes:20]
Commitments and Contingencies

[0001596532-19-000027:notes:21]
Operating Leases

[0001596532-19-000027:notes:22]
We lease various offices and data centers in North America, Europe, Asia and Australia under non-cancelable operating lease arrangements that expire on various dates through 2028. These arrangements require us to pay certain operating expenses, such as taxes, repairs, and insurance and contain renewal and escalation clauses. We recognize rent expense under these arrangements on a straight-line basis over the term of the lease.

[0001596532-19-000027:notes:23]
As of December 31, 2018, the aggregate future minimum payments under non-cancelable operating leases consist of the following (in thousands):

[0001596532-19-000027:notes:24]
| Years Ending December 31, |  |  |
| 2019 |  | $ | 12,789 |  |
| 2020 |  | 13,769 |  |
| 2021 |  | 14,308 |  |
| 2022 |  | 14,291 |  |
| 2023 |  | 12,325 |  |
| Thereafter |  | 35,869 |  |
| Total minimum future lease payments |  | $ | 103,351 |  |

[0001596532-19-000027:notes:25]
Rent expense for all operating leases amounted to $11.6 million, $9.4 million and $8.1 million for the years ended December 31, 2018, 2017 and 2016, respectively.

[0001596532-19-000027:notes:26]
Financing Obligations

[0001596532-19-000027:notes:27]
Build-to-Suit Lease

[0001596532-19-000027:notes:28]
In August 2012, we executed a lease for a building then under construction in Santa Clara, California to serve as our headquarters. The lease term is 120 months and commenced in August 2013.  Based on the terms of the lease agreement and due to our involvement in certain aspects of the construction, we were deemed the owner of the building (for accounting purposes only) during the construction period. Upon completion of construction in 2013, we concluded that we had forms of continued economic involvement in the facility, and therefore did not meet with the provisions for sale-leaseback accounting. We continue to maintain involvement in the property post construction and lack transferability of the risks and rewards of ownership, due to our required maintenance of a $4.0 million letter of credit, in addition to our ability and option to sublease our portion of the leased building for fees substantially higher than our base rate.  Therefore, the lease is accounted for as a financing obligation and lease payments will be attributed to (1) a reduction of the principal financing obligation; (2) imputed interest expense; and (3) land lease expense, representing an imputed cost to lease the underlying land of the building.  At the conclusion of the initial lease term, we will de-recognize both the net book values of the asset and the remaining financing obligation.

[0001596532-19-000027:notes:29]
As of December 31, 2018 and 2017, we have recorded assets of $53.4 million, representing the total costs of the building and improvements incurred, including the costs paid by the lessor (the legal owner of the building) and additional improvement costs paid by us, and a corresponding financing obligation of $37.7 million and $39.6 million, respectively. As of December 31, 2018, $2.3 million and $35.4 million were recorded as short-term and long-term financing obligations, respectively.

[0001596532-19-000027:notes:30]
Land lease expense under our lease financing obligation amounted to $1.3 million for each of the years ended December 31, 2018, 2017 and 2016 respectively.

[0001596532-19-000027:notes:31]
Purchase Commitments

[0001596532-19-000027:notes:32]
We outsource most of our manufacturing and supply chain management operations to third-party contract manufacturers, who procure components and assemble products on our behalf based on our forecasts in order to reduce manufacturing lead times and ensure adequate component supply. We issue purchase orders to our contract manufacturers for finished product and a significant portion of these orders consist of firm non-cancellable commitments.  In addition, we purchase strategic component inventory from certain suppliers under purchase commitments that in some cases are non-cancellable, including integrated circuits, which are consigned to our contract manufacturers. As of December 31, 2018, we had non-cancellable purchase commitments of $389.2 million, of which $346.0 million was to our contract manufacturers and suppliers.  In addition, we have provided deposits to secure our obligations to purchase inventory. We had $17.4 million and $36.9 million in deposits as of December 31, 2018 and 2017, respectively. These deposits are classified in 'Prepaid expenses and other current assets' and 'Other assets' in our accompanying consolidated balance sheets.

[0001596532-19-000027:notes:33]
Guarantees

[0001596532-19-000027:notes:34]
We have entered into agreements with some of our direct customers and channel partners that contain indemnification provisions relating to potential situations where claims could be alleged that our products infringe the intellectual property rights of a third party. We have at our option and expense the ability to repair any infringement, replace product with a non-infringing equivalent-in-function product or refund our customers all or a portion of the value of the product. Other guarantees or indemnification agreements include guarantees of product and service performance and standby letters of credit for leased facilities and corporate credit cards. We have not recorded a liability related to these indemnification and guarantee provisions and our guarantee and indemnification arrangements have not had any significant impact on our consolidated financial statements to date.

[0001596532-19-000027:notes:35]
Legal Proceedings

[0001596532-19-000027:notes:36]
Cisco Systems, Inc. (“Cisco”) Matters

[0001596532-19-000027:notes:37]
On August 6, 2018, we entered into a settlement agreement with Cisco Systems, Inc. (“Cisco”) as described in Note 14 relating to several litigation matters which are summarized below.

[0001596532-19-000027:notes:38]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 4:14-cv-05343) (“’43 Case”)

[0001596532-19-000027:notes:39]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe U.S. Patent Nos. 6,377,577; 6,741,592; 7,023,853; 7,061,875; 7,162,537; 7,200,145; 7,224,668; 7,290,164; 7,340,597; 7,460,492; 8,051,211; and 8,356,296 (respectively, “the ’577 patent,” “the ’592 patent,” “the ’853 patent,” “the ’875 patent,” “the ’537 patent,” “the ’145 patent,” “the ’668 patent,” “the ’164 patent,” “the ’597 patent,” “the ’492 patent,” “the ’211 patent,” and “the ’296 patent”). Pursuant to the settlement with Cisco, as described in Note 14, the ’43 Case was dismissed on August 27, 2018.

[0001596532-19-000027:notes:40]
Cisco Systems, Inc. v. Arista Networks, Inc. (Case No. 5:14-cv-05344) (“’44 Case”)

[0001596532-19-000027:notes:41]
On December 5, 2014, Cisco filed a complaint against us in the District Court for the Northern District of California alleging that we infringe numerous copyrights pertaining to Cisco’s “Command Line Interface” or “CLI” and U.S. Patent Nos. 7,047,526 and 7,953,886 (respectively, “the ’526 patent” and “the ’886 patent”). As relief for our alleged copyright infringement, Cisco sought monetary damages for alleged lost profits, profits from our alleged infringement, statutory damages, attorney’s fees, and associated costs. The ’526 patent is subject to a non-appealable final judgment of non-infringement and the ’886 patent was dismissed with prejudice.

[0001596532-19-000027:notes:42]
On December 14, 2016, following a two-week trial, a jury found that we had proven our copyright defense of scenes a faire. Cisco filed a notice of appeal on June 6, 2017. Cisco did not appeal the jury’s noninfringement verdict on the ’526 patent but did appeal the jury’s finding that we established the defense of scenes a faire. On October 1, 2018, at the parties’ request and pursuant to the settlement agreement, the District Court vacated the jury verdict regarding our copyright defense and dismissed the case.

[0001596532-19-000027:notes:43]
Arista Networks, Inc. v. Cisco Systems, Inc. (Case No. 5:16-cv-00923) (“’23 Case”)

[0001596532-19-000027:notes:44]
On February 24, 2016, we filed a complaint against Cisco in the District Court for the Northern District of California alleging antitrust violations and unfair competition. On August 6, 2018, the Court vacated the trial in light of the settlement with Cisco as describe in Note 14. Pursuant to the settlement with Cisco, the ’23 Case was dismissed.

[0001596532-19-000027:notes:45]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-944) (“944 Investigation”)

[0001596532-19-000027:notes:46]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated 19 U.S.C. § 1337 (“Section 337”). The USITC instituted Cisco’s complaint as Investigation No. 337-TA-944. Cisco initially alleged that certain of our switching products infringe the ’592, ’537, ’145, ’164, ’597, and ’296 patents.

[0001596532-19-000027:notes:47]
On February 2, 2016, the Administrative Law Judge (“ALJ”) issued his initial determination finding a violation of Section 337. The ALJ found that a violation had occurred in the importation into the United States, the sale for importation or the sale within the United States after importation, of certain network devices, related software, and components thereof that the ALJ found infringed asserted claims 1, 2, 8-11, and 17-19 of the ’537 patent; asserted claims 6, 7, 20, and 21 of the ’592 patent; and asserted claims 5, 7, 45, and 46 of the ’145 patent. The ALJ did not find a violation of Section 337 with respect to any asserted claims of the ’597 and ’164 patents. Cisco dropped the ’296 patent before the hearing. On June 23, 2016, the USITC issued its Final Determination, which found a violation with respect to the ’537, ’592, and ’145 patents, and found no violation with respect to the ’597 and ’164 patents. The USITC also issued a limited exclusion order and a cease and desist order pertaining to network devices, related software, and components thereof that infringe one or more of claims 1, 2, 8-11, and 17-19 of the ’537 patent; claims 6, 7, 20, and 21 of the ’592 patent; and claims 5, 7, 45, and 46 of the ’145 patent. On August 22, 2016, the presidential review period for the 944 Investigation expired. The USITC orders will be in effect until the expiration of the ’537, ’592, and ’145 patents.

[0001596532-19-000027:notes:48]
Both we and Cisco filed petitions for review of the USITC’s Final Determination to the Federal Circuit. The appeal was fully briefed and oral argument was held on June 6, 2017. On September 27, 2017, the Federal Circuit affirmed the USITC’s Final Determination.

[0001596532-19-000027:notes:49]
In response to the USITC’s findings in the 944 Investigation, we made design changes to our products for sale in the United States to address the features that were found to infringe the ’537, ’592, and ’145 patents. Following the issuance of the final determination in the 944 Investigation, we submitted a Section 177 ruling request to CBP seeking approval to import these redesigned products into the United States.

[0001596532-19-000027:notes:50]
On August 26, 2016, Cisco filed an enforcement complaint under Section 337 with the USITC. Cisco alleged that we violated the cease and desist and limited exclusion orders issued in the 944 Investigation by engaging in the “marketing, distribution, offering for sale, selling, advertising, and/or aiding or abetting other entities in the sale and/or distribution of products that Cisco alleges continue to infringe claims 1-2, 8-11, and 17-19 of the ’537 patent,” despite the design changes we made to those products. On September 28, 2016, the USITC instituted the enforcement proceeding.

[0001596532-19-000027:notes:51]
On April 7, 2017, we received a 177 ruling from CBP finding that our redesigned products did not infringe the relevant claims of the ’537, ’592, and ʼ145 patents, and approving the importation of those redesigned products into the United States.

[0001596532-19-000027:notes:52]
On June 20, 2017, the ALJ issued his initial determination finding that we did not violate the June 23, 2016 cease and desist order. The initial determination also recommended a civil penalty of $307 million if the USITC decided to overturn the finding of no violation. On July 3, 2017, the parties filed petitions for review of certain findings in the initial determination.

[0001596532-19-000027:notes:53]
On August 4, 2017, the USITC issued an order remanding the investigation to the ALJ to make additional findings on certain issues and issue a remand initial determination. The USITC ordered the ALJ to set a schedule for completion of any necessary remand proceedings and a new target date for the enforcement action (the “944 Enforcement Action”). The ALJ held a hearing on February 1, 2018 and issued a remand initial determination on June 4, 2018, again finding that we did not violate the June 23, 2016 cease and desist order. Pursuant to the settlement with Cisco, the 944 Enforcement Investigation was terminated on September 17, 2018.  The parties have jointly requested suspension of the remedial orders in the 944 Investigation, and on October 23, 2018, the ITC instituted a modification proceeding to determine how to modify the orders consistent with the parties’ request.

[0001596532-19-000027:notes:54]
Certain Network Devices, Related Software, and Components Thereof (Inv. No. 337-TA-945) (“945 Investigation”)

[0001596532-19-000027:notes:55]
On December 19, 2014, Cisco filed a complaint against us in the USITC alleging that we violated Section 337. The USITC instituted Cisco’s complaint as Investigation No. 337-TA-945. The remedial orders from the 945 Investigation are no longer in effect and will terminate when the USPTO issues a certificate cancelling the asserted claims of the ’668 patent based on the IPR proceeding described below.

[0001596532-19-000027:notes:56]
Inter Partes Reviews

[0001596532-19-000027:notes:57]
We have filed petitions for Inter Partes Review of the ’597, ’211, ’668, ’853, ’537, ’577, ’886, and ’526 patents. IPRs relating to the ’597 (IPR No. 2015-00978) and ’211 (IPR No. 2015-00975) patents were instituted in October 2015 and hearings on these IPRs were completed in July 2016. On September 28, 2016, the PTAB issued a final written decision finding claims 1, 14, 39-42, 71, 72, 84, and 85 of the ’597 patent unpatentable. The PTAB also found that claims 29, 63, 64, 73, and 86 of the ’597 patent had not been shown to be unpatentable. On October 5, 2016, the PTAB issued a final written decision finding claims 1 and 12 of the ’211 patent unpatentable. The PTAB also found that claims 2, 6-9, 13, and 17-20 of the ’211 patent had not been shown to be unpatentable. Both parties have appealed the final written decisions on the ’211 and ’537 patent IPRs.  The hearing for the ’211 IPR appeal was held in March 2018, and on March 28, 2018, the Federal Circuit remanded the matter back to the PTAB for further proceedings.

[0001596532-19-000027:notes:58]
IPRs relating to the ’668 (IPR No. 2016-00309), ’577 (IPR No. 2016-00303), ’853 (IPR No. 2016-0306), and ’537 (IPR No. 2016-0308) patents were instituted in June 2016 and hearings were held on March 7, 2017. On May 25, 2017, the PTAB issued final written decisions finding claims 1, 7-10, 12-16, 18-22, 25, and 28-31 of ’577 patent unpatentable, and that claim 2 of the ’577 patent, claim 63 of the ’853 patent, and claims 1, 10, 19, and 21 of the ’537 patent had not been shown to be unpatentable. On June 1, 2017, the PTAB issued a final written decision finding claims 1-10, 12-13, 15-28, 30-31, 33-36, 55-64, 66-67, and 69-72 of the ’668 patent unpatentable. We filed a Notice of Appeal concerning the ’577 patent on July 21, 2017, and Notices of Appeal concerning the ‘853 and ’537 patents on July 26, 2017. Cisco cross-appealed concerning the ’577 patent on July 26, 2017 and filed a Notice of Appeal concerning the ’668 patent on August 1, 2017. For the appeals of the IPRs on the ’668 and ’577 patents, the Federal Circuit granted our motion for an expedited briefing schedule, and the hearings were held on February 9, 2018. On February 14, 2018, the Federal Circuit affirmed the PTAB’s final written decision on the ’668 patent.

[0001596532-19-000027:notes:59]
OptumSoft, Inc. Matters

[0001596532-19-000027:notes:60]
On April 4, 2014, OptumSoft filed a lawsuit against us in the Superior Court of California, Santa Clara County titled OptumSoft, Inc. v. Arista Networks, Inc., in which it asserts (i) ownership of certain components of our EOS network operating system pursuant to the terms of a 2004 agreement between the companies and (ii) breaches of certain confidentiality and use restrictions in that agreement. Under the terms of the 2004 agreement, OptumSoft provided us with a non-exclusive, irrevocable, royalty-free license to software delivered by OptumSoft comprising a software tool used to develop certain components of EOS and a runtime library that is incorporated into EOS. The 2004 agreement places certain restrictions on our use and disclosure of the OptumSoft software and gives OptumSoft ownership of improvements, modifications and corrections to, and derivative works of, the OptumSoft software that we develop.

[0001596532-19-000027:notes:61]
In its lawsuit, OptumSoft has asked the Court to order us to (i) give OptumSoft access to our software for evaluation by OptumSoft; (ii) cease all conduct constituting the alleged confidentiality and use restriction breaches; (iii) secure the return or deletion of OptumSoft’s alleged intellectual property provided to third parties, including our customers; (iv) assign ownership to OptumSoft of OptumSoft’s alleged intellectual property currently owned by us; and (v) pay OptumSoft’s alleged damages, attorney’s fees, and costs of the lawsuit. David Cheriton, one of our founders and a former member of our board of directors, who resigned from our board of directors on March 1, 2014 and has no continuing role with us, is a founder and, we believe, the largest stockholder and director of OptumSoft. The 2010 David R. Cheriton Irrevocable Trust dated July 28, 2010, a trust for the benefit of the minor children of Mr. Cheriton, is one of our largest stockholders.

[0001596532-19-000027:notes:62]
On April 14, 2014, we filed a cross-complaint against OptumSoft, in which we asserted our ownership of the software components at issue and our interpretation of the 2004 agreement. Among other things, we asserted that the language of the 2004 agreement and the parties’ long course of conduct support our ownership of the disputed software components. We asked the Court to declare our ownership of those software components, all similarly-situated software components developed in the future and all related intellectual property. We also asserted that, even if we are found not to own certain components, such components are licensed to us under the terms of the 2004 agreement. However, there can be no assurance that our assertions will ultimately prevail in litigation. On the same day, we also filed an answer to OptumSoft’s claims, as well as affirmative defenses based in part on OptumSoft’s failure to maintain the confidentiality of its claimed trade secrets, its authorization of the disclosures it asserts and its delay in claiming ownership of the software components at issue. We have also taken additional steps to respond to OptumSoft’s allegations that we improperly used and/or disclosed OptumSoft confidential information. While we believe we have meritorious defenses to these allegations, we believe we have (i) revised our software to remove the elements we understand to be the subject of the claims relating to improper use and disclosure of OptumSoft confidential information and made the revised software available to our customers and (ii) removed information from our website that OptumSoft asserted disclosed OptumSoft confidential information.

[0001596532-19-000027:notes:63]
The parties tried Phase I of the case, relating to contract interpretation and application of the contract to certain claimed source code, in September 2015. On March 23, 2016, the Court issued a Final Statement of Decision Following Phase I Trial, in which it agreed with and adopted our interpretation of the 2004 agreement and held that we, and not OptumSoft, own all the software at issue in Phase I. The remaining issues that were not addressed in the Phase I trial are set to be tried in Phase II, including the application of the Court’s interpretation of the 2004 agreement to any other source code that OptumSoft claims to own and the trade secret misappropriation and confidentiality claims. The Phase II Trial is set for September 23, 2019 by the judge.

[0001596532-19-000027:notes:64]
We intend to vigorously defend against any claims brought against us by OptumSoft.  However, we cannot be certain that, if litigated, any claims by OptumSoft would be resolved in our favor.  For example, if it were determined that OptumSoft owned components of our EOS network operating system, we would be required to transfer ownership of those components and any related intellectual property to OptumSoft.  If OptumSoft were the owner of those components, it could make them available to our competitors, such as through a sale or license.  An adverse litigation ruling could result in a significant damages award against us and injunctive relief. In addition, OptumSoft could assert additional or different claims against us, including claims that our license from OptumSoft is invalid.

[0001596532-19-000027:notes:65]
With respect to the legal proceedings described above, it is our belief that while a loss is not probable, it may be reasonably possible. Further, at this stage in the litigation, any possible loss or range of loss cannot be estimated.  However, the outcome of litigation is inherently uncertain. Therefore, if one or more of these legal matters were resolved against us in a reporting period for a material amount, our consolidated financial statements for that reporting period could be materially adversely affected.

[0001596532-19-000027:notes:66]
Other Matters

[0001596532-19-000027:notes:67]
In the ordinary course of business, we are a party to other claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property.

[0001596532-19-000027:notes:68]
We record a provision for contingent losses when it is both probable that a liability has been incurred and the amount of the loss can be reasonably estimated. As of December 31, 2018, provisions recorded for contingent losses related to other claims and matters have not been significant. Based on currently available information, management does not believe that any additional liabilities relating to other unresolved matters are probable or that the amount of any resulting loss is estimable, and believes these other matters are not likely, individually and in the aggregate, to have a material adverse effect on our financial position, results of operations or cash flows. However, litigation is subject to inherent uncertainties and our view of these matters may change in the future. Were an unfavorable outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the unfavorable outcome occurs, and potentially in future periods.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001596532-19-000027:notes:69]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgment and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We will record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001596532-19-000027:notes:70]
The following table summarizes the beginning and ending balances of our contract assets (in thousands):

[0001596532-19-000027:notes:71]
|  |  | Year Ended December 31, 2018 |
| Contract assets, beginning balance |  | $ | — |  |
| Contract assets, ending balance |  | $ | 6,341 |  |

[0001596532-19-000027:notes:72]
The following table summarizes the activity related to our contract liabilities (in thousands):

[0001596532-19-000027:notes:73]
|  |  | Year Ended December 31, 2018 |
| Contract liabilities, beginning balance |  | $ | 16,521 |  |
| Less: Revenue recognized from beginning balance |  | (7,561 | ) |
| Less: Beginning balance reclassified to deferred revenue |  | (371 | ) |
| Add: Contract liabilities recognized |  | 24,006 |  |
| Contract liabilities, ending balance |  | $ | 32,595 |  |


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001596532-19-000027:notes:74]
The following table summarizes the activity related to our deferred revenue (in thousands):

[0001596532-19-000027:notes:75]
|  |  | Year Ended December 31, 2018 |  |
| Deferred revenue, beginning balance |  | $ | 498,740 |  | (1) |
| Less: Revenue recognized from beginning balance |  | (328,758 | ) |  |
| Add: Deferral of revenue in current period, excluding amounts recognized during the period |  | 417,245 |  |  |
| Deferred revenue, ending balance |  | $ | 587,227 |  |  |
| _________________________________ |  |  |  |
| (1) The beginning balance of the year ended December 31, 2018 excludes $16.5 million that was reclassified to other current liabilities and other long-term liabilities at January 1, 2018 as a result of our adoption of ASC 606. See Note 1 for details. |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001596532-19-000027:notes:76]
Equity Award Plan Activities

[0001596532-19-000027:notes:77]
2014 Equity Incentive Plan

[0001596532-19-000027:notes:78]
In April 2014, the board of directors and stockholders approved the 2014 Equity Incentive Plan (the “2014 Plan”), effective on the first day that our common stock was publicly traded. Our board of directors has terminated the 2004 and 2011 equity plans as to future grants.  However, these plans will continue to govern the terms and conditions of the outstanding options previously granted thereunder.

[0001596532-19-000027:notes:79]
Awards granted under the 2014 Plan could be in the form of Incentive Stock Options (“ISOs”), Nonstatutory Stock Options (“NSOs”), Restricted Stock Units (“RSUs”), Restricted Stock Awards (“RSAs”) or Stock Appreciation Rights (“SARs”).  The number of shares available for grant and issuance under the 2014 Plan increases automatically on January 1 of each year commencing with 2016 by the number of shares equal to 3% of the outstanding shares of our common stock on the immediately preceding December 31, but not to exceed 12,500,000 shares, unless the board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2018, our board of directors authorized an increase of 2,211,176 shares to the shares available for issuance under the 2014 Plan. As of December 31, 2018, there remained approximately 22.6 million shares available for issuance under the 2014 Plan.

[0001596532-19-000027:notes:80]
2014 Employee Stock Purchase Plan

[0001596532-19-000027:notes:81]
In April 2014, the board of directors and stockholders approved the 2014 Employee Stock Purchase Plan (the “ESPP”). The ESPP became effective on the first day that our common stock was publicly traded.  The number of shares reserved for issuance under the ESPP increases automatically on January 1 of each year by the number of shares equal to 1% of our shares outstanding immediately preceding December 31, but not to exceed 2,500,000 shares, unless the board of directors, in its discretion, determines to make a smaller increase. Effective January 1, 2018, our board of directors authorized an increase of 737,058 shares to shares available for issuance under the ESPP. On February 4, 2019, our board of directors authorized an increase of 756,679 shares to shares available for issuance under the ESPP effective January 1, 2019. As of December 31, 2018, there remained 2,533,438 shares available for issuance under the ESPP.

[0001596532-19-000027:notes:82]
Under our 2014 ESPP eligible employees are permitted to acquire shares of our common stock at 85% of the lower of the fair market value of our common stock on the first trading day of each offering period or on the exercise date. Each offering period will be approximately two years starting on the first trading date after February 15 and August 15 of each year. Participants may purchase shares of common stock through payroll deductions up to 10% of their eligible compensation, subject to Internal Revenue Service mandated purchase limits.

[0001596532-19-000027:notes:83]
Stock Option Activities

[0001596532-19-000027:notes:84]
The following table summarizes the option activities under our stock plans and related information (in thousands, except years and per share amounts):

[0001596532-19-000027:notes:85]
|  |  | Number of Shares UnderlyingOutstanding Options |  | Weighted- Average Exercise Price per Share |  | Weighted- Average Remaining Contractual Term (In Years) |  | Aggregate Intrinsic Value |
| Balance—December 31, 2017 |  | 7,024 |  |  | $ | 33.05 |  |  | 6.1 |  | $ | 1,422,637 |  |
| Options granted |  | 113 |  |  | 241.92 |  |  |  |  |  |
| Options exercised |  | (1,189 | ) |  | 32.24 |  |  |  |  |  |
| Options canceled |  | (49 | ) |  | 49.53 |  |  |  |  |  |
| Balance—December 31, 2018 |  | 5,899 |  |  | $ | 37.09 |  |  | 5.2 |  | $ | 1,027,741 |  |
| Vested and exercisable—December 31, 2018 |  | 3,097 |  |  | $ | 25.22 |  |  | 4.7 |  | $ | 574,392 |  |

[0001596532-19-000027:notes:86]
The weighted-average grant-date fair value of options granted during the year ended December 31, 2018, 2017 and 2016 was $121.18, $40.17 and $23.66 per share, respectively. The aggregate intrinsic value of options exercised during the year ended December 31, 2018, 2017 and 2016 was $283.8 million, $307.7 million and $147.6 million. The total fair value of options vested for the years ended December 31, 2018, 2017 and 2016 was approximately $31.9 million, $30.7 million and $28.6 million, respectively.

[0001596532-19-000027:notes:87]
Restricted Stock Unit (RSU) Activities

[0001596532-19-000027:notes:88]
A summary of the RSU activities under our 2014 Plan and changes during the reporting period and a summary of related information are presented below (in thousands, except years and per share amounts):

[0001596532-19-000027:notes:89]
|  |  | Number of Shares |  | Weighted- Average Grant Date Fair Value Per Share |  | Weighted-AverageRemainingContractual Term (In Years) |  | Aggregate Intrinsic Value |
| Unvested balance—December 31, 2017 |  | 1,537 |  |  | $ | 104.29 |  |  | 1.6 |  | $ | 362,119 |  |
| RSUs granted |  | 378 |  |  | 257.91 |  |  |  |  |  |
| RSUs vested |  | (538 | ) |  | 96.49 |  |  |  |  |  |
| RSUs forfeited/canceled |  | (69 | ) |  | 129.00 |  |  |  |  |  |
| Unvested balance—December 31, 2018 |  | 1,308 |  |  | $ | 150.60 |  |  | 1.5 |  | $ | 275,638 |  |

[0001596532-19-000027:notes:90]
The total fair value of RSUs vested for the years ended December 31, 2018, 2017 and 2016 was approximately $52.5 million, $35.4 million, and $16.9 million, respectively.

[0001596532-19-000027:notes:91]
Employee Stock Purchase Plan Activities

[0001596532-19-000027:notes:92]
During the year ended December 31, 2018, we issued 190,659 shares at an average purchase price of $80.35 under our ESPP.

[0001596532-19-000027:notes:93]
Shares Available for Grant

[0001596532-19-000027:notes:94]
Restricted Stock

[0001596532-19-000027:notes:95]
Pursuant to the close of an acquisition during the current quarter (see Note 2), we issued 21,749 restricted shares of our common stock to certain key employees. These restricted shares vest over four years from the acquisition date and any unvested shares will be forfeited upon termination of such employees under certain conditions. The acquisition date fair value of these shares will be recognized as stock-based compensation over their vesting period.

[0001596532-19-000027:notes:96]
Stock-Based Compensation Expense

[0001596532-19-000027:notes:97]
Total stock-based compensation expense related to options, RSAs, ESPP and RSUs granted were charged to the department to which the associated employee reported as follow (in thousands):

[0001596532-19-000027:notes:98]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Cost of revenue |  | $ | 5,087 |  |  | $ | 4,353 |  |  | $ | 3,620 |  |
| Research and development |  | 48,205 |  |  | 42,184 |  |  | 31,892 |  |
| Sales and marketing |  | 24,995 |  |  | 17,953 |  |  | 15,666 |  |
| General and administrative |  | 12,915 |  |  | 10,937 |  |  | 7,854 |  |
| Total stock-based compensation |  | $ | 91,202 |  |  | $ | 75,427 |  |  | $ | 59,032 |  |

[0001596532-19-000027:notes:99]
Determination of Fair Value

[0001596532-19-000027:notes:100]
We record stock-based compensation awards based on fair value as of the grant date. We value RSUs at the market close price of our common stock on the date of grant. For option awards and ESPP offerings we use the Black-Scholes option pricing model to determine fair value. We recognize such costs as compensation expense generally on a straight-line basis over the requisite service period of the award.

[0001596532-19-000027:notes:101]
Stock Options

[0001596532-19-000027:notes:102]
For the years ended December 31, 2018, 2017 and 2016, the fair value of each stock option granted under our plans was estimated on the date of grant using the Black-Scholes option pricing model with the following assumptions:

[0001596532-19-000027:notes:103]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Expected term (in years) |  | 7.0 |  |  | 6.3 |  |  | 6.7 |  |
| Risk-free interest rate |  | 2.9 | % |  | 2.1 | % |  | 1.5 | % |
| Expected volatility |  | 44.6 | % |  | 38.9 | % |  | 38.9 | % |
| Dividend rate |  | — | % |  | — | % |  | — | % |

[0001596532-19-000027:notes:104]
ESPP

[0001596532-19-000027:notes:105]
The following table summarizes the assumptions relating to our ESPP:

[0001596532-19-000027:notes:106]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Expected term (in years) |  | 1.1 |  |  | 1.2 |  |  | 1.2 |  |
| Risk-free interest rate |  | 2.4 | % |  | 1.1 | % |  | 0.6 | % |
| Expected volatility |  | 41.9 | % |  | 31.7 | % |  | 31.8 | % |
| Dividend rate |  | — | % |  | — | % |  | — | % |

[0001596532-19-000027:notes:107]
As of December 31, 2018, unrecognized stock-based compensation expenses by award type and their expected weighted-average recognition periods are summarized in the following table (in thousands, except years).

[0001596532-19-000027:notes:108]
|  |  | December 31, 2018 |
|  |  | Stock Option |  | RSU |  | ESPP |  | Restricted Stock |
| Unrecognized stock-based compensation expense |  | $ | 56,441 |  |  | $ | 177,382 |  |  | $ | 6,474 |  |  | $ | 5,387 |  |
| Weighted-average amortization period |  | 3.6 years |  |  | 3.3 years |  |  | 1.0 year |  |  | 3.7 years |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0001596532-19-000027:notes:109]
Basic and diluted net income per share attributable to common stockholders is calculated in conformity with the two-class method required for participating securities. Our shares of common stock subject to repurchase are considered participating securities. In addition, our convertible preferred stock prior to conversion to common shares upon our initial public offering in June 2014, were also considered to be participating securities. Under the two-class method, net income attributable to common stockholders is calculated as net income less earnings attributable to participating securities. In computing diluted net income attributable to common stockholders, undistributed earnings are re-allocated to reflect the potential impact of dilutive securities. Basic net income per common share is computed by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding during the period. Diluted net income per share attributable to common stockholders is computed by dividing the net income attributable to common stockholders by the weighted-average number of common shares outstanding, including potential dilutive common shares assuming the dilutive effect of outstanding stock options, restricted stock units, and employee stock purchase plan using the treasury stock method. For purposes of this calculation, these amounts are excluded from the calculation of diluted net income per share of common stock if their effect is antidilutive.


## us-gaap:EarningsPerShareTextBlock

[0001596532-19-000027:notes:110]
Net Income Per Share Available to Common Stock

[0001596532-19-000027:notes:111]
The following table sets forth the computation of our basic and diluted net income per share available to common stock (in thousands, except per share amounts):

[0001596532-19-000027:notes:112]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Numerator: |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |
| Net income |  | $ | 328,115 |  |  | $ | 423,201 |  |  | $ | 184,189 |  |
| Less: undistributed earnings allocated to participating securities |  | (189 | ) |  | (801 | ) |  | (1,224 | ) |
| Net income available to common stockholders, basic |  | $ | 327,926 |  |  | $ | 422,400 |  |  | $ | 182,965 |  |
| Diluted: |  |  |  |  |  |  |
| Net income attributable to common stockholders, basic |  | $ | 327,926 |  |  | $ | 422,400 |  |  | $ | 182,965 |  |
| Add: undistributed earnings allocated to participating securities |  | 15 |  |  | 68 |  |  | 74 |  |
| Net income attributable to common stockholders, diluted |  | $ | 327,941 |  |  | $ | 422,468 |  |  | $ | 183,039 |  |
| Denominator: |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 74,750 |  |  | 72,258 |  |  | 68,771 |  |
| Diluted: |  |  |  |  |  |  |
| Weighted-average shares used in computing net income per share available to common stockholders, basic |  | 74,750 |  |  | 72,258 |  |  | 68,771 |  |
| Add weighted-average effect of dilutive securities: |  |  |  |  |  |  |
| Stock options, RSUs and RSAs |  | 6,083 |  |  | 6,599 |  |  | 4,408 |  |
| Employee stock purchase plan |  | 11 |  |  | 120 |  |  | 43 |  |
| Weighted-average shares used in computing net income per share available to common stockholders, diluted |  | 80,844 |  |  | 78,977 |  |  | 73,222 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |
| Basic |  | $ | 4.39 |  |  | $ | 5.85 |  |  | $ | 2.66 |  |
| Diluted |  | $ | 4.06 |  |  | $ | 5.35 |  |  | $ | 2.50 |  |

[0001596532-19-000027:notes:113]
The following weighted-average outstanding shares of common stock equivalents were excluded from the computation of diluted net income per share available to common stockholders for the periods presented because including them would have been anti-dilutive (in thousands):

[0001596532-19-000027:notes:114]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Stock options and RSUs to purchase common stock |  | 140 |  |  | 58 |  |  | 2,594 |  |
| Employee stock purchase plan |  | 71 |  |  | — |  |  | — |  |
| Total |  | 211 |  |  | 58 |  |  | 2,594 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001596532-19-000027:notes:115]
The following tables summarize the amortized costs, unrealized gains and losses, and fair value of these financial assets by significant investment category and their level within the fair value hierarchy (in thousands):

[0001596532-19-000027:notes:116]
|  |  | December 31, 2018 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 322,080 |  |  | $ | — |  |  | $ | — |  |  | $ | 322,080 |  |  | $ | 322,080 |  |  | $ | — |  |  | $ | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 59,479 |  |  | — |  |  | — |  |  | 59,479 |  |  | — |  |  | 59,479 |  |  | — |  |
| Certificates of deposits (1) |  | 5,000 |  |  | — |  |  | — |  |  | 5,000 |  |  | — |  |  | 5,000 |  |  | — |  |
| U.S. government notes |  | 308,946 |  |  | 118 |  |  | (286 | ) |  | 308,778 |  |  | 308,778 |  |  | — |  |  | — |  |
| Corporate bonds |  | 660,353 |  |  | 264 |  |  | (1,399 | ) |  | 659,218 |  |  | — |  |  | 659,218 |  |  | — |  |
| Agency securities |  | 273,993 |  |  | 240 |  |  | (511 | ) |  | 273,722 |  |  | — |  |  | 273,722 |  |  | — |  |
|  |  | 1,307,771 |  |  | 622 |  |  | (2,196 | ) |  | 1,306,197 |  |  | 308,778 |  |  | 997,419 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 4,214 |  |  | — |  |  | — |  |  | 4,214 |  |  | 4,214 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 1,634,065 |  |  | $ | 622 |  |  | $ | (2,196 | ) |  | $ | 1,632,491 |  |  | $ | 635,072 |  |  | $ | 997,419 |  |  | $ | — |  |
| ____________________ |
| (1) As of December 31, 2018, all of our certificates of deposits were domestic deposits. |

[0001596532-19-000027:notes:117]
|  |  | December 31, 2017 |
|  |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Losses |  | Fair Value |  | Level I |  | Level II |  | Level III |
| Financial Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash Equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 701,145 |  |  | $ | — |  |  | $ | — |  |  | $ | 701,145 |  |  | $ | 701,145 |  |  | $ | — |  |  | $ | — |  |
| Agency securities |  | 12,728 |  |  | — |  |  | — |  |  | 12,728 |  |  |  |  | 12,728 |  |  | — |  |
|  |  | 713,873 |  |  | — |  |  | — |  |  | 713,873 |  |  | 701,145 |  |  | 12,728 |  |  | — |  |
| Marketable Securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | 11,924 |  |  | — |  |  | — |  |  | 11,924 |  |  | — |  |  | 11,924 |  |  | — |  |
| U.S. government notes |  | 137,025 |  |  | — |  |  | (378 | ) |  | 136,647 |  |  | 136,647 |  |  | — |  |  | — |  |
| Corporate bonds |  | 313,080 |  |  | 20 |  |  | (616 | ) |  | 312,484 |  |  | — |  |  | 312,484 |  |  | — |  |
| Agency securities |  | 215,923 |  |  | 2 |  |  | (617 | ) |  | 215,308 |  |  | — |  |  | 215,308 |  |  | — |  |
|  |  | 677,952 |  |  | 22 |  |  | (1,611 | ) |  | 676,363 |  |  | 136,647 |  |  | 539,716 |  |  | — |  |
| Other Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds - restricted |  | 5,505 |  |  | — |  |  | — |  |  | 5,505 |  |  | 5,505 |  |  | — |  |  | — |  |
| Total Financial Assets |  | $ | 1,397,330 |  |  | $ | 22 |  |  | $ | (1,611 | ) |  | $ | 1,395,741 |  |  | $ | 843,297 |  |  | $ | 552,444 |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001596532-19-000027:notes:118]
Fair Value Measurements

[0001596532-19-000027:notes:119]
We measure and report our cash equivalents, restricted cash, and available-for-sale marketable securities at fair value on a recurring basis. The following tables summarize the amortized costs, unrealized gains and losses, and fair value of these financial assets by significant investment category and their level within the fair value hierarchy (in thousands):

[0001596532-19-000027:notes:120]
We did not realize any other-than-temporary losses on our marketable securities for the years ended December 31, 2018 and 2017. As of December 31, 2018 and 2017, total unrealized losses of our marketable securities that had been in a continuous unrealized loss portion were immaterial. We invest in marketable securities that have maximum maturities of up to two years and are generally deemed to be low risk based on their credit ratings from the major rating agencies. The longer the duration of these marketable securities, the more susceptible they are to changes in market interest rates and bond yields. As interest rates increase, those marketable securities purchased at a lower yield show a mark-to-market unrealized loss. The unrealized losses are due primarily to changes in credit spreads and interest rates. We expect to realize the full value of these investments upon maturity or sale and therefore, we do not consider any of our marketable securities to be other-than-temporarily impaired as of December 31, 2018.

[0001596532-19-000027:notes:121]
As of December 31, 2018, the contractual maturities of our investments did not exceed 24 months. The fair values of available-for-sale marketable securities, by remaining contractual maturity, are as follows (in thousands):

[0001596532-19-000027:notes:122]
|  |  | December 31, 2018 |
| Due in 1 year or less |  | $ | 875,498 |  |
| Due in 1 year through 2 years |  | 430,699 |  |
| Total marketable securities |  | $ | 1,306,197 |  |

[0001596532-19-000027:notes:123]
The weighted-average remaining duration of our current marketable securities is approximately 0.7 years as of December 31, 2018.  As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001596532-19-000027:notes:124]
Fair value is defined as the exchange price that would be received for an asset or an exit price that would be paid to transfer a liability in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. These assets and liabilities include cash and cash equivalents, marketable securities, accounts receivable, accounts payable, and accrued liabilities. Cash equivalents, accounts receivable, accounts payable and accrued liabilities are stated at carrying amounts as reported in the consolidated financial statements, which approximate fair value due to their short-term nature.

[0001596532-19-000027:notes:125]
Assets and liabilities recorded at fair value on a recurring basis in the accompanying consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair value.  We use a fair value hierarchy to measure fair value, maximizing the use of observable inputs and minimizing the use of unobservable inputs.  The three-tiers of the fair value hierarchy are as follows:

[0001596532-19-000027:notes:126]
Level I—Inputs are unadjusted, quoted prices in active markets for identical assets or liabilities at the measurement date;

[0001596532-19-000027:notes:127]
Level II—Inputs are observable, unadjusted quoted prices in active markets for similar assets or liabilities, unadjusted quoted prices for identical or similar assets or liabilities in markets that are not active, or other inputs that are observable or can be corroborated by observable market data for substantially the full term of the related assets or liabilities; and

[0001596532-19-000027:notes:128]
Level III—Unobservable inputs that are supported by little or no market data for the related assets or liabilities and typically reflect management’s estimate of assumptions that market participants would use in pricing the asset or liability.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001596532-19-000027:notes:129]
The functional currency of our foreign subsidiaries is either the U.S. dollar or their local currency.

[0001596532-19-000027:notes:130]
Transaction re-measurement - Assets and liabilities denominated in a currency other than a subsidiary’s functional currency are re-measured into the subsidiary's functional currency using exchange rates in effect at the end of the reporting period, with gains and losses recorded in other income (expense), net in the consolidated statements of operations. We recognized $0.3 million in transaction gains, $0.5 million and $0.7 million in transaction losses for the years ended December 31, 2018, 2017 and 2016, respectively.

[0001596532-19-000027:notes:131]
Translation - Assets and liabilities of subsidiaries denominated in foreign functional currencies are translated into U.S. dollars at the closing exchange rate on the balance sheet date and equity related balances are translated at historical exchange rates.  Revenues, costs and expenses in foreign functional currencies are translated using average exchange rates that approximate those in effect during the period. Translation adjustments are accumulated as a separate component of accumulated other comprehensive income within stockholders’ equity.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001596532-19-000027:notes:132]
Goodwill and Acquisition-Related Intangible Assets

[0001596532-19-000027:notes:133]
Goodwill

[0001596532-19-000027:notes:134]
Goodwill was recorded as a result of our acquisition of Mojo and Metamako in the third quarter of 2018. See Note 2 for details.

[0001596532-19-000027:notes:135]
In the fourth quarter of 2018, we completed an annual goodwill impairment analysis. Based on our assessment of the qualitative factors, management concluded that the fair value of the Company was not more likely than not less than its carrying amount as of December 31, 2018. Subsequent to this 2018 annual impairment test, we have not identified significant events or circumstances negatively affecting the valuation of goodwill. As of December 31, 2018, there was no impairment to the carrying value of our goodwill.

[0001596532-19-000027:notes:136]
Acquisition-Related Intangible Assets

[0001596532-19-000027:notes:137]
The following table presents details of our acquisition-related intangible assets as of December 31, 2018 (in thousands):

[0001596532-19-000027:notes:138]
|  |  | December 31, 2018 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Net Carrying Amount |  | Weighted Average Remaining Useful Life(In Years) |
| Developed technology |  | $ | 52,510 |  |  | $ | (3,824 | ) |  | $ | 48,686 |  |  | 4.6 |
| Customer relationships |  | 7,080 |  |  | (375 | ) |  | 6,705 |  |  | 6.6 |
| Trade name |  | 2,470 |  |  | (289 | ) |  | 2,181 |  |  | 2.7 |
| Others |  | 1,660 |  |  | (622 | ) |  | 1,038 |  |  | 0.6 |
| Total |  | $ | 63,720 |  |  | $ | (5,110 | ) |  | $ | 58,610 |  |  | 4.7 |

[0001596532-19-000027:notes:139]
Amortization expense related to acquisition-related intangible assets was $5.1 million for the year ended December 31, 2018. Prior to 2018, we didn't have acquisition-related intangibles assets.

[0001596532-19-000027:notes:140]
As of December 31, 2018, future estimated amortization expense related to the acquired-related intangible assets is as follows (in thousands):

[0001596532-19-000027:notes:141]
| Years Ending December 31, |  | Future Amortization Expense |
| 2019 |  | $ | 13,375 |  |
| 2020 |  | 12,337 |  |
| 2021 |  | 12,048 |  |
| 2022 |  | 11,513 |  |
| 2023 |  | 7,690 |  |
| Thereafter |  | 1,647 |  |
| Total |  | $ | 58,610 |  |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001596532-19-000027:notes:142]
The carrying amounts of our long-lived assets, including property and equipment and investments in privately held companies, are periodically reviewed for impairment whenever events or changes in circumstances indicate that the carrying value of these assets may not be recoverable. Recoverability of these assets is measured by comparison of the carrying amount of each asset to the future undiscounted cash flows the asset is expected to generate over their remaining lives. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. No impairment of any long-lived assets or investments was identified for any of the periods presented.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001596532-19-000027:notes:143]
Income Taxes

[0001596532-19-000027:notes:144]
The geographical breakdown of income before provision for income taxes is as follows (in thousands):

[0001596532-19-000027:notes:145]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Domestic |  | $ | 136,818 |  |  | $ | 373,221 |  |  | $ | 196,202 |  |
| Foreign |  | 151,983 |  |  | 101,539 |  |  | 46,023 |  |
| Income before income taxes |  | $ | 288,801 |  |  | $ | 474,760 |  |  | $ | 242,225 |  |

[0001596532-19-000027:notes:146]
The components of the provision for income taxes are as follows (in thousands):

[0001596532-19-000027:notes:147]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Current provision for income taxes: |  |  |  |  |  |  |
| Federal |  | $ | 6,113 |  |  | $ | 31,935 |  |  | $ | 64,594 |  |
| State |  | 2,018 |  |  | 3,645 |  |  | 10,529 |  |
| Foreign |  | 10,451 |  |  | 7,322 |  |  | 4,675 |  |
| Total current |  | 18,582 |  |  | 42,902 |  |  | 79,798 |  |
| Deferred taxes benefit: |  |  |  |  |  |  |
| Federal |  | (57,726 | ) |  | 12,795 |  |  | (18,579 | ) |
| State |  | (4,164 | ) |  | (3,404 | ) |  | (3,564 | ) |
| Foreign |  | 3,994 |  |  | (734 | ) |  | 381 |  |
| Total deferred |  | (57,896 | ) |  | 8,657 |  |  | (21,762 | ) |
| Total provision for (benefit from) income taxes |  | $ | (39,314 | ) |  | $ | 51,559 |  |  | $ | 58,036 |  |

[0001596532-19-000027:notes:148]
The reconciliation of the statutory federal income tax rate and our effective income tax rate is as follows:

[0001596532-19-000027:notes:149]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| U.S. federal statutory income tax rate |  | 21.00 | % |  | 35.00 | % |  | 35.00 | % |
| State tax, net of federal benefit |  | (0.59 | ) |  | 0.03 |  |  | 1.87 |  |
| Taxes on foreign earnings differential |  | (3.37 | ) |  | (5.18 | ) |  | (2.27 | ) |
| Tax credits |  | (7.68 | ) |  | (3.23 | ) |  | (4.39 | ) |
| Change in valuation allowance |  | 1.00 |  |  | — |  |  | — |  |
| Uncertain tax positions and associated interest |  | — |  |  | — |  |  | (2.33 | ) |
| Stock-based compensation |  | (24.90 | ) |  | (25.86 | ) |  | (2.81 | ) |
| Tax Cuts and Jobs Act |  | (1.72 | ) |  | 11.14 |  |  | — |  |
| Acquisition and integration costs |  | 2.12 |  |  | — |  |  | — |  |
| Other, net |  | 0.53 |  |  | (1.04 | ) |  | (1.11 | ) |
| Effective tax rate |  | (13.61 | )% |  | 10.86 | % |  | 23.96 | % |

[0001596532-19-000027:notes:150]
We have operations and a taxable presence in numerous jurisdictions outside the U.S.  In 2018, a few of these countries have a lower tax rate than the U.S. The significant jurisdictions in which we have a presence include Cayman Islands, Ireland, and the United Kingdom.

[0001596532-19-000027:notes:151]
In years ended December 31, 2017 and 2018, excess tax benefits attributable to equity compensation significantly reduced the effective tax rate upon adoption of ASU 2016-09 in the first fiscal quarter of 2017. The benefit for equity compensation has proportionally grown in the current year.

[0001596532-19-000027:notes:152]
On December 22, 2017, the U.S. government enacted comprehensive tax legislation commonly referred to as the Tax Cuts and Jobs Act (the “Tax Act”). The Tax Act made broad and complex changes to the U.S. tax code, including, but not limited to, (1) reducing the U.S. federal corporate tax rate from 35 percent to 21 percent; (2) requiring companies to pay a one-time transition tax on certain unrepatriated earnings of foreign subsidiaries; (3) generally eliminating U.S. federal income taxes on dividends from foreign subsidiaries; and (4) requiring a current inclusion in U.S. federal taxable income of certain earnings of controlled foreign corporations.

[0001596532-19-000027:notes:153]
The SEC staff issued Staff Accounting Bulletin 118 (“SAB 118”), which provides guidance on accounting for the tax effects of the Tax Act. SAB 118 provides for a one-year measurement period that should not extend beyond one year from the Tax Act enactment date for companies to complete the accounting under ASC 740.  As of December 31, 2018, we have reflected the income tax effects of the Tax Act for which the accounting is complete, as follows:

[0001596532-19-000027:notes:154]
| • | The Deemed Repatriation Transition Tax (“Transition Tax”) is a tax on previously untaxed accumulated and current earnings and profits (“E&P”) of certain of our controlled foreign corporations (“CFCs”). In 2018, we recorded a Transition Tax expense of $6.1 million in addition to the provisional Transition Tax obligation of $18.8 million recorded in 2017. |

[0001596532-19-000027:notes:155]
| • | The Tax Act reduces the corporate tax rate to 21 percent, effective January 1, 2018. For the year ended December 31, 2017, we recorded a provisional decrease of $33.0 million for our net deferred tax assets, with a corresponding net adjustment to deferred income tax expense. There was no material change to this provision in 2018. |

[0001596532-19-000027:notes:156]
| • | The Tax Act creates a new requirement to provide U.S. tax on foreign earnings, global intangible low taxed income (“GILTI”). Under U.S. GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”). We selected the deferred method of accounting. As a result we recorded a discrete deferred tax benefit of $11.0 million for the year ended December 31, 2018 to record the associated basis differences anticipated to influence prospective GILTI calculations. |

[0001596532-19-000027:notes:157]
The final impact of the Tax Act may differ from the tax expense as described above, due to, among other things, possible changes in the interpretations and assumptions made by us as a result of additional information, additional guidance that will be issued by the U.S. Department of Treasury or any other relevant governing bodies. There may be additional tax effects of the Tax Act that may materially impact our future financial statement upon finalization of law, regulations, and additional guidance and will be accounted for when such guidance is issued.

[0001596532-19-000027:notes:158]
The tax effects of temporary differences that give rise to significant portions of deferred tax assets (liabilities) are as follows (in thousands):

[0001596532-19-000027:notes:159]
|  |  | December 31, |
|  |  | 2018 |  | 2017 |
| Deferred tax assets: |  |  |  |  |
| Property and equipment |  | $ | 1,890 |  |  | $ | 1,942 |  |
| Stock-based compensation |  | 19,186 |  |  | 22,050 |  |
| Reserves and accruals not currently deductible |  | 77,373 |  |  | 41,024 |  |
| Net operating losses |  | 11,052 |  |  | 2,432 |  |
| Tax credits |  | 57,793 |  |  | 30,831 |  |
| Capitalized R&D expenses |  | 30,027 |  |  | — |  |
| Other |  | 2,053 |  |  | 2,115 |  |
| Gross deferred tax assets |  | 199,374 |  |  | 100,394 |  |
| Valuation allowance |  | (56,724 | ) |  | (35,132 | ) |
| Total deferred tax assets |  | 142,650 |  |  | 65,262 |  |
| Deferred tax liabilities: |  |  |  |  |
| Acquired intangibles |  | (13,401 | ) |  | — |  |
| Accrued liabilities |  | (5,190 | ) |  | (2,006 | ) |
| Other |  | (1,320 | ) |  | (9 | ) |
| Total deferred tax liabilities |  | (19,911 | ) |  | (2,015 | ) |
| Net deferred tax assets |  | $ | 122,739 |  |  | $ | 63,247 |  |

[0001596532-19-000027:notes:160]
The following table presents the breakdown between non-current deferred tax assets and liabilities (in thousands):

[0001596532-19-000027:notes:161]
|  |  | December 31, |
|  |  | 2018 |  | 2017 |
| Deferred tax assets, non-current |  | $ | 126,492 |  |  | $ | 65,125 |  |
| Deferred tax liabilities, non-current |  | (3,753 | ) |  | (1,878 | ) |
| Total net deferred tax assets |  | $ | 122,739 |  |  |  | $63,247 |  |

[0001596532-19-000027:notes:162]
Recognition of deferred tax assets is appropriate when realization of these assets is more likely than not. We believe that all of the deferred tax assets were realizable with the exception of U.S. Federal capital losses, California, Canadian, and U.K. deferred tax assets. Therefore, a valuation allowance of $56.7 million and $35.1 million was recorded as of December 31, 2018 and 2017, respectively, against the U.S. Federal capital losses, California, Canadian, U.K. deferred tax assets as it is more likely than not that these assets will be not be recognized.

[0001596532-19-000027:notes:163]
As of December 31, 2018, we had $73.7 million and $38.4 million of net operating loss carryforwards for federal and state income tax purposes, from the acquisition of Mojo. These losses begin to expire in 2019. For foreign jurisdictions, we had combined foreign net operating loss carryforwards of $23.8 million, which do not expire.

[0001596532-19-000027:notes:164]
As of December 31, 2018, we had U.S. federal credit carryforwards of $22.2 million, which begin to expire in 2039.  We had state credit carryforwards of $84.2 million, which can be carried over indefinitely. For foreign jurisdictions, we had $1.2 million of Canadian scientific research and experimental development tax credit carry-forwards, which begin to expire in 2033.

[0001596532-19-000027:notes:165]
Utilization of the net operating losses and tax credit carryforwards may be subject to limitations due to ownership changes limitations provided in the Internal Revenue code and similar state or foreign provisions.

[0001596532-19-000027:notes:166]
As discussed above, the Tax Act required a Transition Tax on previously untaxed accumulated and current foreign earnings.  Correspondingly, all undistributed earnings were deemed to be taxed and distributions of the unremitted earnings will not have any significant U.S. federal income tax impact.  We have not provided for any remaining  tax effect, if any, of limited outside basis differences of our foreign subsidiaries based upon plans of future reinvestment. The determination of the future tax consequences of the remittance of these earnings is not practicable.

[0001596532-19-000027:notes:167]
Uncertain Tax Positions

[0001596532-19-000027:notes:168]
We recognize uncertain tax positions only to the extent that management believes that it is more likely than not the position will be sustained. The reconciliation of the beginning and ending amount of gross unrecognized tax benefits as of December 31, 2018, 2017 and 2016 was as follows (in thousands):

[0001596532-19-000027:notes:169]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Gross unrecognized tax benefits—beginning balance |  | $ | 48,835 |  |  | $ | 26,915 |  |  | $ | 22,239 |  |
| Increases related to tax positions taken in a prior year |  | 330 |  |  | 1,243 |  |  | 46 |  |
| Increases related to tax positions taken during current year |  | 27,413 |  |  | 22,202 |  |  | 11,359 |  |
| Decreases related to tax positions taken in a prior year |  | (675 | ) |  | (21 | ) |  | (426 | ) |
| Decreases related to settlements with taxing authorities |  | — |  |  | — |  |  | (432 | ) |
| Decreases related to lapse of statute of limitations |  | (2,173 | ) |  | (1,504 | ) |  | (5,871 | ) |
| Adjustment for acquisition |  | 706 |  |  | — |  |  | — |  |
| Gross unrecognized tax benefits—ending balance |  | $ | 74,436 |  |  | $ | 48,835 |  |  | $ | 26,915 |  |

[0001596532-19-000027:notes:170]
As of December 31, 2018, 2017 and 2016, the total amount of gross unrecognized tax benefits was $74.4 million, $48.8 million and $26.9 million of which $35.7 million, $26.8 million and $13.9 million would affect our effective tax rate if recognized, respectively.

[0001596532-19-000027:notes:171]
Our policy is to recognize interest and penalties accrued on any unrecognized tax benefits as a component of income tax expense. We have recorded a net expense for interest and penalties of $0.9 million and $0.4 million in the years ended December 31, 2018 and 2017, respectively. As of December 31, 2018 and 2017, we recognized a liability for interest and penalties of $1.9 million and $1.0 million, respectively.

[0001596532-19-000027:notes:172]
The statute of limitations for Federal remains open for 2015 and forward.  Because of the net operating loss and tax credit carryforwards, all tax years remain open to state tax examination. The majority of our foreign tax returns are open to audit under the statute of limitations of the respective foreign countries, in which the subsidiaries are located. It is possible that the amount of existing unrecognized tax benefits may decrease within the next 12 months as a result of statute of limitation lapses in some of the jurisdictions, however, an estimate of the range cannot be made.


## us-gaap:IncomeTaxPolicyTextBlock

[0001596532-19-000027:notes:173]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-19-000027:notes:174]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-19-000027:notes:175]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-19-000027:notes:176]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.


## us-gaap:InventoryPolicyTextBlock

[0001596532-19-000027:notes:177]
Inventories primarily consist of finished goods and strategic components, primarily integrated circuits. Inventories are stated at the lower of cost (computed using the first-in, first-out method) and net realizable value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value. For the years ended December 31, 2018, 2017 and 2016, we recorded charges of $20.8 million, $28.1 million and $12.1 million, respectively, within cost of product revenue for inventory write-downs.

[0001596532-19-000027:notes:178]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts. We record a liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with our contract manufacturers or suppliers for quantities in excess of our demand forecasts or that are considered obsolete due to manufacturing and engineering change orders resulting from design changes. For the year ended December 31, 2018, we did not incur a net loss on such supplier liabilities. For the years ended December 31, 2017 and 2016, we recorded a charge of $21.2 million and $6.2 million, respectively, within cost of product revenue for such liabilities with our contract manufacturers and suppliers.

[0001596532-19-000027:notes:179]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer liabilities.


## us-gaap:InvestmentsAndOtherNoncurrentAssetsTextBlock

[0001596532-19-000027:notes:180]
Investments

[0001596532-19-000027:notes:181]
Investments in Privately-Held Companies

[0001596532-19-000027:notes:182]
As of December 31, 2018 and 2017, the carrying amount of our non-marketable equity investments was approximately $30.3 million and $36.1 million, respectively, with total initial costs of $44.1 million and $36.1 million, respectively. These investments are in the equity of privately-held companies, which do not have readily determinable fair values.

[0001596532-19-000027:notes:183]
Prior to 2018, we accounted for our non-marketable equity securities at cost less impairment. In 2018, we adopted ASU 2016-01 and began to measure such investments using the measurement alternative. See Note 1.

[0001596532-19-000027:notes:184]
During the year ended December 31, 2018, we recorded $1.2 million of unrealized gain on investments in one company after they were re-measured to fair value as of the date observable transactions occurred. In addition, during the year ended December 31, 2018, we recorded $15.0 million of impairment loss on an investment.  Accordingly, as of December 31, 2018, $36.1 million of the initial costs of our investments were re-measured to fair value at $22.3 million and are classified within Level III of the fair value hierarchy. Prior to 2018, we did not record any impairment losses for these investments.


## us-gaap:LegalMattersAndContingenciesTextBlock

[0001596532-19-000027:notes:185]
Legal Settlement

[0001596532-19-000027:notes:186]
On August 6, 2018, we entered into a binding Term Sheet with Cisco to settle various legal matters between us and Cisco as described in Note 7. Pursuant to the Term Sheet, we paid Cisco $400.0 million on August 20, 2018, and the Company and Cisco obtained dismissals of all ongoing district court and USITC litigation between us. Cisco granted us a release for all past claims relating to the patents Cisco asserted against us in the district court and USITC, and we granted Cisco a release from all past antitrust and unfair competition claims. These mutual releases extended to the Company's and Cisco’s customers, contract manufacturers, and partners. The parties further agreed to a five-year stand-down period for any utility patent infringement claims either may have against features currently implemented in the other party’s products and services, with some carve-outs for products stemming from acquired companies. The parties further agreed to a three-year dispute resolution process for allegations by either party against new and/or modified features in the other party’s products. We also agreed to make certain modifications to our CLI. On December 3, 2018, the parties entered into a Mutual Release and Settlement Agreement (“Definitive Agreement”), which superseded the Term Sheet but did not substantially alter the terms.

[0001596532-19-000027:notes:187]
Upon signing the Term Sheet, we recorded a legal settlement charge of $405.0 million to operating expenses, which included the $400.0 million payment to Cisco and $5.0 million of legal fees associated with the settlement in the three months ended June 30, 2018. We have also recorded a corresponding income tax benefit of $96.9 million for the year ended December 31, 2018.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001596532-19-000027:notes:188]
Goodwill Impairment

[0001596532-19-000027:notes:189]
In January 2017, the FASB issued ASU 2017-04, Simplifying the Test for Goodwill Impairment, which eliminated step two from the goodwill impairment test. In assessing impairment of goodwill, if it is concluded that it is more likely than not that the carrying amount of a reportable segment exceeds its fair value during the qualitative assessment, a one-step quantitative goodwill impairment test will be performed. If it is concluded during the quantitative test that the carrying amount of a reportable segment exceeds its fair value, an impairment loss shall be recognized in an amount equal to that excess, limited to the total amount of goodwill allocated to that reportable segment. The guidance is effective for us for our first quarter of 2020. Early adoption is permitted. In the third quarter of 2018, we early adopted ASU 2017-04 upon the completion of our business combinations. The standard did not have an impact to our qualitative assessment for goodwill impairment that we performed in the fourth quarter of fiscal 2018.

[0001596532-19-000027:notes:190]
Revenue Recognition

[0001596532-19-000027:notes:191]
During May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606). In 2016, the FASB issued ASU 2016-08, ASU 2016-10 and ASU 2016-12, which provide interpretive clarifications on the new guidance in Topic 606 (collectively, “ASC 606”). Under ASC 606, the recognition of revenue is based on consideration we expect to be entitled to from the transfer of goods or services to a customer.

[0001596532-19-000027:notes:192]
The primary impact of ASC 606 is related to the deferral of incremental commission costs of obtaining customer service contracts, which were previously expensed as incurred. Under ASC 606, we defer all such costs and amortize them over the expected period of benefit. ASC 606 also requires companies to account for termination clauses at the onset of an arrangement. While there is limited history of cancellations, our prepaid subscription offerings are generally cancellable by customers with 30 days’ notice, therefore, the subscription contracts are considered month-to-month. While these prepaid amounts have historically been recorded to deferred revenue, ASC 606 requires that we record these amounts as other liabilities.  In addition, ASC 606 may impact the amount and timing of revenue recognition of certain sales arrangements and the related disclosures on our consolidated financial statements.

[0001596532-19-000027:notes:193]
We adopted ASC 606 on January 1, 2018 using the modified retrospective method to those contracts that were not completed as of January 1, 2018, which resulted in a cumulative effect adjustment of $3.5 million that increased retained earnings to capitalize certain commission costs that were expensed in the prior year. Correspondingly, we increased prepaid expenses and other current assets by $2.0 million, other assets by $2.2 million, and decreased deferred tax assets by $0.7 million as of January 1, 2018. In addition, we reclassified $16.5 million of deferred revenue as of January 1, 2018 to other current liabilities and other long-term liabilities related to our prepaid subscription offerings. The impact of adopting ASC 606 was not material to our financial results for the year ended December 31, 2018.

[0001596532-19-000027:notes:194]
We apply a practical expedient to expense costs as incurred for costs to obtain a contract with a customer when the amortization period would have been one year or less, as well as the portfolio approach for the contracts reviewed. These costs include a portion of our sales force compensation program as we have determined annual compensation is commensurate with recurring sales activities.

[0001596532-19-000027:notes:195]
Financial Instruments

[0001596532-19-000027:notes:196]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments-Recognition and Measurement of Financial Assets and Financial Liabilities (“ASU 2016-01”), which enhances the reporting model for financial instruments to provide users of financial statements with more decision-useful information. In February 2018, the FASB issued ASU 2018-03, Technical Corrections and Improvements to Financial Instruments, to clarify certain aspects of ASU 2016-01. ASU 2016-01 and ASU 2018-03 (collectively, the “new guidance”) address certain aspects of recognition, measurement, presentation, and disclosure of financial instruments. We adopted this new guidance on January 1, 2018.

[0001596532-19-000027:notes:197]
Under the new guidance, there was no change in the accounting of our marketable securities as our investment policy only allows investments in debt securities. For our cost method equity investments in privately-held companies without readily determinable fair value, we elected to use the measurement alternative, defined as cost, less impairments, as adjusted up or down based on observable price changes in orderly transactions for identical or similar investments of the same issuer, which was adopted prospectively. Adjustments resulting from impairments and/or observable price changes are to be recorded as other income (expense) on a prospective basis.

[0001596532-19-000027:notes:198]
The carrying amount of our equity investments and any related gain or loss may fluctuate in the future as a result of the re-measurement of such equity investments upon the occurrence of observable price changes and/or impairments.

[0001596532-19-000027:notes:199]
Income Taxes on Intra-Entity Transfers of Assets

[0001596532-19-000027:notes:200]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory, which addresses recognition of current and deferred income taxes for intra-entity asset transfers when assets are sold to an outside party. Current GAAP prohibits the recognition of current and deferred income taxes until the asset has been sold to an outside party. This prohibition on recognition is considered an exception to the principle of comprehensive recognition of current and deferred income taxes in GAAP. The new guidance requires an entity to recognize the income tax consequences when the transfer occurs eliminating the exception. The guidance must be applied on a modified retrospective basis through a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. We adopted this guidance in our first quarter of fiscal 2018 and the impact was immaterial.

[0001596532-19-000027:notes:201]
Restricted Cash in Statement of Cash Flows

[0001596532-19-000027:notes:202]
In November 2016, the FASB issued ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force (“ASU 2016-18”), which requires that amounts generally described as restricted cash or restricted cash equivalents be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows.  This standard is required to be applied using a retrospective transition method to each period presented.  We retrospectively adopted ASU 2016-18 in our first quarter of fiscal 2018. As a result of the adoption, we adjusted the consolidated statements of cash flows for the years ended December 31, 2017 and 2016 to increase the beginning-of-period cash amounts by $4.2 million and $4.0 million, respectively, and end-of-period cash amount by $5.5 million and $4.2 million, respectively. In addition, net cash used in investing activities for the years ended December 31, 2017 and 2016 decreased by $1.3 million and $0.2 million, respectively.

[0001596532-19-000027:notes:203]
Recent Accounting Pronouncements Not Yet Effective

[0001596532-19-000027:notes:204]
Nonemployee Share-Based Payments

[0001596532-19-000027:notes:205]
In June 2018, the FASB issued ASU 2018-07, Compensation-Stock Compensation (Topic 718): Improvements to Nonemployee Share-Based Payment Accounting (“ASU 2018-07”), to simplify the accounting for share-based payments to nonemployees by aligning it with the accounting for share-based payments to employees with certain exceptions. Under the guidance, the measurement of equity-classified nonemployee awards will be fixed at the grant date, which may lower their cost and reduce volatility in the income statement. The guidance is effective for us for our first quarter of 2019. Early adoption is permitted. ASU 2018-07 shall be applied on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of the beginning of the fiscal year in which the guidance is adopted. We have evaluated this new guidance and do not expect the adoption of the guidance to have a material impact on our consolidated financial statements.

[0001596532-19-000027:notes:206]
Leases

[0001596532-19-000027:notes:207]
In February 2016, the FASB issued ASU 2016-02, Leases (“ASU 2016-02”). In July 2018, the FASB issued ASU 2018-11, Leases (Topic 842): Targeted Improvements (“ASU 2018-11”). Under the guidance, lessees are required to recognize assets and lease liabilities on the balance sheet for most leases including operating leases and provide enhanced disclosures. There are optional practical expedients that a company may elect to apply. The guidance is effective for us beginning in our first quarter of 2019. Companies are required to adopt this guidance using a modified retrospective approach and apply the transition provisions under the guidance at either 1) the later of the beginning of the earliest comparative period presented in the financial statements and the commencement date of the lease, or 2) the beginning of the period of adoption (i.e. on the effective date). Under the transition method using the second application date, a company initially applies the new leases standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption.

[0001596532-19-000027:notes:208]
We will adopt the guidance for financial statements periods beginning January 1, 2019 using the modified retrospective transition method and initially apply the transition provisions at January 1, 2019, which allows us to continue to apply the legacy guidance in ASC 840 for periods prior to 2019. We will elect the package of transition practical expedients, which, among other things, allows us to keep the historical lease classifications and not have to reassess the lease classification for any existing leases as of the date of adoption. We will also make an accounting policy election to apply the short-term lease exception, which allows us to keep leases with an initial term of twelve months or less off the balance sheet. While we are continuing to assess all potential impacts of the standard, we expect to recognize right-of-use assets and lease liabilities for operating leases of approximately $70.9 million and $79.4 million as of January 1, 2019, respectively. The new guidance will not have a material impact on our consolidated statements of operations.

[0001596532-19-000027:notes:209]
Credit Losses of Financial Instruments

[0001596532-19-000027:notes:210]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments-Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which requires a financial asset measured at amortized cost basis to be presented at the net amount expected to be collected. Credit losses relating to available-for-sale debt securities should be recorded through an allowance for credit losses. This standard is effective for us for our first quarter of 2020. We are currently assessing the impact this guidance may have on our consolidated financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesTextBlock

[0001596532-19-000027:notes:211]
Organization and Summary of Significant Accounting Policies

[0001596532-19-000027:notes:212]
Organization

[0001596532-19-000027:notes:213]
Arista Networks, Inc. (together with our subsidiaries, “we,” “our” or “us”) is a supplier of cloud networking solutions that use software innovations to address the needs of large-scale internet companies, cloud service providers and next-generation enterprise. Our cloud networking solutions consist of our Extensible Operating System, a set of network applications and our 10/25/40/50/100 Gigabit Ethernet switching and routing platforms. We are incorporated in the state of Delaware. Our corporate headquarters are located in Santa Clara, California, and we have wholly-owned subsidiaries throughout the world, including North America, Europe, Asia and Australia.

[0001596532-19-000027:notes:214]
Basis of Presentation and Principles of Consolidation

[0001596532-19-000027:notes:215]
Use of Estimates

[0001596532-19-000027:notes:216]
The preparation of the accompanying consolidated financial statements in conformity with GAAP requires us to make estimates and assumptions that affect the amounts reported and disclosed in the consolidated financial statements and accompanying notes. Those estimates and assumptions include, but are not limited to, revenue recognition and deferred revenue; allowance for doubtful accounts, sales rebates and return reserves; valuation of goodwill and acquisition-related intangible assets, accounting for income taxes, including the valuation allowance on deferred tax assets and reserves for uncertain tax positions; estimate of useful lives of long-lived assets including intangible assets; valuation of inventory and contract manufacturer/supplier liabilities; recognition and measurement of contingent liabilities; valuation of equity investments in privately-held companies; determination of fair value for stock-based awards; and valuation of warranty accruals. We evaluate our estimates and assumptions based on historical experience and other factors and adjust those estimates and assumptions when facts and circumstances dictate. Actual results could differ materially from those estimates.

[0001596532-19-000027:notes:217]
Concentrations of Business and Credit Risk

[0001596532-19-000027:notes:218]
Financial instruments that potentially subject us to concentrations of credit risk consist primarily of cash, cash equivalents, marketable securities, restricted cash, and accounts receivable. Our cash equivalents, restricted cash and marketable securities are invested in high quality financial instruments with banks and financial institutions. Such deposits may be in excess of insured limits provided on such deposits.

[0001596532-19-000027:notes:219]
Our accounts receivable are unsecured and represent amounts due to us based on contractual obligations of our customers. We mitigate credit risk in respect to accounts receivable by performing ongoing credit evaluations of our customers to assess the probability of accounts receivable collection based on a number of factors, including past transaction experience with the customer, evaluation of their credit history, the credit limits extended and review of the invoicing terms of the arrangement. In situations where a customer may be thinly capitalized and we have limited payment history with it, we will either establish a small credit limit or require it to prepay its purchases. We generally do not require our customers to provide collateral to support accounts receivable. We have recorded an allowance for doubtful accounts for those receivables that we have determined not to be collectible. We mitigate credit risk in respect to the notes receivable by performing ongoing credit evaluations of the borrower to assess the probability of collecting all amounts due to us under the existing contractual terms.

[0001596532-19-000027:notes:220]
We market and sell our products through both our direct sales force and our channel partners, including distributors, value-added resellers, system integrators and original equipment manufacturer (“OEM”) partners and in conjunction with various technology partners.  Significant customers are those which represent more than 10% of our total net revenue during the period or net accounts receivable balance at each respective balance sheet date. As of December 31, 2018, we had two customers who represented 35% and 10% of total accounts receivable, respectively. As of December 31, 2017, we had two customers who represented 30% and 18% of total accounts receivable, respectively. For the years ended December 31, 2018, 2017 and 2016, there was one customer who represented 27%, 16% and 16% of our total revenue, respectively.

[0001596532-19-000027:notes:221]
Cash and Cash Equivalents

[0001596532-19-000027:notes:222]
Marketable Securities

[0001596532-19-000027:notes:223]
We classify all highly liquid investments in debt and equity securities with maturities of greater than three months at the date of purchase as marketable securities. We have classified and accounted for our marketable securities as available-for-sale. We determine the appropriate classification of these investments at the time of purchase and reevaluate such designation at each balance sheet date. We may or may not hold securities with stated maturities greater than 12 months until maturity. After consideration of our risk versus reward objectives, as well as our liquidity requirements, we may sell these securities prior to their stated maturities. As we view these securities as available to support current operations, we classify securities with maturities beyond 12 months as current assets under the caption marketable securities in the accompanying consolidated balance sheets. We carry these securities at fair value, and report the unrealized gains and losses, net of taxes, as a component of stockholders’ equity, except for unrealized losses determined to be other-than-temporary, which we record as other income (expense), net. We determine any realized gains or losses on the sale of marketable securities on a specific identification method, and we record such gains and losses as a component of interest and other income, net.

[0001596532-19-000027:notes:224]
Accounts Receivable

[0001596532-19-000027:notes:225]
Accounts receivable are recorded at the invoiced amount, net of allowances for doubtful accounts, and sales rebates and returns reserves. We estimate our allowance for doubtful accounts based upon the collectability of the receivables in light of historical trends, adverse situations that may affect our customers’ ability to pay and prevailing economic conditions. This evaluation is done in order to identify issues which may impact the collectability of receivables and related estimated required allowance. Revisions to the allowance are recorded as an adjustment to bad debt expense. After appropriate collection efforts are exhausted, specific accounts receivable deemed to be uncollectible are charged against the allowance in the period they are deemed uncollectible. Recoveries of accounts receivable previously written-off are recorded as credits to bad debt expense. We primarily estimate our sales rebates and returns reserves based on historical rates applied against current period gross revenues. Specific customer returns, rebates and allowances are considered when determining our estimates. Revisions to the reserves are recorded as adjustments to revenue.

[0001596532-19-000027:notes:226]
Foreign Currency

[0001596532-19-000027:notes:227]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-19-000027:notes:228]
Property and Equipment

[0001596532-19-000027:notes:229]
Property and equipment are stated at cost, less accumulated depreciation. Depreciation is calculated using the straight-line method over the estimated useful lives of the related assets, generally three years.  Our building is depreciated over 30 years and leasehold improvements are depreciated over the shorter of the estimated useful lives of the improvements or the remaining lease term. The leased building under our build-to-suit lease is capitalized and included in property and equipment as we were involved in the construction funding and did not meet the “sale-leaseback” criteria.

[0001596532-19-000027:notes:230]
Impairment of Long-Lived Assets and Investments

[0001596532-19-000027:notes:231]
Loss Contingencies

[0001596532-19-000027:notes:232]
Effective January 1, 2018, we adopted a new revenue recognition policy in accordance with ASC 606 - Revenue from Contracts with Customers (“ASC 606”) using the modified retrospective method as discussed in the section titled Recently Adopted Accounting Pronouncements of this Note 1. Prior to 2018, our revenue recognition policy was based on ASC 605 - Revenue Recognition (“ASC 605”), and is described in Note 1 of Notes to Consolidated Financial Statements under Item 8 of our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

[0001596532-19-000027:notes:233]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with post-contract customer support (“PCS”). We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

[0001596532-19-000027:notes:234]
| • | Identification of the contract, or contracts, with a customer |

[0001596532-19-000027:notes:235]
| • | Identification of the performance obligations in the contract |

[0001596532-19-000027:notes:236]
| • | Determination of the transaction price |

[0001596532-19-000027:notes:237]
| • | Allocation of the transaction price to the performance obligations in the contract |

[0001596532-19-000027:notes:238]
| • | Recognition of revenue when (or as) we satisfy the performance obligation |

[0001596532-19-000027:notes:239]
Post-Contract Customer Support

[0001596532-19-000027:notes:240]
Post-contract support, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernable pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and addresses customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-19-000027:notes:241]
Contracts with Multiple Performance Obligations

[0001596532-19-000027:notes:242]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts which contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

[0001596532-19-000027:notes:243]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

[0001596532-19-000027:notes:244]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

[0001596532-19-000027:notes:245]
Most of our contracts with customers have payment terms of 30 days with some large high volume customers having terms of up to 60 days. We have determined our contracts generally do not include a significant financing component because the Company and the customer have specific business reasons other than financing for entering into such contracts. Specifically, both we and our customers seek to ensure the customer has a simplified way of purchasing Arista products and services.

[0001596532-19-000027:notes:246]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

[0001596532-19-000027:notes:247]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-19-000027:notes:248]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

[0001596532-19-000027:notes:249]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

[0001596532-19-000027:notes:250]
Contract Balances

[0001596532-19-000027:notes:251]
A contract asset is recognized when we have performed under the contract, but our right to consideration is conditional on something other than the passage of time. Contract assets are included in “Other current assets” on our consolidated balance sheets.

[0001596532-19-000027:notes:252]
A contract liability is recognized when we have received customer payments in advance of our satisfaction of a performance obligation under a contract that is cancellable. Contract liabilities are included in “Other current liabilities” and “Other long-term liabilities” on our consolidated balance sheets.

[0001596532-19-000027:notes:253]
Assets Recognized from Costs to Obtain a Contract with a Customer

[0001596532-19-000027:notes:254]
Effective January 1, 2018 in connection with the adoption of ASC 606, we recognize an asset for the incremental costs of obtaining a contract with a customer if we expect the benefit of those costs to be longer than one year. We have determined that certain sales commissions earned by our sales force meet the requirements for capitalization. These costs are deferred and then amortized over a period of benefit that we have determined to be five years. Total capitalized costs to obtain a contract are included in other current and long-term assets on our consolidated balance sheets. As of December 31, 2018, total capitalized costs to obtain contracts was $6.4 million.

[0001596532-19-000027:notes:255]
Research and Development Expenses

[0001596532-19-000027:notes:256]
Costs related to the research, design and development of our products are charged to research and development expenses as incurred. Software development costs are capitalized beginning when a product’s technological feasibility has been established and ending when the product is available for general release to customers. Generally, our products are released soon after technological feasibility has been established. As a result, costs incurred subsequent to achieving technological feasibility have not been significant and accordingly, all software development costs have been expensed as incurred.

[0001596532-19-000027:notes:257]
Warranty

[0001596532-19-000027:notes:258]
We offer a one-year warranty on all of our hardware products and a 90-day warranty against defects in the software embedded in the products. We use judgment and estimates when determining warranty costs based on historical costs to replace product returns within the warranty period at the time we recognize revenue. We accrue for potential warranty claims at the time of shipment as a component of cost of revenues based on historical experience and other relevant information. We reserve for specifically identified products if and when we determine we have a systemic product failure. Although we engage in extensive product quality programs, if actual product failure rates or use of materials differ from estimates, additional warranty costs may be incurred, which could reduce our gross margin. The accrued warranty liability is recorded in accrued liabilities in the accompanying consolidated balance sheets.

[0001596532-19-000027:notes:259]
Segment Reporting

[0001596532-19-000027:notes:260]
We develop, market and sell cloud networking solutions, which consist of our Gigabit Ethernet switches and related software. We have one business activity and there are no segment managers who are held accountable for operations or operating results below the Company level. Our chief operating decision maker is our Chief Executive Officer, who reviews financial information presented on a consolidated basis for purposes of allocating resources and evaluating financial performance.  Accordingly, we have determined that we operate as one reportable segment.

[0001596532-19-000027:notes:261]
Stock-Based Compensation

[0001596532-19-000027:notes:262]
Compensation expense related to stock-based transactions, including stock options, restricted stock units (“RSUs”), restricted stock awards (“RSAs”), and stock purchase rights under our employee stock purchase program is measured and recognized in the financial statements based on the fair value of the equity granted on a straight-line basis over the requisite service periods of the awards, which typically ranges from two to five years. Beginning 2017, upon the adoption of ASU 2016-09, Compensation-Stock Compensation: Improvements to Employee Share-Based Payment Accounting, we account for forfeitures as they occur and no longer include an estimate of future forfeitures in the expense recognition. Prior to 2017, stock-based compensation expense was recognized net of estimated forfeitures.

[0001596532-19-000027:notes:263]
Excess tax benefits generated from stock option exercises and other equity awards are recorded as a reduction to provision for income taxes in the consolidated statements of operations. Prior to 2017, before we adopted ASU 2016-09, such excess tax benefits were recognized as additional paid-in capital in the consolidated balance sheets. See Recently Adopted Accounting Pronouncements below for details. Excess tax benefits resulting from stock awards were $75.5 million, $110.0 million and $42.1 million for the years ended December 31, 2018, 2017 and 2016, respectively.

[0001596532-19-000027:notes:264]
Net Income per Share of Common Stock

[0001596532-19-000027:notes:265]
Business Combinations

[0001596532-19-000027:notes:266]
We use the acquisition method to account for our business combinations in accordance with ASC 805 - Business Combinations (“ASC 805”). We allocate the total fair value of purchase consideration to the tangible and intangible assets acquired and liabilities assumed based on their estimated fair values. The excess of the consideration transferred over the fair values of the assets acquired and liabilities assumed is recorded as goodwill. The results of operations of the acquired businesses are included in our consolidated financial statements from the date of acquisition. Acquisition-related costs and restructuring costs are expensed as incurred.

[0001596532-19-000027:notes:267]
During the measurement period, which is not to exceed one year from the acquisition date, we may record adjustments to the acquired assets and liabilities assumed, with a corresponding offset to goodwill or the preliminary purchase price, to reflect new information obtained about facts and circumstances that existed as of the acquisition date. Upon the conclusion of the measurement period, any subsequent adjustments are recorded to earnings.

[0001596532-19-000027:notes:268]
We perform our annual goodwill impairment analysis in the fourth quarter of each year or more frequently if there are any events or circumstances that would indicate the carrying amount is not recoverable. We first perform a qualitative assessment to determine if it’s necessary to perform a quantitative assessment.  If after our qualitative assessment, we determine it is more likely than not that the fair value of the Company is less than its carrying amount, then a quantitative test is performed by comparing the fair value of the Company with its carrying amount in accordance with Accounting Standard Update (“ASU”) No. 2017-04, Intangibles-Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. We would recognize an impairment loss for the amount by which the carrying amount exceeds the fair value.

[0001596532-19-000027:notes:269]
Intangible Assets

[0001596532-19-000027:notes:270]
Intangible assets are carried at cost less accumulated amortization. All intangible assets have been determined to have definite lives and are amortized on a straight-line basis over their estimated useful lives, ranging from one to seven years. Intangible assets are reviewed for impairment periodically or whenever events or changes in circumstances indicate that their carrying amounts may not be recoverable.

[0001596532-19-000027:notes:271]
Recently Adopted Accounting Pronouncements


## us-gaap:PostemploymentBenefitsDisclosureTextBlock

[0001596532-19-000027:notes:272]
Post-Employment Benefits

[0001596532-19-000027:notes:273]
We have a 401(k) Plan that covers substantially all of our employees in the U.S.  Effective January 1, 2017, we have elected to match 100% of employees' contributions up to a maximum of 3% of an employee's annual salary. Matching contributions will be immediately vested. For the years ended December 31, 2018 and 2017, we contributed approximately $4.6 million and $3.5 million for the matching contributions. For the year ended December 31, 2016, we did not provide a discretionary company match to employee contributions.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001596532-19-000027:notes:274]
Property and equipment, net consists of the following (in thousands):

[0001596532-19-000027:notes:275]
|  |  | December 31, |
|  |  | 2018 |  | 2017 |
| Equipment and machinery |  | $ | 55,912 |  |  | $ | 47,711 |  |
| Computer hardware and software |  | 30,566 |  |  | 22,124 |  |
| Furniture and fixtures |  | 3,697 |  |  | 3,020 |  |
| Leasehold improvements |  | 36,447 |  |  | 30,548 |  |
| Building |  | 35,154 |  |  | 35,154 |  |
| Construction-in-process |  | 3,591 |  |  | 4,742 |  |
| Property and equipment, gross |  | 165,367 |  |  | 143,299 |  |
| Less: accumulated depreciation |  | (90,012 | ) |  | (69,020 | ) |
| Property and equipment, net |  | $ | 75,355 |  |  | $ | 74,279 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001596532-19-000027:notes:276]
Selected Quarterly Financial Information (Unaudited)

[0001596532-19-000027:notes:277]
The following table sets forth selected unaudited quarterly consolidated statements of operations data for each of the quarters in the years ended December 31, 2018 and 2017:

[0001596532-19-000027:notes:278]
|  |  | Three Months Ended |
|  |  | Dec. 31, 2018 |  | Sep. 30, 2018 |  | Jun. 30, 2018 |  | Mar. 31, 2018 |  | Dec. 31, 2017 |  | Sep. 30, 2017 |  | Jun. 30, 2017 |  | Mar. 31, 2017 |
|  |  | (in thousands) |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 503,235 |  |  | $ | 485,481 |  |  | $ | 444,767 |  |  | $ | 407,617 |  |  | $ | 407,195 |  |  | $ | 380,344 |  |  | $ | 353,904 |  |  | $ | 291,367 |  |
| Service |  | 92,491 |  |  | 77,828 |  |  | 75,078 |  |  | 64,872 |  |  | 60,672 |  |  | 57,289 |  |  | 51,307 |  |  | 44,108 |  |
| Total revenue |  | 595,726 |  |  | 563,309 |  |  | 519,845 |  |  | 472,489 |  |  | 467,867 |  |  | 437,633 |  |  | 405,211 |  |  | 335,475 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 204,507 |  |  | 187,764 |  |  | 171,622 |  |  | 156,691 |  |  | 147,919 |  |  | 145,874 |  |  | 134,406 |  |  | 109,836 |  |
| Service |  | 16,227 |  |  | 13,962 |  |  | 14,340 |  |  | 12,879 |  |  | 12,783 |  |  | 11,142 |  |  | 11,028 |  |  | 11,429 |  |
| Total cost of revenue |  | 220,734 |  |  | 201,726 |  |  | 185,962 |  |  | 169,570 |  |  | 160,702 |  |  | 157,016 |  |  | 145,434 |  |  | 121,265 |  |
| Gross profit |  | 374,992 |  |  | 361,583 |  |  | 333,883 |  |  | 302,919 |  |  | 307,165 |  |  | 280,617 |  |  | 259,777 |  |  | 214,210 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | 118,439 |  |  | 117,589 |  |  | 104,078 |  |  | 102,362 |  |  | 107,180 |  |  | 79,610 |  |  | 81,194 |  |  | 81,610 |  |
| Sales and marketing |  | 50,911 |  |  | 47,903 |  |  | 46,188 |  |  | 42,140 |  |  | 38,808 |  |  | 40,640 |  |  | 38,630 |  |  | 37,027 |  |
| General and administrative |  | 12,000 |  |  | 15,321 |  |  | 18,420 |  |  | 19,679 |  |  | 21,789 |  |  | 19,535 |  |  | 23,319 |  |  | 22,155 |  |
| Legal settlement (1) |  | — |  |  | — |  |  | 405,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses |  | 181,350 |  |  | 180,813 |  |  | 573,686 |  |  | 164,181 |  |  | 167,777 |  |  | 139,785 |  |  | 143,143 |  |  | 140,792 |  |
| Income from operations |  | 193,642 |  |  | 180,770 |  |  | (239,803 | ) |  | 138,738 |  |  | 139,388 |  |  | 140,832 |  |  | 116,634 |  |  | 73,418 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | (661 | ) |  | (673 | ) |  | (680 | ) |  | (687 | ) |  | (741 | ) |  | (701 | ) |  | (623 | ) |  | (715 | ) |
| Other income (expense), net |  | 5,509 |  |  | 9,292 |  |  | (1,489 | ) |  | 4,843 |  |  | 2,988 |  |  | 2,136 |  |  | 1,119 |  |  | 1,025 |  |
| Total other income (expense), net |  | 4,848 |  |  | 8,619 |  |  | (2,169 | ) |  | 4,156 |  |  | 2,247 |  |  | 1,435 |  |  | 496 |  |  | 310 |  |
| Income before income taxes |  | 198,490 |  |  | 189,389 |  |  | (241,972 | ) |  | 142,894 |  |  | 141,635 |  |  | 142,267 |  |  | 117,130 |  |  | 73,728 |  |
| Provision for (benefit from) income taxes (2) |  | 28,168 |  |  | 20,865 |  |  | (86,703 | ) |  | (1,644 | ) |  | 37,802 |  |  | 8,545 |  |  | 14,445 |  |  | (9,233 | ) |
| Net income (loss) |  | $ | 170,322 |  |  | $ | 168,524 |  |  | $ | (155,269 | ) |  | $ | 144,538 |  |  | $ | 103,833 |  |  | $ | 133,722 |  |  | $ | 102,685 |  |  | $ | 82,961 |  |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.26 |  |  | $ | 2.25 |  |  | $ | (2.08 | ) |  | $ | 1.95 |  |  | $ | 1.42 |  |  | $ | 1.84 |  |  | $ | 1.42 |  |  | $ | 1.16 |  |
| Diluted |  | $ | 2.10 |  |  | $ | 2.08 |  |  | $ | (2.08 | ) |  | $ | 1.79 |  |  | $ | 1.29 |  |  | $ | 1.68 |  |  | $ | 1.30 |  |  | $ | 1.07 |  |
| ______________________ |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (1) See Note 14.(2) Resulting from the adoption of ASU 2016-09, provision for (benefit from) income taxes for the first, second, third and fourth quarter of 2018 included excess tax benefits of $25.3 million, $20.1 million, $22.3 million and $7.8 million, respectively, of 2017 included $28.8 million, $19.1 million, $23.8 million and $38.3 million, respectively. In addition, provision for income taxes for the fourth quarter of 2017 included a provisional amount of $51.8 million in connection with the Tax Act enacted on December 22, 2017. See Note 10 for details. Benefit from income taxes for the second quarter of 2018 also included a benefit of $99.0 million in connection with our legal settlement with Cisco. See Note 14. |


## us-gaap:ScheduleOfAccountsNotesLoansAndFinancingReceivableTextBlock

[0001596532-19-000027:notes:279]
Accounts Receivable, net

[0001596532-19-000027:notes:280]
Accounts receivable, net consists of the following (in thousands):

[0001596532-19-000027:notes:281]
|  |  | December 31, |
|  |  | 2018 |  | 2017 |
| Accounts receivable |  | $ | 340,897 |  |  | $ | 254,881 |  |
| Allowance for doubtful accounts |  | (507 | ) |  | (112 | ) |
| Product sales rebate and returns reserve |  | (8,613 | ) |  | (7,423 | ) |
| Accounts receivable, net |  | $ | 331,777 |  |  | $ | 247,346 |  |

[0001596532-19-000027:notes:282]
Allowance for Doubtful Accounts

[0001596532-19-000027:notes:283]
Activity in the allowance for doubtful accounts consists of the following (in thousands):

[0001596532-19-000027:notes:284]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Balance at the beginning of year |  | $ | 112 |  |  | $ | 204 |  |  | $ | 963 |  |
| Additions (deductions) charged (credited) to expense |  | 368 |  |  | 17 |  |  | (292 | ) |
| Addition in connection with business acquisitions |  | 132 |  |  | — |  |  | — |  |
| Deductions/write-offs |  | (105 | ) |  | (109 | ) |  | (467 | ) |
| Balance at the end of year |  | $ | 507 |  |  | $ | 112 |  |  | $ | 204 |  |

[0001596532-19-000027:notes:285]
Product Sales Rebate and Returns Reserve

[0001596532-19-000027:notes:286]
Activity in the product sales rebate and returns reserve consists of the following (in thousands):

[0001596532-19-000027:notes:287]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Balance at the beginning of year |  | $ | 7,423 |  |  | $ | 1,317 |  |  | $ | 566 |  |
| Additions charged against revenue |  | 4,269 |  |  | 17,371 |  |  | 5,122 |  |
| Consumption |  | (3,079 | ) |  | (11,265 | ) |  | (4,371 | ) |
| Balance at the end of year |  | $ | 8,613 |  |  | $ | 7,423 |  |  | $ | 1,317 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0001596532-19-000027:notes:288]
Accrued liabilities consist of the following (in thousands):

[0001596532-19-000027:notes:289]
|  |  | December 31, |
|  |  | 2018 |  | 2017 |
| Accrued payroll related costs |  | $ | 70,755 |  |  | $ | 56,626 |  |
| Accrued manufacturing costs |  | 31,336 |  |  | 35,703 |  |
| Accrued product development costs |  | 6,988 |  |  | 21,201 |  |
| Accrued warranty costs |  | 5,362 |  |  | 7,415 |  |
| Accrued professional fees |  | 5,678 |  |  | 7,086 |  |
| Accrued taxes |  | 839 |  |  | 794 |  |
| Other |  | 2,296 |  |  | 5,002 |  |
| Total accrued liabilities |  | $ | 123,254 |  |  | $ | 133,827 |  |


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001596532-19-000027:notes:290]
The following table is a reconciliation of cash, cash equivalents and restricted cash reported within the accompanying consolidated balance sheets that sum to the total of the same such amounts shown in the accompanying consolidated statements of cash flows (in thousands):

[0001596532-19-000027:notes:291]
|  |  | December 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Cash and cash equivalents |  | $ | 649,950 |  |  | $ | 859,192 |  |  | $ | 567,923 |  |
| Restricted cash included in other assets |  | 4,214 |  |  | 5,505 |  |  | 4,245 |  |
| Total cash, cash equivalents and restricted cash |  | $ | 654,164 |  |  | $ | 864,697 |  |  | $ | 572,168 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001596532-19-000027:notes:292]
Inventories consist of the following (in thousands):

[0001596532-19-000027:notes:293]
|  |  | December 31, |
|  |  | 2018 |  | 2017 |
| Raw materials |  | $ | 76,795 |  |  | $ | 69,673 |  |
| Finished goods |  | 187,762 |  |  | 236,525 |  |
| Total inventories |  | $ | 264,557 |  |  | $ | 306,198 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001596532-19-000027:notes:294]
Prepaid expenses and other current assets consists of the following (in thousands):

[0001596532-19-000027:notes:295]
|  |  | December 31, |
|  |  | 2018 |  | 2017 |
| Inventory deposit |  | $ | 14,639 |  |  | $ | 34,141 |  |
| Prepaid income taxes |  | 38,636 |  |  | 38,134 |  |
| Other current assets |  | 95,730 |  |  | 96,215 |  |
| Other prepaid expenses and deposits |  | 13,316 |  |  | 8,840 |  |
| Total prepaid expenses and other current assets |  | $ | 162,321 |  |  | $ | 177,330 |  |


## us-gaap:ScheduleOfOtherNonoperatingIncomeExpenseTableTextBlock

[0001596532-19-000027:notes:296]
Other income (expense), net consists of the following (in thousands):

[0001596532-19-000027:notes:297]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Interest income |  | $ | 31,666 |  |  | $ | 8,093 |  |  | $ | 2,995 |  |
| Interest expense |  | (2,701 | ) |  | (2,780 | ) |  | (3,136 | ) |
| Loss on investments in privately-held companies, net |  | (13,800 | ) |  | — |  |  | — |  |
| Other income (expense) |  | 289 |  |  | (825 | ) |  | (1,043 | ) |
| Total other income (expense), net |  | $ | 15,454 |  |  | $ | 4,488 |  |  | $ | (1,184 | ) |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001596532-19-000027:notes:298]
The following table summarizes the activity related to our accrued liability for estimated future warranty costs (in thousands):

[0001596532-19-000027:notes:299]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | 2017 |
| Warranty accrual, beginning of year |  | $ | 7,415 |  |  | $ | 6,744 |  |
| Liabilities accrued for warranties issued during the year |  | 3,565 |  |  | 5,542 |  |
| Warranty costs incurred during the year |  | (5,618 | ) |  | (4,871 | ) |
| Warranty accrual, end of year |  | $ | 5,362 |  |  | $ | 7,415 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001596532-19-000027:notes:300]
The following table represents revenue based on the customer’s location, as determined by the customer’s shipping address (in thousands):

[0001596532-19-000027:notes:301]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Americas |  | $ | 1,550,453 |  |  | $ | 1,192,289 |  |  | $ | 874,740 |  |
| Europe, Middle East and Africa |  | 414,069 |  |  | 299,547 |  |  | 168,789 |  |
| Asia Pacific |  | 186,847 |  |  | 154,350 |  |  | 85,638 |  |
| Total revenue |  | $ | 2,151,369 |  |  | $ | 1,646,186 |  |  | $ | 1,129,167 |  |

[0001596532-19-000027:notes:302]
Long lived assets, excluding intercompany receivables, investments in subsidiaries, privately held equity investments and deferred tax assets, net by location are summarized as follows (in thousands):

[0001596532-19-000027:notes:303]
|  |  | December 31, |
|  |  | 2018 |  | 2017 |
| United States |  | $ | 69,238 |  |  | $ | 69,128 |  |
| International |  | 6,117 |  |  | 5,151 |  |
| Total |  | $ | 75,355 |  |  | $ | 74,279 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001596532-19-000027:notes:304]
Segment Information

[0001596532-19-000027:notes:305]
We have determined that we operate as one reportable segment. The following table represents revenue based on the customer’s location, as determined by the customer’s shipping address (in thousands):


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001596532-19-000027:notes:306]
4.    Financial Statements Details

[0001596532-19-000027:notes:307]
Cash, Cash Equivalents and Restricted Cash

[0001596532-19-000027:notes:308]
The increase in activity in 2017 primarily relates to channel rebates that we began to offer during 2017.

[0001596532-19-000027:notes:309]
Inventories

[0001596532-19-000027:notes:310]
Prepaid Expenses and Other Current Assets

[0001596532-19-000027:notes:311]
Property and Equipment, net

[0001596532-19-000027:notes:312]
Depreciation expense was $21.6 million, $20.2 million and $19.4 million for the years ended December 31, 2018, 2017 and 2016, respectively.

[0001596532-19-000027:notes:313]
Accrued Liabilities

[0001596532-19-000027:notes:314]
Warranty Accrual

[0001596532-19-000027:notes:315]
There were no significant specific product warranty reserves recorded for the years ended December 31, 2018 or 2017.

[0001596532-19-000027:notes:316]
As of December 31, 2018, $13.5 million of our contract liabilities was included in “Other current liabilities” with the remaining balance included in “Other long-term liabilities”.

[0001596532-19-000027:notes:317]
Deferred Revenue and Performance Obligations

[0001596532-19-000027:notes:318]
Deferred revenue is comprised mainly of unearned revenue related to multi-year PCS contracts, services and product deferrals related to acceptance clauses. The following table summarizes the activity related to our deferred revenue (in thousands):

[0001596532-19-000027:notes:319]
Revenue from Remaining Performance Obligations

[0001596532-19-000027:notes:320]
Revenue from remaining performance obligations represents contracted revenue that has not yet been recognized, which primarily includes contract liabilities and deferred revenue that will be recognized as revenue in future periods. As of December 31, 2018, approximately $621.1 million of revenue is expected to be recognized from remaining performance obligations. We expect to recognize revenue on approximately 85% of these remaining performance obligations over the next 2 years and 15% during the 3rd to the 5th year.

[0001596532-19-000027:notes:321]
Other Income (Expense), Net
