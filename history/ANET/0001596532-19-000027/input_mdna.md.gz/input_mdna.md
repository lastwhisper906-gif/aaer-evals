# ANET MD&A — 0001596532-19-000027


## mdna

[0001596532-19-000027:mdna:1]
Item 7.  Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001596532-19-000027:mdna:2]
Overview

[0001596532-19-000027:mdna:3]
We are a leading supplier of cloud networking solutions that use software innovations to address the needs of large-scale internet companies, cloud service providers and next-generation data centers and campuses for enterprise support. Our cloud networking solutions consist of our Extensible Operating System, or EOS, a set of network applications and our Ethernet switching and routing platforms. Our cloud networking solutions deliver industry-leading performance, scalability, availability, programmability, automation and visibility. At the core of our cloud networking platform is EOS, which was purpose-built to be fully programmable and highly modular. The programmability of EOS has allowed us to create a set of software applications that address the requirements of cloud networking, including workflow automation, network visibility and analytics, and has also allowed us to rapidly integrate with a wide range of third-party applications for virtualization, management, automation, orchestration and network services.

[0001596532-19-000027:mdna:4]
We believe that cloud networks will continue to replace legacy network technologies, and that our cloud networking platform addresses the large and growing cloud networking segment of data center switching, which

[0001596532-19-000027:mdna:5]
remains in the early stage of adoption. Cloud networks are subject to increasing performance requirements due to the growing number of connected devices, as well as new enterprise and consumer applications. Computing architectures are evolving to meet the need for constant connectivity and access to data and applications. We expect to continue growing our organization to meet the needs of new and existing customers as they increasingly realize the performance and cost benefits of our cloud networking solutions and as they expand their cloud networks. Accordingly, we intend to continue to invest in our research and development organization to enhance the functionality of our existing cloud networking platform, introduce new products and features, and build upon our technology leadership. We believe one of our greatest strengths lies in our rapid development of new features and applications.

[0001596532-19-000027:mdna:6]
We generate revenue primarily from sales of our switching products which incorporate our EOS software. We generate the majority of our services revenue from post contract support, or PCS, which end customers typically purchase in conjunction with our products. Our end customers span a range of industries and include large internet companies, service providers, financial services organizations, government agencies, media and entertainment companies and others. As we have grown the functionality of our EOS software, expanded the range of our product portfolio and increased the size of our sales force, our revenue has continued to grow rapidly. We have also been profitable and operating cash flow positive for each year since 2010.

[0001596532-19-000027:mdna:7]
To continue to grow our revenue, it is important that we both obtain new customers and sell additional products to existing customers. We expect that a substantial portion of our future sales will be follow-on sales to existing customers. We intend to continue expanding our sales force and marketing activities in key geographies, as well as our relationships with channel, technology and system-level partners in order to reach new end customers more effectively, increase sales to existing customers, and provide services and support effectively. In order to support our strong growth, we have and may continue to accelerate our investment in infrastructure, such as enterprise resource planning software and other technologies to improve the efficiency of our operations.

[0001596532-19-000027:mdna:8]
Our development model is focused on the development of new products based on our EOS software and enhancements to EOS. We engineer our products to be agnostic to the underlying merchant silicon architecture. Today, we combine our EOS software with merchant silicon into a family of switching and routing products. This enables us to focus our research and development resources on our software core competencies and to leverage the investments made by merchant silicon vendors to achieve cost-effective solutions. We currently procure certain merchant silicon components from multiple vendors, and we continue to expand our relationships with these and other vendors. We work closely with third party contract manufacturers to manufacture our products. Our contract manufacturers deliver our products to our third party direct fulfillment facilities.  We and our fulfillment partners then perform labeling, final configuration, quality assurance testing and shipment to our customers.

[0001596532-19-000027:mdna:9]
Historically, large purchases by a relatively limited number of end customers have accounted for significant portion of our revenue. We have experienced unpredictability in the timing of large orders, especially with respect to our large end customers, due to the complexity of orders, the time it takes end customers to evaluate, test, qualify and accept our products and factors specific to our end customers. Due to these factors, we expect continued variability in our customer concentration and timing of sales on a quarterly and annual basis. For example, our sales to Microsoft as an end-user in the fiscal year ended December 31, 2018, representing 27% of our revenue during fiscal 2018, benefited from certain factors that may not repeat in fiscal 2019 or future fiscal years and the percentage of our revenue from Microsoft in fiscal 2019 may decline. In addition, we have provided, and may in the future provide, pricing discounts to large end customers, which may result in lower margins for the period in which such sales occur. Our gross margins may also fluctuate as a result of the timing of such sales to large end customers.

[0001596532-19-000027:mdna:10]
On August 6, 2018, we entered into a binding term sheet with Cisco (the “Term Sheet”). Pursuant to the Term Sheet, we paid Cisco $400.0 million on August 20, 2018, and the Company and Cisco obtained dismissals of all ongoing district court and USITC litigation between us. Cisco granted us a release for all past claims relating to the patents Cisco asserted against us in the district court and USITC, and we granted Cisco a release from all past antitrust and unfair competition claims. These mutual releases extended to the Company's and Cisco’s customers, contract manufacturers, and partners. The parties further agreed to a five-year stand-down period for any utility patent infringement claims either may have against features currently implemented in the other party’s products and services, with some carve-outs for products stemming from acquired companies. The parties further

[0001596532-19-000027:mdna:11]
agreed to a three-year dispute resolution process for allegations by either party against new and/or modified features in the other party’s products. We also agreed to make certain modifications to our Command Line Interface (“CLI”). On December 3, 2018, the parties entered into a Mutual Release and Settlement Agreement (the “Definitive Agreement”), which superseded the Term Sheet but did not substantially alter the terms. See Note 14. Legal Settlement of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K.

[0001596532-19-000027:mdna:12]
Furthermore, in order to comply with USITC exclusion and cease and desist orders previously issued in relation to the Cisco legal matter, we made certain design changes to our products for sale in the United States. Following the expiration and invalidation of related patent claims, effective July 1, 2018, certain features previously covered by the orders could be re-incorporated into our products.  We are working with customers to complete any remaining re-qualification procedures related to the reintroduction of these features, the timing of which could result in an impact to our revenue and our deferred revenue balances.

[0001596532-19-000027:mdna:13]
Acquisitions

[0001596532-19-000027:mdna:14]
On August 2, 2018, we completed the acquisition of Mojo Networks, Inc., a provider of Cognitive WiFi and cloud-managed wireless networking solutions headquartered in Mountain View, California. We expect to extend our cognitive cloud networking architecture with the addition of Mojo by providing secure, high performance cognitive WiFi at cloud scale.

[0001596532-19-000027:mdna:15]
On September 12, 2018, we completed the acquisition of Metamako Holding PTY LTD. Headquartered in Sydney, Australia, Metamako was a leader in solutions for latency sensitive business applications. We expect this acquisition to play a key role in the delivery of our next generation platforms for low-latency applications.

[0001596532-19-000027:mdna:16]
Results of Operations

[0001596532-19-000027:mdna:17]
Year Ended December 31, 2018 Compared to Year Ended December 31, 2017

[0001596532-19-000027:mdna:18]
Revenue, Cost of Revenue and Gross Profit (in thousands, except percentages)

[0001596532-19-000027:mdna:19]
|  |  | Year Ended December 31, |  |  |
|  |  | 2018 |  | 2017 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,841,100 |  |  | 85.6 | % |  | $ | 1,432,810 |  |  | 87.0 | % |  | $ | 408,290 |  |  | 28.5 | % |
| Service |  | 310,269 |  |  | 14.4 |  |  | 213,376 |  |  | 13.0 |  |  | 96,893 |  |  | 45.4 |  |
| Total revenue |  | 2,151,369 |  |  | 100.0 |  |  | 1,646,186 |  |  | 100.0 |  |  | 505,183 |  |  | 30.7 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 720,584 |  |  | 33.5 |  |  | 538,035 |  |  | 32.7 |  |  | 182,549 |  |  | 33.9 |  |
| Service |  | 57,408 |  |  | 2.7 |  |  | 46,382 |  |  | 2.8 |  |  | 11,026 |  |  | 23.8 |  |
| Total cost of revenue |  | 777,992 |  |  | 36.2 |  |  | 584,417 |  |  | 35.5 |  |  | 193,575 |  |  | 33.1 |  |
| Gross profit |  | $ | 1,373,377 |  |  | 63.8 | % |  | $ | 1,061,769 |  |  | 64.5 | % |  | $ | 311,608 |  |  | 29.3 | % |
| Gross margin |  | 63.8 | % |  |  |  | 64.5 | % |  |  |  |  |  |  |

[0001596532-19-000027:mdna:20]
Revenue by Geography (in thousands, except percentages)

[0001596532-19-000027:mdna:21]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | % of Total |  | 2017 |  | % of Total |
| Americas |  | $ | 1,550,453 |  |  | 72.1 | % |  | $ | 1,192,289 |  |  | 72.4 | % |
| Europe, Middle East and Africa |  | 414,069 |  |  | 19.2 |  |  | 299,547 |  |  | 18.2 |  |
| Asia-Pacific |  | 186,847 |  |  | 8.7 |  |  | 154,350 |  |  | 9.4 |  |
| Total revenue |  | $ | 2,151,369 |  |  | 100.0 | % |  | $ | 1,646,186 |  |  | 100.0 | % |

[0001596532-19-000027:mdna:22]
Revenue

[0001596532-19-000027:mdna:23]
We generate revenue primarily from sales of our products. We also derive a portion of our revenue from sales of PCS, which is typically purchased in conjunction with our products, and subsequent renewals of those contracts. We expect our revenue may vary from period to period based on, among other things, the timing and size of orders, the delivery and acceptance of products, and the impact of significant transactions.  In addition, while we expect our revenue to continue to grow in absolute dollars on a year-over-year basis, our revenue growth rates are expected to decline as our business scales.

[0001596532-19-000027:mdna:24]
Product revenue increased $408.3 million, or 28.5%, in the year ended December 31, 2018 compared to 2017. The increase was primarily driven by sales to our existing customers as they continued to expand and upgrade their cloud networks. In addition, our newer switch products have continued to gain market acceptance, which has contributed to our revenue growth. Service revenue increased $96.9 million, or 45.4%, in the year ended December 31, 2018 compared to 2017 as a result of continued growth in initial and renewal support contracts as our customer installed base has continued to expand. We continue to experience pricing pressure on our products and services due to competition, but demand for our products and growth in our installed base has more than offset this pricing pressure during the period.

[0001596532-19-000027:mdna:25]
Cost of Revenue and Gross Margin

[0001596532-19-000027:mdna:26]
Cost of revenue primarily consists of amounts paid for inventory to our third-party contract manufacturers and merchant silicon vendors, overhead costs in our manufacturing operations department, and other manufacturing-related costs associated with manufacturing our products and managing our inventory.

[0001596532-19-000027:mdna:27]
Cost of revenue increased $193.6 million or 33.1% for the year ended December 31, 2018 compared to 2017. The increase in cost of revenue was primarily due to the corresponding increases in product revenues. We expect our cost of product revenue to continue to increase as our product revenue increases. Cost of providing PCS and other services consists primarily of personnel costs for our global customer support organization.

[0001596532-19-000027:mdna:28]
Gross margin, or gross profit as a percentage of revenue, has been and will continue to be affected by a variety of factors, including sales to large end customers who generally receive lower pricing, manufacturing-related costs including costs associated with supply chain sourcing activities, merchant silicon costs, the mix of products sold, and excess/obsolete inventory write-downs, including charges for excess/obsolete component inventory held by our contract manufacturers.

[0001596532-19-000027:mdna:29]
Gross margin decreased from 64.5% to 63.8% for the year ended December 31, 2018 compared to 2017.   The decrease in gross margin was primarily driven by a decrease in product margins due to customer mix, partially offset by reduced inventory-related charges and an improved service margins due to a relatively fixed services cost base and growing service revenues. We expect our gross margins to fluctuate over time, depending on the factors described above.

[0001596532-19-000027:mdna:30]
Operating Expenses (in thousands, except percentages)

[0001596532-19-000027:mdna:31]
Our operating expenses consist of research and development, sales and marketing, general and administrative expenses, and legal settlement expense. The largest component of our operating expenses is personnel costs. Personnel costs consist of wages, benefits, bonuses and, with respect to sales and marketing expenses, sales commissions. Personnel costs also include stock-based compensation and travel expenses. We

[0001596532-19-000027:mdna:32]
expect operating expenses to continue to increase in absolute dollars in the near term as we continue to invest in the growth of our business.

[0001596532-19-000027:mdna:33]
|  |  | Year Ended December 31, |  |  |
|  |  | 2018 |  | 2017 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 442,468 |  |  | 20.6 | % |  | $ | 349,594 |  |  | 21.2 | % |  | $ | 92,874 |  |  | 26.6 | % |
| Sales and marketing |  | 187,142 |  |  | 8.7 |  |  | 155,105 |  |  | 9.4 |  |  | 32,037 |  |  | 20.7 |  |
| General and administrative |  | 65,420 |  |  | 3.0 |  |  | 86,798 |  |  | 5.3 |  |  | (21,378 | ) |  | (24.6 | ) |
| Legal settlement |  | 405,000 |  |  | 18.8 |  |  | — |  |  | — |  |  | 405,000 |  |  | * |  |
| Total operating expenses |  | $ | 1,100,030 |  |  | 51.1 | % |  | $ | 591,497 |  |  | 35.9 | % |  | $ | 508,533 |  |  | 86.0 | % |
| __________________ |
| * Not meaningful. |

[0001596532-19-000027:mdna:34]
Research and development.

[0001596532-19-000027:mdna:35]
Research and development expenses consist primarily of personnel costs, prototype expenses, third-party engineering and contractor support costs, and an allocated portion of facility and IT costs including depreciation. Our research and development efforts are focused on maintaining and developing additional functionality for our existing products and on new product development, including new releases and upgrades to our EOS software and applications. We expect our research and development expenses to increase in absolute dollars as we continue to invest heavily in software development in order to expand the capabilities of our cloud networking platform, introduce new products and features and build upon our technology leadership.

[0001596532-19-000027:mdna:36]
Research and development expenses increased $92.9 million, or 26.6%, for the year ended December 31, 2018 compared to 2017. The increase was primarily due to a $48.9 million increase in personnel costs, including corporate bonuses and stock-based compensation, driven primarily by headcount growth from our normal hiring process and from the two acquisitions we completed in the third quarter of 2018, and a $24.7 million increase in new product introduction costs, driven by additional development projects. In addition, facility and IT costs increased by $9.5 million due to increased IT services, headcount growth and additional costs associated with our acquired businesses.

[0001596532-19-000027:mdna:37]
Sales and marketing.

[0001596532-19-000027:mdna:38]
Sales and marketing expenses consist primarily of personnel costs, marketing and promotional activities, and an allocated portion of facility and IT costs including depreciation. We expect our sales and marketing expenses to increase in absolute dollars as we continue to expand our sales and marketing efforts worldwide.

[0001596532-19-000027:mdna:39]
Sales and marketing expenses increased $32.0 million, or 20.7% for the year ended December 31, 2018 compared to 2017. The increase primarily included a $28.0 million increase in personnel costs, which was driven by increased headcount as well as higher sales volumes, resulting in increased compensation costs, including commissions and stock-based compensation.

[0001596532-19-000027:mdna:40]
General and administrative.

[0001596532-19-000027:mdna:41]
General and administrative expenses consist primarily of Cisco and OptumSoft litigation related expenses, personnel costs, professional services fees, and an allocated portion of facility and IT costs including depreciation. General and administrative personnel costs include those for our executive, finance, human resources and legal functions. Our professional services fees are primarily due to external legal, accounting, and tax services.

[0001596532-19-000027:mdna:42]
General and administrative expenses decreased $21.4 million, or 24.6%, for the year ended December 31, 2018 compared to 2017. The decrease included a $33.8 million decrease that was primarily related to a reduced level of litigation activities and a decrease in bond costs as a result of the settlement of the Cisco litigation in August 2018. The decrease was partially offset by $3.5 million of acquisition-related expenses incurred in 2018,

[0001596532-19-000027:mdna:43]
a $3.3 million increase in personnel costs, including increased stock-based compensation, driven by increased headcount, and a $3.1 million increase in other legal and professional fees.

[0001596532-19-000027:mdna:44]
Legal settlement.

[0001596532-19-000027:mdna:45]
During the three months ended June 30, 2018, we recorded $405.0 million in legal settlement expenses in connection with the Term Sheet that was entered into on August 6, 2018 between the Company and Cisco, which included a $400.0 million payment to Cisco pursuant to the Term Sheet and $5.0 million of legal fees associated with the settlement. See Note 14. Legal Settlement of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K for further discussion.

[0001596532-19-000027:mdna:46]
Other Income (Expense), Net (in thousands, except percentages)

[0001596532-19-000027:mdna:47]
Other income (expense) consists primarily of interest income from our cash, cash equivalents and marketable securities, foreign currency transaction gains and losses, gains and losses on our investments in privately-held companies, and interest expense on our lease financing obligation. In connection with our adoption of ASU 2016-01 in 2018, other income (expense) may fluctuate in the future as a result of the re-measurement of our private company equity investments upon the occurrence of observable price changes and/or impairments. See Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K for details of this new guidance. In addition, Other income (expense), net will also fluctuate due to changes in interest rates, returns on our cash and cash equivalents and marketable securities, and foreign currency exchange rate fluctuations on our foreign currency transactions.

[0001596532-19-000027:mdna:48]
|  |  | Year Ended December 31, |  |  |
|  |  | 2018 |  | 2017 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | $ | (2,701 | ) |  | (0.1 | )% |  | $ | (2,780 | ) |  | (0.2 | )% |  | $ | 79 |  |  | (2.8 | )% |
| Other income (expense), net |  | 18,155 |  |  | 0.8 |  |  | 7,268 |  |  | 0.4 |  |  | 10,887 |  |  | 149.8 |  |
| Total other income (expense), net |  | $ | 15,454 |  |  | 0.7 | % |  | $ | 4,488 |  |  | 0.2 | % |  | $ | 10,966 |  |  | 244.3 | % |

[0001596532-19-000027:mdna:49]
The favorable change in other income (expense), net, during the year ended December 31, 2018 as compared to 2017 was driven by a $23.6 million increase in interest income as we continued to generate cash and expand our marketable securities portfolios, which was offset partially by a $13.8 million net loss recorded in 2018 on our investments in privately-held companies. See Note 5. Investments of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K for further discussion.

[0001596532-19-000027:mdna:50]
Provision for (Benefit from) Income Taxes (in thousands, except percentages)

[0001596532-19-000027:mdna:51]
We operate in a number of tax jurisdictions and are subject to taxes in each country or jurisdiction in which we conduct business. Earnings from our non-U.S. activities are subject to local country income tax and may also be subject to U.S. income tax. Generally, our U.S. tax obligations are reduced by a credit for foreign income taxes paid on these foreign earnings which avoids double taxation. Our tax expense to date consists of federal, state and foreign current and deferred income taxes.

[0001596532-19-000027:mdna:52]
|  |  | Year Ended December 31, |  |  |
|  |  | 2018 |  | 2017 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Provision for (benefit from) income taxes |  | $ | (39,314 | ) |  | (1.9 | )% |  | $ | 51,559 |  |  | 3.1 | % |  | $ | (90,873 | ) |  | (176.3 | ) |
| Effective tax rate |  | (13.6 | )% |  |  |  | 10.9 | % |  |  |  |  |  |  |  |  |

[0001596532-19-000027:mdna:53]
For the years ended December 31, 2018 and 2017, we recorded a benefit of $39.3 million and an expense of $51.6 million for income taxes, respectively.  The change in our income taxes was largely attributable to a $96.9 million tax benefit on the Cisco settlement in 2018 whereas we recorded a $51.8 million tax expense in 2017 related to the enactment of the Tax Act. The Tax Act provided for a decrease in the 2018 U.S. federal statutory tax rate, but this was partially offset by a new requirement to provide U.S. tax on foreign earnings. For further information regarding income taxes and the impact on our results of operations and financial position, see Note 10. Income Taxes of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K.

[0001596532-19-000027:mdna:54]
Our future effective tax rate is expected to be impacted by fluctuations in excess tax benefits on share-based compensation.

[0001596532-19-000027:mdna:55]
Year Ended December 31, 2017 Compared to Year Ended December 31, 2016

[0001596532-19-000027:mdna:56]
Revenue, Cost of Revenue and Gross Profit (in thousands, except percentages)

[0001596532-19-000027:mdna:57]
|  |  | Year Ended December 31, |  |  |
|  |  | 2017 |  | 2016 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 1,432,810 |  |  | 87.0 | % |  | $ | 991,337 |  |  | 87.8 | % |  | $ | 441,473 |  |  | 44.5 | % |
| Service |  | 213,376 |  |  | 13.0 |  |  | 137,830 |  |  | 12.2 |  |  | 75,546 |  |  | 54.8 |  |
| Total revenue |  | 1,646,186 |  |  | 100.0 |  |  | 1,129,167 |  |  | 100.0 |  |  | 517,019 |  |  | 45.8 |  |
| Cost of revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | 538,035 |  |  | 32.7 |  |  | 369,768 |  |  | 32.8 |  |  | 168,267 |  |  | 45.5 |  |
| Service |  | 46,382 |  |  | 2.8 |  |  | 36,283 |  |  | 3.2 |  |  | 10,099 |  |  | 27.8 |  |
| Total cost of revenue |  | 584,417 |  |  | 35.5 |  |  | 406,051 |  |  | 36.0 |  |  | 178,366 |  |  | 43.9 |  |
| Gross profit |  | $ | 1,061,769 |  |  | 64.5 | % |  | $ | 723,116 |  |  | 64.0 | % |  | $ | 338,653 |  |  | 46.8 | % |
| Gross margin |  | 64.5 | % |  |  |  | 64.0 | % |  |  |  |  |  |  |

[0001596532-19-000027:mdna:58]
Revenue by Geography (in thousands, except percentages)

[0001596532-19-000027:mdna:59]
|  |  | Year Ended December 31, |
|  |  | 2017 |  | % of Total |  | 2016 |  | % of Total |
| Americas |  | $ | 1,192,289 |  |  | 72.4 | % |  | $ | 874,740 |  |  | 77.5 | % |
| Europe, Middle East and Africa |  | 299,547 |  |  | 18.2 |  |  | 168,789 |  |  | 14.9 |  |
| Asia-Pacific |  | 154,350 |  |  | 9.4 |  |  | 85,638 |  |  | 7.6 |  |
| Total revenue |  | $ | 1,646,186 |  |  | 100.0 | % |  | $ | 1,129,167 |  |  | 100.0 | % |

[0001596532-19-000027:mdna:60]
Revenue

[0001596532-19-000027:mdna:61]
Product revenue increased $441.5 million, or 44.5%, in the year ended December 31, 2017 compared to 2016. The increase was primarily driven by increased product shipments to our existing customers as they continued to expand their cloud networks. In addition, our newer switch products had continued to gain market acceptance, which had contributed to our revenue growth. Service revenue increased $75.5 million, or 54.8%, in the year ended December 31, 2017 compared to 2016 as a result of continued growth in initial and renewal support contracts as our customer installed base continued to expand.

[0001596532-19-000027:mdna:62]
We continued to experience pricing pressure on our products and services due to competition, but demand for our products and growth in our installed base had more than offset this pricing pressure. Deferred product revenue at December 31, 2017 remained consistent with the balance at December 31, 2016. The deferred product revenue balance at December 31, 2016 primarily included customer arrangements with new product and new customer acceptance clauses, which expired during 2017, while the balance at December 31, 2017 primarily

[0001596532-19-000027:mdna:63]
represented arrangements with a few of our larger customers related to the then ongoing qualification activities of our 945 Investigation-related product redesigns. See Note 7. Commitments and Contingencies of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K

[0001596532-19-000027:mdna:64]
Cost of Revenue and Gross Margin

[0001596532-19-000027:mdna:65]
Cost of revenue increased $178.4 million, or 43.9%, for the year ended December 31, 2017 compared to 2016. The increase in cost of revenue was primarily due to an increase in product shipment volumes and the corresponding increase in product revenue. Gross margin increased from 64.0% to 64.5% for the year ended December 31, 2017 compared to 2016. The increase in gross margin was primarily driven by improved service margins as we scaled our services business on a relatively fixed cost base and slightly better product margins due to end customer mix. This improvement was partially offset by an increase in excess and obsolete inventory-related charges as we transitioned to new products.

[0001596532-19-000027:mdna:66]
Operating Expenses (in thousands, except percentages)

[0001596532-19-000027:mdna:67]
|  |  | Year Ended December 31, |  |  |
|  |  | 2017 |  | 2016 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  | $ | 349,594 |  |  | 21.2 | % |  | $ | 273,581 |  |  | 24.2 | % |  | $ | 76,013 |  |  | 27.8 | % |
| Sales and marketing |  | 155,105 |  |  | 9.4 |  |  | 130,887 |  |  | 11.6 |  |  | 24,218 |  |  | 18.5 |  |
| General and administrative |  | 86,798 |  |  | 5.3 |  |  | 75,239 |  |  | 6.7 |  |  | 11,559 |  |  | 15.4 |  |
| Total operating expenses |  | $ | 591,497 |  |  | 35.9 | % |  | $ | 479,707 |  |  | 42.5 | % |  | $ | 111,790 |  |  | 23.3 | % |

[0001596532-19-000027:mdna:68]
Research and development

[0001596532-19-000027:mdna:69]
Research and development expenses increased $76.0 million, or 27.8%, for the year ended December 31, 2017 compared to the same period in 2016. The increase was primarily due to a $36.9 million increase in personnel costs driven by headcount growth, resulting in additional compensation costs, including stock-based compensation, and a $31.6 million increase in new product introduction costs, driven by additional development projects, and costs associated with litigation-related changes in product design. In addition, facility and IT costs increased by $5.3 million due to the headcount growth.

[0001596532-19-000027:mdna:70]
Sales and marketing

[0001596532-19-000027:mdna:71]
Sales and marketing expenses increased $24.2 million, or 18.5%, for the year ended December 31, 2017 compared to the same period in 2016. The increase included a $15.4 million increase in personnel costs, which was primarily due to increased headcount as well as higher sales volumes, driving increased compensation costs, including commissions and stock-based compensation. In addition, sales support costs increased by $8.1 million compared to 2016, reflecting increased professional services and field demonstration costs to support our sales infrastructure and expand our customer base.

[0001596532-19-000027:mdna:72]
General and administrative

[0001596532-19-000027:mdna:73]
General and administrative expenses increased $11.6 million, or 15.4%, for the year ended December 31, 2017 compared to the same period in 2016. The increase was primarily due to a $4.5 million increase in the Cisco litigation related expenses, which included bond costs associated with the importation and sale of affected products and components during the presidential review period of the 945 Investigation. In addition, personnel costs increased by $3.9 million primarily due to increased stock-based compensation and higher salary related costs driven by the increased headcount.

[0001596532-19-000027:mdna:74]
Other Income (Expense), Net (in thousands, except percentages)

[0001596532-19-000027:mdna:75]
|  |  | Year Ended December 31, |  |  |
|  |  | 2017 |  | 2016 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Other income (expense), net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense |  | $ | (2,780 | ) |  | (0.2 | )% |  | $ | (3,136 | ) |  | (0.3 | )% |  | $ | 356 |  |  | (11.4 | )% |
| Other income (expense), net |  | 7,268 |  |  | 0.4 |  |  | 1,952 |  |  | 0.2 |  |  | 5,316 |  |  | 272.3 |  |
| Total other income (expense), net |  | $ | 4,488 |  |  | 0.2 | % |  | $ | (1,184 | ) |  | (0.1 | )% |  | $ | 5,672 |  |  | (479.1 | )% |

[0001596532-19-000027:mdna:76]
Other income (expense), net improved during the year ended December 31, 2017 compared to 2016 primarily due to an increase in interest income as we continued to generate cash and expand our marketable securities portfolio.

[0001596532-19-000027:mdna:77]
Provision for Income Taxes (in thousands, except percentages)

[0001596532-19-000027:mdna:78]
|  |  | Year Ended December 31, |  |  |
|  |  | 2017 |  | 2016 |  | Change in |
|  |  | $ |  | % ofRevenue |  | $ |  | % ofRevenue |  | $ |  | % |
| Provision for income taxes |  | $ | 51,559 |  |  | 3.1 | % |  | $ | 58,036 |  |  | 5.1 | % |  | $ | (6,477 | ) |  | (11.2 | )% |
| Effective tax rate |  | 10.9 | % |  |  |  | 24.0 | % |  |  |  |  |  |  |

[0001596532-19-000027:mdna:79]
Our provision for income taxes was approximately $51.6 million and $58.0 million for the year ended December 31, 2017 and 2016, respectively, which resulted in a decrease in our effective tax rate from 24.0% in 2016 to 10.9% in 2017.  The reduction in our effective tax rate was primarily due to the recognition of $110.0 million of excess tax benefits on share-based awards in the provision for income taxes as a result of our adoption of ASU 2016-09 in 2017, combined with a favorable geographical mix of our earnings towards jurisdictions with lower tax rates than the U.S.  These positive drivers were partially offset by the inclusion of provisional tax amount totaling $51.8 million resulting from the recently enacted the Tax Act.

[0001596532-19-000027:mdna:80]
The Tax Act makes significant changes to the U.S. tax code, which include, but are not limited to, a U.S. federal corporate tax rate decrease from 35% to 21% effective January 1, 2018, and a shift to a modified territorial tax regime, which requires companies to pay a one-time transition tax on the mandatory deemed repatriation of the cumulative earnings of certain foreign subsidiaries as of December 31, 2017.  As of December 31, 2017, we had not yet completed our accounting for the tax effects of the Tax Act. As a result, we recorded a provisional tax amount of $18.8 million for the transition tax and a provisional tax amount of $33.0 million related to the re-measurement of certain deferred tax assets and liabilities, based on the tax rates at which they are expected to reverse in the future.

[0001596532-19-000027:mdna:81]
Liquidity and Capital Resources

[0001596532-19-000027:mdna:82]
Our principal sources of liquidity are cash, cash equivalents, marketable securities, and cash generated from operations. As of December 31, 2018, our total balance of cash, cash equivalents and marketable securities was $2.0 billion, of which approximately $294.1 million was held outside the U.S. in our foreign subsidiaries.

[0001596532-19-000027:mdna:83]
Our cash, cash equivalents and marketable securities are held for working capital purposes. Our marketable securities investment portfolio is primarily invested in highly-rated securities with the primary objective of minimizing the potential risk of principal loss. We plan to continue to invest for long-term growth. We believe that our existing balances of cash, cash equivalents and marketable securities together with cash generated from operations will be sufficient to meet our working capital requirements and our growth strategies for at least the next 12 months. Our future capital requirements will depend on many factors, including our growth rate, the timing and extent of our spending to support research and development activities, the timing and cost of establishing additional sales and marketing capabilities, the introduction of new and enhanced product and service offerings,

[0001596532-19-000027:mdna:84]
our costs associated with supply chain activities, including access to outsourced manufacturing, our costs related to investing in or acquiring complementary or strategic businesses and technologies, the continued market acceptance of our products, and costs incurred related to outstanding litigation claims. If we require or elect to seek additional capital through debt or equity financing in the future, we may not be able to raise capital on terms acceptable to us or at all. If we are required and unable to raise additional capital when desired, our business, operating results and financial condition may be adversely affected.

[0001596532-19-000027:mdna:85]
Cash Flows

[0001596532-19-000027:mdna:86]
|  |  | Year Ended December 31, |
|  |  | 2018 |  | 2017As Adjusted (1) |  | 2016As Adjusted (1) |
|  |  | (in thousands) |
| Cash provided by operating activities |  | $ | 503,119 |  |  | $ | 631,627 |  |  | $ | 174,295 |  |
| Cash used in investing activities (1) |  | (755,113 | ) |  | (391,320 | ) |  | (325,775 | ) |
| Cash provided by financing activities |  | 42,851 |  |  | 51,469 |  |  | 32,745 |  |
| Effect of exchange rate changes |  | (1,390 | ) |  | 753 |  |  | (464 | ) |
| Net increase/(decrease) in cash, cash equivalents and restricted cash |  | $ | (210,533 | ) |  | $ | 292,529 |  |  | $ | (119,199 | ) |
| __________________________ |  |  |  |  |  |
| (1) Cash used in investing activities for year ended December 31, 2017 and 2016 were adjusted as a result of our adoption of ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash, in the first quarter of 2018. See Note 1. Organization and Summary of Significant Accounting Policies included in Part II, Item 8, of this Annual Report on Form 10-K for more information. |

[0001596532-19-000027:mdna:87]
Cash Flows from Operating Activities

[0001596532-19-000027:mdna:88]
Our primary source of cash provided by operating activities has been cash collections from our customers. We expect cash inflows from operating activities to be affected by increased sales and timing of collections. Our primary uses of cash from operating activities have been for personnel costs, inventory purchases from our contract manufacturers and suppliers, investment in research and development, and litigation expenses.

[0001596532-19-000027:mdna:89]
During the year ended December 31, 2018, cash provided by operating activities was $503.1 million, net of $405.0 million payments for the legal settlement with Cisco including the associated legal fees. Our cash provided by operating activities was primarily from net income of $328.1 million, non-cash adjustments to net income of $71.4 million, and a net increase of $103.6 million in cash from changes in our operating assets and liabilities. Our operating cash benefited $70.5 million from increased deferred revenue reflecting ongoing growth in service and support contracts, $51.1 million from decreased inventories driven by improved inventory management and timing of receipts, $39.3 million from increased accounts payable due to timing of vendor payments primarily related to inventory-related purchases, $21.4 million from a decrease in prepaid expenses and other assets primarily due to decreased deposits at our contract manufacturers, and $17.5 million from an increase in other long term liabilities primarily driven by increased customer prepayments under cancellable contracts.  These favorable changes were partially offset by unfavorable changes of $77.9 million from increased accounts receivable due to increased billing and timing of customer shipments, and $14.8 million from decreased accrued liabilities due primarily to a decline in supplier liabilities and the timing of vendor accruals.

[0001596532-19-000027:mdna:90]
During the year ended December 31, 2017, cash provided by operating activities was $631.6 million, primarily from net income of $423.2 million with non-cash adjustments to net income of $105.9 million, and a net increase of $102.5 million in cash from changes in our operating assets and liabilities. Our operating cash benefited $142.3 million from increased deferred revenue reflecting ongoing growth in service and support contracts, $43.5 million from increased accrued liabilities driven by increased inventory purchases and product development activities, and $19.9 million from increased income taxes payable. These favorable changes were partially offset by a growth in inventory of $69.7 million, supporting overall growth in the business and the expansion of our manufacturing and supply chain activities, by a decline in accounts payable of $30.1 million due

[0001596532-19-000027:mdna:91]
to timing of vendor payments primarily related to inventory purchases, and by an increase in prepaid expenses and other assets of $11.6 million primarily due to increased prepaid taxes.

[0001596532-19-000027:mdna:92]
During the year ended December 31, 2016, cash provided by operating activities was $174.3 million, primarily from net income of $184.2 million with non-cash adjustments to net income of $58.6 million, partially offset by a net decrease in cash from changes in our operating assets and liabilities of $68.4 million. The decrease in cash from changes in operating assets and liabilities was primarily due to an increase in working capital requirements with accounts receivable up $108.9 million, inventories and inventory deposits up $207.5 million, and increased prepaid expenses and current assets (excluding inventory deposits) of $54.8 million which was primarily driven by an increase in deferred cost of inventory associated with increased product revenue deferrals referenced below. These increases reflect substantial growth in the business and the expansion of our manufacturing and supply chain activities at our new contract manufacturer. These working capital increases were partially offset by an increase in deferred revenue of $176.1 million reflecting ongoing growth in service and support contracts and a significant increase in product deferred revenue related to contract acceptance terms, as well as an increase in accounts payable and accrued liabilities of $69.3 million primarily due to timing of inventory purchases, and an increase in income taxes payable of $42.7 million.

[0001596532-19-000027:mdna:93]
Cash Flows from Investing Activities

[0001596532-19-000027:mdna:94]
Our investing activities have consisted primarily of purchases of available for sale marketable securities, net of proceeds from maturities of marketable securities, business acquisitions, investments in privately-held companies, and capital expenditures.

[0001596532-19-000027:mdna:95]
During the year ended December 31, 2018, cash used in investing activities was $755.1 million, consisting of purchases of marketable securities of $1.2 billion, offset by proceeds of $547.8 million from maturities of marketable securities, $96.8 million for business acquisitions, additional investments in privately-held companies of $8.0 million, and purchases of property, equipment and other assets of $23.8 million.

[0001596532-19-000027:mdna:96]
During the year ended December 31, 2017, cash used in investing activities was $391.3 million, consisting of purchases of marketable securities of $585.4 million, purchases of property, equipment and other assets of $15.3 million, partially offset by proceeds of $206.3 million from maturities of marketable securities and proceeds of $3.0 million from repayment of notes receivable.

[0001596532-19-000027:mdna:97]
During the year ended December 31, 2016, cash used in investing activities was $325.8 million, consisting of purchases of marketable securities of $439.7 million, purchases of property, equipment and other assets of $21.4 million, and an additional investment in a privately-held company of $2.5 million. These decreases were partially offset by proceeds from the maturity of available-for-sale securities of $137.9 million.

[0001596532-19-000027:mdna:98]
Cash Flows from Financing Activities

[0001596532-19-000027:mdna:99]
Our financing activities have consisted primarily of proceeds from the issuance of our common stock under employee equity incentive plans, offset by principal payments for lease financing obligations related to our headquarters facility.

[0001596532-19-000027:mdna:100]
During the year ended December 31, 2018, cash provided by financing activities was $42.9 million, consisting primarily of proceeds of $53.7 million from the issuance of common stock under employee equity incentive plans, partially offset by $8.9 million of minimum tax withheld for employees and payments of $1.9 million for lease financing obligations.

[0001596532-19-000027:mdna:101]
During the year ended December 31, 2017, cash provided by financing activities was $51.5 million, consisting primarily of proceeds of $44.6 million from employee stock option exercises, partially offset by $4.0 million of minimum tax withheld for employees, and proceeds of $12.5 million from employee stock purchases under our ESPP, partially offset by payments of $1.6 million for lease financing obligations.

[0001596532-19-000027:mdna:102]
During the year ended December 31, 2016, cash provided by financing activities was $32.7 million, consisting primarily of proceeds from the exercise of stock options of $24.9 million and proceeds from the issuance of common stock from our ESPP of $10.3 million, partially offset by payments of $1.3 million for lease financing obligations.

[0001596532-19-000027:mdna:103]
Off-Balance Sheet Arrangements

[0001596532-19-000027:mdna:104]
As of December 31, 2018, we did not have any relationships with any unconsolidated entities or financial partnerships, such as entities often referred to as structured finance or special purpose entities that would have been established for the purpose of facilitating off-balance sheet arrangements or other contractually narrow or limited purposes.

[0001596532-19-000027:mdna:105]
Contractual Obligations and Commitments

[0001596532-19-000027:mdna:106]
Our contractual commitments will have an impact on our future liquidity. Our contractual obligations represent material expected or contractually committed future payment obligations. We believe that we will be able to fund these obligations through cash generated from operations and from our existing balances of cash, cash equivalent and marketable securities.

[0001596532-19-000027:mdna:107]
The following summarizes our contractual obligations and commitments as of December 31, 2018 (in thousands):

[0001596532-19-000027:mdna:108]
|  |  | Payments Due by Period |
|  |  | Total |  | Less than1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than5 Years |
| Financing lease obligation (1) |  | $ | 31,649 |  |  | $ | 6,321 |  |  | $ | 13,192 |  |  | $ | 12,136 |  |  | $ | — |  |
| Operating lease obligations |  | 103,351 |  |  | 12,789 |  |  | 28,077 |  |  | 26,616 |  |  | 35,869 |  |
| Purchase commitments with contract manufacturers and suppliers |  | 345,968 |  |  | 345,968 |  |  | — |  |  | — |  |  | — |  |
| Other non-cancellable purchase obligations |  | 43,254 |  |  | 43,254 |  |  | — |  |  | — |  |  |  |
| Total |  | $ | 524,222 |  |  | $ | 408,332 |  |  | $ | 41,269 |  |  | $ | 38,752 |  |  | $ | 35,869 |  |
| ___________________ |  |  |  |  |  |  |  |  |
| (1) Includes interest and land lease. |

[0001596532-19-000027:mdna:109]
The contractual obligation table above excludes tax liabilities of $40.3 million related to uncertain tax positions and transition tax due under the Tax Act because we are unable to make a reasonably reliable estimate of the timing of settlement, if any, of these future payments.

[0001596532-19-000027:mdna:110]
Critical Accounting Policies and Estimates

[0001596532-19-000027:mdna:111]
We have prepared our consolidated financial statements in accordance with GAAP and include our accounts and the accounts of our wholly owned subsidiaries. The preparation of these consolidated financial statements requires our management to make estimates, assumptions and judgments that affect the reported amounts of assets and liabilities at the date of the financial statements, disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenue and expenses during the applicable periods. We base our estimates, assumptions and judgments on historical experience and on various other factors that we believe to be reasonable under the circumstances. Different assumptions and judgments would change the estimates used in the preparation of our consolidated financial statements, which, in turn, could change the results from those reported. We evaluate our estimates, assumptions and judgments on an ongoing basis. Actual results may differ from these estimates. To the extent that there are material differences between these estimates and our actual results, our future financial statements will be affected. The critical accounting estimates, assumptions and judgments that we believe have the most significant impact on our consolidated financial statements are the following:

[0001596532-19-000027:mdna:112]
Revenue Recognition

[0001596532-19-000027:mdna:113]
Prior to 2018, our revenue recognition policy was based on ASC 605 - Revenue Recognition (“ASC 605”), and is described in the section entitled Critical Accounting Policies under Item 7 of our Annual Report on Form 10-K for the year ended December 31, 2017, filed with the SEC on February 20, 2018.

[0001596532-19-000027:mdna:114]
Effective January 1, 2018, we adopted the new revenue recognition guidance under ASC 606 as discussed in the section titled Recently Adopted Accounting Pronouncements in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K. The following is our new revenue recognition policy effective January 1, 2018.

[0001596532-19-000027:mdna:115]
We generate revenue from sales of our products, which incorporate our EOS software and accessories such as cables and optics, to direct customers and channel partners together with PCS. We typically sell products and PCS in a single contract. We recognize revenue upon transfer of control of promised products or services to customers in an amount that reflects the consideration we expect to be entitled to receive in exchange for those products or services. We apply the following five-step revenue recognition model:

[0001596532-19-000027:mdna:116]
| • | Identification of the contract, or contracts, with a customer |

[0001596532-19-000027:mdna:117]
| • | Identification of the performance obligations in the contract |

[0001596532-19-000027:mdna:118]
| • | Determination of the transaction price |

[0001596532-19-000027:mdna:119]
| • | Allocation of the transaction price to the performance obligations in the contract |

[0001596532-19-000027:mdna:120]
| • | Recognition of revenue when (or as) we satisfy the performance obligation |

[0001596532-19-000027:mdna:121]
Post-Contract Customer Support

[0001596532-19-000027:mdna:122]
PCS, which includes technical support, hardware repair and replacement parts beyond standard warranty, bug fixes, patches and unspecified upgrades on a when-and-if-available basis, is offered under renewable, fee-based contracts.  We initially defer PCS revenue and recognize it ratably over the life of the PCS contract as there is no discernable pattern of delivery related to these promises.  We do not provide unspecified upgrades on a set schedule and addresses customer requests for technical support if and when they arise, with the related expenses recognized as incurred. PCS contracts generally have a term of one to three years. We include billed but unearned PCS revenue in deferred revenue.

[0001596532-19-000027:mdna:123]
Contracts with Multiple Performance Obligations

[0001596532-19-000027:mdna:124]
Most of our contracts with customers, other than renewals of PCS, contain multiple performance obligations with a combination of products and PCS. Products and PCS generally qualify as distinct performance obligations. Our hardware includes EOS software, which together deliver the essential functionality of our products. For contracts which contain multiple performance obligations, we allocate revenue to each distinct performance obligation based on the standalone selling price (“SSP”). Judgment is required to determine the SSP for each distinct performance obligation.  We use a range of amounts to estimate SSP for products and PCS sold together in a contract to determine whether there is a discount to be allocated based on the relative SSP of the various products and PCS.

[0001596532-19-000027:mdna:125]
If we do not have an observable SSP, such as when we do not sell a product or service separately, then SSP is estimated using judgment and considering all reasonably available information such as market conditions and information about the size and/or purchase volume of the customer. We generally use a range of amounts to estimate SSP for individual products and services based on multiple factors including, but not limited to the sales channel (reseller, distributor or end customer), the geographies in which our products and services are sold, and the size of the end customer.

[0001596532-19-000027:mdna:126]
We limit the amount of revenue recognition for contracts containing forms of variable consideration, such as future performance obligations, customer-specific returns, and acceptance or refund obligations. We include some or all of an estimate of the related at risk consideration in the transaction price only to the extent that it is probable that a significant reversal in the amount of cumulative revenue recorded under each contract will not occur when the uncertainties surrounding the variable consideration are resolved.

[0001596532-19-000027:mdna:127]
Most of our contracts with customers have payment terms of 30 days with some large high volume customers having terms of up to 60 days. We have determined our contracts generally do not include a significant financing component because the Company and the customer have specific business reasons other than financing for entering into such contracts. Specifically, both we and our customers seek to ensure the customer has a simplified way of purchasing Arista products and services.

[0001596532-19-000027:mdna:128]
We account for multiple contracts with a single partner as one arrangement if the contractual terms and/or substance of those agreements indicate that they may be so closely related that they are, in effect, parts of a single contract.

[0001596532-19-000027:mdna:129]
We may occasionally accept returns to address customer satisfaction issues even though there is generally no contractual provision for such returns. We estimate returns for sales to customers based on historical returns rates applied against current-period shipments. Specific customer returns and allowances are considered when determining our sales return reserve estimate.

[0001596532-19-000027:mdna:130]
Our policy applies to the accounting for individual contracts. However, we have elected a practical expedient to apply the guidance to a portfolio of contracts or performance obligations with similar characteristics so long as such application would not differ materially from applying the guidance to the individual contracts (or performance obligations) within that portfolio. Consequently, we have chosen to apply the portfolio approach when possible, which we do not believe will happen frequently. Additionally, we will evaluate a portfolio of data, when possible, in various situations, including accounting for commissions, rights of return and transactions with variable consideration.

[0001596532-19-000027:mdna:131]
We report revenue net of sales taxes. We include shipping charges billed to customers in revenue and the related shipping costs are included in cost of product revenue.

[0001596532-19-000027:mdna:132]
Inventory Valuation and Contract Manufacturer/Supplier Liabilities

[0001596532-19-000027:mdna:133]
Inventories primarily consist of finished goods and strategic components, primarily integrated circuits. Inventories are stated at the lower of cost (computed using the first-in, first-out method) and net realizable value. Manufacturing overhead costs and inbound shipping costs are included in the cost of inventory.  We record a provision when inventory is determined to be in excess of anticipated demand, or obsolete, to adjust inventory to its estimated realizable value.

[0001596532-19-000027:mdna:134]
Our contract manufacturers procure components and assemble products on our behalf based on our forecasts. We record a liability and a corresponding charge for non-cancellable, non-returnable purchase commitments with our contract manufacturers or suppliers for quantities in excess of our demand forecasts or that are considered obsolete due to manufacturing and engineering change orders resulting from design changes.

[0001596532-19-000027:mdna:135]
We use significant judgment in establishing our forecasts of future demand and obsolete material exposures. These estimates depend on our assessment of current and expected orders from our customers, product development plans and current sales levels. If actual market conditions are less favorable than those projected by management, which may be caused by factors within and outside of our control, we may be required to increase our inventory write-downs and liabilities to our contract manufacturers and suppliers, which could have an adverse impact on our gross margins and profitability. We regularly evaluate our exposure for inventory write-downs and adequacy of our contract manufacturer liabilities.

[0001596532-19-000027:mdna:136]
Income Taxes

[0001596532-19-000027:mdna:137]
Income tax expense is an estimate of current income taxes payable in the current fiscal year based on reported income before income taxes. Deferred income taxes reflect the effect of temporary differences and carryforwards that we recognize for financial reporting and income tax purposes.

[0001596532-19-000027:mdna:138]
We account for income taxes under the liability approach for deferred income taxes, which requires recognition of deferred income tax assets and liabilities for the expected future tax consequences of events that have been recognized in our consolidated financial statements, but have not been reflected in our taxable income. Estimates and judgments occur in the calculation of certain tax liabilities and in the determination of the recoverability of certain deferred income tax assets, which arise from temporary differences and carryforwards. Deferred income tax assets and liabilities are measured using the currently enacted tax rates that apply to taxable income in effect for the years in which those tax assets are expected to be realized or settled. We regularly assess the likelihood that our deferred income tax assets will be realized based on the positive and negative evidence available. We record a valuation allowance to reduce the deferred tax assets to the amount that we are more likely than not to realize.

[0001596532-19-000027:mdna:139]
We believe that we have adequately reserved for our uncertain tax positions, although we can provide no assurance that the final tax outcome of these matters will not be materially different. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will affect the provision for income taxes in the period in which such determination is made and could have a material impact on our financial condition and results of operations. The provision for income taxes includes the effects of any reserves that we believe are appropriate, as well as the related net interest and penalties.

[0001596532-19-000027:mdna:140]
We regularly review our tax positions and benefits to be realized. We recognize tax liabilities based upon our estimate of whether, and to the extent to which, additional taxes will be due when such estimates are more likely than not to be sustained. An uncertain income tax position will not be recognized if it has less than a 50% likelihood of being sustained. We recognize interest and penalties related to income tax matters as income tax expense.

[0001596532-19-000027:mdna:141]
Loss Contingencies

[0001596532-19-000027:mdna:142]
In the ordinary course of business, we are a party to claims and legal proceedings including matters relating to commercial, employee relations, business practices and intellectual property. In assessing loss contingencies, we use significant judgment and assumptions to estimate the likelihood of loss, impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss. We record a provision for contingent losses when it is both probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated. We will record a charge equal to the minimum estimated liability for litigation costs or a loss contingency only when both of the following conditions are met: (i) information available prior to issuance of our consolidated financial statements indicates that it is probable that a liability had been incurred at the date of the financial statements and (ii) the range of loss can be reasonably estimated. We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.

[0001596532-19-000027:mdna:143]
Recent Accounting Pronouncements

[0001596532-19-000027:mdna:144]
Refer to “Recent Accounting Pronouncements” in Note 1. Organization and Summary of Significant Accounting Policies of the Notes to Consolidated Financial Statements included in Part II, Item 8, of this Annual Report on Form 10-K.
