# ANET 8-K — 0001596532-19-000023 filed 2019-02-14

## item codes, every 8-K on or before 2019-02-15

- 2019-02-14 0001596532-19-000023 — 2.02, 5.02, 8.01, 9.01
- 2018-11-01 0001596532-18-000230 — 2.02, 9.01
- 2018-08-06 0001596532-18-000171 — 1.01, 2.02, 2.03
- 2018-08-02 0001596532-18-000166 — 2.02, 9.01
- 2018-05-30 0001596532-18-000142 — 5.07
- 2018-05-03 0001596532-18-000101 — 2.02, 9.01
- 2018-03-28 0001596532-18-000078 — 8.01
- 2018-02-15 0001596532-18-000012 — 2.02, 9.01
- 2017-11-02 0001596532-17-000249 — 2.02, 9.01
- 2017-08-07 0001596532-17-000203 — 8.01
- 2017-08-03 0001596532-17-000199 — 2.02, 9.01
- 2017-07-21 0001596532-17-000191 — 8.01
- 2017-07-07 0001596532-17-000184 — 5.02
- 2017-07-05 0001596532-17-000180 — 8.01
- 2017-06-01 0001596532-17-000149 — 5.07
- 2017-05-04 0001596532-17-000085 — 2.02, 9.01
- 2017-04-11 0001596532-17-000072 — 8.01
- 2017-02-16 0001596532-17-000017 — 2.02, 9.01
- 2017-01-06 0001596532-17-000006 — 5.02
- 2016-11-21 0001193125-16-772719 — 8.01
- 2016-11-03 0001596532-16-000329 — 2.02, 9.01
- 2016-08-04 0001596532-16-000289 — 2.02, 9.01
- 2016-06-24 0001596532-16-000281 — 7.01, 9.01
- 2016-06-03 0001596532-16-000265 — 5.07
- 2016-05-05 0001596532-16-000253 — 2.02, 9.01
- 2016-02-18 0001596532-16-000240 — 2.02, 9.01
- 2015-11-05 0001596532-15-000172 — 2.02, 9.01
- 2015-08-06 0001596532-15-000110 — 2.02, 9.01
- 2015-06-04 0001596532-15-000034 — 5.07
- 2015-05-14 0001596532-15-000008 — 2.02, 4.02, 5.02, 9.01
- 2015-04-01 0001193125-15-116148 — 5.02, 9.01
- 2015-02-19 0001596532-15-000002 — 2.02, 9.01
- 2014-11-06 0001596532-14-000003 — 2.02, 8.01, 9.01
- 2014-08-07 0001350278-14-000008 — 2.02, 8.01, 9.01
- 2014-07-31 0001350278-14-000005 — 1.01

## late-filing notifications on or before 2019-02-15

- none on or before 2019-02-15

## item 2.02 — earnings release, exhibit 99.1

[0001596532-19-000023:8k_2_02:1]
EX-99.1
2
ex991earningsreleaseq418.htm
EXHIBIT 99.1

[0001596532-19-000023:8k_2_02:2]
Exhibit

[0001596532-19-000023:8k_2_02:3]
Exhibit 99.1

[0001596532-19-000023:8k_2_02:4]
Arista Networks, Inc. Reports Fourth Quarter and Full Year 2018 Financial Results

[0001596532-19-000023:8k_2_02:5]
Places in Cloud Networking Across Verticals Yields Record Results

[0001596532-19-000023:8k_2_02:6]
SANTA CLARA, Calif.-- February 14, 2019 -- Arista Networks, Inc. (NYSE: ANET), an industry leader in software-driven cloud networking solutions for large datacenter and campus environments, today announced financial results for its fourth quarter and year ended December 31, 2018 with record revenue and earnings.

[0001596532-19-000023:8k_2_02:7]
Fourth Quarter Financial Highlights

[0001596532-19-000023:8k_2_02:8]
| • | Revenue of $595.7 million, an increase of 5.8% compared to the third quarter of 2018, and an increase of 27.3% from the fourth quarter of 2017. |

[0001596532-19-000023:8k_2_02:9]
| • | GAAP gross margin of 62.9%, compared to GAAP gross margin of 64.2% in the third quarter of 2018 and 65.7% in the fourth quarter of 2017. |

[0001596532-19-000023:8k_2_02:10]
| • | Non-GAAP gross margin of 64.1%, compared to non-GAAP gross margin of 64.6% in the third quarter of 2018 and 65.9% in the fourth quarter of 2017. |

[0001596532-19-000023:8k_2_02:11]
| • | GAAP net income of $170.3 million, or $2.10 per diluted share, compared to GAAP net income of $103.8 million, or $1.29 per diluted share, in the fourth quarter of 2017. |

[0001596532-19-000023:8k_2_02:12]
| • | Non-GAAP net income of $182.2 million, or $2.25 per diluted share, compared to non-GAAP net income of $137.3 million, or $1.71 per diluted share, in the fourth quarter of 2017. |

[0001596532-19-000023:8k_2_02:13]
Full Year Financial Highlights

[0001596532-19-000023:8k_2_02:14]
| • | Revenue of $2.15 billion, an increase of 30.7% compared to fiscal year 2017. |

[0001596532-19-000023:8k_2_02:15]
| • | GAAP gross margin of 63.8%, compared to GAAP gross margin of 64.5% in fiscal year 2017. |

[0001596532-19-000023:8k_2_02:16]
| • | Non-GAAP gross margin of 64.4%, compared to non-GAAP gross margin of 64.8% in fiscal year 2017. |

[0001596532-19-000023:8k_2_02:17]
| • | GAAP net income of $328.1 million, or $4.06 per diluted share, compared to GAAP net income of $423.2 million, or $5.35 per diluted share, in fiscal year 2017. |

[0001596532-19-000023:8k_2_02:18]
| • | Non-GAAP net income of $643.3 million or $7.96 per diluted share, compared to non-GAAP net income of $442.8 million, or $5.61 per diluted share, in fiscal year 2017. |

[0001596532-19-000023:8k_2_02:19]
“We are pleased with our solid 2018 financial performance and continued momentum across cloud titan and enterprise verticals. Arista is earning a strategic role with customers deploying transformative cloud networking.” stated Jayshree Ullal, Arista President and CEO.

[0001596532-19-000023:8k_2_02:20]
Commenting on the company's financial results, Ita Brennan, Arista’s CFO, said, “The business continued to execute well across all key financial metrics in 2018, with strong profitable revenue growth and healthy cash generation.”

[0001596532-19-000023:8k_2_02:21]
Fourth Quarter Company Highlights

[0001596532-19-000023:8k_2_02:22]
| • | Arista Introduces 400 Gigabit Platforms. New 400G fixed systems offer the choice of two optical module form factors - OSFP and QSFP-DD and deliver the performance that hyperscale cloud networks and datacenters need for the growth of applications such as AI (artificial intelligence), machine learning, and serverless computing. |

[0001596532-19-000023:8k_2_02:23]
| • | Arista Expands CloudVision to the Campus. Arista Networks announced the next phase in its campus architecture, changing the way enterprises rebuild campus networks in the future. Arista’s Cognitive |

[0001596532-19-000023:8k_2_02:24]
Campus unifies wired and wireless campus networking, applying modern software-driven cloud principles. Arista Cognitive WiFi™ eliminates legacy WiFi controller bottlenecks to reduce operational costs with higher reliability through a cloud-based, cognitive model.

[0001596532-19-000023:8k_2_02:25]
| • | Arista to Demonstrate Any Cloud Networking for Kubernetes at KubeCon NA 2018. Arista Networks unveiled a technology preview of Arista’s Any Cloud platform for Red Hat OpenShift Container Platform, and Tigera Secure Enterprise Edition, providing a consistent and more secure enterprise-class solution for Kubernetes-managed container workloads spanning host-based and physical network infrastructure. |

[0001596532-19-000023:8k_2_02:26]
2018 Company Highlights

[0001596532-19-000023:8k_2_02:27]
| • | Arista Introduces Cognitive Cloud Networking for the Campus encompassing a new network architecture designed to address transitional changes as the enterprise moves to an IoT ready campus. |

[0001596532-19-000023:8k_2_02:28]
| • | Arista Acquires Mojo Networks for Cloud Networking Expansion. Arista entered the wireless LAN market with a portfolio of WiFi edge products through acquisition of cognitive WiFi pioneer, Mojo Networks. |

[0001596532-19-000023:8k_2_02:29]
| • | Arista Acquires Metamako, a leader in low-latency, FPGA-enabled network solutions. This acquisition will play a key role in the delivery of next generation platforms for low-latency applications. |

[0001596532-19-000023:8k_2_02:30]
| • | Arista Announces New Multi-function Platform for Cloud Networking Based on the Barefoot Tofino™ series of P4-programmable Ethernet switch chips. |

[0001596532-19-000023:8k_2_02:31]
| • | The Forrester Wave(TM) recognized Arista Networks as a leader in the current offering and strategy categories. |

[0001596532-19-000023:8k_2_02:32]
| • | Arista Networks maintained its Leadership position in the Gartner July 2018 Magic Quadrant for Data Center Networking for the fourth consecutive year.* |

[0001596532-19-000023:8k_2_02:33]
Financial Outlook

[0001596532-19-000023:8k_2_02:34]
For the first quarter of 2019, we expect:

[0001596532-19-000023:8k_2_02:35]
| • | Revenue between $588 and $598 million; |

[0001596532-19-000023:8k_2_02:36]
| • | Non-GAAP gross margin between 63% to 65%, and |

[0001596532-19-000023:8k_2_02:37]
| • | Non-GAAP operating margin of approximately 35%. |

[0001596532-19-000023:8k_2_02:38]
Guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. A reconciliation of non-GAAP guidance measures to corresponding GAAP measures is not available on a forward-looking basis (see further explanation below).

[0001596532-19-000023:8k_2_02:39]
Prepared Materials and Conference Call Information

[0001596532-19-000023:8k_2_02:40]
Arista executives will discuss fourth quarter and full year 2018 financial results on a conference call at 1:30 p.m. Pacific time today. To listen to the call via telephone, dial (833) 287-7905 in the United States or (647) 689-4469 from outside the US. The Conference ID is 3657578.

[0001596532-19-000023:8k_2_02:41]
The financial results conference call will also be available via live webcast on our investor relations website at http://investors.arista.com/. Shortly after the conclusion of the conference call, a replay of the audio webcast will be available on Arista’s Investor Relations website.

[0001596532-19-000023:8k_2_02:42]
Forward-Looking Statements

[0001596532-19-000023:8k_2_02:43]
This press release contains “forward-looking statements” regarding our future performance, including statements in the section entitled “Financial Outlook,” such as estimates regarding revenue, non-GAAP gross margin and non-GAAP

[0001596532-19-000023:8k_2_02:44]
operating margin for the first quarter of fiscal 2019, and statements regarding the benefits from the introduction of new products. Forward-looking statements are subject to known and unknown risks, uncertainties, assumptions and other factors that could cause actual results, performance or achievements to differ materially from those anticipated in or implied by the forward-looking statements including risks associated with: Arista Networks’ limited operating history; Arista Networks’ rapid growth; Arista Networks’ customer concentration;  the evolution and growth of the cloud networking market and the adoption by end customers of Arista Networks’ cloud networking solutions; changes in our customer’s demand for our products and services; requests for more favorable terms and conditions from our large end customers; declines in the sales prices of our products and services; customer order patterns or customer mix; the timing of orders and manufacturing and customer lead times; increased competition in our products and service markets; dependence on the introduction and market acceptance of new product offerings and standards; the benefits and impact of acquisitions; rapid technological and market change; Arista Networks’ dispute with OptumSoft; and general market, political, economic and business conditions. Additional risks and uncertainties that could affect Arista Networks can be found in Arista’s most recent Quarterly Report on Form 10-Q filed with the SEC on November 5, 2018, and other filings that the company makes to the SEC from time to time. You can locate these reports through our website at http://investors.arista.com/ and on the SEC’s website at http://www.sec.gov/. All forward-looking statements in this press release are based on information available to the company as of the date hereof and Arista Networks disclaims any obligation to publicly update or revise any forward-looking statement to reflect events that occur or circumstances that exist after the date on which they were made.

[0001596532-19-000023:8k_2_02:45]
Non-GAAP Financial Measures

[0001596532-19-000023:8k_2_02:46]
The company reports certain non-GAAP financial measures that exclude stock-based compensation expense, legal fees and bond costs and recoveries associated with the OptumSoft and Cisco litigations, acquisition-related costs, including external professional fees and severance costs, amortization of acquisition-related intangible assets, loss/gain on investments in privately held companies, other non-recurring charges or benefits, and the income tax effect of these non-GAAP exclusions. In addition, non-GAAP financial measures exclude net tax benefits associated with stock-based awards, which include excess tax benefits, other discrete indirect effects of such awards, acquisition-related tax expense, and discrete tax items associated with the Tax Cuts and Jobs Act of 2017 (the “Tax Act”). The company uses these non-GAAP financial measures internally in analyzing its financial results and believes that these non-GAAP financial measures are useful to investors as an additional tool to evaluate ongoing operating results and trends. In addition, these measures are the primary indicators management uses as a basis for its planning and forecasting for future periods.

[0001596532-19-000023:8k_2_02:47]
Non-GAAP financial measures are not meant to be considered in isolation or as a substitute for comparable GAAP net income, net income per diluted share, gross margin, or operating margin. Non-GAAP financial measures are subject to limitations, and should be read only in conjunction with the company's consolidated financial statements prepared in accordance with GAAP. A description of these non-GAAP financial measures and a reconciliation of the company’s non-GAAP financial measures to their most directly comparable GAAP measures has been provided in the financial statement tables included in this press release, and investors are encouraged to review the reconciliation.

[0001596532-19-000023:8k_2_02:48]
The Company’s guidance for non-GAAP financial measures excludes stock-based compensation expense, amortization of acquisition-related intangible assets, and other non-recurring items. The Company does not provide guidance on GAAP gross margin or GAAP operating margin or the various reconciling items between GAAP gross margin and GAAP operating margin and non-GAAP gross margin and non-GAAP operating margin. Stock-based compensation expense is impacted by the Company’s future hiring and retention needs and the future fair market value of the Company’s common stock, all of which are difficult to predict and subject to constant change. The actual amount of stock-based compensation expense will have a significant impact on the Company’s GAAP gross margin and GAAP operating margin. Accordingly, a reconciliation of the non-GAAP financial measure guidance to the corresponding GAAP measure is not available without unreasonable effort.

[0001596532-19-000023:8k_2_02:49]
3

[0001596532-19-000023:8k_2_02:50]
About Arista Networks

[0001596532-19-000023:8k_2_02:51]
Arista Networks pioneered software-driven, cognitive cloud networking for large-scale datacenter and campus environments. Arista’s award-winning platforms redefine and deliver availability, agility, automation, analytics, and security. Arista has shipped more than twenty million cloud networking ports worldwide with CloudVision and EOS, an advanced network operating system. Committed to open standards across private, public and hybrid cloud solutions, Arista products are supported worldwide directly and through partners.

[0001596532-19-000023:8k_2_02:52]
ARISTA, EOS, CloudVision, Cognitive WiFi and AlgoMatch are among the registered and unregistered trademarks of Arista Networks, Inc. in jurisdictions around the world. Other company names or product names may be trademarks of their respective owners.

[0001596532-19-000023:8k_2_02:53]
*Gartner does not endorse any vendor, product or service depicted in its research publications, and does not advise technology users to select only those vendors with the highest ratings or other designation. Gartner research publications consist of the opinions of Gartner’s research organization and should not be construed as statements of fact. Gartner disclaims all warranties, express or implied, with respect to this research, including any warranties of merchantability or fitness for a particular purpose.

[0001596532-19-000023:8k_2_02:54]
Additional information and resources can be found at: http://www.arista.com/

[0001596532-19-000023:8k_2_02:55]
| Investor Contacts |
| Charles YagerProduct and Investor Advocacy(408) 547-5892cyager@arista.com |  | Chuck ElliottBusiness and Investor Development(408) 547-5549chuck@arista.com |

[0001596532-19-000023:8k_2_02:56]
ARISTA NETWORKS, INC.

[0001596532-19-000023:8k_2_02:57]
Condensed Consolidated Statements of Operations

[0001596532-19-000023:8k_2_02:58]
(Unaudited in thousands, except per share amounts)

[0001596532-19-000023:8k_2_02:59]
|  |  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 503,235 |  |  | $ | 407,195 |  |  | $ | 1,841,100 |  |  | $ | 1,432,810 |  |
| Service |  | 92,491 |  |  | 60,672 |  |  | 310,269 |  |  | 213,376 |  |
| Total revenue |  | 595,726 |  |  | 467,867 |  |  | 2,151,369 |  |  | 1,646,186 |  |
| Cost of revenue: |  |  |  |  |  |  |  |  |
| Product |  | 204,507 |  |  | 147,919 |  |  | 720,584 |  |  | 538,035 |  |
| Service |  | 16,227 |  |  | 12,783 |  |  | 57,408 |  |  | 46,382 |  |
| Total cost of revenue |  | 220,734 |  |  | 160,702 |  |  | 777,992 |  |  | 584,417 |  |
| Total gross profit |  | 374,992 |  |  | 307,165 |  |  | 1,373,377 |  |  | 1,061,769 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 118,439 |  |  | 107,180 |  |  | 442,468 |  |  | 349,594 |  |
| Sales and marketing |  | 50,911 |  |  | 38,808 |  |  | 187,142 |  |  | 155,105 |  |
| General and administrative |  | 12,000 |  |  | 21,789 |  |  | 65,420 |  |  | 86,798 |  |
| Legal settlement |  | — |  |  | — |  |  | 405,000 |  |  | — |  |
| Total operating expenses |  | 181,350 |  |  | 167,777 |  |  | 1,100,030 |  |  | 591,497 |  |
| Income from operations |  | 193,642 |  |  | 139,388 |  |  | 273,347 |  |  | 470,272 |  |
| Other income (expense), net: |  |  |  |  |  |  |  |  |
| Interest expense |  | (661 | ) |  | (741 | ) |  | (2,701 | ) |  | (2,780 | ) |
| Other income (expense), net |  | 5,509 |  |  | 2,988 |  |  | 18,155 |  |  | 7,268 |  |
| Total other income (expense), net |  | 4,848 |  |  | 2,247 |  |  | 15,454 |  |  | 4,488 |  |
| Income before income taxes |  | 198,490 |  |  | 141,635 |  |  | 288,801 |  |  | 474,760 |  |
| Provision for (benefit from) income taxes |  | 28,168 |  |  | 37,802 |  |  | (39,314 | ) |  | 51,559 |  |
| Net income |  | $ | 170,322 |  |  | $ | 103,833 |  |  | $ | 328,115 |  |  | $ | 423,201 |  |
| Net income attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 170,211 |  |  | $ | 103,752 |  |  | $ | 327,926 |  |  | $ | 422,400 |  |
| Diluted |  | $ | 170,218 |  |  | $ | 103,759 |  |  | $ | 327,941 |  |  | $ | 422,468 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.26 |  |  | $ | 1.42 |  |  | $ | 4.39 |  |  | $ | 5.85 |  |
| Diluted |  | $ | 2.10 |  |  | $ | 1.29 |  |  | $ | 4.06 |  |  | $ | 5.35 |  |
| Weighted-average shares used in computing net income per share attributable to common stockholders: |  |  |  |  |  |  |  |  |
| Basic |  | 75,473 |  |  | 73,310 |  |  | 74,750 |  |  | 72,258 |  |
| Diluted |  | 80,928 |  |  | 80,243 |  |  | 80,844 |  |  | 78,977 |  |

[0001596532-19-000023:8k_2_02:60]
5

[0001596532-19-000023:8k_2_02:61]
ARISTA NETWORKS, INC.

[0001596532-19-000023:8k_2_02:62]
Reconciliation of Selected GAAP to Non-GAAP Financial Measures

[0001596532-19-000023:8k_2_02:63]
(Unaudited, in thousands, except percentages and per share amounts)

[0001596532-19-000023:8k_2_02:64]
|  |  | Three Months EndedDecember 31, |  | Twelve Months EndedDecember 31, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| GAAP gross profit |  | $ | 374,992 |  |  | $ | 307,165 |  |  | $ | 1,373,377 |  |  | $ | 1,061,769 |  |
| GAAP gross margin |  | 62.9 | % |  | 65.7 | % |  | 63.8 | % |  | 64.5 | % |
| Stock-based compensation expense |  | 1,381 |  |  | 1,129 |  |  | 5,087 |  |  | 4,353 |  |
| Intangible asset amortization |  | 2,626 |  |  | — |  |  | 3,824 |  |  | — |  |
| Acquisition-related costs (1) |  | 3,138 |  |  | — |  |  | 3,138 |  |  | — |  |
| Non-GAAP gross profit |  | $ | 382,137 |  |  | $ | 308,294 |  |  | $ | 1,385,426 |  |  | $ | 1,066,122 |  |
| Non-GAAP gross margin |  | 64.1 | % |  | 65.9 | % |  | 64.4 | % |  | 64.8 | % |
| GAAP income from operations |  | $ | 193,642 |  |  | $ | 139,388 |  |  | $ | 273,347 |  |  | $ | 470,272 |  |
| Stock-based compensation expense |  | 24,619 |  |  | 20,436 |  |  | 91,202 |  |  | 75,427 |  |
| Litigation expense (benefit) (2) |  | (3,988 | ) |  | 9,072 |  |  | 6,566 |  |  | 40,352 |  |
| Legal settlement (3) |  | — |  |  | — |  |  | 405,000 |  |  | — |  |
| Intangible asset amortization |  | 3,500 |  |  | — |  |  | 5,110 |  |  | — |  |
| Acquisition-related costs |  | 4,313 |  |  | — |  |  | 7,745 |  |  | — |  |
| Non-GAAP income from operations |  | $ | 222,086 |  |  | $ | 168,896 |  |  | $ | 788,970 |  |  | $ | 586,051 |  |
| Non-GAAP operating margin |  | 37.3 | % |  | 36.1 | % |  | 36.7 | % |  | 35.6 | % |
| GAAP net income |  | $ | 170,322 |  |  | $ | 103,833 |  |  | $ | 328,115 |  |  | $ | 423,201 |  |
| Stock-based compensation expense |  | 24,619 |  |  | 20,436 |  |  | 91,202 |  |  | 75,427 |  |
| Litigation expense (benefit) (2) |  | (3,988 | ) |  | 9,072 |  |  | 6,566 |  |  | 40,352 |  |
| Legal settlement (3) |  | — |  |  | — |  |  | 405,000 |  |  | — |  |
| Intangible asset amortization |  | 3,500 |  |  | — |  |  | 5,110 |  |  | — |  |
| Acquisition-related costs |  | 4,313 |  |  | — |  |  | 7,745 |  |  | — |  |
| Loss on investments in privately-held companies, net |  | 4,700 |  |  | — |  |  | 13,800 |  |  | — |  |
| Acquisition-related tax expense |  | — |  |  | — |  |  | 5,853 |  |  | — |  |
| Impact of the U.S. Tax Cuts and Jobs Act (4) |  | (12,632 | ) |  | 51,812 |  |  | (12,632 | ) |  | 51,812 |  |
| Tax benefit on share-based awards |  | (8,227 | ) |  | (38,287 | ) |  | (92,675 | ) |  | (111,542 | ) |
| Income tax effect on non-GAAP exclusions |  | (429 | ) |  | (9,536 | ) |  | (114,769 | ) |  | (36,421 | ) |
| Non-GAAP net income |  | $ | 182,178 |  |  | $ | 137,330 |  |  | $ | 643,315 |  |  | $ | 442,829 |  |
| GAAP diluted net income per share attributable to common stockholders |  | $ | 2.10 |  |  | $ | 1.29 |  |  | $ | 4.06 |  |  | $ | 5.35 |  |
| Non-GAAP adjustments to net income |  | 0.15 |  |  | 0.42 |  |  | 3.90 |  |  | 0.26 |  |
| Non-GAAP diluted net income per share |  | $ | 2.25 |  |  | $ | 1.71 |  |  | $ | 7.96 |  |  | $ | 5.61 |  |
| Weighted-average shares used in computing diluted net income per share attributable to common stockholders |  | 80,928 |  |  | 80,243 |  |  | 80,844 |  |  | 78,977 |  |
| Summary of Stock-Based Compensation Expense: |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,381 |  |  | $ | 1,129 |  |  | $ | 5,087 |  |  | $ | 4,353 |  |
| Research and development |  | 13,505 |  |  | 11,207 |  |  | 48,205 |  |  | 42,184 |  |
| Sales and marketing |  | 6,224 |  |  | 5,302 |  |  | 24,995 |  |  | 17,953 |  |
| General and administrative |  | 3,509 |  |  | 2,798 |  |  | 12,915 |  |  | 10,937 |  |
| Total |  | $ | 24,619 |  |  | $ | 20,436 |  |  | $ | 91,202 |  |  | $ | 75,427 |  |
| ________________________________ |  |  |  |  |  |  |  |  |
| (1) Represents a charge related to our business acquisitions in 2018 resulting from the required revaluation of inventory to its estimated fair value.(2) Includes legal fees and bond costs and recoveries associated with the OptumSoft and Cisco litigations.(3) Represents one-time charges associated with the settlement of our lawsuit with Cisco on August 6, 2018.(4) Represents provisional tax estimates recorded in 2017 resulting from the enactment of the Tax Act, and subsequent changes to these amounts in 2018 as we completed our accounting for these tax effects in the fourth quarter of 2018. |

[0001596532-19-000023:8k_2_02:65]
ARISTA NETWORKS, INC.

[0001596532-19-000023:8k_2_02:66]
Condensed Consolidated Balance Sheets

[0001596532-19-000023:8k_2_02:67]
(Unaudited, in thousands)

[0001596532-19-000023:8k_2_02:68]
|  |  | December 31, 2018 |  | December 31, 2017 |
| ASSETS |  |  |  |  |
| CURRENT ASSETS: |  |  |  |  |
| Cash and cash equivalents |  | $ | 649,950 |  |  | $ | 859,192 |  |
| Marketable securities |  | 1,306,197 |  |  | 676,363 |  |
| Accounts receivable |  | 331,777 |  |  | 247,346 |  |
| Inventories |  | 264,557 |  |  | 306,198 |  |
| Prepaid expenses and other current assets |  | 162,321 |  |  | 177,330 |  |
| Total current assets |  | 2,714,802 |  |  | 2,266,429 |  |
| Property and equipment, net |  | 75,355 |  |  | 74,279 |  |
| Acquisition-related intangible assets, net |  | 58,610 |  |  | — |  |
| Goodwill |  | 53,684 |  |  | — |  |
| Investments |  | 30,336 |  |  | 36,136 |  |
| Deferred tax assets |  | 126,492 |  |  | 65,125 |  |
| Other assets |  | 22,704 |  |  | 18,891 |  |
| TOTAL ASSETS |  | $ | 3,081,983 |  |  | $ | 2,460,860 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |
| CURRENT LIABILITIES: |  |  |  |  |
| Accounts payable |  | $ | 93,757 |  |  | $ | 52,200 |  |
| Accrued liabilities |  | 123,254 |  |  | 133,827 |  |
| Deferred revenue |  | 358,586 |  |  | 327,706 |  |
| Other current liabilities |  | 30,907 |  |  | 16,172 |  |
| Total current liabilities |  | 606,504 |  |  | 529,905 |  |
| Income taxes payable |  | 36,167 |  |  | 34,067 |  |
| Lease financing obligations, non-current |  | 35,431 |  |  | 37,673 |  |
| Deferred revenue, non-current |  | 228,641 |  |  | 187,556 |  |
| Other long-term liabilities |  | 31,851 |  |  | 9,745 |  |
| TOTAL LIABILITIES |  | 938,594 |  |  | 798,946 |  |
| STOCKHOLDERS’ EQUITY: |  |  |  |  |
| Common stock |  | 8 |  |  | 7 |  |
| Additional paid-in capital |  | 956,572 |  |  | 804,731 |  |
| Retained earnings |  | 1,190,803 |  |  | 859,114 |  |
| Accumulated other comprehensive loss |  | (3,994 | ) |  | (1,938 | ) |
| TOTAL STOCKHOLDERS’ EQUITY |  | 2,143,389 |  |  | 1,661,914 |  |
| TOTAL LIABILITIES AND STOCKHOLDERS’ EQUITY |  | $ | 3,081,983 |  |  | $ | 2,460,860 |  |

[0001596532-19-000023:8k_2_02:69]
7

[0001596532-19-000023:8k_2_02:70]
ARISTA NETWORKS, INC.

[0001596532-19-000023:8k_2_02:71]
Condensed Consolidated Statements of Cash Flows

[0001596532-19-000023:8k_2_02:72]
(Unaudited, in thousands)

[0001596532-19-000023:8k_2_02:73]
|  |  | Twelve Months Ended December 31, |
|  |  | 2018 |  | 2017As Adjusted (1) |
| CASH FLOWS FROM OPERATING ACTIVITIES: |  |  |  |  |
| Net income |  | $ | 328,115 |  |  | $ | 423,201 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization and other |  | 27,671 |  |  | 20,640 |  |
| Stock-based compensation |  | 91,202 |  |  | 75,427 |  |
| Deferred income taxes |  | (57,896 | ) |  | 8,426 |  |
| Loss on investments in privately-held companies, net |  | 13,800 |  |  | — |  |
| Amortization (accretion) of investment premiums (discounts) |  | (3,360 | ) |  | 1,452 |  |
| Changes in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  | (77,916 | ) |  | 5,773 |  |
| Inventories |  | 51,054 |  |  | (69,708 | ) |
| Prepaid expenses and other current assets |  | 21,411 |  |  | (11,645 | ) |
| Other assets |  | (3,389 | ) |  | 907 |  |
| Accounts payable |  | 39,337 |  |  | (30,104 | ) |
| Accrued liabilities |  | (14,786 | ) |  | 43,535 |  |
| Deferred revenue |  | 70,533 |  |  | 142,327 |  |
| Income taxes payable |  | (112 | ) |  | 19,921 |  |
| Other liabilities |  | 17,455 |  |  | 1,475 |  |
| Net cash provided by operating activities |  | 503,119 |  |  | 631,627 |  |
| CASH FLOWS FROM INVESTING ACTIVITIES: |  |  |  |  |
| Proceeds from maturities of marketable securities |  | 547,797 |  |  | 206,332 |  |
| Purchases of marketable securities |  | (1,174,259 | ) |  | (585,373 | ) |
| Business acquisitions, net of cash acquired |  | (96,821 | ) |  | — |  |
| Purchases of property and equipment |  | (23,830 | ) |  | (15,279 | ) |
| Proceeds from repayment of notes receivable |  | 2,000 |  |  | 3,000 |  |
| Investments in privately-held companies |  | (8,000 | ) |  | — |  |
| Other investing activities |  | (2,000 | ) |  | — |  |
| Net cash used in investing activities (1) |  | (755,113 | ) |  | (391,320 | ) |
| CASH FLOWS FROM FINANCING ACTIVITIES: |  |  |  |  |
| Principal payments of lease financing obligations |  | (1,929 | ) |  | (1,617 | ) |
| Proceeds from issuance of common stock under equity plans |  | 53,658 |  |  | 57,111 |  |
| Tax withholding paid on behalf of employees for net share settlement |  | (8,878 | ) |  | (4,025 | ) |
| Net cash provided by financing activities |  | 42,851 |  |  | 51,469 |  |
| Effect of exchange rate changes |  | (1,390 | ) |  | 753 |  |
| NET INCREASE (DECREASE) IN CASH, CASH EQUIVALENTS AND RESTRICTED CASH (1) |  | (210,533 | ) |  | 292,529 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —Beginning of period (1) |  | 864,697 |  |  | 572,168 |  |
| CASH, CASH EQUIVALENTS AND RESTRICTED CASH —End of period (1) |  | $ | 654,164 |  |  | $ | 864,697 |  |
| ____________________________________ |  |  |  |  |
| (1) The adoption of ASU 2016-18, Statement of Cash Flows (Topic 230): Restricted Cash ("ASU 2016-18"), in the first quarter of 2018 requires the Company to include restricted cash together with cash and cash equivalents when reconciling the beginning-of-period and end-of-period amounts presented on the statements of cash flows. As a result, for 2017, the beginning-of-period and end-of-period amounts increased by $4.2 million and $5.5 million, respectively, and net cash used in investing activities decreased by $1.3 million. |

[0001596532-19-000023:8k_2_02:74]
8

## item 5.02 — body, verbatim

[0001596532-19-000023:8k_body:1]
ITEM 5.02

[0001596532-19-000023:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers

[0001596532-19-000023:8k_body:3]
Appointment of Chief Operating Officer

[0001596532-19-000023:8k_body:4]
On February 14, 2019, the Company announced the promotion of Anshul Sadana to Senior Vice President and Chief Operating Officer of the Company. The promotion will become effective on March 4, 2019.   Mr. Sadana will assume the duties of the Company's chief operating officer until such time as his successor is appointed, or until his earlier resignation or removal.

[0001596532-19-000023:8k_body:5]
Anshul Sadana has served as the Company’s Chief Customer Officer since October 2016, as the Company’s Senior Vice President of Customer Engineering from January 2012 through September 2016 and in various other positions with the Company, including Vice President of Customer Engineering, from July 2007 to December 2011. From November 1999 to July 2007, Mr. Sadana was a senior engineering manager of the Gigabit Switching Business Unit at Cisco Systems, an information technology provider. Mr. Sadana holds a B.E. degree in Electronics from the University of Mumbai, an M.S. degree in Computer Science from the University of Illinois at Chicago and an executive M.B.A. degree from the Wharton School of Business.

[0001596532-19-000023:8k_body:6]
There are no family relationships between Mr. Sadana and any director or executive officer of the Company, and the Company has not entered into any transactions with Mr. Sadana that are reportable pursuant to Item 404(a) of Regulation S-K. Except as described above, there are no arrangements or understandings between Mr. Sadana and any other persons pursuant to which he was appointed Chief Operating Officer.
