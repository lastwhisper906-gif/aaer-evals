# JCI notes — 0000833444-25-000097


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000833444-25-000097:notes:1]
Portions of the definitive Proxy Statement to be delivered to shareholders in connection with the annual general meeting of shareholders to be held on March 4, 2026 are incorporated by reference into Part III.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000833444-25-000097:notes:2]
The Company faces a wide variety of cybersecurity threats ranging from uncoordinated individual attempts to gain unauthorized access to information technology ("IT") systems to sophisticated and targeted measures known as advanced persistent threats directed at the Company, its products, its customers, supply chain and/or its third-party service providers, including cloud providers. These threats and incidents originate from many sources globally.

[0000833444-25-000097:notes:3]
The Company’s cybersecurity policies, standards, and procedures apply to all users, creating awareness of threats and the importance of information security and cybersecurity across the Company’s workforce. These policies and standards are reviewed annually to reflect emerging threats and evolving industry practices, including elements of recognized standards such as ISO 27001 and the NIST Cybersecurity Framework for the overall enterprise and ISA/IEC 62443 for automation and control system products. The Company has implemented cybersecurity policies throughout its operations, including designing and incorporating cybersecurity into the development process for its products and services. The Company’s enterprise risk management (“ERM”) process considers cybersecurity threat risks alongside other significant risks as part of the Company’s overall risk assessment process.

[0000833444-25-000097:notes:4]
The Company leverages multiple channels to promote cybersecurity topics, deliver targeted initial and refresher training for all users, and conduct an annual mandatory global information security training campaign with certification, which is translated into 20 languages, and ongoing awareness campaigns. These elements are designed to maintain a risk aware culture.

[0000833444-25-000097:notes:5]
The Company maintains a 24 x 7 operations center that monitors the Company’s IT environment and coordinates the investigation and remediation of alerts. As cybersecurity events occur, the cybersecurity team focuses on responding to and containing the threat and minimizing impact. In the event of an incident, the cybersecurity team assesses, among other factors, supply chain and manufacturing disruption, data and personal information loss, business operations disruption, projected cost and potential for reputational harm, with participation from technical, legal and law enforcement support, as appropriate.

[0000833444-25-000097:notes:6]
The Company’s vulnerability management program conducts assessments with specified frequencies for specific asset types to validate system health against known threats. The Company leverages multiple tools, which are routinely updated with new threat signatures, to continually respond to evolving threats identified as part of its threat detection capability. The Company also maintains a cybersecurity insurance policy.

[0000833444-25-000097:notes:7]
The Company engages with third parties to perform security assessments of its technology environment, including penetration testing and maturity assessments, in addition to providing services to support threat analysis and incident detection and response. 
Cybersecurity considerations affect the selection and oversight of the Company’s third-party product and service providers. The Company performs due diligence on third parties that have access to its critical systems and data and whose products and services are integrated into the Company’s products. Contractual undertakings and oversight are put in place, based on the results of the risk assessment to manage and reduce the cybersecurity risk associated with such third-party providers. Such undertakings may include requirements to comply with administrative, technical and physical safeguards to provide notification of cyber incidents involving the Company’s systems or data and agreements to be subject to cybersecurity audits, which the Company conducts as appropriate.  The Company requires compliance with appropriate certifications (e.g., SOC 2, ISO 27001, etc.) or appropriate alternative requirements, depending on the offering, region of use, and other factors.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0000833444-25-000097:notes:8]
The Company’s Board of Directors (the "Board”) has oversight of the management of the most significant risks facing the Company, including cybersecurity. The Board receives information technology and cybersecurity updates from senior management, including the Chief Digital and Information Officer ("CDIO") and Chief Information Security Officer (“CISO”) several times per year. These updates cover the cybersecurity risks facing the Company’s enterprise information technology environment, as well as the Company’s digital products and services. Regular oversight of cybersecurity matters is further delegated by the Board to the Governance and Sustainability Committee. The Governance and Sustainability Committee provides a deeper level of oversight through quarterly engagements with senior management, including the Chief Digital and Information Officer and CISO, to review the Company’s cybersecurity program, including the highest risk areas and key mitigation strategies.


## cyd:CybersecurityRiskRoleOfManagementTextBlock

[0000833444-25-000097:notes:9]
The Company maintains a Cybersecurity Steering Committee ("CSC") designed to ensure effective governance of risks associated with the Company’s use of information and technology assets and demonstrate effective governance of cybersecurity risk. The CSC is chaired by the CISO, and includes the Company’s Chief Financial Officer, General Counsel, CDIO, and other senior representatives from the Company’s business segments and functions. The CSC meets quarterly to monitor the current risk landscape and active risk reduction efforts. Through this review and monitoring activity, the CSC oversees effective governance of IT Risk Management in the Enterprise IT Portfolio, drives accountability and transparency of control effectiveness, and facilitates risk remediation and mitigation in a coordinated and comprehensive manner.

[0000833444-25-000097:notes:10]
The CISO has been appointed by the Chief Digital and Information Officer and is responsible for cybersecurity risk management across the Company. The CISO leads a global enterprise security team responsible for enterprise-wide security strategy, architecture, engineering, and operations. The CSC has granted authority to the CISO to pause or stop business processes during the execution of cybersecurity incident response duties if they deem it necessary. The CSC maintains approval authority for the Company’s Enterprise Information Security Policy. 
The CISO has over 20 years of technology experience including cybersecurity, infrastructure, architecture, and data and analytics in highly regulated industries including healthcare and aviation and defense. The CISO has an undergraduate degree in Computer Information Systems.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000833444-25-000097:notes:11]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited  company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," "Johnson Controls" or "JCI plc").

[0000833444-25-000097:notes:12]
The Company's fiscal year ends on September 30. Unless otherwise stated, references to years in this report relate to fiscal years rather than calendar years.

[0000833444-25-000097:notes:13]
Nature of Operations

[0000833444-25-000097:notes:14]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, safe, healthy and sustainable buildings, serving a wide range of customers around the globe. The Company’s products and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-25-000097:notes:15]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space) and energy-management consulting. The Company partners with customers by leveraging its broad product portfolio and digital capabilities, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

[0000833444-25-000097:notes:16]
In July 2025, the Company sold its Residential and Light Commercial ("R&LC") HVAC business, including the North America Ducted business and the global Residential joint venture with Hitachi Global Life Solutions, Inc. ("Hitachi"), of which Johnson Controls owned 60% and Hitachi owned 40%. The R&LC HVAC business, which was previously reported in the Global Products segment prior to the Company's resegmentation, met the criteria to be classified as a discontinued operation and, as a result, its historical financial results are reflected in the consolidated financial statements as a discontinued operation. Unless otherwise noted, all activities and amounts reported in the following footnotes relate to the continuing operations of the Company and exclude activities and amounts related to the R&LC HVAC business. Refer to Note 2, "Acquisitions and Divestitures," of the notes to consolidated financial statements for more information.

[0000833444-25-000097:notes:17]
Principles of Consolidation

[0000833444-25-000097:notes:18]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries in conformity with U.S. GAAP. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.

[0000833444-25-000097:notes:19]
The Company consolidates variable interest entities ("VIE") when it has the power to direct the significant activities of the entity and the obligation to absorb losses or receive benefits from the entity that may be significant. The Company did not have any material consolidated or nonconsolidated VIE's for the presented reporting periods.

[0000833444-25-000097:notes:20]
Use of Estimates

[0000833444-25-000097:notes:21]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts. Actual results could differ from those estimates.

[0000833444-25-000097:notes:22]
Fair Value of Financial Instruments

[0000833444-25-000097:notes:23]
ASC 820, "Fair Value Measurement," defines fair value as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0000833444-25-000097:notes:24]
Level 1: Observable inputs such as quoted prices in active markets for identical assets or liabilities;

[0000833444-25-000097:notes:25]
Level 2: Quoted prices in active markets for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0000833444-25-000097:notes:26]
Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0000833444-25-000097:notes:27]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0000833444-25-000097:notes:28]
Acquisitions

[0000833444-25-000097:notes:29]
The purchase price of acquired businesses is allocated to the related identifiable assets and liabilities based on estimated fair values. The excess of the purchase price over the amount allocated to the assets and liabilities, if any, is recorded as goodwill. In addition, any contingent consideration is recorded at the estimated fair value as of the date of the acquisition and is recorded as part of the purchase price. This estimate is updated in future periods and any changes in the estimate, which are not considered an adjustment to the purchase price, are recorded in the consolidated statements of operations. Payments for contingent earn-out liabilities that are less than or equal to estimates on the acquisition date are reflected as financing cash outflows. Amounts paid in excess of the estimated contingent earn-out liabilities on the acquisition date are reflected as operating cash outflows.

[0000833444-25-000097:notes:30]
All available information is used to estimate fair values. External valuation specialists are typically engaged to assist in the fair value determination of identifiable intangible assets and any other significant assets or liabilities. The preliminary purchase price allocation is adjusted, as necessary, up to one year after the acquisition closing date as more information is obtained regarding assets acquired and liabilities assumed based on facts and circumstances that existed as of the acquisition date.

[0000833444-25-000097:notes:31]
The purchase price allocation methodology contains uncertainties because it requires the Company to make assumptions and to apply judgment to estimate the fair value of acquired assets and assumed liabilities. The fair value of assets and liabilities is estimated based upon the carrying value of the acquired assets and assumed liabilities and widely accepted valuation techniques, including discounted cash flows. Unanticipated events or circumstances may occur which could affect the accuracy of fair value estimates, including assumptions regarding industry economic factors and business strategies.

[0000833444-25-000097:notes:32]
Other estimates used in determining fair value include, but are not limited to, future cash flows or income related to intangibles, market rate assumptions and discount rates. Fair value estimates are based upon assumptions believed to be reasonable, but that are inherently uncertain, and therefore, may not be realized. Accordingly, there can be no assurance that the estimates, assumptions, and values reflected in the valuations will be realized, and actual results could differ materially.

[0000833444-25-000097:notes:33]
Assets and Liabilities Held for Sale

[0000833444-25-000097:notes:34]
Assets and liabilities (disposal groups) to be sold are classified as held for sale in the period in which all of the following criteria are met:

[0000833444-25-000097:notes:35]
•Management, having the authority to approve the action, commits to a plan to sell the disposal group;

[0000833444-25-000097:notes:36]
•The disposal group is available for immediate sale in its present condition subject only to terms that are usual and customary for sales of such disposal groups;

[0000833444-25-000097:notes:37]
•An active program to locate a buyer and other actions required to complete the plan to sell the disposal group have been initiated;

[0000833444-25-000097:notes:38]
•Sale of the disposal group is probable and transfer of the disposal group is expected to qualify for recognition as a completed sale within one year, except if events or circumstances beyond the Company's control extend the period of time required to sell the disposal group beyond one year;

[0000833444-25-000097:notes:39]
•The disposal group is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and

[0000833444-25-000097:notes:40]
•Actions required to complete the plan indicate that it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn.

[0000833444-25-000097:notes:41]
The Company initially measures a disposal group that is classified as held for sale at the lower of its carrying value or fair value less any costs to sell in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets." The carrying amount of any assets, including goodwill, that are part of the disposal group, but not in the scope of ASC 360-10, are tested for impairment under the relevant guidance prior to measuring the disposal group at fair value, less cost to sell.

[0000833444-25-000097:notes:42]
Any loss resulting from this measurement is recognized in the period in which the held for sale criteria are met. Gains on the sale of a disposal group are not recognized until the date of sale. The Company assesses the fair value of a disposal group, less any costs to sell, each reporting period it remains classified as held for sale and reports any subsequent changes as an adjustment to the carrying value of the disposal group, as long as the new carrying value does not exceed the carrying value of the disposal group at the time it was initially classified as held for sale.

[0000833444-25-000097:notes:43]
Upon determining that a disposal group meets the criteria to be classified as held for sale, the Company reports the assets and liabilities of the disposal group, if material, in the line items assets held for sale and liabilities held for sale in the consolidated statements of financial position.

[0000833444-25-000097:notes:44]
Cash and Cash Equivalents

[0000833444-25-000097:notes:45]
Cash equivalents include all highly liquid investments with an original maturity of three months or less when purchased.

[0000833444-25-000097:notes:46]
Restricted Cash

[0000833444-25-000097:notes:47]
Restricted cash relates to amounts restricted for payment of asbestos liabilities and certain litigation and environmental matters and is recorded within other current assets in the consolidated statements of financial position.

[0000833444-25-000097:notes:48]
Receivables

[0000833444-25-000097:notes:49]
Receivables consist of billed receivables which are currently due from customers and unbilled receivables where the Company has satisfied its performance obligations, but has not yet issued the invoice to the customer. Incentives are periodically offered to customers, including early payment discounts and extended payment terms of certain receivables. The Company extends credit to customers in the normal course of business and maintains an allowance for expected credit losses resulting from the inability or unwillingness of customers to make required payments. The allowance for expected credit losses is based on historical experience, existing economic conditions, reasonable and supportable forecasts, and any specific customer collection issues the Company has identified. The Company evaluates the reasonableness of the allowance for expected credit losses on a quarterly basis.

[0000833444-25-000097:notes:50]
The Company has previously entered into various factoring agreements to sell certain accounts receivable to third-party financial institutions. The Company collected the majority of the factored receivables on behalf of the financial institutions, but maintained no other continuing involvement with the factored receivables. Sales of accounts receivable were reflected as a reduction of accounts receivable in the consolidated statements of financial position and the proceeds were included in cash flows from operating activities in the consolidated statements of cash flows. The Company discontinued its receivables factoring program in March 2024.

[0000833444-25-000097:notes:51]
Inventories

[0000833444-25-000097:notes:52]
Inventories are stated at the lower of cost or net realizable value using the first-in, first-out ("FIFO") method. Finished goods and work-in-process inventories include material, labor and manufacturing overhead costs.

[0000833444-25-000097:notes:53]
Property, Plant and Equipment

[0000833444-25-000097:notes:54]
Property, plant and equipment are recorded at cost. Depreciation is provided over the estimated useful lives of the respective assets using the straight-line method for financial reporting purposes and accelerated methods for income tax purposes. Estimated useful lives generally range from 3 to 40 years for buildings and improvements, up to 15 years for subscriber systems, and from 3 to 15 years for machinery and equipment. Interest on borrowings is capitalized during the active

[0000833444-25-000097:notes:55]
construction period of major capital projects, added to the cost of the underlying assets and amortized over the useful lives of the assets.

[0000833444-25-000097:notes:56]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-25-000097:notes:57]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. Goodwill is reviewed for impairment during the fourth fiscal quarter (as of July 31) or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be one level below the Company's operating segments, using a qualitative assessment or a quantitative test. A qualitative assessment is performed when prior quantitative assessments have resulted in significant excess of fair value over the carrying value of a reporting unit, and consideration of qualitative factors allow the Company to conclude it is more likely than not that the fair value of the reporting unit remains greater than its carrying value. When performing a quantitative goodwill impairment test, the fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. To estimate the fair value, the Company uses a discounted cash flow model, the guideline company method under the market approach, or estimated sales price for reporting units held for sale. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared to the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value.

[0000833444-25-000097:notes:58]
Indefinite-lived intangible assets are also subject to at least annual impairment testing in the fourth fiscal quarter or as events occur or circumstances change that indicate the assets may be impaired. Indefinite-lived intangible assets primarily consist of trademarks and trade names and are tested for impairment using a relief-from-royalty method. The Company considers the implications of both external (e.g., market growth, competition and local economic conditions) and internal (e.g., product sales and expected product growth) factors and their potential impact on cash flows related to the intangible asset in both the near- and long-term. The Company considers the profitability of the business, among other factors, to determine the royalty rate for use in the impairment assessment.

[0000833444-25-000097:notes:59]
While the Company believes that the estimates and assumptions underlying the valuation methodologies are reasonable, different estimates and assumptions could result in different outcomes.

[0000833444-25-000097:notes:60]
Leases

[0000833444-25-000097:notes:61]
Lessee arrangements

[0000833444-25-000097:notes:62]
The Company leases certain administrative, production and other facilities, fleet vehicles, information technology equipment and other equipment under arrangements that are accounted for as operating leases. The Company determines whether an arrangement contains a lease at contract inception based on whether the arrangement involves the use of a physically distinct identified asset and whether the Company has the right to obtain substantially all of the economic benefits from the use of the asset throughout the period as well as the right to direct the use of the asset.

[0000833444-25-000097:notes:63]
Right-of-use assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent its obligation to make lease payments arising from the lease. Right-of-use assets and the corresponding lease liabilities are recognized at commencement date based on the present value of lease payments for all leases with terms longer than twelve months. The majority of the Company's leases do not provide an implicit interest rate. To determine the present value of lease payments, the Company uses its incremental borrowing rate based on information available on the lease commencement date or  the implicit rate if it is readily determinable. The Company determines its incremental borrowing rate based on a comparable market yield curve consistent with its credit rating, term of the lease and relative economic environment. The Company has elected to combine lease and nonlease components for its leases.

[0000833444-25-000097:notes:64]
Most leases contain options to renew or terminate the lease. Right-of-use assets and lease liabilities reflect only the options which the Company is reasonably certain to exercise.

[0000833444-25-000097:notes:65]
The Company has certain real estate leases that contain variable lease payments which are based on changes in the Consumer Price Index ("CPI"). Additionally, the Company's leases generally require it to pay for fuel, maintenance, repair, insurance and taxes. These payments are not included in the right-of-use asset or lease liability and are expensed as incurred.

[0000833444-25-000097:notes:66]
Lease expense is recognized on a straight-line basis over the lease term.

[0000833444-25-000097:notes:67]
Lessor arrangements

[0000833444-25-000097:notes:68]
The Company has monitoring services and maintenance agreements within its security business that include subscriber system assets for which the Company retains ownership. These agreements contain both lease and nonlease components. The Company has elected to combine lease and nonlease components for these arrangements where the timing and pattern of transfer of the lease and nonlease components are the same and the lease component would be classified as an operating lease if accounted for separately. The Company has concluded that in these arrangements the nonlease components are the predominant characteristic, and as a result, the combined component is accounted for under the revenue guidance.

[0000833444-25-000097:notes:69]
Impairment of Long-Lived Assets

[0000833444-25-000097:notes:70]
Long-lived assets, including right-of-use assets under operating leases, other tangible assets and intangible assets with definite lives, are reviewed for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of Software to be Sold, Leased, or Marketed."

[0000833444-25-000097:notes:71]
Assets and liabilities are grouped at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluates the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals.

[0000833444-25-000097:notes:72]
Intangible assets acquired in a business combination that are used in research and development activities are considered indefinite-lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they are not amortized but are tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired. If the carrying amount of an intangible asset exceeds its fair value, the Company recognizes an impairment loss in an amount equal to that excess.

[0000833444-25-000097:notes:73]
Unamortized capitalized costs of a computer software product are compared to the net realizable value of the product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset is written off.

[0000833444-25-000097:notes:74]
Revenue Recognition

[0000833444-25-000097:notes:75]
Revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services is recognized on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company does not adjust the promised amount of consideration for the effects of a significant financing component because at contract inception it expects to receive the payment within twelve months of transfer of goods or services.

[0000833444-25-000097:notes:76]
The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term.

[0000833444-25-000097:notes:77]
The Company also sells certain HVAC and refrigeration products and services in bundled arrangements with multiple performance obligations, such as equipment, commissioning, service labor and extended warranties. Approximately four to twenty-four months separate the timing of the first deliverable until the last piece of equipment is delivered. There may also be extended warranty arrangements with durations of one to five years commencing upon the end of the standard warranty period. In addition, the Company sells security monitoring systems that may have multiple performance obligations, including equipment, installation, monitoring services and maintenance agreements. Revenue associated with the sale of equipment and related installations are generally recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. The transaction price is allocated to each performance

[0000833444-25-000097:notes:78]
obligation based on the relative standalone selling price method. In order to estimate relative standalone selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach. If the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized over the contract term on a straight-line basis. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the contract.

[0000833444-25-000097:notes:79]
In all other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

[0000833444-25-000097:notes:80]
The Company assesses variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

[0000833444-25-000097:notes:81]
Shipping and handling costs billed to customers are included in sales and the related costs are included in cost of sales when control transfers to the customer. The Company presents amounts collected from customers for sales and other taxes net of the related amounts remitted.

[0000833444-25-000097:notes:82]
Subscriber System Assets, Dealer Intangibles and Related Deferred Revenue Accounts

[0000833444-25-000097:notes:83]
The Company considers assets related to the acquisition of new customers in its electronic security business in three asset categories:

[0000833444-25-000097:notes:84]
•Internally generated residential subscriber systems outside of North America;

[0000833444-25-000097:notes:85]
•Internally generated commercial subscriber systems; and

[0000833444-25-000097:notes:86]
•Customer accounts acquired through the ADT dealer program, primarily outside of North America (referred to as dealer intangibles).

[0000833444-25-000097:notes:87]
Subscriber system assets include installed property, plant and equipment for which the Company retains ownership and deferred costs directly related to the customer acquisition and system installation. Subscriber system assets represent capitalized equipment (e.g., security control panels, touch pad, motion detectors, window sensors, and other equipment) and installation costs associated with electronic security monitoring arrangements under which the Company retains ownership of the security system assets in a customer's place of business or residence. Installation costs represent costs incurred to prepare the asset for its intended use. The Company pays property taxes on the subscriber system assets and may retrieve such assets when the agreement is terminated. These assets embody a probable future economic benefit as they generate future monitoring revenue for the Company.

[0000833444-25-000097:notes:88]
Costs related to the subscriber system equipment and installation are categorized as property, plant and equipment rather than deferred costs. Deferred costs associated with subscriber system assets represent direct and incremental selling expenses (such as commissions) related to acquiring the customer. Commissions related to up-front consideration paid by customers in connection with the establishment of the monitoring arrangement are determined based on a percentage of the up-front fees and do not exceed deferred revenue. Such deferred costs are recorded as other current and noncurrent assets within the consolidated statements of financial position.

[0000833444-25-000097:notes:89]
Subscriber system assets and any deferred revenue resulting from the customer acquisition are accounted for over the expected life of the subscriber. In certain geographical areas which have a large number of customers that behave in a similar manner over time, the Company accounts for subscriber system assets and related deferred revenue using pools, with separate pools for the components of subscriber system assets and any related deferred revenue based on the same month and year of acquisition. Pooled subscriber system assets and related deferred revenue are depreciated using a straight-line method with lives up to 12 years and considering customer attrition. Non-pooled subscriber systems (primarily in Europe, Latin America and Asia) and related deferred revenue are depreciated using a straight-line method with lives up to 15 years, with remaining balances written off upon customer termination.

[0000833444-25-000097:notes:90]
Certain contracts and related customer relationships result from purchasing residential security monitoring contracts from an external network of independent dealers who operate under the ADT dealer program, primarily outside of North America.

[0000833444-25-000097:notes:91]
Acquired contracts and related customer relationships are recorded at their contractually determined purchase price. During the first 6 months (12 months in certain circumstances) after the purchase of the customer contract, any cancellation of monitoring service, including those that result from customer payment delinquencies, results in a chargeback by the Company to the dealer for the full amount of the contract purchase price. The Company records the amount charged back to the dealer as a reduction of the previously recorded intangible asset. Intangible assets arising from the ADT dealer program are amortized in pools determined by the same month and year of contract acquisition on a straight-line basis over the period of the customer relationship. The estimated useful life of dealer intangibles ranges from 12 to 15 years.

[0000833444-25-000097:notes:92]
Research and Development Costs

[0000833444-25-000097:notes:93]
Expenditures for research activities relating to product development and improvement are charged against income as incurred and primarily included within selling, general and administrative expenses in the consolidated statements of income. Such expenditures for the years ended September 30, 2025, 2024 and 2023 were $273 million, $267 million and $251 million, respectively.

[0000833444-25-000097:notes:94]
Stock-Based Compensation

[0000833444-25-000097:notes:95]
Restricted (Non-vested) Stock /Units

[0000833444-25-000097:notes:96]
Restricted stock and restricted stock units are typically settled in shares for employees in the U.S. and in cash for employees not in the U.S. Restricted awards typically vest over a period of three years from the grant date. The Company's Compensation and Talent Development Committee may approve different vesting terms on specific grants. The fair value of each share-settled restricted award is based on the closing market value of the Company’s ordinary shares on the date of grant. The fair value of each cash-settled restricted award is recalculated at the end of each reporting period based on the closing market value of the Company's ordinary shares at the end of the reporting period, and the liability and expense are adjusted based on the new fair value.

[0000833444-25-000097:notes:97]
Performance Share Awards

[0000833444-25-000097:notes:98]
Performance-based share unit ("PSU") awards are generally contingent on the achievement of predetermined performance goals over a performance period of one to three years and on the award holder's continuous employment until the vesting date. The majority of PSUs are also indexed to the achievement of specified levels of total shareholder return versus a peer group over the performance period.

[0000833444-25-000097:notes:99]
Upon completion of the performance period, earned PSUs are typically settled with shares of the Company's ordinary shares for employees in the U.S. and in cash for employees not in the U.S.

[0000833444-25-000097:notes:100]
The fair value of the portion of the PSU which is linked to the achievement of performance goals is based on the closing market value of the Company's ordinary shares on the date of grant. Share-based compensation expense for these PSUs is recognized over the performance period based on the probability of achieving the performance targets.

[0000833444-25-000097:notes:101]
The fair value of the portion of the PSU that is indexed to total shareholder return is estimated on the date of grant using a Monte Carlo simulation that uses the following assumptions:

[0000833444-25-000097:notes:102]
•The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant.

[0000833444-25-000097:notes:103]
•The expected volatility is based on the historical volatility of the Company's stock over the most recent three-year period as of the grant date.

[0000833444-25-000097:notes:104]
Share-based compensation expense for PSUs which are indexed to total shareholder return is not adjusted for changes in performance subsequent to the grant date because the likelihood of achieving the market condition is incorporated in the grant date fair value of the award.

[0000833444-25-000097:notes:105]
Stock Options

[0000833444-25-000097:notes:106]
Stock options are granted with an exercise price equal to the market price of the Company’s stock at the date of grant. Stock option awards typically vest between two and three years after the grant date and expire ten years from the grant date.

[0000833444-25-000097:notes:107]
The fair value of each option is estimated on the date of grant using a Black-Scholes option valuation model that uses the following assumptions:

[0000833444-25-000097:notes:108]
•The expected life of options represents the period of time that options granted are expected to be outstanding.

[0000833444-25-000097:notes:109]
•The risk-free interest rate for periods during the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant.

[0000833444-25-000097:notes:110]
•Expected volatility is based on the historical volatility of the Company's stock corresponding to the expected life as of the grant date.

[0000833444-25-000097:notes:111]
•The expected dividend yield is based on the expected annual dividend as a percentage of the market value of the Company’s ordinary shares as of the grant date.

[0000833444-25-000097:notes:112]
The Company uses historical data to estimate option exercises and employee terminations within the valuation model.

[0000833444-25-000097:notes:113]
Earnings Per Share

[0000833444-25-000097:notes:114]
The Company presents both basic and diluted earnings per share ("EPS") amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future and compensation cost for future service that the Company has not yet recognized. For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method include unamortized compensation cost.

[0000833444-25-000097:notes:115]
Foreign Currency Translation

[0000833444-25-000097:notes:116]
Substantially all of the Company’s international operations use the respective local currency as the functional currency. Assets and liabilities of international entities have been translated at period-end exchange rates, and income and expenses have been translated using average exchange rates for the period. Monetary assets and liabilities denominated in non-functional currencies are adjusted to reflect period-end exchange rates. Aggregate transaction gains (losses), net of the impact of foreign currency hedges, included in income from continuing operations for the years ended September 30, 2025, 2024 and 2023 were $(95) million, $(10) million and $22 million, respectively.

[0000833444-25-000097:notes:117]
Derivative Financial Instruments

[0000833444-25-000097:notes:118]
The Company has written policies and procedures that place all derivative financial instruments under the direction of Corporate treasury and restrict all derivative transactions to those intended for hedging purposes. The use of derivatives for speculative purposes is strictly prohibited. The Company selectively uses derivatives to manage the market risk from changes in foreign exchange rates, commodity prices, and interest rates.

[0000833444-25-000097:notes:119]
The fair values of all derivatives are recorded in the consolidated statements of financial position. The change in a derivative’s fair value is recorded each period in current earnings or accumulated other comprehensive income ("AOCI"), depending on whether the derivative is designated as part of a hedge transaction and if so, the type of hedge transaction.

[0000833444-25-000097:notes:120]
Investments

[0000833444-25-000097:notes:121]
Investments in debt and equity securities and deferred compensation plan assets are marked-to-market at the end of each accounting period. Unrealized gains and losses are recognized in the consolidated statements of income.

[0000833444-25-000097:notes:122]
Pension and Postretirement Benefits

[0000833444-25-000097:notes:123]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event.

[0000833444-25-000097:notes:124]
Guarantees

[0000833444-25-000097:notes:125]
The Company records an estimate for future warranty-related costs based on actual historical claims and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different from those estimates.

[0000833444-25-000097:notes:126]
The Company’s product warranty liability is recorded in the consolidated statements of financial position in other current liabilities if the warranty is less than one year and in other noncurrent liabilities if the warranty extends longer than one year.

[0000833444-25-000097:notes:127]
Loss Contingencies

[0000833444-25-000097:notes:128]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business when it is probable a liability has been incurred and the amount of the liability can be reasonably estimated. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarial determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-25-000097:notes:129]
The Company is subject to laws and regulations relating to protecting the environment. Expenses associated with environmental remediation obligations are recognized when such amounts are probable and can be reasonably estimated.

[0000833444-25-000097:notes:130]
Liabilities and expenses for workers' compensation, product, general and auto liabilities are dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-25-000097:notes:131]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-25-000097:notes:132]
The Company and certain of its subsidiaries, along with numerous other companies, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The estimated liability and corresponding insurance recovery for pending and future claims and defense costs are based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present values from the time that the costs are expected to be incurred which in some cases is not until 2068 (which is the Company's reasonable best estimate of the actuarial determined time period through which asbestos-related claims will be filed against its affiliates). Estimated asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and its defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims or insurance receivable is warranted.

[0000833444-25-000097:notes:133]
The Company records asbestos-related insurance recoveries that are probable. Estimated asbestos-related insurance recoveries represent estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers.

[0000833444-25-000097:notes:134]
Income Taxes

[0000833444-25-000097:notes:135]
Deferred tax liabilities and assets are recognized for the expected future tax consequences of events that have been reflected in the consolidated financial statements. Deferred tax asset and liabilities are determined based on the differences between the book and tax basis of particular assets and liabilities and operating loss carryforwards, using tax rates in effect for the years in which the differences are expected to reverse. A valuation allowance is provided to reduce the carrying or book value of deferred tax assets if, based upon the available evidence, including consideration of tax planning strategies, it is more-likely-than-not that some or all of the deferred tax assets will not be realized.

[0000833444-25-000097:notes:136]
The Company’s federal income tax returns and certain non-U.S. income tax returns for various fiscal years remain under various stages of audit by the IRS and respective non-U.S. tax authorities. Although the outcome of tax audits is always uncertain, management believes that it has appropriate support for the positions taken on its tax returns and that its annual tax provisions included amounts sufficient to pay assessments, if any, which may be proposed by the taxing authorities. At September 30, 2025, the Company had recorded a liability of $1.9 billion for its best estimate of the probable loss on certain of its tax positions, the majority of which is included in other noncurrent liabilities in the consolidated statements of financial position.

[0000833444-25-000097:notes:137]
New Accounting Pronouncements

[0000833444-25-000097:notes:138]
Recently Adopted Accounting Pronouncements

[0000833444-25-000097:notes:139]
In September 2022, the FASB issued ASU 2022-04, "Disclosure of Supplier Finance Program Obligations," which is intended to enhance the transparency surrounding the use of supplier finance programs. Supplier finance programs may also be referred to as reverse factoring, payables finance, or structured payables arrangements. The amendments require a buyer that uses supplier finance programs to make annual disclosures about the program’s key terms, the balance sheet presentation of related amounts, the confirmed amount outstanding at the end of the period, and associated rollforward information. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company adopted the new disclosures as required at the beginning of fiscal 2024, other than the rollforward disclosure which was adopted for the annual period ended September 30, 2025.

[0000833444-25-000097:notes:140]
The Company maintains agreements with third-party financial institutions who offer voluntary supply chain financing ("SCF") programs to its suppliers. The SCF programs enable suppliers to sell their receivables to third-party financial institutions and receive payments earlier than the negotiated commercial terms between the suppliers and the Company, which generally range from 90 to 120 days. Suppliers sell receivables to third-party financial institutions on terms negotiated between the supplier and the respective third-party financial institution. The Company remains obligated to make payments under the terms of the original commercial arrangement regardless of whether the supplier receivable is sold, and does not pledge any assets as security or provide other forms of guarantees for the committed payment to the third-party financial institutions.

[0000833444-25-000097:notes:141]
Amounts outstanding related to SCF programs are included in accounts payable in the consolidated statements of financial position. Accounts payable included in the SCF programs were approximately $835 million and $703 million as of September 30, 2025, and September 30, 2024 respectively. The following table presents the Company's outstanding obligations confirmed as valid related to the SCF programs (in millions):

[0000833444-25-000097:notes:142]
|  | Year Ended September 30, 2025 |
| Confirmed obligations outstanding at beginning of period | $ | 703 |  |
| Invoices confirmed during the period | 2,249 |  |
| Confirmed invoices paid during the period | (2,120) |  |
| Currency impact | 3 |  |
| Confirmed obligations outstanding at end of period | $ | 835 |  |

[0000833444-25-000097:notes:143]
In November 2023, the FASB issued ASU 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures," which is intended to improve reportable segment disclosures, primarily through enhanced disclosures about significant segment expenses. In addition, the amendments enhance interim disclosure requirements, clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provide new segment disclosure requirements for entities with a single reportable segment and contain other disclosure requirements. The Company adopted the new annual disclosures as required for fiscal 2025 and will adopt the interim disclosures as required beginning with the first quarter of fiscal 2026. Refer to Note 18, "Segment Information," of the notes to consolidated financial statements for the Company's segment disclosures.

[0000833444-25-000097:notes:144]
Recently Issued Accounting Pronouncements

[0000833444-25-000097:notes:145]
In November 2024, the FASB issued ASU 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses," which is intended to enhance transparency into the nature and function of expenses. The amendments require that on an annual and interim basis, entities disclose disaggregated operating expense information about specific categories, including purchases of inventory, employee compensation, depreciation, amortization and depletion. The Company expects to adopt the new annual disclosures as required for fiscal 2028 and the interim disclosures as required beginning with the first quarter of fiscal 2029.

[0000833444-25-000097:notes:146]
In December 2023, the FASB issued ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures," which is intended to enhance the transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. The amendments require that on an annual basis, entities disclose specific categories in the rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. In addition, the amendments require that entities disclose additional information about income taxes paid as well as additional disclosures of pretax income and income tax expense, and remove the requirement to disclose certain items that are no longer considered cost beneficial or relevant. The Company expects to adopt the new annual disclosures as required for fiscal 2026.

[0000833444-25-000097:notes:147]
In September 2025, the FASB issued ASU 2025-06, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software," which is intended to increase the operability of the recognition guidance considering different methods of software development. The amendments remove all references to prescriptive and sequential software development stages (referred to as “project stages”) throughout Subtopic 350-40, and instead specify an entity is required to start capitalizing software costs when both of the following occur: (1) management has authorized and committed to funding the software project and (2) it is probable that the project will be completed and the software will be used to perform the function intended (referred to as the “probable-to complete recognition threshold”). The Company expects to adopt the new guidance as required for fiscal 2029 and is evaluating the impact the new standard will have on its consolidated financial statements.

[0000833444-25-000097:notes:148]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-25-000097:notes:149]
ACQUISITIONS AND DIVESTITURES
Fiscal 2025

[0000833444-25-000097:notes:150]
In July 2024, the Company entered into a definitive agreement to sell its Residential and Light Commercial ("R&LC") HVAC business, which includes the North America Ducted businesses and the global Residential joint venture with Hitachi, of which Johnson Controls owns 60% and Hitachi owns 40%.  The Company completed the sale of its R&LC HVAC business on July 31, 2025 for proceeds of $5.6 billion, net of cash disposed, after tax and transaction-related expenses.  In connection with the sale, the Company recognized a gain, net of transaction and other costs, of $2.7 billion ($1.5 billion after tax) for the year ended September 30, 2025, subject to final post-closing working capital and net debt adjustments, within income from discontinued operations, net of tax, in the consolidated statements of income.

[0000833444-25-000097:notes:151]
The Company determined that the R&LC HVAC business, which was previously reported in the Global Products segment prior to the Company's resegmentation, met the criteria to be classified as a discontinued operation as it represented a strategic shift in the Company's operations and resulted in the exit of substantially all of its residential and light commercial HVAC businesses. As a result, the R&LC HVAC business was presented in discontinued operations separate from continuing operations for all periods presented.

[0000833444-25-000097:notes:152]
The Company determined that the assets and liabilities for the R&LC HVAC business met the held for sale criteria during the fourth quarter of 2024 and ceased recording depreciation and amortization for the held for sale assets upon meeting the held for sale criteria.

[0000833444-25-000097:notes:153]
The major classes of line items constituting income from discounted operations, net, in millions:

[0000833444-25-000097:notes:154]
|  |  | Year Ended September 30, |  |
|  |  | 2025 |  | 2024 |  | 2023 |  |
| Net sales |  | $ | 3,790 |  |  | $ | 4,466 |  |  | $ | 4,462 |  |  |
| Cost of goods sold |  | 2,881 |  |  | 3,300 |  |  | 3,295 |  |  |
| Gross profit |  | 909 |  |  | 1,166 |  |  | 1,167 |  |  |
| Selling, general and administrative expenses |  | (2,008) |  |  | 761 |  |  | 794 |  |  |
| Restructuring and impairment costs |  | 30 |  |  | 34 |  |  | 15 |  |  |
| Net financing charges |  | 5 |  |  | 17 |  |  | 23 |  |  |
| Equity income |  | 240 |  |  | 276 |  |  | 262 |  |  |
| Income from discontinued operations before income taxes |  | 3,122 |  |  | 630 |  |  | 597 |  |  |
| Provision for income taxes on discontinued operations |  | 1,333 |  |  | 141 |  |  | 145 |  |  |
| Income from discontinued operations, net of tax |  | 1,789 |  |  | 489 |  |  | 452 |  |  |
| Income from discontinued operations attributable to noncontrolling interest, net of tax |  | 219 |  |  | 191 |  |  | 165 |  |  |
| Income from discontinued operations |  | $ | 1,570 |  |  | $ | 298 |  |  | $ | 287 |  |  |

[0000833444-25-000097:notes:155]
The carrying amounts of major classes of assets and liabilities included as part of the R&LC HVAC business discontinued operations and reported as held for sale, were as follows, in millions:

[0000833444-25-000097:notes:156]
|  |  | September 30, 2024 |
| Cash |  | $ | 5 |  |
| Accounts receivable - net |  | 592 |  |
| Inventories |  | 876 |  |
| Other current assets |  | 122 |  |
| Current assets held for sale |  | 1,595 |  |
| Property, plant and equipment - net |  | 793 |  |
| Goodwill |  | 1,182 |  |
| Other intangible assets - net |  | 96 |  |
| Investments in partially-owned affiliates |  | 949 |  |
| Other noncurrent assets |  | 190 |  |
| Noncurrent assets held for sale |  | 3,210 |  |
| Total assets classified as held for sale |  | $ | 4,805 |  |
| Accounts payable |  | $ | 917 |  |
| Accrued compensation and benefits |  | 113 |  |
| Deferred revenue |  | 84 |  |
| Other current liabilities |  | 317 |  |
| Current liabilities held for sale |  | 1,431 |  |
| Pension and postretirement benefit obligations |  | 28 |  |
| Other noncurrent liabilities |  | 377 |  |
| Noncurrent liabilities held for sale |  | 405 |  |
| Total liabilities classified as held for sale |  | $ | 1,836 |  |

[0000833444-25-000097:notes:157]
In conjunction with the divestiture, we entered into Transition Services Agreements to provide administrative services to the buyers. The fees for services rendered under each of the Transition Service Agreements were not material to our results of operations.

[0000833444-25-000097:notes:158]
Fiscal 2024
During fiscal 2024, the Company completed three divestitures, including the divestiture of its Air Distribution Technologies ("ADTi") business which was previously reported in the Global Products segment prior to the Company's resegmentation. The combined selling price, net of cash divested, was $347 million, of which $332 million was received as of September 30, 2024. In connection with the closing of the ADTi transaction, the Company recorded a pre-tax loss of $42 million within selling, general and administrative expenses in the consolidated statements of income. An impairment of $56 million was recorded within restructuring and impairment costs in the consolidated statements of income while the business was classified as held for sale. Net cash proceeds from the divestitures were used for general corporate purposes. The businesses did not meet the criteria to be classified as discontinued operations as the divestitures did not represent a strategic shift that will have a major effect on the Company's operations and financial results.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-25-000097:notes:159]
ASSETS AND LIABILITIES HELD FOR SALE
During the third quarter of fiscal 2025, the Company signed a definitive agreement to sell its ADT Mexico residential security business. The ADT Mexico business, which was reported in the EMEA segment, did not meet the criteria to be classified as discontinued operations as it did not represent a strategic shift in the Company's operations nor result in the exit of substantially all of its residential security businesses.

[0000833444-25-000097:notes:160]
The Company determined that the assets and liabilities of the ADT Mexico business met the held for sale criteria during the third quarter of 2025. Accordingly, $154 million of assets and $21 million of liabilities associated with the ADT Mexico business were reclassified to held for sale in the consolidated balance sheet at September 30, 2025.

[0000833444-25-000097:notes:161]
Assets and liabilities classified as held for sale are required to be recorded at the lower of carrying value or fair value less costs to sell. As of September 30, 2025, the estimated fair value less costs to sell of the held for sale business exceeded their carrying value, and therefore, no adjustment was necessary. The transaction closed on October 31, 2025 and the gain on sale, net of transaction and other costs, is still being finalized, but will not be material.

[0000833444-25-000097:notes:162]
During the year ended September 30, 2023, the Company recorded impairment charges for the Global Retail business of $438 million. The impairment charges were primarily due to reductions in the estimated fair values of the business to be disposed as a result of negotiations with potential buyers and were recorded within restructuring and impairment costs in the consolidated statements of income. During the third quarter of fiscal 2023, the Company concluded that its Global Retail business no longer met the criteria to be classified as held for sale, as it was no longer probable that it would be sold in the next 12 months. The net assets were reclassified to held and used at the lower of fair value or adjusted carrying value, and due to prior period impairment charges recorded, there was no impact to the consolidated statements of income as a result of this reclassification.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-25-000097:notes:163]
REVENUE RECOGNITION
Disaggregated Revenue

[0000833444-25-000097:notes:164]
The following table presents the Company's revenues disaggregated by segment and by products and systems versus services revenue (in millions):

[0000833444-25-000097:notes:165]
|  |  | Year Ended September 30, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 11,187 |  |  | $ | 4,644 |  |  | $ | 15,831 |  |  | $ | 11,206 |  |  | $ | 4,400 |  |  | $ | 15,606 |  |
| EMEA |  | 2,977 |  |  | 1,991 |  |  | 4,968 |  |  | 2,789 |  |  | 1,831 |  |  | 4,620 |  |
| APAC |  | 1,960 |  |  | 837 |  |  | 2,797 |  |  | 1,972 |  |  | 754 |  |  | 2,726 |  |
| Total |  | $ | 16,124 |  |  | $ | 7,472 |  |  | $ | 23,596 |  |  | $ | 15,967 |  |  | $ | 6,985 |  |  | $ | 22,952 |  |

[0000833444-25-000097:notes:166]
Contract Balances

[0000833444-25-000097:notes:167]
Contract assets represent the Company’s right to consideration for performance obligations that have been satisfied but not billed and consist of unbilled receivables and costs in excess of billings. Contract liabilities are customer payments received before performance obligations are satisfied. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

[0000833444-25-000097:notes:168]
The following table presents the location and amount of contract balances in the Company's consolidated statements of financial position (in millions):

[0000833444-25-000097:notes:169]
|  |  |  |  | September 30, |  |  |
|  |  | Location of contract balances |  | 2025 |  | 2024 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,178 |  |  | $ | 1,931 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 9 |  |  | 11 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,470 |  |  | 2,160 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 478 |  |  | 252 |  |  |  |

[0000833444-25-000097:notes:170]
The Company recognized revenue that was included in the beginning of period contract liability balance of approximately $1.8 billion and $1.7 billion for the years ended September 30, 2025 and 2024, respectively.

[0000833444-25-000097:notes:171]
Performance Obligations

[0000833444-25-000097:notes:172]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of September 30, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $22.7 billion, of which approximately 63% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with average initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.

[0000833444-25-000097:notes:173]
Costs to Obtain or Fulfill a Contract

[0000833444-25-000097:notes:174]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when the costs are recoverable. These costs consist primarily of sales commissions and design costs that relate to a contract or an anticipated contract that the Company expects to recover. Costs to obtain or fulfill a contract are capitalized when incurred and amortized to expense over the period of contract performance.

[0000833444-25-000097:notes:175]
The following table presents the location and amount of costs to obtain or fulfill a contract recorded in the Company's consolidated statements of financial position (in millions):

[0000833444-25-000097:notes:176]
|  |  | September 30, |  |  |
|  |  | 2025 |  | 2024 |  |  |
| Other current assets |  | $ | 327 |  |  | $ | 265 |  |  |  |
| Other noncurrent assets |  | 249 |  |  | 291 |  |  |  |
| Total |  | $ | 576 |  |  | $ | 556 |  |  |  |

[0000833444-25-000097:notes:177]
Amortization of costs to obtain or fulfill a contract was $373 million and $312 million during the years ended September 30, 2025 and 2024, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-25-000097:notes:178]
INVENTORIES
Inventories consisted of the following (in millions):

[0000833444-25-000097:notes:179]
|  | September 30, |
|  | 2025 |  | 2024 |
| Raw materials and supplies | $ | 716 |  |  | $ | 765 |  |
| Work-in-process | 132 |  |  | 130 |  |
| Finished goods | 972 |  |  | 879 |  |
| Inventories | $ | 1,820 |  |  | $ | 1,774 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-25-000097:notes:180]
PROPERTY, PLANT AND EQUIPMENT
Property, plant and equipment consisted of the following (in millions):

[0000833444-25-000097:notes:181]
|  | September 30, |
|  | 2025 |  | 2024 |
| Buildings and improvements | $ | 1,095 |  |  | $ | 1,033 |  |
| Subscriber systems | 989 |  |  | 973 |  |
| Machinery and equipment | 3,597 |  |  | 3,374 |  |
| Construction in progress | 382 |  |  | 418 |  |
| Land | 47 |  |  | 48 |  |
| Total property, plant and equipment | 6,110 |  |  | 5,846 |  |
| Less: Accumulated depreciation | (3,917) |  |  | (3,443) |  |
| Property, plant and equipment - net | $ | 2,193 |  |  | $ | 2,403 |  |

[0000833444-25-000097:notes:182]
During the fourth quarter of fiscal 2025, the Company determined that a triggering event had occurred for the Americas Retail asset group within the Americas segment, primarily as a result of customer contract terminations and the related impact on demand and forecasted operating results and cash flows. The Company conducted the two-step impairment test required in accordance with ASC 360, "Property, Plant & Equipment" and determined that the carrying amount of the asset group exceeded its fair value. A non-cash impairment charge of $156 million, comprised of $81 million of property, plant, and equipment and $75 million of definite-lived intangible assets, was recorded and is included in restructuring and impairment costs in the consolidated statements of income.

[0000833444-25-000097:notes:183]
During the fourth quarter of fiscal 2025, the Company determined that a triggering event had also occurred for the Subscriber asset groups within the EMEA segment due to a decline in the market value of the Subscriber business. The Company conducted the two-step impairment test required in accordance with ASC 360, "Property, Plant & Equipment" and determined that the carrying amount of the asset groups exceeded their fair value. A non-cash impairment charge of $184 million, comprised of $94 million of property, plant, and equipment and $90 million of definite-lived intangible assets, was recorded and is included in restructuring and impairment costs in the consolidated statements of income. The Company used a discounted cash flow model to estimate the fair value of the asset group. The primary assumptions and inputs used in the model included estimated proceeds from the disposition of the asset groups, management's internal projections of future cash flows, and the weighted-average cost of capital. The fair value measurement is classified as Level 3 within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement" due to the unobservable inputs used.

[0000833444-25-000097:notes:184]
During the fourth quarter of fiscal 2023, the Company determined that a triggering event had occurred in the asset group comprising the security subscriber business of Argentina, primarily as a result of the significant devaluation of the Argentine peso that occurred during the quarter and the resulting impact on operating results and cash flows. The Company conducted the two-step impairment test required in accordance with ASC 360, "Property, Plant & Equipment" and determined that the carrying amount of the asset group exceeded its fair value. A non-cash impairment charge to the subscriber system assets of $78 million was recorded and is included in restructuring and impairment costs in the consolidated statements of income. The Company used a discounted cash flow model to estimate the fair value of the asset group. The primary assumptions and inputs used in the model included management's internal projections of future cash flows, the weighted-average cost of capital and the long-term growth rate. The fair value measurement is classified as Level 3 within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement" due to the unobservable inputs used.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-25-000097:notes:185]
GOODWILL AND OTHER INTANGIBLE ASSETS
Goodwill

[0000833444-25-000097:notes:186]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments were as follows (in millions):

[0000833444-25-000097:notes:187]
|  |  | Year Ended September 30, 2025 |
|  |  | Americas |  | EMEA |  | APAC |  | Total |
| Goodwill |  | $ | 14,118 |  |  | $ | 2,409 |  |  | $ | 1,393 |  |  | 17,920 |  |
| Accumulated impairment loss |  | (918) |  |  | (277) |  |  | — |  |  | (1,195) |  |
| Balance at beginning of period |  | 13,200 |  |  | 2,132 |  |  | 1,393 |  |  | 16,725 |  |
| Foreign currency translation and other (1) |  | (26) |  |  | (21) |  |  | (45) |  |  | (92) |  |
| Balance at end of period |  | $ | 13,174 |  |  | $ | 2,111 |  |  | $ | 1,348 |  |  | $ | 16,633 |  |

[0000833444-25-000097:notes:188]
(1)  Includes measurement period adjustments and the allocation of $86 million of goodwill from EMEA to the ADT Mexico residential security business disposal group classified as held for sale. Refer to Note 3, "Assets and Liabilities Held for Sale," of the notes to consolidated financial statements for further information.

[0000833444-25-000097:notes:189]
|  |  | Year Ended September 30, 2024 |  |
|  |  | Americas |  | EMEA |  | APAC |  | Total |  |
| Goodwill |  | $ | 14,090 |  |  | $ | 2,302 |  |  | $ | 1,345 |  |  | 17,737 |  |  |
| Accumulated impairment loss |  | (918) |  |  | (47) |  |  | — |  |  | (965) |  |  |
| Balance at beginning of period |  | 13,172 |  |  | 2,255 |  |  | 1,345 |  |  | 16,772 |  |  |
| Impairments |  | — |  |  | (230) |  |  | — |  |  | (230) |  |  |
| Foreign currency translation and other (1) |  | 28 |  |  | 107 |  |  | 48 |  |  | 183 |  |  |
| Balance at end of period |  | $ | 13,200 |  |  | $ | 2,132 |  |  | $ | 1,393 |  |  | $ | 16,725 |  |  |

[0000833444-25-000097:notes:190]
(1)  Includes measurement period adjustments and the allocation of $21 million of goodwill from the ADTi disposal group classified as held for sale in June 2024 and subsequently divested in July 2024. Refer to Note 2, "Acquisitions and Divestitures," of the notes to consolidated financial statements for further information.

[0000833444-25-000097:notes:191]
At April 1, 2025, the Company reallocated goodwill of reporting units impacted by the change in reportable segments described in Note 18, "Segment Information," of the notes to consolidated financial statements and assessed goodwill for impairment. The Company determined that the estimated fair value of each reporting unit exceeded its corresponding carrying amount including recorded goodwill, and as such, no impairment existed at April 1, 2025.

[0000833444-25-000097:notes:192]
Management completed its fiscal 2025 annual impairment test as of July 31, which included a qualitative assessment of all of its reporting units. The Company did not identify any qualitative factors that suggest that it is more likely than not that the fair value of its reporting units is less than their carrying amount, including goodwill, and as such, a quantitative impairment test was not necessary.

[0000833444-25-000097:notes:193]
During the third quarter of fiscal 2025, the Company signed a definitive agreement to sell its ADT Mexico residential security business, which resulted in a triggering event to assess the remaining goodwill in the reporting Subscriber reporting unit. The Company performed a quantitative goodwill impairment test of the remaining $174 million of goodwill, and its fair value was slightly in excess of its carrying value. While no impairment was recorded, it is possible that future changes in circumstances could result in a non-cash impairment charge as the fair value of this reporting unit approximates its carrying amount. The Company used a discounted cash flow model to estimate the fair value of the reporting unit. The primary assumptions used in the model were management's internal projections of future cash flows, the weighted-average cost of capital and the long-term growth rate, which are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." As noted in Note 6, "Property, Plant & Equipment", the Company identified a triggering event in the EMEA Subscriber asset groups in the fourth quarter, resulting in an impairment of long-lived asset groups, which has the effect of lowering the carrying value of the Subscriber reporting unit. This reporting unit was previously disclosed as being at risk of impairment in the Company’s Annual Report on Form 10-K for the year-ended September 30, 2024.

[0000833444-25-000097:notes:194]
During fiscal 2024, the Company determined a triggering event had occurred for one of its reporting units which was previously reported in the Business Solutions EMEA/LA segment due to year-to-date results and projections for the remainder of fiscal

[0000833444-25-000097:notes:195]
2024 being lower than the forecast used in the previous annual goodwill impairment test, and a quantitative test of goodwill for possible impairment was necessary. As a result of the goodwill impairment test, the Company recorded a non-cash impairment charge of $230 million within restructuring and impairment costs in the consolidated statements of income, which was determined by comparing the carrying amount of the reporting unit to its fair value. The Company used a discounted cash flow model to estimate the fair value of the reporting unit. The primary assumptions used in the model were management's internal projections of future cash flows, the weighted-average cost of capital and the long-term growth rate, which are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-25-000097:notes:196]
During fiscal 2023, management completed an updated comprehensive review of the Silent-Aire reporting unit, which was previously reported in the Global Products segment. Because actual results were lower than planned and the nearer term forecast was revised to reflect lower margins and earnings, the Company determined a triggering event had occurred and a quantitative test of goodwill for possible impairment was necessary. As a result of the goodwill impairment test, the Company recorded a non-cash impairment charge of $184 million within restructuring and impairment costs in the consolidated statements of income in fiscal 2023, which was determined by comparing the carrying amount of the reporting unit to its fair value. The Company used a discounted cash flow model to estimate the fair value of the Silent-Aire reporting unit. The primary assumptions and inputs used in the model included management's internal projections of future cash flows, the weighted-average cost of capital and the long-term growth rate. The fair value measurement is classified as Level 3 within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement" due to the unobservable inputs used. The Silent-Aire reporting unit had no remaining goodwill balance as of September 30, 2023.

[0000833444-25-000097:notes:197]
There were no other triggering events requiring that an impairment assessment be conducted in fiscal 2025, 2024 or 2023. However, it is possible that future changes in circumstances would require the Company to record additional non-cash impairment charges.

[0000833444-25-000097:notes:198]
Other Intangible Assets

[0000833444-25-000097:notes:199]
The Company’s other intangible assets, primarily from business acquisitions, consisted of (in millions):

[0000833444-25-000097:notes:200]
|  | September 30, |
|  | 2025 |  | 2024 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,197 |  |  | $ | (714) |  |  | $ | 483 |  |  | $ | 1,592 |  |  | $ | (955) |  |  | $ | 637 |  |
| Customer relationships | 2,026 |  |  | (1,272) |  |  | 754 |  |  | 2,632 |  |  | (1,517) |  |  | 1,115 |  |
| Miscellaneous | 910 |  |  | (511) |  |  | 399 |  |  | 886 |  |  | (480) |  |  | 406 |  |
|  | 4,133 |  |  | (2,497) |  |  | 1,636 |  |  | 5,110 |  |  | (2,952) |  |  | 2,158 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/tradenames | 1,977 |  |  | — |  |  | 1,977 |  |  | 1,972 |  |  | — |  |  | 1,972 |  |
| Total intangible assets | $ | 6,110 |  |  | $ | (2,497) |  |  | $ | 3,613 |  |  | $ | 7,082 |  |  | $ | (2,952) |  |  | $ | 4,130 |  |

[0000833444-25-000097:notes:201]
During the fourth quarter of fiscal 2025, the Company impaired $59 million and $90 million of customer relationships in the Americas segment and EMEA segment, respectively, and $16 million of technology in the Americas segment. Refer to Note 6, "Property, Plant, and Equipment," for additional disclosure regarding impairments in the Americas and EMEA segments.

[0000833444-25-000097:notes:202]
During the fourth quarter of fiscal 2024,  the Company impaired $32 million and $13 million of miscellaneous intangible assets previously reported in the Global Products segment and Building Solutions North America segment, respectively. These non-cash charges were recorded within restructuring and impairment costs in the consolidated statement of income.

[0000833444-25-000097:notes:203]
There were no impairments of other indefinite-lived intangible assets in any of these years, other than as disclosed above. For all other remaining indefinite-lived intangible assets, the Company estimated fair values were greater than the carrying values, with the exception of two registered trademarks with estimated fair values that were consistent with their carrying values, which totaled $320 million as of July 31, 2025.

[0000833444-25-000097:notes:204]
Amortization of other intangible assets included within continuing operations for the years ended September 30, 2025, 2024 and 2023 was $439 million, $476 million and $426 million, respectively.

[0000833444-25-000097:notes:205]
The following table summarizes estimated amortization of existing definite-lived intangible assets as of September 30, 2025 for each of the next five fiscal years (in millions):

[0000833444-25-000097:notes:206]
| 2026 |  | $ | 347 |  |
| 2027 |  | 323 |  |
| 2028 |  | 268 |  |
| 2029 |  | 175 |  |
| 2030 |  | 172 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-25-000097:notes:207]
LEASES
The following table presents the Company’s lease costs (in millions):

[0000833444-25-000097:notes:208]
|  |  | Year Ended September 30, |  |
|  |  | 2025 |  | 2024 |  | 2023 |  |
| Operating lease cost |  | $ | 381 |  |  | $ | 374 |  |  | $ | 365 |  |  |
| Variable lease cost |  | 153 |  |  | 170 |  |  | 154 |  |  |
| Total lease costs |  | $ | 534 |  |  | $ | 544 |  |  | $ | 519 |  |  |

[0000833444-25-000097:notes:209]
The following table presents supplemental consolidated statement of financial position information (in millions):

[0000833444-25-000097:notes:210]
|  |  |  | September 30, |
|  | Location of lease balances |  | 2025 |  | 2024 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,347 |  |  | $ | 1,170 |  |
| Operating lease liabilities - current | Other current liabilities |  | 226 |  |  | 289 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 1,084 |  |  | 921 |  |
| Weighted-average remaining lease term |  |  | 7 years |  | 7 years |
| Weighted-average discount rate |  |  | 4.1 | % |  | 3.8 | % |

[0000833444-25-000097:notes:211]
The following table presents supplemental cash flow information related to operating leases (in millions):

[0000833444-25-000097:notes:212]
|  |  | Year Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Cash paid for amounts included in the measurement of lease liability: |  |  |  |  |  |  |
| Operating cash outflows from operating leases |  | $ | 452 |  |  | $ | 377 |  |  | $ | 355 |  |
| Noncash operating lease activity: |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  | 555 |  |  | 354 |  |  | 389 |  |

[0000833444-25-000097:notes:213]
The following table presents future minimum rental payments for operating lease liabilities as of September 30, 2025 (in millions):

[0000833444-25-000097:notes:214]
| 2026 |  | $ | 274 |  |
| 2027 |  | 306 |  |
| 2028 |  | 245 |  |
| 2029 |  | 189 |  |
| 2030 |  | 132 |  |
| After 2030 |  | 370 |  |
| Total operating lease payments |  | 1,516 |  |
| Less: Interest |  | (206) |  |
| Present value of lease payments |  | $ | 1,310 |  |


## us-gaap:LeaseCostTableTextBlock

[0000833444-25-000097:notes:215]
The following table presents the Company’s lease costs (in millions):


## us-gaap:DebtDisclosureTextBlock

[0000833444-25-000097:notes:216]
DEBT AND FINANCING ARRANGEMENTS
Short-Term Debt

[0000833444-25-000097:notes:217]
Short-term debt consisted of the following (in millions):

[0000833444-25-000097:notes:218]
|  | September 30, |
|  | 2025 |  | 2024 |
| Term loans | $ | 320 |  |  | $ | 603 |  |
| Commercial paper | 400 |  |  | 350 |  |
| Bank borrowings | 3 |  |  | — |  |
|  | $ | 723 |  |  | $ | 953 |  |
| Weighted average interest rate on short-term debt outstanding | 4.5 | % |  | 4.8 | % |

[0000833444-25-000097:notes:219]
Long-Term Debt

[0000833444-25-000097:notes:220]
Long-term debt consisted of the following (in millions):

[0000833444-25-000097:notes:221]
|  |  |  |  |  |  |  | September 30, |
| Issuer |  | Interest Rate |  | Due Date |  |  | 2025 |  | 2024 |
| US dollar debt |  |  |  |  |  |  |  |  |  |
| JCI plc |  | 3.90% |  | February 2026 |  |  | $ | 487 |  |  | $ | 487 |  |
| TIFSA1 |  | 3.90% |  | February 2026 |  |  | 51 |  | 51 |  |
| JCI plc and TFSCA2 |  | 5.50% |  | April 2029 |  |  | 700 |  | 700 |  |
| JCI plc and TFSCA2 |  | 1.75% |  | September 2030 |  |  | 625 |  | 625 |  |
| JCI plc and TFSCA2 |  | 2.00% |  | September 2031 |  |  | 500 |  | 500 |  |
| JCI plc and TFSCA2 |  | 4.90% |  | December 2032 |  |  | 650 |  | 400 |  |
| JCI plc |  | 6.00% |  | January 2036 |  |  | 342 |  | 342 |  |
| JCI inc |  | 6.00% |  | January 2036 |  |  | 8 |  | 8 |  |
| JCI plc |  | 5.70% |  | March 2041 |  |  | 190 |  | 190 |  |
| JCI inc |  | 5.70% |  | March 2041 |  |  | 30 |  | 30 |  |
| JCI plc |  | 5.25% |  | December 2041 |  |  | 155 |  | 155 |  |
| JCI inc |  | 5.25% |  | December 2041 |  |  | 6 |  | 6 |  |
| JCI plc |  | 4.625% |  | July 2044 |  |  | 444 |  | 444 |  |
| JCI inc |  | 4.625% |  | July 2044 |  |  | 6 |  | 6 |  |
| JCI plc |  | 5.125% |  | September 2045 |  |  | 246 |  | 253 |  |
| TIFSA1 |  | 5.125% |  | September 2045 |  |  | 23 |  | 23 |  |
| JCI plc |  | 6.95% |  | December 2045 |  |  | 32 |  | 32 |  |
| JCI plc |  | 6.95% |  | December 2045 |  |  | 4 |  | 4 |  |
| JCI plc |  | 4.50% |  | February 2047 |  |  | 500 |  | 500 |  |
| JCI plc |  | 4.95% |  | July 2064 |  |  | 341 |  | 341 |  |
| JCI plc |  | 4.95% |  | July 2064 |  |  | 15 |  | 15 |  |
| Euro debt |  |  |  |  |  |  |  |  |  |
| JCI plc |  | 1.375% |  | February 2025 |  |  | — |  |  | 472 |  |
| TIFSA1 |  | 1.375% |  | February 2025 |  |  | — |  |  | 60 |  |
| JCI plc |  | EURIBOR plus 0.75% |  | April 2027 |  |  | 176 |  | — |  |
| JCI plc and TFSCA2 |  | 0.375% |  | September 2027 |  |  | 587 |  |  | 559 |  |
| JCI plc and TFSCA2 |  | 3.00% |  | September 2028 |  |  | 704 |  | 670 |  |
| JCI plc and TFSCA2 |  | 1.00% |  | September 2032 |  |  | 587 |  | 559 |  |
| JCI plc and TFSCA2 |  | 3.125% |  | December 2033 |  |  | 587 |  | — |  |
| JCI plc and TFSCA2 |  | 4.25% |  | May 2035 |  |  | 939 |  | 894 |  |
| Japanese yen debt |  |  |  |  |  |  |  |  |  |
| JCI plc |  | TORF plus 0.40% |  | September 2027 |  |  | 203 |  | 211 |  |
| Other |  |  |  |  |  |  | 57 |  |  | 31 |  |
| Gross long-term debt |  |  |  |  |  |  | 9,195 |  |  | 8,568 |  |
| Less: |  |  |  |  |  |  |  |  |  |
| Debt issuance costs |  |  |  |  |  |  | 39 |  |  | 38 |  |
| Net unamortized discount |  |  |  |  | 38 |  |  | 38 |  |
| Net purchase accounting adjustments |  |  |  |  | (39) |  |  | (48) |  |
|  |  |  |  |  |  |  | 9,157 |  |  | 8,540 |  |
| Less: Current portion |  |  |  |  |  |  | 566 |  |  | 536 |  |
| Long-term debt |  |  |  |  |  |  | $ | 8,591 |  |  | $ | 8,004 |  |

[0000833444-25-000097:notes:222]
1 TIFSA = Tyco International Finance S.A.

[0000833444-25-000097:notes:223]
2 TFSCA = Tyco Fire & Security Finance S.C.A.

[0000833444-25-000097:notes:224]
The following table presents maturities of long-term debt as of September 30, 2025 (in millions):

[0000833444-25-000097:notes:225]
| 2026 |  | $ | 566 |  |
| 2027 |  | 972 |  |
| 2028 |  | 710 |  |
| 2029 |  | 706 |  |
| 2030 |  | 631 |  |
| After 2030 |  | 5,610 |  |
| Total |  | $ | 9,195 |  |

[0000833444-25-000097:notes:226]
Other

[0000833444-25-000097:notes:227]
As of September 30, 2025, the Company had two syndicated committed revolving credit facilities including $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2025. There were no draws on the facilities as of September 30, 2025.

[0000833444-25-000097:notes:228]
As of September 30, 2025, the Company was in compliance with all financial covenants set forth in its credit agreements and the indentures governing its outstanding notes, and expects to remain in compliance for the foreseeable future. 
Total interest paid on both short and long-term debt for the years ended September 30, 2025, 2024 and 2023 was $321 million, $361 million and $288 million, respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-25-000097:notes:229]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES
Cash Flow Hedges

[0000833444-25-000097:notes:230]
The Company has global operations and participates in foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange forward contracts. The Company hedges 70% to 90% of the notional amount of each of its known foreign exchange transactional exposures.

[0000833444-25-000097:notes:231]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company's purchases of copper and aluminum in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-25-000097:notes:232]
Under ASC 815, "Derivatives and Hedging," cash flow hedge gains or losses due to changes in fair value are initially recorded as a component of accumulated other comprehensive income ("AOCI") and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates and commodity prices during the years ended September 30, 2025 and 2024.

[0000833444-25-000097:notes:233]
The Company had the following outstanding contracts to hedge forecasted commodity purchases (in metric tons):

[0000833444-25-000097:notes:234]
|  |  | Volume Outstanding as of September 30, |
| Commodity |  | 2025 |  | 2024 |
| Copper |  | 1,950 |  |  | 2,676 |  |
| Aluminum |  | 703 |  |  | 2,450 |  |

[0000833444-25-000097:notes:235]
The Company may enter into forward-starting interest rate swaps in conjunction with anticipated note issuances to manage exposure to interest rate changes. The forward-starting interest swaps are terminated when the anticipated notes are issued.

[0000833444-25-000097:notes:236]
During fiscal 2024, the Company terminated $600 million of forward-starting interest rate swaps related to an anticipated note issuance that was no longer highly likely to occur. Accumulated amounts previously recorded in AOCI were not material and were recognized as net financing charges in the consolidated statements of income when the swaps were terminated.

[0000833444-25-000097:notes:237]
Net Investment Hedges

[0000833444-25-000097:notes:238]
The Company may enter into cross-currency interest rate swaps and foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the cross-currency interest rate swaps and debt obligations are reflected in the AOCI account within shareholders’equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-25-000097:notes:239]
The following table summarizes net investment hedges (in billions):

[0000833444-25-000097:notes:240]
|  |  | September 30, |
|  | 2025 |  | 2024 |
| Euro-denominated bonds designated as net investment hedges in Europe |  | € | 2.9 |  |  | € | 2.9 |  |
| Yen-denominated debt designated as a net investment hedge in Japan |  | ¥ | 30 |  |  | ¥ | 30 |  |

[0000833444-25-000097:notes:241]
Derivatives Not Designated as Hedging Instruments

[0000833444-25-000097:notes:242]
The Company holds certain foreign currency forward contracts not designated as hedging instruments under ASC 815 to hedge foreign currency exposure resulting from monetary assets and liabilities denominated in nonfunctional currencies. The changes in fair value of these foreign currency forward exchange derivatives are recorded in the consolidated statements of income where they offset foreign currency transactional gains and losses on the nonfunctional currency denominated assets and liabilities being hedged.

[0000833444-25-000097:notes:243]
Fair Value of Derivative Instruments

[0000833444-25-000097:notes:244]
The following table presents the location and fair values of derivative instruments and hedging activities included in the Company’s consolidated statements of financial position (in millions):

[0000833444-25-000097:notes:245]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments |  | Derivatives and Hedging Activities Not Designatedas Hedging Instruments |
|  | September 30, 2025 |  | September 30, 2024 |  | September 30, 2025 |  | September 30, 2024 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 14 |  |  | $ | 19 |  |  | $ | — |  |  | $ | 1 |  |
| Commodity derivatives | 1 |  |  | 2 |  |  | — |  |  | — |  |
| Total assets | $ | 15 |  |  | $ | 21 |  |  | $ | — |  |  | $ | 1 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 9 |  |  | $ | 24 |  |  | $ | 14 |  |  | $ | 1 |  |
| Commodity derivatives | 1 |  |  | 1 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,607 |  |  | 3,424 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,617 |  |  | $ | 3,449 |  |  | $ | 14 |  |  | $ | 1 |  |

[0000833444-25-000097:notes:246]
Counterparty Credit Risk

[0000833444-25-000097:notes:247]
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with substantially all of its counterparties. The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all

[0000833444-25-000097:notes:248]
outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position.

[0000833444-25-000097:notes:249]
The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-25-000097:notes:250]
The gross and net amounts of derivative assets and liabilities were as follows (in millions):

[0000833444-25-000097:notes:251]
|  | Fair Value of Assets |  | Fair Value of Liabilities |
|  | September 30, 2025 |  | September 30, 2024 |  | September 30, 2025 |  | September 30, 2024 |  |
| Gross amount recognized | $ | 15 |  |  | $ | 22 |  |  | $ | 3,631 |  |  | $ | 3,450 |  |  |
| Gross amount eligible for offsetting | (4) |  |  | (12) |  |  | (4) |  |  | (12) |  |  |
| Net amount | $ | 11 |  |  | $ | 10 |  |  | $ | 3,627 |  |  | $ | 3,438 |  |  |

[0000833444-25-000097:notes:252]
Derivatives Impact on the Statements of Income and Statements of Comprehensive Income

[0000833444-25-000097:notes:253]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges (in millions):

[0000833444-25-000097:notes:254]
| Derivatives in Cash Flow Hedging Relationships |  | Year Ended September 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Foreign currency exchange derivatives |  | $ | 20 |  |  | $ | (1) |  |  | $ | (13) |  |
| Commodity derivatives |  | 3 |  |  | 5 |  |  | 1 |  |
| Interest rate swaps |  | — |  |  | (21) |  |  | 27 |  |
| Total |  | $ | 23 |  |  | $ | (17) |  |  | $ | 15 |  |

[0000833444-25-000097:notes:255]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income (in millions):

[0000833444-25-000097:notes:256]
| Derivatives in Cash FlowHedging Relationships |  | Location of Gain (Loss)Reclassified from AOCI into Income |  | Year Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 10 |  |  | $ | 1 |  |  | $ | (4) |  |
| Commodity derivatives |  | Cost of sales |  | 2 |  |  | — |  |  | (8) |  |
| Total |  |  |  | $ | 12 |  |  | $ | 1 |  |  | $ | (12) |  |

[0000833444-25-000097:notes:257]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income (in millions):

[0000833444-25-000097:notes:258]
| Derivatives Not Designatedas Hedging Instruments |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2025 |  | 2024 |  | 2023 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (1) |  |  | $ | (5) |  |  | $ | (16) |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | (92) |  |  | 43 |  |  | (103) |  |
| Foreign currency exchange derivatives |  | Selling, general and administrative |  | (3) |  |  | (1) |  |  | — |  |
| Interest rate swaps |  | Net financing charges |  | — |  |  | — |  |  | 1 |  |
| Total |  |  |  | $ | (96) |  |  | $ | 37 |  |  | $ | (118) |  |

[0000833444-25-000097:notes:259]
The following table presents pre-tax gains (losses) on net investment hedges recorded as foreign currency translation adjustments ("CTA") within other comprehensive income (loss) (in millions):

[0000833444-25-000097:notes:260]
|  | Year Ended September 30, |
| 2025 |  | 2024 |  | 2023 |
| Net investment hedges | $ | (159) |  |  | $ | (173) |  |  | $ | (223) |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-25-000097:notes:261]
FAIR VALUE MEASUREMENTS
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value (in millions):

[0000833444-25-000097:notes:262]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2025 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 63 |  |  | 63 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)(1) | 73 |  |  | 73 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)(1) | 217 |  |  | 217 |  |  | — |  |  | — |  |
| Total assets | $ | 368 |  |  | $ | 353 |  |  | $ | 15 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Contingent earn-out liabilities | 19 |  |  | — |  |  | — |  |  | 19 |  |
| Total liabilities | $ | 43 |  |  | $ | — |  |  | $ | 24 |  |  | $ | 19 |  |

[0000833444-25-000097:notes:263]
(1) Classified as restricted investments for payment of asbestos liabilities. Refer to Note 20, "Commitments and Contingencies," of the notes to consolidated financial statements for further details.

[0000833444-25-000097:notes:264]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2024 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 56 |  |  | 56 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)(1) | 81 |  |  | 81 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)(1) | 200 |  |  | 200 |  |  | — |  |  | — |  |
| Total assets | $ | 359 |  |  | $ | 337 |  |  | $ | 22 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 25 |  |  | $ | — |  |  | $ | 25 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Contingent earn-out liabilities | 14 |  |  | — |  |  | — |  |  | 14 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 14 |  |  | — |  |  | — |  |  | 14 |  |
| Total liabilities | $ | 54 |  |  | $ | — |  |  | $ | 26 |  |  | $ | 28 |  |

[0000833444-25-000097:notes:265]
Valuation Methods

[0000833444-25-000097:notes:266]
Commodity derivatives: The commodity derivatives are valued under a market approach using publicized prices, where available, or dealer quotes.

[0000833444-25-000097:notes:267]
Contingent earn-out liabilities: The contingent earn-out liabilities are generally established using a Monte Carlo simulation based on the forecasted operating results and the earn-out formulas specified in the purchase agreements.

[0000833444-25-000097:notes:268]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. Unrealized gains (losses) on the deferred compensation plan assets are recognized in the consolidated statements of income where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-25-000097:notes:269]
Exchange traded funds: Investments in exchange traded funds are valued using a market approach based on quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. Refer to Note 20, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-25-000097:notes:270]
Foreign currency exchange derivatives: The foreign currency exchange derivatives are valued under a market approach using publicized spot and forward prices.

[0000833444-25-000097:notes:271]
The following table presents the portion of unrealized gains recognized in the consolidated statements of income that relate to equity securities still held at September 30, 2025 and 2024 (in millions):

[0000833444-25-000097:notes:272]
|  |  | Year Ended September 30, |  |
|  | 2025 |  | 2024 |  |
| Deferred compensation plan assets |  | $ | 5 |  |  | $ | 10 |  |  |
| Investments in exchange traded funds |  | 29 |  |  | 58 |  |  |

[0000833444-25-000097:notes:273]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values.

[0000833444-25-000097:notes:274]
The fair value of long-term debt at September 30, 2025 and 2024 was as follows (in billions):

[0000833444-25-000097:notes:275]
|  |  | September 30, |  |
|  | 2025 |  | 2024 |  |
| Public debt |  | $ | 8.4 |  |  | $ | 8.1 |  |  |
| Other long-term debt |  | 0.5 |  |  | 0.2 |  |  |
| Total fair value of long-term debt |  | $ | 8.9 |  |  | $ | 8.3 |  |  |

[0000833444-25-000097:notes:276]
The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-25-000097:notes:277]
STOCK-BASED COMPENSATION
Unless otherwise noted, all activities and amounts reported in this footnote include both continuing operations of the Company and activities and amounts related to the R&LC HVAC business. See Note 2, "Acquisitions and Divestitures" for additional details regarding divestiture of the R&LC HVAC business.

[0000833444-25-000097:notes:278]
The Johnson Controls International plc 2021 Equity and Incentive Plan authorizes stock options, stock appreciation rights, restricted (non-vested) stock/units, performance shares, performance units and other stock-based awards. The Compensation and Talent Development Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Annual awards are typically granted in the first quarter of the fiscal year. As of September 30, 2025, there were 55 million shares of the Company's common stock reserved and 30 million shares available for issuance under the 2021 Equity and Incentive Plan.

[0000833444-25-000097:notes:279]
The following table summarizes stock-based compensation related charges and benefits (in millions):

[0000833444-25-000097:notes:280]
|  |  | Year Ended September 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Compensation expense |  | $ | 126 |  |  | $ | 100 |  |  | $ | 101 |  |
| Income tax benefit resulting from share-based compensation arrangements |  | 19 |  |  | 25 |  |  | 25 |  |
| Tax impact from exercise and vesting of equity settled awards |  | 14 |  |  | 1 |  |  | 7 |  |

[0000833444-25-000097:notes:281]
Substantially all compensation expense is recorded in selling, general and administrative expenses. The Company does not settle stock options granted under share-based payment arrangements in cash.

[0000833444-25-000097:notes:282]
Restricted (Non-vested) Stock / Units

[0000833444-25-000097:notes:283]
A summary of non-vested restricted stock awards at September 30, 2025, and changes for the year then ended, is presented below:

[0000833444-25-000097:notes:284]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toRestriction |
| Non-vested, September 30, 2024 | $ | 59.29 |  |  | 2,904,103 |  |
| Granted | 83.08 |  |  | 1,297,984 |  |
| Vested | 62.59 |  |  | (1,231,731) |  |
| Forfeited | 65.78 |  |  | (423,369) |  |
| Non-vested, September 30, 2025 | $ | 69.68 |  |  | 2,546,987 |  |

[0000833444-25-000097:notes:285]
At September 30, 2025, the Company had approximately $116 million of total unrecognized compensation cost related to non-vested restricted stock arrangements granted which is expected to be recognized over a weighted-average period of 1.8 years.

[0000833444-25-000097:notes:286]
Performance Share Awards (PSU's)

[0000833444-25-000097:notes:287]
The following table summarizes the assumptions used in determining the fair value of performance share awards granted:

[0000833444-25-000097:notes:288]
|  | Year Ended September 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Risk-free interest rate | 4.01% |  | 4.21% |  | 4.04% |
| Expected volatility of the Company’s stock | 28.50% |  | 27.20% |  | 33.50% |

[0000833444-25-000097:notes:289]
A summary of the status of the Company’s non-vested PSU's at September 30, 2025, and changes for the year then ended, is presented below:

[0000833444-25-000097:notes:290]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toPSU |
| Non-vested, September 30, 2024 | $ | 71.20 |  |  | 795,633 |  |
| Granted | 97.77 |  |  | 375,308 |  |
| Vested | 90.50 |  |  | (230,999) |  |
| Forfeited | 80.05 |  |  | (27,178) |  |
| Non-vested, September 30, 2025 | $ | 76.97 |  |  | 912,764 |  |

[0000833444-25-000097:notes:291]
At September 30, 2025, the Company had approximately $46 million of total unrecognized compensation cost related to non-vested performance-based share unit awards which is expected to be recognized over a weighted-average period of 2.0 years.

[0000833444-25-000097:notes:292]
The following table summarizes the assumptions used in determining the fair value of stock options granted:

[0000833444-25-000097:notes:293]
|  | Year Ended September 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Expected life of option (years) | 5.7 |  | 5.7 |  | 5.8 |
| Risk-free interest rate | 4.07% |  | 3.86% |  | 3.59% |
| Expected volatility of the Company’s stock | 30.20% |  | 29.80% |  | 29.40% |
| Expected dividend yield on the Company’s stock | 1.83% |  | 2.77% |  | 2.10% |

[0000833444-25-000097:notes:294]
A summary of stock option activity at September 30, 2025, and changes for the year then ended, is presented below:

[0000833444-25-000097:notes:295]
|  | WeightedAverageOption Price |  | SharesSubject toOption |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2024 | $ | 46.51 |  |  | 4,244,782 |  |  |  |  |  |
| Granted | 82.15 |  |  | 530,251 |  |  |  |  |  |
| Exercised | 39.99 |  |  | (2,812,821) |  |  |  |  |  |
| Forfeited or expired | 67.00 |  |  | (66,609) |  |  |  |  |  |
| Outstanding, September 30, 2025 | $ | 65.42 |  |  | 1,895,603 |  |  | 8.07 |  | $ | 84 |  |
| Exercisable, September 30, 2025 | $ | 62.05 |  |  | 688,036 |  |  | 7.31 |  | $ | 33 |  |

[0000833444-25-000097:notes:296]
The following table summarizes additional stock option information:

[0000833444-25-000097:notes:297]
|  |  | Year Ended September 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Weighted-average grant-date fair value of options granted |  | $ | 23.97 |  |  | $ | 13.74 |  |  | $ | 18.21 |  |
| Intrinsic value of options exercised (in millions) |  | 130 |  |  | 22 |  |  | 27 |  |

[0000833444-25-000097:notes:298]
At September 30, 2025, the Company had approximately $12 million of total unrecognized compensation cost related to non-vested stock options which is expected to be recognized over a weighted-average period of 1.6 years.


## us-gaap:EarningsPerShareTextBlock

[0000833444-25-000097:notes:299]
EARNINGS PER SHARE
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-25-000097:notes:300]
|  | Year Ended September 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Income Available to Ordinary Shareholders |  |  |  |  |  |
| Income from continuing operations | $ | 1,721 |  |  | $ | 1,407 |  |  | $ | 1,562 |  |
| Income from discontinued operations | 1,570 |  |  | 298 |  |  | 287 |  |
| Basic and diluted income available to shareholders | $ | 3,291 |  |  | $ | 1,705 |  |  | $ | 1,849 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |
| Basic weighted average shares outstanding | 651.8 |  |  | 673.8 |  |  | 684.3 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 2.3 |  |  | 2.2 |  |  | 3.1 |  |
| Diluted weighted average shares outstanding | 654.1 |  |  | 676.0 |  |  | 687.4 |  |
| Antidilutive Securities |  |  |  |  |  |
| Stock options and unvested restricted stock | 0.1 |  |  | 0.3 |  |  | 0.2 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000833444-25-000097:notes:301]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)
The following table includes changes attributable to both continuing and discontinued operations in AOCI attributable to Johnson Controls (in millions, net of tax):

[0000833444-25-000097:notes:302]
|  | Year Ended September 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Foreign currency translation adjustments |  |  |  |  |  |
| Balance at beginning of period | $ | (956) |  |  | $ | (970) |  |  | $ | (901) |  |
| Net adjustment for the period | 318 |  |  | 14 |  |  | (69) |  |
| Balance at end of period | (638) |  |  | (956) |  |  | (970) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |  |  |
| Balance at beginning of period | (4) |  |  | 15 |  |  | (11) |  |
| Current period changes in fair value | 21 |  |  | (17) |  |  | 19 |  |
| Reclassification to income (1) | (12) |  |  | (1) |  |  | 11 |  |
| Net tax impact | 1 |  |  | (1) |  |  | (4) |  |
| Balance at end of period | 6 |  |  | (4) |  |  | 15 |  |
| Pension and postretirement plans |  |  |  |  |  |
| Balance at beginning of period | (4) |  |  | — |  |  | 1 |  |
| Reclassification to income | (8) |  |  | (5) |  |  | (1) |  |
| Net tax impact | 2 |  |  | 1 |  |  | — |  |
| Balance at end of period | (10) |  |  | (4) |  |  | — |  |
| Accumulated other comprehensive loss, end of period | $ | (642) |  |  | $ | (964) |  |  | $ | (955) |  |

[0000833444-25-000097:notes:303]
(1) Refer to Note 10, "Derivative Instruments and Hedging Activities," of the notes to consolidated financial statements for disclosure of the line items in the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-25-000097:notes:304]
PENSION AND RETIREMENT PLANS
Unless otherwise noted, all activities and amounts reported in this footnote include both continuing operations of the Company and activities and amounts related to the R&LC HVAC business. See Note 2, "Acquisitions and Divestitures" for additional details regarding divestiture of the R&LC HVAC business.

[0000833444-25-000097:notes:305]
Pension Benefits

[0000833444-25-000097:notes:306]
The Company has non-contributory defined benefit pension plans covering certain U.S. and non-U.S. employees. The benefits provided are primarily based on years of service and average compensation or a monthly retirement benefit amount. The Company’s U.S. pension plans no longer allow new participants to enter the plans and no longer accrue benefits. Funding for U.S. pension plans equals or exceeds the minimum requirements of the Employee Retirement Income Security Act of 1974.

[0000833444-25-000097:notes:307]
Funding for non-U.S. plans observes the local legal and regulatory limits. Also, the Company makes contributions to union-trusteed pension funds for construction and service personnel.

[0000833444-25-000097:notes:308]
The following table includes information for pension plans with accumulated benefit obligations ("ABO") in excess of plan assets (in millions):

[0000833444-25-000097:notes:309]
|  |  | September 30, |  |
|  |  | 2025 |  | 2024 |  |
| Accumulated benefit obligation |  | $ | 1,758 |  |  | $ | 331 |  |  |
| Fair value of plan assets |  | 1,595 |  |  | 149 |  |  |

[0000833444-25-000097:notes:310]
The following table includes information for pension plans with projected benefit obligations ("PBO") in excess of plan assets (in millions):

[0000833444-25-000097:notes:311]
|  |  | September 30, |  |
|  |  | 2025 |  | 2024 |  |
| Projected benefit obligation |  | $ | 1,806 |  |  | $ | 344 |  |  |
| Fair value of plan assets |  | 1,607 |  |  | 163 |  |  |

[0000833444-25-000097:notes:312]
The Company contributed $31 million to the defined benefit plans in fiscal 2025 and expects to contribute approximately $21 million in cash in fiscal 2026. None of the contributions made by the Company were voluntary.

[0000833444-25-000097:notes:313]
Projected benefit payments from the plans as of September 30, 2025 are estimated as follows (in millions):

[0000833444-25-000097:notes:314]
| 2026 | $ | 259 |  |
| 2027 | 223 |  |
| 2028 | 218 |  |
| 2029 | 216 |  |
| 2030 | 217 |  |
| 2031 - 2035 | 1,051 |  |

[0000833444-25-000097:notes:315]
Postretirement Benefits

[0000833444-25-000097:notes:316]
The Company provides certain health care and life insurance benefits for eligible retirees and their dependents primarily in the U.S. and Canada. Most non-U.S. employees are covered by government sponsored programs. The cost to the Company is not significant.

[0000833444-25-000097:notes:317]
Eligibility for coverage is based on meeting certain years of service and retirement age qualifications. These benefits may be subject to deductibles, co-payment provisions and other limitations. The Company has reserved the right to modify these benefits.

[0000833444-25-000097:notes:318]
The health care cost trend assumption does not have a significant effect on the amounts reported.

[0000833444-25-000097:notes:319]
The following table includes information for postretirement plans with accumulated postretirement benefit obligations ("APBO") in excess of plan assets (in millions):

[0000833444-25-000097:notes:320]
|  |  | September 30, |  |
|  |  | 2025 |  | 2024 |  |
| Accumulated postretirement benefit obligation |  | $ | 48 |  |  | $ | 56 |  |  |
| Fair value of plan assets |  | 24 |  |  | 26 |  |  |

[0000833444-25-000097:notes:321]
Defined Contribution Plans

[0000833444-25-000097:notes:322]
The Company sponsors various defined contribution savings plans that allow employees to contribute a portion of their pre-tax and/or after-tax income in accordance with plan specified guidelines. Under specified conditions, the Company will contribute to certain savings plans based on predetermined percentages of compensation earned by the employee and/or will match a percentage of the employee contributions up to certain limits. Defined contribution plan contributions charged to expense amounted to $192 million, $208 million and $209 million during the years ended September 30, 2025, 2024 and 2023, respectively.

[0000833444-25-000097:notes:323]
Multiemployer Benefit Plans

[0000833444-25-000097:notes:324]
The Company contributes to multiemployer benefit plans based on obligations arising from collective bargaining agreements related to certain of its hourly employees in the U.S and Canada. These plans provide retirement benefits to participants based on their service to contributing employers. The benefits are paid from assets held in trust for that purpose. The trustees typically

[0000833444-25-000097:notes:325]
are responsible for determining the level of benefits to be provided to participants as well as for such matters as the investment of the assets and the administration of the plans.

[0000833444-25-000097:notes:326]
The risks of participating in these multiemployer benefit plans are different from single-employer benefit plans in the following aspects:

[0000833444-25-000097:notes:327]
•Assets contributed to the multiemployer benefit plan by one employer may be used to provide benefits to employees of other participating employers.

[0000833444-25-000097:notes:328]
•If a participating employer stops contributing to the multiemployer benefit plan, the unfunded obligations of the plan may be borne by the remaining participating employers.

[0000833444-25-000097:notes:329]
•If the Company stops participating in some of its multiemployer benefit plans, it may be required to pay those plans an amount based on its allocable share of the underfunded status of the plan, referred to as a withdrawal liability.

[0000833444-25-000097:notes:330]
The Company participates in approximately 245 multiemployer benefit plans, none of which are individually significant to the Company. The number of employees covered by the Company’s multiemployer benefit plans has remained consistent over the past three years, and there have been no significant changes that affect the comparability of fiscal 2025, 2024 and 2023 contributions. The Company recognizes expense for the contractually-required contribution for each period. The Company contributed $86 million, $80 million and $67 million to multiemployer benefit plans during the years ended September 30, 2025, 2024 and 2023, respectively.

[0000833444-25-000097:notes:331]
Based on the most recent information available, the Company believes that the present value of actuarial accrued liabilities in certain of these multiemployer benefit plans may exceed the value of the assets held in trust to pay benefits. Currently, the Company is not aware of any significant multiemployer benefit plans for which it is probable or reasonably possible that the Company will be obligated to make up any shortfall in funds. Moreover, if the Company were to exit certain markets or otherwise cease making contributions to these funds, the Company could trigger a withdrawal liability. Currently, the Company is not aware of any multiemployer benefit plans for which it is probable or reasonably possible that the Company will have a significant withdrawal liability. Any accrual for a shortfall or withdrawal liability will be recorded when it is probable that a liability exists and it can be reasonably estimated.

[0000833444-25-000097:notes:332]
Plan Assets

[0000833444-25-000097:notes:333]
The Company’s investment policies employ an approach whereby a mix of equities, fixed income and alternative investments are used to maximize the long-term return of plan assets for a prudent level of risk. The investment portfolio primarily contains a diversified blend of equity and fixed income investments. Equity investments are diversified across U.S. and non-U.S. stocks, as well as growth, value and small to large capitalization. Fixed income investments include corporate and government issues, with short-, mid- and long-term maturities, with a focus on investment grade when purchased and a target duration close to that of the plan liability. Investment and market risks are measured and monitored on an ongoing basis through regular investment portfolio reviews, annual liability measurements and periodic asset/liability studies. The majority of the real estate component of the portfolio is invested in a diversified portfolio of high-quality, operating properties with cash yields greater than the targeted appreciation. Investments in other alternative asset classes, including hedge funds, diversify the expected investment returns relative to the equity and fixed income investments. As a result of the Company's diversification strategies, there are no significant concentrations of risk within the portfolio of investments.

[0000833444-25-000097:notes:334]
The Company’s actual asset allocations are in line with target allocations. The Company rebalances asset allocations as appropriate, in order to stay within a range of allocation for each asset category.

[0000833444-25-000097:notes:335]
The expected return on plan assets is based on the Company’s expectation of the long-term average rate of return of the capital markets in which the plans invest. The average market returns are adjusted, where appropriate, for active asset management returns. The expected return reflects the investment policy target asset mix and considers the historical returns earned for each asset category.

[0000833444-25-000097:notes:336]
The Company’s plan assets at September 30, 2025 and 2024, by asset category, are as follows (in millions):

[0000833444-25-000097:notes:337]
|  |  | Fair Value Measurements Using: |
| Asset Category |  | Total as of September 30, 2025 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 43 |  |  | $ | — |  |  | $ | 43 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Large-Cap |  | 19 |  |  | 19 |  |  | — |  |  | — |  |
| Small-Cap |  | 19 |  |  | 19 |  |  | — |  |  | — |  |
| International - Developed |  | 49 |  |  | 49 |  |  | — |  |  | — |  |
| International - Emerging |  | 11 |  |  | 11 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 197 |  |  | 197 |  |  | — |  |  | — |  |
| Corporate/Other |  | 706 |  |  | 704 |  |  | 2 |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 1,044 |  |  | $ | 999 |  |  | $ | 45 |  |  | $ | — |  |
| Investments Measured at Net Asset Value(1) |  |  |  |  |  |  |  |  |
| Alternative |  | 193 |  |  |  |  |  |  |  |
| Real Estate |  | 230 |  |  |  |  |  |  |  |
| Due to Broker |  | (19) |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 1,448 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 18 |  |  | $ | 18 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Large-Cap |  | 185 |  |  | 5 |  |  | 180 |  |  | — |  |
| International - Developed |  | 91 |  |  | 5 |  |  | 86 |  |  | — |  |
| International - Emerging |  | 7 |  |  | — |  |  | 7 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 685 |  |  | 10 |  |  | 675 |  |  |  |
| Corporate/Other |  | 260 |  |  | 170 |  |  | 90 |  |  |  |
| Hedge Fund |  | — |  |  |  |  |  |  |  |
| Real Estate |  | 4 |  |  | 4 |  |  |  |  |  |
| Total Investments in the Fair Value Hierarchy |  | 1,250 |  |  | $ | 212 |  |  | $ | 1,038 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value(1) |  | 24 |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 1,274 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 1 |  |  | $ | 1 |  |  |  |  |  |
| Equity Securities - Global |  | 99 |  |  |  |  | 99 |  |  |  |
| Total Investments in the Fair Value Hierarchy |  | 100 |  |  | $ | 1 |  |  | $ | 99 |  |  | $ | — |  |
| Multi-Credit Strategy Investments Measured at Net Asset Value(1) |  | 75 |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 175 |  |  |  |  |  |  |  |

[0000833444-25-000097:notes:338]
|  |  | Fair Value Measurements Using: |
| Asset Category |  | Total as of September 30, 2024 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Large-Cap |  | 19 |  |  | 19 |  |  | — |  |  | — |  |
| Small-Cap |  | 23 |  |  | 23 |  |  | — |  |  | — |  |
| International - Developed |  | 45 |  |  | 45 |  |  | — |  |  | — |  |
| International - Emerging |  | 8 |  |  | 8 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 265 |  |  | 265 |  |  | — |  |  | — |  |
| Corporate/Other |  | 786 |  |  | 784 |  |  | 2 |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 1,169 |  |  | $ | 1,144 |  |  | $ | 25 |  |  | $ | — |  |
| Investments Measured at Net Asset Value(1) |  |  |  |  |  |  |  |  |
| Alternative |  | 235 |  |  |  |  |  |  |
| Real Estate |  | 266 |  |  |  |  |  |  |
| Due to Broker |  | (79) |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 1,591 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 42 |  |  | $ | 42 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Large-Cap |  | 88 |  |  | 9 |  |  | 79 |  |  | — |  |
| International - Developed |  | 64 |  |  | 10 |  |  | 54 |  |  | — |  |
| International - Emerging |  | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 789 |  |  | 26 |  |  | 763 |  |  | — |  |
| Corporate/Other |  | 417 |  |  | 282 |  |  | 135 |  |  | — |  |
| Hedge Fund |  | 22 |  |  | — |  |  | 22 |  |  | — |  |
| Real Estate |  | 11 |  |  | 11 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 1,436 |  |  | $ | 380 |  |  | $ | 1,056 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value(1) |  | 89 |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 1,525 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 3 |  |  | $ | 3 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities - Global |  | 89 |  |  | — |  |  | 89 |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 92 |  |  | $ | 3 |  |  | $ | 89 |  |  | $ | — |  |
| Multi-Credit Strategy Investments Measured at Net Asset Value(1) |  | 69 |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 161 |  |  |  |  |  |  |  |

[0000833444-25-000097:notes:339]
(1) The fair value of certain real estate, multi-credit strategy, and alternative investments do not have a readily determinable fair value and require the fund managers to independently arrive at fair value by calculating net asset value ("NAV") per share. In order to calculate NAV per share, the fund managers value the investments using any one, or a combination of, the following methods: independent third party appraisals, discounted cash flow analysis of net cash flows projected to be generated by the investment and recent sales of comparable investments. Assumptions used to revalue the investments are updated every quarter.

[0000833444-25-000097:notes:340]
Due to the fact that the fund managers calculate NAV per share, the Company utilizes a practical expedient for measuring the fair value of its real estate, multi-credit strategy, and alternative investments, as provided for under ASC 820, "Fair Value Measurement." In applying the practical expedient, the Company is not required to further adjust the NAV provided by the fund manager in order to determine the fair value of its investments as the NAV per share is calculated in a manner consistent with the measurement principles of ASC 946, "Financial Services - Investment Companies," and as of the Company's measurement date. The Company believes this is an appropriate methodology to obtain the fair value of these assets. The fair value amounts presented in these tables are intended to permit reconciliation of total plan assets to the amounts presented in the notes to consolidated financial statements.

[0000833444-25-000097:notes:341]
The following is a description of the valuation methodologies used for assets measured at fair value. Certain assets are held within commingled funds which are valued at the unitized NAV or percentage of the net asset value as determined by the manager of the fund. These values are based on the fair value of the underlying net assets owned by the fund.

[0000833444-25-000097:notes:342]
Cash and Cash Equivalents: The fair value of cash and cash equivalents is valued at cost.

[0000833444-25-000097:notes:343]
Equity Securities: The fair value of equity securities is determined by direct quoted market prices. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-25-000097:notes:344]
Fixed Income Securities: The fair value of fixed income securities is determined by direct or indirect quoted market prices. If indirect quoted market prices are utilized, the value of assets held in separate accounts is not published, but the investment managers report daily the underlying holdings. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-25-000097:notes:345]
Hedge Funds: The fair value of hedge funds is accounted for by the custodian. The custodian obtains valuations from underlying managers based on market quotes for the most liquid assets and alternative methods for assets that do not have sufficient trading activity to derive prices. The Company and custodian review the methods used by the underlying managers to value the assets. The Company believes this is an appropriate methodology to obtain the fair value of these assets.

[0000833444-25-000097:notes:346]
Real Estate: The fair value of real estate is determined by quoted market prices of the underlying Real Estate Investment Trusts

[0000833444-25-000097:notes:347]
("REITs"), which are securities traded on an open exchange.

[0000833444-25-000097:notes:348]
The methods described above may produce a fair value calculation that may not be indicative of net realizable value or reflective of future fair values. Furthermore, while the Company believes its valuation methods are appropriate and consistent with other market participants, the use of different methodologies or assumptions to determine the fair value of certain financial instruments could result in a different fair value measurement at the reporting date.

[0000833444-25-000097:notes:349]
Funded Status

[0000833444-25-000097:notes:350]
The following table contains the ABO and reconciliations of the changes in the PBO, the changes in plan assets and the funded status (in millions):

[0000833444-25-000097:notes:351]
|  | Pension Benefits |  | PostretirementBenefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| September 30, | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Accumulated Benefit Obligation | $ | 1,473 |  |  | $ | 1,603 |  |  | $ | 1,335 |  |  | $ | 1,563 |  |  | $ | 63 |  |  | $ | 73 |  |
| Change in Projected Benefit Obligation |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of year | $ | 1,603 |  |  | $ | 1,564 |  |  | $ | 1,617 |  |  | $ | 1,473 |  |  | $ | 73 |  |  | $ | 77 |  |
| Service cost | — |  |  | — |  |  | 17 |  |  | 17 |  |  | — |  |  | — |  |
| Interest cost | 65 |  |  | 79 |  |  | 64 |  |  | 69 |  |  | 3 |  |  | 4 |  |
| Plan participant contributions | — |  |  | — |  |  | 3 |  |  | 3 |  |  | 1 |  |  | 2 |  |
| Actuarial loss (gain) | (62) |  |  | 104 |  |  | (111) |  |  | 84 |  |  | (5) |  |  | 4 |  |
| Benefits and settlements paid | (133) |  |  | (144) |  |  | (96) |  |  | (132) |  |  | (9) |  |  | (13) |  |
| Divestitures | — |  |  | — |  |  | (131) |  |  | (5) |  |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | (3) |  |  | 2 |  |  | — |  |  | (1) |  |
| Currency translation adjustment | — |  |  | — |  |  | 14 |  |  | 106 |  |  | — |  |  | — |  |
| Projected benefit obligation at end of year | $ | 1,473 |  |  | $ | 1,603 |  |  | $ | 1,374 |  |  | $ | 1,617 |  |  | $ | 63 |  |  | $ | 73 |  |
| Change in Plan Assets |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 1,591 |  |  | $ | 1,499 |  |  | $ | 1,525 |  |  | $ | 1,388 |  |  | $ | 161 |  |  | $ | 144 |  |
| Actual return on plan assets | (12) |  |  | 234 |  |  | (25) |  |  | 137 |  |  | 20 |  |  | 26 |  |
| Employer and employee contributions | 2 |  |  | 2 |  |  | 32 |  |  | 26 |  |  | 3 |  |  | 4 |  |
| Benefits and settlements paid | (133) |  |  | (144) |  |  | (96) |  |  | (132) |  |  | (9) |  |  | (13) |  |
| Divestitures | — |  |  | — |  |  | (168) |  |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | (2) |  |  | 1 |  |  | — |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | 8 |  |  | 105 |  |  | — |  |  | — |  |
| Fair value of plan assets at end of year | $ | 1,448 |  |  | $ | 1,591 |  |  | $ | 1,274 |  |  | $ | 1,525 |  |  | $ | 175 |  |  | $ | 161 |  |
| Funded status | $ | (25) |  |  | $ | (12) |  |  | $ | (100) |  |  | $ | (92) |  |  | $ | 112 |  |  | $ | 88 |  |
| Amounts recognized in the consolidated statements of financial position consist of: |
| Other noncurrent assets | $ | 1 |  |  | $ | 2 |  |  | $ | 72 |  |  | $ | 62 |  |  | $ | 136 |  |  | $ | 118 |  |
| Noncurrent assets held for sale | — |  |  | — |  |  | — |  |  | 52 |  |  | — |  |  | — |  |
| Accrued compensation and benefits | (2) |  |  | (2) |  |  | (12) |  |  | (12) |  |  | (2) |  |  | (2) |  |
| Pension and postretirement benefit obligations | (24) |  |  | (12) |  |  | (157) |  |  | (166) |  |  | (22) |  |  | (28) |  |
| Noncurrent liabilities held for sale | — |  |  | — |  |  | (3) |  |  | (28) |  |  | — |  |  | — |  |
| Net amount recognized | $ | (25) |  |  | $ | (12) |  |  | $ | (100) |  |  | $ | (92) |  |  | $ | 112 |  |  | $ | 88 |  |
| Weighted Average Assumptions (1) |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate (2) | 4.98 | % |  | 4.60 | % |  | 5.17 | % |  | 4.35 | % |  | 4.77 | % |  | 4.50 | % |
| Rate of compensation increase | N/A |  | N/A |  | 2.91 | % |  | 3.01 | % |  | N/A |  | N/A |
| Interest crediting rate | N/A |  | N/A |  | 1.75 | % |  | 1.58 | % |  | N/A |  | N/A |

[0000833444-25-000097:notes:352]
(1) Plan assets and obligations are determined based on a September 30 measurement date at September 30, 2025 and 2024.

[0000833444-25-000097:notes:353]
(2) The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension and postretirement plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-

[0000833444-25-000097:notes:354]
U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for determining the various discount rates. The Company has elected to utilize a full yield curve approach in the estimation of service and interest components of net periodic benefit cost (credit) for pension and other postretirement for plans that utilize a yield curve approach. The full yield curve approach applies the specific spot rates along the yield curve used in the determination of the benefit obligation to the relevant projected cash flows.

[0000833444-25-000097:notes:355]
The fiscal 2025 net actuarial gains related to changes in the projected benefit obligation were primarily the result of the increase in discount rates globally. The fiscal 2024 net actuarial losses related to changes in the projected benefit obligation were primarily the result of the decrease in discount rates globally.

[0000833444-25-000097:notes:356]
Net Periodic Benefit Cost

[0000833444-25-000097:notes:357]
The following table contains the components of net periodic benefit costs, which are recorded in selling, general and administrative expenses or cost of sales consistent with the related employees' salaries in the consolidated statements of income (in millions):

[0000833444-25-000097:notes:358]
|  | Pension Benefits |  | Postretirement Benefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| Year ended September 30, | 2025 |  | 2024 |  | 2023 |  | 2025 |  | 2024 |  | 2023 |  | 2025 |  | 2024 |  | 2023 |
| Components of Net Periodic Benefit Cost (Credit): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 17 |  |  | $ | 17 |  |  | $ | 16 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 65 |  |  | 79 |  |  | 78 |  |  | 64 |  |  | 69 |  |  | 68 |  |  | 3 |  |  | 4 |  |  | 4 |  |
| Expected return on plan assets | (98) |  |  | (120) |  |  | (131) |  |  | (77) |  |  | (72) |  |  | (77) |  |  | (11) |  |  | (9) |  |  | (9) |  |
| Net actuarial (gain) loss | 48 |  |  | (9) |  |  | 28 |  |  | (2) |  |  | 22 |  |  | 86 |  |  | (14) |  |  | (14) |  |  | (5) |  |
| Settlement loss | — |  |  | — |  |  | 1 |  |  | (3) |  |  | — |  |  | 6 |  |  | — |  |  | — |  |  | — |  |
| Amortization of prior service credit | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (5) |  |  | (5) |  |  | (4) |  |
| Other | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (credit) | $ | 15 |  |  | $ | (50) |  |  | $ | (24) |  |  | $ | — |  |  | $ | 37 |  |  | $ | 99 |  |  | $ | (27) |  |  | $ | (24) |  |  | $ | (14) |  |
| Expense Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 4.60 | % |  | 5.48 | % |  | 5.08 | % |  | 4.35 | % |  | 4.72 | % |  | 4.36 | % |  | 4.50 | % |  | 5.42 | % |  | 4.92 | % |
| Expected return on plan assets | 6.50 | % |  | 8.50 | % |  | 8.25 | % |  | 5.44 | % |  | 5.26 | % |  | 5.02 | % |  | 6.64 | % |  | 6.62 | % |  | 6.64 | % |
| Rate of compensation increase | N/A |  | N/A |  | N/A |  | 3.01 | % |  | 2.90 | % |  | 3.00 | % |  | N/A |  | N/A |  | N/A |
| Interest crediting rate | 6.00 | % |  | 6.00 | % |  | N/A |  | 1.58 | % |  | 1.63 | % |  | 1.69 | % |  | N/A |  | N/A |  | N/A |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-25-000097:notes:359]
RESTRUCTURING AND RELATED COSTS
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to restructuring plans as necessary. Restructuring activities generally result in charges for workforce reductions, plant closures, asset impairments and other related costs which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The Company expects the restructuring actions to reduce cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-25-000097:notes:360]
During the fourth quarter of fiscal 2024, the Company completed its previous restructuring plan and committed to a new multi-year restructuring plan to address stranded costs and further right-size its global operations as a result of previously announced portfolio simplification actions. It is expected that one-time restructuring costs, including severance and other employee termination benefits, contract termination costs, and certain other related cash and non-cash charges, of approximately $400 million will be incurred over the course of fiscal 2025, 2026 and 2027. Restructuring costs will be incurred across all segments and Corporate functions.

[0000833444-25-000097:notes:361]
The following table summarizes restructuring and related costs (in millions):

[0000833444-25-000097:notes:362]
|  |  |  | Year Ended September 30, 2025 |  |
| Americas |  |  | $ | 51 |  |  |
| EMEA |  |  | 49 |  |  |
| APAC |  |  | 17 |  |  |
| Corporate |  |  | 47 |  |  |
| Total |  |  | $ | 164 |  |  |

[0000833444-25-000097:notes:363]
The following table summarizes changes in the reserve under the Company's restructuring plan announced in the fourth quarter of fiscal 2024, which is included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-25-000097:notes:364]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  | Total |
| Restructuring and related costs | $ | 100 |  |  | $ | 40 |  |  | $ | 24 |  |  |  |  | $ | 164 |  |
| Utilized—cash | (69) |  |  | — |  |  | (18) |  |  |  |  | (87) |  |
| Utilized—noncash | — |  |  | (40) |  |  | — |  |  |  |  | (40) |  |
| Other | 8 |  |  | — |  |  | (1) |  |  |  |  | 7 |  |
| Balance at September 30, 2025 | $ | 39 |  |  | $ | — |  |  | $ | 5 |  |  |  |  | $ | 44 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-25-000097:notes:365]
INCOME TAXES
The components of the Company’s income tax provision from continuing operations are as follows (in millions):

[0000833444-25-000097:notes:366]
|  | 2025 |  | 2024 |  | 2023 |
| Tax expense at Ireland statutory rate of 12.5% | $ | 246 |  |  | $ | 190 |  |  | $ | 139 |  |
| U.S. state income tax, net of federal benefit | 60 |  |  | 42 |  |  | 30 |  |
| Income subject to the U.S. federal tax rate | 117 |  |  | 63 |  |  | 42 |  |
| Income subject to rates different than the statutory rate | (181) |  |  | (204) |  |  | 44 |  |
| Reserve and valuation allowance adjustments | 14 |  |  | (139) |  |  | (559) |  |
| Intellectual property transactions and adjustments | — |  |  | — |  |  | (176) |  |
| Impact of acquisitions and divestitures | — |  |  | 121 |  |  | — |  |
| Restructuring and impairment costs | (11) |  |  | 38 |  |  | 12 |  |
| Income tax provision (benefit) | $ | 245 |  |  | $ | 111 |  |  | $ | (468) |  |
| Effective tax rate | 12 | % |  | 7 | % |  | (42) | % |

[0000833444-25-000097:notes:367]
For fiscal 2025, the effective tax rate for continuing operations was 12% and was lower than the statutory tax rate primarily due to the favorable impact of impairment and restructuring charges and the benefits of continuing global tax planning initiatives, partially offset by the unfavorable impact of tax audit resolutions.

[0000833444-25-000097:notes:368]
For fiscal 2024, the effective tax rate for continuing operations was 7% and was lower than the statutory tax rate primarily due to tax reserve adjustments as the result of tax audit resolutions and expired statute of limitations for certain tax years, valuation allowance adjustments and the benefits of continuing global tax planning initiatives, partially offset by the establishment of a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries as a result of the planned divestiture of its R&LC HVAC business and the unfavorable impact of impairment and restructuring charges.

[0000833444-25-000097:notes:369]
For fiscal 2023, the effective tax rate for continuing operations was (42)% and was lower than the statutory tax rate primarily due to the favorable tax impacts of intellectual property tax adjustments, tax reserve adjustments as the result of tax audit resolutions and remeasurements, valuation allowance adjustments and the benefits of continuing global tax planning initiatives, partially offset by the unfavorable impact of impairment and restructuring charges.

[0000833444-25-000097:notes:370]
Valuation Allowances

[0000833444-25-000097:notes:371]
The Company reviews the realizability of its deferred tax assets and related valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-25-000097:notes:372]
In fiscal 2024, due to changes in forecasted taxable income, the Company determined that it was more likely than not that certain deferred tax assets of Mexico and Germany would be realized. The valuation allowance adjustment resulted in a tax benefit of $48 million.

[0000833444-25-000097:notes:373]
In fiscal 2023, due to changes in forecasted taxable income, the Company determined that it was more likely than not that certain deferred tax assets of Canada, Mexico, and Spain would be realized. The valuation allowance adjustment resulted in a tax benefit of $121 million.

[0000833444-25-000097:notes:374]
The following table summarizes changes in the valuation allowance (in millions):

[0000833444-25-000097:notes:375]
|  | 2025 |  | 2024 |  | 2023 |
| Balance at beginning of period | $ | 6,258 |  |  | $ | 6,279 |  |  | $ | 5,906 |  |
| Allowance provision for new operating and other loss carryforwards | 134 |  |  | 215 |  |  | 544 |  |
| Allowance reductions | (136) |  |  | (236) |  |  | (171) |  |
| Balance at end of period | $ | 6,256 |  |  | $ | 6,258 |  |  | $ | 6,279 |  |

[0000833444-25-000097:notes:376]
Uncertain Tax Positions

[0000833444-25-000097:notes:377]
The Company is subject to income taxes in the U.S. and numerous non-U.S. jurisdictions. Judgment is required in determining the worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-25-000097:notes:378]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0000833444-25-000097:notes:379]
|  | 2025 |  | 2024 |  | 2023 |
| Beginning balance, October 1 | $ | 2,053 |  |  | $ | 2,158 |  |  | $ | 2,485 |  |
| Additions for tax positions related to the current year | 62 |  |  | 39 |  |  | 59 |  |
| Additions for tax positions of prior years | 21 |  |  | 53 |  |  | 89 |  |
| Reductions for tax positions of prior years | (62) |  |  | (35) |  |  | (23) |  |
| Settlements with taxing authorities | (65) |  |  | (35) |  |  | (6) |  |
| Statute closings and audit resolutions | (82) |  |  | (127) |  |  | (446) |  |
| Ending balance, September 30 | $ | 1,927 |  |  | $ | 2,053 |  |  | $ | 2,158 |  |

[0000833444-25-000097:notes:380]
The following table summarizes tax effected unrecognized tax benefits that, if recognized, would impact the effective tax rate and the related accrued interest, net of tax benefit (in millions):

[0000833444-25-000097:notes:381]
|  | September 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Tax effected unrecognized tax benefits that, if recognized, would affect the effective tax rate | $ | 1,427 |  |  | $ | 1,466 |  |  | $ | 1,533 |  |
| Net accrued interest | 459 |  |  | 398 |  |  | 329 |  |

[0000833444-25-000097:notes:382]
In the U.S., fiscal years 2019 through 2020 are currently under audit and fiscal years 2017 through 2018 are currently under appeal with the Internal Revenue Service (“IRS”) for certain legal entities.  Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions for continuing operations:

[0000833444-25-000097:notes:383]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2016 - 2017; 2019-2020 |
| Germany |  | 2007 - 2021 |
| Mexico |  | 2016; 2018 - 2019 |
| United Kingdom |  | 2014 - 2015; 2018; 2020 - 2021 |

[0000833444-25-000097:notes:384]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-25-000097:notes:385]
Other Tax Matters

[0000833444-25-000097:notes:386]
During fiscal 2025, 2024 and 2023, the Company incurred charges for restructuring and impairment costs of $546 million, $510 million and $1,049 million, which generated tax benefits of $80 million, $26 million and $120 million, respectively.

[0000833444-25-000097:notes:387]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-25-000097:notes:388]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBB”) was signed into law by the president of the United States. It includes a broad range of tax reform provisions affecting businesses, including extending and modifying certain key Tax Cuts & Jobs Act provisions (both U.S. and non-U.S.), and expanding certain Inflation Reduction Act incentives while accelerating the phase-out of others. The impact on tax expense in the 2025 fiscal year is not material and the Company does not anticipate the OBBB to have a material impact on tax expense in subsequent years.

[0000833444-25-000097:notes:389]
On December 18, 2023, the president of Ireland signed into law the Finance (No. 2) Bill 2023, which included legislation regarding the implementation of the Pillar Two global minimum tax. The Pillar Two legislation went into effect for the Company’s 2025 fiscal year. The impact on tax expense in the 2025 fiscal year is not material.

[0000833444-25-000097:notes:390]
On September 11, 2023, the Schaffhausen parliament approved a partial revision of the cantonal act on direct taxation: Immediate Minimum Taxation Measure (“IMTM”). On November 19, 2023, IMTM was approved in a public referendum in the canton of Schaffhausen, was published in the cantonal official gazette on December 8, 2023, and was effective starting January 1, 2024. The IMTM increased Switzerland's combined statutory income tax rate to approximately 15%. As a result, in fiscal 2024, the Company recorded a noncash discrete net tax benefit of $80 million due to the remeasurement of deferred tax assets and liabilities related to Switzerland and the canton of Schaffhausen.

[0000833444-25-000097:notes:391]
During fiscal 2025, 2024 and 2023, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-25-000097:notes:392]
Selected Income Tax Data

[0000833444-25-000097:notes:393]
Selected income tax data related to continuing operations were as follows (in millions):

[0000833444-25-000097:notes:394]
|  | 2025 |  | 2024 |  | 2023 |
| Components of income (loss) from continuing operations before income taxes: |  |  |  |  |  |
| U.S. | $ | (309) |  |  | $ | (406) |  |  | $ | (325) |  |
| Non-U.S. | 2,278 |  |  | 1,928 |  |  | 1,438 |  |
| Income from continuing operations before income taxes | $ | 1,969 |  |  | $ | 1,522 |  |  | $ | 1,113 |  |
| Components of the provision (benefit) for income taxes: |  |  |  |  |  |
| Current |  |  |  |  |  |
| U.S. federal | $ | (239) |  |  | $ | 330 |  |  | $ | (201) |  |
| U.S. state | (12) |  |  | 86 |  |  | 94 |  |
| Non-U.S. | 302 |  |  | 102 |  |  | 289 |  |
|  | 51 |  |  | 518 |  |  | 182 |  |
| Deferred |  |  |  |  |  |
| U.S. federal | 385 |  |  | (299) |  |  | (267) |  |
| U.S. state | 79 |  |  | (26) |  |  | (25) |  |
| Non-U.S. | (270) |  |  | (82) |  |  | (358) |  |
|  | 194 |  |  | (407) |  |  | (650) |  |
| Income tax provision (benefit) | $ | 245 |  |  | $ | 111 |  |  | $ | (468) |  |
| Income taxes paid (1) | $ | 606 |  |  | $ | 704 |  |  | $ | 294 |  |

[0000833444-25-000097:notes:395]
(1) The Company also paid $1.4 billion of taxes related to the operation and disposition of the Residential & Light Commercial HVAC Business, which is reported through Discontinued Operations.

[0000833444-25-000097:notes:396]
At September 30, 2025 and 2024, the Company recorded within the consolidated statements of financial position in other current assets approximately $562 million and $100 million, respectively, of income tax assets. At September 30, 2025 and 2024, the Company recorded within the consolidated statements of financial position in other current liabilities approximately $176 million and $211 million, respectively, of accrued income tax liabilities.

[0000833444-25-000097:notes:397]
At September 30, 2025, the Company has not provided U.S. or non-U.S. income taxes on approximately $22.7 billion of outside basis differences of consolidated subsidiaries of Johnson Controls International plc. The Company is indefinitely reinvested in these basis differences. The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income. The Company's intent is to reduce the outside basis differences only when it would be tax efficient. Given the numerous ways in which the basis differences may be reduced, it is not practicable to estimate the amount of unrecognized withholding taxes and deferred tax liability on the outside basis differences.

[0000833444-25-000097:notes:398]
Deferred taxes were classified in the consolidated statements of financial position as follows (in millions):

[0000833444-25-000097:notes:399]
|  | September 30, |
|  | 2025 |  | 2024 |
| Other noncurrent assets | $ | 1,777 |  |  | $ | 1,969 |  |
| Other noncurrent liabilities | (185) |  |  | (301) |  |
| Net deferred tax asset | $ | 1,592 |  |  | $ | 1,668 |  |

[0000833444-25-000097:notes:400]
Temporary differences and carryforwards which gave rise to deferred tax assets and liabilities included (in millions):

[0000833444-25-000097:notes:401]
|  | September 30, |
|  | 2025 |  | 2024 |
| Deferred tax assets |  |  |  |
| Accrued expenses and reserves | $ | 424 |  |  | $ | 661 |  |
| Employee and retiree benefits | 38 |  |  | 43 |  |
| Property, plant and equipment | 522 |  |  | 729 |  |
| Net operating loss and other credit carryforwards | 6,963 |  |  | 6,628 |  |
| Research and development | 233 |  |  | 219 |  |
| Intangible assets | 137 |  |  | 306 |  |
| Operating lease liabilities | 327 |  |  | 294 |  |
| Other, net | 315 |  |  | 455 |  |
|  | 8,959 |  |  | 9,335 |  |
| Valuation allowances | (6,256) |  |  | (6,258) |  |
|  | 2,703 |  |  | 3,077 |  |
| Deferred tax liabilities |  |  |  |
| Subsidiaries, joint ventures and partnerships | 193 |  |  | 440 |  |
| Operating lease right-of-use assets | 327 |  |  | 294 |  |
| Other liabilities | 591 |  |  | 675 |  |
|  | 1,111 |  |  | 1,409 |  |
| Net deferred tax asset | $ | 1,592 |  |  | $ | 1,668 |  |

[0000833444-25-000097:notes:402]
At September 30, 2025, the Company had available net operating loss carryforwards of approximately $26.1 billion, of which $15.7 billion will expire at various dates between 2026 and 2045, and the remainder has an indefinite carryforward period. The Company had available U.S. foreign tax credit carryforwards at September 30, 2025 of $35 million which will expire in 2029. The valuation allowance, generally, is for loss and credit carryforwards for which realization is uncertain because it is unlikely that the losses and/or credits will be realized given the lack of sustained profitability and/or limited carryforward periods in certain countries.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-25-000097:notes:403]
SEGMENT INFORMATION
On April 1, 2025, the Company, as part of ongoing initiatives to drive simplification, accelerate growth, better reflect its organizational and operational structure and align with the manner in which the Company's chief operating decision maker ("CODM") assesses performance and makes decisions regarding the allocation of resources following portfolio simplification actions, realigned into three reportable segments (Americas, EMEA and APAC).

[0000833444-25-000097:notes:404]
The Company conducts its business through three operating segments, all of which are reportable segments:

[0000833444-25-000097:notes:405]
•Americas, which designs, manufactures, sells, installs and services HVAC, controls, building management, refrigeration, integrated electronic security systems, integrated fire detection and suppression systems, and digital (software) solutions for commercial, industrial, data center, institutional and governmental customers in the Americas (United States, Canada, and Latin America – Central and South America). Americas also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems, as well as data-driven "smart building" solutions, to the Americas marketplace.

[0000833444-25-000097:notes:406]
•EMEA, which designs, manufactures sells, installs and services HVAC, controls, building management, refrigeration, integrated electronic security systems, integrated fire detection and suppression systems, and digital (software) solutions for commercial, residential security (Subscriber business), industrial, data center, institutional, governmental, and marine customers and provides technical services, including data-driven “smart building” solutions, to markets in Europe, the Middle East and Africa.

[0000833444-25-000097:notes:407]
•APAC, which designs, manufactures, sells, installs, and services HVAC, controls, building management, refrigeration, integrated electronic security systems, integrated fire detection and suppression systems, and digital (software) solutions for commercial, industrial, data center, institutional, and governmental customers and provides technical services, including data-driven “smart building” solutions, to the Asian and Pacific marketplaces.

[0000833444-25-000097:notes:408]
The Chief Executive Officer, the Company’s CODM, evaluates the performance of its segments and allocates resources based on two profitability measures, Segment EBITA and Segment EBIT:

[0000833444-25-000097:notes:409]
•Segment earnings before interest, taxes, and amortization (“EBITA”) represents income from continuing operations, before income taxes and noncontrolling interests, excluding corporate expenses, restructuring and impairment costs, AFFF related settlement costs and insurance recoveries, gains or losses on divestitures, net mark-to-market gains and losses related to pension and post-retirement plans and restricted asbestos investments, net finance charges, and amortization.  Segment EBITA is used as a tool to allow the CODM to evaluate the recurring profitability of the segments, including revenues and expenses that are within the operational control of the segments, and excluding the impact of certain non-cash and non-recurring items. Segment EBITA also provides the CODM with performance comparability across periods and for more accurate benchmarking against peer companies that may not have similar historical acquisition activity, by holding constant the impact of significant acquisitions.

[0000833444-25-000097:notes:410]
•Segment earnings before interest and taxes ("EBIT") represents Segment EBITA, adding back the impact of amortization of intangible assets. Segment EBIT allows the CODM to review profitability, inclusive of the impact of significant acquisition activity, informing the CODM of how the business is integrating key strategic initiatives and generating synergies.

[0000833444-25-000097:notes:411]
Both EBITA and EBIT are reviewed by the CODM and compared against the profit plan and forecast for the current and prior year. Segment EBITA and Segment EBIT are not defined under GAAP and may not be comparable to similarly titled measures used by other companies. Measures of total assets by reportable segment are not provided to the CODM. Therefore, asset information by segment is not disclosed.

[0000833444-25-000097:notes:412]
Financial information relating to the Company’s reportable segments is as follows (in millions):

[0000833444-25-000097:notes:413]
|  | Year Ended September 30, 2025 |
|  | Americas |  | EMEA |  | APAC |
| Net sales | $ | 15,831 |  |  | $ | 4,968 |  |  | $ | 2,797 |  |
| Cost of sales | 9,742 |  | 3,228 |  | 1,777 |
| Selling, general and administrative expenses | 3,206 |  | 1,094 |  | 548 |
| Equity income (loss) | 1 |  | (3) |  |  | (4) |  |
| Segment EBITA | 2,882 |  | 649 |  | 476 |
| Amortization of intangible assets | 356 |  |  | 68 |  |  | 15 |  |
| Segment EBIT | $ | 2,526 |  |  | $ | 581 |  |  | $ | 461 |  |

[0000833444-25-000097:notes:414]
|  | Year Ended September 30, 2024 |
|  | Americas |  | EMEA |  | APAC |
| Net sales | $ | 15,606 |  |  | $ | 4,620 |  |  | $ | 2,726 |  |
| Cost of sales | 9,922 |  |  | 3,024 |  |  | 1,692 |  |
| Selling, general and administrative expenses | 3,003 |  |  | 996 |  |  | 558 |  |
| Equity income (loss) | 2 |  |  | 39 |  |  | (2) |  |
| Segment EBITA | 2,679 |  |  | 561 |  |  | 478 |  |
| Amortization of intangible assets | 379 |  |  | 80 |  |  | 17 |  |
| Segment EBIT | $ | 2,300 |  |  | $ | 481 |  |  | $ | 461 |  |

[0000833444-25-000097:notes:415]
|  | Year Ended September 30, 2023 |
|  | Americas |  | EMEA |  | APAC |
| Net sales | $ | 14,529 |  |  | $ | 4,491 |  |  | $ | 3,311 |  |
| Cost of sales | 9,241 |  |  | 3,035 |  |  | 2,102 |  |
| Selling, general and administrative expenses | 2,945 |  |  | 1,039 |  |  | 602 |  |
| Equity income (loss) | — |  |  | (1) |  |  | (2) |  |
| Segment EBITA | 2,343 |  |  | 418 |  |  | 609 |  |
| Amortization of intangible assets | 337 |  |  | 74 |  |  | 15 |  |
| Segment EBIT | $ | 2,006 |  |  | $ | 344 |  |  | $ | 594 |  |

[0000833444-25-000097:notes:416]
A reconciliation of segment EBIT and segment EBITA to consolidated income before income taxes is as follows (in millions):

[0000833444-25-000097:notes:417]
|  | Year Ended September 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Segment EBITA | $ | 4,007 |  |  | $ | 3,718 |  |  | $ | 3,370 |  |
| Amortization of intangible assets | 439 |  |  | 476 |  |  | 426 |  |
| Segment EBIT | 3,568 |  |  | 3,242 |  |  | 2,944 |  |
| Corporate expenses | 767 |  |  | 490 |  |  | 429 |  |
| Restructuring and impairment costs | 546 |  |  | 510 |  |  | 1,049 |  |
| Water systems AFFF settlement (1) | — |  |  | 750 |  |  | — |  |
| Water systems AFFF insurance recoveries (1) | (39) |  |  | (367) |  |  | — |  |
| Net financing charges | 319 |  |  | 342 |  |  | 258 |  |
| Loss on divestiture | — |  |  | 42 |  |  | — |  |
| Net mark-to-market adjustments | 6 |  |  | (47) |  |  | 95 |  |
| Income from continuing operations before income taxes | $ | 1,969 |  |  | $ | 1,522 |  |  | $ | 1,113 |  |

[0000833444-25-000097:notes:418]
(1)Refer to Note 20, "Commitments and Contingencies," of the notes to consolidated financial statements for further disclosure related to the water systems AFFF settlement and insurance recoveries.

[0000833444-25-000097:notes:419]
|  | Year Ended September 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Depreciation/Amortization |  |  |  |  |  |
| Americas | $ | 490 |  |  | $ | 528 |  |  | $ | 528 |  |
| EMEA | 115 |  |  | 132 |  |  | 129 |  |
| APAC | 36 |  |  | 37 |  |  | 43 |  |
|  | 641 |  |  | 697 |  |  | 700 |  |
| Corporate | 224 |  |  | 119 |  |  | 45 |  |
| Total | $ | 865 |  |  | $ | 816 |  |  | $ | 745 |  |

[0000833444-25-000097:notes:420]
|  | Year Ended September 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Capital Expenditures |  |  |  |  |  |
| Americas | $ | 151 |  |  | $ | 190 |  |  | $ | 197 |  |
| EMEA | 16 |  |  | 34 |  |  | 51 |  |
| APAC | 109 |  |  | 102 |  |  | 148 |  |
|  | 276 |  |  | 326 |  |  | 396 |  |
| Corporate | 158 |  |  | 168 |  |  | 50 |  |
| Total | $ | 434 |  |  | $ | 494 |  |  | $ | 446 |  |

[0000833444-25-000097:notes:421]
In fiscal 2025, 2024 and 2023, no customer exceeded 10% of consolidated net sales.

[0000833444-25-000097:notes:422]
Geographic Areas

[0000833444-25-000097:notes:423]
Financial information relating to the Company’s operations by geographic area is as follows (in millions):

[0000833444-25-000097:notes:424]
|  | Year Ended September 30, |
|  | 2025 |  | 2024 |  | 2023 |
| Net Sales |  |  |  |  |  |
| United States | $ | 13,303 |  |  | $ | 13,171 |  |  | $ | 12,408 |  |
| Other Non-United States | 10,293 |  |  | 9,781 |  |  | 9,923 |  |
| Total | $ | 23,596 |  |  | $ | 22,952 |  |  | $ | 22,331 |  |
| Long-Lived Assets (Year-end) |  |  |  |  |  |
| United States | $ | 1,108 |  |  | $ | 1,137 |  |  | $ | 1,277 |  |
| Other Non-United States | 1,085 |  |  | 1,266 |  |  | 1,097 |  |
| Total | $ | 2,193 |  |  | $ | 2,403 |  |  | $ | 2,374 |  |

[0000833444-25-000097:notes:425]
Net sales attributed to geographic locations are based on the location of where the sale originated. Long-lived assets by geographic location consist of net property, plant and equipment.


## us-gaap:GuaranteesTextBlock

[0000833444-25-000097:notes:426]
GUARANTEES
Certain of the Company's subsidiaries at the business segment level guarantee the performance of third-parties and provide financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance. Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-25-000097:notes:427]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. Generally, the Company's warranties require the repair or replacement of defective products within a specified time period from the date of sale. The following table summarizes changes in the total product warranty liability (in millions).

[0000833444-25-000097:notes:428]
|  | Year Ended September 30, |
|  | 2025 |  | 2024 |
| Balance at beginning of period | $ | 122 |  |  | $ | 91 |  |
| Accruals for warranties issued during the period | 97 |  |  | 85 |  |
| Settlements made (in cash or in kind) during the period | (99) |  |  | (87) |  |
| Changes in estimates to pre-existing warranties | — |  |  | 31 |  |
| Currency translation | — |  |  | 2 |  |
| Balance at end of period | $ | 120 |  |  | $ | 122 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-25-000097:notes:429]
COMMITMENTS AND CONTINGENCIES
Environmental Matters

[0000833444-25-000097:notes:430]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-25-000097:notes:431]
|  | September 30, |
|  | 2025 |  | 2024 |
| Other current liabilities | $ | 27 |  |  | $ | 32 |  |
| Other noncurrent liabilities | 160 |  |  | 179 |  |
| Total reserves for environmental liabilities | $ | 187 |  |  | $ | 211 |  |

[0000833444-25-000097:notes:432]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

[0000833444-25-000097:notes:433]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). Tyco Fire Products has discontinued the production and sale of fluorinated firefighting foams, including AFFF products, and has transitioned to non-fluorinated foam alternatives.

[0000833444-25-000097:notes:434]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. In April 2024, EPA published National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBS. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meet the statutory definition of hazardous waste. In April 2024, EPA finalized a rule designating PFOA and PFOS, along with their salts and structural isomers, as "hazardous substances" under the Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In May 2025, EPA announced that it will retain the 4.0 ppt limit on PFOS and PFOA but will institute a two-year delay in the compliance deadline from 2029 until 2031. EPA also announced its intent to rescind and reconsider the limits on four other types of PFAS (PFHxS, PFNA, HFPO-DA, and PFBS).

[0000833444-25-000097:notes:435]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of

[0000833444-25-000097:notes:436]
other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-25-000097:notes:437]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $7 million at both September 30, 2025 and 2024, respectively.

[0000833444-25-000097:notes:438]
FTC-Related Matters

[0000833444-25-000097:notes:439]
FTC and Stanton Street Remediation

[0000833444-25-000097:notes:440]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere.

[0000833444-25-000097:notes:441]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

[0000833444-25-000097:notes:442]
Tyco Fire Products is operating and monitoring at the FTC a Groundwater Extraction and Treatment System ("GETS"), a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. The Company is also continuing to replace private drinking water wells that may have been impacted by PFAS migrating from the FTC. The Company's reserves for continued remediation of the FTC, the Stanton Street Facility and surrounding areas in Marinette and Peshtigo are based on estimates of costs associated with the long-term remediation actions, including the continued operation of the GETS, the implementation of long-term drinking water solutions for the area impacted by groundwater migrating from the FTC, continued monitoring and testing of groundwater monitoring wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

[0000833444-25-000097:notes:443]
FTC-Related Litigation

[0000833444-25-000097:notes:444]
Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022. In August 2024, WDNR issued a new proposed rule to adopt the EPA Maximum Contaminant Levels for PFAS in drinking water.  In February 2025, the Wisconsin Department of Health Services ("WDHS") recommended individual groundwater enforcement standards of 4 ng/L for PFOA and PFOS, 10 ng/L for PFHxS, PFNA, and HFPO-DA, and 2,000 ng/L for PFBS. Following the February 2025 WDHS recommendation, the WDNR Secretary and the Governor signed the WDNR scope statement and WDNR is in the early stages of rule development for enforcement standards for these six PFAS constituents.

[0000833444-25-000097:notes:445]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a “Notice of

[0000833444-25-000097:notes:446]
Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions, including the potential assessment of penalties.

[0000833444-25-000097:notes:447]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties have completed briefing of summary judgment and pretrial motions. The Court has continued the trial previously scheduled for March 3, 2025 and has not yet set a new trial date. The parties are actively working toward the finalization of a settlement to resolve the matter.

[0000833444-25-000097:notes:448]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina.

[0000833444-25-000097:notes:449]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. Subsequently, several additional plaintiffs have direct-filed in the MDL complaints with similar allegations.

[0000833444-25-000097:notes:450]
The Company is vigorously defending each of these cases and believes that it has meritorious defenses, but it is presently unable to predict the duration, scope, or outcome of these actions.

[0000833444-25-000097:notes:451]
Aqueous Film-Forming Foam ("AFFF") Matters

[0000833444-25-000097:notes:452]
AFFF Litigation

[0000833444-25-000097:notes:453]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-25-000097:notes:454]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one

[0000833444-25-000097:notes:455]
jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to the MDL. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-25-000097:notes:456]
AFFF Municipal and Water Provider Cases

[0000833444-25-000097:notes:457]
Chemguard and Tyco Fire Products have been named as defendants in more than 280 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 36 states and territories. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation.

[0000833444-25-000097:notes:458]
Tyco Fire Products and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-25-000097:notes:459]
Water Systems AFFF Settlement Agreement

[0000833444-25-000097:notes:460]
On April 12, 2024, Tyco Fire Products agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. The settlement releases these claims against Tyco Fire Products, Chemguard, and other related corporate entities. In accordance with the terms of the settlement agreement, Tyco Fire Products made its final required payment of $415 million in December 2024 and has now paid the full settlement amount.

[0000833444-25-000097:notes:461]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of damages alleged to be related to the historical use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.

[0000833444-25-000097:notes:462]
The settlement does not constitute an admission of liability or wrongdoing by Tyco Fire Products or Chemguard.

[0000833444-25-000097:notes:463]
AFFF Putative Class Actions

[0000833444-25-000097:notes:464]
Chemguard and Tyco Fire Products are named in 49 pending putative class actions in federal courts originating from 20 states and territories. All of these cases have been direct-filed in or transferred to the MDL. In addition, seven proposed class actions were filed in Canada (British Columbia, Manitoba, Quebec and Ontario), which name Tyco Fire Products and other manufacturers as defendants, on behalf of various classes of members (including individuals and government entities) who seek to recover for remediation (past and future) costs, claim property or other environmental damages, or claim personal injuries or other harms arising from alleged exposure to or contamination with PFAS or PFAS-containing products (including AFFF).

[0000833444-25-000097:notes:465]
AFFF Individual or Mass Actions

[0000833444-25-000097:notes:466]
There are more than 12,400 individual or “mass” actions pending that were filed in state or federal courts originating from 53 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The Company is currently unable to determine a precise count of personal injury claimants currently pending. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is

[0000833444-25-000097:notes:467]
anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are or will be proceeding in state courts, including actions in Arizona, Illinois and Washington.

[0000833444-25-000097:notes:468]
Tyco and Chemguard are also periodically notified by other individuals that they may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-25-000097:notes:469]
AFFF State or U.S. Territory Attorneys General Litigation

[0000833444-25-000097:notes:470]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-25-000097:notes:471]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-25-000097:notes:472]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

[0000833444-25-000097:notes:473]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. These two cases have also been removed to federal court and transferred to the MDL.

[0000833444-25-000097:notes:474]
In addition, 33 other states and territories have filed 35 lawsuits against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of each of those State's environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within each respective State. The states and territories are: Arkansas, Arizona, California, Colorado, Connecticut, Delaware, the District of Columbia, Florida, Hawaii, Illinois, Indiana, Kentucky, Massachusetts, Maryland, Maine, Michigan, Mississippi, New Hampshire, New Jersey, New Mexico, Ohio, Oklahoma, Oregon, Rhode Island, South Carolina, Tennessee, Texas, Vermont, Washington, Wisconsin, Guam, the Northern Mariana Islands, and Puerto Rico. All of these complaints, if not filed directly in the MDL, have been removed to federal court and transferred to the MDL.

[0000833444-25-000097:notes:475]
In addition, an affiliate of the Company has been named with other manufacturers as a third party by the Canadian Federal Government who is seeking contribution and indemnity in respect of a single-plaintiff action filed in Ontario relating to alleged PFAS and benzene contamination of a private well from the use of AFFF in firefighting training.

[0000833444-25-000097:notes:476]
Other AFFF Related Matters

[0000833444-25-000097:notes:477]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-25-000097:notes:478]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This case has been transferred to the MDL.

[0000833444-25-000097:notes:479]
In July 2023, the Fond du Lac Band of Lake Superior Chippewa (a federally recognized tribe) direct-filed a lawsuit in the MDL against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota.

[0000833444-25-000097:notes:480]
In September 2025, the Leech Lake Band of Ojibwe (one of six federally recognized sovereign bands that make up the federally recognized Minnesota Chippewa Tribe) filed a lawsuit in Minnesota state court against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from, among other things, the alleged use and disposal of AFFF on and near the Band’s property. This case has been transferred to the MDL.

[0000833444-25-000097:notes:481]
Four AFFF property damage proceedings have been filed in Belgium against numerous defendants, including an affiliate of the Company.  The cases are currently on hold pending efforts to dismiss the proceedings.

[0000833444-25-000097:notes:482]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin. The Company has reached settlements with certain insurers and remains in discussions and litigation with the remaining carriers. The Company is unable to predict the amount and timing of any future recoveries under its insurance policies with the remaining carriers. The insurance litigation involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-25-000097:notes:483]
Asbestos Matters

[0000833444-25-000097:notes:484]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-25-000097:notes:485]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-25-000097:notes:486]
|  | September 30, |
|  | 2025 |  | 2024 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 329 |  |  | 350 |  |
| Total asbestos-related liabilities | 387 |  |  | 408 |  |
| Other current assets | 13 |  |  | 14 |  |
| Other noncurrent assets | 326 |  |  | 320 |  |
| Total asbestos-related assets | 339 |  |  | 334 |  |
| Net asbestos-related liabilities | $ | 48 |  |  | $ | 74 |  |

[0000833444-25-000097:notes:487]
The following table presents the components of asbestos-related assets (in millions):

[0000833444-25-000097:notes:488]
|  | September 30, |
|  | 2025 |  | 2024 |
| Restricted |  |  |  |
| Cash | $ | 5 |  |  | $ | 6 |  |
| Investments | 290 |  |  | 281 |  |
| Total restricted assets | 295 |  |  | 287 |  |
| Insurance receivables for asbestos-related liabilities | 44 |  |  | 47 |  |
| Total asbestos-related assets | $ | 339 |  |  | $ | 334 |  |

[0000833444-25-000097:notes:489]
The amounts recorded for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-25-000097:notes:490]
Self-Insured Liabilities

[0000833444-25-000097:notes:491]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage a portion of its insurable liabilities.

[0000833444-25-000097:notes:492]
The following table presents the location and amount of self-insured liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-25-000097:notes:493]
|  | September 30, |
|  | 2025 |  | 2024 |
| Other current liabilities | $ | 87 |  |  | $ | 92 |  |
| Accrued compensation and benefits | 38 |  |  | 20 |  |
| Other noncurrent liabilities | 289 |  |  | 239 |  |
| Total self-insured liabilities | $ | 414 |  |  | $ | 351 |  |

[0000833444-25-000097:notes:494]
The following table presents the location and amount of insurance receivables in the Company's consolidated statements of financial position (in millions):

[0000833444-25-000097:notes:495]
|  | September 30, |
|  | 2025 |  | 2024 |
| Other current assets | $ | 4 |  |  | $ | 5 |  |
| Other noncurrent assets | 13 |  |  | 13 |  |
| Total insurance receivables | $ | 17 |  |  | $ | 18 |  |

[0000833444-25-000097:notes:496]
Other Matters 
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to the Company, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000833444-25-000097:notes:497]
On September 12, 2025 and prior to his departure from the Company, Nathan Manning, the Company's then-serving Vice President and President, Americas, entered into a Rule 10b5-1 trading arrangement (the "Manning 10b5-1 Plan") during the Company's fiscal fourth quarter open trading window. The Manning 10b5-1 Plan is intended to satisfy the Rule 10b5-1 affirmative defense and contemplates the sale of  10,123 ordinary shares of Company stock previously issued upon the vesting of restricted stock unit awards and the sale of 20,576 ordinary shares of Company stock issuable upon the exercise of option awards. The shares are expected to be sold in regular intervals between the plan’s start date and termination date. The Manning

[0000833444-25-000097:notes:498]
10b5-1 Plan is expected to become effective on or about February 5, 2026 and is scheduled to terminate upon the earlier of the sale of all shares contemplated under the Manning 10b5-1 Plan or November 7, 2026.
