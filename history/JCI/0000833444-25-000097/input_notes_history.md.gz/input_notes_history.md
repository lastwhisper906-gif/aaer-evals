# JCI note change history — 0000833444-25-000032 → 0000833444-25-000063


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-08-06):
[0000833444-25-000063:note_history:1]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 23 |  |  | $ | 32 |  |
| Other noncurrent liabilities | 170 |  |  | 179 |  |
| Total reserves for environmental liabilities | $ | 193 |  |  | $ | 211 |  |
  (was, 2025-05-07, similarity 0.9778):
[0000833444-25-000032:note_history:1]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 25 |  |  | $ | 32 |  |
| Other noncurrent liabilities | 174 |  |  | 179 |  |
| Total reserves for environmental liabilities | $ | 199 |  |  | $ | 211 |  |

- changed (2025-08-06):
[0000833444-25-000063:note_history:2]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and
  (was, 2025-05-07, similarity 0.7406):
[0000833444-25-000032:note_history:2]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). During the three months ended June 30, 2024, Tyco Fire Products completed its previously announced plan to discontinue the production and sale of fluorinated firefighting foams, including AFFF products, and has transitioned to non-fluorinated foam alternatives.

- added (2025-08-06):
[0000833444-25-000063:note_history:3]
other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). During the three months ended June 30, 2024, Tyco Fire Products completed its previously announced plan to discontinue the production and sale of fluorinated firefighting foams, including AFFF products, and has transitioned to non-fluorinated foam alternatives.

- changed (2025-08-06):
[0000833444-25-000063:note_history:4]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. In April 2024, EPA published National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBS. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meet the statutory definition of hazardous waste. In April 2024, EPA finalized a rule designating PFOA and PFOS, along with their salts and structural isomers, as "hazardous substances" under the Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In May 2025, EPA announced that it will retain the 4.0 ppt limit on PFOS and PFOA but will institute a two-year delay in the compliance deadline from 2029 until 2031. EPA also announced its intent to rescind and reconsider the limits on four other types of PFAS (PFHxS, PFNA, HFPO-DA, and PFBS).
  (was, 2025-05-07, similarity 0.9012):
[0000833444-25-000032:note_history:4]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. In April 2024, EPA published National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBA. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meet the statutory definition of hazardous waste. In April 2024, EPA finalized a rule designating PFOA and PFOS, along with their salts and structural isomers, as "hazardous substances" under the Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA").

- changed (2025-08-06):
[0000833444-25-000063:note_history:5]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.
  (was, 2025-05-07, similarity 0.8931):
[0000833444-25-000032:note_history:5]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future

- changed (2025-08-06):
[0000833444-25-000063:note_history:6]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $7 million at both June 30, 2025 and September 30, 2024.
  (was, 2025-05-07, similarity 0.9851):
[0000833444-25-000032:note_history:6]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $7 million at both March 31, 2025 and September 30, 2024.

- changed (2025-08-06):
[0000833444-25-000063:note_history:7]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities
  (was, 2025-05-07, similarity 0.7266):
[0000833444-25-000032:note_history:7]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

- added (2025-08-06):
[0000833444-25-000063:note_history:8]
completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

- added (2025-08-06):
[0000833444-25-000063:note_history:9]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions, including the potential assessment of penalties.

- changed (2025-08-06):
[0000833444-25-000063:note_history:10]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties have completed briefing of summary judgment and pretrial motions. The Court has continued the trial previously scheduled for March 3, 2025 and has not yet set a new trial date.
  (was, 2025-05-07, similarity 0.8244):
[0000833444-25-000032:note_history:10]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties are engaged in summary judgment and pretrial motions. The Court has continued the trial previously scheduled for March 3, 2025 and has not yet set a new trial date.

- added (2025-08-06):
[0000833444-25-000063:note_history:11]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v.

- changed (2025-08-06):
[0000833444-25-000063:note_history:12]
Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina.
  (was, 2025-05-07, similarity 0.8107):
[0000833444-25-000032:note_history:12]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina.

- changed (2025-08-06):
[0000833444-25-000063:note_history:13]
Chemguard and Tyco Fire Products have been named as defendants in more than 260 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 34 states and territories. The decrease in water provider actions during the three months ended June 30, 2025 reflects dismissals resulting from the water systems AFFF settlement agreement discussed further below. More water provider cases may be dismissed pursuant to the water systems AFFF settlement agreement. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation.
  (was, 2025-05-07, similarity 0.8433):
[0000833444-25-000032:note_history:13]
Chemguard and Tyco Fire Products have been named as defendants in more than 1,010 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 35 states and territories. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation.

- changed (2025-08-06):
[0000833444-25-000063:note_history:14]
Chemguard and Tyco Fire Products are named in 45 pending putative class actions in federal courts originating from 20 states and territories. The decrease in putative class actions during the three months ended June 30, 2025 reflects dismissals resulting from the water systems AFFF settlement agreement. All of these cases have been direct-filed in or transferred to the MDL. In addition, six proposed class actions were filed in Canada (British Columbia, Manitoba, Quebec and Ontario), which name Tyco Fire Products and other manufacturers as defendants, on behalf of various classes of members (including individuals and government entities) who seek to recover for remediation (past and future) costs, claim property or other environmental damages, or claim personal injuries or other harms arising from alleged exposure to or contamination with PFAS or PFAS-containing products (including AFFF).
  (was, 2025-05-07, similarity 0.9029):
[0000833444-25-000032:note_history:14]
Chemguard and Tyco Fire Products are named in 46 pending putative class actions in federal courts originating from 19 states and territories. All of these cases have been direct-filed in or transferred to the MDL. In addition, six proposed class actions were filed in Canada (British Columbia, Manitoba, Quebec and Ontario), which name Tyco Fire Products and other manufacturers as defendants, on behalf of various classes of members (including individuals and government entities) who seek to recover for remediation (past and future) costs, claim property or other environmental damages, or claim personal injuries or other harms arising from alleged exposure to or contamination with PFAS or PFAS-containing products (including AFFF).

- changed (2025-08-06):
[0000833444-25-000063:note_history:15]
There are more than 9,900 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 9,900 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona and Illinois.
  (was, 2025-05-07, similarity 0.8765):
[0000833444-25-000032:note_history:15]
There are more than 7,510 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 7,510 other plaintiffs. The decrease in individual actions during the three months ended March 31, 2025 reflect a court order establishing a dismissal process for cases that do not involve certain types of personal injuries. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona, Illinois and Wisconsin.

- changed (2025-08-06):
[0000833444-25-000063:note_history:16]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.
  (was, 2025-05-07, similarity 0.8133):
[0000833444-25-000032:note_history:16]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a

- changed (2025-08-06):
[0000833444-25-000063:note_history:17]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and
  (was, 2025-05-07, similarity 0.8231):
[0000833444-25-000032:note_history:17]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

- added (2025-08-06):
[0000833444-25-000063:note_history:18]
disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

- changed (2025-08-06):
[0000833444-25-000063:note_history:19]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin. The insurance litigation involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.
  (was, 2025-05-07, similarity 0.9758):
[0000833444-25-000032:note_history:19]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin and a federal district court in South Carolina. The insurance litigation involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

- added (2025-08-06):
[0000833444-25-000063:note_history:20]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 337 |  |  | 350 |  |
| Total asbestos-related liabilities | 395 |  |  | 408 |  |
| Other current assets | 14 |  |  | 14 |  |
| Other noncurrent assets | 314 |  |  | 320 |  |
| Total asbestos-related assets | 328 |  |  | 334 |  |
| Net asbestos-related liabilities | $ | 67 |  |  | $ | 74 |  |

- added (2025-08-06):
[0000833444-25-000063:note_history:21]
|  | June 30, 2025 |  | September 30, 2024 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 278 |  |  | 281 |  |
| Total restricted assets | 284 |  |  | 287 |  |
| Insurance receivables for asbestos-related liabilities | 44 |  |  | 47 |  |
| Total asbestos-related assets | $ | 328 |  |  | $ | 334 |  |

- changed (2025-08-06):
[0000833444-25-000063:note_history:22]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 96 |  |  | $ | 92 |  |
| Accrued compensation and benefits | 32 |  |  | 20 |  |
| Other noncurrent liabilities | 256 |  |  | 239 |  |
| Total self-insured liabilities | $ | 384 |  |  | $ | 351 |  |
  (was, 2025-05-07, similarity 0.9813):
[0000833444-25-000032:note_history:22]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 99 |  |  | $ | 92 |  |
| Accrued compensation and benefits | 20 |  |  | 20 |  |
| Other noncurrent liabilities | 251 |  |  | 239 |  |
| Total self-insured liabilities | $ | 370 |  |  | $ | 351 |  |

- changed (2025-08-06):
[0000833444-25-000063:note_history:23]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 13 |  |  | 13 |  |
| Total insurance receivables | $ | 18 |  |  | $ | 18 |  |
  (was, 2025-05-07, similarity 0.9744):
[0000833444-25-000032:note_history:23]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 13 |  |  | 13 |  |
| Total insurance receivables | $ | 18 |  |  | $ | 18 |  |

- removed (2025-08-06):
[0000833444-25-000032:note_history:24]
results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- removed (2025-08-06):
[0000833444-25-000032:note_history:25]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a

- removed (2025-08-06):
[0000833444-25-000032:note_history:26]
“Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions, including the potential assessment of penalties.

- removed (2025-08-06):
[0000833444-25-000032:note_history:27]
number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

- removed (2025-08-06):
[0000833444-25-000032:note_history:28]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 344 |  |  | 350 |  |
| Total asbestos-related liabilities | 402 |  |  | 408 |  |
| Other current assets | 15 |  |  | 14 |  |
| Other noncurrent assets | 299 |  |  | 320 |  |
| Total asbestos-related assets | 314 |  |  | 334 |  |
| Net asbestos-related liabilities | $ | 88 |  |  | $ | 74 |  |

- removed (2025-08-06):
[0000833444-25-000032:note_history:29]
|  | March 31, 2025 |  | September 30, 2024 |
| Restricted |  |  |  |
| Cash | $ | 7 |  |  | $ | 6 |  |
| Investments | 262 |  |  | 281 |  |
| Total restricted assets | 269 |  |  | 287 |  |
| Insurance receivables for asbestos-related liabilities | 45 |  |  | 47 |  |
| Total asbestos-related assets | $ | 314 |  |  | $ | 334 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-08-06):
[0000833444-25-000063:note_history:30]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 23 |  |  | $ | 32 |  |
| Other noncurrent liabilities | 170 |  |  | 179 |  |
| Total reserves for environmental liabilities | $ | 193 |  |  | $ | 211 |  |
  (was, 2025-05-07, similarity 0.9778):
[0000833444-25-000032:note_history:30]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 25 |  |  | $ | 32 |  |
| Other noncurrent liabilities | 174 |  |  | 179 |  |
| Total reserves for environmental liabilities | $ | 199 |  |  | $ | 211 |  |

- added (2025-08-06):
[0000833444-25-000063:note_history:31]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 337 |  |  | 350 |  |
| Total asbestos-related liabilities | 395 |  |  | 408 |  |
| Other current assets | 14 |  |  | 14 |  |
| Other noncurrent assets | 314 |  |  | 320 |  |
| Total asbestos-related assets | 328 |  |  | 334 |  |
| Net asbestos-related liabilities | $ | 67 |  |  | $ | 74 |  |

- added (2025-08-06):
[0000833444-25-000063:note_history:32]
|  | June 30, 2025 |  | September 30, 2024 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 278 |  |  | 281 |  |
| Total restricted assets | 284 |  |  | 287 |  |
| Insurance receivables for asbestos-related liabilities | 44 |  |  | 47 |  |
| Total asbestos-related assets | $ | 328 |  |  | $ | 334 |  |

- changed (2025-08-06):
[0000833444-25-000063:note_history:33]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 96 |  |  | $ | 92 |  |
| Accrued compensation and benefits | 32 |  |  | 20 |  |
| Other noncurrent liabilities | 256 |  |  | 239 |  |
| Total self-insured liabilities | $ | 384 |  |  | $ | 351 |  |
  (was, 2025-05-07, similarity 0.9813):
[0000833444-25-000032:note_history:33]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 99 |  |  | $ | 92 |  |
| Accrued compensation and benefits | 20 |  |  | 20 |  |
| Other noncurrent liabilities | 251 |  |  | 239 |  |
| Total self-insured liabilities | $ | 370 |  |  | $ | 351 |  |

- changed (2025-08-06):
[0000833444-25-000063:note_history:34]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 13 |  |  | 13 |  |
| Total insurance receivables | $ | 18 |  |  | $ | 18 |  |
  (was, 2025-05-07, similarity 0.9744):
[0000833444-25-000032:note_history:34]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 13 |  |  | 13 |  |
| Total insurance receivables | $ | 18 |  |  | $ | 18 |  |

- removed (2025-08-06):
[0000833444-25-000032:note_history:35]
The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

- removed (2025-08-06):
[0000833444-25-000032:note_history:36]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 344 |  |  | 350 |  |
| Total asbestos-related liabilities | 402 |  |  | 408 |  |
| Other current assets | 15 |  |  | 14 |  |
| Other noncurrent assets | 299 |  |  | 320 |  |
| Total asbestos-related assets | 314 |  |  | 334 |  |
| Net asbestos-related liabilities | $ | 88 |  |  | $ | 74 |  |

- removed (2025-08-06):
[0000833444-25-000032:note_history:37]
|  | March 31, 2025 |  | September 30, 2024 |
| Restricted |  |  |  |
| Cash | $ | 7 |  |  | $ | 6 |  |
| Investments | 262 |  |  | 281 |  |
| Total restricted assets | 269 |  |  | 287 |  |
| Insurance receivables for asbestos-related liabilities | 45 |  |  | 47 |  |
| Total asbestos-related assets | $ | 314 |  |  | $ | 334 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-08-06):
[0000833444-25-000063:note_history:38]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2024 filed with the SEC on November 19, 2024. The results of operations for the three and nine month periods ended June 30, 2025 are not necessarily indicative of results for the Company’s 2025 fiscal year because of seasonal and other factors.
  (was, 2025-05-07, similarity 0.9791):
[0000833444-25-000032:note_history:38]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2024 filed with the SEC on November 19, 2024. The results of operations for the three and six month periods ended March 31, 2025 are not necessarily indicative of results for the Company’s 2025 fiscal year because of seasonal and other factors.

- added (2025-08-06):
[0000833444-25-000063:note_history:39]
On April 1, 2025, the Company realigned into three reportable segments (Americas, EMEA and APAC) from four reportable segments (Global Products, Building Solutions North America, Building Solutions EMEA/LA and Building Solutions APAC). Historical information has been recast to present the comparative periods on a consistent basis. Refer to Note 16, "Segment Information," of the notes to the consolidated financial statements for further disclosure.

- changed (2025-08-06):
[0000833444-25-000063:note_history:40]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, safe, healthy and sustainable buildings, serving a wide range of customers around the globe. The Company’s products and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.
  (was, 2025-05-07, similarity 0.8266):
[0000833444-25-000032:note_history:40]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, safe, healthy and sustainable buildings, serving a wide range of customers around the globe. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

- changed (2025-08-06):
[0000833444-25-000063:note_history:41]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space) and energy-management consulting. The Company partners with customers by leveraging its broad product portfolio and digital capabilities, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.
  (was, 2025-05-07, similarity 0.7137):
[0000833444-25-000032:note_history:41]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space) and energy-management consulting. The Company's OpenBlue digital software platform enables enterprises to better manage their physical spaces by combining the Company's building products and services with cutting-edge technology and digital capabilities to enable data-driven “smart building” services and solutions. The Company partners with customers by leveraging its broad product portfolio and digital capabilities, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

- added (2025-08-06):
[0000833444-25-000063:note_history:42]
As discussed in more detail in Note 3, "Assets and Liabilities Held for Sale and Discontinued Operations", of the notes to the consolidated financial statements, the Company entered into a definitive agreement to sell its Residential and Light Commercial (“R&LC") HVAC business, including the North America Ducted business and the global Residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which Johnson Controls owns 60% and Hitachi owns 40%. The R&LC HVAC business, which was previously reported in the Global Products segment prior to the Company's resegmentation, meets the criteria to be classified as a discontinued operation and, as a result, its historical financial results are reflected in the consolidated financial statements as a discontinued operation, and assets and liabilities are classified as held for sale for all periods presented. Unless otherwise noted, all activities and amounts reported in the following footnotes relate to the continuing operations of the Company and exclude activities and amounts related to the R&LC HVAC business.

- changed (2025-08-06):
[0000833444-25-000063:note_history:43]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries in conformity with U.S. GAAP. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal.
  (was, 2025-05-07, similarity 0.7443):
[0000833444-25-000032:note_history:43]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries in conformity with U.S. GAAP. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.

- added (2025-08-06):
[0000833444-25-000063:note_history:44]
Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.

- removed (2025-08-06):
[0000833444-25-000032:note_history:45]
As discussed in more detail in Note 3, "Assets and Liabilities Held for Sale and Discontinued Operations", the Company has entered into a definitive agreement to sell its Residential and Light Commercial (“R&LC") HVAC business, including the North America Ducted business and the global Residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which Johnson Controls owns 60% and Hitachi owns 40%. The R&LC HVAC business, which was previously reported in the Global Products segment, meets the criteria to be classified as a discontinued operation and, as a result, its historical financial results are reflected in the consolidated financial statements as a discontinued operation, and assets and liabilities are classified as held for sale for all periods presented. Unless otherwise noted, all activities and amounts reported in the following footnotes relate to the continuing operations of the Company and exclude activities and amounts related to the R&LC HVAC business.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-08-06):
[0000833444-25-000063:note_history:46]
|  | June 30, 2025 |  | September 30, 2024 |
| Commercial paper | $ | 650 |  |  | $ | 350 |  |
| Term loans | 627 |  |  | 603 |  |
|  | $ | 1,277 |  |  | $ | 953 |  |
| Weighted average interest rate on short-term debt outstanding | 4.0 | % |  | 4.8 | % |

- changed (2025-08-06):
[0000833444-25-000063:note_history:47]
As of June 30, 2025, the Company had two syndicated committed revolving credit facilities, including $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2025. There were no draws on the facilities as of June 30, 2025.
  (was, 2025-05-07, similarity 0.95):
[0000833444-25-000032:note_history:47]
As of March 31, 2025, the Company had two syndicated committed revolving credit facilities, including $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2025. There were no draws on the facilities as of March 31, 2025.

- removed (2025-08-06):
[0000833444-25-000032:note_history:48]
|  | March 31, |  | September 30, |
|  | 2025 |  | 2024 |
| Commercial paper | $ | 673 |  |  | $ | 350 |  |
| Term loans | 587 |  |  | 603 |  |
| Bank borrowings | 1 |  |  | — |  |
|  | $ | 1,261 |  |  | $ | 953 |  |
| Weighted average interest rate on short-term debt outstanding | 3.8 | % |  | 4.8 | % |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-08-06):
[0000833444-25-000063:note_history:49]
The fair value of long-term debt at June 30, 2025 and September 30, 2024 was as follows (in billions):
  (was, 2025-05-07, similarity 0.9514):
[0000833444-25-000032:note_history:49]
The fair value of long-term debt at March 31, 2025 and September 30, 2024 was as follows (in billions):

- changed (2025-08-06):
[0000833444-25-000063:note_history:50]
|  |  | June 30, |  | September 30, |
|  | 2025 |  | 2024 |
| Public debt |  | $ | 8.3 |  |  | $ | 8.1 |  |
| Other long-term debt |  | 0.3 |  |  | 0.2 |  |
| Total fair value of long-term debt |  | $ | 8.6 |  |  | $ | 8.3 |  |
  (was, 2025-05-07, similarity 0.9509):
[0000833444-25-000032:note_history:50]
|  |  | March 31, |  | September 30, |  |
|  | 2025 |  | 2024 |  |
| Public debt |  | $ | 8.0 |  |  | $ | 8.1 |  |  |
| Other long-term debt |  | 0.3 |  |  | 0.2 |  |  |
| Total fair value of long-term debt |  | $ | 8.3 |  |  | $ | 8.3 |  |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-08-06):
[0000833444-25-000063:note_history:51]
|  | June 30, 2025 |  | September 30, 2024 |
| Commercial paper | $ | 650 |  |  | $ | 350 |  |
| Term loans | 627 |  |  | 603 |  |
|  | $ | 1,277 |  |  | $ | 953 |  |
| Weighted average interest rate on short-term debt outstanding | 4.0 | % |  | 4.8 | % |

- removed (2025-08-06):
[0000833444-25-000032:note_history:52]
|  | March 31, |  | September 30, |
|  | 2025 |  | 2024 |
| Commercial paper | $ | 673 |  |  | $ | 350 |  |
| Term loans | 587 |  |  | 603 |  |
| Bank borrowings | 1 |  |  | — |  |
|  | $ | 1,261 |  |  | $ | 953 |  |
| Weighted average interest rate on short-term debt outstanding | 3.8 | % |  | 4.8 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-08-06):
[0000833444-25-000063:note_history:53]
|  |  | Three Months Ended June 30, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 2,847 |  |  | $ | 1,195 |  |  | $ | 4,042 |  |  | $ | 2,887 |  |  | $ | 1,148 |  |  | $ | 4,035 |  |
| EMEA |  | 756 |  |  | 517 |  |  | 1,273 |  |  | 710 |  |  | 467 |  |  | 1,177 |  |
| APAC |  | 519 |  |  | 218 |  |  | 737 |  |  | 492 |  |  | 194 |  |  | 686 |  |
| Total |  | $ | 4,122 |  |  | $ | 1,930 |  |  | $ | 6,052 |  |  | $ | 4,089 |  |  | $ | 1,809 |  |  | $ | 5,898 |  |

- added (2025-08-06):
[0000833444-25-000063:note_history:54]
|  |  | Nine Months Ended June 30, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 8,094 |  |  | $ | 3,412 |  |  | $ | 11,506 |  |  | $ | 8,114 |  |  | $ | 3,227 |  |  | $ | 11,341 |  |
| EMEA |  | 2,177 |  |  | 1,454 |  |  | 3,631 |  |  | 2,086 |  |  | 1,354 |  |  | 3,440 |  |
| APAC |  | 1,401 |  |  | 616 |  |  | 2,017 |  |  | 1,376 |  |  | 547 |  |  | 1,923 |  |
| Total |  | $ | 11,672 |  |  | $ | 5,482 |  |  | $ | 17,154 |  |  | $ | 11,576 |  |  | $ | 5,128 |  |  | $ | 16,704 |  |

- removed (2025-08-06):
[0000833444-25-000032:note_history:55]
|  |  | Three Months Ended March 31, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,829 |  |  | $ | 1,087 |  |  | $ | 2,916 |  |  | $ | 1,700 |  |  | $ | 1,039 |  |  | $ | 2,739 |  |
| Building Solutions EMEA/LA |  | 566 |  |  | 519 |  |  | 1,085 |  |  | 572 |  |  | 492 |  |  | 1,064 |  |
| Building Solutions Asia Pacific |  | 337 |  |  | 205 |  |  | 542 |  |  | 308 |  |  | 183 |  |  | 491 |  |
| Global Products |  | 1,133 |  |  | — |  |  | 1,133 |  |  | 1,303 |  |  | — |  |  | 1,303 |  |
| Total |  | $ | 3,865 |  |  | $ | 1,811 |  |  | $ | 5,676 |  |  | $ | 3,883 |  |  | $ | 1,714 |  |  | $ | 5,597 |  |

- removed (2025-08-06):
[0000833444-25-000032:note_history:56]
|  |  | Six Months Ended March 31, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,524 |  |  | $ | 2,136 |  |  | $ | 5,660 |  |  | $ | 3,218 |  |  | $ | 2,008 |  |  | $ | 5,226 |  |
| Building Solutions EMEA/LA |  | 1,140 |  |  | 1,018 |  |  | 2,158 |  |  | 1,144 |  |  | 958 |  |  | 2,102 |  |
| Building Solutions Asia Pacific |  | 671 |  |  | 398 |  |  | 1,069 |  |  | 645 |  |  | 353 |  |  | 998 |  |
| Global Products |  | 2,215 |  |  | — |  |  | 2,215 |  |  | 2,480 |  |  | — |  |  | 2,480 |  |
| Total |  | $ | 7,550 |  |  | $ | 3,552 |  |  | $ | 11,102 |  |  | $ | 7,487 |  |  | $ | 3,319 |  |  | $ | 10,806 |  |

- removed (2025-08-06):
[0000833444-25-000032:note_history:57]
The following table presents further disaggregation of Global Products segment revenues by product type (in millions):

- removed (2025-08-06):
[0000833444-25-000032:note_history:58]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| HVAC |  | $ | 468 |  |  | $ | 581 |  |  | $ | 936 |  |  | $ | 1,114 |  |
| Fire & Security |  | 573 |  |  | 607 |  |  | 1,095 |  |  | 1,154 |  |
| Industrial Refrigeration |  | 92 |  |  | 115 |  |  | 184 |  |  | 212 |  |
| Total |  | $ | 1,133 |  |  | $ | 1,303 |  |  | $ | 2,215 |  |  | $ | 2,480 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-06):
[0000833444-25-000063:note_history:59]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of June 30, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $22.4 billion, of which approximately 63% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.
  (was, 2025-05-07, similarity 0.9955):
[0000833444-25-000032:note_history:59]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $22 billion, of which approximately 63% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-08-06):
[0000833444-25-000063:note_history:60]
|  |  | Three Months Ended June 30, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 2,847 |  |  | $ | 1,195 |  |  | $ | 4,042 |  |  | $ | 2,887 |  |  | $ | 1,148 |  |  | $ | 4,035 |  |
| EMEA |  | 756 |  |  | 517 |  |  | 1,273 |  |  | 710 |  |  | 467 |  |  | 1,177 |  |
| APAC |  | 519 |  |  | 218 |  |  | 737 |  |  | 492 |  |  | 194 |  |  | 686 |  |
| Total |  | $ | 4,122 |  |  | $ | 1,930 |  |  | $ | 6,052 |  |  | $ | 4,089 |  |  | $ | 1,809 |  |  | $ | 5,898 |  |

- added (2025-08-06):
[0000833444-25-000063:note_history:61]
|  |  | Nine Months Ended June 30, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 8,094 |  |  | $ | 3,412 |  |  | $ | 11,506 |  |  | $ | 8,114 |  |  | $ | 3,227 |  |  | $ | 11,341 |  |
| EMEA |  | 2,177 |  |  | 1,454 |  |  | 3,631 |  |  | 2,086 |  |  | 1,354 |  |  | 3,440 |  |
| APAC |  | 1,401 |  |  | 616 |  |  | 2,017 |  |  | 1,376 |  |  | 547 |  |  | 1,923 |  |
| Total |  | $ | 11,672 |  |  | $ | 5,482 |  |  | $ | 17,154 |  |  | $ | 11,576 |  |  | $ | 5,128 |  |  | $ | 16,704 |  |

- changed (2025-08-06):
[0000833444-25-000063:note_history:62]
|  |  | Location of contract balances |  | June 30, 2025 |  | September 30, 2024 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,119 |  |  | $ | 1,931 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 7 |  |  | 11 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,428 |  |  | 2,160 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 269 |  |  | 252 |  |  |  |
  (was, 2025-05-07, similarity 0.989):
[0000833444-25-000032:note_history:62]
|  |  | Location of contract balances |  | March 31, 2025 |  | September 30, 2024 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,998 |  |  | $ | 1,931 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 7 |  |  | 11 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,380 |  |  | 2,160 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 261 |  |  | 252 |  |  |  |

- added (2025-08-06):
[0000833444-25-000063:note_history:63]
For the three months ended June 30, 2025 and 2024, the Company recognized revenue of $279 million and $267 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year. For the nine months ended June 30, 2025 and 2024, the Company recognized revenue of $1,550 million and $1,475 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.

- changed (2025-08-06):
[0000833444-25-000063:note_history:64]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of June 30, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $22.4 billion, of which approximately 63% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.
  (was, 2025-05-07, similarity 0.9955):
[0000833444-25-000032:note_history:64]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $22 billion, of which approximately 63% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.

- changed (2025-08-06):
[0000833444-25-000063:note_history:65]
|  | June 30, 2025 |  | September 30, 2024 |  |  |
| Other current assets | $ | 306 |  |  | $ | 265 |  |  |  |
| Other noncurrent assets | 257 |  |  | 291 |  |  |  |
| Total | $ | 563 |  |  | $ | 556 |  |  |  |
  (was, 2025-05-07, similarity 0.951):
[0000833444-25-000032:note_history:65]
|  |  | March 31, 2025 |  | September 30, 2024 |  |  |
| Other current assets |  | $ | 283 |  |  | $ | 265 |  |  |  |
| Other noncurrent assets |  | 290 |  |  | 291 |  |  |  |
| Total |  | $ | 573 |  |  | $ | 556 |  |  |  |

- changed (2025-08-06):
[0000833444-25-000063:note_history:66]
During the three months ended June 30, 2025 and 2024, the Company recognized expense of $104 million and $84 million, respectively, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2025 and 2024, the Company recognized expense of $279 million and $218 million, respectively, related to costs to obtain or fulfill a contract.
  (was, 2025-05-07, similarity 0.9217):
[0000833444-25-000032:note_history:66]
During the three months ended March 31, 2025 and 2024, the Company recognized expense of $91 million and $77 million, respectively, related to costs to obtain or fulfill a contract. During the six months ended March 31, 2025 and 2024, the Company recognized expense of $175 million and $134 million, respectively, related to costs to obtain or fulfill a contract.

- removed (2025-08-06):
[0000833444-25-000032:note_history:67]
|  |  | Three Months Ended March 31, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,829 |  |  | $ | 1,087 |  |  | $ | 2,916 |  |  | $ | 1,700 |  |  | $ | 1,039 |  |  | $ | 2,739 |  |
| Building Solutions EMEA/LA |  | 566 |  |  | 519 |  |  | 1,085 |  |  | 572 |  |  | 492 |  |  | 1,064 |  |
| Building Solutions Asia Pacific |  | 337 |  |  | 205 |  |  | 542 |  |  | 308 |  |  | 183 |  |  | 491 |  |
| Global Products |  | 1,133 |  |  | — |  |  | 1,133 |  |  | 1,303 |  |  | — |  |  | 1,303 |  |
| Total |  | $ | 3,865 |  |  | $ | 1,811 |  |  | $ | 5,676 |  |  | $ | 3,883 |  |  | $ | 1,714 |  |  | $ | 5,597 |  |

- removed (2025-08-06):
[0000833444-25-000032:note_history:68]
|  |  | Six Months Ended March 31, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,524 |  |  | $ | 2,136 |  |  | $ | 5,660 |  |  | $ | 3,218 |  |  | $ | 2,008 |  |  | $ | 5,226 |  |
| Building Solutions EMEA/LA |  | 1,140 |  |  | 1,018 |  |  | 2,158 |  |  | 1,144 |  |  | 958 |  |  | 2,102 |  |
| Building Solutions Asia Pacific |  | 671 |  |  | 398 |  |  | 1,069 |  |  | 645 |  |  | 353 |  |  | 998 |  |
| Global Products |  | 2,215 |  |  | — |  |  | 2,215 |  |  | 2,480 |  |  | — |  |  | 2,480 |  |
| Total |  | $ | 7,550 |  |  | $ | 3,552 |  |  | $ | 11,102 |  |  | $ | 7,487 |  |  | $ | 3,319 |  |  | $ | 10,806 |  |

- removed (2025-08-06):
[0000833444-25-000032:note_history:69]
The following table presents further disaggregation of Global Products segment revenues by product type (in millions):

- removed (2025-08-06):
[0000833444-25-000032:note_history:70]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| HVAC |  | $ | 468 |  |  | $ | 581 |  |  | $ | 936 |  |  | $ | 1,114 |  |
| Fire & Security |  | 573 |  |  | 607 |  |  | 1,095 |  |  | 1,154 |  |
| Industrial Refrigeration |  | 92 |  |  | 115 |  |  | 184 |  |  | 212 |  |
| Total |  | $ | 1,133 |  |  | $ | 1,303 |  |  | $ | 2,215 |  |  | $ | 2,480 |  |

- removed (2025-08-06):
[0000833444-25-000032:note_history:71]
For the three months ended March 31, 2025 and 2024, the Company recognized revenue of $393 million and $369 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year. For the six months ended March 31, 2025 and 2024, the Company recognized revenue of $1,271 million and $1,208 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.
