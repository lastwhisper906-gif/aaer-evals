# JCI 10-K controls and the auditor's report


## auditors_report

[0000833444-25-000097:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0000833444-25-000097:auditors_report:2]
To the Board of Directors and Shareholders of Johnson Controls International plc

[0000833444-25-000097:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0000833444-25-000097:auditors_report:4]
We have audited the accompanying consolidated statements of financial position of Johnson Controls International plc and its subsidiaries (the "Company") as of September 30, 2025 and 2024, and the related consolidated statements of income, of comprehensive income, of shareholders' equity and of cash flows for each of the three years in the period ended September 30, 2025, including the related notes (collectively referred to as the "consolidated financial statements"). We also have audited the Company's internal control over financial reporting as of September 30, 2025, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0000833444-25-000097:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of September 30, 2025 and 2024, and the results of its operations and its cash flows for each of the three years in the period ended September 30, 2025 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of September 30, 2025, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0000833444-25-000097:auditors_report:6]
Basis for Opinions

[0000833444-25-000097:auditors_report:7]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management’s Report on Internal Control Over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000833444-25-000097:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0000833444-25-000097:auditors_report:9]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0000833444-25-000097:auditors_report:10]
Definition and Limitations of Internal Control over Financial Reporting

[0000833444-25-000097:auditors_report:11]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000833444-25-000097:auditors_report:12]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000833444-25-000097:auditors_report:13]
49

[0000833444-25-000097:auditors_report:14]
Critical Audit Matters

[0000833444-25-000097:auditors_report:15]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0000833444-25-000097:auditors_report:16]
Revenue Recognition from Certain Contracts with Customers

[0000833444-25-000097:auditors_report:17]
As described in Notes 1, 2 and 4 to the consolidated financial statements, the Company recognized net sales of $23,596 million from continuing operations and $3,790 million from discontinued operations for the year ended September 30, 2025, of which a majority relates to certain over time and point in time contracts with customers. Revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services is recognized on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and estimated losses are recorded when identified. The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term. Revenue associated with the sale of equipment and related installations are generally recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. In other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

[0000833444-25-000097:auditors_report:18]
The principal considerations for our determination that performing procedures relating to revenue recognition from certain contracts with customers is a critical audit matter are a high degree of auditor effort in performing procedures and evaluating audit evidence related to the revenue recognized on certain of the Company's over time and point in time contracts with customers.

[0000833444-25-000097:auditors_report:19]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the revenue recognition process for the Company’s over time and point in time contracts with customers. These procedures also included, among others, evaluating the appropriateness of the timing and amount of revenue recognized for a sample of over time and point in time contracts with customers. Evaluating the appropriateness of the timing and amount of revenue recognized for certain over time contracts with customers involved (i) obtaining and inspecting source documents, such as contracts or service tickets, change orders, and evidence of progress towards completion or services delivered; (ii) evaluating the appropriateness of the over time revenue recognition methods; (iii) testing, on a sample basis for certain over time contracts, the costs incurred to date; and (iv) performing a comparison of estimated gross margin in the prior year to gross margin at completion of the arrangement in the current year for certain over time contracts with customers. Evaluating the appropriateness of the timing and amount of revenue recognized for certain point in time contracts with customers involved (i) obtaining and inspecting source documents, such as contracts or purchase orders, evidence of goods delivered, and consideration received in exchange for those goods and (ii) evaluating the appropriateness of the point in time revenue recognition method.

[0000833444-25-000097:auditors_report:20]
/s/ PricewaterhouseCoopers LLP

[0000833444-25-000097:auditors_report:21]
Milwaukee, Wisconsin

[0000833444-25-000097:auditors_report:22]
November 14, 2025

[0000833444-25-000097:auditors_report:23]
We have served as the Company’s auditor since 1957.

[0000833444-25-000097:auditors_report:24]
50

[0000833444-25-000097:auditors_report:25]
Johnson Controls International plc


## item_9a

[0000833444-25-000097:item_9a:1]
ITEM 9A    CONTROLS AND PROCEDURES

[0000833444-25-000097:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000833444-25-000097:item_9a:3]
The Company’s management, with the participation of its Chief Executive Officer and Chief Financial Officer, has evaluated the effectiveness of the Company’s disclosure controls and procedures (as such term is defined in Rule 13a-15(e) under the Securities Exchange Act of 1934, as amended (the "Exchange Act")) as of September 30, 2025. Based on such evaluation, the Company’s Chief Executive Officer and Chief Financial Officer have concluded that, as of September 30, 2025, the Company’s disclosure controls and procedures are effective in recording, processing, summarizing, and reporting, on a timely basis, information required to be disclosed by the Company in the reports that it files or submits under the Exchange Act, and that information is accumulated and communicated to the Company’s management, including the Company’s Chief Executive Officer and Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0000833444-25-000097:item_9a:4]
Management’s Report on Internal Control Over Financial Reporting

[0000833444-25-000097:item_9a:5]
The Company’s management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rule 13a-15(f). The Company’s management, with the participation of the Company’s Chief Executive Officer and Chief Financial Officer, has evaluated the effectiveness of the Company’s internal control over financial reporting based on the framework in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this evaluation, the Company’s management has concluded that, as of September 30, 2025, the Company's internal control over financial reporting was effective.

[0000833444-25-000097:item_9a:6]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000833444-25-000097:item_9a:7]
PricewaterhouseCoopers LLP, an independent registered public accounting firm, has audited the effectiveness of the Company's internal control over financial reporting as of September 30, 2025 as stated in its report which is included in Item 8 of this Form 10-K.

[0000833444-25-000097:item_9a:8]
Changes in Internal Control Over Financial Reporting

[0000833444-25-000097:item_9a:9]
There were no changes in the Company’s internal control over financial reporting during the quarter ended September 30, 2025, that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.
