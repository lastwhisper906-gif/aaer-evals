# JCI MD&A — 0000833444-25-000097


## mdna

[0000833444-25-000097:mdna:1]
ITEM 7    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000833444-25-000097:mdna:2]
General

[0000833444-25-000097:mdna:3]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers around the globe. The Company’s products and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-25-000097:mdna:4]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space) and energy-management consulting. The Company partners with customers by leveraging its broad product portfolio and digital capabilities, together with its direct channel service and solutions capabilities, to deliver solutions and services addressing distinct and diverse operating environments and regulatory requirements that address customers’ needs in their core missions.  On April 1, 2025, the Company, as part of ongoing initiatives to drive simplification, accelerate growth, better reflect its organizational and operational structure and align with the manner in which the Company's chief operating decision maker assesses performance and makes decisions regarding the allocation of resources following portfolio simplification actions, realigned into three reportable segments (Americas, EMEA and APAC) from four reportable segments (Global Products, Building Solutions North America, Building Solutions EMEA/LA and Building Solutions APAC). The Company began reporting under this segment structure on April 1, 2025.

[0000833444-25-000097:mdna:5]
The Company's fiscal year ends on September 30. Unless otherwise stated, references to years in this report relate to fiscal years rather than calendar years. This discussion summarizes the significant factors affecting the consolidated operating results,

[0000833444-25-000097:mdna:6]
financial condition and liquidity of the Company on a continuing operations basis for the year ended September 30, 2025 and should be read in conjunction with Item 8, the consolidated financial statements and the notes to consolidated financial statements.

[0000833444-25-000097:mdna:7]
Macroeconomic Trends

[0000833444-25-000097:mdna:8]
Much of the demand for the Company’s products and solutions is heavily dependent on general economic conditions, localized demand for real estate and the availability of credit, public funding or other financing sources. Positive or negative fluctuations in these dependencies could have a corresponding impact on the Company’s financial condition, results of operations and cash flows.

[0000833444-25-000097:mdna:9]
The Company maintains global operations. The United States has announced tariffs and reciprocal tariffs on a wide range of products manufactured or produced worldwide, including Canada, China, the European Union, Japan and Mexico, among others. Several countries have similarly announced reciprocal or other tariffs impacting products manufactured or produced in the United States. In addition, the United States and other nations have, and may in the future, pause, reimpose, decrease or increase tariffs. Although the Company has been largely able to mitigate the impact of tariffs that have been enacted to date, if additional tariffs and reciprocal tariffs are implemented (whether as currently proposed or otherwise), such actions could negatively impact the Company's revenue growth and margins in future periods through decreased sales and increased cost of goods sold. Further, the Company has experienced, and could again experience, increased material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends including the imposition of tariffs and other restrictive trade measures, as well as geopolitical and economic tensions. The net effect of these events will continue to depend on the Company’s ability to successfully mitigate and offset their impact.

[0000833444-25-000097:mdna:10]
The Company is taking actions to mitigate the actual and anticipated impact of these events, including strengthening the Company's in region, for region manufacturing strategy, pivoting to local sourcing in its supply chain, accelerating pricing actions and asserting contractual rights through change orders. The Company has historically taken a variety of actions to mitigate trade restrictions, supply chain disruptions and inflation, including through expanding and redistributing its supplier network, supplier financing, accelerated purchasing and productivity improvements. These actions have largely been successful mitigating the impacts of the current macroeconomic environment, however, it is uncertain as to whether the actions taken or contemplated to be taken by the Company will be effective in continuing to mitigate the impact of current and future trade restrictions and their related impacts. The Company continues to actively monitor and evaluate the development and potential impacts of tariffs and other trade restrictions on its supply chain and results of operations.

[0000833444-25-000097:mdna:11]
As a result of the Company’s global presence, a significant portion of its revenues and expenses are denominated in currencies other than the U.S. dollar, which results in non-U.S. currency risks and exchange exposure. While the Company employs financial instruments to hedge some of its transactional foreign exchange exposure, these activities do not insulate it completely from those exposures. In addition, currency exposure from the translation of non-U.S. dollar functional currency subsidiaries cannot be hedged. Exchange rates can be volatile and a substantial weakening or strengthening of foreign currencies against the U.S. dollar could increase or reduce the Company’s profit margin, respectively, and impact the comparability of results from period to period.

[0000833444-25-000097:mdna:12]
The Company continues to observe trends demonstrating increased interest and demand for its products and services that enable smart, safe, efficient and sustainable buildings, which are driven in part by government tax incentives, building performance standards and other regulations designed to limit emissions and combat climate change. In particular, legislative and regulatory initiatives such as the EU Energy Efficiency Directive, EU Heat Transition, U.S. Inflation Reduction Act and EU Energy Performance of Buildings Directive include provisions designed to fund and encourage investment in decarbonization and digital technologies for buildings. This demand is supplemented by an increase in commitments in both the public and private sectors to reduce emissions and/or achieve net zero emissions. In addition, the increased maturity and adoption of AI and high-performance computing is currently impacting the microchip and data center industry and driving technology innovation, which has led to increased demand for hyperscale and data center cooling solutions that deliver heat management and energy efficiency. The Company seeks to capitalize on these trends to enable delivery of sustainable, high-efficiency products and tailored services to enable customers to achieve their sustainability, heat management and energy efficiency goals. The Company is leveraging its install base, together with data-driven products and services, to offer outcome-based solutions to customers with a focus on generating accelerated growth in services and recurring revenue.

[0000833444-25-000097:mdna:13]
Certain of our customers, including governmental and institutional customers, have exhibited increased uncertainty regarding future spending decisions due to various political and economic factors, including budget reductions, reprioritization of spending, interest rate fluctuation and economic uncertainty. This uncertainty has and may in the future impact on the Company's ability to predict and forecast the revenue and backlog associated with these customers.

[0000833444-25-000097:mdna:14]
The extent to which the Company’s results of operations and financial condition are impacted by these and other factors in the future will depend on developments that are highly uncertain and cannot be predicted. See Part I, Item 1A, of this Annual Report on Form 10-K for an additional discussion of risks.

[0000833444-25-000097:mdna:15]
Portfolio Simplification Transactions

[0000833444-25-000097:mdna:16]
The Company continues to engage in an ongoing evaluation of its non-core product lines in connection with its objective to be a pure-play provider of comprehensive solutions for commercial buildings. On July 31, 2025, the Company completed the divestiture of its Residential and Light Commercial ("R&LC") HVAC business to Robert Bosch GmbH (“Bosch”) for net cash proceeds of approximately $5.6 billion after tax and transaction-related expenses. The R&LC HVAC business included the Company's North America Ducted business and Johnson Controls-Hitachi Air Conditioning Holding (UK) Ltd., the Company’s global residential joint venture with Hitachi Global Life Solutions, Inc.

[0000833444-25-000097:mdna:17]
Restructuring and Cost Optimization Initiatives

[0000833444-25-000097:mdna:18]
During the fourth quarter of fiscal 2024, the Company committed to a multi-year restructuring plan to address stranded costs and further right-size global operations as a result of previously announced portfolio simplification actions. It is expected that one-time restructuring costs, including severance and other employee termination benefits, contract termination costs, and certain other related cash and non-cash charges, of approximately $400 million will be incurred over the course of fiscal 2025, 2026 and 2027, resulting in expected annual cost savings of approximately $500 million upon full completion of the plan. Restructuring and transformation costs in fiscal 2025 have been material, resulting in savings in 2025 and additional expected savings in fiscal 2026 and 2027. Restructuring costs will be incurred across all segments and Corporate functions. Refer to Note 16, "Restructuring and Related Costs," for an update on the restructuring plan.

[0000833444-25-000097:mdna:19]
FISCAL YEAR 2025 COMPARED TO FISCAL YEAR 2024

[0000833444-25-000097:mdna:20]
Net Sales

[0000833444-25-000097:mdna:21]
|  | Year Ended September 30, |  |  |
| (in millions) | 2025 |  | 2024 |  | Change |
| Net sales | $ | 23,596 |  |  | $ | 22,952 |  |  | 3 | % |

[0000833444-25-000097:mdna:22]
The increase in net sales was due to higher organic sales ($1,430 million), partially offset by the net impact of acquisitions and divestitures ($786 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 6% over the prior year, driven by growth in Services across all segments as well as growth in Products and Systems, led by the Americas. Refer to the "Segment Analysis" below within Item 7 for a discussion of net sales by segment. Refer to Note 4, "Revenue Recognition," of the notes to consolidated financial statements for further disclosure related to the net sales allocation between products and systems versus services revenue.

[0000833444-25-000097:mdna:23]
Cost of Sales / Gross Profit

[0000833444-25-000097:mdna:24]
|  | Year Ended September 30, |  |  |
| (in millions) | 2025 |  | 2024 |  | Change |
| Cost of sales | $ | 15,004 |  |  | $ | 14,875 |  |  | 1 | % |
| Gross profit | 8,592 |  |  | 8,077 |  |  | 6 | % |
| % of sales | 36.4 | % |  | 35.2 | % |  |  |

[0000833444-25-000097:mdna:25]
The increase in gross profit was primarily due to margin improvements in Products and Systems and increased volumes for both Products and Systems and Services. Refer to the "Segment Analysis" below within Item 7 for a discussion of segment earnings.

[0000833444-25-000097:mdna:26]
Selling, General and Administrative Expenses

[0000833444-25-000097:mdna:27]
|  | Year Ended September 30, |  |  |
| (in millions) | 2025 |  | 2024 |  | Change |
| Selling, general and administrative expenses | $ | 5,764 |  |  | $ | 5,661 |  |  | 2 | % |
| % of sales | 24.4 | % |  | 24.7 | % |  |  |

[0000833444-25-000097:mdna:28]
The increase in selling, general and administrative expenses ("SG&A") was primarily due to higher costs to support operations ($277 million), higher transformation costs ($180 million), and the unfavorable impact of prior year earn-out adjustments ($68 million), partially offset by the net favorable impact of the prior year water systems AFFF settlement and related insurance recoveries ($422 million).

[0000833444-25-000097:mdna:29]
Refer to the "Segment Analysis" below within Item 7 for a discussion of segment earnings. Refer to Note 20, "Commitments and Contingencies," of the notes to consolidated financial statements for further disclosure related to the water systems AFFF settlement.

[0000833444-25-000097:mdna:30]
Restructuring and Impairment Costs

[0000833444-25-000097:mdna:31]
|  |  |  | Year Ended September 30, |
| (in millions) |  |  | 2025 |  | 2024 |
| Goodwill and other intangible asset impairments |  |  | $ | 206 |  |  | $ | 296 |  |
| Held for sale impairments |  |  | — |  |  | 35 |  |
| Other impairments |  |  | 176 |  |  | 36 |  |
| Restructuring and related costs |  |  | 164 |  |  | 143 |  |
| Restructuring and impairment costs |  |  | $ | 546 |  |  | $ | 510 |  |

[0000833444-25-000097:mdna:32]
Refer to Note 6, "Property, Plant and Equipment," Note 7, "Goodwill and Other Intangible Assets," and Note 16, "Restructuring and Related Costs," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-25-000097:mdna:33]
Net Financing Charges

[0000833444-25-000097:mdna:34]
|  | Year Ended September 30, |  |  |
|  | 2025 |  | 2024 |  |  |
| Interest expense, net of capitalized interest costs | $ | 227 |  |  | $ | 381 |  |  |  |
| Other financing charges | 22 |  |  | 38 |  |  |  |
| Gain on debt extinguishment | (2) |  |  | (25) |  |  |  |
| Interest income | (19) |  |  | (17) |  |  |  |
| Net foreign exchange on financing activities | 91 |  |  | (35) |  |  |  |
| Net financing charges | $ | 319 |  |  | $ | 342 |  |  |  |

[0000833444-25-000097:mdna:35]
Refer to Note 9, "Debt and Financing Arrangements," of the notes to consolidated financial statements for further disclosure related to the Company's debt.

[0000833444-25-000097:mdna:36]
34

[0000833444-25-000097:mdna:37]
Income Tax Provision

[0000833444-25-000097:mdna:38]
|  | Year Ended September 30, |
| (in millions) | 2025 |  | 2024 |
| Income tax provision | $ | 245 |  |  | $ | 111 |  |
| Effective tax rate | 12 | % |  | 7 | % |

[0000833444-25-000097:mdna:39]
The increase in the effective tax rate was primarily due to non-recurring tax benefits in 2024.  Refer to Note 17, "Income Taxes," of the notes to consolidated financial statements for further details.

[0000833444-25-000097:mdna:40]
In October 2021, the Organization for Economic Co-operation and Development ("OECD")/G20 inclusive framework on Base Erosion and Profit Shifting (the Inclusive Framework) published a statement updating and finalizing the key components of a two-pillar plan on global tax reform which has now been agreed upon by the majority of OECD members. Pillar One allows countries to reallocate a portion of residual profits earned by multinational enterprises ("MNE"), with an annual global revenue exceeding €20 billion and a profit margin over 10%, to other market jurisdictions. The adoption of Pillar One and its potential effective date remain uncertain. Pillar Two requires MNEs with an annual global revenue exceeding €750 million to pay a global minimum tax of 15%. The OECD has since issued administrative guidance providing transition and safe harbor rules around the implementation of the Pillar Two Global Minimum Tax. A number of countries, including Ireland, have enacted legislation to implement the core elements of Pillar Two, which is applicable to the Company in fiscal 2025. The OECD and governments are continuing to evaluate and adjust the Global Minimum Tax rules through legislative updates, administrative guidance, and adoption by additional countries, which could result in an increase in our effective tax rate.

[0000833444-25-000097:mdna:41]
Income From Discontinued Operations, Net of Tax

[0000833444-25-000097:mdna:42]
|  | Year Ended September 30, |  |  |
| (in millions) | 2025 |  | 2024 |  | Change |
| Income from discontinued operations, net of tax | $ | 1,789 |  |  | $ | 489 |  |  | 266 | % |

[0000833444-25-000097:mdna:43]
The increase in income from discontinued operations, net of tax was primarily due to the gain on sale of the R&LC HVAC business. Refer to Note 2, "Acquisitions and Divestitures," of the notes to consolidated financial statements for further information.

[0000833444-25-000097:mdna:44]
SEGMENT ANALYSIS

[0000833444-25-000097:mdna:45]
The Chief Executive Officer, the Company’s CODM, evaluates the performance of its segments and allocates resources based on two profitability measures, Segment EBITA and Segment EBIT:

[0000833444-25-000097:mdna:46]
•Segment earnings before interest, taxes, and amortization (“EBITA”) represents income from continuing operations, before income taxes and noncontrolling interests, excluding corporate expenses, restructuring and impairment costs, AFFF related settlement costs and insurance recoveries, gains or losses on divestitures, net mark-to-market gains and losses related to pension and post-retirement plans and restricted asbestos investments, net finance charges, and amortization.  Segment EBITA is used as a tool to allow the CODM to evaluate the recurring profitability of the segments, including revenues and expenses that are within the operational control of the segments, and excluding the impact of certain non-cash and non-recurring items. Segment EBITA also provides the CODM with performance comparability across periods and for more accurate benchmarking against peer companies that may not have similar historical acquisition activity, by holding constant the impact of significant acquisitions.

[0000833444-25-000097:mdna:47]
•Segment earnings before interest and taxes ("EBIT") represents Segment EBITA, adding back the impact of amortization of intangible assets. Segment EBIT allows the CODM to review profitability, inclusive of the impact of significant acquisition activity, informing the CODM of how the business is integrating key strategic initiatives and generating synergies.

[0000833444-25-000097:mdna:48]
Both EBITA and EBIT are reviewed by the CODM and compared against the profit plan and forecast for the current and prior year. Segment EBITA and Segment EBIT are not defined under GAAP and may not be comparable to similarly titled measures used by other companies. Measures of total assets by reportable segment are not provided to the CODM. Therefore, asset information by segment is not disclosed.

[0000833444-25-000097:mdna:49]
35

[0000833444-25-000097:mdna:50]
Financial information relating to the Company’s reportable segments is as follows (in millions):

[0000833444-25-000097:mdna:51]
|  | Year Ended September 30, 2025 |
|  | Americas |  | EMEA |  | APAC |
| Net sales | $ | 15,831 |  |  | $ | 4,968 |  |  | $ | 2,797 |  |
| Cost of sales | 9,742 |  | 3,228 |  | 1,777 |
| Selling, general and administrative expenses | 3,206 |  | 1,094 |  | 548 |
| Equity income (loss) | 1 |  | (3) |  |  | (4) |  |
| Segment EBITA | 2,882 |  | 649 |  | 476 |
| Amortization of intangible assets | 356 |  |  | 68 |  |  | 15 |  |
| Segment EBIT | $ | 2,526 |  |  | $ | 581 |  |  | $ | 461 |  |

[0000833444-25-000097:mdna:52]
|  | Year Ended September 30, 2024 |
|  | Americas |  | EMEA |  | APAC |
| Net sales | $ | 15,606 |  |  | $ | 4,620 |  |  | $ | 2,726 |  |
| Cost of sales | 9,922 |  |  | 3,024 |  |  | 1,692 |  |
| Selling, general and administrative expenses | 3,003 |  |  | 996 |  |  | 558 |  |
| Equity income (loss) | 2 |  |  | 39 |  |  | (2) |  |
| Segment EBITA | 2,679 |  | 561 |  | 478 |
| Amortization of intangible assets | 379 |  |  | 80 |  |  | 17 |  |
| Segment EBIT | $ | 2,300 |  |  | $ | 481 |  |  | $ | 461 |  |

[0000833444-25-000097:mdna:53]
|  | Year Ended September 30, 2023 |
|  | Americas |  | EMEA |  | APAC |
| Net sales | $ | 14,529 |  |  | $ | 4,491 |  |  | $ | 3,311 |  |
| Cost of sales | 9,241 |  |  | 3,035 |  |  | 2,102 |  |
| Selling, general and administrative expenses | 2,945 |  |  | 1,039 |  |  | 602 |  |
| Equity income (loss) | — |  |  | (1) |  |  | (2) |  |
| Segment EBITA | 2,343 |  |  | 418 |  |  | 609 |  |
| Amortization of intangible assets | 337 |  |  | 74 |  |  | 15 |  |
| Segment EBIT | $ | 2,006 |  |  | $ | 344 |  |  | $ | 594 |  |

[0000833444-25-000097:mdna:54]
Refer to Note 18, "Segment Information," for a reconciliation of Segment EBITA and Segment EBIT to Income from continuing operations before income taxes.

[0000833444-25-000097:mdna:55]
36

[0000833444-25-000097:mdna:56]
Net Sales

[0000833444-25-000097:mdna:57]
|  | Net Sales for the Year Ended September 30, |  |  |
| (in millions) | 2025 |  | 2024 |  | Change |
| Americas | $ | 15,831 |  |  | $ | 15,606 |  |  | 1 | % |
| EMEA | 4,968 |  |  | 4,620 |  |  | 8 | % |
| APAC | 2,797 |  |  | 2,726 |  |  | 3 | % |
|  | $ | 23,596 |  |  | $ | 22,952 |  |  | 3 | % |

[0000833444-25-000097:mdna:58]
•The increase in Americas was primarily due to organic growth ($1,058 million), partially offset by the impact of divestitures ($799 million) and the unfavorable impact of foreign currency translation ($34 million). Excluding the impact of divestitures and foreign currency translation, sales increased 7%, led by growth in Applied HVAC and Controls.

[0000833444-25-000097:mdna:59]
•The increase in EMEA was primarily due to organic growth ($295 million), favorable foreign currency translation ($40 million), and incremental sales related to the net impact of business acquisitions and divestitures ($13 million). Excluding the impact of business acquisitions, divestitures, and foreign currency translation, sales growth was led by 8% growth in Services.

[0000833444-25-000097:mdna:60]
•The increase in APAC was primarily due to organic growth ($77 million), partially offset by the unfavorable impact of foreign currency translation. Excluding the impact of foreign currency translation, sales growth was led by 12% growth in Services.

[0000833444-25-000097:mdna:61]
Segment EBITA and Segment EBIT

[0000833444-25-000097:mdna:62]
|  |  | Segment EBITAfor the Year EndedSeptember 30, |  |  |  | Segment EBITfor the Year EndedSeptember 30 |  |  |
| (in millions) |  | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Americas |  | $ | 2,882 |  |  | $ | 2,679 |  |  | 8 | % |  | $ | 2,526 |  |  | $ | 2,300 |  |  | 10 | % |
| EMEA |  | 649 |  |  | 561 |  |  | 16 | % |  | 581 |  |  | 481 |  |  | 21 | % |
| APAC |  | 476 |  |  | 478 |  |  | — | % |  | 461 |  |  | 461 |  |  | — | % |

[0000833444-25-000097:mdna:63]
•The increases for Americas were primarily due to higher margin backlog conversion and volumes, partially offset by the impact of prior year earn-out adjustments.

[0000833444-25-000097:mdna:64]
•The increases in EMEA were primarily driven by productivity improvements and positive mix from the growth in Services.

[0000833444-25-000097:mdna:65]
•APAC was consistent with the prior year as increases in volume were offset by pricing challenges.

[0000833444-25-000097:mdna:66]
Net Sales

[0000833444-25-000097:mdna:67]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |
| Americas | $ | 15,606 |  |  | $ | 14,529 |  |  | 7 | % |
| EMEA | 4,620 |  |  | 4,491 |  |  | 3 | % |
| APAC | 2,726 |  |  | 3,311 |  |  | (18) | % |
|  | $ | 22,952 |  |  | $ | 22,331 |  |  | 3 | % |

[0000833444-25-000097:mdna:68]
•The increase in Americas was primarily due to organic growth. Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales growth was led by Commercial and Applied HVAC & Controls, partially offset by declines in Fire & Security and Industrial Refrigeration.

[0000833444-25-000097:mdna:69]
•The increase in EMEA was primarily due to organic growth, including higher prices, and the net impact of business acquisitions and divestitures, partially offset by the negative impact of foreign currency translation. Excluding the impact of foreign currency translation and business acquisitions and divestitures, sales growth was led by growth in Services.

[0000833444-25-000097:mdna:70]
•The decrease in APAC was primarily due to organic sales declines, the negative impact of foreign currency translation and the net impact of business acquisitions and divestitures. Excluding the impact of foreign currency translation and business acquisitions and divestitures, sales decreased as Services growth was more than offset by weakness in the China Systems business.

[0000833444-25-000097:mdna:71]
Segment EBITA and Segment EBIT

[0000833444-25-000097:mdna:72]
|  |  | Segment EBITAfor the Year EndedSeptember 30, |  |  |  | Segment EBITfor the Year EndedSeptember 30 |  |  |
| (in millions) |  | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Americas |  | $ | 2,679 |  |  | $ | 2,343 |  |  | 14 | % |  | $ | 2,300 |  |  | $ | 2,006 |  |  | 15 | % |
| EMEA |  | 561 |  |  | 418 |  |  | 34 | % |  | 481 |  |  | 344 |  |  | 40 | % |
| APAC |  | 478 |  |  | 609 |  |  | (22) | % |  | 461 |  |  | 594 |  |  | (22) | % |

[0000833444-25-000097:mdna:73]
•The increases for Americas were primarily due to higher margin backlog conversion, continued growth in Services and operational efficiencies leading to productivity improvements. A favorable earn-out liability adjustment also contributed to the increase in EBITA and EBIT.

[0000833444-25-000097:mdna:74]
•The increases in EMEA were primarily due to growth in higher margin Services and productivity improvements.

[0000833444-25-000097:mdna:75]
•The decreases for APAC were primarily due to continued weakness in the Systems business in China.

[0000833444-25-000097:mdna:76]
LIQUIDITY AND CAPITAL RESOURCES

[0000833444-25-000097:mdna:77]
Working Capital

[0000833444-25-000097:mdna:78]
|  | September 30, |  |  |
| (in millions) | 2025 |  | 2024 |  | Change |
| Current assets | $ | 10,162 |  |  | $ | 11,179 |  |  | (9) | % |
| Current liabilities | (10,941) |  |  | (11,955) |  |  | (8) | % |
| Working capital | $ | (779) |  |  | $ | (776) |  |  | — | % |
| Accounts receivable - net | $ | 6,269 |  |  | $ | 6,051 |  |  | 4 | % |
| Inventories | 1,820 |  |  | 1,774 |  |  | 3 | % |
| Accounts payable | 3,614 |  |  | 3,389 |  |  | 7 | % |

[0000833444-25-000097:mdna:79]
38

[0000833444-25-000097:mdna:80]
Working capital at September 30, 2025 was consistent with September 30, 2024 as decreases in short-term debt and increases in accounts receivable and other current assets were offset by decreases in cash, working capital associated with dispositions and  various current liabilities.

[0000833444-25-000097:mdna:81]
Cash Flows

[0000833444-25-000097:mdna:82]
|  | Year Ended September 30, |
| (in millions) | 2025 |  | 2024 |
| Continuing operations |  |  |  |
| Cash provided by operating activities | $ | 2,554 |  |  | $ | 1,568 |  |
| Cash used by investing activities | (412) |  |  | (184) |  |
| Cash used by financing activities | (6,784) |  |  | (1,948) |  |
| Discontinued operations |  |  |  |
| Cash provided by discontinued operations | $ | 4,787 |  |  | $ | 361 |  |

[0000833444-25-000097:mdna:83]
•The increase in cash provided by operating activities reflects higher net income and favorable changes in accounts receivable, partially offset by the timing of accrued income tax payments.

[0000833444-25-000097:mdna:84]
•The increase in cash used by investing activities was primarily due to proceeds from the ADTi divestiture in fiscal 2024, partially offset by the decrease in capital expenditures.

[0000833444-25-000097:mdna:85]
•The increase in cash used by financing activities was primarily due to the Accelerated Share Repurchase Transactions ("ASR Transactions").

[0000833444-25-000097:mdna:86]
•The increase in cash provided by discontinued operations was primarily due to the net proceeds from the sale of the R&LC HVAC business, partially offset by dividends paid.

[0000833444-25-000097:mdna:87]
Capitalization

[0000833444-25-000097:mdna:88]
|  | September 30, |  |
| (in millions) | 2025 |  | 2024 |  |
| Short-term debt | $ | 723 |  |  | $ | 953 |  |  |
| Current portion of long-term debt | 566 |  |  | 536 |  |  |
| Long-term debt | 8,591 |  |  | 8,004 |  |  |
| Total debt | 9,880 |  |  | 9,493 |  |  |
| Less: Cash and cash equivalents | 379 |  |  | 606 |  |  |
| Net debt | $ | 9,501 |  |  | $ | 8,887 |  |  |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders ("Equity") | $ | 12,927 |  |  | $ | 16,098 |  |  |
| Total capitalization (Total debt plus Equity) | 22,807 |  |  | 25,591 |  |  |
| Net capitalization (Net debt plus Equity) | 22,428 |  |  | 24,985 |  |  |
| Total debt as a % of Total capitalization | 43.3 | % |  | 37.1 | % |  |
| Net debt as a % of Net capitalization | 42.4 | % |  | 35.6 | % |  |

[0000833444-25-000097:mdna:89]
•Net debt and net debt as a percentage of net capitalization are non-GAAP financial measures. The Company believes the percentage of net debt to net capitalization is useful to understanding the Company’s financial condition as it provides a view of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders.

[0000833444-25-000097:mdna:90]
•The Company's material cash requirements primarily consist of working capital requirements, repayments of long-term debt and related interest, operating leases, dividends, capital expenditures, potential acquisitions and share repurchases.

[0000833444-25-000097:mdna:91]
39

[0000833444-25-000097:mdna:92]
•Refer to Note 9, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information on debt obligations and maturities. Interest payable on long-term debt outstanding as of September 30, 2025 is $326 million in the twelve months following September 30, 2025 and $3.3 billion thereafter.

[0000833444-25-000097:mdna:93]
•Refer to Note 8, "Leases," of the notes to consolidated financial statements for additional information on lease obligations and maturities.

[0000833444-25-000097:mdna:94]
•The Company received net cash proceeds related to the sale of its R&LC HVAC business of approximately $5.6 billion after tax and transaction-related expenses in connection with the close of the transaction on July 31, 2025. Consistent with its capital allocation policy and pursuant to its previously announced share repurchase authorization, the Company returned the net proceeds of the transaction to shareholders through the $5.0 billion ASR Transactions which were launched in August 2025 and are expected to be completed in the second quarter of fiscal 2026. The total number of the Company’s ordinary shares (the "Shares") to be repurchased under the ASR Transactions will be based on volume-weighted average prices of the Shares during the term of the ASR Transactions, less a discount and subject to customary adjustments.

[0000833444-25-000097:mdna:95]
•As of September 30, 2025, the Company had purchase obligations which were payable in the next twelve months of approximately $2 billion and payable thereafter of approximately $0.2 billion. These purchase obligations represent commitments under enforceable and legally binding agreements, and do not represent all future expected purchases.

[0000833444-25-000097:mdna:96]
•As of September 30, 2025, the Company expects to contribute $23 million and $162 million to the global pension and postretirement plans in the next twelve months and thereafter, respectively.

[0000833444-25-000097:mdna:97]
•As of September 30, 2025, approximately $4.8 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity and economic environment.

[0000833444-25-000097:mdna:98]
•The Company declared dividends of $1.51 per share in fiscal 2025 and intends to continue paying quarterly dividends in fiscal 2026. The authority to declare and pay dividends is vested in the Board of Directors. The timing, declaration and payment of future dividends to holders of the Company's ordinary shares is determined by the Company's Board of Directors and depends upon many factors, including the Company's financial condition and results of operations, the capital requirements of the Company's businesses, industry practice and any other relevant factors.

[0000833444-25-000097:mdna:99]
•The Company believes its capital resources and liquidity position, including cash and cash equivalents of $379 million at September 30, 2025, are adequate to fund operations and meet its cash obligations for the foreseeable future.

[0000833444-25-000097:mdna:100]
–The Company manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. Commercial paper outstanding was $400 million as of September 30, 2025 and $350 million as of September 30, 2024.

[0000833444-25-000097:mdna:101]
–The Company maintains a shelf registration statement with the SEC under which it may issue additional debt securities, ordinary shares, preferred shares, depository shares, warrants, purchase contracts and units that may be offered in one or more offerings on terms to be determined at the time of the offering. The Company anticipates that the proceeds of any offering would be used for general corporate purposes, including repayment of indebtedness, acquisitions, additions to working capital, repurchases of ordinary shares, dividends, capital expenditures and investments in the Company's subsidiaries.

[0000833444-25-000097:mdna:102]
–The Company has the ability to draw on its syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2028, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2025. There were no draws on the facilities as of September 30, 2025.

[0000833444-25-000097:mdna:103]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of September 30, 2025, the Company's credit ratings and outlook were as follows:

[0000833444-25-000097:mdna:104]
40

[0000833444-25-000097:mdna:105]
| Rating Agency |  | Short-Term Rating |  | Long-Term Rating |  | Outlook |
| S&P |  | A-2 |  | BBB+ |  | Stable |
| Moody's |  | P-2 |  | Baa1 |  | Stable |

[0000833444-25-000097:mdna:106]
The security ratings set forth above are issued by unaffiliated third-party rating agencies and are not a recommendation to buy, sell or hold securities. The ratings may be subject to revision or withdrawal by the assigning rating organization at any time.

[0000833444-25-000097:mdna:107]
•Financial covenants in the Company's revolving credit facilities require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of ASC 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of September 30, 2025, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-25-000097:mdna:108]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-25-000097:mdna:109]
•The Company may from time to time purchase its outstanding debt through open market purchases, privately negotiated transactions or otherwise. Purchases or retirement of debt, if any, will depend on prevailing market conditions, liquidity requirements, contractual restrictions and other factors. The amounts involved may be material.

[0000833444-25-000097:mdna:110]
Co-Issued Securities: Summarized Financial Information

[0000833444-25-000097:mdna:111]
The following information is provided in compliance with Rule 13-01 of Regulation S-X under the Securities Exchange Act of 1934 with respect to the following unsecured, unsubordinated senior notes (collectively, the "Notes") which were issued by Johnson Controls International plc ("Parent Company") and Tyco Fire & Security Finance S.C.A. (“TFSCA”):

[0000833444-25-000097:mdna:112]
•€500 million aggregate principal amount of 0.375% Senior Notes due September 2027

[0000833444-25-000097:mdna:113]
•€600 million aggregate principal amount of 3.000% Senior Notes due September 2028

[0000833444-25-000097:mdna:114]
•$700 million aggregate principal amount of 5.500% Senior Notes due April 2029

[0000833444-25-000097:mdna:115]
•$625 million aggregate principal amount of 1.750% Senior Notes due September 2030

[0000833444-25-000097:mdna:116]
•$500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due September 2031

[0000833444-25-000097:mdna:117]
•€500 million aggregate principal amount of 1.000% Senior Notes due September 2032

[0000833444-25-000097:mdna:118]
•$650 million aggregate principal amount of 4.900% Senior Notes due December 2032

[0000833444-25-000097:mdna:119]
•€500 million aggregate principal amount of 3.125% Senior Notes due December 2033

[0000833444-25-000097:mdna:120]
•€800 million aggregate principal amount of 4.250% Senior Notes due May 2035

[0000833444-25-000097:mdna:121]
TFSCA is a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”) and is a wholly-owned consolidated subsidiary of the Company that

[0000833444-25-000097:mdna:122]
is 99.924% owned directly by the Parent Company and 0.076% owned by TFSCA’s sole general partner and manager, Tyco Fire & Security S.à r.l., which is itself wholly-owned by the Company. The Parent Company is incorporated and organized under the laws of Ireland. TFSCA is incorporated and organized under the laws of Luxembourg. The bankruptcy, insolvency, administrative, debtor relief and other laws of Luxembourg or Ireland, as applicable, may be materially different from, or in conflict with, those of the United States, including in the areas of rights of creditors, priority of governmental and other creditors, ability to obtain post-petition interest and duration of the proceeding. The application of these laws, or any conflict among them, could adversely affect noteholders’ ability to enforce their rights under the Notes in those jurisdictions or limit any amounts that they may receive.

[0000833444-25-000097:mdna:123]
The following table presents the net loss attributable to the Parent Company and TFSCA (collectively, the "Obligor Group") and the net loss attributable to intercompany transactions between the Obligor Group and subsidiaries of the Parent Company other than TFSCA (collectively, the "Non-Obligor Subsidiaries") which are excluded from the Net loss attributable to the Obligor Group (in millions):

[0000833444-25-000097:mdna:124]
|  |  | Year Ended September 30, 2025 |  |  |  |
| Net loss attributable to the Obligor Group |  | $ | 844 |  |  |  |  |
| Net loss attributable to intercompany transactions |  | 56 |  |  |  |  |

[0000833444-25-000097:mdna:125]
The following table presents summarized balance sheet information as of September 30, 2025 (in millions):

[0000833444-25-000097:mdna:126]
|  |  | ObligorGroup |  | Intercompany Balances |  |
| Current assets |  | $ | 2,748 |  |  | $ | 6,161 |  |  |
| Noncurrent assets |  | 243 |  |  | 2,450 |  |  |
| Current liabilities |  | 1,585 |  |  | 4,041 |  |  |
| Noncurrent liabilities |  | 8,473 |  |  | 22,450 |  | * |

[0000833444-25-000097:mdna:127]
*Includes $17 billion of intercompany loans that were canceled as the result of a distribution by a non-obligor subsidiary in October 2025.

[0000833444-25-000097:mdna:128]
The same accounting policies as described in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements are used by the Parent Company and each of its subsidiaries in connection with the summarized financial information presented above.

[0000833444-25-000097:mdna:129]
CRITICAL ACCOUNTING ESTIMATES

[0000833444-25-000097:mdna:130]
The Company prepares its consolidated financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). This requires management to make estimates and assumptions that affect reported amounts and related disclosures. Actual results could differ from those estimates. The following estimates are considered by management to be the most critical to the understanding of the Company's consolidated financial statements as they require significant judgments that could materially impact the Company’s results of operations, financial position and cash flows.

[0000833444-25-000097:mdna:131]
Revenue Recognition

[0000833444-25-000097:mdna:132]
The Company recognizes revenue from certain long-term contracts on an over-time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. Total estimated costs at completion are based primarily on estimated purchase contract terms, historical performance trends and other economic projections. Factors that may result in a change to these estimates include unforeseen engineering problems, construction delays, cost inflation, the performance of internal labor, subcontractors and major material suppliers, and weather conditions. As a result, changes to the original estimates may be required during the life of the contract. Such estimates are reviewed monthly and any adjustments to the measure of completion are recognized as adjustments to sales and gross profit using the cumulative catch-up method. Estimated losses are recorded when identified.

[0000833444-25-000097:mdna:133]
For agreements with multiple performance obligations, the Company allocates the transaction price of the contract to each performance obligation using the best estimate of the relative standalone selling price of each distinct good or service in the contract. In order to estimate relative standalone selling price, market data and transfer price studies are utilized. If the

[0000833444-25-000097:mdna:134]
standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach.

[0000833444-25-000097:mdna:135]
The Company assesses variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

[0000833444-25-000097:mdna:136]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-25-000097:mdna:137]
The Company performs impairment reviews for its reporting units, which have been determined to be one level below the Company's operating segments, using a qualitative assessment or a quantitative test. A qualitative assessment is performed when prior quantitative assessments have resulted in significant excess of fair value over the carrying value of a reporting unit, and consideration of qualitative factors allow the Company to conclude it is more likely than not that the fair value of the reporting unit remains greater than its carrying value. When performing a quantitative goodwill impairment test, the fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. To estimate the fair value, the Company uses a discounted cash flow model, the guideline company method under the market approach, or estimated sales price for reporting units held for sale. The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations. The key assumptions used in the impairment tests were management's projections of future cash flows, earnings before interest, taxes, depreciation and amortization (“EBITDA”), weighted-average cost of capital, EBITDA multiples, and long-term growth rates. Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying business, there are significant judgments in determining the expected future cash flows attributable to a reporting unit.

[0000833444-25-000097:mdna:138]
Management completed its fiscal 2025 annual impairment test as of July 31, which included a qualitative assessment of all of its reporting units. The Company did not identify any qualitative factors that suggest that it is more likely than not that the fair value of its reporting units is less than their carrying amount, including goodwill, and as such, a quantitative impairment test was not necessary.

[0000833444-25-000097:mdna:139]
Indefinite-lived intangible assets are also subject to at least annual impairment testing in the fourth fiscal quarter or as events occur or circumstances change that indicate the assets may be impaired. Indefinite-lived intangible assets primarily consist of trademarks and trade names and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests. The key assumptions used in the impairment tests were long-term revenue growth projections, weighted-average cost of capital, and the royalty rate. The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations.

[0000833444-25-000097:mdna:140]
The Company continuously monitors for events and circumstances that could negatively impact the key assumptions in determining fair value. While the Company believes the judgments and assumptions used in the goodwill and indefinite-lived intangible impairment tests are reasonable, different assumptions or changes in general industry, market and macro-economic conditions could change the estimated fair values and, therefore, future impairment charges could be required, which could be material to the consolidated financial statements.

[0000833444-25-000097:mdna:141]
Refer to Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for information regarding the results of goodwill and indefinite-lived intangible assets impairment testing performed in fiscal 2025, 2024, and 2023.

[0000833444-25-000097:mdna:142]
Pension Plans

[0000833444-25-000097:mdna:143]
The Company provides a range of benefits, including pensions, to eligible active and former employees. Pension plan assets and obligations are measured annually, or more frequently if there is a significant remeasurement event, using various actuarial assumptions such as discount rates, assumed rates of return and compensation increases as of that date. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends when appropriate.

[0000833444-25-000097:mdna:144]
The Company considers expected benefit payments on a plan-by-plan basis when estimating discount rates. Different discount rates are used for each plan depending on the plan jurisdiction and the expected timing of benefit payments. The Company uses

[0000833444-25-000097:mdna:145]
country-specific discount rates determined by an independent third party which are based on government and high-quality corporate bond yields.

[0000833444-25-000097:mdna:146]
In estimating the expected return on plan assets, the Company considers historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions, asset mix and the impact of the active management of the plans’ invested assets. For fiscal 2026, the Company believes the long-term rate of return will approximate 6.65% for U.S. pension plans and 6.04% for non-U.S. pension plans. Any differences between actual investment results and the expected long-term asset returns will be reflected in net periodic benefit costs in the fourth quarter of each fiscal year or at the date of a significant remeasurement event. If actual returns on plan assets are less than the Company’s expectations, additional contributions may be required.

[0000833444-25-000097:mdna:147]
Based on information provided by its independent actuaries and other relevant sources, the Company believes that the assumptions used are reasonable, however, changes in these assumptions could impact the Company’s financial position, results of operations or cash flows. The estimated changes in projected benefit obligation and future ongoing pension expense, excluding any potential mark-to-market adjustments, assuming an increase of 25 basis points in the key assumptions used for the Company's pension plans are immaterial.

[0000833444-25-000097:mdna:148]
Loss Contingencies

[0000833444-25-000097:mdna:149]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business when it is probable a liability has been incurred and the amount of the liability can be reasonably estimated. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarial determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-25-000097:mdna:150]
The Company is subject to laws and regulations relating to protecting the environment. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. Refer to Note 20, "Commitments and Contingencies," of the notes to consolidated financial statements.

[0000833444-25-000097:mdna:151]
Liabilities and expenses for workers' compensation, product, general and auto liabilities are dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage its insurable liabilities

[0000833444-25-000097:mdna:152]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-25-000097:mdna:153]
The Company and certain of its subsidiaries, along with numerous other companies, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The estimated liability and corresponding insurance recovery for pending and future claims and defense costs are based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present values from the time that the costs are expected to be incurred which in some cases is not until 2068 (which is the Company's reasonable best estimate of the actuarial determined time period through which asbestos-related claims will be filed against its affiliates). Estimated asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and its defense strategy. The Company also evaluates

[0000833444-25-000097:mdna:154]
the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims or insurance receivable is warranted.

[0000833444-25-000097:mdna:155]
The Company records asbestos-related insurance recoveries that are probable. Estimated asbestos-related insurance recoveries represent estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers.

[0000833444-25-000097:mdna:156]
Refer to Note 20, "Commitments and Contingencies," of the notes to consolidated financial statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.

[0000833444-25-000097:mdna:157]
Income Taxes

[0000833444-25-000097:mdna:158]
Deferred tax assets and liabilities are recognized for the expected future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and other loss carryforwards. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company records a valuation allowance that primarily represents non-U.S. operating and other loss carryforwards for which realization is uncertain. Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, and the valuation allowance recorded against the Company’s net deferred tax assets.

[0000833444-25-000097:mdna:159]
The Company reviews the realizability of its deferred tax assets and related valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary. At September 30, 2025, the Company had a valuation allowance of $6.3 billion for continuing operations, of which $5.9 billion relates to net operating and capital loss carryforwards primarily in France, Ireland, Luxembourg, Mexico, and the United Kingdom for which sustainable taxable income has not been demonstrated; and $0.4 billion for other deferred tax assets.

[0000833444-25-000097:mdna:160]
The Company’s federal income tax returns and certain non-U.S. income tax returns for various fiscal years remain under various stages of audit by the IRS and respective non-U.S. tax authorities. Although the outcome of tax audits is always uncertain, management believes that it has appropriate support for the positions taken on its tax returns and that its annual tax provisions included amounts sufficient to pay assessments, if any, which may be proposed by the taxing authorities. At September 30, 2025, the Company had recorded a liability of $1.9 billion for its best estimate of the probable loss on certain of its tax positions, the majority of which is included in other noncurrent liabilities in the consolidated statements of financial position. Nonetheless, the amounts ultimately paid, if any, upon resolution of the issues raised by the taxing authorities may differ materially from the amounts accrued for each year.

[0000833444-25-000097:mdna:161]
The Company does not generally provide additional U.S. or non-U.S. income taxes on outside basis differences of consolidated subsidiaries included in shareholders’ equity attributable to Johnson Controls International plc, except in limited circumstances including anticipated taxation on planned divestitures. The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income. The Company’s intent is to reduce the outside basis differences only when it would be tax efficient. Refer to "Capitalization" within the "Liquidity and Capital Resources" section for discussion of U.S. and non-U.S. cash projections.

[0000833444-25-000097:mdna:162]
Refer to Note 17, "Income Taxes," of the notes to consolidated financial statements for the Company's income tax disclosures.

[0000833444-25-000097:mdna:163]
NEW ACCOUNTING PRONOUNCEMENTS

[0000833444-25-000097:mdna:164]
Refer to the "New Accounting Pronouncements" section within Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements.

[0000833444-25-000097:mdna:165]
RISK MANAGEMENT

[0000833444-25-000097:mdna:166]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, and interest rates. All hedging transactions are authorized and executed pursuant to clearly defined policies and procedures, which strictly prohibit the use of financial instruments for speculative purposes. At the inception of the hedge, the

[0000833444-25-000097:mdna:167]
Company assesses the effectiveness of the hedge instrument and designates the hedge instrument as a hedge of either a forecasted transaction or of the variability of cash flows to be received or paid related to an unrecognized asset or liability (a cash flow hedge) or a net investment in a non-U.S. operation (a net investment hedge).

[0000833444-25-000097:mdna:168]
The Company performs hedge effectiveness testing on an ongoing basis depending on the type of hedging instrument used. All derivatives not designated as hedging instruments under ASC 815, "Derivatives and Hedging," are revalued in the consolidated statements of income.

[0000833444-25-000097:mdna:169]
For all foreign currency derivative instruments designated as cash flow hedges, retrospective effectiveness is tested on a monthly basis using a cumulative dollar offset test. The fair value of the hedged exposures and the fair value of the hedge instruments are revalued, and the ratio of the cumulative sum of the periodic changes in the value of the hedge instruments to the cumulative sum of the periodic changes in the value of the hedge is calculated. The hedge is deemed as highly effective if the ratio is between 80% and 125%. For commodity derivative contracts designated as cash flow hedges, effectiveness is tested using a qualitative assessment of the critical terms of the hedging instrument and the hedged item. Ineffectiveness is minimal as the Company aligns most of the critical terms of its derivatives with the supply contracts.

[0000833444-25-000097:mdna:170]
For net investment hedges, the Company assesses its net investment positions in the non-U.S. operations and compares it with the outstanding net investment hedges on a quarterly basis. The hedge is deemed effective if the aggregate outstanding principal of the hedge instruments designated as the net investment hedge in a non-U.S. operation does not exceed the Company’s net investment positions in the respective non-U.S. operation.

[0000833444-25-000097:mdna:171]
Derivative instruments not designated as hedging instruments under ASC 815 require no assessment of effectiveness.

[0000833444-25-000097:mdna:172]
A discussion of the Company’s accounting policies for derivative financial instruments is included in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements, and further disclosure relating to derivatives and hedging activities is included in Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements.

[0000833444-25-000097:mdna:173]
Foreign Exchange

[0000833444-25-000097:mdna:174]
The Company has manufacturing, sales and distribution facilities around the world and thus makes investments and enters into transactions denominated in various foreign currencies. In order to maintain strict control and achieve the benefits of the Company’s global diversification, foreign exchange exposures for each currency are netted internally so that only its net foreign exchange exposures are, as appropriate, hedged with financial instruments.

[0000833444-25-000097:mdna:175]
The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. The Company primarily enters into foreign currency exchange contracts to reduce the earnings and cash flow impact of the variation of non-functional currency denominated receivables and payables. Gains and losses resulting from hedging instruments offset the foreign exchange gains or losses on the underlying assets and liabilities being hedged. The maturities of the forward exchange contracts generally coincide with the settlement dates of the related transactions. Realized and unrealized gains and losses on these contracts are recognized in the same period as gains and losses on the hedged items. The Company also selectively hedges anticipated transactions that are subject to foreign exchange exposure, primarily with foreign currency exchange contracts, which are designated as cash flow hedges in accordance with ASC 815.

[0000833444-25-000097:mdna:176]
The Company has entered into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of debt obligations are reflected in the accumulated other comprehensive income ("AOCI") account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-25-000097:mdna:177]
At September 30, 2025 and 2024, the Company estimates that an unfavorable 10% change in the exchange rates would have decreased net unrealized gains by approximately $214 million and $144 million, respectively.

[0000833444-25-000097:mdna:178]
Interest Rates

[0000833444-25-000097:mdna:179]
Substantially all of the Company's outstanding debt has fixed interest rates, and, therefore, any fluctuation in market interest rates is not expected to have a material effect on the Company's results of operations. A 100 basis point increase/decrease in the average interest rate on the Company's variable rate debt would have an immaterial impact on interest expense.

[0000833444-25-000097:mdna:180]
Commodities

[0000833444-25-000097:mdna:181]
The Company uses commodity hedge contracts in the financial derivatives market in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As a cash flow hedge, gains and losses resulting from the hedging instruments offset the gains or losses on purchases of the underlying commodities that will be used in the business. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-25-000097:mdna:182]
ENVIRONMENTAL, HEALTH AND SAFETY AND OTHER MATTERS

[0000833444-25-000097:mdna:183]
The Company’s global operations are governed by environmental laws and worker safety laws. Under various circumstances, these laws impose civil and criminal penalties and fines, as well as injunctive and remedial relief, for noncompliance and require remediation at sites where Company-related substances have been released into the environment.

[0000833444-25-000097:mdna:184]
The Company has expended substantial resources globally, both financial and managerial, to comply with applicable environmental laws and worker safety laws and to protect the environment and workers. The Company believes it is in substantial compliance with such laws and maintains procedures designed to foster and ensure compliance. However, the Company has been, and in the future may become, the subject of formal or informal enforcement actions or proceedings regarding noncompliance with such laws or the remediation of Company-related substances released into the environment. Such matters typically are resolved with regulatory authorities through commitments to compliance, abatement or remediation programs and in some cases payment of penalties.

[0000833444-25-000097:mdna:185]
Refer to Note 20, "Commitments and Contingencies," of the notes to consolidated financial statements for additional information.
