# JCI MD&A — 0000833444-17-000007


## mdna

[0000833444-17-000007:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000833444-17-000007:mdna:2]
Cautionary Statements for Forward-Looking Information

[0000833444-17-000007:mdna:3]
Unless otherwise indicated, references to "Johnson Controls," the "Company," "we," "our" and "us" in this Quarterly Report on Form 10-Q refer to Johnson Controls International plc and its consolidated subsidiaries.

[0000833444-17-000007:mdna:4]
Overview

[0000833444-17-000007:mdna:5]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. The Company creates intelligent buildings, efficient energy solutions, integrated infrastructure and next generation transportation systems that work seamlessly together to deliver on the promise of smart cities and communities. The Company is committed to helping our customers win and creating greater value for all of its stakeholders through strategic focus on our buildings and energy growth platforms.

[0000833444-17-000007:mdna:6]
Johnson Controls was originally incorporated in the state of Wisconsin in 1885 as Johnson Electric Service Company to manufacture, install and service automatic temperature regulation systems for buildings. The Company was renamed to Johnson Controls, Inc. in 1974. In 1978, the Company acquired Globe-Union, Inc., a Wisconsin-based manufacturer of automotive batteries for both the replacement and original equipment markets. The Company entered the automotive seating industry in 1985 with the acquisition of Michigan-based Hoover Universal, Inc. In 2005, the Company acquired York International, a global supplier of heating, ventilating, air-conditioning and refrigeration equipment and services. In 2014, the Company acquired Air Distribution Technologies, Inc. (ADTi), one of the largest independent providers of air distribution and ventilation products in North America. On October 1, 2015, the Company formed a joint venture with Hitachi to expand its Building Technologies & Solutions product offerings.

[0000833444-17-000007:mdna:7]
In the fourth quarter of fiscal 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco completed their combination, with JCI Inc. merging with a wholly owned, indirect subsidiary of Tyco (the "Merger"). Following the Merger, Tyco changed its name to “Johnson Controls International plc” and JCI Inc. is a wholly-owned subsidiary of Johnson Controls International plc. The merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes. Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be

[0000833444-17-000007:mdna:8]
the historic financial statements of the Company. Refer to Note 3, "Merger Transaction," of the notes to consolidated financial statements for additional information.

[0000833444-17-000007:mdna:9]
The acquisition of Tyco brings together best-in-class product, technology and service capabilities across controls, fire, security, HVAC, power solutions and energy storage, to serve various end-markets including large institutions, commercial buildings, retail, industrial, small business and residential. The combination of the Tyco and Johnson Controls buildings platforms is expected to create immediate opportunities for near-term growth through cross-selling, complementary branch and channel networks, and expanded global reach for established businesses. The new Company is also expected to benefit by combining innovation capabilities and pipelines involving new products, advanced solutions for smart buildings and cities, value-added services driven by advanced data and analytics and connectivity between buildings and energy storage through infrastructure integration.

[0000833444-17-000007:mdna:10]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience Business from Johnson Controls to Adient plc ("Adient") and the issuance of ordinary shares of Adient directly to holders of Johnson Controls ordinary shares on a pro rata basis. Prior to the open of business on October 31, 2016, each of the Company's shareholders received one ordinary share of Adient plc for every 10 ordinary shares of Johnson Controls held as of the close of business on October 19, 2016, the record date for the distribution. Company shareholders received cash in lieu of fractional shares of Adient, if any. Following the separation and distribution, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc. Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation at December 31, 2016.

[0000833444-17-000007:mdna:11]
The Building Efficiency business is a global market leader in designing, producing, marketing and installing integrated heating, ventilating and air conditioning (HVAC) systems, building management systems, controls, security and mechanical equipment. In addition, the Building Efficiency business provides technical services and energy management consulting. The Company also provides residential air conditioning and heating systems and industrial refrigeration products.

[0000833444-17-000007:mdna:12]
The Tyco business is a global market leader in providing security products and services, fire detection and suppression products and services, and life and safety products. Tyco designs, sells, installs, services and monitors electronic security systems and fire detection and suppression systems. In addition, Tyco manufactures and sells fire protection, security and life safety products, including intrusion security, anti-theft devices, breathing apparatus and access control and video management systems. The products and services are  for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide.

[0000833444-17-000007:mdna:13]
The Power Solutions business is a leading global supplier of lead-acid automotive batteries for virtually every type of passenger car, light truck and utility vehicle. The Company serves both automotive original equipment manufacturers (OEMs) and the general vehicle battery aftermarket. The Company also supplies advanced battery technologies to power start-stop, hybrid and electric vehicles.

[0000833444-17-000007:mdna:14]
The following information should be read in conjunction with the September 30, 2016 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2016 filed with the SEC on November 23, 2016. References in the following discussion and analysis to "Three Months"(or similar language) refer to the three months ended December 31, 2016 compared to the three months ended December 31, 2015.

[0000833444-17-000007:mdna:15]
[same as prior period, unchanged from 0000833444-16-000197:mdna:125]

[0000833444-17-000007:mdna:16]
The Company believes its capital resources and liquidity position at December 31, 2016 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in fiscal 2017 will continue be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets.  In the event the Company and its wholly-owned indirect subsidiary, Tyco International Holding S.à.r.l ("TSarl"), are unable to issue commercial paper, they would have the ability to draw on their $2.0 billion and $1.0 billion revolving credit facilities, respectively. Both facilities mature in August 2020. There were no draws on the revolving credit facilities as of December 31, 2016. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-17-000007:mdna:17]
The Company’s debt financial covenants in its revolving credit facility require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times and allow a maximum aggregated amount of 10% of consolidated

[0000833444-17-000007:mdna:18]
shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating the covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification (ASC) 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. TSarl's, revolving credit facility contains customary terms and conditions, and financial covenants that limit the ratio of TSarl's debt to earnings before interest, taxes, depreciation, and amortization and excluding special items to 3.5x and that limit its ability to incur subsidiary debt or grant liens on its property. As of December 31, 2016, the Company and TSarl were in compliance with all covenants and other requirements set forth in their credit agreements and indentures and expect to remain in compliance for the foreseeable future. None of the Company’s or TSarl's debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the respective borrower's credit rating.

[0000833444-17-000007:mdna:19]
The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2017, the Company believes the long-term rate of return will approximate 7.50%, 3.40% and 5.60% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the three months ended December 31, 2016, the Company made approximately $247 million in total pension contributions. In total, the Company expects to contribute approximately $316 million in cash to its defined benefit pension plans in fiscal 2017. The Company expects to contribute $4 million in cash to its postretirement plans in fiscal 2017.

[0000833444-17-000007:mdna:20]
To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2017 and recorded $78 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and  asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs from continuing operations by approximately $60 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs and depreciation expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2018.  For fiscal 2017, the savings from continuing operations, net of execution costs, are expected to be approximately 50% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in 2017. The restructuring plan reserve balance of $62 million at December 31, 2016 is expected to be paid in cash.

[0000833444-17-000007:mdna:21]
To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2016 and recorded $288 million of restructuring and impairment costs in the consolidated statements of income within continuing operations. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments, change-in-control payments and immaterial changes in estimates to prior year plans. The Company currently estimates that upon completion of the restructuring action, the fiscal 2016 restructuring plan will reduce annual operating costs from continuing operations by approximately $135 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized by the end of fiscal 2018. For fiscal 2017, the savings from continuing operations, net of execution costs, are expected to be approximately 35% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in fiscal 2018. The restructuring plan reserve balance of $197 million at December 31, 2016 is expected to be paid in cash. Included in the reserve is $73 million of committed restructuring actions taken by Tyco for liabilities assumed as part of the Tyco Merger.

[0000833444-17-000007:mdna:22]
50

[0000833444-17-000007:mdna:23]
Net Sales

[0000833444-17-000007:mdna:24]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Net sales | $ | 7,086 |  |  | $ | 4,696 |  |  | 51 | % |

[0000833444-17-000007:mdna:25]
The increase in consolidated net sales for the three months ended December 31, 2016 was due to higher sales in the Building Technologies & Solutions business ($2,209 million) and the Power Solutions business ($171 million), and the favorable impact of foreign currency translation ($10 million). Incremental sales resulted from the Tyco Merger, higher global shipments and the impact of higher lead costs on pricing in the Power Solutions business, partially offset by lower volumes in the Building Efficiency Systems and Service North America segment. Excluding the favorable impacts of the Tyco Merger and foreign currency translation, consolidated net sales increased 2% as compared to the prior year. Refer to the "Segment Analysis" below within Item 2 for a discussion of net sales by segment.

[0000833444-17-000007:mdna:26]
Cost of Sales / Gross Profit

[0000833444-17-000007:mdna:27]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Cost of sales | $ | 4,972 |  |  | $ | 3,439 |  |  | 45 | % |
| Gross profit | 2,114 |  |  | 1,257 |  |  | 68 | % |
| % of sales | 29.8 | % |  | 26.8 | % |  |  |

[0000833444-17-000007:mdna:28]
Cost of sales for the three month period ended December 31, 2016 increased as compared to the three month period ended December 31, 2015, and gross profit as a percentage of sales increased by 300 basis points. Gross profit in the Building Technologies & Solutions business increased due to the incremental gross profit related to the Tyco Merger, and lower operating costs in the Building Efficiency Asia and Products North America segments, partially offset by the unfavorable impact of lower volumes in the Building Efficiency Systems and Service North America segment. Gross profit in the Power Solutions business was favorably impacted by higher volumes, and favorable pricing and product mix, partially offset by higher operating costs. Net mark-to-market adjustments on pension plans had a favorable impact on cost of sales of $10 million primarily due to an increase in discount rates. Foreign currency translation had a unfavorable impact on cost of sales of approximately $12 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment earnings before interest, taxes and amortization (EBITA) by segment.

[0000833444-17-000007:mdna:29]
Selling, General and Administrative Expenses

[0000833444-17-000007:mdna:30]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Selling, general and administrative expenses | $ | 1,570 |  |  | $ | 847 |  |  | 85 | % |
| % of sales | 22.2 | % |  | 18.0 | % |  |  |

[0000833444-17-000007:mdna:31]
Selling, general and administrative expenses (SG&A) for the three month period ended December 31, 2016 increased 85% as compared to the three month period ended December 31, 2015. The increase in SG&A was primarily due to incremental SG&A related to the Tyco Merger, partially offset by net mark-to-market adjustments on pension plans which had a favorable impact on on SG&A of $107 million primarily due to an increase in discount rates. Foreign currency translation had a unfavorable impact on SG&A of $4 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-17-000007:mdna:32]
51

[0000833444-17-000007:mdna:33]
Restructuring and Impairment Costs

[0000833444-17-000007:mdna:34]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Restructuring and impairment costs | $ | 78 |  |  | $ | — |  |  | * |

[0000833444-17-000007:mdna:35]
* Measure not meaningful

[0000833444-17-000007:mdna:36]
Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans.

[0000833444-17-000007:mdna:37]
Net Financing Charges

[0000833444-17-000007:mdna:38]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Net financing charges | $ | 136 |  |  | $ | 66 |  |  | * |

[0000833444-17-000007:mdna:39]
* Measure not meaningful

[0000833444-17-000007:mdna:40]
Net financing charges were higher for the three month period ended December 31, 2016 as compared to the three month period ended December 31, 2015, primarily due to higher average borrowing levels due to the debt assumed as a result of the Tyco Merger and debt exchange offer fees.

[0000833444-17-000007:mdna:41]
Equity Income

[0000833444-17-000007:mdna:42]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Equity income | $ | 55 |  |  | $ | 42 |  |  | 31 | % |

[0000833444-17-000007:mdna:43]
The increase in equity income for the three months ended December 31, 2016 was primarily due to higher income of partially-owned affiliates of the the Johnson Controls - Hitachi (JCH) joint venture in the Building Technologies & Solutions business. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-17-000007:mdna:44]
Income Tax Provision (Benefit)

[0000833444-17-000007:mdna:45]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Income tax provision (benefit) | $ | (27 | ) |  | $ | 83 |  |  | * |
| Effective tax rate | -7 | % |  | 22 | % |  |  |

[0000833444-17-000007:mdna:46]
* Measure not meaningful

[0000833444-17-000007:mdna:47]
In calculating the provision for income taxes, the Company uses an estimate of the annual effective tax rate based upon the facts and circumstances known at each interim period. On a quarterly basis, the annual effective tax rate is adjusted, as appropriate, based upon changed facts and circumstances, if any, as compared to those forecasted at the beginning of the fiscal year and each interim period thereafter.

[0000833444-17-000007:mdna:48]
The U.S. federal statutory tax rate is being used as a comparison since the Company was a U.S. domiciled company for 11 months of 2016 and due to the Company's current legal entity structure.  For the three months ended December 31, 2016, the Company's effective tax rate for continuing operations was -7% and was lower  than the U.S. federal statutory rate of 35% primarily due to

[0000833444-17-000007:mdna:49]
the benefits of continuing global tax planning initiatives, non-U.S. tax rate differentials, and a tax benefit due to changes in entity tax status, partially offset by the jurisdictional mix of significant restructuring and impairment costs, as well as the Tyco Merger related transaction and integration costs, and purchase accounting impacts. For the three months ended December 31, 2015, the Company's effective tax rate for continuing operations was 22%. The effective rate was lower than the U.S. federal statutory rate of 35% primarily due to global tax planning and non-U.S. tax rate differentials. The effective tax rate for the three months ended December 31, 2016 decreased as compared to the three months ended December 31, 2015, primarily due to the discrete tax items described below and tax planning initiatives. The global tax planning initiatives related primarily to foreign tax credit planning, global financing structures and alignment of our global business functions in a tax efficient manner.

[0000833444-17-000007:mdna:50]
In the first quarter of fiscal 2017, the Company recorded a discrete tax benefit of $101 million due to changes in entity tax status.

[0000833444-17-000007:mdna:51]
In the first quarter of fiscal 2017, the Company recorded $130 million of transaction and integration costs which generated an $11 million tax benefit.

[0000833444-17-000007:mdna:52]
In the first quarter of fiscal 2017, the Company recorded $78 million of significant restructuring and impairment costs. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $14 million tax benefit.

[0000833444-17-000007:mdna:53]
Income (Loss) From Discontinued Operations, Net of Tax

[0000833444-17-000007:mdna:54]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Income (loss) from discontinued operations, net of tax | $ | (34 | ) |  | $ | 187 |  |  | * |

[0000833444-17-000007:mdna:55]
* Measure not meaningful

[0000833444-17-000007:mdna:56]
Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-17-000007:mdna:57]
Income Attributable to Noncontrolling Interests

[0000833444-17-000007:mdna:58]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 40 |  |  | $ | 23 |  |  | 74 | % |
| Income from discontinued operations attributable to noncontrolling interests | 9 |  |  | 17 |  |  | -47 | % |

[0000833444-17-000007:mdna:59]
The increase in income from continuing operations attributable to noncontrolling interests for the three months ended December 31, 2016, was primarily due to higher income related to the JCH joint venture in the Building Technologies & Solutions business.

[0000833444-17-000007:mdna:60]
Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-17-000007:mdna:61]
Net Income Attributable to Johnson Controls

[0000833444-17-000007:mdna:62]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Net income attributable to Johnson Controls | $ | 329 |  |  | $ | 450 |  |  | * |

[0000833444-17-000007:mdna:63]
* Measure not meaningful

[0000833444-17-000007:mdna:64]
The decrease in net income attributable to Johnson Controls for the three months ended December 31, 2016 was primarily due to a loss from discontinued operations, current year restructuring and impairment costs, and higher net financing charges, partially offset by incremental operating income as a result of the Tyco Merger and a decrease in the income tax provision. Diluted earnings per share attributable to Johnson Controls for the three months ended December 31, 2016 was $0.35 compared to $0.69 for the three months ended December 31, 2015.

[0000833444-17-000007:mdna:65]
Comprehensive Income (Loss) Attributable to Johnson Controls

[0000833444-17-000007:mdna:66]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Comprehensive income (loss) attributable to Johnson Controls | $ | (332 | ) |  | $ | 289 |  |  | * |

[0000833444-17-000007:mdna:67]
* Measure not meaningful

[0000833444-17-000007:mdna:68]
The decrease in comprehensive income attributable to Johnson Controls for the three months ended December 31, 2016 was primarily due to a increase in other comprehensive loss attributable to Johnson Controls ($500 million) resulting primarily from unfavorable foreign currency translation adjustments, and lower net income attributable to Johnson Controls ($121 million). These year-over-year unfavorable foreign currency translation adjustments were primarily driven by the weakening of the British pound, euro and Japanese yen currencies against the U.S. dollar.

[0000833444-17-000007:mdna:69]
Segment Analysis

[0000833444-17-000007:mdna:70]
Management evaluates the performance of its business units based primarily on segment EBITA, which is defined as income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans.

[0000833444-17-000007:mdna:71]
Building Technologies & Solutions

[0000833444-17-000007:mdna:72]
|  | Net Sales Three Months EndedDecember 31, |  |  |  | Segment EBITA Three Months EndedDecember 31, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
| Building Efficiency |  |  |  |  |  |  |  |  |  |  |  |
| Systems and Service North America | $ | 928 |  |  | $ | 984 |  |  | -6 | % |  | $ | 75 |  |  | $ | 99 |  |  | -24 | % |
| Products North America | 543 |  |  | 557 |  |  | -3 | % |  | 37 |  |  | 33 |  |  | 12 | % |
| Asia | 1,042 |  |  | 992 |  |  | 5 | % |  | 119 |  |  | 70 |  |  | 70 | % |
| Rest of World | 398 |  |  | 423 |  |  | -6 | % |  | (10 | ) |  | (3 | ) |  | * |  |
|  | 2,911 |  |  | 2,956 |  |  | -2 | % |  | 221 |  |  | 199 |  |  | 11 | % |
| Tyco | 2,275 |  |  | — |  |  | * |  |  | 214 |  |  | — |  |  | * |  |
|  | $ | 5,186 |  |  | $ | 2,956 |  |  | 75 | % |  | $ | 435 |  |  | $ | 199 |  |  | * |  |

[0000833444-17-000007:mdna:73]
* Measure not meaningful

[0000833444-17-000007:mdna:74]
Net Sales:

[0000833444-17-000007:mdna:75]
| • | The decrease in Systems and Service North America was due to lower volumes of controls systems and service ($42 million), and a prior year business divestiture ($14 million). The decrease in volumes was primarily attributable to lower performance contracting activity. |

[0000833444-17-000007:mdna:76]
| • | The decrease in Products North America was due to lower volumes ($10 million), a prior year business divestiture ($3 million) and the unfavorable impact of foreign currency translation ($1 million). |

[0000833444-17-000007:mdna:77]
| • | The increase in Asia was due to the favorable impact of foreign currency translation ($29 million), higher volumes of equipment and control systems ($17 million), and higher service volumes ($11 million), partially offset by lower volumes related to a business deconsolidation ($7 million). The increase in volumes was primarily due to favorable local market conditions. |

[0000833444-17-000007:mdna:78]
| • | The decrease in Rest of World was due to lower volumes in the Middle East ($20 million), a prior year business divestiture ($7 million) and the unfavorable impact of foreign currency translation ($7 million), partially offset by higher volumes in Latin America ($7 million) and Europe ($2 million). |

[0000833444-17-000007:mdna:79]
| • | The increase in Tyco was due to incremental sales related to the Tyco Merger ($2,275 million). |

[0000833444-17-000007:mdna:80]
Segment EBITA:

[0000833444-17-000007:mdna:81]
| • | The decrease in Systems and Service North America was due to lower volumes ($12 million), higher operating costs ($7 million), current year integration costs ($3 million), unfavorable pricing and mix ($3 million), current year transaction costs ($2 million) and a prior year business divestiture ($1 million), partially offset by lower selling, general and administrative expenses ($4 million). |

[0000833444-17-000007:mdna:82]
| • | The increase in Products North America was due to lower operating costs ($9 million), and lower selling, general and administrative expenses ($4 million), partially offset by lower volumes ($4 million), current year transaction costs ($1 million), current year integration costs ($1 million), unfavorable pricing and mix ($1 million), lower equity income ($1 million) and the unfavorable impact of foreign currency translation ($1 million). |

[0000833444-17-000007:mdna:83]
| • | The increase in Asia was due to lower operating costs due to cost reduction initiatives ($14 million), higher equity income ($13 million), prior year transaction costs ($9 million), higher volumes ($7 million), lower selling, general and administrative expenses ($7 million), and prior year integration costs ($3 million), partially offset by unfavorable pricing and mix ($2 million), and the unfavorable impact of foreign currency translation ($2 million). |

[0000833444-17-000007:mdna:84]
| • | The decrease in Rest of World was due to lower equity income ($6 million), lower volumes ($5 million), higher operating costs ($1 million), current year integration costs ($1 million) and the unfavorable impact of foreign currency translation ($1 million), partially offset by lower selling, general and administrative expenses ($7 million). |

[0000833444-17-000007:mdna:85]
| • | The increase in Tyco was due to incremental operating income related to the Tyco Merger ($349 million), partially offset by the impact of nonrecurring purchasing accounting adjustments ($112 million), current year transaction costs ($14 million) and current year integration costs ($9 million). |

[0000833444-17-000007:mdna:86]
Power Solutions

[0000833444-17-000007:mdna:87]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Net sales | $ | 1,900 |  |  | $ | 1,740 |  |  | 9 | % |
| Segment EBITA | 389 |  |  | 360 |  |  | 8 | % |

[0000833444-17-000007:mdna:88]
| • | Net sales increased due to higher volumes ($96 million), the impact of higher lead costs on pricing ($47 million), and favorable pricing and product mix ($28 million), partially offset by the unfavorable impact of foreign currency translation ($11 million). The increase in volumes was driven by start-stop battery volumes and growth in China. Additionally, higher start-stop volumes contributed to favorable product mix. |

[0000833444-17-000007:mdna:89]
| • | Segment EBITA increased due to higher volumes ($27 million), favorable pricing and product mix ($21 million), and higher equity income ($4 million), partially offset by higher operating costs primarily driven by efforts to satisfy growing customer demand ($19 million), the unfavorable impact of foreign currency translation ($2 million), higher selling, general and administrative expenses ($1 million), and transaction costs ($1 million). |

[0000833444-17-000007:mdna:90]
55

[0000833444-17-000007:mdna:91]
[same as prior period, unchanged from 0000833444-16-000197:mdna:165]

[0000833444-17-000007:mdna:92]
The Company's backlog relating to the Building Technologies & Solutions business is applicable to its sales of systems and services. At December 31, 2016, the backlog was $8.1 billion and reflects harmonization of the Company's method for determining backlog subsequent to the Tyco Merger. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned during the fiscal year.

[0000833444-17-000007:mdna:93]
Financial Condition

[0000833444-17-000007:mdna:94]
Working Capital

[0000833444-17-000007:mdna:95]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2016 |  | 2016 |  | Change |
| Current assets | $ | 10,966 |  |  | $ | 17,109 |  |  |  |
| Current liabilities | (11,459 | ) |  | (16,331 | ) |  |  |
|  | (493 | ) |  | 778 |  |  | * |  |
| Less: Cash | (377 | ) |  | (579 | ) |  |  |
| Add: Short-term debt | 2,379 |  |  | 1,078 |  |  |  |
| Add: Current portion of long-term debt | 520 |  |  | 628 |  |  |  |
| Less: Assets held for sale | (173 | ) |  | (5,812 | ) |  |  |
| Add: Liabilities held for sale | 31 |  |  | 4,276 |  |  |  |
| Working capital (as defined) | $ | 1,887 |  |  | $ | 369 |  |  | * |  |
| Accounts receivable | $ | 6,057 |  |  | $ | 6,394 |  |  | -5 | % |
| Inventories | 2,943 |  |  | 2,888 |  |  | 2 | % |
| Accounts payable | 3,453 |  |  | 4,000 |  |  | -14 | % |
| * Measure not meaningful |  |  |  |  |  |

[0000833444-17-000007:mdna:96]
| • | The Company defines working capital as current assets less current liabilities, excluding cash, short-term debt, the current portion of long-term debt, and the current portion of assets and liabilities held for sale. Management believes that this measure of working capital, which excludes financing-related items, provides a more useful measurement of the Company’s underlying operating performance. |

[0000833444-17-000007:mdna:97]
| • | The increase in working capital at December 31, 2016 as compared to September 30, 2016 was primarily due to income tax payments related to the Adient spin-off and a decrease in accounts payable due to timing of supplier payments. |

[0000833444-17-000007:mdna:98]
| • | The Company’s days sales in accounts receivable at December 31, 2016 were 66, higher than 61 days at September 30, 2016. There have been no significant adverse changes in the level of overdue receivables or changes in revenue recognition methods. |

[0000833444-17-000007:mdna:99]
| • | The Company’s inventory turns for the three months ended December 31, 2016 were lower than the comparable period ended September 30, 2016, primarily due to changes in inventory production levels. |

[0000833444-17-000007:mdna:100]
| • | Days in accounts payable at December 31, 2016 were 65 days, lower than 69 days at the comparable period ended September 30, 2016. |

[0000833444-17-000007:mdna:101]
Cash Flows

[0000833444-17-000007:mdna:102]
|  | Three Months EndedDecember 31, |
| (in millions) | 2016 |  | 2015 |
| Cash used by operating activities | $ | (1,900 | ) |  | $ | (13 | ) |
| Cash used by investing activities | (331 | ) |  | (384 | ) |
| Cash provided by financing activities | 1,979 |  |  | 214 |  |
| Capital expenditures | (371 | ) |  | (282 | ) |

[0000833444-17-000007:mdna:103]
| • | The increase in cash used by operating activities for the three months ended December 31, 2016 was primarily due to higher income tax payments related to the Adient spin-off ($1.2 billion in the first quarter of fiscal 2017), and unfavorable changes in accounts payable and accrued liabilities and accounts receivable. |

[0000833444-17-000007:mdna:104]
| • | The decrease in cash used by investing activities for the three months ended December 31, 2016 was primarily due to cash paid for the Hitachi investment in the prior year, partially offset by an increase in capital expenditures. |

[0000833444-17-000007:mdna:105]
| • | The increase in cash provided by financing activities for the three months ended December 31, 2016 was primarily due to the dividend from the Adient spin-off, an increase in short-term debt, a decrease in dividends paid due to timing and a decrease in dividends paid to noncontrolling interest in the current year, partially offset by repayment of long-term debt and cash transferred to Adient related to the spin-off. |

[0000833444-17-000007:mdna:106]
| • | The increase in capital expenditures for the three months ended December 31, 2016 primarily relates to Tyco capital investments in the current year and higher capital investments in the Building Efficiency business. |

[0000833444-17-000007:mdna:107]
Deferred Taxes

[0000833444-17-000007:mdna:108]
The Company reviews the realizability of its deferred tax assets on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-17-000007:mdna:109]
The Company has certain subsidiaries, mainly located in Australia, Belgium, Brazil, China, France, Spain, Switzerland, Luxembourg and the United Kingdom, which have generated net operating loss carryforwards and, in certain circumstances, have limited loss carryforward periods. In accordance with ASC 740, "Income Taxes," the Company is required to record a valuation allowance when it is more likely than not the Company will not utilize deductible amounts or net operating losses for each legal entity or consolidated group based on the tax rules in the applicable jurisdiction, evaluating both positive and negative historical evidences as well as expected future events and tax planning strategies.

[0000833444-17-000007:mdna:110]
Long-Lived Assets

[0000833444-17-000007:mdna:111]
The Company reviews long-lived assets for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals.

[0000833444-17-000007:mdna:112]
In the first quarter of fiscal 2017, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2017. As a result, the Company reviewed the long-lived assets for impairment and recorded $15 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income, all of which related to Corporate assets. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured

[0000833444-17-000007:mdna:113]
under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000007:mdna:114]
At December 31, 2016 and 2015, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets

[0000833444-17-000007:mdna:115]
Capitalization

[0000833444-17-000007:mdna:116]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2016 |  | 2016 |  | Change |
| Short-term debt | $ | 2,379 |  |  | $ | 1,078 |  |  |  |
| Current portion of long-term debt | 520 |  |  | 628 |  |  |  |
| Long-term debt | 10,351 |  |  | 11,053 |  |  |  |
| Total debt | 13,250 |  |  | 12,759 |  |  | 4 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 19,577 |  |  | 24,118 |  |  | -19 | % |
| Total capitalization | $ | 32,827 |  |  | $ | 36,877 |  |  | -11 | % |
| Total debt as a % of total capitalization | 40 | % |  | 35 | % |  |  |

[0000833444-17-000007:mdna:117]
* Measure not meaningful

[0000833444-17-000007:mdna:118]
| • | The Company believes the percentage of total debt to total capitalization is useful to understanding the Company’s financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. |

[0000833444-17-000007:mdna:119]
| • | In connection with the Tyco Merger, on December 28, 2016, the Company completed its offers to exchange all validly tendered and accepted notes of certain series (the "existing notes") issued by JCI Inc. or Tyco International Finance S.A. ("TIFSA"), as applicable, each of which is a wholly owned subsidiary of the Company, for the new notes to be issued by the Company and the related solicitation of consents to amend the indentures governing the existing notes (the offers to exchange and the related consent solicitation together the "exchange offers"). Pursuant to the exchange offers, the Company exchanged approximately $5.6 billion of $6.0 billion in aggregate principal amount of dollar denominated notes and approximately 423 million euro of 500 million euro in aggregate principal amount of euro denominated notes. All were validly tendered and accepted and notes have been canceled. Following such cancellation, $380,948,000 aggregate principal amount of existing notes (not including the TIFSA Euro Notes) will remain outstanding across seventeen series of dollar-denominated existing notes and 77,394,000 euro aggregate principal amount of TIFSA Euro Notes remain outstanding across one series. In connection with the settlement of the exchange offers, the new notes ("the New Notes") issued by the Company have been registered under the Securities Act of 1933. The terms of the New Notes are described in the Company’s Prospectus dated December 19, 2016, as filed with the SEC under Rule 424(b)(3) of the Act on that date. The issuance of the New Notes occurred on December 28, 2016. The New Notes are unsecured and unsubordinated obligations of the Company and will rank equally with all other unsecured and unsubordinated indebtedness of the Company issued from time to time. |

[0000833444-17-000007:mdna:120]
•In December 2016, the Company retired, at maturity, $400 million in principal amount, plus accrued interest, of its 2.6%

[0000833444-17-000007:mdna:121]
fixed rate notes that matured in December 2016.

[0000833444-17-000007:mdna:122]
| • | In December 2016, the Company entered into a 364-day 100 million euro floating rate term loan scheduled to mature in December 2017. Proceeds from the term loan were used for general corporate purposes. |

[0000833444-17-000007:mdna:123]
| • | In December 2016, a $100 million committed revolving credit facility expired. There were no draws on the facility. |

[0000833444-17-000007:mdna:124]
| • | In November 2016, the Company fully repaid its 37 billion yen syndicated floating rate term loan, plus accrued interest, scheduled to mature in June 2020. |

[0000833444-17-000007:mdna:125]
| • | In November 2016, a $35 million committed revolving credit facility expired. There were no draws on the facility. |

[0000833444-17-000007:mdna:126]
58

[0000833444-17-000007:mdna:127]
| • | In October 2016, the Company repaid two ten-month, floating rate term loans totaling $325 million, plus accrued interest, scheduled to mature in October 2016. |

[0000833444-17-000007:mdna:128]
| • | In October 2016, the Company repaid a nine-month $100 million floating rate term loan, plus accrued interest, scheduled to mature in November 2016. |

[0000833444-17-000007:mdna:129]
| • | In October 2016, the Company repaid a nine-month 100 million euro floating rate term loan, plus accrued interest, scheduled to mature in October 2016. |

[0000833444-17-000007:mdna:130]
| • | The Company also selectively makes use of short-term credit lines other than its revolving credit facilities at the Company and TSarl. The Company estimates that, as of December 31, 2016, it could borrow up to $1.2 billion based on average borrowing levels during the quarter on committed credit lines. |

[0000833444-17-000007:mdna:131]
| • | The Company believes its capital resources and liquidity position at December 31, 2016 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in the remainder of fiscal 2017 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company and TSarl are unable to issue commercial paper, they would have the ability to draw on their $2.0 billion and $1.0 billion revolving credit facilities, respectively. Both facilities mature in August 2020. There were no draws on the revolving credit facility as of December 31, 2016 and September 30, 2016. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future. |

[0000833444-17-000007:mdna:132]
| • | The Company earns a significant amount of its operating income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. However, in fiscal 2016, the Company did provide income tax expense related to a change in the Company's assertion over a portion of the permanently reinvested earnings as a result of the planned spin-off of the Automotive Experience business. Except as noted, the Company’s intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital in the U.S. than is generated by operations in the U.S., the Company could elect to raise capital in the U.S. through debt or equity issuances. In addition, should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. This alternative could result in increased interest expense or other dilution of the Company’s earnings. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. |

[0000833444-17-000007:mdna:133]
| • | The Company’s debt financial covenants in its revolving credit facility require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times and allow a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating the covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification (ASC) 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. TSarl's, revolving credit facility contains customary terms and conditions, and financial covenants that limit the ratio of TSarl's debt to earnings before interest, taxes, depreciation, and amortization and excluding special items to 3.5x and that limit its ability to incur subsidiary debt or grant liens on its property. As of December 31, 2016, the Company and TSarl were in compliance with all covenants and other requirements set forth in their credit agreements and indentures and expect to remain in compliance for the foreseeable future. None of the Company’s or TSarl's debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the respective borrower's credit rating. |

[0000833444-17-000007:mdna:134]
New Accounting Standards

[0000833444-17-000007:mdna:135]
Recently Adopted Accounting Pronouncements

[0000833444-17-000007:mdna:136]
In October 2016, the FASB issued Accounting Standards Update (ASU) No. 2016-17, "Consolidations (Topic 810): Interests Held through Related Parties that are under Common Control." The ASU changes how a single decision maker of a VIE that holds indirect interest in the entity through related parties that are under common control determines whether it is the primary beneficiary of the VIE. The new guidance amends ASU 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis" issued in February 2015. ASU No. 2016-17 was effective for the Company for the quarter ending December 31, 2016. The adoption of this guidance did not have a significant impact on the Company's consolidated financial statements.

[0000833444-17-000007:mdna:137]
In May 2015, the FASB issued ASU No. 2015-07, "Disclosures for Investments in Certain Entities That Calculate Net Asset Value per Share (or Its Equivalent)." ASU No. 2015-07 removes the requirement to categorize within the fair value hierarchy all investments for which fair value is measured using the net asset value per share practical expedient. Such investments should be disclosed separate from the fair value hierarchy. ASU No. 2015-07 was effective retrospectively for the Company for the quarter ending December 31, 2016. The adoption of this guidance did not have an impact on the Company's consolidated financial statements, but will impact pension asset disclosures in future filings.

[0000833444-17-000007:mdna:138]
In April 2015, the FASB issued ASU No. 2015-03, "Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." ASU No. 2015-03 requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability. ASU No. 2015-03 was effective retrospectively for the Company for the quarter ending December 31, 2016. The adoption of this guidance did not have a significant impact on the Company's consolidated financial statements.

[0000833444-17-000007:mdna:139]
In February 2015, the FASB issued ASU No. 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis." ASU No. 2015-02 amends the analysis performed to determine whether a reporting entity should consolidate certain types of legal entities. ASU No. 2015-02 was effective retrospectively for the Company for the quarter ending December 31, 2016. The adoption of this guidance did not have an impact on the Company's consolidated financial statements.

[0000833444-17-000007:mdna:140]
Recently Issued Accounting Pronouncements

[0000833444-17-000007:mdna:141]
In January 2017, the FASB issued ASU No. 2017-04, "Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment," which eliminates the requirement to calculate the implied fair value of goodwill to measure a goodwill impairment charge (Step 2) from the goodwill impairment test. Instead, an impairment charge will equal the amount by which a reporting unit’s carrying amount exceeds its fair value, not to exceed the amount of goodwill allocated to the reporting unit. The guidance will be effective prospectively for the Company for the quarter ending December 31, 2020, with early adoption permitted after January 1, 2017. The impact of this guidance for the Company will depend on the outcomes of future goodwill impairment tests.

[0000833444-17-000007:mdna:142]
In November 2016, the FASB issued ASU No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force)." The ASU requires amounts generally described as restricted cash and restricted cash equivalents to be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. The guidance will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted. The amendments in this update should be applied retrospectively to all periods presented. The impact of this guidance for the Company will depend on the levels of restricted cash balances in the periods presented.

[0000833444-17-000007:mdna:143]
In October 2016, the FASB issued ASU No. 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory". The ASU requires the tax effects of all intra-entity sales of assets other than inventory to be recognized in the period in which the transaction occurs. The guidance will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted but only in the first interim period of a fiscal year. The changes are required to be applied by means of a cumulative-effect adjustment recorded in retained earnings as of the beginning of the fiscal year of adoption. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000007:mdna:144]
In August 2016, the FASB issued ASU No. 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments." ASU No. 2016-15 provides clarification guidance on eight specific cash flow presentation issues in order to reduce the diversity in practice. ASU No. 2016-15 will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted. The guidance should be applied retrospectively to all periods presented, unless deemed impracticable,

[0000833444-17-000007:mdna:145]
in which case prospective application is permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000007:mdna:146]
In June 2016, the FASB issued ASU No. 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments." ASU No. 2016-13 changes the impairment model for financial assets measured at amortized cost, requiring presentation at the net amount expected to be collected. The measurement of expected credit losses is based upon historical experience, current conditions, and reasonable and supportable forecasts. Available-for-sale debt securities with unrealized losses will now be recorded through an allowance for credit losses. ASU No. 2016-13 will be effective for the Company for the quarter ended December 31, 2020, with early adoption permitted for the quarter ended December 31, 2019. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-17-000007:mdna:147]
In March 2016, the FASB issued ASU No. 2016-09, "Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." ASU No. 2016-09 impacts certain aspects of the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the statements of cash flows. ASU No. 2016-09 will be effective for the Company for the quarter ending December 31, 2017, with early adoption permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000007:mdna:148]
In March 2016, the FASB issued ASU No. 2016-07, "Investments - Equity Method and Joint Ventures (Topic 323): Simplifying the Transition to the Equity Method of Accounting." ASU No. 2016-07 eliminates the requirement for an investment that qualifies for the use of the equity method of accounting as a result of an increase in the level of ownership or degree of influence to adjust the investment, results of operations and retained earnings retrospectively. ASU No. 2016-07 will be effective prospectively for the Company for increases in the level of ownership interest or degree of influence that result in the adoption of the equity method that occur during or after the quarter ending December 31, 2017, with early adoption permitted. The impact of this guidance for the Company is dependent on any future increases in the level of ownership interest or degree of influence that result in the adoption of the equity method.

[0000833444-17-000007:mdna:149]
In February 2016, the FASB issued ASU No. 2016-02, "Leases (Topic 842)." ASU No. 2016-02 requires recognition of operating leases as lease assets and liabilities on the balance sheet, and disclosure of key information about leasing arrangements. ASU No. 2016-02 will be effective retrospectively for the Company for the quarter ending December 31, 2019, with early adoption permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000007:mdna:150]
In January 2016, the FASB issued ASU No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." ASU No. 2016-01 amends certain aspects of recognition, measurement, presentation and disclosure of financial instruments. ASU No. 2016-01 will be effective for the Company for the quarter ending December 31, 2018, and early adoption is not permitted, with certain exceptions. The changes are required to be applied by means of a cumulative-effect adjustment on the balance sheet as of the beginning of the fiscal year of adoption. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000007:mdna:151]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory." ASU No. 2015-11 requires inventory that is recorded using the first-in, first-out method to be measured at the lower of cost or net realizable value. ASU No. 2015-11 will be effective prospectively for the Company for the quarter ending December 31, 2017, with early adoption permitted. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-17-000007:mdna:152]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)." ASU No. 2014-09 clarifies the principles for recognizing revenue when an entity either enters into a contract with customers to transfer goods or services or enters into a contract for the transfer of non-financial assets. The original standard was effective retrospectively for the Company for the quarter ending December 31, 2017; however in August 2015, the FASB issued ASU No. 2015-14, "Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date," which defers the effective date of ASU No. 2014-09 by one-year for all entities. The new standard will become effective retrospectively for the Company for the quarter ending December 31, 2018, with early adoption permitted, but not before the original effective date. Additionally, in March 2016, the FASB issued ASU No. 2016-08, "Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net)," in April 2016, the FASB issued ASU No. 2016-10, "Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing," and in May 2016, the FASB issued ASU No. 2016-12, "Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients," and in December 2016, the FASB issued ASU No. 2016-20, "Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers," all of which provide additional clarification on certain topics addressed in ASU No. 2014-09. ASU No. 2016-08, ASU No. 2016-10, ASU No. 2016-12 and ASU No. 2016-20 follow the same implementation guidelines as ASU No. 2014-09 and ASU

[0000833444-17-000007:mdna:153]
No. 2015-14. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000007:mdna:154]
Other Financial Information

[0000833444-17-000007:mdna:155]
The interim financial information included in this Quarterly Report on Form 10-Q has not been audited by PricewaterhouseCoopers LLP (PwC). PwC has, however, applied limited review procedures in accordance with professional standards for reviews of interim financial information. Accordingly, you should restrict your reliance on their reports on such information. PwC is not subject to the liability provisions of Section 11 of the Securities Act of 1933 for its reports on the interim financial information because such reports do not constitute "reports" or "parts" of the registration statements prepared or certified by PwC within the meaning of Sections 7 and 11 of the Securities Act of 1933.
