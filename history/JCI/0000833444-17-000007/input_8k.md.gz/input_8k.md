# JCI 8-K — 0000833444-17-000003 filed 2017-02-01

## item codes, every 8-K on or before 2017-02-08

- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2017-02-08

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-17-000003:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq1fy17.htm
EXHIBIT 99.1

[0000833444-17-000003:8k_2_02:2]
Exhibit

[0000833444-17-000003:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000833444-17-000003:8k_2_02:4]
Exhibit 99.1

[0000833444-17-000003:8k_2_02:5]
| CONTACT: | Investors:Antonella Franzen(609) 720-4665Ryan Edelman(609) 720-4545Media:Fraser Engerman(414) 524-2733 |  |

[0000833444-17-000003:8k_2_02:6]
Johnson Controls reports first quarter 2017 GAAP earnings from continuing operations of $0.39          per share, strong adjusted earnings of $0.53 per share and reaffirms 2017 adjusted EPS guidance

[0000833444-17-000003:8k_2_02:7]
_________________________________________________________________________________________________

[0000833444-17-000003:8k_2_02:8]
| ▪ | Adjusted EPS from continuing operations of $0.53, up 10 percent versus prior year |

[0000833444-17-000003:8k_2_02:9]
| ▪ | Sales of $7.1 billion, reflecting organic growth of 1 percent versus prior year |

[0000833444-17-000003:8k_2_02:10]
| ▪ | Adjusted EBIT margin expansion of 90 basis points year-over-year, to 10.7 percent |

[0000833444-17-000003:8k_2_02:11]
| ▪ | Second quarter adjusted EPS from continuing operations guidance of $0.48 to $0.50, an increase of 7 percent to 11 percent year-over-year |

[0000833444-17-000003:8k_2_02:12]
| ▪ | Reaffirming 2017 adjusted EPS from continuing operations guidance of $2.60 to $2.75, a 13 percent to 19 percent increase year-over-year |

[0000833444-17-000003:8k_2_02:13]
_________________________________________________________________________________________________

[0000833444-17-000003:8k_2_02:14]
CORK, Ireland, Feb. 1, 2017 -- Johnson Controls International, plc (NYSE: JCI) today reported first quarter 2017 GAAP earnings per share (“EPS”) from continuing operations of $0.39.  Adjusted EPS from continuing operations were $0.53, up 10 percent versus the prior year period.

[0000833444-17-000003:8k_2_02:15]
Reported sales of $7.1 billion were up slightly compared to the prior year.  Organic sales growth of 1 percent and higher lead pass-through was mostly offset by the negative impact of foreign currency translation and net acquisition and divestiture activity.

[0000833444-17-000003:8k_2_02:16]
Earnings before interest and taxes (“EBIT”) was $521 million and the EBIT margin was 7.4 percent. Adjusted EBIT was $757 million, up 10 percent over last year (up 13 percent excluding foreign exchange and lead cost increases) with adjusted EBIT margin expansion of 90 basis points, to 10.7 percent.

[0000833444-17-000003:8k_2_02:17]
“First quarter results represent a solid start to the year as we begin executing against our 2017 priorities as a combined company,” said Alex Molinaroli, Johnson Controls chairman & CEO.  Synergy and productivity benefits, along with strong growth in our global battery aftermarket business contributed to the 10 percent earnings growth in the first quarter,” said Molinaroli.  “Integration activities are well underway and we expect the benefits of the combination will continue to ramp as the year progresses.  Our strong first quarter performance, growing backlog in Buildings and continued favorable mix in Power, make us confident in our adjusted EPS guidance range of $2.60 to $2.75 for the year,” Molinaroli continued.

[0000833444-17-000003:8k_2_02:18]
Income and EPS amounts are attributable to Johnson Controls ordinary shareholders

[0000833444-17-000003:8k_2_02:19]
($ millions, except per-share amounts)

[0000833444-17-000003:8k_2_02:20]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated.  All comparisons are to the first quarter of 2016, which are adjusted to reflect the combination of Johnson Controls’ historical Building Efficiency business with historical Tyco results of operations as if these businesses had been operated together during the periods presented, along with certain other adjustments.  For additional information, see the unaudited supplemental financial information included in the Current Report on Form 8-K filed by Johnson Controls with the SEC on Nov. 8, 2016 as well as the attached footnotes.  The spin-off of Adient plc occurred on Oct. 31, 2016 and the results of this business are reported in discontinued operations for all periods presented.

[0000833444-17-000003:8k_2_02:21]
|  | GAAP | Adjusted | Adjusted |  |
|  | Q1 2017 | Q1 2017 | Q1 2016 | Change |
|  |  |  | (Combined) |  |
| Sales | $7,086 | $7,096 | $7,066 | — |
| Segment EBITA | 824 | 968 | 919 | 5% |
| Intangible asset amortization expense | (149) | (103) | (106) | (3%) |
| EBIT | 521 | 757 | 690 | 10% |
| Net income from continuing operations | 372 | 502 | 452 | 11% |
| EPS from continuing operations | $0.39 | $0.53 | $0.48 | 10% |

[0000833444-17-000003:8k_2_02:22]
Organic adjusted sales growth, adjusted segment EBITA, adjusted EBIT, and adjusted EPS from continuing operations are non-GAAP financial measures.  For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes.  First quarter review slides can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-17-000003:8k_2_02:23]
BUSINESS RESULTS

[0000833444-17-000003:8k_2_02:24]
Building Technologies & Solutions (“Buildings”)

[0000833444-17-000003:8k_2_02:25]
|  | GAAP | Adjusted | Adjusted |  |
|  | Q1 2017 | Q1 2017 | Q1 2016 | Change |
|  |  |  | (Combined) |  |
| Sales | $5,186 | $5,196 | $5,326 | (2%) |
| Segment EBITA | $435 | $578 | $559 | 3% |
| Segment EBITA margin % | 8.4% | 11.1% | 10.5% | +60bps |

[0000833444-17-000003:8k_2_02:26]
Buildings sales in the first quarter of 2017 were $5.2 billion, down 2 percent versus the prior year quarter.  Excluding the net impact of acquisition and divestiture activity, as well as foreign exchange, organic sales declined 1 percent versus the prior year, driven by a decline in product revenue.

[0000833444-17-000003:8k_2_02:27]
Orders in the quarter, excluding M&A and adjusted for foreign exchange, increased 2 percent year-over-year, as 3 percent growth in field orders was partially offset by a 3 percent decline in product orders.  Backlog at the end of the quarter of $8.1 billion, increased 6 percent year-over-year, excluding M&A and adjusted for foreign exchange.

[0000833444-17-000003:8k_2_02:28]
Buildings adjusted segment EBITA was $578 million, up 3 percent versus the prior year (up 6 percent excluding foreign exchange).  Adjusted segment EBITA margin of 11.1 percent increased 60 basis points compared with the prior year quarter as benefits from productivity and cost synergies more than offset incremental product and channel investments.

[0000833444-17-000003:8k_2_02:29]
Power Solutions

[0000833444-17-000003:8k_2_02:30]
|  | GAAP | Adjusted | Adjusted |  |
|  | Q1 2017 | Q1 2017 | Q1 2016 | Change |
|  |  |  | (Combined) |  |
| Sales | $1,900 | $1,900 | $1,740 | 9% |
| Segment EBITA | $389 | $390 | $360 | 8% |
| Segment EBITA margin % | 20.5% | 20.5% | 20.7% | (20bps) |

[0000833444-17-000003:8k_2_02:31]
Power Solutions sales in the first quarter of 2017 were $1.9 billion, an increase of 9 percent versus the prior year quarter.  Excluding the impact of higher lead pass-through and foreign exchange, organic sales increased 7 percent versus the prior year, with higher volumes in all regions.  Global original equipment battery shipments were consistent with the prior year and aftermarket shipments increased 7 percent in the quarter.

[0000833444-17-000003:8k_2_02:32]
Power Solutions adjusted segment EBITA was $390 million, up 8 percent from the prior year quarter, due to higher volumes and favorable mix, partially offset by the impact of lead.  Adjusted segment EBITA increased 12 percent excluding the impact of foreign exchange and lead.  Adjusted segment EBITA margin of 20.5 percent decreased 20 basis points compared with the prior year quarter, including a 110 basis point headwind related to the impact of lead.  Excluding the impact of lead, segment EBITA margin increased 90 basis points year-over-year.

[0000833444-17-000003:8k_2_02:33]
Corporate

[0000833444-17-000003:8k_2_02:34]
|  | GAAP | Adjusted | Adjusted |  |
|  | Q1 2017 | Q1 2017 | Q1 2016 | Change |
|  |  |  | (Combined) |  |
| Corporate expense | ($193) | ($108) | ($123) | (12%) |

[0000833444-17-000003:8k_2_02:35]
Adjusted corporate expense was $108 million in the first quarter of 2017, a decrease of 12 percent compared to the prior year quarter driven primarily by productivity initiatives and cost synergies.

[0000833444-17-000003:8k_2_02:36]
OTHER ITEMS

[0000833444-17-000003:8k_2_02:37]
| • | On Dec. 5, 2016, the board of directors approved a quarterly cash dividend of $0.25 per share payable on Jan. 6, 2017, to shareholders of record as of the close of business on Dec. 14, 2016. |

[0000833444-17-000003:8k_2_02:38]
| • | On Dec. 28, 2016, the Company completed its previously announced offers to exchange all validly tendered and accepted notes of certain series (the “existing notes”) issued by Johnson Controls, Inc. or Tyco International Finance S.A., as applicable, each of which is a wholly-owned subsidiary of the Company, for new notes issued by the Company and the related solicitation of consents to amend the indentures governing the existing notes. Pursuant to the exchange offers, the Company exchanged approximately $5.6 billion of $6.0 billion in aggregate principal amount of U.S. dollar denominated notes and approximately €423 million of €500 million in aggregate principal amount of Euro denominated notes. |

[0000833444-17-000003:8k_2_02:39]
| • | The spin-off of Adient plc was completed on Oct. 31, 2016. The results of this business are reported in discontinued operations for all periods presented. |

[0000833444-17-000003:8k_2_02:40]
###

[0000833444-17-000003:8k_2_02:41]
ABOUT JOHNSON CONTROLS

[0000833444-17-000003:8k_2_02:42]
Johnson Controls is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. Our 130,000 employees create intelligent buildings, efficient energy solutions, integrated infrastructure and next generation transportation systems that work seamlessly together to deliver on the promise of smart cities and communities. Our commitment to sustainability dates back to our roots in 1885, with the invention of the first electric room thermostat. We are committed to helping our customers win and creating greater value for all of our stakeholders through strategic focus on our buildings and energy growth platforms. For additional information, please visit http://www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter.

[0000833444-17-000003:8k_2_02:43]
###

[0000833444-17-000003:8k_2_02:44]
Johnson Controls Cautionary Statement Regarding Forward-Looking Statements

[0000833444-17-000003:8k_2_02:45]
###

[0000833444-17-000003:8k_2_02:46]
Non GAAP Financial Information

[0000833444-17-000003:8k_2_02:47]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include mark-to-market for pension plans, transaction/integration/separation costs, restructuring and impairment costs, nonrecurring purchase accounting impacts related to the Tyco merger and discrete tax items. Financial information regarding adjusted sales, adjusted segment EBITA and adjusted segment EBITA margin are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as transaction/integration/separation costs and nonrecurring purchase accounting impacts because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.

[0000833444-17-000003:8k_2_02:48]
###

[0000833444-17-000003:8k_2_02:49]
| February 1, 2017Page 6JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Three Months EndedDecember 31, |
|  |  | 2016 |  |  | 2015 |
| Net sales | $ | 7,086 |  |  |  | $ | 4,696 |  |
| Cost of sales | 4,972 |  |  |  | 3,439 |  |
|  | Gross profit | 2,114 |  |  |  | 1,257 |  |
| Selling, general and administrative expenses | (1,570 | ) |  |  | (847 | ) |
| Restructuring and impairment costs | (78 | ) |  |  | — |  |
| Net financing charges | (136 | ) |  |  | (66 | ) |
| Equity income | 55 |  |  |  | 42 |  |
| Income from continuing operations before income taxes | 385 |  |  |  | 386 |  |
| Income tax provision (benefit) | (27 | ) |  |  | 83 |  |
| Income from continuing operations | 412 |  |  |  | 303 |  |
| Income (loss) from discontinued operations, net of tax | (34 | ) |  |  | 187 |  |
| Net income | 378 |  |  |  | 490 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 40 |  |  |  | 23 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | 9 |  |  |  | 17 |  |
| Net income attributable to JCI | $ | 329 |  |  |  | $ | 450 |  |
| Income from continuing operations | $ | 372 |  |  |  | $ | 280 |  |
| Income (loss) from discontinued operations | (43 | ) |  |  | 170 |  |
| Net income attributable to JCI | $ | 329 |  |  |  | $ | 450 |  |
| Diluted earnings per share from continuing operations | $ | 0.39 |  |  |  | $ | 0.43 |  |
| Diluted earnings (loss) per share from discontinued operations | (0.05 | ) |  |  | 0.26 |  |
| Diluted earnings per share * | $ | 0.35 |  |  |  | $ | 0.69 |  |
| Diluted weighted average shares | 947.4 |  |  |  | 652.8 |  |
| Shares outstanding at period end | 938.7 |  |  |  | 648.2 |  |

[0000833444-17-000003:8k_2_02:50]
* May not sum due to rounding.

[0000833444-17-000003:8k_2_02:51]
| February 1, 2017Page 7JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | December 31, 2016 |  | September 30, 2016 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 377 |  |  | $ | 579 |  |
| Accounts receivable - net | 6,057 |  |  | 6,394 |  |
| Inventories | 2,943 |  |  | 2,888 |  |
| Assets held for sale | 173 |  |  | 5,812 |  |
| Other current assets | 1,416 |  |  | 1,436 |  |
|  | Current assets | 10,966 |  |  | 17,109 |  |
| Property, plant and equipment - net | 5,556 |  |  | 5,632 |  |
| Goodwill | 20,772 |  |  | 21,024 |  |
| Other intangible assets - net | 7,290 |  |  | 7,540 |  |
| Investments in partially-owned affiliates | 1,030 |  |  | 990 |  |
| Noncurrent assets held for sale | — |  |  | 7,374 |  |
| Other noncurrent assets | 3,174 |  |  | 3,510 |  |
|  | Total assets | $ | 48,788 |  |  | $ | 63,179 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 2,899 |  |  | $ | 1,668 |  |
| Accounts payable and accrued expenses | 4,617 |  |  | 5,333 |  |
| Liabilities held for sale | 31 |  |  | 4,276 |  |
| Other current liabilities | 3,912 |  |  | 5,016 |  |
|  | Current liabilities | 11,459 |  |  | 16,293 |  |
| Long-term debt | 10,351 |  |  | 11,091 |  |
| Other noncurrent liabilities | 6,423 |  |  | 6,583 |  |
| Noncurrent liabilities held for sale | — |  |  | 3,888 |  |
| Redeemable noncontrolling interests | 159 |  |  | 234 |  |
| Shareholders' equity attributable to JCI | 19,577 |  |  | 24,118 |  |
| Noncontrolling interests | 819 |  |  | 972 |  |
|  | Total liabilities and equity | $ | 48,788 |  |  | $ | 63,179 |  |

[0000833444-17-000003:8k_2_02:52]
| February 1, 2017Page 8JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended December 31, |
|  |  |  |  |  |  | 2016 |  |  | 2015 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI | $ | 329 |  |  |  | $ | 450 |  |
| Income from continuing operations attributable to noncontrolling interests | 40 |  |  |  | 23 |  |
| Income from discontinued operations attributable to noncontrolling interests | 9 |  |  |  | 17 |  |
| Net income | 378 |  |  |  | 490 |  |
| Adjustments to reconcile net income to cash used by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 346 |  |  |  | 226 |  |
|  |  | Pension and postretirement benefit income | (155 | ) |  |  | (17 | ) |
|  |  | Pension and postretirement contributions | (247 | ) |  |  | (19 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (64 | ) |  |  | (110 | ) |
|  |  | Deferred income taxes | 580 |  |  |  | (14 | ) |
|  |  | Non-cash restructuring and impairment costs | 16 |  |  |  | — |  |
|  |  | Other - net | 37 |  |  |  | 29 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | 37 |  |  |  | 199 |  |
|  |  |  |  | Inventories | (142 | ) |  |  | (70 | ) |
|  |  |  |  | Other assets | (87 | ) |  |  | (108 | ) |
|  |  |  |  | Restructuring reserves | 20 |  |  |  | (74 | ) |
|  |  |  |  | Accounts payable and accrued liabilities | (811 | ) |  |  | (394 | ) |
|  |  |  |  | Accrued income taxes | (1,808 | ) |  |  | (151 | ) |
|  |  |  |  |  | Cash used by operating activities | (1,900 | ) |  |  | (13 | ) |
| Investing Activities |  |  |  |  |
| Capital expenditures | (371 | ) |  |  | (282 | ) |
| Sale of property, plant and equipment | 2 |  |  |  | 9 |  |
| Acquisition of businesses, net of cash acquired | (3 | ) |  |  | (133 | ) |
| Business divestitures, net of cash divested | 47 |  |  |  | 18 |  |
| Other - net | (6 | ) |  |  | 4 |  |
|  |  |  |  |  | Cash used by investing activities | (331 | ) |  |  | (384 | ) |
| Financing Activities |  |  |  |  |
| Increase in short and long-term debt - net | 556 |  |  |  | 514 |  |
| Debt financing costs | (6 | ) |  |  | — |  |
| Payment of cash dividends | — |  |  |  | (168 | ) |
| Proceeds from the exercise of stock options | 29 |  |  |  | 16 |  |
| Dividends paid to noncontrolling interests | (31 | ) |  |  | (154 | ) |
| Dividend from Adient spin-off | 2,050 |  |  |  | — |  |
| Cash transferred to Adient related to spin-off | (564 | ) |  |  | — |  |
| Cash paid related to prior acquisitions | (45 | ) |  |  | — |  |
| Other - net | (10 | ) |  |  | 6 |  |
|  |  |  |  |  | Cash provided by financing activities | 1,979 |  |  |  | 214 |  |
| Effect of exchange rate changes on cash and cash equivalents | (55 | ) |  |  | — |  |
| Cash held for sale | 105 |  |  |  | (14 | ) |
| Decrease in cash and cash equivalents | $ | (202 | ) |  |  | $ | (197 | ) |

[0000833444-17-000003:8k_2_02:53]
February 1, 2017

[0000833444-17-000003:8k_2_02:54]
FOOTNOTES

[0000833444-17-000003:8k_2_02:55]
1. Financial Summary

[0000833444-17-000003:8k_2_02:56]
In the first quarter of fiscal 2017, the Company began evaluating the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans.  Historical information has been revised to present the comparable periods on a consistent basis.  Also in the first quarter of fiscal 2017, the Company began reporting the Automotive Experience business as a discontinued operation, which required retrospective application to previously reported financial information.  As a result, the segment EBITA amounts shown below are for continuing operations and exclude the Automotive Experience business.  In addition, the financial results for the three months ended December 31, 2015 excludes the Tyco business.

[0000833444-17-000003:8k_2_02:57]
|  | Three Months Ended December 31, |
|  | 2016 |  | 2015 |
| (in millions) | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
|  | (unaudited) |  | (unaudited) |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Technologies & Solutions | $ | 5,186 |  |  | $ | 5,196 |  |  | $ | 2,956 |  |  | $ | 2,956 |  |
| Power Solutions | 1,900 |  |  | 1,900 |  |  | 1,740 |  |  | 1,740 |  |
| Net sales | $ | 7,086 |  |  | $ | 7,096 |  |  | $ | 4,696 |  |  | $ | 4,696 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Technologies & Solutions | $ | 435 |  |  | $ | 578 |  |  | $ | 199 |  |  | $ | 211 |  |
| Power Solutions | 389 |  |  | 390 |  |  | 360 |  |  | 360 |  |
| Segment EBITA | 824 |  |  | 968 |  |  | 559 |  |  | 571 |  |
| Corporate expenses (2) | (193 | ) |  | (108 | ) |  | (87 | ) |  | (68 | ) |
| Amortization of intangible assets (3) | (149 | ) |  | (103 | ) |  | (20 | ) |  | (20 | ) |
| Mark-to-market gain for pension plans (4) | 117 |  |  | — |  |  | — |  |  | — |  |
| Restructuring and impairment costs (5) | (78 | ) |  | — |  |  | — |  |  | — |  |
| EBIT (6) | 521 |  |  | 757 |  |  | 452 |  |  | 483 |  |
| Net financing charges (7) | (136 | ) |  | (119 | ) |  | (66 | ) |  | (66 | ) |
| Income from continuing operations before income taxes | 385 |  |  | 638 |  |  | 386 |  |  | 417 |  |
| Income tax (provision) benefit (8) | 27 |  |  | (96 | ) |  | (83 | ) |  | (86 | ) |
| Income from continuing operations | 412 |  |  | 542 |  |  | 303 |  |  | 331 |  |
| Income from continuing operations attributable to |  |  |  |  |  |  |  |
| noncontrolling interests (9) | (40 | ) |  | (40 | ) |  | (23 | ) |  | (29 | ) |
| Net income from continuing operations attributable to JCI | $ | 372 |  |  | $ | 502 |  |  | $ | 280 |  |  | $ | 302 |  |

[0000833444-17-000003:8k_2_02:58]
Building Technology & Solutions - Provides facility systems and services including comfort, energy and security management for the non-residential buildings market, and provides heating, ventilating, and air conditioning products and services, security products and services, fire detection and suppression products and services, and life safety products for the residential and non-residential building markets.

[0000833444-17-000003:8k_2_02:59]
Power Solutions -  Services both automotive original equipment manufacturers and the battery aftermarket by providing advanced battery technology, coupled with systems engineering, marketing and service expertise.

[0000833444-17-000003:8k_2_02:60]
February 1, 2017

[0000833444-17-000003:8k_2_02:61]
(1) The Company's press release contains financial information regarding adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures.  The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-17-000003:8k_2_02:62]
The following is the first quarter reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-17-000003:8k_2_02:63]
| (in millions) | Building Technologies & Solutions |  | Power Solutions |  | Consolidated JCI plc |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net sales as reported | $ | 5,186 |  |  | $ | 2,956 |  |  | $ | 1,900 |  |  | $ | 1,740 |  |  | $ | 7,086 |  |  | $ | 4,696 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |
| Adjusted net sales | $ | 5,196 |  |  | $ | 2,956 |  |  | $ | 1,900 |  |  | $ | 1,740 |  |  | $ | 7,096 |  |  | $ | 4,696 |  |
| Segment EBITA as reported | $ | 435 |  |  | $ | 199 |  |  | $ | 389 |  |  | $ | 360 |  |  | $ | 824 |  |  | $ | 559 |  |
| Segment EBITA margin as reported | 8.4 | % |  | 6.7 | % |  | 20.5 | % |  | 20.7 | % |  | 11.6 | % |  | 11.9 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | 17 |  |  | 9 |  |  | 1 |  |  | — |  |  | 18 |  |  | 9 |  |
| Integration costs | 14 |  |  | 3 |  |  | — |  |  | — |  |  | 14 |  |  | 3 |  |
| Nonrecurring purchase accounting impacts | 112 |  |  | — |  |  | — |  |  | — |  |  | 112 |  |  | — |  |
| Adjusted segment EBITA | $ | 578 |  |  | $ | 211 |  |  | $ | 390 |  |  | $ | 360 |  |  | $ | 968 |  |  | $ | 571 |  |
| Adjusted segment EBITA margin | 11.1 | % |  | 7.1 | % |  | 20.5 | % |  | 20.7 | % |  | 13.6 | % |  | 12.2 | % |

[0000833444-17-000003:8k_2_02:64]
(2) Adjusted Corporate expenses for the fiscal 2017 first quarter exclude $50 million of integration costs, $31 million of transaction costs and $4 million of separation costs.  Adjusted Corporate expenses for the fiscal 2016 first quarter exclude $18 million of separation costs and $1 million of transaction costs.

[0000833444-17-000003:8k_2_02:65]
(3) Adjusted amortization of intangible assets for the fiscal 2017 first quarter excludes $46 million of nonrecurring asset amortization related to Tyco purchase accounting.

[0000833444-17-000003:8k_2_02:66]
(4) The fiscal 2017 first quarter pension mark-to-market gain of $117 million due to lump sum payouts for certain U.S. pension plans in the quarter is excluded from the adjusted non-GAAP results.

[0000833444-17-000003:8k_2_02:67]
(5) The fiscal 2017 first quarter restructuring and impairment charge of $78 million is excluded from the adjusted non-GAAP results.

[0000833444-17-000003:8k_2_02:68]
(6) Management defines earnings before interest and taxes (EBIT) as income from continuing operations before net financing charges, income taxes and noncontrolling interests.

[0000833444-17-000003:8k_2_02:69]
(7) Adjusted net financing charges for the fiscal 2017 first quarter exclude $17 million of transaction costs related to the debt exchange offers.

[0000833444-17-000003:8k_2_02:70]
(8) Adjusted income tax provision for the fiscal 2017 first quarter excludes the tax benefits of changes in entity tax status of $101 million, Tyco non-recurring purchase accounting impacts of $43 million, restructuring and impairment costs of $14 million, integration costs of $7 million and transaction costs of $4 million, partially offset by the tax provision for gain on mark-to-market pension of $46 million.  Adjusted income tax provision for the fiscal 2016 first quarter excludes the tax benefits of transaction costs of $2 million and separation costs of $1 million.

[0000833444-17-000003:8k_2_02:71]
(9) Adjusted income from continuing operations attributable to noncontrolling interests for the fiscal 2016 first quarter excludes $6 million for the noncontrolling interest impact of transaction/integration costs.

[0000833444-17-000003:8k_2_02:72]
2. 2016 Supplemental Combined Information

[0000833444-17-000003:8k_2_02:73]
As a result of the reverse merger between JCI and Tyco, which closed on September 2, 2016, the Company is providing supplemental combined financial information.  As supplemental information that management believes will be useful to investors, the Company has provided unaudited selected historical information which combines JCI’s historical Building Efficiency business with historical Tyco results of operations as if these businesses had been operated together during the periods presented.

[0000833444-17-000003:8k_2_02:74]
The merger is accounted for as a reverse acquisition with JCI considered to be acquiring Tyco for accounting purposes.  As a result, the amounts reflected in Column A in the below table present the historical results of JCI, revised for the reporting changes described within footnote 1 above.  The amounts in Column B reflect the impact of the special items, as set forth in the notes to the table and within footnote 1 above. The amounts in Column C reflect the inclusion of Tyco’s historical results for the period prior to the merger on an adjusted basis.

[0000833444-17-000003:8k_2_02:75]
February 1, 2017

[0000833444-17-000003:8k_2_02:76]
For the avoidance of doubt, this supplemental combined information is not intended to be, and was not, prepared on a basis consistent with the unaudited pro forma condensed combined financial information in Exhibit 99.3 to the Company’s Current Report on Form 8-K/A filed October 3, 2016 with the U.S. Securities and Exchange Commission (the “Pro Forma 8-K/A Filing”), which provides the pro forma financial information required by Item 9.01(b) of Form 8-K. The supplemental combined information is intentionally different from, but does not supersede, the pro forma financial information in the Pro Forma 8-K/A Filing.

[0000833444-17-000003:8k_2_02:77]
In addition, the supplemental combined information does not purport to indicate the results that actually would have been obtained had the JCI and Tyco businesses been operated together on the basis of the new segment structure during the periods presented, or which may be realized in the future.

[0000833444-17-000003:8k_2_02:78]
Amounts Adjusted for Certain Special Items

[0000833444-17-000003:8k_2_02:79]
The supplemental combined information includes line items, such as net sales, income from continuing operations before income taxes, income tax provision, noncontrolling interest, net income and diluted EPS, that have been adjusted for the special items set forth in the notes to the table. Such amounts should be viewed in addition to, and not in lieu of, net sales, income from continuing operations before income taxes, income tax provision, noncontrolling interest, net income and diluted EPS and other financial measures on an unadjusted basis. In addition, per share amounts presented in the tables take into account the effects of (i) the issuance of ordinary shares to JCI shareholders in connection with the merger, and (ii) the consolidation of Tyco ordinary shares immediately prior to the merger. As a result, share counts reflect shares outstanding as of September 2, 2016 immediately following the consummation of the merger transaction.

[0000833444-17-000003:8k_2_02:80]
The Company’s management believes that these adjusted amounts, when considered together with the unadjusted amounts, provide information that is useful to investors in understanding period-over-period operating results separate and apart from items that may, or could, have a disproportionate positive or negative impact on results in any particular period. The Company’s management also believes that these adjusted amounts enhance the ability of investors to analyze trends in the Company’s underlying business and to better understand the Company’s performance. In addition, the Company may utilize adjusted amounts as guides in forecasting, budgeting and long-term planning processes and to measure operating performance for compensation purposes. Adjusted amounts should be considered in addition to, and not as a substitute for, or superior to, unadjusted amounts.

[0000833444-17-000003:8k_2_02:81]
| (in millions, except per share data) |  | Three Months Ended December 31, 2015 |
|  |  | A |  | B |  | C |  | D |
| Net sales |  |  |  |  |  |  |  |  |
| Building Technologies & Solutions |  | $ | 2,956 |  |  | $ | — |  |  | $ | 2,370 |  |  | $ | 5,326 |  |
| Power Solutions |  | 1,740 |  |  | — |  |  | — |  |  | 1,740 |  |
| Net sales |  | $ | 4,696 |  |  | $ | — |  |  | $ | 2,370 |  |  | $ | 7,066 |  |
| Income from continuing operations |  |  |  |  |  |  |  |  |
| Building Technologies & Solutions |  | $ | 199 |  |  | $ | 12 |  |  | $ | 348 |  |  | $ | 559 |  |
| Power Solutions |  | 360 |  |  | — |  |  | — |  |  | 360 |  |
| Segment EBITA |  | 559 |  |  | 12 |  |  | 348 |  |  | 919 |  |
| Corporate expenses |  | (87 | ) |  | 19 |  |  | (55 | ) |  | (123 | ) |
| Amortization of intangible assets |  | (20 | ) |  | — |  |  | (86 | ) |  | (106 | ) |
| EBIT |  | 452 |  |  | 31 |  |  | 207 |  |  | 690 |  |
| Net financing charges |  | (66 | ) |  | — |  |  | (45 | ) |  | (111 | ) |
| Income from continuing operations before income taxes |  | 386 |  |  | 31 |  |  | 162 |  |  | 579 |  |
| Income tax provision |  | (83 | ) |  | (3 | ) |  | (12 | ) |  | (98 | ) |
| Noncontrolling interest |  | (23 | ) |  | (6 | ) |  | — |  |  | (29 | ) |
| Net income |  | $ | 280 |  |  | $ | 22 |  |  | $ | 150 |  |  | $ | 452 |  |
| Diluted weighted average shares |  | 652.8 |  |  |  |  |  |  | 940 |  |
| Diluted earnings per share |  | $ | 0.43 |  |  |  |  |  |  | $ | 0.48 |  |

[0000833444-17-000003:8k_2_02:82]
A - Johnson Controls, as reported.

[0000833444-17-000003:8k_2_02:83]
B - Adjusted to exclude special items because these costs are not considered to be directly related to the underlying operating performance of the Company.  Management believes these non-GAAP measures are useful to investors in better understanding the ongoing operations and business trends of the Company.  The special items are described by line item in footnote 1 above.  The income tax provision and noncontrolling interest adjustments are a result of the special items discussed in footnote 1.

[0000833444-17-000003:8k_2_02:84]
C - Includes Tyco adjusted non-GAAP results for the first quarter of fiscal 2016 as if the merger occurred October 1, 2015. Tyco’s first three fiscal quarters of 2016 ended on the last Friday of December, March and June, while JCI’s fiscal quarters ended on the last day of each such month. Because the historical statements of income of each company represent full and equivalent quarterly periods, no adjustments were made to align the fiscal quarters.  The income tax provision also includes an adjustment to arrive at an annualized 17% tax rate for fiscal 2016 as a combined company.

[0000833444-17-000003:8k_2_02:85]
D - Combined financial information as if the merger with Tyco was completed on October 1, 2015.  Reflects annual 17% tax rate and 940 million share count.

[0000833444-17-000003:8k_2_02:86]
February 1, 2017

[0000833444-17-000003:8k_2_02:87]
3. Organic Adjusted Net Sales Growth Reconciliation

[0000833444-17-000003:8k_2_02:88]
The components of the changes in adjusted net sales for the three months ended December 31, 2016 versus the three months ended December 31, 2015, including organic net sales, is shown below (unaudited):

[0000833444-17-000003:8k_2_02:89]
| (in millions) | Combined Adjusted Net Sales for the Three Months Ended December 31, 2015 |  | Foreign Currency |  | Acquisitions/Divestitures, Net |  | Lead Impact |  | Organic Net Sales |  | Adjusted Net Sales for the Three Months Ended December 31, 2016 |
| Building Technologies & Solutions | $ | 5,326 |  |  | $ | (46 | ) |  | -0.9 | % |  | $ | (50 | ) |  | -0.9 | % |  | $ | — |  |  | — |  |  | $ | (34 | ) |  | -0.6 | % |  | $ | 5,196 |  |  | -2.4 | % |
| Power Solutions | 1,740 |  |  | (11 | ) |  | -0.6 | % |  | — |  |  | — |  |  | 47 |  |  | 2.7 | % |  | 124 |  |  | 7.1 | % |  | 1,900 |  |  | 9.2 | % |
| Total net sales | $ | 7,066 |  |  | $ | (57 | ) |  | -0.8 | % |  | $ | (50 | ) |  | -0.7 | % |  | $ | 47 |  |  | 0.7 | % |  | $ | 90 |  |  | 1.3 | % |  | $ | 7,096 |  |  | 0.4 | % |

[0000833444-17-000003:8k_2_02:90]
4.  Diluted Earnings Per Share Reconciliation

[0000833444-17-000003:8k_2_02:91]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure.  The adjusting items include transaction/integration/separation costs,  nonrecurring purchase accounting impacts related to the Tyco merger, mark-to-market gain for pension plans, restructuring and impairment costs, and discrete tax items.  The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company.  Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-17-000003:8k_2_02:92]
A reconciliation of diluted earnings per share as reported to diluted adjusted earnings per share for the respective periods is shown below.

[0000833444-17-000003:8k_2_02:93]
|  | Net Income Attributable to JCI plc |  | Net Income Attributable to JCI plc from Continuing Operations |
|  | Three Months Ended |  | Three Months Ended |
|  | December 31, |  | December 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
|  | (unaudited) |  | (unaudited) |
| Earnings per share as reported for JCI plc | $ | 0.35 |  |  | $ | 0.69 |  |  | $ | 0.39 |  |  | $ | 0.43 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | 0.07 |  |  | 0.01 |  |  | 0.07 |  |  | 0.01 |  |
| Integration costs | 0.07 |  |  | - |  |  | 0.07 |  |  | - |  |
| Related tax impact | (0.01) |  |  | - |  |  | (0.01) |  |  | - |  |
| Separation costs | 0.09 |  |  | 0.13 |  |  | - |  |  | 0.03 |  |
| Related tax impact | - |  |  | (0.01) |  |  | - |  |  | - |  |
| Nonrecurring purchase accounting impacts | 0.17 |  |  | - |  |  | 0.17 |  |  | - |  |
| Related tax impact | (0.05) |  |  | - |  |  | (0.05) |  |  | - |  |
| Mark-to-market gain for pension plans | (0.12) |  |  | - |  |  | (0.12) |  |  | - |  |
| Related tax impact | 0.05 |  |  | - |  |  | 0.05 |  |  | - |  |
| Restructuring and impairment costs | 0.08 |  |  | - |  |  | 0.08 |  |  | - |  |
| Related tax impact | (0.01) |  |  | - |  |  | (0.01) |  |  | - |  |
| Discrete tax items | (0.08) |  |  | - |  |  | (0.11) |  |  | - |  |
| Adjusted earnings per share for JCI plc * | $ | 0.59 |  |  | $ | 0.82 |  |  | $ | 0.53 |  |  | $ | 0.46 |  |

[0000833444-17-000003:8k_2_02:94]
* May not sum due to rounding.

[0000833444-17-000003:8k_2_02:95]
A reconciliation of the differences between earnings per share as reported and adjusted earnings per share provided on a forward-looking basis is not available due to the high variability of the net mark-to-market adjustments related to pension and postretirement plans and unpredictability of any other potential adjusting items.

[0000833444-17-000003:8k_2_02:96]
February 1, 2017

[0000833444-17-000003:8k_2_02:97]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions):

[0000833444-17-000003:8k_2_02:98]
|  | Three Months Ended |
|  | December 31, |
|  | 2016 |  | 2015 |
|  | (unaudited) |
| Weighted Average Shares Outstanding for JCI plc |  |  |  |
| Basic weighted average shares outstanding | 937.2 |  |  | 647.7 |
| Effect of dilutive securities: |  |  |  |
| Stock options, unvested restricted stock |  |  |  |
| and unvested performance share awards | 10.2 |  |  | 5.1 |
| Diluted weighted average shares outstanding | 947.4 |  |  | 652.8 |

[0000833444-17-000003:8k_2_02:99]
5.  Mark-to-Market of Pension and Postretirement Plans

[0000833444-17-000003:8k_2_02:100]
The pension and postretirement mark-to-market gain or loss for each period is excluded from adjusted diluted earnings per share.  The fiscal 2017 first quarter includes a mark-to-market gain for pension plans of $117 million due to lump sum payouts for certain U.S. pension plans in the quarter.  There was no mark-to-market gain or loss for pension and postretirement plans in the fiscal 2016 first quarter.

[0000833444-17-000003:8k_2_02:101]
6.  Acquisitions and Divestitures

[0000833444-17-000003:8k_2_02:102]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience business from JCI plc to Adient plc and the issuance of ordinary shares of Adient plc directly to holders of JCI plc ordinary shares on a pro rata basis.  Following the separation, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc.  Beginning in the first quarter of fiscal 2017, Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation.

[0000833444-17-000003:8k_2_02:103]
On September 2, 2016, JCI Inc. and Tyco completed their combination which was announced on January 25, 2016.  The merger is accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification (ASC) 805, "Business Combinations."  JCI Inc. is the accounting acquirer for financial reporting purposes.  Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historical financial statements of the Company.  The total fair value of the consideration transferred was $19.7 billion.  As part of the transaction in the fiscal 2016 fourth quarter, the Company recorded $16.4 billion of goodwill and $6.2 billion of intangible assets, of which $3.9 billion are subject to amortization.

[0000833444-17-000003:8k_2_02:104]
On October 1, 2015, the Company formed a joint venture with Hitachi to expand its legacy Building Efficiency product offerings.  The Company acquired a 60 percent ownership stake in the new entity for approximately $133 million ($563 million purchase price less cash acquired of $430 million).

[0000833444-17-000003:8k_2_02:105]
7. Income Taxes

[0000833444-17-000003:8k_2_02:106]
The Company's effective tax rate from continuing operations before consideration of the transaction/integration/separation costs,  nonrecurring purchase accounting impacts related to the Tyco merger, mark-to-market gain for pension plans, restructuring and impairment costs, and discrete tax items for the quarter ending December 31, 2016 and 2015 is approximately 15 percent and 21 percent, respectively.  The fiscal 2017 first quarter includes $101 million ($0.11) of discrete tax benefits in continuing operations related to changes in entity tax status and $23 million ($0.02) of net one-time tax charges in discontinued operations associated with the spin-off of the Automotive Experience business.

[0000833444-17-000003:8k_2_02:107]
8. Restructuring

[0000833444-17-000003:8k_2_02:108]
The fiscal 2017 first quarter includes restructuring and impairment costs of $78 million related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions business and at Corporate.
