# JCI notes — 0000833444-17-000007


## jci:AdientassetsandliabilitiesheldforsaleTableTextBlock

[0000833444-17-000007:notes:1]
The following table summarizes the carrying value of Adient, reclassified as assets and liabilities held for sale at September 30, 2016 (in millions):

[0000833444-17-000007:notes:2]
|  |  | September 30, 2016 |
| Cash |  | $ | 105 |  |
| Cash in escrow related to Adient debt |  | 2,034 |  |
| Accounts receivable - net |  | 2,071 |  |
| Inventories |  | 672 |  |
| Other current assets |  | 756 |  |
| Assets held for sale |  | $ | 5,638 |  |
| Property, plant and equipment - net |  | $ | 2,240 |  |
| Goodwill |  | 2,385 |  |
| Other intangible assets - net |  | 113 |  |
| Investments in partially-owned affiliates |  | 1,745 |  |
| Other noncurrent assets |  | 891 |  |
| Noncurrent assets held for sale |  | $ | 7,374 |  |
| Short-term debt |  | $ | 41 |  |
| Current portion of long-term debt |  | 38 |  |
| Accounts payable |  | 2,764 |  |
| Accrued compensation and benefits |  | 430 |  |
| Other current liabilities |  | 975 |  |
| Liabilities held for sale |  | $ | 4,248 |  |
| Long-term debt |  | $ | 3,441 |  |
| Pension and postretirement benefits |  | 188 |  |
| Other noncurrent liabilities |  | 259 |  |
| Noncurrent liabilities held for sale |  | $ | 3,888 |  |


## jci:AdientdiscontinuedoperationscashflowTableTextBlock

[0000833444-17-000007:notes:3]
The following table summarizes depreciation and amortization, capital expenditures, and significant operating and investing noncash items related to Adient for the three month periods ended December 31, 2016 and 2015 (in millions):

[0000833444-17-000007:notes:4]
|  | Three Months EndedDecember 31, |
|  | 2016 |  | 2015 |
| Depreciation and amortization | $ | 29 |  |  | $ | 86 |  |
| Equity in earnings of partially-owned affiliates | (31 | ) |  | (95 | ) |
| Deferred income taxes | 562 |  |  | (4 | ) |
| Equity-based compensation | 1 |  |  | 3 |  |
| Accrued income taxes | (808 | ) |  | — |  |
| Capital expenditures | (91 | ) |  | (100 | ) |


## jci:AssetsandLiabilitiesHeldforSaleSpecificTransactionsTableTextBlock

[0000833444-17-000007:notes:5]
The following table summarizes the carrying value of the Tyco segment assets and liabilities held for sale at December 31, 2016 and September 30, 2016 (in millions):

[0000833444-17-000007:notes:6]
|  | December 31, 2016 |  | September 30, 2016 |
| Accounts receivable - net | $ | 10 |  |  | $ | 9 |  |
| Inventories | 6 |  |  | 7 |  |
| Other current assets | 3 |  |  | 3 |  |
| Property, plant and equipment - net | 14 |  |  | 15 |  |
| Goodwill | 94 |  |  | 89 |  |
| Other intangible assets - net | 30 |  |  | 30 |  |
| Other noncurrent assets | 4 |  |  | 4 |  |
| Assets held for sale | $ | 161 |  |  | $ | 157 |  |
| Accounts payable | $ | 10 |  |  | $ | 9 |  |
| Other current liabilities | 21 |  |  | 19 |  |
| Liabilities held for sale | $ | 31 |  |  | $ | 28 |  |


## jci:ComponentsOfNetFinancingChargesTableTextBlock

[0000833444-17-000007:notes:7]
The Company's net financing charges line item in the consolidated statements of income for the three month periods ended December 31, 2016 and 2015 contained the following components (in millions):

[0000833444-17-000007:notes:8]
|  | Three Months EndedDecember 31, |
|  | 2016 |  | 2015 |
| Interest expense, net of capitalized interest costs | $ | 110 |  |  | $ | 72 |  |
| Banking fees and bond cost amortization | 30 |  |  | 7 |  |
| Interest income | (7 | ) |  | (2 | ) |
| Net foreign exchange results for financing activities | 3 |  |  | (11 | ) |
| Net financing charges | $ | 136 |  |  | $ | 66 |  |

[0000833444-17-000007:notes:9]
Net financing charges for the three month period ended December 31, 2016 included $17 million of transaction costs related primarily to the debt exchange offers.


## jci:DiscontinuedOperationsbyDisposalGroupAdientspinoffTableTextBlock

[0000833444-17-000007:notes:10]
The following table summarizes the results of Adient, reclassified as discontinued operations for the three month periods ended December 31, 2016 and 2015 (in millions). As the Adient spin-off occurred on October 31, 2016, there is only one month of Adient results included in the three month period ended December 31, 2016.

[0000833444-17-000007:notes:11]
|  | Three Months EndedDecember 31, |
|  | 2016 |  | 2015 |
| Net sales | $ | 1,434 |  |  | $ | 4,233 |  |
| Income from discontinued operations before income taxes | 1 |  |  | 233 |  |
| Provision for income taxes on discontinued operations | 35 |  |  | 46 |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax | 9 |  |  | 17 |  |
| Income (loss) from discontinued operations | $ | (43 | ) |  | $ | 170 |  |


## jci:EquityAttributableToParentAndNoncontrollingInterestsTableTextBlock

[0000833444-17-000007:notes:12]
The following schedules present changes in consolidated equity attributable to Johnson Controls and noncontrolling interests (in millions, net of tax):

[0000833444-17-000007:notes:13]
|  | Three Months Ended December 31, 2016 |  | Three Months Ended December 31, 2015 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, September 30 | $ | 24,118 |  |  | $ | 972 |  |  | $ | 25,090 |  |  | $ | 10,376 |  |  | $ | 163 |  |  | $ | 10,539 |  |
| Total comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 329 |  |  | 36 |  |  | 365 |  |  | 450 |  |  | 20 |  |  | 470 |  |
| Foreign currency translation adjustments | (659 | ) |  | (35 | ) |  | (694 | ) |  | (160 | ) |  | (9 | ) |  | (169 | ) |
| Realized and unrealized gains (losses) on derivatives | — |  |  | 4 |  |  | 4 |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Realized and unrealized losses on marketable securities | (2 | ) |  | — |  |  | (2 | ) |  | — |  |  | — |  |  | — |  |
| Other comprehensive loss | (661 | ) |  | (31 | ) |  | (692 | ) |  | (161 | ) |  | (9 | ) |  | (170 | ) |
| Comprehensive income (loss) | (332 | ) |  | 5 |  |  | (327 | ) |  | 289 |  |  | 11 |  |  | 300 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (236 | ) |  | — |  |  | (236 | ) |  | (188 | ) |  | — |  |  | (188 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | — |  |  | (7 | ) |  | (7 | ) |
| Change in noncontrolling interest share | — |  |  | (20 | ) |  | (20 | ) |  | — |  |  | 764 |  |  | 764 |  |
| Spin-off of Adient | (4,020 | ) |  | (138 | ) |  | (4,158 | ) |  | — |  |  | — |  |  | — |  |
| Other, including options exercised | 47 |  |  | — |  |  | 47 |  |  | 29 |  |  | — |  |  | 29 |  |
| Ending balance, December 31 | $ | 19,577 |  |  | $ | 819 |  |  | $ | 20,396 |  |  | $ | 10,506 |  |  | $ | 931 |  |  | $ | 11,437 |  |


## jci:OffsettingDerivativeAssetsandLiabilitiesTableTextBlock

[0000833444-17-000007:notes:14]
The gross and net amounts of derivative assets and liabilities were as follows (in millions):

[0000833444-17-000007:notes:15]
|  | Fair Value of Assets |  | Fair Value of Liabilities |
|  | December 31, |  | September 30, |  | December 31, |  | September 30, |
|  | 2016 |  | 2016 |  | 2016 |  | 2016 |
| Gross amount recognized | $ | 46 |  |  | $ | 95 |  |  | $ | 556 |  |  | $ | 2,980 |  |
| Gross amount eligible for offsetting | (11 | ) |  | (21 | ) |  | (11 | ) |  | (21 | ) |
| Net amount | $ | 35 |  |  | $ | 74 |  |  | $ | 545 |  |  | $ | 2,959 |  |


## jci:ScheduleOfIntangibleAssetsTableTextBlock

[0000833444-17-000007:notes:16]
The Company’s other intangible assets, primarily from business acquisitions valued based on independent appraisals, consisted of (in millions):

[0000833444-17-000007:notes:17]
|  | December 31, 2016 |  | September 30, 2016 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Amortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,494 |  |  | $ | (60 | ) |  | $ | 1,434 |  |  | $ | 1,528 |  |  | $ | (24 | ) |  | $ | 1,504 |  |
| Customer relationships | 3,122 |  |  | (279 | ) |  | 2,843 |  |  | 3,168 |  |  | (226 | ) |  | 2,942 |  |
| Miscellaneous | 517 |  |  | (183 | ) |  | 334 |  |  | 519 |  |  | (130 | ) |  | 389 |  |
| Total amortized intangible assets | 5,133 |  |  | (522 | ) |  | 4,611 |  |  | 5,215 |  |  | (380 | ) |  | 4,835 |  |
| Unamortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,529 |  |  | — |  |  | 2,529 |  |  | 2,555 |  |  | — |  |  | 2,555 |  |
| Miscellaneous | 150 |  |  | — |  |  | 150 |  |  | 150 |  |  | — |  |  | 150 |  |
| Total intangible assets | $ | 7,812 |  |  | $ | (522 | ) |  | $ | 7,290 |  |  | $ | 7,920 |  |  | $ | (380 | ) |  | $ | 7,540 |  |


## jci:ScheduleofFairValueofConsiderationTransferredTableTextBlock

[0000833444-17-000007:notes:18]
The following table summarizes the total fair value of consideration transferred:

[0000833444-17-000007:notes:19]
| (in millions, except for share consolidation ratio and share data) |  |  |
| Number of Tyco shares outstanding at September 2, 2016 |  | 427,181,743 |  |
| Tyco share consolidation ratio |  | 0.955 |  |
| Tyco ordinary shares outstanding following the share consolidation and immediately prior to the merger |  | 407,958,565 |  |
| JCI Inc. converted share price (1) |  | $ | 47.67 |  |
| Fair value of equity portion of the merger consideration |  | $ | 19,447 |  |
| Fair value of Tyco equity awards |  | 224 |  |
| Total fair value of consideration transferred |  | $ | 19,671 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-17-000007:notes:20]
Commitments and Contingencies

[0000833444-17-000007:notes:21]
Environmental Matters

[0000833444-17-000007:notes:22]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of December 31, 2016, reserves for environmental liabilities totaled $45 million, of which $9 million was recorded within other current liabilities and $36 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at  September 30, 2016. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At December 31, 2016 and September 30, 2016, the Company recorded conditional asset retirement obligations of $70 million and $74 million, respectively.

[0000833444-17-000007:notes:23]
Asbestos Matters

[0000833444-17-000007:notes:24]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-17-000007:notes:25]
As of December 31, 2016, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position is $156 million. The net liability within the consolidated statements of financial position is comprised of a liability for pending and future claims and related defense costs of $544 million, of which $35 million is recorded in other current liabilities and $509 million is recorded in other noncurrent liabilities. The Company also maintains separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $388 million, of which $42 million is recorded in other current assets, and $346 million is recorded in other noncurrent assets. Assets include $32 million of cash and $252 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at December 31, 2016 is $104 million. As of September 30, 2016, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position is $148 million. The net liability within the consolidated statements of financial position is comprised of a liability for pending and future claims and related defense costs of $548 million, of which $35 million is recorded in other current liabilities and $513 million is recorded in other noncurrent liabilities. The Company also maintains separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $400 million, of which $41 million is recorded in other current assets, and $359 million is recorded in other noncurrent assets. Assets include $16 million of cash and $264 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2016 is $120 million. The Company believes that the asbestos related liabilities and insurance related receivables recorded as of December 31, 2016 and September 30, 2016 are appropriate.

[0000833444-17-000007:notes:26]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2069 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2069. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-17-000007:notes:27]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-17-000007:notes:28]
Insurable Liabilities

[0000833444-17-000007:notes:29]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At December 31, 2016 and September 30, 2016, the insurable liabilities for continuing operations totaled $421 million and $422 million, respectively, of which $61 million and $60 million was recorded within other current liabilities, $31 million and $28 million was recorded within accrued compensation and benefits, and $329 million and $334 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

[0000833444-17-000007:notes:30]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-17-000007:notes:31]
Tyco International Finance S.A.

[0000833444-17-000007:notes:32]
TIFSA, a 100% owned subsidiary of the Company, has public debt securities outstanding which, as of September 30, 2016, were fully and unconditionally guaranteed by Johnson Controls and by Tyco Fire & Security Finance S.C.A. ("TIFSCA"), a wholly owned subsidiary of the Company and parent company TIFSA. During the first quarter of fiscal 2017, the guarantees were removed in connection with the previously disclosed debt exchange. The following tables present condensed consolidating financial information for Johnson Controls, TIFSCA, TIFSA and all other subsidiaries. Condensed financial information for the Company, TIFSCA and TIFSA on a stand-alone basis is presented using the equity method of accounting for subsidiaries.

[0000833444-17-000007:notes:33]
The TIFSA public debt securities were assumed as part of the Tyco acquisition. Therefore, no consolidating financial information for the period ended December 31, 2015 is presented related to the guarantee of the TIFSA public debt securities. Additional information regarding TIFSA and TIFSCA for the period ended December 26, 2015 can be found in Tyco's Quarterly report on Form 10-Q filed with the SEC on January 30, 2016.

[0000833444-17-000007:notes:34]
[same as prior period, unchanged from 0000833444-16-000197:notes:62]

[0000833444-17-000007:notes:35]
For the Period Ended December 31, 2016

[0000833444-17-000007:notes:36]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 7,086 |  |  | $ | — |  |  | $ | 7,086 |  |
| Cost of sales | — |  |  | — |  |  | — |  |  | 4,972 |  |  | — |  |  | 4,972 |  |
| Gross profit | — |  |  | — |  |  | — |  |  | 2,114 |  |  | — |  |  | 2,114 |  |
| Selling, general and administrative expenses | (2 | ) |  | — |  |  | 1 |  |  | (1,569 | ) |  | — |  |  | (1,570 | ) |
| Restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (78 | ) |  | — |  |  | (78 | ) |
| Net financing charges | (19 | ) |  | — |  |  | (19 | ) |  | (98 | ) |  | — |  |  | (136 | ) |
| Equity income (loss) | 318 |  |  | (299 | ) |  | (96 | ) |  | 55 |  |  | 77 |  |  | 55 |  |
| Intercompany interest and fees | 32 |  |  | — |  |  | 17 |  |  | (49 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes | 329 |  |  | (299 | ) |  | (97 | ) |  | 375 |  |  | 77 |  |  | 385 |  |
| Income tax benefit | — |  |  | — |  |  | — |  |  | (27 | ) |  | — |  |  | (27 | ) |
| Income (loss) from continuing operations | 329 |  |  | (299 | ) |  | (97 | ) |  | 402 |  |  | 77 |  |  | 412 |  |
| Income (loss) from sale of intercompany investment, net of tax | — |  |  | — |  |  | (935 | ) |  | — |  |  | 935 |  |  | — |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | — |  |  | (34 | ) |  | — |  |  | (34 | ) |
| Net income (loss) | 329 |  |  | (299 | ) |  | (1,032 | ) |  | 368 |  |  | 1,012 |  |  | 378 |  |
| Income from continuing operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 40 |  |  | — |  |  | 40 |  |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Net income (loss) attributable to Johnson Controls | $ | 329 |  |  | $ | (299 | ) |  | $ | (1,032 | ) |  | $ | 319 |  |  | $ | 1,012 |  |  | $ | 329 |  |

[0000833444-17-000007:notes:37]
[same as prior period, unchanged from 0000833444-16-000197:notes:66]

[0000833444-17-000007:notes:38]
| (in millions) | Johnson ControlsInternationalplc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net Income (loss) | $ | 329 |  |  | $ | (299 | ) |  | $ | (1,032 | ) |  | $ | 368 |  |  | $ | 1,012 |  |  | $ | 378 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments | (659 | ) |  | — |  |  | 27 |  |  | (730 | ) |  | 659 |  |  | (703 | ) |
| Realized and unrealized gains on derivatives | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Realized and unrealized gains (losses) on marketable securities | (2 | ) |  | — |  |  | — |  |  | (2 | ) |  | 2 |  |  | (2 | ) |
| Other comprehensive income (loss) | (661 | ) |  | — |  |  | 27 |  |  | (728 | ) |  | 661 |  |  | (701 | ) |
| Total comprehensive income (loss) | (332 | ) |  | (299 | ) |  | (1,005 | ) |  | (360 | ) |  | 1,673 |  |  | (323 | ) |
| Comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Comprehensive income (loss) attributable to Johnson Controls | $ | (332 | ) |  | $ | (299 | ) |  | $ | (1,005 | ) |  | $ | (369 | ) |  | $ | 1,673 |  |  | $ | (332 | ) |

[0000833444-17-000007:notes:39]
CONDENSED CONSOLIDATING STATEMENT OF FINANCIAL POSITION

[0000833444-17-000007:notes:40]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 350 |  |  | $ | — |  |  | $ | 280 |  |  | $ | — |  |  | $ | (253 | ) |  | $ | 377 |  |
| Accounts receivable - net | — |  |  | — |  |  | — |  |  | 6,057 |  |  | — |  |  | 6,057 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 2,943 |  |  | — |  |  | 2,943 |  |
| Intercompany receivables | 3,129 |  |  | — |  |  | 372 |  |  | 2,737 |  |  | (6,238 | ) |  | — |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 173 |  |  | — |  |  | 173 |  |
| Other current assets | 5 |  |  | — |  |  | 1 |  |  | 1,410 |  |  | — |  |  | 1,416 |  |
| Current assets | $ | 3,484 |  |  | $ | — |  |  | $ | 653 |  |  | $ | 13,320 |  |  | $ | (6,491 | ) |  | $ | 10,966 |  |
| Property, plant and equipment - net | — |  |  | — |  |  | — |  |  | 5,556 |  |  | — |  |  | 5,556 |  |
| Goodwill | 239 |  |  | — |  |  | 30 |  |  | 20,503 |  |  | — |  |  | 20,772 |  |
| Other intangible assets - net | — |  |  | — |  |  | — |  |  | 7,290 |  |  | — |  |  | 7,290 |  |
| Investments in partially-owned affiliates | — |  |  | — |  |  | — |  |  | 1,030 |  |  | — |  |  | 1,030 |  |
| Investments in affiliates | 14,933 |  |  | 26,907 |  |  | 22,489 |  |  | — |  |  | (64,329 | ) |  | — |  |
| Intercompany loans receivable | 16,281 |  |  | — |  |  | 2,836 |  |  | 9,855 |  |  | (28,972 | ) |  | — |  |
| Other noncurrent assets | — |  |  | — |  |  | — |  |  | 3,174 |  |  | — |  |  | 3,174 |  |
| Total assets | $ | 34,937 |  |  | $ | 26,907 |  |  | $ | 26,008 |  |  | $ | 60,728 |  |  | $ | (99,792 | ) |  | $ | 48,788 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | 105 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,527 |  |  | $ | (253 | ) |  | $ | 2,379 |  |
| Current portion of long-term debt | 441 |  |  | — |  |  | — |  |  | 79 |  |  | — |  |  | 520 |  |
| Accounts payable | — |  |  | — |  |  | — |  |  | 3,453 |  |  | — |  |  | 3,453 |  |
| Accrued compensation and benefits | — |  |  | — |  |  | — |  |  | 1,164 |  |  | — |  |  | 1,164 |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 31 |  |  | — |  |  | 31 |  |
| Intercompany payables | 780 |  |  | 500 |  |  | 4,319 |  |  | 639 |  |  | (6,238 | ) |  | — |  |
| Other current liabilities | 293 |  |  | 2 |  |  | 25 |  |  | 3,592 |  |  | — |  |  | 3,912 |  |
| Current liabilities | 1,619 |  |  | 502 |  |  | 4,344 |  |  | 11,485 |  |  | (6,491 | ) |  | 11,459 |  |
| Long-term debt | 5,849 |  |  | — |  |  | 183 |  |  | 4,319 |  |  | — |  |  | 10,351 |  |
| Pension and postretirement benefits | — |  |  | — |  |  | — |  |  | 1,094 |  |  | — |  |  | 1,094 |  |
| Intercompany loans payable | 7,892 |  |  | 12,599 |  |  | 1,963 |  |  | 6,518 |  |  | (28,972 | ) |  | — |  |
| Other noncurrent liabilities | — |  |  | — |  |  | 24 |  |  | 5,305 |  |  | — |  |  | 5,329 |  |
| Long-term liabilities | 13,741 |  |  | 12,599 |  |  | 2,170 |  |  | 17,236 |  |  | (28,972 | ) |  | 16,774 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 159 |  |  | — |  |  | 159 |  |
| Ordinary shares | 9 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Ordinary shares held in treasury | (45 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (45 | ) |
| Other shareholders' equity | 19,613 |  |  | 13,806 |  |  | 19,494 |  |  | 31,029 |  |  | (64,329 | ) |  | 19,613 |  |
| Shareholders’ equity attributable to Johnson Controls | 19,577 |  |  | 13,806 |  |  | 19,494 |  |  | 31,029 |  |  | (64,329 | ) |  | 19,577 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 819 |  |  | — |  |  | 819 |  |
| Total equity | 19,577 |  |  | 13,806 |  |  | 19,494 |  |  | 31,848 |  |  | (64,329 | ) |  | 20,396 |  |
| Total liabilities, redeemable noncontrolling interest and equity | $ | 34,937 |  |  | $ | 26,907 |  |  | $ | 26,008 |  |  | $ | 60,728 |  |  | $ | (99,792 | ) |  | $ | 48,788 |  |

[0000833444-17-000007:notes:41]
[same as prior period, unchanged from 0000833444-16-000197:notes:83]

[0000833444-17-000007:notes:42]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Operating Activities |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided (used) by operating activities | $ | 223 |  |  | $ | — |  |  | $ | 32 |  |  | $ | (2,155 | ) |  | $ | — |  |  | $ | (1,900 | ) |
| Investing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (371 | ) |  | — |  |  | (371 | ) |
| Sale of property, plant and equipment | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (6 | ) |  | 3 |  |  | — |  |  | (3 | ) |
| Business divestitures | — |  |  | — |  |  | — |  |  | 47 |  |  | — |  |  | 47 |  |
| Changes in long-term investments | — |  |  | — |  |  | — |  |  | (6 | ) |  | — |  |  | (6 | ) |
| Net change in intercompany loans | — |  |  | — |  |  | 10 |  |  | — |  |  | (10 | ) |  | — |  |
| Net cash provided (used) by investing activities | — |  |  | — |  |  | 4 |  |  | (325 | ) |  | (10 | ) |  | (331 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Increase in short-term debt - net | 105 |  |  | — |  |  | — |  |  | 1,460 |  |  | (253 | ) |  | 1,312 |  |
| Increase in long-term debt | — |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Repayment of long-term debt | — |  |  | — |  |  | — |  |  | (763 | ) |  | — |  |  | (763 | ) |
| Debt financing costs | (6 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (6 | ) |
| Proceeds from the exercise of stock options | 29 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 29 |  |
| Net intercompany loan borrowings (repayments) | — |  |  | — |  |  | — |  |  | (10 | ) |  | 10 |  |  | — |  |
| Dividends paid to noncontrolling interests | — |  |  | — |  |  | — |  |  | (31 | ) |  | — |  |  | (31 | ) |
| Dividend from Adient spin-off | — |  |  | — |  |  | — |  |  | 2,050 |  |  | — |  |  | 2,050 |  |
| Cash transferred to Adient related to spin-off | — |  |  | — |  |  | — |  |  | (564 | ) |  | — |  |  | (564 | ) |
| Cash paid related to prior acquisitions | — |  |  | — |  |  | — |  |  | (45 | ) |  | — |  |  | (45 | ) |
| Other | (12 | ) |  | — |  |  | — |  |  | 2 |  |  | — |  |  | (10 | ) |
| Net cash provided (used) by financing activities | 116 |  |  | — |  |  | — |  |  | 2,106 |  |  | (243 | ) |  | 1,979 |  |
| Effect of exchange rate changes on cash and cash equivalents | — |  |  | — |  |  | — |  |  | (55 | ) |  | — |  |  | (55 | ) |
| Changes in cash held for sale | — |  |  | — |  |  | — |  |  | 105 |  |  | — |  |  | 105 |  |
| Increase (decrease) in cash and cash equivalents | 339 |  |  | — |  |  | 36 |  |  | (324 | ) |  | (253 | ) |  | (202 | ) |
| Cash and cash equivalents at beginning of period | 11 |  |  | — |  |  | 244 |  |  | 324 |  |  | — |  |  | 579 |  |
| Cash and cash equivalents at end of period | $ | 350 |  |  | $ | — |  |  | $ | 280 |  |  | $ | — |  |  | $ | (253 | ) |  | $ | 377 |  |

[0000833444-17-000007:notes:43]
For the Year Ended September 30, 2016

[0000833444-17-000007:notes:44]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 11 |  |  | $ | — |  |  | $ | 244 |  |  | $ | 324 |  |  | $ | — |  |  | $ | 579 |  |
| Accounts receivable - net | — |  |  | — |  |  | — |  |  | 6,394 |  |  | — |  |  | 6,394 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 2,888 |  |  | — |  |  | 2,888 |  |
| Intercompany receivables | 16 |  |  | — |  |  | 2 |  |  | 6,188 |  |  | (6,206 | ) |  | — |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 5,812 |  |  | — |  |  | 5,812 |  |
| Other current assets | 6 |  |  | — |  |  | 1 |  |  | 1,429 |  |  | — |  |  | 1,436 |  |
| Current assets | $ | 33 |  |  | $ | — |  |  | $ | 247 |  |  | $ | 23,035 |  |  | $ | (6,206 | ) |  | $ | 17,109 |  |
| Property, plant and equipment - net | — |  |  | — |  |  | — |  |  | 5,632 |  |  | — |  |  | 5,632 |  |
| Goodwill | — |  |  | — |  |  | 274 |  |  | 20,750 |  |  | — |  |  | 21,024 |  |
| Other intangible assets - net | — |  |  | — |  |  | — |  |  | 7,540 |  |  | — |  |  | 7,540 |  |
| Investments in partially-owned affiliates | — |  |  | — |  |  | — |  |  | 990 |  |  | — |  |  | 990 |  |
| Investments in affiliates | 12,460 |  |  | 31,405 |  |  | 27,906 |  |  | — |  |  | (71,771 | ) |  | — |  |
| Intercompany loans receivable | 18,680 |  |  | — |  |  | 13,336 |  |  | 15,631 |  |  | (47,647 | ) |  | — |  |
| Noncurrent assets held for sale | — |  |  | — |  |  | — |  |  | 7,374 |  |  | — |  |  | 7,374 |  |
| Other noncurrent assets | — |  |  | — |  |  | — |  |  | 3,510 |  |  | — |  |  | 3,510 |  |
| Total assets | $ | 31,173 |  |  | $ | 31,405 |  |  | $ | 41,763 |  |  | $ | 84,462 |  |  | $ | (125,624 | ) |  | $ | 63,179 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,078 |  |  | $ | — |  |  | $ | 1,078 |  |
| Current portion of long-term debt | — |  |  | — |  |  | — |  |  | 628 |  |  | — |  |  | 628 |  |
| Accounts payable | 1 |  |  | — |  |  | — |  |  | 3,999 |  |  | — |  |  | 4,000 |  |
| Accrued compensation and benefits | — |  |  | — |  |  | — |  |  | 1,333 |  |  | — |  |  | 1,333 |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 4,276 |  |  | — |  |  | 4,276 |  |
| Intercompany payables | 3,873 |  |  | — |  |  | 2,315 |  |  | 18 |  |  | (6,206 | ) |  | — |  |
| Other current liabilities | 3 |  |  | 2 |  |  | 32 |  |  | 4,979 |  |  | — |  |  | 5,016 |  |
| Current liabilities | 3,877 |  |  | 2 |  |  | 2,347 |  |  | 16,311 |  |  | (6,206 | ) |  | 16,331 |  |
| Long-term debt | — |  |  | — |  |  | 2,413 |  |  | 8,640 |  |  | — |  |  | 11,053 |  |
| Pension and postretirement benefits | — |  |  | — |  |  | — |  |  | 1,550 |  |  | — |  |  | 1,550 |  |
| Intercompany loans payable | 3,178 |  |  | 18,680 |  |  | 12,453 |  |  | 13,336 |  |  | (47,647 | ) |  | — |  |
| Noncurrent liabilities held for sale | — |  |  | — |  |  | — |  |  | 3,888 |  |  | — |  |  | 3,888 |  |
| Other noncurrent liabilities | — |  |  | — |  |  | 22 |  |  | 5,011 |  |  | — |  |  | 5,033 |  |
| Long-term liabilities | 3,178 |  |  | 18,680 |  |  | 14,888 |  |  | 32,425 |  |  | (47,647 | ) |  | 21,524 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 234 |  |  | — |  |  | 234 |  |
| Ordinary shares | 9 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Ordinary shares held in treasury | (20 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (20 | ) |
| Other shareholders' equity | 24,129 |  |  | 12,723 |  |  | 24,528 |  |  | 34,520 |  |  | (71,771 | ) |  | 24,129 |  |
| Shareholders’ equity attributable to Johnson Controls | 24,118 |  |  | 12,723 |  |  | 24,528 |  |  | 34,520 |  |  | (71,771 | ) |  | 24,118 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 972 |  |  | — |  |  | 972 |  |
| Total equity | 24,118 |  |  | 12,723 |  |  | 24,528 |  |  | 35,492 |  |  | (71,771 | ) |  | 25,090 |  |
| Total liabilities, redeemable noncontrolling interest and equity | $ | 31,173 |  |  | $ | 31,405 |  |  | $ | 41,763 |  |  | $ | 84,462 |  |  | $ | (125,624 | ) |  | $ | 63,179 |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-17-000007:notes:45]
Debt and Financing Arrangements

[0000833444-17-000007:notes:46]
Debt exchange

[0000833444-17-000007:notes:47]
In connection with the Tyco Merger, on December 28, 2016, the Company completed its offers to exchange all validly tendered and accepted notes of certain series (the "existing notes") issued by JCI Inc. or Tyco International Finance S.A. ("TIFSA"), as applicable, each of which is a wholly owned subsidiary of the Company, for the new notes to be issued by the Company and the related solicitation of consents to amend the indentures governing the existing notes (the offers to exchange and the related consent solicitation together the "exchange offers"). Pursuant to the exchange offers, the Company exchanged approximately $5.6 billion of $6.0 billion in aggregate principal amount of dollar denominated notes and approximately 423 million euro of 500 million euro in aggregate principal amount of euro denominated notes. All were validly tendered and accepted and notes have been canceled. Following such cancellation, $380,948,000 aggregate principal amount of existing notes (not including the TIFSA Euro Notes) will remain outstanding across seventeen series of dollar-denominated existing notes and 77,394,000 euro aggregate principal amount of TIFSA Euro Notes remain outstanding across one series. In connection with the settlement of the exchange offers, the new notes ("the New Notes") issued by the Company have been registered under the Securities Act of 1933. The terms of the New Notes are described in the Company’s Prospectus dated December 19, 2016, as filed with the SEC under Rule 424(b)(3) of the Act on that date. The issuance of the New Notes occurred on December 28, 2016. The New Notes are unsecured and unsubordinated obligations of the Company and will rank equally with all other unsecured and unsubordinated indebtedness of the Company issued from time to time.

[0000833444-17-000007:notes:48]
Other financing arrangements

[0000833444-17-000007:notes:49]
In December 2016, the Company retired, at maturity, $400 million in principal amount, plus accrued interest, of its 2.6% fixed rate notes that matured in December 2016.

[0000833444-17-000007:notes:50]
In December 2016, the Company entered into a 364-day 100 million euro floating rate term loan scheduled to mature in December 2017. Proceeds from the term loan were used for general corporate purposes.

[0000833444-17-000007:notes:51]
In December 2016, a $100 million committed revolving credit facility expired. There were no draws on the facility.

[0000833444-17-000007:notes:52]
In November 2016, the Company fully repaid its 37 billion yen syndicated floating rate term loan, plus accrued interest, scheduled to mature in June 2020.

[0000833444-17-000007:notes:53]
In November 2016, a $35 million committed revolving credit facility expired. There were no draws on the facility.

[0000833444-17-000007:notes:54]
In October 2016, the Company repaid two ten-month floating rate term loans totaling $325 million, plus accrued interest, scheduled to mature in October 2016.

[0000833444-17-000007:notes:55]
In October 2016, the Company repaid a nine-month $100 million floating rate term loan, plus accrued interest, scheduled to mature in November 2016.

[0000833444-17-000007:notes:56]
In October 2016, the Company repaid a nine-month 100 million euro floating rate term loan, plus accrued interest, scheduled to mature in October 2016.

[0000833444-17-000007:notes:57]
Net Financing Charges


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-17-000007:notes:58]
Derivative Instruments and Hedging Activities

[0000833444-17-000007:notes:59]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, stock-based compensation liabilities and interest rates. Under Company policy, the use of derivatives is restricted to those intended for hedging purposes; the use of any derivative instrument for speculative purposes is strictly prohibited. A description of each type of derivative utilized by the Company to manage risk is included in the following paragraphs. In addition, refer to Note 17, "Fair Value Measurements," of the notes to consolidated financial statements for information related to the fair value measurements and valuation methods utilized by the Company for each derivative type.

[0000833444-17-000007:notes:60]
Cash Flow Hedges

[0000833444-17-000007:notes:61]
The Company has global operations and participates in the foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. As cash flow hedges under ASC 815, "Derivatives and Hedging," the effective portion of the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. Any ineffective portion of the hedge is reflected in the consolidated statements of income. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three months ended December 31, 2016 and 2015.

[0000833444-17-000007:notes:62]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of lead, copper, tin and aluminum in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As cash flow hedges, the effective portion of the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions, typically sales, occur and affect earnings. Any ineffective portion of the hedge is reflected in the consolidated statements of income. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.These contracts were highly effective in hedging the variability in future cash flows attributable to changes in commodity prices during the three months ended December 31, 2016 and 2015.

[0000833444-17-000007:notes:63]
The Company had the following outstanding contracts to hedge forecasted commodity purchases:

[0000833444-17-000007:notes:64]
|  |  |  |  | Volume Outstanding as of |
| Commodity |  | Units |  | December 31, 2016 |  | September 30, 2016 |
| Copper |  | Pounds |  | 6,950,000 |  |  | 5,849,000 |  |
| Lead |  | Metric Tons |  | 2,980 |  |  | 5,185 |  |
| Aluminum |  | Metric Tons |  | 1,535 |  |  | 2,620 |  |
| Tin |  | Metric Tons |  | 175 |  |  | 185 |  |

[0000833444-17-000007:notes:65]
In September 2005, the Company entered into three forward treasury lock agreements to reduce the market risk associated with changes in interest rates associated with the Company’s anticipated fixed-rate note issuance to finance the acquisition of York International (cash flow hedge). The three forward treasury lock agreements, which had a combined notional amount of $1.3 billion, fixed a portion of the future interest cost for 5-year, 10-year and 30-year notes. The fair value of each treasury lock agreement, or the difference between the treasury lock reference rate and the fixed rate at time of note issuance, is amortized to interest expense over the life of the respective note issuance. In January 2006, in connection with the Company’s debt refinancing, the three forward treasury lock agreements were terminated.

[0000833444-17-000007:notes:66]
Fair Value Hedges

[0000833444-17-000007:notes:67]
The Company selectively uses interest rate swaps to reduce market risk associated with changes in interest rates for its fixed-rate bonds. As fair value hedges, the interest rate swaps and related debt balances are valued under a market approach using publicized swap curves. Changes in the fair value of the swap and hedged portion of the debt are recorded in the consolidated statements of income. In the third quarter of fiscal 2014, the Company entered into four fixed to floating interest rate swaps totaling $400 million to hedge the coupon of its 2.6% notes that matured in December 2016, three fixed to floating interest rate swaps totaling $300 million to hedge the coupon of its 1.4% notes maturing November 2017 and one fixed to floating interest rate swap totaling $150 million to hedge the coupon of its 7.125% notes maturing July 2017. There were eight interest rate swaps outstanding as of September 30, 2016. In December 2016, the four remaining outstanding interest rate swaps were terminated. The Company had no interest rate swaps outstanding at December 31, 2016.

[0000833444-17-000007:notes:68]
Net Investment Hedges

[0000833444-17-000007:notes:69]
The Company has entered into cross-currency interest rate swaps and foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the cross-currency interest rate swaps and debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.  At December 31, 2016, the Company had 500 million euro bonds designated as net investment hedges in the Company's net investment in Europe. The Company had no cross-currency interest rate swaps outstanding at December 31, 2016. At September 30, 2016, the Company had 37 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan and one billion euro and 500 million euro bonds designated as net investment hedges in the Company's net investment in Europe. The Company had no cross-currency interest rate swaps outstanding at September 30, 2016.

[0000833444-17-000007:notes:70]
Derivatives Not Designated as Hedging Instruments

[0000833444-17-000007:notes:71]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount. As of December 31, 2016 and September 30, 2016, the Company had no equity swaps outstanding as a result of the Tyco Merger and the spin-off.

[0000833444-17-000007:notes:72]
The Company also holds certain foreign currency forward contracts which do not qualify for hedge accounting treatment. The change in fair value of foreign currency exchange derivatives not designated as hedging instruments under ASC 815 are recorded in the consolidated statements of income.

[0000833444-17-000007:notes:73]
The following table presents the location and fair values of derivative instruments and hedging activities included in the Company’s consolidated statements of financial position (in millions):

[0000833444-17-000007:notes:74]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | December 31, |  | September 30, |  | December 31, |  | September 30, |
|  | 2016 |  | 2016 |  | 2016 |  | 2016 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 38 |  |  | $ | 41 |  |  | $ | 5 |  |  | $ | 49 |  |
| Commodity derivatives | 3 |  |  | 4 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Interest rate swaps | — |  |  | 1 |  |  | — |  |  | — |  |
| Total assets | $ | 41 |  |  | $ | 46 |  |  | $ | 5 |  |  | $ | 49 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 12 |  |  | $ | 48 |  |  | $ | 18 |  |  | $ | 18 |  |
| Liabilities held for sale |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | — |  |  | — |  |  | — |  |  | 5 |  |
| Current portion of long-term debt |  |  |  |  |  |  |  |
| Fixed rate debt swapped to floating | — |  |  | 551 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 526 |  |  | 938 |  |  | — |  |  | — |  |
| Fixed rate debt swapped to floating | — |  |  | 301 |  |  | — |  |  | — |  |
| Noncurrent liabilities held for sale |  |  |  |  |  |  |  |
| Foreign currency denominated debt | — |  |  | 1,119 |  |  | — |  |  | — |  |
| Total liabilities | $ | 538 |  |  | $ | 2,957 |  |  | $ | 18 |  |  | $ | 23 |  |

[0000833444-17-000007:notes:75]
Counterparty Credit Risk

[0000833444-17-000007:notes:76]
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association (ISDA) master netting agreements with substantially all of its counterparties. The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-17-000007:notes:77]
The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position. Collateral is generally not required of the Company or the counterparties under the master netting agreements. As of December 31, 2016, and September 30, 2016, no cash collateral was received or pledged under the master netting agreements.

[0000833444-17-000007:notes:78]
Derivatives Impact on the Statements of Income and Statements of Comprehensive Income

[0000833444-17-000007:notes:79]
The following table presents the effective portion of pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the three months ended December 31, 2016 and 2015 (in millions):

[0000833444-17-000007:notes:80]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended December 31, |
|  | 2016 |  | 2015 |
| Foreign currency exchange derivatives |  | $ | 8 |  |  | $ | (2 | ) |
| Commodity derivatives |  | 2 |  |  | (2 | ) |
| Total |  | $ | 10 |  |  | $ | (4 | ) |

[0000833444-17-000007:notes:81]
The following tables present the location and amount of the effective portion of pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the three months ended December 31, 2016 and 2015 (in millions):

[0000833444-17-000007:notes:82]
| Derivatives in ASC 815 Cash FlowHedging Relationships |  | Location of Gain (Loss) Reclassifiedfrom AOCI into Income |  | Three Months Ended December 31, |
|  | 2016 |  | 2015 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 8 |  |  | $ | 5 |  |
| Foreign currency exchange derivatives |  | Income (loss) from discontinued operations |  | — |  |  | (5 | ) |
| Commodity derivatives |  | Cost of sales |  | 1 |  |  | (4 | ) |
| Total |  |  |  | $ | 9 |  |  | $ | (4 | ) |

[0000833444-17-000007:notes:83]
The following table presents the location and amount of pre-tax gains (losses) on fair value hedges recognized in the Company’s consolidated statements of income for the three months ended December 31, 2016 and 2015 (in millions):

[0000833444-17-000007:notes:84]
| Derivatives in ASC 815 Fair ValueHedging Relationships |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended December 31, |
|  | 2016 |  | 2015 |
| Interest rate swap |  | Net financing charges |  | $ | (1 | ) |  | $ | (5 | ) |
| Fixed rate debt swapped to floating |  | Net financing charges |  | 2 |  |  | 5 |  |
| Total |  |  |  | $ | 1 |  |  | $ | — |  |

[0000833444-17-000007:notes:85]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the three months ended December 31, 2016 and 2015 (in millions):

[0000833444-17-000007:notes:86]
|  |  |  |  | Amount of Gain (Loss) Recognized inIncome on Derivative |
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended December 31, |
|  | 2016 |  | 2015 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 1 |  |  | $ | 2 |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 4 |  |  | — |  |
| Foreign currency exchange derivatives |  | Income tax provision |  | (3 | ) |  | — |  |
| Foreign currency exchange derivatives |  | Income (loss) from discontinued operations |  | 5 |  |  | (3 | ) |
| Equity swap |  | Selling, general and administrative |  | — |  |  | (6 | ) |
| Total |  |  |  | $ | 7 |  |  | $ | (7 | ) |

[0000833444-17-000007:notes:87]
The effective portion of pre-tax gains  recorded in foreign currency translation adjustment ("CTA") within other comprehensive income (loss) related to net investment hedges were $47 million and $15 million for the for the three months ended December 31, 2016 and 2015, respectively. For the three months ended December 31, 2016 and 2015, no gains or losses were reclassified from CTA into income for the Company’s outstanding net investment hedges, and no gains or losses were recognized in income for the ineffective portion of cash flow hedges.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-17-000007:notes:88]
Stock-Based Compensation

[0000833444-17-000007:notes:89]
References to the Company's stock throughout Note 13 refer to stock of JCI Inc. prior to the Tyco merger date of September 2, 2016 (the "Merger Date") and to stock of the Company subsequent to the Merger Date.

[0000833444-17-000007:notes:90]
During September 2016, the Board of Directors of the Company approved amendments to the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based compensation awards. The Compensation Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter. A summary of the stock-based awards granted during the three month period ended December 31, 2016 and 2015 is presented below:

[0000833444-17-000007:notes:91]
|  | Three Months Ended December 31, |
|  | 2016 |  | 2015 |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  | Number Granted |  | Weighted Average Grant Date Fair Value |
| Stock options | 2,830,826 |  |  | $ | 7.81 |  |  | 957,278 |  |  | $ | 13.15 |  |
| Stock appreciation rights | 15,693 |  |  | 8.28 |  |  | 54,749 |  |  | 13.15 |  |
| Restricted stock | 1,512,544 |  |  | 41.74 |  |  | 2,224,207 |  |  | 43.86 |  |
| Performance shares | 846,725 |  |  | 48.40 |  |  | — |  |  | — |  |

[0000833444-17-000007:notes:92]
Stock Options

[0000833444-17-000007:notes:93]
Stock options are granted with an exercise price equal to the market price of the Company’s stock at the date of grant. Stock option awards typically vest between two and three years after the grant date and expire ten years from the grant date.

[0000833444-17-000007:notes:94]
The fair value of each option is estimated on the date of grant using a Black-Scholes option valuation model that uses the assumptions noted in the following table. The expected life of options represents the period of time that options granted are expected to be outstanding, assessed separately for executives and non-executives. The risk-free interest rate for periods during the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant. For fiscal 2017, expected volatility is based on historical volatility of certain peer companies over the most recent period corresponding to the expected life as of the grant date. For fiscal 2016, expected volatility is based on the historical volatility of the Company's stock and other factors. The expected dividend yield is based on the expected annual dividend as a percentage of the market value of the Company’s ordinary shares as of the grant date. The Company uses historical data to estimate option exercises and employee terminations within the valuation model.

[0000833444-17-000007:notes:95]
|  | Three Months Ended December 31, |
|  | 2016 |  | 2015 |
| Expected life of option (years) | 4.75 & 6.5 |  | 6.4 |
| Risk-free interest rate | 1.23% - 1.48% |  | 1.64% |
| Expected volatility of the Company’s stock | 24.60% |  | 36.00% |
| Expected dividend yield on the Company’s stock | 2.21% |  | 2.11% |

[0000833444-17-000007:notes:96]
Stock Appreciation Rights (SARs)

[0000833444-17-000007:notes:97]
SARs vest under the same terms and conditions as stock option awards; however, they are settled in cash for the difference between the market price on the date of exercise and the exercise price. As a result, SARs are recorded in the Company’s consolidated statements of financial position as a liability until the date of exercise. The fair value of each SAR award is estimated using a similar method described for stock options. The fair value of each SAR award is recalculated at the end of each reporting period and the liability and expense are adjusted based on the new fair value.

[0000833444-17-000007:notes:98]
Restricted (Nonvested) Stock

[0000833444-17-000007:notes:99]
The Plan provides for the award of restricted stock or restricted stock units to certain employees. These awards are typically share settled unless the employee is a non-U.S. employee or elects to defer settlement until retirement at which point the award would be settled in cash. Restricted awards typically vest after three years from the grant date. The Plan allows for different vesting terms on specific grants with approval by the Board of Directors. The value of restricted awards is based on the closing market value of the Company’s ordinary shares on the date of grant.

[0000833444-17-000007:notes:100]
Performance Share Awards

[0000833444-17-000007:notes:101]
The Plan permits the grant of performance-based share unit ("PSU") awards. The PSUs are generally contingent on the achievement of pre-determined performance goals over a three-year performance period as well as on the award holder's continuous employment until the vesting date. The PSUs are also indexed to the achievement of specified levels of total shareholder return versus a peer group over the performance period. Each PSU that is earned will be settled with shares of the Company's ordinary shares following the completion of the performance period, unless the award holder elected to defer a portion or all of the award until retirement which would then be settled in cash.

[0000833444-17-000007:notes:102]
The fair value of each PSU is estimated on the date of grant using a Monte Carlo simulation that uses the assumptions noted in the following table. The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on historical volatility of certain peer companies over the most recent three-year period as of the grant date.

[0000833444-17-000007:notes:103]
|  | Three Months Ended December 31, 2016 |
| Risk-free interest rate | 1.40% |
| Expected volatility of the Company’s stock | 21.00% |

[0000833444-17-000007:notes:104]
Spin-off Modification

[0000833444-17-000007:notes:105]
In connection with the Adient spin-off, pursuant to the Employee Matters Agreement between the Company and Adient, outstanding stock options and SARs held on October 31, 2016 (the “Spin Date”) by employees remaining with the Company were converted into options and SARs of the Company using a 1.085317-for-one share ratio, which is based on the pre-spin and post-spin closing prices of the Company’s ordinary shares. The exercise prices for options and SARs were converted using the inverse ratio in a manner designed to preserve the intrinsic value of such awards. In addition, pursuant to the Employee Matters Agreement, nonvested restricted stock held on the Spin Date by employees remaining with the Company were converted into nonvested restricted stock of the Company using the 1.085317-for-one share ratio in a manner designed to preserve the intrinsic value of such awards. There were no performance share awards outstanding as of the Spin Date. Employees remaining with the Company did not receive stock-based compensation awards of Adient as a result of the spin-off. Except for the conversion of awards and related exercise prices discussed herein, the material terms of the awards remained unchanged. No incremental fair value resulted from the conversion of the awards; therefore, no additional compensation expense was recorded related to the award modification.

[0000833444-17-000007:notes:106]
Also in connection with the spin-off transaction, pursuant to the Employee Matters Agreement, employees of Adient were entitled to receive stock-based compensation awards of the Company and Adient in replacement of previously outstanding awards of the Company granted prior to the Spin Date. These awards include stock options, SARs and nonvested restricted stock. Upon the Spin Date, the existing awards held by Adient employees were converted into new awards of the Company and Adient on a pro rata basis and further adjusted based on a formula designed to preserve the intrinsic value of such awards. Additional compensation expense, if any, resulting from the modification of awards held by Adient employees is to be recorded by Adient.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-17-000007:notes:107]
[same as prior period, unchanged from 0000833444-16-000197:notes:124]

[0000833444-17-000007:notes:108]
As discussed in Note 1, "Financial Statements," of the notes to consolidated financial statements, on October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience Business from Johnson Controls to Adient plc. The Company did not retain any equity interest in Adient plc. During the first quarter of fiscal 2017, the Company determined that Adient met the criteria to be classified as a discontinued operation and, as a result, Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation, and assets and liabilities were retrospectively reclassified as assets and liabilities held for sale. The Company did not allocate any general corporate overhead to discontinued operations.

[0000833444-17-000007:notes:109]
For the three months ended December 31, 2016, the income from discontinued operations before income taxes included separation costs of $79 million. For the three months ended December 31, 2015, the income from discontinued operations before income taxes included separation costs of $70 million.

[0000833444-17-000007:notes:110]
For the three months ended December 31, 2016, the effective tax rate was more than the U.S. federal statutory rate of 35% primarily due to the tax impacts of separation costs and Adient spin-off related tax expense, partially offset by non-U.S. tax rate differentials. For the three months ended December 31, 2015, the effective tax rate was less than the U.S. federal statutory rate of 35% primarily due to non-U.S. tax rate differentials, partially offset by the tax impacts of separation costs.

[0000833444-17-000007:notes:111]
Assets and Liabilities Held for Sale

[0000833444-17-000007:notes:112]
At December 31, 2016 and September 30, 2016, the assets and liabilities of the security business in South Africa of the Tyco segment were classified as held for sale.

[0000833444-17-000007:notes:113]
At December 31, 2016 and September 30, 2016, $12 million and $17 million, respectively, of certain Corporate assets

[0000833444-17-000007:notes:114]
were classified as held for sale.


## us-gaap:EarningsPerShareTextBlock

[0000833444-17-000007:notes:115]
[same as prior period, unchanged from 0000833444-16-000197:notes:131]

[0000833444-17-000007:notes:116]
The Company presents both basic and diluted earnings per share (EPS) amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future, compensation cost for future service that the Company has not yet recognized and any windfall tax benefits that would be credited to capital in excess of par value when the award generates a tax deduction. If there would be a shortfall resulting in a charge to capital in excess of par value, such an amount would be a reduction of the proceeds. For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method would include unamortized compensation cost and windfall tax benefits or shortfalls.

[0000833444-17-000007:notes:117]
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-17-000007:notes:118]
|  | Three Months EndedDecember 31, |
|  | 2016 |  | 2015 |
| Income Available to Ordinary Shareholders |  |  |  |
| Income from continuing operations | $ | 372 |  |  | $ | 280 |  |
| Income (loss) from discontinued operations | (43 | ) |  | 170 |  |
| Basic and diluted income available to shareholders | $ | 329 |  |  | $ | 450 |  |
| Weighted Average Shares Outstanding |  |  |  |
| Basic weighted average shares outstanding | 937.2 |  |  | 647.7 |  |
| Effect of dilutive securities: |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 10.2 |  |  | 5.1 |  |
| Diluted weighted average shares outstanding | 947.4 |  |  | 652.8 |  |
| Antidilutive Securities |  |  |  |
| Options to purchase shares | 0.1 |  |  | 0.2 |  |

[0000833444-17-000007:notes:119]
During the three months ended December 31, 2016 and 2015, the Company declared a dividend of $0.25 and $0.29, respectively, per share. The Company paid all dividends in the month subsequent to the end of each fiscal quarter.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-17-000007:notes:120]
Fair Value Measurements

[0000833444-17-000007:notes:121]
ASC 820, "Fair Value Measurement," defines fair value as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0000833444-17-000007:notes:122]
Level 1: Observable inputs such as quoted prices in active markets;

[0000833444-17-000007:notes:123]
Level 2: Inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0000833444-17-000007:notes:124]
Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0000833444-17-000007:notes:125]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0000833444-17-000007:notes:126]
Recurring Fair Value Measurements

[0000833444-17-000007:notes:127]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of December 31, 2016 and September 30, 2016 (in millions):

[0000833444-17-000007:notes:128]
|  | Fair Value Measurements Using: |
|  | Total as of December 31, 2016 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 43 |  |  | $ | — |  |  | $ | 43 |  |  | $ | — |  |
| Commodity derivatives | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Investments in marketable common stock | 4 |  |  | 4 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 83 |  |  | 83 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 163 |  |  | 163 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 89 |  |  | 89 |  |  | — |  |  | — |  |
| Total assets | $ | 385 |  |  | $ | 339 |  |  | $ | 46 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 30 |  |  | $ | — |  |  | $ | 30 |  |  | $ | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 526 |  |  | 526 |  |  | — |  |  | — |  |
| Total liabilities | $ | 556 |  |  | $ | 526 |  |  | $ | 30 |  |  | $ | — |  |

[0000833444-17-000007:notes:129]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2016 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 90 |  |  | $ | — |  |  | $ | 90 |  |  | $ | — |  |
| Commodity derivatives | 4 |  |  | — |  |  | 4 |  |  | — |  |
| Exchange traded funds (fixed income)1 | 15 |  |  | 15 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Interest rate swaps | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Investments in marketable common stock | 3 |  |  | 3 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 81 |  |  | 81 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 163 |  |  | 163 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 86 |  |  | 86 |  |  | — |  |  | — |  |
| Total assets | $ | 443 |  |  | $ | 348 |  |  | $ | 95 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 66 |  |  | $ | — |  |  | $ | 66 |  |  | $ | — |  |
| Liabilities held for sale |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | 5 |  |  | — |  |  | 5 |  |  | — |  |
| Current portion of long-term debt |  |  |  |  |  |  |  |
| Fixed rate debt swapped to floating | 551 |  |  | — |  |  | 551 |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 938 |  |  | 938 |  |  | — |  |  | — |  |
| Fixed rate debt swapped to floating | 301 |  |  | — |  |  | 301 |  |  | — |  |
| Noncurrent liabilities held for sale |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 1,119 |  |  | 1,119 |  |  | — |  |  | — |  |
| Total liabilities | $ | 2,980 |  |  | $ | 2,057 |  |  | $ | 923 |  |  | $ | — |  |

[0000833444-17-000007:notes:130]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 22, "Commitments and Contingencies" of the notes to consolidated financial statements for further details.

[0000833444-17-000007:notes:131]
Valuation Methods

[0000833444-17-000007:notes:132]
Foreign currency exchange derivatives: The foreign currency exchange derivatives are valued under a market approach using publicized spot and forward prices.

[0000833444-17-000007:notes:133]
Commodity derivatives: The commodity derivatives are valued under a market approach using publicized prices, where available, or dealer quotes.

[0000833444-17-000007:notes:134]
Interest rate swaps and related debt: The interest rate swaps and related debt balances are valued under a market approach using publicized swap curves.

[0000833444-17-000007:notes:135]
Equity swaps: The equity swaps are valued under a market approach as the fair value of the swaps is equal to the Company’s stock price at the reporting period date.

[0000833444-17-000007:notes:136]
Cross-currency interest rate swaps: The cross-currency interest rate swaps are valued using observable market data.

[0000833444-17-000007:notes:137]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices.

[0000833444-17-000007:notes:138]
Investments in marketable common stock and exchange traded funds:  Investments in marketable common stock and exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. There was an unrealized loss recorded on these investments of $3 million as of December 31, 2016 within AOCI in the consolidated statements of  financial position. There was an unrealized loss recorded on these investments of $1 million as of September 30, 2016 within AOCI in the consolidated statements of financial position.

[0000833444-17-000007:notes:139]
Foreign currency denominated debt: The Company has entered into a foreign currency denominated debt obligation to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effect of the debt obligation are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally. The foreign denominated debt obligation is remeasured to current exchange rates under a market approach using publicized spot prices. At December 31, 2016, the Company had 500 million euro bonds designated as net investment hedges in the Company's net investment in Europe. At September 30, 2016, the Company had 37 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan and one billion euro and 500 million euro bonds designated as net investment hedges in the Company's net investment in Europe.

[0000833444-17-000007:notes:140]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The fair value of long-term debt, which was $11.0 billion and $15.7 billion at December 31, 2016 and September 30, 2016, respectively, was determined primarily using market quotes classified as Level 1 inputs within the ASC 820 fair value hierarchy.


## us-gaap:FiniteLivedAndIndefiniteLivedIntangibleAssetsAcquiredAsPartOfBusinessCombinationTableTextBlock

[0000833444-17-000007:notes:141]
The preliminary purchase price allocation to identifiable intangible assets acquired are as follows:

[0000833444-17-000007:notes:142]
|  |  | Preliminary Fair Value (in millions) |  | Weighted Average Life (in years) |
| Customer relationships |  | $ | 2,280 |  |  | 11 |
| Completed technology |  | 1,530 |  |  | 10 |
| Other definite-lived intangibles |  | 223 |  |  | 8 |
| Indefinite-lived trademarks |  | 2,020 |  |  |  |
| Other indefinite-lived intangibles |  | 90 |  |  |  |
| In-process research and development |  | 60 |  |  |  |
| Total identifiable intangible assets |  | $ | 6,203 |  |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-17-000007:notes:143]
Goodwill and Other Intangible Assets

[0000833444-17-000007:notes:144]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the three month period ended December 31, 2016 were as follows (in millions):

[0000833444-17-000007:notes:145]
|  |  |  | Business Acquisitions |  | Business Divestitures |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  |  | December 31, |
|  | 2016 |  |  |  |  | 2016 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |  |  |
| Building Efficiency |  |  |  |  |  |  |  |  |  |
| Systems and Service North America | $ | 975 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 975 |  |
| Products North America | 1,697 |  |  | — |  |  | — |  |  | (5 | ) |  | 1,692 |  |
| Asia | 657 |  |  | — |  |  | — |  |  | (42 | ) |  | 615 |  |
| Rest of World | 301 |  |  | 1 |  |  | — |  |  | (12 | ) |  | 290 |  |
| Tyco | 16,308 |  |  | 19 |  |  | — |  |  | (192 | ) |  | 16,135 |  |
| Power Solutions | 1,086 |  |  | — |  |  | — |  |  | (21 | ) |  | 1,065 |  |
| Total | $ | 21,024 |  |  | $ | 20 |  |  | $ | — |  |  | $ | (272 | ) |  | $ | 20,772 |  |

[0000833444-17-000007:notes:146]
At September 30, 2016, accumulated goodwill impairment charges included $47 million related to the Building Efficiency Rest of World - Latin America reporting unit.

[0000833444-17-000007:notes:147]
Amortization of other intangible assets included within continuing operations for the three month periods ended December 31, 2016 and 2015 was $149 million and $20 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2018, 2019, 2020, 2021 and 2022 will be approximately $416 million, $403 million, $392 million, $385 million and $379 million per year, respectively.


## us-gaap:GuaranteesTextBlock

[0000833444-17-000007:notes:148]
[same as prior period, unchanged from 0000833444-16-000197:notes:169]

[0000833444-17-000007:notes:149]
Certain of the Company's subsidiaries at the business segment level have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance. Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-17-000007:notes:150]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate for future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-17-000007:notes:151]
The Company’s product warranty liability for continuing operations is recorded in the consolidated statements of financial position in other current liabilities if the warranty is less than one year and in other noncurrent liabilities if the warranty extends longer than one year.

[0000833444-17-000007:notes:152]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations, including extended warranties for which deferred revenue is recorded, for the three months ended December 31, 2016 and 2015 were as follows (in millions):

[0000833444-17-000007:notes:153]
|  | Three Months EndedDecember 31, |
|  | 2016 |  | 2015 |
| Balance at beginning of period | $ | 374 |  |  | $ | 288 |  |
| Accruals for warranties issued during the period | 82 |  |  | 93 |  |
| Accruals from acquisition and divestitures | (1 | ) |  | 35 |  |
| Accruals related to pre-existing warranties | (6 | ) |  | — |  |
| Settlements made (in cash or in kind) during the period | (73 | ) |  | (77 | ) |
| Currency translation | (6 | ) |  | (1 | ) |
| Balance at end of period | $ | 370 |  |  | $ | 338 |  |

[0000833444-17-000007:notes:154]
As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded, as part of the acquired liabilities of Tyco, $290 million of post sale contingent tax indemnification liabilities within other noncurrent liabilities in the consolidated statements of financial position. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. Of the $290 million recorded as of September 30, 2016 and December 31, 2016, $255 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0000833444-17-000007:notes:155]
Impairment of Long-Lived Assets

[0000833444-17-000007:notes:156]
The Company reviews long-lived assets for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals.

[0000833444-17-000007:notes:157]
In the first quarter of fiscal 2017, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2017. As a result, the Company reviewed the long-lived assets for impairment and recorded $15 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income, all of which related to Corporate assets. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000007:notes:158]
At December 31, 2016 and 2015, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-17-000007:notes:159]
[same as prior period, unchanged from 0000833444-16-000197:notes:178]

[0000833444-17-000007:notes:160]
In calculating the provision for income taxes, the Company uses an estimate of the annual effective tax rate based upon the facts and circumstances known at each interim period. On a quarterly basis, the actual effective tax rate is adjusted, as appropriate, based upon changed facts and circumstances, if any, as compared to those forecasted at the beginning of the fiscal year and each interim period thereafter. The U.S. federal statutory tax rate is being used as a comparison since the Company was a U.S. domiciled company for 11 months of 2016 and due to the Company's current legal entity structure.  For the three months ended December 31, 2016, the Company's effective tax rate for continuing operations was (7)% and was lower than the U.S. federal statutory rate of 35% primarily due to the benefits of continuing global tax planning initiatives, non-U.S. tax rate differentials and a tax benefit due to changes in entity tax status, partially offset by the jurisdictional mix of significant restructuring and impairment costs, as well as the Tyco Merger transaction and integration costs, and purchase accounting impacts. For the three months ended December 31, 2015, the Company's effective tax rate for continuing operations was 22%. The effective rate was lower than the U.S. federal statutory rate of 35% primarily due to global tax planning and non-U.S. tax rate differentials.

[0000833444-17-000007:notes:161]
Valuation Allowance

[0000833444-17-000007:notes:162]
The Company reviews the realizability of its deferred tax assets on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-17-000007:notes:163]
Uncertain Tax Positions

[0000833444-17-000007:notes:164]
At September 30, 2016, exclusive of items included in noncurrent liabilities held for sale, the Company had gross tax effected unrecognized tax benefits of $1,706 million, of which $1,604 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2016 was approximately $55 million (net of tax benefit). The interest and penalties accrued during the three months ended December 31, 2016 and 2015 was not material. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-17-000007:notes:165]
In the U.S., fiscal years 2010 through 2014 are currently under exam by the Internal Revenue Service ("IRS") and 2008 through 2009 are currently under IRS appeals. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions:

[0000833444-17-000007:notes:166]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2011 - 2014 |
| Brazil |  | 2011 - 2012 |
| Canada |  | 2012 - 2015 |
| France |  | 2010 - 2015 |
| Germany |  | 2007 - 2013 |
| Italy |  | 2006, 2011 |
| Mexico |  | 2009 - 2015 |
| Spain |  | 2009 - 2014 |
| United Kingdom |  | 2011 - 2014 |

[0000833444-17-000007:notes:167]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, of which could be up to a $50 million impact to tax expense.

[0000833444-17-000007:notes:168]
Impacts of Tax Legislation

[0000833444-17-000007:notes:169]
On October 13, 2016, the U.S. Treasury and the IRS released final and temporary Section 385 regulations. These regulations address whether certain instruments between related parties are treated as debt or equity. The Company does not expect that the regulations will have a material impact on its consolidated financial statements.

[0000833444-17-000007:notes:170]
During the three months ended December 31, 2016 and 2015, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-17-000007:notes:171]
Other Tax Matters

[0000833444-17-000007:notes:172]
In the first quarter of fiscal 2017, the Company recorded a discrete tax benefit of  $101 million due to changes in entity tax status.

[0000833444-17-000007:notes:173]
In the first quarter of fiscal 2017, the Company recorded $130 million of transaction and integration costs which generated an $11 million tax benefit.

[0000833444-17-000007:notes:174]
In the first quarter of fiscal 2017, the Company recorded $78 million of significant restructuring and impairment costs. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $14 million tax benefit.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-17-000007:notes:175]
Inventories

[0000833444-17-000007:notes:176]
Inventories consisted of the following (in millions):

[0000833444-17-000007:notes:177]
|  | December 31, 2016 |  | September 30, 2016 |
| Raw materials and supplies | $ | 872 |  |  | $ | 852 |  |
| Work-in-process | 521 |  |  | 503 |  |
| Finished goods | 1,550 |  |  | 1,533 |  |
| Inventories | $ | 2,943 |  |  | $ | 2,888 |  |


## us-gaap:LongTermContractsOrProgramsDisclosureTextBlock

[0000833444-17-000007:notes:178]
Percentage-of-Completion Contracts

[0000833444-17-000007:notes:179]
The Building Technologies & Solutions business records certain long-term contracts under the percentage-of-completion method of accounting. Under this method, sales and gross profit are recognized as work is performed based on the relationship between actual costs incurred and total estimated costs at completion. The Company records costs and earnings in excess of billings on uncompleted contracts primarily within accounts receivable - net and billings in excess of costs and earnings on uncompleted contracts primarily within other current liabilities in the consolidated statements of financial position. Costs and earnings in excess of billings related to these contracts were $812 million and $841 million at December 31, 2016 and September 30, 2016, respectively. Billings in excess of costs and earnings related to these contracts were $462 million and $431 million at December 31, 2016 and September 30, 2016, respectively.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-17-000007:notes:180]
Merger Transaction

[0000833444-17-000007:notes:181]
As discussed in Note 1, "Financial Statements," of the notes to consolidated financial statements, JCI Inc. and Tyco completed the Merger on September 2, 2016. The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with ASC 805, "Business Combinations." Based on the structure of the Merger and other activities contemplated by the Merger Agreement, relative outstanding share ownership, the composition of the Company's board of directors and the designation of certain senior management positions of the Company, JCI Inc. was the accounting acquirer for financial reporting purposes.

[0000833444-17-000007:notes:182]
Immediately prior to the Merger and in connection therewith, Tyco shareholders received 0.955 ordinary shares of Tyco (which shares are now referred to as shares of the Company, or “Company ordinary shares”) for each Tyco ordinary share they held by virtue of a 0.955-for-one share consolidation. In the Merger, each outstanding share of common stock, par value $1.00 per share, of JCI Inc. (“JCI Inc. common stock”) (other than shares held by JCI Inc., Tyco and certain of their subsidiaries) was converted into the right to receive either the cash consideration or the share consideration (each as described below), at the election of the holder, subject to proration procedures described in the Merger Agreement and applicable withholding taxes.  The election to receive the cash consideration was undersubscribed. As a result, holders of shares of JCI Inc. common stock that elected to receive the share consideration and holders of shares of JCI Inc. common stock that made no election (or failed to properly make an election) became entitled to receive, for each such share of JCI Inc. common stock, $5.7293 in cash, without interest, and 0.8357 Company ordinary shares, subject to applicable withholding taxes.  Holders of shares of JCI Inc. common stock that elected to receive the cash consideration became entitled to receive, for each such share of JCI Inc. common stock, $34.88 in cash, without interest, subject to applicable withholding taxes.  In the merger, JCI Inc. shareholders received, in the aggregate, approximately $3.864 billion in cash. Immediately after the closing of, and giving effect to, the Merger, former JCI Inc. shareholders owned approximately 56% of the issued and outstanding Company ordinary shares and former Tyco stockholders owned approximately 44% of the issued and outstanding Company ordinary shares.

[0000833444-17-000007:notes:183]
Tyco is a leading global provider of security products and services, fire detection and suppression products and services, and life safety products. The acquisition of Tyco brings together best-in-class product, technology and service capabilities across controls, fire, security, heating, ventilating and air conditioning (HVAC), power solutions and energy storage, to serve various end-markets including large institutions, commercial buildings, retail, industrial, small business and residential.  The combination of the Tyco and JCI Inc. buildings platforms is expected to create immediate opportunities for near-term growth through cross-selling, complementary branch and channel networks, and expanded global reach for established businesses. The new Company is also expected to benefit by combining innovation capabilities and pipelines involving new products, advanced solutions for smart buildings and cities, value-added services driven by advanced data and analytics and connectivity between buildings and energy storage through infrastructure integration.

[0000833444-17-000007:notes:184]
Fair Value of Consideration Transferred

[0000833444-17-000007:notes:185]
The total fair value of consideration transferred was approximately $19.7 billion. Total consideration is comprised of the equity value of the Tyco shares that were outstanding as of September 2, 2016 and the portion of Tyco's share awards and share options earned as of September 2, 2016 ($224 million). Share awards and share options not earned ($101 million) as of September 2, 2016 will be expensed over the remaining future vesting period.

[0000833444-17-000007:notes:186]
| (1) | Amount equals JCI Inc. closing share price and market capitalization at September 2, 2016 ($45.45 and $29,012 million, respectively) adjusted for the Tyco $3,864 million cash contribution used to purchase 110.8 million shares of JCI Inc. common stock for $34.88 per share. |

[0000833444-17-000007:notes:187]
Fair Value of Assets Acquired and Liabilities Assumed

[0000833444-17-000007:notes:188]
The Company accounted for the merger with Tyco as a business combination using the acquisition method of accounting. The assets acquired and liabilities assumed were recorded at their respective fair values as of the acquisition date.

[0000833444-17-000007:notes:189]
As the Company finalizes the fair value of assets acquired and liabilities assumed, additional purchase price adjustments may be recorded during the measurement period in fiscal 2017. Fair value estimates are based on a complex series of judgments about future events and uncertainties and rely heavily on estimates and assumptions. The judgments used to determine the estimated fair value assigned to each class of assets acquired and liabilities assumed, as well as asset lives, can materially impact the Company's results of operations. The finalization of the purchase accounting assessment may result in a change in the valuation of assets acquired and liabilities assumed and may have a material impact on the Company's results of operations and financial position.

[0000833444-17-000007:notes:190]
The preliminary fair values of the assets acquired and liabilities assumed are as follows (in millions):

[0000833444-17-000007:notes:191]
| Cash and cash equivalents |  | $ | 489 |  |
| Accounts receivable |  | 2,095 |  |
| Inventories |  | 831 |  |
| Other current assets |  | 609 |  |
| Property, plant, and equipment - net |  | 1,224 |  |
| Goodwill |  | 16,382 |  |
| Intangible assets - net |  | 6,203 |  |
| Other noncurrent assets |  | 536 |  |
| Total assets acquired |  | $ | 28,369 |  |
| Short-term debt |  | $ | 462 |  |
| Accounts payable |  | 723 |  |
| Accrued compensation and benefits |  | 306 |  |
| Other current liabilities |  | 1,610 |  |
| Long-term debt |  | 6,416 |  |
| Long-term deferred tax liabilities |  | 1,173 |  |
| Long-term pension and postretirement benefits |  | 774 |  |
| Other noncurrent liabilities |  | 1,064 |  |
| Total liabilities acquired |  | $ | 12,528 |  |
| Noncontrolling interests |  | 34 |  |
| Net assets acquired |  | $ | 15,807 |  |
| Cash consideration paid to JCI Inc. shareholders |  | 3,864 |  |
| Total fair value of consideration transferred |  | $ | 19,671 |  |

[0000833444-17-000007:notes:192]
In connection with the merger, the Company recorded goodwill of $16.4 billion, which is attributable primarily to expected synergies, expanded market opportunities, and other benefits that the Company believes will result from combining its operations with the operations of Tyco. The goodwill created in the merger is not deductible for tax purposes and is subject to potential significant changes as the purchase price allocation is completed. Goodwill has preliminarily been allocated to the Tyco segment based on how the business was reviewed by the Company's Chief Operating Decision Maker as shown in Note 8, "Goodwill and Other Intangible Assets." In connection with the Tyco Merger, the Company recorded additional goodwill of $19 million in the first quarter of fiscal 2017 related to purchase price allocations.

[0000833444-17-000007:notes:193]
Acquisitions and Divestitures

[0000833444-17-000007:notes:194]
In the first quarter of fiscal 2017, the Company completed two acquisitions for a combined purchase price, net of cash acquired, of $6 million, $3 million of which was paid in the three months ended December 31, 2016. The acquisitions in the aggregate were not material to the Company’s consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $1 million.

[0000833444-17-000007:notes:195]
In the first quarter of fiscal 2017, the Company completed one divestiture for a sales price of $4 million, none of which was received in the three months ended December 31, 2016.  The divestiture decreased the Company's ownership from a controlling to noncontrolling interest and as a result the Company deconsolidated cash of $5 million.The divestiture was not material to the Company's consolidated financial statements.

[0000833444-17-000007:notes:196]
During the first quarter of fiscal 2017, the Company received $52 million in net cash proceeds related to prior year business divestitures.

[0000833444-17-000007:notes:197]
In the first quarter of fiscal 2016, the Company formed a joint venture with Hitachi to expand its Building Efficiency product offerings. The Company acquired a 60% ownership interest in the new entity for approximately $178 million ($608 million purchase price less cash acquired of $430 million), $133 million of which was paid in the three months ended December 31, 2015 and $45 million was paid in the three months ended December 31, 2016. In connection with the acquisition, the Company recorded goodwill of $253 million related to purchase price allocations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-17-000007:notes:198]
Financial Statements

[0000833444-17-000007:notes:199]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (SEC). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2016 filed with the SEC on November 23, 2016. The results of operations for the three month period ended December 31, 2016 are not necessarily indicative of results for the Company’s 2017 fiscal year because of seasonal and other factors.

[0000833444-17-000007:notes:200]
Nature of Operations

[0000833444-17-000007:notes:201]
On September 2, 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco International plc (“Tyco”) completed their combination pursuant to the Agreement and Plan of Merger (the “Merger Agreement”), dated as of January 24, 2016, as amended by Amendment No. 1, dated as of July 1, 2016, by and among JCI Inc., Tyco and certain other parties named therein, including Jagara Merger Sub LLC, an indirect wholly owned subsidiary of Tyco (“Merger Sub”). Pursuant to the terms of the Merger Agreement, on September 2, 2016, Merger Sub merged with and into JCI Inc., with JCI Inc. being the surviving corporation in the merger and a wholly owned, indirect subsidiary of Tyco (the “Merger”). Following the Merger, Tyco changed its name to “Johnson Controls International plc.” The Merger changed the jurisdiction of organization from the United States to Ireland. The domicile to Ireland became effective on September 2, 2016.

[0000833444-17-000007:notes:202]
The merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes. Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company. Refer to Note 3, "Merger Transaction," of the notes to consolidated financial statements for further information.

[0000833444-17-000007:notes:203]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience Business from Johnson Controls to Adient plc and the issuance of ordinary shares of Adient directly to holders of Johnson Controls ordinary shares on a pro rata basis. Prior to the open of business on October 31, 2016, each of the Company's shareholders received one ordinary share of Adient plc for every 10 ordinary shares of Johnson Controls held as of the close of business on October 19, 2016, the record date for the distribution. Company shareholders received cash in lieu of fractional shares of Adient, if any. Following the separation and distribution, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc. Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation at December 31, 2016. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-17-000007:notes:204]
Principles of Consolidation

[0000833444-17-000007:notes:205]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with U.S. GAAP. All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the year are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company’s interest exceeds 20% and the Company does not have a controlling interest.

[0000833444-17-000007:notes:206]
Under certain criteria as provided for in Financial Accounting Standards Board (FASB) ASC 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity (VIE). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting rights. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.

[0000833444-17-000007:notes:207]
Consolidated VIEs

[0000833444-17-000007:notes:208]
Based upon the criteria set forth in ASC 810, the Company has determined that it was the primary beneficiary in one VIE for the reporting period ended December 31, 2016 and three VIEs for the reporting period ended  September 30, 2016, as the Company absorbs significant economics of the entities and has the power to direct the activities that are considered most significant to the entities.

[0000833444-17-000007:notes:209]
Two of the VIEs manufacture products in North America for the automotive industry. The Company funded the entities’ short-term liquidity needs through revolving credit facilities and had the power to direct the activities that were considered most significant to the entities through its key customer supply relationships. These VIE's were divested as a result of the Adient spin-off in the first quarter of fiscal 2017.

[0000833444-17-000007:notes:210]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE has been consolidated within the Company’s consolidated statements of financial position. The impact of consolidation of the entity on the Company’s consolidated statements of income for the three month periods ended December 31, 2016 and 2015 was not material. The VIE is named as a co-obligor under a third party debt agreement in the amount of $170 million, maturing in fiscal 2020, under which it could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business.

[0000833444-17-000007:notes:211]
The carrying amounts and classification of assets (none of which are restricted) and liabilities included in the Company’s consolidated statements of financial position for the consolidated VIEs are as follows (in millions):

[0000833444-17-000007:notes:212]
|  | December 31, 2016 |  | September 30, 2016 |
| Current assets | $ | 2 |  |  | $ | 284 |  |
| Noncurrent assets | 54 |  |  | 98 |  |
| Total assets | $ | 56 |  |  | $ | 382 |  |
| Current liabilities | $ | 3 |  |  | $ | 230 |  |
| Noncurrent liabilities | 44 |  |  | 29 |  |
| Total liabilities | $ | 47 |  |  | $ | 259 |  |

[0000833444-17-000007:notes:213]
The Company did not have a significant variable interest in any other consolidated VIEs for the presented reporting periods.

[0000833444-17-000007:notes:214]
Nonconsolidated VIEs

[0000833444-17-000007:notes:215]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is not considered to be the primary beneficiary of two of the entities as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balance of $60 million  and $59 million at December 31, 2016 and September 30, 2016 respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned previously within the "Consolidated VIEs" section above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.

[0000833444-17-000007:notes:216]
The Company did not have a significant variable interest in any other unconsolidated VIEs for the presented reporting periods.

[0000833444-17-000007:notes:217]
Restricted Cash

[0000833444-17-000007:notes:218]
At December 31, 2016, the Company held restricted cash of approximately $42 million, of which $33 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities. At September 30, 2016, the Company held restricted cash of approximately $88 million, of which $79 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash held in escrow from business divestitures and cash restricted for payment of asbestos liabilities.

[0000833444-17-000007:notes:219]
Retrospective Changes

[0000833444-17-000007:notes:220]
Certain amounts as of September 30, 2016 have been revised to conform to the current year’s presentation.

[0000833444-17-000007:notes:221]
During the first quarter of fiscal 2017, the Company determined that its Automotive Experience business (Adient) met the criteria to be classified as a discontinued operation, which required retrospective application to financial information for all periods presented. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-17-000007:notes:222]
In the first quarter of fiscal 2017, the Company began evaluating the performance of its business segments primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans. Historical information has been revised to present the comparable periods on a consistent basis.

[0000833444-17-000007:notes:223]
In April 2015, the FASB issued Accounting Standards Update (ASU) No. 2015-03, "Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." ASU No. 2015-03 requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability.

[0000833444-17-000007:notes:224]
During the quarter ended December 31, 2016, the Company adopted ASU No. 2015-03 and applied the change retrospectively to all periods presented. This change did not have an impact to any period presented on the consolidated statements of income. The financial statement impact of this change for the period ending September 30, 2016 was a decrease to noncurrent assets held for sale of $44 million, a decrease to noncurrent liabilities held for sale of $44 million, a decrease to other noncurrent assets of $30 million and a decrease to long-term debt of $30 million.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-17-000007:notes:225]
Pension and Postretirement Plans

[0000833444-17-000007:notes:226]
The components of the Company’s net periodic benefit costs from continuing operations associated with its defined benefit pension and postretirement plans are shown in the tables below in accordance with ASC 715, "Compensation – Retirement Benefits" (in millions):

[0000833444-17-000007:notes:227]
|  | U.S. Pension Plans |
|  | Three Months EndedDecember 31, |
|  | 2016 |  | 2015 |
| Service cost | $ | 5 |  |  | $ | 4 |  |
| Interest cost | 28 |  |  | 25 |  |
| Expected return on plan assets | (59 | ) |  | (46 | ) |
| Net actuarial gain | (117 | ) |  | — |  |
| Settlement gain | (8 | ) |  | — |  |
| Net periodic benefit credit | $ | (151 | ) |  | $ | (17 | ) |

[0000833444-17-000007:notes:228]
|  | Non-U.S. Pension Plans |
|  | Three Months EndedDecember 31, |
|  | 2016 |  | 2015 |
| Service cost | $ | 8 |  |  | $ | 3 |  |
| Interest cost | 12 |  |  | 6 |  |
| Expected return on plan assets | (23 | ) |  | (8 | ) |
| Net periodic benefit cost (credit) | $ | (3 | ) |  | $ | 1 |  |

[0000833444-17-000007:notes:229]
|  | Postretirement Benefits |
|  | Three Months EndedDecember 31, |
|  | 2016 |  | 2015 |
| Service cost | $ | 1 |  |  | $ | — |  |
| Interest cost | 1 |  |  | 1 |  |
| Expected return on plan assets | (3 | ) |  | (2 | ) |
| Net periodic benefit credit | $ | (1 | ) |  | $ | (1 | ) |

[0000833444-17-000007:notes:230]
During the three months ended December 31, 2016, the amount of lump sum payouts triggered a remeasurement event for certain U.S. pension plans resulting in the recognition of net actuarial gains of $117 million.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-17-000007:notes:231]
Related Party Transactions

[0000833444-17-000007:notes:232]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-17-000007:notes:233]
The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $225 million and $49 million, respectively, for the three months ended December 31, 2016; and $234 million and $38 million, respectively, for the three months ended December 31, 2015.

[0000833444-17-000007:notes:234]
The following table sets forth the amount of accounts receivable due from and payable to related parties for continuing operations in the consolidated statements of financial position (in millions):

[0000833444-17-000007:notes:235]
|  |  | December 31, 2016 |  | September 30, 2016 |  |
| Receivable from related parties |  | $ | 50 |  |  | $ | 66 |  |
| Payable to related parties |  | 29 |  |  | 11 |  |

[0000833444-17-000007:notes:236]
The Company has also provided financial support to certain of its VIE's, see Note 1, "Financial Statements," of the notes to consolidated financial statements for additional information.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-17-000007:notes:237]
Significant Restructuring and Impairment Costs

[0000833444-17-000007:notes:238]
To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company commits to restructuring plans as necessary.

[0000833444-17-000007:notes:239]
In fiscal 2017, the Company committed to a significant restructuring plan (2017 Plan) and recorded $78 million of restructuring and impairment costs in the consolidated statements of income. This is the total amount incurred to date for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $65 million related to Corporate, $6 million related to the Building Efficiency Asia segment, $5 million related to the Tyco segment and $2 million related to the Building Efficiency Rest of World segment. The restructuring actions are expected to be substantially complete in 2017.

[0000833444-17-000007:notes:240]
The following table summarizes the changes in the Company’s 2017 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-17-000007:notes:241]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original Reserve | $ | 62 |  |  | $ | 15 |  |  | $ | 1 |  |  | $ | 78 |  |
| Utilized—noncash | — |  |  | (15 | ) |  | (1 | ) |  | (16 | ) |
| Balance at December 31, 2016 | $ | 62 |  |  | $ | — |  |  | $ | — |  |  | $ | 62 |  |

[0000833444-17-000007:notes:242]
In fiscal 2016, the Company committed to a significant restructuring plan (2016 Plan) and recorded $288 million of restructuring and impairment costs in the consolidated statements of income. This is the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments, change-in-control payments and immaterial changes in estimates to prior year plans. Of the restructuring and impairment costs recorded, $161 million related to Corporate, $66 million related to the Power Solutions segment, $26 million related to the Building Efficiency Asia segment, $16 million related to the Building Efficiency Rest of World segment, $9 million related to the Building Efficiency Products North America segment, $8 million related to the Tyco segment, and $2 million related to the Building Efficiency Systems and Service North America segment. The restructuring actions are expected to be substantially complete in fiscal 2018. Included in the reserve is $73 million of committed restructuring actions taken by Tyco for liabilities assumed as part of the Tyco acquisition.

[0000833444-17-000007:notes:243]
Additionally, the Company recorded $332 million of restructuring and impairment costs within discontinued operations related to Adient in fiscal 2016.

[0000833444-17-000007:notes:244]
The following table summarizes the changes in the Company’s 2016 Plan reserve, included within other current liabilities and liabilities held for sale in the consolidated statements of financial position (in millions):

[0000833444-17-000007:notes:245]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original Reserve | $ | 368 |  |  | $ | 190 |  |  | $ | 62 |  |  | $ | — |  |  | $ | 620 |  |
| Acquired Tyco restructuring reserves | 78 |  |  | — |  |  | — |  |  | — |  |  | 78 |  |
| Utilized—cash | (32 | ) |  | — |  |  | — |  |  | — |  |  | (32 | ) |
| Utilized—noncash | — |  |  | (190 | ) |  | (32 | ) |  | 1 |  |  | (221 | ) |
| Balance at September 30, 2016 | $ | 414 |  |  | $ | — |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 445 |  |
| Adient spin-off impact | (194 | ) |  | — |  |  | (22 | ) |  | — |  |  | (216 | ) |
| Utilized—cash | (23 | ) |  | — |  |  | — |  |  | — |  |  | (23 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (4 | ) |  | (4 | ) |
| Adjustment to acquired Tyco restructuring reserves | — |  |  | — |  |  | (5 | ) |  | — |  |  | (5 | ) |
| Balance at December 31, 2016 | $ | 197 |  |  | $ | — |  |  | $ | 3 |  |  | $ | (3 | ) |  | $ | 197 |  |

[0000833444-17-000007:notes:246]
The Company's fiscal 2017 and 2016 restructuring plans included workforce reductions of approximately 3,200 employees (2,400 for the Building Technologies & Solutions business and 800 for Corporate). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of December 31, 2016, approximately 300 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included ten plant closures in the Building Technologies & Solutions business. As of December 31, 2016, one of the ten plants have been closed.

[0000833444-17-000007:notes:247]
Company management closely monitors its overall cost structure and continually analyzes each of its businesses for opportunities to consolidate current operations, improve operating efficiencies and locate facilities in close proximity to customers. This ongoing analysis includes a review of its manufacturing, engineering and purchasing operations, as well as the overall global footprint for all its businesses.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-17-000007:notes:248]
The following schedules present changes in accumulated other comprehensive income (AOCI) attributable to Johnson Controls (in millions, net of tax):

[0000833444-17-000007:notes:249]
|  | Three Months EndedDecember 31, |
|  | 2016 |  | 2015 |
| Foreign currency translation adjustments |  |  |  |
| Balance at beginning of period | $ | (1,152 | ) |  | $ | (1,047 | ) |
| Aggregate adjustment for the period (net of tax effect of $5 and $(4)) | (659 | ) |  | (160 | ) |
| Adient spin-off impact (net of tax effect of $0) | 563 |  |  | — |  |
| Balance at end of period | (1,248 | ) |  | (1,207 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 4 |  |  | (7 | ) |
| Current period changes in fair value (net of tax effect of $4 and $0) | 6 |  |  | (4 | ) |
| Reclassification to income (net of tax effect of $(3) and $1) * | (6 | ) |  | 3 |  |
| Adient spin-off impact (net of tax effect of $6 and $0) | 16 |  |  | — |  |
| Balance at end of period | 20 |  |  | (8 | ) |
| Realized and unrealized losses on marketable securities |  |  |  |
| Balance at beginning of period | (1 | ) |  | — |  |
| Current period changes in fair value (net of tax effect of $0) | (2 | ) |  | — |  |
| Balance at end of period | (3 | ) |  | — |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (4 | ) |  | (3 | ) |
| Adient spin-off impact (net of tax effect of $0) | 2 |  |  | — |  |
| Balance at end of period | (2 | ) |  | (3 | ) |
| Accumulated other comprehensive loss, end of period | $ | (1,233 | ) |  | $ | (1,218 | ) |

[0000833444-17-000007:notes:250]
*  Refer to Note 16, "Derivative Instruments and Hedging Activities," of the notes to consolidated financial statements for disclosure of the line items on the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000833444-17-000007:notes:251]
Financial information relating to the Company’s reportable segments is as follows (in millions):

[0000833444-17-000007:notes:252]
|  | Net Sales |
|  | Three Months EndedDecember 31, |
|  | 2016 |  | 2015 |
| Building Technologies & Solutions |  |  |  |
| Building Efficiency |  |  |  |
| Systems and Service North America | $ | 928 |  |  | $ | 984 |  |
| Products North America | 543 |  |  | 557 |  |
| Asia | 1,042 |  |  | 992 |  |
| Rest of World | 398 |  |  | 423 |  |
|  | 2,911 |  |  | 2,956 |  |
| Tyco | 2,275 |  |  | — |  |
|  | 5,186 |  |  | 2,956 |  |
| Power Solutions | 1,900 |  |  | 1,740 |  |
| Total net sales | $ | 7,086 |  |  | $ | 4,696 |  |

[0000833444-17-000007:notes:253]
|  | Segment EBITA |
|  | Three Months EndedDecember 31, |
|  | 2016 |  | 2015 |
| Building Technologies & Solutions |  |  |  |
| Building Efficiency |  |  |  |
| Systems and Service North America | $ | 75 |  |  | $ | 99 |  |
| Products North America | 37 |  |  | 33 |  |
| Asia | 119 |  |  | 70 |  |
| Rest of World | (10 | ) |  | (3 | ) |
|  | 221 |  |  | 199 |  |
| Tyco | 214 |  |  | — |  |
|  | 435 |  |  | 199 |  |
| Power Solutions | 389 |  |  | 360 |  |
| Segment EBITA | $ | 824 |  |  | $ | 559 |  |
| Corporate expenses | $ | (193 | ) |  | $ | (87 | ) |
| Amortization of intangible assets | (149 | ) |  | (20 | ) |
| Restructuring and impairment costs | (78 | ) |  | — |  |
| Net mark-to-market adjustments on pension plans | 117 |  |  | — |  |
| Net financing charges | (136 | ) |  | (66 | ) |
| Income from continuing operations before income taxes | $ | 385 |  |  | $ | 386 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-17-000007:notes:254]
Segment Information

[0000833444-17-000007:notes:255]
During the first quarter of fiscal 2017, the Company determined that the Automotive Experience business met the criteria to be classified as a discontinued operation, which required retrospective application to financial information for all periods presented. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-17-000007:notes:256]
In the first quarter of fiscal 2017, the Company began evaluating the performance of its business segments primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans.  Historical information has been revised to present the comparable periods on a consistent basis.

[0000833444-17-000007:notes:257]
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has six reportable segments for financial reporting purposes. The Company’s six reportable segments are presented in the context of its two primary businesses – Building Technologies & Solutions and Power Solutions.

[0000833444-17-000007:notes:258]
Building Technologies & Solutions

[0000833444-17-000007:notes:259]
Building Efficiency

[0000833444-17-000007:notes:260]
Building Efficiency designs, produces, markets and installs HVAC and control systems that monitor, automate and integrate critical building segment equipment and conditions including HVAC, fire-safety and security in commercial buildings and in various industrial applications.

[0000833444-17-000007:notes:261]
| • | Systems and Service North America provides products and services to non-residential building and industrial applications in the North American marketplace. The products and services include HVAC and controls systems, energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems. |

[0000833444-17-000007:notes:262]
| • | Products North America designs and produces heating and air conditioning solutions for residential and light commercial applications, and also markets products and refrigeration systems to the replacement and new construction markets in the North American marketplace. Products North America also includes HVAC products installed for Navy and Marine customers globally. |

[0000833444-17-000007:notes:263]
| • | Asia provides HVAC, controls and refrigeration systems and technical services to the Asian marketplace. Asia also includes the Johnson Controls-Hitachi Air Conditioning joint venture, which was formed October 1, 2015. |

[0000833444-17-000007:notes:264]
| • | Rest of World provides HVAC, controls and refrigeration systems and technical services to markets in Europe, the Middle East and Latin America. |

[0000833444-17-000007:notes:265]
Tyco

[0000833444-17-000007:notes:266]
Tyco designs, sells, installs, services and monitors integrated electronic security systems and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers. The Tyco business also designs, manufactures and sells fire protection, security and life safety products, including intrusion security, anti-theft devices, breathing apparatus and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide.

[0000833444-17-000007:notes:267]
Power Solutions

[0000833444-17-000007:notes:268]
Power Solutions services both automotive original equipment manufacturers and the battery aftermarket by providing advanced battery technology, coupled with systems engineering, marketing and service expertise.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-17-000007:notes:269]
Equity and Noncontrolling Interests

[0000833444-17-000007:notes:270]
Other comprehensive income includes activity relating to discontinued operations. The following schedules present changes in consolidated equity attributable to Johnson Controls and noncontrolling interests (in millions, net of tax):

[0000833444-17-000007:notes:271]
As previously disclosed, on October 31, 2016, the Company completed the Adient spin-off. As a result of the spin-off, the Company divested net assets of $4,020 million. The Company expects any final cash and working capital adjustments to occur in the second quarter of fiscal 2017.

[0000833444-17-000007:notes:272]
As previously disclosed, on October 1, 2015, the Company formed a joint venture with Hitachi. In connection with the acquisition, the Company recorded equity attributable to noncontrolling interests of $679 million.

[0000833444-17-000007:notes:273]
Following the Tyco Merger, the Company adopted, subject to the ongoing existence of sufficient distributable reserves, the existing Tyco International plc $1 billion share repurchase program in September 2016. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. For the three month periods ended December 31, 2016, the Company had no repurchases of its ordinary shares.

[0000833444-17-000007:notes:274]
The Company consolidates certain subsidiaries in which the noncontrolling interest party has within its control the right to require the Company to redeem all or a portion of its interest in the subsidiary. The redeemable noncontrolling interests are reported at their estimated redemption value. Any adjustment to the redemption value impacts retained earnings but does not impact net income. Redeemable noncontrolling interests which are redeemable only upon future events, the occurrence of which is not currently probable, are recorded at carrying value.

[0000833444-17-000007:notes:275]
The following schedules present changes in the redeemable noncontrolling interests (in millions):

[0000833444-17-000007:notes:276]
|  | Three Months EndedDecember 31, |
|  | 2016 |  | 2015 |
| Beginning balance, September 30 | $ | 234 |  |  | $ | 212 |  |
| Net income | 13 |  |  | 20 |  |
| Foreign currency translation adjustments | (9 | ) |  | (8 | ) |
| Realized and unrealized losses on derivatives | — |  |  | (2 | ) |
| Dividends | (43 | ) |  | (6 | ) |
| Spin-off of Adient | (36 | ) |  | — |  |
| Ending balance, December 31 | $ | 159 |  |  | $ | 216 |  |


## us-gaap:SubsequentEventsTextBlock

[0000833444-17-000007:notes:277]
Subsequent Event

[0000833444-17-000007:notes:278]
On February 2, 2017, the Company issued $500 million aggregate principal amount of 4.5% senior unsecured fixed rate notes due in February 2047. Proceeds were used for general corporate purposes.
