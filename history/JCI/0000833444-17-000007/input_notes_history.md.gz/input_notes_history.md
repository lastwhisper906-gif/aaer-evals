# JCI note change history — 0000833444-16-000197 → 0000833444-17-000007


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2017-02-08):
[0000833444-17-000007:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of December 31, 2016, reserves for environmental liabilities totaled $45 million, of which $9 million was recorded within other current liabilities and $36 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at  September 30, 2016. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At December 31, 2016 and September 30, 2016, the Company recorded conditional asset retirement obligations of $70 million and $74 million, respectively.

- changed (2017-02-08):
[0000833444-17-000007:note_history:2]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.
  (was, 2016-07-29, similarity 0.819):
[0000833444-16-000197:note_history:2]
The Company and certain of its subsidiaries, including Grinnell LLC (“Grinnell”), along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. Substantially all cases pending against affiliates of the Company have been filed against Grinnell, and have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

- added (2017-02-08):
[0000833444-17-000007:note_history:3]
As of December 31, 2016, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position is $156 million. The net liability within the consolidated statements of financial position is comprised of a liability for pending and future claims and related defense costs of $544 million, of which $35 million is recorded in other current liabilities and $509 million is recorded in other noncurrent liabilities. The Company also maintains separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $388 million, of which $42 million is recorded in other current assets, and $346 million is recorded in other noncurrent assets. Assets include $32 million of cash and $252 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at December 31, 2016 is $104 million. As of September 30, 2016, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position is $148 million. The net liability within the consolidated statements of financial position is comprised of a liability for pending and future claims and related defense costs of $548 million, of which $35 million is recorded in other current liabilities and $513 million is recorded in other noncurrent liabilities. The Company also maintains separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $400 million, of which $41 million is recorded in other current assets, and $359 million is recorded in other noncurrent assets. Assets include $16 million of cash and $264 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2016 is $120 million. The Company believes that the asbestos related liabilities and insurance related receivables recorded as of December 31, 2016 and September 30, 2016 are appropriate.

- added (2017-02-08):
[0000833444-17-000007:note_history:4]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2069 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2069. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

- added (2017-02-08):
[0000833444-17-000007:note_history:5]
Insurable Liabilities

- added (2017-02-08):
[0000833444-17-000007:note_history:6]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At December 31, 2016 and September 30, 2016, the insurable liabilities for continuing operations totaled $421 million and $422 million, respectively, of which $61 million and $60 million was recorded within other current liabilities, $31 million and $28 million was recorded within accrued compensation and benefits, and $329 million and $334 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

- added (2017-02-08):
[0000833444-17-000007:note_history:7]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.

- removed (2017-02-08):
[0000833444-16-000197:note_history:8]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of June 24, 2016, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $20 million to $69 million. As of June 24, 2016, Tyco concluded that the best estimate within this range is approximately $31 million, of which $11 million is included in Accrued and other current liabilities and $20 million is included in Other liabilities within the Company's Consolidated Balance Sheet.

- removed (2017-02-08):
[0000833444-16-000197:note_history:9]
As previously disclosed, the majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. As of June 24, 2016, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $12 million to $44 million. The Company's best estimate within that range is approximately $21 million, of which $9 million is included in Accrued and other current liabilities and $12 million is included in Other liabilities within the Company's Consolidated Balance Sheet.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.

- removed (2017-02-08):
[0000833444-16-000197:note_history:10]
During the third quarter of fiscal 2014, the Company, through Grinnell, resolved disputes with certain of its historical insurers and agreed that certain insurance proceeds would be used to establish and fund a qualified settlement fund (“QSF”), within the meaning of the Internal Revenue Code, which would be used for the resolution primarily of Grinnell asbestos liabilities. It is intended that the QSF will receive future insurance payments and proceeds from third party insurers and, in addition, will fund and manage liabilities for certain historical operations of the Company, primarily related to Grinnell. On January 9, 2015, the Company completed a series of restructuring transactions related to the establishment and funding of a dedicated structure pursuant to which a subsidiary of the Company acquired the assets of Grinnell and transferred cash and other assets totaling approximately $278 million (not including $22 million received by the QSF during the quarter ended December 26, 2014 from historic third-party insurers in settlement of coverage disputes) to the structure. As part of the restructuring, subsidiaries in the structure assumed certain liabilities related to historic Grinnell, Scott and Figgie operations, including all historical Grinnell asbestos liabilities, and such subsidiaries purchased additional insurance by, through or from a wholly-owned subsidiary in the structure in order to supplement and enhance existing insurance assets.

- removed (2017-02-08):
[0000833444-16-000197:note_history:11]
The Company consolidates the qualified settlement fund and related entities that were established for the purpose of managing and resolving the liabilities described above. Although the entities in the dedicated structure serve the specific purpose of managing certain liabilities, each entity in the structure is a wholly-owned indirect subsidiary of the Company, and therefore is required to be consolidated under GAAP.

- removed (2017-02-08):
[0000833444-16-000197:note_history:12]
As of June 24, 2016, the Company has determined that there were approximately 3,000 claims pending against its subsidiaries, primarily Grinnell. This amount reflects the Company's current estimate of the number of viable claims made against Grinnell and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties.

- removed (2017-02-08):
[0000833444-16-000197:note_history:13]
As of June 24, 2016, the Company's estimated asbestos related net liability recorded within the Company's Consolidated Balance Sheet is $18 million. The net liability within the Consolidated Balance Sheet is comprised of a liability for pending and future claims and related defense costs of $492 million, of which $22 million is recorded in Accrued and other current liabilities, and $470 million is recorded in Other liabilities. The Company also maintains separate cash, investment and other assets within the Consolidated Balance Sheet of $474 million, of which $31 million is recorded in Prepaid expenses and other current assets, and $443 million is recorded in Other assets. Assets include $11 million of cash and $257 million of investments, which have all been designated as restricted.  As of September 25, 2015, the Company's estimated net liability recorded within the Company's Consolidated Balance Sheet was $28 million. The net liability was comprised of a liability for pending and future claims and related defense costs of $515 million, of which $23 million was recorded in Accrued and other current liabilities, and $492 million was recorded in Other liabilities.  The Company also maintained separate cash, investment and other assets within the Consolidated Balance Sheet of $487 million, of which $38 million was recorded in Prepaid expenses and other current assets, and $449 million was recorded in Other assets. Assets included $11 million of cash and $263 million of investments, which were all designated as restricted.

- removed (2017-02-08):
[0000833444-16-000197:note_history:14]
The Company periodically assesses the sufficiency of its estimated liability for pending and future asbestos claims and defense costs. On a periodic basis, the Company, through the dedicated structure referred to above, evaluates actual experience regarding asbestos claims filed, settled and dismissed, amounts paid in settlements, and the recoverability of its insurance assets. If and when data from actual experience demonstrate a significant unfavorable discernible trend, the Company performs a valuation of its asbestos related liabilities and corresponding insurance assets including a comprehensive review of the underlying assumptions. In addition, the Company evaluates its ability to reasonably estimate claim activity beyond its current look-forward period (through 2056) in order to assess whether such period continues to be appropriate. In addition to claims and litigation experience, the Company considers additional qualitative and quantitative factors such as changes in legislation, the legal environment, the Company’s strategy in managing claims and obtaining insurance, including its defense strategy, and health related trends in the overall population of individuals potentially exposed to asbestos. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance assets is warranted.

- removed (2017-02-08):
[0000833444-16-000197:note_history:15]
Tax Matters

- removed (2017-02-08):
[0000833444-16-000197:note_history:16]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation. The issues and proposed adjustments related to such years are generally subject to the sharing provisions of the 2007 Tax Sharing Agreement and Tyco's liabilities under the 2007 Tax Sharing Agreement are further subject to the sharing provisions in the 2012 Tax Sharing Agreement. Tyco has previously disclosed that on June 20, 2013, it had received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owed additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million had been asserted. These amounts excluded interest and did not reflect the roll-forward impact on subsequent audit periods.

- removed (2017-02-08):
[0000833444-16-000197:note_history:17]
As previously reported, the Company, as Audit Managing Party under each Tax Sharing Agreement dated September 25, 2007 (among the Company, TE Connectivity Ltd. and Covidien plc (which on January 26, 2015 was acquired by and now operates as a subsidiary of Medtronic plc) and dated September 28, 2012 (among the Company, The ADT Corporation and Pentair Ltd. (along with TE Connectivity and Covidien, the "Parties")), entered into Stipulations of Settled Issues with the IRS intended to resolve all Federal tax disputes related to the intercompany debt issues for the Company’s 1997 - 2000 audit cycle before the U.S. Tax Court. The Stipulations of Settled Issues were contingent upon the IRS Appeals Division applying the same settlement terms to all intercompany debt issues on appeal for subsequent audit cycles (2001 - 2007). On May 17, 2016 the IRS Office of Appeals issued fully-executed Forms 870-AD that effectively settled the matters on appeal on the same terms as those set forth in the Stipulations of Settled Issues, and on May 31, 2016, the U.S. Tax Court entered decisions consistent with the Stipulations of Settled Issues. As a result, all aspects of this controversy that were before the U.S. Tax Court and Appeals Division of the IRS have been finally resolved for audit cycles 1997 - 2007. The Company paid $120 million to TE Connectivity Ltd. and $2 million to Covidien during the second quarter of fiscal 2016 representing its share of the total amount payable to the IRS in connection with this matter.

- removed (2017-02-08):
[0000833444-16-000197:note_history:18]
Additionally, during the third quarter of fiscal 2016, the Company also paid $12 million to Covidien and $4 million to TE Connectivity with respect to other matters sharable pursuant to the 2007 Tax Sharing Agreement.

- removed (2017-02-08):
[0000833444-16-000197:note_history:19]
As a result of the final settlement, the Company assessed its remaining obligations under its tax sharing agreements. Based on the assessment performed, the Company reversed a portion of its shared tax obligation liabilities related to the 2007 and 2012 Tax Sharing Agreements, and recognized a gain of $54 million in Other income (expense), net within the Consolidated Statements of Operations for both the quarter and nine months ended June 24, 2016. The Company believes the remaining liabilities that it has recorded are sufficient to cover its future obligations under the Tax Sharing Agreements.

- removed (2017-02-08):
[0000833444-16-000197:note_history:20]
Other Matters

- removed (2017-02-08):
[0000833444-16-000197:note_history:21]
On March 1, 2016, a putative class action lawsuit, Wandel v. Tyco International plc, et al., Docket No. C-000010-16, was filed in the Superior Court of New Jersey naming Tyco, the individual members of its board of directors, Johnson Controls and Merger Sub as defendants. The complaint alleges that Tyco’s directors breached their fiduciary duties and exercised their powers as directors in a manner oppressive to the public shareholders of Tyco in violation of Irish law by, among other things, failing to take steps to maximize shareholder value and failing to protect against purported conflicts of interest. The complaint further alleges that Tyco, Johnson Controls and Merger Sub aided and abetted Tyco’s directors in the breach of their fiduciary duties. The complaint seeks, among other things, to enjoin the merger. The Company believes that the claims asserted by the complaint are not valid.

- removed (2017-02-08):
[0000833444-16-000197:note_history:22]
On May 20, 2016, a putative class action lawsuit, Laufer v. Johnson Controls, Inc., et al., Docket No. 2016CV003859, was filed in the Circuit Court of Wisconsin, Milwaukee County, naming Johnson Controls, the individual members of its board of directors, Tyco and Merger Sub as defendants. The complaint alleges that Johnson Controls' directors breached their fiduciary duties by, among other things, failing to take steps to maximize shareholder value, seeking to benefit themselves improperly and failing to disclose material information in this joint proxy statement/prospectus. The complaint further alleges that Tyco aided and abetted Johnson Controls' directors in the breach of their fiduciary duties. The complaint seeks, among other things, to enjoin the merger. The Company believes that the claims asserted by the complaint are not valid.

- removed (2017-02-08):
[0000833444-16-000197:note_history:23]
In addition to the foregoing, the Company is subject to claims and suits, including from time to time, contractual disputes and product and general liability claims, incidental to present and former operations, acquisitions and dispositions. With respect to many of these claims, the Company either self-insures or maintains insurance through third-parties, with varying deductibles. While the ultimate outcome of these matters cannot be predicted with certainty, the Company believes that the resolution of any such proceedings, whether the underlying claims are covered by insurance or not, will not have a material adverse effect on the Company's financial condition, results of operations or cash flows beyond amounts recorded for such matters.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2017-02-08):
[0000833444-16-000197:note_history:24]
Basis of Presentation and Summary of Significant Accounting Policies

- removed (2017-02-08):
[0000833444-16-000197:note_history:25]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year.  These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 25, 2015 (the "2015 Form 10-K") and Current Report filed on Form 8-K filed on March 11, 2016 which recast the Company's consolidated financial statements for each of the three years in the period ended September 25, 2015 to reflect changes in the presentation of operating income by segment. The information included in this Form 8-K was presented for informational purposes only and does not amend or restate the Company’s audited consolidated financial statements, which were included in its 2015 Form 10-K, and did not affect the Company’s previously reported net income, earnings per share, cash flows, operating income or assets or liabilities for any of the periods presented therein.

- removed (2017-02-08):
[0000833444-16-000197:note_history:26]
References to 2016 and 2015 are to Tyco's fiscal quarters ending June 24, 2016 and June 26, 2015, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September.  Fiscal 2016 is a 53-week year as compared with fiscal 2015, which was 52 weeks, with the additional week occurring in the fourth quarter of fiscal 2016.  The Company's results for the quarters and nine months ended June 24, 2016 and June 26, 2015 both consisted of 13 weeks and 39 weeks, respectively.

- removed (2017-02-08):
[0000833444-16-000197:note_history:27]
The Company operates and reports financial and operating information in the following three segments: North America Integrated Solutions & Services ("NA Integrated Solutions & Services"), Rest of World Integrated Solutions & Services ("ROW Integrated Solutions & Services") and Global Products. The Company also provides general corporate services to its segments which is reported as a fourth, non-operating segment, Corporate and Other.

- removed (2017-02-08):
[0000833444-16-000197:note_history:28]
Proposed Merger with Johnson Controls, Inc.— On January 24, 2016, Tyco entered into an Agreement and Plan of Merger (as amended, the “Merger Agreement”) with Johnson Controls, Inc., a Wisconsin corporation (“Johnson Controls”), and certain other parties named therein (which was subsequently amended by Amendment No. 1 on July 1, 2016), including Jagara Merger Sub LLC, a Wisconsin limited liability company and indirect wholly owned subsidiary of Tyco (“Merger Sub”). Pursuant to the Merger Agreement and subject to the terms and conditions set forth therein, Merger Sub will merge with and into Johnson Controls (the “Merger”), with Johnson Controls surviving the Merger as an indirect wholly owned subsidiary of Tyco. At the effective time of the Merger, Tyco will change its name to “Johnson Controls International plc” and will trade under the ticker symbol “JCI.” Following such time, Tyco is referred to below as the “Combined Company.”

- removed (2017-02-08):
[0000833444-16-000197:note_history:29]
As a result of the Merger, each outstanding share of Johnson Controls common stock (the “Johnson Controls Shares”), other than shares held by Johnson Controls, its subsidiaries, Tyco or Merger Sub, will be converted into the right to receive (subject to proration as described below), at the holder’s election, either: (i) one (1) (the “Exchange Ratio”) ordinary share of the Combined Company (the “Share Consideration”); or (ii) an amount in cash equal to $34.88 (the “Cash Consideration”). Elections will be prorated so that Johnson Controls shareholders will receive in the aggregate approximately $3.864 billion of cash in the Merger (the “Aggregate Cash Consideration”). Holders that do not make an election will be treated as having elected to receive the Share Consideration. The Exchange Ratio takes into account the effects of a Tyco share consolidation contemplated by the Merger Agreement whereby, immediately prior to the Merger, every issued and unissued ordinary share of Tyco (each, a “Tyco Share”) will be consolidated into 0.955 of a share of Tyco.

- removed (2017-02-08):
[0000833444-16-000197:note_history:30]
The completion of the Merger is subject to certain closing conditions, including, among others, (i) the approval and adoption of the Merger Agreement by holders of two-thirds of the Johnson Controls Shares entitled to vote on such matter, (ii) the approval by the Tyco shareholders, at a special meeting of the Tyco shareholders (the “Tyco Special Meeting”) of (A) the issuance of Tyco shares in connection with the Merger, (B) the Tyco share consolidation and (C) the increase in Tyco’s authorized share capital, in each case, by a majority of the votes cast on these matters at the Tyco Special Meeting, and of certain amendments to Tyco’s articles of association, including a change of its name to “Johnson Controls International plc,” by at least 75% of the votes cast on these matters at the Tyco Special Meeting (clause (ii), collectively, the “Tyco Shareholder Approvals”), (iii) the expiration or termination of any waiting period applicable to the Merger under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, the consent of, or filing with, certain specified antitrust authorities, and certain other customary regulatory approvals, and (iv) Tyco’s obtaining the financing required to close the Merger on the terms set forth in the Merger Agreement.

- removed (2017-02-08):
[0000833444-16-000197:note_history:31]
The Merger Agreement contains specified termination rights, including, among others, the right of either party to terminate the Merger Agreement (i) if the requisite shareholder approvals have not been obtained, (ii) if the board of directors of the other party effects a change of recommendation, (iii) if the closing has not occurred by October 24, 2016, subject to extension to January 24, 2017 in certain circumstances, (iv) in response to certain intervening events (subject to the limitations set forth in the Merger Agreement) or (v) if there is a material breach by the other party of any of its representations, warranties or covenants, subject to certain conditions.

- removed (2017-02-08):
[0000833444-16-000197:note_history:32]
Tyco has entered into a senior unsecured term loan facility in the amount of $4 billion to finance the cash consideration for, and fees, expenses and costs incurred in connection with, the merger. In addition, the Company has entered into a revolving credit agreement in the amount of $1 billion, which is intended to replace Tyco's existing $1.5 billion revolving credit agreement. Tyco's ability to draw down on both the term loan facility and the new revolving credit agreement is contingent on the consummation of the merger with Johnson Controls. See Note 9.

- removed (2017-02-08):
[0000833444-16-000197:note_history:33]
Change of Jurisdiction— On May 30, 2014, Tyco entered into a Merger Agreement with Tyco International plc, a newly-formed Irish public limited company and a wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement with Tyco Ireland, Tyco merged with and into Tyco Ireland, with Tyco Ireland being the surviving company. This resulted in Tyco Ireland becoming Tyco's publicly-traded parent company and changed the jurisdiction of organization of Tyco from Switzerland to Ireland. Tyco's shareholders received one ordinary share of Tyco Ireland for each ordinary share of Tyco held immediately prior to the re-domicile to Ireland. The re-domicile to Ireland became effective on November 17, 2014.

- removed (2017-02-08):
[0000833444-16-000197:note_history:34]
Reclassifications— Certain prior period amounts have been reclassified to conform with the current period presentation.

- removed (2017-02-08):
[0000833444-16-000197:note_history:35]
Effective for the first quarter of fiscal 2016, the Company has elected to present operating income by segment, as well as Corporate and Other, excluding restructuring and repositioning charges, net.  Restructuring and repositioning charges, net, are shown in aggregate. This presentation is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. See Note 15.

- removed (2017-02-08):
[0000833444-16-000197:note_history:36]
During the third quarter of fiscal 2016, the Company reclassified the assets and liabilities of a business it plans to sell within the ROW Integrated Solutions & Services segment as held for sale for all periods presented within the Consolidated Balance Sheets.  As of June 24, 2016, assets of $71 million and liabilities of $34 million were reclassified as held for sale related to this business. The results of operations of this business are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied. During the second quarter of fiscal 2016, the Company completed the sale of its Australian fire protection business, included in the ROW Integrated Solutions & Services segment. The assets and liabilities related to this business were classified as held for sale as of September 25, 2015.  Its results of operations are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied. See Note 3.

- removed (2017-02-08):
[0000833444-16-000197:note_history:37]
Recently Adopted Accounting Pronouncements— In April 2014, the Financial Accounting Standards Board ("FASB") issued authoritative guidance to change the criteria for reporting discontinued operations. Under the new guidance, only disposals representing a strategic shift that has or will have a major effect on the Company's operations and financial results should be reported as discontinued operations, with expanded disclosures. The guidance became effective for Tyco in the first quarter of fiscal 2016. The Company considers both qualitative and quantitative factors when assessing whether a disposed business represents a strategic shift that will have a major effect on the Company's operations and financial results. The Company considers the level (e.g. individual business or product line, reporting unit or reportable segment) and geographic impact (e.g. country, region, worldwide) of the disposal group. In addition, the Company considers the significance of the disposed business on certain financial measures when assessing whether or not such disposal has a major effect on the Company's operations and financial results. The adoption of this guidance did not have a material impact on the Company's financial position, results of operations or cash flows. During fiscal 2016, the divestiture of the Company's Australian fire protection business and the planned sale of another business within its ROW Integrated Solutions & Services segment did not meet the criteria set forth in the new guidance and therefore were not classified as discontinued operations. See Note 3.

- removed (2017-02-08):
[0000833444-16-000197:note_history:38]
Recently Issued Accounting Pronouncements— In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires quantitative and qualitative disclosures that are more comprehensive than existing standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. The new standard permits either the full retrospective method or the modified retrospective method of adoption. In August 2015, the FASB issued authoritative guidance to defer the effective date of this guidance, which for Tyco will be the first quarter of fiscal 2019, with early adoption permitted beginning the first quarter of fiscal 2018. In March 2016, the FASB issued additional authoritative guidance clarifying its implementation guidance on principal versus agent considerations when determining whether to report revenue gross versus net. In April 2016, the FASB issued additional authoritative guidance clarifying issues related to identifying performance obligations and licensing. In May 2016, the FASB issued additional authoritative guidance specifically in the areas of assessing collectability, presentation of sales taxes, noncash consideration, and completed contracts and contract modifications. The Company is in the process of assessing the impact the guidance is expected to have upon adoption, including determining the adoption method.

- removed (2017-02-08):
[0000833444-16-000197:note_history:39]
In May 2015, the FASB issued authoritative guidance that is intended to improve the existing disclosure requirements for short-duration contracts for insurance entities that issue such contracts.  The guidance requires additional information to be disclosed about the liability for unpaid claims and claim adjustment expenses to increase the transparency of significant estimates made in measuring those liabilities.  This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- removed (2017-02-08):
[0000833444-16-000197:note_history:40]
In July 2015, the FASB issued authoritative guidance intended to simplify the existing guidance under which an entity must measure inventory at the lower of cost or market. Under the new guidance, inventory is “measured at the lower of cost and net realizable value,” and does not apply to inventory that is measured using last-in, first-out or the retail method. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- removed (2017-02-08):
[0000833444-16-000197:note_history:41]
In September 2015, the FASB issued authoritative guidance intended to reduce the cost and complexity of financial reporting when recognizing adjustments to provisional amounts in connection with a business combination. This guidance eliminates the requirement to restate prior period financial statements, but requires entities to present separately on the face of the income statement, or disclose in the notes, the portion of the amount recorded in current-period earnings by line item that would have been recorded in previous reporting periods if the adjustment to the provisional amounts had been recognized as of the acquisition date. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- removed (2017-02-08):
[0000833444-16-000197:note_history:42]
In November 2015, the FASB issued authoritative guidance intended to simplify the presentation of deferred income taxes.  Under the new guidance, deferred tax liabilities and deferred tax assets are to be classified as noncurrent in a classified statement of financial position.  The current requirement that deferred tax liabilities and assets of a tax-paying component of an entity be offset and presented as a single amount is not affected by the amendments in this update. This guidance is effective for Tyco in the first quarter of fiscal 2018, with early adoption permitted on a prospective or retrospective basis. The Company plans to adopt this guidance as of September 30, 2016 and does not expect the guidance to have a material impact on its financial statements.

- removed (2017-02-08):
[0000833444-16-000197:note_history:43]
In January 2016, the FASB issued authoritative guidance addressing the recognition, measurement, presentation and disclosure of financial assets and liabilities. The guidance primarily affects the accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments. In addition, the guidance clarifies the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. This guidance is effective for Tyco in the first quarter of fiscal 2019, and early adoption is not permitted, with certain exceptions.  The amendments are required to be applied by means of a cumulative-effect adjustment on the balance sheet as of the beginning of the fiscal year of adoption.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- removed (2017-02-08):
[0000833444-16-000197:note_history:44]
In February 2016, the FASB issued authoritative guidance requiring the recognition of lease assets and lease liabilities by lessees for those leases previously classified as operating leases. The guidance requires quantitative and qualitative disclosures that are more comprehensive than existing standards. The disclosures are intended to enable financial statement users to understand the amount, timing and uncertainty of cash flows arising from leases. This guidance is effective for Tyco in the first quarter of fiscal 2020 with early adoption permitted. The amendments are required to be applied by means of a modified retrospective approach. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- removed (2017-02-08):
[0000833444-16-000197:note_history:45]
In March 2016, the FASB amended its authoritative guidance for employee share-based payment transactions by simplifying several aspects of the accounting for employee share-based payment awards, including the accounting for income taxes, withholding taxes and forfeitures, as well as classification on the statement of cash flows. The amended guidance is effective for Tyco in the first quarter of fiscal 2018 with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- removed (2017-02-08):
[0000833444-16-000197:note_history:46]
In June 2016, the FASB issued authoritative guidance amending the impairment model for most financial assets by requiring a new forward-looking “expected loss” methodology that will replace today’s “incurred loss” methodology and generally result in the more timely recognition of allowances for credit losses. Furthermore, additional disclosures will be required. The guidance is effective for Tyco in the first quarter of fiscal 2021, with early adoption permitted in the first quarter of fiscal 2020. The Company is in the process of assessing the timing and impact, if any, the guidance may have upon adoption.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2017-02-08):
[0000833444-17-000007:note_history:47]
Financial Statements

- added (2017-02-08):
[0000833444-17-000007:note_history:48]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (SEC). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2016 filed with the SEC on November 23, 2016. The results of operations for the three month period ended December 31, 2016 are not necessarily indicative of results for the Company’s 2017 fiscal year because of seasonal and other factors.

- added (2017-02-08):
[0000833444-17-000007:note_history:49]
Nature of Operations

- added (2017-02-08):
[0000833444-17-000007:note_history:50]
On September 2, 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco International plc (“Tyco”) completed their combination pursuant to the Agreement and Plan of Merger (the “Merger Agreement”), dated as of January 24, 2016, as amended by Amendment No. 1, dated as of July 1, 2016, by and among JCI Inc., Tyco and certain other parties named therein, including Jagara Merger Sub LLC, an indirect wholly owned subsidiary of Tyco (“Merger Sub”). Pursuant to the terms of the Merger Agreement, on September 2, 2016, Merger Sub merged with and into JCI Inc., with JCI Inc. being the surviving corporation in the merger and a wholly owned, indirect subsidiary of Tyco (the “Merger”). Following the Merger, Tyco changed its name to “Johnson Controls International plc.” The Merger changed the jurisdiction of organization from the United States to Ireland. The domicile to Ireland became effective on September 2, 2016.

- added (2017-02-08):
[0000833444-17-000007:note_history:51]
The merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes. Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company. Refer to Note 3, "Merger Transaction," of the notes to consolidated financial statements for further information.

- added (2017-02-08):
[0000833444-17-000007:note_history:52]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience Business from Johnson Controls to Adient plc and the issuance of ordinary shares of Adient directly to holders of Johnson Controls ordinary shares on a pro rata basis. Prior to the open of business on October 31, 2016, each of the Company's shareholders received one ordinary share of Adient plc for every 10 ordinary shares of Johnson Controls held as of the close of business on October 19, 2016, the record date for the distribution. Company shareholders received cash in lieu of fractional shares of Adient, if any. Following the separation and distribution, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc. Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation at December 31, 2016. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information.

- added (2017-02-08):
[0000833444-17-000007:note_history:53]
Principles of Consolidation

- added (2017-02-08):
[0000833444-17-000007:note_history:54]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with U.S. GAAP. All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the year are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company’s interest exceeds 20% and the Company does not have a controlling interest.

- added (2017-02-08):
[0000833444-17-000007:note_history:55]
Under certain criteria as provided for in Financial Accounting Standards Board (FASB) ASC 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity (VIE). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting rights. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.

- added (2017-02-08):
[0000833444-17-000007:note_history:56]
Consolidated VIEs

- added (2017-02-08):
[0000833444-17-000007:note_history:57]
Based upon the criteria set forth in ASC 810, the Company has determined that it was the primary beneficiary in one VIE for the reporting period ended December 31, 2016 and three VIEs for the reporting period ended  September 30, 2016, as the Company absorbs significant economics of the entities and has the power to direct the activities that are considered most significant to the entities.

- added (2017-02-08):
[0000833444-17-000007:note_history:58]
Two of the VIEs manufacture products in North America for the automotive industry. The Company funded the entities’ short-term liquidity needs through revolving credit facilities and had the power to direct the activities that were considered most significant to the entities through its key customer supply relationships. These VIE's were divested as a result of the Adient spin-off in the first quarter of fiscal 2017.

- added (2017-02-08):
[0000833444-17-000007:note_history:59]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE has been consolidated within the Company’s consolidated statements of financial position. The impact of consolidation of the entity on the Company’s consolidated statements of income for the three month periods ended December 31, 2016 and 2015 was not material. The VIE is named as a co-obligor under a third party debt agreement in the amount of $170 million, maturing in fiscal 2020, under which it could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business.

- added (2017-02-08):
[0000833444-17-000007:note_history:60]
The carrying amounts and classification of assets (none of which are restricted) and liabilities included in the Company’s consolidated statements of financial position for the consolidated VIEs are as follows (in millions):

- added (2017-02-08):
[0000833444-17-000007:note_history:61]
|  | December 31, 2016 |  | September 30, 2016 |
| Current assets | $ | 2 |  |  | $ | 284 |  |
| Noncurrent assets | 54 |  |  | 98 |  |
| Total assets | $ | 56 |  |  | $ | 382 |  |
| Current liabilities | $ | 3 |  |  | $ | 230 |  |
| Noncurrent liabilities | 44 |  |  | 29 |  |
| Total liabilities | $ | 47 |  |  | $ | 259 |  |

- added (2017-02-08):
[0000833444-17-000007:note_history:62]
The Company did not have a significant variable interest in any other consolidated VIEs for the presented reporting periods.

- added (2017-02-08):
[0000833444-17-000007:note_history:63]
Nonconsolidated VIEs

- added (2017-02-08):
[0000833444-17-000007:note_history:64]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is not considered to be the primary beneficiary of two of the entities as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balance of $60 million  and $59 million at December 31, 2016 and September 30, 2016 respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned previously within the "Consolidated VIEs" section above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.

- added (2017-02-08):
[0000833444-17-000007:note_history:65]
The Company did not have a significant variable interest in any other unconsolidated VIEs for the presented reporting periods.

- added (2017-02-08):
[0000833444-17-000007:note_history:66]
Restricted Cash

- added (2017-02-08):
[0000833444-17-000007:note_history:67]
At December 31, 2016, the Company held restricted cash of approximately $42 million, of which $33 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities. At September 30, 2016, the Company held restricted cash of approximately $88 million, of which $79 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash held in escrow from business divestitures and cash restricted for payment of asbestos liabilities.

- added (2017-02-08):
[0000833444-17-000007:note_history:68]
Retrospective Changes

- added (2017-02-08):
[0000833444-17-000007:note_history:69]
Certain amounts as of September 30, 2016 have been revised to conform to the current year’s presentation.

- added (2017-02-08):
[0000833444-17-000007:note_history:70]
During the first quarter of fiscal 2017, the Company determined that its Automotive Experience business (Adient) met the criteria to be classified as a discontinued operation, which required retrospective application to financial information for all periods presented. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

- added (2017-02-08):
[0000833444-17-000007:note_history:71]
In the first quarter of fiscal 2017, the Company began evaluating the performance of its business segments primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans. Historical information has been revised to present the comparable periods on a consistent basis.

- added (2017-02-08):
[0000833444-17-000007:note_history:72]
In April 2015, the FASB issued Accounting Standards Update (ASU) No. 2015-03, "Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." ASU No. 2015-03 requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability.

- added (2017-02-08):
[0000833444-17-000007:note_history:73]
During the quarter ended December 31, 2016, the Company adopted ASU No. 2015-03 and applied the change retrospectively to all periods presented. This change did not have an impact to any period presented on the consolidated statements of income. The financial statement impact of this change for the period ending September 30, 2016 was a decrease to noncurrent assets held for sale of $44 million, a decrease to noncurrent liabilities held for sale of $44 million, a decrease to other noncurrent assets of $30 million and a decrease to long-term debt of $30 million.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-02-08):
[0000833444-17-000007:note_history:74]
Debt and Financing Arrangements

- added (2017-02-08):
[0000833444-17-000007:note_history:75]
Debt exchange

- added (2017-02-08):
[0000833444-17-000007:note_history:76]
In connection with the Tyco Merger, on December 28, 2016, the Company completed its offers to exchange all validly tendered and accepted notes of certain series (the "existing notes") issued by JCI Inc. or Tyco International Finance S.A. ("TIFSA"), as applicable, each of which is a wholly owned subsidiary of the Company, for the new notes to be issued by the Company and the related solicitation of consents to amend the indentures governing the existing notes (the offers to exchange and the related consent solicitation together the "exchange offers"). Pursuant to the exchange offers, the Company exchanged approximately $5.6 billion of $6.0 billion in aggregate principal amount of dollar denominated notes and approximately 423 million euro of 500 million euro in aggregate principal amount of euro denominated notes. All were validly tendered and accepted and notes have been canceled. Following such cancellation, $380,948,000 aggregate principal amount of existing notes (not including the TIFSA Euro Notes) will remain outstanding across seventeen series of dollar-denominated existing notes and 77,394,000 euro aggregate principal amount of TIFSA Euro Notes remain outstanding across one series. In connection with the settlement of the exchange offers, the new notes ("the New Notes") issued by the Company have been registered under the Securities Act of 1933. The terms of the New Notes are described in the Company’s Prospectus dated December 19, 2016, as filed with the SEC under Rule 424(b)(3) of the Act on that date. The issuance of the New Notes occurred on December 28, 2016. The New Notes are unsecured and unsubordinated obligations of the Company and will rank equally with all other unsecured and unsubordinated indebtedness of the Company issued from time to time.

- added (2017-02-08):
[0000833444-17-000007:note_history:77]
Other financing arrangements

- changed (2017-02-08):
[0000833444-17-000007:note_history:78]
In December 2016, the Company retired, at maturity, $400 million in principal amount, plus accrued interest, of its 2.6% fixed rate notes that matured in December 2016.
  (was, 2016-07-29, similarity 0.6067):
[0000833444-16-000197:note_history:78]
On October 15, 2015, the Company repaid $258 million aggregate principal amount of 3.375% notes which matured on such date.

- added (2017-02-08):
[0000833444-17-000007:note_history:79]
In December 2016, the Company entered into a 364-day 100 million euro floating rate term loan scheduled to mature in December 2017. Proceeds from the term loan were used for general corporate purposes.

- added (2017-02-08):
[0000833444-17-000007:note_history:80]
In December 2016, a $100 million committed revolving credit facility expired. There were no draws on the facility.

- added (2017-02-08):
[0000833444-17-000007:note_history:81]
In November 2016, the Company fully repaid its 37 billion yen syndicated floating rate term loan, plus accrued interest, scheduled to mature in June 2020.

- added (2017-02-08):
[0000833444-17-000007:note_history:82]
In November 2016, a $35 million committed revolving credit facility expired. There were no draws on the facility.

- added (2017-02-08):
[0000833444-17-000007:note_history:83]
In October 2016, the Company repaid two ten-month floating rate term loans totaling $325 million, plus accrued interest, scheduled to mature in October 2016.

- added (2017-02-08):
[0000833444-17-000007:note_history:84]
In October 2016, the Company repaid a nine-month $100 million floating rate term loan, plus accrued interest, scheduled to mature in November 2016.

- added (2017-02-08):
[0000833444-17-000007:note_history:85]
In October 2016, the Company repaid a nine-month 100 million euro floating rate term loan, plus accrued interest, scheduled to mature in October 2016.

- added (2017-02-08):
[0000833444-17-000007:note_history:86]
Net Financing Charges

- added (2017-02-08):
[0000833444-17-000007:note_history:87]
The Company's net financing charges line item in the consolidated statements of income for the three month periods ended December 31, 2016 and 2015 contained the following components (in millions):

- added (2017-02-08):
[0000833444-17-000007:note_history:88]
|  | Three Months EndedDecember 31, |
|  | 2016 |  | 2015 |
| Interest expense, net of capitalized interest costs | $ | 110 |  |  | $ | 72 |  |
| Banking fees and bond cost amortization | 30 |  |  | 7 |  |
| Interest income | (7 | ) |  | (2 | ) |
| Net foreign exchange results for financing activities | 3 |  |  | (11 | ) |
| Net financing charges | $ | 136 |  |  | $ | 66 |  |

- added (2017-02-08):
[0000833444-17-000007:note_history:89]
Net financing charges for the three month period ended December 31, 2016 included $17 million of transaction costs related primarily to the debt exchange offers.

- removed (2017-02-08):
[0000833444-16-000197:note_history:90]
Debt

- removed (2017-02-08):
[0000833444-16-000197:note_history:91]
The carrying value of the Company's debt as of June 24, 2016 and September 25, 2015 is as follows ($ in millions):

- removed (2017-02-08):
[0000833444-16-000197:note_history:92]
|  | As of |
|  | June 24, 2016 |  | September 25, 2015 |
| Commercial paper(1) | $ | 341 |  |  | $ | — |  |
| 3.375% public notes due 2015(2) | — |  |  | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 7.0% public notes due 2019(2) | — |  |  | 245 |  |
| 6.875% public notes due 2021(2) | — |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 564 |  |  | 558 |  |
| 3.9% public notes due 2026 | 745 |  |  | 745 |  |
| 5.125% public notes due 2045 | 746 |  |  | 746 |  |
| Other (2) | 1 |  |  | 20 |  |
| Total debt | 2,506 |  |  | 3,146 |  |
| Less current portion | 341 |  |  | 987 |  |
| Long-term debt | $ | 2,165 |  |  | $ | 2,159 |  |

- removed (2017-02-08):
[0000833444-16-000197:note_history:93]
_______________________________________________________________________________

- removed (2017-02-08):
[0000833444-16-000197:note_history:94]
(1) The current portion of debt as of June 24, 2016 is comprised of $341 million of commercial paper.

- removed (2017-02-08):
[0000833444-16-000197:note_history:95]
(2) The current portion of debt as of September 25, 2015 is comprised of $258 million notes due 2015, $245 million notes due 2019, $465 million notes due 2021 and $19 million of Other debt.

- removed (2017-02-08):
[0000833444-16-000197:note_history:96]
Fair Value

- removed (2017-02-08):
[0000833444-16-000197:note_history:97]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of June 24, 2016 and September 25, 2015 was $2,505 million and $3,126 million, respectively. The Company has determined the fair value of such debt to be $2,660 million and $3,291 million as of June 24, 2016 and September 25, 2015, respectively. The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets. As of June 24, 2016 and September 25, 2015, the fair value of the Company's debt which was actively traded was $2,319 million and $3,291 million, respectively. As of June 24, 2016 and September 25, 2015, the Company's debt that was subject to the fair value disclosure requirements and was actively traded is classified as Level 1 in the fair value hierarchy. Additionally, the Company believes the carrying amount of its commercial paper of $341 million as of June 24, 2016 approximates fair value based on the short-term nature of such debt.

- removed (2017-02-08):
[0000833444-16-000197:note_history:98]
Fiscal 2016 Debt Repayment

- removed (2017-02-08):
[0000833444-16-000197:note_history:99]
On September 14, 2015, the Company and the Company's wholly-owned subsidiary, Tyco International Finance S.A. ("TIFSA") announced the redemption of all of the outstanding $242 million aggregate principal amount of 7.0% notes due 2019 and $462 million aggregate principal amount of 6.875% notes due 2021. On October 14, 2015, TIFSA paid cash of $876 million to complete the redemption, resulting in a loss on extinguishment of $168 million which was recorded in Other expense, net within the Consolidated Statements of Operations during the first quarter of fiscal 2016. The charge is comprised of the make-whole premium of $172 million and the write-off of unamortized debt issuance costs of $1 million, partially offset by the write-off of the unamortized premium of $5 million.

- removed (2017-02-08):
[0000833444-16-000197:note_history:100]
Financing in Connection with Proposed Merger with Johnson Controls

- removed (2017-02-08):
[0000833444-16-000197:note_history:101]
On March 10, 2016, Tyco International Holding S.à r.l. ("TSARL"), an indirect wholly owned subsidiary of Tyco, entered into a Term Loan Credit Agreement with a syndicate of lenders providing for a senior unsecured term loan facility in the amount of $4 billion to finance the cash consideration for, and fees, expenses and costs incurred in connection with the Merger. Any borrowing under the Term Loan Credit Agreement is conditioned upon the closing of the Merger and will be made in a single borrowing on the closing date of the Merger and will have a maturity of 3.5 years and be denominated in U.S. dollars. See Note 1.

- removed (2017-02-08):
[0000833444-16-000197:note_history:102]
In addition, on March 10, 2016, TSARL entered into a Multi-Year Senior Unsecured Credit Agreement providing for revolving credit commitments in the aggregate amount of $1 billion (the “Revolving Credit Agreement”). TSARL's ability to borrow under the Revolving Credit Agreement is subject to the satisfaction or waiver of customary conditions, including the consummation of the Merger, as well as the termination of the commitments of the lenders, and payments of any amounts outstanding, under TIFSA's existing $1.5 billion Amended and Restated Five-Year Senior Unsecured Credit Agreement dated as of August 7, 2015 (the "2015 Credit Agreement"). The Revolving Credit Agreement has a scheduled maturity date of August 7, 2020 and includes an option for TSARL to request an increase in the aggregate principal amount of the commitments, up to an additional $250 million.

- removed (2017-02-08):
[0000833444-16-000197:note_history:103]
Credit Facilities

- removed (2017-02-08):
[0000833444-16-000197:note_history:104]
On August 7, 2015, TIFSA entered into the 2015 Credit Agreement, which amended and restated TIFSA's existing $1 billion Five-Year Senior Unsecured Credit Agreement, dated June 22, 2012 (the “2012 Credit Agreement”). The 2015 Credit Agreement will be terminated upon completion of the Merger and replaced with the Revolving Credit Agreement discussed above.

- removed (2017-02-08):
[0000833444-16-000197:note_history:105]
As of June 24, 2016, the Company's total committed revolving credit facilities totaled $1.5 billion. The Company's revolving credit facilities may be used for working capital, capital expenditures and general corporate purposes. As of June 24, 2016 and September 25, 2015, there were no amounts drawn under the Company's revolving credit facilities. Interest under the revolving credit facilities is variable and is calculated by reference to LIBOR or an alternate base rate.

- removed (2017-02-08):
[0000833444-16-000197:note_history:106]
TIFSA's revolving credit facilities contain customary terms and conditions, and financial covenants that limit the ratio of the Company's debt to earnings before interest, taxes, depreciation, and amortization and that limit our ability to incur subsidiary debt or grant liens on its property. The indentures governing the Company's public notes contain customary covenants including limits on negative pledges, subsidiary debt and sale/leaseback transactions. None of these covenants are considered restrictive to the Company's business.

- removed (2017-02-08):
[0000833444-16-000197:note_history:107]
Commercial Paper

- removed (2017-02-08):
[0000833444-16-000197:note_history:108]
From time to time, TIFSA may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1.5 billion as of June 24, 2016. As of June 24, 2016 and September 25, 2015, TIFSA had $341 million and nil of commercial paper outstanding, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2017-02-08):
[0000833444-16-000197:note_history:109]
The carrying value of the Company's debt as of June 24, 2016 and September 25, 2015 is as follows ($ in millions):

- removed (2017-02-08):
[0000833444-16-000197:note_history:110]
|  | As of |
|  | June 24, 2016 |  | September 25, 2015 |
| Commercial paper(1) | $ | 341 |  |  | $ | — |  |
| 3.375% public notes due 2015(2) | — |  |  | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 7.0% public notes due 2019(2) | — |  |  | 245 |  |
| 6.875% public notes due 2021(2) | — |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 564 |  |  | 558 |  |
| 3.9% public notes due 2026 | 745 |  |  | 745 |  |
| 5.125% public notes due 2045 | 746 |  |  | 746 |  |
| Other (2) | 1 |  |  | 20 |  |
| Total debt | 2,506 |  |  | 3,146 |  |
| Less current portion | 341 |  |  | 987 |  |
| Long-term debt | $ | 2,165 |  |  | $ | 2,159 |  |

- removed (2017-02-08):
[0000833444-16-000197:note_history:111]
_______________________________________________________________________________

- removed (2017-02-08):
[0000833444-16-000197:note_history:112]
(1) The current portion of debt as of June 24, 2016 is comprised of $341 million of commercial paper.

- removed (2017-02-08):
[0000833444-16-000197:note_history:113]
(2) The current portion of debt as of September 25, 2015 is comprised of $258 million notes due 2015, $245 million notes due 2019, $465 million notes due 2021 and $19 million of Other debt.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_prior_note, score: 0.0

- added (2017-02-08):
[0000833444-17-000007:note_history:114]
Related Party Transactions

- added (2017-02-08):
[0000833444-17-000007:note_history:115]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

- added (2017-02-08):
[0000833444-17-000007:note_history:116]
The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $225 million and $49 million, respectively, for the three months ended December 31, 2016; and $234 million and $38 million, respectively, for the three months ended December 31, 2015.

- added (2017-02-08):
[0000833444-17-000007:note_history:117]
The following table sets forth the amount of accounts receivable due from and payable to related parties for continuing operations in the consolidated statements of financial position (in millions):

- added (2017-02-08):
[0000833444-17-000007:note_history:118]
|  |  | December 31, 2016 |  | September 30, 2016 |  |
| Receivable from related parties |  | $ | 50 |  |  | $ | 66 |  |
| Payable to related parties |  | 29 |  |  | 11 |  |

- added (2017-02-08):
[0000833444-17-000007:note_history:119]
The Company has also provided financial support to certain of its VIE's, see Note 1, "Financial Statements," of the notes to consolidated financial statements for additional information.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: no_prior_note, score: 0.0

- added (2017-02-08):
[0000833444-17-000007:note_history:120]
The following table sets forth the amount of accounts receivable due from and payable to related parties for continuing operations in the consolidated statements of financial position (in millions):

- added (2017-02-08):
[0000833444-17-000007:note_history:121]
|  |  | December 31, 2016 |  | September 30, 2016 |  |
| Receivable from related parties |  | $ | 50 |  |  | $ | 66 |  |
| Payable to related parties |  | 29 |  |  | 11 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2017-02-08):
[0000833444-17-000007:note_history:122]
Subsequent Event
  (was, 2016-07-29, similarity 0.9697):
[0000833444-16-000197:note_history:122]
Subsequent Events

- added (2017-02-08):
[0000833444-17-000007:note_history:123]
On February 2, 2017, the Company issued $500 million aggregate principal amount of 4.5% senior unsecured fixed rate notes due in February 2047. Proceeds were used for general corporate purposes.

- removed (2017-02-08):
[0000833444-16-000197:note_history:124]
On July 21, 2016, the Company announced that it expects to close its merger with Johnson Controls, Inc. on September 2, 2016. In addition, the Company declared an accelerated dividend of $0.23 per ordinary share, payable on August 26, 2016, to shareholders of record on August 5, 2016.

- removed (2017-02-08):
[0000833444-16-000197:note_history:125]
The accelerated dividend is in addition to the regular third quarter dividend scheduled to be paid on August 17, 2016 to shareholders of record on July 22, 2016. This accelerated dividend pulls forward the quarterly dividend that Tyco would have declared in its fiscal fourth quarter, and is intended to align dividend payments made to shareholders of Tyco and Johnson Controls prior to the closing of the merger. Closing of the merger is contingent upon, among other things, the approval of proposals related to the merger by shareholders of each company. The special meetings for shareholders of Tyco and Johnson Controls are scheduled for August 17, 2016.
