# JCI MD&A — 0000833444-22-000043


## mdna

[0000833444-22-000043:mdna:1]
ITEM 7    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000833444-22-000043:mdna:2]
General

[0000833444-22-000043:mdna:3]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers in more than 150 countries. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-22-000043:mdna:4]
The Company is a global leader in engineering, manufacturing and commissioning building products and systems, including residential and commercial HVAC equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions. The Company partners with customers by leveraging its broad product portfolio and digital capabilities, including its OpenBlue platform,

[0000833444-22-000043:mdna:5]
together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

[0000833444-22-000043:mdna:6]
The Company's fiscal year ends on September 30. Unless otherwise stated, references to years in this report relate to fiscal years rather than calendar years. This discussion summarizes the significant factors affecting the consolidated operating results, financial condition and liquidity of the Company for the year ended September 30, 2022. This discussion should be read in conjunction with Item 8, the consolidated financial statements and the notes to consolidated financial statements. A detailed discussion of the 2021 to 2020 year-over-year changes are not included herein and can be found in the Management's Discussion and Analysis section in the Company's 2021 Annual Report on Form 10-K filed November 15, 2021 under the heading "Fiscal year 2021 compared to fiscal year 2020" which is incorporated herein by reference.

[0000833444-22-000043:mdna:7]
Macroeconomic Trends

[0000833444-22-000043:mdna:8]
Much of the demand for installation of the Company’s products and solutions is driven by commercial and residential construction and industrial facility expansion and maintenance projects. Commercial and residential construction projects are heavily dependent on general economic conditions, localized demand for commercial and residential real estate and availability of credit. Positive or negative fluctuations in commercial and residential construction, industrial facility expansion and maintenance projects and other capital investments in buildings could have a corresponding impact on the Company’s financial condition, results of operations and cash flows.

[0000833444-22-000043:mdna:9]
As a result of the Company’s global presence, a significant portion of its revenues and expenses is denominated in currencies other than the U.S. dollar. The Company is therefore subject to non-U.S. currency risks and non-U.S. exchange exposure. While the Company employs financial instruments to hedge some of its transactional foreign exchange exposure, these activities do not insulate it completely from those exposures. In addition, the currency exposure from the translation of non-U.S. dollar functional currency subsidiaries are not able to be hedged. Exchange rates can be volatile and a substantial weakening or strengthening of foreign currencies against the U.S. dollar could increase or reduce the Company’s profit margin, respectively, and impact the comparability of results from period to period. During fiscal 2022, revenue and profits were adversely impacted due to the significant strengthening of the U.S. dollar against foreign currencies. The continued strength of the U.S. dollar could continue to adversely impact the Company's results.

[0000833444-22-000043:mdna:10]
The Company continues to observe trends demonstrating increased interest and demand for its products and services that enable smart, safe, efficient and sustainable buildings. This demand is driven in part by government tax incentives, building performance standards and other regulations designed to limit emissions and combat climate change. In particular, legislative and regulatory initiatives such as the U.S. Climate Smart Buildings Imitative, U.S. Inflection Reduction Act and EU Energy Performance of Buildings Directive include provisions designed to fund and encourage investment in decarbonization and digital technologies for buildings. This demand is supplemented by an increase in commitments in both the public and private sectors to reduce emissions and/or achieve net zero emissions.  The Company seeks to capitalize on these trends to drive growth by developing and delivering technologies and solutions to create smart, sustainable and healthy buildings. The Company is investing in new digital and product capabilities, including its OpenBlue platform, to enable it to deliver sustainable, high-efficiency products and tailored services to enable customers to achieve their sustainability goals. The Company is leveraging its install base, together with data-driven products and services to offer outcome-based solutions to customers with a focus on generating accelerated growth in services and recurring revenue.

[0000833444-22-000043:mdna:11]
The Company has experienced, and expects to continue to experience, increased input material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends, including increased global demand, the conflict between Russia and Ukraine, government-mandated actions in response to COVID-19, particularly in China, and labor shortages. Actions taken by the Company to mitigate supply chain disruptions and inflation, including expanding and redistributing its supplier network, supplier financing, price increases and productivity improvements, have generally been successful in offsetting some, but not all, of the impact of these trends. The collective impact of these trends has been to positively impact revenue due to increased demand and price increases to offset inflation, while negatively impacting margins due to supply chain disruptions and cost pressures. The Company has also experienced delays in converting its backlog due to continued supply chain disruptions, negatively impacting both revenues and margins. Although the Company has experienced recent improvement in its supply chain, the Company expects that these trends will continue to impact its results into fiscal 2023. Therefore, the Company could experience further disruptions, shortages and cost increases in the future, the effect of which will depend on the Company’s ability to successfully mitigate and offset the impact of these events.

[0000833444-22-000043:mdna:12]
During the second quarter of fiscal 2022, the Company suspended its operations in Russia in response to the conflict between Russia and Ukraine. Although this decision has not had and is not expected to have a material impact on the Company’s

[0000833444-22-000043:mdna:13]
operating results, the broader consequences of this conflict, including heightened supply chain disruption, inflation, economic instability and other factors have and could continue to adversely impact the Company’s results of operations.

[0000833444-22-000043:mdna:14]
Impact of COVID-19 Pandemic

[0000833444-22-000043:mdna:15]
The COVID-19 pandemic continues to impact aspects of the Company's operations and results. During fiscal 2022, the Company's facilities generally operated at normal levels, however, the Company has experienced some disruptions to its business in China due to government-mandated lockdowns in several major cities.

[0000833444-22-000043:mdna:16]
The Company has experienced increases in demand as governments have distributed vaccines and lifted COVID-19-related restrictions, leading to increases in retrofit activity and commercial building construction. As a result of the pandemic, the Company has seen an increase in demand for its products and solutions that promote building health and optimize customers’ infrastructure.

[0000833444-22-000043:mdna:17]
However, the Company continues to be influenced by COVID-19-related trends impacting site access and the labor force, which have and may continue to negatively impact the Company’s revenues and margins. Challenges in reaching sufficient vaccination levels and the introduction of new variants of COVID-19 have caused some governments to extend or reinstitute lockdowns and similar restrictive measures, which, in some cases, have limited the Company’s ability to access customer sites to install and maintain its products and deliver services. In addition, the Company has experienced and continues to experience labor shortages at certain facilities as the Company expands its production capacity to meet increased customer demand. Although the Company is mitigating these shortages through focused recruitment efforts and competitive compensation packages, the Company could continue to experience such shortages in the future.

[0000833444-22-000043:mdna:18]
The extent to which the COVID-19 pandemic continues to impact the Company’s results of operations and financial condition will depend on future developments that are highly uncertain and cannot be predicted. See Part I, Item 1A, of this Annual Report on Form 10-K for an additional discussion of risks related to COVID-19.

[0000833444-22-000043:mdna:19]
Restructuring and Cost Optimization Initiatives

[0000833444-22-000043:mdna:20]
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to restructuring plans as necessary. In fiscal 2021, the Company announced its plans to optimize its cost structure through broad-based SG&A actions focused on simplification, standardization and centralization, with the intent to deliver annualized savings of $300 million by fiscal 2023 (the “2021 Plan”). Additionally, the Company announced cost of sales actions to drive $250 million in annual run rate savings by fiscal 2023. The Company believes it is on track to deliver and exceed the productivity savings by fiscal 2023. For more information on the Company’s restructuring plans, see “Liquidity and Capital Resources—Restructuring.”

[0000833444-22-000043:mdna:21]
FISCAL YEAR 2022 COMPARED TO FISCAL YEAR 2021

[0000833444-22-000043:mdna:22]
Net Sales

[0000833444-22-000043:mdna:23]
|  | Year Ended September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Net sales | $ | 25,299 |  |  | $ | 23,668 |  |  | 7 | % |

[0000833444-22-000043:mdna:24]
The increase in net sales was due to higher organic sales ($2,033 million), incremental sales from acquisitions ($356 million) and the impact of prior year nonrecurring purchase accounting adjustments ($6 million), partially offset by the unfavorable impact of foreign currency translation ($741 million) and lower sales due to business divestitures ($23 million). Excluding the impact of foreign currency translation, business acquisitions and divestitures and nonrecurring adjustments, consolidated net sales increased 9% as compared to the prior year, attributable to higher volumes and increased pricing in response to inflation pressures. Refer to the "Segment Analysis" below within Item 7 for a discussion of net sales by segment.

[0000833444-22-000043:mdna:25]
Cost of Sales / Gross Profit

[0000833444-22-000043:mdna:26]
|  | Year Ended September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Cost of sales | $ | 16,956 |  |  | $ | 15,609 |  |  | 9 | % |
| Gross profit | 8,343 |  |  | 8,059 |  |  | 4 | % |
| % of sales | 33.0 | % |  | 34.1 | % |  |  |

[0000833444-22-000043:mdna:27]
Cost of sales and gross profit both increased and gross profit as a percentage of sales decreased by 110 basis points. Gross profit increased due to organic sales growth and business acquisitions, partially offset by the unfavorable impact of foreign currency translation ($229 million), supply chain inefficiencies, price/cost pressures and the unfavorable year-over-year impact of net pension mark-to-market adjustments ($121 million). Gross profit as a percentage of sales decreased as the benefit of volume leverage was more than offset by supply chain inefficiencies and price/cost pressures. Refer to the "Segment Analysis" below within Item 7 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-22-000043:mdna:28]
Selling, General and Administrative Expenses

[0000833444-22-000043:mdna:29]
|  | Year Ended September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Selling, general and administrative expenses | $ | 5,945 |  |  | $ | 5,258 |  |  | 13 | % |
| % of sales | 23.5 | % |  | 22.2 | % |  |  |

[0000833444-22-000043:mdna:30]
Selling, general and administrative expenses ("SG&A") increased by $687 million, and SG&A as a percentage of sales increased by 130 basis points. The increase in SG&A on a percentage basis was primarily due to the current year environmental remediation charge and related reserves ($255 million), the unfavorable year-over-year impact of net mark-to-market adjustments on pension plans ($154 million), the unfavorable year-over-year impact of net mark-to-market adjustments on restricted asbestos investments ($93 million), the absence of certain one-time cost mitigation actions and current year business acquisitions, partially offset by a favorable earn-out liability adjustment ($43 million) and favorable foreign currency translation ($141 million). Refer to the "Segment Analysis" below within Item 7 for a discussion of segment EBITA.

[0000833444-22-000043:mdna:31]
Restructuring and Impairment Costs

[0000833444-22-000043:mdna:32]
|  | Year Ended September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Restructuring and impairment costs | $ | 721 |  |  | $ | 242 |  |  | * |

[0000833444-22-000043:mdna:33]
* Measure not meaningful

[0000833444-22-000043:mdna:34]
Restructuring and impairment costs in fiscal 2022 included $419 million impairment costs related to businesses classified as held-for-sale, $75 million impairment of goodwill attributable to the Silent-Aire reporting unit, $45 million impairment of long-lived assets in the Building Solutions Asia Pacific segment reclassified from held for sale and $182 million in severance, long-lived asset impairments and other costs associated with the 2021 Plan. All of the fiscal 2021 restructuring and impairment costs were related to the 2021 Plan.

[0000833444-22-000043:mdna:35]
Refer to "Note 3, "Assets and Liabilities Held for Sale & Discontinued Operations," Note 8, "Goodwill and Other Intangible Assets," and Note 17, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-22-000043:mdna:36]
Net Financing Charges

[0000833444-22-000043:mdna:37]
|  | Year Ended September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Net financing charges | $ | 213 |  |  | $ | 206 |  |  | 3 | % |

[0000833444-22-000043:mdna:38]
Refer to Note 10, "Debt and Financing Arrangements," of the notes to consolidated financial statements for further disclosure related to the Company's net financing charges.

[0000833444-22-000043:mdna:39]
Equity Income

[0000833444-22-000043:mdna:40]
|  | Year Ended September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Equity income | $ | 246 |  |  | $ | 261 |  |  | -6 | % |

[0000833444-22-000043:mdna:41]
The decrease in equity income was primarily due to lower income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture and at certain partially-owned affiliates within the Building Solutions North America segment. Refer to the "Segment Analysis" below within Item 7 for a discussion of segment EBITA.

[0000833444-22-000043:mdna:42]
Income Tax Provision

[0000833444-22-000043:mdna:43]
|  | Year Ended September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Income tax provision (benefit) | $ | (13) |  |  | $ | 868 |  |  | * |
| Effective tax rate | (1) | % |  | 33 | % |  |  |

[0000833444-22-000043:mdna:44]
* Measure not meaningful

[0000833444-22-000043:mdna:45]
The statutory tax rate in Ireland of 12.5% is being used as a comparison since the Company is domiciled in Ireland.

[0000833444-22-000043:mdna:46]
For fiscal 2022, the effective tax rate for continuing operations was (1)% and was lower than the statutory tax rate primarily due to tax reserve adjustments as the result of expired statute of limitations for certain tax years and the benefits of continuing global tax planning initiatives, partially offset by the income tax effects of impairment and restructuring charges, valuation allowance adjustments, the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestitures and tax rate differentials.

[0000833444-22-000043:mdna:47]
For fiscal 2021, the effective tax rate for continuing operations was 33% and was higher than the statutory tax rate primarily due to the tax impacts of an intercompany transfer of certain of the Company’s intellectual property rights, valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives.

[0000833444-22-000043:mdna:48]
The fiscal 2022 effective tax rate decreased as compared to fiscal 2021 primarily due to the income tax effects of mark-to-market adjustments, tax reserve adjustments as the result of expired statute of limitations for certain tax years and the benefits of continuing global tax planning initiatives, partially offset by valuation allowance adjustments, the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestitures, impairment and restructuring charges and tax rate differentials. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for further details.

[0000833444-22-000043:mdna:49]
The U.S. enacted the Inflation Reduction Act of 2022 (“IRA”) in August 2022, which, among other sections, creates a new book minimum tax of at least 15% of consolidated GAAP pre-tax income for corporations with average book income in excess of $1 billion. The book minimum tax will first apply to us in fiscal 2024. We do not expect the IRA to have a material impact on our effective tax rate. In addition, in October 2021, 136 out of 140 countries in the Organization for Economic Co-operation and Development ("OECD") Inclusive Framework on Base Erosion and Profit Shifting ("IF"), including Ireland, politically committed to potentially fundamental changes to the international corporate tax system, including the potential implementation of a global minimum corporate tax rate. While the details of these pronouncements presently remain unclear and timing of implementation uncertain, the impact of local country IF adoption could have a material impact on the Company's effective tax

[0000833444-22-000043:mdna:50]
rate in future periods. It is also possible that jurisdictions in which the Company does business could react to such IF developments unilaterally by enacting tax legislation that could adversely affect the Company or its affiliates.

[0000833444-22-000043:mdna:51]
Income From Discontinued Operations, Net of Tax

[0000833444-22-000043:mdna:52]
|  | Year Ended September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Income from discontinued operations, net of tax | $ | — |  |  | $ | 124 |  |  | * |

[0000833444-22-000043:mdna:53]
* Measure not meaningful

[0000833444-22-000043:mdna:54]
Refer to Note 3, "Assets and Liabilities Held for Sale & Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-22-000043:mdna:55]
Income Attributable to Noncontrolling Interests

[0000833444-22-000043:mdna:56]
|  | Year Ended September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 191 |  |  | $ | 233 |  |  | -18 | % |

[0000833444-22-000043:mdna:57]
The decrease in income from continuing operations attributable to noncontrolling interests was primarily due to lower net income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture.

[0000833444-22-000043:mdna:58]
Net Income Attributable to Johnson Controls

[0000833444-22-000043:mdna:59]
|  | Year Ended September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Net income attributable to Johnson Controls | $ | 1,532 |  |  | $ | 1,637 |  |  | -6 | % |

[0000833444-22-000043:mdna:60]
The decrease in net income attributable to Johnson Controls was primarily due to higher SG&A, higher restructuring and impairment costs and the non-recurrence of prior year income from discontinued operations, partially offset by lower income tax provision and higher gross profit. Diluted earnings per share attributable to Johnson Controls was $2.19 for the year ended September 30, 2022 compared to $2.27 for the year ended September 30, 2021.

[0000833444-22-000043:mdna:61]
Comprehensive Income Attributable to Johnson Controls

[0000833444-22-000043:mdna:62]
|  | Year Ended September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 1,055 |  |  | $ | 1,979 |  |  | -47 | % |

[0000833444-22-000043:mdna:63]
The decrease in comprehensive income attributable to Johnson Controls was due to a decrease in other comprehensive income attributable to Johnson Controls ($819 million) resulting primarily from foreign currency translation adjustments and lower net income attributable to Johnson Controls ($105 million). The year-over-year unfavorable foreign currency translation adjustments were primarily driven by the weakening of the British pound, euro and Canadian dollar in the current year compared to strengthening of the British pound, Canadian dollar and Mexican peso against the U.S. dollar in the prior year.

[0000833444-22-000043:mdna:64]
SEGMENT ANALYSIS

[0000833444-22-000043:mdna:65]
Management evaluates the performance of its business units based primarily on segment EBITA, which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-22-000043:mdna:66]
Effective October 1, 2021, the Company's marine businesses previously included in the Building Solutions Asia Pacific and Global Products reportable segments are now part of the Building Solutions EMEA/LA reportable segment. Historical

[0000833444-22-000043:mdna:67]
33

[0000833444-22-000043:mdna:68]
information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation. Refer to Note 19, “Segment Information,” of the notes to the consolidated financial statements for further information.

[0000833444-22-000043:mdna:69]
Beginning on October 1, 2021, the Company began reporting certain retrofit projects in the Building Solutions EMEA/LA and Building Solutions Asia Pacific segments as products and systems revenue on a prospective basis as they have evolved to be more aligned with other install offerings.

[0000833444-22-000043:mdna:70]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |  | Segment EBITAfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Building Solutions North America | $ | 9,367 |  |  | $ | 8,685 |  |  | 8 | % |  | $ | 1,122 |  |  | $ | 1,204 |  |  | -7 | % |
| Building Solutions EMEA/LA | 3,845 |  |  | 3,884 |  |  | -1 | % |  | 358 |  |  | 401 |  |  | -11 | % |
| Building Solutions Asia Pacific | 2,714 |  |  | 2,616 |  |  | 4 | % |  | 332 |  |  | 344 |  |  | -3 | % |
| Global Products | 9,373 |  |  | 8,483 |  |  | 10 | % |  | 1,594 |  |  | 1,436 |  |  | 11 | % |
|  | $ | 25,299 |  |  | $ | 23,668 |  |  | 7 | % |  | $ | 3,406 |  |  | $ | 3,385 |  |  | 1 | % |

[0000833444-22-000043:mdna:71]
Net Sales:

[0000833444-22-000043:mdna:72]
•The increase in Building Solutions North America was due to higher volumes and prices ($672 million) and incremental sales related to business acquisitions ($22 million), partially offset by the unfavorable impact of foreign currency translation ($12 million). The sales increase was led by strong growth in the HVAC & Controls platform.

[0000833444-22-000043:mdna:73]
•The decrease in Building Solutions EMEA/LA was due to the unfavorable impact of foreign currency translation ($269 million) and business divestitures ($22 million), partially offset by higher volumes and prices ($214 million) and incremental sales related to business acquisitions ($38 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales increased, driven by growth in the Fire & Security platforms and the HVAC & Controls platform. By region, strong growth in Europe and single digit growth in Latin America was partially offset by growth decline in the Middle East.

[0000833444-22-000043:mdna:74]
•The increase in Building Solutions Asia Pacific was due to the net impact of higher prices and lower volumes ($178 million) and incremental sales related to business acquisitions ($42 million), partially offset by the unfavorable impact of foreign currency translation ($121 million) and business divestitures ($1 million). The increase in sales was led by strong demand for HVAC & Controls and Industrial Refrigeration equipment. By region, the sales growth was driven by sales in China.

[0000833444-22-000043:mdna:75]
•The increase in Global Products was due to higher volumes and prices ($975 million) and incremental sales related to business acquisitions ($254 million), partially offset by the unfavorable impact of foreign currency translation ($339 million). Sales growth was driven by broad-based demand for Commercial and Residential HVAC and Fire & Security products and strong price realization.

[0000833444-22-000043:mdna:76]
Segment EBITA:

[0000833444-22-000043:mdna:77]
•The decrease in Building Solutions North America was primarily due to lower absorption related to supply chain disruptions and labor constraints and the unfavorable impact of foreign currency translations, partially offset by productivity savings.

[0000833444-22-000043:mdna:78]
•The decrease in Building Solutions EMEA/LA was primarily due to supply chain disruptions, the suspension of operations in Russia ($11 million),  and the unfavorable impact of foreign currency translation ($29 million), partially offset by favorable price/cost and productivity savings.

[0000833444-22-000043:mdna:79]
•The decrease in Building Solutions Asia Pacific was primarily due to supply chain disruptions, unfavorable mix and the unfavorable impact of foreign currency translation ($23 million), partially offset by favorable price/cost and productivity savings.

[0000833444-22-000043:mdna:80]
•The increase in Global Products was primarily due to favorable volumes and mix, productivity savings and a favorable earn-out liability adjustment ($43 million), partially offset by the current year environmental remediation charge ($222 million), the unfavorable impact of foreign currency translation ($37 million) and lower equity income driven primarily by certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture ($13 million).

[0000833444-22-000043:mdna:81]
LIQUIDITY AND CAPITAL RESOURCES

[0000833444-22-000043:mdna:82]
Working Capital

[0000833444-22-000043:mdna:83]
|  | September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Current assets | $ | 11,685 |  |  | $ | 9,998 |  |  |  |
| Current liabilities | (11,239) |  |  | (9,098) |  |  |  |
|  | 446 |  |  | 900 |  |  | -50 | % |
| Less: Cash and cash equivalents | (2,031) |  |  | (1,336) |  |  |  |
| Add: Short-term debt | 669 |  |  | 8 |  |  |  |
| Add: Current portion of long-term debt | 865 |  |  | 226 |  |  |  |
| Less: Current assets held for sale | (387) |  |  | — |  |  |  |
| Add: Current liabilities held for sale | 236 |  |  | — |  |  |  |
| Working capital (as defined) | $ | (202) |  |  | $ | (202) |  |  | — | % |
| Accounts receivable - net | $ | 5,528 |  |  | $ | 5,613 |  |  | -2 | % |
| Inventories | 2,510 |  |  | 2,057 |  |  | 22 | % |
| Accounts payable | 4,241 |  |  | 3,746 |  |  | 13 | % |

[0000833444-22-000043:mdna:84]
•The Company defines working capital as current assets less current liabilities, excluding cash and cash equivalents, short-term debt, the current portion of long-term debt, and current assets and liabilities held for sale. Management believes that this measure of working capital, which excludes financing-related items and businesses to be divested, provides a more useful measurement of the Company’s operating performance.

[0000833444-22-000043:mdna:85]
•Working capital at September 30, 2022 remained consistent as compared to September 30, 2021 as an increase in inventory due to supply chain disruptions was offset by an increase in accounts payable.

[0000833444-22-000043:mdna:86]
•The Company’s days sales in accounts receivable at September 30, 2022 were 51, a decrease from 58 at September 30, 2021, primarily due to collection efforts and increased use of receivables factoring programs. There has been no significant adverse change in the level of overdue receivables or significant changes in revenue recognition methods.

[0000833444-22-000043:mdna:87]
•The Company’s inventory turns for the year ended September 30, 2022 were lower than the comparable period ended September 30, 2021 primarily due to supply chain disruptions.

[0000833444-22-000043:mdna:88]
•Days in accounts payable at September 30, 2022 were 85 days, higher from 76 days for the comparable period ended September 30, 2021, primarily due to timing of payments.

[0000833444-22-000043:mdna:89]
Cash Flows From Continuing Operations

[0000833444-22-000043:mdna:90]
|  | Year Ended September 30, |
| (in millions) | 2022 |  | 2021 |
| Cash provided by operating activities | $ | 1,990 |  |  | $ | 2,551 |  |
| Cash used by investing activities | (693) |  |  | (1,090) |  |
| Cash used by financing activities | (516) |  |  | (2,131) |  |

[0000833444-22-000043:mdna:91]
•The decrease in cash provided by operating activities was primarily due to the unfavorable impacts driven by supply chain disruptions. This resulted in increases in inventory and higher unbilled receivables due to shipment delays, which

[0000833444-22-000043:mdna:92]
were partially offset by the benefit of receivables factoring activity and an increase in accounts payable due to timing of payments.

[0000833444-22-000043:mdna:93]
•The decrease in cash used by investing activities was primarily due to lower cash payments made for acquisitions.

[0000833444-22-000043:mdna:94]
•The increase in cash provided by financing activities was primarily due to higher short-term and long-term debt borrowings.

[0000833444-22-000043:mdna:95]
Capitalization

[0000833444-22-000043:mdna:96]
|  | September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Short-term debt | $ | 669 |  |  | $ | 8 |  |  |  |
| Current portion of long-term debt | 865 |  |  | 226 |  |  |  |
| Long-term debt | 7,426 |  |  | 7,506 |  |  |  |
| Total debt | 8,960 |  |  | 7,740 |  |  | 16 | % |
| Less: Cash and cash equivalents | 2,031 |  |  | 1,336 |  |  |  |
| Total net debt | 6,929 |  |  | 6,404 |  |  | 8 | % |
| Shareholders’ equity attributable to Johnson Controls | 16,268 |  |  | 17,562 |  |  | -7 | % |
| Total capitalization | $ | 23,197 |  |  | $ | 23,966 |  |  | -3 | % |
| Total net debt as a % of total capitalization | 29.9 | % |  | 26.7 | % |  |  |

[0000833444-22-000043:mdna:97]
•Net debt and net debt as a percentage of total capitalization are non-GAAP financial measures. The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company’s financial condition as it provides a view of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders.

[0000833444-22-000043:mdna:98]
•The Company's material cash requirements primarily consist of working capital requirements, repayments of long-term debt and related interest, operating leases, dividends, capital expenditures, potential acquisitions and share repurchases.

[0000833444-22-000043:mdna:99]
•Refer to Note 10, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information on debt obligations and maturities. Interest payable on long-term debt is $253 million in the twelve months following September 30, 2022 and $3.5 billion thereafter.

[0000833444-22-000043:mdna:100]
•Refer to Note 9, "Leases," of the notes to consolidated financial statements for additional information on lease obligations and maturities.

[0000833444-22-000043:mdna:101]
•As of September 30, 2022, purchase obligations are $1.5 billion payable in the next twelve months and $284 million payable thereafter. These purchase obligations represent commitments under enforceable and legally binding agreements, and do not represent the entire anticipated purchases in the future.

[0000833444-22-000043:mdna:102]
•As of September 30, 2022, the Company expects to contribute $41 million and $193 million to the global pension and postretirement plans in the next twelve months and thereafter, respectively.

[0000833444-22-000043:mdna:103]
•As of September 30, 2022, approximately $3.6 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity and economic environment.

[0000833444-22-000043:mdna:104]
•The Company declared dividends of $1.39 per share in fiscal 2022 and intends to continue paying quarterly dividends in fiscal 2023.

[0000833444-22-000043:mdna:105]
•The Company believes its capital resources and liquidity position at September 30, 2022 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in fiscal 2023 will continue to be funded

[0000833444-22-000043:mdna:106]
from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company is unable to issue commercial paper, it would have the ability to draw on its $2.5 billion revolving credit facility which expires in December 2024 or its $0.5 billion 364-day revolving credit facility which expires in December 2022. There were no draws on the revolving credit facilities as of September 30, 2022 and 2021. The Company estimates that as of September 30, 2022, it could borrow up to $2.0 billion based on average borrowing levels during fiscal 2022 on committed credit lines. The Company maintains a shelf registration statement with the SEC under which it may issue additional debt securities, ordinary shares, preferred shares, depository shares, warrants purchase contracts and units that may be offered in one or more offerings on terms to be determined at the time of the offering. The Company anticipates that the proceeds of any offering would be used for general corporate purposes, including repayment of indebtedness, acquisitions, additions to working capital, repurchases of ordinary shares, dividends, capital expenditures and investments in the Company's subsidiaries. In addition, the Company held cash and cash equivalents of $2.0 billion as of September 30, 2022. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-22-000043:mdna:107]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of September 30, 2022, the Company's credit ratings and outlook were as follows:

[0000833444-22-000043:mdna:108]
| Rating Agency |  | Short-Term Rating |  | Long-Term Rating |  | Outlook |
| S&P |  | A-2 |  | BBB+ |  | Stable |
| Moody's |  | P-2 |  | Baa2 |  | Stable |

[0000833444-22-000043:mdna:109]
The security ratings set forth above are issued by unaffiliated third party rating agencies and are not a recommendation to buy, sell or hold securities. The ratings may be subject to revision or withdrawal by the assigning rating organization at any time.

[0000833444-22-000043:mdna:110]
•The Company entered into the following new or modified debt arrangements in fiscal 2022:

[0000833444-22-000043:mdna:111]
◦In November 2021, the Company entered into a €200 million ($196 million as of September 30, 2022) bank term loan which had an interest rate of EURIBOR plus 0.5% and was due and paid in October 2022.

[0000833444-22-000043:mdna:112]
◦In March 2022, the Company entered into two bank term loans totaling €285 million ($280 million as of September 30, 2022) which both have an interest rate of EURIBOR plus 0.5% and are due in March 2023.

[0000833444-22-000043:mdna:113]
◦In September 2022, the Company and its wholly owned subsidiary, TFSCA issued €600 million ($589 million as of September 30, 2022) of bonds with an interest rate of 3.0%, which are due in September 2028 and $400 million of bonds with an interest rate of 4.9%, which are due in December 2032.

[0000833444-22-000043:mdna:114]
◦In September 2022, the Company repaid a ¥25 billion ($181 million) term loan and entered into a ¥30 billion ($208 million as of September 30, 2022) term loan which is due in September 2027.  Both the original and the new debt have an interest rate of LIBOR plus 0.4%.

[0000833444-22-000043:mdna:115]
•Financial covenants in the Company's revolving credit facilities requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of ASC 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of September 30, 2022, the Company was in compliance with all financial covenants set forth in its credit agreements and the indentures governing its outstanding notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-22-000043:mdna:116]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in fiscal 2022, the Company recorded income tax expense related to a change in its assertion over the outside basis differences of its investment in certain subsidiaries as a result of the planned divestitures. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient

[0000833444-22-000043:mdna:117]
manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-22-000043:mdna:118]
•The Company may from time to time purchase its outstanding debt through open market purchases, privately negotiated transactions or otherwise. Purchases or retirement of debt, if any, will depend on prevailing market conditions, liquidity requirements, contractual restrictions and other factors. The amounts involved may be material.

[0000833444-22-000043:mdna:119]
Restructuring

[0000833444-22-000043:mdna:120]
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to restructuring plans as necessary. Restructuring plans generally result in charges for workforce reductions, plant closures, asset impairments and other related costs which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The Company expects the restructuring actions to reduce cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-22-000043:mdna:121]
In fiscal 2021, the Company announced plans to optimize its cost structure through broad-based SG&A actions focused on simplification, standardization and centralization, with the intent to deliver annualized savings of $300 million by fiscal 2023. Additionally, the Company announced cost of sales actions intended to drive $250 million in annual run rate savings by fiscal 2023. The one-time pre-tax costs associated with these actions were originally expected to be approximately $385 million across all segments and at Corporate through fiscal 2023. The Company has incurred and exceeded these costs during fiscal 2022 due to certain restructuring actions and expenses planned for fiscal 2023 being accelerated into fiscal 2022, which also resulted in incremental savings. During the year ended September 30, 2022, the Company recorded $182 million and in total, the Company has recorded $424 million of costs resulting from the 2021 restructuring plan, which is the total amount expected to be incurred for this restructuring plan. The Company has outstanding restructuring reserves of $82 million at September 30, 2022, all of which is expected to be paid in cash.

[0000833444-22-000043:mdna:122]
Co-Issued Securities: Summarized Financial Information

[0000833444-22-000043:mdna:123]
The following information is provided in compliance with Rule 13-01 of Regulation S-X under the Securities Exchange Act of 1934 with respect to the (i) $625 million aggregate principal amount of 1.750% Senior Notes due 2030 (the “2030 Notes”), (ii) €500 million aggregate principal amount of 0.375% Senior Notes due 2027 (the “2027 Notes”), (iii) €500 million aggregate principal amount of 1.000% Senior Notes due 2032 (the “2032 Notes”), (iv) $500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due 2031  (the “2031 Notes”), (v)  €600 million aggregate principal amount of  3.000% Senior Notes due 2028 (the “2028 Notes”) and (vi) $400 million aggregate principal amount of 4.900% Senior Notes due 2032 (the “2032 Notes 2” and together with the 2032 Notes, the 2030 Notes, the 2028 Notes and the 2027 Notes, the “Notes”), each issued by Johnson Controls International plc ("Parent Company") and TFSCA, a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”). Refer to Note 10, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information.

[0000833444-22-000043:mdna:124]
TFSCA is a wholly-owned consolidated subsidiary of the Company that is 99.996% owned directly by the Parent Company and 0.004% owned by TFSCA’s sole general partner and manager, Tyco Fire & Security S.à r.l., which is itself wholly-owned by the Company. The Notes are the Parent Company’s and TFSCA’s unsecured, unsubordinated obligations. The Parent Company is incorporated and organized under the laws of Ireland and TFSCA is incorporated and organized under the laws of Luxembourg. The bankruptcy, insolvency, administrative, debtor relief and other laws of Luxembourg or Ireland, as applicable, may be materially different from, or in conflict with, those of the United States, including in the areas of rights of creditors, priority of governmental and other creditors, ability to obtain post-petition interest and duration of the proceeding. The

[0000833444-22-000043:mdna:125]
application of these laws, or any conflict among them, could adversely affect noteholders’ ability to enforce their rights under the Notes in those jurisdictions or limit any amounts that they may receive.

[0000833444-22-000043:mdna:126]
The following tables set forth summarized financial information of the Parent Company and TFSCA (collectively, the “Obligor Group”) on a combined basis after intercompany transactions have been eliminated, including adjustments to remove the receivable and payable balances, investment in, and equity in earnings from, those subsidiaries of the Parent Company other than TFSCA (collectively, the "Non-Obligor Subsidiaries").

[0000833444-22-000043:mdna:127]
The following table presents summarized income statement information for the year ended September 30, 2022 (in millions):

[0000833444-22-000043:mdna:128]
|  |  | September 30, 2022 |  |
| Net sales |  | $ | — |  |  |
| Gross profit |  | — |  |  |
| Loss from continuing operations |  | (268) |  |  |
| Net loss |  | (268) |  |  |
| Income attributable to noncontrolling interests |  | — |  |  |
| Net loss attributable to the entity |  | (268) |  |  |

[0000833444-22-000043:mdna:129]
Excluded from the table above are the intercompany transactions between the Obligor Group and Non-Obligor Subsidiaries as follows (in millions):

[0000833444-22-000043:mdna:130]
|  |  | September 30, 2022 |  |
| Net sales |  | $ | — |  |  |
| Gross profit |  | — |  |  |
| Income from continuing operations |  | 92 |  |  |
| Net income |  | 92 |  |  |
| Income attributable to noncontrolling interests |  | — |  |  |
| Net income attributable to the entity |  | 92 |  |  |

[0000833444-22-000043:mdna:131]
The following table presents summarized balance sheet information (in millions):

[0000833444-22-000043:mdna:132]
|  |  | September 30, 2022 |  |
| Current assets |  | $ | 1,231 |  |  |
| Noncurrent assets |  | 243 |  |  |
| Current liabilities |  | 5,463 |  |  |
| Noncurrent liabilities |  | 7,176 |  |  |
| Noncontrolling interests |  | — |  |  |

[0000833444-22-000043:mdna:133]
Excluded from the table above are the intercompany balances between the Obligor Group and Non-Obligor Subsidiaries as follows (in millions):

[0000833444-22-000043:mdna:134]
|  |  | September 30, 2022 |  |
| Current assets |  | $ | 455 |  |  |
| Noncurrent assets |  | 2,952 |  |  |
| Current liabilities |  | 2,538 |  |  |
| Noncurrent liabilities |  | 6,228 |  |  |
| Noncontrolling interests |  | — |  |  |

[0000833444-22-000043:mdna:135]
The same accounting policies as described in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements are used by the Parent Company and each of its subsidiaries in connection with the summarized financial information presented above.

[0000833444-22-000043:mdna:136]
CRITICAL ACCOUNTING ESTIMATES

[0000833444-22-000043:mdna:137]
The Company prepares its consolidated financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). This requires management to make estimates and assumptions that affect reported amounts and related disclosures. Actual results could differ from those estimates. The following estimates are considered by management to be the most critical to the understanding of the Company's consolidated financial statements as they require significant judgments that could materially impact the Company’s results of operations, financial position and cash flows.

[0000833444-22-000043:mdna:138]
Revenue Recognition

[0000833444-22-000043:mdna:139]
The Company recognizes revenue from certain long-term contracts on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. Total estimated costs at completion are based primarily on estimated purchase contract terms, historical performance trends and other economic projections. Factors that may result in a change to these estimates include unforeseen engineering problems, construction delays, cost inflation, the performance of subcontractors and major material suppliers, and weather conditions. As a result, changes to the original estimates may be required during the life of the contract. Such estimates are reviewed monthly and any adjustments to the measure of completion are recognized as adjustments to sales and gross profit using the cumulative catch-up method. Estimated losses are recorded when identified.

[0000833444-22-000043:mdna:140]
For agreements with multiple performance obligations, the Company allocates the transaction price of the contract to each performance obligation using the best estimate of the standalone selling price of each distinct good or service in the contract.  In order to estimate relative selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach.

[0000833444-22-000043:mdna:141]
The Company considers the contractual consideration payable by the customer and assesses variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

[0000833444-22-000043:mdna:142]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-22-000043:mdna:143]
The Company reviews goodwill for impairment annually as of July 31 or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses the multiples of earnings approach based on the average of published multiples of earnings of comparable entities with similar operations and economic characteristics that are applied to the Company's average of historical and future financial results. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations. The key assumptions used in the impairment tests were management's projections of future cash flows, weighted-average cost of capital and long-term growth rates. Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying businesses, there are significant judgments in determining the expected future cash flows attributable to a reporting unit.

[0000833444-22-000043:mdna:144]
During its fiscal 2022 annual impairment test, the Company determined that its Silent-Aire reporting unit's goodwill was impaired by $75 million. No other reporting unit was determined to be at risk of failing the goodwill impairment test.

[0000833444-22-000043:mdna:145]
Indefinite-lived intangible assets are also subject to at least annual impairment testing. Indefinite-lived intangible assets primarily consist of trademarks and trade names and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests. The key assumptions used in the impairment tests were long-term revenue growth projections, weighted-average cost of capital, the royalty rate and general industry, market and macro-economic conditions.

[0000833444-22-000043:mdna:146]
The Company continuously monitors for events and circumstances that could negatively impact the key assumptions in determining fair value. While the Company believes the judgments and assumptions used in the goodwill and indefinite-lived intangible impairment tests are reasonable, different assumptions or changes in general industry, market and macro-economic conditions could change the estimated fair values and, therefore, future impairment charges could be required, which could be material to the consolidated financial statements.

[0000833444-22-000043:mdna:147]
Refer to Note 8, "Goodwill and other Intangible Assets," of the notes to consolidated financial statements for information regarding the results of goodwill and indefinite-lived intangible assets impairment testing performed in fiscal 2022 and 2021.

[0000833444-22-000043:mdna:148]
Pension Plans

[0000833444-22-000043:mdna:149]
The Company provides a range of benefits to its employees and retired employees, including pensions. Plan assets and obligations are measured annually, or more frequently if there is a significant remeasurement event, based on the Company’s measurement date utilizing various actuarial assumptions such as discount rates, assumed rates of return and compensation increases as of that date. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends when appropriate.

[0000833444-22-000043:mdna:150]
The Company utilizes a mark-to-market approach for recognizing pension expenses, including measuring the market related value of plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event. Refer to Note 16, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the Company's pension plans.

[0000833444-22-000043:mdna:151]
U.S. GAAP requires that companies recognize in the statement of financial position a liability for plans that are underfunded or unfunded, or an asset for plans that are over funded. U.S. GAAP also requires that companies measure the benefit obligations and fair value of plan assets that determine a benefit plan’s funded status as of the date of the employer’s fiscal year end.

[0000833444-22-000043:mdna:152]
The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension plans, the Company consistently uses the relevant country specific benchmark indices for determining the various discount rates. The Company’s weighted average discount rate on U.S. pension plans was 5.08% and 2.50% at September 30, 2022 and 2021, respectively. The Company’s weighted average discount rate on non-U.S. pension plans was 4.36% and 1.80% at September 30, 2022 and 2021, respectively.

[0000833444-22-000043:mdna:153]
In estimating the expected return on plan assets, the Company considers the historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plans’ invested assets. Reflecting the relatively long-term nature of the plans’ obligations, approximately 19% of the plans’ assets are invested in equity securities and 66% in fixed income securities, with the remainder primarily invested in alternative investments. For the years ended September 30, 2022 and 2021, the Company’s expected long-term return on U.S. pension plan assets used to determine net periodic benefit cost was 7.00% and 6.50%, respectively. The actual rate of return on U.S. pension plans was below 7.00% in fiscal 2022 and above 6.50% in fiscal 2021. For the years ended September 30, 2022 and 2021, the Company’s weighted average expected long-term return on non-U.S. pension plan assets was 3.70% and 4.90%, respectively. The actual rate of return on non-U.S. pension plans was below 3.70% in fiscal 2022 and above 4.90% in fiscal 2021.

[0000833444-22-000043:mdna:154]
Beginning in fiscal 2023, the Company believes the long-term rate of return will approximate 8.25% for U.S. pension plans and 3.70% for non-U.S. pension plans. Any differences between actual investment results and the expected long-term asset returns will be reflected in net periodic benefit costs in the fourth quarter of each fiscal year or at the date of a significant remeasurement event. If the Company’s actual returns on plan assets are less than the Company’s expectations, additional contributions may be required.

[0000833444-22-000043:mdna:155]
In fiscal 2022, total employer contributions to the defined benefit pension plans were $93 million, none of which were voluntary contributions made by the Company. The Company expects to contribute approximately $38 million in cash to its defined benefit pension plans in fiscal 2023.

[0000833444-22-000043:mdna:156]
Based on information provided by its independent actuaries and other relevant sources, the Company believes that the assumptions used are reasonable; however, changes in these assumptions could impact the Company’s financial position, results of operations or cash flows.

[0000833444-22-000043:mdna:157]
Mark-to-market adjustments represent actuarial gains (losses) arising from changes in actuarial assumptions and actuarial experiences different from those assumed that are used to value the plan assets and the benefit obligations. The primary factors contributing to actuarial gains (losses) are changes in the discount rate used to value benefit obligations and the difference between expected and actual returns on plan assets. Mark-to-market adjustments are highly volatile and are difficult to forecast. Refer to Note 16, "Retirement Plans," of the notes to consolidated financial statements for further details.

[0000833444-22-000043:mdna:158]
The following chart illustrates the estimated increases (decreases) in projected benefit obligation and future ongoing pension expense, which excludes any potential mark-to-market adjustments, assuming an increase of 25 basis points in the key assumptions for the Company's pension plans (in millions):

[0000833444-22-000043:mdna:159]
|  | Pension Benefits |
|  | U.S. Plans |  | Non-U.S. Plans |
|  | Change in Projected Benefit Obligation |  | Change in Ongoing Pension Expense |  | Change in Projected Benefit Obligation |  | Change in Ongoing Pension Expense |
| Discount rate | $ | (31) |  |  | $ | 3 |  |  | $ | (39) |  |  | $ | 1 |  |
| Expected return on plan assets | — |  |  | (4) |  |  | — |  |  | (3) |  |

[0000833444-22-000043:mdna:160]
Loss Contingencies

[0000833444-22-000043:mdna:161]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-22-000043:mdna:162]
The Company is subject to laws and regulations relating to protecting the environment. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. During fiscal 2022, the Company increased its accrual for environmental remediation liabilities by $228 million. Refer to Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements.

[0000833444-22-000043:mdna:163]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-22-000043:mdna:164]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-22-000043:mdna:165]
The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Estimated asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. Annually, the Company assesses the

[0000833444-22-000043:mdna:166]
sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-22-000043:mdna:167]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers. Refer to Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.

[0000833444-22-000043:mdna:168]
Income Taxes

[0000833444-22-000043:mdna:169]
Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and other loss carryforwards. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company records a valuation allowance that primarily represents non-U.S. operating and other loss carryforwards for which realization is uncertain. Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, and the valuation allowance recorded against the Company’s net deferred tax assets.

[0000833444-22-000043:mdna:170]
The Company reviews the realizability of its deferred tax assets and related valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary. At September 30, 2022, the Company had a valuation allowance of $6.0 billion for continuing operations, of which $5.5 billion relates to net operating loss carryforwards primarily in France, Germany, Ireland, Luxembourg, Mexico, Spain, United Kingdom and the U.S. for which sustainable taxable income has not been demonstrated; and $0.5 billion for other deferred tax assets.

[0000833444-22-000043:mdna:171]
The Company’s federal income tax returns and certain non-U.S. income tax returns for various fiscal years remain under various stages of audit by the IRS and respective non-U.S. tax authorities. Although the outcome of tax audits is always uncertain, management believes that it has appropriate support for the positions taken on its tax returns and that its annual tax provisions included amounts sufficient to pay assessments, if any, which may be proposed by the taxing authorities. At September 30, 2022, the Company had recorded a liability of $2.5 billion for its best estimate of the probable loss on certain of its tax positions, the majority of which is included in other noncurrent liabilities in the consolidated statements of financial position. Nonetheless, the amounts ultimately paid, if any, upon resolution of the issues raised by the taxing authorities may differ materially from the amounts accrued for each year.

[0000833444-22-000043:mdna:172]
The Company does not generally provide additional U.S. or non-U.S. income taxes on outside basis differences of consolidated subsidiaries included in shareholders’ equity attributable to Johnson Controls International plc, except in limited circumstances including anticipated taxation on planned divestitures. The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income. The Company’s intent is to reduce the outside basis differences only when it would be tax efficient.  Refer to "Capitalization" within the "Liquidity and Capital Resources" section for discussion of U.S. and non-U.S. cash projections.

[0000833444-22-000043:mdna:173]
Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for the Company's income tax disclosures.

[0000833444-22-000043:mdna:174]
NEW ACCOUNTING PRONOUNCEMENTS

[0000833444-22-000043:mdna:175]
Refer to the "New Accounting Pronouncements" section within Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements.

[0000833444-22-000043:mdna:176]
RISK MANAGEMENT

[0000833444-22-000043:mdna:177]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, stock-based compensation and interest rates. All hedging transactions are authorized and executed pursuant to clearly defined policies and procedures, which strictly prohibit the use of financial instruments for speculative purposes. At the inception of the hedge, the Company assesses the effectiveness of the hedge instrument and designates the hedge instrument as either (1) a hedge of a recognized asset or liability or of a recognized firm commitment (a fair value hedge), (2) a hedge of a forecasted transaction or of the variability of cash flows to be received or paid related to an unrecognized asset or liability (a cash flow hedge) or (3) a hedge of a net investment in a non-U.S. operation (a net investment hedge). The Company performs hedge effectiveness testing on an ongoing basis depending on the type of hedging instrument used. All other derivatives not designated as hedging instruments under ASC 815, "Derivatives and Hedging," are revalued in the consolidated statements of income.

[0000833444-22-000043:mdna:178]
For all foreign currency derivative instruments designated as cash flow hedges, retrospective effectiveness is tested on a monthly basis using a cumulative dollar offset test. The fair value of the hedged exposures and the fair value of the hedge instruments are revalued, and the ratio of the cumulative sum of the periodic changes in the value of the hedge instruments to the cumulative sum of the periodic changes in the value of the hedge is calculated. The hedge is deemed as highly effective if the ratio is between 80% and 125%. For commodity derivative contracts designated as cash flow hedges, effectiveness is tested using a regression calculation. Ineffectiveness is minimal as the Company aligns most of the critical terms of its derivatives with the supply contracts.

[0000833444-22-000043:mdna:179]
For net investment hedges, the Company assesses its net investment positions in the non-U.S. operations and compares it with the outstanding net investment hedges on a quarterly basis. The hedge is deemed effective if the aggregate outstanding principal of the hedge instruments designated as the net investment hedge in a non-U.S. operation does not exceed the Company’s net investment positions in the respective non-U.S. operation.

[0000833444-22-000043:mdna:180]
Equity swaps and any other derivative instruments not designated as hedging instruments under ASC 815 require no assessment of effectiveness.

[0000833444-22-000043:mdna:181]
A discussion of the Company’s accounting policies for derivative financial instruments is included in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements, and further disclosure relating to derivatives and hedging activities is included in Note 11, "Derivative Instruments and Hedging Activities," and Note 12, "Fair Value Measurements," of the notes to consolidated financial statements.

[0000833444-22-000043:mdna:182]
Foreign Exchange

[0000833444-22-000043:mdna:183]
The Company has manufacturing, sales and distribution facilities around the world and thus makes investments and enters into transactions denominated in various foreign currencies. In order to maintain strict control and achieve the benefits of the Company’s global diversification, foreign exchange exposures for each currency are netted internally so that only its net foreign exchange exposures are, as appropriate, hedged with financial instruments.

[0000833444-22-000043:mdna:184]
The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. The Company primarily enters into foreign currency exchange contracts to reduce the earnings and cash flow impact of the variation of non-functional currency denominated receivables and payables. Gains and losses resulting from hedging instruments offset the foreign exchange gains or losses on the underlying assets and liabilities being hedged. The maturities of the forward exchange contracts generally coincide with the settlement dates of the related transactions. Realized and unrealized gains and losses on these contracts are recognized in the same period as gains and losses on the hedged items. The Company also selectively hedges anticipated transactions that are subject to foreign exchange exposure, primarily with foreign currency exchange contracts, which are designated as cash flow hedges in accordance with ASC 815.

[0000833444-22-000043:mdna:185]
The Company has entered into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of debt obligations are reflected in the accumulated other comprehensive income ("AOCI") account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-22-000043:mdna:186]
At September 30, 2022 and 2021, the Company estimates that an unfavorable 10% change in the exchange rates would have decreased net unrealized gains by approximately $133 million and $213 million, respectively.

[0000833444-22-000043:mdna:187]
Interest Rates

[0000833444-22-000043:mdna:188]
Substantially all of the Company's outstanding debt has fixed interest rates, and, therefore, any fluctuation in market interest rates is not expected to have a material effect on the Company's results of operations. A 20 basis point increase/decrease in the average interest rate on the Company's variable rate debt would have an immaterial impact on interest expense.

[0000833444-22-000043:mdna:189]
Commodities

[0000833444-22-000043:mdna:190]
The Company uses commodity hedge contracts in the financial derivatives market in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As a cash flow hedge, gains and losses resulting from the hedging instruments offset the gains or losses on purchases of the underlying commodities that will be used in the business. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-22-000043:mdna:191]
ENVIRONMENTAL, HEALTH AND SAFETY AND OTHER MATTERS

[0000833444-22-000043:mdna:192]
The Company’s global operations are governed by environmental laws and worker safety laws. Under various circumstances, these laws impose civil and criminal penalties and fines, as well as injunctive and remedial relief, for noncompliance and require remediation at sites where Company-related substances have been released into the environment.

[0000833444-22-000043:mdna:193]
The Company has expended substantial resources globally, both financial and managerial, to comply with applicable environmental laws and worker safety laws and to protect the environment and workers. The Company believes it is in substantial compliance with such laws and maintains procedures designed to foster and ensure compliance. However, the Company has been, and in the future may become, the subject of formal or informal enforcement actions or proceedings regarding noncompliance with such laws or the remediation of Company-related substances released into the environment. Such matters typically are resolved with regulatory authorities through commitments to compliance, abatement or remediation programs and in some cases payment of penalties. Historically, neither such commitments nor penalties imposed on the Company have been material.

[0000833444-22-000043:mdna:194]
Refer to Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements for additional information.
