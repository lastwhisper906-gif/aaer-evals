# JCI notes — 0000833444-22-000043


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000833444-22-000043:notes:1]
Portions of the definitive Proxy Statement to be delivered to shareholders in connection with the annual general meeting of shareholders to be held on March 8, 2023 are incorporated by reference into Part III.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000833444-22-000043:notes:2]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited  company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," "Johnson Controls" or "JCI plc").

[0000833444-22-000043:notes:3]
The Company's fiscal year ends on September 30. Unless otherwise stated, references to years in this report relate to fiscal years rather than calendar years.

[0000833444-22-000043:notes:4]
Nature of Operations

[0000833444-22-000043:notes:5]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers in more than 150 countries. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-22-000043:notes:6]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management and repair of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its OpenBlue software platform and capabilities. The Company partners with customers by leveraging its broad product portfolio and digital capabilities powered by OpenBlue, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

[0000833444-22-000043:notes:7]
Principles of Consolidation

[0000833444-22-000043:notes:8]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the year are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.

[0000833444-22-000043:notes:9]
The Company consolidates variable interest entities ("VIE") when it has the power to direct the significant activities of the entity and the obligation to absorb losses or receive benefits from the entity that may be significant. The Company did not have any material consolidated or nonconsolidated VIEs in its continuing operations for the presented reporting periods.

[0000833444-22-000043:notes:10]
Use of Estimates

[0000833444-22-000043:notes:11]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0000833444-22-000043:notes:12]
Fair Value of Financial Instruments

[0000833444-22-000043:notes:13]
ASC 820, "Fair Value Measurement," defines fair value as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0000833444-22-000043:notes:14]
Level 1: Observable inputs such as quoted prices in active markets for identical assets or liabilities;

[0000833444-22-000043:notes:15]
Level 2: Quoted prices in active markets for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0000833444-22-000043:notes:16]
Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0000833444-22-000043:notes:17]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0000833444-22-000043:notes:18]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values.

[0000833444-22-000043:notes:19]
Assets and Liabilities Held for Sale

[0000833444-22-000043:notes:20]
Assets and liabilities (disposal groups) to be sold are classified as held for sale in the period in which all of the following criteria are met:

[0000833444-22-000043:notes:21]
•Management, having the authority to approve the action, commits to a plan to sell the disposal group;

[0000833444-22-000043:notes:22]
•The disposal group is available for immediate sale in its present condition subject only to terms that are usual and customary for sales of such disposal groups;

[0000833444-22-000043:notes:23]
•An active program to locate a buyer and other actions required to complete the plan to sell the disposal group have been initiated;

[0000833444-22-000043:notes:24]
•Sale of the disposal group is probable and transfer of the disposal group is expected to qualify for recognition as a completed sale within one year, except if events or circumstances beyond the Company's control extend the period of time required to sell the disposal group beyond one year;

[0000833444-22-000043:notes:25]
•The disposal group is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and

[0000833444-22-000043:notes:26]
•Actions required to complete the plan indicate that it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn.

[0000833444-22-000043:notes:27]
The Company initially measures a disposal group that is classified as held for sale at the lower of its carrying value or fair value less any costs to sell. Any loss resulting from this measurement is recognized in the period in which the held for sale criteria are met. Conversely, gains are not recognized on the sale of a disposal group until the date of sale. The Company assesses the fair value of a disposal group, less any costs to sell, each reporting period it remains classified as held for sale and reports any subsequent changes as an adjustment to the carrying value of the disposal group, as long as the new carrying value does not exceed the carrying value of the disposal group at the time it was initially classified as held for sale.

[0000833444-22-000043:notes:28]
Upon determining that a disposal group meets the criteria to be classified as held for sale, the Company reports the assets and liabilities of the disposal group, if material, in the line items assets held for sale and liabilities held for sale in the consolidated statements of financial position.

[0000833444-22-000043:notes:29]
Cash and Cash Equivalents

[0000833444-22-000043:notes:30]
Cash equivalents include all highly liquid investments with an original maturity of three months or less when purchased.

[0000833444-22-000043:notes:31]
Restricted Cash

[0000833444-22-000043:notes:32]
Restricted cash relates to amounts restricted for payment of asbestos liabilities and certain litigation and environmental matters. Restricted cash is recorded within other current assets in the consolidated statements of financial position and totaled $35 million and $6 million at September 30, 2022 and 2021, respectively.

[0000833444-22-000043:notes:33]
Receivables

[0000833444-22-000043:notes:34]
Receivables consist of amounts billed and currently due from customers and unbilled costs and accrued profits related to revenues on long-term contracts that have been recognized for accounting purposes but not yet billed to customers. The Company extends credit to customers in the normal course of business and maintains an allowance for expected credit losses resulting from the inability or unwillingness of customers to make required payments. The allowance for expected credit losses is based on historical experience, existing economic conditions, reasonable and supportable forecasts, and any specific customer collection issues the Company has identified. The Company evaluates the reasonableness of the allowance for expected credit losses on a quarterly basis.

[0000833444-22-000043:notes:35]
The Company enters into various factoring agreements to sell certain accounts receivable to third-party financial institutions. For the majority of these agreements, for ease of administration, the Company collects customer payments related to the  factored receivables on behalf of the financial institutions but otherwise maintains no continuing involvement with respect to the factored receivables. Sales of accounts receivable are reflected as a reduction of accounts receivable in the consolidated statements of financial position and the proceeds are included in cash flows from operating activities in the consolidated statements of cash flows.

[0000833444-22-000043:notes:36]
Inventories

[0000833444-22-000043:notes:37]
Inventories are stated at the lower of cost or net realizable value using the first-in, first-out ("FIFO") method. Finished goods and work-in-process inventories include material, labor and manufacturing overhead costs.

[0000833444-22-000043:notes:38]
Property, Plant and Equipment

[0000833444-22-000043:notes:39]
Property, plant and equipment are recorded at cost. Depreciation is provided over the estimated useful lives of the respective assets using the straight-line method for financial reporting purposes and accelerated methods for income tax purposes. The estimated useful lives generally range from 3 to 40 years for buildings and improvements, up to 15 years for subscriber systems, and from 3 to 15 years for machinery and equipment. Interest on borrowings is capitalized during the active construction period of major capital projects, added to the cost of the underlying assets and amortized over the useful lives of the assets.

[0000833444-22-000043:notes:40]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-22-000043:notes:41]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. Goodwill is reviewed for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses the multiples of earnings approach based on the average of published multiples of earnings of comparable entities with similar operations and economic characteristics and applies the multiples to the Company's average of historical and future financial results for each reporting unit. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared to the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value.

[0000833444-22-000043:notes:42]
Indefinite-lived intangible assets are also subject to at least annual impairment testing. Indefinite-lived intangible assets primarily consist of trademarks and trade names and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests.

[0000833444-22-000043:notes:43]
Leases

[0000833444-22-000043:notes:44]
Lessee arrangements

[0000833444-22-000043:notes:45]
The Company leases certain administrative, production and other facilities, fleet vehicles, information technology equipment and other equipment under arrangements that are accounted for as operating leases. The Company determines whether an arrangement contains a lease at contract inception based on whether the arrangement involves the use of a physically distinct identified asset and whether the Company has the right to obtain substantially all of the economic benefits from the use of the asset throughout the period as well as the right to direct the use of the asset.

[0000833444-22-000043:notes:46]
The Company adopted ASU 2016-02, "Leases (Topic 842)" and the related amendments using a modified-retrospective approach as of October 1, 2019.

[0000833444-22-000043:notes:47]
Right-of-use assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent its obligation to make lease payments arising from the lease. Right-of-use assets and the corresponding lease liabilities are recognized at commencement date based on the present value of lease payments for all leases with terms longer than twelve months. The majority of the Company's leases do not provide an implicit interest rate. To determine the present value of lease payments, the Company uses its incremental borrowing rate based on information available on the lease commencement date or  the implicit rate if it is readily determinable.  The Company determines its incremental borrowing rate based on a comparable market yield curve consistent with its credit rating, term of the lease and relative economic environment. The Company has elected to combine lease and nonlease components for its leases.

[0000833444-22-000043:notes:48]
Most leases contain options to renew or terminate the lease. Right-of-use assets and lease liabilities reflect only the options which the Company is reasonably certain to exercise.

[0000833444-22-000043:notes:49]
The Company has certain real estate leases that contain variable lease payments which are based on changes in the Consumer Price Index (CPI). Additionally, the Company’s leases generally require it to pay for fuel, maintenance, repair, insurance and taxes. These payments are not included in the right-of-use asset or lease liability and are expensed as incurred.

[0000833444-22-000043:notes:50]
Lease expense is recognized on a straight-line basis over the lease term.

[0000833444-22-000043:notes:51]
Lessor arrangements

[0000833444-22-000043:notes:52]
The Company has monitoring services and maintenance agreements within its security business that include subscriber system assets for which the Company retains ownership. These agreements contain both lease and nonlease components. The Company has elected to combine lease and nonlease components for these arrangements where the timing and pattern of transfer of the lease and nonlease components are the same and the lease component would be classified as an operating lease if accounted for separately. The Company has concluded that in these arrangements the nonlease components are the predominant characteristic, and as a result, the combined component is accounted for under the revenue guidance.

[0000833444-22-000043:notes:53]
Impairment of Long-Lived Assets

[0000833444-22-000043:notes:54]
Long-lived assets, including right-of-use assets under operating leases, other tangible assets and intangible assets with definitive lives, are reviewed for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of Software to be Sold, Leased, or Marketed."

[0000833444-22-000043:notes:55]
Assets and liabilities are grouped at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluates the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. Intangible assets acquired in a business combination that are used in research and development activities are considered indefinite-lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they are not amortized but are tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired.  If the carrying amount of an intangible asset exceeds its fair value, the Company recognizes an impairment loss in an amount equal to that excess. Unamortized capitalized costs of a computer software product are compared to the net realizable value of the product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset is written off.

[0000833444-22-000043:notes:56]
Revenue Recognition

[0000833444-22-000043:notes:57]
Revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services is recognized on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are

[0000833444-22-000043:notes:58]
reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company does not adjust the promised amount of consideration for the effects of a significant financing component as at contract inception the Company expects to receive the payment within twelve months of transfer of goods or services.

[0000833444-22-000043:notes:59]
The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term.

[0000833444-22-000043:notes:60]
The Company also sells certain HVAC and refrigeration products and services in bundled arrangements with multiple performance obligations, such as equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Company sells security monitoring systems that may have multiple performance obligations, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with the sale of equipment and related installations are recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. The transaction price is allocated to each performance obligation based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized over time on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the contract.

[0000833444-22-000043:notes:61]
In all other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

[0000833444-22-000043:notes:62]
The Company considers the contractual consideration payable by the customer and assesses variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

[0000833444-22-000043:notes:63]
Shipping and handling costs billed to customers are included in sales and the related costs are included in cost of sales when control transfers to the customer. The Company presents amounts collected from customers for sales and other taxes net of the related amounts remitted.

[0000833444-22-000043:notes:64]
Subscriber System Assets, Dealer Intangibles and Related Deferred Revenue Accounts

[0000833444-22-000043:notes:65]
The Company considers assets related to the acquisition of new customers in its electronic security business in three asset categories:

[0000833444-22-000043:notes:66]
•Internally generated residential subscriber systems outside of North America

[0000833444-22-000043:notes:67]
•Internally generated commercial subscriber systems (collectively referred to as subscriber system assets)

[0000833444-22-000043:notes:68]
•Customer accounts acquired through the ADT dealer program, primarily outside of North America (referred to as dealer intangibles)

[0000833444-22-000043:notes:69]
Subscriber system assets include installed property, plant and equipment for which the Company retains ownership and deferred costs directly related to the customer acquisition and system installation. Subscriber system assets represent capitalized equipment (e.g. security control panels, touch pad, motion detectors, window sensors, and other equipment) and installation costs associated with electronic security monitoring arrangements under which the Company retains ownership of the security system assets in a customer's place of business, or outside of North America, residence. Installation costs represent costs incurred to prepare the asset for its intended use. The Company pays property taxes on the subscriber system assets and upon

[0000833444-22-000043:notes:70]
customer termination, may retrieve such assets. These assets embody a probable future economic benefit as they generate future monitoring revenue for the Company.

[0000833444-22-000043:notes:71]
Costs related to the subscriber system equipment and installation are categorized as property, plant and equipment rather than deferred costs. Deferred costs associated with subscriber system assets represent direct and incremental selling expenses (such as commissions) related to acquiring the customer. Commissions related to up-front consideration paid by customers in connection with the establishment of the monitoring arrangement are determined based on a percentage of the up-front fees and do not exceed deferred revenue. Such deferred costs are recorded as other current and noncurrent assets within the consolidated statements of financial position.

[0000833444-22-000043:notes:72]
Subscriber system assets and any deferred revenue resulting from the customer acquisition are accounted for over the expected life of the subscriber. In certain geographical areas where the Company has a large number of customers that behave in a similar manner over time, the Company accounts for subscriber system assets and related deferred revenue using pools, with separate pools for the components of subscriber system assets and any related deferred revenue based on the same month and year of acquisition. Pooled subscriber system assets and related deferred revenue are depreciated using a straight-line method with lives up to 12 years and considering customer attrition. Non-pooled subscriber systems (primarily in Europe, Latin America and Asia) and related deferred revenue are depreciated using a straight-line method with a 15-year life, with remaining balances written off upon customer termination.

[0000833444-22-000043:notes:73]
Certain contracts and related customer relationships result from purchasing residential security monitoring contracts from an external network of independent dealers who operate under the ADT dealer program, primarily outside of North America. Acquired contracts and related customer relationships are recorded at their contractually determined purchase price.

[0000833444-22-000043:notes:74]
During the first 6 months (12 months in certain circumstances) after the purchase of the customer contract, any cancellation of monitoring service, including those that result from customer payment delinquencies, results in a chargeback by the Company to the dealer for the full amount of the contract purchase price. The Company records the amount charged back to the dealer as a reduction of the previously recorded intangible asset.

[0000833444-22-000043:notes:75]
Intangible assets arising from the ADT dealer program described above are amortized in pools determined by the same month and year of contract acquisition on a straight-line basis over the period of the customer relationship. The estimated useful life of dealer intangibles ranges from 12 to 15 years.

[0000833444-22-000043:notes:76]
Research and Development Costs

[0000833444-22-000043:notes:77]
Expenditures for research activities relating to product development and improvement are charged against income as incurred and included within selling, general and administrative expenses in the consolidated statements of income. Such expenditures for the years ended September 30, 2022, 2021 and 2020 were $295 million, $275 million and $274 million, respectively.

[0000833444-22-000043:notes:78]
Stock-Based Compensation

[0000833444-22-000043:notes:79]
Restricted (Non-vested) Stock /Units

[0000833444-22-000043:notes:80]
Restricted stock and restricted stock units are typically settled in shares for employees in the U.S. and in cash for employees not in the U.S. Restricted awards typically vest over a period of three years from the grant date. The Company's Compensation and Talent Development Committee may approve different vesting terms on specific grants. The fair value of each share-settled restricted award is based on the closing market value of the Company’s ordinary shares on the date of grant. The fair value of each cash-settled restricted award is recalculated at the end of each reporting period based on the closing market value of the Company's ordinary shares at the end of the reporting period, and the liability and expense are adjusted based on the new fair value.

[0000833444-22-000043:notes:81]
Performance Share Awards

[0000833444-22-000043:notes:82]
Performance-based share unit ("PSU") awards are generally contingent on the achievement of predetermined performance goals over a performance period of one to three years and on the award holder's continuous employment until the vesting date. The majority of PSUs are also indexed to the achievement of specified levels of total shareholder return versus a peer group over the performance period.

[0000833444-22-000043:notes:83]
Upon completion of the performance period, earned PSUs are typically settled with shares of the Company's ordinary shares for employees in the U.S. and in cash for employees not in the U.S.

[0000833444-22-000043:notes:84]
The fair value of the portion of the PSU which is linked to the achievement of performance goals is based on the closing market value of the Company's ordinary shares on the date of grant. Share-based compensation expense for these PSUs is recognized over the performance period based on the probability of achieving the performance targets.

[0000833444-22-000043:notes:85]
The fair value of the portion of the PSU that is indexed to total shareholder return is estimated on the date of grant using a Monte Carlo simulation that uses the following assumptions:

[0000833444-22-000043:notes:86]
•The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant.

[0000833444-22-000043:notes:87]
•The expected volatility is based on the historical volatility of the Company's stock over the most recent three-year period as of the grant date.

[0000833444-22-000043:notes:88]
Share-based compensation expense for PSUs which are indexed to total shareholder return is not adjusted for changes in performance subsequent to the grant date because the likelihood of achieving the market condition is incorporated in the grant date fair value of the award.

[0000833444-22-000043:notes:89]
Stock Options

[0000833444-22-000043:notes:90]
Stock options are granted with an exercise price equal to the market price of the Company’s stock at the date of grant. Stock option awards typically vest between two and three years after the grant date and expire ten years from the grant date.

[0000833444-22-000043:notes:91]
The fair value of each option is estimated on the date of grant using a Black-Scholes option valuation model that uses the following assumptions:

[0000833444-22-000043:notes:92]
•The expected life of options represents the period of time that options granted are expected to be outstanding.

[0000833444-22-000043:notes:93]
•The risk-free interest rate for periods during the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant.

[0000833444-22-000043:notes:94]
•Expected volatility is based on the historical volatility of the Company's stock since October 2016 blended with the historical volatility of certain peer companies' stock prior to October 2016 over the most recent period corresponding to the expected life as of the grant date.

[0000833444-22-000043:notes:95]
•The expected dividend yield is based on the expected annual dividend as a percentage of the market value of the Company’s ordinary shares as of the grant date.

[0000833444-22-000043:notes:96]
The Company uses historical data to estimate option exercises and employee terminations within the valuation model.

[0000833444-22-000043:notes:97]
Stock Appreciation Rights

[0000833444-22-000043:notes:98]
SARs vest under the same terms and conditions as stock option awards, but are settled in cash for the difference between the market price on the date of exercise and the exercise price. As a result, SARs are recorded in the Company’s consolidated statements of financial position as a liability until the date of exercise.

[0000833444-22-000043:notes:99]
The fair value of each SAR award is estimated using a similar method to that used for stock options. The fair value of each SAR award is recalculated at the end of each reporting period and the liability and expense are adjusted based on the new fair value.

[0000833444-22-000043:notes:100]
Amounts related to SARs are not material.

[0000833444-22-000043:notes:101]
Earnings Per Share

[0000833444-22-000043:notes:102]
The Company presents both basic and diluted earnings per share ("EPS") amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method

[0000833444-22-000043:notes:103]
assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future and compensation cost for future service that the Company has not yet recognized. For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method include unamortized compensation cost.

[0000833444-22-000043:notes:104]
Foreign Currency Translation

[0000833444-22-000043:notes:105]
Substantially all of the Company’s international operations use the respective local currency as the functional currency. Assets and liabilities of international entities have been translated at period-end exchange rates, and income and expenses have been translated using average exchange rates for the period. Monetary assets and liabilities denominated in non-functional currencies are adjusted to reflect period-end exchange rates. Aggregate transaction gains (losses), net of the impact of foreign currency hedges, for the years ended September 30, 2022, 2021 and 2020 were $49 million, $56 million and $(32) million, respectively.

[0000833444-22-000043:notes:106]
Derivative Financial Instruments

[0000833444-22-000043:notes:107]
The Company has written policies and procedures that place all financial instruments under the direction of Corporate treasury and restrict all derivative transactions to those intended for hedging purposes. The use of financial instruments for speculative purposes is strictly prohibited. The Company selectively uses financial instruments to manage the market risk from changes in foreign exchange rates, commodity prices, stock-based compensation liabilities and interest rates.

[0000833444-22-000043:notes:108]
The fair values of all derivatives are recorded in the consolidated statements of financial position. The change in a derivative’s fair value is recorded each period in current earnings or accumulated other comprehensive income ("AOCI"), depending on whether the derivative is designated as part of a hedge transaction and if so, the type of hedge transaction.

[0000833444-22-000043:notes:109]
Investments

[0000833444-22-000043:notes:110]
Investments in debt and equity securities are are marked to market at the end of each accounting period. Unrealized gains and losses on these securities are recognized in the Company's consolidated statements of income. The deferred compensation plan assets are marked to market at the end of each accounting period and all unrealized gains and losses are recorded in the consolidated statements of income.

[0000833444-22-000043:notes:111]
Pension and Postretirement Benefits

[0000833444-22-000043:notes:112]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring the market related value of plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event.

[0000833444-22-000043:notes:113]
Loss Contingencies

[0000833444-22-000043:notes:114]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-22-000043:notes:115]
The Company is subject to laws and regulations relating to protecting the environment. Expenses associated with environmental remediation obligations are recognized when such amounts are probable and can be reasonably estimated.

[0000833444-22-000043:notes:116]
Liabilities and expenses for workers' compensation, product, general and auto liabilities is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. Receivables from third party insurers are recorded when recovery has been determined to be probable. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-22-000043:notes:117]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-22-000043:notes:118]
The Company and certain of its subsidiaries, along with numerous other companies, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The estimated liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068

[0000833444-22-000043:notes:119]
(which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against its affiliates). Estimated asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-22-000043:notes:120]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. Estimated asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers.

[0000833444-22-000043:notes:121]
Income Taxes

[0000833444-22-000043:notes:122]
Deferred tax liabilities and assets are recognized for the expected future tax consequences of events that have been reflected in the consolidated financial statements. Deferred tax liabilities and assets are determined based on the differences between the book and tax basis of particular assets and liabilities and operating loss carryforwards, using tax rates in effect for the years in which the differences are expected to reverse. A valuation allowance is provided to reduce the carrying or book value of deferred tax assets if, based upon the available evidence, including consideration of tax planning strategies, it is more-likely-than-not that some or all of the deferred tax assets will not be realized.

[0000833444-22-000043:notes:123]
Retrospective Changes

[0000833444-22-000043:notes:124]
Effective October 1, 2021, the Company's marine businesses, which were previously included in the Building Solutions Asia Pacific and Global Products segments, became part of the Building Solutions EMEA/LA segment. Historical information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation.

[0000833444-22-000043:notes:125]
New Accounting Pronouncements

[0000833444-22-000043:notes:126]
Recently Adopted Accounting Pronouncements

[0000833444-22-000043:notes:127]
In October 2021, the FASB issued ASU No. 2021-08, “Business Combinations (Topic 805), Accounting for Contract Assets and Contract Liabilities from Contracts with Customers,” which requires contract assets and contract liabilities (e.g. deferred revenue) acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, “Revenue from Contracts with Customers.” Generally, this new guidance will result in the acquirer recognizing contract assets and contract liabilities at the same amounts recorded by the acquiree. Historically, such amounts were recognized by the acquirer at fair value in acquisition accounting. The guidance is applied prospectively to acquisitions occurring on or after the effective date. The Company early adopted ASU No. 2021-08 at the beginning of fiscal 2022. The adoption of the new standard did not have a material impact on the Company's consolidated financial statements.

[0000833444-22-000043:notes:128]
Recently Issued Accounting Pronouncements

[0000833444-22-000043:notes:129]
In September 2022, the FASB issued ASU 2022-04, "Disclosure of Supplier Finance Program Obligations", which is intended to enhance the transparency surrounding the use of supplier finance programs. Supplier finance programs may also be referred to as reverse factoring, payables finance, or structured payables arrangements. The amendments require a buyer that uses supplier finance programs to make annual disclosures about the program’s key terms, the balance sheet presentation of related amounts, the confirmed amount outstanding at the end of the period, and associated rollforward information. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company expects to adopt the new disclosures, other than the rollforward disclosure, as required at the beginning of fiscal 2024. The rollforward disclosures will be adopted as required at the beginning of fiscal 2025.

[0000833444-22-000043:notes:130]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-22-000043:notes:131]
ACQUISITIONS AND DIVESTITURES
During fiscal 2022, the Company acquired several businesses for a combined purchase price, net of cash acquired, of $323 million, of which $269 million was paid as of September 30, 2022. Intangible assets associated with these acquisitions totaled $123 million and primarily relate to customer relationships and technology. In connection with these acquisitions, the Company recorded goodwill of $194 million, of which $68 million was assigned to the Building Solutions EMEA/LA segment, $45 million was assigned to the Global Products segment, $44 million was assigned to the Building Solutions APAC segment and $36 million was assigned to the Building Solutions North America segment.

[0000833444-22-000043:notes:132]
Silent-Aire Acquisition

[0000833444-22-000043:notes:133]
In May 2021, the Company completed its acquisition of Silent-Aire, a global leader in hyperscale data center cooling and modular critical infrastructure solutions, for approximately $755 million, net of cash acquired, which was comprised of an upfront net cash payment of approximately $661 million, the estimated fair value at the acquisition date of contingent earn-out liabilities of approximately $86 million and a working capital adjustment of $8 million. The contingent earn-out liabilities are based upon the achievement of certain defined operating results in each of the three years following the acquisition, with a maximum payout of approximately $250 million. The fair value of contingent earn-out liabilities is reassessed on a quarterly basis and could differ materially from the initial estimates. Subsequent changes in the estimated fair value of contingent earn-out liabilities are recorded in the consolidated statements of income when incurred. Earn-out payments that are less than or equal to the contingent earn-out liabilities on the acquisition date are reflected as financing cash outflows and amounts paid in excess of the contingent earn-out liabilities on the acquisition date are reflected as operating cash outflows. During the year ended September 30, 2022, the Company recorded a reduction in the fair value of the contingent earn-out liability of $43 million. No earn-out payments were made for the first twelve-month earn-out period ended April 30, 2022 as the performance measures for the period were not achieved.

[0000833444-22-000043:notes:134]
In connection with the acquisition, the Company recorded goodwill of $244 million in the Global Products segment. Goodwill is attributable primarily to expected synergies, expanded market opportunities and other benefits that the Company believes will result from combining its operations with the operations of Silent-Aire. The goodwill created in the acquisition is not deductible for tax purposes.

[0000833444-22-000043:notes:135]
The original fair values of the assets acquired and liabilities assumed related to Silent-Aire are as follows (in millions):

[0000833444-22-000043:notes:136]
| Cash and cash equivalents |  | $ | 5 |  |
| Accounts receivable |  | 141 |  |
| Inventories |  | 60 |  |
| Other current assets |  | 4 |  |
| Property, plant, and equipment - net |  | 33 |  |
| Goodwill |  | 244 |  |
| Intangible assets - net |  | 497 |  |
| Other noncurrent assets |  | 84 |  |
| Total assets acquired |  | 1,068 |  |
| Accounts payable |  | 62 |  |
| Accrued compensation and benefits |  | 6 |  |
| Deferred revenue |  | 32 |  |
| Other current liabilities |  | 12 |  |
| Other noncurrent liabilities |  | 196 |  |
| Total liabilities acquired |  | 308 |  |
| Net assets acquired |  | $ | 760 |  |

[0000833444-22-000043:notes:137]
The purchase price allocation to identifiable intangible assets acquired related to Silent-Aire is as follows:

[0000833444-22-000043:notes:138]
|  |  | Fair Value (in millions) |  | Weighted Average Life (in years) |
| Customer relationships |  | $ | 291 |  |  | 19 |
| Technology |  | 116 |  |  | 13 |
| Other definite-lived intangibles |  | 23 |  |  | 1 |
| Indefinite-lived trademarks |  | 67 |  |  |  |
| Total identifiable intangible assets |  | $ | 497 |  |  |  |

[0000833444-22-000043:notes:139]
Other acquisitions and divestitures were not material individually or in the aggregate in fiscal 2021 and 2020.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-22-000043:notes:140]
ASSETS AND LIABILITIES HELD FOR SALE & DISCONTINUED OPERATIONS
Assets and Liabilities Held for Sale

[0000833444-22-000043:notes:141]
During fiscal 2022, the Company determined that its Global Retail business within its Building Solutions North America, Building Solutions Asia Pacific and Building Solutions EMEA/LA segments and a business within the Building Solutions Asia Pacific segment both met the criteria to be classified as held for sale. The assets and liabilities of both businesses are presented as held for sale in the consolidated statements of financial position as of September 30, 2022. Assets and liabilities held for sale are recorded at the lower of carrying value or fair value, less costs to sell in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets". The carrying amount of any assets, including goodwill, that are part of the disposal group, but not in the scope of ASC 360-10, are tested for impairment under the relevant guidance prior to measuring the disposal group at fair value, less cost to sell.

[0000833444-22-000043:notes:142]
As a result of classifying the Global Retail business as held for sale, during the year ended September 30, 2022, the Company recorded impairment charges of $235 million to write down goodwill related to its North America Retail reporting unit and $86 million to write down the disposal group to its estimated fair value, less costs to sell. The Company also fully impaired $38 million of internal-use software projects that were no longer probable of being completed. Refer to Note 8, "Goodwill and Other Intangible Assets," of the notes to the consolidated financial statements for further information regarding the goodwill impairment charge.

[0000833444-22-000043:notes:143]
An additional $60 million was recorded in the year ended September 30, 2022 to write down the business classified as held for sale in the Building Solutions Asia Pacific segment to its estimated fair value, less costs to sell.

[0000833444-22-000043:notes:144]
All of the impairments were recorded within restructuring and impairment costs in the consolidated statements of income. The divestiture of the businesses held for sale could result in a gain or loss on sale to the extent the ultimate selling prices differ from the current carrying value of the net assets recorded, which could be material. The businesses did not meet the criteria to be classified as discontinued operations as neither divestiture represents a strategic shift that will have a major effect on the Company's operations and financial results.

[0000833444-22-000043:notes:145]
The following table summarizes the carrying value of the Global Retail assets and liabilities held for sale (in millions):

[0000833444-22-000043:notes:146]
|  |  |  | September 30, 2022 |
| Accounts receivable - net |  |  | $ | 199 |  |
| Inventories |  |  | 155 |  |
| Other current assets |  |  | 21 |  |
| Current assets held for sale |  |  | $ | 375 |  |
| Property, plant and equipment - net |  |  | $ | 89 |  |
| Goodwill |  |  | 22 |  |
| Other intangible assets - net |  |  | 514 |  |
| Other noncurrent assets |  |  | 72 |  |
| Noncurrent assets held for sale |  |  | $ | 697 |  |
| Accounts payable |  |  | $ | 127 |  |
| Accrued compensation and benefits |  |  | 25 |  |
| Deferred revenue |  |  | 36 |  |
| Other current liabilities |  |  | 33 |  |
| Current liabilities held for sale |  |  | $ | 221 |  |
| Other noncurrent liabilities |  |  | $ | 61 |  |
| Noncurrent liabilities held for sale |  |  | $ | 61 |  |

[0000833444-22-000043:notes:147]
During the third quarter of fiscal 2020, the Company determined that certain assets of the Building Solutions Asia Pacific segment met the criteria to be classified as held for sale. During the fourth quarter of fiscal 2022, the Company determined that these assets no longer met the criteria to be classified as held for sale as the Company can no longer assert that the sale of the assets is probable within a year due to the real estate market downturn in China that has worsened in the period after the COVID-19 lockdowns. As a result, the Company reclassified the held for sale assets to held and used as of September 30, 2022. Upon reclassification, an impairment of $45 million was recorded within restructuring and impairment costs in the consolidated statements of income to adjust the asset to the lower of its carrying value adjusted for depreciation and the fair value of the asset as of September 30, 2022.

[0000833444-22-000043:notes:148]
Discontinued Operations

[0000833444-22-000043:notes:149]
The Company completed the sale of its Power Solutions business on April 30, 2019. In December 2020, the favorable resolution of certain post-closing working capital and net debt adjustments resulted in  income from discontinued operations of $124 million, net of tax of $26 million, due to a reversal of a reserve established in connection with the sale.

[0000833444-22-000043:notes:150]
There was no Power Solutions related activity in fiscal 2022 and 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-22-000043:notes:151]
REVENUE RECOGNITION
Disaggregated Revenue

[0000833444-22-000043:notes:152]
The following table presents the Company's revenues disaggregated by segment and by products and systems versus services revenue (in millions):

[0000833444-22-000043:notes:153]
|  |  | Year Ended September 30, |
|  |  | 2022 |  | 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 5,708 |  |  | $ | 3,659 |  |  | $ | 9,367 |  |  | $ | 5,312 |  |  | $ | 3,373 |  |  | $ | 8,685 |  |
| Building Solutions EMEA/LA |  | 2,188 |  |  | 1,657 |  |  | 3,845 |  |  | 1,929 |  |  | 1,955 |  |  | 3,884 |  |
| Building Solutions Asia Pacific |  | 2,005 |  |  | 709 |  |  | 2,714 |  |  | 1,478 |  |  | 1,138 |  |  | 2,616 |  |
| Global Products |  | 9,373 |  |  | — |  |  | 9,373 |  |  | 8,483 |  |  | — |  |  | 8,483 |  |
| Total |  | $ | 19,274 |  |  | $ | 6,025 |  |  | $ | 25,299 |  |  | $ | 17,202 |  |  | $ | 6,466 |  |  | $ | 23,668 |  |

[0000833444-22-000043:notes:154]
The following table presents further disaggregation of Global Products revenues by product type (in millions):

[0000833444-22-000043:notes:155]
|  |  | Year Ended September 30, |
|  |  | 2022 |  | 2021 |
| HVAC |  | $ | 6,756 |  |  | $ | 6,054 |  |
| Fire & Security |  | 2,367 |  |  | 2,192 |  |
| Industrial Refrigeration |  | 250 |  |  | 237 |  |
| Total |  | $ | 9,373 |  |  | $ | 8,483 |  |

[0000833444-22-000043:notes:156]
Contract Balances

[0000833444-22-000043:notes:157]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed and consist of unbilled receivables and costs in excess of billings. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

[0000833444-22-000043:notes:158]
The following table presents the location and amount of contract balances in the Company's consolidated statements of financial position (in millions):

[0000833444-22-000043:notes:159]
|  |  |  |  | September 30, |  |  |
|  |  | Location of contract balances |  | 2022 |  | 2021 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,020 |  |  | $ | 1,718 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 79 |  |  | 99 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,768) |  |  | (1,637) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (282) |  |  | (269) |  |  |  |

[0000833444-22-000043:notes:160]
The Company recognized revenue that was included in the beginning of period contract liability balance of approximately $1.5 billion and $1.2 billion for the years ended September 30, 2022 and 2021, respectively.

[0000833444-22-000043:notes:161]
Performance Obligations

[0000833444-22-000043:notes:162]
A performance obligation is a distinct good, service, or bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

[0000833444-22-000043:notes:163]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of September 30, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $17.5 billion, of which approximately 65% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with average initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-22-000043:notes:164]
Costs to Obtain or Fulfill a Contract

[0000833444-22-000043:notes:165]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and bid/proposal costs. Costs to obtain or fulfill a contract are capitalized and amortized to revenue over the period of contract performance.

[0000833444-22-000043:notes:166]
The following table presents the location and amount of costs to obtain or fulfill a contract recorded in the Company's consolidated statements of financial position (in millions):

[0000833444-22-000043:notes:167]
|  |  | September 30, |  |  |
|  |  | 2022 |  | 2021 |  |  |
| Other current assets |  | $ | 139 |  |  | $ | 149 |  |  |  |
| Other noncurrent assets |  | 174 |  |  | 117 |  |  |  |
| Total |  | $ | 313 |  |  | $ | 266 |  |  |  |

[0000833444-22-000043:notes:168]
Amortization related to costs to obtain or fulfill a contract were $191 million and $173 million during the years ended September 30, 2022 and 2021, respectively. There were no impairment losses recognized in the year ended September 30, 2022 or 2021.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0000833444-22-000043:notes:169]
ACCOUNTS RECEIVABLE
Accounts receivable, net consisted of the following (in millions):

[0000833444-22-000043:notes:170]
|  |  | September 30, |  |  |
|  |  | 2022 |  | 2021 |  |  |
| Accounts receivable |  | $ | 5,590 |  |  | $ | 5,723 |  |  |  |
| Less: Allowance for expected credit losses |  | (62) |  |  | (110) |  |  |  |
| Accounts receivable, net |  | $ | 5,528 |  |  | $ | 5,613 |  |  |  |

[0000833444-22-000043:notes:171]
The changes in the allowance for expected credit losses related to accounts receivable were as follows (in millions):

[0000833444-22-000043:notes:172]
|  |  | Year Ended September 30, 2022 |
|  |  | 2022 |  | 2021 |
| Balance at beginning of period |  | $ | 110 |  |  | $ | 173 |  |
| Benefit for expected credit losses |  | (2) |  |  | (3) |  |
| Write-offs charged against the allowance for expected credit losses |  | (38) |  |  | (65) |  |
| Currency translation |  | (3) |  |  | 1 |  |
| Other |  | (5) |  |  | 4 |  |
| Balance at end of period |  | $ | 62 |  |  | $ | 110 |  |

[0000833444-22-000043:notes:173]
The Company sold receivables where it collected customer payments related to the factored receivables on behalf of the financial institution but otherwise maintained no continuing involvement totaling $1,115 million and $129 million during the years ended September 30, 2022 and 2021, respectively.  The costs of factoring such receivables were not material. Outstanding 
receivables sold under the factoring agreements were $476 million as of September 30, 2022 and $127 million as of September 30, 2021.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-22-000043:notes:174]
INVENTORIES
Inventories consisted of the following (in millions):

[0000833444-22-000043:notes:175]
|  | September 30, |
|  | 2022 |  | 2021 |
| Raw materials and supplies | $ | 1,009 |  |  | $ | 769 |  |
| Work-in-process | 196 |  |  | 166 |  |
| Finished goods | 1,305 |  |  | 1,122 |  |
| Inventories | $ | 2,510 |  |  | $ | 2,057 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-22-000043:notes:176]
PROPERTY, PLANT AND EQUIPMENT
Property, plant and equipment consisted of the following (in millions):

[0000833444-22-000043:notes:177]
|  | September 30, |
|  | 2022 |  | 2021 |
| Buildings and improvements | $ | 1,300 |  |  | $ | 1,313 |  |
| Subscriber systems | 733 |  |  | 802 |  |
| Machinery and equipment | 3,550 |  |  | 3,669 |  |
| Construction in progress | 512 |  |  | 500 |  |
| Land | 196 |  |  | 231 |  |
| Total property, plant and equipment | 6,291 |  |  | 6,515 |  |
| Less: Accumulated depreciation | (3,249) |  |  | (3,287) |  |
| Property, plant and equipment - net | $ | 3,042 |  |  | $ | 3,228 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-22-000043:notes:178]
GOODWILL AND OTHER INTANGIBLE ASSETS
Effective October 1, 2021, the Company's marine businesses previously included in the Building Solutions Asia Pacific and Global Products reportable segments became part of the Building Solutions EMEA/LA reportable segment. Historical information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation or the allocation of goodwill.

[0000833444-22-000043:notes:179]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments were as follows (in millions):

[0000833444-22-000043:notes:180]
|  | September 30, 2020 |  | BusinessAcquisitions |  | BusinessDivestitures |  | Impairments |  | Currency Translation and Other |  | September 30, 2021 |
| Building Solutions North America | $ | 9,160 |  |  | $ | 21 |  |  | $ | — |  |  | $ | — |  |  | $ | 34 |  |  | $ | 9,215 |  |
| Building Solutions EMEA/LA | 1,987 |  |  | 35 |  |  | — |  |  | — |  |  | 19 |  |  | 2,041 |  |
| Building Solutions Asia Pacific | 1,223 |  |  | — |  |  | (7) |  |  | — |  |  | 21 |  |  | 1,237 |  |
| Global Products | 5,562 |  |  | 244 |  |  | — |  |  | — |  |  | 36 |  |  | 5,842 |  |
| Total | $ | 17,932 |  |  | $ | 300 |  |  | $ | (7) |  |  | $ | — |  |  | $ | 110 |  |  | $ | 18,335 |  |
|  | September 30, 2021 |  | BusinessAcquisitions |  | BusinessDivestitures (1) |  | Impairments |  | Currency Translation and Other |  | September 30, 2022 |
| Building Solutions North America | $ | 9,215 |  |  | $ | 37 |  |  | $ | — |  |  | $ | (235) |  |  | $ | (46) |  |  | $ | 8,971 |  |
| Building Solutions EMEA/LA | 2,041 |  |  | 78 |  |  | (98) |  |  | — |  |  | (296) |  |  | 1,725 |  |
| Building Solutions Asia Pacific | 1,237 |  |  | 44 |  |  | (29) |  |  | — |  |  | (136) |  |  | 1,116 |  |
| Global Products | 5,842 |  |  | 60 |  |  | — |  |  | (75) |  |  | (311) |  |  | 5,516 |  |
| Total | $ | 18,335 |  |  | $ | 219 |  |  | $ | (127) |  |  | $ | (310) |  |  | $ | (789) |  |  | $ | 17,328 |  |

[0000833444-22-000043:notes:181]
(1) Business divestitures include $93 million and $29 million of goodwill within the Building Solutions EMEA/LA and Building Solutions Asia Pacific reportable segments, respectively, transferred to noncurrent assets held for sale on the consolidated statements of financial position.

[0000833444-22-000043:notes:182]
As of September 30, 2022, the accumulated impairment loss totaled $781 million, of which $659 million related to the Building Solutions North America segment, $75 million related to the Global Products segment and $47 million related to the Building Solutions EMEA/LA segment.

[0000833444-22-000043:notes:183]
As of September 30, 2021 and 2020, the accumulated impairment loss totaled $471 million, of which $424 million related to the Building Solutions North America segment and $47 million related to the Building Solutions EMEA/LA segment.

[0000833444-22-000043:notes:184]
The Company reviews goodwill for impairment annually as of July 31 or more frequently if events or changes in circumstances indicate the asset might be impaired. During its fiscal 2022 annual impairment test, the Company determined that its Silent-Aire reporting unit's goodwill was impaired. As a result, the Company recorded a non-cash impairment charge of $75 million within restructuring and impairment costs in the consolidated statements of income in the fourth quarter of fiscal 2022, which was determined by comparing the carrying amount of the reporting unit to its fair value. The Silent-Aire reporting unit has a remaining goodwill balance of $183 million at September 30, 2022. The Company used a discounted cash flow model to estimate the fair value of the reporting unit. The primary assumptions used in the model were management's internal projections of future cash flows, the weighted-average cost of capital and long-term growth rates, which are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying business, there was significant judgment in determining the expected future cash flows attributable to the Silent-Aire reporting unit. Other than the Silent-Aire reporting unit that is recorded at fair value, no other reporting unit was determined to be at risk of failing the goodwill impairment test.

[0000833444-22-000043:notes:185]
In the second quarter of fiscal 2022, the Company concluded it had a triggering event requiring assessment of goodwill impairment for its North America Retail reporting unit in conjunction with classifying its Global Retail business as held for sale. Refer to Note 3, "Discontinued Operations & Assets and Liabilities Held for Sale," of the notes to the consolidated financial statements for further disclosure related to the Global Retail assets held for sale. As a result, the Company recorded a non-cash impairment charge of $235 million within restructuring and impairment costs in the consolidated statements of

[0000833444-22-000043:notes:186]
income in the second quarter of fiscal 2022. The North America Retail reporting unit has no remaining goodwill balance as of September 30, 2022. The Company used the market approach to estimate the fair value of the reporting unit based on the relative estimated sales proceeds for the planned disposal of the Global Retail business attributable to the North America Retail reporting unit. The inputs utilized in the analysis are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-22-000043:notes:187]
There were no other triggering events requiring that an impairment assessment be conducted in fiscal 2022.

[0000833444-22-000043:notes:188]
There were no goodwill impairments resulting from the fiscal 2021 and the fiscal 2020 annual impairment test and no reporting unit was determined to be at risk of failing the goodwill impairment test as of September 30, 2021.

[0000833444-22-000043:notes:189]
During fiscal 2020, the Company considered the deterioration in general economic and market conditions due to the COVID-19 pandemic and its impact on each of the Company’s reporting units’ performance. Due to declines in cash flow projections of the North America Retail reporting unit in the third quarter of fiscal 2020 as a result of the COVID-19 pandemic, the Company concluded a triggering event occurred requiring assessment of impairment for its North America Retail reporting unit. As a result, the Company recorded a non-cash impairment charge of $424 million within restructuring and impairment costs in the consolidated statements of income in the third quarter of fiscal 2020. The North America Retail reporting unit had a remaining goodwill balance of $235 million at September 30, 2021. The Company used a discounted cash flow model to estimate the fair value of the reporting unit. The primary assumptions used in the model were management's internal projections of future cash flows, the weighted-average cost of capital and long-term growth rates, which are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-22-000043:notes:190]
The Company’s other intangible assets, primarily from business acquisitions, consisted of (in millions):

[0000833444-22-000043:notes:191]
|  | September 30, |
|  | 2022 |  | 2021 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,353 |  |  | $ | (658) |  |  | $ | 695 |  |  | $ | 1,464 |  |  | $ | (629) |  |  | $ | 835 |  |
| Customer relationships | 2,742 |  |  | (1,254) |  |  | 1,488 |  |  | 3,097 |  |  | (1,191) |  |  | 1,906 |  |
| Miscellaneous | 756 |  |  | (386) |  |  | 370 |  |  | 750 |  |  | (354) |  |  | 396 |  |
|  | 4,851 |  |  | (2,298) |  |  | 2,553 |  |  | 5,311 |  |  | (2,174) |  |  | 3,137 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/tradenames | 2,088 |  |  | — |  |  | 2,088 |  |  | 2,332 |  |  | — |  |  | 2,332 |  |
| Miscellaneous | — |  |  | — |  |  | — |  |  | 80 |  |  | — |  |  | 80 |  |
|  | 2,088 |  |  | — |  |  | 2,088 |  |  | 2,412 |  |  | — |  |  | 2,412 |  |
| Total intangible assets | $ | 6,939 |  |  | $ | (2,298) |  |  | $ | 4,641 |  |  | $ | 7,723 |  |  | $ | (2,174) |  |  | $ | 5,549 |  |

[0000833444-22-000043:notes:192]
The Company reviews indefinite-lived intangible assets for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired.

[0000833444-22-000043:notes:193]
There were no indefinite-lived intangible asset impairments resulting from the fiscal 2022, 2021 and 2020 annual impairment tests. However, it is possible that future changes in circumstances would require the Company to record non-cash impairment charges. For fiscal 2022, the estimated fair values of all indefinite-lived intangibles substantially exceeded their carrying values, with the exception of the indefinite-lived trademarks related to the Company's Asia Pacific subscriber business. The estimated fair value for the Asia Pacific indefinite-lived trademark was consistent with its carrying value of $54 million.

[0000833444-22-000043:notes:194]
During the second and third quarters of fiscal 2020, the Company determined that it had a triggering event at each reporting period end requiring assessment of impairment for certain of its indefinite-lived intangible assets due to declines in revenue directly attributable to the COVID-19 pandemic. As a result, the Company recorded an impairment charge of $62 million related primarily to the Company's retail business indefinite-lived intangible assets within restructuring and impairment costs in the consolidated statements of income in the second quarter of fiscal 2020. No further impairment was required to be recorded in the third quarter of fiscal 2020 as a result of the completed impairment assessment.

[0000833444-22-000043:notes:195]
Amortization of other intangible assets included within continuing operations for the years ended September 30, 2022, 2021 and 2020 was $427 million, $435 million and $386 million, respectively.

[0000833444-22-000043:notes:196]
The following table summarizes the expected amortization of definite-lived intangible assets, excluding the impact of future acquisitions, by year (in millions):

[0000833444-22-000043:notes:197]
| 2023 |  | $ | 414 |  |
| 2024 |  | 406 |
| 2025 |  | 382 |
| 2026 |  | 317 |
| 2027 |  | 282 |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-22-000043:notes:198]
LEASES
The following table presents the Company’s lease costs (in millions):

[0000833444-22-000043:notes:199]
|  |  | Year Ended September 30, |  |
|  |  | 2022 |  | 2021 |  | 2020 |  |
| Operating lease cost |  | $ | 352 |  |  | $ | 384 |  |  | $ | 399 |  |  |
| Variable lease cost |  | 165 |  |  | 130 |  |  | 145 |  |  |
| Total lease costs |  | $ | 517 |  |  | $ | 514 |  |  | $ | 544 |  |  |

[0000833444-22-000043:notes:200]
The following table presents supplemental consolidated statement of financial position information (in millions):

[0000833444-22-000043:notes:201]
|  |  |  | September 30, |
|  | Location of lease balances |  | 2022 |  | 2021 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,271 |  |  | $ | 1,376 |  |
| Operating lease liabilities - current | Other current liabilities |  | 280 |  |  | 319 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 987 |  |  | 1,055 |  |
| Weighted-average remaining lease term |  |  | 7 years |  | 7 years |
| Weighted-average discount rate |  |  | 2.1 | % |  | 1.8 | % |

[0000833444-22-000043:notes:202]
The following table presents supplemental cash flow information related to operating leases (in millions):

[0000833444-22-000043:notes:203]
|  |  | Year Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Cash paid for amounts included in the measurement of lease liability: |  |  |  |  |  |  |
| Operating cash outflows from operating leases |  | $ | 367 |  |  | $ | 398 |  |  | $ | 397 |  |
| Noncash operating lease activity: |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  | 369 |  |  | 515 |  |  | 467 |  |

[0000833444-22-000043:notes:204]
The following table presents maturities of operating lease liabilities (in millions):

[0000833444-22-000043:notes:205]
|  |  | September 30, 2022 |
| 2023 |  | $ | 301 |  |
| 2024 |  | 269 |  |
| 2025 |  | 203 |  |
| 2026 |  | 149 |  |
| 2027 |  | 109 |  |
| After 2027 |  | 345 |  |
| Total operating lease payments |  | 1,376 |  |
| Less: Interest |  | (109) |  |
| Present value of lease payments |  | $ | 1,267 |  |


## us-gaap:LeaseCostTableTextBlock

[0000833444-22-000043:notes:206]
The following table presents the Company’s lease costs (in millions):


## us-gaap:DebtDisclosureTextBlock

[0000833444-22-000043:notes:207]
DEBT AND FINANCING ARRANGEMENTS
Short-term debt consisted of the following (in millions):

[0000833444-22-000043:notes:208]
|  | September 30, |
|  | 2022 |  | 2021 |
| Bank borrowings | $ | 10 |  |  | $ | 8 |  |
| Commercial paper | 172 |  |  | — |  |
| Term loans | 487 |  |  | — |  |
|  | $ | 669 |  |  | $ | 8 |  |
| Weighted average interest rate on short-term debt outstanding | 0.5 | % |  | 0.2 | % |

[0000833444-22-000043:notes:209]
As of September 30, 2022, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2022. There were no draws on the facilities as of September 30, 2022.

[0000833444-22-000043:notes:210]
Long-term debt consisted of the following (in millions; due dates by fiscal year):

[0000833444-22-000043:notes:211]
|  | September 30, |
|  | 2022 |  | 2021 |
| Unsecured notes |  |  |  |
| JCI plc - Term Loan -¥25 billion; LIBOR JPY plus 0.40% due in 2022 | $ | — |  |  | $ | 223 |  |
| JCI plc - 4.625% due in 2023 ($25 million par value) | 25 |  |  | 25 |  |
| Tyco International Finance S.A. ("TIFSA") - 4.625% due in 2023 ($7 million par value) | 7 |  |  | 7 |  |
| JCI plc - 1.00% due in 2023 (€846 million par value) | 830 |  |  | 980 |  |
| JCI plc - 3.625% due in 2024 ($453 million par value) | 453 |  |  | 453 |  |
| JCI Inc. - 3.625% due in 2024 ($31 million par value) | 31 |  |  | 31 |  |
| JCI plc - 1.375% due in 2025 (€423 million par value) | 419 |  |  | 496 |  |
| TIFSA - 1.375% due in 2025 (€54 million par value) | 53 |  |  | 63 |  |
| JCI plc - 3.90% due in 2026 ($487 million par value) | 505 |  |  | 510 |  |
| TIFSA - 3.90% due in 2026 ($51 million par value) | 51 |  |  | 51 |  |
| JCI plc - Term Loan - ¥30 billion; TORF plus 0.40% due in 2027 | 208 |  |  | — |  |
| JCI plc and Tyco Fire & Security Finance S.C.A. ("TFSCA") - 0.375% due in 2027 (€500 million par value) | 488 |  |  | 577 |  |
| JCI plc and TFSCA - 3.00% due in 2028 (€600 million par value) | 586 |  |  | — |  |
| JCI plc and TFSCA - 1.75% due in 2030 ($625 million par value) | 623 |  |  | 623 |  |
| JCI plc and TFSCA - 2.00% due in 2031 ($500 million par value) | 496 |  |  | 496 |  |
| JCI plc and TFSCA - 1.00% due in 2032 (€500 million par value) | 489 |  |  | 578 |  |
| JCI plc and TFSCA - 4.90% due in 2032 ($400 million par value) | 394 |  |  | — |  |
| JCI plc - 6.00% due in 2036 ($342 million par value) | 339 |  |  | 339 |  |
| JCI Inc. - 6.00% due in 2036 ($8 million par value) | 8 |  |  | 8 |  |
| JCI plc - 5.70% due in 2041 ($190 million par value) | 189 |  |  | 189 |  |
| JCI Inc. - 5.70% due in 2041 ($30 million par value) | 30 |  |  | 30 |  |
| JCI plc - 5.25% due in 2042 ($155 million par value) | 155 |  |  | 155 |  |
| JCI Inc. - 5.25% due in 2042 ($6 million par value) | 6 |  |  | 6 |  |
| JCI plc - 4.625% due in 2044 ($444 million par value) | 441 |  |  | 441 |  |
| JCI Inc. - 4.625% due in 2044 ($6 million par value) | 6 |  |  | 6 |  |
| JCI plc - 5.125% due in 2045 ($477 million par value) | 557 |  |  | 560 |  |
| TIFSA - 5.125% due in 2045 ($23 million par value) | 23 |  |  | 22 |  |
| JCI plc - 6.95% due in 2046 ($32 million par value) | 32 |  |  | 32 |  |
| JCI Inc. - 6.95% due in 2046 ($4 million par value) | 4 |  |  | 4 |  |
| JCI plc - 4.50% due in 2047 ($500 million par value) | 496 |  |  | 496 |  |
| JCI plc - 4.95% due in 2064 ($341 million par value) | 340 |  |  | 340 |  |
| JCI Inc. - 4.95% due in 2064 ($15 million par value) | 15 |  |  | 15 |  |
| Other | 25 |  |  | 8 |  |
| Gross long-term debt | 8,324 |  |  | 7,764 |  |
| Less: current portion | 865 |  |  | 226 |  |
| Less: debt issuance costs | 33 |  |  | 32 |  |
| Long-term debt | $ | 7,426 |  |  | $ | 7,506 |  |

[0000833444-22-000043:notes:212]
The following table presents maturities of long-term debt as of September 30, 2022 (in millions):

[0000833444-22-000043:notes:213]
| 2023 |  | $ | 865 |  |
| 2024 |  | 485 |  |
| 2025 |  | 473 |  |
| 2026 |  | 557 |  |
| 2027 |  | 697 |  |
| After 2027 |  | 5,247 |  |
| Total |  | $ | 8,324 |  |

[0000833444-22-000043:notes:214]
As of September 30, 2022, the Company was in compliance with all financial covenants set forth in its credit agreements and the indentures governing its outstanding notes, and expects to remain in compliance for the foreseeable future.

[0000833444-22-000043:notes:215]
Total interest paid on both short and long-term debt for the years ended September 30, 2022, 2021 and 2020 was $226 million, $242 million and $247 million, respectively.

[0000833444-22-000043:notes:216]
Financing Arrangements

[0000833444-22-000043:notes:217]
In November 2021, the Company entered into a €200 million ($196 million as of September 30, 2022) bank term loan which had an interest rate of EURIBOR plus 0.5% and was due in October 2022.

[0000833444-22-000043:notes:218]
In March 2022, the Company entered into two bank term loans totaling €285 million ($280 million as of September 30, 2022) which both have an interest rate of EURIBOR plus 0.5% and are due in March 2023.

[0000833444-22-000043:notes:219]
In September 2022, the Company and its wholly owned subsidiary, TFSCA issued €600 million ($589 million as of September 30, 2022) of bonds with an interest rate of 3.0%, which are due in September 2028 and $400 million of bonds with an interest rate of 4.9%, which are due in December 2032.

[0000833444-22-000043:notes:220]
In September 2022, the Company repaid a ¥25 billion ($181 million) term loan and entered into a ¥30 billion ($208 million as of September 30, 2022) term loan which is due in September 2027. The new ¥30 billion loan has an interest rate of TORF plus 0.4%. The original ¥25 billion loan had an interest rate of LIBOR JPY plus 0.4%.

[0000833444-22-000043:notes:221]
Net Financing Charges

[0000833444-22-000043:notes:222]
The Company's net financing charges line item in the consolidated statements of income contained the following components (in millions):

[0000833444-22-000043:notes:223]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Interest expense, net of capitalized interest costs | $ | 225 |  |  | $ | 219 |  |  | $ | 240 |  |
| Other financing charges | 27 |  |  | 25 |  |  | 26 |  |
| Interest income | (6) |  |  | (9) |  |  | (23) |  |
| Net foreign exchange results for financing activities | (33) |  |  | (29) |  |  | (12) |  |
| Net financing charges | $ | 213 |  |  | $ | 206 |  |  | $ | 231 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-22-000043:notes:224]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES
Cash Flow Hedges

[0000833444-22-000043:notes:225]
The Company has global operations and participates in foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange forward contracts. The Company hedges 70% to 90% of the notional amount of each of its known foreign exchange transactional exposures.

[0000833444-22-000043:notes:226]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of copper and aluminum in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-22-000043:notes:227]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the years ended September 30, 2022 and 2021.

[0000833444-22-000043:notes:228]
The Company had the following outstanding contracts to hedge forecasted commodity purchases (in metric tons):

[0000833444-22-000043:notes:229]
|  |  | Volume Outstanding as of September 30, |
| Commodity |  | 2022 |  | 2021 |
| Copper |  | 3,629 |  |  | 2,656 |  |
| Aluminum |  | 6,758 |  |  | 5,159 |  |

[0000833444-22-000043:notes:230]
The Company enters into forward-starting interest rate swaps in conjunction with anticipated note issuances.  The following table summarizes forward-starting interest rate swaps and the related anticipated note issuances (in millions):

[0000833444-22-000043:notes:231]
|  |  | Year Ended September 30, |
|  | 2022 |  | 2021 |
| US dollar denominated |  |  |  |  |
| Forward-starting interest swaps |  | $ | 300 |  |  | $ | 500 |  |
| Anticipated note issuance |  | 400 |  |  | 500 |  |
| Euro denominated |  |  |  |  |
| Forward-starting interest swap |  | € | 200 |  |  | — |  |
| Anticipated note issuance |  | 600 |  |  | — |  |

[0000833444-22-000043:notes:232]
All of the forward-starting interest swaps were terminated when the anticipated notes were issued and none were outstanding at September 30, 2022. Accumulated amounts recorded in AOCI as of the date of the note issuance are amortized to interest expense over the life of the related note to reflect the difference between the swap's reference rate and the fixed rate of the note.

[0000833444-22-000043:notes:233]
Net Investment Hedges

[0000833444-22-000043:notes:234]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company’s net investments globally.

[0000833444-22-000043:notes:235]
The following table summarizes net investment hedges (in billions):

[0000833444-22-000043:notes:236]
|  |  | September 30, |
|  | 2022 |  | 2021 |
| Euro-denominated bonds designated as net investment hedges in Europe |  | € | 2.9 |  |  | € | 2.3 |  |
| Yen-denominated debt designated as a net investment hedge in Japan |  | ¥ | 30 |  |  | ¥ | 25 |  |

[0000833444-22-000043:notes:237]
Derivatives Not Designated as Hedging Instruments

[0000833444-22-000043:notes:238]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount. The Company hedged approximately 0.3 million ordinary shares, which had a cost basis of $23 million, as of September 30, 2021.  No shares were hedged as of September 30, 2022.

[0000833444-22-000043:notes:239]
The Company also holds certain foreign currency forward contracts not designated as hedging instruments under ASC 815 to hedge foreign currency exposure resulting from monetary assets and liabilities denominated in nonfunctional currencies. The changes in fair value of these foreign currency exchange derivatives are recorded in the consolidated statements of income where they offset foreign currency transactional gains and losses on the nonfunctional currency denominated assets and liabilities being hedged.

[0000833444-22-000043:notes:240]
Fair Value of Derivative Instruments

[0000833444-22-000043:notes:241]
The following table presents the location and fair values of derivative instruments and hedging activities included in the Company’s consolidated statements of financial position (in millions):

[0000833444-22-000043:notes:242]
|  | Designated as Hedging Instruments |  | Not Designatedas Hedging Instruments |
|  | September 30, 2022 |  | September 30, 2021 |  | September 30, 2022 |  | September 30, 2021 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 30 |  |  | $ | 15 |  |  | $ | 24 |  |  | $ | 17 |  |
| Commodity derivatives | — |  |  | 2 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | — |  |  | 23 |  |
| Total assets | $ | 30 |  |  | $ | 17 |  |  | $ | 24 |  |  | $ | 40 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 24 |  |  | $ | 11 |  |  | $ | 27 |  |  | $ | 6 |  |
| Commodity derivatives | 10 |  |  | 1 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,077 |  |  | 2,918 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,111 |  |  | $ | 2,930 |  |  | $ | 27 |  |  | $ | 6 |  |

[0000833444-22-000043:notes:243]
Counterparty Credit Risk

[0000833444-22-000043:notes:244]
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with substantially all of its counterparties. The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position.

[0000833444-22-000043:notes:245]
The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-22-000043:notes:246]
The gross and net amounts of derivative assets and liabilities were as follows (in millions):

[0000833444-22-000043:notes:247]
|  | Fair Value of Assets |  | Fair Value of Liabilities |
|  | September 30, 2022 |  | September 30, 2021 |  | September 30, 2022 |  | September 30, 2021 |  |
| Gross amount recognized | $ | 54 |  |  | $ | 57 |  |  | $ | 3,138 |  |  | $ | 2,936 |  |  |
| Gross amount eligible for offsetting | (42) |  |  | (16) |  |  | (42) |  |  | (16) |  |  |
| Net amount | $ | 12 |  |  | $ | 41 |  |  | $ | 3,096 |  |  | $ | 2,920 |  |  |

[0000833444-22-000043:notes:248]
Derivatives Impact on the Statements of Income and Statements of Comprehensive Income

[0000833444-22-000043:notes:249]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges (in millions):

[0000833444-22-000043:notes:250]
| Derivatives in Cash Flow Hedging Relationships |  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Foreign currency exchange derivatives |  | $ | 26 |  |  | $ | 15 |  |  | $ | 1 |  |
| Commodity derivatives |  | (21) |  |  | 4 |  |  | 6 |  |
| Interest rate swaps |  | 16 |  |  | (21) |  |  | — |  |
| Total |  | $ | 21 |  |  | $ | (2) |  |  | $ | 7 |  |

[0000833444-22-000043:notes:251]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income (in millions):

[0000833444-22-000043:notes:252]
| Derivatives in Cash FlowHedging Relationships |  | Location of Gain (Loss)Reclassified from AOCI into Income |  | Year Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 25 |  |  | $ | 11 |  |  | $ | (5) |  |
| Commodity derivatives |  | Cost of sales |  | (7) |  |  | 3 |  |  | 2 |  |
| Interest rate swaps |  | Net financing charges |  | (2) |  |  | — |  |  | — |  |
| Total |  |  |  | $ | 16 |  |  | $ | 14 |  |  | $ | (3) |  |

[0000833444-22-000043:notes:253]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income (in millions):

[0000833444-22-000043:notes:254]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2022 |  | 2021 |  | 2020 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 10 |  |  | $ | (6) |  |  | $ | (1) |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 85 |  |  | 174 |  |  | 87 |  |
| Foreign currency exchange derivatives |  | Selling, general and administrative |  | — |  |  | (2) |  |  | — |  |
| Foreign currency exchange derivatives |  | Income tax provision |  | — |  |  | (1) |  |  | — |  |
| Equity swap |  | Selling, general and administrative |  | (5) |  |  | 28 |  |  | (4) |  |
| Total |  |  |  | $ | 90 |  |  | $ | 193 |  |  | $ | 82 |  |

[0000833444-22-000043:notes:255]
Pre-tax gains (losses) on net investment hedges recorded as foreign currency translation adjustment ("CTA") within other comprehensive income (loss) were $470 million, $42 million and $(172) million for the years ended September 30, 2022, 2021 and 2020, respectively. No gains or losses were reclassified from CTA into income for the years ended September 30, 2022, 2021 and 2020.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-22-000043:notes:256]
FAIR VALUE MEASUREMENTS
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value (in millions):

[0000833444-22-000043:notes:257]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2022 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |
| Exchange traded funds (fixed income)1 | 22 |  |  | 22 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 46 |  |  | 46 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 86 |  |  | 86 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 131 |  |  | 131 |  |  | — |  |  | — |  |
| Total assets | $ | 339 |  |  | $ | 285 |  |  | $ | 54 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 51 |  |  | $ | — |  |  | $ | 51 |  |  | $ | — |  |
| Commodity derivatives | 10 |  |  | — |  |  | 10 |  |  | — |  |
| Contingent earn-out liabilities | 30 |  |  | — |  |  | — |  |  | 30 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 30 |  |  | — |  |  | — |  |  | 30 |  |
| Total liabilities | $ | 121 |  |  | $ | — |  |  | $ | 61 |  |  | $ | 60 |  |

[0000833444-22-000043:notes:258]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2021 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 32 |  |  | $ | — |  |  | $ | 32 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 63 |  |  | 63 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 146 |  |  | 146 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 168 |  |  | 168 |  |  | — |  |  | — |  |
| Equity swap | 23 |  |  | — |  |  | 23 |  |  | — |  |
| Total assets | $ | 434 |  |  | $ | 377 |  |  | $ | 57 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 17 |  |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Contingent earn-out liabilities | 32 |  |  | — |  |  | — |  |  | 32 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 50 |  |  | — |  |  | — |  |  | 50 |  |
| Total liabilities | $ | 100 |  |  | $ | — |  |  | $ | 18 |  |  | $ | 82 |  |

[0000833444-22-000043:notes:259]
1Classified as restricted investments for payment of asbestos liabilities. Refer to Note 21, "Commitments and Contingencies" of the notes to consolidated financial statements for further details.

[0000833444-22-000043:notes:260]
The following table summarizes the changes in contingent earn-out liabilities, which are valued using significant unobservable inputs (Level 3) (in millions):

[0000833444-22-000043:notes:261]
| Balance at September 30, 2021 | $ | 82 |  |  |
| Acquisitions | 29 |  |  |
| Payments | (5) |  |  |
| Reduction for change in estimates | (43) |  |  |
| Currency translation | (3) |  |  |
| Balance at September 30, 2022 | $ | 60 |  |  |

[0000833444-22-000043:notes:262]
Valuation Methods

[0000833444-22-000043:notes:263]
Foreign currency exchange derivatives: The foreign currency exchange derivatives are valued under a market approach using publicized spot and forward prices.

[0000833444-22-000043:notes:264]
Commodity derivatives: The commodity derivatives are valued under a market approach using publicized prices, where available, or dealer quotes.

[0000833444-22-000043:notes:265]
Equity swaps: The equity swaps are valued under a market approach as the fair value of the swaps is equal to the Company’s stock price at the reporting period date.

[0000833444-22-000043:notes:266]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. Unrealized gains (losses) on the deferred compensation plan assets are recognized in the consolidated statements of income where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-22-000043:notes:267]
Investments in exchange traded funds: Investments in exchange traded funds are valued using a market approach based on quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. Refer to Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-22-000043:notes:268]
Contingent earn-out liabilities:  The contingent earn-out liabilities are typically established using a Monte Carlo simulation based on the forecasted operating results and the earn-out formulas specified in the purchase agreements.

[0000833444-22-000043:notes:269]
The following table presents the portion of unrealized gains (losses) recognized in the consolidated statements of income that relate to equity securities still held at September 30, 2022 and 2021 (in millions):

[0000833444-22-000043:notes:270]
|  |  | Year Ended September 30, |  |
|  | 2022 |  | 2021 |  |
| Deferred compensation plan assets |  | $ | (10) |  |  | $ | 7 |  |  |
| Investments in exchange traded funds |  | (55) |  |  | 37 |  |  |

[0000833444-22-000043:notes:271]
All of the gains and losses on investments in exchange traded funds related to restricted investments. 
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. At September 30, 2022, the fair value of long-term debt was $7.3 billion, including public debt of $7.1 billion and other long-term debt of $0.2 billion. At September 30, 2021, the fair value of long-term debt was $8.5 billion, including public debt of $8.3 billion and other long-term debt of $0.2 billion. The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy.  The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-22-000043:notes:272]
STOCK-BASED COMPENSATION
On March 10, 2021, the shareholders of the Company approved the Johnson Controls International plc 2021 Equity and Incentive Plan, which terminated the Johnson Controls International plc 2012 Share and Incentive Plan, as amended in September 2016 (collectively, the "Plans"). Both Plans authorize stock options, stock appreciation rights, restricted (non-vested) stock/units, performance shares, performance units and other stock-based awards. The Compensation and Talent Development Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. As of September 30, 2022, there were 55 million shares of the Company's common stock reserved and 54 million shares available for issuance under the 2021 Equity and Incentive Plan.

[0000833444-22-000043:notes:273]
The following table summarizes stock-based compensation related charges and benefits (in millions):

[0000833444-22-000043:notes:274]
|  |  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Compensation expense |  | $ | 104 |  |  | $ | 97 |  |  | $ | 66 |  |
| Income tax benefit resulting from share-based compensation arrangements |  | 26 |  |  | 24 |  |  | 16 |  |
| Tax impact from exercise and vesting of equity settled awards |  | 12 |  |  | 12 |  |  | — |  |

[0000833444-22-000043:notes:275]
Compensation expense excludes the offsetting impact of equity swaps and is recorded in selling, general and administrative expenses. The Company does not settle stock options granted under share-based payment arrangements in cash.

[0000833444-22-000043:notes:276]
Restricted (Non-vested) Stock / Units

[0000833444-22-000043:notes:277]
A summary of non-vested restricted stock awards at September 30, 2022, and changes for the year then ended, is presented below:

[0000833444-22-000043:notes:278]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toRestriction |
| Non-vested, September 30, 2021 | $ | 44.06 |  |  | 3,334,437 |  |
| Granted | 74.63 |  |  | 1,508,550 |  |
| Vested | 42.52 |  |  | (1,497,497) |  |
| Forfeited | 56.58 |  |  | (396,296) |  |
| Non-vested, September 30, 2022 | $ | 58.78 |  |  | 2,949,194 |  |

[0000833444-22-000043:notes:279]
At September 30, 2022, the Company had approximately $107 million of total unrecognized compensation cost related to non-vested restricted stock arrangements granted for continuing operations which is expected to be recognized over a weighted-average period of 2.0 years.

[0000833444-22-000043:notes:280]
The following table summarizes the assumptions used in determining the fair value of stock options granted:

[0000833444-22-000043:notes:281]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Risk-free interest rate | 0.99% |  | 0.20% |  | 1.60% |
| Expected volatility of the Company’s stock | 30.00% |  | 30.90% |  | 21.80% |

[0000833444-22-000043:notes:282]
A summary of the status of the Company’s non-vested PSUs at September 30, 2022, and changes for the year then ended, is presented below:

[0000833444-22-000043:notes:283]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toPSU |
| Non-vested, September 30, 2021 | $ | 43.11 |  |  | 1,196,318 |  |
| Granted | 82.88 |  |  | 482,030 |  |
| Vested | 36.35 |  |  | (402,465) |  |
| Forfeited | 60.02 |  |  | (132,812) |  |
| Non-vested, September 30, 2022 | $ | 60.30 |  |  | 1,143,071 |  |

[0000833444-22-000043:notes:284]
At September 30, 2022, the Company had approximately $37 million of total unrecognized compensation cost related to non-vested performance-based share unit awards granted for continuing operations which is expected to be recognized over a weighted-average period of 1.7 years.

[0000833444-22-000043:notes:285]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Expected life of option (years) | 6.0 |  | 6.5 |  | 6.5 |
| Risk-free interest rate | 1.35% |  | 0.60% |  | 1.67% |
| Expected volatility of the Company’s stock | 27.80% |  | 27.60% |  | 22.40% |
| Expected dividend yield on the Company’s stock | 1.71% |  | 2.28% |  | 2.49% |

[0000833444-22-000043:notes:286]
A summary of stock option activity at September 30, 2022, and changes for the year then ended, is presented below:

[0000833444-22-000043:notes:287]
|  | WeightedAverageOption Price |  | SharesSubject toOption |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2021 | $ | 38.84 |  |  | 5,951,011 |  |  |  |  |  |
| Granted | 79.54 |  |  | 548,398 |  |  |  |  |  |
| Exercised | 33.77 |  |  | (542,903) |  |  |  |  |  |
| Forfeited or expired | 50.97 |  |  | (272,659) |  |  |  |  |  |
| Outstanding, September 30, 2022 | $ | 42.46 |  |  | 5,683,847 |  |  | 5.7 |  | $ | 52 |  |
| Exercisable, September 30, 2022 | $ | 37.86 |  |  | 4,082,897 |  |  | 4.1 |  | $ | 47 |  |

[0000833444-22-000043:notes:288]
The following table summarizes additional stock option information:

[0000833444-22-000043:notes:289]
|  |  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Weighted-average grant-date fair value of options granted |  | $ | 18.59 |  |  | $ | 9.36 |  |  | $ | 7.29 |  |
| Intrinsic value of options exercised (in millions) |  | 19 |  |  | 94 |  |  | 30 |  |

[0000833444-22-000043:notes:290]
At September 30, 2022, the Company had approximately $10 million of total unrecognized compensation cost related to non-vested stock options granted for continuing operations which is expected to be recognized over a weighted-average period of 1.6 years.


## us-gaap:EarningsPerShareTextBlock

[0000833444-22-000043:notes:291]
EARNINGS PER SHARE
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-22-000043:notes:292]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Income Available to Ordinary Shareholders |  |  |  |  |  |
| Income from continuing operations | $ | 1,532 |  |  | $ | 1,513 |  |  | $ | 631 |  |
| Income from discontinued operations | — |  |  | 124 |  |  | — |  |
| Basic and diluted income available to shareholders | $ | 1,532 |  |  | $ | 1,637 |  |  | $ | 631 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |
| Basic weighted average shares outstanding | 696.1 |  |  | 716.6 |  |  | 751.0 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 3.5 |  |  | 4.5 |  |  | 2.6 |  |
| Diluted weighted average shares outstanding | 699.6 |  |  | 721.1 |  |  | 753.6 |  |
| Antidilutive Securities |  |  |  |  |  |
| Stock options and unvested restricted stock | 0.4 |  |  | — |  |  | 1.4 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-22-000043:notes:293]
EQUITY
Dividends

[0000833444-22-000043:notes:294]
The authority to declare and pay dividends is vested in the Board of Directors. The timing, declaration and payment of future dividends to holders of the Company's ordinary shares is determined by the Company's Board of Directors and depends upon many factors, including the Company's financial condition and results of operations, the capital requirements of the Company's businesses, industry practice and any other relevant factors.

[0000833444-22-000043:notes:295]
Under Irish law, dividends may only be paid (and share repurchases and redemptions must generally be funded) out of "distributable reserves." The creation of distributable reserves was accomplished by way of a capital reduction, which the Irish High Court approved on December 18, 2014 and as acquired in conjunction with the Merger.

[0000833444-22-000043:notes:296]
Share Repurchase Program

[0000833444-22-000043:notes:297]
As of September 30, 2022, approximately $3.6 billion remained available under the share repurchase program which was approved by the Company's Board of Directors in March 2021. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice.

[0000833444-22-000043:notes:298]
The Company repurchased and retired its ordinary shares of approximately $1,441 million, $1,307 million and $2,204 million  during the years ended September 30, 2022, 2021 and 2020, respectively.

[0000833444-22-000043:notes:299]
Accumulated Other Comprehensive Income

[0000833444-22-000043:notes:300]
The following table includes changes in AOCI attributable to Johnson Controls (in millions, net of tax):

[0000833444-22-000043:notes:301]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Foreign currency translation adjustments |  |  |  |  |  |
| Balance at beginning of period | $ | (421) |  |  | $ | (778) |  |  | $ | (785) |  |
| Aggregate adjustment for the period (net of tax effect of $0, $0 and $1) | (480) |  |  | 357 |  |  | 7 |  |
| Balance at end of period | (901) |  |  | (421) |  |  | (778) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |  |  |
| Balance at beginning of period | (17) |  |  | 2 |  |  | (2) |  |
| Current period changes in fair value (net of tax effect of $2, $5 and $1) | 18 |  |  | (8) |  |  | 3 |  |
| Reclassification to income (net of tax effect of $(4), $(3) and $0) (1) | (12) |  |  | (11) |  |  | 1 |  |
| Balance at end of period | (11) |  |  | (17) |  |  | 2 |  |
| Pension and postretirement plans |  |  |  |  |  |
| Balance at beginning of period | 4 |  |  | — |  |  | (8) |  |
| Reclassification to income (net of tax effect of $0, $0 and $(1)) | (3) |  |  | (3) |  |  | (1) |  |
| Other changes (net of tax effect of $0, $(1) and $4) | — |  |  | 7 |  |  | 9 |  |
| Balance at end of period | 1 |  |  | 4 |  |  | — |  |
| Accumulated other comprehensive loss, end of period | $ | (911) |  |  | $ | (434) |  |  | $ | (776) |  |

[0000833444-22-000043:notes:302]
(1)   Refer to Note 11, "Derivative Instruments and Hedging Activities," of the notes to consolidated financial statements for disclosure of the line items in the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-22-000043:notes:303]
RETIREMENT PLANS
Pension Benefits

[0000833444-22-000043:notes:304]
The Company has non-contributory defined benefit pension plans covering certain U.S. and non-U.S. employees. The benefits provided are primarily based on years of service and average compensation or a monthly retirement benefit amount. Certain of the Company’s U.S. pension plans have been amended to prohibit new participants from entering the plans and no longer accrue benefits. Funding for U.S. pension plans equals or exceeds the minimum requirements of the Employee Retirement Income Security Act of 1974. Funding for non-U.S. plans observes the local legal and regulatory limits. Also, the Company makes contributions to union-trusteed pension funds for construction and service personnel.

[0000833444-22-000043:notes:305]
The following table includes information for pension plans with accumulated benefit obligations ("ABO") in excess of plan assets (in millions):

[0000833444-22-000043:notes:306]
|  |  | September 30, |  |
|  |  | 2022 |  | 2021 |  |
| Accumulated benefit obligation |  | $ | 2,004 |  |  | $ | 4,402 |  |  |
| Fair value of plan assets |  | 1,720 |  |  | 3,841 |  |  |

[0000833444-22-000043:notes:307]
The following table includes information for pension plans with projected benefit obligations ("PBO") in excess of plan assets (in millions):

[0000833444-22-000043:notes:308]
|  |  | September 30, |  |
|  |  | 2022 |  | 2021 |  |
| Projected benefit obligation |  | $ | 2,013 |  |  | $ | 4,519 |  |  |
| Fair value of plan assets |  | 1,729 |  |  | 3,954 |  |  |

[0000833444-22-000043:notes:309]
During the year ended September 30, 2022, total employer contributions to the defined benefit pension plans were $93 million, none of which were voluntary contributions made by the Company. The Company expects to contribute approximately $38 million in cash to its defined benefit pension plans in the year ended September 30, 2023. Projected benefit payments from the plans as of September 30, 2022 are estimated as follows (in millions):

[0000833444-22-000043:notes:310]
| 2023 | $ | 266 |  |
| 2024 | 248 |  |
| 2025 | 246 |  |
| 2026 | 245 |  |
| 2027 | 243 |  |
| 2028 - 2032 | 1,180 |  |

[0000833444-22-000043:notes:311]
Postretirement Benefits

[0000833444-22-000043:notes:312]
The Company provides certain health care and life insurance benefits for eligible retirees and their dependents primarily in the U.S. and Canada. Most non-U.S. employees are covered by government sponsored programs. The cost to the Company is not significant.

[0000833444-22-000043:notes:313]
Eligibility for coverage is based on meeting certain years of service and retirement age qualifications. These benefits may be subject to deductibles, co-payment provisions and other limitations. The Company has reserved the right to modify these benefits.

[0000833444-22-000043:notes:314]
The health care cost trend assumption does not have a significant effect on the amounts reported.

[0000833444-22-000043:notes:315]
The following table includes information for postretirement plans with accumulated postretirement benefit obligations ("APBO") in excess of plan assets (in millions):

[0000833444-22-000043:notes:316]
|  |  | September 30, |  |
|  |  | 2022 |  | 2021 |  |
| Accumulated postretirement benefit obligation |  | $ | 68 |  |  | $ | 96 |  |  |
| Fair value of plan assets |  | 28 |  |  | 38 |  |  |

[0000833444-22-000043:notes:317]
During the year ended September 30, 2022, total employer contributions to the postretirement plans were $3 million. The Company expects to contribute approximately $3 million in cash to its postretirement plans in the year ended September 30, 2023. Projected benefit payments from the plans as of September 30, 2022 are estimated as follows (in millions):

[0000833444-22-000043:notes:318]
| 2023 | $ | 11 |  |
| 2024 | 10 |  |
| 2025 | 10 |  |
| 2026 | 10 |  |
| 2027 | 9 |  |
| 2028 - 2032 | 31 |  |

[0000833444-22-000043:notes:319]
Defined Contribution Plans

[0000833444-22-000043:notes:320]
The Company sponsors various defined contribution savings plans that allow employees to contribute a portion of their pre-tax and/or after-tax income in accordance with plan specified guidelines. Under specified conditions, the Company will contribute to certain savings plans based on predetermined percentages of compensation earned by the employee and/or will match a percentage of the employee contributions up to certain limits. The Company temporarily suspended certain contributions in fiscal 2021 and 2020 in response to the COVID-19 pandemic. Defined contribution plan contributions charged to expense amounted to $196 million, $118 million and $104 million during the years ended September 30, 2022, 2021 and 2020, respectively.

[0000833444-22-000043:notes:321]
Multiemployer Benefit Plans

[0000833444-22-000043:notes:322]
The Company contributes to multiemployer benefit plans based on obligations arising from collective bargaining agreements related to certain of its hourly employees in the U.S. These plans provide retirement benefits to participants based on their service to contributing employers. The benefits are paid from assets held in trust for that purpose. The trustees typically are responsible for determining the level of benefits to be provided to participants as well as for such matters as the investment of the assets and the administration of the plans.

[0000833444-22-000043:notes:323]
The risks of participating in these multiemployer benefit plans are different from single-employer benefit plans in the following aspects:

[0000833444-22-000043:notes:324]
•Assets contributed to the multiemployer benefit plan by one employer may be used to provide benefits to employees of other participating employers.

[0000833444-22-000043:notes:325]
•If a participating employer stops contributing to the multiemployer benefit plan, the unfunded obligations of the plan may be borne by the remaining participating employers.

[0000833444-22-000043:notes:326]
•If the Company stops participating in some of its multiemployer benefit plans, the Company may be required to pay those plans an amount based on its allocable share of the underfunded status of the plan, referred to as a withdrawal liability.

[0000833444-22-000043:notes:327]
The Company participates in approximately 270 multiemployer benefit plans, none of which are individually significant to the Company. The number of employees covered by the Company’s multiemployer benefit plans has remained consistent over the past three years, and there have been no significant changes that affect the comparability of fiscal 2022, 2021 and 2020 contributions. The Company recognizes expense for the contractually-required contribution for each period. The Company contributed $71 million, $67 million and $66 million to multiemployer benefit plans during the years ended September 30, 2022, 2021 and 2020, respectively.

[0000833444-22-000043:notes:328]
Based on the most recent information available, the Company believes that the present value of actuarial accrued liabilities in certain of these multiemployer benefit plans may exceed the value of the assets held in trust to pay benefits. Currently, the Company is not aware of any significant multiemployer benefit plans for which it is probable or reasonably possible that the Company will be obligated to make up any shortfall in funds. Moreover, if the Company were to exit certain markets or otherwise cease making contributions to these funds, the Company could trigger a withdrawal liability. Currently, the Company is not aware of any multiemployer benefit plans for which it is probable or reasonably possible that the Company will have a significant withdrawal liability. Any accrual for a shortfall or withdrawal liability will be recorded when it is probable that a liability exists and it can be reasonably estimated.

[0000833444-22-000043:notes:329]
Plan Assets

[0000833444-22-000043:notes:330]
The Company’s investment policies employ an approach whereby a mix of equities, fixed income and alternative investments are used to maximize the long-term return of plan assets for a prudent level of risk. The investment portfolio primarily contains a diversified blend of equity and fixed income investments. Equity investments are diversified across U.S. and non-U.S. stocks, as well as growth, value and small to large capitalization. Fixed income investments include corporate and government issues, with short-, mid- and long-term maturities, with a focus on investment grade when purchased and a target duration close to that of the plan liability. Investment and market risks are measured and monitored on an ongoing basis through regular investment portfolio reviews, annual liability measurements and periodic asset/liability studies. The majority of the real estate component of the portfolio is invested in a diversified portfolio of high-quality, operating properties with cash yields greater than the targeted appreciation. Investments in other alternative asset classes, including hedge funds and commodities, diversify the expected investment returns relative to the equity and fixed income investments. As a result of the Company's diversification strategies, there are no significant concentrations of risk within the portfolio of investments.

[0000833444-22-000043:notes:331]
The Company’s actual asset allocations are in line with target allocations. The Company rebalances asset allocations as appropriate, in order to stay within a range of allocation for each asset category.

[0000833444-22-000043:notes:332]
The expected return on plan assets is based on the Company’s expectation of the long-term average rate of return of the capital markets in which the plans invest. The average market returns are adjusted, where appropriate, for active asset management returns. The expected return reflects the investment policy target asset mix and considers the historical returns earned for each asset category.

[0000833444-22-000043:notes:333]
The Company’s plan assets at September 30, 2022 and 2021, by asset category, are as follows (in millions):

[0000833444-22-000043:notes:334]
|  |  | Fair Value Measurements Using: |
| Asset Category |  | Total as of September 30, 2022 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 40 |  |  | $ | — |  |  | $ | 40 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Large-Cap |  | 160 |  |  | 160 |  |  | — |  |  | — |  |
| Small-Cap |  | 175 |  |  | 175 |  |  | — |  |  | — |  |
| International - Developed |  | 139 |  |  | 139 |  |  | — |  |  | — |  |
| International - Emerging |  | 39 |  |  | 39 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 217 |  |  | 216 |  |  | 1 |  |  | — |  |
| Corporate/Other |  | 804 |  |  | 804 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 1,574 |  |  | $ | 1,533 |  |  | $ | 41 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value(1) |  | 322 |  |  |  |  |  |  |  |
| Due to Broker |  | (166) |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 1,730 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 150 |  |  | $ | 150 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Large-Cap |  | 45 |  |  | 8 |  |  | 37 |  |  | — |  |
| International - Developed |  | 43 |  |  | 12 |  |  | 31 |  |  | — |  |
| International - Emerging |  | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 650 |  |  | 50 |  |  | 600 |  |  | — |  |
| Corporate/Other |  | 418 |  |  | 277 |  |  | 141 |  |  | — |  |
| Hedge Fund |  | 18 |  |  | — |  |  | 18 |  |  | — |  |
| Real Estate |  | 9 |  |  | 9 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 1,336 |  |  | $ | 506 |  |  | $ | 830 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value(1) |  | 97 |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 1,433 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 13 |  |  | $ | 13 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Global |  | 66 |  |  | — |  |  | 66 |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 79 |  |  | $ | 13 |  |  | $ | 66 |  |  | $ | — |  |
| Multi-Credit Strategy Investments Measured at Net Asset Value(1) |  | 65 |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 144 |  |  |  |  |  |  |  |

[0000833444-22-000043:notes:335]
|  |  | Fair Value Measurements Using: |
| Asset Category |  | Total as of September 30, 2021 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 75 |  |  | $ | — |  |  | $ | 75 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Large-Cap |  | 185 |  |  | 185 |  |  | — |  |  | — |  |
| Small-Cap |  | 215 |  |  | 215 |  |  | — |  |  | — |  |
| International - Developed |  | 182 |  |  | 182 |  |  | — |  |  | — |  |
| International - Emerging |  | 34 |  |  | 34 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 286 |  |  | 98 |  |  | 188 |  |  | — |  |
| Corporate/Other |  | 1,279 |  |  | 1,279 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 2,256 |  |  | $ | 1,993 |  |  | $ | 263 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value(1) |  | 280 |  |  |  |  |  |  |  |
| Due to Broker |  | (77) |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 2,459 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 151 |  |  | $ | 151 |  |  | $ | — |  |  | $ | — |  |
| Large-Cap |  | 197 |  |  | 23 |  |  | 174 |  |  | — |  |
| International - Developed |  | 128 |  |  | 30 |  |  | 98 |  |  | — |  |
| International - Emerging |  | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 1,123 |  |  | 77 |  |  | 1,046 |  |  | — |  |
| Corporate/Other |  | 597 |  |  | 320 |  |  | 277 |  |  | — |  |
| Hedge Fund |  | 27 |  |  | — |  |  | 27 |  |  | — |  |
| Real Estate |  | 14 |  |  | 14 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 2,239 |  |  | $ | 615 |  |  | $ | 1,624 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value(1) |  | 105 |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 2,344 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 5 |  |  | $ | 5 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Large-Cap |  | 24 |  |  | — |  |  | 24 |  |  | — |  |
| Small-Cap |  | 8 |  |  | — |  |  | 8 |  |  | — |  |
| International - Developed |  | 19 |  |  | — |  |  | 19 |  |  | — |  |
| International - Emerging |  | 12 |  |  | — |  |  | 12 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 20 |  |  | — |  |  | 20 |  |  | — |  |
| Corporate/Other |  | 56 |  |  | — |  |  | 56 |  |  | — |  |
| Commodities |  | 17 |  |  | — |  |  | 17 |  |  | — |  |
| Real Estate |  | 11 |  |  | — |  |  | 11 |  |  | — |  |
| Total Plan Assets |  | $ | 172 |  |  | $ | 5 |  |  | $ | 167 |  |  | $ | — |  |

[0000833444-22-000043:notes:336]
(1)The fair value of certain real estate and multi-credit strategy investments do not have a readily determinable fair value and require the fund managers to independently arrive at fair value by calculating net asset value ("NAV") per share. In order to

[0000833444-22-000043:notes:337]
calculate NAV per share, the fund managers value the investments using any one, or a combination of, the following methods: independent third party appraisals, discounted cash flow analysis of net cash flows projected to be generated by the investment and recent sales of comparable investments. Assumptions used to revalue the investments are updated every quarter. Due to the fact that the fund managers calculate NAV per share, the Company utilizes a practical expedient for measuring the fair value of its real estate and multi-credit strategy investments, as provided for under ASC 820, "Fair Value Measurement." In applying the practical expedient, the Company is not required to further adjust the NAV provided by the fund manager in order to determine the fair value of its investments as the NAV per share is calculated in a manner consistent with the measurement principles of ASC 946, "Financial Services - Investment Companies," and as of the Company's measurement date. The Company believes this is an appropriate methodology to obtain the fair value of these assets. For the component of the real estate portfolio under development, the investments are carried at cost until they are completed and valued by a third party appraiser. In accordance with ASU No. 2015-07, "Disclosures for Investments in Certain Entities That Calculate Net Asset Value per Share (or Its Equivalent)," investments for which fair value is measured using the net asset value per share practical expedient are disclosed separate from the fair value hierarchy. The fair value amounts presented in these tables are intended to permit reconciliation of total plan assets to the amounts presented in the notes to consolidated financial statements.

[0000833444-22-000043:notes:338]
The following is a description of the valuation methodologies used for assets measured at fair value. Certain assets are held within commingled funds which are valued at the unitized NAV or percentage of the net asset value as determined by the manager of the fund. These values are based on the fair value of the underlying net assets owned by the fund.

[0000833444-22-000043:notes:339]
Cash and Cash Equivalents: The fair value of cash and cash equivalents is valued at cost.

[0000833444-22-000043:notes:340]
Equity Securities: The fair value of equity securities is determined by direct quoted market prices. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-22-000043:notes:341]
Fixed Income Securities: The fair value of fixed income securities is determined by direct or indirect quoted market prices. If indirect quoted market prices are utilized, the value of assets held in separate accounts is not published, but the investment managers report daily the underlying holdings. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-22-000043:notes:342]
Commodities: The fair value of the commodities is determined by quoted market prices of the underlying holdings on regulated financial exchanges.

[0000833444-22-000043:notes:343]
Hedge Funds: The fair value of hedge funds is accounted for by the custodian. The custodian obtains valuations from underlying managers based on market quotes for the most liquid assets and alternative methods for assets that do not have sufficient trading activity to derive prices. The Company and custodian review the methods used by the underlying managers to value the assets. The Company believes this is an appropriate methodology to obtain the fair value of these assets.

[0000833444-22-000043:notes:344]
Real Estate: The fair value of real estate is determined by quoted market prices of the underlying Real Estate Investment Trusts

[0000833444-22-000043:notes:345]
("REITs"), which are securities traded on an open exchange.

[0000833444-22-000043:notes:346]
The methods described above may produce a fair value calculation that may not be indicative of net realizable value or reflective of future fair values. Furthermore, while the Company believes its valuation methods are appropriate and consistent with other market participants, the use of different methodologies or assumptions to determine the fair value of certain financial instruments could result in a different fair value measurement at the reporting date.

[0000833444-22-000043:notes:347]
There were no Level 3 assets as of September 30, 2022 or 2021 or any Level 3 asset activity during fiscal 2022 or 2021.

[0000833444-22-000043:notes:348]
Funded Status

[0000833444-22-000043:notes:349]
The following table contains the ABO and reconciliations of the changes in the PBO, the changes in plan assets and the funded status (in millions):

[0000833444-22-000043:notes:350]
|  | Pension Benefits |  | PostretirementBenefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| September 30, | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Accumulated Benefit Obligation | $ | 1,822 |  |  | $ | 2,629 |  |  | $ | 1,417 |  |  | $ | 2,540 |  |  | $ | 89 |  |  | $ | — |  |
| Change in Projected Benefit Obligation |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of year | $ | 2,629 |  |  | $ | 3,217 |  |  | $ | 2,625 |  |  | $ | 2,726 |  |  | $ | 123 |  |  | $ | 146 |  |
| Service cost | — |  |  | — |  |  | 20 |  |  | 27 |  |  | 1 |  |  | 1 |  |
| Interest cost | 56 |  |  | 47 |  |  | 39 |  |  | 32 |  |  | 2 |  |  | 2 |  |
| Plan participant contributions | — |  |  | — |  |  | 2 |  |  | 3 |  |  | 3 |  |  | 3 |  |
| Actuarial gain | (587) |  |  | (52) |  |  | (651) |  |  | (103) |  |  | (25) |  |  | (13) |  |
| Amendments made during the year | — |  |  | — |  |  | (1) |  |  | (6) |  |  | — |  |  | — |  |
| Benefits and settlements paid | (276) |  |  | (583) |  |  | (166) |  |  | (124) |  |  | (14) |  |  | (17) |  |
| Curtailment | — |  |  | — |  |  | — |  |  | (3) |  |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | (2) |  |  | (2) |  |  | — |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | (395) |  |  | 75 |  |  | (1) |  |  | 1 |  |
| Projected benefit obligation at end of year | $ | 1,822 |  |  | $ | 2,629 |  |  | $ | 1,471 |  |  | $ | 2,625 |  |  | $ | 89 |  |  | $ | 123 |  |
| Change in Plan Assets |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 2,459 |  |  | $ | 2,706 |  |  | $ | 2,344 |  |  | $ | 2,213 |  |  | $ | 172 |  |  | $ | 153 |  |
| Actual return on plan assets | (454) |  |  | 333 |  |  | (459) |  |  | 125 |  |  | (20) |  |  | 30 |  |
| Employer and employee contributions | 1 |  |  | 3 |  |  | 94 |  |  | 65 |  |  | 6 |  |  | 6 |  |
| Benefits paid | (85) |  |  | (108) |  |  | (74) |  |  | (79) |  |  | (14) |  |  | (17) |  |
| Settlement payments | (191) |  |  | (475) |  |  | (92) |  |  | (45) |  |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | (2) |  |  | (1) |  |  | — |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | (378) |  |  | 66 |  |  | — |  |  | — |  |
| Fair value of plan assets at end of year | $ | 1,730 |  |  | $ | 2,459 |  |  | $ | 1,433 |  |  | $ | 2,344 |  |  | $ | 144 |  |  | $ | 172 |  |
| Funded status | $ | (92) |  |  | $ | (170) |  |  | $ | (38) |  |  | $ | (281) |  |  | $ | 55 |  |  | $ | 49 |  |
| Amounts recognized in the statement of financial position consist of: |
| Prepaid benefit cost | $ | 37 |  |  | $ | 44 |  |  | $ | 151 |  |  | $ | 79 |  |  | $ | 95 |  |  | $ | 107 |  |
| Accrued benefit liability | (129) |  |  | (214) |  |  | (189) |  |  | (360) |  |  | (40) |  |  | (58) |  |
| Net amount recognized | $ | (92) |  |  | $ | (170) |  |  | $ | (38) |  |  | $ | (281) |  |  | $ | 55 |  |  | $ | 49 |  |
| Weighted Average Assumptions (1) |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate (2) | 5.08 | % |  | 2.50 | % |  | 4.36 | % |  | 1.80 | % |  | 4.92 | % |  | 2.30 | % |
| Rate of compensation increase | N/A |  | N/A |  | 3.00 | % |  | 2.85 | % |  | N/A |  | N/A |
| Interest crediting rate | N/A |  | N/A |  | 1.69 | % |  | 1.45 | % |  | N/A |  | N/A |

[0000833444-22-000043:notes:351]
(1)Plan assets and obligations are determined based on a September 30 measurement date at September 30, 2022 and 2021.

[0000833444-22-000043:notes:352]
(2 The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension and postretirement plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for

[0000833444-22-000043:notes:353]
determining the various discount rates. The Company has elected to utilize a full yield curve approach in the estimation of service and interest components of net periodic benefit cost (credit) for pension and other postretirement for plans that utilize a yield curve approach. The full yield curve approach applies the specific spot rates along the yield curve used in the determination of the benefit obligation to the relevant projected cash flows.

[0000833444-22-000043:notes:354]
The fiscal 2022 and fiscal 2021 net actuarial gains related to changes in the projected benefit obligation were primarily the result of the increase in discount rates globally.

[0000833444-22-000043:notes:355]
Net Periodic Benefit Cost

[0000833444-22-000043:notes:356]
The following table contains the components of net periodic benefit costs, which are primarily recorded in selling, general and administrative expenses in the consolidated statements of income (in millions):

[0000833444-22-000043:notes:357]
|  | Pension Benefits |  | Postretirement Benefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| Year ended September 30, | 2022 |  | 2021 |  | 2020 |  | 2022 |  | 2021 |  | 2020 |  | 2022 |  | 2021 |  | 2020 |
| Components of Net Periodic Benefit Cost (Credit): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 20 |  |  | $ | 27 |  |  | $ | 25 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest cost | 56 |  |  | 47 |  |  | 67 |  |  | 39 |  |  | 32 |  |  | 36 |  |  | 2 |  |  | 2 |  |  | 4 |  |
| Expected return on plan assets | (150) |  |  | (171) |  |  | (180) |  |  | (81) |  |  | (112) |  |  | (111) |  |  | (9) |  |  | (8) |  |  | (9) |  |
| Net actuarial (gain) loss | 16 |  |  | (214) |  |  | 244 |  |  | (116) |  |  | (115) |  |  | 43 |  |  | 4 |  |  | (35) |  |  | 2 |  |
| Amortization of prior service cost (credit) | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | (4) |  |  | (4) |  |  | (3) |  |
| Curtailment gain | — |  |  | — |  |  | — |  |  | — |  |  | (3) |  |  | (8) |  |  | — |  |  | — |  |  | — |  |
| Settlement (gain) loss | 1 |  |  | — |  |  | 6 |  |  | 5 |  |  | (1) |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Special termination benefit cost | — |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (credit) included in continuing operations | $ | (77) |  |  | $ | (338) |  |  | $ | 137 |  |  | $ | (133) |  |  | $ | (169) |  |  | $ | (14) |  |  | $ | (6) |  |  | $ | (44) |  |  | $ | (5) |  |
| Expense Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 2.52 | % |  | 2.25 | % |  | 2.95 | % |  | 1.79 | % |  | 1.35 | % |  | 1.50 | % |  | 2.30 | % |  | 1.90 | % |  | 2.65 | % |
| Expected return on plan assets | 7.00 | % |  | 6.50 | % |  | 6.90 | % |  | 3.70 | % |  | 4.90 | % |  | 5.20 | % |  | 5.29 | % |  | 5.30 | % |  | 5.70 | % |
| Rate of compensation increase | N/A |  | N/A |  | N/A |  | 2.85 | % |  | 2.75 | % |  | 2.80 | % |  | N/A |  | N/A |  | N/A |
| Interest crediting rate | N/A |  | N/A |  | N/A |  | 1.44 | % |  | 1.50 | % |  | 1.50 | % |  | N/A |  | N/A |  | N/A |


## us-gaap:ScheduleOfExpectedBenefitPaymentsTableTextBlock

[0000833444-22-000043:notes:358]
Projected benefit payments from the plans as of September 30, 2022 are estimated as follows (in millions):


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-22-000043:notes:359]
SIGNIFICANT RESTRUCTURING AND IMPAIRMENT COSTS
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to restructuring plans as necessary. Restructuring plans generally result in charges for workforce reductions, plant closures, asset impairments and other related costs which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The other related costs consist primarily of consulting costs incurred as a direct result of the restructuring initiatives. The Company expects the restructuring actions to reduce cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-22-000043:notes:360]
In fiscal 2021, the Company committed to a significant multi-year restructuring plan ("2021 Plan") which is expected to be completed during fiscal 2023. The Company originally expected to incur $385 million of restructuring costs across all segments and at Corporate through fiscal 2023. The Company has incurred and exceeded these costs during fiscal 2022 due to certain restructuring actions and expenses planned for fiscal 2023 being accelerated into fiscal 2022. In total, the Company recorded $424 million of restructuring and impairment costs related to the 2021 Plan, which is the total amount expected to be incurred for this restructuring plan.

[0000833444-22-000043:notes:361]
The following table summarizes restructuring and impairment costs related to the 2021 Plan (in millions):

[0000833444-22-000043:notes:362]
|  |  |  | Year Ended September 30, 2022 |  | Inception to September 30, 2022 |
| Building Solutions North America |  |  | $ | 41 |  |  | $ | 111 |  |
| Building Solutions EMEA/LA |  |  | 33 |  |  | 62 |  |
| Building Solutions Asia Pacific |  |  | 21 |  |  | 49 |  |
| Global Products |  |  | 75 |  |  | 166 |  |
| Corporate |  |  | 12 |  |  | 36 |  |
| Total |  |  | $ | 182 |  |  | $ | 424 |  |

[0000833444-22-000043:notes:363]
The following table summarizes the changes in the Company’s 2021 Plan reserve, included primarily within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-22-000043:notes:364]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments (1) |  | Other |  | Total |
| Original reserve | $ | 68 |  |  | $ | 98 |  |  | $ | 76 |  |  | $ | 242 |  |
| Utilized—cash | (28) |  |  | — |  |  | (51) |  |  | (79) |  |
| Utilized—noncash | — |  |  | (98) |  |  | — |  |  | (98) |  |
| Balance at September 30, 2021 | 40 |  |  | — |  |  | 25 |  |  | 65 |  |
| Additional restructuring costs | 116 |  | 17 |  |  | 49 |  |  | 182 |  |
| Utilized—cash | (81) |  |  | — |  |  | (66) |  |  | (147) |  |
| Utilized—noncash | — |  |  | (17) |  |  | — |  |  | (17) |  |
| Currency translation | (1) |  |  | — |  |  | — |  |  | (1) |  |
| Balance at September 30, 2022 | $ | 74 |  |  | $ | — |  |  | $ | 8 |  |  | $ | 82 |  |

[0000833444-22-000043:notes:365]
(1) Of the $98 million of long-lived asset impairment charges in fiscal 2021, $50 million related to the Global Products segment, $33 million related to the Building Solutions North America segment, $6 million related to Corporate assets, $5 million related to the Building Solutions EMEA/LA segment and $4 million related to the Building Solutions Asia Pacific segment. Of the $17 million of long-lived asset impairment charges in fiscal 2022, $6 million related to the Building Solutions Asia Pacific segment, $5 million related to Corporate assets, $3 million related to the Global Products segment, $2 million related to the Building Solutions EMEA/LA segment and $1 million related to the Building Solutions North America segment.

[0000833444-22-000043:notes:366]
The 2021 Plan included workforce reductions of approximately 6,200 employees. Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of September 30, 2022, approximately 4,000 of the employees have been separated from the Company pursuant to the restructuring plans.
Company management closely monitors its overall cost structure and continually analyzes each of its businesses for opportunities to consolidate current operations, improve operating efficiencies and locate facilities in close proximity to customers. This ongoing analysis includes a review of its manufacturing, engineering and purchasing operations, as well as the overall global footprint for all its businesses.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-22-000043:notes:367]
INCOME TAXES
The more significant components of the Company’s income tax provision from continuing operations are as follows (in millions):

[0000833444-22-000043:notes:368]
|  | 2022 |  | 2021 |  | 2020 |
| Tax expense at Ireland statutory rate | $ | 214 |  |  | $ | 327 |  |  | $ | 113 |  |
| U.S. state income tax, net of federal benefit | (23) |  |  | 34 |  |  | 8 |  |
| Income subject to the U.S. federal tax rate | (95) |  |  | 3 |  |  | (92) |  |
| Income subject to rates different than the statutory rate | 125 |  |  | 30 |  |  | 99 |  |
| Reserve and valuation allowance adjustments | (274) |  |  | 66 |  |  | (70) |  |
| Intercompany intellectual property transfer | — |  |  | 417 |  |  | — |  |
| Restructuring and impairment costs | 40 |  |  | (9) |  |  | 50 |  |
| Income tax provision (benefit) | $ | (13) |  |  | $ | 868 |  |  | $ | 108 |  |

[0000833444-22-000043:notes:369]
The statutory tax rate in Ireland of 12.5% is being used as a comparison since the Company is domiciled in Ireland.

[0000833444-22-000043:notes:370]
For fiscal 2022, the effective tax rate for continuing operations was (1)% and was lower than the statutory tax rate primarily due to tax reserve adjustments as the result of expired statute of limitations for certain tax years and  the benefits of continuing global tax planning initiatives, partially offset by the income tax effects of impairment and restructuring charges, valuation allowance adjustments, the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestitures and tax rate differentials.

[0000833444-22-000043:notes:371]
For fiscal 2021, the effective tax rate for continuing operations was 33% and was higher than the statutory tax rate primarily due to the tax impacts of an intercompany transfer of certain of the Company’s intellectual property rights, valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives.

[0000833444-22-000043:notes:372]
For fiscal 2020, the effective tax rate for continuing operations was 12% and was lower than the statutory tax rate primarily due to tax audit reserve adjustments, the income tax effects of mark-to-market adjustments, valuation allowance adjustments and the benefits of continuing global tax planning initiatives, partially offset by a discrete tax charge related to the remeasurement of deferred tax assets and liabilities as a result of Swiss tax reform, the tax impact of an impairment charge and tax rate differentials.

[0000833444-22-000043:notes:373]
Valuation Allowances

[0000833444-22-000043:notes:374]
The Company reviews the realizability of its deferred tax assets and related valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-22-000043:notes:375]
In fiscal 2022, due to changes in forecasted taxable income, the Company determined that it was more likely than not that certain deferred tax assets of Japan would not be realized. The valuation allowance adjustment resulted in a tax charge of $27 million.

[0000833444-22-000043:notes:376]
In fiscal 2021, as a result of an intercompany transfer of certain of the Company’s intellectual property rights, the Company determined that it is more likely than not that certain deferred tax assets of Switzerland would be realized, and it was more likely than not that certain deferred tax assets of Canada would not be realized. The valuation allowance adjustments resulted in a $39 million net benefit to income tax expense. Due to changes in forecasted taxable income, the Company also recorded a

[0000833444-22-000043:notes:377]
discrete tax charge of $105 million related to valuation allowances on certain Mexico deferred tax assets now considered unrealizable.

[0000833444-22-000043:notes:378]
In fiscal 2020, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering feasible tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily within the U.S. would not be realized, and it is more likely than not that certain deferred tax assets of Canada would be realized. The valuation allowance adjustments resulted in a $26 million net benefit to income tax expense.

[0000833444-22-000043:notes:379]
Uncertain Tax Positions

[0000833444-22-000043:notes:380]
The Company is subject to income taxes in the U.S. and numerous non-U.S. jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-22-000043:notes:381]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0000833444-22-000043:notes:382]
|  | 2022 |  | 2021 |  | 2020 |
| Beginning balance, October 1 | $ | 2,726 |  |  | $ | 2,528 |  |  | $ | 2,451 |  |
| Additions for tax positions related to the current year | 169 |  |  | 240 |  |  | 128 |  |
| Additions for tax positions of prior years | 31 |  |  | 33 |  |  | 129 |  |
| Reductions for tax positions of prior years | (48) |  |  | (6) |  |  | (27) |  |
| Settlements with taxing authorities | (7) |  |  | (24) |  |  | (54) |  |
| Statute closings and audit resolutions | (334) |  |  | (45) |  |  | (99) |  |
| Ending balance, September 30 | $ | 2,537 |  |  | $ | 2,726 |  |  | $ | 2,528 |  |

[0000833444-22-000043:notes:383]
The following table summarizes gross tax effected unrecognized tax benefits that, if recognized, would impact the effective tax rate and the related accrued interest, net of tax benefit (in millions):

[0000833444-22-000043:notes:384]
|  | September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Gross tax effected unrecognized tax benefits | $ | 1,973 |  |  | $ | 2,268 |  |  | $ | 2,132 |  |
| Net accrued interest | 284 |  |  | 252 |  |  | 205 |  |

[0000833444-22-000043:notes:385]
In fiscal 2022, the statute of limitations for certain tax years expired, which resulted in a $301 million benefit to income tax expense.

[0000833444-22-000043:notes:386]
During fiscal 2020, tax audit resolutions resulted in a $44 million net benefit to income tax expense.

[0000833444-22-000043:notes:387]
In the U.S., fiscal years 2017 through 2018 are currently under exam by the Internal Revenue Service (“IRS”) for certain legal entities. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions for continuing operations:

[0000833444-22-000043:notes:388]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2021 |
| Germany |  | 2007 - 2018 |
| Luxembourg |  | 2017 - 2018 |
| Mexico |  | 2015 - 2017 |
| United Kingdom |  | 2014 - 2015, 2017 - 2018; 2020 |

[0000833444-22-000043:notes:389]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-22-000043:notes:390]
Other Tax Matters

[0000833444-22-000043:notes:391]
During fiscal 2022, 2021 and 2020, the Company incurred charges for restructuring and impairment costs of $721 million, $242 million and $783 million, which generated tax benefits of $50 million, $39 million and $48 million, respectively.

[0000833444-22-000043:notes:392]
In fiscal 2021, the Company completed an intercompany transfer of certain of the Company’s intellectual property rights which resulted in a net tax charge of $417 million.

[0000833444-22-000043:notes:393]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-22-000043:notes:394]
On August 16, 2022, the U.S. enacted the Inflation Reduction Act (“IRA”) which, among other things, creates a new book minimum tax of at least 15% of consolidated GAAP pre-tax income for corporations with average book income in excess of $1 billion. The book minimum tax is first applicable in fiscal year 2024.  The Company does not expect this provision to have a material impact on its effective tax rate.

[0000833444-22-000043:notes:395]
In fiscal 2020, the Company recorded a noncash discrete tax charge of $30 million due to the remeasurement of deferred tax assets and liabilities related to Switzerland and the canton of Schaffhausen. On September 28, 2018, the Swiss Parliament approved the Federal Act on Tax Reform and AHV Financing (“TRAF”), which was subsequently approved by the Swiss electorate on May 19, 2019. During the fourth quarter of fiscal 2019, the Swiss Federal Council enacted TRAF which became effective for the Company on January 1, 2020. The impacts of the federal enactment did not have a material impact to the Company’s financial statements. TRAF also provides for parameters which enable the Swiss cantons to adjust tax rates and establish new regulations for companies. As of September 30, 2019, the canton of Schaffhausen had not concluded its public referendum; however, the enactment did occur during the first quarter of fiscal 2020.

[0000833444-22-000043:notes:396]
During the fiscal years ended 2022, 2021 and 2020, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-22-000043:notes:397]
Continuing Operations

[0000833444-22-000043:notes:398]
Selected income tax data related to continuing operations were as follows (in millions):

[0000833444-22-000043:notes:399]
|  | 2022 |  | 2021 |  | 2020 |
| Components of income (loss) from continuing operations before income taxes: |  |  |  |  |  |
| U.S. | $ | 67 |  |  | $ | 543 |  |  | $ | (385) |  |
| Non-U.S. | 1,643 |  |  | 2,071 |  |  | 1,288 |  |
| Income from continuing operations before income taxes | $ | 1,710 |  |  | $ | 2,614 |  |  | $ | 903 |  |
| Components of the provision (benefit) for income taxes: |  |  |  |  |  |
| Current |  |  |  |  |  |
| U.S. federal | $ | (219) |  |  | $ | 459 |  |  | $ | 309 |  |
| U.S. state | 53 |  |  | 108 |  |  | 72 |  |
| Non-U.S. | 294 |  |  | 265 |  |  | 264 |  |
|  | 128 |  |  | 832 |  |  | 645 |  |
| Deferred |  |  |  |  |  |
| U.S. federal | (175) |  |  | (7) |  |  | (382) |  |
| U.S. state | (69) |  |  | 46 |  |  | (43) |  |
| Non-U.S. | 103 |  |  | (3) |  |  | (112) |  |
|  | (141) |  |  | 36 |  |  | (537) |  |
| Income tax provision (benefit) | $ | (13) |  |  | $ | 868 |  |  | $ | 108 |  |
| Income taxes paid (refunded) | $ | 568 |  |  | $ | 504 |  |  | $ | (386) |  |

[0000833444-22-000043:notes:400]
At September 30, 2022 and 2021, the Company recorded within the consolidated statements of financial position in other current assets approximately $253 million and $120 million, respectively, of income tax assets. At September 30, 2022 and 2021, the Company recorded within the consolidated statements of financial position in other current liabilities approximately $143 million and $201 million, respectively, of accrued income tax liabilities.

[0000833444-22-000043:notes:401]
The Company has not provided U.S. or non-U.S. income taxes on approximately $23.6 billion of outside basis differences of consolidated subsidiaries of Johnson Controls International plc. The Company is indefinitely reinvested in these basis differences. The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income. The Company's intent is to reduce the outside basis differences only when it would be tax efficient. Given the numerous ways in which the basis differences may be reduced, it is not practicable to estimate the amount of unrecognized withholding taxes and deferred tax liability on the outside basis differences.

[0000833444-22-000043:notes:402]
Deferred taxes were classified in the consolidated statements of financial position as follows (in millions):

[0000833444-22-000043:notes:403]
|  | September 30, |
|  | 2022 |  | 2021 |
| Other noncurrent assets | $ | 944 |  |  | $ | 755 |  |
| Other noncurrent liabilities | (500) |  |  | (443) |  |
| Net deferred tax asset | $ | 444 |  |  | $ | 312 |  |

[0000833444-22-000043:notes:404]
Temporary differences and carryforwards which gave rise to deferred tax assets and liabilities included (in millions):

[0000833444-22-000043:notes:405]
|  | September 30, |
|  | 2022 |  | 2021 |
| Deferred tax assets |  |  |  |
| Accrued expenses and reserves | $ | 376 |  |  | $ | 407 |  |
| Employee and retiree benefits | 77 |  |  | 148 |  |
| Property, plant and equipment | 444 |  |  | 369 |  |
| Net operating loss and other credit carryforwards | 6,472 |  |  | 6,293 |  |
| Research and development | 52 |  |  | 42 |  |
| Operating lease liabilities | 309 |  |  | 334 |  |
| Other, net | 58 |  |  | 28 |  |
|  | 7,788 |  |  | 7,621 |  |
| Valuation allowances | (5,967) |  |  | (5,853) |  |
|  | 1,821 |  |  | 1,768 |  |
| Deferred tax liabilities |  |  |  |
| Subsidiaries, joint ventures and partnerships | 338 |  |  | 346 |  |
| Intangible assets | 730 |  |  | 776 |  |
| Operating lease right-of-use assets | 309 |  |  | 334 |  |
|  | 1,377 |  |  | 1,456 |  |
| Net deferred tax asset | $ | 444 |  |  | $ | 312 |  |

[0000833444-22-000043:notes:406]
At September 30, 2022, the Company had available net operating loss carryforwards of approximately $24.3 billion, of which $14.0 billion will expire at various dates between 2023 and 2042, and the remainder has an indefinite carryforward period. The Company had available U.S. foreign tax credit carryforwards at September 30, 2022 of $35 million which will expire in 2029. The valuation allowance, generally, is for loss and credit carryforwards for which realization is uncertain because it is unlikely that the losses and/or credits will be realized given the lack of sustained profitability and/or limited carryforward periods in certain countries.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-22-000043:notes:407]
SEGMENT INFORMATION
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has four reportable segments for financial reporting purposes.

[0000833444-22-000043:notes:408]
Building Solutions North America: Building Solutions North America designs, sells, installs and services HVAC, controls, building management, refrigeration, integrated electronic security and integrated fire-detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in the United States and Canada. Building Solutions North America also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and controls systems, as well as data-driven “smart building” solutions, to non-residential building and industrial applications in the United States and Canadian marketplace.

[0000833444-22-000043:notes:409]
Building Solutions EMEA/LA: Building Solutions EMEA/LA designs, sells, installs and services HVAC, controls, building management, refrigeration, integrated electronic security, integrated fire-detection and suppression systems, and provides technical services, including data-driven “smart building” solutions, to markets in Europe, the Middle East, Africa and Latin America.

[0000833444-22-000043:notes:410]
Building Solutions Asia Pacific: Building Solutions Asia Pacific designs, sells, installs and services HVAC, controls, building management, refrigeration, integrated electronic security, integrated fire-detection and suppression systems, and provides technical services, including data-driven “smart building” solutions, in the Asia Pacific marketplace.

[0000833444-22-000043:notes:411]
Global Products: Global Products designs, manufactures and sells HVAC equipment, controls software and software services for residential and commercial applications to commercial, industrial, retail, residential, small business, institutional and

[0000833444-22-000043:notes:412]
governmental customers worldwide. In addition, Global Products designs, manufactures and sells refrigeration equipment and controls globally. The Global Products business also designs, manufactures and sells fire protection, fire suppression and security products, including intrusion security, anti-theft devices, access control, and video surveillance and management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide. Global Products includes the Johnson Controls-Hitachi joint venture.

[0000833444-22-000043:notes:413]
Effective October 1, 2021, the Company's marine businesses previously included in the Building Solutions Asia Pacific and Global Products reportable segments became part of the Building Solutions EMEA/LA reportable segment. Historical information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation or the allocation of goodwill.

[0000833444-22-000043:notes:414]
Management evaluates the performance of its business segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-22-000043:notes:415]
Financial information relating to the Company’s reportable segments is as follows (in millions):

[0000833444-22-000043:notes:416]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Net Sales |  |  |  |  |  |
| Building Solutions North America | $ | 9,367 |  |  | $ | 8,685 |  |  | $ | 8,605 |  |
| Building Solutions EMEA/LA | 3,845 |  |  | 3,884 |  |  | 3,613 |  |
| Building Solutions Asia Pacific | 2,714 |  |  | 2,616 |  |  | 2,368 |  |
| Global Products | 9,373 |  |  | 8,483 |  |  | 7,731 |  |
| Total net sales | $ | 25,299 |  |  | $ | 23,668 |  |  | $ | 22,317 |  |

[0000833444-22-000043:notes:417]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Segment EBITA (1) |  |  |  |  |  |
| Building Solutions North America | $ | 1,122 |  |  | $ | 1,204 |  |  | $ | 1,157 |  |
| Building Solutions EMEA/LA | 358 |  |  | 401 |  |  | 349 |  |
| Building Solutions Asia Pacific | 332 |  |  | 344 |  |  | 314 |  |
| Global Products | 1,594 |  |  | 1,436 |  |  | 1,128 |  |
| Total segment EBITA | $ | 3,406 |  |  | $ | 3,385 |  |  | $ | 2,948 |  |
| Amortization of intangible assets | (427) |  |  | (435) |  |  | (386) |  |
| Corporate expenses | (369) |  |  | (290) |  |  | (371) |  |
| Net financing charges | (213) |  |  | (206) |  |  | (231) |  |
| Restructuring and impairment costs | (721) |  |  | (242) |  |  | (783) |  |
| Net mark-to-market adjustments | 34 |  |  | 402 |  |  | (274) |  |
| Income from continuing operations before income taxes | $ | 1,710 |  |  | $ | 2,614 |  |  | $ | 903 |  |

[0000833444-22-000043:notes:418]
|  | September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Assets (2) |  |  |  |  |  |
| Building Solutions North America | $ | 14,429 |  |  | $ | 15,317 |  |  | $ | 15,215 |  |
| Building Solutions EMEA/LA | 4,766 |  |  | 5,397 |  |  | 5,159 |  |
| Building Solutions Asia Pacific | 2,424 |  |  | 2,728 |  |  | 2,662 |  |
| Global Products | 15,185 |  |  | 15,227 |  |  | 13,770 |  |
|  | 36,804 |  |  | 38,669 |  |  | 36,806 |  |
| Assets held for sale | 1,138 |  |  | 156 |  |  | 147 |  |
| Unallocated | 4,216 |  |  | 3,065 |  |  | 3,862 |  |
| Total | $ | 42,158 |  |  | $ | 41,890 |  |  | $ | 40,815 |  |

[0000833444-22-000043:notes:419]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Depreciation/Amortization |  |  |  |  |  |
| Building Solutions North America | $ | 213 |  |  | $ | 245 |  |  | $ | 233 |  |
| Building Solutions EMEA/LA | 96 |  |  | 103 |  |  | 102 |  |
| Building Solutions Asia Pacific | 21 |  |  | 25 |  |  | 24 |  |
| Global Products | 461 |  |  | 432 |  |  | 414 |  |
|  | 791 |  |  | 805 |  |  | 773 |  |
| Corporate | 39 |  |  | 40 |  |  | 49 |  |
| Total | $ | 830 |  |  | $ | 845 |  |  | $ | 822 |  |

[0000833444-22-000043:notes:420]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Capital Expenditures |  |  |  |  |  |
| Building Solutions North America | $ | 141 |  |  | $ | 87 |  |  | $ | 93 |  |
| Building Solutions EMEA/LA | 119 |  |  | 128 |  |  | 99 |  |
| Building Solutions Asia Pacific | 22 |  |  | 31 |  |  | 36 |  |
| Global Products | 257 |  |  | 265 |  |  | 191 |  |
|  | 539 |  |  | 511 |  |  | 419 |  |
| Corporate | 53 |  |  | 41 |  |  | 24 |  |
| Total | $ | 592 |  |  | $ | 552 |  |  | $ | 443 |  |

[0000833444-22-000043:notes:421]
(1)For the years ended September 30, 2022, 2021 and 2020, segment EBITA includes $240 million, $250 million and $166 million, respectively, of equity income for the Global Products segment. Equity income for other segments is immaterial.

[0000833444-22-000043:notes:422]
(2)Building Solutions EMEA/LA assets as of September 30, 2022, 2021 and 2020 include $115 million, $111 million and $108 million, respectively, of investments in partially-owned affiliates. Global Products assets as of September 30, 2022, 2021 and 2020 include $834 million, $945 million and $797 million, respectively, of investments in partially-owned affiliates. Investments in partially-owned affiliates for other segments is immaterial.

[0000833444-22-000043:notes:423]
In fiscal 2022, 2021 and 2020, no customer exceeded 10% of consolidated net sales.

[0000833444-22-000043:notes:424]
Geographic Segments

[0000833444-22-000043:notes:425]
Financial information relating to the Company’s operations by geographic area is as follows (in millions):

[0000833444-22-000043:notes:426]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Net Sales |  |  |  |  |  |
| United States | $ | 12,864 |  |  | $ | 11,577 |  |  | $ | 11,371 |  |
| Europe | 4,186 |  |  | 4,069 |  |  | 3,523 |  |
| Asia Pacific | 5,791 |  |  | 5,748 |  |  | 5,285 |  |
| Other Non-U.S. | 2,458 |  |  | 2,274 |  |  | 2,138 |  |
| Total | $ | 25,299 |  |  | $ | 23,668 |  |  | $ | 22,317 |  |
| Long-Lived Assets (Year-end) |  |  |  |  |  |
| United States | $ | 1,573 |  |  | $ | 1,638 |  |  | $ | 1,713 |  |
| Europe | 412 |  |  | 436 |  |  | 278 |  |
| Asia Pacific | 656 |  |  | 727 |  |  | 667 |  |
| Other Non-U.S. | 401 |  |  | 427 |  |  | 401 |  |
| Total | $ | 3,042 |  |  | $ | 3,228 |  |  | $ | 3,059 |  |

[0000833444-22-000043:notes:427]
Net sales attributed to geographic locations are based on the location of where the sale originated. Long-lived assets by geographic location consist of net property, plant and equipment.


## us-gaap:GuaranteesTextBlock

[0000833444-22-000043:notes:428]
GUARANTEES
Certain of the Company's subsidiaries at the business segment level have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance. Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-22-000043:notes:429]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate for future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-22-000043:notes:430]
The Company’s product warranty liability is recorded in the consolidated statements of financial position in other current liabilities if the warranty is less than one year and in other noncurrent liabilities if the warranty extends longer than one year.

[0000833444-22-000043:notes:431]
The changes in the carrying amount of the Company’s total product warranty liability were as follows (in millions).

[0000833444-22-000043:notes:432]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |
| Balance at beginning of period | $ | 192 |  |  | $ | 167 |  |
| Accruals for warranties issued during the period | 119 |  |  | 91 |  |
| Accruals from acquisitions and divestitures | (1) |  |  | — |  |
| Changes in estimates to pre-existing warranties | (6) |  |  | 11 |  |
| Settlements made (in cash or in kind) during the period | (114) |  |  | (77) |  |
| Currency translation | (11) |  |  | — |  |
| Balance at end of period | $ | 179 |  |  | $ | 192 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-22-000043:notes:433]
COMMITMENTS AND CONTINGENCIES
Environmental Matters

[0000833444-22-000043:notes:434]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-22-000043:notes:435]
|  | September 30, |
|  | 2022 |  | 2021 |
| Other current liabilities | $ | 66 |  |  | $ | 48 |  |
| Other noncurrent liabilities | 220 |  |  | 54 |  |
| Total reserves for environmental liabilities | $ | 286 |  |  | $ | 102 |  |

[0000833444-22-000043:notes:436]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. During the three months ended September 30, 2022, with the assistance of independent environmental consultants and taking into consideration investigation and remediation actions previously completed, new information available to the Company during the fourth quarter of 2022 and ongoing discussions with the Wisconsin Department of Natural Resources ("WDNR"), the Company completed a comprehensive long-term analysis and cost assessment related to the Company’s ongoing environmental remediation obligations. As a result of this analysis, the Company increased its accrual for environmental liabilities by $228 million, which are recorded on an undiscounted basis. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

[0000833444-22-000043:notes:437]
A substantial portion of the increase to the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to fire-fighting foams containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The increase in reserves was recorded as a result of several events that occurred in the three months ended September 30, 2022, including the completion and testing of the Groundwater Extraction and Treatment System (“GETS”) at the FTC (as further discussed below), the completion of resident surveys in Peshtigo regarding long-term drinking water solutions, correspondence with regulators on planned remediation activities, finalization of cost estimates for system upgrades and related long-term run rate costs in response to new permit requirements at the Stanton Street Facility, and the development of additional information through ongoing investigation and analysis. These events have allowed the Company to develop estimates of costs associated with the long-term remediation actions expected to be performed over an estimated period of up to 20 years, including the continued operation of the GETS, the implementation of long-term drinking water solutions, continued monitoring and testing of the wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

[0000833444-22-000043:notes:438]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, the WDNR approved Tyco Fire Products’ proposed GETS, a permanent groundwater remediation system that will extract groundwater that contains PFAS, treat it using advanced filtration systems, and return the treated water to the environment. Tyco Fire Products has completed construction of the GETS, which is now in operation. Tyco Fire Products is also in the process of completing the removal and disposal of PFAS-affected soil from the FTC.

[0000833444-22-000043:notes:439]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency (“EPA”) to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis.

[0000833444-22-000043:notes:440]
Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

[0000833444-22-000043:notes:441]
PFOA, PFOS, and other PFAS compounds are being studied by EPA and other environmental and health agencies and researchers. EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. While those studies continue, EPA issued in June 2022 an updated set of interim health advisory levels for PFOA and PFOS in drinking water, as well as final health advisory levels for two other types of PFAS (PFBS and GenX chemicals). In November 2022, EPA added a class definition of PFAS to the final version of EPA's fifth Contaminant Candidate List (CCL 5), which is a list of substances not currently subject to national drinking water regulation, but which EPA believes may require future regulation.

[0000833444-22-000043:notes:442]
In October 2021, EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains. In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under CERCLA.

[0000833444-22-000043:notes:443]
It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-22-000043:notes:444]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $17 million and $29 million at September 30, 2022 and 2021, respectively.

[0000833444-22-000043:notes:445]
FTC-Related Remediation and Litigation

[0000833444-22-000043:notes:446]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin recently approved final regulatory standards for PFOA and PFOS in drinking water and surface water, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. In September 2022, the Governor of Wisconsin signed a scope statement setting out parameters for the WDNR to draft a final rule regarding groundwater quality standards for PFOA and PFOS, among other compounds. The WDNR is now in the process of drafting the rule.

[0000833444-22-000043:notes:447]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products responded to the WDNR’s letter by requesting additional necessary information. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco

[0000833444-22-000043:notes:448]
Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to date. Tyco Fire Products responded to the WDNR’s September 2021 notice by the December 27, 2021 deadline set by WDNR and submitted a Land Applied Biosolids Interim Site Status Update Report to WDNR on October 25, 2022. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

[0000833444-22-000043:notes:449]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The lawsuit is presently at the beginning stages of litigation. Tyco Fire Products and Johnson Controls, Inc. each filed Answers to the Complaint on April 4, 2022 and the parties are proceeding with initial fact discovery. The Company is vigorously defending this civil enforcement action and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

[0000833444-22-000043:notes:450]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The lawsuit is presently at the beginning stages of litigation. The Company was served with the operative complaint on October 21, 2022. The Company plans to vigorously defend against this case and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

[0000833444-22-000043:notes:451]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-22-000043:notes:452]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-22-000043:notes:453]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-22-000043:notes:454]
AFFF Putative Class Actions

[0000833444-22-000043:notes:455]
Chemguard and Tyco Fire Products are named in 33 pending putative class actions in federal courts originating from Colorado, Florida, Massachusetts, New York, Pennsylvania, Washington, New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan, Texas and South Dakota. All of these cases except one have been direct-filed in or transferred to the MDL, and the remaining action was recently removed to federal court and will be tagged for transfer to the MDL shortly.

[0000833444-22-000043:notes:456]
AFFF Individual or Mass Actions

[0000833444-22-000043:notes:457]
There are more than 2,900 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 2,900 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona, Illinois, and Texas.

[0000833444-22-000043:notes:458]
Tyco and Chemguard are also periodically notified by other individuals that they may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-22-000043:notes:459]
AFFF Municipal and Water Provider Cases

[0000833444-22-000043:notes:460]
Chemguard and Tyco Fire Products have been named as defendants in more than 250 cases in federal and state courts involving municipal or water provider plaintiffs in various states including Alaska, Alabama, Arizona, California, Colorado, Connecticut, Florida, Idaho, Illinois, Kentucky, Louisiana, Maryland, Massachusetts, Michigan, New Jersey, New York, North Carolina, Ohio, Pennsylvania, Virginia, Washington, West Virginia, Wisconsin, the District of Columbia, and several municipalities or water providers from various states who direct-filed complaints in South Carolina. The vast majority of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.

[0000833444-22-000043:notes:461]
Tyco and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-22-000043:notes:462]
State or U.S. Territory Attorneys General Litigation related to AFFF

[0000833444-22-000043:notes:463]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-22-000043:notes:464]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-22-000043:notes:465]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752-000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio. The lawsuit seeks to recover costs and natural resource damages associated with the contamination. This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-22-000043:notes:466]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

[0000833444-22-000043:notes:467]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-22-000043:notes:468]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-22-000043:notes:469]
In August 2020, the Attorney General of the State of Michigan filed two substantially similar lawsuits—one in federal court and one in state court—against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within the State.  The federal action has been transferred to the MDL, and the state court action has been removed to federal court and transferred to the MDL.

[0000833444-22-000043:notes:470]
In December 2020, the State of Mississippi filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint was direct-filed in the MDL in South Carolina.

[0000833444-22-000043:notes:471]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

[0000833444-22-000043:notes:472]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. It is anticipated that these two cases will be removed to federal court and transferred to the MDL.

[0000833444-22-000043:notes:473]
In February 2022, the Attorney General of the State of Colorado filed a lawsuit in Colorado state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State's land and natural resources, public health, and State property allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-22-000043:notes:474]
In April 2022, the Attorney General of the State of Florida filed a lawsuit in Florida state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage to the State's natural resources and public health allegedly resulting from the use of firefighting foams at various locations throughout the State. It is anticipated that this complaint will be removed to federal court and transferred to the MDL.

[0000833444-22-000043:notes:475]
In May 2022, the Attorney General of the Commonwealth of Massachusetts filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State's natural resources, property, residents, and consumers allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint was direct-filed in the MDL in South Carolina.

[0000833444-22-000043:notes:476]
In July 2022, the Attorney General of the State of Wisconsin filed a lawsuit in Wisconsin state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage to the State's natural

[0000833444-22-000043:notes:477]
resources and public health allegedly resulting, in part, from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and tagged for transfer to the MDL. The Attorney General has opposed transfer, and the parties are awaiting a decision from the JPML.

[0000833444-22-000043:notes:478]
In November 2022, the Attorney General of the State of California filed a lawsuit in California state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the manufacture, use, marketing, or sale of PFAS-containing products, including firefighting foams, at various locations throughout the State. It is anticipated that this case will be removed to federal court and transferred to the MDL.

[0000833444-22-000043:notes:479]
Other AFFF Related Matters

[0000833444-22-000043:notes:480]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-22-000043:notes:481]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This complaint has been transferred to the MDL.

[0000833444-22-000043:notes:482]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-22-000043:notes:483]
Asbestos Matters

[0000833444-22-000043:notes:484]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-22-000043:notes:485]
The Company estimates the asbestos-related liability for pending and future claims and related defense costs on a discounted basis. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable.

[0000833444-22-000043:notes:486]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-22-000043:notes:487]
|  | September 30, |
|  | 2022 |  | 2021 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 380 |  |  | 400 |  |
| Total asbestos-related liabilities | 438 |  |  | 458 |  |
| Other current assets | 37 |  |  | 13 |  |
| Other noncurrent assets | 263 |  |  | 365 |  |
| Total asbestos-related assets | 300 |  |  | 378 |  |
| Net asbestos-related liabilities | $ | 138 |  |  | $ | 80 |  |

[0000833444-22-000043:notes:488]
The following table presents the components of asbestos-related assets (in millions):

[0000833444-22-000043:notes:489]
|  | September 30, |
|  | 2022 |  | 2021 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 239 |  |  | 314 |  |
| Total restricted assets | 245 |  |  | 320 |  |
| Insurance recoveries for asbestos-related liabilities | 55 |  |  | 58 |  |
| Total asbestos-related assets | $ | 300 |  |  | $ | 378 |  |

[0000833444-22-000043:notes:490]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be paid by Company affiliates). Estimated asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be paid through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-22-000043:notes:491]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-22-000043:notes:492]
Insurable Liabilities

[0000833444-22-000043:notes:493]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-22-000043:notes:494]
The following table presents the location and amount of insurable liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-22-000043:notes:495]
|  | September 30, |
|  | 2022 |  | 2021 |
| Other current liabilities | $ | 89 |  |  | $ | 77 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 230 |  |  | 226 |  |
| Total insurable liabilities | $ | 341 |  |  | $ | 325 |  |

[0000833444-22-000043:notes:496]
The following table presents the location and amount of insurable receivables in the Company's consolidated statements of financial position (in millions):

[0000833444-22-000043:notes:497]
|  | September 30, |
|  | 2022 |  | 2021 |
| Other current assets | $ | 10 |  |  | $ | 5 |  |
| Other noncurrent assets | 20 |  |  | 15 |  |
| Total insurable receivables | $ | 30 |  |  | $ | 20 |  |

[0000833444-22-000043:notes:498]
Other Matters 
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock

[0000833444-22-000043:notes:499]
The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):


## us-gaap:SubsequentEventsTextBlock

[0000833444-22-000043:notes:500]
SUBSEQUENT EVENTS
In October 2022, the Company acquired Rescue Air Systems, a leading provider of firefighter air replenishment systems, for $100 million to enhance its Fire Suppression portfolio.

[0000833444-22-000043:notes:501]
In October 2022, the Company repaid a €200 million ($196 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5% and entered into a €150 million term loan with an interest rate of EURIBOR plus 0.7% which is due in April 2024.
In October 2022, a third party warehouse in Menominee, Michigan, at which the Company stores certain Global Products inventory related to its fire suppression business, was severely damaged by a fire. The fire originated at an adjacent location not owned or operated by the Company. The Company is evaluating the losses incurred, including inventory and other assets that were damaged or destroyed, as well as expected lost revenues and profits due to the business interruption. The Company believes losses will be at least partially covered by insurance and also plans to seek recovery from the responsible parties. The Company expects the majority of the financial impact will be recognized in the first quarter of fiscal 2023. Based on the current evaluation, the Company believes the warehouse fire will not have a material impact on fiscal 2023 financial results, financial position or cash flows.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000833444-22-000043:notes:502]
JOHNSON CONTROLS INTERNATIONAL PLC AND SUBSIDIARIES

[0000833444-22-000043:notes:503]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000833444-22-000043:notes:504]
(In millions)

[0000833444-22-000043:notes:505]
|  | Year Ended September 30, |
|  | 2022 |  | 2021 |  | 2020 |
| Accounts Receivable - Allowance for Expected Credit Losses (1) |  |  |  |  |  |
| Balance at beginning of period | $ | 110 |  |  | $ | 173 |  |  | $ | 173 |  |
| Provision (income) charged to costs and expenses | (2) |  |  | (3) |  |  | 20 |  |
| Accounts charged off, net of recoveries | (38) |  |  | (65) |  |  | (21) |  |
| Currency translation | (3) |  |  | 1 |  |  | 1 |  |
| Other | (5) |  |  | 4 |  |  | — |  |
| Balance at end of period | $ | 62 |  |  | $ | 110 |  |  | $ | 173 |  |
| Deferred Tax Assets - Valuation Allowance |  |  |  |  |  |
| Balance at beginning of period | $ | 5,853 |  |  | $ | 5,518 |  |  | $ | 5,068 |  |
| Allowance provision for new operating and other loss carryforwards | 326 |  |  | 505 |  |  | 624 |  |
| Allowance held for sale | (8) |  |  | — |  |  | — |  |
| Allowance benefits | (204) |  |  | (170) |  |  | (174) |  |
| Balance at end of period | $ | 5,967 |  |  | $ | 5,853 |  |  | $ | 5,518 |  |

[0000833444-22-000043:notes:506]
(1) Allowance for doubtful accounts as of September 30, 2020, prior to the adoption of ASU 2016-13.
