# JCI note change history — 0000833444-25-000063 → 0000833444-26-000019


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0000833444-26-000019:note_history:1]
|  | December 31, 2025 |  | September 30, 2025 |
| Other current liabilities | $ | 24 |  |  | $ | 27 |  |
| Other noncurrent liabilities | 156 |  |  | 160 |  |
| Total reserves for environmental liabilities | $ | 180 |  |  | $ | 187 |  |
  (was, 2025-08-06, similarity 0.9706):
[0000833444-25-000063:note_history:1]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 23 |  |  | $ | 32 |  |
| Other noncurrent liabilities | 170 |  |  | 179 |  |
| Total reserves for environmental liabilities | $ | 193 |  |  | $ | 211 |  |

- changed (2026-02-04):
[0000833444-26-000019:note_history:2]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). Tyco Fire Products has discontinued the production and sale of fluorinated firefighting foams, including AFFF products, and has transitioned to non-fluorinated foam alternatives.
  (was, 2025-08-06, similarity 0.7787):
[0000833444-25-000063:note_history:2]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and

- changed (2026-02-04):
[0000833444-26-000019:note_history:3]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $7 million at both December 31, 2025 and September 30, 2025.
  (was, 2025-08-06, similarity 0.9803):
[0000833444-25-000063:note_history:3]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $7 million at both June 30, 2025 and September 30, 2024.

- changed (2026-02-04):
[0000833444-26-000019:note_history:4]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.
  (was, 2025-08-06, similarity 0.7266):
[0000833444-25-000063:note_history:4]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities

- changed (2026-02-04):
[0000833444-26-000019:note_history:5]
Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022. In August 2024, WDNR issued a new proposed rule to adopt the EPA Maximum Contaminant Levels for PFAS in drinking water. In February 2025, the Wisconsin Department of Health Services ("WDHS") recommended individual groundwater enforcement standards of 4 ng/L for PFOA and PFOS, 10 ng/L for PFHxS, PFNA, and HFPO-DA, and 2,000 ng/L for PFBS. Following the February 2025 WDHS recommendation, the WDNR Secretary and the Governor signed the WDNR scope statement. In January 2026, the Wisconsin Natural Resources Board approved drinking water standards of 4 ng/L for PFOA and PFOS and 10 ng/L for PFHxS, PFNA, and HFPO-DA. The standards are subject to further reviews and approvals before they become final.
  (was, 2025-08-06, similarity 0.7608):
[0000833444-25-000063:note_history:5]
Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022. In August 2024, WDNR issued a new proposed rule to adopt the EPA Maximum Contaminant Levels for PFAS in drinking water. In February 2025, the Wisconsin Department of Health Services ("WDHS") recommended individual groundwater enforcement standards of 4 ng/L for PFOA and PFOS, 10 ng/L for PFHxS, PFNA, and HFPO-DA, and 2,000 ng/L for PFBS. Following the February 2025 WDHS recommendation, the WDNR Secretary and the Governor signed the WDNR scope statement and WDNR is in the early stages of rule development for enforcement standards for these six PFAS constituents.

- changed (2026-02-04):
[0000833444-26-000019:note_history:6]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties have completed briefing of summary judgment and pretrial motions. The Court has continued the trial previously scheduled for March 3, 2025 and has not yet set a new trial date. The parties are actively working toward the finalization of a settlement to resolve the matter.
  (was, 2025-08-06, similarity 0.9514):
[0000833444-25-000063:note_history:6]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties have completed briefing of summary judgment and pretrial motions. The Court has continued the trial previously scheduled for March 3, 2025 and has not yet set a new trial date.

- changed (2026-02-04):
[0000833444-26-000019:note_history:7]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina.
  (was, 2025-08-06, similarity 0.8107):
[0000833444-25-000063:note_history:7]
Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina.

- changed (2026-02-04):
[0000833444-26-000019:note_history:8]
Chemguard and Tyco Fire Products have been named as defendants in more than 300 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 36 states and territories. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation.
  (was, 2025-08-06, similarity 0.8433):
[0000833444-25-000063:note_history:8]
Chemguard and Tyco Fire Products have been named as defendants in more than 260 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 34 states and territories. The decrease in water provider actions during the three months ended June 30, 2025 reflects dismissals resulting from the water systems AFFF settlement agreement discussed further below. More water provider cases may be dismissed pursuant to the water systems AFFF settlement agreement. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation.

- changed (2026-02-04):
[0000833444-26-000019:note_history:9]
On April 12, 2024, Tyco Fire Products agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. The settlement releases these claims against Tyco Fire Products, Chemguard, and other related corporate entities. In accordance with the terms of the settlement agreement, Tyco Fire Products made its final required payment of $415 million in December 2024 and has now paid the full settlement amount.
  (was, 2025-08-06, similarity 0.9408):
[0000833444-25-000063:note_history:9]
On April 12, 2024, Tyco Fire Products agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. The settlement releases these claims against Tyco Fire Products, Chemguard, and other related corporate entities. On November 22, 2024, the Court entered final approval of the settlement agreement. In accordance with the terms of the settlement agreement, Tyco Fire Products made its final required payment of $415 million in December 2024 and has now paid the full settlement amount.

- changed (2026-02-04):
[0000833444-26-000019:note_history:10]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of
  (was, 2025-08-06, similarity 0.8552):
[0000833444-25-000063:note_history:10]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of damages alleged to be related to the historic use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.

- added (2026-02-04):
[0000833444-26-000019:note_history:11]
damages alleged to be related to the historical use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.

- changed (2026-02-04):
[0000833444-26-000019:note_history:12]
Chemguard and Tyco Fire Products are named in 49 pending putative class actions in federal courts originating from 21 states and territories. All of these cases have been direct-filed in or transferred to the MDL. In addition, seven proposed class actions were filed in Canada (British Columbia, Manitoba, Quebec and Ontario), which name Tyco Fire Products and other manufacturers as defendants, on behalf of various classes of members (including individuals and government entities) who seek to recover for remediation (past and future) costs, claim property or other environmental damages, or claim personal injuries or other harms arising from alleged exposure to or contamination with PFAS or PFAS-containing products (including AFFF).
  (was, 2025-08-06, similarity 0.8736):
[0000833444-25-000063:note_history:12]
Chemguard and Tyco Fire Products are named in 45 pending putative class actions in federal courts originating from 20 states and territories. The decrease in putative class actions during the three months ended June 30, 2025 reflects dismissals resulting from the water systems AFFF settlement agreement. All of these cases have been direct-filed in or transferred to the MDL. In addition, six proposed class actions were filed in Canada (British Columbia, Manitoba, Quebec and Ontario), which name Tyco Fire Products and other manufacturers as defendants, on behalf of various classes of members (including individuals and government entities) who seek to recover for remediation (past and future) costs, claim property or other environmental damages, or claim personal injuries or other harms arising from alleged exposure to or contamination with PFAS or PFAS-containing products (including AFFF).

- changed (2026-02-04):
[0000833444-26-000019:note_history:13]
There are more than 15,000 individual or “mass” actions pending that were filed in state or federal courts originating from 53 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The Company is currently unable to determine a precise count of personal injury claimants currently pending. The vast majority of these matters transferred to or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are or will be proceeding in state courts, including actions in Arizona, Illinois and Washington.
  (was, 2025-08-06, similarity 0.755):
[0000833444-25-000063:note_history:13]
There are more than 9,900 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 9,900 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona and Illinois.

- added (2026-02-04):
[0000833444-26-000019:note_history:14]
In addition, an affiliate of the Company has been named with other manufacturers as a third party by the Canadian Federal Government who is seeking contribution and indemnity in respect of a single-plaintiff action filed in Ontario relating to alleged PFAS and benzene contamination of a private well from the use of AFFF in firefighting training.

- changed (2026-02-04):
[0000833444-26-000019:note_history:15]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.
  (was, 2025-08-06, similarity 0.8231):
[0000833444-25-000063:note_history:15]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and

- changed (2026-02-04):
[0000833444-26-000019:note_history:16]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This case has been transferred to the MDL.
  (was, 2025-08-06, similarity 0.9877):
[0000833444-25-000063:note_history:16]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This complaint has been transferred to the MDL.

- added (2026-02-04):
[0000833444-26-000019:note_history:17]
In September 2025, the Leech Lake Band of Ojibwe (one of six federally recognized sovereign bands that make up the federally recognized Minnesota Chippewa Tribe) filed a lawsuit in Minnesota state court against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from, among other things, the alleged use and disposal of AFFF on and near the Band’s property. This case has been transferred to the MDL.

- added (2026-02-04):
[0000833444-26-000019:note_history:18]
Four AFFF property damage proceedings have been filed in Belgium against numerous defendants, including an affiliate of the Company.  The cases are currently on hold pending efforts to dismiss the proceedings.

- added (2026-02-04):
[0000833444-26-000019:note_history:19]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin. The Company has reached settlements with certain insurers and remains in discussions and litigation with the remaining carriers. In the first quarter of fiscal year 2026, the Company recorded $130 million of insurance recoveries related to settlements with its insurance carriers in selling, general and administrative expenses in the consolidated statements of income. The Company is unable to predict the amount and timing of any future recoveries under its insurance policies with the remaining carriers. The insurance litigation involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

- added (2026-02-04):
[0000833444-26-000019:note_history:20]
|  | December 31, 2025 |  | September 30, 2025 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 336 |  |  | 329 |  |
| Total asbestos-related liabilities | 394 |  |  | 387 |  |
| Other current assets | 14 |  |  | 13 |  |
| Other noncurrent assets | 326 |  |  | 326 |  |
| Total asbestos-related assets | 340 |  |  | 339 |  |
| Net asbestos-related liabilities | $ | 54 |  |  | $ | 48 |  |

- added (2026-02-04):
[0000833444-26-000019:note_history:21]
|  | December 31, 2025 |  | September 30, 2025 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 5 |  |
| Investments | 291 |  |  | 290 |  |
| Total restricted assets | 297 |  |  | 295 |  |
| Insurance receivables for asbestos-related liabilities | 43 |  |  | 44 |  |
| Total asbestos-related assets | $ | 340 |  |  | $ | 339 |  |

- changed (2026-02-04):
[0000833444-26-000019:note_history:22]
The amounts recorded for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to
  (was, 2025-08-06, similarity 0.8066):
[0000833444-25-000063:note_history:22]
The amounts recorded for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

- added (2026-02-04):
[0000833444-26-000019:note_history:23]
jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

- changed (2026-02-04):
[0000833444-26-000019:note_history:24]
|  | December 31, 2025 |  | September 30, 2025 |
| Other current liabilities | $ | 89 |  |  | $ | 87 |  |
| Accrued compensation and benefits | 38 |  |  | 38 |  |
| Other noncurrent liabilities | 311 |  |  | 289 |  |
| Total self-insured liabilities | $ | 438 |  |  | $ | 414 |  |
  (was, 2025-08-06, similarity 0.9752):
[0000833444-25-000063:note_history:24]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 96 |  |  | $ | 92 |  |
| Accrued compensation and benefits | 32 |  |  | 20 |  |
| Other noncurrent liabilities | 256 |  |  | 239 |  |
| Total self-insured liabilities | $ | 384 |  |  | $ | 351 |  |

- removed (2026-02-04):
[0000833444-25-000063:note_history:25]
other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). During the three months ended June 30, 2024, Tyco Fire Products completed its previously announced plan to discontinue the production and sale of fluorinated firefighting foams, including AFFF products, and has transitioned to non-fluorinated foam alternatives.

- removed (2026-02-04):
[0000833444-25-000063:note_history:26]
completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

- removed (2026-02-04):
[0000833444-25-000063:note_history:27]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v.

- removed (2026-02-04):
[0000833444-25-000063:note_history:28]
disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

- removed (2026-02-04):
[0000833444-25-000063:note_history:29]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin. The insurance litigation involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

- removed (2026-02-04):
[0000833444-25-000063:note_history:30]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 337 |  |  | 350 |  |
| Total asbestos-related liabilities | 395 |  |  | 408 |  |
| Other current assets | 14 |  |  | 14 |  |
| Other noncurrent assets | 314 |  |  | 320 |  |
| Total asbestos-related assets | 328 |  |  | 334 |  |
| Net asbestos-related liabilities | $ | 67 |  |  | $ | 74 |  |

- removed (2026-02-04):
[0000833444-25-000063:note_history:31]
|  | June 30, 2025 |  | September 30, 2024 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 278 |  |  | 281 |  |
| Total restricted assets | 284 |  |  | 287 |  |
| Insurance receivables for asbestos-related liabilities | 44 |  |  | 47 |  |
| Total asbestos-related assets | $ | 328 |  |  | $ | 334 |  |

- removed (2026-02-04):
[0000833444-25-000063:note_history:32]
The following table presents the location and amount of insurance receivables in the Company's consolidated statements of financial position (in millions):

- removed (2026-02-04):
[0000833444-25-000063:note_history:33]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 13 |  |  | 13 |  |
| Total insurance receivables | $ | 18 |  |  | $ | 18 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0000833444-26-000019:note_history:34]
|  | December 31, 2025 |  | September 30, 2025 |
| Other current liabilities | $ | 24 |  |  | $ | 27 |  |
| Other noncurrent liabilities | 156 |  |  | 160 |  |
| Total reserves for environmental liabilities | $ | 180 |  |  | $ | 187 |  |
  (was, 2025-08-06, similarity 0.9706):
[0000833444-25-000063:note_history:34]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 23 |  |  | $ | 32 |  |
| Other noncurrent liabilities | 170 |  |  | 179 |  |
| Total reserves for environmental liabilities | $ | 193 |  |  | $ | 211 |  |

- added (2026-02-04):
[0000833444-26-000019:note_history:35]
|  | December 31, 2025 |  | September 30, 2025 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 336 |  |  | 329 |  |
| Total asbestos-related liabilities | 394 |  |  | 387 |  |
| Other current assets | 14 |  |  | 13 |  |
| Other noncurrent assets | 326 |  |  | 326 |  |
| Total asbestos-related assets | 340 |  |  | 339 |  |
| Net asbestos-related liabilities | $ | 54 |  |  | $ | 48 |  |

- added (2026-02-04):
[0000833444-26-000019:note_history:36]
|  | December 31, 2025 |  | September 30, 2025 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 5 |  |
| Investments | 291 |  |  | 290 |  |
| Total restricted assets | 297 |  |  | 295 |  |
| Insurance receivables for asbestos-related liabilities | 43 |  |  | 44 |  |
| Total asbestos-related assets | $ | 340 |  |  | $ | 339 |  |

- changed (2026-02-04):
[0000833444-26-000019:note_history:37]
|  | December 31, 2025 |  | September 30, 2025 |
| Other current liabilities | $ | 89 |  |  | $ | 87 |  |
| Accrued compensation and benefits | 38 |  |  | 38 |  |
| Other noncurrent liabilities | 311 |  |  | 289 |  |
| Total self-insured liabilities | $ | 438 |  |  | $ | 414 |  |
  (was, 2025-08-06, similarity 0.9752):
[0000833444-25-000063:note_history:37]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 96 |  |  | $ | 92 |  |
| Accrued compensation and benefits | 32 |  |  | 20 |  |
| Other noncurrent liabilities | 256 |  |  | 239 |  |
| Total self-insured liabilities | $ | 384 |  |  | $ | 351 |  |

- removed (2026-02-04):
[0000833444-25-000063:note_history:38]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 337 |  |  | 350 |  |
| Total asbestos-related liabilities | 395 |  |  | 408 |  |
| Other current assets | 14 |  |  | 14 |  |
| Other noncurrent assets | 314 |  |  | 320 |  |
| Total asbestos-related assets | 328 |  |  | 334 |  |
| Net asbestos-related liabilities | $ | 67 |  |  | $ | 74 |  |

- removed (2026-02-04):
[0000833444-25-000063:note_history:39]
|  | June 30, 2025 |  | September 30, 2024 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 278 |  |  | 281 |  |
| Total restricted assets | 284 |  |  | 287 |  |
| Insurance receivables for asbestos-related liabilities | 44 |  |  | 47 |  |
| Total asbestos-related assets | $ | 328 |  |  | $ | 334 |  |

- removed (2026-02-04):
[0000833444-25-000063:note_history:40]
The following table presents the location and amount of insurance receivables in the Company's consolidated statements of financial position (in millions):

- removed (2026-02-04):
[0000833444-25-000063:note_history:41]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 13 |  |  | 13 |  |
| Total insurance receivables | $ | 18 |  |  | $ | 18 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0000833444-26-000019:note_history:42]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2025 filed with the SEC on November 14, 2025. The results of operations for the three month period ended December 31, 2025 is not necessarily indicative of results for the Company’s 2026 fiscal year because of seasonal and other factors.
  (was, 2025-08-06, similarity 0.9765):
[0000833444-25-000063:note_history:42]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2024 filed with the SEC on November 19, 2024. The results of operations for the three and nine month periods ended June 30, 2025 are not necessarily indicative of results for the Company’s 2025 fiscal year because of seasonal and other factors.

- added (2026-02-04):
[0000833444-26-000019:note_history:43]
Johnson Controls International plc, headquartered in Cork, Ireland, a global technology leader in energy efficiency, decarbonization, thermal management and mission-critical performance, helps customers use energy more productively, reduce carbon emissions, and operate with the precision and resilience required in rapidly expanding industries such as data centers, healthcare, pharmaceuticals, advanced manufacturing, and higher education.

- changed (2026-02-04):
[0000833444-26-000019:note_history:44]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space) and energy-management consulting. The Company partners with customers by leveraging its broad product portfolio and digital capabilities, together with its direct channel capabilities, to deliver solutions and services addressing distinct and diverse operating environments and regulatory requirements that address customers’ needs in their core missions.
  (was, 2025-08-06, similarity 0.8402):
[0000833444-25-000063:note_history:44]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space) and energy-management consulting. The Company partners with customers by leveraging its broad product portfolio and digital capabilities, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

- changed (2026-02-04):
[0000833444-26-000019:note_history:45]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries in conformity with U.S. GAAP. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.
  (was, 2025-08-06, similarity 0.7443):
[0000833444-25-000063:note_history:45]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries in conformity with U.S. GAAP. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal.

- added (2026-02-04):
[0000833444-26-000019:note_history:46]
Prior Period Revision – Statement of Cash Flows
Amounts reported as "Repayments of debt" and "Proceeds from debt" have been revised for certain short-term debt transactions that occurred in the three months ended December 31, 2024 and were incorrectly presented on a net basis within the financing activities section of the consolidated statements of cash flows. A similar revision for the periods ended March 31, 2025 and June 30, 2025 will be included in future Quarterly Reports on Form 10-Q. Cash provided by financing activities and the total increase (decrease) in cash, cash equivalents and restricted cash were unchanged for all affected periods. The Company does not consider the incorrect presentation to be material to any periods impacted.

- removed (2026-02-04):
[0000833444-25-000063:note_history:47]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, safe, healthy and sustainable buildings, serving a wide range of customers around the globe. The Company’s products and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

- removed (2026-02-04):
[0000833444-25-000063:note_history:48]
As discussed in more detail in Note 3, "Assets and Liabilities Held for Sale and Discontinued Operations", of the notes to the consolidated financial statements, the Company entered into a definitive agreement to sell its Residential and Light Commercial (“R&LC") HVAC business, including the North America Ducted business and the global Residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which Johnson Controls owns 60% and Hitachi owns 40%. The R&LC HVAC business, which was previously reported in the Global Products segment prior to the Company's resegmentation, meets the criteria to be classified as a discontinued operation and, as a result, its historical financial results are reflected in the consolidated financial statements as a discontinued operation, and assets and liabilities are classified as held for sale for all periods presented. Unless otherwise noted, all activities and amounts reported in the following footnotes relate to the continuing operations of the Company and exclude activities and amounts related to the R&LC HVAC business.

- removed (2026-02-04):
[0000833444-25-000063:note_history:49]
Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.

- removed (2026-02-04):
[0000833444-25-000063:note_history:50]
The Company consolidates variable interest entities ("VIE") when it has the power to direct the significant activities of the entity and the obligation to absorb losses or receive benefits from the entity that may be significant. The Company did not have any material consolidated or nonconsolidated VIE's for the presented reporting periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-02-04):
[0000833444-26-000019:note_history:51]
|  | December 31, 2025 |  | September 30, 2025 |
| Commercial paper | $ | 200 |  |  | $ | 400 |  |
| Term loans | 236 |  |  | 320 |  |
| Bank borrowings | — |  |  | 3 |  |
|  | $ | 436 |  |  | $ | 723 |  |
| Weighted average interest rate on short-term debt outstanding | 4.3 | % |  | 4.5 | % |

- added (2026-02-04):
[0000833444-26-000019:note_history:52]
As of December 31, 2025, the Company had an outstanding syndicated committed revolving credit facility of $2.5 billion which is scheduled to expire in December 2028. There were no draws on the facility as of December 31, 2025.

- added (2026-02-04):
[0000833444-26-000019:note_history:53]
The following table presents the Company's net financing charges (in millions):

- added (2026-02-04):
[0000833444-26-000019:note_history:54]
|  | Three Months Ended December 31, |  |
| (in millions) | 2025 |  | 2024 |  |  |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 42 |  |  | $ | 67 |  |  |  |  |  |  |  |
| Other financing charges | 7 |  |  | 6 |  |  |  |  |  |  |  |
| Interest income | (2) |  |  | (3) |  |  |  |  |  |  |  |
| Net foreign exchange results for financing activities | 12 |  |  | 16 |  |  |  |  |  |  |  |
| Net financing charges | $ | 59 |  |  | $ | 86 |  |  |  |  |  |  |  |

- added (2026-02-04):
[0000833444-26-000019:note_history:55]
Net financing charges includes pre-tax losses on derivatives not designated as hedging instruments of $155 million and $144 million for the three months ended December 31, 2025 and 2024, respectively, which are offset by gains resulting from changes in foreign exchange rates on underlying exposures during those periods.

- removed (2026-02-04):
[0000833444-25-000063:note_history:56]
|  | June 30, 2025 |  | September 30, 2024 |
| Commercial paper | $ | 650 |  |  | $ | 350 |  |
| Term loans | 627 |  |  | 603 |  |
|  | $ | 1,277 |  |  | $ | 953 |  |
| Weighted average interest rate on short-term debt outstanding | 4.0 | % |  | 4.8 | % |

- removed (2026-02-04):
[0000833444-25-000063:note_history:57]
As of June 30, 2025, the Company had two syndicated committed revolving credit facilities, including $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2025. There were no draws on the facilities as of June 30, 2025.

- removed (2026-02-04):
[0000833444-25-000063:note_history:58]
In February 2025, the Company repaid €476 million of its 1.375% Notes due 2025 and extinguished $7 million of its 5.125% Notes due 2045 through a bilateral private purchase.

- removed (2026-02-04):
[0000833444-25-000063:note_history:59]
In December 2024, the Company and its wholly-owned subsidiary, Tyco Fire & Security Finance S.C.A, co-issued the following unsecured, unsubordinated senior notes:

- removed (2026-02-04):
[0000833444-25-000063:note_history:60]
•$250 million 4.900% Senior Notes due 2032. These notes are a further issuance of the $400 million, 4.900% Senior Notes due 2032, which were originally issued in September 2022.

- removed (2026-02-04):
[0000833444-25-000063:note_history:61]
•€500 million 3.125% Senior Notes due 2033.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0000833444-26-000019:note_history:62]
The fair value of long-term debt at December 31, 2025 and September 30, 2025 was as follows (in billions):
  (was, 2025-08-06, similarity 0.9468):
[0000833444-25-000063:note_history:62]
The fair value of long-term debt at June 30, 2025 and September 30, 2024 was as follows (in billions):

- changed (2026-02-04):
[0000833444-26-000019:note_history:63]
|  |  | December 31, |  | September 30, |
|  | 2025 |  | 2025 |
| Public debt |  | $ | 8.4 |  |  | $ | 8.4 |  |
| Other long-term debt |  | 0.6 |  |  | 0.5 |  |
| Total fair value of long-term debt |  | $ | 9.0 |  |  | $ | 8.9 |  |
  (was, 2025-08-06, similarity 0.9737):
[0000833444-25-000063:note_history:63]
|  |  | June 30, |  | September 30, |
|  | 2025 |  | 2024 |
| Public debt |  | $ | 8.3 |  |  | $ | 8.1 |  |
| Other long-term debt |  | 0.3 |  |  | 0.2 |  |
| Total fair value of long-term debt |  | $ | 8.6 |  |  | $ | 8.3 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-02-04):
[0000833444-26-000019:note_history:64]
|  | December 31, 2025 |  | September 30, 2025 |
| Commercial paper | $ | 200 |  |  | $ | 400 |  |
| Term loans | 236 |  |  | 320 |  |
| Bank borrowings | — |  |  | 3 |  |
|  | $ | 436 |  |  | $ | 723 |  |
| Weighted average interest rate on short-term debt outstanding | 4.3 | % |  | 4.5 | % |

- added (2026-02-04):
[0000833444-26-000019:note_history:65]
The following table presents the Company's net financing charges (in millions):

- added (2026-02-04):
[0000833444-26-000019:note_history:66]
|  | Three Months Ended December 31, |  |
| (in millions) | 2025 |  | 2024 |  |  |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 42 |  |  | $ | 67 |  |  |  |  |  |  |  |
| Other financing charges | 7 |  |  | 6 |  |  |  |  |  |  |  |
| Interest income | (2) |  |  | (3) |  |  |  |  |  |  |  |
| Net foreign exchange results for financing activities | 12 |  |  | 16 |  |  |  |  |  |  |  |
| Net financing charges | $ | 59 |  |  | $ | 86 |  |  |  |  |  |  |  |

- removed (2026-02-04):
[0000833444-25-000063:note_history:67]
|  | June 30, 2025 |  | September 30, 2024 |
| Commercial paper | $ | 650 |  |  | $ | 350 |  |
| Term loans | 627 |  |  | 603 |  |
|  | $ | 1,277 |  |  | $ | 953 |  |
| Weighted average interest rate on short-term debt outstanding | 4.0 | % |  | 4.8 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0000833444-26-000019:note_history:68]
The following table presents the Company's revenues disaggregated by segment and by Products & Systems and Services revenue (in millions):
  (was, 2025-08-06, similarity 0.9928):
[0000833444-25-000063:note_history:68]
The following tables present the Company's revenues disaggregated by segment and by Products & Systems and Services revenue (in millions):

- changed (2026-02-04):
[0000833444-26-000019:note_history:69]
|  |  | Three Months Ended December 31, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 2,640 |  |  | $ | 1,203 |  |  | $ | 3,843 |  |  | $ | 2,536 |  |  | $ | 1,091 |  |  | $ | 3,627 |  |
| EMEA |  | 762 |  |  | 499 |  |  | 1,261 |  |  | 700 |  |  | 457 |  |  | 1,157 |  |
| APAC |  | 490 |  |  | 203 |  |  | 693 |  |  | 449 |  |  | 193 |  |  | 642 |  |
| Total |  | $ | 3,892 |  |  | $ | 1,905 |  |  | $ | 5,797 |  |  | $ | 3,685 |  |  | $ | 1,741 |  |  | $ | 5,426 |  |
  (was, 2025-08-06, similarity 0.986):
[0000833444-25-000063:note_history:69]
|  |  | Three Months Ended June 30, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 2,847 |  |  | $ | 1,195 |  |  | $ | 4,042 |  |  | $ | 2,887 |  |  | $ | 1,148 |  |  | $ | 4,035 |  |
| EMEA |  | 756 |  |  | 517 |  |  | 1,273 |  |  | 710 |  |  | 467 |  |  | 1,177 |  |
| APAC |  | 519 |  |  | 218 |  |  | 737 |  |  | 492 |  |  | 194 |  |  | 686 |  |
| Total |  | $ | 4,122 |  |  | $ | 1,930 |  |  | $ | 6,052 |  |  | $ | 4,089 |  |  | $ | 1,809 |  |  | $ | 5,898 |  |

- removed (2026-02-04):
[0000833444-25-000063:note_history:70]
|  |  | Nine Months Ended June 30, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 8,094 |  |  | $ | 3,412 |  |  | $ | 11,506 |  |  | $ | 8,114 |  |  | $ | 3,227 |  |  | $ | 11,341 |  |
| EMEA |  | 2,177 |  |  | 1,454 |  |  | 3,631 |  |  | 2,086 |  |  | 1,354 |  |  | 3,440 |  |
| APAC |  | 1,401 |  |  | 616 |  |  | 2,017 |  |  | 1,376 |  |  | 547 |  |  | 1,923 |  |
| Total |  | $ | 11,672 |  |  | $ | 5,482 |  |  | $ | 17,154 |  |  | $ | 11,576 |  |  | $ | 5,128 |  |  | $ | 16,704 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0000833444-26-000019:note_history:71]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $24.5 billion, of which approximately 65% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations of service contracts with a duration of one year or less and open purchase orders from the indirect third-party sales channel that have a short cycle time (generally 60 days or less).
  (was, 2025-08-06, similarity 0.8623):
[0000833444-25-000063:note_history:71]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of June 30, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $22.4 billion, of which approximately 63% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.

- changed (2026-02-04):
[0000833444-26-000019:note_history:72]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and design costs that relate to a contract or an anticipated contract that the Company expects to recover. Costs to obtain or fulfill a contract are capitalized when incurred and amortized to expense over the period of contract performance.
  (was, 2025-08-06, similarity 0.9707):
[0000833444-25-000063:note_history:72]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and design costs that relate to a contract or an anticipated contract that the Company expects to recover. Costs to obtain or fulfill a contract are capitalized and amortized over the period of contract performance.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-04):
[0000833444-26-000019:note_history:73]
The following table presents the Company's revenues disaggregated by segment and by Products & Systems and Services revenue (in millions):
  (was, 2025-08-06, similarity 0.9928):
[0000833444-25-000063:note_history:73]
The following tables present the Company's revenues disaggregated by segment and by Products & Systems and Services revenue (in millions):

- changed (2026-02-04):
[0000833444-26-000019:note_history:74]
|  |  | Three Months Ended December 31, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 2,640 |  |  | $ | 1,203 |  |  | $ | 3,843 |  |  | $ | 2,536 |  |  | $ | 1,091 |  |  | $ | 3,627 |  |
| EMEA |  | 762 |  |  | 499 |  |  | 1,261 |  |  | 700 |  |  | 457 |  |  | 1,157 |  |
| APAC |  | 490 |  |  | 203 |  |  | 693 |  |  | 449 |  |  | 193 |  |  | 642 |  |
| Total |  | $ | 3,892 |  |  | $ | 1,905 |  |  | $ | 5,797 |  |  | $ | 3,685 |  |  | $ | 1,741 |  |  | $ | 5,426 |  |
  (was, 2025-08-06, similarity 0.986):
[0000833444-25-000063:note_history:74]
|  |  | Three Months Ended June 30, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 2,847 |  |  | $ | 1,195 |  |  | $ | 4,042 |  |  | $ | 2,887 |  |  | $ | 1,148 |  |  | $ | 4,035 |  |
| EMEA |  | 756 |  |  | 517 |  |  | 1,273 |  |  | 710 |  |  | 467 |  |  | 1,177 |  |
| APAC |  | 519 |  |  | 218 |  |  | 737 |  |  | 492 |  |  | 194 |  |  | 686 |  |
| Total |  | $ | 4,122 |  |  | $ | 1,930 |  |  | $ | 6,052 |  |  | $ | 4,089 |  |  | $ | 1,809 |  |  | $ | 5,898 |  |

- added (2026-02-04):
[0000833444-26-000019:note_history:75]
|  |  | Location of contract balances |  | December 31, 2025 |  | September 30, 2025 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,343 |  |  | $ | 2,178 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 6 |  |  | 9 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,542 |  |  | 2,470 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 501 |  |  | 478 |  |  |  |

- changed (2026-02-04):
[0000833444-26-000019:note_history:76]
For the three months ended December 31, 2025 and 2024, the Company recognized revenue of $1,004 million and $878 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.
  (was, 2025-08-06, similarity 0.6527):
[0000833444-25-000063:note_history:76]
For the three months ended June 30, 2025 and 2024, the Company recognized revenue of $279 million and $267 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year. For the nine months ended June 30, 2025 and 2024, the Company recognized revenue of $1,550 million and $1,475 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.

- changed (2026-02-04):
[0000833444-26-000019:note_history:77]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $24.5 billion, of which approximately 65% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations of service contracts with a duration of one year or less and open purchase orders from the indirect third-party sales channel that have a short cycle time (generally 60 days or less).
  (was, 2025-08-06, similarity 0.8623):
[0000833444-25-000063:note_history:77]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of June 30, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $22.4 billion, of which approximately 63% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.

- changed (2026-02-04):
[0000833444-26-000019:note_history:78]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and design costs that relate to a contract or an anticipated contract that the Company expects to recover. Costs to obtain or fulfill a contract are capitalized when incurred and amortized to expense over the period of contract performance.
  (was, 2025-08-06, similarity 0.9707):
[0000833444-25-000063:note_history:78]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and design costs that relate to a contract or an anticipated contract that the Company expects to recover. Costs to obtain or fulfill a contract are capitalized and amortized over the period of contract performance.

- changed (2026-02-04):
[0000833444-26-000019:note_history:79]
|  | December 31, 2025 |  | September 30, 2025 |  |  |
| Other current assets | $ | 320 |  |  | $ | 327 |  |  |  |
| Other noncurrent assets | 233 |  |  | 249 |  |  |  |
| Total | $ | 553 |  |  | $ | 576 |  |  |  |
  (was, 2025-08-06, similarity 0.9708):
[0000833444-25-000063:note_history:79]
|  | June 30, 2025 |  | September 30, 2024 |  |  |
| Other current assets | $ | 306 |  |  | $ | 265 |  |  |  |
| Other noncurrent assets | 257 |  |  | 291 |  |  |  |
| Total | $ | 563 |  |  | $ | 556 |  |  |  |

- added (2026-02-04):
[0000833444-26-000019:note_history:80]
Amortization of costs to obtain or fulfill a contract was $102 million and $84 million during the three months ended December 31, 2025 and 2024, respectively.

- removed (2026-02-04):
[0000833444-25-000063:note_history:81]
|  |  | Nine Months Ended June 30, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 8,094 |  |  | $ | 3,412 |  |  | $ | 11,506 |  |  | $ | 8,114 |  |  | $ | 3,227 |  |  | $ | 11,341 |  |
| EMEA |  | 2,177 |  |  | 1,454 |  |  | 3,631 |  |  | 2,086 |  |  | 1,354 |  |  | 3,440 |  |
| APAC |  | 1,401 |  |  | 616 |  |  | 2,017 |  |  | 1,376 |  |  | 547 |  |  | 1,923 |  |
| Total |  | $ | 11,672 |  |  | $ | 5,482 |  |  | $ | 17,154 |  |  | $ | 11,576 |  |  | $ | 5,128 |  |  | $ | 16,704 |  |

- removed (2026-02-04):
[0000833444-25-000063:note_history:82]
|  |  | Location of contract balances |  | June 30, 2025 |  | September 30, 2024 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,119 |  |  | $ | 1,931 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 7 |  |  | 11 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,428 |  |  | 2,160 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 269 |  |  | 252 |  |  |  |

- removed (2026-02-04):
[0000833444-25-000063:note_history:83]
During the three months ended June 30, 2025 and 2024, the Company recognized expense of $104 million and $84 million, respectively, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2025 and 2024, the Company recognized expense of $279 million and $218 million, respectively, related to costs to obtain or fulfill a contract.
