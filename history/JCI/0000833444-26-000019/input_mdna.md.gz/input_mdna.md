# JCI MD&A — 0000833444-26-000019


## mdna

[0000833444-26-000019:mdna:1]
[same as prior period, unchanged from 0000833444-25-000063:mdna:1]

[0000833444-26-000019:mdna:2]
[same as prior period, unchanged from 0000833444-25-000063:mdna:2]

[0000833444-26-000019:mdna:3]
[same as prior period, unchanged from 0000833444-25-000063:mdna:3]

[0000833444-26-000019:mdna:4]
[same as prior period, unchanged from 0000833444-25-000063:mdna:4]

[0000833444-26-000019:mdna:5]
Johnson Controls International plc, headquartered in Cork, Ireland, a global technology leader in energy efficiency, decarbonization, thermal management and mission-critical performance, helps customers use energy more productively, reduce carbon emissions, and operate with the precision and resilience required in rapidly expanding industries such as data centers, healthcare, pharmaceuticals, advanced manufacturing, and higher education.

[0000833444-26-000019:mdna:6]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space) and energy-management consulting. The Company partners with customers by leveraging its broad product portfolio and digital capabilities, together with its direct channel capabilities, to deliver solutions and services addressing distinct and diverse operating environments and regulatory requirements that address customers’ needs in their core missions.

[0000833444-26-000019:mdna:7]
The following information should be read in conjunction with the September 30, 2025 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in the Company's Annual Report on Form 10-K for the year ended September 30, 2025 filed with the SEC on November 14, 2025. References in the following discussion and analysis to "Three Months," "First Quarter" or similar language refer to the three months ended December 31, 2025 compared to the three months ended December 31, 2024.

[0000833444-26-000019:mdna:8]
[same as prior period, unchanged from 0000833444-25-000063:mdna:10]

[0000833444-26-000019:mdna:9]
Much of the demand for the Company’s products, services and solutions is driven by commercial, institutional, industrial, data center and governmental construction, industrial facility expansion, retrofit activity, maintenance projects and other capital investments in buildings within the sectors that the Company serves. Construction and other capital investment projects are heavily dependent on general economic conditions, localized demand for real estate and availability of credit, public funding or other sources of financing. In addition, most real estate developers rely heavily on project financing in order to initiate and complete projects. Positive or negative fluctuations in these dependencies could have a corresponding impact on the Company’s financial condition, results of operations and cash flows.

[0000833444-26-000019:mdna:10]
The Company maintains global operations. The United States has announced tariffs and reciprocal tariffs on a wide range of products manufactured or produced worldwide, including Canada, China, the European Union, Japan, India and Mexico, among others. Several countries have similarly announced reciprocal or other tariffs impacting products manufactured or produced in the United States. In addition, the United States and other nations have, and may in the future, pause, reimpose, decrease or increase tariffs. Although the Company has been largely able to mitigate the impact of tariffs that have been enacted to date, if additional tariffs and reciprocal tariffs are implemented (whether as currently proposed or otherwise), such actions could negatively impact the Company's revenue growth and margins in future periods through decreased sales and increased cost of goods sold. Further, the Company has experienced, and could again experience, increased material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends including the imposition of tariffs and other restrictive trade measures, as well as geopolitical and economic tensions. The net effect of these events will continue to depend on the Company’s ability to successfully mitigate and offset their impact.

[0000833444-26-000019:mdna:11]
The Company is taking actions to mitigate the actual and anticipated impact of these events, including strengthening the Company's in region, for region manufacturing strategy, pivoting to local sourcing in its supply chain, accelerating pricing actions and asserting contractual rights through change orders. The Company has historically taken a variety of actions to mitigate trade restrictions, supply chain disruptions and inflation, including through expanding and redistributing its supplier network, supplier financing, accelerated purchasing and productivity improvements. These actions have largely been successful in mitigating the impacts of the current macroeconomic environment, however, it is uncertain as to whether the actions taken or contemplated to be taken by the Company will be effective in continuing to mitigate the impact of current and future trade restrictions and their related impacts. The Company continues to actively monitor and evaluate the development and potential impacts of tariffs and other trade restrictions on its supply chain and results of operations.

[0000833444-26-000019:mdna:12]
As a result of the Company’s global presence, a significant portion of its revenues and expenses are denominated in currencies other than the U.S. dollar, which results in non-U.S. currency risks and exchange exposure. While the Company employs financial instruments to hedge some of its transactional foreign exchange exposure, these activities do not insulate it completely from those exposures. In addition, currency exposure from the translation of non-U.S. dollar functional currency subsidiaries cannot be hedged. Exchange rates can be volatile and a substantial weakening or strengthening of foreign currencies against the U.S. dollar could increase or reduce the Company’s profit margin, respectively, and impact the comparability of results from period to period.

[0000833444-26-000019:mdna:13]
The Company continues to observe trends demonstrating increased interest and demand for its products and services that enable smart, efficient and sustainable buildings, which are driven in part by government tax incentives, building performance standards and other regulations designed to limit emissions and combat climate change. In particular, legislative and regulatory initiatives such as the EU Energy Efficiency Directive, EU Heat Transition, U.S. Inflation Reduction Act and EU Energy Performance of Buildings Directive include provisions designed to fund and encourage investment in decarbonization and digital technologies for buildings. This demand is supplemented by commitments in both the public and private sectors to reduce emissions and/or achieve net zero emissions. In addition, the increased maturity and adoption of AI and high-performance computing is currently impacting the microchip and data center industry and driving technology innovation, which has led to increased demand for hyperscale and data center cooling solutions that deliver heat management and energy efficiency. The Company seeks to capitalize on these trends to enable delivery of sustainable, high-efficiency products and tailored services to empower customers to achieve their sustainability, heat management and energy efficiency goals. The Company is leveraging its install base, together with data-driven products and services, to offer outcome-based solutions to customers with a focus on generating accelerated growth in services and recurring revenue.

[0000833444-26-000019:mdna:14]
Certain of our customers, including governmental and institutional customers, have exhibited increased uncertainty regarding future spending decisions due to various political and economic factors, including budget reductions, reprioritization of spending, interest rate fluctuation and economic uncertainty. This uncertainty has and may in the future impact on the Company's ability to predict and forecast the revenue and backlog associated with these customers.

[0000833444-26-000019:mdna:15]
The extent to which the Company’s results of operations and financial condition are impacted by these and other factors in the future will depend on developments that are highly uncertain and cannot be predicted. See the section entitled "Risk Factors" in Johnson Controls' Annual Report on Form 10-K for the year ended September 30, 2025 filed with the United States Securities and Exchange Commission ("SEC") on November 14, 2025. Certain of these risk factors have been updated and supplemented  in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0000833444-26-000019:mdna:16]
[same as prior period, unchanged from 0000833444-25-000063:mdna:21]

[0000833444-26-000019:mdna:17]
During the fourth quarter of fiscal 2024, the Company committed to a multi-year restructuring plan to address stranded costs and further right-size global operations as a result of previously announced portfolio simplification actions.

[0000833444-26-000019:mdna:18]
It is expected that the plan will be completed in fiscal 2027 and the Company will incur one-time restructuring costs, including severance and other employee termination benefits, contract termination costs, and certain other related cash and non-cash charges, totaling approximately $400 million, resulting in expected annual cost savings of approximately $500 million upon full completion of the plan. Restructuring costs will be incurred across all segments and Corporate functions. Refer to Note 14, "Restructuring and Related Costs," for an update on the restructuring plan.

[0000833444-26-000019:mdna:19]
[same as prior period, unchanged from 0000833444-25-000063:mdna:28]

[0000833444-26-000019:mdna:20]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2025 |  | 2024 |  | Change |  |  |  |  |  |  |
| Net sales | $ | 5,797 |  |  | $ | 5,426 |  |  | 7 | % |  |  |  |  |  |  |

[0000833444-26-000019:mdna:21]
The increase in net sales for the three months ended December 31, 2025 was due to higher organic sales ($311 million) and the favorable impact of foreign currency translation ($72 million), partially offset by the net impact of acquisitions and divestitures ($12 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, net sales increased 6% over the prior year, driven by growth across all segments, led by the Americas.

[0000833444-26-000019:mdna:22]
[same as prior period, unchanged from 0000833444-25-000063:mdna:32]

[0000833444-26-000019:mdna:23]
33

[0000833444-26-000019:mdna:24]
[same as prior period, unchanged from 0000833444-25-000063:mdna:33]

[0000833444-26-000019:mdna:25]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2025 |  | 2024 |  | Change |  |  |  |  |  |  |
| Cost of sales | $ | 3,723 |  |  | $ | 3,500 |  |  | 6 | % |  |  |  |  |  |  |
| Gross profit | 2,074 |  |  | 1,926 |  |  | 8 | % |  |  |  |  |  |  |
| % of sales | 35.8 | % |  | 35.5% |  | 30 | bp |  |  |  |  |  |  |

[0000833444-26-000019:mdna:26]
The increase in gross profit for the three months ended December 31, 2025 was primarily due to margin improvements as a result of disciplined execution across pricing, productivity, and project delivery.

[0000833444-26-000019:mdna:27]
Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings.

[0000833444-26-000019:mdna:28]
Selling, General and Administrative Expenses ("SG&A")

[0000833444-26-000019:mdna:29]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2025 |  | 2024 |  | Change |  |  |  |  |  |  |
| SG&A | $ | 1,221 |  |  | $ | 1,399 |  |  | (13 | %) |  |  |  |  |  |  |
| % of sales | 21.1 | % |  | 25.8 | % |  | (470) | bp |  |  |  |  |  |  |

[0000833444-26-000019:mdna:30]
The decrease in SG&A was primarily due to AFFF insurance recoveries related to the previously disclosed water systems settlement ($130 million) and the gain on the ADT Mexico business divestiture ($70 million).

[0000833444-26-000019:mdna:31]
Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings. Refer to Note 18, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement.

[0000833444-26-000019:mdna:32]
[same as prior period, unchanged from 0000833444-25-000063:mdna:42]

[0000833444-26-000019:mdna:33]
|  | Three Months Ended December 31, |  |
| (in millions) | 2025 |  | 2024 |  |  |  |  |  |  |
| Restructuring and related costs | $ | 37 |  |  | $ | 33 |  |  |  |  |  |  |  |
| Other impairments | 50 |  |  | — |  |  |  |  |  |  |  |
| Restructuring and impairment costs | $ | 87 |  |  | $ | 33 |  |  |  |  |  |  |  |

[0000833444-26-000019:mdna:34]
[same as prior period, unchanged from 0000833444-25-000063:mdna:44]

[0000833444-26-000019:mdna:35]
[same as prior period, unchanged from 0000833444-25-000063:mdna:45]

[0000833444-26-000019:mdna:36]
Refer to Note 9, "Debt and Financing Arrangements," of the notes to the consolidated financial statements for further disclosure related to the Company's net financing charges and debt.

[0000833444-26-000019:mdna:37]
[same as prior period, unchanged from 0000833444-25-000063:mdna:48]

[0000833444-26-000019:mdna:38]
|  | Three Months Ended December 31, |  |
| (in millions) | 2025 |  | 2024 |  |  |  |  |  |  |
| Income tax provision | $ | 152 |  |  | $ | 47 |  |  |  |  |  |  |  |
| Effective tax rate | 21.4 | % |  | 11.5 | % |  |  |  |  |  |  |

[0000833444-26-000019:mdna:39]
[same as prior period, unchanged from 0000833444-25-000063:mdna:50]

[0000833444-26-000019:mdna:40]
[same as prior period, unchanged from 0000833444-25-000063:mdna:51]

[0000833444-26-000019:mdna:41]
The Chief Executive Officer, the Company’s chief operating decision maker ("CODM"), evaluates the performance of its segments and allocates resources based on two profitability measures, Segment EBITA and Segment EBIT:

[0000833444-26-000019:mdna:42]
•Segment earnings before interest, taxes, and amortization (“EBITA”) represents income from continuing operations, before income taxes and noncontrolling interests, excluding corporate expenses, restructuring and impairment costs, AFFF related settlement costs and insurance recoveries, gains or losses on divestitures, net mark-to-market gains and losses related to pension and postretirement plans and restricted asbestos investments, net finance charges, and amortization.  Segment EBITA is used as a tool to allow the CODM to evaluate the recurring profitability of the segments, including revenues and expenses that are within the operational control of the segments, and excluding the impact of certain non-cash and non-recurring items. Segment EBITA also provides the CODM with performance comparability across periods and for more accurate benchmarking against peer companies that may not have similar historical acquisition activity, by holding constant the impact of significant acquisitions.

[0000833444-26-000019:mdna:43]
•Segment earnings before interest and taxes ("EBIT") represents Segment EBITA, adding back the impact of amortization of intangible assets. Segment EBIT allows the CODM to review profitability, inclusive of the impact of significant acquisition activity, informing the CODM of how the business is integrating key strategic initiatives and generating synergies.

[0000833444-26-000019:mdna:44]
Both EBITA and EBIT are reviewed by the CODM and compared against the profit plan and forecast for the current and prior year. Segment EBITA and Segment EBIT are not defined under GAAP and may not be comparable to similarly titled measures used by other companies. Measures of total assets by reportable segment are not provided to the CODM. Therefore, asset information by segment is not disclosed.

[0000833444-26-000019:mdna:45]
[same as prior period, unchanged from 0000833444-25-000063:mdna:53]

[0000833444-26-000019:mdna:46]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2025 |  | 2024 |  | Change |  |  |  |  |  |  |
| Americas | $ | 3,843 |  |  | $ | 3,627 |  |  | 6 | % |  |  |  |  |  |  |
| EMEA | 1,261 |  |  | 1,157 |  |  | 9 | % |  |  |  |  |  |  |
| APAC | 693 |  |  | 642 |  |  | 8 | % |  |  |  |  |  |  |
|  | $ | 5,797 |  |  | $ | 5,426 |  |  | 7 | % |  |  |  |  |  |  |

[0000833444-26-000019:mdna:47]
•The increase in Americas was primarily due to organic growth ($210 million). Excluding the impact of divestitures and foreign currency translation, sales increased 6%, led by continued strength across Applied HVAC and Controls. Products and Systems sales increased 4% and Services increased 10%.

[0000833444-26-000019:mdna:48]
•The increase in EMEA was primarily due to the favorable impact of foreign currency translation ($65 million) and organic growth ($51 million). Excluding the impact of foreign currency translation, sales increased 4%, led by 8% growth in Services.

[0000833444-26-000019:mdna:49]
•The increase in APAC was primarily due to organic growth ($50 million). Excluding the impact of foreign currency translation, sales increased 8%, led by 9% growth in Products and Systems.

[0000833444-26-000019:mdna:50]
Segment EBITA and Segment EBIT

[0000833444-26-000019:mdna:51]
|  | Segment EBITAThree Months Ended December 31, |  | Segment EBITThree Months Ended December 31, |  |  |
| (in millions) | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 | Change |  |  |  |  |  |  |
| Americas | $ | 620 |  |  | $ | 589 |  |  | 5 | % |  | $ | 544 |  |  | $ | 494 |  | 10 | % |  |  |  |  |  |  |
| EMEA | 158 |  |  | 136 |  |  | 16 | % |  | 151 |  |  | 116 |  | 30 | % |  |  |  |  |  |  |
| APAC | 117 |  |  | 90 |  |  | 30 | % |  | 113 |  |  | 85 |  | 33 | % |  |  |  |  |  |  |

[0000833444-26-000019:mdna:52]
•The increase in Americas was primarily due to productivity improvements and improved mix.

[0000833444-26-000019:mdna:53]
•The increase in EMEA was primarily driven by favorable pricing and productivity improvements.

[0000833444-26-000019:mdna:54]
•The increase in APAC was primarily driven by increased volumes and productivity improvements.

[0000833444-26-000019:mdna:55]
[same as prior period, unchanged from 0000833444-25-000063:mdna:73]

[0000833444-26-000019:mdna:56]
Backlog and orders are additional metrics that are meant to provide management with a deeper level of insight into the progress of specific strategic and growth initiatives. Orders provide management with a signal of customer demand for the Company's products and services, as well as an indication of future revenues and performance. However, the timing and conversion of backlog and orders are subject to numerous uncertainties and risks and are not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-26-000019:mdna:57]
The following table summarizes backlog and orders by segment:

[0000833444-26-000019:mdna:58]
|  | Backlog |  | Orders |
| (in billions) | December 31, 2025 |  |  |  | Year-over-Year Change (1) |  | Three Months Ended December 31, 2025 |  |  |  | Year-over-Year Change (1) |
| Americas | $ | 13.3 |  |  |  |  | 22 | % |  | $ | 5.0 |  |  |  |  | 56 | % |
| EMEA | 3.0 |  |  |  |  | 11 | % |  | 1.3 |  |  |  |  | 8 | % |
| APAC | 1.9 |  |  |  |  | 20 | % |  | 0.7 |  |  |  |  | 10 | % |
| Total | $ | 18.2 |  |  |  |  | 20 | % |  | $ | 7.0 |  |  |  |  | 39 | % |

[0000833444-26-000019:mdna:59]
(1) Change is compared to December 31, 2024 (backlog) and the three months ended December 31, 2024 (orders) and excludes the impact of acquisitions, divestitures and foreign currency.

[0000833444-26-000019:mdna:60]
•The increase in backlog and orders was primarily due to demand led by customers' accelerated investments in data center projects.

[0000833444-26-000019:mdna:61]
Remaining performance obligations were $24.5 billion at December 31, 2025. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-26-000019:mdna:62]
[same as prior period, unchanged from 0000833444-25-000063:mdna:79]

[0000833444-26-000019:mdna:63]
[same as prior period, unchanged from 0000833444-25-000063:mdna:80]

[0000833444-26-000019:mdna:64]
[same as prior period, unchanged from 0000833444-25-000063:mdna:81]

[0000833444-26-000019:mdna:65]
The Company reports backlog, which it believes is a useful measure of evaluating the Company's operational performance and relationship to total orders.

[0000833444-26-000019:mdna:66]
[same as prior period, unchanged from 0000833444-25-000063:mdna:82]

[0000833444-26-000019:mdna:67]
[same as prior period, unchanged from 0000833444-25-000063:mdna:83]

[0000833444-26-000019:mdna:68]
| (in millions) | December 31, 2025 |  | September 30, 2025 |  | Change |
| Current assets | $ | 10,441 |  |  | $ | 10,162 |  |  |  |
| Current liabilities | 10,501 |  |  | 10,941 |  |  |  |
| Working capital | $ | (60) |  |  | $ | (779) |  |  | (92) | % |
| Accounts receivable - net | $ | 6,190 |  |  | $ | 6,269 |  |  | (1) | % |
| Inventories | 1,932 |  |  | 1,820 |  |  | 6 | % |
| Accounts payable | 3,614 |  |  | 3,614 |  |  | — | % |

[0000833444-26-000019:mdna:69]
The increase in working capital at December 31, 2025 as compared to September 30, 2025 was primarily due to increases in cash and inventories and decreases in short-term debt and accrued compensation, partially offset by the net impact of other current assets and liabilities.

[0000833444-26-000019:mdna:70]
[same as prior period, unchanged from 0000833444-25-000063:mdna:86]

[0000833444-26-000019:mdna:71]
|  |  | Three Months Ended December 31, |
| (in millions) |  | 2025 |  | 2024 |
| Cash provided by operating activities |  | $ | 611 |  |  | $ | 249 |  |
| Cash provided (used) by investing activities |  | 90 |  |  | (105) |  |
| Cash provided (used) by financing activities |  | (464) |  |  | 201 |  |

[0000833444-26-000019:mdna:72]
The increase in cash provided by operating activities primarily reflects higher net income and favorable changes in accounts payable and accrued liabilities.

[0000833444-26-000019:mdna:73]
The change in investing activities was due to proceeds from the ADT Mexico divestiture.

[0000833444-26-000019:mdna:74]
The change in financing activities was primarily due to changes in net debt activity, partially offset by lower stock repurchases.

[0000833444-26-000019:mdna:75]
[same as prior period, unchanged from 0000833444-25-000063:mdna:27]

[0000833444-26-000019:mdna:76]
[same as prior period, unchanged from 0000833444-25-000063:mdna:91]

[0000833444-26-000019:mdna:77]
| (in millions) | December 31, 2025 |  | September 30, 2025 |  |
| Short-term debt | $ | 436 |  |  | $ | 723 |  |  |
| Current portion of long-term debt | 568 |  |  | 566 |  |  |
| Long-term debt | 8,701 |  |  | 8,591 |  |  |
| Total debt | 9,705 |  |  | 9,880 |  |  |
| Less: Cash and cash equivalents | 552 |  |  | 379 |  |  |
| Net debt | $ | 9,153 |  |  | $ | 9,501 |  |  |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders ("Equity") | $ | 13,204 |  |  | $ | 12,927 |  |  |
| Total capitalization (Total debt plus Equity) | 22,909 |  |  | 22,807 |  |  |
| Net capitalization (Net debt plus Equity) | 22,357 |  |  | 22,428 |  |  |
| Total debt as a % of Total capitalization | 42.4 | % |  | 43.3 | % |  |
| Net debt as a % of Net capitalization | 40.9 | % |  | 42.4 | % |  |

[0000833444-26-000019:mdna:78]
[same as prior period, unchanged from 0000833444-25-000063:mdna:93]

[0000833444-26-000019:mdna:79]
•As of December 31, 2025, approximately $4.8 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity, and the economic environment.

[0000833444-26-000019:mdna:80]
•The Company declared a dividend of $0.40 per common share in the quarter ended December 31, 2025 and intends to continue paying dividends throughout fiscal 2026.

[0000833444-26-000019:mdna:81]
•The Company believes its capital resources and liquidity position, including cash and cash equivalents of $552 million at December 31, 2025, are adequate to fund operations and meet its cash obligations for the foreseeable future.

[0000833444-26-000019:mdna:82]
–The Company manages its short-term debt position in the U.S. and euro commercial paper and bank loan markets. Commercial paper outstanding totaled $200 million as of December 31, 2025 and $400 million as of September 30, 2025.

[0000833444-26-000019:mdna:83]
[same as prior period, unchanged from 0000833444-25-000063:mdna:99]

[0000833444-26-000019:mdna:84]
–The Company also has the ability to draw on its $2.5 billion revolving credit facility which is scheduled to expire in December 2028. There were no draws on the revolving credit facility as of December 31, 2025 and September 30, 2025.

[0000833444-26-000019:mdna:85]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of December 31, 2025, the Company's credit ratings and outlook were as follows:

[0000833444-26-000019:mdna:86]
[same as prior period, unchanged from 0000833444-25-000063:mdna:102]

[0000833444-26-000019:mdna:87]
[same as prior period, unchanged from 0000833444-25-000063:mdna:103]

[0000833444-26-000019:mdna:88]
•Financial covenants in the Company's revolving credit facilities require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of December 31, 2025, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-26-000019:mdna:89]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at its Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-26-000019:mdna:90]
[same as prior period, unchanged from 0000833444-25-000063:mdna:107]

[0000833444-26-000019:mdna:91]
[same as prior period, unchanged from 0000833444-25-000063:mdna:109]

[0000833444-26-000019:mdna:92]
[same as prior period, unchanged from 0000833444-25-000063:mdna:110]

[0000833444-26-000019:mdna:93]
•€500 million aggregate principal amount of 0.375% Senior Notes due September 2027

[0000833444-26-000019:mdna:94]
•€600 million aggregate principal amount of 3.000% Senior Notes due September 2028

[0000833444-26-000019:mdna:95]
•$700 million aggregate principal amount of 5.500% Senior Notes due April 2029

[0000833444-26-000019:mdna:96]
•$625 million aggregate principal amount of 1.750% Senior Notes due September 2030

[0000833444-26-000019:mdna:97]
•$500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due September 2031

[0000833444-26-000019:mdna:98]
•€500 million aggregate principal amount of 1.000% Senior Notes due September 2032

[0000833444-26-000019:mdna:99]
•$650 million aggregate principal amount of 4.900% Senior Notes due December 2032

[0000833444-26-000019:mdna:100]
39

[0000833444-26-000019:mdna:101]
•€500 million aggregate principal amount of 3.125% Senior Notes due December 2033

[0000833444-26-000019:mdna:102]
•€800 million aggregate principal amount of 4.250% Senior Notes due May 2035

[0000833444-26-000019:mdna:103]
TFSCA is a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”) and is a wholly-owned consolidated subsidiary of the Company that is 99.924% owned directly by the Parent Company and 0.076% owned by TFSCA’s sole general partner and manager, Tyco Fire & Security S.à r.l., which is itself wholly-owned by the Company. The Parent Company is incorporated and organized under the laws of Ireland. TFSCA is incorporated and organized under the laws of Luxembourg. The bankruptcy, insolvency, administrative, debtor relief and other laws of Luxembourg or Ireland, as applicable, may be materially different from, or in conflict with, those of the United States, including in the areas of rights of creditors, priority of governmental and other creditors, ability to obtain post-petition interest and duration of the proceeding. The application of these laws, or any conflict among them, could adversely affect noteholders’ ability to enforce their rights under the Notes in those jurisdictions or limit any amounts that they may receive.

[0000833444-26-000019:mdna:104]
[same as prior period, unchanged from 0000833444-25-000063:mdna:122]

[0000833444-26-000019:mdna:105]
|  |  | Three Months Ended December 31, 2025 |  | Year Ended September 30, 2025 |
| Net loss attributable to the Obligor Group |  | $ | 69 |  |  | $ | 844 |  |
| Net income (loss) attributable to intercompany transactions |  | 4 |  |  | (56) |  |

[0000833444-26-000019:mdna:106]
[same as prior period, unchanged from 0000833444-25-000063:mdna:124]

[0000833444-26-000019:mdna:107]
[same as prior period, unchanged from 0000833444-25-000063:mdna:125]

[0000833444-26-000019:mdna:108]
|  |  | Obligor Group |  | Intercompany Balances |  |
|  |  | December 31, 2025 |  | September 30, 2025 |  | December 31, 2025 |  | September 30, 2025 |  |
| Current assets |  | $ | 1,513 |  |  | $ | 2,748 |  |  | $ | 6,350 |  |  | $ | 6,161 |  |  |
| Noncurrent assets |  | 243 |  |  | 243 |  |  | 2,143 |  |  | 2,450 |  |  |
| Current liabilities |  | 1,320 |  |  | 1,585 |  |  | 3,156 |  |  | 4,041 |  |  |
| Noncurrent liabilities |  | 8,576 |  |  | 8,473 |  |  | 5,058 |  |  | 22,450 |  | * |

[0000833444-26-000019:mdna:109]
*Includes $17 billion of intercompany loans that were canceled as the result of a distribution by a non-obligor subsidiary in October 2025.

[0000833444-26-000019:mdna:110]
The same accounting policies as described in Note 1, "Summary of Significant Accounting Policies," of the Company's Annual Report on 10-K for the year ended September 30, 2025 are used by the Parent Company and each of its subsidiaries in connection with the summarized financial information presented above.

[0000833444-26-000019:mdna:111]
[same as prior period, unchanged from 0000833444-25-000063:mdna:128]

[0000833444-26-000019:mdna:112]
[same as prior period, unchanged from 0000833444-25-000063:mdna:129]

[0000833444-26-000019:mdna:113]
[same as prior period, unchanged from 0000833444-25-000063:mdna:130]

[0000833444-26-000019:mdna:114]
The Company prepares its consolidated financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). This requires management to make estimates and assumptions that affect reported amounts and related disclosures. Actual results could differ from those estimates. The Company’s critical accounting estimates requiring significant judgement that could materially impact the Company's results of operations, financial position and cash flows are described in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in the

[0000833444-26-000019:mdna:115]
Company’s Annual Report on Form 10-K for the year ended September 30, 2025. Since the date of the Company’s most recent Annual Report, there have been no material changes in the Company’s critical accounting estimates or assumptions.
