# JCI notes — 0000833444-26-000019


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-26-000019:notes:1]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2025 filed with the SEC on November 14, 2025. The results of operations for the three month period ended December 31, 2025 is not necessarily indicative of results for the Company’s 2026 fiscal year because of seasonal and other factors.

[0000833444-26-000019:notes:2]
[same as prior period, unchanged from 0000833444-25-000063:notes:2]

[0000833444-26-000019:notes:3]
[same as prior period, unchanged from 0000833444-25-000063:notes:3]

[0000833444-26-000019:notes:4]
Johnson Controls International plc, headquartered in Cork, Ireland, a global technology leader in energy efficiency, decarbonization, thermal management and mission-critical performance, helps customers use energy more productively, reduce carbon emissions, and operate with the precision and resilience required in rapidly expanding industries such as data centers, healthcare, pharmaceuticals, advanced manufacturing, and higher education.

[0000833444-26-000019:notes:5]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space) and energy-management consulting. The Company partners with customers by leveraging its broad product portfolio and digital capabilities, together with its direct channel capabilities, to deliver solutions and services addressing distinct and diverse operating environments and regulatory requirements that address customers’ needs in their core missions.

[0000833444-26-000019:notes:6]
[same as prior period, unchanged from 0000833444-25-000063:notes:7]

[0000833444-26-000019:notes:7]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries in conformity with U.S. GAAP. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.

[0000833444-26-000019:notes:8]
Prior Period Revision – Statement of Cash Flows
Amounts reported as "Repayments of debt" and "Proceeds from debt" have been revised for certain short-term debt transactions that occurred in the three months ended December 31, 2024 and were incorrectly presented on a net basis within the financing activities section of the consolidated statements of cash flows. A similar revision for the periods ended March 31, 2025 and June 30, 2025 will be included in future Quarterly Reports on Form 10-Q. Cash provided by financing activities and the total increase (decrease) in cash, cash equivalents and restricted cash were unchanged for all affected periods. The Company does not consider the incorrect presentation to be material to any periods impacted.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000833444-26-000019:notes:9]
NEW ACCOUNTING STANDARDS
Recently Adopted Accounting Pronouncements

[0000833444-26-000019:notes:10]
In November 2023, the FASB issued ASU 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures," which is intended to improve reportable segment disclosures, primarily through enhanced disclosures about significant segment expenses. In addition, the amendments enhance interim disclosure requirements, clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provide new segment disclosure requirements for entities with a single reportable segment and contain other disclosure requirements. The Company adopted the new annual disclosures as required for fiscal 2025 and the interim disclosures as required in the first quarter of fiscal 2026. Refer to Note 16, "Segment Information," of the notes to consolidated financial statements for the Company's segment disclosures.

[0000833444-26-000019:notes:11]
Recently Issued Accounting Pronouncements

[0000833444-26-000019:notes:12]
In December 2023, the FASB issued ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures," which is intended to enhance the transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. The amendments require that on an annual basis, entities disclose specific categories in the rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. In addition, the amendments require that entities disclose additional information about income taxes paid as well as additional disclosures of pretax income and income tax expense, and remove the requirement to disclose certain items that are no longer considered cost beneficial or relevant. The Company expects to adopt the new annual disclosures as required for fiscal 2026.

[0000833444-26-000019:notes:13]
In November 2024, the FASB issued ASU 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses," which is intended to enhance transparency into the nature and function of expenses. The amendments require that on an annual and interim basis, entities disclose disaggregated operating expense information about specific categories, including purchases of inventory, employee compensation, depreciation, amortization and depletion. The Company expects to adopt the new annual disclosures as required for fiscal 2028 and the interim disclosures as required beginning with the first quarter of fiscal 2029.

[0000833444-26-000019:notes:14]
In September 2025, the FASB issued ASU 2025-06, "Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software," which is intended to increase the operability of the recognition guidance considering different methods of software development. The amendments remove all references to prescriptive and sequential software development stages (referred to as “project stages”) throughout Subtopic 350-40, and instead specify an entity is required to start capitalizing software costs when both of the following occur: (1) management has authorized and committed to funding the software project and (2) it is probable that the project will be completed and the software will be used to perform the function intended (referred to as the “probable-to complete recognition threshold”). The Company expects to adopt the new guidance as required for fiscal 2029 and is evaluating the impact the new standard will have on its consolidated financial statements.

[0000833444-26-000019:notes:15]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-26-000019:notes:16]
DIVESTITURES
ADT Mexico Security Business

[0000833444-26-000019:notes:17]
On October 31, 2025, the Company completed the sale of its ADT Mexico Security business for net proceeds of $207 million. In connection with the sale, the Company recognized a pre-tax gain of $70 million within selling, general and administrative expenses in the consolidated statements of income.

[0000833444-26-000019:notes:18]
The held for sale assets and liabilities in the consolidated balance sheet at September 30, 2025 included $154 million of assets and $21 million of liabilities associated with the ADT Mexico Security business as the Company determined that the held for sale criteria was met in the third quarter of 2025.

[0000833444-26-000019:notes:19]
Assets and Liabilities Held for Sale

[0000833444-26-000019:notes:20]
During the first quarter of fiscal 2026, the Company signed a definitive agreement to sell a component of its EMEA Security business and determined that it met the criteria to be classified as held for sale. As the estimated fair value less costs to sell was below its carrying value, the Company recorded non-cash impairment charges of $50 million within restructuring and impairment costs in the consolidated statements of income.

[0000833444-26-000019:notes:21]
As of December 31, 2025, $106 million of assets and $19 million of liabilities associated with the business were separately presented in the consolidated statements of financial position. The remaining assets and liabilities classified as held for sale as of December 31, 2025 relate to other immaterial disposal groups.

[0000833444-26-000019:notes:22]
The business did not meet the criteria to be classified as a discontinued operation as the divestiture does not represent a strategic shift that will have a major effect on the Company's operations and financial results. The transaction is expected to close in the second quarter of fiscal 2026.

[0000833444-26-000019:notes:23]
Residential & Light Commercial ("R&LC") HVAC business

[0000833444-26-000019:notes:24]
In 2024, the Company determined that the R&LC HVAC business, which was previously reported in the Global Products segment, met the criteria to be classified as discontinued operations as it represented a strategic shift in the Company's operations and resulted in the exit of substantially all of its residential and light commercial HVAC businesses. In July 2025, the Company completed the sale of its R&LC HVAC business.

[0000833444-26-000019:notes:25]
The results of the R&LC HVAC business recorded in income from discontinued operations, net of tax, was a loss of $31 million for the three months ended December 31, 2025 associated with estimated post-closing working capital and net debt adjustments.

[0000833444-26-000019:notes:26]
The following table summarizes the results of the R&LC HVAC business which were reported as discontinued operations (in millions) for the three months ended December 31, 2024:

[0000833444-26-000019:notes:27]
| Net sales | $ | 966 |  |  |  |  |  |
| Cost of goods sold | 731 |  |  |  |  |  |
| Gross profit | 235 |  |  |  |  |  |
| Selling, general and administrative expenses | 183 |  |  |  |  |  |
| Restructuring and impairment costs | 4 |  |  |  |  |  |
| Net financing charges | (1) |  |  |  |  |  |
| Equity income | 65 |  |  |  |  |  |
| Income from discontinued operations before income taxes | 114 |  |  |  |  |  |
| Provision for income taxes on discontinued operations | 24 |  |  |  |  |  |
| Income from discontinued operations, net of tax | 90 |  |  |  |  |  |
| Income from discontinued operations attributable to noncontrolling interest, net of tax | 34 |  |  |  |  |  |
| Income from discontinued operations | $ | 56 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-26-000019:notes:28]
[same as prior period, unchanged from 0000833444-25-000063:notes:28]

[0000833444-26-000019:notes:29]
The following table presents the Company's revenues disaggregated by segment and by Products & Systems and Services revenue (in millions):

[0000833444-26-000019:notes:30]
|  |  | Three Months Ended December 31, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 2,640 |  |  | $ | 1,203 |  |  | $ | 3,843 |  |  | $ | 2,536 |  |  | $ | 1,091 |  |  | $ | 3,627 |  |
| EMEA |  | 762 |  |  | 499 |  |  | 1,261 |  |  | 700 |  |  | 457 |  |  | 1,157 |  |
| APAC |  | 490 |  |  | 203 |  |  | 693 |  |  | 449 |  |  | 193 |  |  | 642 |  |
| Total |  | $ | 3,892 |  |  | $ | 1,905 |  |  | $ | 5,797 |  |  | $ | 3,685 |  |  | $ | 1,741 |  |  | $ | 5,426 |  |

[0000833444-26-000019:notes:31]
[same as prior period, unchanged from 0000833444-25-000063:notes:32]

[0000833444-26-000019:notes:32]
[same as prior period, unchanged from 0000833444-25-000063:notes:33]

[0000833444-26-000019:notes:33]
[same as prior period, unchanged from 0000833444-25-000063:notes:34]

[0000833444-26-000019:notes:34]
|  |  | Location of contract balances |  | December 31, 2025 |  | September 30, 2025 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,343 |  |  | $ | 2,178 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 6 |  |  | 9 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,542 |  |  | 2,470 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 501 |  |  | 478 |  |  |  |

[0000833444-26-000019:notes:35]
For the three months ended December 31, 2025 and 2024, the Company recognized revenue of $1,004 million and $878 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.

[0000833444-26-000019:notes:36]
[same as prior period, unchanged from 0000833444-25-000063:notes:37]

[0000833444-26-000019:notes:37]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $24.5 billion, of which approximately 65% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations of service contracts with a duration of one year or less and open purchase orders from the indirect third-party sales channel that have a short cycle time (generally 60 days or less).

[0000833444-26-000019:notes:38]
[same as prior period, unchanged from 0000833444-25-000063:notes:39]

[0000833444-26-000019:notes:39]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and design costs that relate to a contract or an anticipated contract that the Company expects to recover. Costs to obtain or fulfill a contract are capitalized when incurred and amortized to expense over the period of contract performance.

[0000833444-26-000019:notes:40]
[same as prior period, unchanged from 0000833444-25-000063:notes:41]

[0000833444-26-000019:notes:41]
|  | December 31, 2025 |  | September 30, 2025 |  |  |
| Other current assets | $ | 320 |  |  | $ | 327 |  |  |  |
| Other noncurrent assets | 233 |  |  | 249 |  |  |  |
| Total | $ | 553 |  |  | $ | 576 |  |  |  |

[0000833444-26-000019:notes:42]
Amortization of costs to obtain or fulfill a contract was $102 million and $84 million during the three months ended December 31, 2025 and 2024, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-26-000019:notes:43]
[same as prior period, unchanged from 0000833444-25-000063:notes:44]

[0000833444-26-000019:notes:44]
|  | December 31, 2025 |  | September 30, 2025 |
| Raw materials and supplies | $ | 797 |  |  | $ | 716 |  |
| Work-in-process | 138 |  |  | 132 |  |
| Finished goods | 997 |  |  | 972 |  |
| Inventories | $ | 1,932 |  |  | $ | 1,820 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-26-000019:notes:45]
[same as prior period, unchanged from 0000833444-25-000063:notes:46]

[0000833444-26-000019:notes:46]
|  |  | Three Months Ended December 31, 2025 |
|  |  | Americas |  | EMEA |  | APAC |  | Total |
| Goodwill |  | $ | 14,092 |  |  | $ | 2,388 |  |  | $ | 1,348 |  |  | $ | 17,828 |  |
| Accumulated impairment loss |  | (918) |  |  | (277) |  |  | — |  |  | (1,195) |  |
| Balance at beginning of period |  | 13,174 |  |  | 2,111 |  |  | 1,348 |  |  | 16,633 |  |
| Foreign currency translation and other (1) |  | 20 |  |  | (41) |  |  | (2) |  |  | (23) |  |
| Balance at end of period |  | $ | 13,194 |  |  | $ | 2,070 |  |  | $ | 1,346 |  |  | $ | 16,610 |  |

[0000833444-26-000019:notes:47]
(1)  Includes the allocation of $38 million of goodwill from an EMEA reporting unit to the disposal group classified as held for sale. Refer to Note 3, "Divestitures" of the notes to the consolidated financial statements for further information.

[0000833444-26-000019:notes:48]
[same as prior period, unchanged from 0000833444-25-000063:notes:51]

[0000833444-26-000019:notes:49]
|  | December 31, 2025 |  | September 30, 2025 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,204 |  |  | $ | (741) |  |  | $ | 463 |  |  | $ | 1,197 |  |  | $ | (714) |  |  | $ | 483 |  |
| Customer relationships | 2,023 |  |  | (1,312) |  |  | 711 |  |  | 2,026 |  |  | (1,272) |  |  | 754 |  |
| Miscellaneous | 936 |  |  | (535) |  |  | 401 |  |  | 910 |  |  | (511) |  |  | 399 |  |
|  | 4,163 |  |  | (2,588) |  |  | 1,575 |  |  | 4,133 |  |  | (2,497) |  |  | 1,636 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 1,975 |  |  | — |  |  | 1,975 |  |  | 1,977 |  |  | — |  |  | 1,977 |  |
| Total intangible assets | $ | 6,138 |  |  | $ | (2,588) |  |  | $ | 3,550 |  |  | $ | 6,110 |  |  | $ | (2,497) |  |  | $ | 3,613 |  |

[0000833444-26-000019:notes:50]
Amortization of other intangible assets included within continuing operations for the three months ended December 31, 2025 and 2024 was $87 million and $120 million, respectively.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0000833444-26-000019:notes:51]
SUPPLEMENTAL CASH FLOW DISCLOSURES

[0000833444-26-000019:notes:52]
The following table presents supplemental noncash operating lease activity (in millions):

[0000833444-26-000019:notes:53]
|  |  |  |  | Three Months Ended December 31, |  |  |
|  |  |  |  |  |  | 2025 |  | 2024 |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  |  |  |  |  | $ | 104 |  |  | $ | 130 |  |  |  |


## us-gaap:SupplierFinanceProgramTextBlock

[0000833444-26-000019:notes:54]
SUPPLY CHAIN FINANCING
The Company maintains agreements with third-party financial institutions who offer voluntary supply chain financing ("SCF") programs to its suppliers. The SCF programs enable suppliers to sell their receivables to third-party financial institutions and receive payments earlier than the negotiated commercial terms between the suppliers and the Company, which generally range from 90 to 120 days. Suppliers sell receivables to third-party financial institutions on terms negotiated between the supplier and the respective third-party financial institution. The Company remains obligated to make payments under the terms of the original commercial arrangement regardless of whether the supplier receivable is sold, and does not pledge any assets as security or provide other forms of guarantees for the committed payment to the third-party financial institutions.
Amounts outstanding related to SCF programs are included in accounts payable in the consolidated statements of financial position. Accounts payable included in the SCF programs were approximately $910 million and $835 million as of December 31, 2025 and September 30, 2025, respectively.


## us-gaap:DebtDisclosureTextBlock

[0000833444-26-000019:notes:55]
DEBT AND FINANCING ARRANGEMENTS
Short-term debt consisted of the following (in millions):

[0000833444-26-000019:notes:56]
|  | December 31, 2025 |  | September 30, 2025 |
| Commercial paper | $ | 200 |  |  | $ | 400 |  |
| Term loans | 236 |  |  | 320 |  |
| Bank borrowings | — |  |  | 3 |  |
|  | $ | 436 |  |  | $ | 723 |  |
| Weighted average interest rate on short-term debt outstanding | 4.3 | % |  | 4.5 | % |

[0000833444-26-000019:notes:57]
As of December 31, 2025, the Company had an outstanding syndicated committed revolving credit facility of $2.5 billion which is scheduled to expire in December 2028. There were no draws on the facility as of December 31, 2025.

[0000833444-26-000019:notes:58]
The following table presents the Company's net financing charges (in millions):

[0000833444-26-000019:notes:59]
|  | Three Months Ended December 31, |  |
| (in millions) | 2025 |  | 2024 |  |  |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 42 |  |  | $ | 67 |  |  |  |  |  |  |  |
| Other financing charges | 7 |  |  | 6 |  |  |  |  |  |  |  |
| Interest income | (2) |  |  | (3) |  |  |  |  |  |  |  |
| Net foreign exchange results for financing activities | 12 |  |  | 16 |  |  |  |  |  |  |  |
| Net financing charges | $ | 59 |  |  | $ | 86 |  |  |  |  |  |  |  |

[0000833444-26-000019:notes:60]
Net financing charges includes pre-tax losses on derivatives not designated as hedging instruments of $155 million and $144 million for the three months ended December 31, 2025 and 2024, respectively, which are offset by gains resulting from changes in foreign exchange rates on underlying exposures during those periods.


## us-gaap:ScheduleOfShortTermDebtTextBlock

[0000833444-26-000019:notes:61]
Short-term debt consisted of the following (in millions):


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-26-000019:notes:62]
[same as prior period, unchanged from 0000833444-25-000063:notes:96]

[0000833444-26-000019:notes:63]
[same as prior period, unchanged from 0000833444-25-000063:notes:97]

[0000833444-26-000019:notes:64]
[same as prior period, unchanged from 0000833444-25-000063:notes:98]

[0000833444-26-000019:notes:65]
[same as prior period, unchanged from 0000833444-25-000063:notes:99]

[0000833444-26-000019:notes:66]
[same as prior period, unchanged from 0000833444-25-000063:notes:100]

[0000833444-26-000019:notes:67]
[same as prior period, unchanged from 0000833444-25-000063:notes:101]

[0000833444-26-000019:notes:68]
[same as prior period, unchanged from 0000833444-25-000063:notes:102]

[0000833444-26-000019:notes:69]
|  | Fair Value Measurements Using: |
|  | Total as of December 31, 2025 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Derivatives | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 64 |  |  | 64 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)(1) | 72 |  |  | 72 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)(1) | 219 |  |  | 219 |  |  | — |  |  | — |  |
| Total assets | $ | 381 |  |  | $ | 355 |  |  | $ | 26 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Derivatives | $ | 62 |  |  | $ | — |  |  | $ | 62 |  |  | $ | — |  |
| Contingent earn-out liabilities | 19 |  |  | — |  |  | — |  |  | 19 |  |
| Total liabilities | $ | 81 |  |  | $ | — |  |  | $ | 62 |  |  | $ | 19 |  |

[0000833444-26-000019:notes:70]
(1)  Classified as restricted investments for payment of asbestos liabilities. See Note 18, "Commitments and Contingencies," of the notes to the consolidated financial statements for further details.

[0000833444-26-000019:notes:71]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2025 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Derivatives | $ | 15 |  |  | $ | — |  |  | $ | 15 |  |  | $ | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 63 |  |  | 63 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)(1) | 73 |  |  | 73 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)(1) | 217 |  |  | 217 |  |  | — |  |  | — |  |
| Total assets | $ | 368 |  |  | $ | 353 |  |  | $ | 15 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Derivatives | $ | 24 |  |  | $ | — |  |  | $ | 24 |  |  | $ | — |  |
| Contingent earn-out liabilities | 19 |  |  | — |  |  | — |  |  | 19 |  |
| Total liabilities | $ | 43 |  |  | $ | — |  |  | $ | 24 |  |  | $ | 19 |  |

[0000833444-26-000019:notes:72]
Net Investment Hedges

[0000833444-26-000019:notes:73]
The Company enters into foreign-currency-denominated debt obligations in order to manage foreign currency translation risk associated with normal operations. The carrying value of foreign operations translates on a recurring basis using the exchange rate at the end of the applicable period and approximates its fair value. As of both December 31, 2025 and September 30, 2025, the Company had designated debt obligations of €2.9 billion and ¥30 billion as partial hedges of its investments in certain euro-denominated and yen-denominated subsidiaries.

[0000833444-26-000019:notes:74]
The fair value of foreign-currency-denominated debt was $3.5 billion as of December 31, 2025 and $3.6 billion as of September 30, 2025. The currency effects of the debt obligations are reflected in the accumulated other comprehensive income ("AOCI") account within shareholders' equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-26-000019:notes:75]
Pre-tax gains on net investment hedges recorded as foreign currency translation adjustments ("CTA") within other comprehensive income (loss) were $16 million and $238 million for the three months ended December 31, 2025 and 2024, respectively.

[0000833444-26-000019:notes:76]
[same as prior period, unchanged from 0000833444-25-000063:notes:106]

[0000833444-26-000019:notes:77]
[same as prior period, unchanged from 0000833444-25-000063:notes:108]

[0000833444-26-000019:notes:78]
[same as prior period, unchanged from 0000833444-25-000063:notes:109]

[0000833444-26-000019:notes:79]
Derivatives: The derivatives are valued under a market approach using publicly available prices, where available, or dealer quotes.

[0000833444-26-000019:notes:80]
Exchange traded funds: Investments in exchange traded funds are valued using a market approach based on quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. Refer to Note 18, "Commitments and Contingencies," of the notes to the consolidated financial statements for further information.

[0000833444-26-000019:notes:81]
Unrealized gains (losses) recognized in the consolidated statements of income that relate to equity securities still held at December 31, 2025 and 2024 were $4 million and $(2) million for the three months ended December 31, 2025 and 2024, respectively.

[0000833444-26-000019:notes:82]
[same as prior period, unchanged from 0000833444-25-000063:notes:114]

[0000833444-26-000019:notes:83]
The fair value of long-term debt at December 31, 2025 and September 30, 2025 was as follows (in billions):

[0000833444-26-000019:notes:84]
|  |  | December 31, |  | September 30, |
|  | 2025 |  | 2025 |
| Public debt |  | $ | 8.4 |  |  | $ | 8.4 |  |
| Other long-term debt |  | 0.6 |  |  | 0.5 |  |
| Total fair value of long-term debt |  | $ | 9.0 |  |  | $ | 8.9 |  |

[0000833444-26-000019:notes:85]
[same as prior period, unchanged from 0000833444-25-000063:notes:117]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000833444-26-000019:notes:86]
[same as prior period, unchanged from 0000833444-25-000063:notes:118]

[0000833444-26-000019:notes:87]
Derivatives: The derivatives are valued under a market approach using publicly available prices, where available, or dealer quotes. 
Exchange traded funds: Investments in exchange traded funds are valued using a market approach based on quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:EarningsPerShareTextBlock

[0000833444-26-000019:notes:88]
WEIGHTED AVERAGE SHARES OUTSTANDING
The following table reconciles shares used to calculate basic and diluted earnings per share (in millions):

[0000833444-26-000019:notes:89]
|  | Three Months Ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 611 |  |  | 662 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 3 |  |  | 3 |  |  |  |  |  |
| Diluted weighted average shares outstanding | 614 |  |  | 665 |  |  |  |  |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Stock options and unvested restricted stock | — |  |  | — |  |  |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000833444-26-000019:notes:90]
[same as prior period, unchanged from 0000833444-25-000063:notes:122]

[0000833444-26-000019:notes:91]
|  | Three Months Ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Foreign currency translation adjustments |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (638) |  |  | $ | (956) |  |  |  |  |  |
| Aggregate adjustment for the period | 5 |  |  | (85) |  |  |  |  |  |
| Balance at end of period | (633) |  |  | (1,041) |  |  |  |  |  |
| Other |  |  |  |  |  |  |  |
| Balance at beginning of period | (4) |  |  | (8) |  |  |  |  |  |
| Current period changes in fair value | 10 |  |  | 8 |  |  |  |  |  |
| Reclassification to income | (4) |  |  | (2) |  |  |  |  |  |
| Net tax impact | — |  |  | (1) |  |  |  |  |  |
| Balance at end of period | 2 |  |  | (3) |  |  |  |  |  |
| Accumulated other comprehensive loss, end of period | $ | (631) |  |  | $ | (1,044) |  |  |  |  |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-26-000019:notes:92]
PENSION AND RETIREMENT PLANS
The components of net periodic benefit cost (credit) associated with defined benefit pension and postretirement plans, which are primarily recorded in selling, general and administrative expenses in the consolidated statements of income, are shown in the table below (in millions):

[0000833444-26-000019:notes:93]
|  | Three Months Ended December 31, |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Service cost | $ | 4 |  |  | $ | 4 |  |  |  |  |  |
| Interest cost | 32 |  | 33 |  |  |  |  |
| Expected return on plan assets | (44) |  |  | (46) |  |  |  |  |  |
| Amortization of prior service credit | (1) |  |  | (1) |  |  |  |  |  |
| Net periodic benefit credit | $ | (9) |  |  | $ | (10) |  |  |  |  |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-26-000019:notes:94]
[same as prior period, unchanged from 0000833444-25-000063:notes:130]

[0000833444-26-000019:notes:95]
During the fourth quarter of fiscal 2024, the Company committed to a multi-year restructuring plan to address stranded costs and further right-size its global operations as a result of portfolio simplification actions. It is expected that the plan will be completed in fiscal 2027 and the Company will incur one-time restructuring costs, including severance and other

[0000833444-26-000019:notes:96]
employee termination benefits, contract termination costs, and certain other related cash and non-cash charges, totaling approximately $400 million.

[0000833444-26-000019:notes:97]
[same as prior period, unchanged from 0000833444-25-000063:notes:132]

[0000833444-26-000019:notes:98]
|  | Three Months Ended December 31, 2025 |  | Inception to December 31, 2025 |  |  |  |  |
| Americas | $ | 9 |  |  | $ | 60 |  |  |  |  |  |
| EMEA | 11 |  |  | 60 |  |  |  |  |  |
| APAC | 3 |  |  | 20 |  |  |  |  |  |
| Corporate | 14 |  |  | 61 |  |  |  |  |  |
| Total | $ | 37 |  |  | $ | 201 |  |  |  |  |  |

[0000833444-26-000019:notes:99]
[same as prior period, unchanged from 0000833444-25-000063:notes:134]

[0000833444-26-000019:notes:100]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  |  |  | Total |
| Balance at September 30, 2025 | $ | 39 |  |  | $ | — |  |  | $ | 5 |  |  |  |  |  |  | $ | 44 |  |
| Restructuring and related costs | 25 |  |  | 10 |  |  | 2 |  |  |  |  |  |  | 37 |  |
| Utilized—cash | (28) |  |  | — |  |  | (2) |  |  |  |  |  |  | (30) |  |
| Utilized—noncash | — |  |  | (10) |  |  | — |  |  |  |  |  |  | (10) |  |
| Other | 3 |  |  | — |  |  | 2 |  |  |  |  |  |  | 5 |  |
| Balance at December 31, 2025 | $ | 39 |  |  | $ | — |  |  | $ | 7 |  |  |  |  |  |  | $ | 46 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-26-000019:notes:101]
[same as prior period, unchanged from 0000833444-25-000063:notes:136]

[0000833444-26-000019:notes:102]
[same as prior period, unchanged from 0000833444-25-000063:notes:137]

[0000833444-26-000019:notes:103]
For the three months ended December 31, 2025, the Company's effective tax rate for continuing operations was 21.4% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of the water systems Aqueous Film Forming Foam ("AFFF") insurance proceeds, the tax impact of current and planned divestitures, and tax rate differentials, partially offset by the benefits of continuing global tax planning.

[0000833444-26-000019:notes:104]
For the three months ended December 31, 2024, the Company's effective tax rate for continuing operations was 11.5% and was lower than the statutory tax rate of 12.5% primarily due to the benefits of continuing global tax planning, partially offset by tax rate differentials.

[0000833444-26-000019:notes:105]
Refer to Note 18, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement.

[0000833444-26-000019:notes:106]
[same as prior period, unchanged from 0000833444-25-000063:notes:143]

[0000833444-26-000019:notes:107]
At September 30, 2025, the Company had gross tax-effected unrecognized tax benefits of $1.9 billion, of which $1.4 billion, if recognized, would impact the effective tax rate. Accrued interest, net at September 30, 2025 was approximately $459 million (net of tax benefit). Interest accrued during the three months ended December 31, 2025 and 2024 was approximately $30 million and $28 million (both net of tax benefit), respectively. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-26-000019:notes:108]
In the U.S., fiscal years 2019 through 2020 are currently under audit and fiscal years 2017 through 2018 are currently under appeal with the Internal Revenue Service (“IRS”) for certain legal entities. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions:

[0000833444-26-000019:notes:109]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2016 - 2017; 2019 - 2020 |
| Germany |  | 2007 - 2021 |
| Mexico |  | 2016; 2018 - 2019 |
| United Kingdom |  | 2014 - 2015; 2018; 2020 - 2021 |

[0000833444-26-000019:notes:110]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-26-000019:notes:111]
[same as prior period, unchanged from 0000833444-25-000063:notes:153]

[0000833444-26-000019:notes:112]
[same as prior period, unchanged from 0000833444-25-000063:notes:154]

[0000833444-26-000019:notes:113]
[same as prior period, unchanged from 0000833444-25-000063:notes:155]

[0000833444-26-000019:notes:114]
[same as prior period, unchanged from 0000833444-25-000063:notes:156]

[0000833444-26-000019:notes:115]
[same as prior period, unchanged from 0000833444-25-000063:notes:157]

[0000833444-26-000019:notes:116]
The Chief Executive Officer, the Company’s chief operating decision maker ("CODM"), evaluates the performance of its segments and allocates resources based on two profitability measures, Segment EBITA and Segment EBIT:

[0000833444-26-000019:notes:117]
•Segment earnings before interest, taxes, and amortization (“EBITA”) represents income from continuing operations, before income taxes and noncontrolling interests, excluding corporate expenses, restructuring and impairment costs, AFFF related settlement costs and insurance recoveries, gains or losses on divestitures, net mark-to-market gains and losses related to pension and postretirement plans and restricted asbestos investments, net finance charges, and amortization.  Segment EBITA is used as a tool to allow the CODM to evaluate the recurring profitability of the segments, including revenues and expenses that are within the operational control of the segments, and excluding the impact of certain non-cash and non-recurring items. Segment EBITA also provides the CODM with performance comparability across periods and for more accurate benchmarking against peer companies that may not have similar historical acquisition activity, by holding constant the impact of significant acquisitions.

[0000833444-26-000019:notes:118]
•Segment earnings before interest and taxes ("EBIT") represents Segment EBITA, adding back the impact of amortization of intangible assets. Segment EBIT allows the CODM to review profitability, inclusive of the impact of significant acquisition activity, informing the CODM of how the business is integrating key strategic initiatives and generating synergies.

[0000833444-26-000019:notes:119]
Both EBITA and EBIT are reviewed by the CODM and compared against the profit plan and forecast for the current and prior year. Segment EBITA and Segment EBIT are not defined under GAAP and may not be comparable to similarly titled measures used by other companies. Measures of total assets by reportable segment are not provided to the CODM. Therefore, asset information by segment is not disclosed.

[0000833444-26-000019:notes:120]
[same as prior period, unchanged from 0000833444-25-000063:notes:159]

[0000833444-26-000019:notes:121]
|  | Three Months Ended December 31, 2025 |
|  | Americas |  | EMEA |  | APAC |
| Net sales | $ | 3,843 |  |  | $ | 1,261 |  |  | $ | 693 |  |
| Cost of sales | 2,429 |  | 808 |  | 441 |
| Selling, general and administrative expenses ("SG&A") | 794 |  | 295 |  | 136 |
| Equity loss | — |  |  | — |  |  | (1) |  |
| Segment EBITA | 620 |  | 158 |  | 117 |
| Amortization of intangible assets | 76 |  |  | 7 |  |  | 4 |  |
| Segment EBIT | $ | 544 |  |  | $ | 151 |  |  | $ | 113 |  |
| Depreciation included in Cost of sales and SG&A | $ | 33 |  |  | $ | 6 |  |  | $ | 5 |  |

[0000833444-26-000019:notes:122]
|  | Three Months Ended December 31, 2024 |
|  | Americas |  | EMEA |  | APAC |
| Net sales | $ | 3,627 |  |  | $ | 1,157 |  |  | $ | 642 |  |
| Cost of sales | 2,278 |  | 754 |  | 404 |
| SG&A | 760 |  | 267 |  | 148 |
| Segment EBITA | 589 |  | 136 |  | 90 |
| Amortization of intangible assets | 95 |  |  | 20 |  |  | 5 |  |
| Segment EBIT | $ | 494 |  |  | $ | 116 |  |  | $ | 85 |  |
| Depreciation included in Cost of sales and SG&A | $ | 33 |  |  | $ | 5 |  |  | $ | 5 |  |

[0000833444-26-000019:notes:123]
A reconciliation of segment EBIT and segment EBITA to consolidated income before income taxes is as follows (in millions):

[0000833444-26-000019:notes:124]
|  | Three Months Ended December 31, |
|  | 2025 |  | 2024 |
| Segment EBITA | $ | 895 |  |  | $ | 815 |  |
| Amortization of intangible assets | 87 |  |  | 120 |  |
| Segment EBIT | 808 |  |  | 695 |  |
| Corporate expenses | 156 |  |  | 171 |  |
| Restructuring and impairment costs | 87 |  |  | 33 |  |
| Water systems AFFF insurance recoveries (1) | (130) |  |  | (4) |  |
| Net financing charges | 59 |  |  | 86 |  |
| Gain on divestiture | (70) |  |  | — |  |
| Net mark-to-market adjustments | (2) |  |  | 1 |  |
| Income from continuing operations before income taxes | $ | 708 |  |  | $ | 408 |  |

[0000833444-26-000019:notes:125]
(1) Refer to Note 18, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement.


## us-gaap:GuaranteesTextBlock

[0000833444-26-000019:notes:126]
[same as prior period, unchanged from 0000833444-25-000063:notes:163]

[0000833444-26-000019:notes:127]
[same as prior period, unchanged from 0000833444-25-000063:notes:164]

[0000833444-26-000019:notes:128]
[same as prior period, unchanged from 0000833444-25-000063:notes:165]

[0000833444-26-000019:notes:129]
[same as prior period, unchanged from 0000833444-25-000063:notes:166]

[0000833444-26-000019:notes:130]
| Balance at September 30, 2025 | $ | 120 |  |
| Accruals for warranties issued | 33 |  |
| Settlements made | (28) |  |
| Changes in estimates to pre-existing warranties | 9 |  |
| Balance at December 31, 2025 | $ | 134 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-26-000019:notes:131]
COMMITMENTS AND CONTINGENCIES
Environmental Matters

[0000833444-26-000019:notes:132]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-26-000019:notes:133]
|  | December 31, 2025 |  | September 30, 2025 |
| Other current liabilities | $ | 24 |  |  | $ | 27 |  |
| Other noncurrent liabilities | 156 |  |  | 160 |  |
| Total reserves for environmental liabilities | $ | 180 |  |  | $ | 187 |  |

[0000833444-26-000019:notes:134]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

[0000833444-26-000019:notes:135]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). Tyco Fire Products has discontinued the production and sale of fluorinated firefighting foams, including AFFF products, and has transitioned to non-fluorinated foam alternatives.

[0000833444-26-000019:notes:136]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. In April 2024, EPA published National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBS. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meet the statutory definition of hazardous waste. In April 2024, EPA finalized a rule designating PFOA and PFOS, along with their salts and structural isomers, as "hazardous substances" under the Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In May 2025, EPA announced that it will retain the 4.0 ppt limit on PFOS and PFOA but will institute a two-year delay in the compliance deadline from 2029 until 2031. EPA also announced its intent to rescind and reconsider the limits on four other types of PFAS (PFHxS, PFNA, HFPO-DA, and PFBS).

[0000833444-26-000019:notes:137]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-26-000019:notes:138]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $7 million at both December 31, 2025 and September 30, 2025.

[0000833444-26-000019:notes:139]
FTC-Related Matters

[0000833444-26-000019:notes:140]
FTC and Stanton Street Remediation

[0000833444-26-000019:notes:141]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere.

[0000833444-26-000019:notes:142]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

[0000833444-26-000019:notes:143]
Tyco Fire Products is operating and monitoring at the FTC a Groundwater Extraction and Treatment System ("GETS"), a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. The Company is also continuing to replace private drinking water wells that may have been impacted by PFAS migrating from the FTC. The Company's reserves for continued remediation of the FTC, the Stanton Street Facility and surrounding areas in Marinette and Peshtigo are based on estimates of costs associated with the long-term remediation actions, including the continued operation of the GETS, the implementation of long-term drinking water solutions for the area impacted by groundwater migrating from the FTC, continued monitoring and testing of groundwater monitoring wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

[0000833444-26-000019:notes:144]
FTC-Related Litigation

[0000833444-26-000019:notes:145]
Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022. In August 2024, WDNR issued a new proposed rule to adopt the EPA Maximum Contaminant Levels for PFAS in drinking water. In February 2025, the Wisconsin Department of Health Services ("WDHS") recommended individual groundwater enforcement standards of 4 ng/L for PFOA and PFOS, 10 ng/L for PFHxS, PFNA, and HFPO-DA, and 2,000 ng/L for PFBS. Following the February 2025 WDHS recommendation, the WDNR Secretary and the Governor signed the WDNR scope statement. In January 2026, the Wisconsin Natural Resources Board approved drinking water standards of 4 ng/L for PFOA and PFOS and 10 ng/L for PFHxS, PFNA, and HFPO-DA. The standards are subject to further reviews and approvals before they become final.

[0000833444-26-000019:notes:146]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions, including the potential assessment of penalties.

[0000833444-26-000019:notes:147]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties have completed briefing of summary judgment and pretrial motions. The Court has continued the trial previously scheduled for March 3, 2025 and has not yet set a new trial date. The parties are actively working toward the finalization of a settlement to resolve the matter.

[0000833444-26-000019:notes:148]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina.

[0000833444-26-000019:notes:149]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. Subsequently, several additional plaintiffs have direct-filed in the MDL complaints with similar allegations.

[0000833444-26-000019:notes:150]
The Company is vigorously defending each of these cases and believes that it has meritorious defenses, but it is presently unable to predict the duration, scope, or outcome of these actions.

[0000833444-26-000019:notes:151]
Aqueous Film-Forming Foam ("AFFF") Matters

[0000833444-26-000019:notes:152]
AFFF Litigation

[0000833444-26-000019:notes:153]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-26-000019:notes:154]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to the MDL. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-26-000019:notes:155]
AFFF Municipal and Water Provider Cases

[0000833444-26-000019:notes:156]
Chemguard and Tyco Fire Products have been named as defendants in more than 300 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 36 states and territories. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation.

[0000833444-26-000019:notes:157]
Tyco Fire Products and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-26-000019:notes:158]
Water Systems AFFF Settlement Agreement

[0000833444-26-000019:notes:159]
On April 12, 2024, Tyco Fire Products agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. The settlement releases these claims against Tyco Fire Products, Chemguard, and other related corporate entities. In accordance with the terms of the settlement agreement, Tyco Fire Products made its final required payment of $415 million in December 2024 and has now paid the full settlement amount.

[0000833444-26-000019:notes:160]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of

[0000833444-26-000019:notes:161]
damages alleged to be related to the historical use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.

[0000833444-26-000019:notes:162]
The settlement does not constitute an admission of liability or wrongdoing by Tyco Fire Products or Chemguard.

[0000833444-26-000019:notes:163]
AFFF Putative Class Actions

[0000833444-26-000019:notes:164]
Chemguard and Tyco Fire Products are named in 49 pending putative class actions in federal courts originating from 21 states and territories. All of these cases have been direct-filed in or transferred to the MDL. In addition, seven proposed class actions were filed in Canada (British Columbia, Manitoba, Quebec and Ontario), which name Tyco Fire Products and other manufacturers as defendants, on behalf of various classes of members (including individuals and government entities) who seek to recover for remediation (past and future) costs, claim property or other environmental damages, or claim personal injuries or other harms arising from alleged exposure to or contamination with PFAS or PFAS-containing products (including AFFF).

[0000833444-26-000019:notes:165]
AFFF Individual or Mass Actions

[0000833444-26-000019:notes:166]
There are more than 15,000 individual or “mass” actions pending that were filed in state or federal courts originating from 53 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The Company is currently unable to determine a precise count of personal injury claimants currently pending. The vast majority of these matters transferred to or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are or will be proceeding in state courts, including actions in Arizona, Illinois and Washington.

[0000833444-26-000019:notes:167]
Tyco and Chemguard are also periodically notified by other individuals that they may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-26-000019:notes:168]
AFFF State or U.S. Territory Attorneys General Litigation

[0000833444-26-000019:notes:169]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-26-000019:notes:170]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-26-000019:notes:171]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

[0000833444-26-000019:notes:172]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. These two cases have also been removed to federal court and transferred to the MDL.

[0000833444-26-000019:notes:173]
In addition, 33 other states and territories have filed 35 lawsuits against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of each of those State's environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within each respective State. The states and territories are: Arkansas, Arizona, California, Colorado, Connecticut, Delaware, the District of Columbia, Florida, Hawaii, Illinois, Indiana, Kentucky, Massachusetts, Maryland, Maine, Michigan, Mississippi, New Hampshire, New Jersey, New Mexico, Ohio, Oklahoma, Oregon, Rhode Island, South Carolina, Tennessee, Texas, Vermont, Washington, Wisconsin, Guam, the Northern Mariana Islands, and Puerto Rico. All of these complaints, if not filed directly in the MDL, have been removed to federal court and transferred to the MDL.

[0000833444-26-000019:notes:174]
In addition, an affiliate of the Company has been named with other manufacturers as a third party by the Canadian Federal Government who is seeking contribution and indemnity in respect of a single-plaintiff action filed in Ontario relating to alleged PFAS and benzene contamination of a private well from the use of AFFF in firefighting training.

[0000833444-26-000019:notes:175]
Other AFFF Related Matters

[0000833444-26-000019:notes:176]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-26-000019:notes:177]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This case has been transferred to the MDL.

[0000833444-26-000019:notes:178]
In July 2023, the Fond du Lac Band of Lake Superior Chippewa (a federally recognized tribe) direct-filed a lawsuit in the MDL against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota.

[0000833444-26-000019:notes:179]
In September 2025, the Leech Lake Band of Ojibwe (one of six federally recognized sovereign bands that make up the federally recognized Minnesota Chippewa Tribe) filed a lawsuit in Minnesota state court against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from, among other things, the alleged use and disposal of AFFF on and near the Band’s property. This case has been transferred to the MDL.

[0000833444-26-000019:notes:180]
Four AFFF property damage proceedings have been filed in Belgium against numerous defendants, including an affiliate of the Company.  The cases are currently on hold pending efforts to dismiss the proceedings.

[0000833444-26-000019:notes:181]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin. The Company has reached settlements with certain insurers and remains in discussions and litigation with the remaining carriers. In the first quarter of fiscal year 2026, the Company recorded $130 million of insurance recoveries related to settlements with its insurance carriers in selling, general and administrative expenses in the consolidated statements of income. The Company is unable to predict the amount and timing of any future recoveries under its insurance policies with the remaining carriers. The insurance litigation involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-26-000019:notes:182]
Asbestos Matters

[0000833444-26-000019:notes:183]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-26-000019:notes:184]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-26-000019:notes:185]
|  | December 31, 2025 |  | September 30, 2025 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 336 |  |  | 329 |  |
| Total asbestos-related liabilities | 394 |  |  | 387 |  |
| Other current assets | 14 |  |  | 13 |  |
| Other noncurrent assets | 326 |  |  | 326 |  |
| Total asbestos-related assets | 340 |  |  | 339 |  |
| Net asbestos-related liabilities | $ | 54 |  |  | $ | 48 |  |

[0000833444-26-000019:notes:186]
The following table presents the components of asbestos-related assets (in millions):

[0000833444-26-000019:notes:187]
|  | December 31, 2025 |  | September 30, 2025 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 5 |  |
| Investments | 291 |  |  | 290 |  |
| Total restricted assets | 297 |  |  | 295 |  |
| Insurance receivables for asbestos-related liabilities | 43 |  |  | 44 |  |
| Total asbestos-related assets | $ | 340 |  |  | $ | 339 |  |

[0000833444-26-000019:notes:188]
The amounts recorded for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to

[0000833444-26-000019:notes:189]
jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-26-000019:notes:190]
Self-Insured Liabilities

[0000833444-26-000019:notes:191]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage a portion of its insurable liabilities.

[0000833444-26-000019:notes:192]
The following table presents the location and amount of self-insured liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-26-000019:notes:193]
|  | December 31, 2025 |  | September 30, 2025 |
| Other current liabilities | $ | 89 |  |  | $ | 87 |  |
| Accrued compensation and benefits | 38 |  |  | 38 |  |
| Other noncurrent liabilities | 311 |  |  | 289 |  |
| Total self-insured liabilities | $ | 438 |  |  | $ | 414 |  |

[0000833444-26-000019:notes:194]
Other Matters

[0000833444-26-000019:notes:195]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to the Company, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.
