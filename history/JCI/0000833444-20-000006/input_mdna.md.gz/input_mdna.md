# JCI MD&A — 0000833444-20-000006


## mdna

[0000833444-20-000006:mdna:1]
[same as prior period, unchanged from 0000833444-19-000041:mdna:1]

[0000833444-20-000006:mdna:2]
[same as prior period, unchanged from 0000833444-19-000041:mdna:2]

[0000833444-20-000006:mdna:3]
[same as prior period, unchanged from 0000833444-19-000041:mdna:3]

[0000833444-20-000006:mdna:4]
[same as prior period, unchanged from 0000833444-19-000041:mdna:4]

[0000833444-20-000006:mdna:5]
[same as prior period, unchanged from 0000833444-19-000041:mdna:5]

[0000833444-20-000006:mdna:6]
Johnson Controls was originally incorporated in the state of Wisconsin in 1885 as Johnson Electric Service Company to manufacture, install and service automatic temperature regulation systems for buildings. The Company was renamed to Johnson Controls, Inc. in 1974. In 2005, the Company acquired York International, a global supplier of heating, ventilating, air-conditioning ("HVAC") and refrigeration equipment and services. In 2014, the Company acquired Air Distribution Technologies, Inc., one of the largest independent providers of air distribution and ventilation products in North America. In 2015, the Company formed a joint venture with Hitachi to expand its building related product offerings. In 2016, Johnson Controls, Inc. and Tyco completed their combination (the "Merger"). Following the Merger, Tyco changed its name to "Johnson Controls International plc."

[0000833444-20-000006:mdna:7]
[same as prior period, unchanged from 0000833444-19-000041:mdna:10]

[0000833444-20-000006:mdna:8]
During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation and, as a result, Power Solutions' historical financial results are reflected in the Company's consolidated financial statements as a discontinued operation, and its assets and liabilities were retrospectively reclassified as assets and liabilities held for sale.

[0000833444-20-000006:mdna:9]
The Company is a global market leader in engineering, developing, manufacturing and installing building products and systems around the world, including HVAC equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Company further serves customers by providing technical services (in the HVAC, security and fire-protection space), energy-management consulting and data-driven solutions via its data-enabled business. Finally, the Company has a strong presence in the North American residential air conditioning and heating systems market and is a global market leader in industrial refrigeration products.

[0000833444-20-000006:mdna:10]
The following information should be read in conjunction with the September 30, 2019 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2019 filed with the SEC on November 21, 2019. References in the following discussion and analysis to "Three Months" (or similar language) refer to the three months ended December 31, 2019 compared to the three months ended December 31, 2018.

[0000833444-20-000006:mdna:11]
[same as prior period, unchanged from 0000833444-19-000041:mdna:13]

[0000833444-20-000006:mdna:12]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Net sales | $ | 5,576 |  |  | $ | 5,464 |  |  | 2 | % |

[0000833444-20-000006:mdna:13]
The increase in consolidated net sales was due to higher organic sales ($138 million) and acquisitions ($8 million), partially offset by the unfavorable impact of foreign currency translation ($27 million) and lower sales due to business divestitures ($7 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 3% as compared to the prior year, with organic sales growth in all segments. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-20-000006:mdna:14]
[same as prior period, unchanged from 0000833444-19-000041:mdna:17]

[0000833444-20-000006:mdna:15]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Cost of sales | $ | 3,773 |  |  | $ | 3,739 |  |  | 1 | % |
| Gross profit | 1,803 |  |  | 1,725 |  |  | 5 | % |
| % of sales | 32.3 | % |  | 31.6 | % |  |  |

[0000833444-20-000006:mdna:16]
Cost of sales, gross profit and gross profit as a percentage of sales increased. Gross profit increased due to organic sales growth across all segments, partially offset by business divestitures. Foreign currency translation had a favorable impact on cost of sales of approximately $17 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-20-000006:mdna:17]
[same as prior period, unchanged from 0000833444-19-000041:mdna:21]

[0000833444-20-000006:mdna:18]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Selling, general and administrative expenses | $ | 1,427 |  |  | $ | 1,438 |  |  | -1 | % |
| % of sales | 25.6 | % |  | 26.3 | % |  |  |

[0000833444-20-000006:mdna:19]
Selling, general and administrative expenses ("SG&A") decreased $11 million, and SG&A as a percentage of sales decreased by 70 basis points. The decrease in SG&A was primarily due to favorable year-over-year impact of net mark-to-market adjustments on restricted asbestos investments. Foreign currency translation had a favorable impact on SG&A of $7 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-20-000006:mdna:20]
[same as prior period, unchanged from 0000833444-19-000041:mdna:25]

[0000833444-20-000006:mdna:21]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Restructuring and impairment costs | $ | 111 |  |  | $ | — |  |  | * |

[0000833444-20-000006:mdna:22]
[same as prior period, unchanged from 0000833444-19-000041:mdna:27]

[0000833444-20-000006:mdna:23]
Refer to Note 9, "Significant Restructuring and Impairment Costs," and Note 18, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-20-000006:mdna:24]
[same as prior period, unchanged from 0000833444-19-000041:mdna:29]

[0000833444-20-000006:mdna:25]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Net financing charges | $ | 52 |  |  | $ | 85 |  |  | -39 | % |

[0000833444-20-000006:mdna:26]
Refer to Note 12, "Debt and Financing Arrangements," of the notes to consolidated financial statements for further disclosure related to the Company's net financing charges.

[0000833444-20-000006:mdna:27]
[same as prior period, unchanged from 0000833444-19-000041:mdna:32]

[0000833444-20-000006:mdna:28]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Equity income | $ | 43 |  |  | $ | 42 |  |  | 2 | % |

[0000833444-20-000006:mdna:29]
The increase in equity income was primarily due to higher income at a certain partially-owned affiliate of the Johnson Controls - Hitachi joint venture. Foreign currency translation had an unfavorable impact on equity income of $1 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-20-000006:mdna:30]
[same as prior period, unchanged from 0000833444-19-000041:mdna:35]

[0000833444-20-000006:mdna:31]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Income tax provision | $ | 65 |  |  | $ | 108 |  |  | -40 | % |
| Effective tax rate | 25 | % |  | 44 | % |  |  |

[0000833444-20-000006:mdna:32]
[same as prior period, unchanged from 0000833444-19-000041:mdna:38]

[0000833444-20-000006:mdna:33]
42

[0000833444-20-000006:mdna:34]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended December 31, 2019, the Company's effective tax rate for continuing operations was 25% and was higher than the statutory tax rate of 12.5% primarily due to a discrete tax charge related to the remeasurement of deferred tax assets and liabilities as a result of Swiss tax reform and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the three months ended December 31, 2018, the Company's effective tax rate for continuing operations was 44% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments as a result of tax law changes and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. The effective tax rate for the three months ended December 31, 2019 decreased as compared to the three months ended December 31, 2018 primarily due to the discrete tax items. Refer to Note 10, "Income Taxes," of the notes to consolidated financial statements for further details.

[0000833444-20-000006:mdna:35]
[same as prior period, unchanged from 0000833444-19-000041:mdna:53]

[0000833444-20-000006:mdna:36]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Income from discontinued operations, net of tax | $ | — |  |  | $ | 263 |  |  | * |

[0000833444-20-000006:mdna:37]
[same as prior period, unchanged from 0000833444-19-000041:mdna:37]

[0000833444-20-000006:mdna:38]
[same as prior period, unchanged from 0000833444-19-000041:mdna:56]

[0000833444-20-000006:mdna:39]
[same as prior period, unchanged from 0000833444-19-000041:mdna:57]

[0000833444-20-000006:mdna:40]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 32 |  |  | $ | 29 |  |  | 10 | % |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | 15 |  |  | * |  |

[0000833444-20-000006:mdna:41]
[same as prior period, unchanged from 0000833444-19-000041:mdna:55]

[0000833444-20-000006:mdna:42]
The increase in income from continuing operations attributable to noncontrolling interests was primarily due to higher net income at certain partially-owned affiliates within the Global Products segment.

[0000833444-20-000006:mdna:43]
[same as prior period, unchanged from 0000833444-19-000041:mdna:61]

[0000833444-20-000006:mdna:44]
[same as prior period, unchanged from 0000833444-19-000041:mdna:62]

[0000833444-20-000006:mdna:45]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Net income attributable to Johnson Controls | $ | 159 |  |  | $ | 355 |  |  | -55 | % |

[0000833444-20-000006:mdna:46]
The decrease in net income attributable to Johnson Controls was primarily due to the prior year income from discontinued operations and current year restructuring and impairment charges, partially offset by higher gross profit, lower income tax provision and lower net financing charges.

[0000833444-20-000006:mdna:47]
Diluted earnings per share attributable to Johnson Controls for the three months ended December 31, 2019 was $0.21 compared to $0.38 for the three months ended December 31, 2018.

[0000833444-20-000006:mdna:48]
43

[0000833444-20-000006:mdna:49]
[same as prior period, unchanged from 0000833444-19-000041:mdna:67]

[0000833444-20-000006:mdna:50]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 414 |  |  | $ | 229 |  |  | 81 | % |

[0000833444-20-000006:mdna:51]
The increase in comprehensive income attributable to Johnson Controls was due an increase in other comprehensive income attributable to Johnson Controls ($381 million) resulting primarily from favorable currency translation adjustments, partially offset by lower net income attributable to Johnson Controls ($196 million). The year-over-year favorable foreign currency translation adjustments were primarily driven by the strengthening of the British pound and euro currencies against the U.S. dollar in the current year.

[0000833444-20-000006:mdna:52]
[same as prior period, unchanged from 0000833444-19-000041:mdna:72]

[0000833444-20-000006:mdna:53]
[same as prior period, unchanged from 0000833444-19-000041:mdna:74]

[0000833444-20-000006:mdna:54]
[same as prior period, unchanged from 0000833444-19-000041:mdna:75]

[0000833444-20-000006:mdna:55]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Building Solutions North America | $ | 2,167 |  |  | $ | 2,116 |  |  | 2 | % |
| Building Solutions EMEA/LA | 928 |  |  | 907 |  |  | 2 | % |
| Building Solutions Asia Pacific | 629 |  |  | 613 |  |  | 3 | % |
| Global Products | 1,852 |  |  | 1,828 |  |  | 1 | % |
|  | $ | 5,576 |  |  | $ | 5,464 |  |  | 2 | % |

[0000833444-20-000006:mdna:56]
| • | The increase in Building Solutions North America was primarily attributable to higher installation / service sales ($51 million). |

[0000833444-20-000006:mdna:57]
| • | The increase in Building Solutions EMEA/LA was primarily attributable to higher installation sales ($45 million) and incremental sales related to business acquisitions ($5 million), partially offset by the unfavorable impact of foreign currency translation ($25 million) and lower volumes due to business divestitures ($4 million). |

[0000833444-20-000006:mdna:58]
| • | The increase in Building Solutions Asia Pacific was primarily attributable to higher installation sales ($19 million) and incremental sales related to business acquisitions ($2 million), partially offset by the unfavorable impact of foreign currency translation ($5 million). |

[0000833444-20-000006:mdna:59]
| • | The increase in Global Products was primarily attributable to higher building management and specialty products sales ($23 million), the favorable impact of foreign currency translation ($3 million) and incremental sales related to business acquisitions ($1 million), partially offset by lower volumes due to business divestitures ($3 million). |

[0000833444-20-000006:mdna:60]
44

[0000833444-20-000006:mdna:61]
[same as prior period, unchanged from 0000833444-19-000041:mdna:89]

[0000833444-20-000006:mdna:62]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Building Solutions North America | $ | 258 |  |  | $ | 250 |  |  | 3 | % |
| Building Solutions EMEA/LA | 90 |  |  | 77 |  |  | 17 | % |
| Building Solutions Asia Pacific | 72 |  |  | 66 |  |  | 9 | % |
| Global Products | 203 |  |  | 190 |  |  | 7 | % |
|  | $ | 623 |  |  | $ | 583 |  |  | 7 | % |

[0000833444-20-000006:mdna:63]
| • | The increase in Building Solutions North America was due to favorable volumes ($12 million) and prior year integration costs ($3 million), partially offset by unfavorable mix, net of productivity savings ($6 million) and current year integration costs ($1 million). |

[0000833444-20-000006:mdna:64]
| • | The increase in Building Solutions EMEA/LA was due to favorable volumes ($9 million), lower SG&A and operating expenses ($7 million), and higher income due to business acquisitions ($1 million), partially offset by the unfavorable impact of foreign currency translation ($3 million) and lower income due to business divestitures ($1 million). |

[0000833444-20-000006:mdna:65]
| • | The increase in Building Solutions Asia Pacific was due to favorable volumes and productivity savings ($5 million) and higher income due to business acquisitions ($1 million). |

[0000833444-20-000006:mdna:66]
| • | The increase in Global Products was due to productivity savings and net favorable price / cost ($10 million), prior year integration costs ($4 million) and higher equity income ($2 million), partially offset by current year integration costs ($1 million), the unfavorable impact of foreign currency translation ($1 million) and lower income due to business acquisitions ($1 million). |

[0000833444-20-000006:mdna:67]
[same as prior period, unchanged from 0000833444-19-000041:mdna:102]

[0000833444-20-000006:mdna:68]
The Company’s backlog relating to the Building Technologies & Solutions business is applicable to its sales of systems and services. At December 31, 2019, the backlog was $9.3 billion, of which $9.0 billion is attributable to the field business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-20-000006:mdna:69]
In the first quarter of fiscal 2019, the Company adopted ASC 606, “Revenue from Contracts with Customers,” and as a result is required to disclose remaining performance obligations. At December 31, 2019, remaining performance obligations were $14.7 billion, which is $5.4 billion higher than the Company's backlog of $9.3 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-20-000006:mdna:70]
[same as prior period, unchanged from 0000833444-19-000041:mdna:105]

[0000833444-20-000006:mdna:71]
[same as prior period, unchanged from 0000833444-19-000041:mdna:106]

[0000833444-20-000006:mdna:72]
[same as prior period, unchanged from 0000833444-19-000041:mdna:107]

[0000833444-20-000006:mdna:73]
[same as prior period, unchanged from 0000833444-19-000041:mdna:108]

[0000833444-20-000006:mdna:74]
[same as prior period, unchanged from 0000833444-19-000041:mdna:109]

[0000833444-20-000006:mdna:75]
[same as prior period, unchanged from 0000833444-19-000041:mdna:110]

[0000833444-20-000006:mdna:76]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2019 |  | 2019 |  | Change |
| Current assets | $ | 11,320 |  |  | $ | 12,393 |  |  |  |
| Current liabilities | (9,692 | ) |  | (9,070 | ) |  |  |
|  | 1,628 |  |  | 3,323 |  |  | -51 | % |
| Less: Cash | (2,160 | ) |  | (2,805 | ) |  |  |
| Add: Short-term debt | 20 |  |  | 10 |  |  |  |
| Add: Current portion of long-term debt | 1,342 |  |  | 501 |  |  |  |
| Less: Assets held for sale | (87 | ) |  | (98 | ) |  |  |
| Add: Liabilities held for sale | 44 |  |  | 44 |  |  |  |
| Working capital (as defined) | $ | 787 |  |  | $ | 975 |  |  | -19 | % |
| Accounts receivable - net | $ | 5,612 |  |  | $ | 5,770 |  |  | -3 | % |
| Inventories | 1,953 |  |  | 1,814 |  |  | 8 | % |
| Accounts payable | 3,336 |  |  | 3,582 |  |  | -7 | % |

[0000833444-20-000006:mdna:77]
[same as prior period, unchanged from 0000833444-19-000041:mdna:112]

[0000833444-20-000006:mdna:78]
| • | The decrease in working capital at December 31, 2019 as compared to September 30, 2019, was primarily due to lower income tax assets and the establishment of an operating lease liability on the balance sheet in the first quarter of fiscal 2020 as a result of the adoption of ASC 842, partially offset by a decrease in accounts payable due to timing of supplier payments and other current liabilities. |

[0000833444-20-000006:mdna:79]
| • | The Company’s days sales in accounts receivable at December 31, 2019 and September 30, 2019 were 72 days and 67 days, respectively. There has been no significant adverse changes in the level of overdue receivables or significant changes in revenue recognition methods. |

[0000833444-20-000006:mdna:80]
| • | The Company’s inventory turns for the three months ended December 31, 2019 were lower than the comparable period ended September 30, 2019, primarily due to changes in inventory production levels. |

[0000833444-20-000006:mdna:81]
| • | Days in accounts payable at December 31, 2019 were 76 days, higher than 72 days at the comparable period ended September 30, 2019. |

[0000833444-20-000006:mdna:82]
46

[0000833444-20-000006:mdna:83]
[same as prior period, unchanged from 0000833444-19-000041:mdna:118]

[0000833444-20-000006:mdna:84]
|  |  | Three Months Ended December 31, |
| (in millions) |  | 2019 |  | 2018 |
| Cash provided (used) by operating activities |  | $ | 511 |  |  | $ | (79 | ) |
| Cash used by investing activities |  | (173 | ) |  | (136 | ) |
| Cash provided (used) by financing activities |  | (850 | ) |  | 256 |  |

[0000833444-20-000006:mdna:85]
| • | The increase in cash provided by operating activities was primarily due to income tax refunds and favorable changes in accounts receivable and inventory, partially offset by unfavorable changes in accounts payable and accrued liabilities. |

[0000833444-20-000006:mdna:86]
| • | The increase in cash used by investing activities was primarily due to net cash payments made for acquisitions. |

[0000833444-20-000006:mdna:87]
| • | The increase in cash used by financing activities was primarily due to lower debt borrowings and higher stock repurchases. |

[0000833444-20-000006:mdna:88]
[same as prior period, unchanged from 0000833444-19-000041:mdna:124]

[0000833444-20-000006:mdna:89]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2019 |  | 2019 |  | Change |
| Short-term debt | $ | 20 |  |  | $ | 10 |  |  |  |
| Current portion of long-term debt | 1,342 |  |  | 501 |  |  |  |
| Long-term debt | 5,920 |  |  | 6,708 |  |  |  |
| Total debt | 7,282 |  |  | 7,219 |  |  | 1 | % |
| Less: cash and cash equivalents | 2,160 |  |  | 2,805 |  |  |  |
| Total net debt | 5,122 |  |  | 4,414 |  |  | 16 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 19,329 |  |  | 19,766 |  |  | -2 | % |
| Total capitalization | $ | 24,451 |  |  | $ | 24,180 |  |  | 1 | % |
| Total net debt as a % of total capitalization | 20.9 | % |  | 18.3 | % |  |  |

[0000833444-20-000006:mdna:90]
[same as prior period, unchanged from 0000833444-19-000041:mdna:126]

[0000833444-20-000006:mdna:91]
| • | The Company believes its capital resources and liquidity position at December 31, 2019 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in the remainder of fiscal 2020 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company is unable to issue commercial paper, it would have the ability to draw on its $2.5 billion and $0.5 billion revolving credit facilities. The facilities mature in December 2024 and December 2020, respectively. There were no draws on the revolving credit facilities as of December 31, 2019 and September 30, 2019. In addition, the Company held cash and cash equivalents of $2.2 billion as of December 31, 2019. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future. |

[0000833444-20-000006:mdna:92]
| • | The Company’s debt financial covenant in its revolving credit facility requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity |

[0000833444-20-000006:mdna:93]
47

[0000833444-20-000006:mdna:94]
attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of December 31, 2019, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures, governing its notes, and expect to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-20-000006:mdna:95]
| • | The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2020, the Company believes the long-term rate of return will approximate 6.90%, 5.20% and 5.70% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first three months of fiscal 2020, the Company made approximately $12 million in total pension and postretirement contributions for continuing operations. In total, the Company expects to contribute approximately $50 million in cash to its defined benefit pension plans in fiscal 2020 for continuing operations. The Company expects to contribute $4 million in cash to its postretirement plans in fiscal 2020 for continuing operations. |

[0000833444-20-000006:mdna:96]
| • | The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in fiscal 2019, the Company provided income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain subsidiaries as a result of the planned divestiture of the Power Solutions business. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. Except as noted, the Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings. |

[0000833444-20-000006:mdna:97]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2020 and recorded $111 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2020 restructuring plan will reduce annual operating costs for continuing operations by approximately $80 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in 2021. For fiscal 2020, the savings, net of execution costs, are expected to be approximately 60% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in 2020. The restructuring plan reserve balance of $49 million at December 31, 2019 is expected to be paid in cash. |

[0000833444-20-000006:mdna:98]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2018 and recorded $255 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2018 restructuring plan will reduce annual operating costs for continuing operations by approximately $300 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in 2020. The restructuring action is expected to be substantially complete in 2020. The restructuring plan reserve balance of $95 million at December 31, 2019 is expected to be paid in cash. |

[0000833444-20-000006:mdna:99]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2017 and recorded $347 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs for continuing operations by approximately $260 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company substantially realized the annual benefit of these actions in fiscal 2019. The restructuring actions are expected to be substantially complete in fiscal 2020. The restructuring plan reserve balance of $46 million at December 31, 2019 is expected to be paid in cash. |

[0000833444-20-000006:mdna:100]
| • | Refer to Note 12, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information on items impacting capitalization. |

[0000833444-20-000006:mdna:101]
[same as prior period, unchanged from 0000833444-19-000041:mdna:140]

[0000833444-20-000006:mdna:102]
[same as prior period, unchanged from 0000833444-19-000041:mdna:141]
