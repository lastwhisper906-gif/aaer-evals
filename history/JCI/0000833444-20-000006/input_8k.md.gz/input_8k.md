# JCI 8-K — 0000833444-20-000003 filed 2020-01-31

## item codes, every 8-K on or before 2020-01-31

- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2020-01-31

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-20-000003:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq1f.htm
EXHIBIT 99.1

[0000833444-20-000003:8k_2_02:2]
Exhibit

[0000833444-20-000003:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000833444-20-000003:8k_2_02:4]
| CONTACT: | Investors:Antonella Franzen(609) 720-4665Ryan Edelman(609) 720-4545Media:Fraser Engerman(414) 524-2733 | Exhibit 99.1 |

[0000833444-20-000003:8k_2_02:5]
Johnson Controls reports strong start to the fiscal year and reaffirms full year guidance

[0000833444-20-000003:8k_2_02:6]
________________________________________________________________________________

[0000833444-20-000003:8k_2_02:7]
| ▪ | GAAP EPS from continuing operations of $0.21 per share, including special items |

[0000833444-20-000003:8k_2_02:8]
| ▪ | Adjusted EPS from continuing operations of $0.40, up 54% versus prior year |

[0000833444-20-000003:8k_2_02:9]
| ▪ | Sales of $5.6 billion, up 2%, reflecting organic growth of 3%; Field up 2% with organic growth of 4%; Products up 1% with organic growth of 2% |

[0000833444-20-000003:8k_2_02:10]
| ▪ | Field orders flat organically versus strong prior year; Backlog up 6% organically versus prior year |

[0000833444-20-000003:8k_2_02:11]
| ▪ | Repurchased approximately 15 million shares in the quarter for $651 million |

[0000833444-20-000003:8k_2_02:12]
| ▪ | Reaffirms fiscal 2020 adjusted EPS from continuing operations guidance of $2.50 to $2.60, representing a year-over-year increase of 28% to 33% |

[0000833444-20-000003:8k_2_02:13]
________________________________________________________________________________

[0000833444-20-000003:8k_2_02:14]
CORK, Ireland, January 31, 2020 -- Johnson Controls International plc (NYSE: JCI) today reported fiscal first quarter 2020 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.21.  Excluding these items, adjusted EPS from continuing operations was $0.40, up 54% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-20-000003:8k_2_02:15]
Sales of $5.6 billion increased 2% compared to the prior year and grew 3% organically.

[0000833444-20-000003:8k_2_02:16]
GAAP earnings before interest and taxes (“EBIT”) was $308 million and EBIT margin was 5.5%. Adjusted EBIT was $448 million and adjusted EBIT margin was 8.0%, up 70 basis points over the prior year.  Excluding the impact of M&A and foreign currency, the underlying adjusted EBIT margin increased 80 basis points.

[0000833444-20-000003:8k_2_02:17]
Page 1 of 14

[0000833444-20-000003:8k_2_02:18]
“Our first quarter results reflect a strong start to fiscal 2020, marking the fifth consecutive quarter of organic double-digit adjusted EBIT growth as a pure-play buildings technology company.  Our performance in the quarter reflects a continued commitment to solid execution and to improving the underlying fundamentals of our business, which is shared throughout the organization,” said George Oliver, chairman and CEO.  “We deliver the safest, most secure and sustainable solutions for our customers given our robust portfolio of products and services.  This, along with our strong balance sheet, positions us well to continue to deliver long-term shareholder value,” Oliver added.

[0000833444-20-000003:8k_2_02:19]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-20-000003:8k_2_02:20]
($ millions, except per-share amounts)

[0000833444-20-000003:8k_2_02:21]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal first quarter of 2019.  The results of Power Solutions are reported as discontinued operations in all periods presented.

[0000833444-20-000003:8k_2_02:22]
Organic sales growth, organic EBITA growth, segment EBITA, adjusted segment EBITA, EBIT, adjusted EBIT, adjusted EPS from continuing operations and adjusted free cash flow are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes.  A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-20-000003:8k_2_02:23]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q1 2019 | Q1 2020 |  | Q1 2019 | Q1 2020 | Change |
| Sales | $5,464 | $5,576 |  | $5,464 | $5,576 | +2% |
| Segment EBITA | 583 | 623 |  | 590 | 625 | +6% |
| EBIT | 329 | 308 |  | 400 | 448 | +12% |
| Net income from continuing operations | 107 | 159 |  | 243 | 306 | +26% |
| Diluted EPS from continuing operations | $0.12 | $0.21 |  | $0.26 | $0.40 | +54% |

[0000833444-20-000003:8k_2_02:24]
Page 2 of 14

[0000833444-20-000003:8k_2_02:25]
BUSINESS RESULTS

[0000833444-20-000003:8k_2_02:26]
Building Solutions North America

[0000833444-20-000003:8k_2_02:27]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q1 2019 | Q1 2020 |  | Q1 2019 | Q1 2020 | Change |
| Sales | $2,116 | $2,167 |  | $2,116 | $2,167 | 2% |
| Segment EBITA | $250 | $258 |  | $253 | $259 | 2% |
| Segment EBITA margin % | 11.8% | 11.9% |  | 12.0% | 12.0% | — |

[0000833444-20-000003:8k_2_02:28]
Sales in the quarter of $2.2 billion, increased 2% versus the prior year.  Organic sales increased 3% versus the prior year led by strength in Fire & Security and, to a lesser extent, HVAC & Controls.  This growth was partially offset by a decline in Performance Solutions.

[0000833444-20-000003:8k_2_02:29]
Orders in the quarter, excluding M&A and adjusted for foreign currency, decreased 1% year-over-year off a strong prior year and due to timing between quarters.  Backlog at the end of the quarter of $5.8 billion increased 7% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-20-000003:8k_2_02:30]
Adjusted segment EBITA was $259 million, up 2% versus the prior year. Adjusted segment EBITA margin of 12.0% was consistent with the prior year as favorable volume leverage as well as productivity savings and cost synergies, were offset by Retail mix.

[0000833444-20-000003:8k_2_02:31]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-20-000003:8k_2_02:32]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q1 2019 | Q1 2020 |  | Q1 2019 | Q1 2020 | Change |
| Sales | $907 | $928 |  | $907 | $928 | 2% |
| Segment EBITA | $77 | $90 |  | $77 | $90 | 17% |
| Segment EBITA margin % | 8.5% | 9.7% |  | 8.5% | 9.7% | 120bps |

[0000833444-20-000003:8k_2_02:33]
Sales in the quarter of $928 million increased 2% versus the prior year.  Organic sales grew 7% versus the prior year driven by strong growth in project installations and service.  Growth was positive across all regions and across HVAC & Controls, Fire & Security and Industrial Refrigeration.

[0000833444-20-000003:8k_2_02:34]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 4% year-over-year.  Backlog at the end of the quarter of $1.7 billion increased 8% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-20-000003:8k_2_02:35]
Page 3 of 14

[0000833444-20-000003:8k_2_02:36]
Adjusted segment EBITA was $90 million, up 17% versus the prior year. Adjusted segment EBITA margin of 9.7% expanded 120 basis points over the prior year, including a 10 basis point headwind related to foreign currency.  Adjusting for foreign currency, the underlying margin improved 130 basis points driven by favorable volume leverage as well as the benefit from productivity savings and cost synergies.

[0000833444-20-000003:8k_2_02:37]
Building Solutions Asia Pacific

[0000833444-20-000003:8k_2_02:38]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q1 2019 | Q1 2020 |  | Q1 2019 | Q1 2020 | Change |
| Sales | $613 | $629 |  | $613 | $629 | 3% |
| Segment EBITA | $66 | $72 |  | $66 | $72 | 9% |
| Segment EBITA margin % | 10.8% | 11.4% |  | 10.8% | 11.4% | 60bps |

[0000833444-20-000003:8k_2_02:39]
Sales in the quarter of $629 million increased 3% versus the prior year.  Organic sales also increased 3% versus the prior year driven by growth in project installations, particularly in Fire & Security.

[0000833444-20-000003:8k_2_02:40]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 1% year-over-year.  Backlog at the end of the quarter of $1.6 billion increased 2% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-20-000003:8k_2_02:41]
Adjusted segment EBITA was $72 million, up 9% versus the prior year. Adjusted segment EBITA margin of 11.4% expanded 60 basis points over the prior year driven by favorable volume leverage and the benefit of productivity savings and cost synergies.

[0000833444-20-000003:8k_2_02:42]
Global Products

[0000833444-20-000003:8k_2_02:43]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q1 2019 | Q1 2020 |  | Q1 2019 | Q1 2020 | Change |
| Sales | $1,828 | $1,852 |  | $1,828 | $1,852 | 1% |
| Segment EBITA | $190 | $203 |  | $194 | $204 | 5% |
| Segment EBITA margin % | 10.4% | 11.0% |  | 10.6% | 11.0% | 40bps |

[0000833444-20-000003:8k_2_02:44]
Sales in the quarter of $1.9 billion increased 1% versus the prior year. Organic sales increased 2% versus the prior year led by strong growth in Building Management Systems and, to a lesser extent, Specialty Products. Sales of HVAC & Refrigeration Equipment were consistent with the prior year.

[0000833444-20-000003:8k_2_02:45]
Page 4 of 14

[0000833444-20-000003:8k_2_02:46]
Adjusted segment EBITA was $204 million, up 5% versus the prior year. Adjusted segment EBITA margin of 11.0% expanded 40 basis points over the prior year, including a 10 basis point headwind related to foreign currency.  Adjusting for foreign currency, the underlying margin improved 50 basis points driven by positive price/cost as well as the benefit of productivity savings and cost synergies.

[0000833444-20-000003:8k_2_02:47]
Corporate

[0000833444-20-000003:8k_2_02:48]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q1 2019 | Q1 2020 |  | Q1 2019 | Q1 2020 | Change |
| Corporate expense | ($136) | ($118) |  | ($93) | ($81) | (13%) |

[0000833444-20-000003:8k_2_02:49]
Adjusted Corporate expense was $81 million in the quarter, a decrease of 13% compared to the prior year, driven primarily by continued productivity savings and cost synergies, as well as cost reductions related to the Power Solutions sale.

[0000833444-20-000003:8k_2_02:50]
OTHER ITEMS

[0000833444-20-000003:8k_2_02:51]
| • | As expected during the quarter, the Company received an income tax refund of $0.6 billion. |

[0000833444-20-000003:8k_2_02:52]
| • | Cash provided by operating activities from continuing operations was $0.5 billion and capital expenditures were $0.1 billion in the quarter, resulting in free cash flow from continuing operations of $0.4 billion. Adjusted free cash flow was an outflow of $0.1 billion, which excludes net cash inflows of $0.4 billion primarily related to an income tax refund partially offset by integration costs. |

[0000833444-20-000003:8k_2_02:53]
| • | During the quarter, the Company repurchased approximately 15 million shares for $651 million. |

[0000833444-20-000003:8k_2_02:54]
| • | During the quarter, the Company recorded a pre-tax restructuring and impairment charge of $111 million primarily related to workforce reductions, plant closures and asset impairments. |

[0000833444-20-000003:8k_2_02:55]
| • | During the quarter, the Company adopted Accounting Standards Codification (ASC) 842, Leases, which resulted in an increase to other noncurrent assets of $1.1 billion, other current liabilities of $0.3 billion and other noncurrent liabilities of $0.8 billion. |

[0000833444-20-000003:8k_2_02:56]
###

[0000833444-20-000003:8k_2_02:57]
Page 5 of 14

[0000833444-20-000003:8k_2_02:58]
About Johnson Controls:

[0000833444-20-000003:8k_2_02:59]
At Johnson Controls, we transform the environments where people live, work, learn and play. From optimizing building performance to improving safety and enhancing comfort, we drive the outcomes that matter most. We deliver our promise in industries such as healthcare, education, data centers, and manufacturing. With a global team of 105,000 experts in more than 150 countries and over 130 years of innovation, we are the power behind our customers’ mission. Our leading portfolio of building technology and solutions includes some of the most trusted names in the industry, such as Tyco®, YORK®, Metasys®, Ruskin®, Titus®, Frick®, PENN®, Sabroe®, Simplex®, Ansul® and Grinnell®. For more information, visit www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter

[0000833444-20-000003:8k_2_02:60]
###

[0000833444-20-000003:8k_2_02:61]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-20-000003:8k_2_02:62]
Page 6 of 14

[0000833444-20-000003:8k_2_02:63]
###

[0000833444-20-000003:8k_2_02:64]
Non-GAAP Financial Information

[0000833444-20-000003:8k_2_02:65]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include restructuring and impairment costs, transaction costs, integration costs, net mark-to-market adjustments, and discrete tax items. Financial information regarding organic sales, EBIT, EBIT margin, segment EBITA, adjusted segment EBITA, adjusted organic segment EBITA, adjusted segment EBITA margin, free cash flow and adjusted free cash flow, are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as transaction costs and integration costs because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.  For further information on the calculation of thee non-GAAP measures and a reconciliation of these non-GAAP measures, refer to the attached footnotes.

[0000833444-20-000003:8k_2_02:66]
###

[0000833444-20-000003:8k_2_02:67]
Page 7 of 14

[0000833444-20-000003:8k_2_02:68]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Three Months Ended December 31, |
|  |  | 2019 |  |  | 2018 |
| Net sales | $ | 5,576 |  |  |  | $ | 5,464 |  |
| Cost of sales | 3,773 |  |  |  | 3,739 |  |
|  | Gross profit | 1,803 |  |  |  | 1,725 |  |
| Selling, general and administrative expenses | (1,427 | ) |  |  | (1,438 | ) |
| Restructuring and impairment costs | (111 | ) |  |  | — |  |
| Net financing charges | (52 | ) |  |  | (85 | ) |
| Equity income | 43 |  |  |  | 42 |  |
| Income from continuing operations before income taxes | 256 |  |  |  | 244 |  |
| Income tax provision | 65 |  |  |  | 108 |  |
| Income from continuing operations | 191 |  |  |  | 136 |  |
| Income from discontinued operations, net of tax | — |  |  |  | 263 |  |
| Net income | 191 |  |  |  | 399 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 32 |  |  |  | 29 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 15 |  |
| Net income attributable to JCI | $ | 159 |  |  |  | $ | 355 |  |
| Income from continuing operations | $ | 159 |  |  |  | $ | 107 |  |
| Income from discontinued operations | — |  |  |  | 248 |  |
| Net income attributable to JCI | $ | 159 |  |  |  | $ | 355 |  |
| Diluted earnings per share from continuing operations | $ | 0.21 |  |  |  | $ | 0.12 |  |
| Diluted earnings per share from discontinued operations | — |  |  |  | 0.27 |  |
| Diluted earnings per share * | $ | 0.21 |  |  |  | $ | 0.38 |  |
| Diluted weighted average shares | 774.0 |  |  |  | 925.2 |  |
| Shares outstanding at period end | 764.0 |  |  |  | 912.7 |  |

[0000833444-20-000003:8k_2_02:69]
* May not sum due to rounding.

[0000833444-20-000003:8k_2_02:70]
Page 8 of 14

[0000833444-20-000003:8k_2_02:71]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | December 31,2019 |  | September 30,2019 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 2,160 |  |  | $ | 2,805 |  |
| Accounts receivable - net | 5,612 |  |  | 5,770 |  |
| Inventories | 1,953 |  |  | 1,814 |  |
| Assets held for sale | 87 |  |  | 98 |  |
| Other current assets | 1,508 |  |  | 1,906 |  |
|  | Current assets | 11,320 |  |  | 12,393 |  |
| Property, plant and equipment - net | 3,341 |  |  | 3,348 |  |
| Goodwill | 18,351 |  |  | 18,178 |  |
| Other intangible assets - net | 5,610 |  |  | 5,632 |  |
| Investments in partially-owned affiliates | 865 |  |  | 853 |  |
| Noncurrent assets held for sale | 46 |  |  | 60 |  |
| Other noncurrent assets | 2,980 |  |  | 1,823 |  |
|  | Total assets | $ | 42,513 |  |  | $ | 42,287 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 1,362 |  |  | $ | 511 |  |
| Accounts payable and accrued expenses | 4,180 |  |  | 4,535 |  |
| Liabilities held for sale | 44 |  |  | 44 |  |
| Other current liabilities | 4,106 |  |  | 3,980 |  |
|  | Current liabilities | 9,692 |  |  | 9,070 |  |
| Long-term debt | 5,920 |  |  | 6,708 |  |
| Other noncurrent liabilities | 6,470 |  |  | 5,680 |  |
| Shareholders' equity attributable to JCI | 19,329 |  |  | 19,766 |  |
| Noncontrolling interests | 1,102 |  |  | 1,063 |  |
|  | Total liabilities and equity | $ | 42,513 |  |  | $ | 42,287 |  |

[0000833444-20-000003:8k_2_02:72]
Page 9 of 14

[0000833444-20-000003:8k_2_02:73]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended December 31, |
|  |  |  |  |  |  | 2019 |  |  | 2018 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI from continuing operations | $ | 159 |  |  |  | $ | 107 |  |
| Income from continuing operations attributable to noncontrolling interests | 32 |  |  |  | 29 |  |
| Net income from continuing operations | 191 |  |  |  | 136 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 207 |  |  |  | 211 |  |
|  |  | Pension and postretirement benefit income | (40 | ) |  |  | (29 | ) |
|  |  | Pension and postretirement contributions | (12 | ) |  |  | (21 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | 8 |  |  |  | (36 | ) |
|  |  | Deferred income taxes | (3 | ) |  |  | 43 |  |
|  |  | Non-cash restructuring and impairment costs | 54 |  |  |  | — |  |
|  |  | Other - net | 16 |  |  |  | 28 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | 237 |  |  |  | 146 |  |
|  |  |  |  | Inventories | (114 | ) |  |  | (222 | ) |
|  |  |  |  | Other assets | (92 | ) |  |  | (63 | ) |
|  |  |  |  | Restructuring reserves | 33 |  |  |  | (25 | ) |
|  |  |  |  | Accounts payable and accrued liabilities | (498 | ) |  |  | (226 | ) |
|  |  |  |  | Accrued income taxes | 524 |  |  |  | (21 | ) |
|  |  |  |  |  | Cash provided (used) by operating activities from continuing operations | 511 |  |  |  | (79 | ) |
| Investing Activities |  |  |  |  |
| Capital expenditures | (126 | ) |  |  | (153 | ) |
| Acquisition of businesses, net of cash acquired | (48 | ) |  |  | (13 | ) |
| Business divestitures, net of cash divested | — |  |  |  | 6 |  |
| Other - net | 1 |  |  |  | 24 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (173 | ) |  |  | (136 | ) |
| Financing Activities |  |  |  |  |
| Increase in short and long-term debt - net | 10 |  |  |  | 1,014 |  |
| Stock repurchases | (651 | ) |  |  | (467 | ) |
| Payment of cash dividends | (203 | ) |  |  | (240 | ) |
| Dividends paid to noncontrolling interests | (5 | ) |  |  | (43 | ) |
| Proceeds from the exercise of stock options | 21 |  |  |  | 13 |  |
| Employee equity-based compensation withholding | (20 | ) |  |  | (21 | ) |
| Other - net | (2 | ) |  |  | — |  |
|  |  |  |  |  | Cash provided (used) by financing activities from continuing operations | (850 | ) |  |  | 256 |  |
| Discontinued Operations |  |  |  |  |
| Net cash provided (used) by operating activities | (194 | ) |  |  | 193 |  |
| Net cash used by investing activities | — |  |  |  | (66 | ) |
| Net cash used by financing activities | — |  |  |  | (11 | ) |
|  |  |  |  |  | Net cash flows provided (used) by discontinued operations | (194 | ) |  |  | 116 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 57 |  |  |  | (43 | ) |
| Changes in cash held for sale | — |  |  |  | (2 | ) |
| Increase (decrease) in cash, cash equivalents and restricted cash | $ | (649 | ) |  |  | $ | 112 |  |

[0000833444-20-000003:8k_2_02:74]
Page 10 of 14

[0000833444-20-000003:8k_2_02:75]
FOOTNOTES

[0000833444-20-000003:8k_2_02:76]
1. Financial Summary

[0000833444-20-000003:8k_2_02:77]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans. The financial results shown below are for continuing operations and exclude the Power Solutions business.

[0000833444-20-000003:8k_2_02:78]
|  | Three Months Ended December 31, |
| (in millions; unaudited) | 2019 |  | 2018 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,167 |  |  | $ | 2,167 |  |  | $ | 2,116 |  |  | $ | 2,116 |  |
| Building Solutions EMEA/LA | 928 |  |  | 928 |  |  | 907 |  |  | 907 |  |
| Building Solutions Asia Pacific | 629 |  |  | 629 |  |  | 613 |  |  | 613 |  |
| Global Products | 1,852 |  |  | 1,852 |  |  | 1,828 |  |  | 1,828 |  |
| Net sales | $ | 5,576 |  |  | $ | 5,576 |  |  | $ | 5,464 |  |  | $ | 5,464 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 258 |  |  | $ | 259 |  |  | $ | 250 |  |  | $ | 253 |  |
| Building Solutions EMEA/LA | 90 |  |  | 90 |  |  | 77 |  |  | 77 |  |
| Building Solutions Asia Pacific | 72 |  |  | 72 |  |  | 66 |  |  | 66 |  |
| Global Products | 203 |  |  | 204 |  |  | 190 |  |  | 194 |  |
| Segment EBITA | 623 |  |  | 625 |  |  | 583 |  |  | 590 |  |
| Corporate expenses (2) | (118 | ) |  | (81 | ) |  | (136 | ) |  | (93 | ) |
| Amortization of intangible assets | (96 | ) |  | (96 | ) |  | (97 | ) |  | (97 | ) |
| Net mark-to-market adjustments (3) | 10 |  |  | — |  |  | (21 | ) |  | — |  |
| Restructuring and impairment costs (4) | (111 | ) |  | — |  |  | — |  |  | — |  |
| EBIT (5) | 308 |  |  | 448 |  |  | 329 |  |  | 400 |  |
| EBIT margin | 5.5 | % |  | 8.0 | % |  | 6.0 | % |  | 7.3 | % |
| Net financing charges | (52 | ) |  | (52 | ) |  | (85 | ) |  | (85 | ) |
| Income from continuing operations before income taxes | 256 |  |  | 396 |  |  | 244 |  |  | 315 |  |
| Income tax provision (6) | (65 | ) |  | (53 | ) |  | (108 | ) |  | (43 | ) |
| Income from continuing operations | 191 |  |  | 343 |  |  | 136 |  |  | 272 |  |
| Income from continuing operations attributable to noncontrolling interests | (32 | ) |  | (37 | ) |  | (29 | ) |  | (29 | ) |
| Net income from continuing operations attributable to JCI | $ | 159 |  |  | $ | 306 |  |  | $ | 107 |  |  | $ | 243 |  |

[0000833444-20-000003:8k_2_02:79]
(1) The Company's press release contains financial information regarding segment EBITA, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-20-000003:8k_2_02:80]
A reconciliation of segment EBITA to income from continuing operations is shown earlier within this footnote. The following is the three months ended December 31, 2019 and 2018 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-20-000003:8k_2_02:81]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment EBITA as reported | $ | 258 |  |  | $ | 250 |  |  | $ | 90 |  |  | $ | 77 |  |  | $ | 72 |  |  | $ | 66 |  |  | $ | 203 |  |  | $ | 190 |  |  | $ | 623 |  |  | $ | 583 |  |
| Segment EBITA margin as reported | 11.9 | % |  | 11.8 | % |  | 9.7 | % |  | 8.5 | % |  | 11.4 | % |  | 10.8 | % |  | 11.0 | % |  | 10.4 | % |  | 11.2 | % |  | 10.7 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | 1 |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 4 |  |  | 2 |  |  | 7 |  |
| Adjusted segment EBITA | $ | 259 |  |  | $ | 253 |  |  | $ | 90 |  |  | $ | 77 |  |  | $ | 72 |  |  | $ | 66 |  |  | $ | 204 |  |  | $ | 194 |  |  | $ | 625 |  |  | $ | 590 |  |
| Adjusted segment EBITA margin | 12.0 | % |  | 12.0 | % |  | 9.7 | % |  | 8.5 | % |  | 11.4 | % |  | 10.8 | % |  | 11.0 | % |  | 10.6 | % |  | 11.2 | % |  | 10.8 | % |

[0000833444-20-000003:8k_2_02:82]
(2) Adjusted Corporate expenses excludes special items because these costs are not considered to be directly related to the underlying operating performance of the Company’s business. Adjusted Corporate expenses for the three months ended December 31, 2019 excludes $37 million of integration costs. Adjusted Corporate expenses for the three months ended December 31, 2018 excludes $41 million of integration costs and $2 million of transaction costs.

[0000833444-20-000003:8k_2_02:83]
Page 11 of 14

[0000833444-20-000003:8k_2_02:84]
(3) The three months ended December 31, 2019 exclude the net mark-to-market adjustments on restricted investments of $10 million. The three months ended December 31, 2018 exclude the net mark-to-market adjustments on restricted investments of $21 million.

[0000833444-20-000003:8k_2_02:85]
(4) Restructuring and impairment costs for the three months ended December 31, 2019 of $111 million are excluded from the adjusted non-GAAP results. The restructuring actions and impairment costs related primarily to workforce reductions, plant closures and asset impairments.

[0000833444-20-000003:8k_2_02:86]
(5) Management defines earnings before interest and taxes (EBIT) as income from continuing operations before net financing charges, income taxes and noncontrolling interests. EBIT is a non-GAAP performance measure. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company. A reconciliation of EBIT to income from continuing operations is shown earlier within this footnote.

[0000833444-20-000003:8k_2_02:87]
(6) Adjusted income tax provision for the three months ended December 31, 2019 excludes tax provisions related to Switzerland tax reform of $30 million and net mark-to-market adjustments of $3 million, partially offset by tax benefits for restructuring and impairment costs of $16 million and integration costs of $5 million. Adjusted income tax provision for the three months ended December 31, 2018 excludes the tax provision for valuation allowance adjustments of $76 million as a result of changes in U.S. tax law, partially offset by the tax benefits for integration costs of $6 million and net mark-to-market adjustments of $5 million.

[0000833444-20-000003:8k_2_02:88]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-20-000003:8k_2_02:89]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include transaction/integration costs, net mark-to-market adjustments, restructuring and impairment costs, impact of ceasing the depreciation and amortization expense for the Power Solutions business as the business is held for sale, and discrete tax items. The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-20-000003:8k_2_02:90]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-20-000003:8k_2_02:91]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Three Months Ended |  | Three Months Ended |
|  | December 31, |  | December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Earnings per share as reported for JCI plc | $ | 0.21 |  |  | $ | 0.38 |  |  | $ | 0.21 |  |  | $ | 0.12 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 0.03 |  |  | — |  |  | — |  |
| Integration costs | 0.05 |  |  | 0.05 |  |  | 0.05 |  |  | 0.05 |  |
| Related tax impact | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |
| Net mark-to-market adjustments | (0.01 | ) |  | 0.02 |  |  | (0.01 | ) |  | 0.02 |  |
| Related tax impact | — |  |  | (0.01 | ) |  | — |  |  | (0.01 | ) |
| Restructuring and impairment costs | 0.14 |  |  | — |  |  | 0.14 |  |  | — |  |
| Related tax impact | (0.02 | ) |  | — |  |  | (0.02 | ) |  | — |  |
| NCI impact of restructuring and impairment | (0.01 | ) |  | — |  |  | (0.01 | ) |  | — |  |
| Cease of Power Solutions |  |  |  |  |  |  |  |
| depreciation / amortization expense | — |  |  | (0.03 | ) |  | — |  |  | — |  |
| Related tax impact | — |  |  | 0.01 |  |  | — |  |  | — |  |
| Discrete tax items | 0.04 |  |  | 0.16 |  |  | 0.04 |  |  | 0.08 |  |
| Adjusted earnings per share for JCI plc * | $ | 0.40 |  |  | $ | 0.61 |  |  | $ | 0.40 |  |  | $ | 0.26 |  |

[0000833444-20-000003:8k_2_02:92]
* May not sum due to rounding

[0000833444-20-000003:8k_2_02:93]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-20-000003:8k_2_02:94]
|  | Three Months Ended |
|  | December 31, |
|  | 2019 |  | 2018 |
| Weighted average shares outstanding for JCI plc |  |  |  |
| Basic weighted average shares outstanding | 769.9 |  |  | 921.6 |  |
| Effect of dilutive securities: |  |  |  |
| Stock options, unvested restricted stock |  |  |  |
| and unvested performance share awards | 4.1 |  |  | 3.6 |  |
| Diluted weighted average shares outstanding | 774.0 |  |  | 925.2 |  |

[0000833444-20-000003:8k_2_02:95]
The Company has presented forward-looking statements regarding adjusted EPS from continuing operations, organic net sales growth, organic adjusted EBITA growth, organic adjusted EBIT growth, adjusted segment EBITA margin, adjusted EBIT margin and adjusted free cash flow conversion for the full fiscal year of 2020, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, income or cash flows from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments and the effect of foreign currency exchange fluctuations. Our fiscal 2020 outlook for organic net sales and adjusted EBITA and EBIT growth also excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s full year 2020 GAAP financial results.

[0000833444-20-000003:8k_2_02:96]
Page 12 of 14

[0000833444-20-000003:8k_2_02:97]
3. Organic Growth Reconciliation

[0000833444-20-000003:8k_2_02:98]
The components of the changes in net sales for the three months ended December 31, 2019 versus the three months ended December 31, 2018, including organic growth, is shown below (unaudited):

[0000833444-20-000003:8k_2_02:99]
| (in millions) | Net Sales for the Three Months Ended December 31, 2018 |  | Base Year Adjustments - Divestitures and Other |  | Adjusted Base Net Sales for the Three Months Ended December 31, 2018 |  | Acquisitions |  | Foreign Currency |  | Organic Growth |  | Net Sales for the Three Months EndedDecember 31, 2019 |
| Building Solutions North America | $ | 2,116 |  |  | $ | (2 | ) |  | — |  |  | $ | 2,114 |  |  | $ | — |  |  | — |  |  | $ | — |  |  | — |  |  | $ | 53 |  |  | 3 | % |  | $ | 2,167 |  |  | 3 | % |
| Building Solutions EMEA/LA | 907 |  |  | (25 | ) |  | -3 | % |  | 882 |  |  | 5 |  |  | 1 | % |  | (25 | ) |  | -3 | % |  | 66 |  |  | 7 | % |  | 928 |  |  | 5 | % |
| Building Solutions Asia Pacific | 613 |  |  | — |  |  | — |  |  | 613 |  |  | 2 |  |  | — |  |  | (5 | ) |  | -1 | % |  | 19 |  |  | 3 | % |  | 629 |  |  | 3 | % |
| Total field | 3,636 |  |  | (27 | ) |  | -1 | % |  | 3,609 |  |  | 7 |  |  | — |  |  | (30 | ) |  | -1 | % |  | 138 |  |  | 4 | % |  | 3,724 |  |  | 3 | % |
| Global Products | 1,828 |  |  | (8 | ) |  | — |  |  | 1,820 |  |  | 1 |  |  | — |  |  | 3 |  |  | — |  |  | 28 |  |  | 2 | % |  | 1,852 |  |  | 2 | % |
| Total net sales | $ | 5,464 |  |  | $ | (35 | ) |  | -1 | % |  | $ | 5,429 |  |  | $ | 8 |  |  | — |  |  | $ | (27 | ) |  | — |  |  | $ | 166 |  |  | 3 | % |  | $ | 5,576 |  |  | 3 | % |

[0000833444-20-000003:8k_2_02:100]
The components of the changes in segment EBITA and EBIT for the three months ended December 31, 2019 versus the three months ended December 31, 2018, including organic growth, is shown below (unaudited):

[0000833444-20-000003:8k_2_02:101]
| (in millions) | Adjusted Segment EBITA / EBIT for the Three Months Ended December 31, 2018 |  | Base Year Adjustments - Divestitures and Other |  | Adjusted Base Segment EBITA / EBIT for the Three Months Ended December 31, 2018 |  | Acquisitions |  | Foreign Currency |  | Organic Growth |  | Adjusted SegmentEBITA / EBIT forthe ThreeMonths EndedDecember 31, 2019 |
| Building Solutions North America | $ | 253 |  |  | $ | — |  |  | — |  |  | $ | 253 |  |  | $ | — |  |  | — |  |  | $ | — |  |  | — |  |  | $ | 6 |  |  | 2 | % |  | $ | 259 |  |  | 2 | % |
| Building Solutions EMEA/LA | 77 |  |  | (1 | ) |  | -1 | % |  | 76 |  |  | 1 |  |  | 1 | % |  | (3 | ) |  | -4 | % |  | 16 |  |  | 21 | % |  | 90 |  |  | 18 | % |
| Building Solutions Asia Pacific | 66 |  |  | — |  |  | — |  |  | 66 |  |  | 1 |  |  | 2 | % |  | — |  |  | — |  |  | 5 |  |  | 8 | % |  | 72 |  |  | 9 | % |
| Total field | 396 |  |  | (1 | ) |  | — |  |  | 395 |  |  | 2 |  |  | 1 | % |  | (3 | ) |  | -1 | % |  | 27 |  |  | 7 | % |  | 421 |  |  | 7 | % |
| Global Products | 194 |  |  | — |  |  | — |  |  | 194 |  |  | (1 | ) |  | -1 | % |  | (1 | ) |  | -1 | % |  | 12 |  |  | 6 | % |  | 204 |  |  | 5 | % |
| Total adjusted segment EBITA | 590 |  |  | (1 | ) |  | — |  |  | 589 |  |  | $ | 1 |  |  | — |  |  | $ | (4 | ) |  | -1 | % |  | $ | 39 |  |  | 7 | % |  | 625 |  |  | 6 | % |
| Corporate expenses | (93 | ) |  | — |  |  |  |  | (93 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (81 | ) |  | 13 | % |
| Amortization of intangible assets | (97 | ) |  | — |  |  |  |  | (97 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (96 | ) |  | 1 | % |
| Total adjusted EBIT | $ | 400 |  |  | $ | (1 | ) |  |  |  | $ | 399 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 448 |  |  | 12 | % |

[0000833444-20-000003:8k_2_02:102]
4.  Adjusted Free Cash Flow Reconciliation

[0000833444-20-000003:8k_2_02:103]
The Company's press release contains financial information regarding free cash flow, adjusted free cash flow and adjusted free cash flow conversion, which are non-GAAP performance measures. Free cash flow is defined as cash provided by operating activities less capital expenditures. Adjusted free cash flow excludes special items, as included in the table below, because these cash flows are not considered to be directly related to its underlying businesses. Adjusted free cash flow conversion is defined as adjusted free cash flow divided by adjusted net income. Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash.

[0000833444-20-000003:8k_2_02:104]
The following is the three months ended December 31, 2019 and 2018 reconciliation of free cash flow, adjusted free cash flow and adjusted free cash flow conversion for continuing operations (unaudited):

[0000833444-20-000003:8k_2_02:105]
| (in billions) | Three Months Ended December 31, 2019 |  | Three Months Ended December 31, 2018 |
| Cash provided by operating activities from continuing operations | $ | 0.5 |  |  | $ | (0.1 | ) |
| Capital expenditures | (0.1 | ) |  | (0.2 | ) |
| Reported free cash flow | 0.4 |  |  | (0.3 | ) |
| Adjusting items: |  |  |  |
| Transaction/integration costs | 0.1 |  |  | 0.1 |  |
| Income tax refunds | (0.6 | ) |  | — |  |
| Total adjusting items * | (0.4 | ) |  | 0.1 |  |
| Adjusted free cash flow * | $ | (0.1 | ) |  | $ | (0.2 | ) |
| Adjusted net income from continuing operations |  |  |  |
| attributable to JCI | $ | 0.3 |  |  | $ | 0.2 |  |
| Adjusted free cash flow conversion | -33 | % |  | -100 | % |

[0000833444-20-000003:8k_2_02:106]
* May not sum due to rounding

[0000833444-20-000003:8k_2_02:107]
Page 13 of 14

[0000833444-20-000003:8k_2_02:108]
5.  Net Debt to Capitalization

[0000833444-20-000003:8k_2_02:109]
The Company provides financial information regarding net debt as a percentage of total capitalization, which is a non-GAAP performance measure. The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. The following is the December 31, 2019 and September 30, 2019 calculation of net debt as a percentage of total capitalization (unaudited):

[0000833444-20-000003:8k_2_02:110]
| (in millions) | December 31, 2019 |  | September 30, 2019 |
| Short-term debt and current portion of long-term debt | $ | 1,362 |  |  | $ | 511 |  |
| Long-term debt | 5,920 |  |  | 6,708 |  |
| Total debt | 7,282 |  |  | 7,219 |  |
| Less: cash and cash equivalents | 2,160 |  |  | 2,805 |  |
| Total net debt | 5,122 |  |  | 4,414 |  |
| Shareholders' equity attributable to JCI | 19,329 |  |  | 19,766 |  |
| Total capitalization | $ | 24,451 |  |  | $ | 24,180 |  |
| Total net debt as a % of total capitalization | 20.9 | % |  | 18.3 | % |

[0000833444-20-000003:8k_2_02:111]
6.  Income Taxes

[0000833444-20-000003:8k_2_02:112]
The Company's effective tax rate from continuing operations before consideration of transaction/integration costs, net mark-to-market adjustments, restructuring and impairment costs, and discrete tax items for the three months ending December 31, 2019 and 2018 is approximately 13.5%.

[0000833444-20-000003:8k_2_02:113]
7.  Restructuring and Impairment Costs

[0000833444-20-000003:8k_2_02:114]
The three months ended December 31, 2019 include restructuring and impairment costs of $111 million related primarily to workforce reductions, plant closures and asset impairments.

[0000833444-20-000003:8k_2_02:115]
8.  Leases

[0000833444-20-000003:8k_2_02:116]
On October 1, 2019, the Company adopted ASU 2016-02, “Leases (Topic 842),” which requires recognition of operating leases as a lease asset and liabilities on the balance sheet.  The adoption of the new guidance resulted in recognition of a right-of-use asset and related lease liabilities of $1.1 billion.

[0000833444-20-000003:8k_2_02:117]
Page 14 of 14
