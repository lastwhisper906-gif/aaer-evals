# JCI notes — 0000833444-20-000006


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-20-000006:notes:1]
[same as prior period, unchanged from 0000833444-19-000041:notes:1]

[0000833444-20-000006:notes:2]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2019 filed with the SEC on November 21, 2019. The results of operations for the three month period ended December 31, 2019 are not necessarily indicative of results for the Company’s 2020 fiscal year because of seasonal and other factors.

[0000833444-20-000006:notes:3]
[same as prior period, unchanged from 0000833444-19-000041:notes:3]

[0000833444-20-000006:notes:4]
[same as prior period, unchanged from 0000833444-19-000041:notes:4]

[0000833444-20-000006:notes:5]
[same as prior period, unchanged from 0000833444-19-000041:notes:5]

[0000833444-20-000006:notes:6]
[same as prior period, unchanged from 0000833444-19-000041:notes:6]

[0000833444-20-000006:notes:7]
[same as prior period, unchanged from 0000833444-19-000041:notes:7]

[0000833444-20-000006:notes:8]
The Company consolidates variable interest entities ("VIE") in which the Company has the power to direct the significant activities of the entity and the obligation to absorb losses or receive benefits from the entity that may be significant.  The Company did not have a significant variable interest in any consolidated or nonconsolidated VIEs in its continuing operations for the presented reporting periods.

[0000833444-20-000006:notes:9]
[same as prior period, unchanged from 0000833444-19-000041:notes:10]

[0000833444-20-000006:notes:10]
At December 31, 2019 and September 30, 2019, the Company held restricted cash of approximately $12 million and $16 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-20-000006:notes:11]
[same as prior period, unchanged from 0000833444-19-000041:notes:18]

[0000833444-20-000006:notes:12]
During the first quarter of fiscal 2020, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $54 million, of which $48 million was paid as of December 31, 2019. In connection with the acquisitions, the Company recorded goodwill of $17 million within the Global Products segment and $12 million within the Building Solutions EMEA/LA segment.

[0000833444-20-000006:notes:13]
During the first quarter of fiscal 2019, the Company completed an acquisition for a purchase price of $13 million, all of which was paid as of December 31, 2018. In connection with the acquisition, the Company recorded goodwill of $9 million within the Global Products segment.

[0000833444-20-000006:notes:14]
During the first quarter of fiscal 2019, the Company completed certain divestitures within the Global Products business. The combined selling price was $6 million, all of which was received as of December 31, 2018.

[0000833444-20-000006:notes:15]
Acquisitions and divestitures were not material to the Company's consolidated financial statements in either the first quarter of fiscal 2020 or 2019.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-20-000006:notes:16]
[same as prior period, unchanged from 0000833444-19-000041:notes:26]

[0000833444-20-000006:notes:17]
[same as prior period, unchanged from 0000833444-19-000041:notes:27]

[0000833444-20-000006:notes:18]
[same as prior period, unchanged from 0000833444-19-000041:notes:28]

[0000833444-20-000006:notes:19]
The following table summarizes the results of Power Solutions reclassified as discontinued operations for the three month period ended December 31, 2018 (in millions).

[0000833444-20-000006:notes:20]
|  | Three Months Ended December 31, |
|  | 2018 |
| Net sales | $ | 2,427 |  |
| Income from discontinued operations before income taxes | 390 |  |
| Provision for income taxes on discontinued operations | (127 | ) |
| Income from discontinued operations attributable to noncontrolling interests, net of tax | (15 | ) |
| Income from discontinued operations | $ | 248 |  |

[0000833444-20-000006:notes:21]
For the three months ended December 31, 2018, income from discontinued operations before income taxes included transaction costs of $28 million and a favorable impact of $32 million for ceasing depreciation and amortization expense as the business was held for sale.

[0000833444-20-000006:notes:22]
For the three months ended December 31, 2018, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the planned divestiture of the business and tax rate differentials.

[0000833444-20-000006:notes:23]
[same as prior period, unchanged from 0000833444-19-000041:notes:33]

[0000833444-20-000006:notes:24]
During the third quarter of fiscal 2019, the Company determined that a business within its Global Products segment met the criteria to be classified as held for sale. The assets and liabilities of this business are presented as held for sale in the consolidated statements of financial position as of December 31, 2019 and September 30, 2019. Assets and liabilities held for sale are required to be recorded at the lower of carrying value or fair value less any costs to sell. Accordingly, the Company has recorded total impairment charges of $250 million within restructuring and impairment costs in the consolidated statements of income to write down the carrying value of the assets held for sale to fair value less any costs to sell. Of the $250 million total impairment charges, $235 million was recorded during the third quarter of fiscal 2019, and $15 million was recorded during the first quarter of fiscal 2020. Refer to Note 18, "Impairment of Long-Lived Assets" of the notes to consolidated financial statements for further information regarding the impairment charges. The divestiture of the business held for sale could result in a gain or loss on sale to the extent the ultimate selling price differs from the current carrying value of the net assets recorded. The business did not meet the criteria to be classified as a discontinued operation as the divestiture of the business will not have a major effect on the Company's operations and financial results.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-20-000006:notes:25]
[same as prior period, unchanged from 0000833444-19-000041:notes:37]

[0000833444-20-000006:notes:26]
[same as prior period, unchanged from 0000833444-19-000041:notes:46]

[0000833444-20-000006:notes:27]
The following table presents the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three months ended December 31, 2019 and 2018 (in millions):

[0000833444-20-000006:notes:28]
|  |  | Three Months Ended December 31, 2019 |  | Three Months Ended December 31, 2018 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,356 |  |  | $ | 811 |  |  | $ | 2,167 |  |  | $ | 1,321 |  |  | $ | 795 |  |  | $ | 2,116 |  |
| Building Solutions EMEA/LA |  | 457 |  |  | 471 |  |  | 928 |  |  | 417 |  |  | 490 |  |  | 907 |  |
| Building Solutions Asia Pacific |  | 371 |  |  | 258 |  |  | 629 |  |  | 356 |  |  | 257 |  |  | 613 |  |
| Global Products |  | 1,852 |  |  | — |  |  | 1,852 |  |  | 1,828 |  |  | — |  |  | 1,828 |  |
| Total |  | $ | 4,036 |  |  | $ | 1,540 |  |  | $ | 5,576 |  |  | $ | 3,922 |  |  | $ | 1,542 |  |  | $ | 5,464 |  |

[0000833444-20-000006:notes:29]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2019 and 2018 (in millions):

[0000833444-20-000006:notes:30]
|  |  | Three Months Ended December 31, |
|  |  | 2019 |  | 2018 |
| Building management systems |  | $ | 300 |  |  | $ | 281 |  |
| HVAC & refrigeration equipment |  | 1,285 |  |  | 1,285 |  |
| Specialty products |  | 267 |  |  | 262 |  |
| Total |  | $ | 1,852 |  |  | $ | 1,828 |  |

[0000833444-20-000006:notes:31]
[same as prior period, unchanged from 0000833444-19-000041:notes:51]

[0000833444-20-000006:notes:32]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed and consist of unbilled receivables and costs in excess of billings. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract liabilities consist of deferred revenue. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

[0000833444-20-000006:notes:33]
[same as prior period, unchanged from 0000833444-19-000041:notes:53]

[0000833444-20-000006:notes:34]
|  |  | Location of contract balances |  | December 31, 2019 |  | September 30, 2019 |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,465 |  |  | $ | 1,389 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 99 |  |  | 90 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,495 | ) |  | (1,407 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (119 | ) |  | (117 | ) |
| Total |  |  |  | $ | (50 | ) |  | $ | (45 | ) |

[0000833444-20-000006:notes:35]
For the three months ended December 31, 2019 and December 31, 2018, the Company recognized revenue of $686 million and $712 million, respectively, that was included in the beginning of period contract liability balance.

[0000833444-20-000006:notes:36]
[same as prior period, unchanged from 0000833444-19-000041:notes:56]

[0000833444-20-000006:notes:37]
[same as prior period, unchanged from 0000833444-19-000041:notes:57]

[0000833444-20-000006:notes:38]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of December 31, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.7 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-20-000006:notes:39]
[same as prior period, unchanged from 0000833444-19-000041:notes:59]

[0000833444-20-000006:notes:40]
[same as prior period, unchanged from 0000833444-19-000041:notes:60]

[0000833444-20-000006:notes:41]
As of December 31, 2019, the Company recorded the costs to obtain or fulfill a contract of $236 million, of which $127 million is recorded within other current assets and $109 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2019, the Company recorded the costs to obtain or fulfill a contract of $212 million, of which $110 million is recorded within other current assets and $102 million is recorded within other noncurrent assets in the consolidated statements of financial position.

[0000833444-20-000006:notes:42]
During the three months ended December 31, 2019 and 2018, the Company recognized amortization expense of $26 million and $35 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three months ended December 31, 2019 and 2018.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-20-000006:notes:43]
Leases

[0000833444-20-000006:notes:44]
Lessee arrangements

[0000833444-20-000006:notes:45]
The Company leases certain administrative, production and other facilities, fleet vehicles, information technology equipment and other equipment under arrangements that are accounted for as operating leases. The Company determines whether an arrangement contains a lease at contract inception based on whether the arrangement involves the use of a physically distinct identified asset and whether the Company has the right to obtain substantially all of the economic benefits from the use of the asset throughout the period as well as the right to direct the use of the asset.

[0000833444-20-000006:notes:46]
Right-of-use assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent its obligation to make lease payments arising from the lease. Right-of-use assets and the corresponding lease liabilities are recognized at commencement date based on the present value of lease payments for all leases with terms longer than twelve months. As the majority of the Company's leases do not provide an implicit interest rate, to determine the present value of lease payments, the Company uses its incremental borrowing rate based on information available on the lease commencement date and uses the implicit rate when readily determinable.  The Company determines its incremental borrowing rate based on

[0000833444-20-000006:notes:47]
a comparable market yield curve consistent with the Company's credit rating, term of the lease and relative economic environment. The Company has elected to combine lease and non-lease components for its leases.

[0000833444-20-000006:notes:48]
Most leases contain options to renew or terminate the lease. Right-of-use assets and lease liabilities reflect only the options which the Company is reasonably certain to exercise. Lease expense is recognized on a straight-line basis over the lease term.

[0000833444-20-000006:notes:49]
The Company has certain real estate leases that contain variable lease payments which are based on changes in the Consumer Price Index (CPI). Additionally, the Company’s leases generally require it to pay for fuel, maintenance, repair, insurance and taxes. These payments are not included in the right-of-use asset or lease liability and are expensed as incurred.

[0000833444-20-000006:notes:50]
The following table presents the Company’s lease costs for the three months ended December 31, 2019 (in millions):

[0000833444-20-000006:notes:51]
|  |  | Three Months Ended December 31, |
|  |  | 2019 |
| Operating lease cost |  | $ | 99 |  |
| Variable lease cost |  | 40 |  |
| Total lease costs |  | $ | 139 |  |

[0000833444-20-000006:notes:52]
The following table presents supplemental consolidated statement of financial position information as of December 31, 2019 (in millions):

[0000833444-20-000006:notes:53]
|  | Location of lease balances |  | December 31, 2019 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,091 |  |
| Operating lease liabilities - current | Other current liabilities |  | 322 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 790 |  |
| Weighted-average remaining lease term |  |  | 6 years |  |
| Weighted-average discount rate |  |  | 2.3 | % |

[0000833444-20-000006:notes:54]
The following table presents supplemental cash flow information related to operating leases for the three months ended December 31, 2019 (in millions):

[0000833444-20-000006:notes:55]
|  |  | Three Months Ended December 31, 2019 |
| Cash paid for amounts included in the measurement of lease liability: |  |  |
| Operating cash outflows from operating leases |  | $ | 97 |  |
| Noncash operating lease activity: |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  | 74 |  |

[0000833444-20-000006:notes:56]
The following table presents maturities of operating lease liabilities as of December 31, 2019 (in millions):

[0000833444-20-000006:notes:57]
|  |  | December 31, 2019 |
| 2020 (9 months) |  | $ | 264 |  |
| 2021 |  | 304 |  |
| 2022 |  | 217 |  |
| 2023 |  | 126 |  |
| 2024 |  | 85 |  |
| After 2024 |  | 192 |  |
| Total operating lease payments |  | 1,188 |  |
| Less interest |  | (76 | ) |
| Present value of lease payments |  | $ | 1,112 |  |

[0000833444-20-000006:notes:58]
As previously disclosed in the Company's Annual Report on Form 10-K for the year ended September 30, 2019 and accounted for under the previous lease accounting guidance, future minimum operating lease payments for long-term noncancellable operating leases as of September 30, 2019 were as follows (in millions):

[0000833444-20-000006:notes:59]
|  |  | September 30, 2019 |
| 2020 |  | $ | 352 |  |
| 2021 |  | 287 |  |
| 2022 |  | 200 |  |
| 2023 |  | 111 |  |
| 2024 |  | 71 |  |
| After 2024 |  | 172 |  |
| Total minimum lease payments |  | $ | 1,193 |  |

[0000833444-20-000006:notes:60]
Lessor arrangements

[0000833444-20-000006:notes:61]
The Company's monitoring services and maintenance agreements within its electronic security business that include the subscriber system assets for which the Company retains ownership contain both lease and nonlease components. The Company has elected the practical expedient to combine lease and nonlease components for these arrangements where the timing and pattern of transfer of the lease and nonlease components are the same and the lease component would be classified as an operating lease if accounted for separately. The Company has concluded that in these arrangements the nonlease components are the predominant characteristic and as a result, the combined component is accounted for under the revenue guidance.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-20-000006:notes:62]
[same as prior period, unchanged from 0000833444-19-000041:notes:63]

[0000833444-20-000006:notes:63]
[same as prior period, unchanged from 0000833444-19-000041:notes:64]

[0000833444-20-000006:notes:64]
|  | December 31, 2019 |  | September 30, 2019 |
| Raw materials and supplies | $ | 637 |  |  | $ | 588 |  |
| Work-in-process | 167 |  |  | 176 |  |
| Finished goods | 1,149 |  |  | 1,050 |  |
| Inventories | $ | 1,953 |  |  | $ | 1,814 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-20-000006:notes:65]
[same as prior period, unchanged from 0000833444-19-000041:notes:66]

[0000833444-20-000006:notes:66]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the three month period ended December 31, 2019 were as follows (in millions):

[0000833444-20-000006:notes:67]
|  |  |  | Business Acquisitions |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  | December 31, |
|  | 2019 |  |  |  | 2019 |
| Building Solutions North America | $ | 9,588 |  |  | $ | — |  |  | $ | 12 |  |  | $ | 9,600 |  |
| Building Solutions EMEA/LA | 1,849 |  |  | 12 |  |  | 67 |  |  | 1,928 |  |
| Building Solutions Asia Pacific | 1,194 |  |  | — |  |  | 36 |  |  | 1,230 |  |
| Global Products | 5,547 |  |  | 17 |  |  | 29 |  |  | 5,593 |  |
| Total | $ | 18,178 |  |  | $ | 29 |  |  | $ | 144 |  |  | $ | 18,351 |  |

[0000833444-20-000006:notes:68]
At September 30, 2019, accumulated goodwill impairment charges included $47 million related to the Building Solutions EMEA/LA - Latin America reporting unit.

[0000833444-20-000006:notes:69]
[same as prior period, unchanged from 0000833444-19-000041:notes:71]

[0000833444-20-000006:notes:70]
|  | December 31, 2019 |  | September 30, 2019 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Amortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,328 |  |  | $ | (403 | ) |  | $ | 925 |  |  | $ | 1,307 |  |  | $ | (370 | ) |  | $ | 937 |  |
| Customer relationships | 2,754 |  |  | (817 | ) |  | 1,937 |  |  | 2,722 |  |  | (759 | ) |  | 1,963 |  |
| Miscellaneous | 585 |  |  | (231 | ) |  | 354 |  |  | 584 |  |  | (224 | ) |  | 360 |  |
| Total amortized intangible assets | 4,667 |  |  | (1,451 | ) |  | 3,216 |  |  | 4,613 |  |  | (1,353 | ) |  | 3,260 |  |
| Unamortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,304 |  |  | — |  |  | 2,304 |  |  | 2,282 |  |  | — |  |  | 2,282 |  |
| Miscellaneous | 90 |  |  | — |  |  | 90 |  |  | 90 |  |  | — |  |  | 90 |  |
|  | 2,394 |  |  | — |  |  | 2,394 |  |  | 2,372 |  |  | — |  |  | 2,372 |  |
| Total intangible assets | $ | 7,061 |  |  | $ | (1,451 | ) |  | $ | 5,610 |  |  | $ | 6,985 |  |  | $ | (1,353 | ) |  | $ | 5,632 |  |

[0000833444-20-000006:notes:71]
Amortization of other intangible assets included within continuing operations for the three month periods ended December 31, 2019 and 2018 was $96 million and $97 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2021, 2022, 2023, 2024 and 2025 will be approximately $394 million, $390 million, $379 million, $368 million and $344 million per year, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-20-000006:notes:72]
[same as prior period, unchanged from 0000833444-19-000041:notes:74]

[0000833444-20-000006:notes:73]
[same as prior period, unchanged from 0000833444-19-000041:notes:75]

[0000833444-20-000006:notes:74]
In fiscal 2020, the Company committed to a significant restructuring plan ("2020 Plan") and recorded $111 million of restructuring and impairment costs for continuing operations in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related primarily to cost reduction initiatives. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $87 million related to the Global Products segment, $10 million related to the Building Solutions Asia Pacific segment, $8 million related to the Building Solutions North America segment and $6 million related to the Building Solutions EMEA/LA segment. The restructuring actions are expected to be substantially complete in fiscal 2020.

[0000833444-20-000006:notes:75]
The following table summarizes the changes in the Company’s 2020 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-20-000006:notes:76]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 54 |  |  | $ | 54 |  |  | $ | 3 |  |  | $ | 111 |  |
| Utilized—cash | (8 | ) |  | — |  |  | — |  |  | (8 | ) |
| Utilized—noncash | — |  |  | (54 | ) |  | — |  |  | (54 | ) |
| Balance at December 31, 2019 | $ | 46 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 49 |  |

[0000833444-20-000006:notes:77]
In fiscal 2018, the Company committed to a significant restructuring plan ("2018 Plan") and recorded $255 million of restructuring and impairment costs for continuing operations in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $113 million related to the Global Products segment, $56 million related to the Building Solutions EMEA/LA segment, $50 million related to Corporate, $20 million related to the Building Solutions North America segment and $16 million related to the Building Solutions Asia Pacific segment. The restructuring actions are expected to be substantially complete in 2020.

[0000833444-20-000006:notes:78]
[same as prior period, unchanged from 0000833444-19-000041:notes:77]

[0000833444-20-000006:notes:79]
[same as prior period, unchanged from 0000833444-19-000041:notes:78]

[0000833444-20-000006:notes:80]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 209 |  |  | $ | 42 |  |  | $ | 12 |  |  | $ | — |  |  | $ | 263 |  |
| Utilized—cash | (45 | ) |  | — |  |  | (2 | ) |  | — |  |  | (47 | ) |
| Utilized—noncash | — |  |  | (42 | ) |  | — |  |  | — |  |  | (42 | ) |
| Balance at September 30, 2018 | $ | 164 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 174 |  |
| Utilized—cash | (61 | ) |  | — |  |  | (6 | ) |  | — |  |  | (67 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Transfer to liabilities held for sale | (4 | ) |  | — |  |  | — |  |  | — |  |  | (4 | ) |
| Balance at September 30, 2019 | $ | 99 |  |  | $ | — |  |  | $ | 4 |  |  | $ | (1 | ) |  | $ | 102 |  |
| Utilized—cash | (5 | ) |  | — |  |  | — |  |  | — |  |  | (5 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | 2 |  |  | 2 |  |
| Adoption of ASC 8421 | — |  |  | — |  |  | (4 | ) |  | — |  |  | (4 | ) |
| Balance at December 31, 2019 | $ | 94 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 95 |  |

[0000833444-20-000006:notes:81]
1Represents liability for facility closings recorded as an offset to right-of-use asset upon adoption of ASC 842.

[0000833444-20-000006:notes:82]
In fiscal 2017, the Company committed to a significant restructuring plan ("2017 Plan") and recorded $347 million of restructuring and impairment costs for continuing operations in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $166 million related to Corporate, $74 million related to the Building Solutions EMEA/LA segment, $59 million related to the Building Solutions North America segment, $32 million related to the Global Products segment and $16 million related to the Building Solutions Asia Pacific segment. The restructuring actions are expected to be substantially complete in fiscal 2020.

[0000833444-20-000006:notes:83]
[same as prior period, unchanged from 0000833444-19-000041:notes:81]

[0000833444-20-000006:notes:84]
[same as prior period, unchanged from 0000833444-19-000041:notes:82]

[0000833444-20-000006:notes:85]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 276 |  |  | $ | 77 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 367 |  |
| Utilized—cash | (75 | ) |  | — |  |  | — |  |  | — |  |  | (75 | ) |
| Utilized—noncash | — |  |  | (77 | ) |  | (1 | ) |  | — |  |  | (78 | ) |
| Adjustment to restructuring reserves | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |
| Balance at September 30, 2017 | $ | 226 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 239 |  |
| Utilized—cash | (152 | ) |  | — |  |  | (6 | ) |  | — |  |  | (158 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Balance at September 30, 2018 | $ | 74 |  |  | $ | — |  |  | $ | 7 |  |  | $ | (1 | ) |  | $ | 80 |  |
| Utilized—cash | (11 | ) |  | — |  |  | (2 | ) |  | — |  |  | (13 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (3 | ) |  | (3 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Balance at September 30, 2019 | $ | 60 |  |  | $ | — |  |  | $ | 5 |  |  | $ | (4 | ) |  | $ | 61 |  |
| Utilized—cash | (10 | ) |  | — |  |  | — |  |  | — |  |  | (10 | ) |
| Adoption of ASC 8421 | — |  |  | — |  |  | (5 | ) |  | — |  |  | (5 | ) |
| Balance at December 31, 2019 | $ | 50 |  |  | $ | — |  |  | $ | — |  |  | $ | (4 | ) |  | $ | 46 |  |

[0000833444-20-000006:notes:86]
The Company's fiscal 2020, 2018 and 2017 restructuring plans included workforce reductions of approximately 11,200 employees (9,000 for the Building Technologies & Solutions business and 2,200 for Corporate). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of December 31, 2019, approximately 8,100 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included nine plant closures in the Building Technologies & Solutions business. As of December 31, 2019, eight of the nine plants have been closed.

[0000833444-20-000006:notes:87]
[same as prior period, unchanged from 0000833444-19-000041:notes:89]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-20-000006:notes:88]
[same as prior period, unchanged from 0000833444-19-000041:notes:90]

[0000833444-20-000006:notes:89]
[same as prior period, unchanged from 0000833444-19-000041:notes:91]

[0000833444-20-000006:notes:90]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended December 31, 2019, the Company's effective tax rate for continuing operations was 25% and was higher than the statutory tax rate of 12.5% primarily due to a discrete tax charge related to the remeasurement of deferred tax assets and liabilities as a result of Swiss tax reform and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the three months ended December 31, 2018, the Company's effective tax rate for continuing operations was 44% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments as a result of tax law changes and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives.

[0000833444-20-000006:notes:91]
[same as prior period, unchanged from 0000833444-19-000041:notes:94]

[0000833444-20-000006:notes:92]
[same as prior period, unchanged from 0000833444-19-000041:notes:95]

[0000833444-20-000006:notes:93]
[same as prior period, unchanged from 0000833444-19-000041:notes:96]

[0000833444-20-000006:notes:94]
[same as prior period, unchanged from 0000833444-19-000041:notes:97]

[0000833444-20-000006:notes:95]
At September 30, 2019, the Company had gross tax effected unrecognized tax benefits of $2,451 million, of which $2,121 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2019 was approximately $181 million (net of tax benefit). The interest and penalties accrued during the three months ended December 31, 2019 were approximately $20 million (net of tax benefit). Interest and penalties accrued during the three months ended December 31, 2018 were immaterial. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-20-000006:notes:96]
The Company is currently under exam in the following major jurisdictions for continuing operations:

[0000833444-20-000006:notes:97]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2018 |
| China |  | 2008 - 2016 |
| Germany |  | 2007 - 2016 |
| Japan |  | 2015 - 2018 |
| Luxembourg |  | 2016 |
| United Kingdom |  | 2012 - 2015 |

[0000833444-20-000006:notes:98]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense.

[0000833444-20-000006:notes:99]
[same as prior period, unchanged from 0000833444-19-000041:notes:105]

[0000833444-20-000006:notes:100]
In the first quarter of fiscal 2020, the Company recorded a noncash discrete tax charge of $30 million due to the remeasurement of deferred tax assets and liabilities related to Switzerland and the canton of Schaffhausen. On September 28, 2018, the Swiss Parliament approved the Federal Act on Tax Reform and AHV Financing (“TRAF”), which was subsequently approved by the Swiss electorate on May 19, 2019. During the fourth quarter of fiscal 2019, the Swiss Federal Council enacted TRAF which becomes effective for the Company on January 1, 2020. The impacts of the federal enactment did not have a material impact to the Company’s financial statements. TRAF also provides for parameters which enable the Swiss cantons to adjust tax rates and establish new regulations for companies. As of September 30, 2019, the canton of Schaffhausen had not concluded its public referendum; however, the enactment did occur during the first quarter of fiscal 2020.

[0000833444-20-000006:notes:101]
During the three months ended December 31, 2019 and 2018, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-20-000006:notes:102]
[same as prior period, unchanged from 0000833444-19-000041:notes:109]

[0000833444-20-000006:notes:103]
In the first quarter of fiscal 2020, the Company recorded $111 million of significant restructuring and impairment costs. Refer to Note 9, “Significant Restructuring and Impairment Costs,” of the notes to consolidated financial statements for additional information. The restructuring costs generated a $16 million tax benefit, which reflects the Company’s current tax position in the impacted jurisdictions.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-20-000006:notes:104]
[same as prior period, unchanged from 0000833444-19-000041:notes:114]

[0000833444-20-000006:notes:105]
[same as prior period, unchanged from 0000833444-19-000041:notes:115]

[0000833444-20-000006:notes:106]
|  | U.S. Pension Plans |
|  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Interest cost | $ | 18 |  |  | $ | 25 |  |
| Expected return on plan assets | (44 | ) |  | (46 | ) |
| Net periodic benefit credit | $ | (26 | ) |  | $ | (21 | ) |

[0000833444-20-000006:notes:107]
|  | Non-U.S. Pension Plans |
|  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Service cost | $ | 6 |  |  | $ | 5 |  |
| Interest cost | 9 |  |  | 14 |  |
| Expected return on plan assets | (27 | ) |  | (27 | ) |
| Net periodic benefit credit | $ | (12 | ) |  | $ | (8 | ) |

[0000833444-20-000006:notes:108]
|  | Postretirement Benefits |
|  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Interest cost | $ | 1 |  |  | $ | 2 |  |
| Expected return on plan assets | (2 | ) |  | (2 | ) |
| Amortization of prior service credit | (1 | ) |  | — |  |
| Net periodic benefit credit | $ | (2 | ) |  | $ | — |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-20-000006:notes:109]
Debt and Financing Arrangements

[0000833444-20-000006:notes:110]
Net Financing Charges

[0000833444-20-000006:notes:111]
The Company's net financing charges line item in the consolidated statements of income for the three months ended December 31, 2019 and 2018 contained the following components (in millions):

[0000833444-20-000006:notes:112]
|  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Interest expense, net of capitalized interest costs | $ | 62 |  |  | $ | 91 |  |
| Banking fees and bond cost amortization | 5 |  |  | 6 |  |
| Interest income | (13 | ) |  | (7 | ) |
| Net foreign exchange results for financing activities | (2 | ) |  | (5 | ) |
| Net financing charges | $ | 52 |  |  | $ | 85 |  |

[0000833444-20-000006:notes:113]
In December 2019, the Company entered into a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2020.  As of December 31, 2019, there were no draws on the facilities.

[0000833444-20-000006:notes:114]
In December 2019, the Company terminated its syndicated 5-year $2 billion committed revolving credit facility and four 364-day revolving credit facilities with total committed capacity of $750 million.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-20-000006:notes:115]
[same as prior period, unchanged from 0000833444-19-000041:notes:133]

[0000833444-20-000006:notes:116]
On September 2, 2016, the shareholders of the Company approved amendments to the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based compensation awards. The Compensation Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter. A summary of the stock-based awards granted during the three month periods ended December 31, 2019 and 2018 is presented below:

[0000833444-20-000006:notes:117]
|  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  | Number Granted |  | Weighted Average Grant Date Fair Value |
| Stock options | 1,302,729 |  |  | $ | 7.29 |  |  | 1,713,733 |  |  | $ | 5.56 |  |
| Restricted stock/units | 1,695,130 |  |  | 41.78 |  |  | 2,143,457 |  |  | 33.39 |  |
| Performance shares | 464,234 |  |  | 42.53 |  |  | 574,716 |  |  | 36.28 |  |

[0000833444-20-000006:notes:118]
[same as prior period, unchanged from 0000833444-19-000041:notes:136]

[0000833444-20-000006:notes:119]
[same as prior period, unchanged from 0000833444-19-000041:notes:137]

[0000833444-20-000006:notes:120]
The fair value of each option is estimated on the date of grant using a Black-Scholes option valuation model that uses the assumptions noted in the following table. The expected life of options represents the period of time that options granted are expected to be outstanding, assessed separately for executives and non-executives. The risk-free interest rate for periods during the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant. The expected volatility is based on the historical volatility of the Company’s stock since October 2016 blended with the historical volatility of certain peer companies’ stock prior to October 2016 over the most recent period corresponding to the expected life as of the grant date. The expected dividend yield is based on the expected annual dividend as a percentage of the market value of the Company’s ordinary shares as of the grant date. The Company uses historical data to estimate option exercises and employee terminations within the valuation model.

[0000833444-20-000006:notes:121]
|  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Expected life of option (years) | 6.5 |  | 6.4 |
| Risk-free interest rate | 1.67% |  | 2.77% |
| Expected volatility of the Company’s stock | 22.4% |  | 21.8% |
| Expected dividend yield on the Company’s stock | 2.49% |  | 3.29% |

[0000833444-20-000006:notes:122]
[same as prior period, unchanged from 0000833444-19-000041:notes:140]

[0000833444-20-000006:notes:123]
[same as prior period, unchanged from 0000833444-19-000041:notes:141]

[0000833444-20-000006:notes:124]
[same as prior period, unchanged from 0000833444-19-000041:notes:142]

[0000833444-20-000006:notes:125]
[same as prior period, unchanged from 0000833444-19-000041:notes:143]

[0000833444-20-000006:notes:126]
The fair value of each PSU is estimated on the date of grant with the use of a Monte Carlo simulation that uses the assumptions noted in the following table. The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant. For fiscal 2020, the expected volatility is based on the historical volatility of the Company's stock over the most recent three-year period as of the grant date. For fiscal 2019, the expected volatility is based on the historical volatility of the Company’s stock since October 2016 blended with the historical volatility of certain peer companies’ stock prior to October 2016 over the most recent three-year period as of the grant date.

[0000833444-20-000006:notes:127]
|  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Risk-free interest rate | 1.60% |  | 2.76% |
| Expected volatility of the Company’s stock | 21.8% |  | 22.9% |


## us-gaap:EarningsPerShareTextBlock

[0000833444-20-000006:notes:128]
[same as prior period, unchanged from 0000833444-19-000041:notes:146]

[0000833444-20-000006:notes:129]
[same as prior period, unchanged from 0000833444-19-000041:notes:147]

[0000833444-20-000006:notes:130]
[same as prior period, unchanged from 0000833444-19-000041:notes:148]

[0000833444-20-000006:notes:131]
|  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Income Available to Ordinary Shareholders |  |  |  |
| Income from continuing operations | $ | 159 |  |  | $ | 107 |  |
| Income from discontinued operations | — |  |  | 248 |  |
| Basic and diluted income available to shareholders | $ | 159 |  |  | $ | 355 |  |
| Weighted Average Shares Outstanding |  |  |  |
| Basic weighted average shares outstanding | 769.9 |  |  | 921.6 |  |
| Effect of dilutive securities: |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 4.1 |  |  | 3.6 |  |
| Diluted weighted average shares outstanding | 774.0 |  |  | 925.2 |  |
| Antidilutive Securities |  |  |  |
| Options to purchase shares | 0.2 |  |  | 2.7 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-20-000006:notes:132]
[same as prior period, unchanged from 0000833444-19-000041:notes:151]

[0000833444-20-000006:notes:133]
[same as prior period, unchanged from 0000833444-19-000041:notes:152]

[0000833444-20-000006:notes:134]
|  | Three Months Ended December 31, 2019 |  | Three Months Ended December 31, 2018 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, September 30, | $ | 19,766 |  |  | $ | 1,063 |  |  | $ | 20,829 |  |  | $ | 21,164 |  |  | $ | 1,294 |  |  | $ | 22,458 |  |
| Total comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 159 |  |  | 32 |  |  | 191 |  |  | 355 |  |  | 44 |  |  | 399 |  |
| Foreign currency translation adjustments | 251 |  |  | 10 |  |  | 261 |  |  | (127 | ) |  | 9 |  |  | (118 | ) |
| Realized and unrealized gains on derivatives | 5 |  |  | 2 |  |  | 7 |  |  | 1 |  |  | 1 |  |  | 2 |  |
| Pension and postretirement plans | (1 | ) |  | — |  |  | (1 | ) |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | 255 |  |  | 12 |  |  | 267 |  |  | (126 | ) |  | 10 |  |  | (116 | ) |
| Comprehensive income | 414 |  |  | 44 |  |  | 458 |  |  | 229 |  |  | 54 |  |  | 283 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (201 | ) |  | — |  |  | (201 | ) |  | (240 | ) |  | — |  |  | (240 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (5 | ) |  | (5 | ) |  | — |  |  | (43 | ) |  | (43 | ) |
| Repurchases and retirements of ordinary shares | (651 | ) |  | — |  |  | (651 | ) |  | (467 | ) |  | — |  |  | (467 | ) |
| Adoption of ASC 606 | — |  |  | — |  |  | — |  |  | (45 | ) |  | — |  |  | (45 | ) |
| Adoption of ASU 2016-16 | — |  |  | — |  |  | — |  |  | (546 | ) |  | — |  |  | (546 | ) |
| Adoption of ASC 842 | (5 | ) |  | — |  |  | (5 | ) |  | — |  |  | — |  |  | — |  |
| Other, including options exercised | 6 |  |  | — |  |  | 6 |  |  | 7 |  |  | — |  |  | 7 |  |
| Ending balance, December 31, | $ | 19,329 |  |  | $ | 1,102 |  |  | $ | 20,431 |  |  | $ | 20,102 |  |  | $ | 1,305 |  |  | $ | 21,407 |  |

[0000833444-20-000006:notes:135]
During the quarter ended December 31, 2018, the Company adopted ASC 606, "Revenue from Contracts with Customers." As a result, the Company recorded $45 million to beginning retained earnings, which relates primarily to deferred revenue recorded for the Power Solutions business for certain battery core returns that represent a material right provided to customers.

[0000833444-20-000006:notes:136]
During the quarter ended December 31, 2018, the Company adopted ASU 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory." As a result, the Company recognized deferred taxes of $546 million related to the tax effects of all intra-entity sales of assets other than inventory on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2018.

[0000833444-20-000006:notes:137]
For the three months ended December 31, 2019, the Company repurchased and retired $651 million of its ordinary shares. For the three months ended December 31, 2018, the Company repurchased $467 million of its ordinary shares, which were retired in the fourth quarter of fiscal 2019. As of December 31, 2019, approximately $3.9 billion remains available under the share repurchase program.

[0000833444-20-000006:notes:138]
[same as prior period, unchanged from 0000833444-19-000041:notes:166]

[0000833444-20-000006:notes:139]
|  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Foreign currency translation adjustments ("CTA") |  |  |  |
| Balance at beginning of period | $ | (785 | ) |  | $ | (939 | ) |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | 251 |  |  | (127 | ) |
| Balance at end of period | (534 | ) |  | (1,066 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (2 | ) |  | (13 | ) |
| Current period changes in fair value (net of tax effect of $2 and $(2)) | 5 |  |  | (4 | ) |
| Reclassification to income (net of tax effect of $0 and $1) * | — |  |  | 5 |  |
| Balance at end of period | 3 |  |  | (12 | ) |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | — |  |  | 8 |  |
| Adoption of ASU 2016-01** | — |  |  | (8 | ) |
| Balance at end of period | — |  |  | — |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (8 | ) |  | (2 | ) |
| Reclassification to income (net of tax effect of $0 and $0) | (1 | ) |  | — |  |
| Balance at end of period | (9 | ) |  | (2 | ) |
| Accumulated other comprehensive loss, end of period | $ | (540 | ) |  | $ | (1,080 | ) |

[0000833444-20-000006:notes:140]
* Refer to Note 16, "Derivative Instruments and Hedging Activities," of the notes to consolidated financial statements for

[0000833444-20-000006:notes:141]
disclosure of the line items in the consolidated statements of income affected by reclassifications from AOCI into income

[0000833444-20-000006:notes:142]
related to derivatives.

[0000833444-20-000006:notes:143]
** During the quarter ended December 31, 2018, the Company adopted ASU 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." As a result, the Company reclassified $8 million of unrealized gains on marketable securities to retained earnings as of October 1, 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-20-000006:notes:144]
[same as prior period, unchanged from 0000833444-19-000041:notes:173]

[0000833444-20-000006:notes:145]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, stock-based compensation liabilities and interest rates. Under Company policy, the use of derivatives is restricted to those intended for hedging purposes; the use of any derivative instrument for speculative purposes is strictly prohibited. A description of each type of derivative utilized by the Company to manage risk is included in the following paragraphs. In addition, refer to Note 17, "Fair Value Measurements," of the notes to consolidated financial statements for information related to the fair value measurements and valuation methods utilized by the Company for each derivative type.

[0000833444-20-000006:notes:146]
[same as prior period, unchanged from 0000833444-19-000041:notes:175]

[0000833444-20-000006:notes:147]
The Company has global operations and participates in the foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures.

[0000833444-20-000006:notes:148]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of copper and aluminum in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-20-000006:notes:149]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three months ended December 31, 2019 and 2018.

[0000833444-20-000006:notes:150]
The Company had the following outstanding contracts to hedge forecasted commodity purchases (in metric tons):

[0000833444-20-000006:notes:151]
|  |  | Volume Outstanding as of |
| Commodity |  | December 31, 2019 |  | September 30, 2019 |
| Copper |  | 3,447 |  |  | 3,561 |  |
| Aluminum |  | 2,691 |  |  | 2,967 |  |

[0000833444-20-000006:notes:152]
[same as prior period, unchanged from 0000833444-19-000041:notes:180]

[0000833444-20-000006:notes:153]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company’s net investments globally. At December 31, 2019 and September 30, 2019, the Company had 888 million euro, 750 million euro, 423 million euro and 54 million euro in bonds designated as net investment hedges in the Company's net investment in Europe and 25 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan.

[0000833444-20-000006:notes:154]
[same as prior period, unchanged from 0000833444-19-000041:notes:182]

[0000833444-20-000006:notes:155]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount.  As of December 31, 2019, the Company hedged approximately 1.4 million shares of its ordinary shares, which have a cost basis of $60 million. As of September 30, 2019, the Company hedged approximately 1.4 million shares of its ordinary shares, which have a cost basis of $60 million.

[0000833444-20-000006:notes:156]
The Company also holds certain foreign currency forward contracts for which hedge accounting treatment was not elected. The change in fair value of foreign currency exchange derivatives not designated as hedging instruments under ASC 815 are recorded in the consolidated statements of income.

[0000833444-20-000006:notes:157]
[same as prior period, unchanged from 0000833444-19-000041:notes:185]

[0000833444-20-000006:notes:158]
[same as prior period, unchanged from 0000833444-19-000041:notes:186]

[0000833444-20-000006:notes:159]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | December 31, |  | September 30, |  | December 31, |  | September 30, |
|  | 2019 |  | 2019 |  | 2019 |  | 2019 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 10 |  |  | $ | 16 |  |  | $ | 37 |  |  | $ | 19 |  |
| Commodity derivatives | 1 |  |  | — |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 58 |  |  | 62 |  |
| Total assets | $ | 11 |  |  | $ | 16 |  |  | $ | 95 |  |  | $ | 81 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 8 |  |  | $ | 23 |  |  | $ | 1 |  |  | $ | — |  |
| Commodity derivatives | — |  |  | 1 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 2,602 |  |  | 2,544 |  |  | — |  |  | — |  |
| Total liabilities | $ | 2,610 |  |  | $ | 2,568 |  |  | $ | 1 |  |  | $ | — |  |

[0000833444-20-000006:notes:160]
[same as prior period, unchanged from 0000833444-19-000041:notes:188]

[0000833444-20-000006:notes:161]
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with substantially all of its counterparties. The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position.

[0000833444-20-000006:notes:162]
The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-20-000006:notes:163]
[same as prior period, unchanged from 0000833444-19-000041:notes:192]

[0000833444-20-000006:notes:164]
|  |  | Fair Value of Assets |  | Fair Value of Liabilities |
|  |  | December 31, |  | September 30, |  | December 31, |  | September 30, |
|  |  | 2019 |  | 2019 |  | 2019 |  | 2019 |
| Gross amount recognized |  | $ | 106 |  |  | $ | 97 |  |  | $ | 2,611 |  |  | $ | 2,568 |  |
| Gross amount eligible for offsetting |  | (7 | ) |  | (11 | ) |  | (7 | ) |  | (11 | ) |
| Net amount |  | $ | 99 |  |  | $ | 86 |  |  | $ | 2,604 |  |  | $ | 2,557 |  |

[0000833444-20-000006:notes:165]
[same as prior period, unchanged from 0000833444-19-000041:notes:194]

[0000833444-20-000006:notes:166]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the three months ended December 31, 2019 and 2018 (in millions):

[0000833444-20-000006:notes:167]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Foreign currency exchange derivatives |  | $ | 9 |  |  | $ | — |  |
| Commodity derivatives |  | 1 |  |  | (6 | ) |
| Total |  | $ | 10 |  |  | $ | (6 | ) |

[0000833444-20-000006:notes:168]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the three months ended December 31, 2019 and 2018 (in millions):

[0000833444-20-000006:notes:169]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 1 |  |  | $ | — |  |
| Foreign currency exchange derivatives |  | Income from discontinued operations |  | — |  |  | 1 |  |
| Commodity derivatives |  | Cost of sales |  | (1 | ) |  | (2 | ) |
| Commodity derivatives |  | Income from discontinued operations |  | — |  |  | (5 | ) |
| Total |  |  |  | $ | — |  |  | $ | (6 | ) |

[0000833444-20-000006:notes:170]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the three months ended December 31, 2019 and 2018 (in millions):

[0000833444-20-000006:notes:171]
|  |  |  |  | Amount of Gain (Loss) Recognized inIncome on Derivative |
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | — |  |  | $ | (4 | ) |
| Foreign currency exchange derivatives |  | Net financing charges |  | 59 |  |  | (21 | ) |
| Foreign currency exchange derivatives |  | Income from discontinued operations |  | — |  |  | 26 |  |
| Equity swap |  | Selling, general and administrative |  | (4 | ) |  | (9 | ) |
| Total |  |  |  | $ | 55 |  |  | $ | (8 | ) |

[0000833444-20-000006:notes:172]
The pre-tax gains (losses) on net investment hedges recorded in CTA within other comprehensive income (loss) were $(58) million and $34 million for the three months ended December 31, 2019 and 2018, respectively. For the three months ended December 31, 2019 and 2018, no gains or losses were reclassified from CTA into income.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-20-000006:notes:173]
[same as prior period, unchanged from 0000833444-19-000041:notes:202]

[0000833444-20-000006:notes:174]
[same as prior period, unchanged from 0000833444-19-000041:notes:203]

[0000833444-20-000006:notes:175]
[same as prior period, unchanged from 0000833444-19-000041:notes:204]

[0000833444-20-000006:notes:176]
[same as prior period, unchanged from 0000833444-19-000041:notes:205]

[0000833444-20-000006:notes:177]
[same as prior period, unchanged from 0000833444-19-000041:notes:206]

[0000833444-20-000006:notes:178]
[same as prior period, unchanged from 0000833444-19-000041:notes:207]

[0000833444-20-000006:notes:179]
[same as prior period, unchanged from 0000833444-19-000041:notes:208]

[0000833444-20-000006:notes:180]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of December 31, 2019 and September 30, 2019 (in millions):

[0000833444-20-000006:notes:181]
|  | Fair Value Measurements Using: |
|  | Total as of December 31, 2019 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 47 |  |  | $ | — |  |  | $ | 47 |  |  | $ | — |  |
| Exchange traded funds (fixed income)1 | 38 |  |  | 38 |  |  | — |  |  | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 75 |  |  | 75 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 119 |  |  | 119 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 125 |  |  | 125 |  |  | — |  |  | — |  |
| Equity swap | 58 |  |  | — |  |  | 58 |  |  | — |  |
| Total assets | $ | 463 |  |  | $ | 357 |  |  | $ | 106 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |  | $ | — |  |
| Total liabilities | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |  | $ | — |  |

[0000833444-20-000006:notes:182]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2019 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 35 |  |  | $ | — |  |  | $ | 35 |  |  | $ | — |  |
| Exchange traded funds (fixed income)1 | 19 |  |  | 19 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 71 |  |  | 71 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 138 |  |  | 138 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 116 |  |  | 116 |  |  | — |  |  | — |  |
| Equity swap | 62 |  |  | — |  |  | 62 |  |  | — |  |
| Total assets | $ | 441 |  |  | $ | 344 |  |  | $ | 97 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Total liabilities | $ | 24 |  |  | $ | — |  |  | $ | 24 |  |  | $ | — |  |

[0000833444-20-000006:notes:183]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements for further details.

[0000833444-20-000006:notes:184]
[same as prior period, unchanged from 0000833444-19-000041:notes:213]

[0000833444-20-000006:notes:185]
[same as prior period, unchanged from 0000833444-19-000041:notes:214]

[0000833444-20-000006:notes:186]
[same as prior period, unchanged from 0000833444-19-000041:notes:215]

[0000833444-20-000006:notes:187]
[same as prior period, unchanged from 0000833444-19-000041:notes:216]

[0000833444-20-000006:notes:188]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. During the three months ended December 31, 2019 and 2018, the Company recognized unrealized losses of $3 million and $9 million, respectively, in the consolidated statements of income on these investments that were still held as of December 31, 2019 and 2018, where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-20-000006:notes:189]
Investments in marketable common stock and exchange traded funds:  Investments in marketable common stock and exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. During the three months ended December 31, 2019, the Company recognized unrealized gains of $10 million in the consolidated statements of income on these investments that were still held as of December 31, 2019, all of which related to restricted investments. During the three months ended December 31, 2018, the Company recognized unrealized losses of $22 million in the consolidated statements of income on these investments that were still held as of December 31, 2018, of which $21 million related to restricted investments. Refer to Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-20-000006:notes:190]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. At both December 31, 2019 and September 30, 2019, the fair value of long-term debt was $7.6 billion, including public debt of $7.4 billion, which was determined primarily using market quotes classified as Level 1 inputs within the ASC 820 fair value hierarchy and other long-term debt of $0.2 billion, which was determined based on quoted market prices for similar instruments classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0000833444-20-000006:notes:191]
[same as prior period, unchanged from 0000833444-19-000041:notes:221]

[0000833444-20-000006:notes:192]
The Company reviews long-lived assets, including right-of-use assets under operating leases, other tangible assets and intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of software to be sold, leased, or marketed."  ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 350-30 requires intangible assets acquired in a business combination that are used in research and development activities to be considered indefinite lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they shall not be amortized but shall be tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired.  If the carrying amount of an intangible asset exceeds its fair value, an entity shall recognize an impairment loss in an amount equal to that excess. ASC 985-20 requires the unamortized capitalized costs of a computer software product

[0000833444-20-000006:notes:193]
be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off.

[0000833444-20-000006:notes:194]
During the third quarter of fiscal 2019, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with the plans to dispose of a business within its Global Products segment that met the criteria to be classified as held for sale. Assets and liabilities held for sale are required to be recorded at the lower of carrying value or fair value less any costs to sell. The Company recorded an initial impairment charge of $235 million within restructuring and impairment costs in the consolidated statements of income in the third quarter of fiscal 2019 to write down the carrying value of the assets held for sale to fair value less any costs to sell. In the first quarter of fiscal 2020, the Company recorded an additional impairment charge of $15 million to further write down the carrying value of the assets held for sale to the current fair value less any costs to sell. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-20-000006:notes:195]
In the first quarter of fiscal 2020, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2020. As a result, the Company reviewed the long-lived assets for impairment and recorded $39 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $33 million related to the Global Products segment and $6 million related to the Building Solutions North America segment. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-20-000006:notes:196]
At December 31, 2019 and 2018, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-20-000006:notes:197]
[same as prior period, unchanged from 0000833444-19-000041:notes:226]

[0000833444-20-000006:notes:198]
[same as prior period, unchanged from 0000833444-19-000041:notes:227]

[0000833444-20-000006:notes:199]
[same as prior period, unchanged from 0000833444-19-000041:notes:228]

[0000833444-20-000006:notes:200]
[same as prior period, unchanged from 0000833444-19-000041:notes:229]

[0000833444-20-000006:notes:201]
[same as prior period, unchanged from 0000833444-19-000041:notes:230]

[0000833444-20-000006:notes:202]
[same as prior period, unchanged from 0000833444-19-000041:notes:231]

[0000833444-20-000006:notes:203]
[same as prior period, unchanged from 0000833444-19-000041:notes:234]

[0000833444-20-000006:notes:204]
[same as prior period, unchanged from 0000833444-19-000041:notes:235]

[0000833444-20-000006:notes:205]
|  | Net Sales |
|  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Building Solutions North America | $ | 2,167 |  |  | $ | 2,116 |  |
| Building Solutions EMEA/LA | 928 |  |  | 907 |  |
| Building Solutions Asia Pacific | 629 |  |  | 613 |  |
| Global Products | 1,852 |  |  | 1,828 |  |
| Total net sales | $ | 5,576 |  |  | $ | 5,464 |  |

[0000833444-20-000006:notes:206]
|  | Segment EBITA |
|  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Building Solutions North America | $ | 258 |  |  | $ | 250 |  |
| Building Solutions EMEA/LA | 90 |  |  | 77 |  |
| Building Solutions Asia Pacific | 72 |  |  | 66 |  |
| Global Products | 203 |  |  | 190 |  |
| Total segment EBITA | $ | 623 |  |  | $ | 583 |  |
| Corporate expenses | $ | (118 | ) |  | $ | (136 | ) |
| Amortization of intangible assets | (96 | ) |  | (97 | ) |
| Restructuring and impairment costs | (111 | ) |  | — |  |
| Net mark-to-market adjustments | 10 |  |  | (21 | ) |
| Net financing charges | (52 | ) |  | (85 | ) |
| Income from continuing operations before income taxes | $ | 256 |  |  | $ | 244 |  |


## us-gaap:GuaranteesTextBlock

[0000833444-20-000006:notes:207]
[same as prior period, unchanged from 0000833444-19-000041:notes:238]

[0000833444-20-000006:notes:208]
[same as prior period, unchanged from 0000833444-19-000041:notes:239]

[0000833444-20-000006:notes:209]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate for future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are

[0000833444-20-000006:notes:210]
adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-20-000006:notes:211]
[same as prior period, unchanged from 0000833444-19-000041:notes:241]

[0000833444-20-000006:notes:212]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations, including extended warranties for which deferred revenue is recorded, for the three months ended December 31, 2019 and 2018 were as follows (in millions):

[0000833444-20-000006:notes:213]
|  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Balance at beginning of period | $ | 285 |  |  | $ | 315 |  |
| Accruals for warranties issued during the period | 23 |  |  | 29 |  |
| Accruals from acquisition and divestitures | 1 |  |  | — |  |
| Accruals related to pre-existing warranties | (2 | ) |  | (5 | ) |
| Settlements made (in cash or in kind) during the period | (21 | ) |  | (30 | ) |
| Currency translation | 1 |  |  | 1 |  |
| Balance at end of period | $ | 287 |  |  | $ | 310 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-20-000006:notes:214]
Commitments and Contingencies

[0000833444-20-000006:notes:215]
Environmental Matters

[0000833444-20-000006:notes:216]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of December 31, 2019, reserves for environmental liabilities for continuing operations totaled $151 million, of which $51 million was recorded within other current liabilities and $100 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $159 million at September 30, 2019, of which $52 million was recorded within other current liabilities and $107 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

[0000833444-20-000006:notes:217]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin.  In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.

[0000833444-20-000006:notes:218]
During the third quarter of 2019, the Company increased its environmental reserves which included $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).  The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.

[0000833444-20-000006:notes:219]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in

[0000833444-20-000006:notes:220]
the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

[0000833444-20-000006:notes:221]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS.  The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion.  On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation.

[0000833444-20-000006:notes:222]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers.  Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter.  The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).”  The WDNR issued a further letter regarding the issue on November 4, 2019.  Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations.  The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

[0000833444-20-000006:notes:223]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990.  Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River.  In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts.

[0000833444-20-000006:notes:224]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At December 31, 2019 and September 30, 2019, the Company recorded conditional asset retirement obligations for continuing operations of $31 million and $30 million, respectively.

[0000833444-20-000006:notes:225]
Asbestos Matters

[0000833444-20-000006:notes:226]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-20-000006:notes:227]
As of December 31, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $132 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $502 million, of which $50 million was recorded in other current liabilities and $452 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $370 million, of which $42 million was recorded in other current assets, and $328 million was recorded in other noncurrent assets. Assets included $12 million of cash and $282 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at December 31, 2019 was $76 million. As of September 30, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $141 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $507 million, of which $50 million was recorded in other current liabilities and $457 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $366 million, of which $46 million was recorded in other current assets, and $320 million was recorded in other noncurrent assets. Assets included $16 million of cash and $273 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2019 was $77 million.

[0000833444-20-000006:notes:228]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-20-000006:notes:229]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be

[0000833444-20-000006:notes:230]
significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-20-000006:notes:231]
Insurable Liabilities

[0000833444-20-000006:notes:232]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At December 31, 2019 and September 30, 2019, the insurable liabilities totaled $378 million and $379 million, respectively, of which $101 million and $99 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $255 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at December 31, 2019 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2019 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-20-000006:notes:233]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-20-000006:notes:234]
Two of our subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but has stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

[0000833444-20-000006:notes:235]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-20-000006:notes:236]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to the MDL.

[0000833444-20-000006:notes:237]
AFFF Putative Class Actions

[0000833444-20-000006:notes:238]
Chemguard and Tyco Fire Products are named in 24 putative class actions in federal and state courts in Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington New Hampshire, Guam, and Michigan. Each of these cases has been transferred to the MDL. The following putative class actions were filed since the beginning of fiscal year 2020:

[0000833444-20-000006:notes:239]
| • | Aguon et al. v. The 3M Company et al., filed October 3, 2019, in the United States District Court, District of Guam. |

[0000833444-20-000006:notes:240]
AFFF Individual or Mass Actions

[0000833444-20-000006:notes:241]
There are approximately 152 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases), Pennsylvania (11 cases), New Mexico (2 cases) and South Carolina (94 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania, two plaintiffs in New Mexico, and approximately 100 plaintiffs from various states who direct-filed complaints in South Carolina.  These matters have been transferred to or directly-filed in the MDL.  The Company is also on notice of approximately 660 other possible individual product liability claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters in Pennsylvania.  Some of the individuals who filed claims in Pennsylvania state court filed individual complaints in the MDL in South Carolina (and dismissed their claims in Pennsylvania state court), and the Company anticipates that the rest will soon be filed in the MDL.

[0000833444-20-000006:notes:242]
AFFF Municipal Cases

[0000833444-20-000006:notes:243]
Chemguard and Tyco Fire Products are also defendants in 37 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, California, Colorado, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio, Pennsylvania, and South Carolina.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  All of these cases but one have been transferred to the MDL. The following municipal actions were filed since the beginning of fiscal year 2020:

[0000833444-20-000006:notes:244]
| • | California Water Service Co. v. The 3M Company et al., direct-filed on October 14, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-20-000006:notes:245]
| • | Town of Ayer v. The 3M Company et al., direct-filed on November 4, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-20-000006:notes:246]
| • | Town of Maysville v. The 3M Company et al., direct-filed on December 10, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-20-000006:notes:247]
| • | Town of Grantsville v. The 3M Company et al., filed November 26, 2019, in the United States District Court, District of Maryland. |

[0000833444-20-000006:notes:248]
| • | Town of Mountain Lake Park v. The 3M Company et al., filed November 26, 2019, in the United States District Court, District of Maryland. |

[0000833444-20-000006:notes:249]
| • | Sanford Airport Authority v. The 3M Company et al., filed November 19, 2019, in circuit court in Seminole County, Florida, and removed to the United States District Court, Middle District of Florida. It has been tagged for transfer to the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-20-000006:notes:250]
| • | South Adams County Water & Sanitation District v. The 3M Company et al., filed December 20, 2019, in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-20-000006:notes:251]
| • | Town of Southampton v. The 3M Company et al., filed December 17, 2019, in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-20-000006:notes:252]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base.

[0000833444-20-000006:notes:253]
State Attorneys General Litigation related to AFFF

[0000833444-20-000006:notes:254]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al., No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-20-000006:notes:255]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-20-000006:notes:256]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752 -000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio.  The lawsuit seeks to recover costs and natural resource damages associated with the contamination.  This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-20-000006:notes:257]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

[0000833444-20-000006:notes:258]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

[0000833444-20-000006:notes:259]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Group, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and tagged for transfer to the MDL.

[0000833444-20-000006:notes:260]
AFFF Matters Related to the Tyco Fire Products Fire Technology Center in Marinette, Wisconsin

[0000833444-20-000006:notes:261]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.

[0000833444-20-000006:notes:262]
The Company is vigorously defending the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but

[0000833444-20-000006:notes:263]
there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

[0000833444-20-000006:notes:264]
Bosch Litigation

[0000833444-20-000006:notes:265]
On March 15, 2019, a German subsidiary of the Company received a complaint from Robert Bosch GmbH (“Bosch”), filed in a German court. The complaint relates to an automotive starter batteries joint venture in which the Company and Bosch were 80/20 parties to this joint venture. At the time the complaint was filed, JCI’s ownership interest in the joint venture was to be transferred to entities controlled by the Purchaser upon consummation of the previously announced sale of the Company’s Power Solutions business.

[0000833444-20-000006:notes:266]
The complaint alleged that certain internal Company reorganization transactions were not in compliance with the arrangements relating to such joint venture. The complaint sought a declaration that such internal reorganization transactions are void or, in the alternative, a declaration of damages that represent an alleged difference between (i) the value ascribed to the joint venture interests in connection with the Power Solutions sale and (ii) the value that was assigned to those interests in connection with such internal reorganization transactions.

[0000833444-20-000006:notes:267]
On August 8, 2019, Bosch entered into an agreement with Purchaser pursuant to which Purchaser would purchase Bosch’s interest in the joint venture.  Simultaneously with this agreement, the Company and Bosch executed an agreement to dismiss the proceedings between the parties upon the completion of Purchaser’s acquisition of Bosch’s interest. In the first quarter of fiscal 2020, following the completion of Purchaser’s acquisition of Bosch’s interest in the joint venture, the Company and Bosch made filings with the German court terminating the litigation.

[0000833444-20-000006:notes:268]
Pursuant to the Company’s obligations to Purchaser in connection with the divestiture of the Company’s Power Solutions business, the Company reimbursed Purchaser a portion of its costs in connection with its acquisition of Bosch’s interests in the joint venture, which is reflected as a cash outflow for discontinued operations.

[0000833444-20-000006:notes:269]
Other Matters

[0000833444-20-000006:notes:270]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-20-000006:notes:271]
Related Party Transactions

[0000833444-20-000006:notes:272]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-20-000006:notes:273]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $45 million and $12 million, respectively, for the three months ended December 31, 2019; and $43 million and $14 million, respectively, for the three months ended December 31, 2018.

[0000833444-20-000006:notes:274]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position for continuing operations (in millions):

[0000833444-20-000006:notes:275]
|  |  | December 31, 2019 |  | September 30, 2019 |  |
| Receivable from related parties |  | $ | 29 |  |  | $ | 34 |  |
| Payable to related parties |  | 6 |  |  | 6 |  |
