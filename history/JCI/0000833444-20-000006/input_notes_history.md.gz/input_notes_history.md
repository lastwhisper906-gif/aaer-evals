# JCI note change history — 0000833444-19-000041 → 0000833444-20-000006


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-01-31):
[0000833444-20-000006:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of December 31, 2019, reserves for environmental liabilities for continuing operations totaled $151 million, of which $51 million was recorded within other current liabilities and $100 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $159 million at September 30, 2019, of which $52 million was recorded within other current liabilities and $107 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.
  (was, 2019-08-01, similarity 0.9919):
[0000833444-19-000041:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of June 30, 2019, reserves for environmental liabilities for continuing operations totaled $163 million, of which $52 million was recorded within other current liabilities and $111 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $37 million at September 30, 2018, of which $10 million was recorded within other current liabilities and $27 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

- changed (2020-01-31):
[0000833444-20-000006:note_history:2]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin.  In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.
  (was, 2019-08-01, similarity 0.9338):
[0000833444-19-000041:note_history:2]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin.  In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working closely with WDNR to address these issues insofar as they related to this migration.

- changed (2020-01-31):
[0000833444-20-000006:note_history:3]
During the third quarter of 2019, the Company increased its environmental reserves which included $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).  The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.
  (was, 2019-08-01, similarity 0.8791):
[0000833444-19-000041:note_history:3]
The increase in reserves as of June 30, 2019 includes $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).  The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.

- changed (2020-01-31):
[0000833444-20-000006:note_history:4]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in
  (was, 2019-08-01, similarity 0.6684):
[0000833444-19-000041:note_history:4]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure

- changed (2020-01-31):
[0000833444-20-000006:note_history:5]
the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.
  (was, 2019-08-01, similarity 0.6168):
[0000833444-19-000041:note_history:5]
that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

- added (2020-01-31):
[0000833444-20-000006:note_history:6]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS.  The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion.  On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation.

- added (2020-01-31):
[0000833444-20-000006:note_history:7]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers.  Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter.  The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).”  The WDNR issued a further letter regarding the issue on November 4, 2019.  Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations.  The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

- changed (2020-01-31):
[0000833444-20-000006:note_history:8]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At December 31, 2019 and September 30, 2019, the Company recorded conditional asset retirement obligations for continuing operations of $31 million and $30 million, respectively.
  (was, 2019-08-01, similarity 0.9966):
[0000833444-19-000041:note_history:8]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At June 30, 2019 and September 30, 2018, the Company recorded conditional asset retirement obligations for continuing operations of $30 million and $29 million, respectively.

- changed (2020-01-31):
[0000833444-20-000006:note_history:9]
As of December 31, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $132 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $502 million, of which $50 million was recorded in other current liabilities and $452 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $370 million, of which $42 million was recorded in other current assets, and $328 million was recorded in other noncurrent assets. Assets included $12 million of cash and $282 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at December 31, 2019 was $76 million. As of September 30, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $141 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $507 million, of which $50 million was recorded in other current liabilities and $457 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $366 million, of which $46 million was recorded in other current assets, and $320 million was recorded in other noncurrent assets. Assets included $16 million of cash and $273 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2019 was $77 million.
  (was, 2019-08-01, similarity 0.8302):
[0000833444-19-000041:note_history:9]
As of June 30, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $167 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $538 million, of which $55 million was recorded in other current liabilities and $483 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $371 million, of which $49 million was recorded in other current assets, and $322 million was recorded in other noncurrent assets. Assets included $16 million of cash and $272 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at June 30, 2019 was $83 million. As of September 30, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $173 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $550 million, of which $55 million was recorded in other current liabilities and $495 million was recorded in other noncurrent liabilities. The

- changed (2020-01-31):
[0000833444-20-000006:note_history:10]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be
  (was, 2019-08-01, similarity 0.9517):
[0000833444-19-000041:note_history:10]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

- added (2020-01-31):
[0000833444-20-000006:note_history:11]
significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

- changed (2020-01-31):
[0000833444-20-000006:note_history:12]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At December 31, 2019 and September 30, 2019, the insurable liabilities totaled $378 million and $379 million, respectively, of which $101 million and $99 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $255 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at December 31, 2019 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2019 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.
  (was, 2019-08-01, similarity 0.8419):
[0000833444-19-000041:note_history:12]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At June 30, 2019 and September 30, 2018, the insurable liabilities totaled $451 million and $417 million, respectively, of which $118 million and $95 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $311 million and $300 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at June 30, 2019 and September 30, 2018 were $26 million, of which $6 million was recorded within other current assets and $20 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

- added (2020-01-31):
[0000833444-20-000006:note_history:13]
Two of our subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but has stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

- changed (2020-01-31):
[0000833444-20-000006:note_history:14]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.
  (was, 2019-08-01, similarity 0.7304):
[0000833444-19-000041:note_history:14]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

- changed (2020-01-31):
[0000833444-20-000006:note_history:15]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to the MDL.
  (was, 2019-08-01, similarity 0.9575):
[0000833444-19-000041:note_history:15]
In September of 2018, the Company filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to the MDL.

- changed (2020-01-31):
[0000833444-20-000006:note_history:16]
Chemguard and Tyco Fire Products are named in 24 putative class actions in federal and state courts in Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington New Hampshire, Guam, and Michigan. Each of these cases has been transferred to the MDL. The following putative class actions were filed since the beginning of fiscal year 2020:
  (was, 2019-08-01, similarity 0.7273):
[0000833444-19-000041:note_history:16]
Chemguard and Tyco Fire Products are named in 23 putative class actions in federal and state courts in Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington New Hampshire, and Michigan. Each of these cases has been transferred to the MDL. The following putative class actions were filed in fiscal year 2019:

- changed (2020-01-31):
[0000833444-20-000006:note_history:17]
| • | Aguon et al. v. The 3M Company et al., filed October 3, 2019, in the United States District Court, District of Guam. |
  (was, 2019-08-01, similarity 0.9021):
[0000833444-19-000041:note_history:17]
| • | Grubb v. The 3M Company et al., filed October 30, 2018 in the United States District Court, District of Delaware. |

- added (2020-01-31):
[0000833444-20-000006:note_history:18]
There are approximately 152 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases), Pennsylvania (11 cases), New Mexico (2 cases) and South Carolina (94 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania, two plaintiffs in New Mexico, and approximately 100 plaintiffs from various states who direct-filed complaints in South Carolina.  These matters have been transferred to or directly-filed in the MDL.  The Company is also on notice of approximately 660 other possible individual product liability claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters in Pennsylvania.  Some of the individuals who filed claims in Pennsylvania state court filed individual complaints in the MDL in South Carolina (and dismissed their claims in Pennsylvania state court), and the Company anticipates that the rest will soon be filed in the MDL.

- added (2020-01-31):
[0000833444-20-000006:note_history:19]
Chemguard and Tyco Fire Products are also defendants in 37 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, California, Colorado, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio, Pennsylvania, and South Carolina.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  All of these cases but one have been transferred to the MDL. The following municipal actions were filed since the beginning of fiscal year 2020:

- changed (2020-01-31):
[0000833444-20-000006:note_history:20]
| • | California Water Service Co. v. The 3M Company et al., direct-filed on October 14, 2019 in the MDL pending in the United States District Court, District of South Carolina. |
  (was, 2019-08-01, similarity 0.9123):
[0000833444-19-000041:note_history:20]
| • | California-American Water v. The 3M Company et al., direct-filed on June 21, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

- changed (2020-01-31):
[0000833444-20-000006:note_history:21]
| • | Town of Ayer v. The 3M Company et al., direct-filed on November 4, 2019 in the MDL pending in the United States District Court, District of South Carolina. |
  (was, 2019-08-01, similarity 0.9159):
[0000833444-19-000041:note_history:21]
| • | City of Sioux Falls v. The 3M Company et al., direct-filed on June 26, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

- changed (2020-01-31):
[0000833444-20-000006:note_history:22]
| • | Town of Maysville v. The 3M Company et al., direct-filed on December 10, 2019 in the MDL pending in the United States District Court, District of South Carolina. |
  (was, 2019-08-01, similarity 0.8522):
[0000833444-19-000041:note_history:22]
| • | Sioux Falls Regional Airport Authority v. The 3M Company et al., direct-filed on June 28, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

- changed (2020-01-31):
[0000833444-20-000006:note_history:23]
| • | Town of Grantsville v. The 3M Company et al., filed November 26, 2019, in the United States District Court, District of Maryland. |
  (was, 2019-08-01, similarity 0.9213):
[0000833444-19-000041:note_history:23]
| • | Town of Vienna v. The 3M Company et al., filed March 30, 2019 in the United States District Court, District of Maryland. |

- changed (2020-01-31):
[0000833444-20-000006:note_history:24]
| • | Town of Mountain Lake Park v. The 3M Company et al., filed November 26, 2019, in the United States District Court, District of Maryland. |
  (was, 2019-08-01, similarity 0.8321):
[0000833444-19-000041:note_history:24]
| • | City of Fairbanks v. The 3M Company et al., filed April 26, 2019 in the United States District Court, District of Alaska. |

- added (2020-01-31):
[0000833444-20-000006:note_history:25]
| • | Sanford Airport Authority v. The 3M Company et al., filed November 19, 2019, in circuit court in Seminole County, Florida, and removed to the United States District Court, Middle District of Florida. It has been tagged for transfer to the MDL pending in the United States District Court, District of South Carolina. |

- changed (2020-01-31):
[0000833444-20-000006:note_history:26]
| • | South Adams County Water & Sanitation District v. The 3M Company et al., filed December 20, 2019, in the MDL pending in the United States District Court, District of South Carolina. |
  (was, 2019-08-01, similarity 0.7342):
[0000833444-19-000041:note_history:26]
| • | Battisti et al. v. The 3M Company et al., filed December 20, 2018 in the United States District Court, Middle District of Florida. |

- changed (2020-01-31):
[0000833444-20-000006:note_history:27]
| • | Town of Southampton v. The 3M Company et al., filed December 17, 2019, in the MDL pending in the United States District Court, District of South Carolina. |
  (was, 2019-08-01, similarity 0.7832):
[0000833444-19-000041:note_history:27]
| • | City of Dayton v. The 3M Company et al., filed October 3, 2018 in the United States District Court, Southern District of Ohio. |

- changed (2020-01-31):
[0000833444-20-000006:note_history:28]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base.
  (was, 2019-08-01, similarity 0.6072):
[0000833444-19-000041:note_history:28]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base. In addition, three water districts in Pennsylvania, Horsham Water and Sewer Authority, Warminster Municipal Authority, and Warrington Township have filed praecipes for summons against Chemguard and Tyco Fire Products and other AFFF manufacturers relating to alleged PFOS and PFOA contamination.  These praecipes are not active suits, but have the effect of tolling the statute of limitations.

- changed (2020-01-31):
[0000833444-20-000006:note_history:29]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.
  (was, 2019-08-01, similarity 0.7398):
[0000833444-19-000041:note_history:29]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and tagged for transfer to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York.  This third complaint has not been served.

- changed (2020-01-31):
[0000833444-20-000006:note_history:30]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.
  (was, 2019-08-01, similarity 0.7812):
[0000833444-19-000041:note_history:30]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.).  The State of New Jersey action has been removed to the United State District Court for the District of New Jersey and tagged for transfer to the MDL.  The State of Vermont and State of New Hampshire actions were recently served.

- added (2020-01-31):
[0000833444-20-000006:note_history:31]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

- added (2020-01-31):
[0000833444-20-000006:note_history:32]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Group, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and tagged for transfer to the MDL.

- changed (2020-01-31):
[0000833444-20-000006:note_history:33]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.
  (was, 2019-08-01, similarity 0.9922):
[0000833444-19-000041:note_history:33]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFOA/PFOS contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.

- changed (2020-01-31):
[0000833444-20-000006:note_history:34]
The Company is vigorously defending the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but
  (was, 2019-08-01, similarity 0.8463):
[0000833444-19-000041:note_history:34]
The Company is vigorously defending the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

- added (2020-01-31):
[0000833444-20-000006:note_history:35]
there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

- changed (2020-01-31):
[0000833444-20-000006:note_history:36]
The complaint alleged that certain internal Company reorganization transactions were not in compliance with the arrangements relating to such joint venture. The complaint sought a declaration that such internal reorganization transactions are void or, in the alternative, a declaration of damages that represent an alleged difference between (i) the value ascribed to the joint venture interests in connection with the Power Solutions sale and (ii) the value that was assigned to those interests in connection with such internal reorganization transactions.
  (was, 2019-08-01, similarity 0.6499):
[0000833444-19-000041:note_history:36]
The complaint alleges that certain internal Company reorganization transactions were not in compliance with the arrangements relating to such joint venture. The complaint seeks a declaration that such internal reorganization transactions are void. In the alternative, the complaint seeks a declaration of damages that represent an alleged difference between (i) the value ascribed to the joint venture interests in connection with the Power Solutions sale and (ii) the value that was assigned to those interests in connection with such internal reorganization transactions. The Company believes that it has several strong defenses to the substance of the complaint and that the complaint substantially overstates any reasonable valuation of the joint venture interests. The Company does not believe the complaint has merit, and intends to defend it vigorously. While litigation is inherently uncertain, the Company believes that any ultimate liability that may arise from this proceeding would be immaterial to its business, financial condition and results of operations.

- added (2020-01-31):
[0000833444-20-000006:note_history:37]
On August 8, 2019, Bosch entered into an agreement with Purchaser pursuant to which Purchaser would purchase Bosch’s interest in the joint venture.  Simultaneously with this agreement, the Company and Bosch executed an agreement to dismiss the proceedings between the parties upon the completion of Purchaser’s acquisition of Bosch’s interest. In the first quarter of fiscal 2020, following the completion of Purchaser’s acquisition of Bosch’s interest in the joint venture, the Company and Bosch made filings with the German court terminating the litigation.

- added (2020-01-31):
[0000833444-20-000006:note_history:38]
Pursuant to the Company’s obligations to Purchaser in connection with the divestiture of the Company’s Power Solutions business, the Company reimbursed Purchaser a portion of its costs in connection with its acquisition of Bosch’s interests in the joint venture, which is reflected as a cash outflow for discontinued operations.

- removed (2020-01-31):
[0000833444-19-000041:note_history:39]
Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $33 million was recorded in other current assets, and $344 million was recorded in other noncurrent assets. Assets included $6 million of cash and $281 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2018 was $90 million.

- removed (2020-01-31):
[0000833444-19-000041:note_history:40]
Two of our subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the

- removed (2020-01-31):
[0000833444-19-000041:note_history:41]
firefighting foam products manufactured by defendants contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued regulatory limits, however; while those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

- removed (2020-01-31):
[0000833444-19-000041:note_history:42]
| • | County of Dutchess v. The 3M Company et al., filed October 12, 2018 in the United States District Court, Southern District of New York. |

- removed (2020-01-31):
[0000833444-19-000041:note_history:43]
| • | Jackson et al. v. The 3M Company et al., filed February 5, 2019 in the United States District Court, Western District of Washington. |

- removed (2020-01-31):
[0000833444-19-000041:note_history:44]
| • | Smith et al. v. The 3M Company et al., filed May 24, 2019 in the United States District Court, District of New Hampshire. |

- removed (2020-01-31):
[0000833444-19-000041:note_history:45]
| • | Cadrette et al. v. The 3M Company et al., filed May 24, 2019 in the United States District Court, Eastern District of Michigan. |

- removed (2020-01-31):
[0000833444-19-000041:note_history:46]
There are approximately 60 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases), Pennsylvania (11 cases), New Mexico (2 cases) and South Carolina (2 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania and two plaintiffs in New Mexico.  These matters have been transferred to or directly-filed in the MDL.  The Company is also on notice of approximately 660 other possible individual product liability claims and three possible municipal claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, but the Company anticipates that they soon will be.

- removed (2020-01-31):
[0000833444-19-000041:note_history:47]
Chemguard and Tyco Fire Products are also defendants in 23 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio and South Carolina.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  All of these cases have been transferred to the MDL. The following municipal actions were filed in fiscal year 2019:

- removed (2020-01-31):
[0000833444-19-000041:note_history:48]
| • | Dutchess County v. The 3M Company et al. filed October 12, 2018 (removed to the United States District Court, Southern District of New York) and styled as a class action. |

- removed (2020-01-31):
[0000833444-19-000041:note_history:49]
| • | City of Stuart v. The 3M Company et al., filed October 18, 2018 in the United States District Court, Southern District of Florida. |

- removed (2020-01-31):
[0000833444-19-000041:note_history:50]
| • | City of Tucson and Town of Marana v. The 3M Company et al., filed November 8, 2018 in the Superior Court of the State of Arizona, County of Pima (removed to the United States District Court for the District of Arizona). |

- removed (2020-01-31):
[0000833444-19-000041:note_history:51]
| • | New Jersey-American Water Company, Inc. v. The 3M Company et al., filed November 8, 2018 in the United States District Court for the District of New Jersey. |

- removed (2020-01-31):
[0000833444-19-000041:note_history:52]
| • | Village of Farmingdale v. The 3M Company et al., filed December 19, 2018 in the Supreme Court of the State of New York, County of Nassau (removed to the United States District Court for the Eastern District of New York). |

- removed (2020-01-31):
[0000833444-19-000041:note_history:53]
| • | Town of East Hampton v. The 3M Company et al., filed December 28, 2018 in the Supreme Court of the State of New York, County of Suffolk. |

- removed (2020-01-31):
[0000833444-19-000041:note_history:54]
| • | Ridgewood Water v. The 3M Company et al., filed February 25, 2019, in the Superior Court of the State of New Jersey, Bergen County (removed to the United States District Court for the District of New Jersey). |

- removed (2020-01-31):
[0000833444-19-000041:note_history:55]
| • | Atlantic City Municipal Utilities Authority v. The 3M Company et al., filed April 10, 2019 in the United States District Court, District of New Jersey. |

- removed (2020-01-31):
[0000833444-19-000041:note_history:56]
| • | New York American Water Company, Inc. v. The 3M Company et al., filed April 11, 2019 in the United States District Court, Eastern District of New York. |

- removed (2020-01-31):
[0000833444-19-000041:note_history:57]
| • | County of Westchester v. The 3M Company et al., filed May 24, 2019 in the United States District Court, Southern District of New York. |

- removed (2020-01-31):
[0000833444-19-000041:note_history:58]
| • | Diane Hebrank et al. v. City of Newburgh v. The 3M Company et al., third-party complaint filed June 10, 2019, in the Supreme Court of New York, Orange County. |

- removed (2020-01-31):
[0000833444-19-000041:note_history:59]
Under the previously announced Stock and Asset Purchase Agreement dated November 13, 2018 between the Company and the Purchaser, the Company has agreed to indemnify the Purchaser for any damages that could arise from this litigation.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-01-31):
[0000833444-20-000006:note_history:60]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2019 filed with the SEC on November 21, 2019. The results of operations for the three month period ended December 31, 2019 are not necessarily indicative of results for the Company’s 2020 fiscal year because of seasonal and other factors.
  (was, 2019-08-01, similarity 0.9778):
[0000833444-19-000041:note_history:60]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2018 filed with the SEC on November 20, 2018. The results of operations for the three and nine month periods ended June 30, 2019 are not necessarily indicative of results for the Company’s 2019 fiscal year because of seasonal and other factors.

- added (2020-01-31):
[0000833444-20-000006:note_history:61]
The Company consolidates variable interest entities ("VIE") in which the Company has the power to direct the significant activities of the entity and the obligation to absorb losses or receive benefits from the entity that may be significant.  The Company did not have a significant variable interest in any consolidated or nonconsolidated VIEs in its continuing operations for the presented reporting periods.

- added (2020-01-31):
[0000833444-20-000006:note_history:62]
At December 31, 2019 and September 30, 2019, the Company held restricted cash of approximately $12 million and $16 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.

- removed (2020-01-31):
[0000833444-19-000041:note_history:63]
Under certain criteria as provided for in Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity ("VIE"). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting rights. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.

- removed (2020-01-31):
[0000833444-19-000041:note_history:64]
The Company did not have a significant variable interest in any consolidated or nonconsolidated VIEs in its continuing operations for the presented reporting periods.

- removed (2020-01-31):
[0000833444-19-000041:note_history:65]
At June 30, 2019, the Company held restricted cash of approximately $16 million, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities. At September 30, 2018, the Company held restricted cash of approximately $15 million, of which $6 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position.

- removed (2020-01-31):
[0000833444-19-000041:note_history:66]
Retrospective Changes

- removed (2020-01-31):
[0000833444-19-000041:note_history:67]
During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation, which required retrospective application to financial information for all periods presented. Refer to Note 4, "Discontinued Operations" of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

- removed (2020-01-31):
[0000833444-19-000041:note_history:68]
In November 2016, the FASB issued Accounting Standards Update ("ASU") No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force)." The ASU requires amounts generally described as restricted cash and restricted cash equivalents to be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. ASU No. 2016-18 was effective retrospectively for the quarter ended December 31, 2018. The impact of this guidance did not have a significant impact on the Company's consolidated financial statements for the periods presented.

- removed (2020-01-31):
[0000833444-19-000041:note_history:69]
In August 2016, the FASB issued ASU No. 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments." ASU No. 2016-15 provides clarification guidance on eight specific cash flow presentation issues in order to reduce the diversity in practice. ASU No. 2016-15 was effective retrospectively for the Company for the quarter ending December 31, 2018. The adoption of this guidance had an impact on the presentation of equity swap funding and settlement activities since the activity changed from an operating activity to an investing activity.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-01-31):
[0000833444-20-000006:note_history:70]
The Company's net financing charges line item in the consolidated statements of income for the three months ended December 31, 2019 and 2018 contained the following components (in millions):
  (was, 2019-08-01, similarity 0.9485):
[0000833444-19-000041:note_history:70]
The Company's net financing charges line item in the consolidated statements of income for the three and nine months ended June 30, 2019 and 2018 contained the following components (in millions):

- changed (2020-01-31):
[0000833444-20-000006:note_history:71]
|  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Interest expense, net of capitalized interest costs | $ | 62 |  |  | $ | 91 |  |
| Banking fees and bond cost amortization | 5 |  |  | 6 |  |
| Interest income | (13 | ) |  | (7 | ) |
| Net foreign exchange results for financing activities | (2 | ) |  | (5 | ) |
| Net financing charges | $ | 52 |  |  | $ | 85 |  |
  (was, 2019-08-01, similarity 0.7189):
[0000833444-19-000041:note_history:71]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Interest expense, net of capitalized interest costs | $ | 81 |  |  | $ | 106 |  |  | $ | 269 |  |  | $ | 307 |  |
| Banking fees and bond cost amortization | 7 |  |  | 8 |  |  | 20 |  |  | 23 |  |
| Loss on debt extinguishment | 60 |  |  | — |  |  | 60 |  |  | — |  |
| Interest income | (28 | ) |  | (5 | ) |  | (41 | ) |  | (13 | ) |
| Net foreign exchange results for financing activities | (1 | ) |  | (14 | ) |  | (6 | ) |  | (13 | ) |
| Net financing charges | $ | 119 |  |  | $ | 95 |  |  | $ | 302 |  |  | $ | 304 |  |

- changed (2020-01-31):
[0000833444-20-000006:note_history:72]
In December 2019, the Company entered into a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2020.  As of December 31, 2019, there were no draws on the facilities.
  (was, 2019-08-01, similarity 0.6485):
[0000833444-19-000041:note_history:72]
In February 2019, a 364-day $150 million committed revolving credit facility expired.  The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2020.  As of June 30, 2019 there were no draws on the facility.

- added (2020-01-31):
[0000833444-20-000006:note_history:73]
In December 2019, the Company terminated its syndicated 5-year $2 billion committed revolving credit facility and four 364-day revolving credit facilities with total committed capacity of $750 million.

- removed (2020-01-31):
[0000833444-19-000041:note_history:74]
In June 2019, TSarl, a subsidiary of the Company, terminated its $1.25 billion committed revolving credit facility scheduled to expire in August 2020. In connection with the termination, the Company repaid all of the outstanding obligations in respect of principal, interest and fees under the credit facility. In relation to the termination of the credit facility, TSarl completed all of its obligations under the Term Loan Credit Agreement, dated as of March 10, 2016 (the "Term Facility") by repaying all of the outstanding obligations under the term facility, which included $364 million term loan scheduled to mature in March 2020. Other debt held at TSarl as of March 31, 2019 was also repaid, including a 364-day $250 million floating rate term loan scheduled to mature in March 2020 and an 18-month 215 million euro floating rate euro term loan scheduled to mature in July 2019. No amounts remain outstanding on the $4.0 billion TSarl merger-related debt as of June 30, 2019.

- removed (2020-01-31):
[0000833444-19-000041:note_history:75]
In June 2019, the Company repurchased at par, $2.5 million of its 5.25% fixed rate notes, plus accrued interest, scheduled to mature in 2041.

- removed (2020-01-31):
[0000833444-19-000041:note_history:76]
In May 2019, the Company completed the debt tender offer to purchase up to $1.5 billion in aggregate principal amount of certain of its outstanding notes for $1.6 billion total consideration. The Company recognized a loss on the extinguishment of debt of $60 million, which was recorded within net financing charges in the consolidated statements of income.

- removed (2020-01-31):
[0000833444-19-000041:note_history:77]
In May 2019, the Company repaid 10 billion yen of the 35 billion yen five-year syndicated floating rate term loan, plus accrued interest, scheduled to mature in September 2022.

- removed (2020-01-31):
[0000833444-19-000041:note_history:78]
In April 2019, the Company repurchased at a discount, 4.7 million euro of its 1.375% fixed rate euro notes, plus accrued interest, scheduled to mature in 2025.

- removed (2020-01-31):
[0000833444-19-000041:note_history:79]
In March 2019, a 364-day $250 million committed revolving credit facility expired.  The Company entered into a new $250 million committed revolving credit facility scheduled to expire in March 2020.  As of June 30, 2019 there were no draws on the facility.

- removed (2020-01-31):
[0000833444-19-000041:note_history:80]
In February 2019, the Company repurchased at a discount, $12 million of its 3.9% fixed rate notes, plus accrued interest, scheduled to mature in 2026.

- removed (2020-01-31):
[0000833444-19-000041:note_history:81]
In February 2019, a 364-day $150 million committed revolving credit facility expired.  The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2020.  As of June 30, 2019 there were no draws on the facility.

- removed (2020-01-31):
[0000833444-19-000041:note_history:82]
In January 2019, the Company entered into a $750 million term loan due the earlier of January 2020 or five business days from the closing on the sale of the Power Solutions business.  Proceeds from the term loan were used for general corporate purposes. Following the sale of the Power Solutions business, the loan was repaid in May 2019.

- removed (2020-01-31):
[0000833444-19-000041:note_history:83]
In January 2019, a 364-day $200 million committed revolving credit facility expired.  The Company entered into a new $350 million committed revolving credit facility scheduled to expire in January 2020.  As of June 30, 2019 there were no draws on the facility.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-01-31):
[0000833444-20-000006:note_history:84]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $45 million and $12 million, respectively, for the three months ended December 31, 2019; and $43 million and $14 million, respectively, for the three months ended December 31, 2018.
  (was, 2019-08-01, similarity 0.6341):
[0000833444-19-000041:note_history:84]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $65 million and $27 million, respectively, for the three months ended June 30, 2019; and $65 million and $19 million, respectively, for the three months ended June 30, 2018. The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $162 million and $57 million, respectively, for the nine months ended June 30, 2019; and $169 million and $43 million, respectively, for the nine months ended June 30, 2018.

- changed (2020-01-31):
[0000833444-20-000006:note_history:85]
|  |  | December 31, 2019 |  | September 30, 2019 |  |
| Receivable from related parties |  | $ | 29 |  |  | $ | 34 |  |
| Payable to related parties |  | 6 |  |  | 6 |  |
  (was, 2019-08-01, similarity 0.9655):
[0000833444-19-000041:note_history:85]
|  |  | June 30, 2019 |  | September 30, 2018 |  |
| Receivable from related parties |  | $ | 55 |  |  | $ | 36 |  |
| Payable to related parties |  | 8 |  |  | 18 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-01-31):
[0000833444-20-000006:note_history:86]
|  |  | December 31, 2019 |  | September 30, 2019 |  |
| Receivable from related parties |  | $ | 29 |  |  | $ | 34 |  |
| Payable to related parties |  | 6 |  |  | 6 |  |
  (was, 2019-08-01, similarity 0.9655):
[0000833444-19-000041:note_history:86]
|  |  | June 30, 2019 |  | September 30, 2018 |  |
| Receivable from related parties |  | $ | 55 |  |  | $ | 36 |  |
| Payable to related parties |  | 8 |  |  | 18 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-01-31):
[0000833444-20-000006:note_history:87]
The following table presents the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three months ended December 31, 2019 and 2018 (in millions):
  (was, 2019-08-01, similarity 0.8956):
[0000833444-19-000041:note_history:87]
The following table presents the Company's revenues disaggregated by segment and by product versus services revenue for the three and nine months ended June 30, 2019 (in millions):

- added (2020-01-31):
[0000833444-20-000006:note_history:88]
|  |  | Three Months Ended December 31, 2019 |  | Three Months Ended December 31, 2018 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,356 |  |  | $ | 811 |  |  | $ | 2,167 |  |  | $ | 1,321 |  |  | $ | 795 |  |  | $ | 2,116 |  |
| Building Solutions EMEA/LA |  | 457 |  |  | 471 |  |  | 928 |  |  | 417 |  |  | 490 |  |  | 907 |  |
| Building Solutions Asia Pacific |  | 371 |  |  | 258 |  |  | 629 |  |  | 356 |  |  | 257 |  |  | 613 |  |
| Global Products |  | 1,852 |  |  | — |  |  | 1,852 |  |  | 1,828 |  |  | — |  |  | 1,828 |  |
| Total |  | $ | 4,036 |  |  | $ | 1,540 |  |  | $ | 5,576 |  |  | $ | 3,922 |  |  | $ | 1,542 |  |  | $ | 5,464 |  |

- changed (2020-01-31):
[0000833444-20-000006:note_history:89]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2019 and 2018 (in millions):
  (was, 2019-08-01, similarity 0.9235):
[0000833444-19-000041:note_history:89]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and nine months ended June 30, 2019 (in millions):

- added (2020-01-31):
[0000833444-20-000006:note_history:90]
|  |  | Three Months Ended December 31, |
|  |  | 2019 |  | 2018 |
| Building management systems |  | $ | 300 |  |  | $ | 281 |  |
| HVAC & refrigeration equipment |  | 1,285 |  |  | 1,285 |  |
| Specialty products |  | 267 |  |  | 262 |  |
| Total |  | $ | 1,852 |  |  | $ | 1,828 |  |

- removed (2020-01-31):
[0000833444-19-000041:note_history:91]
|  |  | Three Months EndedJune 30, 2019 |  | Nine Months EndedJune 30, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,494 |  |  | $ | 833 |  |  | $ | 2,327 |  |  | $ | 4,202 |  |  | $ | 2,428 |  |  | $ | 6,630 |  |
| Building Solutions EMEA/LA |  | 464 |  |  | 458 |  |  | 922 |  |  | 1,297 |  |  | 1,410 |  |  | 2,707 |  |
| Building Solutions Asia Pacific |  | 427 |  |  | 264 |  |  | 691 |  |  | 1,134 |  |  | 798 |  |  | 1,932 |  |
| Global Products |  | 2,511 |  |  | — |  |  | 2,511 |  |  | 6,425 |  |  | — |  |  | 6,425 |  |
| Total |  | $ | 4,896 |  |  | $ | 1,555 |  |  | $ | 6,451 |  |  | $ | 13,058 |  |  | $ | 4,636 |  |  | $ | 17,694 |  |

- removed (2020-01-31):
[0000833444-19-000041:note_history:92]
|  |  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  |  | 2019 |  | 2019 |
| Building Management |  | $ | 342 |  |  | $ | 943 |  |
| HVAC & Refrigeration Equipment |  | 1,869 |  |  | 4,628 |  |
| Specialty |  | 300 |  |  | 854 |  |
| Total Global Products |  | $ | 2,511 |  |  | $ | 6,425 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2020-01-31):
[0000833444-19-000041:note_history:93]
The Company designs, manufactures and installs building products and systems around the world, including HVAC equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Company also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems.

- removed (2020-01-31):
[0000833444-19-000041:note_history:94]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion

- removed (2020-01-31):
[0000833444-19-000041:note_history:95]
measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company elected the practical expedient which permits the promised amount of consideration to not be adjusted for the effects of a significant financing component as at contract inception the Company expects to receive the payment within the twelve months of transfer of goods or services.

- removed (2020-01-31):
[0000833444-19-000041:note_history:96]
The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term.

- removed (2020-01-31):
[0000833444-19-000041:note_history:97]
The Company also sells certain HVAC and refrigeration products and services in bundled arrangements with multiple performance obligations, such as equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Company sells security monitoring systems that may have multiple performance obligations, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with sale of equipment and related installations are recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. The transaction price is allocated to each performance obligation based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach. Revenue recognized for security monitoring equipment and installation is limited to the lesser of their allocated amounts under the estimated selling price hierarchy or the non-contingent up-front consideration received at the time of installation, since collection of future amounts under the arrangement with the customer is contingent upon the delivery of monitoring and maintenance services. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized over time on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the contract.

- removed (2020-01-31):
[0000833444-19-000041:note_history:98]
In all other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

- removed (2020-01-31):
[0000833444-19-000041:note_history:99]
The Company considers the contractual consideration payable by the customer and assess variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

- removed (2020-01-31):
[0000833444-19-000041:note_history:100]
Shipping and handling costs billed to customers are included in sales and the related costs are included in cost of sales when control transfers to the customer. The Company has elected to present amounts collected from customers for sales and other taxes net of the related amounts remitted.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-01-31):
[0000833444-20-000006:note_history:101]
The following table presents the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three months ended December 31, 2019 and 2018 (in millions):
  (was, 2019-08-01, similarity 0.8956):
[0000833444-19-000041:note_history:101]
The following table presents the Company's revenues disaggregated by segment and by product versus services revenue for the three and nine months ended June 30, 2019 (in millions):

- added (2020-01-31):
[0000833444-20-000006:note_history:102]
|  |  | Three Months Ended December 31, 2019 |  | Three Months Ended December 31, 2018 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,356 |  |  | $ | 811 |  |  | $ | 2,167 |  |  | $ | 1,321 |  |  | $ | 795 |  |  | $ | 2,116 |  |
| Building Solutions EMEA/LA |  | 457 |  |  | 471 |  |  | 928 |  |  | 417 |  |  | 490 |  |  | 907 |  |
| Building Solutions Asia Pacific |  | 371 |  |  | 258 |  |  | 629 |  |  | 356 |  |  | 257 |  |  | 613 |  |
| Global Products |  | 1,852 |  |  | — |  |  | 1,852 |  |  | 1,828 |  |  | — |  |  | 1,828 |  |
| Total |  | $ | 4,036 |  |  | $ | 1,540 |  |  | $ | 5,576 |  |  | $ | 3,922 |  |  | $ | 1,542 |  |  | $ | 5,464 |  |

- changed (2020-01-31):
[0000833444-20-000006:note_history:103]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2019 and 2018 (in millions):
  (was, 2019-08-01, similarity 0.9235):
[0000833444-19-000041:note_history:103]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and nine months ended June 30, 2019 (in millions):

- added (2020-01-31):
[0000833444-20-000006:note_history:104]
|  |  | Three Months Ended December 31, |
|  |  | 2019 |  | 2018 |
| Building management systems |  | $ | 300 |  |  | $ | 281 |  |
| HVAC & refrigeration equipment |  | 1,285 |  |  | 1,285 |  |
| Specialty products |  | 267 |  |  | 262 |  |
| Total |  | $ | 1,852 |  |  | $ | 1,828 |  |

- changed (2020-01-31):
[0000833444-20-000006:note_history:105]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed and consist of unbilled receivables and costs in excess of billings. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract liabilities consist of deferred revenue. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.
  (was, 2019-08-01, similarity 0.999):
[0000833444-19-000041:note_history:105]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed and consist of unbilled receivable and costs in excess of billings. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract liabilities consist of deferred revenue. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

- added (2020-01-31):
[0000833444-20-000006:note_history:106]
|  |  | Location of contract balances |  | December 31, 2019 |  | September 30, 2019 |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,465 |  |  | $ | 1,389 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 99 |  |  | 90 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,495 | ) |  | (1,407 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (119 | ) |  | (117 | ) |
| Total |  |  |  | $ | (50 | ) |  | $ | (45 | ) |

- changed (2020-01-31):
[0000833444-20-000006:note_history:107]
For the three months ended December 31, 2019 and December 31, 2018, the Company recognized revenue of $686 million and $712 million, respectively, that was included in the beginning of period contract liability balance.
  (was, 2019-08-01, similarity 0.9091):
[0000833444-19-000041:note_history:107]
For the three and nine months ended June 30, 2019, the Company recognized revenue of $130 million and $1,056 million, respectively, that was included in the beginning of period contract liability balance.

- changed (2020-01-31):
[0000833444-20-000006:note_history:108]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of December 31, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.7 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.
  (was, 2019-08-01, similarity 0.779):
[0000833444-19-000041:note_history:108]
Performance obligations are satisfied as of a point in time or over time. Performance obligations are supported by contracts with customers, providing a framework for the nature of the distinct goods, services, or bundle of goods and services. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of June 30, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.2 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company has applied the practical expedient for certain revenue streams to exclude the value of remaining performance obligations for contracts with an original expected duration of one year or less.

- added (2020-01-31):
[0000833444-20-000006:note_history:109]
As of December 31, 2019, the Company recorded the costs to obtain or fulfill a contract of $236 million, of which $127 million is recorded within other current assets and $109 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2019, the Company recorded the costs to obtain or fulfill a contract of $212 million, of which $110 million is recorded within other current assets and $102 million is recorded within other noncurrent assets in the consolidated statements of financial position.

- added (2020-01-31):
[0000833444-20-000006:note_history:110]
During the three months ended December 31, 2019 and 2018, the Company recognized amortization expense of $26 million and $35 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three months ended December 31, 2019 and 2018.

- removed (2020-01-31):
[0000833444-19-000041:note_history:111]
The Company designs, manufactures and installs building products and systems around the world, including HVAC equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Company also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems.

- removed (2020-01-31):
[0000833444-19-000041:note_history:112]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion

- removed (2020-01-31):
[0000833444-19-000041:note_history:113]
measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company elected the practical expedient which permits the promised amount of consideration to not be adjusted for the effects of a significant financing component as at contract inception the Company expects to receive the payment within the twelve months of transfer of goods or services.

- removed (2020-01-31):
[0000833444-19-000041:note_history:114]
The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term.

- removed (2020-01-31):
[0000833444-19-000041:note_history:115]
The Company also sells certain HVAC and refrigeration products and services in bundled arrangements with multiple performance obligations, such as equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Company sells security monitoring systems that may have multiple performance obligations, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with sale of equipment and related installations are recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. The transaction price is allocated to each performance obligation based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach. Revenue recognized for security monitoring equipment and installation is limited to the lesser of their allocated amounts under the estimated selling price hierarchy or the non-contingent up-front consideration received at the time of installation, since collection of future amounts under the arrangement with the customer is contingent upon the delivery of monitoring and maintenance services. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized over time on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the contract.

- removed (2020-01-31):
[0000833444-19-000041:note_history:116]
In all other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

- removed (2020-01-31):
[0000833444-19-000041:note_history:117]
The Company considers the contractual consideration payable by the customer and assess variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

- removed (2020-01-31):
[0000833444-19-000041:note_history:118]
Shipping and handling costs billed to customers are included in sales and the related costs are included in cost of sales when control transfers to the customer. The Company has elected to present amounts collected from customers for sales and other taxes net of the related amounts remitted.

- removed (2020-01-31):
[0000833444-19-000041:note_history:119]
|  |  | Three Months EndedJune 30, 2019 |  | Nine Months EndedJune 30, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,494 |  |  | $ | 833 |  |  | $ | 2,327 |  |  | $ | 4,202 |  |  | $ | 2,428 |  |  | $ | 6,630 |  |
| Building Solutions EMEA/LA |  | 464 |  |  | 458 |  |  | 922 |  |  | 1,297 |  |  | 1,410 |  |  | 2,707 |  |
| Building Solutions Asia Pacific |  | 427 |  |  | 264 |  |  | 691 |  |  | 1,134 |  |  | 798 |  |  | 1,932 |  |
| Global Products |  | 2,511 |  |  | — |  |  | 2,511 |  |  | 6,425 |  |  | — |  |  | 6,425 |  |
| Total |  | $ | 4,896 |  |  | $ | 1,555 |  |  | $ | 6,451 |  |  | $ | 13,058 |  |  | $ | 4,636 |  |  | $ | 17,694 |  |

- removed (2020-01-31):
[0000833444-19-000041:note_history:120]
|  |  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  |  | 2019 |  | 2019 |
| Building Management |  | $ | 342 |  |  | $ | 943 |  |
| HVAC & Refrigeration Equipment |  | 1,869 |  |  | 4,628 |  |
| Specialty |  | 300 |  |  | 854 |  |
| Total Global Products |  | $ | 2,511 |  |  | $ | 6,425 |  |

- removed (2020-01-31):
[0000833444-19-000041:note_history:121]
|  |  | Location of contract balances |  | June 30, 2019 |  | October 1, 2018 |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,428 |  |  | $ | 1,261 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 85 |  |  | 85 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,389 | ) |  | (1,335 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (125 | ) |  | (113 | ) |
| Total |  |  |  | $ | (1 | ) |  | $ | (102 | ) |

- removed (2020-01-31):
[0000833444-19-000041:note_history:122]
As of June 30, 2019, the Company recorded the costs to obtain or fulfill a contract of $190 million, of which $100 million is recorded within other current assets and $90 million is recorded within other noncurrent assets in the consolidated statements of financial position.

- removed (2020-01-31):
[0000833444-19-000041:note_history:123]
During the three and nine months ended June 30, 2019, the Company recognized amortization expense of $50 million and $119 million, respectively related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and nine months ended June 30, 2019.
