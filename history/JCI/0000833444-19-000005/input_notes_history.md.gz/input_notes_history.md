# JCI note change history — 0000833444-18-000044 → 0000833444-19-000005


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-02-01):
[0000833444-19-000005:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of December 31, 2018, reserves for environmental liabilities for continuing operations totaled $32 million, of which $13 million was recorded within other current liabilities and $19 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $37 million at September 30, 2018, of which $10 million was recorded within other current liabilities and $27 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At December 31, 2018 and September 30, 2018, the Company recorded conditional asset retirement obligations for continuing operations of $29 million.
  (was, 2018-08-02, similarity 0.9692):
[0000833444-18-000044:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of June 30, 2018, reserves for environmental liabilities totaled $43 million, of which $14 million was recorded within other current liabilities and $29 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities totaled $51 million at September 30, 2017, of which $10 million was recorded within other current liabilities and $41 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At June 30, 2018 and September 30, 2017, the Company recorded conditional asset retirement obligations of $48 million and $61 million, respectively.

- changed (2019-02-01):
[0000833444-19-000005:note_history:2]
As of December 31, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $194 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $546 million, of which $55 million was recorded in other current liabilities and $491 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $352 million, of which $33 million was recorded in other current assets, and $319 million was recorded in other noncurrent assets. Assets included $20 million of cash and $243 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at December 31, 2018 was $89 million. As of September 30, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $173 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $550 million, of which $55 million was recorded in other current liabilities and $495 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $33 million was recorded in other current assets, and $344 million was recorded in other noncurrent assets. Assets included $6 million of cash and $281 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2018 was $90 million.
  (was, 2018-08-02, similarity 0.9946):
[0000833444-18-000044:note_history:2]
As of June 30, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $180 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $557 million, of which $54 million was recorded in other current liabilities and $503 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $41 million was recorded in other current assets, and $336 million was recorded in other noncurrent assets. Assets included $10 million of cash and $274 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at June 30, 2018 was $93 million. As of September 30, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $181 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $573 million, of which $48 million was recorded in other current liabilities and $525 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $392 million, of which $53 million was recorded in other current assets, and $339 million was recorded in other noncurrent assets. Assets included $22 million of cash and $269 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2017 was $101 million.

- changed (2019-02-01):
[0000833444-19-000005:note_history:3]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At December 31, 2018 and September 30, 2018, the insurable liabilities totaled $415 million and $417 million, respectively, of which $94 million and $95 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $299 million and $300 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at December 31, 2018 and September 30, 2018 were $26 million, of which $6 million was recorded within other current assets and $20 million was recorded within other noncurrent assets. The Company maintains captive insurance companies to manage its insurable liabilities.
  (was, 2018-08-02, similarity 0.8967):
[0000833444-18-000044:note_history:3]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At June 30, 2018 and September 30, 2017, the insurable liabilities totaled $444 million and $445 million, respectively, of which $80 million and $122 million was recorded within other current liabilities, $25 million and $22 million was recorded within accrued compensation and benefits, and $339 million and $301 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at June 30, 2018 was $21 million, of which $6 million was recorded within other current assets and $15 million was recorded within other noncurrent assets.  The amount of such receivables recorded at September 30, 2017 was $46 million, of which $31 million was recorded within other current assets and $15 million was recorded within other noncurrent assets. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

- changed (2019-02-01):
[0000833444-19-000005:note_history:4]
Two of our subsidiaries, Chemguard, Inc. ("Chemguard") and Tyco Fire Products L.P. ("Tyco Fire Products"), have been named, along with other defendant manufacturers, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated ("PFAS") compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued regulatory limits, however; while those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.
  (was, 2018-08-02, similarity 0.7565):
[0000833444-18-000044:note_history:4]
Two of our subsidiaries, Chemguard, Inc. ("Chemguard") and Tyco Fire Products L.P. ("Tyco Fire Products"), have been named, along with other defendant manufacturers, in a number of class action lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and that the use of these products by others at various airbases and airports resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports and airbases. PFOA and PFOS are being studied by the United States Environmental Protection Agency (EPA) and other environmental and health agencies and researchers. The EPA has not issued regulatory limits, however; while those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

- changed (2019-02-01):
[0000833444-19-000005:note_history:5]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.
  (was, 2018-08-02, similarity 0.8179):
[0000833444-18-000044:note_history:5]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination. As of August 2, 2018, the Company is named in 16 putative class actions in federal courts in six states as set forth below:

- added (2019-02-01):
[0000833444-19-000005:note_history:6]
In September of 2018, the Company filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to the MDL.

- added (2019-02-01):
[0000833444-19-000005:note_history:7]
AFFF Putative Class Actions

- added (2019-02-01):
[0000833444-19-000005:note_history:8]
Chemguard and Tyco Fire Products are named in 20 putative class actions in federal and state courts in Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania and Washington.  Each of these cases have been transferred to the MDL. The following putative class actions were filed in fiscal year 2019:

- changed (2019-02-01):
[0000833444-19-000005:note_history:9]
| • | Grubb v. The 3M Company et al., filed October 30, 2018 in the United States District Court, District of Delaware. |
  (was, 2018-08-02, similarity 0.8268):
[0000833444-18-000044:note_history:9]
| • | District of Delaware - Anderson v. The 3M Company et al., filed June 12, 2018 in the United States District Court District of Delaware. |

- changed (2019-02-01):
[0000833444-19-000005:note_history:10]
| • | County of Dutchess v. 3M Company et al., filed October 12, 2018 in the United States District Court, Southern District of New York. |
  (was, 2018-08-02, similarity 0.7309):
[0000833444-18-000044:note_history:10]
| • | Eastern District of Washington - Ackerman et al. v. The 3M Company et al., filed April 5, 2018 in the United States District Court, Eastern District of Washington. |

- changed (2019-02-01):
[0000833444-19-000005:note_history:11]
| • | Battisti et al. v. The 3M Company et al., filed December 20, 2018 in the United States District Court, Middle District of Florida. |
  (was, 2018-08-02, similarity 0.7021):
[0000833444-18-000044:note_history:11]
| • | District of Massachusetts - Civitarese et al. v. The 3M Company et al., filed April 18, 2018 in the United States District Court of Massachusetts. |

- added (2019-02-01):
[0000833444-19-000005:note_history:12]
AFFF Individual or Mass Actions

- added (2019-02-01):
[0000833444-19-000005:note_history:13]
There are approximately 55 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases) and Pennsylvania (10 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York and 14 plaintiffs in Pennsylvania.  These matters have been transferred to the MDL.  The Company is also on notice of approximately 660 other possible individual product liability claims and 3 possible municipal claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, and, under Pennsylvania’s procedural rules, they may or may not result in lawsuits.

- added (2019-02-01):
[0000833444-19-000005:note_history:14]
AFFF Municipal Cases

- added (2019-02-01):
[0000833444-19-000005:note_history:15]
Chemguard and Tyco Fire Products are also defendants in 14 cases in federal and state courts involving municipal plaintiffs in Arizona, Florida, Massachusetts, New Jersey, New York and Ohio.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  All but two of these cases either have been transferred or identified for transfer to the MDL.   The following municipal actions were filed in fiscal year 2019:

- added (2019-02-01):
[0000833444-19-000005:note_history:16]
| • | Dutchess County v. The 3M Company et al. filed October 12, 2018 (and removed to the United States District Court, Southern District of New York) and styled as a class action. |

- added (2019-02-01):
[0000833444-19-000005:note_history:17]
| • | City of Dayton v. The 3M Company et al., filed October 3, 2018 in the United States District Court, Southern District of Ohio. |

- added (2019-02-01):
[0000833444-19-000005:note_history:18]
| • | City of Stuart v. the 3M Company et al., filed October 18, 2018 in the United States District Court, Southern District of Florida. |

- added (2019-02-01):
[0000833444-19-000005:note_history:19]
| • | City of Tucson and Town of Marana v. The 3M Company et al., filed November 8, 2018 in the Superior Court of the State of Arizona, County of Pima (removed to the United States District Court for the District of Arizona). |

- added (2019-02-01):
[0000833444-19-000005:note_history:20]
| • | New Jersey-American Water Company, Inc. v. The 3M Company et al., filed November 8, 2018 in the United States District Court for the District of New Jersey. |

- changed (2019-02-01):
[0000833444-19-000005:note_history:21]
| • | Village of Farmingdale v. The 3M Company et al., filed December 19, 2018 in the Supreme Court of the State of New York, County of Nassau (removed to the United States District Court for the Eastern District of New York). |
  (was, 2018-08-02, similarity 0.6244):
[0000833444-18-000044:note_history:21]
| • | Eastern District of New York - Green et al. v. The 3M Company et al., filed March 27, 2017 in Supreme Court of the State of New York, Suffolk County, prior to removal to federal court. |

- added (2019-02-01):
[0000833444-19-000005:note_history:22]
| • | Town of East Hampton v. The 3M Company et al., filed December 28, 2018 in the Supreme Court of the State of New York, County of Suffolk. |

- added (2019-02-01):
[0000833444-19-000005:note_history:23]
State Attorneys General Litigation related to AFFF

- changed (2019-02-01):
[0000833444-19-000005:note_history:24]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. 3M Co., No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and identified for transfer to the MDL.
  (was, 2018-08-02, similarity 0.9067):
[0000833444-18-000044:note_history:24]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. 3M Co., No. 904029-18 (N.Y. Sup. Ct., Albany County) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites.

- added (2019-02-01):
[0000833444-19-000005:note_history:25]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. 3M Co., No. G-4801-CI-021804752 -000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio.  The lawsuit seeks to recover costs and natural resource damages associated with the contamination.  This lawsuit has been removed to the United States District Court for the Northern District of Ohio and identified for transfer to the MDL.

- added (2019-02-01):
[0000833444-19-000005:note_history:26]
AFFF Matters Related to the Tyco Fire Products Fire Technology Center in Marinette, Wisconsin

- changed (2019-02-01):
[0000833444-19-000005:note_history:27]
Tyco Fire Products, in coordination with the Wisconsin Department of Natural Resources ("WDNR") and the Wisconsin Department of Health Services ("DHS"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin.  In connection with the assessment, PFOS and PFOA have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC.  Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working closely with WDNR and DHS to develop interim measures to remove these compounds from certain areas where they have been detected.
  (was, 2018-08-02, similarity 0.9825):
[0000833444-18-000044:note_history:27]
Tyco Fire Products, in coordination with the Wisconsin Department of Natural Resources (WDNR) and the Wisconsin Department of Health Services (DHS), has been conducting an environmental assessment of its Fire Technology Center (FTC) located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin.  In connection with the assessment, PFOS and PFOA have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC.  Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working closely with WDNR and DHS to develop interim measures to remove these compounds from certain areas where they have been detected.

- added (2019-02-01):
[0000833444-19-000005:note_history:28]
Tyco Fire Products and its subsidiary Chemguard are defendants in two lawsuits in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFOA/PFOS contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and will identify it for transfer to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater.

- added (2019-02-01):
[0000833444-19-000005:note_history:29]
The Company is vigorously defending the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

- changed (2019-02-01):
[0000833444-19-000005:note_history:30]
Other Matters
  (was, 2018-08-02, similarity 0.8387):
[0000833444-18-000044:note_history:30]
Other AFFF Matters

- removed (2019-02-01):
[0000833444-18-000044:note_history:31]
Arbitration Award

- removed (2019-02-01):
[0000833444-18-000044:note_history:32]
In September 2017, the Company was subject to an unfavorable arbitration award of approximately $50 million relating to a contractual dispute with a subcontractor used by the Company at an airport construction project in Doha, Qatar. In connection with the unfavorable arbitration award, the Company recorded a charge of $50 million within selling, general and administrative expenses in the consolidated statements of income in the fourth quarter of fiscal 2017. The airport project is being managed by a steering committee. The Company and the subcontractor were working jointly to document claims for increased costs against the steering committee when the subcontractor initiated the arbitration proceeding against the Company. Pursuant to its arbitration proceeding against the Company, the subcontractor sought to recover costs it alleges it incurred due to project delays, additional work and related financing costs. The Company has filed annulment proceedings with respect to the arbitration award in the local court in Qatar. While the award remains outstanding, a portion of the balance will accrue interest at a statutory rate of 9.56%.

- removed (2019-02-01):
[0000833444-18-000044:note_history:33]
In a related action, the Company has initiated an arbitration claim against the steering committee related to costs it incurred in connection with delays of the airport construction project, including costs related to the above award. The arbitrator is expected to issue a decision on the Company’s claims against the steering committee by the end of fiscal 2018.

- removed (2019-02-01):
[0000833444-18-000044:note_history:34]
Colorado

- removed (2019-02-01):
[0000833444-18-000044:note_history:35]
| • | District of Colorado - Bell et al. v. The 3M Company et al., filed September 18, 2016. |

- removed (2019-02-01):
[0000833444-18-000044:note_history:36]
| • | District of Colorado - Bell et al. v. The 3M Company et al., filed September 18, 2016. |

- removed (2019-02-01):
[0000833444-18-000044:note_history:37]
| • | District of Colorado - Davis et al. v. The 3M Company et al., filed September 22, 2016. |

- removed (2019-02-01):
[0000833444-18-000044:note_history:38]
The above cases have been consolidated in the U.S. District Court for the District of Colorado, and a hearing on the plaintiffs’ motion for class certification is expected in 2018 with a trial date schedule for April 2019.

- removed (2019-02-01):
[0000833444-18-000044:note_history:39]
Delaware

- removed (2019-02-01):
[0000833444-18-000044:note_history:40]
Massachusetts

- removed (2019-02-01):
[0000833444-18-000044:note_history:41]
Washington

- removed (2019-02-01):
[0000833444-18-000044:note_history:42]
New York

- removed (2019-02-01):
[0000833444-18-000044:note_history:43]
| • | Southern District of New York - Adamo et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

- removed (2019-02-01):
[0000833444-18-000044:note_history:44]
| • | Southern District of New York - Fogarty et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

- removed (2019-02-01):
[0000833444-18-000044:note_history:45]
| • | Southern District of New York - Miller et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

- removed (2019-02-01):
[0000833444-18-000044:note_history:46]
| • | Supreme Court of the State of New York, Suffolk County - Singer et al. v. The 3M Company et al., filed October 10, 2017. |

- removed (2019-02-01):
[0000833444-18-000044:note_history:47]
| • | Supreme Court of the State of New York, Suffolk County - Shipman et al. v. The 3M Company et al., filed March 21, 2018. |

- removed (2019-02-01):
[0000833444-18-000044:note_history:48]
Pennsylvania

- removed (2019-02-01):
[0000833444-18-000044:note_history:49]
| • | Eastern District of Pennsylvania - Bates et al. v. The 3M Company et al., filed September 15, 2016. |

- removed (2019-02-01):
[0000833444-18-000044:note_history:50]
| • | Eastern District of Pennsylvania - Grande et al. v. The 3M Company et al., filed October 13, 2016. |

- removed (2019-02-01):
[0000833444-18-000044:note_history:51]
| • | Eastern District of Pennsylvania - Yockey et al. v. The 3M Company et al., filed October 24, 2016. |

- removed (2019-02-01):
[0000833444-18-000044:note_history:52]
| • | Eastern District of Pennsylvania - Fearnley et al. v. The 3M Company et al., filed December 9, 2016. |

- removed (2019-02-01):
[0000833444-18-000044:note_history:53]
The above cases have been consolidated in the U.S. District Court for the Eastern District of Pennsylvania. The defendants' motion to dismiss the complaint in the consolidated proceeding was denied without prejudice and the cases are currently stayed pending the appeal of an action in which the Company is not a party.

- removed (2019-02-01):
[0000833444-18-000044:note_history:54]
In addition, as of August 2, 2018, there were a total of 51 individual or “mass” actions filed in state court in Colorado (41 cases), New York (1 case) and Pennsylvania (9 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, 26 plaintiffs in New York and 13 plaintiffs in Pennsylvania.  The Company is also on notice of approximately 622 other possible individual product liability claims and 3 possible municipal claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, and, under Pennsylvania’s procedural rules, they may or may not result in lawsuits.

- removed (2019-02-01):
[0000833444-18-000044:note_history:55]
Chemguard and Tyco Fire Products are also defendants in three municipal cases pending in the U.S. District Court for the District of Massachusetts: Town of Barnstable v. the 3M. Co., et al, (filed Nov. 21, 2016), County of Barnstable v. the 3M. Co., et al, (filed January 9, 2017) and City of Westfield v. the 3M Co., et al., (filed on February 24, 2018), as well as two municipal cases pending in the Eastern District of New York: Suffolk County Water Auth. v. 3M Co. (filed November 30, 2017) and Hampton Bays Water Dist. v. 3M Co. (filed Feb. 21, 2018), and one municipal case pending in the Northern District of Florida: Emerald Coast Utilities Auth. v. 3M Co. (filed June 22, 2018). These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property. The defendants have filed motions to dismiss in County of Barnstable and City of Westfield.

- removed (2019-02-01):
[0000833444-18-000044:note_history:56]
The Company is vigorously defending these cases and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-02-01):
[0000833444-19-000005:note_history:57]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2018 filed with the SEC on November 20, 2018. The results of operations for the three month period ended December 31, 2018 are not necessarily indicative of results for the Company’s 2019 fiscal year because of seasonal and other factors.
  (was, 2018-08-02, similarity 0.9778):
[0000833444-18-000044:note_history:57]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2017 filed with the SEC on November 21, 2017. The results of operations for the three and nine month periods ended June 30, 2018 are not necessarily indicative of results for the Company’s 2018 fiscal year because of seasonal and other factors.

- changed (2019-02-01):
[0000833444-19-000005:note_history:58]
The Building Technologies & Solutions ("Buildings") business is a global market leader in engineering, developing, manufacturing and installing building products and systems around the world, including heating, ventilating, air-conditioning ("HVAC") equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Buildings business further serves customers by providing technical services (in the HVAC, security and fire-protection space), energy-management consulting and data-driven solutions via its data-enabled business. Finally, the Company has a strong presence in the North American residential air conditioning and heating systems market and is a global market leader in industrial refrigeration products.
  (was, 2018-08-02, similarity 0.8751):
[0000833444-18-000044:note_history:58]
The Building Technologies & Solutions ("Buildings") business is a global market leader in engineering, developing, manufacturing and installing building products and systems around the world, including heating, ventilating, air-conditioning ("HVAC") equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Buildings business further serves customers by providing technical services (in the HVAC, security and fire-protection space), energy-management consulting and data-driven solutions via its recently launch data-enabled business. Finally, the Company is a North American market leader in residential air conditioning and heating systems and a global market leader in industrial refrigeration products.

- changed (2019-02-01):
[0000833444-19-000005:note_history:59]
The Power Solutions business is a leading global supplier of lead-acid automotive batteries for virtually every type of passenger car, light truck and utility vehicle. The Company serves both automotive original equipment manufacturers and the general vehicle battery aftermarket. The Company also supplies advanced battery technologies to power start-stop, hybrid and electric vehicles. During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation, which required retrospective application to financial information for all periods presented. Refer to Note 4, "Discontinued Operations" of the notes to consolidated financial statements for further information.
  (was, 2018-08-02, similarity 0.6784):
[0000833444-18-000044:note_history:59]
The Power Solutions business is a leading global supplier of lead-acid automotive batteries for virtually every type of passenger car, light truck and utility vehicle. The Company serves both automotive original equipment manufacturers and the general vehicle battery aftermarket. The Company also supplies advanced battery technologies to power start-stop, hybrid and electric vehicles.

- changed (2019-02-01):
[0000833444-19-000005:note_history:60]
Under certain criteria as provided for in Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity ("VIE"). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting rights. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.
  (was, 2018-08-02, similarity 0.9834):
[0000833444-18-000044:note_history:60]
Under certain criteria as provided for in Financial Accounting Standards Board ("FASB") ASC 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity ("VIE"). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting rights. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.

- changed (2019-02-01):
[0000833444-19-000005:note_history:61]
The Company did not have a significant variable interest in any consolidated or nonconsolidated VIEs in its continuing operations for the presented reporting periods.
  (was, 2018-08-02, similarity 0.8493):
[0000833444-18-000044:note_history:61]
The Company did not have a significant variable interest in any other unconsolidated VIEs for the presented reporting periods.

- added (2019-02-01):
[0000833444-19-000005:note_history:62]
At December 31, 2018, the Company held restricted cash of approximately $20 million, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities. At September 30, 2018, the Company held restricted cash of approximately $15 million, of which $6 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position.

- added (2019-02-01):
[0000833444-19-000005:note_history:63]
During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation, which required retrospective application to financial information for all periods presented. Refer to Note 4, "Discontinued Operations" of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

- added (2019-02-01):
[0000833444-19-000005:note_history:64]
In November 2016, the FASB issued Accounting Standards Update ("ASU") No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force)." The ASU requires amounts generally described as restricted cash and restricted cash equivalents to be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. ASU No. 2016-18 was effective retrospectively for the quarter ended December 31, 2018. The impact of this guidance did not have a significant impact on the Company's consolidated financial statements for the periods presented.

- added (2019-02-01):
[0000833444-19-000005:note_history:65]
In August 2016, the FASB issued ASU No. 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments." ASU No. 2016-15 provides clarification guidance on eight specific cash flow presentation issues in order to reduce the diversity in practice. ASU No. 2016-15 was effective retrospectively for the Company for the quarter ending December 31, 2018. The adoption of this guidance had an impact on the presentation of equity swap funding and settlement activities since the activity changed from an operating activity to an investing activity.

- removed (2019-02-01):
[0000833444-18-000044:note_history:66]
In the fourth quarter of fiscal 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco International plc ("Tyco") completed their combination with JCI Inc. merging with a wholly-owned, indirect subsidiary of Tyco (the "Merger"). Following the Merger, Tyco changed its name to “Johnson Controls International plc” and JCI Inc. is a wholly-owned subsidiary of Johnson Controls International plc. The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes. Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company.

- removed (2019-02-01):
[0000833444-18-000044:note_history:67]
Consolidated VIEs

- removed (2019-02-01):
[0000833444-18-000044:note_history:68]
Based upon the criteria set forth in ASC 810, the Company has determined that it was not the primary beneficiary in any VIEs for the reporting period ended June 30, 2018 and that it was the primary beneficiary in one VIE for the reporting period ended September 30, 2017, as the Company absorbed significant economics of the entity and had the power to direct the activities that are considered most significant to the entity.

- removed (2019-02-01):
[0000833444-18-000044:note_history:69]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company was considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE was consolidated within the Company’s consolidated statements of financial position as of September 30, 2017. During the quarter ended December 31, 2017, certain joint venture agreements were amended, and as a result, the Company can no longer make key operating decisions considered to be most significant to the VIE. As such, the Company is no longer considered the primary beneficiary of this entity, and the Company deconsolidated the entity during the quarter ended December 31, 2017. The impact of the entity on the Company’s consolidated statements of income for the nine month periods ended June 30, 2018 and 2017 was not material.

- removed (2019-02-01):
[0000833444-18-000044:note_history:70]
The carrying amounts and classification of assets (none of which are restricted) and liabilities included in the Company’s consolidated statements of financial position for the consolidated VIE is as follows (in millions):

- removed (2019-02-01):
[0000833444-18-000044:note_history:71]
|  |  | September 30,2017 |
| Current assets |  | $ | 2 |  |
| Noncurrent assets |  | 53 |  |
| Total assets |  | $ | 55 |  |
| Current liabilities |  | $ | 6 |  |
| Noncurrent liabilities |  | 42 |  |
| Total liabilities |  | $ | 48 |  |

- removed (2019-02-01):
[0000833444-18-000044:note_history:72]
The Company did not have a significant variable interest in any other consolidated VIEs for the presented reporting periods.

- removed (2019-02-01):
[0000833444-18-000044:note_history:73]
Nonconsolidated VIEs

- removed (2019-02-01):
[0000833444-18-000044:note_history:74]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The VIEs are named as co-obligors under a third party debt agreement in the amount of $157 million, maturing in fiscal 2020, under which a VIE could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $38 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business. The Company is not considered to be the primary beneficiary of three of the entities as of June 30, 2018 and two of the entities as of September 30, 2017, as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balances of $42 million and $65 million at June 30, 2018 and September 30, 2017, respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.

- removed (2019-02-01):
[0000833444-18-000044:note_history:75]
At June 30, 2018, the Company held restricted cash of approximately $19 million, of which $10 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. At September 30, 2017, the Company held restricted cash of approximately $31 million, of which $22 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash restricted for payment of asbestos liabilities.

- removed (2019-02-01):
[0000833444-18-000044:note_history:76]
Effective July 1, 2017, the Company reorganized the reportable segments within its Building Technologies & Solutions business to align with its new management reporting structure and business activities. Prior to this reorganization, Building Technologies & Solutions was comprised of five reportable segments for financial reporting purposes: Systems and Service North America, Products North America, Asia, Rest of World and Tyco. As a result of this change, Building Technologies & Solutions is now comprised of four reportable segments for financial reporting purposes: Building Solutions North America, Building Solutions EMEA/LA, Building Solutions Asia Pacific and Global Products. Refer to Note 18, “Segment Information,” of the notes to consolidated financial statements for further information. The net sales and cost of sales split of products and systems versus services in the consolidated statements of income has also been revised for the Building Technologies & Solutions reorganization.

- removed (2019-02-01):
[0000833444-18-000044:note_history:77]
In March 2016, the FASB issued Accounting Standards Update ("ASU") No. 2016-09, "Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." During the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09. As a result, employee withholding taxes paid to taxing authorities for equity-based compensation transactions, previously classified as cash flows from operating activities, were reclassified to financing activities in the consolidated statements of cash flows for the nine months ended June 30, 2017. Refer to Note 2, "New Accounting Standards," of the notes to consolidated financial statements for further information.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-01):
[0000833444-19-000005:note_history:78]
The Company's net financing charges line item in the consolidated statements of income for the three months ended December 31, 2018 and 2017 contained the following components (in millions):
  (was, 2018-08-02, similarity 0.9485):
[0000833444-18-000044:note_history:78]
The Company's net financing charges line item in the consolidated statements of income for the three and nine months ended June 30, 2018 and 2017 contained the following components (in millions):

- changed (2019-02-01):
[0000833444-19-000005:note_history:79]
|  | Three Months EndedDecember 31, |
|  | 2018 |  | 2017 |
| Interest expense, net of capitalized interest costs | $ | 91 |  |  | $ | 102 |  |
| Banking fees and bond cost amortization | 6 |  |  | 7 |  |
| Interest income | (7 | ) |  | (7 | ) |
| Net foreign exchange results for financing activities | (5 | ) |  | — |  |
| Net financing charges | $ | 85 |  |  | $ | 102 |  |
  (was, 2018-08-02, similarity 0.7919):
[0000833444-18-000044:note_history:79]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Interest expense, net of capitalized interest costs | $ | 110 |  |  | $ | 115 |  |  | $ | 328 |  |  | $ | 343 |  |
| Banking fees and bond cost amortization | 14 |  |  | 14 |  |  | 41 |  |  | 55 |  |
| Interest income | (10 | ) |  | (4 | ) |  | (24 | ) |  | (16 | ) |
| Net foreign exchange results for financing activities | (13 | ) |  | (1 | ) |  | (13 | ) |  | (6 | ) |
| Net financing charges | $ | 101 |  |  | $ | 124 |  |  | $ | 332 |  |  | $ | 376 |  |

- removed (2019-02-01):
[0000833444-18-000044:note_history:80]
In October 2017, the Company completed the previously announced sale of its Scott Safety business to 3M. Net cash proceeds from the transaction of approximately $1.9 billion were used to repay a significant portion of the TSarl $4.0 billion of merger-related debt. In addition, in March 2018, the Company repaid $26 million in principal amount, plus accrued interest and in April 2018, the Company refinanced approximately $400 million in principal amount, plus accrued interest of the TSarl merger-related debt with commercial paper.

- removed (2019-02-01):
[0000833444-18-000044:note_history:81]
In March 2018, the Company increased the committed credit limit from $1.0 billion to $1.25 billion on TSarl's committed revolving credit facility scheduled to expire in August 2020. As of June 30, 2018, there were no draws on the facility.

- removed (2019-02-01):
[0000833444-18-000044:note_history:82]
In March 2018, the Company entered into a 364-day $250 million committed revolving credit facility scheduled to expire in March 2019. As of June 30, 2018, there were no draws on the facility.

- removed (2019-02-01):
[0000833444-18-000044:note_history:83]
In March 2018, a 364-day $150 million committed revolving credit facility expired. The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2019. As of June 30, 2018, there were no draws on the facility.

- removed (2019-02-01):
[0000833444-18-000044:note_history:84]
In February 2018, a 364-day $150 million committed revolving credit facility expired. The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2019. As of June 30, 2018, there were no draws on the facility.

- removed (2019-02-01):
[0000833444-18-000044:note_history:85]
In January 2018, a 364-day $250 million committed revolving credit facility expired. The Company entered into a new $200 million committed revolving credit facility scheduled to expire in January 2019. As of June 30, 2018, there were no draws on the facility.

- removed (2019-02-01):
[0000833444-18-000044:note_history:86]
In January 2018, the Company retired $67 million in principal amount, plus accrued interest, of its 3.75% fixed rate notes  that expired in January 2018.

- removed (2019-02-01):
[0000833444-18-000044:note_history:87]
In December 2017, the Company repaid a 364-day 150 million euro floating rate term loan, plus accrued interest, scheduled  to mature in September 2018.

- removed (2019-02-01):
[0000833444-18-000044:note_history:88]
In November 2017, the Company issued 750 million euro in principal amount of 0.0% senior unsecured fixed rate notes due in December 2020. Proceeds from the issuance were used to repay existing debt and for other general corporate purposes.

- removed (2019-02-01):
[0000833444-18-000044:note_history:89]
In November 2017, the Company retired $300 million in principal amount, plus accrued interest, of its 1.4% fixed rate notes that expired in November 2017.

- removed (2019-02-01):
[0000833444-18-000044:note_history:90]
Net financing charges for the nine month period ended June 30, 2017, included $17 million of transaction costs related primarily to the prior year debt exchange offer fees.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-02-01):
[0000833444-19-000005:note_history:91]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $43 million and $14 million, respectively, for the three months ended December 31, 2018; and $45 million and $9 million, respectively, for the three months ended December 31, 2017.
  (was, 2018-08-02, similarity 0.6111):
[0000833444-18-000044:note_history:91]
The net sales to and purchases from related parties included in the consolidated statements of income were $256 million and $45 million, respectively, for the three months ended June 30, 2018; and $251 million and $64 million, respectively, for the three months ended June 30, 2017. The net sales to and purchases from related parties included in the consolidated statements of income were $720 million and $137 million, respectively, for the nine months ended June 30, 2018; and $705 million and $165 million, respectively, for the nine months ended June 30, 2017.

- changed (2019-02-01):
[0000833444-19-000005:note_history:92]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position for continuing operations (in millions):
  (was, 2018-08-02, similarity 0.9297):
[0000833444-18-000044:note_history:92]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position (in millions):

- changed (2019-02-01):
[0000833444-19-000005:note_history:93]
|  |  | December 31, 2018 |  | September 30, 2018 |  |
| Receivable from related parties |  | $ | 41 |  |  | $ | 36 |  |
| Payable to related parties |  | 7 |  |  | 18 |  |
  (was, 2018-08-02, similarity 0.9655):
[0000833444-18-000044:note_history:93]
|  |  | June 30, 2018 |  | September 30, 2017 |  |
| Receivable from related parties |  | $ | 109 |  |  | $ | 108 |  |
| Payable to related parties |  | 51 |  |  | 50 |  |

- removed (2019-02-01):
[0000833444-18-000044:note_history:94]
The Company has also provided financial support to certain of its VIE's; see Note 1, "Financial Statements," of the notes to consolidated financial statements for additional information.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-02-01):
[0000833444-19-000005:note_history:95]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position for continuing operations (in millions):
  (was, 2018-08-02, similarity 0.9297):
[0000833444-18-000044:note_history:95]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position (in millions):

- changed (2019-02-01):
[0000833444-19-000005:note_history:96]
|  |  | December 31, 2018 |  | September 30, 2018 |  |
| Receivable from related parties |  | $ | 41 |  |  | $ | 36 |  |
| Payable to related parties |  | 7 |  |  | 18 |  |
  (was, 2018-08-02, similarity 0.9655):
[0000833444-18-000044:note_history:96]
|  |  | June 30, 2018 |  | September 30, 2017 |  |
| Receivable from related parties |  | $ | 109 |  |  | $ | 108 |  |
| Payable to related parties |  | 51 |  |  | 50 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-02-01):
[0000833444-19-000005:note_history:97]
The following table presents the Company's revenues disaggregated by segment and by product versus services revenue for the three months ended December 31, 2018 (in millions):

- added (2019-02-01):
[0000833444-19-000005:note_history:98]
|  |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,321 |  |  | $ | 795 |  |  | $ | 2,116 |  |
| Building Solutions EMEA/LA |  | 417 |  |  | 490 |  |  | 907 |  |
| Building Solutions Asia Pacific |  | 356 |  |  | 257 |  |  | 613 |  |
| Global Products |  | 1,828 |  |  | — |  |  | 1,828 |  |
| Total |  | $ | 3,922 |  |  | $ | 1,542 |  |  | $ | 5,464 |  |

- added (2019-02-01):
[0000833444-19-000005:note_history:99]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2018 (in millions):

- added (2019-02-01):
[0000833444-19-000005:note_history:100]
|  |  | Three Months EndedDecember 31, |
|  |  | 2018 |
| Building Management |  | $ | 281 |  |
| HVAC & Refrigeration Equipment |  | 1,285 |  |
| Specialty |  | 262 |  |
| Total Global Products |  | $ | 1,828 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-02-01):
[0000833444-19-000005:note_history:101]
Revenue Recognition

- added (2019-02-01):
[0000833444-19-000005:note_history:102]
The Company designs, manufactures and installs building products and systems around the world, including HVAC equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Company also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems.

- added (2019-02-01):
[0000833444-19-000005:note_history:103]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. Claims against customers are recognized as revenue upon settlement. The Company elected the practical expedient which permits the promised amount of consideration to not be adjusted for the effects of a significant financing component as at contract inception the Company expects to receive the payment within the twelve months of transfer of goods or services.

- added (2019-02-01):
[0000833444-19-000005:note_history:104]
The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term.

- added (2019-02-01):
[0000833444-19-000005:note_history:105]
The Company also sells certain HVAC and refrigeration products and services in bundled arrangements with multiple performance obligations, such as equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Company sells security monitoring systems that may have multiple performance obligations, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with sale of equipment and related installations are recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. The transaction price is allocated to each performance obligation based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach. Revenue recognized for security monitoring equipment and installation is limited to the lesser of their allocated amounts under the estimated selling price hierarchy or the non-contingent up-front consideration received at the time of installation, since collection of future amounts under the arrangement with the customer is contingent upon the delivery of monitoring and maintenance services. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized over time on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the contract.

- added (2019-02-01):
[0000833444-19-000005:note_history:106]
In all other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

- added (2019-02-01):
[0000833444-19-000005:note_history:107]
The Company considers the contractual consideration payable by the customer and assess variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar  sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

- added (2019-02-01):
[0000833444-19-000005:note_history:108]
Shipping and handling costs billed to customers are included in sales and the related costs are included in cost of sales when control transfers to the customer. The Company has elected to present amounts collected from customers for sales and other taxes net of the related amounts remitted.

- added (2019-02-01):
[0000833444-19-000005:note_history:109]
Disaggregated Revenue

- added (2019-02-01):
[0000833444-19-000005:note_history:110]
The following table presents the Company's revenues disaggregated by segment and by product versus services revenue for the three months ended December 31, 2018 (in millions):

- added (2019-02-01):
[0000833444-19-000005:note_history:111]
|  |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,321 |  |  | $ | 795 |  |  | $ | 2,116 |  |
| Building Solutions EMEA/LA |  | 417 |  |  | 490 |  |  | 907 |  |
| Building Solutions Asia Pacific |  | 356 |  |  | 257 |  |  | 613 |  |
| Global Products |  | 1,828 |  |  | — |  |  | 1,828 |  |
| Total |  | $ | 3,922 |  |  | $ | 1,542 |  |  | $ | 5,464 |  |

- added (2019-02-01):
[0000833444-19-000005:note_history:112]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2018 (in millions):

- added (2019-02-01):
[0000833444-19-000005:note_history:113]
|  |  | Three Months EndedDecember 31, |
|  |  | 2018 |
| Building Management |  | $ | 281 |  |
| HVAC & Refrigeration Equipment |  | 1,285 |  |
| Specialty |  | 262 |  |
| Total Global Products |  | $ | 1,828 |  |

- added (2019-02-01):
[0000833444-19-000005:note_history:114]
Contract Balances

- added (2019-02-01):
[0000833444-19-000005:note_history:115]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed and consist of unbilled receivable and costs in excess of billings. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract liabilities consist of deferred revenue. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

- added (2019-02-01):
[0000833444-19-000005:note_history:116]
The following table presents the location and amount of contract balances in the the Company's consolidated statements of financial position (in millions):

- added (2019-02-01):
[0000833444-19-000005:note_history:117]
|  |  | Location of contract balances |  | December 31, 2018 |  |  | October 1, 2018 |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,320 |  |  | $ | 1,261 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 73 |  |  | 85 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,378 | ) |  | (1,335 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (110 | ) |  | (113 | ) |
| Total |  |  |  | $ | (95 | ) |  | $ | (102 | ) |

- added (2019-02-01):
[0000833444-19-000005:note_history:118]
For the three months ended December 31, 2018, the Company recognized revenue of $712 million that was included in the beginning of period contract liability balance.

- added (2019-02-01):
[0000833444-19-000005:note_history:119]
Performance Obligations

- added (2019-02-01):
[0000833444-19-000005:note_history:120]
A performance obligation is a distinct good, service, or a bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

- added (2019-02-01):
[0000833444-19-000005:note_history:121]
Performance obligations are satisfied as of a point in time or over time. Performance obligations are supported by contracts with customers, providing a framework for the nature of the distinct goods, services, or bundle of goods and services. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of December 31, 2018, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $13.7 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company has applied the practical expedient for certain revenue streams to exclude the value of remaining performance obligations for contracts with an original expected duration of one year or less.

- added (2019-02-01):
[0000833444-19-000005:note_history:122]
Costs to Obtain or Fulfill a Contract

- added (2019-02-01):
[0000833444-19-000005:note_history:123]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist  primarily of sales commissions and bid/proposal costs. Costs to obtain or fulfill a contract are capitalized and amortized to revenue over the period of contract performance.

- added (2019-02-01):
[0000833444-19-000005:note_history:124]
As of December 31, 2018, the Company recorded the costs to obtain or fulfill a contract of $175 million, of which $91 million is recorded within other current assets and $84 million is recorded within other noncurrent assets in the consolidated statements of financial position.

- added (2019-02-01):
[0000833444-19-000005:note_history:125]
During the three months ended December 31, 2018, the Company recognized amortization expense of $35 million related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three months ended December 31, 2018.


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-02-01):
[0000833444-19-000005:note_history:126]
The Company designs, manufactures and installs building products and systems around the world, including HVAC equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Company also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems.

- added (2019-02-01):
[0000833444-19-000005:note_history:127]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. Claims against customers are recognized as revenue upon settlement. The Company elected the practical expedient which permits the promised amount of consideration to not be adjusted for the effects of a significant financing component as at contract inception the Company expects to receive the payment within the twelve months of transfer of goods or services.

- added (2019-02-01):
[0000833444-19-000005:note_history:128]
The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term.

- added (2019-02-01):
[0000833444-19-000005:note_history:129]
The Company also sells certain HVAC and refrigeration products and services in bundled arrangements with multiple performance obligations, such as equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Company sells security monitoring systems that may have multiple performance obligations, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with sale of equipment and related installations are recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. The transaction price is allocated to each performance obligation based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach. Revenue recognized for security monitoring equipment and installation is limited to the lesser of their allocated amounts under the estimated selling price hierarchy or the non-contingent up-front consideration received at the time of installation, since collection of future amounts under the arrangement with the customer is contingent upon the delivery of monitoring and maintenance services. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized over time on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the contract.

- added (2019-02-01):
[0000833444-19-000005:note_history:130]
In all other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

- added (2019-02-01):
[0000833444-19-000005:note_history:131]
The Company considers the contractual consideration payable by the customer and assess variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar  sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

- added (2019-02-01):
[0000833444-19-000005:note_history:132]
Shipping and handling costs billed to customers are included in sales and the related costs are included in cost of sales when control transfers to the customer. The Company has elected to present amounts collected from customers for sales and other taxes net of the related amounts remitted.
