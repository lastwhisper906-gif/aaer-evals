# JCI notes — 0000833444-19-000005


## jci:ComponentsOfNetFinancingChargesTableTextBlock

[0000833444-19-000005:notes:1]
The Company's net financing charges line item in the consolidated statements of income for the three months ended December 31, 2018 and 2017 contained the following components (in millions):

[0000833444-19-000005:notes:2]
|  | Three Months EndedDecember 31, |
|  | 2018 |  | 2017 |
| Interest expense, net of capitalized interest costs | $ | 91 |  |  | $ | 102 |  |
| Banking fees and bond cost amortization | 6 |  |  | 7 |  |
| Interest income | (7 | ) |  | (7 | ) |
| Net foreign exchange results for financing activities | (5 | ) |  | — |  |
| Net financing charges | $ | 85 |  |  | $ | 102 |  |


## jci:DisposalGroupIncludingDiscontinuedOperationsIncomeStatementDisclosuresTableTextBlock

[0000833444-19-000005:notes:3]
The following table summarizes the results of Power Solutions reclassified as discontinued operations for the three month periods ended December 31, 2018 and 2017 (in millions):

[0000833444-19-000005:notes:4]
|  | Three Months EndedDecember 31, |
|  | 2018 |  | 2017 |
| Net sales | $ | 2,427 |  |  | $ | 2,130 |  |
| Income from discontinued operations before income taxes | 390 |  |  | 368 |  |
| Provision for income taxes on discontinued operations | (127 | ) |  | (50 | ) |
| Income from discontinued operations attributable to noncontrolling interests, net of tax | (15 | ) |  | (13 | ) |
| Income from discontinued operations | $ | 248 |  |  | $ | 305 |  |


## jci:EquityAttributableToParentAndNoncontrollingInterestsTableTextBlock

[0000833444-19-000005:notes:5]
[same as prior period, unchanged from 0000833444-18-000044:notes:5]

[0000833444-19-000005:notes:6]
|  | Three Months Ended December 31, 2018 |  | Three Months Ended December 31, 2017 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, September 30, | $ | 21,164 |  |  | $ | 1,294 |  |  | $ | 22,458 |  |  | $ | 20,447 |  |  | $ | 920 |  |  | $ | 21,367 |  |
| Total comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 355 |  |  | 44 |  |  | 399 |  |  | 230 |  |  | 28 |  |  | 258 |  |
| Foreign currency translation adjustments | (127 | ) |  | 9 |  |  | (118 | ) |  | 58 |  |  | 16 |  |  | 74 |  |
| Realized and unrealized gains on derivatives | 1 |  |  | 1 |  |  | 2 |  |  | 1 |  |  | 1 |  |  | 2 |  |
| Other comprehensive income (loss) | (126 | ) |  | 10 |  |  | (116 | ) |  | 59 |  |  | 17 |  |  | 76 |  |
| Comprehensive income | 229 |  |  | 54 |  |  | 283 |  |  | 289 |  |  | 45 |  |  | 334 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (240 | ) |  | — |  |  | (240 | ) |  | (242 | ) |  | — |  |  | (242 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (43 | ) |  | (43 | ) |  | — |  |  | — |  |  | — |  |
| Repurchases of ordinary shares | (467 | ) |  | — |  |  | (467 | ) |  | (150 | ) |  | — |  |  | (150 | ) |
| Adoption of ASC 606 | (45 | ) |  | — |  |  | (45 | ) |  | — |  |  | — |  |  | — |  |
| Adoption of ASU 2016-16 | (546 | ) |  | — |  |  | (546 | ) |  | — |  |  | — |  |  | — |  |
| Adoption of ASU 2016-09 | — |  |  | — |  |  | — |  |  | 179 |  |  | — |  |  | 179 |  |
| Other, including options exercised | 7 |  |  | — |  |  | 7 |  |  | 12 |  |  | — |  |  | 12 |  |
| Ending balance, December 31 | $ | 20,102 |  |  | $ | 1,305 |  |  | $ | 21,407 |  |  | $ | 20,535 |  |  | $ | 965 |  |  | $ | 21,500 |  |


## jci:OffsettingDerivativeAssetsandLiabilitiesTableTextBlock

[0000833444-19-000005:notes:7]
[same as prior period, unchanged from 0000833444-18-000044:notes:8]

[0000833444-19-000005:notes:8]
|  |  | Fair Value of Assets |  | Fair Value of Liabilities |
|  |  | December 31, |  | September 30, |  | December 31, |  | September 30, |
|  |  | 2018 |  | 2018 |  | 2018 |  | 2018 |
| Gross amount recognized |  | $ | 64 |  |  | $ | 80 |  |  | $ | 3,152 |  |  | $ | 3,175 |  |
| Gross amount eligible for offsetting |  | (12 | ) |  | (12 | ) |  | (12 | ) |  | (12 | ) |
| Net amount |  | $ | 52 |  |  | $ | 68 |  |  | $ | 3,140 |  |  | $ | 3,163 |  |


## jci:ScheduleOfIntangibleAssetsTableTextBlock

[0000833444-19-000005:notes:9]
[same as prior period, unchanged from 0000833444-18-000044:notes:10]

[0000833444-19-000005:notes:10]
|  | December 31, 2018 |  | September 30, 2018 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Amortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,306 |  |  | $ | (279 | ) |  | $ | 1,027 |  |  | $ | 1,317 |  |  | $ | (251 | ) |  | $ | 1,066 |  |
| Customer relationships | 2,926 |  |  | (649 | ) |  | 2,277 |  |  | 2,941 |  |  | (599 | ) |  | 2,342 |  |
| Miscellaneous | 518 |  |  | (201 | ) |  | 317 |  |  | 458 |  |  | (185 | ) |  | 273 |  |
| Total amortized intangible assets | 4,750 |  |  | (1,129 | ) |  | 3,621 |  |  | 4,716 |  |  | (1,035 | ) |  | 3,681 |  |
| Unamortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,369 |  |  | — |  |  | 2,369 |  |  | 2,386 |  |  | — |  |  | 2,386 |  |
| Miscellaneous | 90 |  |  | — |  |  | 90 |  |  | 120 |  |  | — |  |  | 120 |  |
|  | 2,459 |  |  | — |  |  | 2,459 |  |  | 2,506 |  |  | — |  |  | 2,506 |  |
| Total intangible assets | $ | 7,209 |  |  | $ | (1,129 | ) |  | $ | 6,080 |  |  | $ | 7,222 |  |  | $ | (1,035 | ) |  | $ | 6,187 |  |


## jci:ScheduleofsharebasedpaymentawardperformancesharevaluationassumptionsTableTextBlock

[0000833444-19-000005:notes:11]
|  | Three Months Ended December 31, |
|  | 2018 |  | 2017 |
| Risk-free interest rate | 2.76% |  | 1.92% |
| Expected volatility of the Company’s stock | 22.9% |  | 21.7% |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-19-000005:notes:12]
Commitments and Contingencies

[0000833444-19-000005:notes:13]
Environmental Matters

[0000833444-19-000005:notes:14]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of December 31, 2018, reserves for environmental liabilities for continuing operations totaled $32 million, of which $13 million was recorded within other current liabilities and $19 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $37 million at September 30, 2018, of which $10 million was recorded within other current liabilities and $27 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At December 31, 2018 and September 30, 2018, the Company recorded conditional asset retirement obligations for continuing operations of $29 million.

[0000833444-19-000005:notes:15]
Asbestos Matters

[0000833444-19-000005:notes:16]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-19-000005:notes:17]
As of December 31, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $194 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $546 million, of which $55 million was recorded in other current liabilities and $491 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $352 million, of which $33 million was recorded in other current assets, and $319 million was recorded in other noncurrent assets. Assets included $20 million of cash and $243 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at December 31, 2018 was $89 million. As of September 30, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $173 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $550 million, of which $55 million was recorded in other current liabilities and $495 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $33 million was recorded in other current assets, and $344 million was recorded in other noncurrent assets. Assets included $6 million of cash and $281 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2018 was $90 million.

[0000833444-19-000005:notes:18]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-19-000005:notes:19]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-19-000005:notes:20]
Insurable Liabilities

[0000833444-19-000005:notes:21]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At December 31, 2018 and September 30, 2018, the insurable liabilities totaled $415 million and $417 million, respectively, of which $94 million and $95 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $299 million and $300 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at December 31, 2018 and September 30, 2018 were $26 million, of which $6 million was recorded within other current assets and $20 million was recorded within other noncurrent assets. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-19-000005:notes:22]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-19-000005:notes:23]
Two of our subsidiaries, Chemguard, Inc. ("Chemguard") and Tyco Fire Products L.P. ("Tyco Fire Products"), have been named, along with other defendant manufacturers, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated ("PFAS") compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued regulatory limits, however; while those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

[0000833444-19-000005:notes:24]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-19-000005:notes:25]
In September of 2018, the Company filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to the MDL.

[0000833444-19-000005:notes:26]
AFFF Putative Class Actions

[0000833444-19-000005:notes:27]
Chemguard and Tyco Fire Products are named in 20 putative class actions in federal and state courts in Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania and Washington.  Each of these cases have been transferred to the MDL. The following putative class actions were filed in fiscal year 2019:

[0000833444-19-000005:notes:28]
| • | Grubb v. The 3M Company et al., filed October 30, 2018 in the United States District Court, District of Delaware. |

[0000833444-19-000005:notes:29]
| • | County of Dutchess v. 3M Company et al., filed October 12, 2018 in the United States District Court, Southern District of New York. |

[0000833444-19-000005:notes:30]
| • | Battisti et al. v. The 3M Company et al., filed December 20, 2018 in the United States District Court, Middle District of Florida. |

[0000833444-19-000005:notes:31]
AFFF Individual or Mass Actions

[0000833444-19-000005:notes:32]
There are approximately 55 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases) and Pennsylvania (10 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York and 14 plaintiffs in Pennsylvania.  These matters have been transferred to the MDL.  The Company is also on notice of approximately 660 other possible individual product liability claims and 3 possible municipal claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, and, under Pennsylvania’s procedural rules, they may or may not result in lawsuits.

[0000833444-19-000005:notes:33]
AFFF Municipal Cases

[0000833444-19-000005:notes:34]
Chemguard and Tyco Fire Products are also defendants in 14 cases in federal and state courts involving municipal plaintiffs in Arizona, Florida, Massachusetts, New Jersey, New York and Ohio.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  All but two of these cases either have been transferred or identified for transfer to the MDL.   The following municipal actions were filed in fiscal year 2019:

[0000833444-19-000005:notes:35]
| • | Dutchess County v. The 3M Company et al. filed October 12, 2018 (and removed to the United States District Court, Southern District of New York) and styled as a class action. |

[0000833444-19-000005:notes:36]
| • | City of Dayton v. The 3M Company et al., filed October 3, 2018 in the United States District Court, Southern District of Ohio. |

[0000833444-19-000005:notes:37]
| • | City of Stuart v. the 3M Company et al., filed October 18, 2018 in the United States District Court, Southern District of Florida. |

[0000833444-19-000005:notes:38]
| • | City of Tucson and Town of Marana v. The 3M Company et al., filed November 8, 2018 in the Superior Court of the State of Arizona, County of Pima (removed to the United States District Court for the District of Arizona). |

[0000833444-19-000005:notes:39]
| • | New Jersey-American Water Company, Inc. v. The 3M Company et al., filed November 8, 2018 in the United States District Court for the District of New Jersey. |

[0000833444-19-000005:notes:40]
| • | Village of Farmingdale v. The 3M Company et al., filed December 19, 2018 in the Supreme Court of the State of New York, County of Nassau (removed to the United States District Court for the Eastern District of New York). |

[0000833444-19-000005:notes:41]
| • | Town of East Hampton v. The 3M Company et al., filed December 28, 2018 in the Supreme Court of the State of New York, County of Suffolk. |

[0000833444-19-000005:notes:42]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base. In addition, three water districts in Pennsylvania, Horsham Water and Sewer Authority, Warminster Municipal Authority, and Warrington Township have filed praecipes for summons against Chemguard and Tyco Fire Products and other AFFF manufacturers relating to alleged PFOS and PFOA contamination.  These praecipes are not active suits, but have the effect of tolling the statute of limitations.

[0000833444-19-000005:notes:43]
State Attorneys General Litigation related to AFFF

[0000833444-19-000005:notes:44]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. 3M Co., No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and identified for transfer to the MDL.

[0000833444-19-000005:notes:45]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. 3M Co., No. G-4801-CI-021804752 -000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio.  The lawsuit seeks to recover costs and natural resource damages associated with the contamination.  This lawsuit has been removed to the United States District Court for the Northern District of Ohio and identified for transfer to the MDL.

[0000833444-19-000005:notes:46]
AFFF Matters Related to the Tyco Fire Products Fire Technology Center in Marinette, Wisconsin

[0000833444-19-000005:notes:47]
Tyco Fire Products, in coordination with the Wisconsin Department of Natural Resources ("WDNR") and the Wisconsin Department of Health Services ("DHS"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin.  In connection with the assessment, PFOS and PFOA have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC.  Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working closely with WDNR and DHS to develop interim measures to remove these compounds from certain areas where they have been detected.

[0000833444-19-000005:notes:48]
Tyco Fire Products and its subsidiary Chemguard are defendants in two lawsuits in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFOA/PFOS contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and will identify it for transfer to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater.

[0000833444-19-000005:notes:49]
The Company is vigorously defending the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

[0000833444-19-000005:notes:50]
Other Matters

[0000833444-19-000005:notes:51]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000833444-19-000005:notes:52]
The following table presents the location and amount of contract balances in the the Company's consolidated statements of financial position (in millions):

[0000833444-19-000005:notes:53]
|  |  | Location of contract balances |  | December 31, 2018 |  |  | October 1, 2018 |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,320 |  |  | $ | 1,261 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 73 |  |  | 85 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,378 | ) |  | (1,335 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (110 | ) |  | (113 | ) |
| Total |  |  |  | $ | (95 | ) |  | $ | (102 | ) |


## us-gaap:DebtDisclosureTextBlock

[0000833444-19-000005:notes:54]
Debt and Financing Arrangements

[0000833444-19-000005:notes:55]
Net Financing Charges


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-19-000005:notes:56]
[same as prior period, unchanged from 0000833444-18-000044:notes:73]

[0000833444-19-000005:notes:57]
[same as prior period, unchanged from 0000833444-18-000044:notes:74]

[0000833444-19-000005:notes:58]
[same as prior period, unchanged from 0000833444-18-000044:notes:75]

[0000833444-19-000005:notes:59]
The Company has global operations and participates in the foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three months ended December 31, 2018 and 2017.

[0000833444-19-000005:notes:60]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of lead, copper, tin, aluminum and polypropylene in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As cash flow hedges, the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions, typically sales, occur and affect earnings. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in commodity prices during the three months ended December 31, 2018 and 2017.

[0000833444-19-000005:notes:61]
The Company had the following outstanding contracts to hedge forecasted commodity purchases for continuing and discontinued operations (in metric tons):

[0000833444-19-000005:notes:62]
|  |  | Volume Outstanding as of |
| Commodity |  | December 31, 2018 |  | September 30, 2018 |
| Copper |  | 3,175 |  |  | 3,175 |  |
| Polypropylene |  | 29,482 |  |  | 15,868 |  |
| Lead |  | 29,016 |  |  | 49,066 |  |
| Aluminum |  | 3,955 |  |  | 3,381 |  |
| Tin |  | 3,588 |  |  | 3,076 |  |

[0000833444-19-000005:notes:63]
[same as prior period, unchanged from 0000833444-18-000044:notes:82]

[0000833444-19-000005:notes:64]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company’s net investments globally. At December 31, 2018, the Company had one billion euro, 750 million euro, 423 million euro and 58 million euro in bonds and a 215 million euro term loan designated as net investment hedges in the Company's net investment in Europe and 35 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan. Also, at September 30, 2018, the Company had one billion euro, 750 million euro, 423 million euro and 58 million euro in bonds and a 215 million euro term loan designated as net investment hedges in the Company's net investment in Europe and 35 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan.

[0000833444-19-000005:notes:65]
[same as prior period, unchanged from 0000833444-18-000044:notes:84]

[0000833444-19-000005:notes:66]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount.  As of December 31, 2018, the Company hedged approximately 1.6 million shares of its ordinary shares, which have a cost basis of $66 million. As of September 30, 2018, the Company hedged approximately 1.8 million shares of its ordinary shares, which have a cost basis of $73 million.

[0000833444-19-000005:notes:67]
[same as prior period, unchanged from 0000833444-18-000044:notes:86]

[0000833444-19-000005:notes:68]
[same as prior period, unchanged from 0000833444-18-000044:notes:87]

[0000833444-19-000005:notes:69]
[same as prior period, unchanged from 0000833444-18-000044:notes:88]

[0000833444-19-000005:notes:70]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | December 31, |  | September 30, |  | December 31, |  | September 30, |
|  | 2018 |  | 2018 |  | 2018 |  | 2018 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 9 |  |  | $ | 6 |  |  | $ | 7 |  |  | $ | 10 |  |
| Commodity derivatives | — |  |  | 1 |  |  | — |  |  | — |  |
| Assets held for sale |  |  |  |  |  |  |  |
| Commodity derivatives | 1 |  |  | — |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 47 |  |  | 63 |  |
| Total assets | $ | 10 |  |  | $ | 7 |  |  | $ | 54 |  |  | $ | 73 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 15 |  |  | $ | 10 |  |  | $ | 9 |  |  | $ | 2 |  |
| Commodity derivatives | 2 |  |  | 2 |  |  | — |  |  | — |  |
| Liabilities held for sale |  |  |  |  |  |  |  |
| Commodity derivatives | 11 |  |  | 12 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,115 |  |  | 3,149 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,143 |  |  | $ | 3,173 |  |  | $ | 9 |  |  | $ | 2 |  |

[0000833444-19-000005:notes:71]
[same as prior period, unchanged from 0000833444-18-000044:notes:90]

[0000833444-19-000005:notes:72]
[same as prior period, unchanged from 0000833444-18-000044:notes:91]

[0000833444-19-000005:notes:73]
The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position. Collateral is generally not required of the Company or the counterparties under the master netting agreements. As of December 31, 2018 and September 30, 2018, no cash collateral was received or pledged under the master netting agreements.

[0000833444-19-000005:notes:74]
[same as prior period, unchanged from 0000833444-18-000044:notes:93]

[0000833444-19-000005:notes:75]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the three months ended December 31, 2018 and 2017 (in millions):

[0000833444-19-000005:notes:76]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended December 31, |
|  | 2018 |  | 2017 |
| Foreign currency exchange derivatives |  | $ | — |  |  | $ | 6 |  |
| Commodity derivatives |  | (6 | ) |  | 3 |  |
| Total |  | $ | (6 | ) |  | $ | 9 |  |

[0000833444-19-000005:notes:77]
The following tables present the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the three months ended December 31, 2018 and 2017 (in millions):

[0000833444-19-000005:notes:78]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended December 31, |
|  | 2018 |  | 2017 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | — |  |  | $ | 2 |  |
| Foreign currency exchange derivatives |  | Income (loss) from discontinued operations |  | 1 |  |  | — |  |
| Commodity derivatives |  | Cost of sales |  | (2 | ) |  | 2 |  |
| Commodity derivatives |  | Income (loss) from discontinued operations |  | (5 | ) |  | 3 |  |
| Total |  |  |  | $ | (6 | ) |  | $ | 7 |  |

[0000833444-19-000005:notes:79]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the three months ended December 31, 2018 and 2017 (in millions):

[0000833444-19-000005:notes:80]
|  |  |  |  | Amount of Gain (Loss) Recognized inIncome on Derivative |
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months EndedDecember 31, |
|  | 2018 |  | 2017 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (4 | ) |  | $ | 2 |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | (21 | ) |  | 3 |  |
| Foreign currency exchange derivatives |  | Income (loss) from discontinued operations |  | 26 |  |  | 3 |  |
| Equity swap |  | Selling, general and administrative |  | (9 | ) |  | (2 | ) |
| Total |  |  |  | $ | (8 | ) |  | $ | 6 |  |

[0000833444-19-000005:notes:81]
The pre-tax gains (losses) recorded in CTA within other comprehensive income (loss) related to net investment hedges were $34 million and $(36) million for the three months ended December 31, 2018 and 2017, respectively. For the three months ended December 31, 2018 and 2017, no gains or losses were reclassified from CTA into income for the Company’s outstanding net investment hedges.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000833444-19-000005:notes:82]
The following table presents the Company's revenues disaggregated by segment and by product versus services revenue for the three months ended December 31, 2018 (in millions):

[0000833444-19-000005:notes:83]
|  |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,321 |  |  | $ | 795 |  |  | $ | 2,116 |  |
| Building Solutions EMEA/LA |  | 417 |  |  | 490 |  |  | 907 |  |
| Building Solutions Asia Pacific |  | 356 |  |  | 257 |  |  | 613 |  |
| Global Products |  | 1,828 |  |  | — |  |  | 1,828 |  |
| Total |  | $ | 3,922 |  |  | $ | 1,542 |  |  | $ | 5,464 |  |

[0000833444-19-000005:notes:84]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2018 (in millions):

[0000833444-19-000005:notes:85]
|  |  | Three Months EndedDecember 31, |
|  |  | 2018 |
| Building Management |  | $ | 281 |  |
| HVAC & Refrigeration Equipment |  | 1,285 |  |
| Specialty |  | 262 |  |
| Total Global Products |  | $ | 1,828 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-19-000005:notes:86]
[same as prior period, unchanged from 0000833444-18-000044:notes:103]

[0000833444-19-000005:notes:87]
During September 2016, the Board of Directors of the Company approved amendments to the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based compensation awards. The Compensation Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter. A summary of the stock-based awards granted during the three month periods ended December 31, 2018 and 2017 is presented below:

[0000833444-19-000005:notes:88]
|  | Three Months Ended December 31, |
|  | 2018 |  | 2017 |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  | Number Granted |  | Weighted Average Grant Date Fair Value |
| Stock options | 1,713,733 |  |  | $ | 5.56 |  |  | 1,355,595 |  |  | $ | 7.05 |  |
| Restricted stock/units | 2,143,457 |  |  | 33.39 |  |  | 2,051,817 |  |  | 37.36 |  |
| Performance shares | 574,716 |  |  | 36.28 |  |  | 496,478 |  |  | 36.31 |  |

[0000833444-19-000005:notes:89]
[same as prior period, unchanged from 0000833444-18-000044:notes:106]

[0000833444-19-000005:notes:90]
[same as prior period, unchanged from 0000833444-18-000044:notes:107]

[0000833444-19-000005:notes:91]
The fair value of each option is estimated on the date of grant using a Black-Scholes option valuation model that uses the assumptions noted in the following table. The expected life of options represents the period of time that options granted are expected to be outstanding, assessed separately for executives and non-executives. The risk-free interest rate for periods during the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant. For fiscal 2019 and fiscal 2018, the expected volatility is based on the historical volatility of the Company’s stock since October 2016 blended with the historical volatility of certain peer companies’ stock prior to October 2016 over the most recent period corresponding to the expected life as of the grant date. The expected dividend yield is based on the expected annual dividend as a percentage of the market value of the Company’s ordinary shares as of the grant date. The Company uses historical data to estimate option exercises and employee terminations within the valuation model.

[0000833444-19-000005:notes:92]
|  | Three Months Ended December 31, |
|  | 2018 |  | 2017 |
| Expected life of option (years) | 6.4 |  | 6.5 |
| Risk-free interest rate | 2.77% |  | 2.28% |
| Expected volatility of the Company’s stock | 21.8% |  | 23.7% |
| Expected dividend yield on the Company’s stock | 3.29% |  | 2.78% |

[0000833444-19-000005:notes:93]
[same as prior period, unchanged from 0000833444-18-000044:notes:112]

[0000833444-19-000005:notes:94]
[same as prior period, unchanged from 0000833444-18-000044:notes:113]

[0000833444-19-000005:notes:95]
[same as prior period, unchanged from 0000833444-18-000044:notes:114]

[0000833444-19-000005:notes:96]
[same as prior period, unchanged from 0000833444-18-000044:notes:115]

[0000833444-19-000005:notes:97]
The fair value of each PSU is estimated on the date of grant with the use of a Monte Carlo simulation that uses the assumptions noted in the following table. The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant. For fiscal 2019 and fiscal 2018, the expected volatility is based on the historical volatility of the Company’s stock after October 2016 blended with the historical volatility of certain peer companies’ stock prior to October 2016 over the most recent three-year period as of the grant date.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-19-000005:notes:98]
[same as prior period, unchanged from 0000833444-18-000044:notes:117]

[0000833444-19-000005:notes:99]
On November 13, 2018, the Company entered into a Stock and Asset Purchase Agreement (“Purchase Agreement”) with BCP Acquisitions LLC (“Purchaser”). The Purchaser is a newly-formed entity controlled by investment funds managed by Brookfield Capital Partners LLC. Pursuant to the Purchase Agreement, on the terms and subject to the conditions therein, the Company has agreed to sell, and Purchaser has agreed to acquire, the Company’s Power Solutions business for a purchase price of $13.2 billion. Net cash proceeds are expected to be $11.4 billion after tax and transaction-related expenses. The transaction is expected to close by June 30, 2019, subject to customary closing conditions and required regulatory approvals.

[0000833444-19-000005:notes:100]
During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation and, as a result, Power Solutions' historical financial results are reflected in the Company's consolidated financial statements as a discontinued operation, and assets and liabilities were retrospectively reclassified as assets and liabilities held for sale. The Company did not allocate any general corporate overhead to discontinued operations.

[0000833444-19-000005:notes:101]
For the three months ended December 31, 2018, the income from discontinued operations before income taxes included transaction costs of $28 million and a favorable impact of $32 million for ceasing depreciation and amortization expense as the business was held for sale. The increase in net sales for the three months ended December 31, 2018 was primarily due to the impact of the adoption of the New Revenue Standard. Refer to Note 2, "New Accounting Standards," of the notes to consolidated financial statements for further information.

[0000833444-19-000005:notes:102]
For the three months ended December 31, 2018, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to establishment of a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries related to the planned divestiture of the business and tax rate differentials. For the three months ended December 31, 2017, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to tax rate differentials.

[0000833444-19-000005:notes:103]
[same as prior period, unchanged from 0000833444-18-000044:notes:123]

[0000833444-19-000005:notes:104]
The following table summarizes the carrying value of the Power Solutions assets and liabilities held for sale at December 31, 2018 and September 30, 2018 (in millions):

[0000833444-19-000005:notes:105]
|  | December 31, 2018 |  | September 30, 2018 |
| Cash | $ | 17 |  |  | $ | 15 |  |
| Accounts receivable - net | 1,466 |  |  | 1,443 |  |
| Inventories | 1,370 |  |  | 1,405 |  |
| Other current assets | 189 |  |  | 152 |  |
| Assets held for sale | $ | 3,042 |  |  | $ | 3,015 |  |
| Property, plant and equipment - net | $ | 2,900 |  |  | $ | 2,871 |  |
| Goodwill | 1,085 |  |  | 1,092 |  |
| Other intangible assets - net | 156 |  |  | 161 |  |
| Investments in partially-owned affiliates | 463 |  |  | 453 |  |
| Other noncurrent assets | 555 |  |  | 611 |  |
| Noncurrent assets held for sale | $ | 5,159 |  |  | $ | 5,188 |  |
| Short-term debt | $ | 7 |  |  | $ | 9 |  |
| Current portion of long-term debt | 23 |  |  | 25 |  |
| Accounts payable | 1,048 |  |  | 1,237 |  |
| Accrued compensation and benefits | 94 |  |  | 125 |  |
| Deferred revenue | 40 |  |  | — |  |
| Other current liabilities | 424 |  |  | 395 |  |
| Liabilities held for sale | $ | 1,636 |  |  | $ | 1,791 |  |
| Long-term debt | $ | 30 |  |  | $ | 31 |  |
| Pension and postretirement benefits | 101 |  |  | 101 |  |
| Other noncurrent liabilities | 70 |  |  | 75 |  |
| Noncurrent liabilities held for sale | $ | 201 |  |  | $ | 207 |  |


## us-gaap:EarningsPerShareTextBlock

[0000833444-19-000005:notes:106]
[same as prior period, unchanged from 0000833444-18-000044:notes:128]

[0000833444-19-000005:notes:107]
[same as prior period, unchanged from 0000833444-18-000044:notes:129]

[0000833444-19-000005:notes:108]
[same as prior period, unchanged from 0000833444-18-000044:notes:130]

[0000833444-19-000005:notes:109]
|  | Three Months EndedDecember 31, |
|  | 2018 |  | 2017 |
| Income Available to Ordinary Shareholders |  |  |  |
| Income (loss) from continuing operations | $ | 107 |  |  | $ | (75 | ) |
| Income from discontinued operations | 248 |  |  | 305 |  |
| Basic and diluted income available to shareholders | $ | 355 |  |  | $ | 230 |  |
| Weighted Average Shares Outstanding |  |  |  |
| Basic weighted average shares outstanding | 921.6 |  |  | 926.1 |  |
| Effect of dilutive securities: |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 3.6 |  |  | — |  |
| Diluted weighted average shares outstanding | 925.2 |  |  | 926.1 |  |
| Antidilutive Securities |  |  |  |
| Options to purchase shares | 2.7 |  |  | — |  |

[0000833444-19-000005:notes:110]
For the three months ended December 31, 2017, the total weighted average of potential dilutive shares due to stock options, unvested restricted stock and unvested performance share awards was 7.2 million. However, these items were not included in the computation of diluted EPS for the three months ended December 31, 2017, since to do so would decrease the loss per share for continuing operations.

[0000833444-19-000005:notes:111]
During the three months ended December 31, 2018 and 2017, the Company declared dividends of $0.26 per share. The Company paid all dividends in the month subsequent to the end of each fiscal quarter.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-19-000005:notes:112]
[same as prior period, unchanged from 0000833444-18-000044:notes:133]

[0000833444-19-000005:notes:113]
[same as prior period, unchanged from 0000833444-18-000044:notes:134]

[0000833444-19-000005:notes:114]
[same as prior period, unchanged from 0000833444-18-000044:notes:135]

[0000833444-19-000005:notes:115]
[same as prior period, unchanged from 0000833444-18-000044:notes:136]

[0000833444-19-000005:notes:116]
[same as prior period, unchanged from 0000833444-18-000044:notes:137]

[0000833444-19-000005:notes:117]
[same as prior period, unchanged from 0000833444-18-000044:notes:138]

[0000833444-19-000005:notes:118]
[same as prior period, unchanged from 0000833444-18-000044:notes:139]

[0000833444-19-000005:notes:119]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of December 31, 2018 and September 30, 2018 (in millions):

[0000833444-19-000005:notes:120]
|  | Fair Value Measurements Using: |
|  | Total as of December 31, 2018 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 16 |  |  | $ | — |  |  | $ | 16 |  |  | $ | — |  |
| Assets held for sale |  |  |  |  |  |  |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Investments in marketable common stock | 1 |  |  | 1 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 92 |  |  | 92 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 145 |  |  | 145 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 98 |  |  | 98 |  |  | — |  |  | — |  |
| Equity swap | 47 |  |  | — |  |  | 47 |  |  | — |  |
| Noncurrent assets held for sale |  |  |  |  |  |  |  |
| Investments in marketable common stock | 2 |  |  | 2 |  |  | — |  |  | — |  |
| Total assets | $ | 402 |  |  | $ | 338 |  |  | $ | 64 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 24 |  |  | $ | — |  |  | $ | 24 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Liabilities held for sale |  |  |  |  |  |  |  |
| Commodity derivatives | 11 |  |  | — |  |  | 11 |  |  | — |  |
| Total liabilities | $ | 37 |  |  | $ | — |  |  | $ | 37 |  |  | $ | — |  |

[0000833444-19-000005:notes:121]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2018 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 16 |  |  | $ | — |  |  | $ | 16 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Exchange traded funds (fixed income)1 | 14 |  |  | 14 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Investments in marketable common stock | 1 |  |  | 1 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 100 |  |  | 100 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 148 |  |  | 148 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 119 |  |  | 119 |  |  | — |  |  | — |  |
| Equity swap | 63 |  |  | — |  |  | 63 |  |  | — |  |
| Noncurrent assets held for sale |  |  |  |  |  |  |  |
| Investments in marketable common stock | 3 |  |  | 3 |  |  | — |  |  | — |  |
| Total assets | $ | 465 |  |  | $ | 385 |  |  | $ | 80 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Liabilities held for sale |  |  |  |  |  |  |  |
| Commodity derivatives | 12 |  |  | — |  |  | 12 |  |  | — |  |
| Total liabilities | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |

[0000833444-19-000005:notes:122]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 20, "Commitments and Contingencies," of the notes to consolidated financial statements for further details.

[0000833444-19-000005:notes:123]
[same as prior period, unchanged from 0000833444-18-000044:notes:144]

[0000833444-19-000005:notes:124]
[same as prior period, unchanged from 0000833444-18-000044:notes:145]

[0000833444-19-000005:notes:125]
[same as prior period, unchanged from 0000833444-18-000044:notes:146]

[0000833444-19-000005:notes:126]
[same as prior period, unchanged from 0000833444-18-000044:notes:147]

[0000833444-19-000005:notes:127]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. During the three months ended December 31, 2018, the Company recognized unrealized losses of $9 million in the consolidated statements of income on these investments that were still held as of December 31, 2018, where they offset unrealized gains on the related deferred compensation plan liability.

[0000833444-19-000005:notes:128]
Investments in marketable common stock and exchange traded funds:  Investments in marketable common stock and exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. During the three months ended December 31, 2018, the Company recognized unrealized losses of $22 million in the consolidated statements of income on these investments that were still held as of December 31, 2018, of which $21 million related to restricted investments. Refer to Note 20, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-19-000005:notes:129]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The fair value of long-term debt was $9.5 billion and $9.6 billion at December 31, 2018 and September 30, 2018, respectively. The fair value of public debt was $8.5 billion and $8.6 billion, at December 31, 2018 and September 30, 2018, respectively, which was determined primarily using market quotes classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was $1.0 billion at December 31, 2018 and September 30, 2018, which was determined based on quoted market prices for similar instruments classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-19-000005:notes:130]
[same as prior period, unchanged from 0000833444-18-000044:notes:151]

[0000833444-19-000005:notes:131]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the three month period ended December 31, 2018 were as follows (in millions):

[0000833444-19-000005:notes:132]
|  |  |  | Business Acquisitions |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  | December 31, |
|  | 2018 |  |  |  | 2018 |
| Building Solutions North America | $ | 9,603 |  |  | $ | — |  |  | $ | (31 | ) |  | $ | 9,572 |  |
| Building Solutions EMEA/LA | 1,950 |  |  | — |  |  | (37 | ) |  | 1,913 |  |
| Building Solutions Asia Pacific | 1,235 |  |  | — |  |  | — |  |  | 1,235 |  |
| Global Products | 5,593 |  |  | 9 |  |  | (31 | ) |  | 5,571 |  |
| Total | $ | 18,381 |  |  | $ | 9 |  |  | $ | (99 | ) |  | $ | 18,291 |  |

[0000833444-19-000005:notes:133]
At September 30, 2018, accumulated goodwill impairment charges included $47 million related to the Building Solutions EMEA/LA  - Latin America reporting unit.

[0000833444-19-000005:notes:134]
Amortization of other intangible assets included within continuing operations for the three month periods ended December 31, 2018 and 2017 was $97 million and $92 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2020, 2021, 2022, 2023 and 2024 will be approximately $388 million, $385 million, $376 million, $362 million and $348 million per year, respectively.


## us-gaap:GuaranteesTextBlock

[0000833444-19-000005:notes:135]
[same as prior period, unchanged from 0000833444-18-000044:notes:156]

[0000833444-19-000005:notes:136]
[same as prior period, unchanged from 0000833444-18-000044:notes:157]

[0000833444-19-000005:notes:137]
[same as prior period, unchanged from 0000833444-18-000044:notes:158]

[0000833444-19-000005:notes:138]
The Company’s product warranty liability for continuing operations is recorded in the consolidated statements of financial position in deferred revenue or other current liabilities if the warranty is less than one year and in other noncurrent liabilities if the warranty extends longer than one year.

[0000833444-19-000005:notes:139]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations, including extended warranties for which deferred revenue is recorded, for the three months ended December 31, 2018 and 2017 were as follows (in millions):

[0000833444-19-000005:notes:140]
|  | Three Months EndedDecember 31, |
|  | 2018 |  | 2017 |
| Balance at beginning of period | $ | 315 |  |  | $ | 323 |  |
| Accruals for warranties issued during the period | 29 |  |  | 24 |  |
| Accruals related to pre-existing warranties | (5 | ) |  | (1 | ) |
| Settlements made (in cash or in kind) during the period | (30 | ) |  | (26 | ) |
| Currency translation | 1 |  |  | 2 |  |
| Balance at end of period | $ | 310 |  |  | $ | 322 |  |

[0000833444-19-000005:notes:141]
As a result of the Tyco merger in the fourth quarter of fiscal 2016, the Company recorded, as part of the acquired liabilities of Tyco, $290 million of post sale contingent tax indemnification liabilities. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. At December 31, 2018 and September 30, 2018, the Company recorded liabilities of $255 million. Of the $255 million, $235 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0000833444-19-000005:notes:142]
[same as prior period, unchanged from 0000833444-18-000044:notes:163]

[0000833444-19-000005:notes:143]
[same as prior period, unchanged from 0000833444-18-000044:notes:164]

[0000833444-19-000005:notes:144]
In the first quarter of fiscal 2018, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2018. As a result, the Company reviewed the long-lived assets for impairment and recorded $28 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $23 million related to the Global Products segment and $5 million related to Corporate assets. In addition, the Company recorded $2 million of asset impairments within discontinued operations related to the Power Solutions segment in the first quarter of fiscal 2018. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-19-000005:notes:145]
At December 31, 2018 and 2017, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-19-000005:notes:146]
[same as prior period, unchanged from 0000833444-18-000044:notes:168]

[0000833444-19-000005:notes:147]
[same as prior period, unchanged from 0000833444-18-000044:notes:169]

[0000833444-19-000005:notes:148]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended December 31, 2018, the Company's effective tax rate for continuing operations was 44% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments as a result of tax law changes and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the three months ended December 31, 2017, the Company's effective tax rate for continuing operations was 128% and was higher than the statutory tax rate of 12.5% primarily due to the discrete net impacts of U.S. Tax Reform, the tax impact of the divestiture of the Scott Safety business and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives and tax audit closures.

[0000833444-19-000005:notes:149]
[same as prior period, unchanged from 0000833444-18-000044:notes:171]

[0000833444-19-000005:notes:150]
[same as prior period, unchanged from 0000833444-18-000044:notes:172]

[0000833444-19-000005:notes:151]
In the first quarter of fiscal 2019, as a result of changes to U.S. tax law, the Company recorded a discrete tax charge of $76 million related to valuation allowance on certain U.S. deferred tax assets.

[0000833444-19-000005:notes:152]
[same as prior period, unchanged from 0000833444-18-000044:notes:173]

[0000833444-19-000005:notes:153]
At September 30, 2018, the Company had gross tax effected unrecognized tax benefits of $2,358 million, of which $2,225 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2018 was approximately $119 million (net of tax benefit). The interest and penalties accrued during the three months ended December 31, 2018 and 2017 were immaterial. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-19-000005:notes:154]
[same as prior period, unchanged from 0000833444-18-000044:notes:175]

[0000833444-19-000005:notes:155]
In the U.S., fiscal years 2015 through 2016 are currently under exam by the Internal Revenue Service ("IRS") for certain legal entities. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions:

[0000833444-19-000005:notes:156]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2017 |
| China |  | 2008 - 2016 |
| France |  | 2010 - 2012; 2015 - 2016 |
| Germany |  | 2007 - 2016 |
| United Kingdom |  | 2012 - 2015 |

[0000833444-19-000005:notes:157]
[same as prior period, unchanged from 0000833444-18-000044:notes:178]

[0000833444-19-000005:notes:158]
On December 22, 2017, the “Tax Cuts and Jobs Act” (H.R. 1) was enacted and significantly revised U.S. corporate income tax by, among other things, lowering corporate income tax rates, imposing a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries, and implementing a territorial tax system and various base erosion minimum tax provisions.

[0000833444-19-000005:notes:159]
In connection with the Company’s analysis of the impact of the U.S. tax law changes, the Company recorded a provisional net tax charge of $108 million during fiscal 2018 consistent with guidance prescribed by Staff Accounting Bulletin 118. This provisional net tax charge arises from a benefit of $108 million due to the remeasurement of U.S. deferred tax assets and liabilities, offset by the Company’s tax charge relating to the one-time transition tax on deemed repatriated earnings, inclusive of all relevant taxes, of $216 million. The Company’s estimated benefit of the remeasurement of U.S. deferred tax assets and liabilities increased from $101 million as of December 31, 2017 to $108 million as of September 30, 2018 due to calculation refinement of the Company’s estimated impact. The Company remeasured certain deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future, which is generally 21% or the blended fiscal 2018 rate of 24.5%. The Company’s tax charge for transition tax decreased from $305 million as of December 31, 2017 to $216 million as of September 30, 2018 due to further analysis of the Company’s post-1986 non-U.S. earnings and profits (“E&P”) previously deferred from U.S. federal taxation and refinement of the estimated impact of tax law changes. In the first quarter of fiscal 2019, the Company completed its analysis of all enactment-date income tax effects of the U.S. tax law change with no further adjustment to the provisional amounts recorded as of September 30, 2018.

[0000833444-19-000005:notes:160]
During the three months ended December 31, 2018 and 2017, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-19-000005:notes:161]
[same as prior period, unchanged from 0000833444-18-000044:notes:185]

[0000833444-19-000005:notes:162]
[same as prior period, unchanged from 0000833444-18-000044:notes:188]

[0000833444-19-000005:notes:163]
In the first quarter of fiscal 2018, the Company recorded $154 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $23 million tax benefit, which reflects the Company’s current tax position in these jurisdictions.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-19-000005:notes:164]
[same as prior period, unchanged from 0000833444-18-000044:notes:202]

[0000833444-19-000005:notes:165]
[same as prior period, unchanged from 0000833444-18-000044:notes:203]

[0000833444-19-000005:notes:166]
|  | December 31, 2018 |  | September 30, 2018 |
| Raw materials and supplies | $ | 647 |  |  | $ | 606 |  |
| Work-in-process | 183 |  |  | 155 |  |
| Finished goods | 1,197 |  |  | 1,058 |  |
| Inventories | $ | 2,027 |  |  | $ | 1,819 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-19-000005:notes:167]
[same as prior period, unchanged from 0000833444-18-000044:notes:207]

[0000833444-19-000005:notes:168]
In the first quarter of fiscal 2019, the Company completed an acquisition for a purchase price of $13 million, all of which was paid as of December 31, 2018. The acquisition was not material to the Company's consolidated financial statements. In connection with the acquisition, the Company recorded goodwill of $9 million within the Global Products segment.

[0000833444-19-000005:notes:169]
In the first quarter of fiscal 2019, the Company completed certain divestitures within the Global Products business. The combined selling price was $6 million, all of which was received as of December 31, 2018. The divestitures in the aggregate were not material to the Company's consolidated financial statements.

[0000833444-19-000005:notes:170]
In the first quarter of fiscal 2018, the Company completed the sale of its Scott Safety business to 3M Company. The selling price, net of cash divested, was $2.0 billion, all of which was received as of December 31, 2017. In connection with the sale, the Company recorded a pre-tax gain of $114 million within selling, general and administrative expenses in the consolidated statements of income and reduced goodwill in the consolidated statements of financial position by $1.2 billion. The gain, net of tax, recorded was $84 million. Net cash proceeds from the transaction of approximately $1.9 billion were used to repay a significant portion of the Tyco International Holding S.a.r.L.'s ("TSarl") $4.0 billion of merger-related debt.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-19-000005:notes:171]
[same as prior period, unchanged from 0000833444-18-000044:notes:215]

[0000833444-19-000005:notes:172]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2018 filed with the SEC on November 20, 2018. The results of operations for the three month period ended December 31, 2018 are not necessarily indicative of results for the Company’s 2019 fiscal year because of seasonal and other factors.

[0000833444-19-000005:notes:173]
[same as prior period, unchanged from 0000833444-18-000044:notes:217]

[0000833444-19-000005:notes:174]
[same as prior period, unchanged from 0000833444-18-000044:notes:218]

[0000833444-19-000005:notes:175]
The Building Technologies & Solutions ("Buildings") business is a global market leader in engineering, developing, manufacturing and installing building products and systems around the world, including heating, ventilating, air-conditioning ("HVAC") equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Buildings business further serves customers by providing technical services (in the HVAC, security and fire-protection space), energy-management consulting and data-driven solutions via its data-enabled business. Finally, the Company has a strong presence in the North American residential air conditioning and heating systems market and is a global market leader in industrial refrigeration products.

[0000833444-19-000005:notes:176]
The Power Solutions business is a leading global supplier of lead-acid automotive batteries for virtually every type of passenger car, light truck and utility vehicle. The Company serves both automotive original equipment manufacturers and the general vehicle battery aftermarket. The Company also supplies advanced battery technologies to power start-stop, hybrid and electric vehicles. During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation, which required retrospective application to financial information for all periods presented. Refer to Note 4, "Discontinued Operations" of the notes to consolidated financial statements for further information.

[0000833444-19-000005:notes:177]
[same as prior period, unchanged from 0000833444-18-000044:notes:222]

[0000833444-19-000005:notes:178]
[same as prior period, unchanged from 0000833444-18-000044:notes:223]

[0000833444-19-000005:notes:179]
Under certain criteria as provided for in Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity ("VIE"). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting rights. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.

[0000833444-19-000005:notes:180]
The Company did not have a significant variable interest in any consolidated or nonconsolidated VIEs in its continuing operations for the presented reporting periods.

[0000833444-19-000005:notes:181]
[same as prior period, unchanged from 0000833444-18-000044:notes:234]

[0000833444-19-000005:notes:182]
At December 31, 2018, the Company held restricted cash of approximately $20 million, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities. At September 30, 2018, the Company held restricted cash of approximately $15 million, of which $6 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position.

[0000833444-19-000005:notes:183]
[same as prior period, unchanged from 0000833444-18-000044:notes:236]

[0000833444-19-000005:notes:184]
During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation, which required retrospective application to financial information for all periods presented. Refer to Note 4, "Discontinued Operations" of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-19-000005:notes:185]
In November 2016, the FASB issued Accounting Standards Update ("ASU") No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force)." The ASU requires amounts generally described as restricted cash and restricted cash equivalents to be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. ASU No. 2016-18 was effective retrospectively for the quarter ended December 31, 2018. The impact of this guidance did not have a significant impact on the Company's consolidated financial statements for the periods presented.

[0000833444-19-000005:notes:186]
In August 2016, the FASB issued ASU No. 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments." ASU No. 2016-15 provides clarification guidance on eight specific cash flow presentation issues in order to reduce the diversity in practice. ASU No. 2016-15 was effective retrospectively for the Company for the quarter ending December 31, 2018. The adoption of this guidance had an impact on the presentation of equity swap funding and settlement activities since the activity changed from an operating activity to an investing activity.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-19-000005:notes:187]
[same as prior period, unchanged from 0000833444-18-000044:notes:239]

[0000833444-19-000005:notes:188]
The components of the Company’s net periodic benefit costs from continuing operations associated with its defined benefit pension and postretirement plans, which are primarily recorded in selling, general and administrative expenses in the consolidated statements of income, are shown in the tables below in accordance with ASC 715, "Compensation – Retirement Benefits" (in millions):

[0000833444-19-000005:notes:189]
|  | U.S. Pension Plans |
|  | Three Months EndedDecember 31, |
|  | 2018 |  | 2017 |
| Interest cost | $ | 25 |  |  | $ | 23 |  |
| Expected return on plan assets | (46 | ) |  | (50 | ) |
| Net periodic benefit credit | $ | (21 | ) |  | $ | (27 | ) |

[0000833444-19-000005:notes:190]
|  | Non-U.S. Pension Plans |
|  | Three Months EndedDecember 31, |
|  | 2018 |  | 2017 |
| Service cost | $ | 5 |  |  | $ | 5 |  |
| Interest cost | 14 |  |  | 14 |  |
| Expected return on plan assets | (27 | ) |  | (28 | ) |
| Net periodic benefit credit | $ | (8 | ) |  | $ | (9 | ) |

[0000833444-19-000005:notes:191]
|  | Postretirement Benefits |
|  | Three Months EndedDecember 31, |
|  | 2018 |  | 2017 |
| Interest cost | $ | 2 |  |  | $ | 2 |  |
| Expected return on plan assets | (2 | ) |  | (2 | ) |
| Net periodic benefit credit | $ | — |  |  | $ | — |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-19-000005:notes:192]
Related Party Transactions

[0000833444-19-000005:notes:193]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-19-000005:notes:194]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $43 million and $14 million, respectively, for the three months ended December 31, 2018; and $45 million and $9 million, respectively, for the three months ended December 31, 2017.

[0000833444-19-000005:notes:195]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position for continuing operations (in millions):

[0000833444-19-000005:notes:196]
|  |  | December 31, 2018 |  | September 30, 2018 |  |
| Receivable from related parties |  | $ | 41 |  |  | $ | 36 |  |
| Payable to related parties |  | 7 |  |  | 18 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-19-000005:notes:197]
[same as prior period, unchanged from 0000833444-18-000044:notes:251]

[0000833444-19-000005:notes:198]
[same as prior period, unchanged from 0000833444-18-000044:notes:252]

[0000833444-19-000005:notes:199]
In fiscal 2018, the Company committed to a significant restructuring plan (2018 Plan) and recorded $255 million of restructuring and impairment costs for continuing operations in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $113 million related to the Global Products segment, $56 million related to the Building Solutions EMEA/LA segment, $50 million related to Corporate, $20 million related to the Building Solutions North America segment and $16 million related to the Building Solutions Asia Pacific segment. The restructuring actions are expected to be substantially complete in 2020.

[0000833444-19-000005:notes:200]
Additionally, the Company recorded $8 million of restructuring and impairment costs related to Power Solutions in fiscal 2018. This is reported within discontinued operations.

[0000833444-19-000005:notes:201]
[same as prior period, unchanged from 0000833444-18-000044:notes:254]

[0000833444-19-000005:notes:202]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 209 |  |  | $ | 42 |  |  | $ | 12 |  |  | $ | 263 |  |
| Utilized—cash | (45 | ) |  | — |  |  | (2 | ) |  | (47 | ) |
| Utilized—noncash | — |  |  | (42 | ) |  | — |  |  | (42 | ) |
| Balance at September 30, 2018 | $ | 164 |  |  | $ | — |  |  | $ | 10 |  |  | $ | 174 |  |
| Utilized—cash | (12 | ) |  | — |  |  | (3 | ) |  | (15 | ) |
| Transfer to liabilities held for sale | (4 | ) |  | — |  |  | — |  |  | (4 | ) |
| Balance at December 31, 2018 | $ | 148 |  |  | $ | — |  |  | $ | 7 |  |  | $ | 155 |  |

[0000833444-19-000005:notes:203]
In fiscal 2017, the Company committed to a significant restructuring plan (2017 Plan) and recorded $347 million of restructuring and impairment costs for continuing operations in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $166 million related to Corporate, $74 million related to the Building Solutions EMEA/LA segment, $59 million related to the Building Solutions North America segment, $32 million related to the Global Products segment and $16 million related to the Building Solutions Asia Pacific segment. The restructuring actions are expected to be substantially complete in fiscal 2019.

[0000833444-19-000005:notes:204]
Additionally, the Company recorded $20 million of restructuring and impairment costs related to Power Solutions in fiscal 2017. This is reported within discontinued operations.

[0000833444-19-000005:notes:205]
[same as prior period, unchanged from 0000833444-18-000044:notes:257]

[0000833444-19-000005:notes:206]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 276 |  |  | $ | 77 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 367 |  |
| Utilized—cash | (75 | ) |  | — |  |  | — |  |  | — |  |  | (75 | ) |
| Utilized—noncash | — |  |  | (77 | ) |  | (1 | ) |  | — |  |  | (78 | ) |
| Adjustment to restructuring reserves | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |
| Balance at September 30, 2017 | $ | 226 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 239 |  |
| Utilized—cash | (152 | ) |  | — |  |  | (6 | ) |  | — |  |  | (158 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Balance at September 30, 2018 | $ | 74 |  |  | $ | — |  |  | $ | 7 |  |  | $ | (1 | ) |  | $ | 80 |  |
| Utilized—cash | (2 | ) |  | — |  |  | — |  |  | — |  |  | (2 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (2 | ) |  | (2 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Balance at December 31, 2018 | $ | 69 |  |  | $ | — |  |  | $ | 7 |  |  | $ | (3 | ) |  | $ | 73 |  |

[0000833444-19-000005:notes:207]
In fiscal 2016, the Company committed to a significant restructuring plan (2016 Plan) and recorded $222 million of restructuring and impairment costs for continuing operations in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. Of the restructuring and impairment costs recorded, $161 million related to Corporate, $44 million related to the Global Products segment and $17 million related to the Building Solutions EMEA/LA segment. The restructuring actions are expected to be substantially complete in fiscal 2019. Included in the reserve is $56 million of committed restructuring actions taken by Tyco for liabilities assumed as part of the Tyco acquisition.

[0000833444-19-000005:notes:208]
Additionally, the Company recorded $398 million of restructuring and impairment costs related to Adient and Power Solutions in fiscal 2016. This is reported within discontinued operations.

[0000833444-19-000005:notes:209]
[same as prior period, unchanged from 0000833444-18-000044:notes:261]

[0000833444-19-000005:notes:210]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 368 |  |  | $ | 190 |  |  | $ | 62 |  |  | $ | — |  |  | $ | 620 |  |
| Acquired Tyco restructuring reserves | 78 |  |  | — |  |  | — |  |  | — |  |  | 78 |  |
| Utilized—cash | (32 | ) |  | — |  |  | — |  |  | — |  |  | (32 | ) |
| Utilized—noncash | — |  |  | (190 | ) |  | (32 | ) |  | 1 |  |  | (221 | ) |
| Balance at September 30, 2016 | $ | 414 |  |  | $ | — |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 445 |  |
| Adient spin-off impact | (194 | ) |  | — |  |  | (22 | ) |  | — |  |  | (216 | ) |
| Utilized—cash | (86 | ) |  | — |  |  | (2 | ) |  | — |  |  | (88 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Adjustment to restructuring reserves | (25 | ) |  | — |  |  | — |  |  | — |  |  | (25 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Adjustment to acquired Tyco restructuring reserves | (22 | ) |  | — |  |  | — |  |  | — |  |  | (22 | ) |
| Balance at September 30, 2017 | $ | 84 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 2 |  |  | $ | 92 |  |
| Utilized—cash | (17 | ) |  | — |  |  | (2 | ) |  | — |  |  | (19 | ) |
| Balance at September 30, 2018 | $ | 67 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 2 |  |  | $ | 73 |  |
| Utilized—cash | (8 | ) |  | — |  |  | — |  |  | — |  |  | (8 | ) |
| Balance at December 31, 2018 | $ | 59 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 2 |  |  | $ | 65 |  |

[0000833444-19-000005:notes:211]
The Company's fiscal 2018, 2017 and 2016 restructuring plans included workforce reductions of approximately 11,300 employees (9,100 for the Building Technologies & Solutions business and 2,200 for Corporate). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of December 31, 2018, approximately 5,000 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included twelve plant closures in the Building Technologies & Solutions business. As of December 31, 2018, eight of the twelve plants have been closed.

[0000833444-19-000005:notes:212]
[same as prior period, unchanged from 0000833444-18-000044:notes:264]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-19-000005:notes:213]
Revenue Recognition

[0000833444-19-000005:notes:214]
The Company designs, manufactures and installs building products and systems around the world, including HVAC equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Company also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems.

[0000833444-19-000005:notes:215]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. Claims against customers are recognized as revenue upon settlement. The Company elected the practical expedient which permits the promised amount of consideration to not be adjusted for the effects of a significant financing component as at contract inception the Company expects to receive the payment within the twelve months of transfer of goods or services.

[0000833444-19-000005:notes:216]
The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term.

[0000833444-19-000005:notes:217]
The Company also sells certain HVAC and refrigeration products and services in bundled arrangements with multiple performance obligations, such as equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Company sells security monitoring systems that may have multiple performance obligations, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with sale of equipment and related installations are recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. The transaction price is allocated to each performance obligation based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach. Revenue recognized for security monitoring equipment and installation is limited to the lesser of their allocated amounts under the estimated selling price hierarchy or the non-contingent up-front consideration received at the time of installation, since collection of future amounts under the arrangement with the customer is contingent upon the delivery of monitoring and maintenance services. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized over time on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the contract.

[0000833444-19-000005:notes:218]
In all other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

[0000833444-19-000005:notes:219]
The Company considers the contractual consideration payable by the customer and assess variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar  sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

[0000833444-19-000005:notes:220]
Shipping and handling costs billed to customers are included in sales and the related costs are included in cost of sales when control transfers to the customer. The Company has elected to present amounts collected from customers for sales and other taxes net of the related amounts remitted.

[0000833444-19-000005:notes:221]
Disaggregated Revenue

[0000833444-19-000005:notes:222]
Contract Balances

[0000833444-19-000005:notes:223]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed and consist of unbilled receivable and costs in excess of billings. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract liabilities consist of deferred revenue. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

[0000833444-19-000005:notes:224]
For the three months ended December 31, 2018, the Company recognized revenue of $712 million that was included in the beginning of period contract liability balance.

[0000833444-19-000005:notes:225]
Performance Obligations

[0000833444-19-000005:notes:226]
A performance obligation is a distinct good, service, or a bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

[0000833444-19-000005:notes:227]
Performance obligations are satisfied as of a point in time or over time. Performance obligations are supported by contracts with customers, providing a framework for the nature of the distinct goods, services, or bundle of goods and services. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of December 31, 2018, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $13.7 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company has applied the practical expedient for certain revenue streams to exclude the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-19-000005:notes:228]
Costs to Obtain or Fulfill a Contract

[0000833444-19-000005:notes:229]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist  primarily of sales commissions and bid/proposal costs. Costs to obtain or fulfill a contract are capitalized and amortized to revenue over the period of contract performance.

[0000833444-19-000005:notes:230]
As of December 31, 2018, the Company recorded the costs to obtain or fulfill a contract of $175 million, of which $91 million is recorded within other current assets and $84 million is recorded within other noncurrent assets in the consolidated statements of financial position.

[0000833444-19-000005:notes:231]
During the three months ended December 31, 2018, the Company recognized amortization expense of $35 million related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three months ended December 31, 2018.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-19-000005:notes:232]
[same as prior period, unchanged from 0000833444-18-000044:notes:265]

[0000833444-19-000005:notes:233]
|  | Three Months EndedDecember 31, |
|  | 2018 |  | 2017 |
| Foreign currency translation adjustments ("CTA") |  |  |  |
| Balance at beginning of period | $ | (939 | ) |  | $ | (481 | ) |
| Aggregate adjustment for the period (net of tax effect of $0 and $1) * | (127 | ) |  | 58 |  |
| Balance at end of period | (1,066 | ) |  | (423 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (13 | ) |  | 6 |  |
| Current period changes in fair value (net of tax effect of $(2) and $3) | (4 | ) |  | 6 |  |
| Reclassification to income (net of tax effect of $1 and $(2)) ** | 5 |  |  | (5 | ) |
| Balance at end of period | (12 | ) |  | 7 |  |
| Realized and unrealized gains on marketable securities |  |  |  |
| Balance at beginning of period | 8 |  |  | 4 |  |
| Adoption of ASU 2016-01 *** | (8 | ) |  | — |  |
| Balance at end of period | — |  |  | 4 |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (2 | ) |  | (2 | ) |
| Other changes | — |  |  | — |  |
| Balance at end of period | (2 | ) |  | (2 | ) |
| Accumulated other comprehensive loss, end of period | $ | (1,080 | ) |  | $ | (414 | ) |

[0000833444-19-000005:notes:234]
* During the three months ended December 31, 2017, $12 million of cumulative CTA was recognized as part of the divestiture-related gain recognized as part of the divestiture of Scott Safety.

[0000833444-19-000005:notes:235]
[same as prior period, unchanged from 0000833444-18-000044:notes:269]

[0000833444-19-000005:notes:236]
*** As previously disclosed, during the quarter ended December 31, 2018, the Company adopted ASU 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." As a result the Company reclassified $8 million of unrealized gains on marketable securities to retained earnings as of October 1, 2018.


## us-gaap:ScheduleOfNewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000833444-19-000005:notes:237]
The impact of adoption of the New Revenue Standard to the Company's consolidated statement of financial position as of December 31, 2018 is as follows (in millions):

[0000833444-19-000005:notes:238]
|  | December 31, 2018 |
|  | As reported |  | Under previous accounting guidance |  | Impact from adopting the New Revenue Standard |
| Consolidated Statement of Financial Position |  |  |  |  |  |
| Assets |  |  |  |  |  |
| Accounts receivable - net | $ | 5,442 |  |  | $ | 5,476 |  |  | $ | (34 | ) |
| Inventories | 2,027 |  |  | 2,041 |  |  | (14 | ) |
| Assets held for sale | 3,042 |  |  | 3,032 |  |  | 10 |  |
| Other current assets | 1,152 |  |  | 1,174 |  |  | (22 | ) |
| Property, plant and equipment - net | 3,314 |  |  | 3,274 |  |  | 40 |  |
| Noncurrent assets held for sale | 5,159 |  |  | 5,153 |  |  | 6 |  |
| Other noncurrent assets | 2,330 |  |  | 2,303 |  |  | 27 |  |
| Liabilities and Equity |  |  |  |  |  |
| Deferred revenue | 1,378 |  |  | 1,369 |  |  | 9 |  |
| Liabilities held for sale | 1,636 |  |  | 1,597 |  |  | 39 |  |
| Retained earnings | 6,136 |  |  | 6,171 |  |  | (35 | ) |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000833444-19-000005:notes:239]
[same as prior period, unchanged from 0000833444-18-000044:notes:271]

[0000833444-19-000005:notes:240]
|  | Net Sales |
|  | Three Months EndedDecember 31, |
|  | 2018 |  | 2017 |
| Building Solutions North America | $ | 2,116 |  |  | $ | 2,012 |  |
| Building Solutions EMEA/LA | 907 |  |  | 915 |  |
| Building Solutions Asia Pacific | 613 |  |  | 597 |  |
| Global Products | 1,828 |  |  | 1,781 |  |
| Total net sales | $ | 5,464 |  |  | $ | 5,305 |  |

[0000833444-19-000005:notes:241]
|  | Segment EBITA |
|  | Three Months EndedDecember 31, |
|  | 2018 |  | 2017 |
| Building Solutions North America | $ | 250 |  |  | $ | 227 |  |
| Building Solutions EMEA/LA | 77 |  |  | 69 |  |
| Building Solutions Asia Pacific | 66 |  |  | 74 |  |
| Global Products | 190 |  |  | 286 |  |
| Total segment EBITA | $ | 583 |  |  | $ | 656 |  |
| Corporate expenses | $ | (136 | ) |  | $ | (138 | ) |
| Amortization of intangible assets | (97 | ) |  | (92 | ) |
| Restructuring and impairment costs | — |  |  | (154 | ) |
| Net mark-to-market adjustments | (21 | ) |  | — |  |
| Net financing charges | (85 | ) |  | (102 | ) |
| Income from continuing operations before income taxes | $ | 244 |  |  | $ | 170 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-19-000005:notes:242]
[same as prior period, unchanged from 0000833444-18-000044:notes:274]

[0000833444-19-000005:notes:243]
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has four reportable segments for financial reporting purposes.

[0000833444-19-000005:notes:244]
[same as prior period, unchanged from 0000833444-18-000044:notes:284]

[0000833444-19-000005:notes:245]
[same as prior period, unchanged from 0000833444-18-000044:notes:285]

[0000833444-19-000005:notes:246]
[same as prior period, unchanged from 0000833444-18-000044:notes:286]

[0000833444-19-000005:notes:247]
| • | Global Products designs and produces heating and air conditioning for residential and commercial applications, and markets products and refrigeration systems to replacement and new construction market customers globally. The Global Products business also designs, manufactures and sells fire protection and security products, including intrusion security, anti-theft devices, and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide. Global Products also includes the Johnson Controls-Hitachi joint venture. |

[0000833444-19-000005:notes:248]
During the first quarter of fiscal 2019, the Company determined that the Power Solutions business met the criteria to be classified as a discontinued operation, which required retrospective application to financial information for all periods presented.  Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-19-000005:notes:249]
On October 1, 2018, the Company adopted ASU No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." The new standard requires the mark-to-market of marketable securities investments previously recorded within accumulated other comprehensive income on the statement of financial position be recorded in the statement of income on a prospective basis beginning as of the adoption date. As these restricted investments do not relate to the underlying operating performance of its business, the Company’s definition of segment earnings excludes the mark-to-market adjustments beginning in the first quarter of fiscal 2019.

[0000833444-19-000005:notes:250]
Management evaluates the performance of its business segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-19-000005:notes:251]
[same as prior period, unchanged from 0000833444-18-000044:notes:291]

[0000833444-19-000005:notes:252]
[same as prior period, unchanged from 0000833444-18-000044:notes:292]

[0000833444-19-000005:notes:253]
As previously disclosed, during the quarter ended December 31, 2018, the Company adopted ASC 606, "Revenue from Contracts with Customers." As a result, the Company recorded $45 million to beginning retained earnings, which relates primarily to deferred revenue recorded for the Power Solutions business for certain battery core returns that represent a material right provided to customers.

[0000833444-19-000005:notes:254]
As previously disclosed, during the quarter ended December 31, 2018, the Company adopted ASU 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory." As a result, the Company recognized deferred taxes of $546 million related to the tax effects of all intra-entity sales of assets other than inventory on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2018.

[0000833444-19-000005:notes:255]
As previously disclosed, during the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09, "Compensation - Stock Compensation (Topic 718) Improvements to Employee Share-Based Payment Accounting." As a result, the Company recognized deferred tax assets of $179 million related to certain operating loss carryforwards resulting from the exercise of employee stock options and restricted stock vestings on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2017.

[0000833444-19-000005:notes:256]
Following the Tyco Merger, the Company adopted, subject to the ongoing existence of sufficient distributable reserves, the existing Tyco International plc $1 billion share repurchase program in September 2016. In December 2017, the Company's Board of Directors approved a $1 billion increase to its share repurchase authorization. In November 2018, the Company's Board of Directors approved an additional $1 billion increase to its share repurchase authorization. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. For the three months ended December 31, 2018 and 2017, the Company repurchased $467 million and $150 million of its ordinary shares, respectively. As of December 31, 2018, approximately $1.6 billion remains available under the share repurchase program.

[0000833444-19-000005:notes:257]
The Company consolidates certain subsidiaries in which the noncontrolling interest party has within its control the right to require the Company to redeem all or a portion of its interest in the subsidiary. The redeemable noncontrolling interests are reported at their estimated redemption value. Any adjustment to the redemption value impacts retained earnings but does not impact net income. Redeemable noncontrolling interests which are redeemable only upon future events, the occurrence of which is not currently probable, are recorded at carrying value. Beginning in the fourth quarter of fiscal 2018, the Company does not have any subsidiaries for which the noncontrolling interest party has within their control the right to require the Company to redeem any portion of its interests.

[0000833444-19-000005:notes:258]
The following schedule present changes in the redeemable noncontrolling interests for the three months ended December 31, 2017 (in millions):

[0000833444-19-000005:notes:259]
| Beginning balance, September 30, 2017 | $ | 211 |  |
| Net income | 13 |  |
| Foreign currency translation adjustments | 5 |  |
| Realized and unrealized losses on derivatives | (3 | ) |
| Ending balance, December 31, 2017 | $ | 226 |  |
