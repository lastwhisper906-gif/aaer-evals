# JCI MD&A — 0000833444-19-000005


## mdna

[0000833444-19-000005:mdna:1]
[same as prior period, unchanged from 0000833444-18-000044:mdna:1]

[0000833444-19-000005:mdna:2]
[same as prior period, unchanged from 0000833444-18-000044:mdna:2]

[0000833444-19-000005:mdna:3]
[same as prior period, unchanged from 0000833444-18-000044:mdna:3]

[0000833444-19-000005:mdna:4]
[same as prior period, unchanged from 0000833444-18-000044:mdna:4]

[0000833444-19-000005:mdna:5]
[same as prior period, unchanged from 0000833444-18-000044:mdna:5]

[0000833444-19-000005:mdna:6]
Johnson Controls was originally incorporated in the state of Wisconsin in 1885 as Johnson Electric Service Company to manufacture, install and service automatic temperature regulation systems for buildings. The Company was renamed to Johnson Controls, Inc. in 1974. In 1978, the Company acquired Globe-Union, Inc., a Wisconsin-based manufacturer of automotive batteries for both the replacement and original equipment markets. In 2005, the Company acquired York International, a global supplier of heating, ventilating, air-conditioning and refrigeration equipment and services. In 2014, the Company acquired Air Distribution Technologies, Inc. ("ADTi"), one of the largest independent providers of air distribution and ventilation products in North America. On October 1, 2015, the Company formed a joint venture with Hitachi to expand its building product offerings.

[0000833444-19-000005:mdna:7]
44

[0000833444-19-000005:mdna:8]
[same as prior period, unchanged from 0000833444-18-000044:mdna:7]

[0000833444-19-000005:mdna:9]
The Building Technologies & Solutions ("Buildings") business is a global market leader in engineering, developing, manufacturing and installing building products and systems around the world, including heating, ventilating, air-conditioning ("HVAC") equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Buildings business further serves customers by providing technical services (in the HVAC, security and fire-protection space), energy-management consulting and data-driven solutions via its data-enabled business. Finally, the Company has a strong presence in the North American residential air conditioning and heating systems market and is a global market leader in industrial refrigeration products.

[0000833444-19-000005:mdna:10]
[same as prior period, unchanged from 0000833444-18-000044:mdna:11]

[0000833444-19-000005:mdna:11]
On November 13, 2018, the Company entered into a Stock and Asset Purchase Agreement (“Purchase Agreement”) with BCP Acquisitions LLC (“Purchaser”). The Purchaser is a newly-formed entity controlled by investment funds managed by Brookfield Capital Partners LLC. Pursuant to the Purchase Agreement, on the terms and subject to the conditions therein, the Company has agreed to sell, and Purchaser has agreed to acquire, the Company’s Power Solutions business for a purchase price of $13.2 billion. Net cash proceeds are expected to be $11.4 billion after tax and transaction-related expenses. The transaction is expected to close by June 30, 2019, subject to customary closing conditions and required regulatory approvals.

[0000833444-19-000005:mdna:12]
During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation and, as a result, Power Solutions' historical financial results are reflected in the Company's consolidated financial statements as a discontinued operation, and assets and liabilities were retrospectively reclassified as assets and liabilities held for sale.

[0000833444-19-000005:mdna:13]
The following information should be read in conjunction with the September 30, 2018 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2018 filed with the SEC on November 20, 2018. References in the following discussion and analysis to "Three Months"(or similar language) refer to the three months ended December 31, 2018 compared to the three months ended December 31, 2017.

[0000833444-19-000005:mdna:14]
[same as prior period, unchanged from 0000833444-18-000044:mdna:14]

[0000833444-19-000005:mdna:15]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Net sales | $ | 5,464 |  |  | $ | 5,305 |  |  | 3 | % |

[0000833444-19-000005:mdna:16]
The increase in consolidated net sales for the three months ended December 31, 2018 was due to higher organic sales ($306 million) and acquisitions ($8 million), partially offset by the unfavorable impact of foreign currency translation ($100 million) and lower sales due to business divestitures ($55 million). The increase in organic sales related to higher volumes across all segments. Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 6% as compared to the prior year. Refer to the "Segment Analysis" below within Item 2 for a discussion of net sales by segment.

[0000833444-19-000005:mdna:17]
[same as prior period, unchanged from 0000833444-18-000044:mdna:18]

[0000833444-19-000005:mdna:18]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Cost of sales | $ | 3,739 |  |  | $ | 3,607 |  |  | 4 | % |
| Gross profit | 1,725 |  |  | 1,698 |  |  | 2 | % |
| % of sales | 31.6 | % |  | 32.0 | % |  |  |

[0000833444-19-000005:mdna:19]
Cost of sales for the three month period ended December 31, 2018 increased as compared to the three month period ended December 31, 2017, and gross profit as a percentage of sales decreased by 40 basis points. Gross profit increased due to higher volumes across all segments, partially offset by business divestitures and higher operating costs. Foreign currency translation had a favorable impact on cost of sales of approximately $66 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-19-000005:mdna:20]
[same as prior period, unchanged from 0000833444-18-000044:mdna:23]

[0000833444-19-000005:mdna:21]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Selling, general and administrative expenses | $ | 1,438 |  |  | $ | 1,319 |  |  | 9 | % |
| % of sales | 26.3 | % |  | 24.9 | % |  |  |

[0000833444-19-000005:mdna:22]
Selling, general and administrative expenses ("SG&A") for the three month period ended December 31, 2018 increased 9% as compared to the three month period ended December 31, 2017. The increase in SG&A was primarily due to a $114 million gain on sale of the Scott Safety business in the Global Products segment in the prior year and a current year net mark-to-market loss on restricted asbestos investments, partially offset by productivity savings and costs synergies, net of incremental investments. Foreign currency translation had a favorable impact on SG&A of $22 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-19-000005:mdna:23]
[same as prior period, unchanged from 0000833444-18-000044:mdna:27]

[0000833444-19-000005:mdna:24]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Restructuring and impairment costs | $ | — |  |  | $ | 154 |  |  | * |

[0000833444-19-000005:mdna:25]
[same as prior period, unchanged from 0000833444-18-000044:mdna:29]

[0000833444-19-000005:mdna:26]
[same as prior period, unchanged from 0000833444-18-000044:mdna:30]

[0000833444-19-000005:mdna:27]
[same as prior period, unchanged from 0000833444-18-000044:mdna:31]

[0000833444-19-000005:mdna:28]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Net financing charges | $ | 85 |  |  | $ | 102 |  |  | -17 | % |

[0000833444-19-000005:mdna:29]
[same as prior period, unchanged from 0000833444-18-000044:mdna:33]

[0000833444-19-000005:mdna:30]
[same as prior period, unchanged from 0000833444-18-000044:mdna:34]

[0000833444-19-000005:mdna:31]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Equity income | $ | 42 |  |  | $ | 47 |  |  | -11 | % |

[0000833444-19-000005:mdna:32]
The decrease in equity income for the three months ended December 31, 2018 was primarily due to lower income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-19-000005:mdna:33]
[same as prior period, unchanged from 0000833444-18-000044:mdna:37]

[0000833444-19-000005:mdna:34]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Income tax provision | $ | 108 |  |  | $ | 217 |  |  | -50 | % |
| Effective tax rate | 44 | % |  | 128 | % |  |  |

[0000833444-19-000005:mdna:35]
[same as prior period, unchanged from 0000833444-18-000044:mdna:39]

[0000833444-19-000005:mdna:36]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended December 31, 2018, the Company's effective tax rate for continuing operations was 44% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments as a result of tax law changes and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the three months ended December 31, 2017, the Company's effective tax rate for continuing operations was 128% and was higher than the statutory tax rate of 12.5% primarily due to the discrete net impacts of U.S. Tax Reform, the tax impact of the divestiture of the Scott Safety business and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives and tax audit closures.

[0000833444-19-000005:mdna:37]
On December 22, 2017, the “Tax Cuts and Jobs Act” (H.R. 1) was enacted and significantly revised U.S. corporate income tax by, among other things, lowering corporate income tax rates, imposing a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries, and implementing a territorial tax system and various base erosion minimum tax provisions.

[0000833444-19-000005:mdna:38]
In connection with the Company’s analysis of the impact of the U.S. tax law changes, the Company recorded a provisional net tax charge of $108 million during fiscal 2018 consistent with guidance prescribed by Staff Accounting Bulletin 118. This provisional net tax charge arises from a benefit of $108 million due to the remeasurement of U.S. deferred tax assets and liabilities, offset by the Company’s tax charge relating to the one-time transition tax on deemed repatriated earnings, inclusive of all relevant taxes, of $216 million. The Company’s estimated benefit of the remeasurement of U.S. deferred tax assets and liabilities increased from $101 million as of December 31, 2017 to $108 million as of September 30, 2018 due to calculation refinement of the Company’s estimated impact. The Company remeasured certain deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future, which is generally 21% or the blended fiscal 2018 rate of 24.5%. The Company’s tax charge for transition tax decreased from $305 million as of December 31, 2017 to $216 million as of September 30, 2018 due to further analysis of the Company’s post-1986 non-U.S. earnings and profits (“E&P”) previously deferred from U.S. federal taxation and refinement of the estimated impact of tax law changes. In the first quarter of fiscal 2019, the Company completed its analysis of all enactment-date income tax effects of the U.S. tax law change with no further adjustment to the provisional amounts recorded as of September 30, 2018.

[0000833444-19-000005:mdna:39]
In the first quarter of fiscal 2019, as a result of changes to U.S. tax law, the Company recorded a discrete tax charge of $76 million related to valuation allowance on certain U.S. deferred tax assets.

[0000833444-19-000005:mdna:40]
47

[0000833444-19-000005:mdna:41]
[same as prior period, unchanged from 0000833444-18-000044:mdna:49]

[0000833444-19-000005:mdna:42]
In the first quarter of fiscal 2018, the Company recorded $154 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $23 million tax benefit, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-19-000005:mdna:43]
Income From Discontinued Operations, Net of Tax

[0000833444-19-000005:mdna:44]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Income from discontinued operations, net of tax | $ | 263 |  |  | $ | 318 |  |  | -17 | % |

[0000833444-19-000005:mdna:45]
[same as prior period, unchanged from 0000833444-18-000044:mdna:67]

[0000833444-19-000005:mdna:46]
[same as prior period, unchanged from 0000833444-18-000044:mdna:68]

[0000833444-19-000005:mdna:47]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 29 |  |  | $ | 28 |  |  | 4 | % |
| Income from discontinued operations attributable to noncontrolling interests | 15 |  |  | 13 |  |  | 15 | % |

[0000833444-19-000005:mdna:48]
The increase in income from continuing operations attributable to noncontrolling interests for the three ended December 31, 2018 was primarily due to lower net loss at a certain partially-owned affiliate.

[0000833444-19-000005:mdna:49]
[same as prior period, unchanged from 0000833444-18-000044:mdna:72]

[0000833444-19-000005:mdna:50]
[same as prior period, unchanged from 0000833444-18-000044:mdna:73]

[0000833444-19-000005:mdna:51]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Net income attributable to Johnson Controls | $ | 355 |  |  | $ | 230 |  |  | 54 | % |

[0000833444-19-000005:mdna:52]
The increase in net income attributable to Johnson Controls for the three months ended December 31, 2018 was primarily due to a decrease in restructuring and impairment costs and income tax provision, and higher gross profit, partially offset by higher SG&A and lower income from discontinued operations. Diluted earnings per share attributable to Johnson Controls for the three months ended December 31, 2018 was $0.38 compared to $0.25 for the three months ended December 31, 2017.

[0000833444-19-000005:mdna:53]
[same as prior period, unchanged from 0000833444-18-000044:mdna:76]

[0000833444-19-000005:mdna:54]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 229 |  |  | $ | 289 |  |  | -21 | % |

[0000833444-19-000005:mdna:55]
The decrease in comprehensive income attributable to Johnson Controls for the three months ended December 31, 2018 was primarily due to a decrease in other comprehensive income attributable to Johnson Controls ($185 million) resulting primarily from unfavorable foreign currency translation adjustments, partially offset by higher net income attributable to Johnson Controls ($125 million). These year-over-year unfavorable foreign currency translation adjustments were primarily driven by the weakening of the British pound and euro currencies against the U.S. dollar.

[0000833444-19-000005:mdna:56]
[same as prior period, unchanged from 0000833444-18-000044:mdna:80]

[0000833444-19-000005:mdna:57]
On October 1, 2018, the Company adopted Accounting Standards Update ("ASU") No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." The new standard requires the mark-to-market of marketable securities investments previously recorded within accumulated other comprehensive income on the statement of financial position be recorded in the statement of income on a prospective basis beginning as of the adoption date. As these restricted investments do not relate to the underlying operating performance of its business, the Company’s definition of segment earnings excludes the mark-to-market adjustments beginning in the first quarter of fiscal 2019.

[0000833444-19-000005:mdna:58]
Management evaluates the performance of its business units based primarily on segment EBITA, which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-19-000005:mdna:59]
Net Sales

[0000833444-19-000005:mdna:60]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Building Solutions North America | $ | 2,116 |  |  | $ | 2,012 |  |  | 5 | % |
| Building Solutions EMEA/LA | 907 |  |  | 915 |  |  | -1 | % |
| Building Solutions Asia Pacific | 613 |  |  | 597 |  |  | 3 | % |
| Global Products | 1,828 |  |  | 1,781 |  |  | 3 | % |
|  | $ | 5,464 |  |  | $ | 5,305 |  |  | 3 | % |

[0000833444-19-000005:mdna:61]
| • | The increase in Building Solutions North America was due to higher volumes ($112 million), partially offset by the unfavorable impact of foreign currency translation ($8 million). The increase in volumes was primarily attributable to higher installation / service sales. |

[0000833444-19-000005:mdna:62]
| • | The decrease in Building Solutions EMEA/LA was due to the unfavorable impact of foreign currency translation ($43 million), partially offset by higher volumes ($33 million) and incremental sales related to a business acquisition ($2 million). The increase in volumes was primarily attributable to higher service sales. |

[0000833444-19-000005:mdna:63]
| • | The increase in Building Solutions Asia Pacific was due to higher volumes ($34 million), partially offset by the unfavorable impact of foreign currency translation ($18 million). The increase in volumes was primarily attributable to higher installation sales. |

[0000833444-19-000005:mdna:64]
| • | The increase in Global Products was due to higher volumes ($127 million) and incremental sales related to business acquisitions ($6 million), partially offset by lower volumes related to business divestitures ($55 million) and the unfavorable impact of foreign currency translation ($31 million). The increase in volumes was primarily attributable to higher building management, HVAC and refrigeration equipment, and specialty products sales. |

[0000833444-19-000005:mdna:65]
[same as prior period, unchanged from 0000833444-18-000044:mdna:22]

[0000833444-19-000005:mdna:66]
Segment EBITA

[0000833444-19-000005:mdna:67]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Building Solutions North America | $ | 250 |  |  | $ | 227 |  |  | 10 | % |
| Building Solutions EMEA/LA | 77 |  |  | 69 |  |  | 12 | % |
| Building Solutions Asia Pacific | 66 |  |  | 74 |  |  | -11 | % |
| Global Products | 190 |  |  | 286 |  |  | -34 | % |
|  | $ | 583 |  |  | $ | 656 |  |  | -11 | % |

[0000833444-19-000005:mdna:68]
| • | The increase in Building Solutions North America was due to favorable volumes ($36 million) and prior year integration costs ($9 million), partially offset by incremental sales investments ($11 million), unfavorable mix ($7 million), current year integration costs ($3 million) and the unfavorable impact of foreign currency translation ($1 million). |

[0000833444-19-000005:mdna:69]
| • | The increase in Building Solutions EMEA/LA was due to favorable volumes / mix ($11 million), lower SG&A ($5 million), prior year integration costs ($2 million) and incremental income related to a business acquisition ($1 million), partially offset by the unfavorable impact of foreign currency translation ($7 million) and incremental sales investments ($4 million). |

[0000833444-19-000005:mdna:70]
| • | The decrease in Building Solutions Asia Pacific was due to unfavorable mix / margin rates ($8 million), higher SG&A ($5 million), incremental investments ($1 million) and the unfavorable impact of foreign currency translation ($1 million), partially offset by higher volumes ($7 million). |

[0000833444-19-000005:mdna:71]
| • | The decrease in Global Products was due to a prior year gain on sale of Scott Safety ($114 million), higher SG&A and operating expenses including planned incremental global product and channel investments, partially offset by productivity savings ($21 million), lower income due to business divestitures ($6 million), lower equity income ($5 million), current year integration costs ($4 million) and the unfavorable impact of foreign currency translation ($3 million). These items were partially offset by favorable volumes / mix ($51 million) and prior year integration costs ($6 million). |

[0000833444-19-000005:mdna:72]
[same as prior period, unchanged from 0000833444-18-000044:mdna:115]

[0000833444-19-000005:mdna:73]
The Company’s backlog relating to the Building Technologies & Solutions business is applicable to its sales of systems and services. At December 31, 2018, the backlog was $8.8 billion, of which $8.5 billion is attributable to the field business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-19-000005:mdna:74]
In the first quarter of fiscal 2019, the Company adopted ASC 606, “Revenue from Contracts with Customers,” and as a result is required to disclose remaining performance obligations. At December 31, 2018, remaining performance obligations were $13.7 billion, which is $4.9 billion higher than the Company's backlog of $8.8 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-19-000005:mdna:75]
| • | Remaining performance obligations include large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which are services to be performed over the building's lifetime with initial contract terms of 25 to 35 years for the entire term of the contract versus backlog which includes only the lifecycle period of these contracts which approximates five years; |

[0000833444-19-000005:mdna:76]
| • | The Company has elected to exclude from remaining performance obligations certain contracts with customers with a term of one year or less or contracts that are cancelable without substantial penalty while these contracts are included within backlog; and |

[0000833444-19-000005:mdna:77]
| • | Remaining performance obligations include the full remaining term of service contracts with substantial termination penalties versus backlog which includes one year for all outstanding service contracts. |

[0000833444-19-000005:mdna:78]
The Company will continue to report backlog as it believes it is a useful measure of evaluating the Company's operational performance and relationship to total orders.

[0000833444-19-000005:mdna:79]
[same as prior period, unchanged from 0000833444-18-000044:mdna:118]

[0000833444-19-000005:mdna:80]
[same as prior period, unchanged from 0000833444-18-000044:mdna:119]

[0000833444-19-000005:mdna:81]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2018 |  | 2018 |  | Change |
| Current assets | $ | 11,955 |  |  | $ | 11,823 |  |  |  |
| Current liabilities | (11,653 | ) |  | (11,250 | ) |  |  |
|  | 302 |  |  | 573 |  |  | -47 | % |
| Less: Cash | (292 | ) |  | (185 | ) |  |  |
| Add: Short-term debt | 2,319 |  |  | 1,306 |  |  |  |
| Add: Current portion of long-term debt | 1 |  |  | 1 |  |  |  |
| Less: Assets held for sale | (3,042 | ) |  | (3,015 | ) |  |  |
| Add: Liabilities held for sale | 1,636 |  |  | 1,791 |  |  |  |
| Working capital (as defined) | $ | 924 |  |  | $ | 471 |  |  | 96 | % |
| Accounts receivable - net | $ | 5,442 |  |  | $ | 5,622 |  |  | -3 | % |
| Inventories | 2,027 |  |  | 1,819 |  |  | 11 | % |
| Accounts payable | 3,273 |  |  | 3,407 |  |  | -4 | % |

[0000833444-19-000005:mdna:82]
| • | The Company defines working capital as current assets less current liabilities, excluding cash, short-term debt, the current portion of long-term debt, and the current portions of assets and liabilities held for sale. Management believes that this measure of working capital, which excludes financing-related items and businesses to be divested, provides a more useful measurement of the Company’s operating performance. |

[0000833444-19-000005:mdna:83]
| • | The increase in working capital at December 31, 2018 as compared to September 30, 2018, was primarily due to an increase in inventory to meet anticipated customer demand and a decrease in accounts payable due to timing of supplier payments. |

[0000833444-19-000005:mdna:84]
| • | The Company’s days sales in accounts receivable at December 31, 2018 were 73 days, higher than 68 days at September 30, 2018. There has been no significant adverse changes in the level of overdue receivables or significant changes in revenue recognition methods. |

[0000833444-19-000005:mdna:85]
| • | The Company’s inventory turns for the three months ended December 31, 2018 were lower than the comparable period ended September 30, 2018, primarily due to changes in inventory production levels. |

[0000833444-19-000005:mdna:86]
| • | Days in accounts payable at December 31, 2018 were 75 days, higher than 72 days at the comparable period ended September 30, 2018. |

[0000833444-19-000005:mdna:87]
51

[0000833444-19-000005:mdna:88]
Cash Flows From Continuing Operations

[0000833444-19-000005:mdna:89]
|  |  | Three Months Ended December 31, |
| (in millions) |  | 2018 |  | 2017 |
| Cash used by operating activities |  | $ | (79 | ) |  | $ | (133 | ) |
| Cash provided (used) by investing activities |  | (136 | ) |  | 1,880 |  |
| Cash provided (used) by financing activities |  | 256 |  |  | (1,450 | ) |
| Capital expenditures |  | (153 | ) |  | (114 | ) |

[0000833444-19-000005:mdna:90]
| • | The decrease in cash used by operating activities for the three months ended December 31, 2018 was primarily due to favorable movements in accounts receivable and other assets, partially offset by income tax refunds in the prior year. |

[0000833444-19-000005:mdna:91]
| • | The increase in cash used by investing activities for the three months ended December 31, 2018 was primarily due to net cash proceeds received from the Scott Safety business divestiture in the prior year. |

[0000833444-19-000005:mdna:92]
| • | The increase in cash provided by financing activities for the three months ended December 31, 2018 was primarily due to prior year repayments of long-term debt, partially offset by higher stock repurchases in the current year. |

[0000833444-19-000005:mdna:93]
| • | The increase in capital expenditures for the three months ended December 31, 2018 primarily relates to increased product investments. |

[0000833444-19-000005:mdna:94]
[same as prior period, unchanged from 0000833444-18-000044:mdna:132]

[0000833444-19-000005:mdna:95]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2018 |  | 2018 |  | Change |
| Short-term debt | $ | 2,319 |  |  | $ | 1,306 |  |  |  |
| Current portion of long-term debt | 1 |  |  | 1 |  |  |  |
| Long-term debt | 9,588 |  |  | 9,623 |  |  |  |
| Total debt | 11,908 |  |  | 10,930 |  |  | 9 | % |
| Less: cash and cash equivalents | 292 |  |  | 185 |  |  |  |
| Total net debt | 11,616 |  |  | 10,745 |  |  | 8 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 20,102 |  |  | 21,164 |  |  | -5 | % |
| Total capitalization | $ | 31,718 |  |  | $ | 31,909 |  |  | -1 | % |
| Total net debt as a % of total capitalization | 36.6 | % |  | 33.7 | % |  |  |

[0000833444-19-000005:mdna:96]
[same as prior period, unchanged from 0000833444-18-000044:mdna:134]

[0000833444-19-000005:mdna:97]
| • | The Company believes its capital resources and liquidity position at December 31, 2018 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in the remainder of fiscal 2019 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company and Tyco International Holding S.à.r.l ("TSarl") are unable to issue commercial paper, they would have the ability to draw on their $2.0 billion and $1.25 billion revolving credit facilities, respectively. Both facilities mature in August 2020. There were no draws on the revolving credit facilities as of December 31, 2018 and September 30, 2018. The Company also selectively makes use of short-term credit lines other than its revolving credit facilities at the Company and TSarl. The Company estimates that, as |

[0000833444-19-000005:mdna:98]
[same as prior period, unchanged from 0000833444-18-000044:mdna:58]

[0000833444-19-000005:mdna:99]
of December 31, 2018, it could borrow up to $1.8 billion based on average borrowing levels during the quarter on committed credit lines. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-19-000005:mdna:100]
| • | The Company’s debt financial covenant in its revolving credit facility require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. TSarl's revolving credit facility contains customary terms and conditions, and a financial covenant that limits the ratio of TSarl's debt to earnings before interest, taxes, depreciation, and amortization as adjusted for certain items set forth in the agreement to 3.5x. TSarl's revolving credit facility also limits its ability to incur subsidiary debt or grant liens on its and its subsidiaries' property. As of December 31, 2018, the Company and TSarl were in compliance with all covenants and other requirements set forth in their credit agreements and the indentures, governing their notes, and expect to remain in compliance for the foreseeable future. None of the Company’s or TSarl's debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the respective borrower's credit rating. |

[0000833444-19-000005:mdna:101]
| • | The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2019, the Company believes the long-term rate of return will approximate 7.10%, 5.20% and 5.65% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first three months of fiscal 2019, the Company made approximately $21 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $85 million in cash to its defined benefit pension plans in fiscal 2019. The Company expects to contribute $15 million in cash to its postretirement plans in fiscal 2019. |

[0000833444-19-000005:mdna:102]
| • | The Company earns a significant amount of its operating income outside of the parent company. Outside basis differences in consolidated subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in fiscal 2019, the Company provided income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain subsidiaries as a result of the planned divestiture of the Power Solutions business. Also, in fiscal 2018, due to U.S. Tax Reform, the Company provided income tax related to the change in the Company’s assertion over the outside basis difference of certain non-U.S. subsidiaries owned directly or indirectly by U.S. subsidiaries. Under U.S. Tax Reform, the U.S. has adopted a territorial tax system that provides an exemption for dividends received by U.S. corporations from 10% or more owned non-U.S. corporations. However, certain non-U.S, U.S. state and withholding taxes may still apply when closing an outside basis difference via distribution or other transactions. The Company currently does not intend nor foresee a need to repatriate undistributed earnings or reduce outside basis differences other than as noted above or in tax efficient manners. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in a tax efficient manner, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings. |

[0000833444-19-000005:mdna:103]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2018 and recorded $255 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2018 restructuring plan will reduce annual operating costs for continuing operations by approximately $300 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in 2020. For fiscal 2019, the savings, net of execution costs, are expected to be approximately 70% of the expected annual operating |

[0000833444-19-000005:mdna:104]
cost reduction. The restructuring action is expected to be substantially complete in 2020. The restructuring plan reserve balance of $155 million at December 31, 2018 is expected to be paid in cash.

[0000833444-19-000005:mdna:105]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2017 and recorded $347 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs for continuing operations by approximately $260 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2019. The restructuring action is expected to be substantially complete in fiscal 2019. The restructuring plan reserve balance of $73 million at December 31, 2018 is expected to be paid in cash. |

[0000833444-19-000005:mdna:106]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2016 and recorded $222 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2016 restructuring plan will reduce annual operating costs for continuing operations by approximately $127 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2019. The restructuring action is expected to be substantially complete in fiscal 2019. The restructuring plan reserve balance of $65 million at December 31, 2018 is expected to be paid in cash. |

[0000833444-19-000005:mdna:107]
[same as prior period, unchanged from 0000833444-18-000044:mdna:147]

[0000833444-19-000005:mdna:108]
[same as prior period, unchanged from 0000833444-18-000044:mdna:148]
