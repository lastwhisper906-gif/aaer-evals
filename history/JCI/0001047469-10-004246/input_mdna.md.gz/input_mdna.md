# JCI MD&A — 0001047469-10-004246


## mdna

[0001047469-10-004246:mdna:1]
[same as prior period, unchanged from 0001047469-10-000401:mdna:1]

[0001047469-10-004246:mdna:2]
[same as prior period, unchanged from 0001047469-10-000401:mdna:2]

[0001047469-10-004246:mdna:3]
[same as prior period, unchanged from 0001047469-10-000401:mdna:3]

[0001047469-10-004246:mdna:4]
[same as prior period, unchanged from 0001047469-10-000401:mdna:4]

[0001047469-10-004246:mdna:5]
[same as prior period, unchanged from 0001047469-10-000401:mdna:5]

[0001047469-10-004246:mdna:6]
[same as prior period, unchanged from 0001047469-10-000401:mdna:6]

[0001047469-10-004246:mdna:7]
[same as prior period, unchanged from 0001047469-10-000401:mdna:7]

[0001047469-10-004246:mdna:8]
[same as prior period, unchanged from 0001047469-10-000401:mdna:8]

[0001047469-10-004246:mdna:9]
[same as prior period, unchanged from 0001047469-10-000401:mdna:9]

[0001047469-10-004246:mdna:10]
[same as prior period, unchanged from 0001047469-10-000401:mdna:10]

[0001047469-10-004246:mdna:11]
[same as prior period, unchanged from 0001047469-10-000401:mdna:11]

[0001047469-10-004246:mdna:12]
[same as prior period, unchanged from 0001047469-10-000401:mdna:12]

[0001047469-10-004246:mdna:13]
[same as prior period, unchanged from 0001047469-10-000401:mdna:13]

[0001047469-10-004246:mdna:14]
[same as prior period, unchanged from 0001047469-10-000401:mdna:14]

[0001047469-10-004246:mdna:15]
[same as prior period, unchanged from 0001047469-10-000401:mdna:15]

[0001047469-10-004246:mdna:16]
[same as prior period, unchanged from 0001047469-10-000401:mdna:16]

[0001047469-10-004246:mdna:17]
References
to the segment data are to the Company's continuing operations. Certain prior period amounts have been reclassified to conform with the current period presentation.
Specifically, the Company has realigned certain business operations during the first quarter of fiscal 2010 resulting in prior period segment amounts being recast. See Note 14 to the
Consolidated Financial Statements.

[0001047469-10-004246:mdna:18]
Overview

[0001047469-10-004246:mdna:19]
Net revenue increased $19 million, or 0.5%, for the quarter ended March 26, 2010 as compared to the quarter ended
March 27, 2009. The increase in revenue for the quarter ended March 26, 2010 was driven by favorable changes in foreign currency exchange rates of $275 million as the U.S. dollar
weakened against most major currencies as nearly 50% of our net revenue is generated outside the

[0001047469-10-004246:mdna:20]
United
States. The increase in net revenue was partially offset by reduced volume in our Flow Control segment and continued weakness in commercial markets, which negatively impacted our ADT Worldwide,
Fire Protection Services and Safety Products segments. Service revenue, which is principally derived from our ADT Worldwide and Fire Protection Services businesses, remained relatively flat
sequentially and grew compared to the same period in the prior year. Service revenue, as a percentage of our overall revenue was 41% for the quarter ended March 26, 2010.

[0001047469-10-004246:mdna:21]
Net
revenue for the six months ended March 26, 2010 decreased $161 million, or 1.9%, as compared to the six months ended March 27, 2009. The decrease in revenue for
the six months ended March 26, 2010 was driven primarily by lower selling prices of steel products in our Electrical and Metal Products segment, reduced volume in our Flow Control segment and
weakness in commercial markets, which negatively impacted our ADT Worldwide, Fire Protection and Safety Products segments. Service revenue grew as a percentage of our overall revenue to 41% for the
six months ended March 26, 2010 as compared to the same period in the prior year. Partially offsetting the net revenue decrease were favorable changes in foreign currency exchange rates of
$539 million for the six months ended March 26, 2010 as the U.S. dollar weakened against most major currencies.

[0001047469-10-004246:mdna:22]
Operating
income for the quarter and six months ended March 26, 2010 was $427 million and $841 million, respectively, compared to an operating loss of
$2.6 billion and $2.1 billion for the quarter and six months ended March 27, 2009. Operating income in 2009 was negatively affected by goodwill and intangible asset impairment
charges of approximately $2.7 billion recorded during the quarter ended March 27, 2009 as well as legacy legal settlement charges of approximately $102 and $110 million for the
quarter and six months ended March 27, 2009. Operating income in 2010 was favorably impacted by efficiencies gained from cost containment actions taken by us in fiscal 2009 and 2008 as well as
restructuring actions taken in prior years. Restructuring and asset impairment charges declined from $104 million and $109 million for the quarter and six months ended March 27,
2009, respectively, to $21 million and $32 million for the quarter and six months ended March 26, 2010, respectively. In addition, operating income for the quarter and six months
ended March 26, 2010 was favorably impacted by net gains on divestitures of approximately $45 million and $44 million, respectively, as compared to a $1 million gain and
$1 million loss on divestitures for the quarter and six months ended March 27, 2009, respectively. Also, lower volumes across all of our segments in the quarter and six months ended
March 26, 2010 negatively impacted operating income as compared to the same periods in the prior year. Changes in foreign currency exchange rates favorably impacted operating income by
$36 million and $70 million for the quarter and six months ended March 26, 2010, respectively.

[0001047469-10-004246:mdna:23]
As
of March 26, 2010, our cash balance was $2.7 billion, as compared to $2.4 billion as of September 25, 2009. The increase was primarily due to cash flow
generated from operating activities of approximately $1.0 billion and proceeds of $498 million received from the issuance of long-term debt partially offset by
$753 million of cash used for acquisitions net of cash acquired, accounts purchased by ADT and capital expenditures and the net repayment of $243 million of short-term debt.
We expect to continue to use our cash to fund internal growth opportunities, improve productivity across all of our businesses, make acquisitions that strategically fit within our ADT Worldwide, Fire
Protection Services and Flow Control businesses and return capital to shareholders. In fiscal 2010, we expect to use up to approximately $600 million of cash to fund the acquisition of Brink's
Home Security Holdings, Inc. ("BHS"), as described below.

[0001047469-10-004246:mdna:24]
On
January 18, 2010, we entered into a definitive agreement to acquire BHS, now operating as Broadview Security, for approximately $2.0 billion or $42.50 per share. The
acquisition is expected to be financed with cash of up to approximately $600 million and the issuance of Tyco common shares. The transaction has been unanimously approved by the board of
directors of each company. The transaction is expected to close shortly after the special meeting of BHS shareholders scheduled for May 12, 2010 assuming all closing conditions are met or
waived. Following the closing of the transaction, we intend to combine BHS with our ADT Worldwide segment.

[0001047469-10-004246:mdna:25]
50

[0001047469-10-004246:mdna:26]
In
2010, we also expect to continue our portfolio refinement efforts by exiting areas that have not provided, and are not expected to provide, an adequate return on investment and take
advantage of restructuring opportunities that are expected to provide significant future cost savings. During the
quarter and six months ended March 26, 2010, we incurred approximately $21 million and $32 million of restructuring and asset impairment charges, respectively. We expect to incur
total restructuring and restructuring related charges of approximately $100 million to $150 million in fiscal 2010.

[0001047469-10-004246:mdna:27]
We
continue to assess the strategic fit of our various businesses and are considering additional divestitures where businesses do not align with our long term vision. We will explore a
number of strategic alternatives for under-performing or non-strategic businesses including divestiture. As part of our portfolio refinement efforts, we sold our french security business
which was part of our ADT Worldwide segment resulting in a pre-tax gain of $53 million for the quarter ended March 26, 2010. The gain and results of operations of the french
security business were presented in continuing operations as the criteria for discontinued operations had not been met.

[0001047469-10-004246:mdna:28]
Goodwill and Intangible Asset Impairments

[0001047469-10-004246:mdna:29]
Annually, in the fiscal fourth quarter, and more frequently if triggering events occur, the Company tests goodwill and indefinite-lived
intangible assets for impairment by comparing the fair value of each reporting unit or indefinite-lived intangible assets with its carrying amount.

[0001047469-10-004246:mdna:30]
As
discussed above, the operating loss for the three and six months ended March 27, 2009 included an aggregate pre-tax goodwill and intangible asset impairment charge
of approximately $2.7 billion. During the first half of 2009, we experienced a decline in revenue in our ADT Worldwide, Fire Protection Services and Safety Products segments as a result of a
slowdown in the commercial markets, including the retailer end market as well as a decline in sales volume primarily due to the downturn in the non-residential construction market at our
Electrical Metal Products segment. We determined that these events and changes in circumstances, along with downward revisions to forecasted results, restructuring actions and weaker industry
outlooks, constituted triggering events for the following six reporting units: EMEA Security and EMEA Fire reporting units within the ADT Worldwide and Fire Protection Services segments, respectively,
Electrical and Metal Products reporting unit within the Electrical and Metal Products segment and Access Control and Video Systems ("ACVS"), Life Safety and Sensormatic Retail Solutions ("SRS")
reporting units within the Safety Products segment. Furthermore, we determined that certain indefinite-lived intangible assets required impairment testing based on the events and changes in
circumstances described as well as the continued deterioration of the business environment related to the retailer end market of our ADT Worldwide and Safety Products segments. As a result of the
triggering events, we performed long-lived asset, goodwill and intangible asset impairment tests for these reporting units and certain of our trade names and franchise rights.

[0001047469-10-004246:mdna:31]
Fair
value of each reporting unit was determined utilizing a discounted cash flow analysis based on our forecast cash flows and revenue and operating income growth rates discounted used
an estimated weighted-average cost of capital for market participants. In determining fair value, management relied on and considered a number of factors, including operating results, business plans,
economic projections including expectations and assumptions regarding the timing and degree of any economic recovery, anticipated cash flow forecasts, comparable market transactions (to the extent
available), other market data, and our overall market capitalization. Our estimated future cash flows (including estimated underlying revenue and operating income growth rates) and weighted-average
cost of capital were the primary assumptions resulting in the carrying values of certain reporting units to exceed their respective fair values. Based on the factors described above, actual and
anticipated reductions in demand for the reporting unit's products and services as well as increased risk due to economic uncertainty, the estimates of future cash flows used in the second quarter of
2009 discounted cash flow analyses were revised downward from the most recent test conducted during the fiscal fourth quarter of

[0001047469-10-004246:mdna:32]
2008.
Furthermore, the range of the weighted-average cost of capital utilized was increased to reflect increased risk due to current economic volatility and uncertainties related to demand for our
products and services. The results of the goodwill impairment tests indicated that the implied goodwill amount was less than the carrying amount of goodwill for each of the aforementioned reporting
units. We recorded an aggregate non-cash impairment charge of $2.6 billion ($2.6 billion after-tax) during the second quarter of 2009. The non-cash
impairment charge was recorded in goodwill and intangible asset impairments in the Consolidated Statements of Operations for the quarter ended March 27, 2009.

[0001047469-10-004246:mdna:33]
Indefinite-lived
intangible assets consisting primarily of trade names are tested for impairment using either a relief from royalty method or excess earnings method. In determining the
fair value of our indefinite-lived intangible assets, management relied on and considered a number of factors, including the selection of discount rates, royalty rates and terminal year growth rate
assumptions, economic projections including expectations and assumptions regarding the timing and degree of any economic recovery and estimates of the amount and timing of future cash flows
attributable to the underlying intangible assets. Based on the factors described above, actual and anticipated reductions in demand as well as increased risk due to economic uncertainty, the estimates
of future cash flows used in determining the fair value of our Safety Products segment Sensormatic tradename as well as certain ADT Worldwide segment franchise rights were revised downward relative to
the estimates used in the tests during the fourth quarter of 2008. Furthermore, the range of the discount rates utilized was increased to reflect increased risk due to current economic volatility and
uncertainties related to demand for our products and services. The results of the impairment test indicated that the Safety Products Sensormatic tradename and ADT Worldwide franchise rights estimated
fair values were less than their respective carrying amounts. As a result, we recorded an aggregate non-cash impairment charge of $64 million ($40 million
after-tax) during the second quarter of 2009. The non-cash impairment charge was recorded in goodwill and intangible asset impairments in the Consolidated Statements of
Operations for the quarter ended March 27, 2009.

[0001047469-10-004246:mdna:34]
52

[0001047469-10-004246:mdna:35]
[same as prior period, unchanged from 0001047469-10-000401:mdna:26]

[0001047469-10-004246:mdna:36]
|  |  | For the Quarters Ended |  | For the Six Months Ended |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | March 26, 2010 |  | March 27, 2009 |  |
| Revenue from product sales |  | $ | 2,469 |  | $ | 2,518 |  | $ | 4,997 |  | $ | 5,286 |  |
| Service revenue |  |  | 1,700 |  |  | 1,632 |  |  | 3,418 |  |  | 3,290 |  |
| Net revenue |  | $ | 4,169 |  | $ | 4,150 |  | $ | 8,415 |  | $ | 8,576 |  |
| Operating income (loss) |  | $ | 427 |  | $ | (2,554 | ) | $ | 841 |  | $ | (2,141 | ) |
| Interest income |  |  | 7 |  |  | 11 |  |  | 16 |  |  | 23 |  |
| Interest expense |  |  | (74 | ) |  | (78 | ) |  | (150 | ) |  | (151 | ) |
| Other income, net |  |  | 3 |  |  | 7 |  |  | 12 |  |  | 11 |  |
| Income (loss) from continuing operations before income taxes |  |  | 363 |  |  | (2,614 | ) |  | 719 |  |  | (2,258 | ) |
| Income tax (expense) benefit |  |  | (51 | ) |  | 60 |  |  | (104 | ) |  | (24 | ) |
| Income (loss) from continuing operations |  |  | 312 |  |  | (2,554 | ) |  | 615 |  |  | (2,282 | ) |
| Loss from discontinued operations, net of income taxes |  |  | — |  |  | (12 | ) |  | — |  |  | (7 | ) |
| Net income (loss) |  | $ | 312 |  | $ | (2,566 | ) | $ | 615 |  | $ | (2,289 | ) |
| Less: Noncontrolling interest in subsidiaries net income |  |  | 2 |  |  | 1 |  |  | 3 |  |  | 1 |  |
| Net income (loss) attributable to Tyco common shareholders |  | $ | 310 |  | $ | (2,567 | ) | $ | 612 |  | $ | (2,290 | ) |

[0001047469-10-004246:mdna:37]
Quarter Ended March 26, 2010 Compared to Quarter Ended March 27, 2009

[0001047469-10-004246:mdna:38]
[same as prior period, unchanged from 0001047469-10-000401:mdna:29]

[0001047469-10-004246:mdna:39]
Net revenue, goodwill and intangible asset impairments, operating income (loss) and operating margin for ADT Worldwide were as follows
($ in millions):

[0001047469-10-004246:mdna:40]
|  |  | For the Quarters Ended |  |  |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | % Change |  |
| Revenue from product sales |  | $ | 557 |  | $ | 537 |  |  | 3.7% | (1) |
| Service revenue |  |  | 1,210 |  |  | 1,168 |  |  | 3.6% | (1) |
| Net revenue |  | $ | 1,767 |  | $ | 1,705 |  |  | 3.6 | % |
| Goodwill and intangible asset impairments |  | $ | — |  | $ | 1,023 |  |  | — | (2) |
| Operating income (loss) |  | $ | 305 |  | $ | (867 | ) |  | — | (2) |
| Operating margin |  |  | 17.3 | % |  | — | (2) |  |  |  |

[0001047469-10-004246:mdna:41]
[same as prior period, unchanged from 0001047469-10-000401:mdna:32]

[0001047469-10-004246:mdna:42]
As
discussed in Note 1 to the Consolidated Financial Statements, revenue related to the sale of electronic tags and labels has been
classified as revenue from product sales during the quarter ended March 26, 2010. During the quarter ended March 27, 2009, the sale of the electronic tags and labels were misclassified
as service revenue. The service revenue and revenue from product sales during the quarter ended March 27, 2009 have not been changed for this misclassification, as the effect is not material.
The impact of the misclassification in the first, second, third and fourth quarters of fiscal 2009 would have been to decrease service revenue by $77 million, $65 million,
$73 million and $71 million, respectively, with corresponding increases to revenue from product sales.

[0001047469-10-004246:mdna:43]
[same as prior period, unchanged from 0001047469-10-000401:mdna:101]

[0001047469-10-004246:mdna:44]
Certain
operating margins and percentages have not been presented as management believes such calculations are not meaningful.

[0001047469-10-004246:mdna:45]
Revenue
from product sales includes sales and installation of electronic security and other life safety systems as well as products related to retailer anti-theft systems.
Service revenue is comprised of electronic security services and maintenance, including the monitoring of burglar alarms, fire alarms and other life safety systems as well as other security services.

[0001047469-10-004246:mdna:46]
Net
revenue by geographic area for ADT Worldwide was as follows ($ in millions):

[0001047469-10-004246:mdna:47]
|  |  | For the Quarters Ended |  |  |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | % Change |  |
| North America |  | $ | 1,033 |  | $ | 1,031 |  |  | 0.2 | % |
| Europe, Middle East and Africa ("EMEA") |  |  | 446 |  |  | 446 |  |  | — | % |
| Rest of World |  |  | 288 |  |  | 228 |  |  | 26.3 | % |
|  |  | $ | 1,767 |  | $ | 1,705 |  |  | 3.6 | % |

[0001047469-10-004246:mdna:48]
Net
revenue for ADT Worldwide increased $62 million, or 3.6%, during the quarter ended March 26, 2010, as compared to the quarter ended March 27, 2009. Net revenue
was favorably impacted by changes in foreign currency exchange rates of $101 million, while growth in recurring revenue was more than offset by lower systems installation, product sales and
other service revenue. Approximately 58% and 55% of ADT Worldwide's total net revenue for the quarters ended March 26, 2010 and March 27, 2009, respectively, represents revenue
associated with monitoring and maintenance services under contractual arrangements, which is considered recurring revenue. Recurring revenue increased by $86 million, or 9.2%, to approximately
$1.0 billion, primarily as a result of growth in customer accounts of approximately 112,000, or 1.5%, to a total of 7.4 million accounts as of March 26, 2010. Changes in foreign
currency exchange rates favorably impacted recurring revenue by $51 million, or 5.4%. Systems
installation, product sales and other service revenue declined by $24 million, or 3.1%, to $743 million due to lower sales volume primarily as the result of continued weakness in
commercial and retailer end markets, which declined at a slower rate than the same period in the prior year. Changes in foreign currency exchange rates favorably impacted systems installation, product
sales and other service revenue by $50 million, or 6.5%, while the net impact of acquisitions and divestitures resulted in an unfavorable impact of $11 million, or 1.5%.

[0001047469-10-004246:mdna:49]
Geographically,
North America net revenue increased $2 million, or 0.2%, due to an increase in recurring revenue and the favorable impact of changes in foreign currency exchange
rates of $17 million, or 1.6%. Partially offsetting these increases was a decline in systems installation, product sales and other service revenue primarily as the result of continued weakness
in commercial and retailer end markets, which has declined at a slower rate than the same period in the prior year. Net revenue in EMEA was flat when compared to the quarter ended March 27,
2009. Changes in foreign currency exchange rates favorably impacted EMEA net revenue by $43 million, or 9.6%. This increase was offset by a decline in systems installation, product sales and
other service revenue as a result of continued weakness in commercial and retailer end markets. Additionally, net revenue was unfavorably impacted by $14 million for the net impact of
acquisitions and divestitures. Recurring revenue in EMEA was relatively flat as compared to the quarter ended March 27, 2009. Rest of World net revenue increased $60 million, or 26.3%,
primarily due to recurring revenue growth in both the Asia Pacific and Latin American regions as ADT Worldwide continues to focus on building its customer account and recurring revenue base in these
markets. Net revenue in the Rest of World was also favorably impacted by changes in foreign currency exchange rates of $41 million, or 18.0%. Additionally, the Rest of World experienced an
increase in systems installation, product sales and other

[0001047469-10-004246:mdna:50]
service
revenue primarily in the Asia Pacific region, which was partially offset by a decrease in the Latin American region due to continued slowdown in commercial and retailer end markets.

[0001047469-10-004246:mdna:51]
Trailing
12-month attrition rates decreased sequentially as well as compared to the quarter ended September 25, 2009 as shown in the following table:

[0001047469-10-004246:mdna:52]
|  |  | For the Quarters Ended |  |
|  |  | March 26, 2010 |  | December 25, 2009 |  | September 25, 2009 |  |
| Trailing 12-month basis attrition |  |  | 13.1 | % |  | 13.4 | %(1) |  | 13.3 | %(1) |

[0001047469-10-004246:mdna:53]
[same as prior period, unchanged from 0001047469-10-000401:mdna:99]

[0001047469-10-004246:mdna:54]
The
trailing 12-month basis attrition rates for the quarters ended December 25, 2009 and September 25, 2009 have
been recast to reflect the divestiture of our french security business, which resulted in a reduction of 0.1% in the amounts previously reported for both periods.

[0001047469-10-004246:mdna:55]
Operating
income increased by approximately $1.2 billion in the quarter ended March 26, 2010 as compared to the same period in the prior year. Operating margin was 17.3% in
the quarter ended March 26, 2010. Operating income for the quarter ended March 27, 2009 was negatively affected by goodwill impairment charges of $959 million recorded at its ADT
EMEA and Sensormatic Retail Solutions reporting units and intangible asset impairment charges of $64 million related to certain franchise rights within North America and tradenames. Operating
income was also positively impacted by the shift to higher margin recurring revenue discussed above. Additionally, operating income was favorably impacted by $51 million of a net gain on
divestitures primarily relating to the divesture of ADT's french security business, the net impact of savings realized through previous restructuring actions and savings realized through cost
containment actions and lower intangible asset amortization related to certain tradenames. During the quarter ended March 26, 2010, $4 million of restructuring
charges were incurred compared to $55 million during the quarter ended March 27, 2009. Changes in foreign currency exchange rates favorably impacted operating income by
$12 million.

[0001047469-10-004246:mdna:56]
[same as prior period, unchanged from 0001047469-10-000401:mdna:44]

[0001047469-10-004246:mdna:57]
[same as prior period, unchanged from 0001047469-10-000401:mdna:45]

[0001047469-10-004246:mdna:58]
|  |  | For the Quarters Ended |  |  |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | % Change |  |
| Revenue from product sales |  | $ | 835 |  | $ | 868 |  |  | (3.8 | )% |
| Service revenue |  |  | 64 |  |  | 59 |  |  | 8.5 | % |
| Net revenue |  | $ | 899 |  | $ | 927 |  |  | (3.0 | )% |
| Operating income |  | $ | 93 |  | $ | 133 |  |  | (30.1 | )% |
| Operating margin |  |  | 10.3 | % |  | 14.3 | % |  |  |  |

[0001047469-10-004246:mdna:59]
Net
revenue for Flow Control decreased $28 million, or 3.0%, in the quarter ended March 26, 2010 compared to the quarter ended March 27, 2009. The decrease in net
revenue was primarily driven by reduced volume in the valves business across all regions and to a lesser extent reduced project activity in the water business. These decreases were offset by favorable
changes in foreign currency exchange rates of $92 million and a slight increase of project activity within the thermal controls business.

[0001047469-10-004246:mdna:60]
The
decrease in operating income of $40 million, or 30.1%, in the quarter ended March 26, 2010, as compared to the same period in the prior year, was primarily due to
decreased volume in the valves

[0001047469-10-004246:mdna:61]
business
as well as an expected loss related to completion of a long-term construction project and an increase of product warranty reserves in the water business, primarily in the Asia Pacific region.
The decline in operating income was partially offset by savings realized through cost containment and restructuring actions. Changes in foreign currency exchange rates favorably impacted operating
income by $14 million.

[0001047469-10-004246:mdna:62]
[same as prior period, unchanged from 0001047469-10-000401:mdna:49]

[0001047469-10-004246:mdna:63]
Net revenue, goodwill impairment, operating income (loss) and operating margin for Fire Protection Services were as follows ($ in
millions):

[0001047469-10-004246:mdna:64]
|  |  | For the Quarters Ended |  |  |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | % Change |  |
| Revenue from product sales |  | $ | 385 |  | $ | 411 |  |  | (6.3 | )% |
| Service revenue |  |  | 422 |  |  | 402 |  |  | 5.0 | % |
| Net revenue |  | $ | 807 |  | $ | 813 |  |  | (0.7 | )% |
| Goodwill impairment |  | $ | — |  | $ | 180 |  |  | — | (1) |
| Operating income (loss) |  |  | 62 |  |  | (121 | ) |  | — | (1) |
| Operating margin |  |  | 7.7 | % |  | — | (1) |  |  |  |

[0001047469-10-004246:mdna:65]
(1)

[0001047469-10-004246:mdna:66]
Certain
operating margins and percentage changes have not been presented as management believes such calculations are not meaningful.

[0001047469-10-004246:mdna:67]
[same as prior period, unchanged from 0001047469-10-000401:mdna:52]

[0001047469-10-004246:mdna:68]
[same as prior period, unchanged from 0001047469-10-000401:mdna:53]

[0001047469-10-004246:mdna:69]
|  |  | For the Quarters Ended |  |  |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | % Change |  |
| North America |  | $ | 466 |  | $ | 486 |  |  | (4.1 | )% |
| International |  |  | 341 |  |  | 327 |  |  | 4.3 | % |
| Net revenue |  | $ | 807 |  | $ | 813 |  |  | (0.7 | )% |

[0001047469-10-004246:mdna:70]
Net
revenue for Fire Protection Services decreased $6 million, or 0.7%, during the quarter ended March 26, 2010 compared to the quarter ended March 27, 2009. This
decrease was primarily due to continued weakness in commercial markets, which more than offset the favorable changes in foreign currency exchange rates of $51 million, or 6.3%. Geographically,
net revenue in North America decreased $20 million, or 4.1%, primarily due to the continued decline in systems installation and upgrade activity as well as a decline in service revenue in the
sprinkler business. Changes in foreign currency exchange rates favorably impacted revenue in North America by $10 million, or 2.1%. Net revenue in our international fire businesses increased by
$14 million, or 4.3% largely due to the favorable impact of changes in foreign currency exchange rates of $41 million, or 12.5%, partially offset by a decrease in revenue due to
continued weakness in the European commercial markets.

[0001047469-10-004246:mdna:71]
Operating
income increased $183 million in the quarter ended March 26, 2010 as compared to the same period in the prior year. Operating income for the quarter ended
March 27, 2009 was negatively affected by goodwill impairment charges of $180 million recorded at its EMEA Fire reporting unit. Operating income was favorably impacted by the savings
realized through cost containment actions and

[0001047469-10-004246:mdna:72]
to
a lesser extent favorable changes in foreign currency exchange rates of $4 million. The increase was partially offset by the decreased sales volume discussed above. During the quarter ended
March 26, 2010, $4 million of restructuring charges were incurred as compared to $11 million of restructuring charges in the quarter ended March 27, 2009.

[0001047469-10-004246:mdna:73]
[same as prior period, unchanged from 0001047469-10-000401:mdna:57]

[0001047469-10-004246:mdna:74]
Net revenue, goodwill impairment, operating income (loss) and operating margin for Electrical and Metal Products were as follows ($ in
millions):

[0001047469-10-004246:mdna:75]
|  |  | For the Quarters Ended |  |  |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | % Change |  |
| Revenue from product sales |  | $ | 335 |  | $ | 329 |  |  | 1.8 | % |
| Service revenue |  |  | 1 |  |  | 1 |  |  | — | % |
| Net revenue |  | $ | 336 |  | $ | 330 |  |  | 1.8 | % |
| Goodwill impairment |  | $ | — |  | $ | 935 |  |  | — | (1) |
| Operating income (loss) |  |  | 24 |  |  | (961 | ) |  | — | (1) |
| Operating margin |  |  | 7.1 | % |  | — | (1) |  |  |  |

[0001047469-10-004246:mdna:76]
(1)

[0001047469-10-004246:mdna:77]
Certain
operating margins and percentage changes have not been presented as management believes such calculations are not meaningful.

[0001047469-10-004246:mdna:78]
Net
revenue for Electrical and Metal Products increased $6 million, or 1.8%, in the quarter ended March 26, 2010 compared to the quarter ended
March 27, 2009. The increase in revenue was primarily due to increased volume for steel products and higher selling prices of armored cable products. These increases were partially offset by
lower volume for armored cable products and lower selling prices of steel products. Changes in foreign currency exchange rates had a favorable impact of $13 million.

[0001047469-10-004246:mdna:79]
Operating
income increased $985 million in the quarter ended March 26, 2010 as compared to the same period in the prior year. Operating income for the quarter ended
March 27, 2009 was negatively affected by goodwill impairment charges of $935 million recorded at its Electrical and Metal Products reporting unit. Also contributing to the increase in
operating income was the increased volume as well as higher spreads for steel products. Lower raw material costs more than offset lower selling prices which resulted in higher spreads for steel
products.

[0001047469-10-004246:mdna:80]
[same as prior period, unchanged from 0001047469-10-000401:mdna:63]

[0001047469-10-004246:mdna:81]
Net revenue, goodwill impairments, operating income (loss) and operating margin for Safety Products were as follows ($ in millions):

[0001047469-10-004246:mdna:82]
|  |  | For the Quarters Ended |  |  |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | % Change |  |
| Revenue from product sales |  | $ | 357 |  | $ | 373 |  |  | (4.3 | )% |
| Service revenue |  |  | 3 |  |  | 2 |  |  | 50.0 | % |
| Net revenue |  | $ | 360 |  | $ | 375 |  |  | (4.0 | )% |
| Goodwill impairments |  | $ | — |  | $ | 567 |  |  | — | (1) |
| Operating income (loss) |  | $ | 47 |  | $ | (537 | ) |  | — | (1) |
| Operating margin |  |  | 13.1 | % |  | — | (1) |  |  |  |

[0001047469-10-004246:mdna:83]
(1)

[0001047469-10-004246:mdna:84]
Certain
operating margins and percentage changes have not been presented as management believes such calculations are not meaningful.

[0001047469-10-004246:mdna:85]
Net revenue for Safety Products decreased $15 million, or 4.0%, during the quarter ended March 26, 2010 as compared to the quarter
ended March 27, 2009. The decrease in net revenue is primarily due to lower volume in our fire suppression and electronic security businesses. The decrease in our fire suppression business was
primarily due to reduced spending in the commercial construction market. The electronic security business decrease was primarily due to the continued slow down in the retail sector, as retail capital
projects and new store openings continue to be canceled or delayed. Net revenue was favorably impacted by changes in foreign currency exchange rates of $18 million and was unfavorably impacted
by $6 million for the net impact of acquisitions and divestitures.

[0001047469-10-004246:mdna:86]
Operating
income increased $584 million during the quarter ended March 26, 2010 compared to the same period in the prior year. Operating income for the quarter ended
March 27, 2009 was negatively affected by goodwill impairment charges of $567 million recorded at its ACVS and Life Safety reporting units. Additionally, restructuring and divestiture
charges, net was $5 million during the quarter ended March 26, 2010 as compared to $21 million of restructuring charges during the quarter ended March 27, 2009. Savings
realized through cost containment and restructuring actions also contributed to the increase in operating income, although partially offset by the sales volume decline as discussed above.

[0001047469-10-004246:mdna:87]
[same as prior period, unchanged from 0001047469-10-000401:mdna:68]

[0001047469-10-004246:mdna:88]
Corporate expense decreased $97 million, or 48.3%, to $104 million in the quarter ended March 26, 2010 compared to
$201 million in the quarter ended March 27, 2009. The decrease in expense relates primarily to $101 million of charges to establish a reserve related to unresolved legacy
securities matters during the quarter ended March 27, 2009. Additionally, during the second quarter ended March 27, 2009, we agreed to settle two legacy securities matters for
$17 million, which was partially offset by a $16 million benefit related to a settlement reached with a former executive. Additionally, Corporate expense for the quarter ended
March 27, 2009 included $6 million of restructuring charges as compared to nil for the quarter ended March 26, 2010. Corporate expense for the quarter ended March 26, 2010
included $4 million relating to divestiture charges and $3 million related to acquisition costs as compared to nil for the quarter ended March 27, 2009.

[0001047469-10-004246:mdna:89]
[same as prior period, unchanged from 0001047469-10-000401:mdna:70]

[0001047469-10-004246:mdna:90]
Interest income was $7 million and $11 million during the quarters ended March 26, 2010 and March 27, 2009,
respectively. The decrease in interest income is primarily related to lower investment yields.

[0001047469-10-004246:mdna:91]
Interest
expense was $74 million in the quarter ended March 26, 2010 compared to $78 million in the quarter ended March 27, 2009. The decrease in interest
expense is primarily related to outstanding credit facility and commercial paper balances during the quarter ended March 27, 2009.

[0001047469-10-004246:mdna:92]
[same as prior period, unchanged from 0001047469-10-000401:mdna:73]

[0001047469-10-004246:mdna:93]
Other income, net was $3 million and $7 million during the quarters ended March 26, 2010, March 27, 2009,
respectively. Other income, net for the quarter ended March 26, 2010 primarily relates to an increase in receivables due from Covidien and Tyco Electronics under the Tax Sharing Agreement.

[0001047469-10-004246:mdna:94]
[same as prior period, unchanged from 0001047469-10-000401:mdna:75]

[0001047469-10-004246:mdna:95]
Our effective income tax rate was 14.0% during the quarter ended March 26, 2010. The effective income tax rate for the second
quarter of 2009 was not meaningful primarily as a result of the loss driven by goodwill impairment charges of $2.6 billion for which almost no tax benefit was available. Taxes were positively
impacted by a non-recurring benefit to income taxes related to the Company's on-going income tax audits as well as limited tax on certain business dispositions for the quarter ended March 26,
2010.

[0001047469-10-004246:mdna:96]
Six Months Ended March 26, 2010 Compared to Six Months Ended March 27, 2009

[0001047469-10-004246:mdna:97]
ADT Worldwide

[0001047469-10-004246:mdna:98]
Net revenue, goodwill and intangible asset impairments, operating income (loss) and operating margin for ADT Worldwide were as follows
($ in millions):

[0001047469-10-004246:mdna:99]
|  |  | For the Six Months Ended |  |  |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | % Change |  |
| Revenue from product sales |  | $ | 1,188 |  | $ | 1,173 |  |  | 1.3% | (1) |
| Service revenue |  |  | 2,414 |  |  | 2,343 |  |  | 3.0% | (1) |
| Net revenue |  | $ | 3,602 |  | $ | 3,516 |  |  | 2.4 | % |
| Goodwill and intangible asset impairments |  | $ | — |  | $ | 1,023 |  |  | — | (2) |
| Operating income (loss) |  |  | 564 |  |  | (640 | ) |  | — | (2) |
| Operating margin |  |  | 15.7 | % |  | — | (2) |  |  |  |

[0001047469-10-004246:mdna:100]
(1)

[0001047469-10-004246:mdna:101]
As
discussed in Note 1 to the Consolidated Financial Statements, revenue related to the sale of electronic tags and labels has been
classified as revenue from product sales for the six months ended March 26, 2010. During the six months ended March 27, 2009, the sale of the electronic tags and labels were
misclassified as service revenue. The service revenue and revenue from product sales during the quarter ended March 27, 2009 have not been changed for this misclassification, as the effect is
not material. The impact of the misclassification in the first, second, third and fourth quarters of fiscal 2009 would have been to decrease service revenue by $77 million, $65 million,
$73 million and $71 million, respectively, with corresponding increases to revenue from product sales.

[0001047469-10-004246:mdna:102]
(2)

[0001047469-10-004246:mdna:103]
Certain
operating margins and percentages have not been presented as management believes such calculations are not meaningful.

[0001047469-10-004246:mdna:104]
Revenue
from product sales includes sales and installation of electronic security and other life safety systems as well as products related to retailer anti-theft systems.
Service revenue is comprised of electronic security services and maintenance, including the monitoring of burglar alarms, fire alarms and other life safety systems as well as other security services.

[0001047469-10-004246:mdna:105]
Net
revenue by geographic area for ADT Worldwide was as follows ($ in millions):

[0001047469-10-004246:mdna:106]
|  |  | For the Six Months Ended |  |  |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | % Change |  |
| North America |  | $ | 2,089 |  | $ | 2,100 |  |  | (0.5 | )% |
| Europe, Middle East and Africa ("EMEA") |  |  | 931 |  |  | 930 |  |  | 0.1 | % |
| Rest of World |  |  | 582 |  |  | 486 |  |  | 19.8 | % |
|  |  | $ | 3,602 |  | $ | 3,516 |  |  | 2.4 | % |

[0001047469-10-004246:mdna:107]
Net
revenue for ADT Worldwide increased $86 million, or 2.4%, for the six months ended March 26, 2010, as compared to the same period ended March 27, 2009. Net
revenue was favorably impacted by changes in foreign currency exchange rates of $190 million, while growth in recurring revenue was more than offset by lower systems installation, product sales
and other service revenue. Approximately 57% and 53% of ADT Worldwide's total net revenue for the six months ended March 26, 2010 and March 27, 2009, respectively, represents revenue
associated with monitoring and maintenance services under contractual arrangements, which is considered recurring revenue. Recurring revenue increased by $175 million, or 9.3%, to approximately
$2.1 billion as a result of growth in customer accounts of 112,000, or 1.5%, to a total of approximately 7.4 million accounts as of March 26,

[0001047469-10-004246:mdna:108]
59

[0001047469-10-004246:mdna:109]
2010.
Changes in foreign currency exchange rates favorably impacted recurring revenue by $92 million, or 4.9%. Systems installation, product sales and other service revenue declined by
$89 million, or 5.4%,
to approximately $1.5 billion due to lower sales volume primarily as the result of continued weakness in commercial and retailer end markets, which have declined at a slower rate than the same
period in the prior year. Changes in foreign currency exchange rates favorably impacted systems installation, product sales and other service revenue by $98 million, or 6.0%, while the net
impact of acquisitions and divestitures resulted in an unfavorable impact of $16 million, or 1.0%.

[0001047469-10-004246:mdna:110]
Geographically,
North America net revenue decreased $11 million, or 0.5%, due to a decline in systems installation, product sales and other service revenue as the result of
continued weakness in commercial and retailer end markets. This decrease was partially offset by an increase in recurring revenue and favorable changes in foreign currency exchange rates of
$29 million, or 1.4%. Net revenue in EMEA remained relatively flat as favorable changes in foreign currency exchange rates of $88 million, or 9.5% were almost entirely offset by a
decline in systems installation, product sales and other service revenue as a result of continued weakness in commercial and retailer end markets, which has declined at a slower rate than the same
period in the prior year. Additionally, EMEA net revenue was unfavorably impacted by $19 million for the net impact of acquisitions and divestitures. Recurring revenue in EMEA remained
relatively flat when compared to the six months ended March 27, 2009. Net revenue increased $96 million, or 19.8%, in the Rest of World geographies primarily due to recurring revenue
growth in both the Asia Pacific and Latin American regions as ADT Worldwide continues to focus on building its customer account and recurring revenue base in these markets. This increase was partially
offset by a decline in system installation, products sales and other service revenue in the Latin American region due to continued slowdown in commercial and retailer end markets. Net revenue in the
Rest of World geographics was also favorably impacted by changes in foreign currency exchange rates of $73 million, or 15.0%.

[0001047469-10-004246:mdna:111]
Trailing
12-month attrition rates decreased as compared to the quarters ended September 25, 2009 and March 27, 2009 as shown in the following table:

[0001047469-10-004246:mdna:112]
|  |  | For the Quarters Ended |  |
|  |  | March 26, 2010 |  | September 25, 2009 |  | March 27, 2009 |  |
| Trailing 12-month basis attrition |  |  | 13.1 | % |  | 13.4 | %(1) |  | 13.3 | %(1) |

[0001047469-10-004246:mdna:113]
(1)

[0001047469-10-004246:mdna:114]
The
trailing 12-month basis attrition rates for the quarters ended December 25, 2009 and September 25, 2009 have
been recast to reflect the divestiture of our french security business, which resulted in a reduction of 0.1% in the amounts previously reported for both periods.

[0001047469-10-004246:mdna:115]
Operating
income increased by approximately $1.2 billion for the six months ended March 26, 2010 as compared to the same period in the prior year. Operating
margin was 15.7% for the six months ended March 26, 2010. Operating income for the six months ended March 27, 2009 was negatively affected by goodwill impairment charges of
$959 million recorded at its ADT EMEA and Sensormatic Retail Solutions reporting units and intangible asset impairment charges of $64 million related to certain franchise rights within
North America and tradenames. Operating income was also positively impacted by the shift to higher margin recurring revenue discussed above. Additionally, operating income was favorably impacted by
the net impact of savings realized through previous restructuring actions and savings realized through cost containment actions and lower intangible asset amortization related to certain tradenames.
For the six months ended March 26, 2010, $9 million of restructuring charges were incurred compared to $56 million of restructuring and asset impairment charges during the six
months ended March 27, 2009. The six months ended March 26, 2010 also included a $51 million gain on divestitures, net related to the sale of its french security business. Changes
in foreign currency exchange rates favorably impacted operating income by $22 million.

[0001047469-10-004246:mdna:116]
60

[0001047469-10-004246:mdna:117]
Flow Control

[0001047469-10-004246:mdna:118]
Net revenue, operating income and operating margin for Flow Control were as follows ($ in millions):

[0001047469-10-004246:mdna:119]
|  |  | For the Six Months Ended |  |  |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | % Change |  |
| Revenue from product sales |  | $ | 1,673 |  | $ | 1,760 |  |  | (4.9 | )% |
| Service revenue |  |  | 149 |  |  | 126 |  |  | 18.3 | % |
| Net revenue |  | $ | 1,822 |  | $ | 1,886 |  |  | (3.4 | )% |
| Operating income |  | $ | 205 |  | $ | 270 |  |  | (24.1 | )% |
| Operating margin |  |  | 11.3 | % |  | 14.3 | % |  |  |  |

[0001047469-10-004246:mdna:120]
Net
revenue for Flow Control decreased $64 million, or 3.4%, for the six months ended March 26, 2010 compared to the same period ended March 27, 2009. The decrease
in net revenue was primarily driven by reduced volume in the valves business across all regions and to a lesser extent the absence of large project work in the thermal controls business as well as
reduced project activity in the water business. Changes in foreign currency exchange rates favorably impacted net revenue by $188 million.

[0001047469-10-004246:mdna:121]
The
decrease in operating income of $65 million, or 24.1%, for the six months ended March 26, 2010, as compared to the same period in the prior year, was primarily due to
decreased volume across all regions in the valves business and absence of large project work in the thermal controls business offset by margin improvements in the water business within the EMEA region
and favorable changes in foreign currency exchange rates of $29 million. Operating income was negatively impacted by $14 million of restructuring charges for the six months ended
March 26, 2010 as compared to $10 million of restructuring and divestiture charges, net during the same period ended March 27, 2009. The decline in operating income was partially
offset by savings realized through cost containment and restructuring actions.

[0001047469-10-004246:mdna:122]
Fire Protection Services

[0001047469-10-004246:mdna:123]
Net revenue, goodwill impairment, operating income (loss) and operating margin for Fire Protection Services were as follows ($ in
millions):

[0001047469-10-004246:mdna:124]
|  |  | For the Six Months Ended |  |  |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | % Change |  |
| Revenue from product sales |  | $ | 792 |  | $ | 837 |  |  | (5.4 | )% |
| Service revenue |  |  | 848 |  |  | 815 |  |  | 4.0 | % |
| Net revenue |  | $ | 1,640 |  | $ | 1,652 |  |  | (0.7 | )% |
| Goodwill impairment |  | $ | — |  | $ | 180 |  |  | — | (1) |
| Operating income (loss) |  |  | 126 |  |  | (65 | ) |  | — | (1) |
| Operating margin |  |  | 7.7 | % |  | — | (1) |  |  |  |

[0001047469-10-004246:mdna:125]
(1)

[0001047469-10-004246:mdna:126]
Certain
operating margins and percentage changes have not been presented as management believes such calculations are not meaningful.

[0001047469-10-004246:mdna:127]
Revenue
from product sales includes sales and installation of fire protection and other systems. Service revenue consists of inspection, maintenance, service and monitoring of fire
detection and suppression systems.

[0001047469-10-004246:mdna:128]
Net
revenue by geographic area for Fire Protection Services was as follows ($ in millions):

[0001047469-10-004246:mdna:129]
|  |  | For the Six Months Ended |  |  |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | % Change |  |
| North America |  | $ | 935 |  | $ | 977 |  |  | (4.3 | )% |
| International |  |  | 705 |  |  | 675 |  |  | 4.4 | % |
| Net revenue |  | $ | 1,640 |  | $ | 1,652 |  |  | (0.7 | )% |

[0001047469-10-004246:mdna:130]
Net
revenue for Fire Protection Services decreased $12 million, or 0.7%, during the six months ended March 26, 2010 compared to the same period ended March 27, 2009.
This decrease was primarily due to continued weakness in commercial markets, which more than offset the favorable changes in foreign currency exchange rates of $100 million, or 6.1%.
Geographically, net revenue in North America decreased $42 million, or 4.3%, primarily due to the continued decline in systems installation and upgrade activity as well as service revenue in
the sprinkler business. Changes in foreign currency exchange rates favorably impacted revenue in North America by $17 million, or 1.7%. Net revenue in our international fire businesses
increased by $30 million, or 4.4%, largely due to the favorable impact of changes in foreign currency exchange rates of $83 million, or 12.3%, partially offset by a decrease in revenue
due to continued weakness in the European commercial markets.

[0001047469-10-004246:mdna:131]
Operating
income increased $191 million for the six months ended March 26, 2010 as compared to the same period in the prior year. Operating income for the six months ended
March 27, 2009 was negatively affected by goodwill impairment charges of $180 million recorded at its EMEA Fire reporting unit. Additionally, operating income was favorably impacted by
savings realized through cost containment actions, a reduction in legal costs and to a lesser extent favorable changes in foreign currency exchange rates of $7 million. During the six months
ended March 26, 2010, $4 million of restructuring and divestiture charges, net were incurred as compared to $11 million of restructuring
charges in the six months ended March 27, 2009. The increase was partially offset by the decreased sales volume discussed above.

[0001047469-10-004246:mdna:132]
Electrical and Metal Products

[0001047469-10-004246:mdna:133]
Net revenue, goodwill impairment, operating income (loss) and operating margin for Electrical and Metal Products were as follows ($ in
millions):

[0001047469-10-004246:mdna:134]
|  |  | For the Six Months Ended |  |  |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | % Change |  |
| Revenue from product sales |  | $ | 631 |  | $ | 744 |  |  | (15.2 | )% |
| Service revenue |  |  | 2 |  |  | 2 |  |  | — | % |
| Net revenue |  | $ | 633 |  | $ | 746 |  |  | (15.1 | )% |
| Goodwill impairment |  | $ | — |  | $ | 935 |  |  | — | (1) |
| Operating income (loss) |  | $ | 47 |  | $ | (934 | ) |  | — | (1) |
| Operating margin |  |  | 7.4 | % |  | — | (1) |  |  |  |

[0001047469-10-004246:mdna:135]
(1)

[0001047469-10-004246:mdna:136]
Certain
operating margins and percentage changes have not been presented as management believes such calculations are not meaningful.

[0001047469-10-004246:mdna:137]
Net
revenue for Electrical and Metal Products decreased $113 million, or 15.1%, for the six months ended March 26, 2010 compared to the same period ended March 27,
2009. The decrease in revenue was primarily due to lower selling prices of steel products, partially offset by higher volume of steel products. Also contributing to the decline were lower volumes for
armored cable products

[0001047469-10-004246:mdna:138]
62

[0001047469-10-004246:mdna:139]
partially
offset by higher selling prices for armored cable products. Changes in foreign currency exchange rates had a favorable impact of $25 million.

[0001047469-10-004246:mdna:140]
Operating
income increased $981 million for the six months ended March 26, 2010 as compared to the same period in the prior year. Operating income for the six months ended
March 27, 2009 was negatively affected by goodwill impairment charges of $935 million recorded at its Electrical and Metal Products reporting unit. Also contributing to the increase in
operating income was the increased volume as discussed above as well as higher spreads for steel products. Lower raw material costs more than offset lower selling prices which resulted in higher
spreads for steel products.

[0001047469-10-004246:mdna:141]
Safety Products

[0001047469-10-004246:mdna:142]
Net revenue, goodwill impairments, operating income (loss) and operating margin for Safety Products were as follows ($ in millions):

[0001047469-10-004246:mdna:143]
|  |  | For the Six Months Ended |  |  |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | % Change |  |
| Revenue from product sales |  | $ | 713 |  | $ | 772 |  |  | (7.6 | )% |
| Service revenue |  |  | 5 |  |  | 4 |  |  | 25.0 | % |
| Net revenue |  | $ | 718 |  | $ | 776 |  |  | (7.5 | )% |
| Goodwill impairments |  | $ | — |  | $ | 567 |  |  | — | (1) |
| Operating income (loss) |  | $ | 101 |  | $ | (457 | ) |  | — | (1) |
| Operating margin |  |  | 14.1 | % |  | — | (1) |  |  |  |

[0001047469-10-004246:mdna:144]
(1)

[0001047469-10-004246:mdna:145]
Certain
operating margins and percentage changes have not been presented as management believes such calculations are not meaningful.

[0001047469-10-004246:mdna:146]
Net
revenue for Safety Products decreased $58 million, or 7.5%, for the six months ended March 26, 2010 as compared to the same period ended March 27, 2009. The
decrease in net revenue is primarily due to lower volume in our fire suppression and electronic security businesses. The decrease in our fire suppression business was primarily due to reduced spending
in the commercial construction market. The electronic security business decrease was primarily due to the continued slow down in the retail sector, as retail capital projects and new store openings
continue to be canceled or delayed. Net revenue was favorably impacted by changes in foreign currency exchange rates of $36 million and was unfavorably impacted by $12 million for the
net impact of acquisitions and divestitures.

[0001047469-10-004246:mdna:147]
Operating
income increased $558 million during the quarter ended March 26, 2010 compared to the same period in the prior year. Operating income for the six months ended
March 27, 2009 was negatively affected by goodwill impairment charges of $567 million recorded at its ACVS and Life Safety reporting units. Additionally, restructuring, asset impairment
and divestiture charges, net was $4 million during the six months ended March 26, 2010 as compared to $22 million of restructuring charges during the six months ended
March 27, 2009. Savings realized through cost containment and restructuring actions also contributed to the increase in operating income and was partially offset by the sales volume decline as
discussed above. Changes in foreign currency exchange rates also favorably impacted operating income by $6 million.

[0001047469-10-004246:mdna:148]
Corporate and Other

[0001047469-10-004246:mdna:149]
Corporate expense decreased $113 million, or 35.9%, to $202 million for the six months ended March 26, 2010
compared to $315 million in the same period ended March 27, 2009. The decrease in Corporate expense for the six months ended March 26, 2010 primarily relates to
$126 million of charges related to legacy securities matters, partially offset by a $16 million benefit related to a settlement reached with a former executive recorded during the six
months ended March 27, 2009.

[0001047469-10-004246:mdna:150]
63

[0001047469-10-004246:mdna:151]
Additionally,
Corporate expense for the six months ended March 27, 2009 included $6 million of restructuring charges, as compared to nil for the six months ended March 26, 2010.
The remaining decrease in Corporate expense is primarily related to savings realized through cost containment actions. Corporate expense for the six months ended March 26, 2010 also includes
$6 million of net divestiture charges and $3 million of acquisition costs as compared to $2 million of divestiture charges, net for the six months ended March 27, 2009.

[0001047469-10-004246:mdna:152]
Interest Income and Expense

[0001047469-10-004246:mdna:153]
Interest income was $16 million and $23 million for the six months ended March 26, 2010 and March 27, 2009,
respectively. The decrease in interest income is primarily related to lower investment yields.

[0001047469-10-004246:mdna:154]
Interest
expense was $150 million for the six months ended March 26, 2010 as compared to $151 million for the same period in the prior year.

[0001047469-10-004246:mdna:155]
Other Income, Net

[0001047469-10-004246:mdna:156]
Other income, net was $12 million for the six months ended March 26, 2010 as compared to $11 million for the same
period in the prior year.

[0001047469-10-004246:mdna:157]
Effective Income Tax Rate

[0001047469-10-004246:mdna:158]
Our effective income tax rate was 14.5% for the six months ended March 26, 2010. The effective income tax rate for the six
months ended March 27, 2009 was not meaningful primarily as a result of the loss driven by goodwill impairment charges of $2.6 billion for which almost no tax benefit was available.
Taxes were positively impacted by limited tax on certain business dispositions, beneficial enacted tax law changes and a non-recurring item generating a tax benefit for the six months ended
March 26, 2010.

[0001047469-10-004246:mdna:159]
[same as prior period, unchanged from 0001047469-10-000401:mdna:83]

[0001047469-10-004246:mdna:160]
[same as prior period, unchanged from 0001047469-10-000401:mdna:84]

[0001047469-10-004246:mdna:161]
During
the fourth quarter of 2009, the Company approved a plan to sell its french security business, which was part of the Company's ADT Worldwide segment. This business has been
classified as held for sale as of September 25, 2009, however, its results of operations were presented in continuing operations as the criteria for discontinued operations have not been met.
During March 2010, the Company completed the sale and recorded a $53 million pre-tax gain within restructuring, asset impairment and (gain)/loss on divestitures, net in the
Company's Consolidated Statement of Operations.

[0001047469-10-004246:mdna:162]
During
the third quarter of 2008, the Company approved a plan to sell a business in its Safety Products segment. This business had been classified as held for sale in the Company's
historical Consolidated Balance Sheet. During the second quarter of 2009, due to a change in strategy by management, the Company decided not to sell the business. As a result, the business no longer
satisfied the requirements to be classified as held for sale. The Company measured the business at the lower of its (i) carrying amount before it was classified as held for sale, adjusted for
depreciation and amortization expense that would have been recognized had the business been continuously classified as held and used, or (ii) fair value at the date the decision not to sell was
made. The Company recorded a charge of $8 million in the second quarter of 2009 relating to the amount of depreciation and amortization expense that would have been recorded had the asset been
continuously classified as held and used.

[0001047469-10-004246:mdna:163]
64

[0001047469-10-004246:mdna:164]
Discontinued Operations

[0001047469-10-004246:mdna:165]
In July 2008, the Company substantially completed the sale of its Infrastructure Services business, which met the criteria to be
presented as discontinued operations. In order to complete the sale of Earth Tech Brasil Ltda. ("ET Brasil") and Earth Tech UK businesses and certain assets in China, the Company was required
to obtain consents and approvals to transfer the legal ownership of the businesses and assets. On January 22, 2009 the Company received the necessary consents and approvals to transfer the
legal ownership of its ET Brasil business to Corioca Christiani-Nielsen Engenharia S.A. and received cash proceeds of approximately $13 million. On February 27, 2009 the Company
received the necessary consents to transfer certain of the China assets and received cash proceeds of $18 million. At March 27, 2009, the necessary consents and approvals for Earth Tech
UK and the remaining assets in China had not been obtained by the Company. At March 27, 2009, the Company had assessed and determined that the carrying value of the remaining assets were
recoverable based on current fair value, less cost to sell. The remaining consents and approvals for the other businesses and assets were obtained during the second half of fiscal 2009.

[0001047469-10-004246:mdna:166]
Acquisitions

[0001047469-10-004246:mdna:167]
On January 18, 2010, the Company entered into a definitive agreement to acquire Brink's Home Security Holdings, Inc ("BHS"), now
operating as Broadview Security, for approximately $2.0 billion or $42.50 per share. The acquisition is expected to be financed with cash of up to approximately $600 million, and the
issuance of Tyco common shares. The transaction has been unanimously approved by the board of directors of each company. The transaction is expected to close shortly after the special meeting of BHS
shareholders scheduled for May 12, 2010 assuming all closing conditions are met or waived. Following the closing of the transaction, the Company intends to combine BHS with its ADT Worldwide
segment. In conjunction with the acquisition of BHS, the Company has incurred acquisition costs of $4 million, which are recorded in selling, general and administrative expenses in the
Company's Consolidated Statement of Operations for the quarter and six months ended March 26, 2010.

[0001047469-10-004246:mdna:168]
During
the quarter and six months ended March 26, 2010, cash paid for acquisitions included in continuing operations totaled $9 million and $152 million,
respectively, net of cash acquired of nil and $1 million, respectively, which primarily related to the acquisition of two Brazilian valve companies, including Hiter Industria e Comercio de
Controle Termo-Hidraulico Ltda ("Hiter"), a valve manufacturer which serves a variety of industries including the oil and gas, chemical and petrochemical markets. Net cash paid for the
Brazilian valve companies totaled $104 million by the Company's Flow Control segment. In addition, the Company's Electrical and Metals Products segment acquired certain assets of a business for
$39 million and its Safety Products segment acquired a business for $9 million.

[0001047469-10-004246:mdna:169]
During
the quarter and six months ended March 27, 2009, cash paid for acquisitions included in continuing operations totaled $2 million and $47 million,
respectively, net of cash acquired of $1 million and $2 million, respectively, which primarily related to the acquisition of Vue Technology, Inc., a provider of radio frequency
identification (RFID) technology, for $43 million by the Company's Safety Products segment.

[0001047469-10-004246:mdna:170]
[same as prior period, unchanged from 0001047469-10-000401:mdna:87]

[0001047469-10-004246:mdna:171]
The preparation of the Consolidated Financial Statements in conformity with GAAP requires management to use judgment in making
estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of contingent assets and liabilities and the reported amounts of revenue and expenses. We believe that
our accounting policies for depreciation and amortization methods of security monitoring-related assets, revenue recognition, loss contingencies, income taxes, goodwill and indefinite-lived intangible
assets, long-lived assets and pension and postretirement benefits are based on, among other things, judgments and assumptions made by management that include inherent risks and
uncertainties. During the three months ended March 26, 2010, there were no significant changes to

[0001047469-10-004246:mdna:172]
these
policies or in the underlying accounting assumptions and estimates used in the above critical accounting policies from those disclosed in the Consolidated Financial Statements and accompanying
notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 25, 2009 (the "2009 Form 10-K"). See Note 1 to the
Consolidated Financial Statements for the adoption of new accounting standards during the first quarter of 2010.

[0001047469-10-004246:mdna:173]
[same as prior period, unchanged from 0001047469-10-000401:mdna:89]

[0001047469-10-004246:mdna:174]
[same as prior period, unchanged from 0001047469-10-000401:mdna:90]

[0001047469-10-004246:mdna:175]
On
January 9, 2009, TIFSA issued $750 million aggregate principal amount of 8.5% notes due 2019 (the "2019 notes"), which are fully and unconditionally guaranteed by the
Company. TIFSA received net proceeds of approximately $745 million after underwriting discounts and offering expenses. The Company may be required to repurchase all or part of the 2019 Notes at
par in July of 2014 at the option of the noteholders.

[0001047469-10-004246:mdna:176]
The
net proceeds of the aforementioned offerings may be used for general corporate purposes, which may include repayment of indebtedness, acquisitions, additions to working capital,
repurchase of common shares, capital expenditures and investments in the Company's subsidiaries.

[0001047469-10-004246:mdna:177]
As
of March 26, 2010, there were no amounts drawn under our revolving credit facilities. As of March 26, 2010, the aggregate available commitment under our senior revolving
credit facilities was $1.69 billion. We continually monitor developments regarding the availability of funds under our revolving credit facilities. Although there is some risk that financial
institutions will fail to perform their contractual obligations, particularly in times of credit market distress, we believe that the lenders under our revolving credit facilities are capable of
meeting any borrowing requests we may make for the foreseeable future.

[0001047469-10-004246:mdna:178]
During
the first quarter of 2010, TIFSA had made payments of $200 million to extinguish all of its commercial paper outstanding. As of March 26, 2010, there was no
commercial paper outstanding.

[0001047469-10-004246:mdna:179]
In
addition to our available cash and operating cash flows, additional sources of potential liquidity include committed credit lines, our commercial paper program, public debt and equity
markets as well as the ability to sell trade accounts receivable. We continue to balance our operating, investing and financing uses of cash through investment in our existing core businesses,
strategic acquisitions and divestitures, dividends and share repurchases. We believe our cash position, amounts available under our credit facilities and cash provided by operating activities will be
adequate to cover our operational and business needs.

[0001047469-10-004246:mdna:180]
We
continue to monitor market conditions and assess the impact, if any, on our financial position, results of operations or cash flows. Approximately 100% of our U.S. and more than 95%
of our non-U.S. funded pension plans are invested in marketable investments, including publicly-traded equity and fixed income securities. Although we do not believe we will be required to
make materially higher cash contributions in the next 12 months, if market conditions worsen, we may be required to make incremental cash contributions under local statutory law.

[0001047469-10-004246:mdna:181]
[same as prior period, unchanged from 0001047469-10-000401:mdna:97]

[0001047469-10-004246:mdna:182]
|  |  | For the Quarters Ended |  | For the Six Months Ended |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  | March 26, 2010 |  | March 27, 2009 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income (loss) |  | $ | 427 |  | $ | (2,554 | ) | $ | 841 |  | $ | (2,141 | ) |
| Goodwill and intangible asset impairments |  |  | — |  |  | 2,705 |  |  | — |  |  | 2,705 |  |
| Depreciation and amortization(1) |  |  | 282 |  |  | 284 |  |  | 569 |  |  | 559 |  |
| Non-cash compensation expense |  |  | 32 |  |  | 23 |  |  | 63 |  |  | 52 |  |
| Deferred income taxes |  |  | (39 | ) |  | (165 | ) |  | (35 | ) |  | (182 | ) |
| Provision for losses on accounts receivable and inventory |  |  | 30 |  |  | 35 |  |  | 64 |  |  | 69 |  |
| Other, net |  |  | (23 | ) |  | 24 |  |  | (11 | ) |  | 46 |  |
| Net change in working capital |  |  | 41 |  |  | 381 |  |  | (242 | ) |  | (174 | ) |
| Interest income |  |  | 7 |  |  | 11 |  |  | 16 |  |  | 23 |  |
| Interest expense |  |  | (74 | ) |  | (78 | ) |  | (150 | ) |  | (151 | ) |
| Income tax expense |  |  | (51 | ) |  | 60 |  |  | (104 | ) |  | (24 | ) |
| Net cash provided by operating activities |  | $ | 632 |  | $ | 726 |  | $ | 1,011 |  | $ | 782 |  |
| Other cash flow items: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures, net(2) |  | $ | (167 | ) | $ | (170 | ) | $ | (316 | ) | $ | (327 | ) |
| Decrease in the sale of accounts receivable |  |  | 3 |  |  | 7 |  |  | 2 |  |  | 10 |  |
| Accounts purchased by ADT |  |  | (116 | ) |  | (114 | ) |  | (266 | ) |  | (231 | ) |
| Purchase accounting and holdback liabilities |  |  | (3 | ) |  | (1 | ) |  | (3 | ) |  | (1 | ) |
| Voluntary pension contributions |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |

[0001047469-10-004246:mdna:183]
(1)

[0001047469-10-004246:mdna:184]
The
quarters ended March 26, 2010 and March 27, 2009 included depreciation expense of $155 million and
$155 million, respectively, and amortization of intangible assets of $127 million and $129 million, respectively. The six months ended March 26, 2010 and March 27,
2009 included depreciation expense of $313 million and $303 million, respectively, and amortization of intangible assets of $256 million and $256 million, respectively.

[0001047469-10-004246:mdna:185]
(2)

[0001047469-10-004246:mdna:186]
Included
net proceeds received for the sale/disposition of property, plant and equipment of $3 million and $2 million for the
quarters ended March 26, 2010 and March 27, 2009, respectively, as well as $19 million and $4 million for the six months ended March 26, 2010 and March 27,
2009, respectively.

[0001047469-10-004246:mdna:187]
The net change in working capital increased operating cash flow by $41 million in the quarter ended March 26, 2010. The significant
changes in working capital included a $73 million increase in deferred revenue, a $19 million increase in accounts payable, and an $18 million decrease in prepaid expenses and
other current assets, offset by a $29 million increase in inventories, a $22 million increase in accounts receivable, as well as a $14 million decrease in contracts in process.

[0001047469-10-004246:mdna:188]
The
net change in working capital decreased operating cash flow by $242 million in the six months ended March 26, 2010. The significant changes in working capital included
a $202 million decrease in accrued expenses and other current liabilities, a $73 million increase in inventories, and a $52 million decrease in accounts payable, offset by a
$66 million decrease in accounts receivable.

[0001047469-10-004246:mdna:189]
During
the quarter and six months ended March 26, 2010, we paid approximately $48 million and $97 million, respectively, in cash related to restructuring activities
as compared to cash paid related to restructuring activities of $37 million and $57 million for the quarter and six months ended March 27, 2009, respectively. See Note 3 to
our Consolidated Financial Statements for further information regarding our restructuring activities.

[0001047469-10-004246:mdna:190]
Income taxes paid, net of refunds, related to continuing operations were $90 million and $139 million during the quarter and six months ended
March 26, 2010 and $103 million and $176 million for the quarter and six months ended March 27, 2009, respectively.

[0001047469-10-004246:mdna:191]
The
primary uses and sources of cash flows from investing activities were as follows ($ in millions):

[0001047469-10-004246:mdna:192]
We
continue to fund capital expenditures to grow our business, improve the cost structure of our businesses, to invest in new processes and technology, and to maintain high quality
production standards. During the six months ended March 26, 2010, we made capital expenditures of $335 million as compared to $331 million during the comparable prior period. The
level of capital expenditures in fiscal year 2010 is expected to exceed the spending levels in fiscal year 2009 and is also expected to exceed depreciation.

[0001047469-10-004246:mdna:193]
We
acquired approximately 105,000 and 234,000 customer contracts for electronic security services within our ADT Worldwide segment for $120 million and $271 million during
the quarter and six months ended March 26, 2010, respectively. Of these amounts, $113 million and $261 million was paid during the quarter and six months ended March 26,
2010, respectively. Additionally, we paid $3 million during the quarter ended March 26, 2010 for customer contracts acquired during the quarter ended December 25,
2009. We also paid $2 million during the quarter ended December 25, 2009 for customer contracts acquired during the quarter ended September 25, 2009.

[0001047469-10-004246:mdna:194]
During
the six months ended March 26, 2010, cash paid for acquisitions included in continuing operations totaled $152 million, net of cash acquired of $1 million,
which primarily related to the acquisition of two Brazilian valve companies, including Hiter Industria e Comercio de Controle Termo-Hidraulico Ltda ("Hiter"), a valve manufacturer which serves
a variety of industries including the oil and gas, chemical and petrochemical markets. Net cash paid for Hiter totaled $104 million by our Flow Control segment. In addition, our Electrical and
Metal Products segment acquired certain assets of a business for $39 million and our Safety Products segment acquired a business for $9 million.

[0001047469-10-004246:mdna:195]
During
the six months ended March 26, 2010, we received cash proceeds in the amount of $28 million for divestitures included in continuing operations, net of cash divested
of $14 million.

[0001047469-10-004246:mdna:196]
We
will continue to divest businesses that do not align with our overall strategy. We expect to use the proceeds from these sales, as well as the cash generated by our operations, to
continue to make investments in our businesses that are intended to grow revenue and profitability, and improve productivity, including funding restructuring actions. We expect to also use cash to
selectively pursue acquisitions. As disclosed in Note 4 to our Consolidated Financial Statements, we entered into a definitive agreement to acquire BHS for approximately $2.0 billion. We
expect to finance this acquisition using cash up to approximately $600 million and the issuance of our common shares. The transaction is expected to close shortly after the special meeting of
BHS shareholders scheduled for May 12, 2010 assuming all conditions are met or waived.

[0001047469-10-004246:mdna:197]
The
primary uses and sources of cash flows from financing activities were as follows ($ in millions):

[0001047469-10-004246:mdna:198]
On
October 5, 2009, we issued $500 million aggregate principal amount of 4.125% notes due on October 15, 2014 and received net cash proceeds of approximately
$495 million. During the six months ended March 26, 2010, net repayments of short-term debt were approximately $243 million, which primarily related to the
extinguishment of our outstanding commercial paper. Additionally during the six months ended March 26, 2010, we paid cash dividends of approximately $214 million.

[0001047469-10-004246:mdna:199]
[same as prior period, unchanged from 0001047469-10-000401:mdna:110]

[0001047469-10-004246:mdna:200]
Management
believes that cash generated by or available to us should be sufficient to fund our capital and liquidity needs for the foreseeable future, including quarterly dividend
payments. During

[0001047469-10-004246:mdna:201]
fiscal
2010, we expect to resume repurchasing under our existing $1.0 billion share repurchase program approved by our Board of Directors on July 10, 2008 in accordance with applicable
law and depending on credit market conditions, macroeconomic factors and expectations regarding future cash flows. As also disclosed in Note 12 to our Consolidated Financial Statements, on
March 10, 2010, our shareholders approved an annual dividend on our common shares of 0.90 CHF per share, which will be paid in the form of a return on capital in four installments of
CHF 0.22, CHF 0.22, CHF 0.23 and CHF 0.23.

[0001047469-10-004246:mdna:202]
[same as prior period, unchanged from 0001047469-10-000401:mdna:112]

[0001047469-10-004246:mdna:203]
Our shareholders' equity was $12.9 billion, or $27.17 per share, as of March 26, 2010, compared to $12.9 billion,
or $27.30 per share, as of September 25, 2009. Our shareholders' equity remained relatively flat primarily due to net income attributable to our common shareholders of $612 million,
offset by dividends declared of $399 million and unfavorable changes in foreign currency exchange rates of $336 million. Total debt was $4.5 billion as of March 26, 2010,
as compared to $4.3 billion as of September 25, 2009. Total debt as a percentage of total capitalization (total debt and shareholders' equity) was 26% as of March 26, 2010 and 25%
as of September 25, 2009.

[0001047469-10-004246:mdna:204]
Our
cash balance increased to $2.7 billion as of March 26, 2010, as compared to $2.4 billion at September 25, 2009. The increase was primarily due to cash
flow generated from operating activities of $1.0 billion and proceeds of $498 million received from the issuance of long-term debt, partially offset by $753 million of cash used
for capital expenditures, accounts purchased by ADT, business acquisitions and the net repayment of $243 million of short-term debt.

[0001047469-10-004246:mdna:205]
The
following table details our long-term and short-term debt ratings as of March 26, 2010 and September 25, 2009:

[0001047469-10-004246:mdna:206]
[same as prior period, unchanged from 0001047469-10-000401:mdna:117]

[0001047469-10-004246:mdna:207]
On
April 12, 2010, Standard & Poor's Rating Services raised our long term debt ratings to A- from BBB+.

[0001047469-10-004246:mdna:208]
[same as prior period, unchanged from 0001047469-10-000401:mdna:118]

[0001047469-10-004246:mdna:209]
Commitments and Contingencies

[0001047469-10-004246:mdna:210]
For a detailed discussion of contingencies related to our litigation matters and governmental investigations see Note 10 to our
Consolidated Financial Statements.

[0001047469-10-004246:mdna:211]
[same as prior period, unchanged from 0001047469-10-000401:mdna:121]

[0001047469-10-004246:mdna:212]
As of March 26, we had a backlog of unfilled orders of $9.0 billion compared to a backlog of $9.0 billion as of
September 25, 2009. We expect that approximately 86% of our backlog as of

[0001047469-10-004246:mdna:213]
69

[0001047469-10-004246:mdna:214]
March 26,
2010 will be filled during the next 12 months. Backlog by segment was as follows ($ in millions):

[0001047469-10-004246:mdna:215]
|  |  | March 26, 2010 |  | September 25, 2009 |  |
| ADT Worldwide |  | $ | 5,956 |  | $ | 5,916 |  |
| Flow Control |  |  | 1,629 |  |  | 1,698 |  |
| Fire Protection Services |  |  | 1,163 |  |  | 1,171 |  |
| Electrical and Metal Products |  |  | 95 |  |  | 72 |  |
| Safety Products |  |  | 134 |  |  | 102 |  |
|  |  | $ | 8,977 |  | $ | 8,959 |  |

[0001047469-10-004246:mdna:216]
Backlog
increased by $18 million, or 0.2%, to $9.0 billion as of March 26, 2010. The increase in backlog was primarily due to an increase in recurring
revenue-in-force at our ADT Worldwide segment partially offset by unfavorable changes in foreign currency exchange rates of $80 million. ADT Worldwide's backlog includes recurring
revenue-in-force and long-term deferred revenue for upfront fees paid by customers for ADT owned security systems. Revenue-in-force represents 12 months' revenue
associated with monitoring and maintenance services under contract in the security business. ADT Worldwide's backlog of $6.0 billion and $5.9 billion as of March 26, 2010 and
September 25, 2009, respectively, primarily consists of $4.1 billion and $4.0 billion of recurring revenue-in-force as of March 26, 2010 and September 25, 2009,
respectively, and $1.1 billion of deferred revenue for both March 26, 2010 and September 25, 2009. ADT Worldwide's backlog increased $40 million primarily driven by a
increase in revenue-in-force of $64 million partially offset by a decrease in deferred revenue of $26 million and unfavorable changes in foreign exchange rates of
$33 million. Flow Control's backlog decreased by $69 million primarily due to decreased bookings of $36 million as several large projects were completed during the first half of
fiscal
2010 and unfavorable exchange rates of $33 million. Electrical and Metal Products' backlog increased $23 million primarily related to the acquisition of a business during the first
quarter of fiscal 2010. Backlog within Safety Products increased $32 million due to increased orders across various businesses partially offset by unfavorable changes in foreign currency
exchange rates of $4 million.

[0001047469-10-004246:mdna:217]
[same as prior period, unchanged from 0001047469-10-000401:mdna:125]

[0001047469-10-004246:mdna:218]
[same as prior period, unchanged from 0001047469-10-000401:mdna:126]

[0001047469-10-004246:mdna:219]
Certain of our international businesses utilize the sale of accounts receivable as short-term financing mechanisms. The
aggregate amount outstanding under our international accounts receivable programs was $48 million and $55 million as of March 26, 2010 and September 25, 2009, respectively.

[0001047469-10-004246:mdna:220]
[same as prior period, unchanged from 0001047469-10-000401:mdna:128]

[0001047469-10-004246:mdna:221]
[same as prior period, unchanged from 0001047469-10-000401:mdna:129]

[0001047469-10-004246:mdna:222]
There
are certain guarantees or indemnifications extended among Tyco, Covidien and Tyco Electronics in accordance with the terms of the Separation and Distribution Agreement and the Tax
Sharing Agreement. The guarantees primarily relate to certain contingent tax liabilities included in the Tax Sharing Agreement. At the time of the Separation, we recorded a liability necessary to
recognize the fair value of such guarantees and indemnifications. See Note 5 to the Consolidated Financial

[0001047469-10-004246:mdna:223]
Statements
for further discussion of the Tax Sharing Agreement. In addition, prior to the Separation we provided support in the form of financial and/or performance guarantees to various Covidien and
Tyco Electronics operating entities. To the extent these guarantees were not assigned in connection with the Separation, we assumed primary liability on any remaining such support. The estimated fair
value of these obligations was not material to us as of March 26, 2010.

[0001047469-10-004246:mdna:224]
[same as prior period, unchanged from 0001047469-10-000401:mdna:131]

[0001047469-10-004246:mdna:225]
[same as prior period, unchanged from 0001047469-10-000401:mdna:132]

[0001047469-10-004246:mdna:226]
For
a detailed discussion of guarantees and indemnifications, see Note 17 to the Consolidated Financial Statements.

[0001047469-10-004246:mdna:227]
[same as prior period, unchanged from 0001047469-10-000401:mdna:134]

[0001047469-10-004246:mdna:228]
Recently Adopted Accounting Pronouncements    In June 2008, the Financial Accounting Standards Board ("FASB") ratified authoritative
guidance for
determining whether instruments granted in share-based payment transactions are participating securities. The guidance addresses whether instruments granted
in share-based payment awards are participating securities prior to vesting and, therefore, must be included in the earnings allocation in calculating earnings per share under the
two-class method. The guidance requires that unvested share-based payment awards that contain non-forfeitable rights to dividends or dividend-equivalents be treated as
participating securities in calculating earnings per share. The guidance became effective for Tyco in the first quarter of fiscal 2010, and was applied retrospectively to prior periods. The adoption
did not have a material impact on our historical annual or quarterly basic and diluted earnings per share. See Note 6 to the Consolidated Financial Statements for additional information related
to the adoption of the guidance.

[0001047469-10-004246:mdna:229]
In
December 2007, the FASB revised the authoritative guidance for business combinations. The revised guidance retains the underlying concepts of the existing guidance in that business
combinations are still accounted for at fair value. However, the accounting for certain other aspects of business combinations will be affected. Acquisition costs will generally be expensed as
incurred. Restructuring costs associated with a business combination will generally be expensed subsequent to the acquisition date. In-process research and development will be recorded at
fair value as an indefinite-lived intangible at the acquisition date until it is completed or abandoned and its useful life can be determined. Changes in deferred tax asset valuation allowances and
uncertain tax positions after the acquisition date will generally impact income tax expense. The revised guidance also expands required disclosures surrounding the nature and financial effects of
business combinations. We adopted the revised guidance in the first quarter of fiscal 2010. The revised guidance is primarily effective for all business combinations beginning in the first quarter of
fiscal 2010 and thereafter, and its adoption did not have a material impact on our financial position, results of operations or cash flows for the quarter and six months ended March 26, 2010.

[0001047469-10-004246:mdna:230]
In
December 2007, the FASB issued authoritative guidance for noncontrolling interests in consolidated financial statements. The guidance requires the recognition of a noncontrolling
interest (minority interest prior to the adoption of the guidance) as equity in the Consolidated Financial

[0001047469-10-004246:mdna:231]
Statements.
The amount of net income attributable to the noncontrolling interest should be included in consolidated net income on the face of the Consolidated Statements of Operations. The guidance
also amends certain existing consolidation procedures in order to achieve consistency with the requirements of the revised authoritative guidance for business combinations discussed above. The
guidance also includes expanded disclosure requirements regarding the interests of the parent and its noncontrolling interest. The guidance was adopted by Tyco in the first quarter of fiscal 2010 and
was applied retrospectively. The adoption did not have a material impact on our financial position, results of operations or cash flows.

[0001047469-10-004246:mdna:232]
In
September 2006, the FASB issued authoritative guidance for fair value measurements, which enhances existing guidance for measuring assets and liabilities at fair value. The guidance
defines fair value, establishes a framework for measuring fair value and expands disclosure about fair value measurements. The guidance was adopted in two phases. We adopted the fair value provisions
relating to financial assets and liabilities in the first quarter of 2009 and for nonfinancial assets and liabilities in the first quarter of fiscal 2010. The adoption did not have a material impact
on our financial position, results of operations or cash flows.

[0001047469-10-004246:mdna:233]
In
April 2008, the FASB issued authoritative guidance for determining the useful life of intangible assets. The guidance amends the factors that should be considered in developing
renewal or extension assumptions used to determine the useful life of a recognized intangible asset. The guidance became effective for Tyco in the first quarter of fiscal 2010. The adoption did not
have a material impact on our financial position, results of operations or cash flows.

[0001047469-10-004246:mdna:234]
Recently Issued Accounting Pronouncements    In September 2009, the FASB issued authoritative guidance for the accounting for revenue
arrangements with
multiple deliverables. The guidance establishes a selling price hierarchy for determining the selling price of a deliverable. The selling price used for each deliverable will be based on
vendor-specific objective evidence if available, third-party evidence if vendor-specific objective evidence is not available, or estimated selling price if neither vendor-specific evidence nor
third-party evidence is available. The guidance requires arrangements under which multiple revenue generating activities that are to be performed be allocated at inception. The residual method under
the existing accounting guidance has been eliminated. The guidance expands the disclosure requirements related to multiple-deliverable revenue arrangements. The guidance becomes effective for revenue
arrangements entered into or materially modified beginning in the first quarter of fiscal 2011. The guidance applies on a prospective basis unless the Company specifically elects to apply the guidance
retrospectively. We are currently assessing what impact, if any, the guidance will have on our financial position, results of operations or cash flows.

[0001047469-10-004246:mdna:235]
In
June 2009, the FASB issued authoritative guidance which amended the existing guidance for the consolidation of variable interest entities, to address the elimination of the concept of
a qualifying special purpose entity. The guidance also replaces the quantitative-based risks and rewards calculation for determining which enterprise has a controlling financial interest in a variable
interest entity with an approach focused on identifying which enterprise has the power to direct the activities of a variable interest entity, and the obligation to absorb losses of the entity or the
right to receive benefits from the entity. Additionally, the guidance requires any enterprise that holds a variable interest in an entity to provide enhanced disclosures that will provide users of
financial statements with more transparent information about an enterprise's involvement in a variable interest entity. The guidance is effective for Tyco in the first quarter of fiscal 2011. We are
currently assessing what impact, if any, that the guidance will have on our financial position, results of operations or cash flows.

[0001047469-10-004246:mdna:236]
In
December 2008, the FASB issued authoritative guidance for employers' disclosures about postretirement benefit plan assets. The guidance requires additional disclosures about plan
assets related to an employer's defined benefit pension or other post-retirement plans to enable investors to better understand how investment decisions are made, the major categories of
plan assets, the inputs

[0001047469-10-004246:mdna:237]
72

[0001047469-10-004246:mdna:238]
and
valuation techniques used to measure the fair value of plan assets, the effect of fair value measurements using significant unobservable inputs (Level 3) on changes in plan assets for the
period,
and the significant concentrations of risk within plan assets. The disclosure provisions of the guidance are effective for Tyco in fiscal 2010 and will be adopted concurrently with the pension
disclosures associated with our annual valuation process during the fourth quarter of fiscal 2010.

[0001047469-10-004246:mdna:239]
[same as prior period, unchanged from 0001047469-10-000401:mdna:147]

[0001047469-10-004246:mdna:240]
[same as prior period, unchanged from 0001047469-10-000401:mdna:148]

[0001047469-10-004246:mdna:241]
[same as prior period, unchanged from 0001047469-10-000401:mdna:149]

[0001047469-10-004246:mdna:242]
[same as prior period, unchanged from 0001047469-10-000401:mdna:150]

[0001047469-10-004246:mdna:243]
[same as prior period, unchanged from 0001047469-10-000401:mdna:151]

[0001047469-10-004246:mdna:244]
[same as prior period, unchanged from 0001047469-10-000401:mdna:152]

[0001047469-10-004246:mdna:245]
[same as prior period, unchanged from 0001047469-10-000401:mdna:153]

[0001047469-10-004246:mdna:246]
[same as prior period, unchanged from 0001047469-10-000401:mdna:154]

[0001047469-10-004246:mdna:247]
[same as prior period, unchanged from 0001047469-10-000401:mdna:155]

[0001047469-10-004246:mdna:248]
[same as prior period, unchanged from 0001047469-10-000401:mdna:157]

[0001047469-10-004246:mdna:249]
[same as prior period, unchanged from 0001047469-10-000401:mdna:158]

[0001047469-10-004246:mdna:250]
[same as prior period, unchanged from 0001047469-10-000401:mdna:159]

[0001047469-10-004246:mdna:251]
the outcome of litigation and governmental proceedings;

[0001047469-10-004246:mdna:252]
[same as prior period, unchanged from 0001047469-10-000401:mdna:161]

[0001047469-10-004246:mdna:253]
[same as prior period, unchanged from 0001047469-10-000401:mdna:162]

[0001047469-10-004246:mdna:254]
[same as prior period, unchanged from 0001047469-10-000401:mdna:163]

[0001047469-10-004246:mdna:255]
[same as prior period, unchanged from 0001047469-10-000401:mdna:164]

[0001047469-10-004246:mdna:256]
[same as prior period, unchanged from 0001047469-10-000401:mdna:165]

[0001047469-10-004246:mdna:257]
[same as prior period, unchanged from 0001047469-10-000401:mdna:166]

[0001047469-10-004246:mdna:258]
[same as prior period, unchanged from 0001047469-10-000401:mdna:167]

[0001047469-10-004246:mdna:259]
[same as prior period, unchanged from 0001047469-10-000401:mdna:168]

[0001047469-10-004246:mdna:260]
[same as prior period, unchanged from 0001047469-10-000401:mdna:169]

[0001047469-10-004246:mdna:261]
[same as prior period, unchanged from 0001047469-10-000401:mdna:170]

[0001047469-10-004246:mdna:262]
[same as prior period, unchanged from 0001047469-10-000401:mdna:171]

[0001047469-10-004246:mdna:263]
[same as prior period, unchanged from 0001047469-10-000401:mdna:172]

[0001047469-10-004246:mdna:264]
[same as prior period, unchanged from 0001047469-10-000401:mdna:173]

[0001047469-10-004246:mdna:265]
[same as prior period, unchanged from 0001047469-10-000401:mdna:174]

[0001047469-10-004246:mdna:266]
[same as prior period, unchanged from 0001047469-10-000401:mdna:175]

[0001047469-10-004246:mdna:267]
[same as prior period, unchanged from 0001047469-10-000401:mdna:176]

[0001047469-10-004246:mdna:268]
[same as prior period, unchanged from 0001047469-10-000401:mdna:177]

[0001047469-10-004246:mdna:269]
[same as prior period, unchanged from 0001047469-10-000401:mdna:178]

[0001047469-10-004246:mdna:270]
[same as prior period, unchanged from 0001047469-10-000401:mdna:179]

[0001047469-10-004246:mdna:271]
[same as prior period, unchanged from 0001047469-10-000401:mdna:180]

[0001047469-10-004246:mdna:272]
[same as prior period, unchanged from 0001047469-10-000401:mdna:181]

[0001047469-10-004246:mdna:273]
[same as prior period, unchanged from 0001047469-10-000401:mdna:182]

[0001047469-10-004246:mdna:274]
[same as prior period, unchanged from 0001047469-10-000401:mdna:183]

[0001047469-10-004246:mdna:275]
[same as prior period, unchanged from 0001047469-10-000401:mdna:184]

[0001047469-10-004246:mdna:276]
[same as prior period, unchanged from 0001047469-10-000401:mdna:185]

[0001047469-10-004246:mdna:277]
[same as prior period, unchanged from 0001047469-10-000401:mdna:186]
