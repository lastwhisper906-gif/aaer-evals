# JCI 8-K — 0001104659-10-021941 filed 2010-04-27

## item codes, every 8-K on or before 2010-04-27

- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2010-04-27

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0001104659-10-021941:8k_2_02:1]
EX-99.1
2
a10-8646_1ex99d1.htm
EX-99.1

[0001104659-10-021941:8k_2_02:2]
Exhibit 99.1

[0001104659-10-021941:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001104659-10-021941:8k_2_02:4]
| Contacts: |  | News Media |  | Investor Relations |
|  |  | Paul Fitzhenry |  | Ed Arditte |
|  |  | 609-720-4261 |  | 609-720-4621 |
|  |  |  |  | Antonella Franzen |
|  |  |  |  | 609-720-4665 |

[0001104659-10-021941:8k_2_02:5]
TYCO INTERNATIONAL REPORTS SECOND QUARTER EARNINGS

[0001104659-10-021941:8k_2_02:6]
FROM CONTINUING OPERATIONS BEFORE SPECIAL ITEMS OF $0.59 PER

[0001104659-10-021941:8k_2_02:7]
SHARE AND GAAP EARNINGS OF $0.65 PER SHARE

[0001104659-10-021941:8k_2_02:8]
(Income and EPS amounts are
attributable to Tyco common shareholders)

[0001104659-10-021941:8k_2_02:9]
($ millions, except per-share
amounts)

[0001104659-10-021941:8k_2_02:10]
|  |  | Q2 2010 |  | Q2 2009 |  | % Change |  |
| Revenue |  | $ | 4,169 |  | $ | 4,150 |  | — |  |
| Income/(Loss) from Continuing Operations |  | $ | 310 |  | $ | (2,555 | ) | — |  |
| Diluted EPS from Continuing Operations |  | $ | 0.65 |  | $ | (5.40 | ) | — |  |
| Special Items |  | $ | 0.06 |  | $ | (5.95 | ) |  |  |
| Income from Continuing Ops Before Special Items |  | $ | 284 |  | $ | 261 |  | 9 | % |
| Diluted EPS from Continuing Ops Before Special Items |  | $ | 0.59 |  | $ | 0.55 |  | 7 | % |

[0001104659-10-021941:8k_2_02:11]
SCHAFFHAUSEN, Switzerland — April 27, 2010 — Tyco International Ltd. (NYSE: TYC) today reported
$0.65 in diluted earnings per share (EPS) from continuing operations for the
fiscal second quarter of 2010 and diluted EPS from continuing operations before
special items of $0.59 per share.  In the
prior year, diluted EPS from continuing operations was negatively impacted by
special items of $5.95 per share, primarily non-cash goodwill and intangible
asset impairments.  Revenue in the
quarter was $4.2 billion with an organic revenue decline of 5.8%.

[0001104659-10-021941:8k_2_02:12]
1

[0001104659-10-021941:8k_2_02:13]
Cash
from operating activities was $632 million and free cash flow was $349
million.  These amounts included $48
million of cash outflows related to restructuring activities.  For the year to date, free cash flow was $428
million compared to free cash flow of $239 million in 2009.

[0001104659-10-021941:8k_2_02:14]
“Our results this quarter
reflect modestly higher-than-expected revenue with continued strength in our
recurring revenue and service activities,” said Tyco Chairman and Chief
Executive Officer Ed Breen. “We continue to see the benefits of our
cost-management and restructuring actions and order activity is improving in a
number of our businesses which increases our confidence about the second half
of our fiscal year,” Breen added.

[0001104659-10-021941:8k_2_02:15]
“We
are on track to complete the acquisition of Broadview Security next month and
look forward to combining the business with ADT to enhance our opportunities in
the North American security industry,” added Breen.

[0001104659-10-021941:8k_2_02:16]
Organic
revenue, free cash flow and operating income, operating margin, income and
diluted EPS from continuing operations before special items are non-GAAP
financial measures and are described below. 
For a reconciliation of these non-GAAP measures, see the attached
tables.  Additional schedules as well as
Second Quarter Review slides can be found at www.tyco.com on the Investor
Relations portion of Tyco’s website. 
Certain tables in this press release contain the symbol “-”, where the
percent change is not meaningful.

[0001104659-10-021941:8k_2_02:17]
SEGMENT RESULTS

[0001104659-10-021941:8k_2_02:18]
The
financial results presented in the tables below are in accordance with GAAP
unless otherwise indicated.  Beginning in
the first quarter of fiscal 2010, certain businesses and overhead costs were
realigned, resulting in changes to historical segment performance.  The revenue and operating income results
shown below have been adjusted to reflect these changes.  All dollar amounts are pre-tax and stated in
millions.  All comparisons are to the
fiscal second quarter of 2009 unless otherwise indicated.

[0001104659-10-021941:8k_2_02:19]
2

[0001104659-10-021941:8k_2_02:20]
ADT Worldwide

[0001104659-10-021941:8k_2_02:21]
|  |  | Q2 2010 |  | Q2 2009 |  | % Change |  |
| Revenue |  | $ | 1,767 |  | $ | 1,705 |  | 4 | % |
| Operating Income |  | $ | 305 |  | $ | (867 | ) | — |  |
| Operating Margin |  | 17.3 | % | — |  |  |  |
| Special Items |  | $ | 46 |  | $ | (1,078 | ) |  |  |
| Operating Income Before Special Items |  | $ | 259 |  | $ | 211 |  | 23 | % |
| Operating Margin Before Special Items |  | 14.7 | % | 12.4 | % |  |  |

[0001104659-10-021941:8k_2_02:22]
Revenue
of $1.8 billion increased 4% in the quarter with an organic revenue decline of
1.5%.  Recurring revenue grew 4%
organically on a global basis.  Systems
installation and service revenue declined 8% organically, due to continued
softness in North America and Europe, as a result of lower sales to commercial
customers.

[0001104659-10-021941:8k_2_02:23]
Operating
income was $305 million and the operating margin was 17.3%.  Special items of $46 million consisted
primarily of a gain on the previously-announced sale of the France security
business.  Operating income before
special items was $259 million and the operating margin before special items
improved 230 basis points to 14.7%.  The
benefits from restructuring and cost-containment actions as well as growth in
higher-margin recurring revenue more than offset the impact of the organic
revenue decline in systems installation and service.

[0001104659-10-021941:8k_2_02:24]
Flow Control

[0001104659-10-021941:8k_2_02:25]
|  |  | Q2 2010 |  | Q2 2009 |  | % Change |  |
| Revenue |  | $ | 899 |  | $ | 927 |  | (3 | )% |
| Operating Income |  | $ | 93 |  | $ | 133 |  | (30 | )% |
| Operating Margin |  | 10.3 | % | 14.3 | % |  |  |
| Special Items |  | $ | (8 | ) | $ | (8 | ) |  |  |
| Operating Income Before Special Items |  | $ | 101 |  | $ | 141 |  | (28 | )% |
| Operating Margin Before Special Items |  | 11.2 | % | 15.2 | % |  |  |

[0001104659-10-021941:8k_2_02:26]
Revenue
of $899 million declined 3% in the quarter with an organic revenue decline of
13%.  Organic revenue growth of 2% in
Thermal Controls was more than offset by a 19% decline in the Valves business
and a 7% decline in Water.  Backlog of
$1.6 billion was flat on a quarter sequential basis excluding the impact of
foreign currency.

[0001104659-10-021941:8k_2_02:27]
3

[0001104659-10-021941:8k_2_02:28]
Operating
income was $93 million and the operating margin was 10.3%.  Special items of $8 million consisted
primarily of restructuring charges. 
Operating income before special items was $101 million and included a
charge of $9 million for an anticipated loss on a project retained from the
2008 divestiture of Earth Tech, Inc. 
The operating margin before special items decreased to 11.2% as the
benefits from cost-containment and restructuring actions were more than offset
by the impact of the organic revenue decline and product mix.

[0001104659-10-021941:8k_2_02:29]
Fire Protection Services

[0001104659-10-021941:8k_2_02:30]
|  |  | Q2 2010 |  | Q2 2009 |  | % Change |  |
| Revenue |  | $ | 807 |  | $ | 813 |  | (1 | )% |
| Operating Income |  | $ | 62 |  | $ | (121 | ) | — |  |
| Operating Margin |  | 7.7 | % | — |  |  |  |
| Special Items |  | $ | (4 | ) | $ | (191 | ) |  |  |
| Operating Income Before Special Items |  | $ | 66 |  | $ | 70 |  | (6 | )% |
| Operating Margin Before Special Items |  | 8.2 | % | 8.6 | % |  |  |

[0001104659-10-021941:8k_2_02:31]
Revenue of $807 million
declined 1% in the quarter with an organic revenue decline of 7%.  Service revenue was down 1% organically while
installation revenue declined 12% driven by softness in the North America and EMEA
regions.  Backlog of $1.2 billion
increased 1% on a quarter sequential basis.

[0001104659-10-021941:8k_2_02:32]
Operating income was $62
million and the operating margin was 7.7%. 
Special items of $4 million consisted of restructuring charges.  Operating income before special items was $66
million and the operating margin before special items was 8.2%.

[0001104659-10-021941:8k_2_02:33]
Electrical and Metal Products

[0001104659-10-021941:8k_2_02:34]
|  |  | Q2 2010 |  | Q2 2009 |  | % Change |  |
| Revenue |  | $ | 336 |  | $ | 330 |  | 2 | % |
| Operating Income |  | $ | 24 |  | $ | (961 | ) | — |  |
| Operating Margin |  | 7.1 | % | — |  |  |  |
| Special Items |  | $ | (2 | ) | $ | (936 | ) |  |  |
| Operating Income Before Special Items |  | $ | 26 |  | $ | (25 | ) | — |  |
| Operating Margin Before Special Items |  | 7.7 | % | (7.6 | )% |  |  |

[0001104659-10-021941:8k_2_02:35]
Revenue of $336 million
increased 2% in the quarter with an organic revenue decline of 3%.  Although volume remained essentially flat
year over year, lower average selling prices for steel products drove the
organic revenue decline.

[0001104659-10-021941:8k_2_02:36]
4

[0001104659-10-021941:8k_2_02:37]
Operating income was $24
million and the operating margin was 7.1%. 
Special items of $2 million consisted of restructuring charges.  Operating income before special items
increased $51 million primarily due to better spreads resulting from a lower
average cost for steel products.  The
operating margin before special items was 7.7%.

[0001104659-10-021941:8k_2_02:38]
Safety Products

[0001104659-10-021941:8k_2_02:39]
|  |  | Q2 2010 |  | Q2 2009 |  | % Change |  |
| Revenue |  | $ | 360 |  | $ | 375 |  | (4 | )% |
| Operating Income |  | $ | 47 |  | $ | (537 | ) | — |  |
| Operating Margin |  | 13.1 | % | — |  |  |  |
| Special Items |  | $ | (5 | ) | $ | (592 | ) |  |  |
| Operating Income Before Special Items |  | $ | 52 |  | $ | 55 |  | (5 | )% |
| Operating Margin Before Special Items |  | 14.4 | % | 14.7 | % |  |  |

[0001104659-10-021941:8k_2_02:40]
Revenue
of $360 million declined 4% in the quarter with an organic revenue decline of
7%.  Organic revenue growth of 1% in
Electronic Security was more than offset by declines of 12% in Fire Suppression
and 3% in Life Safety.

[0001104659-10-021941:8k_2_02:41]
Operating
income was $47 million and the operating margin was 13.1%.  Special items of $5 million consisted of
restructuring and divestiture charges. 
Operating income before special items was $52 million and the operating
margin before special items was 14.4%. 
The margin impact from lower organic revenue was mostly offset by the
benefits of restructuring and cost-containment actions as well as product mix.

[0001104659-10-021941:8k_2_02:42]
OTHER ITEMS

[0001104659-10-021941:8k_2_02:43]
·                  Corporate expense was $104 million in the
quarter and included special items of $7 million.  Corporate expense before special items was
$97 million.

[0001104659-10-021941:8k_2_02:44]
·                  The tax rate for the quarter was 14.0% and
the tax rate before special items was 16.6%.

[0001104659-10-021941:8k_2_02:45]
·                  The company incurred pre-tax charges of $21
million in the quarter related to restructuring activities.

[0001104659-10-021941:8k_2_02:46]
·                  As previously announced, Tyco expects to
complete its acquisition of Brinks Home Security Holdings, operating as
Broadview Security, on May 14, 2010, pending approval of the transaction
by Brinks’ shareholders on May 12, 2010.

[0001104659-10-021941:8k_2_02:47]
·                  On April 12, 2010 Standard &
Poor’s upgraded Tyco’s debt rating from BBB+ to A-.

[0001104659-10-021941:8k_2_02:48]
5

[0001104659-10-021941:8k_2_02:49]
ABOUT TYCO INTERNATIONAL

[0001104659-10-021941:8k_2_02:50]
Tyco International Ltd. (NYSE: TYC) is a diversified
company that provides vital products and services to customers around the
world.  Tyco is a leading provider of
security products and services, fire protection and detection products and
services, valves and controls, and other industrial products.  Tyco had 2009 revenue of more than $17
billion and has more than 100,000 employees worldwide.  More information on Tyco can be found at
www.tyco.com.

[0001104659-10-021941:8k_2_02:51]
CONFERENCE CALL AND WEBCAST

[0001104659-10-021941:8k_2_02:52]
Management will discuss the
company’s second quarter results for 2010 and outlook for the third quarter and
full year during a conference call and webcast today beginning at 8:00 a.m.
EST.  Today’s conference call for
investors can be accessed in the following ways:

[0001104659-10-021941:8k_2_02:53]
·                  At Tyco’s website: http://investors.tyco.com.

[0001104659-10-021941:8k_2_02:54]
·                  By telephone: For both “listen-only”
participants and those participants who wish to take part in the
question-and-answer portion of the call, the telephone dial-in number in the
United States is (888) 455-5685.  The
telephone dial-in number for participants outside the United States is (773)
799-3896.  The participant code is TYCO.

[0001104659-10-021941:8k_2_02:55]
·                  An audio replay of the conference call will
be available beginning at 4:00 p.m. on April 27, 2010 and ending on May 3,
2010. The dial-in number for participants in the United States is (800)
756-0715. For participants outside the United States, the replay dial-in number
is (203) 369-3427.

[0001104659-10-021941:8k_2_02:56]
NON-GAAP MEASURES

[0001104659-10-021941:8k_2_02:57]
“Organic revenue,” “free cash flow (outflow)” (FCF), “income
from continuing operations before special items”, “earnings per share (EPS)
from continuing operations before special items”, “operating income before
special items” and “operating margin before special items” are non-GAAP
measures and should not be considered replacements for GAAP results.

[0001104659-10-021941:8k_2_02:58]
Organic revenue is a useful measure used by the
company to measure the underlying results and trends in the business. The
difference between reported net revenue (the most comparable GAAP measure) and
organic revenue (the non-GAAP measure) consists of the impact from foreign currency,
acquisitions and divestitures, and other changes that do not reflect the
underlying results and trends (for example, revenue reclassifications and
changes to the fiscal year). Organic revenue is a useful measure of the company’s
performance because it excludes items that: i) are not completely under
management’s control, such as the impact of foreign currency exchange; or ii)
do not reflect the underlying results of the company’s existing businesses,
such as acquisitions and divestitures. It may be used as a component of the
company’s compensation programs. The limitation of this measure is that it
excludes items that have an impact on the company’s revenue. This limitation is
best addressed by using organic

[0001104659-10-021941:8k_2_02:59]
6

[0001104659-10-021941:8k_2_02:60]
revenue in combination with the GAAP numbers. See the
accompanying tables to this press release for the reconciliation presenting the
components of organic revenue.

[0001104659-10-021941:8k_2_02:61]
FCF is a useful measure of the company’s cash which
is free from any significant existing obligation. The difference between Cash
Flows from Operating Activities (the most comparable GAAP measure) and FCF (the
non-GAAP measure) consists mainly of significant cash flows that the company
believes are useful to identify. FCF permits management and investors to gain
insight into the number that management employs to measure cash that is free
from any significant existing obligation. It, or a measure that is based on it,
may be used as a component in the company’s incentive compensation plans. The
difference reflects the impact from:

[0001104659-10-021941:8k_2_02:62]
·
net capital expenditures,

[0001104659-10-021941:8k_2_02:63]
·
accounts purchased by ADT,

[0001104659-10-021941:8k_2_02:64]
·
cash paid for purchase accounting and holdback liabilities,

[0001104659-10-021941:8k_2_02:65]
·
voluntary pension contributions, and

[0001104659-10-021941:8k_2_02:66]
·
the sale of accounts receivable programs.

[0001104659-10-021941:8k_2_02:67]
Capital expenditures and accounts purchased by ADT
are subtracted because they represent long-term commitments. Cash paid for
purchase accounting and holdback liabilities is subtracted because these cash
outflows are not available for general corporate uses. Voluntary pension
contributions and the impact from the sale of accounts receivable programs are
added or subtracted because this activity is driven by economic financing
decisions rather than operating activity.

[0001104659-10-021941:8k_2_02:68]
The limitation associated with using FCF is that it
adjusts for cash items that are ultimately within management’s and the Board of
Directors’ discretion to direct and therefore may imply that there is less or
more cash that is available for the company’s programs than the most comparable
GAAP measure. This limitation is best addressed by using FCF in combination
with the GAAP cash flow numbers.

[0001104659-10-021941:8k_2_02:69]
FCF as presented herein may not be comparable to
similarly titled measures reported by other companies. The measure should be
used in conjunction with other GAAP financial measures. Investors are urged to
read the company’s financial statements as filed with the Securities and
Exchange Commission, as well as the accompanying tables to this press release
that show all the elements of the GAAP measures of Cash Flows from Operating
Activities, Cash Flows from Investing Activities, Cash Flows from Financing
Activities and a reconciliation of the company’s total cash and cash
equivalents for the period. See the accompanying tables to this press release
for a cash flow statement presented in accordance with GAAP and a
reconciliation presenting the components of FCF.

[0001104659-10-021941:8k_2_02:70]
The company has presented its income and EPS from
continuing operations before special items and operating income and margin
before special items. Special Items include charges and gains related to
divestitures, acquisitions, restructurings, impairments, legacy legal and tax
charges and other income or charges that may mask the underlying operating
results and/or business trends of the company or business segment, as
applicable. The company utilizes income and EPS from continuing operations
before special items and operating income and margin before special items to
assess overall operating performance and segment level core operating
performance, as well as to provide insight to management in evaluating overall
and segment operating plan execution and underlying market conditions. They may
be used as components in the company’s incentive compensation plans. Operating
income, operating margin, and income and EPS from continuing operations before
special items are useful

[0001104659-10-021941:8k_2_02:71]
7

[0001104659-10-021941:8k_2_02:72]
measures for investors because they permit more
meaningful comparisons of the company’s underlying operating results and
business trends between periods. The difference between income and EPS from
continuing operations before special items and income and EPS from continuing
operations (the most comparable GAAP measures) consists of the impact of
charges and gains related to divestitures, acquisitions, restructurings,
impairments, legacy legal and tax charges and other income or charges that may
mask the underlying operating results and/or business trends. Operating income
and margin before special items do not reflect any additional adjustments that
are not reflected in income from continuing operations before special
items.  The limitation of these measures is that they exclude the impact
(which may be material) of items that increase or decrease the company’s
reported operating income and margin and operating income and EPS from
continuing operations. This limitation is best addressed by using the non-GAAP
measures in combination with the most comparable GAAP measures in order to
better understand the amounts, character and impact of any increase or decrease
on reported results. Tyco provides general corporate services to its segments
and those costs are reported in the “Corporate and Other” segment. This segment’s
operating income (loss) is presented as “Corporate Expense.”

[0001104659-10-021941:8k_2_02:73]
FORWARD-LOOKING STATEMENTS

[0001104659-10-021941:8k_2_02:74]
#  #  #

[0001104659-10-021941:8k_2_02:75]
8

[0001104659-10-021941:8k_2_02:76]
TYCO
INTERNATIONAL LTD.

[0001104659-10-021941:8k_2_02:77]
CONSOLIDATED
STATEMENTS OF OPERATIONS

[0001104659-10-021941:8k_2_02:78]
(in
millions, except per share data)

[0001104659-10-021941:8k_2_02:79]
(Unaudited)

[0001104659-10-021941:8k_2_02:80]
|  |  | Quarters Ended |  | Six Months Ended |  |
|  |  | March 26, |  | March 27, |  | March 26, |  | March 27, |  |
|  |  | 2010 |  | 2009 |  | 2010 |  | 2009 |  |
| Net revenue |  | $ | 4,169 |  | $ | 4,150 |  | $ | 8,415 |  | $ | 8,576 |  |
| Cost of sales |  | 2,659 |  | 2,715 |  | 5,340 |  | 5,584 |  |
| Selling, general and administrative expenses |  | 1,108 |  | 1,200 |  | 2,248 |  | 2,340 |  |
| Goodwill and intangible asset impairments |  | — |  | 2,705 |  | — |  | 2,705 |  |
| Restructuring, asset impairment and (gain)/loss on divestitures, net |  | (25 | ) | 84 |  | (14 | ) | 88 |  |
| Operating income (loss) |  | 427 |  | (2,554 | ) | 841 |  | (2,141 | ) |
| Interest income |  | 7 |  | 11 |  | 16 |  | 23 |  |
| Interest expense |  | (74 | ) | (78 | ) | (150 | ) | (151 | ) |
| Other income, net |  | 3 |  | 7 |  | 12 |  | 11 |  |
| Income (loss) from continuing operations before income taxes |  | 363 |  | (2,614 | ) | 719 |  | (2,258 | ) |
| Income tax (expense) benefit |  | (51 | ) | 60 |  | (104 | ) | (24 | ) |
| Income (loss) from continuing operations |  | 312 |  | (2,554 | ) | 615 |  | (2,282 | ) |
| Loss from discontinued operations, net of income taxes |  | — |  | (12 | ) | — |  | (7 | ) |
| Net income (loss) |  | 312 |  | (2,566 | ) | 615 |  | (2,289 | ) |
| Less: noncontrolling interest in subsidiaries net income |  | 2 |  | 1 |  | 3 |  | 1 |  |
| Net income (loss) attributable to Tyco common shareholders |  | $ | 310 |  | $ | (2,567 | ) | $ | 612 |  | $ | (2,290 | ) |
| Amounts attributable to Tyco common shareholders |  |  |  |  |  |  |  |  |  |
| Income (loss) from continuing operations |  | $ | 310 |  | $ | (2,555 | ) | $ | 612 |  | $ | (2,283 | ) |
| Loss from discontinued operations |  | — |  | (12 | ) | — |  | (7 | ) |
| Net income (loss) attributable to Tyco common shareholders |  | $ | 310 |  | $ | (2,567 | ) | $ | 612 |  | $ | (2,290 | ) |
| Basic earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |
| Income (loss) from continuing operations |  | $ | 0.65 |  | $ | (5.40 | ) | $ | 1.29 |  | $ | (4.83 | ) |
| Loss from discontinued operations |  | — |  | (0.02 | ) | — |  | (0.01 | ) |
| Net income (loss) attributable to Tyco common shareholders |  | $ | 0.65 |  | $ | (5.42 | ) | $ | 1.29 |  | $ | (4.84 | ) |
| Diluted earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |
| Income (loss) from continuing operations |  | $ | 0.65 |  | $ | (5.40 | ) | $ | 1.28 |  | $ | (4.83 | ) |
| Loss from discontinued operations |  | — |  | (0.02 | ) | — |  | (0.01 | ) |
| Net income (loss) attributable to Tyco common shareholders |  | $ | 0.65 |  | $ | (5.42 | ) | $ | 1.28 |  | $ | (4.84 | ) |
| Weighted-average number of shares outstanding: |  |  |  |  |  |  |  |  |  |
| Basic |  | 476 |  | 473 |  | 476 |  | 473 |  |
| Diluted |  | 478 |  | 473 |  | 479 |  | 473 |  |

[0001104659-10-021941:8k_2_02:81]
NOTE:                 These financial
statements should be read in conjunction with the Consolidated Financial
Statements and accompanying notes contained in the Company’s Annual Report on
Form 10-K for the fiscal year ended September 25, 2009 and Quarterly
Report on Form 10-Q for the quarter ended December 25, 2009.

[0001104659-10-021941:8k_2_02:82]
9

[0001104659-10-021941:8k_2_02:83]
TYCO
INTERNATIONAL LTD.

[0001104659-10-021941:8k_2_02:84]
RESULTS
OF SEGMENTS

[0001104659-10-021941:8k_2_02:85]
(in
millions)

[0001104659-10-021941:8k_2_02:86]
(Unaudited)

[0001104659-10-021941:8k_2_02:87]
|  |  | Quarters Ended |  |  |  | Six Months Ended |  |  |  |
|  |  | March 26, |  |  |  | March 27, |  |  |  | March 26, |  |  |  | March 27, |  |  |  |
|  |  | 2010 |  |  |  | 2009 |  |  |  | 2010 |  |  |  | 2009 |  |  |  |
| NET REVENUE |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ADT Worldwide |  | $ | 1,767 |  |  |  | $ | 1,705 |  |  |  | $ | 3,602 |  |  |  | $ | 3,516 |  |  |  |
| Flow Control |  | 899 |  |  |  | 927 |  |  |  | 1,822 |  |  |  | 1,886 |  |  |  |
| Fire Protection Services |  | 807 |  |  |  | 813 |  |  |  | 1,640 |  |  |  | 1,652 |  |  |  |
| Electrical and Metal Products |  | 336 |  |  |  | 330 |  |  |  | 633 |  |  |  | 746 |  |  |  |
| Safety Products |  | 360 |  |  |  | 375 |  |  |  | 718 |  |  |  | 776 |  |  |  |
| Corporate and Other |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |
| Total Net Revenue |  | $ | 4,169 |  |  |  | $ | 4,150 |  |  |  | $ | 8,415 |  |  |  | $ | 8,576 |  |  |  |
| OPERATING INCOME (LOSS) AND MARGIN |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ADT Worldwide |  | $ | 305 |  | 17.3 | % | $ | (867 | ) | N/M |  | $ | 564 |  | 15.7 | % | $ | (640 | ) | N/M |  |
| Flow Control |  | 93 |  | 10.3 | % | 133 |  | 14.3 | % | 205 |  | 11.3 | % | 270 |  | 14.3 | % |
| Fire Protection Services |  | 62 |  | 7.7 | % | (121 | ) | N/M |  | 126 |  | 7.7 | % | (65 | ) | N/M |  |
| Electrical and Metal Products |  | 24 |  | 7.1 | % | (961 | ) | N/M |  | 47 |  | 7.4 | % | (934 | ) | N/M |  |
| Safety Products |  | 47 |  | 13.1 | % | (537 | ) | N/M |  | 101 |  | 14.1 | % | (457 | ) | N/M |  |
| Corporate and Other |  | (104 | ) | N/M |  | (201 | ) | N/M |  | (202 | ) | N/M |  | (315 | ) | N/M |  |
| Operating Income (Loss) and Margin |  | $ | 427 |  | N/M |  | $ | (2,554 | ) | N/M |  | $ | 841 |  | N/M |  | $ | (2,141 | ) | N/M |  |

[0001104659-10-021941:8k_2_02:88]
10

[0001104659-10-021941:8k_2_02:89]
TYCO
INTERNATIONAL LTD.

[0001104659-10-021941:8k_2_02:90]
CONSOLIDATED
BALANCE SHEETS

[0001104659-10-021941:8k_2_02:91]
(in
millions)

[0001104659-10-021941:8k_2_02:92]
(Unaudited)

[0001104659-10-021941:8k_2_02:93]
|  |  | March 26, |  | September 25, |  |
|  |  | 2010 |  | 2009 |  |
| Current Assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,733 |  | $ | 2,354 |  |
| Accounts receivable, net |  | 2,460 |  | 2,629 |  |
| Inventories |  | 1,464 |  | 1,443 |  |
| Other current assets |  | 1,340 |  | 1,385 |  |
| Assets held for sale |  | — |  | 156 |  |
| Total current assets |  | 7,997 |  | 7,967 |  |
| Property, plant and equipment, net |  | 3,501 |  | 3,497 |  |
| Goodwill |  | 8,665 |  | 8,791 |  |
| Intangible assets, net |  | 2,698 |  | 2,647 |  |
| Other assets |  | 2,611 |  | 2,651 |  |
| Total Assets |  | $ | 25,472 |  | $ | 25,553 |  |
| Current Liabilities: |  |  |  |  |  |
| Short-term debt and current maturities of long-term debt |  | $ | 536 |  | $ | 245 |  |
| Accounts payable |  | 1,164 |  | 1,244 |  |
| Accrued and other current liabilities |  | 2,441 |  | 2,476 |  |
| Deferred revenue |  | 614 |  | 590 |  |
| Liabilities held for sale |  | — |  | 161 |  |
| Total current liabilities |  | 4,755 |  | 4,716 |  |
| Long-term debt |  | 3,995 |  | 4,029 |  |
| Other liabilities |  | 3,799 |  | 3,854 |  |
| Total Liabilities |  | 12,549 |  | 12,599 |  |
| Tyco’s shareholders’ equity |  | 12,907 |  | 12,941 |  |
| Noncontrolling interest |  | 16 |  | 13 |  |
| Total Equity |  | 12,923 |  | 12,954 |  |
| Total Liabilities and Equity |  | $ | 25,472 |  | $ | 25,553 |  |

[0001104659-10-021941:8k_2_02:94]
NOTE: These financial
statements should be read in conjunction with the Consolidated Financial
Statements and accompanying notes contained in the Company’s Annual Report on
Form 10-K for the fiscal year ended September 25, 2009 and Quarterly
Report on Form 10-Q for the quarter ended December 25, 2009.

[0001104659-10-021941:8k_2_02:95]
11

[0001104659-10-021941:8k_2_02:96]
TYCO
INTERNATIONAL LTD.

[0001104659-10-021941:8k_2_02:97]
CONSOLIDATED
STATEMENTS OF CASH FLOWS

[0001104659-10-021941:8k_2_02:98]
(in
millions)

[0001104659-10-021941:8k_2_02:99]
(Unaudited)

[0001104659-10-021941:8k_2_02:100]
|  |  | Quarters Ended |  | Six Months Ended |  |
|  |  | March 26, |  | March 27, |  | March 26, |  | March 27, |  |
|  |  | 2010 |  | 2009 |  | 2010 |  | 2009 |  |
| Cash Flows from Operating Activities: |  |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to Tyco common shareholders |  | $ | 310 |  | $ | (2,567 | ) | $ | 612 |  | $ | (2,290 | ) |
| Noncontrolling interests in subsidiaries net income |  | 2 |  | 1 |  | 3 |  | 1 |  |
| Loss from discontinued operations, net of income taxes |  | — |  | 12 |  | — |  | 7 |  |
| Income (loss) from continuing operations |  | 312 |  | (2,554 | ) | 615 |  | (2,282 | ) |
| Adjustments to reconcile net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |
| Goodwill and intangible asset impairments |  | — |  | 2,705 |  | — |  | 2,705 |  |
| Depreciation and amortization |  | 282 |  | 284 |  | 569 |  | 559 |  |
| Non-cash compensation expense |  | 32 |  | 23 |  | 63 |  | 52 |  |
| Deferred income taxes |  | (39 | ) | (165 | ) | (35 | ) | (182 | ) |
| Provision for losses on accounts receivable and inventory |  | 30 |  | 35 |  | 64 |  | 69 |  |
| Other non-cash items |  | (26 | ) | 17 |  | (23 | ) | 35 |  |
| Changes in assets and liabilities, net of the effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (25 | ) | 149 |  | 66 |  | 162 |  |
| Inventories |  | (29 | ) | 172 |  | (73 | ) | 21 |  |
| Other current assets |  | 18 |  | (301 | ) | 20 |  | (287 | ) |
| Accounts payable |  | 19 |  | (201 | ) | (52 | ) | (376 | ) |
| Accrued expenses and other liabilities |  | 14 |  | 490 |  | (202 | ) | 190 |  |
| Income taxes, net |  | (1 | ) | (8 | ) | — |  | 22 |  |
| Other |  | 45 |  | 80 |  | (1 | ) | 94 |  |
| Net cash provided by operating activities |  | 632 |  | 726 |  | 1,011 |  | 782 |  |
| Net cash used in discontinued operating activities |  | — |  | (13 | ) | — |  | (13 | ) |
| Cash Flows from Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures |  | (170 | ) | (172 | ) | (335 | ) | (331 | ) |
| Proceeds from disposal of assets |  | 3 |  | 2 |  | 19 |  | 4 |  |
| Acquisition of businesses, net of cash acquired |  | (9 | ) | (2 | ) | (152 | ) | (47 | ) |
| Accounts purchased by ADT |  | (116 | ) | (114 | ) | (266 | ) | (231 | ) |
| Divestiture of businesses, net of cash retained |  | 13 |  | 6 |  | 28 |  | 8 |  |
| Other |  | 1 |  | (22 | ) | 11 |  | (6 | ) |
| Net cash used in investing activities |  | (278 | ) | (302 | ) | (695 | ) | (603 | ) |
| Net cash provided by discontinued investing activities |  | — |  | 29 |  | — |  | 32 |  |
| Cash Flows from Financing Activities: |  |  |  |  |  |  |  |  |  |
| Net proceeds from issuance of debt |  | (2 | ) | (126 | ) | 246 |  | (20 | ) |
| Proceeds from exercise of share options |  | 3 |  | 1 |  | 9 |  | 1 |  |
| Dividends paid |  | (107 | ) | (94 | ) | (214 | ) | (189 | ) |
| Repurchase of common shares by subsidiary |  | — |  | — |  | — |  | (3 | ) |
| Transfers from discontinued operations |  | — |  | 16 |  | — |  | 19 |  |
| Other |  | 9 |  | (7 | ) | 21 |  | (5 | ) |
| Net cash (used in) provided by financing activities |  | (97 | ) | (210 | ) | 62 |  | (197 | ) |
| Net cash used in discontinued financing activities |  | — |  | (16 | ) | — |  | (19 | ) |
| Effect of currency translation on cash |  | 3 |  | 12 |  | 1 |  | (82 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 260 |  | 226 |  | 379 |  | (100 | ) |
| Cash and cash equivalents at beginning of period |  | 2,473 |  | 1,193 |  | 2,354 |  | 1,519 |  |
| Cash and cash equivalents at end of period |  | $ | 2,733 |  | $ | 1,419 |  | $ | 2,733 |  | $ | 1,419 |  |
| Reconciliation to “Free Cash Flow”: |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 632 |  | $ | 726 |  | $ | 1,011 |  | $ | 782 |  |
| Sale of accounts receivable |  | 3 |  | 7 |  | 2 |  | 10 |  |
| Capital expenditures, net |  | (167 | ) | (170 | ) | (316 | ) | (327 | ) |
| Accounts purchased by ADT |  | (116 | ) | (114 | ) | (266 | ) | (231 | ) |
| Purchase accounting and holdback liabilities |  | (3 | ) | (1 | ) | (3 | ) | (1 | ) |
| Voluntary pension contributions |  | — |  | 6 |  | — |  | 6 |  |
| Free Cash Flow |  | $ | 349 |  | $ | 454 |  | $ | 428 |  | $ | 239 |  |

[0001104659-10-021941:8k_2_02:101]
NOTE:
Free cash flow is a non-GAAP measure. 
See description of non-GAAP measures contained in this release.

[0001104659-10-021941:8k_2_02:102]
12

[0001104659-10-021941:8k_2_02:103]
TYCO
INTERNATIONAL LTD.

[0001104659-10-021941:8k_2_02:104]
ORGANIC
REVENUE RECONCILIATION

[0001104659-10-021941:8k_2_02:105]
(in
millions)

[0001104659-10-021941:8k_2_02:106]
(Unaudited)

[0001104659-10-021941:8k_2_02:107]
|  |  | Quarter Ended March 26, 2010 |  | Net Revenue for the Quarter |  |
|  |  | Net Revenue |  | Foreign Currency |  | Acquisition / (Divestiture) |  | Organic Revenue |  | Ended March 27, 2009 |  |
| ADT Worldwide |  | $ | 1,767 |  | 3.6 | % | $ | 101 |  | 5.9 | % | $ | (14 | ) | -0.8 | % | $ | (25 | ) | -1.5 | % | $ | 1,705 |  |
| Flow Control |  | 899 |  | -3.0 | % | 92 |  | 9.9 | % | 1 |  | 0.2 | % | (121 | ) | -13.1 | % | 927 |  |
| Fire Protection Services |  | 807 |  | -0.7 | % | 51 |  | 6.3 | % | (2 | ) | -0.2 | % | (55 | ) | -6.8 | % | 813 |  |
| Electrical and Metal Products |  | 336 |  | 1.8 | % | 13 |  | 3.9 | % | 4 |  | 1.2 | % | (11 | ) | -3.3 | % | 330 |  |
| Safety Products |  | 360 |  | -4.0 | % | 18 |  | 4.8 | % | (6 | ) | -1.6 | % | (27 | ) | -7.2 | % | 375 |  |
| Total Net Revenue |  | $ | 4,169 |  | 0.5 | % | $ | 275 |  | 6.6 | % | $ | (17 | ) | -0.3 | % | $ | (239 | ) | -5.8 | % | $ | 4,150 |  |

[0001104659-10-021941:8k_2_02:108]
|  |  | Six Months Ended March 26, 2010 |  | Net Revenue for the Six Months |  |
|  |  | Net Revenue |  | Foreign Currency |  | Acquisition / (Divestiture) |  | Organic Revenue |  | Ended March 27, 2009 |  |
| ADT Worldwide |  | $ | 3,602 |  | 2.4 | % | $ | 190 |  | 5.4 | % | $ | (19 | ) | -0.6 | % | $ | (85 | ) | -2.4 | % | $ | 3,516 |  |
| Flow Control |  | 1,822 |  | -3.4 | % | 188 |  | 10.0 | % | (2 | ) | -0.1 | % | (250 | ) | -13.3 | % | 1,886 |  |
| Fire Protection Services |  | 1,640 |  | -0.7 | % | 100 |  | 6.1 | % | (3 | ) | -0.2 | % | (109 | ) | -6.6 | % | 1,652 |  |
| Electrical and Metal Products |  | 633 |  | -15.1 | % | 25 |  | 3.4 | % | (2 | ) | -0.3 | % | (136 | ) | -18.2 | % | 746 |  |
| Safety Products |  | 718 |  | -7.5 | % | 36 |  | 4.6 | % | (12 | ) | -1.5 | % | (82 | ) | -10.6 | % | 776 |  |
| Total Net Revenue |  | $ | 8,415 |  | -1.9 | % | $ | 539 |  | 6.3 | % | $ | (38 | ) | -0.5 | % | $ | (662 | ) | -7.7 | % | $ | 8,576 |  |

[0001104659-10-021941:8k_2_02:109]
NOTE:  Organic revenue is a non-GAAP measure.  See description of non-GAAP measures
contained in this release.

[0001104659-10-021941:8k_2_02:110]
13

[0001104659-10-021941:8k_2_02:111]
Tyco International Ltd.

[0001104659-10-021941:8k_2_02:112]
Earnings Per Share Summary

[0001104659-10-021941:8k_2_02:113]
(Unaudited)

[0001104659-10-021941:8k_2_02:114]
|  |  | Quarter Ended |  | Quarter Ended |  |
|  |  | March 26, 2010 |  | March 27, 2009 |  |
| Diluted EPS from Continuing Operations Attributable to Tyco Shareholders (GAAP) |  | $ | 0.65 |  | $ | (5.40 | ) |
| Restructuring, net |  | 0.02 |  | 0.13 |  |
| Restructuring charges in cost of sales and SG&A |  | — |  | 0.02 |  |
| Acquisition costs |  | 0.01 |  | — |  |
| Other additional charges resulting from restructuring actions |  | — |  | 0.01 |  |
| (Gains)/losses on divestitures, net |  | (0.10 | ) | — |  |
| Intangible impairments |  | — |  | 0.09 |  |
| Goodwill impairments |  | — |  | 5.47 |  |
| Tax items |  | 0.01 |  | — |  |
| Legacy legal items |  | — |  | 0.23 |  |
| Total Before Special Items |  | $ | 0.59 |  | $ | 0.55 |  |

[0001104659-10-021941:8k_2_02:115]
14

[0001104659-10-021941:8k_2_02:116]
Tyco International Ltd.

[0001104659-10-021941:8k_2_02:117]
For the Quarter Ended March 26, 2010

[0001104659-10-021941:8k_2_02:118]
(in millions, except per share data)

[0001104659-10-021941:8k_2_02:119]
(Unaudited)

[0001104659-10-021941:8k_2_02:120]
|  |  | ADT |  | Flow |  | Fire Protection |  | Electrical & |  | Safety |  | Corporate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Worldwide |  | Control |  | Services |  | Metal Products |  | Products |  | and Other |  | Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  | $ | 1,767 |  | $ | 899 |  | $ | 807 |  | $ | 336 |  | $ | 360 |  | — |  | $ | 4,169 |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001104659-10-021941:8k_2_02:121]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Income |  | Diluted |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | from |  | EPS from |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Continuing |  | Continuing |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  | Operations |  | Operations |  |
|  |  |  |  |  |  | Fire |  | Electrical |  |  |  |  |  | Total |  |  |  |  |  |  |  |  |  | Attributable |  | Attributable |  |
|  |  | ADT |  | Flow |  | Protection |  | & Metal |  | Safety |  | Corporate |  | Operating |  | Interest |  | Other |  | Income |  | Noncontrolling |  | to Tyco |  | to Tyco |  |
|  |  | Worldwide |  | Control |  | Services |  | Products |  | Products |  | and Other |  | Income |  | Expense, net |  | Income, net |  | Taxes |  | Interest |  | Shareholders |  | Shareholders |  |
| As Reported (GAAP) |  | $ | 305 |  | $ | 93 |  | $ | 62 |  | $ | 24 |  | $ | 47 |  | $ | (104 | ) | $ | 427 |  | $ | (67 | ) | $ | 3 |  | $ | (51 | ) | $ | (2 | ) | $ | 310 |  | $ | 0.65 |  |
| Restructuring, net |  | 4 |  | 8 |  | 4 |  | 2 |  | 2 |  | — |  | 20 |  |  |  |  |  | (7 | ) |  |  | 13 |  | 0.02 |  |
| Restructuring charges in cost of sales and SG&A |  | — |  | 1 |  | — |  | — |  |  |  | — |  | 1 |  |  |  |  |  | — |  |  |  | 1 |  | 0.00 |  |
| Acquisition costs |  | 1 |  |  |  |  |  |  |  |  |  | 3 |  | 4 |  |  |  |  |  |  |  |  |  | 4 |  | 0.01 |  |
| Losses on divestitures, net |  | (51 | ) | (1 | ) | — |  | — |  | 3 |  | 4 |  | (45 | ) |  |  |  |  | (4 | ) |  |  | (49 | ) | (0.10 | ) |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 5 |  |  |  | 5 |  | 0.01 |  |
| Total Before Special Items |  | $ | 259 |  | $ | 101 |  | $ | 66 |  | $ | 26 |  | $ | 52 |  | $ | (97 | ) | $ | 407 |  | $ | (67 | ) | $ | 3 |  | $ | (57 | ) | $ | (2 | ) | $ | 284 |  | $ | 0.59 |  |

[0001104659-10-021941:8k_2_02:122]
| Diluted Shares Outstanding |  | 478 |  |
| Diluted Shares Outstanding - Before Special Items |  | 478 |  |

[0001104659-10-021941:8k_2_02:123]
Tyco International Ltd.

[0001104659-10-021941:8k_2_02:124]
For the Quarter Ended March 27, 2009

[0001104659-10-021941:8k_2_02:125]
(in millions, except per share data)

[0001104659-10-021941:8k_2_02:126]
(Unaudited)

[0001104659-10-021941:8k_2_02:127]
|  |  | ADT |  | Flow |  | Fire Protection |  | Electrical & |  | Safety |  | Corporate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Worldwide |  | Control |  | Services |  | Metal Products |  | Products |  | and Other |  | Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Previously Reported Revenue (GAAP) |  | $ | 1,694 |  | $ | 927 |  | $ | 817 |  | $ | 330 |  | $ | 382 |  | — |  | $ | 4,150 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Segment Realignment |  | 11 |  |  |  | (4 | ) |  |  | (7 | ) |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Recasted Revenue (GAAP) |  | $ | 1,705 |  | $ | 927 |  | $ | 813 |  | $ | 330 |  | $ | 375 |  | — |  | $ | 4,150 |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001104659-10-021941:8k_2_02:128]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Income |  | Diluted |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | from |  | EPS from |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Continuing |  | Continuing |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  | Operations |  | Operations |  |
|  |  |  |  |  |  | Fire |  | Electrical |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Attributable |  | Attributable |  |
|  |  | ADT |  | Flow |  | Protection |  | & Metal |  | Safety |  | Corporate |  | Operating |  | Interest |  | Other |  | Income |  | Noncontrolling |  | to Tyco |  | to Tyco |  |
|  |  | Worldwide |  | Control |  | Services |  | Products |  | Products |  | and Other |  | Income |  | Expense, net |  | Income, net |  | Taxes |  | Interest |  | Shareholders |  | Shareholders |  |
| As Previously Reported (GAAP) |  | $ | (457 | ) | $ | 133 |  | $ | (122 | ) | $ | (962 | ) | $ | (943 | ) | $ | (203 | ) | $ | (2,554 | ) | $ | (67 | ) | $ | 7 |  | $ | 60 |  | $ | (1 | ) | $ | (2,555 | ) | $ | (5.40 | ) |
| Segment Realignment |  | (410 | ) |  |  | 1 |  | 1 |  | 406 |  | 2 |  | — |  |  |  |  |  |  |  |  |  | — |  |  |  |
| As Reported (GAAP) |  | $ | (867 | ) | $ | 133 |  | $ | (121 | ) | $ | (961 | ) | $ | (537 | ) | $ | (201 | ) | $ | (2,554 | ) | $ | (67 | ) | $ | 7 |  | $ | 60 |  | $ | (1 | ) | $ | (2,555 | ) | $ | (5.40 | ) |
| Restructuring and asset impairment charges, net |  | 48 |  | 4 |  | 11 |  | 2 |  | 16 |  | 5 |  | 86 |  |  |  |  |  | (24 | ) |  |  | 62 |  | 0.13 |  |
| Restructuring charges in cost of sales and SG&A |  | 7 |  | 1 |  |  |  | 4 |  | 5 |  | 1 |  | 18 |  |  |  |  |  | (7 | ) |  |  | 11 |  | 0.02 |  |
| Other additional charges resulting from restructuring actions |  |  |  |  |  |  |  |  |  | 4 |  |  |  | 4 |  |  |  |  |  | (1 | ) |  |  | 3 |  | 0.01 |  |
| (Gains)/losses on divestitures, net |  |  |  | 3 |  |  |  | (5 | ) |  |  |  |  | (2 | ) |  |  |  |  |  |  |  |  | (2 | ) |  |  |
| Intangible impairments |  | 64 |  |  |  |  |  |  |  | — |  |  |  | 64 |  |  |  |  |  | (25 | ) |  |  | 39 |  | 0.09 |  |
| Goodwill impairments |  | 959 |  |  |  | 180 |  | 935 |  | 567 |  |  |  | 2,641 |  |  |  |  |  | (43 | ) |  |  | 2,598 |  | 5.47 |  |
| Legacy legal items |  |  |  |  |  |  |  |  |  |  |  | 101 |  | 101 |  |  |  |  |  | 4 |  |  |  | 105 |  | 0.23 |  |
| Total Before Special Items |  | $ | 211 |  | $ | 141 |  | $ | 70 |  | $ | (25 | ) | $ | 55 |  | $ | (94 | ) | $ | 358 |  | $ | (67 | ) | $ | 7 |  | $ | (36 | ) | $ | (1 | ) | $ | 261 |  | $ | 0.55 |  |

[0001104659-10-021941:8k_2_02:129]
| Diluted Shares Outstanding |  | 473 |  |
| Diluted Shares Outstanding - Before Special Items |  | 475 |  |

[0001104659-10-021941:8k_2_02:130]
16
