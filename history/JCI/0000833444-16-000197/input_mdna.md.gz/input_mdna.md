# JCI MD&A — 0000833444-16-000197


## mdna

[0000833444-16-000197:mdna:1]
[same as prior period, unchanged from 0000833444-16-000172:mdna:1]

[0000833444-16-000197:mdna:2]
[same as prior period, unchanged from 0000833444-16-000172:mdna:2]

[0000833444-16-000197:mdna:3]
[same as prior period, unchanged from 0000833444-16-000172:mdna:3]

[0000833444-16-000197:mdna:4]
[same as prior period, unchanged from 0000833444-16-000172:mdna:4]

[0000833444-16-000197:mdna:5]
References to 2016 and 2015 are to Tyco's fiscal quarters ending June 24, 2016 and June 26, 2015, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September. Fiscal 2016 is a 53-week year as compared with fiscal 2015, which was 52 weeks, with the additional week occurring in the fourth quarter of fiscal 2016. The Company's results for the quarters and nine months ended June 24, 2016 and June 26, 2015 both consisted of 13 weeks and 39 weeks, respectively.

[0000833444-16-000197:mdna:6]
[same as prior period, unchanged from 0000833444-16-000172:mdna:6]

[0000833444-16-000197:mdna:7]
[same as prior period, unchanged from 0000833444-16-000172:mdna:7]

[0000833444-16-000197:mdna:8]
[same as prior period, unchanged from 0000833444-16-000172:mdna:8]

[0000833444-16-000197:mdna:9]
[same as prior period, unchanged from 0000833444-16-000172:mdna:9]

[0000833444-16-000197:mdna:10]
[same as prior period, unchanged from 0000833444-16-000172:mdna:10]

[0000833444-16-000197:mdna:11]
[same as prior period, unchanged from 0000833444-16-000172:mdna:11]

[0000833444-16-000197:mdna:12]
Effective for the first quarter of fiscal 2016, the Company elected to present operating income by segment, as well as Corporate and Other, excluding restructuring and repositioning charges, net.  Restructuring and repositioning charges, net, are shown in aggregate. This presentation is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. See Note 15 to the unaudited Consolidated Financial Statements.

[0000833444-16-000197:mdna:13]
During the third quarter of fiscal 2016, the Company reclassified the assets and liabilities of a business it plans to sell as held for sale for all periods presented within the Consolidated Balance Sheets. As of June 24, 2016, assets of $71 million and liabilities of $34 million were reclassified as held for sale related to this business. The results of operations of this business in the ROW Integrated Solutions & Services segment are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied. During the second quarter of fiscal 2016, the Company completed the sale of its Australian fire protection business, included in the ROW Integrated Solutions & Services segment. The assets and liabilities related to this business were classified as held for sale as of September 25, 2015.  Its results of operations are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied. See Note 3 to the unaudited Consolidated Financial Statements.

[0000833444-16-000197:mdna:14]
[same as prior period, unchanged from 0000833444-16-000172:mdna:14]

[0000833444-16-000197:mdna:15]
[same as prior period, unchanged from 0000833444-16-000172:mdna:15]

[0000833444-16-000197:mdna:16]
On January 25, 2016, Tyco and Johnson Controls, Inc. ("Johnson Controls") announced that they had entered into a definitive merger agreement to combine Tyco and Johnson Controls and create a global leader in building products and technology, integrated solutions and energy storage. Under the terms of the agreement, which was unanimously approved by both companies’ Boards of Directors, Johnson Controls shareholders will own approximately 56% of the equity of the combined company and receive aggregate cash consideration of approximately $3.9 billion. Tyco shareholders will own approximately 44% of the equity of the combined company.

[0000833444-16-000197:mdna:17]
[same as prior period, unchanged from 0000833444-16-000172:mdna:17]

[0000833444-16-000197:mdna:18]
[same as prior period, unchanged from 0000833444-16-000172:mdna:18]

[0000833444-16-000197:mdna:19]
[same as prior period, unchanged from 0000833444-16-000172:mdna:19]

[0000833444-16-000197:mdna:20]
[same as prior period, unchanged from 0000833444-16-000172:mdna:20]

[0000833444-16-000197:mdna:21]
Settlement with IRS

[0000833444-16-000197:mdna:22]
On January 15, 2016, Tyco entered into Stipulations of Settled Issues with the IRS intended to resolve all disputes related to the intercompany debt issues for the 1997 - 2000 audit cycle that were before the U.S. Tax Court at the time. The Stipulations of Settled Issues were contingent upon the IRS Appeals Division applying the same settlement to all intercompany debt issues on appeal for subsequent audit cycles (2001 - 2007). The tentative resolution was finalized on May 31, 2016.  The final resolution covers all aspects of the controversy that were before the U.S. Tax Court and the Appeals Division of the IRS. In the second quarter of fiscal 2016, the Company paid $120 million to TE Connectivity and $2 million to Covidien, which was subsequently paid to the IRS, in connection with the resolution.

[0000833444-16-000197:mdna:23]
As a result of the final settlement, the Company assessed its remaining obligations under its tax sharing agreements. Based on the assessment performed, the Company reversed a portion of its shared tax obligation liabilities related to the 2007 and 2012 Tax Sharing Agreements, and recognized a gain of $54 million in Other income (expense), net within the Consolidated Statements of Operations for both the quarter and nine months ended June 24, 2016. The Company believes the remaining liabilities that it has recorded are sufficient to cover its future obligations under the Tax Sharing Agreements. See Note 6 to the unaudited Consolidated Financial Statements.

[0000833444-16-000197:mdna:24]
[same as prior period, unchanged from 0000833444-16-000172:mdna:23]

[0000833444-16-000197:mdna:25]
During the first quarter of fiscal 2016, the Company made an additional investment of approximately $128 million in the Company's joint venture, Tyco UAE, with its local partner Suwaidi Engineering Group in the United Arab Emirates ("UAE"). Tyco UAE is a leading provider of fire, security and integrated solutions and services in the UAE and also has operations in Qatar and Oman.  Effective with the date of this transaction, the Company consolidated 100% of Tyco UAE, which is recorded in the Company's ROW Integrated Solutions & Services segment. As a result of this transaction, the Company recorded a net gain of $111 million recorded in Selling, general and administrative expenses within the Company's Consolidated Statements of Operations. In addition, during the second quarter of fiscal 2016, the Company completed the acquisition of ShopperTrak, a leading global provider of retail consumer behavior insights and location-based analytics, for approximately $176 million in cash. The financial results of this business have been reported in the NA Integrated Solutions & Services and ROW Integrated Solutions & Services segments. See Note 5 to the unaudited Consolidated Financial Statements.

[0000833444-16-000197:mdna:26]
[same as prior period, unchanged from 0000833444-16-000172:mdna:25]

[0000833444-16-000197:mdna:27]
The Company continuously assesses the strategic fit of its various businesses and pursues the divestiture of certain businesses included within the Company's portfolio which do not align with the Company's long-term strategy. During the third quarter of fiscal 2016, the Company concluded that a business in the ROW Integrated Solutions & Services segment which it intends to sell met the criteria to be classified as held for sale, and recorded a loss of $59 million for the quarter and nine months ended June 24, 2016. During the second quarter of fiscal 2016, the Company completed the sale of its Australian fire protection business within its ROW Integrated Solutions & Services segment. As a result, the Company incurred a loss related to this sale of $74 million for the nine months ended June 24, 2016. The losses for both businesses were recorded in Selling, general and administrative expenses within the Company’s Consolidated Statements of Operations. See Note 3 to the unaudited Consolidated Financial Statements.

[0000833444-16-000197:mdna:28]
[same as prior period, unchanged from 0000833444-16-000172:mdna:27]

[0000833444-16-000197:mdna:29]
On September 14, 2015, the Company and TIFSA announced the redemption of all of the outstanding $242 million aggregate principal amount of 7.0% notes due 2019 and $462 million aggregate principal amount of 6.875% notes due 2021. On October 14, 2015, TIFSA paid cash of $876 million to complete the redemption, resulting in a loss on extinguishment of $168 million that was recorded in Other income (expense), net within the Consolidated Statements of Operations during the first quarter of fiscal 2016. On October 15, 2015, the Company repaid at maturity $258 million aggregate principal amount of 3.375% notes. See Note 9 to the unaudited Consolidated Financial Statements.

[0000833444-16-000197:mdna:30]
[same as prior period, unchanged from 0000833444-16-000172:mdna:29]

[0000833444-16-000197:mdna:31]
We are a leading global provider of security products and services, fire detection and suppression products and services and life safety products. We utilize our extensive global footprint of approximately 900 locations, including manufacturing facilities, service and distribution centers, monitoring centers and sales offices, to provide solutions and localized expertise to our global customer base. We provide an extensive range of product and service offerings to over 3 million customers in more than 100 countries through multiple channels. Our revenues are broadly diversified across the United States and Canada (collectively “North America”); Central America and South America (collectively “Latin America”); Europe, the Middle East, and Africa (collectively “EMEA”) and the Asia-Pacific geographic areas. The following chart reflects our net revenue by geographic area for the nine months ended June 24, 2016.

[0000833444-16-000197:mdna:32]
52

[0000833444-16-000197:mdna:33]
Nine Months Ended June 24, 2016

[0000833444-16-000197:mdna:34]
[same as prior period, unchanged from 0000833444-16-000172:mdna:32]

[0000833444-16-000197:mdna:35]
[same as prior period, unchanged from 0000833444-16-000172:mdna:33]

[0000833444-16-000197:mdna:36]
[same as prior period, unchanged from 0000833444-16-000172:mdna:34]

[0000833444-16-000197:mdna:37]
[same as prior period, unchanged from 0000833444-16-000172:mdna:35]

[0000833444-16-000197:mdna:38]
[same as prior period, unchanged from 0000833444-16-000172:mdna:36]

[0000833444-16-000197:mdna:39]
[same as prior period, unchanged from 0000833444-16-000172:mdna:37]

[0000833444-16-000197:mdna:40]
[same as prior period, unchanged from 0000833444-16-000172:mdna:38]

[0000833444-16-000197:mdna:41]
[same as prior period, unchanged from 0000833444-16-000172:mdna:39]

[0000833444-16-000197:mdna:42]
As a global business with a varied customer base and an extensive range of products and services, our operations and results are impacted by global, regional and industry specific factors, and by political factors. Our geographic diversity and the diversity in our customer base and our products and services has helped mitigate the impact of any one industry or the economy of any single country on our consolidated operating results, financial condition and cash flows. Due to the global nature of our business and the variety of our customers, products and services, no single factor is predominantly used to forecast Company results. Rather, management monitors a number of factors to develop expectations regarding future results, including the activity of key competitors and customers, order rates for longer lead time projects, and capital expenditure budgets and spending patterns of our customers. We also monitor trends throughout the commercial and residential fire and security

[0000833444-16-000197:mdna:43]
53

[0000833444-16-000197:mdna:44]
markets, including building codes and fire-safety standards. Our commercial installation businesses are impacted by trends in commercial construction starts, while our residential business, which is located outside of North America, is impacted by new housing starts.

[0000833444-16-000197:mdna:45]
Because we are a global business, with approximately 50% of our revenue generated outside of the United States, and because our financial statements are prepared in U.S. Dollars, the results of our operations are impacted by changes in foreign currency exchange rates. During fiscal 2016, the U.S. Dollar has remained strong against the currencies of most of the significant non-U.S. jurisdictions where we operate. The most significant impact on our results has been due to the strengthening of the U.S. Dollar as compared to the Euro and the Canadian Dollar, which has unfavorably impacted our revenue and operating income during fiscal 2015 and 2016.

[0000833444-16-000197:mdna:46]
In addition, the Company sells its products and services into the high-hazard, heavy industrial sector. Revenue from this market vertical is spread across each of the Company’s segments, with the most significant exposure in the United Kingdom in the ROW Integrated Solutions & Services segment and in the Fire Protection Products business in the Global Products segment. As a result of volatility in oil prices beginning in 2015, this market vertical has seen significant changes in spending patterns, in particular with respect to capital expenditures. The revenue tied to this market vertical was unfavorably impacted during fiscal 2015, and the weakness in this sector continued during fiscal 2016.

[0000833444-16-000197:mdna:47]
[same as prior period, unchanged from 0000833444-16-000172:mdna:44]

[0000833444-16-000197:mdna:48]
[same as prior period, unchanged from 0000833444-16-000172:mdna:45]

[0000833444-16-000197:mdna:49]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Net revenue | $ | 2,449 |  |  | $ | 2,489 |  |  | $ | 7,156 |  |  | $ | 7,397 |  |
| Net revenue decline | (1.6 | )% |  | N/A |  |  | (3.3 | )% |  | N/A |  |
| Organic revenue growth | 1.5 | % |  | N/A |  |  | 0.2 | % |  | N/A |  |
| Segment operating income | $ | 299 |  |  | $ | 367 |  |  | $ | 950 |  |  | $ | 996 |  |
| Segment operating margin | 12.2 | % |  | 14.7 | % |  | 13.3 | % |  | 13.5 | % |
| Corporate and Other | $ | (50 | ) |  | $ | (49 | ) |  | $ | (155 | ) |  | $ | (154 | ) |
| Restructuring and repositioning charges, net | (13 | ) |  | (65 | ) |  | (41 | ) |  | (169 | ) |
| Operating income | 236 |  |  | 253 |  |  | 754 |  |  | 673 |  |
| Operating margin | 9.6 | % |  | 10.2 | % |  | 10.5 | % |  | 9.1 | % |
| Interest income | $ | 3 |  |  | $ | 4 |  |  | $ | 11 |  |  | $ | 11 |  |
| Interest expense | (22 | ) |  | (26 | ) |  | (68 | ) |  | (75 | ) |
| Other income (expense), net | 54 |  |  | 6 |  |  | (111 | ) |  | 9 |  |
| Income tax expense | (31 | ) |  | (49 | ) |  | (130 | ) |  | (86 | ) |
| Income from continuing operations attributable to Tyco ordinary shareholders | 241 |  |  | 188 |  |  | 458 |  |  | 535 |  |

[0000833444-16-000197:mdna:50]
[same as prior period, unchanged from 0000833444-16-000172:mdna:47]

[0000833444-16-000197:mdna:51]
Net revenue for the quarter ended June 24, 2016 decreased by $40 million, or 1.6%, to $2,449 million as compared to net revenue of $2,489 million for the quarter ended June 26, 2015.  Changes in foreign currency exchange rates had an unfavorable impact of $63 million, or 2.5%, on net revenue, primarily in our ROW Integrated Solutions & Services segment, and to a lesser extent, in our Global Products segment.  In addition, divestitures had an unfavorable impact of $84 million, or 3.4%, primarily in the ROW Integrated Solutions & Services segment. On an organic basis, net revenue increased by $37 million, or 1.5%, year over year, primarily as a result of growth in our NA and ROW Integrated Solutions & Services segments, partially offset by a small decline in our Global Products segment. Net revenue was favorably impacted by acquisitions that contributed $70 million, or 2.8%, primarily within our ROW Integrated Solutions & Services segment, and to a lesser extent, in our NA Integrated Solutions & Services segment.

[0000833444-16-000197:mdna:52]
Net revenue for the nine months ended June 24, 2016 decreased by $241 million, or 3.3%, to $7,156 million as compared to net revenue of $7,397 million for the nine months ended June 26, 2015. Changes in foreign currency exchange rates had an unfavorable impact of $316 million, or 4.3%, on net revenue in all three segments, but primarily in our ROW Integrated Solutions & Services segment. In addition, divestitures had an unfavorable impact of $172 million, or 2.3% primarily in the ROW Integrated Solutions & Services segment. On an organic basis, net revenue increased by $16 million, or 0.2%, year over

[0000833444-16-000197:mdna:53]
54

[0000833444-16-000197:mdna:54]
year, primarily as a result of growth in our NA Integrated Solutions & Services segment, partially offset by declines in our Global Products and, to a lesser extent, ROW Integrated Solutions & Services segments. Net revenue was favorably impacted by acquisitions that contributed $231 million, or 3.1%, primarily within our ROW Integrated Solutions & Services and Global Products segments.

[0000833444-16-000197:mdna:55]
[same as prior period, unchanged from 0000833444-16-000172:mdna:50]

[0000833444-16-000197:mdna:56]
The significant components of cost of product sales include material costs, labor and overhead costs, product shipping and warehousing costs. The significant components of cost of services include labor and employee related costs, depreciation expense, costs associated with our equipment and fleet of vehicles, telecommunication costs and material costs. The significant components of SG&A include compensation and compensation related costs, facility and maintenance expenses and professional fees. SG&A for the quarter ended June 24, 2016 also includes divestiture charges, net of $38 million. SG&A for the nine months ended June 24, 2016 includes a net gain on an equity investment of $111 million, partially offset by divestiture charges, net, of $107 million.  See Notes 3 and 5 to the unaudited Consolidated Financial Statements.

[0000833444-16-000197:mdna:57]
[same as prior period, unchanged from 0000833444-16-000172:mdna:52]

[0000833444-16-000197:mdna:58]
The Company incurred merger costs of $19 million and $45 million for the quarter and nine months ended June 24, 2016, respectively, in connection with the proposed merger with Johnson Controls. These costs primarily relate to financing, advisory, and professional fees. See Note 2 to the unaudited Consolidated Financial Statements.

[0000833444-16-000197:mdna:59]
[same as prior period, unchanged from 0000833444-16-000172:mdna:55]

[0000833444-16-000197:mdna:60]
The Company continues to identify and pursue opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across the Company's businesses and corporate functions. Accordingly, the Company has initiated certain global actions designed to reduce its cost structure and improve future profitability by streamlining operations and better aligning functions, which the Company refers to as repositioning actions. These actions may or may not lead to a future restructuring action. During fiscal 2015, the Company recorded restructuring and repositioning charges of $289 million, of which $65 million and $169 million were recorded during the quarter and nine months ended June 26, 2015, respectively. The Company recorded restructuring and repositioning charges, net of $13 million and $41 million during the quarter and nine months ended June 24, 2016, respectively. See Note 4 to the unaudited Consolidated Financial Statements.

[0000833444-16-000197:mdna:61]
[same as prior period, unchanged from 0000833444-16-000172:mdna:57]

[0000833444-16-000197:mdna:62]
Operating income for the quarter ended June 24, 2016 decreased by $17 million, or 6.7%, to $236 million, as compared to operating income of $253 million for the quarter ended June 26, 2015. The decrease in operating income was primarily due to an increase in divestiture charges, net of $42 million primarily due to the write-down to fair value of a business in our ROW Integrated Solutions & Services segment that we plan to sell. The decrease is also due to merger costs of $19 million related to the proposed merger with Johnson Controls and the unfavorable impact of foreign currency exchange rates of $10 million, or 4.0%. These decreases are partially offset by a $52 million decrease in restructuring and repositioning charges, net.

[0000833444-16-000197:mdna:63]
Operating income for the nine months ended June 24, 2016 increased by $81 million, or 12.0%, to $754 million, as compared to operating income of $673 million for the nine months ended June 26, 2015. In connection with the additional investment in our UAE joint venture, we recorded a net gain of $111 million within Selling, general and administrative expenses relating to the Company's previously held equity method investment in the joint venture. See Note 5 to the unaudited Consolidated Financial Statements. Operating income also increased due to a $128 million reduction in restructuring and repositioning charges, net, and a $10 million increase in legacy legal gains. Operating income also benefited from previous productivity initiatives. These items were partially offset by an increase of $88 million of divestiture charges, net, primarily related to the loss on the sale of our Australian fire protection business and the write-down to fair value of another ROW Integrated Solutions & Services business that we plan to sell, as well as $45 million in merger costs related to the proposed merger with Johnson Controls. See Notes 2 and 3 to the unaudited Consolidated Financial Statements. Changes in foreign currency exchange rates also had an unfavorable impact on operating income of $35 million, or 5.2%.

[0000833444-16-000197:mdna:64]
Key items impacting operating income for the quarters and nine months ended June 24, 2016 and June 26, 2015, respectively, are as follows:

[0000833444-16-000197:mdna:65]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Gain on equity investment, net | $ | — |  |  | $ | — |  |  | $ | (111 | ) |  | $ | — |  |
| Legacy legal losses (gains) | 1 |  |  | (2 | ) |  | (18 | ) |  | (8 | ) |
| Divestiture charges (gains), net | 38 |  |  | (4 | ) |  | 107 |  |  | 19 |  |
| Restructuring and repositioning charges, net | 13 |  |  | 65 |  |  | 41 |  |  | 169 |  |
| Merger costs | 19 |  |  | — |  |  | 45 |  |  | — |  |
| Acquisition and integration costs | 5 |  |  | 2 |  |  | 9 |  |  | 4 |  |
| Unfavorable impact of foreign currency | 10 |  |  | N/A |  |  | 35 |  |  | N/A |  |

[0000833444-16-000197:mdna:66]
[same as prior period, unchanged from 0000833444-16-000172:mdna:62]

[0000833444-16-000197:mdna:67]
Interest income was $3 million and $4 million for the quarters ended June 24, 2016 and June 26, 2015, respectively.  Interest income was $11 million for both the nine months ended June 24, 2016 and June 26, 2015.

[0000833444-16-000197:mdna:68]
Interest expense was $22 million and $26 million for the quarters ended June 24, 2016 and June 26, 2015, respectively. Interest expense was $68 million and $75 million for the nine months ended June 24, 2016 and June 26, 2015, respectively.  The decrease in interest expense for both periods was due to the impact of the debt refinancing during the first quarter of fiscal 2016.  See Note 9 to the unaudited Consolidated Financial Statements.

[0000833444-16-000197:mdna:69]
Other Income (Expense), net

[0000833444-16-000197:mdna:70]
Significant components of other income (expense), net for the quarters and nine months ended June 24, 2016 and June 26, 2015 are as follows:

[0000833444-16-000197:mdna:71]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Loss on extinguishment of debt (see Note 9 to the unaudited Consolidated Financial Statements) | $ | — |  |  | $ | — |  |  | $ | (168 | ) |  | $ | — |  |
| 2012 Tax Sharing Agreement gain (loss) (see Note 6 to the unaudited Consolidated Financial Statements) | 32 |  |  | — |  |  | 32 |  |  | (2 | ) |
| 2007 Tax Sharing Agreement gain (see Note 6 to the unaudited Consolidated Financial Statements) | 22 |  |  | — |  |  | 22 |  |  | — |  |
| Equity investment income | — |  |  | 5 |  | — |  |  | 5 |
| Other | — |  |  | 1 |  | 3 |  |  | 6 |
|  | $ | 54 |  |  | $ | 6 |  |  | $ | (111 | ) |  | $ | 9 |  |

[0000833444-16-000197:mdna:72]
[same as prior period, unchanged from 0000833444-16-000172:mdna:68]

[0000833444-16-000197:mdna:73]
Our effective income tax rate was 11.4% and 20.7% during the quarters ended June 24, 2016 and June 26, 2015, respectively.  The decrease in our effective tax rate in the current period was primarily due to the favorable impact from the release of certain Tax Sharing Agreement liabilities and unrecognized tax benefits related to the favorable resolution of the intercompany debt issue. See Note 6 to the unaudited Consolidated Financial Statements. These favorable items were offset by the impact of an impairment for a held for sale business in our ROW Integrated Solutions & Services segment, and from merger costs, which are not expected to generate a tax benefit.

[0000833444-16-000197:mdna:74]
Our effective income tax rate was 22.2% and 13.9% during the nine months ended June 24, 2016 and June 26, 2015, respectively. The increase in our effective tax rate in the current period in addition to the items listed above was primarily due to tax charges in connection with the divestiture of the Australian Fire Protection business and a non-recurring loss on debt extinguishment for which the related deferred tax benefits will not be realized. The prior period was favorably impacted by a decrease in valuation allowances on the basis of management's reassessment of the amount of its deferred tax assets that are more likely than not to be realized resulting from the impact of restructuring actions and tax law changes in a non-U.S. jurisdiction.

[0000833444-16-000197:mdna:75]
[same as prior period, unchanged from 0000833444-16-000172:mdna:90]

[0000833444-16-000197:mdna:76]
[same as prior period, unchanged from 0000833444-16-000172:mdna:71]

[0000833444-16-000197:mdna:77]
[same as prior period, unchanged from 0000833444-16-000172:mdna:72]

[0000833444-16-000197:mdna:78]
The following chart reflects our net revenue by operating segment, as well as the percent of net revenue by operating segment, for the quarters and nine months ended June 24, 2016 and June 26, 2015, respectively.

[0000833444-16-000197:mdna:79]
[same as prior period, unchanged from 0000833444-16-000172:mdna:74]

[0000833444-16-000197:mdna:80]
[same as prior period, unchanged from 0000833444-16-000172:mdna:75]

[0000833444-16-000197:mdna:81]
Financial information for NA Integrated Solutions & Services for the quarters and nine months ended June 24, 2016 and June 26, 2015 is as follows:

[0000833444-16-000197:mdna:82]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Net revenue | $ | 1,004 |  |  | $ | 972 |  |  | $ | 2,904 |  |  | $ | 2,867 |  |
| Net revenue growth | 3.3 | % |  | N/A |  |  | 1.3 | % |  | N/A |  |
| Organic revenue growth | 2.5 | % |  | N/A |  |  | 1.5 | % |  | N/A |  |
| Segment operating income | $ | 148 |  |  | $ | 157 |  |  | $ | 411 |  |  | $ | 411 |  |
| Segment operating margin | 14.7 | % |  | 16.2 | % |  | 14.2 | % |  | 14.3 | % |

[0000833444-16-000197:mdna:83]
[same as prior period, unchanged from 0000833444-16-000172:mdna:101]

[0000833444-16-000197:mdna:84]
[same as prior period, unchanged from 0000833444-16-000172:mdna:79]

[0000833444-16-000197:mdna:85]
[same as prior period, unchanged from 0000833444-16-000172:mdna:80]

[0000833444-16-000197:mdna:86]
| Factors Contributing to Year-Over-Year Change |  | Third QuarterFiscal 2016 Compared toThird QuarterFiscal 2015 |  | Year to DateFiscal 2016 Compared toYear to DateFiscal 2015 |
| Organic revenue growth |  | $ | 24 |  |  | $ | 43 |  |
| Acquisitions |  | 13 |  |  | 25 |  |
| Impact of foreign currency |  | (5 | ) |  | (31 | ) |
| Total change |  | $ | 32 |  |  | $ | 37 |  |

[0000833444-16-000197:mdna:87]
Net revenue increased $32 million, or 3.3%, to $1,004 million for the quarter ended June 24, 2016 as compared to $972 million for the quarter ended June 26, 2015. On an organic basis, net revenue grew by $24 million, or 2.5%, from the comparable quarter, with growth driven by both integrated solutions and service revenue. Net revenue was also favorably impacted by $13 million, or 1.3%, due to acquisitions, primarily related to the ShopperTrak acquisition that closed in the second quarter of fiscal 2016. Changes in foreign currency exchange rates unfavorably impacted net revenue by $5 million, or 0.5%.

[0000833444-16-000197:mdna:88]
Net revenue increased $37 million, or 1.3%, to $2,904 million for the nine months ended June 24, 2016 as compared to $2,867 million for the nine months ended June 26, 2015. On an organic basis, net revenue grew by $43 million, or 1.5%, from the comparable period, with growth in both integrated solutions and service revenue, and in particular, in the retail, commercial and institutional vertical markets. Net revenue was also favorably impacted by $25 million, or 0.9%, primarily due to the ShopperTrak acquisition and several acquisitions made during fiscal 2015. Changes in foreign currency exchange rates unfavorably impacted net revenue by $31 million, or 1.1%.

[0000833444-16-000197:mdna:89]
[same as prior period, unchanged from 0000833444-16-000172:mdna:84]

[0000833444-16-000197:mdna:90]
Segment operating income for the quarter ended June 24, 2016 decreased $9 million, or 5.7%, to $148 million, as compared to segment operating income of $157 million for the quarter ended June 26, 2015. Operating income was unfavorably impacted by the higher mix of installation revenue and higher amortization expense related to recent acquisitions.

[0000833444-16-000197:mdna:91]
Segment operating income was $411 million for both the nine months ended June 24, 2016 and June 26, 2015. Operating income was favorably impacted by the benefit of previous productivity initiatives, offset by higher amortization expense related to recent acquisitions.

[0000833444-16-000197:mdna:92]
[same as prior period, unchanged from 0000833444-16-000172:mdna:87]

[0000833444-16-000197:mdna:93]
Financial information for ROW Integrated Solutions & Services for the quarters and nine months ended June 24, 2016 and June 26, 2015 is as follows:

[0000833444-16-000197:mdna:94]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Net revenue | $ | 794 |  |  | $ | 842 |  |  | $ | 2,374 |  |  | $ | 2,605 |  |
| Net revenue decline | (5.7 | )% |  | N/A |  |  | (8.9 | )% |  | N/A |  |
| Organic revenue growth (decline) | 1.9 | % |  | N/A |  |  | (0.1 | )% |  | N/A |  |
| Segment operating income | $ | 36 |  |  | $ | 97 |  |  | $ | 226 |  |  | $ | 253 |  |
| Segment operating margin | 4.5 | % |  | 11.5 | % |  | 9.5 | % |  | 9.7 | % |

[0000833444-16-000197:mdna:95]
[same as prior period, unchanged from 0000833444-16-000172:mdna:91]

[0000833444-16-000197:mdna:96]
[same as prior period, unchanged from 0000833444-16-000172:mdna:92]

[0000833444-16-000197:mdna:97]
| Factors Contributing to Year-Over-Year Change |  | Third QuarterFiscal 2016 Compared toThird QuarterFiscal 2015 |  | Year to DateFiscal 2016 Compared toYear to DateFiscal 2015 |
| Organic revenue growth (decline) |  | $ | 15 |  |  | $ | (3 | ) |
| Acquisitions |  | 57 |  |  | 150 |  |
| Divestitures |  | (72 | ) |  | (156 | ) |
| Impact of foreign currency |  | (48 | ) |  | (222 | ) |
| Total change |  | $ | (48 | ) |  | $ | (231 | ) |

[0000833444-16-000197:mdna:98]
Net revenue decreased $48 million, or 5.7%, to $794 million for the quarter ended June 24, 2016 as compared to $842 million for the quarter ended June 26, 2015. Changes in foreign currency exchange rates unfavorably impacted net revenue by $48 million, or 5.7%. On an organic basis, net revenue increased by $15 million, or 1.9%, driven by growth in growth markets and Continental Europe due to an increase in service and integrated solutions revenue, partially offset by declines within the United Kingdom driven by pressure within the high-hazard, heavy industrial sector. In addition, divestitures primarily in the Pacific region had an unfavorable impact of $72 million, or 8.6%. Net revenue was favorably impacted by $57 million, or 6.8%, due to acquisitions primarily within growth markets and retail solutions.

[0000833444-16-000197:mdna:99]
Net revenue decreased $231 million, or 8.9%, to $2,374 million for the nine months ended June 24, 2016 as compared to $2,605 million for the nine months ended June 26, 2015. Changes in foreign currency exchange rates unfavorably impacted net revenue by $222 million, or 8.5%. On an organic basis, net revenue declined by $3 million, or 0.1%, primarily in the Pacific region, Asia and the United Kingdom as a result of pressure within the high-hazard, heavy industrial sector partially offset by growth in our growth markets and  Continental Europe primarily due to growth in both service and integrated solutions revenue. In addition, divestitures in the Pacific region and Asia had an unfavorable impact of $156 million, or 6.0%. Net revenue was favorably impacted by $150 million, or 5.8%, due to acquisitions primarily within growth markets and retail solutions.

[0000833444-16-000197:mdna:100]
[same as prior period, unchanged from 0000833444-16-000172:mdna:96]

[0000833444-16-000197:mdna:101]
Segment operating income for the quarter ended June 24, 2016 decreased $61 million, or 62.9%, to $36 million as compared to segment operating income of $97 million for the quarter ended June 26, 2015. Segment operating income decreased primarily due to an increase in divestiture charges, net of $57 million, the unfavorable impact of changes in foreign currency exchange rates of $8 million, or 8.2%, and higher amortization expense primarily due to recent acquisitions. These decreases are partially offset by revenue growth, improved execution and the benefit of previous productivity initiatives.

[0000833444-16-000197:mdna:102]
Segment operating income for the nine months ended June 24, 2016 decreased $27 million, or 10.7%, to $226 million as compared to segment operating income of $253 million for the nine months ended June 26, 2015. Segment operating income decreased primarily due to an increase in divestiture charges, net, of $106 million, primarily related to the loss on sale of our Australian fire protection business and the write-down to fair value of another ROW Integrated Solutions & Services business that we plan to sell. See Note 3 to the unaudited Consolidated Financial Statements. In addition, changes in foreign currency exchange rates had an unfavorable impact on segment operating income of $26 million, or 10.3%. In connection with the additional investment in our UAE joint venture, we recorded a net gain of $111 million within Selling, general and administrative expenses relating to the Company's previously held equity method investment in the joint venture. See Note 5 to the unaudited Consolidated Financial Statements. To a lesser extent, segment operating income increased due to the benefit of previous productivity initiatives.

[0000833444-16-000197:mdna:103]
Key items impacting segment operating income for the quarters and nine months ended June 24, 2016 and June 26, 2015, respectively, are as follows:

[0000833444-16-000197:mdna:104]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Divestiture charges (gains), net | $ | 52 |  |  | $ | (5 | ) |  | $ | 124 |  |  | $ | 18 |  |
| Gain on equity investment, net | — |  |  | — |  |  | (111 | ) |  | — |  |
| Unfavorable impact of foreign currency | 8 |  |  | N/A |  |  | 26 |  |  | N/A |  |

[0000833444-16-000197:mdna:105]
[same as prior period, unchanged from 0000833444-16-000172:mdna:102]

[0000833444-16-000197:mdna:106]
Financial information for Global Products for the quarters and nine months ended June 24, 2016 and June 26, 2015 is as follows:

[0000833444-16-000197:mdna:107]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Net revenue | $ | 651 |  |  | $ | 675 |  |  | $ | 1,878 |  |  | $ | 1,925 |  |
| Net revenue decline | (3.6 | )% |  | N/A |  |  | (2.4 | )% |  | N/A |  |
| Organic revenue decline | (0.3 | )% |  | N/A |  |  | (1.3 | )% |  | N/A |  |
| Segment operating income | $ | 115 |  |  | $ | 113 |  |  | $ | 313 |  |  | $ | 332 |  |
| Segment operating margin | 17.7 | % |  | 16.7 | % |  | 16.7 | % |  | 17.2 | % |

[0000833444-16-000197:mdna:108]
[same as prior period, unchanged from 0000833444-16-000172:mdna:105]

[0000833444-16-000197:mdna:109]
[same as prior period, unchanged from 0000833444-16-000172:mdna:106]

[0000833444-16-000197:mdna:110]
| Factors Contributing to Year-Over-Year Change |  | Third QuarterFiscal 2016 Compared toThird QuarterFiscal 2015 |  | Year to DateFiscal 2016 Compared toYear to DateFiscal 2015 |
| Organic revenue decline |  | $ | (2 | ) |  | $ | (24 | ) |
| Acquisitions |  | — |  |  | 56 |  |
| Divestitures |  | (12 | ) |  | (16 | ) |
| Impact of foreign currency |  | (10 | ) |  | (63 | ) |
| Total change |  | $ | (24 | ) |  | $ | (47 | ) |

[0000833444-16-000197:mdna:111]
Net revenue decreased $24 million, or 3.6%, to $651 million for the quarter ended June 24, 2016 as compared to $675 million for the quarter ended June 26, 2015. On an organic basis, net revenue declined by $2 million, or 0.3%. Divestitures in our fire protection products business had an unfavorable impact of $12 million, or 1.8%. Net revenue was also unfavorably impacted by changes in foreign currency exchange rates of $10 million, or 1.5%.

[0000833444-16-000197:mdna:112]
Net revenue decreased $47 million, or 2.4%, to $1,878 million for the nine months ended June 24, 2016 as compared to $1,925 million for the nine months ended June 26, 2015. On an organic basis, net revenue declined by $24 million, or 1.3%, driven by the timing of increased shipments of Scott Air-Paks in our life safety business in the comparable period in the prior year, and to a lesser extent, our fire products business, partially offset by organic growth in our security products business. Divestitures, primarily in our fire protection products business, had an unfavorable impact of $16 million, or 0.8%. Net revenue was unfavorably impacted by changes in foreign currency exchange rates of $63 million, or 3.3%. Net revenue was favorably impacted during the nine months ended June 24, 2016 by $56 million, or 2.9%, from acquisitions, primarily related to the Industrial Safety Technologies acquisition within our life safety business in fiscal 2015.

[0000833444-16-000197:mdna:113]
[same as prior period, unchanged from 0000833444-16-000172:mdna:110]

[0000833444-16-000197:mdna:114]
Segment operating income for the quarter ended June 24, 2016 increased by $2 million, or 1.8% to $115 million, as compared to segment operating income of $113 million for the quarter ended June 26, 2015. Segment operating income was favorably impacted by the benefit of previous productivity initiatives, partially offset by unfavorable revenue mix.

[0000833444-16-000197:mdna:115]
Segment operating income for the nine months ended June 24, 2016 decreased by $19 million, or 5.7% to $313 million, as compared to segment operating income of $332 million for the nine months ended June 26, 2015. Segment operating income decreased due to revenue mix and the decline in revenue. In addition, changes in foreign currency exchange rates had an unfavorable impact on segment operating income of $6 million, or 1.8%. These decreases were partially offset by the benefit of previous productivity initiatives.

[0000833444-16-000197:mdna:116]
[same as prior period, unchanged from 0000833444-16-000172:mdna:113]

[0000833444-16-000197:mdna:117]
Corporate expense, excluding restructuring and repositioning charges, net, was $50 million and $49 million for the quarters ended June 24, 2016 and June 26, 2015, respectively.  Corporate expense for the current quarter includes merger costs of $19 million related to the proposed merger with Johnson Controls, partially offset by a $13 million divestiture gain, and the benefit of productivity initiatives and cost containment actions.

[0000833444-16-000197:mdna:118]
Corporate expense, excluding restructuring and repositioning charges, net, was $155 million and $154 million for the nine months ended June 24, 2016 and June 26, 2015, respectively. Corporate expense for the nine months of fiscal 2016 includes merger costs of $45 million related to the proposed merger with Johnson Controls, partially offset by a $16 million divestiture gain, a $9 million increase in legacy legal gains and the benefit of productivity initiatives and cost containment actions.

[0000833444-16-000197:mdna:119]
Key items included in corporate expense for the quarters and nine months ended June 24, 2016 and June 26, 2015, respectively, are as follows:

[0000833444-16-000197:mdna:120]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Merger costs | $ | 19 |  |  | $ | — |  |  | $ | 45 |  |  | $ | — |  |
| Divestiture gains, net | (13 | ) |  | — |  |  | (16 | ) |  | — |  |
| Legacy legal losses (gains) | 1 |  |  | (2 | ) |  | (18 | ) |  | (9 | ) |

[0000833444-16-000197:mdna:121]
[same as prior period, unchanged from 0000833444-16-000172:mdna:118]

[0000833444-16-000197:mdna:122]
The preparation of the unaudited Consolidated Financial Statements in conformity with U.S. GAAP requires management to use judgment in making estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of contingent assets and liabilities and the reported amounts of revenue and expenses. We believe that our accounting policies for depreciation and amortization methods of security monitoring-related assets, revenue recognition, loss contingencies, income taxes, goodwill and indefinite-lived intangible assets, long-lived assets and pension and postretirement benefits are based on, among other things, judgments and assumptions made by management that include inherent risks and uncertainties.

[0000833444-16-000197:mdna:123]
[same as prior period, unchanged from 0000833444-16-000172:mdna:120]

[0000833444-16-000197:mdna:124]
[same as prior period, unchanged from 0000833444-16-000172:mdna:121]

[0000833444-16-000197:mdna:125]
[same as prior period, unchanged from 0000833444-16-000172:mdna:122]

[0000833444-16-000197:mdna:126]
[same as prior period, unchanged from 0000833444-16-000172:mdna:123]

[0000833444-16-000197:mdna:127]
The primary source of funds to finance our operations and capital expenditures is cash generated by operations. In addition, we maintain a $1.5 billion commercial paper program, backed up by a committed revolving credit facility, and have access to equity and debt capital from public and private sources. We continue to balance our operating, investing, and financing uses of cash through investments and acquisitions in our core businesses, dividends, and share repurchases.  In addition, we believe our available cash, amounts available under our credit facility, commercial paper program and cash provided by operating activities will be adequate to cover our operational, capital and other business needs in the foreseeable future. To the extent it is necessary for us to finance our cash needs through the issuance of commercial paper, by accessing our committed revolving credit facility, or through other public or private sources, our cost of funding may increase depending on market conditions at the time of such borrowing.

[0000833444-16-000197:mdna:128]
Additionally, the Company has entered into a senior unsecured term loan facility in the amount of $4 billion to finance the cash consideration for, and fees, expenses and costs incurred in connection with, the merger. In addition, the Company has entered into a revolving credit agreement in the amount of $1 billion, which is intended to replace the Company's existing $1.5 billion revolving credit agreement. Tyco's ability to draw down on both the term loan facility and the new revolving credit agreement is contingent on the consummation of the merger with Johnson Controls. See Note 9 to the unaudited Consolidated Financial Statements.

[0000833444-16-000197:mdna:129]
As of June 24, 2016 and September 25, 2015, our cash and cash equivalents, short- and long-term debt at carrying value, and Tyco shareholder's equity are as follows:

[0000833444-16-000197:mdna:130]
|  | As of |  | Credit Availability as of |
| ($ in millions) | June 24, 2016 |  | September 25, 2015 |  | June 24, 2016 (2) |
| Cash and cash equivalents | $ | 345 |  |  | $ | 1,401 |  |  | $ | — |  |
| Total debt (excluding revolving credit facility) | 2,506 |  |  | 3,146 |  |  | — |  |
| Revolving credit facility | — |  |  | — |  |  | 1,500 |  |
| Total Tyco shareholders' equity | 4,351 |  |  | 4,041 |  |  | — |  |
| Total debt as a % of total capital (1) | 36.5 | % |  | 43.8 | % |  | N/A |  |

[0000833444-16-000197:mdna:131]
(1) Total capital represents the aggregate amount of total debt and total shareholders' equity which was $6,857 million and $7,187 million as of June 24, 2016 and September 25, 2015, respectively.

[0000833444-16-000197:mdna:132]
[same as prior period, unchanged from 0000833444-16-000172:mdna:130]

[0000833444-16-000197:mdna:133]
Significant uses of capital that are expected in the near- to mid-term include expenditures for (i) capital expenditures and dealer investments in annual amounts expected to approximate 3% to 3.5% of total revenues, (ii) the funding of potential tax liabilities or settlements (see Note 6 to the unaudited Consolidated Financial Statements), including with respect to the divestiture of our ADT Korea business, (iii) estimated restructuring payments, of which $96 million has been accrued as a current liability as of June 24, 2016 (see Note 4 to the unaudited Consolidated Financial Statements), (iv) quarterly dividend payments, of which $87 million has been accrued as of June 24, 2016 (see Note 13 to the unaudited Consolidated Financial Statements), and (v) merger related items. The Company intends to fund these capital uses through a combination of available cash, cash generated from operations, borrowing in the commercial paper market or under its revolving credit facility, and borrowing in public or private markets for debt securities. In addition, the Company intends, in its discretion, to pursue strategically important acquisitions, may repurchase its shares from time to time and may engage in other capital market activities, in each case depending on a number of factors, including the Company’s strategic priorities, its financial condition and results of operations, the capital requirements of the Company’s businesses, industry and capital markets factors and other relevant factors.

[0000833444-16-000197:mdna:134]
[same as prior period, unchanged from 0000833444-16-000172:mdna:132]

[0000833444-16-000197:mdna:135]
Our cash flows from operating, investing and financing from continuing operations for the nine months ended June 24, 2016 and June 26, 2015 are summarized below:

[0000833444-16-000197:mdna:136]
|  | For the Nine Months Ended |
| ($ in millions) | June 24, 2016 |  | June 26, 2015 |
| Net cash provided by operating activities | $ | 504 |  |  | $ | 511 |  |
| Net cash used in investing activities | (511 | ) |  | (752 | ) |
| Net cash used in financing activities | (1,041 | ) |  | (102 | ) |

[0000833444-16-000197:mdna:137]
[same as prior period, unchanged from 0000833444-16-000172:mdna:135]

[0000833444-16-000197:mdna:138]
Cash flow from operating activities can fluctuate significantly from period to period as working capital needs and the timing of payments for items such as restructuring activities, pension funding, income taxes, merger costs and other items impact reported cash flow.

[0000833444-16-000197:mdna:139]
The net change in working capital decreased operating cash flow by $479 million in the nine months ended June 24, 2016. The significant changes in working capital included a $149 million decrease in accrued and other liabilities, a $138 million decrease in tax sharing agreement, net, a $69 million increase in contracts in process, a $65 million increase in accounts receivable, and a $55 million increase in inventories.

[0000833444-16-000197:mdna:140]
The net change in working capital decreased operating cash flow by $372 million in the nine months ended June 26, 2015. The significant changes in working capital included a $104 million increase in accounts receivable, a $78 million decrease in accounts payable, a $72 million increase in inventories, a $55 million increase in prepaid expense and other current assets, and a $34 million decrease in accrued and other liabilities.

[0000833444-16-000197:mdna:141]
During the nine months ended June 24, 2016 and June 26, 2015, we paid approximately $67 million and $78 million, respectively, in cash related to restructuring activities. During the nine months ended June 24, 2016 and June 26, 2015, we paid approximately $43 million and $41 million, respectively, in cash related to repositioning activities.

[0000833444-16-000197:mdna:142]
During the nine months ended June 24, 2016 and June 26, 2015, we paid merger related expenses of $20 million and nil, respectively, related to the proposed merger with Johnson Controls.

[0000833444-16-000197:mdna:143]
During the nine months ended June 24, 2016 and June 26, 2015, we made payments of $39 million and nil, respectively, to satisfy a pension obligation.

[0000833444-16-000197:mdna:144]
During the nine months ended June 24, 2016 and June 26, 2015, we made required contributions of $2 million and $9 million, respectively, to our U.S. pension plans and $16 million and $13 million, respectively, to our non-U.S. pension plans. During the nine months ended June 24, 2016, we made voluntary contributions to our non-U.S. pension plan of $4 million. We anticipate that we will contribute $3 million to our U.S. plans and $25 million to our non-U.S. plans during fiscal 2016.

[0000833444-16-000197:mdna:145]
Income taxes paid, net of refunds, related to continuing operations were $51 million and $84 million during the nine months ended June 24, 2016 and June 26, 2015, respectively.

[0000833444-16-000197:mdna:146]
Net interest paid related to continuing operations was $49 million and $52 million for the nine months ended June 24, 2016 and June 26, 2015, respectively.

[0000833444-16-000197:mdna:147]
[same as prior period, unchanged from 0000833444-16-000172:mdna:146]

[0000833444-16-000197:mdna:148]
[same as prior period, unchanged from 0000833444-16-000172:mdna:147]

[0000833444-16-000197:mdna:149]
We made capital expenditures of $209 million and $183 million for the nine months ended June 24, 2016 and June 26, 2015, respectively.

[0000833444-16-000197:mdna:150]
During the nine months ended June 24, 2016, total consideration for acquisitions was $320 million, which was comprised of $364 million of cash paid, including $5 million to settle pre-existing matters and $6 million for pre-paid agency commissions, net of cash acquired of $33 million, which primarily related to our additional investment in the UAE joint venture in our ROW Integrated Solutions & Services segment and the acquisition of ShopperTrak in our NA Integrated Solutions & Services and ROW Integrated Solutions & Services segments. During the nine months ended June 26, 2015, we paid cash for acquisitions totaling $525 million, net of $26 million cash acquired, primarily related to acquisitions in in our ROW Integrated Solutions & Services and Global Products segments.

[0000833444-16-000197:mdna:151]
During the nine months ended June 24, 2016, we had net sales and maturities of investments, including restricted investments, of $18 million. During the nine months ended June 26, 2015, we had net purchases of investments, including restricted investments, of $7 million.  Maturities of investments of $283 million included time deposits of $275 million, and we made purchases of $290 million of investments, primarily consisting of exchange traded equity and fixed income funds, which were classified as available-for-sale investments and were restricted as to use.

[0000833444-16-000197:mdna:152]
During the nine months ended June 24, 2016, our restricted cash decreased by $3 million. During the nine months ended June 26, 2015, our restricted cash increased by $27 million. This increase was primarily driven by $16 million of cash received from former management, which was required to be shared pursuant to the terms of a legacy class action lawsuit, an increase of $7 million pertaining to the asbestos-related qualified settlement fund, and $4 million of restricted cash related to an acquisition.

[0000833444-16-000197:mdna:153]
[same as prior period, unchanged from 0000833444-16-000172:mdna:152]

[0000833444-16-000197:mdna:154]
[same as prior period, unchanged from 0000833444-16-000172:mdna:153]

[0000833444-16-000197:mdna:155]
During the nine months ended June 24, 2016, we repaid a total of approximately $1,134 million of current portion of long-term debt.  On October 14, 2015, the Company redeemed its outstanding $242 million aggregate principal amount 7.0% notes due 2019 and $462 million aggregate principal amount 6.875% notes due 2021, which were classified as current as of September 25, 2015, for total cash of $876 million, which included a make-whole premium of $172 million. Also, on October 15, 2015, the Company repaid $258 million aggregate principal amount of 3.375% notes due 2015, which matured on such date.

[0000833444-16-000197:mdna:156]
During the nine months ended June 24, 2016 and June 26, 2015, we paid debt financing costs of $23 million and $5 million, respectively.

[0000833444-16-000197:mdna:157]
As of June 24, 2016 and September 25, 2015, TIFSA had commercial paper outstanding of $341 million and nil, respectively. The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1.5 billion as of June 24, 2016. As of June 24, 2016 and September 25, 2015, there were no amounts drawn under the Company's revolving credit facility. See Note 9 to the unaudited Consolidated Financial Statements.

[0000833444-16-000197:mdna:158]
During the nine months ended June 26, 2015, TIFSA issued €500 million aggregate principal amount of public notes due 2025, which resulted in proceeds of $567 million.

[0000833444-16-000197:mdna:159]
Pursuant to our share repurchase program, we may repurchase Tyco shares from time to time in open market purchases at prevailing market prices, in negotiated transactions off the market, or pursuant to an approved trading plan in accordance with applicable regulations. During the nine months ended June 24, 2016, we did not repurchase shares. During the nine months ended June 26, 2015, we repurchased approximately 10 million ordinary shares for approximately $417 million.

[0000833444-16-000197:mdna:160]
During the nine months ended June 24, 2016 and June 26, 2015, we paid cash dividends of approximately $261 million and $237 million, respectively.

[0000833444-16-000197:mdna:161]
During the nine months ended June 26, 2015, we paid contingent consideration of $23 million related to the transfer of a business license in China to Tyco. Contingent consideration paid during the nine months ended June 24, 2016 was not material.

[0000833444-16-000197:mdna:162]
[same as prior period, unchanged from 0000833444-16-000172:mdna:161]

[0000833444-16-000197:mdna:163]
Commitments and Contingencies

[0000833444-16-000197:mdna:164]
For a detailed discussion of contingencies related to tax and litigation matters, see Notes 6 and 11 to the unaudited Consolidated Financial Statements.

[0000833444-16-000197:mdna:165]
[same as prior period, unchanged from 0000833444-16-000172:mdna:164]

[0000833444-16-000197:mdna:166]
We had a backlog of unfilled orders of $4,786 million and $4,562 million as of June 24, 2016 and September 25, 2015, respectively.

[0000833444-16-000197:mdna:167]
[same as prior period, unchanged from 0000833444-16-000172:mdna:166]

[0000833444-16-000197:mdna:168]
|  | NA Integrated Solutions & Services |  | ROW Integrated Solutions & Services |  | GlobalProducts |  | Total |
| As of September 25, 2015 |  |  |  |  |  |  |  |
| Backlog | $ | 1,035 |  |  | $ | 820 |  |  | $ | 195 |  |  | $ | 2,050 |  |
| Recurring revenue in force | 1,229 |  |  | 1,013 |  |  | — |  |  | 2,242 |  |
| Deferred revenue | 235 |  |  | 35 |  |  | — |  |  | 270 |  |
| Total Backlog | $ | 2,499 |  |  | $ | 1,868 |  |  | $ | 195 |  |  | $ | 4,562 |  |
| As of June 24, 2016 |  |  |  |  |  |  |  |  |  |  |  |
| Backlog | $ | 1,181 |  |  | $ | 961 |  |  | $ | 170 |  |  | $ | 2,312 |  |
| Recurring revenue in force | 1,268 |  |  | 952 |  |  | — |  |  | 2,220 |  |
| Deferred revenue | 222 |  |  | 32 |  |  | — |  |  | 254 |  |
| Total Backlog | $ | 2,671 |  |  | $ | 1,945 |  |  | $ | 170 |  |  | $ | 4,786 |  |

[0000833444-16-000197:mdna:169]
Total backlog increased $224 million, or 4.9%, to $4,786 million as of June 24, 2016 compared to $4,562 million as of September 25, 2015. Acquisitions during fiscal 2016 contributed approximately $194 million, or 4.1%, to total backlog, primarily related to our UAE and ShopperTrak businesses. In addition, backlog also increased in our NA and ROW Integrated Solutions & Services segments. These increases were partially offset by divestitures, primarily related to our Australia fire protection business in our ROW Integrated Solutions & Services segment during fiscal 2016, which had an unfavorable impact of $101 million, or 2.1% to total backlog. In addition, changes in foreign currency had an unfavorable impact to total backlog of $61 million, or 1.3%, primarily in our ROW Integrated Solutions & Services segment.

[0000833444-16-000197:mdna:170]
[same as prior period, unchanged from 0000833444-16-000172:mdna:169]

[0000833444-16-000197:mdna:171]
[same as prior period, unchanged from 0000833444-16-000172:mdna:170]

[0000833444-16-000197:mdna:172]
[same as prior period, unchanged from 0000833444-16-000172:mdna:171]

[0000833444-16-000197:mdna:173]
In disposing of assets or businesses, we often provide representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities, and unidentified tax and other liabilities related to periods prior to disposition. We have no reason to believe that these uncertainties would have a material adverse effect on our financial position, results of operations or cash flows. We have recorded liabilities for known indemnifications included as part of environmental liabilities. See Note 11 to the unaudited Consolidated Financial Statements.

[0000833444-16-000197:mdna:174]
[same as prior period, unchanged from 0000833444-16-000172:mdna:174]

[0000833444-16-000197:mdna:175]
[same as prior period, unchanged from 0000833444-16-000172:mdna:175]

[0000833444-16-000197:mdna:176]
[same as prior period, unchanged from 0000833444-16-000172:mdna:176]

[0000833444-16-000197:mdna:177]
[same as prior period, unchanged from 0000833444-16-000172:mdna:177]

[0000833444-16-000197:mdna:178]
[same as prior period, unchanged from 0000833444-16-000172:mdna:206]

[0000833444-16-000197:mdna:179]
[same as prior period, unchanged from 0000833444-16-000172:mdna:178]

[0000833444-16-000197:mdna:180]
Quarter Ended June 24, 2016

[0000833444-16-000197:mdna:181]
|  | Net Revenue for the Quarter Ended June 26, 2015 |  | Base YearAdjustmentsDivestitures / Other |  | AdjustedFiscal 2015Base Revenue |  | ForeignCurrency |  | Acquisitions |  | OrganicRevenue |  | OrganicGrowth (Decline)Percentage(1) |  | Net Revenue for the Quarter Ended June 24, 2016 |
|  | ($ in millions) |
| NA Integrated Solutions & Services | $ | 972 |  |  | $ | — |  |  | $ | 972 |  |  | $ | (5 | ) |  | $ | 13 |  |  | $ | 24 |  |  | 2.5 | % |  | $ | 1,004 |  |
| ROW Integrated Solutions & Services | 842 |  |  | (72 | ) |  | 770 |  |  | (48 | ) |  | 57 |  |  | 15 |  |  | 1.9 | % |  | 794 |  |
| Global Products | 675 |  |  | (12 | ) |  | 663 |  |  | (10 | ) |  | — |  |  | (2 | ) |  | (0.3 | )% |  | 651 |  |
| Total Net Revenue | $ | 2,489 |  |  | $ | (84 | ) |  | $ | 2,405 |  |  | $ | (63 | ) |  | $ | 70 |  |  | $ | 37 |  |  | 1.5 | % |  | $ | 2,449 |  |

[0000833444-16-000197:mdna:182]
[same as prior period, unchanged from 0000833444-16-000172:mdna:181]

[0000833444-16-000197:mdna:183]
Nine Months Ended June 24, 2016

[0000833444-16-000197:mdna:184]
|  | Net Revenue for the Nine Months Ended June 26, 2015 |  | Base YearAdjustmentsDivestitures / Other |  | AdjustedFiscal 2015Base Revenue |  | ForeignCurrency |  | Acquisitions |  | OrganicRevenue |  | OrganicGrowth (Decline)Percentage(1) |  | Net Revenue for the Nine Months Ended June 24, 2016 |
|  | ($ in millions) |
| NA Integrated Solutions & Services | $ | 2,867 |  |  | $ | — |  |  | $ | 2,867 |  |  | $ | (31 | ) |  | $ | 25 |  |  | $ | 43 |  |  | 1.5 | % |  | $ | 2,904 |  |
| ROW Integrated Solutions & Services | 2,605 |  |  | (156 | ) |  | 2,449 |  |  | (222 | ) |  | 150 |  |  | (3 | ) |  | (0.1 | )% |  | 2,374 |  |
| Global Products | 1,925 |  |  | (16 | ) |  | 1,909 |  |  | (63 | ) |  | 56 |  |  | (24 | ) |  | (1.3 | )% |  | 1,878 |  |
| Total Net Revenue | $ | 7,397 |  |  | $ | (172 | ) |  | $ | 7,225 |  |  | $ | (316 | ) |  | $ | 231 |  |  | $ | 16 |  |  | 0.2 | % |  | $ | 7,156 |  |

[0000833444-16-000197:mdna:185]
[same as prior period, unchanged from 0000833444-16-000172:mdna:185]

[0000833444-16-000197:mdna:186]
[same as prior period, unchanged from 0000833444-16-000172:mdna:186]

[0000833444-16-000197:mdna:187]
[same as prior period, unchanged from 0000833444-16-000172:mdna:187]

[0000833444-16-000197:mdna:188]
[same as prior period, unchanged from 0000833444-16-000172:mdna:188]

[0000833444-16-000197:mdna:189]
[same as prior period, unchanged from 0000833444-16-000172:mdna:189]

[0000833444-16-000197:mdna:190]
| • | our, and our employees' and agents' ability to comply with complex and continually changing laws and regulations that govern our international operations, including the U.S. Foreign Corrupt Practices Act, similar anti-bribery laws in |

[0000833444-16-000197:mdna:191]
66

[0000833444-16-000197:mdna:192]
other jurisdictions, a variety of export control, customs, privacy, currency exchange control and transfer pricing regulations, and our corporate policies governing these matters;

[0000833444-16-000197:mdna:193]
| • | the outcome of litigation, arbitrations and governmental proceedings; |

[0000833444-16-000197:mdna:194]
| • | effect of income tax audits, litigation, settlements and appeals; |

[0000833444-16-000197:mdna:195]
[same as prior period, unchanged from 0000833444-16-000172:mdna:193]

[0000833444-16-000197:mdna:196]
[same as prior period, unchanged from 0000833444-16-000172:mdna:194]

[0000833444-16-000197:mdna:197]
[same as prior period, unchanged from 0000833444-16-000172:mdna:195]

[0000833444-16-000197:mdna:198]
[same as prior period, unchanged from 0000833444-16-000172:mdna:196]

[0000833444-16-000197:mdna:199]
[same as prior period, unchanged from 0000833444-16-000172:mdna:197]

[0000833444-16-000197:mdna:200]
[same as prior period, unchanged from 0000833444-16-000172:mdna:198]

[0000833444-16-000197:mdna:201]
[same as prior period, unchanged from 0000833444-16-000172:mdna:199]

[0000833444-16-000197:mdna:202]
[same as prior period, unchanged from 0000833444-16-000172:mdna:200]

[0000833444-16-000197:mdna:203]
[same as prior period, unchanged from 0000833444-16-000172:mdna:201]

[0000833444-16-000197:mdna:204]
[same as prior period, unchanged from 0000833444-16-000172:mdna:202]

[0000833444-16-000197:mdna:205]
[same as prior period, unchanged from 0000833444-16-000172:mdna:203]

[0000833444-16-000197:mdna:206]
[same as prior period, unchanged from 0000833444-16-000172:mdna:204]

[0000833444-16-000197:mdna:207]
[same as prior period, unchanged from 0000833444-16-000172:mdna:205]

[0000833444-16-000197:mdna:208]
[same as prior period, unchanged from 0000833444-16-000172:mdna:207]

[0000833444-16-000197:mdna:209]
[same as prior period, unchanged from 0000833444-16-000172:mdna:208]

[0000833444-16-000197:mdna:210]
[same as prior period, unchanged from 0000833444-16-000172:mdna:209]

[0000833444-16-000197:mdna:211]
[same as prior period, unchanged from 0000833444-16-000172:mdna:210]

[0000833444-16-000197:mdna:212]
[same as prior period, unchanged from 0000833444-16-000172:mdna:211]

[0000833444-16-000197:mdna:213]
| • | assuming the proposed merger with Johnson Controls is completed, the ability of us and Johnson Controls to integrate our businesses successfully and to achieve anticipated synergies, changes in tax laws or interpretations, access to available financing, potential litigation relating to the proposed transaction, and the risk that disruptions from the proposed transaction will harm our business. |
