# JCI notes — 0000833444-16-000197


## tyc:ScheduleOfNetReceivablesAndLiabilitiesRecordedUnderTaxSharingAgreementsTableTextBlock

[0000833444-16-000197:notes:1]
The receivables and liabilities related to the 2012 and 2007 Tax Sharing Agreements as of June 24, 2016 and September 25, 2015, are as follows ($ in millions):

[0000833444-16-000197:notes:2]
|  | 2012 Tax Sharing Agreement |  | 2007 Tax Sharing Agreement |
|  | As of |  | As of |
|  | June 24, 2016 |  | September 25, 2015 |  | June 24, 2016 |  | September 25, 2015 |
| Tax sharing agreement related receivables: |  |  |  |  |  |  |  |
| Other assets | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 19 |  |
|  | — |  |  | — |  |  | — |  |  | 19 |  |
| Tax sharing agreement related liabilities: |  |  |  |  |  |  |  |
| Accrued and other current liabilities | — |  |  | — |  |  | (30 | ) |  | (15 | ) |
| Other liabilities | (16 | ) |  | (46 | ) |  | — |  |  | (194 | ) |
|  | (16 | ) |  | (46 | ) |  | (30 | ) |  | (209 | ) |
| Net liability | $ | (16 | ) |  | $ | (46 | ) |  | $ | (30 | ) |  | $ | (190 | ) |


## tyc:ScheduleOfSegmentReportingInformationNetRevenueAndOperatingIncomeLossBySegmentTableTextBlock

[0000833444-16-000197:notes:3]
[same as prior period, unchanged from 0000833444-16-000172:notes:30]

[0000833444-16-000197:notes:4]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Net revenue(1): |  |  |  |  |  |  |  |
| NA Integrated Solutions & Services | $ | 1,004 |  |  | $ | 972 |  |  | $ | 2,904 |  |  | $ | 2,867 |  |
| ROW Integrated Solutions & Services | 794 |  |  | 842 |  |  | 2,374 |  |  | 2,605 |  |
| Global Products | 651 |  |  | 675 |  |  | 1,878 |  |  | 1,925 |  |
|  | $ | 2,449 |  |  | $ | 2,489 |  |  | $ | 7,156 |  |  | $ | 7,397 |  |

[0000833444-16-000197:notes:5]
[same as prior period, unchanged from 0000833444-16-000172:notes:32]

[0000833444-16-000197:notes:6]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Operating income: |  |  |  |  |  |  |  |
| NA Integrated Solutions & Services | $ | 148 |  |  | $ | 157 |  |  | $ | 411 |  |  | $ | 411 |  |
| ROW Integrated Solutions & Services | 36 |  |  | 97 |  |  | 226 |  |  | 253 |  |
| Global Products | 115 |  |  | 113 |  |  | 313 |  |  | 332 |  |
| Segment operating income | 299 |  |  | 367 |  |  | 950 |  |  | 996 |  |
| Corporate and Other | (50 | ) |  | (49 | ) |  | (155 | ) |  | (154 | ) |
| Restructuring and repositioning charges, net | (13 | ) |  | (65 | ) |  | (41 | ) |  | (169 | ) |
| Operating income | $ | 236 |  |  | $ | 253 |  |  | $ | 754 |  |  | $ | 673 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000833444-16-000197:notes:7]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year.  These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 25, 2015 (the "2015 Form 10-K") and Current Report filed on Form 8-K filed on March 11, 2016 which recast the Company's consolidated financial statements for each of the three years in the period ended September 25, 2015 to reflect changes in the presentation of operating income by segment. The information included in this Form 8-K was presented for informational purposes only and does not amend or restate the Company’s audited consolidated financial statements, which were included in its 2015 Form 10-K, and did not affect the Company’s previously reported net income, earnings per share, cash flows, operating income or assets or liabilities for any of the periods presented therein.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000833444-16-000197:notes:8]
Basis of Presentation and Summary of Significant Accounting Policies

[0000833444-16-000197:notes:9]
References to 2016 and 2015 are to Tyco's fiscal quarters ending June 24, 2016 and June 26, 2015, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September.  Fiscal 2016 is a 53-week year as compared with fiscal 2015, which was 52 weeks, with the additional week occurring in the fourth quarter of fiscal 2016.  The Company's results for the quarters and nine months ended June 24, 2016 and June 26, 2015 both consisted of 13 weeks and 39 weeks, respectively.

[0000833444-16-000197:notes:10]
The Company operates and reports financial and operating information in the following three segments: North America Integrated Solutions & Services ("NA Integrated Solutions & Services"), Rest of World Integrated Solutions & Services ("ROW Integrated Solutions & Services") and Global Products. The Company also provides general corporate services to its segments which is reported as a fourth, non-operating segment, Corporate and Other.

[0000833444-16-000197:notes:11]
Proposed Merger with Johnson Controls, Inc.— On January 24, 2016, Tyco entered into an Agreement and Plan of Merger (as amended, the “Merger Agreement”) with Johnson Controls, Inc., a Wisconsin corporation (“Johnson Controls”), and certain other parties named therein (which was subsequently amended by Amendment No. 1 on July 1, 2016), including Jagara Merger Sub LLC, a Wisconsin limited liability company and indirect wholly owned subsidiary of Tyco (“Merger Sub”). Pursuant to the Merger Agreement and subject to the terms and conditions set forth therein, Merger Sub will merge with and into Johnson Controls (the “Merger”), with Johnson Controls surviving the Merger as an indirect wholly owned subsidiary of Tyco. At the effective time of the Merger, Tyco will change its name to “Johnson Controls International plc” and will trade under the ticker symbol “JCI.” Following such time, Tyco is referred to below as the “Combined Company.”

[0000833444-16-000197:notes:12]
As a result of the Merger, each outstanding share of Johnson Controls common stock (the “Johnson Controls Shares”), other than shares held by Johnson Controls, its subsidiaries, Tyco or Merger Sub, will be converted into the right to receive (subject to proration as described below), at the holder’s election, either: (i) one (1) (the “Exchange Ratio”) ordinary share of the Combined Company (the “Share Consideration”); or (ii) an amount in cash equal to $34.88 (the “Cash Consideration”). Elections will be prorated so that Johnson Controls shareholders will receive in the aggregate approximately $3.864 billion of cash in the Merger (the “Aggregate Cash Consideration”). Holders that do not make an election will be treated as having elected to receive the Share Consideration. The Exchange Ratio takes into account the effects of a Tyco share consolidation contemplated by the Merger Agreement whereby, immediately prior to the Merger, every issued and unissued ordinary share of Tyco (each, a “Tyco Share”) will be consolidated into 0.955 of a share of Tyco.

[0000833444-16-000197:notes:13]
The completion of the Merger is subject to certain closing conditions, including, among others, (i) the approval and adoption of the Merger Agreement by holders of two-thirds of the Johnson Controls Shares entitled to vote on such matter, (ii) the approval by the Tyco shareholders, at a special meeting of the Tyco shareholders (the “Tyco Special Meeting”) of (A) the issuance of Tyco shares in connection with the Merger, (B) the Tyco share consolidation and (C) the increase in Tyco’s authorized share capital, in each case, by a majority of the votes cast on these matters at the Tyco Special Meeting, and of certain amendments to Tyco’s articles of association, including a change of its name to “Johnson Controls International plc,” by at least 75% of the votes cast on these matters at the Tyco Special Meeting (clause (ii), collectively, the “Tyco Shareholder Approvals”), (iii) the expiration or termination of any waiting period applicable to the Merger under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, the consent of, or filing with, certain specified antitrust authorities, and certain other customary regulatory approvals, and (iv) Tyco’s obtaining the financing required to close the Merger on the terms set forth in the Merger Agreement.

[0000833444-16-000197:notes:14]
The Merger Agreement contains specified termination rights, including, among others, the right of either party to terminate the Merger Agreement (i) if the requisite shareholder approvals have not been obtained, (ii) if the board of directors of the other party effects a change of recommendation, (iii) if the closing has not occurred by October 24, 2016, subject to extension to January 24, 2017 in certain circumstances, (iv) in response to certain intervening events (subject to the limitations set forth in the Merger Agreement) or (v) if there is a material breach by the other party of any of its representations, warranties or covenants, subject to certain conditions.

[0000833444-16-000197:notes:15]
Tyco has entered into a senior unsecured term loan facility in the amount of $4 billion to finance the cash consideration for, and fees, expenses and costs incurred in connection with, the merger. In addition, the Company has entered into a revolving credit agreement in the amount of $1 billion, which is intended to replace Tyco's existing $1.5 billion revolving credit agreement. Tyco's ability to draw down on both the term loan facility and the new revolving credit agreement is contingent on the consummation of the merger with Johnson Controls. See Note 9.

[0000833444-16-000197:notes:16]
Change of Jurisdiction— On May 30, 2014, Tyco entered into a Merger Agreement with Tyco International plc, a newly-formed Irish public limited company and a wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement with Tyco Ireland, Tyco merged with and into Tyco Ireland, with Tyco Ireland being the surviving company. This resulted in Tyco Ireland becoming Tyco's publicly-traded parent company and changed the jurisdiction of organization of Tyco from Switzerland to Ireland. Tyco's shareholders received one ordinary share of Tyco Ireland for each ordinary share of Tyco held immediately prior to the re-domicile to Ireland. The re-domicile to Ireland became effective on November 17, 2014.

[0000833444-16-000197:notes:17]
Reclassifications— Certain prior period amounts have been reclassified to conform with the current period presentation.

[0000833444-16-000197:notes:18]
Effective for the first quarter of fiscal 2016, the Company has elected to present operating income by segment, as well as Corporate and Other, excluding restructuring and repositioning charges, net.  Restructuring and repositioning charges, net, are shown in aggregate. This presentation is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. See Note 15.

[0000833444-16-000197:notes:19]
During the third quarter of fiscal 2016, the Company reclassified the assets and liabilities of a business it plans to sell within the ROW Integrated Solutions & Services segment as held for sale for all periods presented within the Consolidated Balance Sheets.  As of June 24, 2016, assets of $71 million and liabilities of $34 million were reclassified as held for sale related to this business. The results of operations of this business are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied. During the second quarter of fiscal 2016, the Company completed the sale of its Australian fire protection business, included in the ROW Integrated Solutions & Services segment. The assets and liabilities related to this business were classified as held for sale as of September 25, 2015.  Its results of operations are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied. See Note 3.

[0000833444-16-000197:notes:20]
Recently Adopted Accounting Pronouncements— In April 2014, the Financial Accounting Standards Board ("FASB") issued authoritative guidance to change the criteria for reporting discontinued operations. Under the new guidance, only disposals representing a strategic shift that has or will have a major effect on the Company's operations and financial results should be reported as discontinued operations, with expanded disclosures. The guidance became effective for Tyco in the first quarter of fiscal 2016. The Company considers both qualitative and quantitative factors when assessing whether a disposed business represents a strategic shift that will have a major effect on the Company's operations and financial results. The Company considers the level (e.g. individual business or product line, reporting unit or reportable segment) and geographic impact (e.g. country, region, worldwide) of the disposal group. In addition, the Company considers the significance of the disposed business on certain financial measures when assessing whether or not such disposal has a major effect on the Company's operations and financial results. The adoption of this guidance did not have a material impact on the Company's financial position, results of operations or cash flows. During fiscal 2016, the divestiture of the Company's Australian fire protection business and the planned sale of another business within its ROW Integrated Solutions & Services segment did not meet the criteria set forth in the new guidance and therefore were not classified as discontinued operations. See Note 3.

[0000833444-16-000197:notes:21]
Recently Issued Accounting Pronouncements— In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires quantitative and qualitative disclosures that are more comprehensive than existing standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. The new standard permits either the full retrospective method or the modified retrospective method of adoption. In August 2015, the FASB issued authoritative guidance to defer the effective date of this guidance, which for Tyco will be the first quarter of fiscal 2019, with early adoption permitted beginning the first quarter of fiscal 2018. In March 2016, the FASB issued additional authoritative guidance clarifying its implementation guidance on principal versus agent considerations when determining whether to report revenue gross versus net. In April 2016, the FASB issued additional authoritative guidance clarifying issues related to identifying performance obligations and licensing. In May 2016, the FASB issued additional authoritative guidance specifically in the areas of assessing collectability, presentation of sales taxes, noncash consideration, and completed contracts and contract modifications. The Company is in the process of assessing the impact the guidance is expected to have upon adoption, including determining the adoption method.

[0000833444-16-000197:notes:22]
In May 2015, the FASB issued authoritative guidance that is intended to improve the existing disclosure requirements for short-duration contracts for insurance entities that issue such contracts.  The guidance requires additional information to be disclosed about the liability for unpaid claims and claim adjustment expenses to increase the transparency of significant estimates made in measuring those liabilities.  This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

[0000833444-16-000197:notes:23]
In July 2015, the FASB issued authoritative guidance intended to simplify the existing guidance under which an entity must measure inventory at the lower of cost or market. Under the new guidance, inventory is “measured at the lower of cost and net realizable value,” and does not apply to inventory that is measured using last-in, first-out or the retail method. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

[0000833444-16-000197:notes:24]
In September 2015, the FASB issued authoritative guidance intended to reduce the cost and complexity of financial reporting when recognizing adjustments to provisional amounts in connection with a business combination. This guidance eliminates the requirement to restate prior period financial statements, but requires entities to present separately on the face of the income statement, or disclose in the notes, the portion of the amount recorded in current-period earnings by line item that would have been recorded in previous reporting periods if the adjustment to the provisional amounts had been recognized as of the acquisition date. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

[0000833444-16-000197:notes:25]
In November 2015, the FASB issued authoritative guidance intended to simplify the presentation of deferred income taxes.  Under the new guidance, deferred tax liabilities and deferred tax assets are to be classified as noncurrent in a classified statement of financial position.  The current requirement that deferred tax liabilities and assets of a tax-paying component of an entity be offset and presented as a single amount is not affected by the amendments in this update. This guidance is effective for Tyco in the first quarter of fiscal 2018, with early adoption permitted on a prospective or retrospective basis. The Company plans to adopt this guidance as of September 30, 2016 and does not expect the guidance to have a material impact on its financial statements.

[0000833444-16-000197:notes:26]
In January 2016, the FASB issued authoritative guidance addressing the recognition, measurement, presentation and disclosure of financial assets and liabilities. The guidance primarily affects the accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments. In addition, the guidance clarifies the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. This guidance is effective for Tyco in the first quarter of fiscal 2019, and early adoption is not permitted, with certain exceptions.  The amendments are required to be applied by means of a cumulative-effect adjustment on the balance sheet as of the beginning of the fiscal year of adoption.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

[0000833444-16-000197:notes:27]
In February 2016, the FASB issued authoritative guidance requiring the recognition of lease assets and lease liabilities by lessees for those leases previously classified as operating leases. The guidance requires quantitative and qualitative disclosures that are more comprehensive than existing standards. The disclosures are intended to enable financial statement users to understand the amount, timing and uncertainty of cash flows arising from leases. This guidance is effective for Tyco in the first quarter of fiscal 2020 with early adoption permitted. The amendments are required to be applied by means of a modified retrospective approach. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

[0000833444-16-000197:notes:28]
In March 2016, the FASB amended its authoritative guidance for employee share-based payment transactions by simplifying several aspects of the accounting for employee share-based payment awards, including the accounting for income taxes, withholding taxes and forfeitures, as well as classification on the statement of cash flows. The amended guidance is effective for Tyco in the first quarter of fiscal 2018 with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

[0000833444-16-000197:notes:29]
In June 2016, the FASB issued authoritative guidance amending the impairment model for most financial assets by requiring a new forward-looking “expected loss” methodology that will replace today’s “incurred loss” methodology and generally result in the more timely recognition of allowances for credit losses. Furthermore, additional disclosures will be required. The guidance is effective for Tyco in the first quarter of fiscal 2021, with early adoption permitted in the first quarter of fiscal 2020. The Company is in the process of assessing the timing and impact, if any, the guidance may have upon adoption.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000833444-16-000197:notes:30]
[same as prior period, unchanged from 0000833444-16-000172:notes:34]

[0000833444-16-000197:notes:31]
During the quarter ended June 24, 2016, cash consideration for acquisitions included in continuing operations was $6 million related to an acquisition that is being integrated within the Company's Global Products segment.

[0000833444-16-000197:notes:32]
During the nine months ended June 24, 2016, cash consideration for acquisitions included in continuing operations was $320 million.  This included cash consideration of $176 million, which was comprised of $182 million of cash paid, net of cash acquired of $6 million and related to the acquisition of ShopperTrak, a leading global provider of retail consumer behavior insights and location-based analytics. ShopperTrak is being integrated into the NA Integrated Solutions & Services and ROW Integrated Solutions & Services segments. In addition, cash consideration for the nine month period also included $128 million, which was comprised of $166 million of cash paid, including $5 million to settle pre-existing matters and $6 million for prepaid agency commissions, net of cash acquired of $27 million, related to an additional investment in the Company's Tyco UAE joint venture with its local partner Suwaidi Engineering Group ("Suwaidi") in the United Arab Emirates ("UAE").  Tyco UAE is a leading provider of fire, security and integrated solutions and services in the UAE and also has operations in Qatar and Oman.  Effective with the date of this transaction, the Company consolidated 100% of Tyco UAE, which is recorded in the Company's ROW Integrated Solutions & Services segment. The total enterprise fair value of the UAE joint venture was allocated as follows: $99 million of assets, $136 million of goodwill, $99 million of intangible assets and the assumption of $32 million of liabilities. The Company's proportionate share of the joint venture's net income was historically recorded in Selling, general and administrative expenses within the Consolidated Statements of Operations for periods prior to the acquisition date. As a result of this transaction, the Company recorded a net gain of $111 million which primarily relates to the Company's previously held 49% equity interest in the joint venture, which was previously accounted for under the equity method of accounting, inclusive of a charge for the settlement of pre-existing matters with the Company's former joint venture partner. The Company recorded the net gain in Selling, general and administrative expenses within the Consolidated Statements of Operations during the quarter ended December 25, 2015.  The balance of the cash paid during the nine months ended June 24, 2016 of $16 million related to acquisitions within the Company's ROW Integrated Solutions & Services and Global Products segments which were not material.

[0000833444-16-000197:notes:33]
The Company finalized the determination of fair value of certain assets and liabilities related to the ShopperTrak acquisition during the third quarter of fiscal 2016 with no material effect on the purchase price allocation.  In addition, during the nine months ended June 24, 2016, the Company finalized the determination of fair value for certain assets and liabilities relating to the acquisitions closed during the first quarter of fiscal 2016 and fourth quarter of fiscal 2015, with no material adjustment to the preliminary purchase price allocations.

[0000833444-16-000197:notes:34]
During the quarter ended June 26, 2015, the Company did not complete any acquisitions. During the nine months ended June 26, 2015, total consideration paid, net of $26 million of cash acquired and $8 million of holdback liability, for 11 acquisitions included in continuing operations was $525 million.  The largest of these was the acquisition of Industrial Safety Technologies International ("IST"), a global leader in gas and flame detection with operations in Europe, the Middle East, China, and the U.S., for total consideration paid, net of $5 million of cash acquired, of $327 million. The purchase price for IST has been allocated as follows: $68 million of assets, $136 million of goodwill, $143 million of intangible assets and the assumption of $15 million of liabilities. IST has been integrated into the Global Products segment.  The remaining 10 acquisitions during the nine months ended June 26, 2015 have been integrated into the ROW Integrated Solutions & Services and Global Products segments.

[0000833444-16-000197:notes:35]
Acquisition and Integration Related Costs

[0000833444-16-000197:notes:36]
Acquisition and integration related costs are expensed as incurred.  During the quarters ended June 24, 2016 and June 26, 2015, the Company incurred acquisition and integration related costs of $5 million and $2 million, respectively.  During the nine months ended June 24, 2016 and June 26, 2015, the Company incurred acquisition and integration related costs of $9 million and $4 million, respectively.  Such costs are recorded in Selling, general and administrative expenses within the Company's Consolidated Statements of Operations.


## us-gaap:BusinessCombinationSeparatelyRecognizedTransactionsTableTextBlock

[0000833444-16-000197:notes:37]
Merger costs were classified in continuing operations within the Company's Consolidated Statement of Operations as follows ($ in millions):

[0000833444-16-000197:notes:38]
|  | For the Quarter Ended |  | For the Nine Months Ended |
|  | June 24, 2016 |  | June 24, 2016 |
| Selling, general and administrative | $ | 12 |  |  | $ | 12 |  |
| Merger costs | 7 |  |  | 33 |  |
| Total | $ | 19 |  |  | $ | 45 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-16-000197:notes:39]
Commitments and Contingencies

[0000833444-16-000197:notes:40]
Environmental Matters

[0000833444-16-000197:notes:41]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of June 24, 2016, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $20 million to $69 million. As of June 24, 2016, Tyco concluded that the best estimate within this range is approximately $31 million, of which $11 million is included in Accrued and other current liabilities and $20 million is included in Other liabilities within the Company's Consolidated Balance Sheet.

[0000833444-16-000197:notes:42]
As previously disclosed, the majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. As of June 24, 2016, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $12 million to $44 million. The Company's best estimate within that range is approximately $21 million, of which $9 million is included in Accrued and other current liabilities and $12 million is included in Other liabilities within the Company's Consolidated Balance Sheet.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.

[0000833444-16-000197:notes:43]
Asbestos Matters

[0000833444-16-000197:notes:44]
The Company and certain of its subsidiaries, including Grinnell LLC (“Grinnell”), along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. Substantially all cases pending against affiliates of the Company have been filed against Grinnell, and have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-16-000197:notes:45]
During the third quarter of fiscal 2014, the Company, through Grinnell, resolved disputes with certain of its historical insurers and agreed that certain insurance proceeds would be used to establish and fund a qualified settlement fund (“QSF”), within the meaning of the Internal Revenue Code, which would be used for the resolution primarily of Grinnell asbestos liabilities. It is intended that the QSF will receive future insurance payments and proceeds from third party insurers and, in addition, will fund and manage liabilities for certain historical operations of the Company, primarily related to Grinnell. On January 9, 2015, the Company completed a series of restructuring transactions related to the establishment and funding of a dedicated structure pursuant to which a subsidiary of the Company acquired the assets of Grinnell and transferred cash and other assets totaling approximately $278 million (not including $22 million received by the QSF during the quarter ended December 26, 2014 from historic third-party insurers in settlement of coverage disputes) to the structure. As part of the restructuring, subsidiaries in the structure assumed certain liabilities related to historic Grinnell, Scott and Figgie operations, including all historical Grinnell asbestos liabilities, and such subsidiaries purchased additional insurance by, through or from a wholly-owned subsidiary in the structure in order to supplement and enhance existing insurance assets.

[0000833444-16-000197:notes:46]
The Company consolidates the qualified settlement fund and related entities that were established for the purpose of managing and resolving the liabilities described above. Although the entities in the dedicated structure serve the specific purpose of managing certain liabilities, each entity in the structure is a wholly-owned indirect subsidiary of the Company, and therefore is required to be consolidated under GAAP.

[0000833444-16-000197:notes:47]
As of June 24, 2016, the Company has determined that there were approximately 3,000 claims pending against its subsidiaries, primarily Grinnell. This amount reflects the Company's current estimate of the number of viable claims made against Grinnell and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties.

[0000833444-16-000197:notes:48]
As of June 24, 2016, the Company's estimated asbestos related net liability recorded within the Company's Consolidated Balance Sheet is $18 million. The net liability within the Consolidated Balance Sheet is comprised of a liability for pending and future claims and related defense costs of $492 million, of which $22 million is recorded in Accrued and other current liabilities, and $470 million is recorded in Other liabilities. The Company also maintains separate cash, investment and other assets within the Consolidated Balance Sheet of $474 million, of which $31 million is recorded in Prepaid expenses and other current assets, and $443 million is recorded in Other assets. Assets include $11 million of cash and $257 million of investments, which have all been designated as restricted.  As of September 25, 2015, the Company's estimated net liability recorded within the Company's Consolidated Balance Sheet was $28 million. The net liability was comprised of a liability for pending and future claims and related defense costs of $515 million, of which $23 million was recorded in Accrued and other current liabilities, and $492 million was recorded in Other liabilities.  The Company also maintained separate cash, investment and other assets within the Consolidated Balance Sheet of $487 million, of which $38 million was recorded in Prepaid expenses and other current assets, and $449 million was recorded in Other assets. Assets included $11 million of cash and $263 million of investments, which were all designated as restricted.

[0000833444-16-000197:notes:49]
The Company periodically assesses the sufficiency of its estimated liability for pending and future asbestos claims and defense costs. On a periodic basis, the Company, through the dedicated structure referred to above, evaluates actual experience regarding asbestos claims filed, settled and dismissed, amounts paid in settlements, and the recoverability of its insurance assets. If and when data from actual experience demonstrate a significant unfavorable discernible trend, the Company performs a valuation of its asbestos related liabilities and corresponding insurance assets including a comprehensive review of the underlying assumptions. In addition, the Company evaluates its ability to reasonably estimate claim activity beyond its current look-forward period (through 2056) in order to assess whether such period continues to be appropriate. In addition to claims and litigation experience, the Company considers additional qualitative and quantitative factors such as changes in legislation, the legal environment, the Company’s strategy in managing claims and obtaining insurance, including its defense strategy, and health related trends in the overall population of individuals potentially exposed to asbestos. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance assets is warranted.

[0000833444-16-000197:notes:50]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-16-000197:notes:51]
Tax Matters

[0000833444-16-000197:notes:52]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation. The issues and proposed adjustments related to such years are generally subject to the sharing provisions of the 2007 Tax Sharing Agreement and Tyco's liabilities under the 2007 Tax Sharing Agreement are further subject to the sharing provisions in the 2012 Tax Sharing Agreement. Tyco has previously disclosed that on June 20, 2013, it had received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owed additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million had been asserted. These amounts excluded interest and did not reflect the roll-forward impact on subsequent audit periods.

[0000833444-16-000197:notes:53]
As previously reported, the Company, as Audit Managing Party under each Tax Sharing Agreement dated September 25, 2007 (among the Company, TE Connectivity Ltd. and Covidien plc (which on January 26, 2015 was acquired by and now operates as a subsidiary of Medtronic plc) and dated September 28, 2012 (among the Company, The ADT Corporation and Pentair Ltd. (along with TE Connectivity and Covidien, the "Parties")), entered into Stipulations of Settled Issues with the IRS intended to resolve all Federal tax disputes related to the intercompany debt issues for the Company’s 1997 - 2000 audit cycle before the U.S. Tax Court. The Stipulations of Settled Issues were contingent upon the IRS Appeals Division applying the same settlement terms to all intercompany debt issues on appeal for subsequent audit cycles (2001 - 2007). On May 17, 2016 the IRS Office of Appeals issued fully-executed Forms 870-AD that effectively settled the matters on appeal on the same terms as those set forth in the Stipulations of Settled Issues, and on May 31, 2016, the U.S. Tax Court entered decisions consistent with the Stipulations of Settled Issues. As a result, all aspects of this controversy that were before the U.S. Tax Court and Appeals Division of the IRS have been finally resolved for audit cycles 1997 - 2007. The Company paid $120 million to TE Connectivity Ltd. and $2 million to Covidien during the second quarter of fiscal 2016 representing its share of the total amount payable to the IRS in connection with this matter.

[0000833444-16-000197:notes:54]
Additionally, during the third quarter of fiscal 2016, the Company also paid $12 million to Covidien and $4 million to TE Connectivity with respect to other matters sharable pursuant to the 2007 Tax Sharing Agreement.

[0000833444-16-000197:notes:55]
As a result of the final settlement, the Company assessed its remaining obligations under its tax sharing agreements. Based on the assessment performed, the Company reversed a portion of its shared tax obligation liabilities related to the 2007 and 2012 Tax Sharing Agreements, and recognized a gain of $54 million in Other income (expense), net within the Consolidated Statements of Operations for both the quarter and nine months ended June 24, 2016. The Company believes the remaining liabilities that it has recorded are sufficient to cover its future obligations under the Tax Sharing Agreements.

[0000833444-16-000197:notes:56]
Other Matters

[0000833444-16-000197:notes:57]
On March 1, 2016, a putative class action lawsuit, Wandel v. Tyco International plc, et al., Docket No. C-000010-16, was filed in the Superior Court of New Jersey naming Tyco, the individual members of its board of directors, Johnson Controls and Merger Sub as defendants. The complaint alleges that Tyco’s directors breached their fiduciary duties and exercised their powers as directors in a manner oppressive to the public shareholders of Tyco in violation of Irish law by, among other things, failing to take steps to maximize shareholder value and failing to protect against purported conflicts of interest. The complaint further alleges that Tyco, Johnson Controls and Merger Sub aided and abetted Tyco’s directors in the breach of their fiduciary duties. The complaint seeks, among other things, to enjoin the merger. The Company believes that the claims asserted by the complaint are not valid.

[0000833444-16-000197:notes:58]
On May 20, 2016, a putative class action lawsuit, Laufer v. Johnson Controls, Inc., et al., Docket No. 2016CV003859, was filed in the Circuit Court of Wisconsin, Milwaukee County, naming Johnson Controls, the individual members of its board of directors, Tyco and Merger Sub as defendants. The complaint alleges that Johnson Controls' directors breached their fiduciary duties by, among other things, failing to take steps to maximize shareholder value, seeking to benefit themselves improperly and failing to disclose material information in this joint proxy statement/prospectus. The complaint further alleges that Tyco aided and abetted Johnson Controls' directors in the breach of their fiduciary duties. The complaint seeks, among other things, to enjoin the merger. The Company believes that the claims asserted by the complaint are not valid.

[0000833444-16-000197:notes:59]
In addition to the foregoing, the Company is subject to claims and suits, including from time to time, contractual disputes and product and general liability claims, incidental to present and former operations, acquisitions and dispositions. With respect to many of these claims, the Company either self-insures or maintains insurance through third-parties, with varying deductibles. While the ultimate outcome of these matters cannot be predicted with certainty, the Company believes that the resolution of any such proceedings, whether the underlying claims are covered by insurance or not, will not have a material adverse effect on the Company's financial condition, results of operations or cash flows beyond amounts recorded for such matters.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-16-000197:notes:60]
[same as prior period, unchanged from 0000833444-16-000172:notes:60]

[0000833444-16-000197:notes:61]
[same as prior period, unchanged from 0000833444-16-000172:notes:61]

[0000833444-16-000197:notes:62]
[same as prior period, unchanged from 0000833444-16-000172:notes:62]

[0000833444-16-000197:notes:63]
For the Quarter Ended June 24, 2016

[0000833444-16-000197:notes:64]
[same as prior period, unchanged from 0000833444-16-000172:notes:64]

[0000833444-16-000197:notes:65]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,449 |  |  | $ | — |  |  | $ | 2,449 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 1,026 |  |  | — |  |  | 1,026 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 508 |  |  | — |  |  | 508 |  |
| Selling, general and administrative expenses | 1 |  |  | — |  |  | 1 |  |  | 665 |  |  | — |  |  | 667 |  |
| Merger costs | 2 |  |  | — |  |  | 1 |  |  | 4 |  |  | — |  |  | 7 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Operating (loss) income | (3 | ) |  | — |  |  | (2 | ) |  | 241 |  |  | — |  |  | 236 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Interest expense | — |  |  | — |  |  | (22 | ) |  | — |  |  | — |  |  | (22 | ) |
| Other income, net | — |  |  | — |  |  | 54 |  |  | — |  |  | — |  |  | 54 |  |
| Equity in net income of subsidiaries | 225 |  |  | 220 |  |  | 169 |  |  | — |  |  | (614 | ) |  | — |  |
| Intercompany interest and fees | 17 |  |  | — |  |  | 21 |  |  | (38 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 239 |  |  | 220 |  |  | 220 |  |  | 206 |  |  | (614 | ) |  | 271 |  |
| Income tax expense | — |  |  | — |  |  | — |  |  | (31 | ) |  | — |  |  | (31 | ) |
| Income from continuing operations | 239 |  |  | 220 |  |  | 220 |  |  | 175 |  |  | (614 | ) |  | 240 |  |
| Loss from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Net income | 239 |  |  | 220 |  |  | 220 |  |  | 173 |  |  | (614 | ) |  | 238 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 239 |  |  | $ | 220 |  |  | $ | 220 |  |  | $ | 174 |  |  | $ | (614 | ) |  | $ | 239 |  |

[0000833444-16-000197:notes:66]
[same as prior period, unchanged from 0000833444-16-000172:notes:66]

[0000833444-16-000197:notes:67]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 239 |  |  | $ | 220 |  |  | $ | 220 |  |  | $ | 173 |  |  | $ | (614 | ) |  | $ | 238 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | 6 |  |  | — |  |  | (6 | ) |  | 12 |  |  | (6 | ) |  | 6 |  |
| Defined benefit and post retirement plans | 5 |  |  | — |  |  | — |  |  | 5 |  |  | (5 | ) |  | 5 |  |
| Unrealized gain on marketable securities and derivative instruments, net of tax | 3 |  |  | — |  |  | — |  |  | 3 |  |  | (3 | ) |  | 3 |  |
| Total other comprehensive income (loss), net of tax | 14 |  |  | — |  |  | (6 | ) |  | 20 |  |  | (14 | ) |  | 14 |  |
| Comprehensive income | 253 |  |  | 220 |  |  | 214 |  |  | 193 |  |  | (628 | ) |  | 252 |  |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 253 |  |  | $ | 220 |  |  | $ | 214 |  |  | $ | 194 |  |  | $ | (628 | ) |  | $ | 253 |  |

[0000833444-16-000197:notes:68]
For the Quarter Ended June 26, 2015

[0000833444-16-000197:notes:69]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,489 |  |  | $ | — |  |  | $ | 2,489 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 1,025 |  |  | — |  |  | 1,025 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 548 |  |  | — |  |  | 548 |  |
| Selling, general and administrative expenses | 1 |  |  | — |  |  | — |  |  | 624 |  |  | — |  |  | 625 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 38 |  |  | — |  |  | 38 |  |
| Operating (loss) income | (1 | ) |  | — |  |  | — |  |  | 254 |  |  | — |  |  | 253 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Interest expense | — |  |  | — |  |  | (25 | ) |  | (1 | ) |  | — |  |  | (26 | ) |
| Other income, net | — |  |  | — |  |  | 1 |  |  | 5 |  |  | — |  |  | 6 |  |
| Equity in net income of subsidiaries | 145 |  |  | 165 |  |  | 166 |  |  | — |  |  | (476 | ) |  | — |  |
| Intercompany interest and fees | 12 |  |  | — |  |  | 23 |  |  | (35 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 156 |  |  | 165 |  |  | 165 |  |  | 227 |  |  | (476 | ) |  | 237 |  |
| Income tax expense | — |  |  | — |  |  | — |  |  | (49 | ) |  | — |  |  | (49 | ) |
| Income from continuing operations | 156 |  |  | 165 |  |  | 165 |  |  | 178 |  |  | (476 | ) |  | 188 |  |
| Loss from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | (32 | ) |  | — |  |  | (32 | ) |
| Net income | 156 |  |  | 165 |  |  | 165 |  |  | 146 |  |  | (476 | ) |  | 156 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income attributable to Tyco ordinary shareholders | $ | 156 |  |  | $ | 165 |  |  | $ | 165 |  |  | $ | 146 |  |  | $ | (476 | ) |  | $ | 156 |  |

[0000833444-16-000197:notes:70]
[same as prior period, unchanged from 0000833444-16-000172:notes:70]

[0000833444-16-000197:notes:71]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 156 |  |  | $ | 165 |  |  | $ | 165 |  |  | $ | 146 |  |  | $ | (476 | ) |  | $ | 156 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | 28 |  |  | — |  |  | (12 | ) |  | 40 |  |  | (28 | ) |  | 28 |  |
| Defined benefit and post retirement plans | 4 |  |  | — |  |  | — |  |  | 4 |  |  | (4 | ) |  | 4 |  |
| Unrealized loss on marketable securities and derivative instruments, net of tax | (4 | ) |  | — |  |  | — |  |  | (4 | ) |  | 4 |  |  | (4 | ) |
| Total other comprehensive income (loss), net of tax | 28 |  |  | — |  |  | (12 | ) |  | 40 |  |  | (28 | ) |  | 28 |  |
| Comprehensive income | 184 |  |  | 165 |  |  | 153 |  |  | 186 |  |  | (504 | ) |  | 184 |  |
| Less: comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 184 |  |  | $ | 165 |  |  | $ | 153 |  |  | $ | 186 |  |  | $ | (504 | ) |  | $ | 184 |  |

[0000833444-16-000197:notes:72]
For the Nine Months Ended June 24, 2016

[0000833444-16-000197:notes:73]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 7,156 |  |  | $ | — |  |  | $ | 7,156 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 2,956 |  |  | — |  |  | 2,956 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 1,550 |  |  | — |  |  | 1,550 |  |
| Selling, general and administrative expenses | 5 |  |  | — |  |  | 2 |  |  | 1,835 |  |  | — |  |  | 1,842 |  |
| Merger costs | 2 |  |  | — |  |  | 11 |  |  | 20 |  |  | — |  |  | 33 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Operating (loss) income | (7 | ) |  | — |  |  | (13 | ) |  | 774 |  |  | — |  |  | 754 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Interest expense | — |  |  | — |  |  | (67 | ) |  | (1 | ) |  | — |  |  | (68 | ) |
| Other (expense) income, net | — |  |  | — |  |  | (112 | ) |  | 1 |  |  | — |  |  | (111 | ) |
| Equity in net income of subsidiaries | 388 |  |  | 380 |  |  | 504 |  |  | — |  |  | (1,272 | ) |  | — |  |
| Intercompany interest and fees | 82 |  |  | — |  |  | 68 |  |  | (150 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 463 |  |  | 380 |  |  | 380 |  |  | 635 |  |  | (1,272 | ) |  | 586 |  |
| Income tax expense | (2 | ) |  | — |  |  | — |  |  | (128 | ) |  | — |  |  | (130 | ) |
| Income from continuing operations | 461 |  |  | 380 |  |  | 380 |  |  | 507 |  |  | (1,272 | ) |  | 456 |  |
| Income from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Net income | 461 |  |  | 380 |  |  | 380 |  |  | 510 |  |  | (1,272 | ) |  | 459 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 461 |  |  | $ | 380 |  |  | $ | 380 |  |  | $ | 512 |  |  | $ | (1,272 | ) |  | $ | 461 |  |

[0000833444-16-000197:notes:74]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 461 |  |  | $ | 380 |  |  | $ | 380 |  |  | $ | 510 |  |  | $ | (1,272 | ) |  | $ | 459 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | 7 |  |  | — |  |  | (5 | ) |  | 12 |  |  | (7 | ) |  | 7 |  |
| Defined benefit and post retirement plans | 13 |  |  | — |  |  | — |  |  | 13 |  |  | (13 | ) |  | 13 |  |
| Unrealized gain on marketable securities and derivative instruments, net of tax | 6 |  |  | — |  |  | — |  |  | 6 |  |  | (6 | ) |  | 6 |  |
| Total other comprehensive income (loss), net of tax | 26 |  |  | — |  |  | (5 | ) |  | 31 |  |  | (26 | ) |  | 26 |  |
| Comprehensive income | 487 |  |  | 380 |  |  | 375 |  |  | 541 |  |  | (1,298 | ) |  | 485 |  |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 487 |  |  | $ | 380 |  |  | $ | 375 |  |  | $ | 543 |  |  | $ | (1,298 | ) |  | $ | 487 |  |

[0000833444-16-000197:notes:75]
For the Nine Months Ended June 26, 2015

[0000833444-16-000197:notes:76]
|  | TycoInternationalplc |  | TycoFire & Security Finance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 7,397 |  |  | $ | — |  |  | $ | 7,397 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 3,046 |  |  | — |  |  | 3,046 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 1,645 |  |  | — |  |  | 1,645 |  |
| Selling, general and administrative expenses | 6 |  |  | — |  |  | 1 |  |  | 1,918 |  |  | — |  |  | 1,925 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 108 |  |  | — |  |  | 108 |  |
| Operating (loss) income | (6 | ) |  | — |  |  | (1 | ) |  | 680 |  |  | — |  |  | 673 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Interest expense | — |  |  | — |  |  | (73 | ) |  | (2 | ) |  | — |  |  | (75 | ) |
| Other income, net | — |  |  | — |  |  | 3 |  |  | 6 |  |  | — |  |  | 9 |  |
| Equity in net income of subsidiaries | 440 |  |  | 456 |  |  | 453 |  |  | — |  |  | (1,349 | ) |  | — |  |
| Intercompany interest and fees | 51 |  |  | — |  |  | 74 |  |  | (125 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 485 |  |  | 456 |  |  | 456 |  |  | 570 |  |  | (1,349 | ) |  | 618 |  |
| Income tax expense | — |  |  | — |  |  | — |  |  | (86 | ) |  | — |  |  | (86 | ) |
| Income from continuing operations | 485 |  |  | 456 |  |  | 456 |  |  | 484 |  |  | (1,349 | ) |  | 532 |  |
| Loss from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | (50 | ) |  | — |  |  | (50 | ) |
| Net income | 485 |  |  | 456 |  |  | 456 |  |  | 434 |  |  | (1,349 | ) |  | 482 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 485 |  |  | $ | 456 |  |  | $ | 456 |  |  | $ | 437 |  |  | $ | (1,349 | ) |  | $ | 485 |  |

[0000833444-16-000197:notes:77]
|  | TycoInternationalplc |  | TycoFire & Security Finance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 485 |  |  | $ | 456 |  |  | $ | 456 |  |  | $ | 434 |  |  | $ | (1,349 | ) |  | $ | 482 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (346 | ) |  | — |  |  | 3 |  |  | (349 | ) |  | 346 |  |  | (346 | ) |
| Defined benefit and post retirement plans | 13 |  |  | — |  |  | — |  |  | 13 |  |  | (13 | ) |  | 13 |  |
| Unrealized loss on marketable securities and derivative instruments | (4 | ) |  | — |  |  | — |  |  | (4 | ) |  | 4 |  |  | (4 | ) |
| Total other comprehensive (loss) income, net of tax | (337 | ) |  | — |  |  | 3 |  |  | (340 | ) |  | 337 |  |  | (337 | ) |
| Comprehensive income | 148 |  |  | 456 |  |  | 459 |  |  | 94 |  |  | (1,012 | ) |  | 145 |  |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 148 |  |  | $ | 456 |  |  | $ | 459 |  |  | $ | 97 |  |  | $ | (1,012 | ) |  | $ | 148 |  |

[0000833444-16-000197:notes:78]
[same as prior period, unchanged from 0000833444-16-000172:notes:78]

[0000833444-16-000197:notes:79]
As of June 24, 2016

[0000833444-16-000197:notes:80]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 345 |  |  | $ | — |  |  | $ | 345 |  |
| Accounts receivable, net | — |  |  | — |  |  | — |  |  | 1,805 |  |  | — |  |  | 1,805 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 656 |  |  | — |  |  | 656 |  |
| Intercompany receivables | 10 |  |  | — |  |  | 553 |  |  | 7,750 |  |  | (8,313 | ) |  | — |  |
| Prepaid expenses and other current assets | 1 |  |  | — |  |  | 56 |  |  | 826 |  |  | — |  |  | 883 |  |
| Deferred income taxes | — |  |  | — |  |  | — |  |  | 62 |  |  | — |  |  | 62 |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 71 |  |  | — |  |  | 71 |  |
| Total Current Assets | 11 |  |  | — |  |  | 609 |  |  | 11,515 |  |  | (8,313 | ) |  | 3,822 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | — |  |  | 1,180 |  |  | — |  |  | 1,180 |  |
| Goodwill | — |  |  | — |  |  | — |  |  | 4,418 |  |  | — |  |  | 4,418 |  |
| Intangible assets, net | — |  |  | — |  |  | — |  |  | 966 |  |  | — |  |  | 966 |  |
| Investment in subsidiaries | 11,339 |  |  | 11,581 |  |  | 16,569 |  |  | — |  |  | (39,489 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | — |  |  | 13,987 |  |  | 16,166 |  |  | (30,153 | ) |  | — |  |
| Other assets | — |  |  | — |  |  | 21 |  |  | 1,207 |  |  | — |  |  | 1,228 |  |
| Total Assets | $ | 11,350 |  |  | $ | 11,581 |  |  | $ | 31,186 |  |  | $ | 35,452 |  |  | $ | (77,955 | ) |  | $ | 11,614 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 341 |  |  | $ | — |  |  | $ | — |  |  | $ | 341 |  |
| Accounts payable | 1 |  |  | — |  |  | — |  |  | 798 |  |  | — |  |  | 799 |  |
| Accrued and other current liabilities | 90 |  |  | — |  |  | 61 |  |  | 1,413 |  |  | — |  |  | 1,564 |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 378 |  |  | — |  |  | 378 |  |
| Intercompany payables | 3,736 |  |  | — |  |  | 4,023 |  |  | 554 |  |  | (8,313 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 34 |  |  | — |  |  | 34 |  |
| Total Current Liabilities | 3,827 |  |  | — |  |  | 4,425 |  |  | 3,177 |  |  | (8,313 | ) |  | 3,116 |  |
| Long-term debt | — |  |  | — |  |  | 2,164 |  |  | 1 |  |  | — |  |  | 2,165 |  |
| Intercompany loans payable | 3,172 |  |  | — |  |  | 12,994 |  |  | 13,987 |  |  | (30,153 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 284 |  |  | — |  |  | 284 |  |
| Other liabilities | — |  |  | — |  |  | 22 |  |  | 1,641 |  |  | — |  |  | 1,663 |  |
| Total Liabilities | 6,999 |  |  | — |  |  | 19,605 |  |  | 19,090 |  |  | (38,466 | ) |  | 7,228 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |  |  |
| Ordinary shares | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |
| Ordinary shares held in treasury | (15 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (15 | ) |
| Other shareholders' equity | 4,362 |  |  | 11,581 |  |  | 11,581 |  |  | 16,327 |  |  | (39,489 | ) |  | 4,362 |  |
| Total Tyco Shareholders' Equity | 4,351 |  |  | 11,581 |  |  | 11,581 |  |  | 16,327 |  |  | (39,489 | ) |  | 4,351 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 35 |  |  | — |  |  | 35 |  |
| Total Equity | 4,351 |  |  | 11,581 |  |  | 11,581 |  |  | 16,362 |  |  | (39,489 | ) |  | 4,386 |  |
| Total Liabilities and Equity | $ | 11,350 |  |  | $ | 11,581 |  |  | $ | 31,186 |  |  | $ | 35,452 |  |  | $ | (77,955 | ) |  | $ | 11,614 |  |

[0000833444-16-000197:notes:81]
[same as prior period, unchanged from 0000833444-16-000172:notes:81]

[0000833444-16-000197:notes:82]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,401 |  |  | $ | — |  |  | $ | 1,401 |  |
| Accounts receivable, net | — |  |  | — |  |  | — |  |  | 1,722 |  |  | — |  |  | 1,722 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 620 |  |  | — |  |  | 620 |  |
| Intercompany receivables | 15 |  |  | — |  |  | 332 |  |  | 6,508 |  |  | (6,855 | ) |  | — |  |
| Prepaid expenses and other current assets | — |  |  | — |  |  | 63 |  |  | 687 |  |  | — |  |  | 750 |  |
| Deferred income taxes | — |  |  | — |  |  | — |  |  | 62 |  |  | — |  |  | 62 |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 208 |  |  | — |  |  | 208 |  |
| Total Current Assets | 15 |  |  | — |  |  | 395 |  |  | 11,208 |  |  | (6,855 | ) |  | 4,763 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | — |  |  | 1,166 |  |  | — |  |  | 1,166 |  |
| Goodwill | — |  |  | — |  |  | — |  |  | 4,203 |  |  | — |  |  | 4,203 |  |
| Intangible assets, net | — |  |  | — |  |  | — |  |  | 822 |  |  | — |  |  | 822 |  |
| Investment in subsidiaries | 10,885 |  |  | 11,140 |  |  | 15,993 |  |  | — |  |  | (38,018 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | — |  |  | 2,942 |  |  | 5,066 |  |  | (8,008 | ) |  | — |  |
| Other assets | 1 |  |  | — |  |  | 44 |  |  | 1,322 |  |  | — |  |  | 1,367 |  |
| Total Assets | $ | 10,901 |  |  | $ | 11,140 |  |  | $ | 19,374 |  |  | $ | 23,787 |  |  | $ | (52,881 | ) |  | $ | 12,321 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 967 |  |  | $ | 20 |  |  | $ | — |  |  | $ | 987 |  |
| Accounts payable | 1 |  |  | — |  |  | — |  |  | 763 |  |  | — |  |  | 764 |  |
| Accrued and other current liabilities | 88 |  |  | — |  |  | 61 |  |  | 1,495 |  |  | — |  |  | 1,644 |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 379 |  |  | — |  |  | 379 |  |
| Intercompany payables | 3,616 |  |  | — |  |  | 2,892 |  |  | 347 |  |  | (6,855 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 80 |  |  | — |  |  | 80 |  |
| Total Current Liabilities | 3,705 |  |  | — |  |  | 3,920 |  |  | 3,084 |  |  | (6,855 | ) |  | 3,854 |  |
| Long-term debt | — |  |  | — |  |  | 2,158 |  |  | 1 |  |  | — |  |  | 2,159 |  |
| Intercompany loans payable | 3,155 |  |  | — |  |  | 1,911 |  |  | 2,942 |  |  | (8,008 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 302 |  |  | — |  |  | 302 |  |
| Other liabilities | — |  |  | — |  |  | 245 |  |  | 1,685 |  |  | — |  |  | 1,930 |  |
| Total Liabilities | 6,860 |  |  | — |  |  | 8,234 |  |  | 8,014 |  |  | (14,863 | ) |  | 8,245 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |  |  |
| Ordinary shares | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |
| Ordinary shares held in treasury | (3 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Other shareholders' equity | 4,040 |  |  | 11,140 |  |  | 11,140 |  |  | 15,738 |  |  | (38,018 | ) |  | 4,040 |  |
| Total Tyco Shareholders' Equity | 4,041 |  |  | 11,140 |  |  | 11,140 |  |  | 15,738 |  |  | (38,018 | ) |  | 4,041 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 35 |  |  | — |  |  | 35 |  |
| Total Equity | 4,041 |  |  | 11,140 |  |  | 11,140 |  |  | 15,773 |  |  | (38,018 | ) |  | 4,076 |  |
| Total Liabilities and Equity | $ | 10,901 |  |  | $ | 11,140 |  |  | $ | 19,374 |  |  | $ | 23,787 |  |  | $ | (52,881 | ) |  | $ | 12,321 |  |

[0000833444-16-000197:notes:83]
[same as prior period, unchanged from 0000833444-16-000172:notes:83]

[0000833444-16-000197:notes:84]
|  | TycoInternational plc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 216 |  |  | $ | — |  |  | $ | 775 |  |  | $ | (487 | ) |  | $ | — |  |  | $ | 504 |  |
| Net cash used in discontinued operating activities | — |  |  | — |  |  | — |  |  | (12 | ) |  | — |  |  | (12 | ) |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (209 | ) |  | — |  |  | (209 | ) |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | — |  |  | (320 | ) |  | — |  |  | (320 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | — |  |  | (17 | ) |  | — |  |  | (17 | ) |
| Divestiture of businesses, net of cash divested | — |  |  | — |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Net decrease in intercompany loans | — |  |  | — |  |  | 37 |  |  | — |  |  | (37 | ) |  | — |  |
| Increase in investment in subsidiaries | — |  |  | — |  |  | (5 | ) |  | — |  |  | 5 |  |  | — |  |
| Sales and maturities of investments including restricted investments | — |  |  | — |  |  | 7 |  |  | 19 |  |  | — |  |  | 26 |  |
| Purchases of investments including restricted investments | — |  |  | — |  |  | — |  |  | (8 | ) |  | — |  |  | (8 | ) |
| Decrease in restricted cash | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Net cash provided by (used in) investing activities | — |  |  | — |  |  | 39 |  |  | (518 | ) |  | (32 | ) |  | (511 | ) |
| Net cash provided by discontinued investing activities | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt | — |  |  | — |  |  | 4,179 |  |  | — |  |  | — |  |  | 4,179 |  |
| Repayment of short-term debt | — |  |  | — |  |  | (3,838 | ) |  | — |  |  | — |  |  | (3,838 | ) |
| Repayment of current portion of long-term debt | — |  |  | — |  |  | (1,134 | ) |  | — |  |  | — |  |  | (1,134 | ) |
| Proceeds from exercise of share options | 57 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 57 |  |
| Dividends paid | (261 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (261 | ) |
| Net intercompany loan repayments | — |  |  | — |  |  | — |  |  | (37 | ) |  | 37 |  |  | — |  |
| Increase in equity from parent | — |  |  | — |  |  | — |  |  | 5 |  |  | (5 | ) |  | — |  |
| Transfer to discontinued operations | — |  |  | — |  |  | — |  |  | (8 | ) |  | — |  |  | (8 | ) |
| Payment of contingent consideration | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Debt financing costs | — |  |  | — |  |  | (21 | ) |  | (2 | ) |  |  |  |  | (23 | ) |
| Other | (12 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (12 | ) |
| Net cash used in financing activities | (216 | ) |  | — |  |  | (814 | ) |  | (43 | ) |  | 32 |  |  | (1,041 | ) |
| Net cash provided by discontinued financing activities | — |  |  | — |  |  | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Effect of currency translation on cash | — |  |  | — |  |  | — |  |  | (8 | ) |  | — |  |  | (8 | ) |
| Net decrease in cash and cash equivalents | — |  |  | — |  |  | — |  |  | (1,056 | ) |  | — |  |  | (1,056 | ) |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | — |  |  | 1,401 |  |  | — |  |  | 1,401 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 345 |  |  | $ | — |  |  | $ | 345 |  |

[0000833444-16-000197:notes:85]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 94 |  |  | $ | — |  |  | $ | (525 | ) |  | $ | 942 |  |  | $ | — |  |  | $ | 511 |  |
| Net cash used in discontinued operating activities | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (183 | ) |  | — |  |  | (183 | ) |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | — |  |  | (525 | ) |  | — |  |  | (525 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | — |  |  | (13 | ) |  | — |  |  | (13 | ) |
| Divestiture of businesses, net of cash divested | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net increase in intercompany loans | — |  |  | — |  |  | (41 | ) |  | — |  |  | 41 |  |  | — |  |
| Sales and maturities of investments including restricted investments | — |  |  | — |  |  | 4 |  |  | 279 |  |  | — |  |  | 283 |  |
| Purchases of investments including restricted investments | — |  |  | — |  |  | (1 | ) |  | (289 | ) |  | — |  |  | (290 | ) |
| Increase in restricted cash | — |  |  | — |  |  | — |  |  | (27 | ) |  | — |  |  | (27 | ) |
| Other | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Net cash used in investing activities | — |  |  | — |  |  | (38 | ) |  | (755 | ) |  | 41 |  |  | (752 | ) |
| Net cash used in discontinued investing activities | — |  |  | — |  |  | — |  |  | (37 | ) |  | — |  |  | (37 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt | — |  |  | — |  |  | 258 |  |  | — |  |  | — |  |  | 258 |  |
| Repayment of short-term debt | — |  |  | — |  |  | (258 | ) |  | (1 | ) |  | — |  |  | (259 | ) |
| Proceeds from issuance of long-term debt | — |  |  | — |  |  | 567 |  |  | 3 |  |  | — |  |  | 570 |  |
| Proceeds from exercise of share options | 63 |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 70 |  |
| Dividends paid | (237 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (237 | ) |
| Repurchase of ordinary shares | — |  |  | — |  |  | — |  |  | (417 | ) |  | — |  |  | (417 | ) |
| Net intercompany loan borrowings | 83 |  |  | — |  |  | — |  |  | (42 | ) |  | (41 | ) |  | — |  |
| Transfer to discontinued operations | — |  |  | — |  |  | — |  |  | (38 | ) |  | — |  |  | (38 | ) |
| Payment of contingent consideration | — |  |  | — |  |  | — |  |  | (23 | ) |  | — |  |  | (23 | ) |
| Debt financing costs | — |  |  | — |  |  | (5 | ) |  | — |  |  | — |  |  | (5 | ) |
| Other | (3 | ) |  | — |  |  | 1 |  |  | (19 | ) |  | — |  |  | (21 | ) |
| Net cash (used in) provided by financing activities | (94 | ) |  | — |  |  | 563 |  |  | (530 | ) |  | (41 | ) |  | (102 | ) |
| Net cash provided by discontinued financing activities | — |  |  | — |  |  | — |  |  | 38 |  |  | — |  |  | 38 |  |
| Effect of currency translation on cash | — |  |  | — |  |  | — |  |  | (18 | ) |  | — |  |  | (18 | ) |
| Net decrease in cash and cash equivalents | — |  |  | — |  |  | — |  |  | (361 | ) |  | — |  |  | (361 | ) |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | — |  |  | 892 |  |  | — |  |  | 892 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 531 |  |  | $ | — |  |  | $ | 531 |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-16-000197:notes:86]
Debt

[0000833444-16-000197:notes:87]
The carrying value of the Company's debt as of June 24, 2016 and September 25, 2015 is as follows ($ in millions):

[0000833444-16-000197:notes:88]
|  | As of |
|  | June 24, 2016 |  | September 25, 2015 |
| Commercial paper(1) | $ | 341 |  |  | $ | — |  |
| 3.375% public notes due 2015(2) | — |  |  | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 7.0% public notes due 2019(2) | — |  |  | 245 |  |
| 6.875% public notes due 2021(2) | — |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 564 |  |  | 558 |  |
| 3.9% public notes due 2026 | 745 |  |  | 745 |  |
| 5.125% public notes due 2045 | 746 |  |  | 746 |  |
| Other (2) | 1 |  |  | 20 |  |
| Total debt | 2,506 |  |  | 3,146 |  |
| Less current portion | 341 |  |  | 987 |  |
| Long-term debt | $ | 2,165 |  |  | $ | 2,159 |  |

[0000833444-16-000197:notes:89]
_______________________________________________________________________________

[0000833444-16-000197:notes:90]
(1) The current portion of debt as of June 24, 2016 is comprised of $341 million of commercial paper.

[0000833444-16-000197:notes:91]
(2) The current portion of debt as of September 25, 2015 is comprised of $258 million notes due 2015, $245 million notes due 2019, $465 million notes due 2021 and $19 million of Other debt.

[0000833444-16-000197:notes:92]
Fair Value

[0000833444-16-000197:notes:93]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of June 24, 2016 and September 25, 2015 was $2,505 million and $3,126 million, respectively. The Company has determined the fair value of such debt to be $2,660 million and $3,291 million as of June 24, 2016 and September 25, 2015, respectively. The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets. As of June 24, 2016 and September 25, 2015, the fair value of the Company's debt which was actively traded was $2,319 million and $3,291 million, respectively. As of June 24, 2016 and September 25, 2015, the Company's debt that was subject to the fair value disclosure requirements and was actively traded is classified as Level 1 in the fair value hierarchy. Additionally, the Company believes the carrying amount of its commercial paper of $341 million as of June 24, 2016 approximates fair value based on the short-term nature of such debt.

[0000833444-16-000197:notes:94]
Fiscal 2016 Debt Repayment

[0000833444-16-000197:notes:95]
On September 14, 2015, the Company and the Company's wholly-owned subsidiary, Tyco International Finance S.A. ("TIFSA") announced the redemption of all of the outstanding $242 million aggregate principal amount of 7.0% notes due 2019 and $462 million aggregate principal amount of 6.875% notes due 2021. On October 14, 2015, TIFSA paid cash of $876 million to complete the redemption, resulting in a loss on extinguishment of $168 million which was recorded in Other expense, net within the Consolidated Statements of Operations during the first quarter of fiscal 2016. The charge is comprised of the make-whole premium of $172 million and the write-off of unamortized debt issuance costs of $1 million, partially offset by the write-off of the unamortized premium of $5 million.

[0000833444-16-000197:notes:96]
On October 15, 2015, the Company repaid $258 million aggregate principal amount of 3.375% notes which matured on such date.

[0000833444-16-000197:notes:97]
Financing in Connection with Proposed Merger with Johnson Controls

[0000833444-16-000197:notes:98]
On March 10, 2016, Tyco International Holding S.à r.l. ("TSARL"), an indirect wholly owned subsidiary of Tyco, entered into a Term Loan Credit Agreement with a syndicate of lenders providing for a senior unsecured term loan facility in the amount of $4 billion to finance the cash consideration for, and fees, expenses and costs incurred in connection with the Merger. Any borrowing under the Term Loan Credit Agreement is conditioned upon the closing of the Merger and will be made in a single borrowing on the closing date of the Merger and will have a maturity of 3.5 years and be denominated in U.S. dollars. See Note 1.

[0000833444-16-000197:notes:99]
In addition, on March 10, 2016, TSARL entered into a Multi-Year Senior Unsecured Credit Agreement providing for revolving credit commitments in the aggregate amount of $1 billion (the “Revolving Credit Agreement”). TSARL's ability to borrow under the Revolving Credit Agreement is subject to the satisfaction or waiver of customary conditions, including the consummation of the Merger, as well as the termination of the commitments of the lenders, and payments of any amounts outstanding, under TIFSA's existing $1.5 billion Amended and Restated Five-Year Senior Unsecured Credit Agreement dated as of August 7, 2015 (the "2015 Credit Agreement"). The Revolving Credit Agreement has a scheduled maturity date of August 7, 2020 and includes an option for TSARL to request an increase in the aggregate principal amount of the commitments, up to an additional $250 million.

[0000833444-16-000197:notes:100]
Credit Facilities

[0000833444-16-000197:notes:101]
On August 7, 2015, TIFSA entered into the 2015 Credit Agreement, which amended and restated TIFSA's existing $1 billion Five-Year Senior Unsecured Credit Agreement, dated June 22, 2012 (the “2012 Credit Agreement”). The 2015 Credit Agreement will be terminated upon completion of the Merger and replaced with the Revolving Credit Agreement discussed above.

[0000833444-16-000197:notes:102]
As of June 24, 2016, the Company's total committed revolving credit facilities totaled $1.5 billion. The Company's revolving credit facilities may be used for working capital, capital expenditures and general corporate purposes. As of June 24, 2016 and September 25, 2015, there were no amounts drawn under the Company's revolving credit facilities. Interest under the revolving credit facilities is variable and is calculated by reference to LIBOR or an alternate base rate.

[0000833444-16-000197:notes:103]
TIFSA's revolving credit facilities contain customary terms and conditions, and financial covenants that limit the ratio of the Company's debt to earnings before interest, taxes, depreciation, and amortization and that limit our ability to incur subsidiary debt or grant liens on its property. The indentures governing the Company's public notes contain customary covenants including limits on negative pledges, subsidiary debt and sale/leaseback transactions. None of these covenants are considered restrictive to the Company's business.

[0000833444-16-000197:notes:104]
Commercial Paper

[0000833444-16-000197:notes:105]
From time to time, TIFSA may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1.5 billion as of June 24, 2016. As of June 24, 2016 and September 25, 2015, TIFSA had $341 million and nil of commercial paper outstanding, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-16-000197:notes:106]
[same as prior period, unchanged from 0000833444-16-000172:notes:106]

[0000833444-16-000197:notes:107]
[same as prior period, unchanged from 0000833444-16-000172:notes:107]

[0000833444-16-000197:notes:108]
[same as prior period, unchanged from 0000833444-16-000172:notes:108]

[0000833444-16-000197:notes:109]
[same as prior period, unchanged from 0000833444-16-000172:notes:109]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-16-000197:notes:110]
[same as prior period, unchanged from 0000833444-16-000172:notes:110]

[0000833444-16-000197:notes:111]
[same as prior period, unchanged from 0000833444-16-000172:notes:111]

[0000833444-16-000197:notes:112]
[same as prior period, unchanged from 0000833444-16-000172:notes:112]

[0000833444-16-000197:notes:113]
During the third quarter of fiscal 2016, the Company concluded that a business in the ROW Integrated Solutions & Services segment which it intends to sell met the criteria to be classified as held for sale. The assets and liabilities of this business have been presented separately as held for sale within the Consolidated Balance Sheets for all periods presented.  A pre-tax loss of approximately $59 million for the write-down to fair value, less cost to sell, was recorded in Selling, general and administrative expenses within the Company's Consolidated Statements of Operations for the quarter and nine months ended June 24, 2016.  This business has not been presented in discontinued operations within the Consolidated Statements of Operations, as the criteria to be presented as a discontinued operation were not satisfied.

[0000833444-16-000197:notes:114]
During the second quarter of fiscal 2016, the Company completed the sale of its Australian fire protection business, included within its ROW Integrated Solutions & Services segment. The assets and liabilities of this business have been presented separately as held for sale within the Consolidated Balance Sheets as of September 25, 2015. The Company recorded a pre-tax loss of $74 million related to the sale for the nine months ended June 24, 2016. This loss included a $57 million write-down to fair value, less costs to sell, which was recorded during the first quarter of fiscal 2016. Also included in the loss for the nine month period was the write-off of a cumulative translation loss of $30 million. This business has not been presented in discontinued operations within the Consolidated Statements of Operations, as the criteria to be presented as a discontinued operation were not satisfied.

[0000833444-16-000197:notes:115]
[same as prior period, unchanged from 0000833444-16-000172:notes:114]

[0000833444-16-000197:notes:116]
In addition, during the second quarter of fiscal 2016, the Company completed the sale of another business within the ROW Integrated Solutions & Services segment and realized a loss that was not material. This business is accounted for as held for sale within the Consolidated Balance Sheets as of September 25, 2015, and its results of operations have been presented as discontinued operations within the Consolidated Statements of Operations for the nine months ended June 24, 2016 and the quarter and nine months ended June 26, 2015.

[0000833444-16-000197:notes:117]
[same as prior period, unchanged from 0000833444-16-000172:notes:116]

[0000833444-16-000197:notes:118]
[same as prior period, unchanged from 0000833444-16-000172:notes:117]

[0000833444-16-000197:notes:119]
During the third quarter of fiscal 2015, the Company completed the sale of several businesses in the ROW Integrated Solutions & Services segment, and recorded a loss on sale of $29 million and $28 million in (Loss) income from discontinued operations, net of taxes within the Consolidated Statements of Operations for the quarter and nine months ended June 26, 2015, respectively.  The results of operations of these businesses have been presented within discontinued operations on the Consolidated Statements of Operations during the quarter and nine months ended June 26, 2015.

[0000833444-16-000197:notes:120]
In addition, during the third quarter of fiscal 2015, the Company completed the sale of another business in the ROW Integrated Solutions & Services segment.  The Company recorded $22 million in Selling, general and administrative expenses within the Consolidated Statements of Operations for an anticipated loss on disposal during the quarter ended March 27, 2015.  This business did not meet the criteria to be classified as a discontinued operation, and thus its results of operations were included in continuing operations in the Consolidated Financial Statements.

[0000833444-16-000197:notes:121]
[same as prior period, unchanged from 0000833444-16-000172:notes:119]

[0000833444-16-000197:notes:122]
During the third quarter of fiscal 2016, the Company recorded a net loss of $38 million in Selling, general and administrative expenses within the Company's Consolidated Statements of Operations, primarily related to the loss on anticipated sale of a business in the ROW Integrated Solutions & Services segment, as described above, partially offset by a $14 million gain related to the reversal of an indemnification reserve for a previously divested business. The Company recorded a net gain of $4 million during the third quarter of fiscal 2015, related to a business in the ROW Integrated Solutions & Services segment in Selling, general and administrative expenses within the Company's Consolidated Statements of Operations.

[0000833444-16-000197:notes:123]
During the nine months ended June 24, 2016, the Company recorded a net loss of $107 million in Selling, general and administrative expenses within the Company's Consolidated Statements of Operations, primarily due to the third quarter of fiscal 2016 items as described above, in addition to the loss on sale of its Australian fire protection business. During the nine months ended June 26, 2015, the Company recorded a net loss of $19 million in Selling, general and administrative expenses within the Company's Consolidated Statements of Operations, related to several businesses in the ROW Integrated Solutions & Services segment.

[0000833444-16-000197:notes:124]
[same as prior period, unchanged from 0000833444-16-000172:notes:122]

[0000833444-16-000197:notes:125]
The components of (loss) income from discontinued operations, net of income taxes are as follows ($ in millions):

[0000833444-16-000197:notes:126]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Net revenue | $ | — |  |  | $ | 5 |  |  | $ | 1 |  |  | $ | 15 |  |
| Pre-tax loss from discontinued operations | — |  |  | (3 | ) |  | (2 | ) |  | (12 | ) |
| Pre-tax (loss) gain on sale of discontinued operations | (1 | ) |  | (29 | ) |  | 16 |  |  | (28 | ) |
| Income tax expense (1) | (1 | ) |  | — |  |  | (11 | ) |  | (10 | ) |
| (Loss) income from discontinued operations, net of income taxes | $ | (2 | ) |  | $ | (32 | ) |  | $ | 3 |  |  | $ | (50 | ) |

[0000833444-16-000197:notes:127]
(1)  Income tax expense for the nine months ended June 24, 2016 includes $14 million related to the Company’s settlement of income tax matters pertaining to its divested ADT Korea business. These matters are unrelated to the liability established of $212 million during fiscal 2014 which relates to the indemnification for certain tax related matters in connection with the sale. The Company continues to maintain such liability until the matter is resolved.

[0000833444-16-000197:notes:128]
Balance sheet information for the assets and liabilities of businesses classified as held for sale as of June 24, 2016 and September 25, 2015 was as follows ($ in millions):

[0000833444-16-000197:notes:129]
|  | As of |  | As of |
|  | June 24, 2016 |  | September 25, 2015 |
| Accounts receivable, net | $ | 9 |  |  | $ | 54 |  |
| Inventories | 6 |  |  | 8 |  |
| Prepaid expenses and other current assets | 6 |  |  | 26 |  |
| Deferred income taxes | — |  |  | 1 |  |
| Property, plant and equipment, net | 13 |  |  | 24 |  |
| Goodwill | — |  |  | 34 |  |
| Intangible assets, net | 33 |  |  | 57 |  |
| Other assets | 4 |  |  | 4 |  |
| Total assets | $ | 71 |  |  | $ | 208 |  |
| Accounts payable | 12 |  |  | 22 |  |
| Accrued and other current liabilities | 19 |  |  | 43 |  |
| Deferred revenue | 3 |  |  | 5 |  |
| Other liabilities | — |  |  | 10 |  |
| Total liabilities | $ | 34 |  |  | $ | 80 |  |

[0000833444-16-000197:notes:130]
[same as prior period, unchanged from 0000833444-16-000172:notes:128]


## us-gaap:EarningsPerShareTextBlock

[0000833444-16-000197:notes:131]
[same as prior period, unchanged from 0000833444-16-000172:notes:129]

[0000833444-16-000197:notes:132]
[same as prior period, unchanged from 0000833444-16-000172:notes:130]

[0000833444-16-000197:notes:133]
|  | For the Quarter Ended June 24, 2016 |  | For the Quarter Ended June 26, 2015 |
|  | Income |  | Shares |  | Per ShareAmount |  | Income |  | Shares |  | Per ShareAmount |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 241 |  |  | 426 |  |  | $ | 0.57 |  |  | $ | 188 |  |  | 421 |  |  | $ | 0.45 |  |
| Share options and restricted share awards |  |  |  | 3 |  |  |  |  | — |  |  | 6 |  |  |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations attributable to Tyco ordinary shareholders, giving effect to dilutive adjustments | $ | 241 |  |  | 429 |  |  | $ | 0.56 |  |  | $ | 188 |  |  | 427 |  |  | $ | 0.44 |  |

[0000833444-16-000197:notes:134]
|  | For the Nine Months Ended June 24, 2016 |  | For the Nine Months Ended June 26, 2015 |
|  | Income |  | Shares |  | Per ShareAmount |  | Income |  | Shares |  | Per ShareAmount |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 458 |  |  | 425 |  |  | $ | 1.08 |  |  | $ | 535 |  |  | 421 |  |  | $ | 1.27 |  |
| Share options and restricted share awards |  |  |  | 3 |  |  |  |  | — |  |  | 6 |  |  |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations attributable to Tyco ordinary shareholders, giving effect to dilutive adjustments | $ | 458 |  |  | 428 |  |  | $ | 1.07 |  |  | $ | 535 |  |  | 427 |  |  | $ | 1.25 |  |

[0000833444-16-000197:notes:135]
The computation of diluted earnings per share for the quarter and nine months ended June 24, 2016 excludes the effect of the potential exercise of share options to purchase approximately 6 million shares for both periods and excludes restricted stock units of approximately 2 million shares for both periods because the effect would be anti-dilutive.

[0000833444-16-000197:notes:136]
The computation of diluted earnings per share for the quarter and nine months ended June 26, 2015 excludes the effect of the potential exercise of share options to purchase approximately 3 million shares for both periods and excludes restricted stock units of approximately 1 million and 2 million shares, respectively, for the quarter and nine months ended June 26, 2015 because the effect would be anti-dilutive.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000833444-16-000197:notes:137]
The following table presents the Company's hierarchy for its assets measured at fair value on a recurring basis as of June 24, 2016 and September 25, 2015 ($ in millions):

[0000833444-16-000197:notes:138]
|  |  |  |  |  |  |  | Consolidated Balance SheetClassification |
|  | As of June 24, 2016 |  | Cash and Cash Equivalents |  | Prepaid Expenses andOther CurrentAssets |  | Other Assets |
| Investment Assets: | Level 1 |  | Level 2 |  | Total |  |  |  |
| Cash equivalents | $ | 81 |  |  | $ | — |  |  | $ | 81 |  |  | $ | 81 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (fixed income) (1) | 176 |  |  | — |  |  | 176 |  |  | — |  |  | 15 |  |  | 161 |  |
| Exchange traded funds (equity) (1) | 81 |  |  | — |  |  | 81 |  |  | — |  |  | — |  |  | 81 |  |
| Trading securities: |  |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (equity) | 55 |  |  | — |  |  | 55 |  |  | — |  |  | 55 |  |  | — |  |
|  | $ | 393 |  |  | $ | — |  |  | $ | 393 |  |  | $ | 81 |  |  | $ | 70 |  |  | $ | 242 |  |

[0000833444-16-000197:notes:139]
|  |  |  |  |  |  |  | Consolidated Balance SheetClassification |
|  | As of September 25, 2015 |  | Cash and Cash Equivalents |  | Prepaid Expenses andOther CurrentAssets |  | Other Assets |
| Investment Assets: | Level 1 |  | Level 2 |  | Total |  |  |  |
| Cash equivalents | $ | 909 |  |  | $ | — |  |  | $ | 909 |  |  | $ | 909 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (fixed income) (1) | 186 |  |  | — |  |  | 186 |  |  | — |  |  | 15 |  |  | 171 |  |
| Exchange traded funds (equity) (1) | 77 |  |  | — |  |  | 77 |  |  | — |  |  | — |  |  | 77 |  |
| Trading securities: |  |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (equity) | 59 |  |  | — |  |  | 59 |  |  | — |  |  | 59 |  |  | — |  |
|  | $ | 1,231 |  |  | $ | — |  |  | $ | 1,231 |  |  | $ | 909 |  |  | $ | 74 |  |  | $ | 248 |  |

[0000833444-16-000197:notes:140]
[same as prior period, unchanged from 0000833444-16-000172:notes:138]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000833444-16-000197:notes:141]
[same as prior period, unchanged from 0000833444-16-000172:notes:139]

[0000833444-16-000197:notes:142]
The Company's financial instruments consist primarily of cash and cash equivalents, accounts receivable, investments, accounts payable, debt and derivative financial instruments. The fair value of cash, accounts receivable, and accounts payable approximated book value as of June 24, 2016 and September 25, 2015. The fair value of derivative financial instruments was not material to any of the periods presented. See below for the fair value of cash equivalents and investments and Note 9 for the fair value of debt.

[0000833444-16-000197:notes:143]
[same as prior period, unchanged from 0000833444-16-000172:notes:141]

[0000833444-16-000197:notes:144]
In the normal course of business, Tyco is exposed to market risk arising from changes in currency exchange rates, interest rates and commodity prices. The Company may use derivative financial instruments to manage exposures to foreign currency, interest rate and commodity risks. The Company's objective for utilizing derivative financial instruments is to manage these risks using the most effective methods to eliminate or reduce the impacts of these exposures. The Company does not use derivative financial instruments for trading or speculative purposes. As of and during the nine months ended June 24, 2016, the Company did not hold or enter into any commodity derivative instruments or interest rate swaps.

[0000833444-16-000197:notes:145]
For derivative instruments that are designated and qualified as hedging instruments for accounting purposes, the Company documents and links the relationships between the hedging instruments and hedged items.  The Company also assesses and documents at the hedge's inception whether the derivatives used in hedging transactions are effective in offsetting changes in fair values associated with the hedged items. During the quarter ended March 27, 2015, the Company designated its 2025 Euro notes as a net investment hedge of the Company’s investments in certain of its international subsidiaries that use the Euro as their functional currency and intercompany permanent loans in order to reduce the volatility caused by changes in foreign currency exchange rates of the Euro with respect to the U.S. Dollar. During both the quarter and nine months ended June 24, 2016, the change in the carrying value due to remeasurement of the 2025 Euro notes resulted in a net loss of $6 million reported in Accumulated other comprehensive loss within the Consolidated Statement of Shareholders' Equity. During the quarter and nine months ended June 26, 2015, the change in the carrying value due to remeasurement of the 2025 Euro notes resulted in a $12 million loss and an $8 million gain, respectively, reported in Accumulated other comprehensive loss on the Consolidated Balance Sheet. This hedge did not result in any hedge ineffectiveness for the quarters and nine months ended June 24, 2016 and June 26, 2015.

[0000833444-16-000197:notes:146]
[same as prior period, unchanged from 0000833444-16-000172:notes:144]

[0000833444-16-000197:notes:147]
As of June 24, 2016 and September 25, 2015, the total gross notional amount of the Company's foreign exchange contracts was $614 million and $365 million, respectively. The fair value of these derivative financial instruments and impact of such changes in the fair value was not material to the Consolidated Balance Sheets as of June 24, 2016 and September 25, 2015 or Consolidated Statements of Operations and Consolidated Statements of Cash Flows for the quarters and nine months ended June 24, 2016 and June 26, 2015.

[0000833444-16-000197:notes:148]
[same as prior period, unchanged from 0000833444-16-000172:notes:146]

[0000833444-16-000197:notes:149]
The use of derivative financial instruments exposes the Company to counterparty credit risk.  Tyco has established policies and procedures to limit its exposure to counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association master netting agreements with substantially all of its counterparties.  The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties.  The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes.  The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company. The maximum amount of loss that the Company would incur as of June 24, 2016 without giving consideration to the effects of legally enforceable master netting agreements was not material.

[0000833444-16-000197:notes:150]
[same as prior period, unchanged from 0000833444-16-000172:notes:148]

[0000833444-16-000197:notes:151]
[same as prior period, unchanged from 0000833444-16-000172:notes:149]

[0000833444-16-000197:notes:152]
[same as prior period, unchanged from 0000833444-16-000172:notes:150]

[0000833444-16-000197:notes:153]
[same as prior period, unchanged from 0000833444-16-000172:notes:151]

[0000833444-16-000197:notes:154]
[same as prior period, unchanged from 0000833444-16-000172:notes:152]

[0000833444-16-000197:notes:155]
During the quarters ended June 24, 2016 and June 26, 2015, the Company did not have any significant transfers between levels within the fair value hierarchy.

[0000833444-16-000197:notes:156]
The Company recorded unrealized gains related to available-for-sale securities of $4 million and unrealized losses of $6 million for the quarters ended June 24, 2016 and June 26, 2015, respectively, and unrealized gains of $9 million and unrealized losses of $6 million for the nine months ended June 24, 2016 and June 26, 2015, respectively, within Accumulated other comprehensive loss.

[0000833444-16-000197:notes:157]
Unrealized gains related to trading securities were nil and $1 million for the quarters ended June 24, 2016 and June 26, 2015, respectively. Unrealized gains were $2 million and $5 million for the nine months ended June 24, 2016 and June 26, 2015, respectively, which are recorded within Other income (expense), net within the Consolidated Statements of Operations.

[0000833444-16-000197:notes:158]
[same as prior period, unchanged from 0000833444-16-000172:notes:156]

[0000833444-16-000197:notes:159]
The Company had $1.3 billion and $1.4 billion of intercompany loans designated as permanent in nature as of June 24, 2016 and September 25, 2015, respectively.  Additionally, for the quarters ended June 24, 2016 and June 26, 2015, the Company recorded cumulative translation losses of $9 million and gains of $40 million, respectively, through Accumulated other comprehensive loss related to these loans. For the nine months ended June 24, 2016 and June 26, 2015, the Company recorded cumulative translation losses of $68 million and $105 million, respectively, through Accumulated other comprehensive loss related to these loans.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-16-000197:notes:160]
[same as prior period, unchanged from 0000833444-16-000172:notes:158]

[0000833444-16-000197:notes:161]
[same as prior period, unchanged from 0000833444-16-000172:notes:159]

[0000833444-16-000197:notes:162]
[same as prior period, unchanged from 0000833444-16-000172:notes:160]

[0000833444-16-000197:notes:163]
|  | NA Integrated Solutions &Services |  | ROWIntegrated Solutions &Services |  | GlobalProducts |  | Total |
| Gross goodwill | $ | 2,102 |  |  | $ | 1,938 |  |  | $ | 1,809 |  |  | $ | 5,849 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 26, 2014 | 1,976 |  |  | 870 |  |  | 1,242 |  |  | 4,088 |  |
| 2015 activity: |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions / purchase accounting adjustments | 23 |  |  | 50 |  |  | 274 |  |  | 347 |  |
| Currency translation | (29 | ) |  | (167 | ) |  | (36 | ) |  | (232 | ) |
| Gross goodwill | $ | 2,096 |  |  | $ | 1,821 |  |  | $ | 2,047 |  |  | $ | 5,964 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 25, 2015 | 1,970 |  |  | 753 |  |  | 1,480 |  |  | 4,203 |  |
| 2016 activity: |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions / purchase accounting adjustments | 73 |  |  | 161 |  |  | 5 |  |  | 239 |  |
| Currency translation | 5 |  |  | (23 | ) |  | (6 | ) |  | (24 | ) |
| Gross goodwill | $ | 2,174 |  |  | $ | 1,959 |  |  | $ | 2,046 |  |  | $ | 6,179 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of June 24, 2016 | $ | 2,048 |  |  | $ | 891 |  |  | $ | 1,479 |  |  | $ | 4,418 |  |

[0000833444-16-000197:notes:164]
[same as prior period, unchanged from 0000833444-16-000172:notes:162]

[0000833444-16-000197:notes:165]
The following table sets forth the gross carrying amount and accumulated amortization of the Company's intangible assets as of June 24, 2016 and September 25, 2015 ($ in millions):

[0000833444-16-000197:notes:166]
|  | As of |
|  | June 24, 2016 |  | September 25, 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Amortizable: |  |  |  |  |  |  |  |
| Contracts and related customer relationships | $ | 1,266 |  |  | $ | 960 |  |  | $ | 1,167 |  |  | $ | 918 |  |
| Intellectual property | 879 |  |  | 528 |  |  | 760 |  |  | 496 |  |
| Other | 8 |  |  | 5 |  |  | 7 |  |  | 4 |  |
| Total | $ | 2,153 |  |  | $ | 1,493 |  |  | $ | 1,934 |  |  | $ | 1,418 |  |
| Non-Amortizable: |  |  |  |  |  |  |  |
| Intellectual property | $ | 211 |  |  |  |  |  | $ | 210 |  |  |  |
| Franchise rights | 76 |  |  |  |  |  | 76 |  |  |  |
| In-process research and development | 19 |  |  |  |  | 20 |  |  |  |
| Total | $ | 306 |  |  |  |  |  | $ | 306 |  |  |  |

[0000833444-16-000197:notes:167]
Intangible asset amortization expense for the quarters ended June 24, 2016 and June 26, 2015 was $25 million and $24 million, respectively. Intangible asset amortization expense for the nine months ended June 24, 2016 and June 26, 2015 was $73 million and $65 million, respectively.

[0000833444-16-000197:notes:168]
The estimated aggregate amortization expense on intangible assets is expected to be approximately $26 million for the remainder of 2016, $94 million for 2017, $88 million for 2018, $83 million for 2019, and $369 million for 2020 and thereafter.


## us-gaap:GuaranteesTextBlock

[0000833444-16-000197:notes:169]
[same as prior period, unchanged from 0000833444-16-000172:notes:165]

[0000833444-16-000197:notes:170]
[same as prior period, unchanged from 0000833444-16-000172:notes:166]

[0000833444-16-000197:notes:171]
[same as prior period, unchanged from 0000833444-16-000172:notes:167]

[0000833444-16-000197:notes:172]
In addition, Tyco historically provided support in the form of financial and/or performance guarantees to various Covidien, TE Connectivity, ADT and Tyco Flow Control operating entities. In connection with both the 2012 and 2007 Separations, the Company worked with the guarantee counterparties to cancel or assign these guarantees to Covidien, TE Connectivity, ADT or Pentair, as appropriate. To the extent these guarantees were not assigned prior to the Separation dates, Tyco remained as the guarantor, but was typically indemnified by the former subsidiary. The Company's obligations related to the 2012 Separation were $3 million, which were included in Other liabilities within the Company's Consolidated Balance Sheets as of both June 24, 2016 and September 25, 2015, with an offset to Tyco's shareholders' equity on the 2012 Separation date. The Company's obligations related to the 2007 Separation were $3 million, which were included in Other liabilities within the Company's Consolidated Balance Sheets as of both June 24, 2016 and September 25, 2015, with an offset to Tyco's shareholders' equity on the 2007 Separation date.

[0000833444-16-000197:notes:173]
In disposing of assets or businesses, the Company or its subsidiaries often provides representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities and unidentified tax liabilities and legal fees related to periods prior to disposition. The Company has no reason to believe that these contingencies, if realized, would have a material adverse effect on the Company's financial position, results of operations or cash flows. The Company has recorded liabilities for known indemnifications included as part of environmental liabilities. See Note 11 for further information on environmental matters.

[0000833444-16-000197:notes:174]
[same as prior period, unchanged from 0000833444-16-000172:notes:170]

[0000833444-16-000197:notes:175]
The changes in the carrying amount of the Company's warranty accrual from September 25, 2015 to June 24, 2016 were as follows ($ millions):

[0000833444-16-000197:notes:176]
| Balance as of September 25, 2015 | $ | 29 |  |
| Warranties issued | 6 |  |
| Changes in estimates | (2 | ) |
| Settlements | (3 | ) |
| Balance as of June 24, 2016 | $ | 30 |  |

[0000833444-16-000197:notes:177]
Warranty accruals for businesses that are included in Liabilities held for sale within the Consolidated Balance Sheets are excluded from the table above. See Note 3.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-16-000197:notes:178]
[same as prior period, unchanged from 0000833444-16-000172:notes:174]

[0000833444-16-000197:notes:179]
Tyco did not have a significant change to its unrecognized tax benefits during the quarter ended June 24, 2016.

[0000833444-16-000197:notes:180]
[same as prior period, unchanged from 0000833444-16-000172:notes:176]

[0000833444-16-000197:notes:181]
| Jurisdiction | Years OpenTo Audit |
| Australia | 2008-2015 |
| Canada | 2007-2015 |
| Germany | 2006-2015 |
| Ireland | 2011-2015 |
| Switzerland | 2006-2015 |
| United Kingdom | 2013-2015 |
| United States | 2008-2015 |

[0000833444-16-000197:notes:182]
[same as prior period, unchanged from 0000833444-16-000172:notes:178]

[0000833444-16-000197:notes:183]
At each balance sheet date, the Company evaluates whether it is more likely than not that Tyco's deferred tax assets will be realized and if sufficient future taxable income will be available by assessing current period and projected operating results and other pertinent data. As of June 24, 2016, Tyco recorded deferred tax assets of approximately $182 million, which is comprised of $2.3 billion gross deferred tax assets net of $2.1 billion valuation allowances.

[0000833444-16-000197:notes:184]
[same as prior period, unchanged from 0000833444-16-000172:notes:180]

[0000833444-16-000197:notes:185]
In connection with the 2012 and 2007 Separations, Tyco entered into the 2012 and 2007 Tax Sharing Agreements, respectively, that govern the respective rights, responsibilities, and obligations of (i) Tyco, Pentair plc and ADT Corporation after the 2012 Separation and (ii) Tyco, Covidien plc (subsequently acquired by Medtronic plc) and TE Connectivity Ltd. after the 2007 Separation, with respect to taxes. Specifically, this includes taxes in the ordinary course of business and taxes, if any, incurred as a result of any failure of the respective distributions to qualify tax-free for U.S. federal income tax purposes within the meaning of Section 355 of the Internal Revenue Code ("the Code") or certain internal transactions undertaken in anticipation of the spin-offs to qualify for tax-favored treatment under the Code.

[0000833444-16-000197:notes:186]
[same as prior period, unchanged from 0000833444-16-000172:notes:182]

[0000833444-16-000197:notes:187]
[same as prior period, unchanged from 0000833444-16-000172:notes:183]

[0000833444-16-000197:notes:188]
[same as prior period, unchanged from 0000833444-16-000172:notes:184]

[0000833444-16-000197:notes:189]
In addition to dealing with tax liabilities for periods prior to the respective Separations, the 2012 and 2007 Tax Sharing Agreements contain sharing provisions to address the contingencies that the 2012 or 2007 Separations, or internal transactions related thereto, may be deemed taxable by U.S. or non U.S. taxing authorities. In the event the 2012 Separation is determined to be taxable and such determination was the result of actions taken after the 2012 Separations by Tyco, ADT or Pentair, the party responsible for such failure would be responsible for all taxes imposed on each company as a result thereof. If such determination is not the result of actions taken by Tyco, ADT or Pentair after the 2012 Separation, then Tyco, ADT and Pentair would be responsible for any taxes imposed on any of the companies as a result of such determination in the same manner and in the same proportions as described above. Similar provisions exist in the 2007 Tax Sharing Agreement. If either of the 2007 or 2012 Separation, or internal transactions taken in anticipation thereof, were deemed taxable, the associated liability could be significant. Tyco is responsible for all of its own taxes that are not shared pursuant to the 2012 and 2007 Tax Sharing Agreements' sharing formulas. In addition, Pentair and ADT, and Covidien and TE Connectivity are responsible for their tax liabilities that are not subject to the 2012 or 2007 Tax Sharing Agreements' sharing formula.

[0000833444-16-000197:notes:190]
[same as prior period, unchanged from 0000833444-16-000172:notes:188]

[0000833444-16-000197:notes:191]
In addition to the amounts above, pursuant to the terms of the 2012 Separation and Distribution Agreement, Tyco, ADT and Pentair are each responsible for issuing their own shares upon employee exercise of a stock option award or vesting of a restricted unit award. However, the 2012 Tax Sharing Agreement provides that any allowable compensation tax deduction for such awards is to be claimed by the employee's current employer. The 2012 Tax Sharing Agreement requires the employer claiming a tax deduction for shares issued by the other companies to pay a percentage of the allowable tax deduction to the company issuing the equity. During the quarter ended June 24, 2016, Tyco made a $1 million net payment to ADT in connection with deductions claimed for ADT shares issued to Company employees. During the nine months ended June 24, 2016, Tyco made a $15 million net payment to Pentair and a $2 million net payment to ADT in connection with deductions claimed for Pentair and ADT shares issued to Company employees. Payments made to Pentair and ADT for the quarter and nine months ended June 26, 2015 were not material.

[0000833444-16-000197:notes:192]
[same as prior period, unchanged from 0000833444-16-000172:notes:190]

[0000833444-16-000197:notes:193]
[same as prior period, unchanged from 0000833444-16-000172:notes:191]


## us-gaap:InventoryDisclosureTextBlock

[0000833444-16-000197:notes:194]
[same as prior period, unchanged from 0000833444-16-000172:notes:192]

[0000833444-16-000197:notes:195]
[same as prior period, unchanged from 0000833444-16-000172:notes:193]

[0000833444-16-000197:notes:196]
|  | As of |
|  | June 24, 2016 |  | September 25, 2015 |
| Purchased materials and manufactured parts | $ | 181 |  |  | $ | 165 |  |
| Work in process | 79 |  |  | 83 |  |
| Finished goods | 396 |  |  | 372 |  |
| Inventories | $ | 656 |  |  | $ | 620 |  |

[0000833444-16-000197:notes:197]
[same as prior period, unchanged from 0000833444-16-000172:notes:195]


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-16-000197:notes:198]
Merger Costs

[0000833444-16-000197:notes:199]
On January 24, 2016, Tyco entered into a Merger Agreement with Johnson Controls. See Note 1. The Company expects to incur transaction related costs ("Merger Costs") in connection with activities taken in anticipation of the Merger, primarily related to financing, investment banking, advisory, legal, valuation, and other professional fees, and retention related costs for certain Tyco employees. The Company incurred pre-tax merger costs within continuing operations of $19 million and $45 million during the quarter and nine months ended June 24, 2016, respectively, primarily related to financing, advisory and professional fees. The Company received no tax benefits during the quarter and nine months ended June 24, 2016 related to these charges.  The Company did not incur merger costs during the nine months ended June 26, 2015.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-16-000197:notes:200]
[same as prior period, unchanged from 0000833444-16-000172:notes:197]

[0000833444-16-000197:notes:201]
[same as prior period, unchanged from 0000833444-16-000172:notes:198]

[0000833444-16-000197:notes:202]
|  | U.S. Plans |
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Service cost | $ | 2 |  |  | $ | 2 |  |  | $ | 6 |  |  | $ | 6 |  |
| Interest cost | 8 |  |  | 9 |  |  | 24 |  |  | 27 |  |
| Expected return on plan assets | (12 | ) |  | (14 | ) |  | (36 | ) |  | (42 | ) |
| Amortization of net actuarial loss | 3 |  |  | 3 |  |  | 9 |  |  | 7 |  |
| Net periodic cost (benefit) | $ | 1 |  |  | $ | — |  |  | $ | 3 |  |  | $ | (2 | ) |

[0000833444-16-000197:notes:203]
|  | Non-U.S. Plans |
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Service cost | $ | 2 |  |  | $ | 2 |  |  | $ | 6 |  |  | $ | 7 |  |
| Interest cost | 11 |  |  | 14 |  |  | 32 |  |  | 40 |  |
| Expected return on plan assets | (18 | ) |  | (19 | ) |  | (53 | ) |  | (58 | ) |
| Amortization of net actuarial loss | 4 |  |  | 3 |  |  | 11 |  |  | 10 |  |
| Net periodic benefit | $ | (1 | ) |  | $ | — |  |  | $ | (4 | ) |  | $ | (1 | ) |

[0000833444-16-000197:notes:204]
[same as prior period, unchanged from 0000833444-16-000172:notes:201]

[0000833444-16-000197:notes:205]
[same as prior period, unchanged from 0000833444-16-000172:notes:202]

[0000833444-16-000197:notes:206]
[same as prior period, unchanged from 0000833444-16-000172:notes:203]

[0000833444-16-000197:notes:207]
During the quarter ended June 24, 2016, the Company made required contributions of $1 million to its U.S. pension plans and $3 million to its non-U.S. pension plans. During the nine months ended June 24, 2016, the Company made required contributions of $2 million to its U.S. pension plans and $16 million to its non-U.S. pension plans.  The Company did not make any voluntary contributions to its U.S. plans during the nine months ended June 24, 2016.  The Company made a voluntary contribution of nil and $4 million to its non-U.S. plans during the quarter and nine months ended June 24, 2016, respectively.

[0000833444-16-000197:notes:208]
[same as prior period, unchanged from 0000833444-16-000172:notes:205]


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-16-000197:notes:209]
[same as prior period, unchanged from 0000833444-16-000172:notes:206]

[0000833444-16-000197:notes:210]
[same as prior period, unchanged from 0000833444-16-000172:notes:207]

[0000833444-16-000197:notes:211]
|  | As of |
|  | June 24, 2016 |  | September 25, 2015 |
| Land | $ | 33 |  |  | $ | 33 |  |
| Buildings | 433 |  |  | 403 |  |
| Subscriber systems | 1,720 |  |  | 1,916 |  |
| Machinery and equipment | 1,279 |  |  | 1,234 |  |
| Construction in progress | 107 |  |  | 81 |  |
| Accumulated depreciation | (2,392 | ) |  | (2,501 | ) |
| Property, plant and equipment, net | $ | 1,180 |  |  | $ | 1,166 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000833444-16-000197:notes:212]
[same as prior period, unchanged from 0000833444-16-000172:notes:209]

[0000833444-16-000197:notes:213]
[same as prior period, unchanged from 0000833444-16-000172:notes:210]

[0000833444-16-000197:notes:214]
The Company recorded restructuring and asset impairment charges (income) by action as follows ($ in millions):

[0000833444-16-000197:notes:215]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| 2016 actions | $ | 6 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |
| 2015 actions | (1 | ) |  | 39 |  |  | — |  |  | 97 |  |
| 2014 and prior actions | — |  |  | (1 | ) |  | 1 |  |  | 11 |  |
| Total restructuring and asset impairment charges, net | $ | 5 |  |  | $ | 38 |  |  | $ | 22 |  |  | $ | 108 |  |
| Charges reflected in SG&A | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |
| Charges reflected in restructuring and asset impairments, net | 5 |  |  | 38 |  |  | 21 |  |  | 108 |  |

[0000833444-16-000197:notes:216]
[same as prior period, unchanged from 0000833444-16-000172:notes:213]

[0000833444-16-000197:notes:217]
Restructuring and asset impairment charges, net, during the quarter and nine months ended June 24, 2016 related to the 2016 actions are as follows ($ in millions):

[0000833444-16-000197:notes:218]
|  | For the Quarter Ended June 24, 2016 |
|  | EmployeeSeverance andBenefits |
| NA Integrated Solutions & Services | $ | 4 |  |
| ROW Integrated Solutions & Services | 1 |  |
| Global Products | 1 |  |
| Total | $ | 6 |  |

[0000833444-16-000197:notes:219]
|  | For the Nine Months Ended June 24, 2016 |
|  | EmployeeSeverance andBenefits |  | Facility Exit and Other Charges |  | Charges Reflected in SG&A |  | Total |
| NA Integrated Solutions & Services | $ | 6 |  |  | $ | — |  |  | $ | — |  |  | $ | 6 |  |
| ROW Integrated Solutions & Services | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Global Products | 5 |  |  | 1 |  |  | 1 |  |  | 7 |  |
| Corporate and Other | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Total | $ | 19 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 21 |  |

[0000833444-16-000197:notes:220]
The rollforward of the reserves from September 25, 2015 to June 24, 2016 is as follows ($ in millions):

[0000833444-16-000197:notes:221]
| Balance as of September 25, 2015 | $ | — |  |
| Charges | 22 |  |
| Reversals | (2 | ) |
| Utilization | (13 | ) |
| Balance as of June 24, 2016 | $ | 7 |  |

[0000833444-16-000197:notes:222]
[same as prior period, unchanged from 0000833444-16-000172:notes:219]

[0000833444-16-000197:notes:223]
Restructuring and asset impairment charges, net, during the quarters ended June 24, 2016 and June 26, 2015 and nine months ended June 26, 2015 related to the 2015 actions are as follows ($ in millions):

[0000833444-16-000197:notes:224]
|  | For the Quarter Ended June 24, 2016 |
|  | EmployeeSeverance andBenefits |
| NA Integrated Solutions & Services | $ | (1 | ) |
| Total | $ | (1 | ) |

[0000833444-16-000197:notes:225]
|  | For the Quarter Ended June 26, 2015 |
|  | EmployeeSeverance andBenefits |  | Facility Exit and Other Charges |  | Total |
| NA Integrated Solutions & Services | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| ROW Integrated Solutions & Services | 34 |  |  | 1 |  |  | 35 |  |
| Global Products | 1 |  |  | — |  |  | 1 |  |
| Corporate and Other | 2 |  |  | — |  |  | 2 |  |
| Total | $ | 38 |  |  | $ | 1 |  |  | $ | 39 |  |

[0000833444-16-000197:notes:226]
|  |  | For the Nine Months Ended June 26, 2015 |
|  |  | EmployeeSeverance andBenefits |  | Facility Exit and Other Charges |  | Total |
| NA Integrated Solutions & Services |  | $ | 27 |  |  | $ | — |  |  | $ | 27 |  |
| ROW Integrated Solutions & Services |  | 48 |  |  | 6 |  |  | 54 |  |
| Global Products |  | 4 |  |  | — |  |  | 4 |  |
| Corporate and Other |  | 12 |  |  | — |  |  | 12 |  |
| Total |  | $ | 91 |  |  | $ | 6 |  |  | $ | 97 |  |

[0000833444-16-000197:notes:227]
Restructuring and asset impairment charges (income), net, incurred cumulative to date from initiation of the 2015 actions are as follows ($ in millions):

[0000833444-16-000197:notes:228]
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Charges (Income) Reflected in SG&A |  | Total |
| NA Integrated Solutions & Services | $ | 41 |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | 45 |  |
| ROW Integrated Solutions & Services | 81 |  |  | 9 |  |  | 1 |  |  | 91 |  |
| Global Products | 21 |  |  | 1 |  |  | (1 | ) |  | 21 |  |
| Corporate and Other | 20 |  |  | 1 |  |  | — |  |  | 21 |  |
| Total | $ | 163 |  |  | $ | 14 |  |  | $ | 1 |  |  | $ | 178 |  |

[0000833444-16-000197:notes:229]
| Balance as of September 25, 2015 | $ | 117 |  |
| Charges | 8 |  |
| Reversals | (8 | ) |
| Utilization | (42 | ) |
| Balance as of June 24, 2016 | $ | 75 |  |

[0000833444-16-000197:notes:230]
[same as prior period, unchanged from 0000833444-16-000172:notes:227]

[0000833444-16-000197:notes:231]
[same as prior period, unchanged from 0000833444-16-000172:notes:228]

[0000833444-16-000197:notes:232]
The Company continues to maintain restructuring reserves related to actions initiated prior to fiscal 2015. The total amount of these reserves was $27 million and $38 million as of June 24, 2016 and September 25, 2015, respectively. The Company incurred nil of net restructuring charges and $1 million of net restructuring reversals for the quarters ended June 24, 2016 and June 26, 2015, respectively, related to 2014 and prior actions. The Company utilized $2 million and $9 million of restructuring reserves during the quarters ended June 24, 2016 and June 26, 2015, respectively. The Company incurred $1 million and $11 million of net restructuring charges and utilized $12 million and $38 million for the nine months ended June 24, 2016 and June 26, 2015, respectively, related to 2014 and prior actions. The aggregate remaining reserves relate to employee severance and benefits as well as facility exit costs for long-term non-cancelable lease obligations primarily within the Company's NA Integrated Solutions & Services and ROW Integrated Solutions & Services segments.

[0000833444-16-000197:notes:233]
[same as prior period, unchanged from 0000833444-16-000172:notes:230]

[0000833444-16-000197:notes:234]
As of June 24, 2016 and September 25, 2015, restructuring reserves related to all actions were included within the Company's Consolidated Balance Sheets as follows ($ in millions):

[0000833444-16-000197:notes:235]
|  | As of |
|  | June 24, 2016 |  | September 25, 2015 |
| Accrued and other current liabilities | $ | 96 |  |  | $ | 140 |  |
| Other liabilities | 13 |  |  | 15 |  |
| Total | $ | 109 |  |  | $ | 155 |  |

[0000833444-16-000197:notes:236]
[same as prior period, unchanged from 0000833444-16-000172:notes:231]

[0000833444-16-000197:notes:237]
The Company has initiated certain global actions designed to reduce its cost structure and improve future profitability by streamlining operations and better aligning functions, which the Company refers to as repositioning actions. These actions may or may not lead to a future restructuring action. During the quarters ended June 24, 2016 and June 26, 2015, the Company recorded net repositioning charges of $8 million and $27 million, respectively, and $19 million and $61 million for the nine months ended June 24, 2016 and June 26, 2015, respectively, primarily related to professional fees which have been reflected in Selling, general and administrative expenses within the Consolidated Statements of Operations.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-16-000197:notes:238]
A summary of the changes in each component of Accumulated other comprehensive loss, net of tax, for the nine months ended June 24, 2016 and June 26, 2015 are as follows ($ in millions):

[0000833444-16-000197:notes:239]
|  | CurrencyTranslationAdjustments |  | Unrealized (Loss) Gain onMarketableSecurities andDerivativeInstruments |  | RetirementPlans |  | Accumulated OtherComprehensive Loss |
| Balance as of September 25, 2015 | $ | (1,233 | ) |  | $ | (9 | ) |  | $ | (599 | ) |  | $ | (1,841 | ) |
| Other comprehensive (loss) income, net of tax | (21 | ) |  | 6 |  |  | — |  |  | (15 | ) |
| Amounts reclassified from accumulated other comprehensive income, net of tax | 28 |  |  | — |  |  | 13 |  |  | 41 |  |
| Net current period other comprehensive income | $ | 7 |  |  | $ | 6 |  |  | $ | 13 |  |  | $ | 26 |  |
| Balance as of June 24, 2016 | $ | (1,226 | ) |  | $ | (3 | ) |  | $ | (586 | ) |  | $ | (1,815 | ) |

[0000833444-16-000197:notes:240]
|  | CurrencyTranslationAdjustments |  | Unrealized Loss onMarketableSecurities andDerivativeInstruments |  | RetirementPlans |  | Accumulated OtherComprehensive Loss |
| Balance as of September 26, 2014 | $ | (693 | ) |  | $ | — |  |  | $ | (532 | ) |  | $ | (1,225 | ) |
| Other comprehensive loss, net of tax | (349 | ) |  | — |  |  | — |  |  | (349 | ) |
| Amounts reclassified from accumulated other comprehensive income, net of tax | 3 |  |  | (4 | ) |  | 13 |  |  | 12 |  |
| Net current period other comprehensive (loss) income | $ | (346 | ) |  | $ | (4 | ) |  | $ | 13 |  |  | $ | (337 | ) |
| Balance as of June 26, 2015 | $ | (1,039 | ) |  | $ | (4 | ) |  | $ | (519 | ) |  | $ | (1,562 | ) |


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0000833444-16-000197:notes:241]
[same as prior period, unchanged from 0000833444-16-000172:notes:236]

[0000833444-16-000197:notes:242]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Net income | $ | 238 |  |  | $ | 156 |  |  | $ | 459 |  |  | $ | 482 |  |
| Gain (loss) on foreign currency translation (1) | 7 |  |  | 25 |  |  | (21 | ) |  | (349 | ) |
| (Loss) gain on liquidation of foreign entities (2) | (1 | ) |  | 3 |  |  | 28 |  |  | 3 |  |
| Foreign currency translation | 6 |  |  | 28 |  |  | 7 |  |  | (346 | ) |
| Amortization of net actuarial losses (3) | 7 |  |  | 6 |  |  | 20 |  |  | 17 |  |
| Income tax expense | (2 | ) |  | (2 | ) |  | (7 | ) |  | (4 | ) |
| Defined benefit and post retirement plans, net of tax | 5 |  |  | 4 |  |  | 13 |  |  | 13 |  |
| Unrealized gain (loss) on marketable securities and derivative instruments (4) | 4 |  |  | (6 | ) |  | 9 |  |  | (6 | ) |
| Income tax (expense) benefit | (1 | ) |  | 2 |  |  | (3 | ) |  | 2 |  |
| Unrealized gain (loss) on marketable securities and derivative instruments, net of tax | 3 |  |  | (4 | ) |  | 6 |  |  | (4 | ) |
| Total other comprehensive income (loss), net of tax | 14 |  |  | 28 |  |  | 26 |  |  | (337 | ) |
| Comprehensive income | 252 |  |  | 184 |  |  | 485 |  |  | 145 |  |
| Less: comprehensive loss attributable to noncontrolling interests | (1 | ) |  | — |  |  | (2 | ) |  | (3 | ) |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 253 |  |  | $ | 184 |  |  | $ | 487 |  |  | $ | 148 |  |

[0000833444-16-000197:notes:243]
(1) Includes loss of $6 million related to the net investment hedge for both the quarter and nine months ended June 24, 2016. Includes loss of $12 million and gain of $8 million related to the net investment hedge for the quarter and nine months ended June 26, 2015, respectively.  See Note 10.

[0000833444-16-000197:notes:244]
(2) During the quarter ended June 24, 2016, $1 million of cumulative translation gains were transferred from currency translation adjustments to Selling, general and administrative expense within the Consolidated Statements of Operations as a result of the sale of a foreign entity.  During the quarter ended March 25, 2016, $31 million of cumulative translation losses were transferred from currency translation adjustments as a result of the sale of a foreign entity. Of this amount, $24 million was applied against a provision for cumulative translation losses within the Consolidated Balance Sheets which was established during the first quarter of fiscal 2016 and $7 million was transferred to Selling, general and administrative expense within the Consolidated Statements of Operations. Additionally, during the quarter ended March 25, 2016, $2 million of cumulative translation gains were transferred from currency translation adjustments and are included in Income (loss) from discontinued operations, net of income taxes within the Consolidated Statements of Operations as a result of the sale of another foreign entity.  During both the quarter and nine months ended June 26, 2015, $3 million of cumulative translation losses were transferred from foreign currency translation and included in (Loss) income from discontinued operations in the Consolidated Statements of Operations as a result of the sale of foreign entities.

[0000833444-16-000197:notes:245]
[same as prior period, unchanged from 0000833444-16-000172:notes:240]

[0000833444-16-000197:notes:246]
[same as prior period, unchanged from 0000833444-16-000172:notes:241]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-16-000197:notes:247]
[same as prior period, unchanged from 0000833444-16-000172:notes:242]

[0000833444-16-000197:notes:248]
[same as prior period, unchanged from 0000833444-16-000172:notes:243]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-16-000197:notes:249]
[same as prior period, unchanged from 0000833444-16-000172:notes:244]

[0000833444-16-000197:notes:250]
[same as prior period, unchanged from 0000833444-16-000172:notes:245]

[0000833444-16-000197:notes:251]
As of June 24, 2016 and September 25, 2015, the Company's authorized share capital amounted to $11,000,000 and €40,000, divided into 1,000,000,000 ordinary shares with a par value of $0.01 per share, 100,000,000 preferred shares with a par value of $0.01 per share and 40,000 ordinary A shares with a par value of €1.00 per share.  The authorized share capital includes 40,000 ordinary A shares with a par value of €1.00 per share in order to satisfy statutory requirements for the incorporation of all Irish public limited companies. Tyco Ireland may issue shares subject to the maximum prescribed by its authorized share capital contained in its memorandum of association. In connection with the re-domicile to Ireland, the Company canceled all the outstanding treasury shares, including shares held by subsidiaries, with an offsetting reduction in Additional paid in capital.

[0000833444-16-000197:notes:252]
[same as prior period, unchanged from 0000833444-16-000172:notes:247]

[0000833444-16-000197:notes:253]
The Company issued one authorized ordinary share in exchange for each ordinary share of Tyco International Ltd., the Swiss incorporated predecessor of the Company ("Tyco Switzerland") to the former shareholders of Tyco Switzerland.  All ordinary shares issued at the effective time of the re-domicile were issued as fully paid-up and non-assessable. See Note 1.

[0000833444-16-000197:notes:254]
[same as prior period, unchanged from 0000833444-16-000172:notes:249]

[0000833444-16-000197:notes:255]
[same as prior period, unchanged from 0000833444-16-000172:notes:250]

[0000833444-16-000197:notes:256]
[same as prior period, unchanged from 0000833444-16-000172:notes:251]

[0000833444-16-000197:notes:257]
On June 8, 2016, the Company declared a quarterly dividend of $0.205 per share, payable on August 17, 2016 to shareholders of record on July 22, 2016.  As a result, the Company recorded an accrued dividend of $87 million as of June 24, 2016 in Accrued and other current liabilities within the Company's Consolidated Balance Sheet. On March 14, 2016, the Company declared a quarterly dividend of $0.205 per share, paid on May 18, 2016 to shareholders of record on April 22, 2016. On December 8, 2015, the Company declared a quarterly dividend of $0.205 per share, paid on February 17, 2016 to shareholders of record on January 22, 2016. On September 3, 2015, the Company declared a quarterly dividend of $0.205 per share, paid on November 12, 2015 to shareholders of record on October 23, 2015.

[0000833444-16-000197:notes:258]
On June 4, 2015, the Company declared a quarterly divided of $0.205 per share paid on August 19, 2015 to shareholders of record on July 24, 2015. On March 4, 2015, the Company declared a quarterly dividend $0.205 per share paid on May 20, 2015 to shareholders of record on April 24, 2015.

[0000833444-16-000197:notes:259]
As previously disclosed in the 2015 Form 10-K, the Company presented dividends declared of $172 million as a reduction of Additional paid in capital within the Company’s Consolidated Statements of Shareholders’ Equity for the nine months ended June 26, 2015. For the year ended September 25, 2015, the Company corrected this presentation to present dividends declared for the periods subsequent to the re-domicile to Ireland as a reduction of Accumulated Earnings within the Consolidated Statement of Shareholder’s Equity to conform the presentation to its stand-alone statutory financial statements prepared under Irish GAAP. The Irish Companies Act (2014) does not permit dividends to be paid from share capital, including share premium. This reclassification had no effect on net revenue, operating income (loss), net income (loss), cash flows and total equity. Accordingly, the Company has reclassed its presentation of dividends declared for the nine months ended June 26, 2015 included herein.

[0000833444-16-000197:notes:260]
[same as prior period, unchanged from 0000833444-16-000172:notes:255]

[0000833444-16-000197:notes:261]
The Company's Board of Directors approved $1.75 billion and $1 billion share repurchase programs in March 2014 and September 2014, respectively.  No shares were repurchased during the quarters ended June 24, 2016 and June 26, 2015 and the nine months ended June 24, 2016.  During the nine months ended June 26, 2015, the Company repurchased a total of approximately 10 million shares for approximately $417 million which completed the $1.75 billion share repurchase program.  As of June 24, 2016, a total of approximately $1 billion in share repurchase authority remained outstanding.

[0000833444-16-000197:notes:262]
[same as prior period, unchanged from 0000833444-16-000172:notes:257]


## us-gaap:SubsequentEventsTextBlock

[0000833444-16-000197:notes:263]
Subsequent Events

[0000833444-16-000197:notes:264]
On July 21, 2016, the Company announced that it expects to close its merger with Johnson Controls, Inc. on September 2, 2016. In addition, the Company declared an accelerated dividend of $0.23 per ordinary share, payable on August 26, 2016, to shareholders of record on August 5, 2016.

[0000833444-16-000197:notes:265]
The accelerated dividend is in addition to the regular third quarter dividend scheduled to be paid on August 17, 2016 to shareholders of record on July 22, 2016. This accelerated dividend pulls forward the quarterly dividend that Tyco would have declared in its fiscal fourth quarter, and is intended to align dividend payments made to shareholders of Tyco and Johnson Controls prior to the closing of the merger. Closing of the merger is contingent upon, among other things, the approval of proposals related to the merger by shareholders of each company. The special meetings for shareholders of Tyco and Johnson Controls are scheduled for August 17, 2016.
