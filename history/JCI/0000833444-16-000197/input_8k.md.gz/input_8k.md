# JCI 8-K — 0000833444-16-000194 filed 2016-07-29

## item codes, every 8-K on or before 2016-07-29

- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2016-07-29

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-16-000194:8k_2_02:1]
EX-99.1
2
exhibit991-q316.htm
EXHIBIT 99.1

[0000833444-16-000194:8k_2_02:2]
Exhibit

[0000833444-16-000194:8k_2_02:3]
| Investor Contacts: |  | Media Contact: |  |
| Antonella Franzen |  | Stephen Wasdick |  |
| +1-609-720-4665 |  | +1-609-806-2262 |  |
| afranzen@tyco.com |  | swasdick@tyco.com |  |
| Ryan Edelman |  |  |  |
| +1-609-720-4545 |  |  |  |
| redelman@tyco.com |  |  |  |

[0000833444-16-000194:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-16-000194:8k_2_02:5]
TYCO REPORTS THIRD QUARTER 2016 GAAP EARNINGS FROM CONTINUING OPERATIONS

[0000833444-16-000194:8k_2_02:6]
OF $0.56 PER SHARE AND $0.54 PER SHARE BEFORE SPECIAL ITEMS

[0000833444-16-000194:8k_2_02:7]
| • | Accelerates expected closing for planned merger with Johnson Controls to September 2 and reaffirms combined company's ability to achieve the previously announced $1 billion in merger synergies and productivity initiatives |

[0000833444-16-000194:8k_2_02:8]
| • | As previously announced, the company's Board declared an accelerated dividend for the fiscal fourth quarter of $0.23 per share, payable on August 26 to shareholders of record on August 5, in addition to the fiscal third quarter dividend of $0.205 |

[0000833444-16-000194:8k_2_02:9]
| • | Revenue of $2.45 billion, with organic revenue growth of 1.5% in the quarter |

[0000833444-16-000194:8k_2_02:10]
| • | GAAP diluted EPS from continuing operations increases 27%, primarily due to the reversal of tax sharing agreement reserves resulting from the IRS settlement, as well as decreased restructuring and repositioning charges, partially offset by an increase in divestiture charges and merger costs |

[0000833444-16-000194:8k_2_02:11]
| • | Diluted EPS from continuing operations before special items increases 17%, partially related to decreased restructuring and repositioning charges |

[0000833444-16-000194:8k_2_02:12]
CORK, Ireland, July 29, 2016 - Tyco (NYSE: TYC) today reported $0.56 in GAAP diluted earnings per share (EPS) from continuing operations for the fiscal third quarter of 2016 and diluted EPS from continuing operations before special items of $0.54.  Revenue of $2.45 billion in the quarter decreased 2% versus the prior year, as 1.5% organic growth was more than offset by a 3% negative impact from the stronger U.S. dollar against foreign currencies.  A three percentage point benefit related to acquisitions was fully offset by a three percentage point impact related to divestitures.

[0000833444-16-000194:8k_2_02:13]
"We have continued to make great progress with integration planning for our merger with Johnson Controls.  We are now in position to close the merger a month ahead of schedule and hit the ground running.  As a result of the integration planning work, we are confident that we will be able to realize      $1 billion of savings related to previously announced merger synergies and productivity initiatives," said Tyco Chief Executive Officer George R. Oliver.  "I would like to express my gratitude to the entire Tyco team for their dedication and for the results we have achieved as a focused fire and security industry leader over the past four years," Mr. Oliver added.

[0000833444-16-000194:8k_2_02:14]
(Income and EPS amounts are attributable to Tyco ordinary shareholders)

[0000833444-16-000194:8k_2_02:15]
($ millions, except per-share amounts)

[0000833444-16-000194:8k_2_02:16]
|  |  | Q3 2016 |  | Q3 2015 |  | % Change |  |
| Revenue |  | $ | 2,449 |  |  | $ | 2,489 |  |  | (2 | )% |  |
| Segment Operating Income |  | $ | 299 |  |  | $ | 367 |  |  | (19 | )% |  |
| Restructuring and Repositioning |  | $ | (13 | ) |  | $ | (65 | ) |  | (80 | )% |  |
| Operating Income |  | $ | 236 |  |  | $ | 253 |  |  | (7 | )% |  |
| Income from Continuing Operations |  | $ | 241 |  |  | $ | 188 |  |  | 28 | % |  |
| GAAP Diluted EPS from Continuing Operations |  | $ | 0.56 |  |  | $ | 0.44 |  |  | 27 | % |  |
| Special Items |  | $ | (0.02 | ) |  | $ | 0.02 |  |  |  |  |
| Segment Operating Income Before Special Items |  | $ | 355 |  |  | $ | 369 |  |  | (4 | )% |  |
| Restructuring and Repositioning Before Special Items |  | $ | (15 | ) |  | $ | (65 | ) |  | (77 | )% |  |
| Income from Continuing Ops Before Special Items |  | $ | 231 |  |  | $ | 198 |  |  | 17 | % |  |
| Diluted EPS from Continuing Ops Before Special Items |  | $ | 0.54 |  |  | $ | 0.46 |  |  | 17 | % |  |

[0000833444-16-000194:8k_2_02:17]
Organic revenue, free cash flow, adjusted free cash flow, operating income, segment operating income, and diluted EPS from continuing operations before special items are non-GAAP financial measures and are described below.  For a reconciliation of these non-GAAP measures, see the attached tables. Additional schedules as well as third quarter review slides can be found in the Investor Relations section of Tyco’s website at http://investors.tyco.com.

[0000833444-16-000194:8k_2_02:18]
SEGMENT RESULTS

[0000833444-16-000194:8k_2_02:19]
The financial results presented in the tables below are in accordance with GAAP unless otherwise indicated.  All dollar amounts are pre-tax and stated in millions.  All comparisons are to the fiscal third quarter of 2015 unless otherwise indicated.

[0000833444-16-000194:8k_2_02:20]
North America Integrated Solutions & Services

[0000833444-16-000194:8k_2_02:21]
|  |  | Q3 2016 |  | Q3 2015 |  | % Change |  |
| Revenue |  | $ | 1,004 |  |  | $ | 972 |  |  | 3 | % |  |
| Operating Income |  | $ | 148 |  |  | $ | 157 |  |  | (6 | )% |  |
| Operating Margin |  | 14.7 | % |  | 16.2 | % |  |  |  |
| Special Items |  | $ | — |  |  | $ | — |  |  |  |  |
| Operating Income Before Special Items |  | $ | 148 |  |  | $ | 157 |  |  | (6 | )% |  |
| Operating Margin Before Special Items |  | 14.7 | % |  | 16.2 | % |  |  |  |

[0000833444-16-000194:8k_2_02:22]
Revenue of $1.0 billion increased 3% from the prior year.  Organic revenue growth of 2.5% was driven by 4% growth in integrated solutions and 1% growth in service revenue.  Acquisition growth of 1% was partially offset by the weakening of the Canadian dollar.  Backlog of $2.67 billion increased 5% year over year and 3% on a quarter sequential basis, excluding the impact of foreign currency.

[0000833444-16-000194:8k_2_02:23]
Operating income for the quarter was $148 million and the operating margin declined 150 basis points to 14.7%, including a 30 basis point headwind related to non-cash purchase accounting.  Underlying operations declined 120 basis points due to increased investments and a higher mix of installation revenue.

[0000833444-16-000194:8k_2_02:24]
Rest of World Integrated Solutions & Services

[0000833444-16-000194:8k_2_02:25]
|  |  | Q3 2016 |  | Q3 2015 |  | % Change |  |
| Revenue |  | $ | 794 |  |  | $ | 842 |  |  | (6 | )% |  |
| Operating Income |  | $ | 36 |  |  | $ | 97 |  |  | (63 | )% |  |
| Operating Margin |  | 4.5 | % |  | 11.5 | % |  |  |  |
| Special Items |  | $ | (56 | ) |  | $ | 4 |  |  |  |  |
| Operating Income Before Special Items |  | $ | 92 |  |  | $ | 93 |  |  | (1 | )% |  |
| Operating Margin Before Special Items |  | 11.6 | % |  | 11.0 | % |  |  |  |

[0000833444-16-000194:8k_2_02:26]
Revenue of $794 million decreased 6% compared to the prior year, driven by a 6% unfavorable impact from foreign currency exchange rates.  Organic revenue increased 2%, with 2% growth in service and a 2% increase in integrated solutions.  Acquisition growth of 7% was more than offset by a 9% decline related to divestitures.  Backlog of $1.94 billion increased 14% year over year, partly driven by acquisition activity, and 2% on a quarter sequential basis, excluding the impact of foreign currency and divestitures.

[0000833444-16-000194:8k_2_02:27]
Operating income for the quarter was $36 million and the operating margin was 4.5%.  Special items of $56 million consisted primarily of a writedown of a business held for sale.  Before special items, operating income was $92 million and the operating margin was 11.6%.  The operating margin improved by 60 basis points, including a 30 basis point impact related to non-cash purchase accounting.  Underlying operations improved 90 basis points, driven by revenue growth, improved execution and productivity benefits.

[0000833444-16-000194:8k_2_02:28]
Global Products

[0000833444-16-000194:8k_2_02:29]
|  |  | Q3 2016 |  | Q3 2015 |  | % Change |  |
| Revenue |  | $ | 651 |  |  | $ | 675 |  |  | (4 | )% |  |
| Operating Income |  | $ | 115 |  |  | $ | 113 |  |  | 2 | % |  |
| Operating Margin |  | 17.7 | % |  | 16.7 | % |  |  |  |
| Special Items |  | $ | — |  |  | $ | (6 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 115 |  |  | $ | 119 |  |  | (3 | )% |  |
| Operating Margin Before Special Items |  | 17.7 | % |  | 17.6 | % |  |  |  |

[0000833444-16-000194:8k_2_02:30]
Revenue of $651 million decreased 4% compared to the prior year driven by a 2% unfavorable impact from foreign currency exchange rates and a 2% unfavorable impact related to a divestiture. Organic revenue growth was flat year over year.

[0000833444-16-000194:8k_2_02:31]
Operating income for the quarter was $115 million and the operating margin was 17.7%.  Before special items, the operating margin increased 10 basis points as productivity benefits more than offset headwinds from revenue mix.

[0000833444-16-000194:8k_2_02:32]
OTHER ITEMS

[0000833444-16-000194:8k_2_02:33]
| • | Cash from operating activities was $191 million and free cash flow was $119 million, which included cash outflows of $95 million from special items. Adjusted free cash flow for the quarter was $214 million representing an adjusted free cash flow conversion rate of 93% for the third quarter and 104% for the nine months ending June 24, 2016. The company completed the quarter with $345 million in cash and cash equivalents. |

[0000833444-16-000194:8k_2_02:34]
| • | Corporate expense for the quarter was $50 million on a GAAP basis and $44 million before special items. |

[0000833444-16-000194:8k_2_02:35]
| • | Restructuring and repositioning charges were $15 million before the reversal of $2 million of prior-period charges treated as special items, compared to $65 million for the prior year period. |

[0000833444-16-000194:8k_2_02:36]
| • | The GAAP tax rate was 11.4% for the quarter, which was favorably impacted by the IRS settlement and the tax impact on special items. The tax rate was 17.3% before special items. |

[0000833444-16-000194:8k_2_02:37]
| • | During the quarter, a loss of $59 million was recorded due to the anticipated sale of a business in the Rest of World Integrated Solutions & Services segment that generates approximately $160 million in annual revenue. |

[0000833444-16-000194:8k_2_02:38]
| • | As previously announced, the registration statement on Form S-4 filed with the U.S. Securities and Exchange Commission in connection with the proposed Tyco and Johnson Controls merger was declared effective on July 6, 2016. Both companies have scheduled meetings of their respective shareholders for approval of matters related to the merger. Tyco’s extraordinary meeting of shareholders will be held on August 17, 2016, at 9:00 a.m. local time at Earlsfort Centre, Earlsfort Terrace, Dublin, Ireland. Tyco's Board of Directors unanimously recommends that shareholders vote "FOR" the matters specified in the joint proxy statement/prospectus included in the Form S-4, which is available on the SEC's website (as filed under Tyco) at: www.sec.gov. |

[0000833444-16-000194:8k_2_02:39]
| • | As previously announced, in accordance with applicable Irish and European rules and regulations related to the proposed merger with Johnson Controls, Tyco has withdrawn its previously issued standalone profit forecast. |

[0000833444-16-000194:8k_2_02:40]
| • | As previously announced, the company's Board of Directors has declared an accelerated dividend of $0.23 per ordinary share, payable on August 26, 2016, to shareholders of record at the close of NYSE trading on August 5, 2016. The accelerated dividend is in addition to the regular third quarter dividend. This accelerated dividend pulls forward the quarterly dividend that Tyco would have declared in its fiscal fourth quarter, and is intended to align dividend payments made to shareholders of Tyco and Johnson Controls prior to the closing of the merger. |

[0000833444-16-000194:8k_2_02:41]
ABOUT TYCO

[0000833444-16-000194:8k_2_02:42]
Tyco (NYSE: TYC) is the world’s largest pure-play fire protection and security company. Tyco provides more than three million customers around the globe with the latest fire protection and security products and services. Tyco has over 57,000 employees in more than 900 locations across 50 countries serving various end markets, including commercial, institutional, governmental, retail, industrial, energy, residential and small business. For more information, visit www.tyco.com.

[0000833444-16-000194:8k_2_02:43]
CONFERENCE CALL AND WEBCAST

[0000833444-16-000194:8k_2_02:44]
Management will discuss the company’s third quarter results for 2016 during a conference call and webcast today beginning at 8:00 a.m. Eastern time (ET).  Today’s conference call for investors can be accessed in the following ways:

[0000833444-16-000194:8k_2_02:45]
| • | Live via webcast - through the Investor Relations section of Tyco’s website at http://investors.tyco.com, |

[0000833444-16-000194:8k_2_02:46]
| • | Live via telephone (for “listen-only” participants and those who would like to ask a question) - by dialing 800-857-9797 (in the United States) or 517-308-9029 (outside the United States), passcode “Tyco”, |

[0000833444-16-000194:8k_2_02:47]
| • | Replay via telephone - by dialing 800-879-5193 (in the United States) or 203-369-3562 (outside the United States), passcode 2577, from 10:00 a.m. (ET) on July 29, 2016, until 11:59 p.m. (ET) on August 5, 2016, and |

[0000833444-16-000194:8k_2_02:48]
| • | Replay via webcast - through the “Presentations & Webcasts” link on the Investor Relations section of Tyco’s website: http://investors.tyco.com. |

[0000833444-16-000194:8k_2_02:49]
NON-GAAP MEASURES

[0000833444-16-000194:8k_2_02:50]
Organic revenue, free cash flow (outflow) (FCF), and income from continuing operations, earnings per share (EPS) from continuing operations, operating income and segment operating income, in each case “before special items,” are non-GAAP measures and should not be considered replacements for GAAP results.

[0000833444-16-000194:8k_2_02:51]
Organic revenue is a useful measure used by the company to measure the underlying results and trends in the business. The difference between reported net revenue (the most comparable GAAP measure) and organic revenue (the non-GAAP measure) consists of the impact from foreign currency, acquisitions and divestitures, and other changes that either do not reflect the underlying results and trends of the Company’s businesses or are not completely under management’s control. There are limitations associated with organic revenue, such as the fact that, as presented herein, the metric may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using organic revenue in combination with the GAAP numbers. Organic revenue may be used as a component in the company’s incentive compensation plans.

[0000833444-16-000194:8k_2_02:52]
FCF is a useful measure of the company's cash that permits management and investors to gain insight into the number that management employs to measure cash that is free from any significant existing obligation and is available to service debt and make investments. The difference between Cash Flows from Operating Activities (the most comparable GAAP measure) and FCF (the non-GAAP measure) consists mainly of significant cash flows that the company believes are useful to identify. It, or a measure that is based on it, may be used as a component in the company's incentive compensation plans. The difference reflects the impact from:

[0000833444-16-000194:8k_2_02:53]
| • | net capital expenditures, |

[0000833444-16-000194:8k_2_02:54]
| • | dealer generated accounts and bulk accounts purchased, |

[0000833444-16-000194:8k_2_02:55]
| • | cash paid for purchase accounting and holdback liabilities, and |

[0000833444-16-000194:8k_2_02:56]
| • | voluntary pension contributions. |

[0000833444-16-000194:8k_2_02:57]
Capital expenditures and dealer generated and bulk accounts purchased are subtracted because they represent long-term investments that are required for normal business activities. Cash paid for purchase accounting and holdback liabilities is subtracted because these cash outflows are not available for general corporate uses. Voluntary pension contributions are added because this activity is driven by economic financing decisions rather than operating activity. In addition, the company presents adjusted free cash flow, which is free cash flow, adjusted to exclude the cash impact of the special items highlighted below. This number provides information to investors regarding the cash impact of certain items management believes are useful to identify, as described below.

[0000833444-16-000194:8k_2_02:58]
The limitation associated with using these cash flow metrics is that they adjust for cash items that are ultimately within management's and the Board of Directors' discretion to direct and therefore may imply that there is less or more cash that is available for the company's programs than the most comparable GAAP measure. Furthermore, these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using FCF in combination with the GAAP cash flow numbers.

[0000833444-16-000194:8k_2_02:59]
The company has presented its income and EPS from continuing operations, operating income and segment operating income before special items. Special items include charges and gains related to divestitures, acquisitions, restructurings, impairments, certain changes to accounting methodologies, legacy legal and tax charges and other income or charges that may mask the underlying operating results and/or business trends of the company or business segment, as applicable. The company utilizes these measures to assess overall operating performance and segment level core operating performance, as well as to provide insight to management in evaluating overall and segment operating plan execution

[0000833444-16-000194:8k_2_02:60]
and underlying market conditions. The Company also presents its effective tax rate as adjusted for special items for consistency, and presents corporate expense excluding special items. One or more of these measures may be used as components in the company's incentive compensation plans. These measures are useful for investors because they may permit more meaningful comparisons of the company's underlying operating results and business trends between periods. The difference between income and EPS from continuing operations before special items and income and EPS from continuing operations (the most comparable GAAP measures) consists of the impact of the special items noted above on the applicable GAAP measure. The limitation of these measures is that they exclude the impact (which may be material) of items that increase or decrease the company's reported GAAP metrics, and these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using the non-GAAP measures in combination with the most comparable GAAP measures in order to better understand the amounts, character and impact of any increase or decrease on reported results.

[0000833444-16-000194:8k_2_02:61]
The company provides general corporate services to its segments and those costs are reported in the "Corporate and Other" segment. This segment's operating income (loss) is presented as "Corporate Expense." Segment Operating Income represents Tyco’s operating income excluding the Corporate and Other segment, and reflects the results of Tyco’s three operating segments. Segment Operating Income before special items reflects GAAP operating income adjusted for the special items noted in the paragraph above.

[0000833444-16-000194:8k_2_02:62]
NO OFFER OR SOLICITATION

[0000833444-16-000194:8k_2_02:63]
This communication is not intended to and does not constitute an offer to sell or the solicitation of an offer to subscribe for or buy or an invitation to purchase or subscribe for any securities or the solicitation of any vote or approval in any jurisdiction, nor shall there be any sale, issuance or transfer of securities in any jurisdiction in contravention of applicable law.

[0000833444-16-000194:8k_2_02:64]
ADDITIONAL INFORMATION AND WHERE TO FIND IT

[0000833444-16-000194:8k_2_02:65]
In connection with the proposed transaction between Johnson Controls, Inc. (“JCI”) and Tyco International plc (“Tyco”), Tyco has filed with the U.S. Securities and Exchange Commission (the “SEC”) a registration statement on Form S-4 (the “Registration Statement”) that includes a joint proxy statement of JCI and Tyco that also constitutes a prospectus of Tyco (the “Joint Proxy Statement/Prospectus”). The Registration Statement was declared effective by the SEC on July 6, 2016, and the definitive Joint Proxy Statement/Prospectus was first mailed to shareholders of JCI and Tyco on or about July 6, 2016. INVESTORS AND SECURITY HOLDERS OF JCI AND TYCO ARE URGED TO READ THE JOINT PROXY STATEMENT/PROSPECTUS AND OTHER RELEVANT DOCUMENTS FILED OR TO BE FILED WITH THE SEC, AS WELL AS ANY AMENDMENTS OR SUPPLEMENTS TO THOSE DOCUMENTS, BECAUSE THEY WILL CONTAIN IMPORTANT INFORMATION ABOUT JCI, TYCO, THE TRANSACTION AND RELATED MATTERS. Investors and security holders may obtain free copies of the Joint Proxy Statement/Prospectus and other documents filed with the SEC by JCI and Tyco through the website maintained by the SEC at www.sec.gov. In addition, investors and security holders may obtain free copies of the documents filed with the SEC by JCI by contacting JCI Shareholder Services at Shareholder.Services@jci.com or by calling (800) 524-6220 and may obtain free copies of the documents filed with the SEC by Tyco by contacting Tyco Investor Relations at Investorrelations@tyco.com or by calling (609) 720-4333.

[0000833444-16-000194:8k_2_02:66]
CAUTIONARY STATEMENT REGARDING FORWARD-LOOKING STATEMENTS

[0000833444-16-000194:8k_2_02:67]
Forward-looking statements by their nature address matters that are, to different degrees, uncertain, such as statements about the consummation of the proposed transaction. Many factors could cause actual results to differ materially from these forward-looking statements, including, in addition to factors previously disclosed in Tyco’s reports filed with the SEC, which are available at www.sec.gov and www.Tyco.com under the “Investor Relations” tab, and those identified elsewhere in this communication, risks relating to the completion of the proposed transaction on anticipated terms and timing, including obtaining shareholder and regulatory approvals, anticipated tax treatment, unforeseen liabilities, future capital expenditures, revenues, expenses, earnings, synergies, economic performance, indebtedness, financial condition, losses, future prospects, business and management strategies for the management, expansion and growth of the new combined company’s operations, the ability of Tyco and JCI to integrate their businesses successfully and to achieve anticipated synergies, changes in tax laws or interpretations, access to available financing, potential litigation relating to the proposed transaction, and the risk that disruptions from the proposed transaction will harm Tyco’s business.

[0000833444-16-000194:8k_2_02:68]
Annualized, pro forma, projected and estimated numbers are used for illustrative purpose only, are not forecasts and may not reflect actual results.

[0000833444-16-000194:8k_2_02:69]
STATEMENT REQUIRED BY THE IRISH TAKEOVER RULES

[0000833444-16-000194:8k_2_02:70]
The directors of Tyco accept responsibility for the information contained in this communication relating to Tyco and the directors of Tyco and members of their immediate families, related trusts and persons connected with them. To the best of the knowledge and belief of the directors of Tyco (who have taken all reasonable care to ensure such is the case), the information contained in this communication for which they accept responsibility is in accordance with the facts and does not omit anything likely to affect the import of such information.

[0000833444-16-000194:8k_2_02:71]
Lazard Frères & Co. LLC, which is a registered broker dealer with the SEC, is acting for Tyco International plc and no one else in connection with the proposed transaction and will not be responsible to anyone other than Tyco International plc for providing the protections afforded to clients of Lazard Frères & Co. LLC, or for giving advice in connection with the proposed transaction or any matter referred to herein.

[0000833444-16-000194:8k_2_02:72]
NOT FOR RELEASE, PUBLICATION OR DISTRIBUTION, IN WHOLE OR IN PART, IN, INTO OR FROM ANY JURISDICTION WHERE TO DO SO WOULD CONSTITUTE A VIOLATION OF THE RELEVANT LAWS OR REGULATIONS OF SUCH JURISDICTION.

[0000833444-16-000194:8k_2_02:73]
This communication is not intended to be and is not a prospectus for the purposes of Part 23 of the Companies Act 2014 of Ireland (the “2014 Act”), Prospectus (Directive 2003/71/EC) Regulations 2005 (S.I. No. 324 of 2005) of Ireland (as amended from time to time) or the Prospectus Rules issued by the Central Bank of Ireland pursuant to section 1363 of the 2014 Act, and the Central Bank of Ireland (“CBI”) has not approved this communication.

[0000833444-16-000194:8k_2_02:74]
# # #

[0000833444-16-000194:8k_2_02:75]
TYCO INTERNATIONAL PLC

[0000833444-16-000194:8k_2_02:76]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0000833444-16-000194:8k_2_02:77]
(in millions, except per share data)

[0000833444-16-000194:8k_2_02:78]
(Unaudited)

[0000833444-16-000194:8k_2_02:79]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Revenue from product sales | $ | 1,487 |  |  | $ | 1,511 |  |  | $ | 4,293 |  |  | $ | 4,457 |  |
| Service revenue | 962 |  |  | 978 |  |  | 2,863 |  |  | 2,940 |  |
| Net revenue | 2,449 |  |  | 2,489 |  |  | 7,156 |  |  | 7,397 |  |
| Cost of product sales | 1,026 |  |  | 1,025 |  |  | 2,956 |  |  | 3,046 |  |
| Cost of services | 508 |  |  | 548 |  |  | 1,550 |  |  | 1,645 |  |
| Selling, general and administrative expenses | 667 |  |  | 625 |  |  | 1,842 |  |  | 1,925 |  |
| Merger costs | 7 |  |  | — |  |  | 33 |  |  | — |  |
| Restructuring and asset impairment charges, net | 5 |  |  | 38 |  |  | 21 |  |  | 108 |  |
| Operating income | 236 |  |  | 253 |  |  | 754 |  |  | 673 |  |
| Interest income | 3 |  |  | 4 |  |  | 11 |  |  | 11 |  |
| Interest expense | (22 | ) |  | (26 | ) |  | (68 | ) |  | (75 | ) |
| Other income (expense), net | 54 |  |  | 6 |  |  | (111 | ) |  | 9 |  |
| Income from continuing operations before income taxes | 271 |  |  | 237 |  |  | 586 |  |  | 618 |  |
| Income tax expense | (31 | ) |  | (49 | ) |  | (130 | ) |  | (86 | ) |
| Income from continuing operations | 240 |  |  | 188 |  |  | 456 |  |  | 532 |  |
| (Loss) income from discontinued operations, net of income taxes | (2 | ) |  | (32 | ) |  | 3 |  |  | (50 | ) |
| Net income | 238 |  |  | 156 |  |  | 459 |  |  | 482 |  |
| Less: noncontrolling interest in subsidiaries net loss | (1 | ) |  | — |  |  | (2 | ) |  | (3 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 239 |  |  | $ | 156 |  |  | $ | 461 |  |  | $ | 485 |  |
| Amounts attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 241 |  |  | $ | 188 |  |  | $ | 458 |  |  | $ | 535 |  |
| (Loss) income from discontinued operations | (2 | ) |  | (32 | ) |  | 3 |  |  | (50 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 239 |  |  | $ | 156 |  |  | $ | 461 |  |  | $ | 485 |  |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 0.57 |  |  | $ | 0.45 |  |  | $ | 1.08 |  |  | $ | 1.27 |  |
| Loss from discontinued operations | (0.01 | ) |  | (0.08 | ) |  | — |  |  | (0.12 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 0.56 |  |  | $ | 0.37 |  |  | $ | 1.08 |  |  | $ | 1.15 |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 0.56 |  |  | $ | 0.44 |  |  | $ | 1.07 |  |  | $ | 1.25 |  |
| (Loss) income from discontinued operations | — |  |  | (0.07 | ) |  | 0.01 |  |  | (0.11 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 0.56 |  |  | $ | 0.37 |  |  | $ | 1.08 |  |  | $ | 1.14 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |  |  |
| Basic | 426 |  |  | 421 |  |  | 425 |  |  | 421 |  |
| Diluted | 429 |  |  | 427 |  |  | 428 |  |  | 427 |  |

[0000833444-16-000194:8k_2_02:80]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed on November 13, 2015 and Form 8-K filed on March 11, 2016 for the fiscal year ended September 25, 2015 and Quarterly Report on Form 10-Q filed on April 29, 2016 for the quarter ended March 25, 2016.

[0000833444-16-000194:8k_2_02:81]
TYCO INTERNATIONAL PLC

[0000833444-16-000194:8k_2_02:82]
RESULTS OF SEGMENTS

[0000833444-16-000194:8k_2_02:83]
(in millions)

[0000833444-16-000194:8k_2_02:84]
(Unaudited)

[0000833444-16-000194:8k_2_02:85]
|  |  | For the Quarters Ended |  |  |  | For the Nine Months Ended |  |  |
|  |  | June 24, 2016 |  |  |  | June 26, 2015 |  |  |  | June 24, 2016 |  |  |  | June 26, 2015 |  |  |
| Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Integrated Solutions & Services |  | $ | 1,004 |  |  |  |  |  | $ | 972 |  |  |  |  |  | $ | 2,904 |  |  |  |  |  | $ | 2,867 |  |  |  |  |
| ROW Integrated Solutions & Services |  | 794 |  |  |  |  |  | 842 |  |  |  |  |  | 2,374 |  |  |  |  |  | 2,605 |  |  |  |  |
| Global Products |  | 651 |  |  |  |  |  | 675 |  |  |  |  |  | 1,878 |  |  |  |  |  | 1,925 |  |  |  |  |
| Total Net Revenue |  | $ | 2,449 |  |  |  |  |  | $ | 2,489 |  |  |  |  |  | $ | 7,156 |  |  |  |  |  | $ | 7,397 |  |  |  |  |
| Operating Income and Margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Integrated Solutions & Services |  | $ | 148 |  |  | 14.7 | % |  | $ | 157 |  |  | 16.2 | % |  | $ | 411 |  |  | 14.2 | % |  | $ | 411 |  |  | 14.3 | % |
| ROW Integrated Solutions & Services |  | 36 |  |  | 4.5 | % |  | 97 |  |  | 11.5 | % |  | 226 |  |  | 9.5 | % |  | 253 |  |  | 9.7 | % |
| Global Products |  | 115 |  |  | 17.7 | % |  | 113 |  |  | 16.7 | % |  | 313 |  |  | 16.7 | % |  | 332 |  |  | 17.2 | % |
| Segment Operating Income |  | 299 |  |  | 12.2 | % |  | 367 |  |  | 14.7 | % |  | 950 |  |  | 13.3 | % |  | 996 |  |  | 13.5 | % |
| Corporate and Other expense |  | (50 | ) |  | N/M |  |  | (49 | ) |  | N/M |  |  | (155 | ) |  | N/M |  |  | (154 | ) |  | N/M |  |
| Restructuring and repositioning charges, net |  | (13 | ) |  | N/M |  |  | (65 | ) |  | N/M |  |  | (41 | ) |  | N/M |  |  | (169 | ) |  | N/M |  |
| Operating Income |  | $ | 236 |  |  | 9.6 | % |  | $ | 253 |  |  | 10.2 | % |  | $ | 754 |  |  | 10.5 | % |  | $ | 673 |  |  | 9.1 | % |

[0000833444-16-000194:8k_2_02:86]
TYCO INTERNATIONAL PLC

[0000833444-16-000194:8k_2_02:87]
CONSOLIDATED BALANCE SHEETS

[0000833444-16-000194:8k_2_02:88]
(in millions)

[0000833444-16-000194:8k_2_02:89]
(Unaudited)

[0000833444-16-000194:8k_2_02:90]
|  |  | June 24, 2016 |  | September 25, 2015 |
| Assets |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 345 |  |  | $ | 1,401 |  |
| Accounts receivable, net |  | 1,805 |  |  | 1,722 |  |
| Inventories |  | 656 |  |  | 620 |  |
| Prepaid expenses and other current assets |  | 883 |  |  | 750 |  |
| Deferred income taxes |  | 62 |  |  | 62 |  |
| Assets held for sale |  | 71 |  |  | 208 |  |
| Total Current Assets |  | 3,822 |  |  | 4,763 |  |
| Property, plant and equipment, net |  | 1,180 |  |  | 1,166 |  |
| Goodwill |  | 4,418 |  |  | 4,203 |  |
| Intangible assets, net |  | 966 |  |  | 822 |  |
| Other assets |  | 1,228 |  |  | 1,367 |  |
| Total Assets |  | $ | 11,614 |  |  | $ | 12,321 |  |
| Liabilities and Equity |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |
| Loans payable and current maturities of long-term debt |  | $ | 341 |  |  | $ | 987 |  |
| Accounts payable |  | 799 |  |  | 764 |  |
| Accrued and other current liabilities |  | 1,564 |  |  | 1,644 |  |
| Deferred revenue |  | 378 |  |  | 379 |  |
| Liabilities held for sale |  | 34 |  |  | 80 |  |
| Total Current Liabilities |  | 3,116 |  |  | 3,854 |  |
| Long-term debt |  | 2,165 |  |  | 2,159 |  |
| Deferred revenue |  | 284 |  |  | 302 |  |
| Other liabilities |  | 1,663 |  |  | 1,930 |  |
| Total Liabilities |  | 7,228 |  |  | 8,245 |  |
| Total Tyco shareholders' equity |  | 4,351 |  |  | 4,041 |  |
| Nonredeemable noncontrolling interest |  | 35 |  |  | 35 |  |
| Total Equity |  | 4,386 |  |  | 4,076 |  |
| Total Liabilities and Equity |  | $ | 11,614 |  |  | $ | 12,321 |  |

[0000833444-16-000194:8k_2_02:91]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed on November 13, 2015 and Form 8-K filed on March 11, 2016 for the fiscal year ended September 25, 2015 and Quarterly Report on Form 10-Q filed on April 29, 2016 for the quarter ended March 25, 2016.

[0000833444-16-000194:8k_2_02:92]
TYCO INTERNATIONAL PLC

[0000833444-16-000194:8k_2_02:93]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000833444-16-000194:8k_2_02:94]
(in millions)

[0000833444-16-000194:8k_2_02:95]
(Unaudited)

[0000833444-16-000194:8k_2_02:96]
|  |  | For the Quarters Ended |  | For the Nine Months Ended |
|  |  | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Tyco ordinary shareholders |  | $ | 239 |  |  | $ | 156 |  |  | $ | 461 |  |  | $ | 485 |  |
| Noncontrolling interest in subsidiaries net loss |  | (1 | ) |  | — |  |  | (2 | ) |  | (3 | ) |
| Loss (income) from discontinued operations, net of income taxes |  | 2 |  |  | 32 |  |  | (3 | ) |  | 50 |  |
| Income from continuing operations |  | 240 |  |  | 188 |  |  | 456 |  |  | 532 |  |
| Adjustments to reconcile net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  | 83 |  |  | 86 |  |  | 250 |  |  | 257 |  |
| Non-cash compensation expense |  | 12 |  |  | 14 |  |  | 39 |  |  | 44 |  |
| Deferred income taxes |  | 27 |  |  | 28 |  |  | 89 |  |  | (1 | ) |
| Provision for losses on accounts receivable and inventory |  | 21 |  |  | 3 |  |  | 50 |  |  | 37 |  |
| Loss on extinguishment of debt |  | — |  |  | — |  |  | 168 |  |  | — |  |
| Legacy legal matters |  | 1 |  |  | — |  |  | (18 | ) |  | — |  |
| Loss (gain) on divestitures, net |  | 38 |  |  | (4 | ) |  | 107 |  |  | 19 |  |
| Gain on investments, net |  | — |  |  | (8 | ) |  | (114 | ) |  | (15 | ) |
| (Gain) loss on tax sharing agreements |  | (54 | ) |  | 1 |  |  | (54 | ) |  | 2 |  |
| Other non-cash items |  | 5 |  |  | 2 |  |  | 10 |  |  | 8 |  |
| Changes in assets and liabilities, net of the effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (103 | ) |  | (126 | ) |  | (65 | ) |  | (104 | ) |
| Contracts in progress |  | (15 | ) |  | 38 |  |  | (69 | ) |  | 8 |  |
| Inventories |  | 1 |  |  | (8 | ) |  | (55 | ) |  | (72 | ) |
| Prepaid expenses and other assets |  | 1 |  |  | 11 |  |  | (29 | ) |  | (55 | ) |
| Accounts payable |  | 12 |  |  | 9 |  |  | 14 |  |  | (78 | ) |
| Accrued and other liabilities |  | (16 | ) |  | 22 |  |  | (149 | ) |  | (34 | ) |
| Tax sharing agreement, net |  | (16 | ) |  | — |  |  | (138 | ) |  | — |  |
| Income taxes, net |  | (24 | ) |  | 3 |  |  | (11 | ) |  | 4 |  |
| Other |  | (22 | ) |  | (10 | ) |  | 23 |  |  | (41 | ) |
| Net cash provided by operating activities |  | 191 |  |  | 249 |  |  | 504 |  |  | 511 |  |
| Net cash used in discontinued operating activities |  | (1 | ) |  | (4 | ) |  | (12 | ) |  | (1 | ) |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures |  | (66 | ) |  | (60 | ) |  | (209 | ) |  | (183 | ) |
| Acquisition of businesses, net of cash acquired |  | (6 | ) |  | — |  |  | (320 | ) |  | (525 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (6 | ) |  | (5 | ) |  | (17 | ) |  | (13 | ) |
| Divestiture of businesses, net of cash divested |  | 5 |  |  | — |  |  | 14 |  |  | (1 | ) |
| Sales and maturities of investments including restricted investments |  | 18 |  |  | 4 |  |  | 26 |  |  | 283 |  |
| Purchases of investments including restricted investments |  | (1 | ) |  | (2 | ) |  | (8 | ) |  | (290 | ) |
| (Increase) decrease in restricted cash |  | (21 | ) |  | 12 |  |  | 3 |  |  | (27 | ) |
| Other |  | (1 | ) |  | 2 |  |  | — |  |  | 4 |  |
| Net cash used in investing activities |  | (78 | ) |  | (49 | ) |  | (511 | ) |  | (752 | ) |
| Net cash (used in) provided by discontinued investing activities |  | — |  |  | (22 | ) |  | 4 |  |  | (37 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt |  | 1,681 |  |  | 258 |  |  | 4,179 |  |  | 258 |  |
| Repayment of short-term debt |  | (1,740 | ) |  | (258 | ) |  | (3,838 | ) |  | (259 | ) |
| Repayment of current portion of long-term debt |  | — |  |  | — |  |  | (1,134 | ) |  | — |  |
| Proceeds from issuance of long-term debt |  | — |  |  | 3 |  |  | — |  |  | 570 |  |
| Proceeds from exercise of share options |  | 31 |  |  | 13 |  |  | 57 |  |  | 70 |  |
| Dividends paid |  | (87 | ) |  | (86 | ) |  | (261 | ) |  | (237 | ) |
| Repurchase of ordinary shares |  | — |  |  | — |  |  | — |  |  | (417 | ) |
| Transfer to discontinued operations |  | (1 | ) |  | (26 | ) |  | (8 | ) |  | (38 | ) |
| Payment of contingent consideration |  | — |  |  | — |  |  | (1 | ) |  | (23 | ) |
| Debt financing costs |  | — |  |  | (1 | ) |  | (23 | ) |  | (5 | ) |
| Other |  | 1 |  |  | (2 | ) |  | (12 | ) |  | (21 | ) |
| Net cash used in financing activities |  | (115 | ) |  | (99 | ) |  | (1,041 | ) |  | (102 | ) |
| Net cash provided by discontinued financing activities |  | 1 |  |  | 26 |  |  | 8 |  |  | 38 |  |
| Effect of currency translation on cash |  | 2 |  |  | (2 | ) |  | (8 | ) |  | (18 | ) |
| Net increase (decrease) in cash and cash equivalents |  | — |  |  | 99 |  |  | (1,056 | ) |  | (361 | ) |
| Cash and cash equivalents at beginning of period |  | 345 |  |  | 432 |  |  | 1,401 |  |  | 892 |  |
| Cash and cash equivalents at end of period |  | $ | 345 |  |  | $ | 531 |  |  | $ | 345 |  |  | $ | 531 |  |

[0000833444-16-000194:8k_2_02:97]
|  |  | For the Quarters Ended |  | For the Nine Months Ended |
|  |  | June 24, 2016 |  | June 26, 2015 |  | June 24, 2016 |  | June 26, 2015 |
| Reconciliation to "Free Cash Flow": |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 191 |  |  | $ | 249 |  |  | $ | 504 |  |  | $ | 511 |  |
| Capital expenditures, net |  | (65 | ) |  | (59 | ) |  | (207 | ) |  | (179 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (6 | ) |  | (5 | ) |  | (17 | ) |  | (13 | ) |
| Payment of contingent consideration |  | (1 | ) |  | 1 |  |  | (2 | ) |  | (23 | ) |
| Voluntary pension contributions |  | — |  |  | — |  |  | 4 |  |  | — |  |
| Free Cash Flow |  | $ | 119 |  |  | $ | 186 |  |  | $ | 282 |  |  | $ | 296 |  |
| Reconciliation to "Adjusted Free Cash Flow": |  |  |  |  |  |  |  |  |
| IRS litigation costs |  | $ | 2 |  |  | $ | — |  |  | $ | 5 |  |  | $ | — |  |
| Separation costs |  | — |  |  | — |  |  | — |  |  | 3 |  |
| Restructuring and repositioning costs (FY15 and prior) |  | 16 |  |  | 48 |  |  | 84 |  |  | 119 |  |
| Environmental remediation payments |  | — |  |  | (1 | ) |  | 2 |  |  | 7 |  |
| Legal settlements |  | — |  |  | (4 | ) |  | 14 |  |  | (16 | ) |
| Satisfaction of pension obligation |  | 39 |  |  | — |  |  | 39 |  |  | — |  |
| Net asbestos payments |  | 5 |  |  | — |  |  | 15 |  |  | 8 |  |
| Merger costs |  | 12 |  |  | — |  |  | 20 |  |  | — |  |
| Cash payment to ADT Resi / Pentair |  | 1 |  |  | — |  |  | 17 |  |  | 1 |  |
| Cash payment to Covidien / TE Connectivity |  | 16 |  |  | — |  |  | 138 |  |  | — |  |
| Acquisition / integration costs |  | 4 |  |  | 1 |  |  | 9 |  |  | 4 |  |
| Special Items |  | $ | 95 |  |  | $ | 44 |  |  | $ | 343 |  |  | $ | 126 |  |
| Adjusted Free Cash Flow |  | $ | 214 |  |  | $ | 230 |  |  | $ | 625 |  |  | $ | 422 |  |

[0000833444-16-000194:8k_2_02:98]
Note: Free cash flow is a non-GAAP measure.  See description of non-GAAP measures contained in this release.

[0000833444-16-000194:8k_2_02:99]
TYCO INTERNATIONAL PLC

[0000833444-16-000194:8k_2_02:100]
ORGANIC GROWTH RECONCILIATION - REVENUE

[0000833444-16-000194:8k_2_02:101]
(in millions)

[0000833444-16-000194:8k_2_02:102]
(Unaudited)

[0000833444-16-000194:8k_2_02:103]
|  |  |  |  | Quarter Ended June 24, 2016 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Quarter Ended June 26, 2015 |  | Adjustments |  | Adjusted Fiscal 2015 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Quarter Ended June 24, 2016 |
|  |  |  | Divestitures / Other |  |  | Foreign Currency |  | Acquisitions |  | Organic Revenue(1) |  |
| NA Integrated Solutions & Services |  | $ | 972 |  |  | $ | — |  |  | — | % |  | $ | 972 |  |  | $ | (5 | ) |  | (0.5 | )% |  | $ | 13 |  |  | 1.3 | % |  | $ | 24 |  |  | 2.5 | % |  | $ | 1,004 |  |  | 3.3 | % |
| ROW Integrated Solutions & Services |  | 842 |  |  | (72 | ) |  | (8.6 | )% |  | 770 |  |  | (48 | ) |  | (5.7 | )% |  | 57 |  |  | 6.8 | % |  | 15 |  |  | 1.9 | % |  | 794 |  |  | (5.7 | )% |
| Global Products |  | 675 |  |  | (12 | ) |  | (1.8 | )% |  | 663 |  |  | (10 | ) |  | (1.5 | )% |  | — |  |  | — | % |  | (2 | ) |  | (0.3 | )% |  | 651 |  |  | (3.6 | )% |
| Total Net Revenue |  | $ | 2,489 |  |  | $ | (84 | ) |  | (3.4 | )% |  | $ | 2,405 |  |  | $ | (63 | ) |  | (2.5 | )% |  | $ | 70 |  |  | 2.8 | % |  | $ | 37 |  |  | 1.5 | % |  | $ | 2,449 |  |  | (1.6 | )% |

[0000833444-16-000194:8k_2_02:104]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2015 base revenue. |

[0000833444-16-000194:8k_2_02:105]
|  |  |  |  | Nine Months Ended June 24, 2016 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Nine Months Ended June 26, 2015 |  | Adjustments |  | Adjusted Fiscal 2015 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Nine Months Ended June 24, 2016 |
|  |  |  | Divestitures / Other |  |  | Foreign Currency |  | Acquisitions |  |  | Organic Revenue (1) |  |
| NA Integrated Solutions & Services |  | $ | 2,867 |  |  | $ | — |  |  | — | % |  | $ | 2,867 |  |  | $ | (31 | ) |  | (1.1 | )% |  | $ | 25 |  |  | 0.9 | % |  |  | $ | 43 |  |  | 1.5 | % |  | $ | 2,904 |  |  | 1.3 | % |
| ROW Integrated Solutions & Services |  | 2,605 |  |  | (156 | ) |  | (6.0 | )% |  | 2,449 |  |  | (222 | ) |  | (8.5 | )% |  | 150 |  |  | 5.8 | % |  |  | (3 | ) |  | (0.1 | )% |  | 2,374 |  |  | (8.9 | )% |
| Global Products |  | 1,925 |  |  | (16 | ) |  | (0.8 | )% |  | 1,909 |  |  | (63 | ) |  | (3.3 | )% |  | 56 |  |  | 2.9 | % |  |  | (24 | ) |  | (1.3 | )% |  | 1,878 |  |  | (2.4 | )% |
| Total Net Revenue |  | $ | 7,397 |  |  | $ | (172 | ) |  | (2.3 | )% |  | $ | 7,225 |  |  | $ | (316 | ) |  | (4.3 | )% |  | $ | 231 |  |  | 3.1 | % |  |  | $ | 16 |  |  | 0.2 | % |  | $ | 7,156 |  |  | (3.3 | )% |

[0000833444-16-000194:8k_2_02:106]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2015 base revenue. |

[0000833444-16-000194:8k_2_02:107]
Earnings Per Share Summary

[0000833444-16-000194:8k_2_02:108]
(Unaudited)

[0000833444-16-000194:8k_2_02:109]
|  |  | Quarter Ended |  | Quarter Ended |
|  |  | June 24, 2016 |  | June 26, 2015 |
| Diluted EPS from Continuing Operations Attributable to Tyco Shareholders (GAAP) |  | $ | 0.56 |  |  | $ | 0.44 |  |
| expense / (benefit) |  |  |  |  |
| Merger costs |  | 0.04 |  |  | — |  |
| (Gains) / losses on divestitures, net included in SG&A |  | 0.09 |  |  | (0.01 | ) |
| Acquisition / integration costs |  | 0.01 |  |  | — |  |
| TSA adjustment |  | (0.13 | ) |  | — |  |
| Asbestos |  | — |  |  | 0.02 |  |
| Tax items |  | (0.04 | ) |  | — |  |
| Total Before Special Items |  | $ | 0.54 |  |  | $ | 0.46 |  |

[0000833444-16-000194:8k_2_02:110]
Note:  Sum of EPS before special items does not equal total due to rounding.

[0000833444-16-000194:8k_2_02:111]
Tyco International plc

[0000833444-16-000194:8k_2_02:112]
For the Quarter Ended June 24, 2016

[0000833444-16-000194:8k_2_02:113]
(in millions, except per share data)

[0000833444-16-000194:8k_2_02:114]
(Unaudited)

[0000833444-16-000194:8k_2_02:115]
expense / (benefit)

[0000833444-16-000194:8k_2_02:116]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | NA Integrated Solutions& Services |  |  |  | ROW Integrated Solutions & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  | $1,004 |  |  |  |  |  | $794 |  |  |  |  |  | $651 |  |  |  |  |  | $2,449 |  |  |  |  | $— |  |  |  |  |  | $2,449 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | NA Integrated Solutions& Services |  | Margin |  | ROW Integrated Solutions & Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome | Margin |  | Corporateand Other |  | Restructuring and Repositioning |  | Total OperatingIncome | Margin |  | Interest (Expense), net |  | Other (Expense) Income, net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  | $148 |  |  | 14.7 | % |  |  | $36 |  |  | 4.5 | % |  |  | $115 |  |  | 17.7 | % |  |  | $299 |  | 12.2 | % |  |  | ($50 | ) |  |  | ($13 | ) |  |  | $236 |  | 9.6 | % |  |  | ($19 | ) |  |  | $54 |  |  |  | ($31 | ) |  |  | $— |  |  |  | $1 |  |  | $241 |  |  | $0.56 |  |
| Amortization of acquired backlog included in revenue |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Restructuring and repositioning reversals (FY15 and prior) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (2 | ) |  | (2 | ) |  |  |  |  |  |  | 1 |  |  |  |  |  | (1 | ) | — |  |
| Merger costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 19 |  |  |  |  | 19 |  |  |  |  |  |  |  |  |  |  |  |  | 19 |  | 0.04 |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  | 52 |  |  |  |  | (1 | ) |  |  |  | 51 |  |  |  | (13 | ) |  |  |  | 38 |  |  |  |  |  |  |  | (1 | ) |  |  |  |  | 37 |  | 0.09 |  |
| Acquisition / integration costs |  |  |  |  | 3 |  |  |  |  | 1 |  |  |  |  | 4 |  |  |  | 1 |  |  |  |  | 5 |  |  |  |  |  |  |  |  |  |  |  |  | 5 |  | 0.01 |  |
| Legacy legal items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  | (1 | ) |  |  |  |  | — |  | — |  |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (2 | ) |  |  |  | (2 | ) |  |  |  |  |  |  | 1 |  |  |  |  |  | (1 | ) | — |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  | 1 |  | — |  |
| TSA adjustment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (54 | ) |  |  |  |  |  |  | (54 | ) | (0.13 | ) |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (17 | ) |  |  |  |  | (17 | ) | (0.04 | ) |
| Total Before Special Items |  | $148 |  |  | 14.7 | % |  |  | $92 |  |  | 11.6 | % |  |  | $115 |  |  | 17.7 | % |  |  | $355 |  | 14.5 | % |  |  | ($44 | ) |  |  | ($15 | ) |  |  | $296 |  | 12.1 | % |  |  | ($19 | ) |  |  | $1 |  |  |  | ($48 | ) |  |  | $— |  |  |  | $1 |  |  | $231 |  |  | $0.54 |  |
| Note: Sum of EPS before special items does not equal total due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  | 429 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 429 |  |

[0000833444-16-000194:8k_2_02:117]
Tyco International plc

[0000833444-16-000194:8k_2_02:118]
For the Quarter Ended June 26, 2015

[0000833444-16-000194:8k_2_02:119]
(in millions, except per share data)

[0000833444-16-000194:8k_2_02:120]
(Unaudited)

[0000833444-16-000194:8k_2_02:121]
expense / (benefit)

[0000833444-16-000194:8k_2_02:122]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  |  |  | ROW Integrated Solutions & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $972 |  |  |  |  |  | $842 |  |  |  |  |  | $675 |  |  |  |  |  | $2,489 |  |  |  |  |  | $— |  |  |  |  |  | $2,489 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  | Margin |  | ROW Integrated Solutions & Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Restructuring and Repositioning |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other Income, net |  | Income Tax (Expense) |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $157 |  |  | 16.2 | % |  |  | $97 |  |  | 11.5 | % |  |  | $113 |  |  | 16.7 | % |  |  | $367 |  |  | 14.7 | % |  |  | ($49 | ) |  |  | ($65 | ) |  |  | $253 |  |  | 10.2 | % |  |  | ($22 | ) |  |  | $6 |  |  |  | ($49 | ) |  |  | $— |  |  |  | $188 |  |  | $0.44 |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  | (5 | ) |  |  |  | 1 |  |  |  |  | (4 | ) |  |  |  |  |  |  |  | (4 | ) |  |  |  |  |  |  |  | 1 |  |  |  |  | (3 | ) | (0.01 | ) |
| Acquisition / integration costs |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  | 1 |  | — |  |
| Settlement with former management |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (2 | ) |  |  |  | (2 | ) |  |  |  |  |  |  |  | 1 |  |  |  |  | (1 | ) | — |  |
| Amortization of inventory step-up |  |  |  |  |  |  |  |  |  | 3 |  |  |  |  | 3 |  |  |  |  |  |  |  |  | 3 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  | 2 |  | — |  |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 9 |  |  |  |  | 10 |  | 0.02 |  |
| Amortization of acquired backlog |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Total Before Special Items |  |  | $157 |  |  | 16.2 | % |  |  | $93 |  |  | 11.0 | % |  |  | $119 |  |  | 17.6 | % |  |  | $369 |  |  | 14.8 | % |  |  | ($50 | ) |  |  | ($65 | ) |  |  | $254 |  |  | 10.2 | % |  |  | ($22 | ) |  |  | $6 |  |  |  | ($40 | ) |  |  | $— |  |  |  | $198 |  |  | $0.46 |  |
| Note: Sum of EPS before special items does not equal total due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 427 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 427 |  |
