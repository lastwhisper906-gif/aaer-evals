# JCI 8-K — 0000833444-19-000017 filed 2019-05-01

## item codes, every 8-K on or before 2019-05-03

- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2019-05-03

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-19-000017:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq2fy19.htm
EXHIBIT 99.1

[0000833444-19-000017:8k_2_02:2]
Exhibit

[0000833444-19-000017:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000833444-19-000017:8k_2_02:4]
| CONTACT: | Investors:Antonella Franzen(609) 720-4665Ryan Edelman(609) 720-4545Media:Fraser Engerman(414) 524-2733 | Exhibit 99.1 |

[0000833444-19-000017:8k_2_02:5]
Johnson Controls reports strong organic revenue and earnings growth in fiscal Q2;

[0000833444-19-000017:8k_2_02:6]
Closes sale of Power Solutions business and increases fiscal 2019 guidance

[0000833444-19-000017:8k_2_02:7]
________________________________________________________________________________

[0000833444-19-000017:8k_2_02:8]
| ▪ | GAAP EPS from continuing operations of $0.26 per share, including special items |

[0000833444-19-000017:8k_2_02:9]
| ▪ | Adjusted EPS from continuing operations of $0.32, up 23% versus prior year |

[0000833444-19-000017:8k_2_02:10]
| ▪ | Sales of $5.8 billion, up 3%, reflecting organic growth of 6%; Field up 3% with organic growth of 6%; Products up 2% with organic growth of 7% |

[0000833444-19-000017:8k_2_02:11]
| ▪ | Field orders up 2% organically versus prior year; Backlog up 6% organically versus prior year |

[0000833444-19-000017:8k_2_02:12]
| ▪ | Repurchased approximately 16 million shares in the quarter for $533 million |

[0000833444-19-000017:8k_2_02:13]
| ▪ | Closed sale of Power Solutions business with net cash proceeds of approximately $11.6 billion |

[0000833444-19-000017:8k_2_02:14]
| ▪ | Increased fiscal 2019 adjusted EPS from continuing operations guidance to $1.85 to $1.95, representing a year-over-year increase of 16% to 23% |

[0000833444-19-000017:8k_2_02:15]
________________________________________________________________________________

[0000833444-19-000017:8k_2_02:16]
CORK, Ireland, May 1, 2019 -- Johnson Controls International plc (NYSE: JCI) today reported fiscal second quarter 2019 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.26.  Excluding these items, adjusted EPS from continuing operations was $0.32, up 23% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-19-000017:8k_2_02:17]
Sales of $5.8 billion increased 3% compared to the prior year.  Excluding the impacts of M&A and foreign currency, sales grew 6% organically.

[0000833444-19-000017:8k_2_02:18]
GAAP earnings before interest and taxes (“EBIT”) was $419 million and EBIT margin was 7.3%. Adjusted EBIT was $469 million and adjusted EBIT margin was 8.1%, up 60 basis points over the prior year.  Excluding the impact of M&A and foreign currency, the underlying adjusted EBIT margin increased 70 basis points.

[0000833444-19-000017:8k_2_02:19]
Page 1 of 16

[0000833444-19-000017:8k_2_02:20]
On April 30, 2019, the Company closed the previously announced sale of the Power Solutions business to Brookfield Business Partners for net cash proceeds of approximately $11.6 billion.  As previously stated, net cash proceeds are expected to be used to reduce $3.4 billion in existing debt, and fund the repurchase of up to $8.2 billion in ordinary shares.

[0000833444-19-000017:8k_2_02:21]
Separately, in connection with the closing of the transaction, the Company announced today that it plans to launch a “modified Dutch auction” tender offer in the coming days for up to $4.0 billion of its ordinary shares with a price range between $36.00 and $40.00 per share. The Company also announced that it has commenced a cash tender offer to purchase up to $1.5 billion in aggregate principal amount of certain of its outstanding notes.  For additional information regarding the debt tender, please refer to the debt tender offer press release issued by the Company concurrently with this release.

[0000833444-19-000017:8k_2_02:22]
“Johnson Controls delivered another strong quarter, demonstrating continued organic top-line momentum and our commitment to operational execution,” said George Oliver, chairman and CEO.  “Given the strength of our backlog, visibility into our order pipeline, and strategic initiatives to improve profitability, I am confident in our outlook for the second half.  Additionally, we closed the Power Solutions transaction ahead of schedule, which enables us to accelerate our efforts to return capital to shareholders.”

[0000833444-19-000017:8k_2_02:23]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-19-000017:8k_2_02:24]
($ millions, except per-share amounts)

[0000833444-19-000017:8k_2_02:25]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal second quarter of 2018.  The results of Power Solutions are reported as discontinued operations in all periods presented.

[0000833444-19-000017:8k_2_02:26]
Organic sales growth, organic EBITA growth, adjusted segment EBITA, adjusted EBIT, adjusted EPS from continuing operations and adjusted free cash flow are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes.  A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-19-000017:8k_2_02:27]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2018 |  | Q2 2019 |  | Q2 2018 |  | Q2 2019 |  | Change |
| Sales |  | $5,630 |  | $5,779 |  | $5,630 |  | $5,779 |  | +3% |
| Segment EBITA |  | 615 |  | 664 |  | 630 |  | 671 |  | +7% |
| EBIT |  | 361 |  | 419 |  | 425 |  | 469 |  | +10% |
| Net income from continuing operations |  | 184 |  | 240 |  | 246 |  | 287 |  | +17% |
| Diluted EPS from continuing operations |  | $0.20 |  | $0.26 |  | $0.26 |  | $0.32 |  | +23% |

[0000833444-19-000017:8k_2_02:28]
Page 2 of 16

[0000833444-19-000017:8k_2_02:29]
BUSINESS RESULTS

[0000833444-19-000017:8k_2_02:30]
Building Solutions North America

[0000833444-19-000017:8k_2_02:31]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2018 |  | Q2 2019 |  | Q2 2018 |  | Q2 2019 |  | Change |
| Sales |  | $2,097 |  | $2,187 |  | $2,097 |  | $2,187 |  | 4% |
| Segment EBITA |  | $239 |  | $257 |  | $244 |  | $259 |  | 6% |
| Segment EBITA margin % |  | 11.4% |  | 11.8% |  | 11.6% |  | 11.8% |  | 20bps |

[0000833444-19-000017:8k_2_02:32]
Sales in the quarter of $2.2 billion increased 4% versus the prior year.  Excluding M&A and foreign currency, organic sales increased 5% versus the prior year driven by solid growth across HVAC & Controls and Fire & Security.

[0000833444-19-000017:8k_2_02:33]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 2% year-over-year.  Backlog at the end of the quarter of $5.6 billion increased 5% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-19-000017:8k_2_02:34]
Adjusted segment EBITA was $259 million, up 6% versus the prior year. Adjusted segment EBITA margin of 11.8% expanded 20 basis points versus the prior year as favorable volume leverage as well as cost synergies and productivity savings, were partially offset by unfavorable mix and run-rate salesforce additions.

[0000833444-19-000017:8k_2_02:35]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-19-000017:8k_2_02:36]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2018 |  | Q2 2019 |  | Q2 2018 |  | Q2 2019 |  | Change |
| Sales |  | $907 |  | $878 |  | $907 |  | $878 |  | (3%) |
| Segment EBITA |  | $77 |  | $80 |  | $78 |  | $81 |  | 4% |
| Segment EBITA margin % |  | 8.5% |  | 9.1% |  | 8.6% |  | 9.2% |  | 60bps |

[0000833444-19-000017:8k_2_02:37]
Sales in the quarter of $878 million declined 3% versus the prior year.  Excluding M&A and foreign currency, organic sales grew 4% versus the prior year driven by strong growth in service and project installation. Growth was positive across most regions, led by strength in Fire & Security and Industrial Refrigeration in Europe and Latin America.

[0000833444-19-000017:8k_2_02:38]
Page 3 of 16

[0000833444-19-000017:8k_2_02:39]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 3% year-over-year.  Backlog at the end of the quarter of $1.7 billion increased 9% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-19-000017:8k_2_02:40]
Adjusted segment EBITA was $81 million, up 4% versus the prior year. Adjusted segment EBITA margin of 9.2% expanded 60 basis points over the prior year, including a 40 basis point headwind related to foreign currency.  Adjusting for foreign currency, the underlying margin improved 100 basis points driven by favorable volume, as well as the benefit from cost synergies and productivity savings, partially offset by run-rate salesforce additions.

[0000833444-19-000017:8k_2_02:41]
Building Solutions Asia Pacific

[0000833444-19-000017:8k_2_02:42]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2018 |  | Q2 2019 |  | Q2 2018 |  | Q2 2019 |  | Change |
| Sales |  | $586 |  | $628 |  | $586 |  | $628 |  | 7% |
| Segment EBITA |  | $71 |  | $76 |  | $71 |  | $76 |  | 7% |
| Segment EBITA margin % |  | 12.1% |  | 12.1% |  | 12.1% |  | 12.1% |  | Flat |

[0000833444-19-000017:8k_2_02:43]
Sales in the quarter of $628 million increased 7% versus the prior year.  Excluding M&A and foreign currency, organic sales increased 12% versus the prior year driven primarily by double digit growth in project installations.

[0000833444-19-000017:8k_2_02:44]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 1% year-over-year.  Backlog at the end of the quarter of $1.6 billion increased 8% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-19-000017:8k_2_02:45]
Adjusted segment EBITA was $76 million, up 7% versus the prior year. Adjusted segment EBITA margin of 12.1% was unchanged versus the prior year as favorable volume was more than offset by unfavorable mix, run-rate salesforce additions and expected underlying margin pressure.

[0000833444-19-000017:8k_2_02:46]
Global Products

[0000833444-19-000017:8k_2_02:47]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2018 |  | Q2 2019 |  | Q2 2018 |  | Q2 2019 |  | Change |
| Sales |  | $2,040 |  | $2,086 |  | $2,040 |  | $2,086 |  | 2% |
| Segment EBITA |  | $228 |  | $251 |  | $237 |  | $255 |  | 8% |
| Segment EBITA margin % |  | 11.2% |  | 12.0% |  | 11.6% |  | 12.2% |  | 60bps |

[0000833444-19-000017:8k_2_02:48]
Page 4 of 16

[0000833444-19-000017:8k_2_02:49]
Sales in the quarter of $2.1 billion increased 2% versus the prior year. Excluding M&A and foreign currency, organic sales increased 7% versus the prior year with low-double digit growth in Building Management Systems, mid-single digit growth in HVAC & Refrigeration Equipment, and low-double digit growth in Specialty Products.

[0000833444-19-000017:8k_2_02:50]
Adjusted segment EBITA was $255 million, up 8% versus the prior year. Adjusted segment EBITA margin of 12.2% expanded 60 basis points over the prior year. This increase was driven by favorable volume and mix, positive price/cost as well as the benefit of cost synergies and productivity savings, slightly offset by ongoing product investments.

[0000833444-19-000017:8k_2_02:51]
Corporate

[0000833444-19-000017:8k_2_02:52]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2018 |  | Q2 2019 |  | Q2 2018 |  | Q2 2019 |  | Change |
| Corporate expense |  | ($162) |  | ($167) |  | ($113) |  | ($104) |  | (8%) |

[0000833444-19-000017:8k_2_02:53]
Adjusted Corporate expense was $104 million in the quarter, a decrease of 8% compared to the prior year, driven primarily by continued cost synergies and productivity savings.

[0000833444-19-000017:8k_2_02:54]
OTHER ITEMS

[0000833444-19-000017:8k_2_02:55]
| • | For the quarter, cash provided by operating activities from continuing operations was $0.2 billion and capital expenditures were $0.1 billion, resulting in free cash flow from continuing operations of $0.1 billion. Adjusted free cash flow was $0.2 billion, which excludes net cash outflows of $0.1 billion primarily related to integration costs. |

[0000833444-19-000017:8k_2_02:56]
| • | Year-to-date, cash provided by operating activities from continuing operations was $0.1 billion and capital expenditures were $0.3 billion, resulting in a free cash outflow from continuing operations of $0.2 billion. Adjusted free cash flow was neutral, which excludes net cash outflows of $0.2 billion primarily related to restructuring and integration costs. |

[0000833444-19-000017:8k_2_02:57]
| • | During the quarter, the Company repurchased approximately 16 million shares for $533 million. Year-to-date, the Company repurchased approximately 30 million shares for $1 billion. |

[0000833444-19-000017:8k_2_02:58]
| ▪ | The Company is increasing its outlook for fiscal 2019 adjusted EPS before special items from continuing operations to a range of $1.85 to $1.95, representing a year-over-year increase of 16% to 23%. The updated outlook reflects the incremental use of Power Solutions sale proceeds, which are now expected to result in an approximate $0.15 benefit versus a $0.05 benefit previously expected. |

[0000833444-19-000017:8k_2_02:59]
###

[0000833444-19-000017:8k_2_02:60]
Page 5 of 16

[0000833444-19-000017:8k_2_02:61]
About Johnson Controls:

[0000833444-19-000017:8k_2_02:62]
Johnson Controls is a global leader creating a safe, comfortable and sustainable world. Our 105,000 employees create intelligent buildings, efficient energy solutions and integrated infrastructure that work seamlessly together to deliver on the promise of smart cities and communities in 150 countries. Our commitment to sustainability dates back to our roots in 1885, with the invention of the first electric room thermostat. We are committed to helping our customers win everywhere, every day and creating greater value for all of our stakeholders through our strategic focus on buildings. For additional information, please visit http://www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter.

[0000833444-19-000017:8k_2_02:63]
###

[0000833444-19-000017:8k_2_02:64]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-19-000017:8k_2_02:65]
###

[0000833444-19-000017:8k_2_02:66]
Page 6 of 16

[0000833444-19-000017:8k_2_02:67]
Non-GAAP Financial Information

[0000833444-19-000017:8k_2_02:68]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include net mark-to-market adjustments, transaction/integration costs, restructuring and impairment costs, Scott Safety gain on sale, the impact of ceasing the depreciation/amortization expense for the Power Solutions business as the business is held for sale and discrete tax items. Financial information regarding organic sales, adjusted segment EBITA, adjusted organic segment EBITA, adjusted segment EBITA margin, adjusted free cash flow and adjusted free cash flow conversion are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as transaction/integration costs and Scott Safety gain on sale because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.

[0000833444-19-000017:8k_2_02:69]
Additional Information and Where to Find It

[0000833444-19-000017:8k_2_02:70]
This news release is for informational purposes only, is not a recommendation to buy or sell any securities of Johnson Controls, and does not constitute an offer to buy or the solicitation to sell any securities of Johnson Controls.

[0000833444-19-000017:8k_2_02:71]
The equity tender offer has not yet commenced, and there can be no assurances that Johnson Controls will commence the equity tender offer on the terms described in this new release or at all. On the commencement date of the equity tender offer, Johnson Controls will file a tender offer statement on Schedule TO, including an offer to purchase, letter of transmittal and related materials, with the SEC.  The equity tender offer will be made only pursuant to the offer to purchase, the related letter of transmittal and other related materials filed as part of the Schedule TO with the SEC upon commencement of the equity tender offer.  When available, shareholders should read carefully the offer to purchase, letter of transmittal and related materials because they will contain important information, including the various terms of, and conditions to, the equity tender offer. Once the equity tender offer is commenced, shareholders will be able to obtain a free copy of the tender offer statement on Schedule TO, the offer to purchase, letter of transmittal and other documents that Johnson Controls will be filing with the SEC at the SEC’s website at www.sec.gov or from Johnson Control’s information agent in connection with the equity tender offer.

[0000833444-19-000017:8k_2_02:72]
Additionally, the debt tender offer described in this news release is being made solely on the terms and subject to the conditions set forth in the offering materials relating to the debt tender and the information in this press release is qualified by reference to such offering materials.

[0000833444-19-000017:8k_2_02:73]
###

[0000833444-19-000017:8k_2_02:74]
Page 7 of 16

[0000833444-19-000017:8k_2_02:75]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Three Months Ended March 31, |
|  |  | 2019 |  |  | 2018 |
| Net sales | $ | 5,779 |  |  |  | $ | 5,630 |  |
| Cost of sales | 3,935 |  |  |  | 3,806 |  |
|  | Gross profit | 1,844 |  |  |  | 1,824 |  |
| Selling, general and administrative expenses | (1,458 | ) |  |  | (1,490 | ) |
| Net financing charges | (98 | ) |  |  | (107 | ) |
| Equity income | 33 |  |  |  | 27 |  |
| Income from continuing operations before income taxes | 321 |  |  |  | 254 |  |
| Income tax provision | 47 |  |  |  | 36 |  |
| Income from continuing operations | 274 |  |  |  | 218 |  |
| Income from discontinued operations, net of tax | 284 |  |  |  | 265 |  |
| Net income | 558 |  |  |  | 483 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 34 |  |  |  | 34 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | 9 |  |  |  | 11 |  |
| Net income attributable to JCI | $ | 515 |  |  |  | $ | 438 |  |
| Income from continuing operations | $ | 240 |  |  |  | $ | 184 |  |
| Income from discontinued operations | 275 |  |  |  | 254 |  |
| Net income attributable to JCI | $ | 515 |  |  |  | $ | 438 |  |
| Diluted earnings per share from continuing operations | $ | 0.26 |  |  |  | $ | 0.20 |  |
| Diluted earnings per share from discontinued operations | 0.30 |  |  |  | 0.27 |  |
| Diluted earnings per share * | $ | 0.57 |  |  |  | $ | 0.47 |  |
| Diluted weighted average shares | 905.9 |  |  |  | 932.5 |  |
| Shares outstanding at period end | 898.1 |  |  |  | 926.2 |  |

[0000833444-19-000017:8k_2_02:76]
* May not sum due to rounding.

[0000833444-19-000017:8k_2_02:77]
Page 8 of 16

[0000833444-19-000017:8k_2_02:78]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Six Months Ended March 31, |
|  |  | 2019 |  |  | 2018 |
| Net sales | $ | 11,243 |  |  |  | $ | 10,935 |  |
| Cost of sales | 7,674 |  |  |  | 7,413 |  |
|  | Gross profit | 3,569 |  |  |  | 3,522 |  |
| Selling, general and administrative expenses | (2,896 | ) |  |  | (2,809 | ) |
| Restructuring and impairment costs | — |  |  |  | (154 | ) |
| Net financing charges | (183 | ) |  |  | (209 | ) |
| Equity income | 75 |  |  |  | 74 |  |
| Income from continuing operations before income taxes | 565 |  |  |  | 424 |  |
| Income tax provision | 155 |  |  |  | 253 |  |
| Income from continuing operations | 410 |  |  |  | 171 |  |
| Income from discontinued operations, net of tax | 547 |  |  |  | 583 |  |
| Net income | 957 |  |  |  | 754 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 63 |  |  |  | 62 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | 24 |  |  |  | 24 |  |
| Net income attributable to JCI | $ | 870 |  |  |  | $ | 668 |  |
| Income from continuing operations | $ | 347 |  |  |  | $ | 109 |  |
| Income from discontinued operations | 523 |  |  |  | 559 |  |
| Net income attributable to JCI | $ | 870 |  |  |  | $ | 668 |  |
| Diluted earnings per share from continuing operations | $ | 0.38 |  |  |  | $ | 0.12 |  |
| Diluted earnings per share from discontinued operations | 0.57 |  |  |  | 0.60 |  |
| Diluted earnings per share | $ | 0.95 |  |  |  | $ | 0.72 |  |
| Diluted weighted average shares | 915.6 |  |  |  | 932.9 |  |
| Shares outstanding at period end | 898.1 |  |  |  | 926.2 |  |

[0000833444-19-000017:8k_2_02:79]
Page 9 of 16

[0000833444-19-000017:8k_2_02:80]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | March 31,2019 |  | September 30,2018 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 239 |  |  | $ | 185 |  |
| Accounts receivable - net | 5,707 |  |  | 5,622 |  |
| Inventories | 2,124 |  |  | 1,819 |  |
| Assets held for sale | 2,999 |  |  | 3,015 |  |
| Other current assets | 1,767 |  |  | 1,182 |  |
|  | Current assets | 12,836 |  |  | 11,823 |  |
| Property, plant and equipment - net | 3,332 |  |  | 3,300 |  |
| Goodwill | 18,311 |  |  | 18,381 |  |
| Other intangible assets - net | 6,015 |  |  | 6,187 |  |
| Investments in partially-owned affiliates | 937 |  |  | 848 |  |
| Noncurrent assets held for sale | 5,229 |  |  | 5,188 |  |
| Other noncurrent assets | 1,829 |  |  | 3,070 |  |
|  | Total assets | $ | 48,489 |  |  | $ | 48,797 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 3,968 |  |  | $ | 1,307 |  |
| Accounts payable and accrued expenses | 4,214 |  |  | 4,428 |  |
| Liabilities held for sale | 1,558 |  |  | 1,791 |  |
| Other current liabilities | 3,701 |  |  | 3,724 |  |
|  | Current liabilities | 13,441 |  |  | 11,250 |  |
| Long-term debt | 8,418 |  |  | 9,623 |  |
| Other noncurrent liabilities | 5,144 |  |  | 5,259 |  |
| Noncurrent liabilities held for sale | 185 |  |  | 207 |  |
| Shareholders' equity attributable to JCI | 20,036 |  |  | 21,164 |  |
| Noncontrolling interests | 1,265 |  |  | 1,294 |  |
|  | Total liabilities and equity | $ | 48,489 |  |  | $ | 48,797 |  |

[0000833444-19-000017:8k_2_02:81]
Page 10 of 16

[0000833444-19-000017:8k_2_02:82]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended March 31, |
|  |  |  |  |  |  | 2019 |  |  | 2018 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI from continuing operations | $ | 240 |  |  |  | $ | 184 |  |
| Income from continuing operations attributable to noncontrolling interests | 34 |  |  |  | 34 |  |
| Net income from continuing operations | 274 |  |  |  | 218 |  |
| Adjustments to reconcile net income from continuing operations to |  |  |  |  |
| cash provided by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 211 |  |  |  | 212 |  |
|  |  | Pension and postretirement benefit income | (28 | ) |  |  | (36 | ) |
|  |  | Pension and postretirement contributions | (16 | ) |  |  | (13 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (31 | ) |  |  | (26 | ) |
|  |  | Deferred income taxes | 460 |  |  |  | 1 |  |
|  |  | Other - net | 5 |  |  |  | 11 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (285 | ) |  |  | (97 | ) |
|  |  |  |  | Inventories | (99 | ) |  |  | (13 | ) |
|  |  |  |  | Other assets | 34 |  |  |  | (37 | ) |
|  |  |  |  | Restructuring reserves | (34 | ) |  |  | (102 | ) |
|  |  |  |  | Accounts payable and accrued liabilities | 209 |  |  |  | 206 |  |
|  |  |  |  | Accrued income taxes | (518 | ) |  |  | (51 | ) |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 182 |  |  |  | 273 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (125 | ) |  |  | (166 | ) |
| Acquisition of businesses, net of cash acquired | — |  |  |  | (15 | ) |
| Business divestitures, net of cash divested | — |  |  |  | 103 |  |
| Other - net | 2 |  |  |  | 9 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (123 | ) |  |  | (69 | ) |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | 530 |  |  |  | (488 | ) |
| Stock repurchases | (533 | ) |  |  | (49 | ) |
| Payment of cash dividends | (239 | ) |  |  | (241 | ) |
| Proceeds from the exercise of stock options | 38 |  |  |  | 20 |  |
| Dividends paid to noncontrolling interests | (89 | ) |  |  | (43 | ) |
| Employee equity-based compensation withholdings | (2 | ) |  |  | (12 | ) |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (295 | ) |  |  | (813 | ) |
| Discontinued Operations |  |  |  |  |
| Net cash provided by operating activities | 309 |  |  |  | 391 |  |
| Net cash used by investing activities | (87 | ) |  |  | (107 | ) |
| Net cash used by financing activities | (17 | ) |  |  | (1 | ) |
|  |  |  |  |  | Net cash flows provided by discontinued operations | 205 |  |  |  | 283 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 5 |  |  |  | 44 |  |
| Changes in cash held for sale | (28 | ) |  |  | (5 | ) |
| Decrease in cash, cash equivalents and restricted cash | $ | (54 | ) |  |  | $ | (287 | ) |

[0000833444-19-000017:8k_2_02:83]
Page 11 of 16

[0000833444-19-000017:8k_2_02:84]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Six Months Ended March 31, |
|  |  |  |  |  |  | 2019 |  |  | 2018 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI from continuing operations | $ | 347 |  |  |  | $ | 109 |  |
| Income from continuing operations attributable to noncontrolling interests | 63 |  |  |  | 62 |  |
| Net income from continuing operations | 410 |  |  |  | 171 |  |
| Adjustments to reconcile net income from continuing operations to |  |  |  |  |
| cash provided by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 422 |  |  |  | 422 |  |
|  |  | Pension and postretirement benefit income | (57 | ) |  |  | (72 | ) |
|  |  | Pension and postretirement contributions | (37 | ) |  |  | (36 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (67 | ) |  |  | (59 | ) |
|  |  | Deferred income taxes | 503 |  |  |  | (79 | ) |
|  |  | Non-cash restructuring and impairment costs | — |  |  |  | 28 |  |
|  |  | Gain on Scott Safety business divestiture | — |  |  |  | (114 | ) |
|  |  | Other - net | 33 |  |  |  | 38 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (139 | ) |  |  | (107 | ) |
|  |  |  |  | Inventories | (321 | ) |  |  | (209 | ) |
|  |  |  |  | Other assets | (29 | ) |  |  | (174 | ) |
|  |  |  |  | Restructuring reserves | (59 | ) |  |  | (6 | ) |
|  |  |  |  | Accounts payable and accrued liabilities | (17 | ) |  |  | (53 | ) |
|  |  |  |  | Accrued income taxes | (539 | ) |  |  | 390 |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 103 |  |  |  | 140 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (278 | ) |  |  | (280 | ) |
| Acquisition of businesses, net of cash acquired | (13 | ) |  |  | (15 | ) |
| Business divestitures, net of cash divested | 6 |  |  |  | 2,114 |  |
| Other - net | 26 |  |  |  | (8 | ) |
|  |  |  |  |  | Cash provided (used) by investing activities from continuing operations | (259 | ) |  |  | 1,811 |  |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | 1,544 |  |  |  | (1,544 | ) |
| Stock repurchases | (1,000 | ) |  |  | (199 | ) |
| Payment of cash dividends | (479 | ) |  |  | (473 | ) |
| Dividends paid to noncontrolling interests | (132 | ) |  |  | (43 | ) |
| Proceeds from the exercise of stock options | 51 |  |  |  | 36 |  |
| Employee equity-based compensation withholdings | (23 | ) |  |  | (36 | ) |
| Other - net | — |  |  |  | (4 | ) |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (39 | ) |  |  | (2,263 | ) |
| Discontinued Operations |  |  |  |  |
| Net cash provided by operating activities | 502 |  |  |  | 397 |  |
| Net cash used by investing activities | (153 | ) |  |  | (228 | ) |
| Net cash provided (used) by financing activities | (28 | ) |  |  | 9 |  |
|  |  |  |  |  | Net cash flows provided by discontinued operations | 321 |  |  |  | 178 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (38 | ) |  |  | 61 |  |
| Changes in cash held for sale | (30 | ) |  |  | 5 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | $ | 58 |  |  |  | $ | (68 | ) |

[0000833444-19-000017:8k_2_02:85]
Page 12 of 16

[0000833444-19-000017:8k_2_02:86]
FOOTNOTES

[0000833444-19-000017:8k_2_02:87]
1. Financial Summary

[0000833444-19-000017:8k_2_02:88]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans. In the first quarter of fiscal 2019, the Company began reporting the Power Solutions business as a discontinued operation, which required retrospective application to previously reported financial information. As a result, the financial results shown below are for continuing operations and exclude the Power Solutions business.

[0000833444-19-000017:8k_2_02:89]
|  | Three Months Ended March 31, |
| (in millions; unaudited) | 2019 |  | 2018 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,187 |  |  | $ | 2,187 |  |  | $ | 2,097 |  |  | $ | 2,097 |  |
| Building Solutions EMEA/LA | 878 |  |  | 878 |  |  | 907 |  |  | 907 |  |
| Building Solutions Asia Pacific | 628 |  |  | 628 |  |  | 586 |  |  | 586 |  |
| Global Products | 2,086 |  |  | 2,086 |  |  | 2,040 |  |  | 2,040 |  |
| Net sales | $ | 5,779 |  |  | $ | 5,779 |  |  | $ | 5,630 |  |  | $ | 5,630 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 257 |  |  | $ | 259 |  |  | $ | 239 |  |  | $ | 244 |  |
| Building Solutions EMEA/LA | 80 |  |  | 81 |  |  | 77 |  |  | 78 |  |
| Building Solutions Asia Pacific | 76 |  |  | 76 |  |  | 71 |  |  | 71 |  |
| Global Products | 251 |  |  | 255 |  |  | 228 |  |  | 237 |  |
| Segment EBITA | 664 |  |  | 671 |  |  | 615 |  |  | 630 |  |
| Corporate expenses (2) | (167 | ) |  | (104 | ) |  | (162 | ) |  | (113 | ) |
| Amortization of intangible assets | (98 | ) |  | (98 | ) |  | (92 | ) |  | (92 | ) |
| Net mark-to-market adjustments (3) | 20 |  |  | — |  |  | — |  |  | — |  |
| Restructuring and impairment costs (4) | — |  |  | — |  |  | — |  |  | — |  |
| EBIT (5) | 419 |  |  | 469 |  |  | 361 |  |  | 425 |  |
| EBIT margin | 7.3 | % |  | 8.1 | % |  | 6.4 | % |  | 7.5 | % |
| Net financing charges | (98 | ) |  | (98 | ) |  | (107 | ) |  | (107 | ) |
| Income from continuing operations before income taxes | 321 |  |  | 371 |  |  | 254 |  |  | 318 |  |
| Income tax provision (6) | (47 | ) |  | (50 | ) |  | (36 | ) |  | (38 | ) |
| Income from continuing operations | 274 |  |  | 321 |  |  | 218 |  |  | 280 |  |
| Income from continuing operations attributable to noncontrolling interests | (34 | ) |  | (34 | ) |  | (34 | ) |  | (34 | ) |
| Net income from continuing operations attributable to JCI | $ | 240 |  |  | $ | 287 |  |  | $ | 184 |  |  | $ | 246 |  |

[0000833444-19-000017:8k_2_02:90]
|  | Six Months Ended March 31, |
| (in millions; unaudited) | 2019 |  | 2018 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 4,303 |  |  | $ | 4,303 |  |  | $ | 4,109 |  |  | $ | 4,109 |  |
| Building Solutions EMEA/LA | 1,785 |  |  | 1,785 |  |  | 1,822 |  |  | 1,822 |  |
| Building Solutions Asia Pacific | 1,241 |  |  | 1,241 |  |  | 1,183 |  |  | 1,183 |  |
| Global Products | 3,914 |  |  | 3,914 |  |  | 3,821 |  |  | 3,821 |  |
| Net sales | $ | 11,243 |  |  | $ | 11,243 |  |  | $ | 10,935 |  |  | $ | 10,935 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 507 |  |  | $ | 512 |  |  | $ | 466 |  |  | $ | 480 |  |
| Building Solutions EMEA/LA | 157 |  |  | 158 |  |  | 146 |  |  | 149 |  |
| Building Solutions Asia Pacific | 142 |  |  | 142 |  |  | 145 |  |  | 145 |  |
| Global Products | 441 |  |  | 449 |  |  | 514 |  |  | 415 |  |
| Segment EBITA | 1,247 |  |  | 1,261 |  |  | 1,271 |  |  | 1,189 |  |
| Corporate expenses (2) | (303 | ) |  | (197 | ) |  | (300 | ) |  | (218 | ) |
| Amortization of intangible assets | (195 | ) |  | (195 | ) |  | (184 | ) |  | (184 | ) |
| Net mark-to-market adjustments (3) | (1 | ) |  | — |  |  | — |  |  | — |  |
| Restructuring and impairment costs (4) | — |  |  | — |  |  | (154 | ) |  | — |  |
| EBIT (5) | 748 |  |  | 869 |  |  | 633 |  |  | 787 |  |
| EBIT margin | 6.7 | % |  | 7.7 | % |  | 5.8 | % |  | 7.2 | % |
| Net financing charges | (183 | ) |  | (183 | ) |  | (209 | ) |  | (209 | ) |
| Income from continuing operations before income taxes | 565 |  |  | 686 |  |  | 424 |  |  | 578 |  |
| Income tax provision (6) | (155 | ) |  | (93 | ) |  | (253 | ) |  | (70 | ) |
| Income from continuing operations | 410 |  |  | 593 |  |  | 171 |  |  | 508 |  |
| Income from continuing operations attributable to noncontrolling interests | (63 | ) |  | (63 | ) |  | (62 | ) |  | (62 | ) |
| Net income from continuing operations attributable to JCI | $ | 347 |  |  | $ | 530 |  |  | $ | 109 |  |  | $ | 446 |  |

[0000833444-19-000017:8k_2_02:91]
(1) The Company's press release contains financial information regarding adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-19-000017:8k_2_02:92]
The following is the three months ended March 31, 2019 and 2018 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-19-000017:8k_2_02:93]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment EBITA as reported | $ | 257 |  |  | $ | 239 |  |  | $ | 80 |  |  | $ | 77 |  |  | $ | 76 |  |  | $ | 71 |  |  | $ | 251 |  |  | $ | 228 |  |  | $ | 664 |  |  | $ | 615 |  |
| Segment EBITA margin as reported | 11.8 | % |  | 11.4 | % |  | 9.1 | % |  | 8.5 | % |  | 12.1 | % |  | 12.1 | % |  | 12.0 | % |  | 11.2 | % |  | 11.5 | % |  | 10.9 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | 2 |  |  | 5 |  |  | 1 |  |  | 1 |  |  | — |  |  | — |  |  | 4 |  |  | 9 |  |  | 7 |  |  | 15 |  |
| Adjusted segment EBITA | $ | 259 |  |  | $ | 244 |  |  | $ | 81 |  |  | $ | 78 |  |  | $ | 76 |  |  | $ | 71 |  |  | $ | 255 |  |  | $ | 237 |  |  | $ | 671 |  |  | $ | 630 |  |
| Adjusted segment EBITA margin | 11.8 | % |  | 11.6 | % |  | 9.2 | % |  | 8.6 | % |  | 12.1 | % |  | 12.1 | % |  | 12.2 | % |  | 11.6 | % |  | 11.6 | % |  | 11.2 | % |

[0000833444-19-000017:8k_2_02:94]
The following is the six months ended March 31, 2019 and 2018 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-19-000017:8k_2_02:95]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment EBITA as reported | $ | 507 |  |  | $ | 466 |  |  | $ | 157 |  |  | $ | 146 |  |  | $ | 142 |  |  | $ | 145 |  |  | $ | 441 |  |  | $ | 514 |  |  | $ | 1,247 |  |  | $ | 1,271 |  |
| Segment EBITA margin as reported | 11.8 | % |  | 11.3 | % |  | 8.8 | % |  | 8.0 | % |  | 11.4 | % |  | 12.3 | % |  | 11.3 | % |  | 13.5 | % |  | 11.1 | % |  | 11.6 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | 5 |  |  | 14 |  |  | 1 |  |  | 3 |  |  | — |  |  | — |  |  | 8 |  |  | 15 |  |  | 14 |  |  | 32 |  |
| Scott Safety gain on sale | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (114 | ) |  | — |  |  | (114 | ) |
| Adjusted segment EBITA | $ | 512 |  |  | $ | 480 |  |  | $ | 158 |  |  | $ | 149 |  |  | $ | 142 |  |  | $ | 145 |  |  | $ | 449 |  |  | $ | 415 |  |  | $ | 1,261 |  |  | $ | 1,189 |  |
| Adjusted segment EBITA margin | 11.9 | % |  | 11.7 | % |  | 8.9 | % |  | 8.2 | % |  | 11.4 | % |  | 12.3 | % |  | 11.5 | % |  | 10.9 | % |  | 11.2 | % |  | 10.9 | % |

[0000833444-19-000017:8k_2_02:96]
Page 13 of 16

[0000833444-19-000017:8k_2_02:97]
(2) Adjusted Corporate expenses for the three months ended March 31, 2019 excludes $61 million of integration costs and $2 million of transaction costs. Adjusted Corporate expenses for the six months ended March 31, 2019 excludes $102 million of integration costs and $4 million of transaction costs. Adjusted Corporate expenses for the three months ended March 31, 2018 excludes $46 million of integration costs and $3 million of transaction costs. Adjusted Corporate expenses for the six months ended March 31, 2018 excludes $74 million of integration costs and $8 million of transaction costs.

[0000833444-19-000017:8k_2_02:98]
(3) On October 1, 2018, the Company adopted Accounting Standards Update (ASU) No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." ASU No. 2016-01 amends certain aspects of recognition, measurement, presentation and disclosure of financial instruments, including marketable securities. The new standard requires the mark-to-market of marketable securities investments previously recorded within accumulated other comprehensive income on the statement of financial position be recorded in the statement of income on a prospective basis beginning as of the adoption date. The three months ended March 31, 2019 exclude the net mark-to-market adjustments on restricted investments of $20 million. The six months ended March 31. 2018 exclude the net mark-to-market adjustments on restricted investments of $1 million. As these restricted investments do not relate to the underlying operating performance of its businesses, the Company’s definition of adjusted segment EBITA and adjusted EBIT excludes the mark-to-market adjustments effective October 1, 2018.

[0000833444-19-000017:8k_2_02:99]
(4) Restructuring and impairment costs for the six months ended March 31, 2018 of $154 million are excluded from the adjusted non-GAAP results. The restructuring actions and impairment costs related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions business and at Corporate.

[0000833444-19-000017:8k_2_02:100]
(5) Management defines earnings before interest and taxes (EBIT) as income from continuing operations before net financing charges, income taxes and noncontrolling interests.

[0000833444-19-000017:8k_2_02:101]
(6) Adjusted income tax provision for the three months ended March 31, 2019 excludes the tax benefits of integration costs of $7 million and transaction costs of $1 million, partially offset by the tax provision for net mark-to-market adjustments of $5 million. Adjusted income tax provision for the six months ended March 31, 2019 excludes the tax provision for valuation allowance adjustments of $76 million as a result of changes in U.S. tax law, partially offset by the tax benefits for integration costs of $13 million and transactions costs of $1 million. Adjusted income tax provision for the three months ended March 31, 2018 excludes the tax benefit for integration costs of $9 million, partially offset by the impact of the third quarter fiscal 2018 effective tax rate change of $7 million. Adjusted income tax provision for the six months ended March 31, 2018 excludes the net tax provision related to the U.S. Tax Reform legislation of $204 million, Scott Safety gain on sale of $30 million and the impact of the third quarter fiscal 2018 effective tax rate change of $13 million, partially offset by tax audit settlements of $25 million, restructuring and impairment costs of $23 million, integration costs of $15 million and transaction costs of $1 million.

[0000833444-19-000017:8k_2_02:102]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-19-000017:8k_2_02:103]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include transaction/integration costs, gain on sale of the Scott Safety business, net mark-to-market adjustments, restructuring and impairment costs, impact of ceasing the depreciation / amortization expense for the Power Solutions business as the business is held for sale, and discrete tax items. The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-19-000017:8k_2_02:104]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-19-000017:8k_2_02:105]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Three Months Ended |  | Three Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Earnings per share as reported for JCI plc | $ | 0.57 |  |  | $ | 0.47 |  |  | $ | 0.26 |  |  | $ | 0.20 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | 0.02 |  |  | — |  |  | — |  |  | — |  |
| Integration costs | 0.08 |  |  | 0.07 |  |  | 0.08 |  |  | 0.07 |  |
| Related tax impact | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |
| Net mark-to-market adjustments | (0.02 | ) |  | — |  |  | (0.02 | ) |  | — |  |
| Related tax impact | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Cease of Power Solutions |  |  |  |  |  |  |  |
| depreciation / amortization expense | (0.07 | ) |  | — |  |  | — |  |  | — |  |
| Related tax impact | 0.02 |  |  | — |  |  | — |  |  | — |  |
| Discrete tax items | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |
| Adjusted earnings per share for JCI plc* | $ | 0.59 |  |  | $ | 0.54 |  |  | $ | 0.32 |  |  | $ | 0.26 |  |

[0000833444-19-000017:8k_2_02:106]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Six Months Ended |  | Six Months Ended |
|  | December 31, |  | December 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Earnings per share as reported for JCI plc | $ | 0.95 |  |  | $ | 0.72 |  |  | $ | 0.38 |  |  | $ | 0.12 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | 0.05 |  |  | 0.01 |  |  | — |  |  | 0.01 |  |
| Related tax impact | (0.01 | ) |  | — |  |  | — |  |  | — |  |
| Integration costs | 0.13 |  |  | 0.11 |  |  | 0.13 |  |  | 0.11 |  |
| Related tax impact | (0.01 | ) |  | (0.02 | ) |  | (0.01 | ) |  | (0.02 | ) |
| Scott Safety gain on sale | — |  |  | (0.12 | ) |  | — |  |  | (0.12 | ) |
| Related tax impact | — |  |  | 0.03 |  |  | — |  |  | 0.03 |  |
| Restructuring and impairment costs | — |  |  | 0.17 |  |  | — |  |  | 0.17 |  |
| Related tax impact | — |  |  | (0.03 | ) |  | — |  |  | (0.02 | ) |
| Cease of Power Solutions |  |  |  |  |  |  |  |
| depreciation / amortization expense | (0.10 | ) |  | — |  |  | — |  |  | — |  |
| Related tax impact | 0.03 |  |  | — |  |  | — |  |  | — |  |
| Discrete tax items | 0.16 |  |  | 0.21 |  |  | 0.08 |  |  | 0.21 |  |
| Adjusted earnings per share for JCI plc* | $ | 1.20 |  |  | $ | 1.08 |  |  | $ | 0.58 |  |  | $ | 0.48 |  |

[0000833444-19-000017:8k_2_02:107]
* May not sum due to rounding.

[0000833444-19-000017:8k_2_02:108]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-19-000017:8k_2_02:109]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, |  | March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 902.5 |  |  | 926.2 |  |  | 912.1 |  |  | 926.2 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |
| and unvested performance share awards | 3.4 |  |  | 6.3 |  |  | 3.5 |  |  | 6.7 |  |
| Diluted weighted average shares outstanding | 905.9 |  |  | 932.5 |  |  | 915.6 |  |  | 932.9 |  |

[0000833444-19-000017:8k_2_02:110]
The Company has presented forward-looking statements regarding adjusted EPS from continuing operations, organic net sales growth, organic adjusted EBITA growth, organic adjusted EBIT growth, adjusted segment EBITA margin, adjusted EBIT margin and adjusted free cash flow conversion for the full fiscal year of 2019, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, income or cash flows from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments and the effect of foreign currency exchange fluctuations. Our fiscal 2019 outlook for organic net sales and adjusted EBITA and EBIT growth also excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s full year 2019 GAAP financial results.

[0000833444-19-000017:8k_2_02:111]
Page 14 of 16

[0000833444-19-000017:8k_2_02:112]
3. Organic Growth Reconciliation

[0000833444-19-000017:8k_2_02:113]
The components of the changes in net sales for the three months ended March 31, 2019 versus the three months ended March 31, 2018, including organic growth, is shown below (unaudited):

[0000833444-19-000017:8k_2_02:114]
| (in millions) | Net Sales for the Three Months Ended March 31, 2018 |  | Base Year Adjustments -Acquisitions and Divestitures |  | Adjusted Base Net Sales for the Three Months Ended March 31, 2018 |  | Foreign Currency |  | Organic Growth |  | Net Sales for the Three Months EndedMarch 31, 2019 |
| Building Solutions North America | $ | 2,097 |  |  | $ | — |  |  | — |  |  | $ | 2,097 |  |  | $ | (10 | ) |  | — |  |  | $ | 100 |  |  | 5 | % |  | $ | 2,187 |  |  | 4 | % |
| Building Solutions EMEA/LA | 907 |  |  | — |  |  | — |  |  | 907 |  |  | (69 | ) |  | -8 | % |  | 40 |  |  | 4 | % |  | 878 |  |  | -3 | % |
| Building Solutions Asia Pacific | 586 |  |  | — |  |  | — |  |  | 586 |  |  | (26 | ) |  | -4 | % |  | 68 |  |  | 12 | % |  | 628 |  |  | 7 | % |
| Total field | 3,590 |  |  | — |  |  | — |  |  | 3,590 |  |  | (105 | ) |  | -3 | % |  | 208 |  |  | 6 | % |  | 3,693 |  |  | 3 | % |
| Global Products | 2,040 |  |  | (38 | ) |  | -2 | % |  | 2,002 |  |  | (60 | ) |  | -3 | % |  | 144 |  |  | 7 | % |  | 2,086 |  |  | 4 | % |
| Total net sales | $ | 5,630 |  |  | $ | (38 | ) |  | -1 | % |  | $ | 5,592 |  |  | $ | (165 | ) |  | -3 | % |  | $ | 352 |  |  | 6 | % |  | $ | 5,779 |  |  | 3 | % |

[0000833444-19-000017:8k_2_02:115]
The components of the changes in net sales for the six months ended March 31, 2019 versus the six months ended March 31, 2018, including organic growth, is shown below (unaudited):

[0000833444-19-000017:8k_2_02:116]
| (in millions) | Net Sales for the Six Months Ended March 31, 2018 |  | Base Year Adjustments -Acquisitions and Divestitures |  | Adjusted Base Net Sales for the Six Months Ended March 31, 2018 |  | Foreign Currency |  | Organic Growth |  | Net Sales for the Six Months EndedMarch 31, 2019 |
| Building Solutions North America | $ | 4,109 |  |  | $ | — |  |  | — |  |  | $ | 4,109 |  |  | $ | (18 | ) |  | — |  |  | $ | 212 |  |  | 5 | % |  | $ | 4,303 |  |  | 5 | % |
| Building Solutions EMEA/LA | 1,822 |  |  | 2 |  |  | — |  |  | 1,824 |  |  | (112 | ) |  | -6 | % |  | 73 |  |  | 4 | % |  | 1,785 |  |  | -2 | % |
| Building Solutions Asia Pacific | 1,183 |  |  | — |  |  | — |  |  | 1,183 |  |  | (44 | ) |  | -4 | % |  | 102 |  |  | 9 | % |  | 1,241 |  |  | 5 | % |
| Total field | 7,114 |  |  | 2 |  |  | — |  |  | 7,116 |  |  | (174 | ) |  | -2 | % |  | 387 |  |  | 5 | % |  | 7,329 |  |  | 3 | % |
| Global Products | 3,821 |  |  | (87 | ) |  | -2 | % |  | 3,734 |  |  | (91 | ) |  | -2 | % |  | 271 |  |  | 7 | % |  | 3,914 |  |  | 5 | % |
| Total net sales | $ | 10,935 |  |  | $ | (85 | ) |  | -1 | % |  | $ | 10,850 |  |  | $ | (265 | ) |  | -2 | % |  | $ | 658 |  |  | 6 | % |  | $ | 11,243 |  |  | 4 | % |

[0000833444-19-000017:8k_2_02:117]
The components of the changes in segment EBITA and EBIT for the three months ended March 31, 2019 versus the three months ended March 31, 2018, including organic growth, is shown below (unaudited):

[0000833444-19-000017:8k_2_02:118]
| (in millions) | Adjusted Segment EBITA / EBIT for the Three Months Ended March 31, 2018 |  | Base Year Adjustments -Acquisitions and Divestitures |  | Adjusted Base Segment EBITA / EBIT for the Three Months Ended March 31, 2018 |  | Foreign Currency |  | Organic Growth |  | Adjusted SegmentEBITA / EBIT forthe ThreeMonths EndedMarch 31, 2019 |
| Building Solutions North America | $ | 244 |  |  | $ | — |  |  | — |  |  | $ | 244 |  |  | $ | (1 | ) |  | — |  |  | $ | 16 |  |  | 7 | % |  | $ | 259 |  |  | 6 | % |
| Building Solutions EMEA/LA | 78 |  |  | — |  |  | — |  |  | 78 |  |  | (10 | ) |  | -13 | % |  | 13 |  |  | 17 | % |  | 81 |  |  | 4 | % |
| Building Solutions Asia Pacific | 71 |  |  | — |  |  | — |  |  | 71 |  |  | (3 | ) |  | -4 | % |  | 8 |  |  | 11 | % |  | 76 |  |  | 7 | % |
| Total field | 393 |  |  | — |  |  | — |  |  | 393 |  |  | (14 | ) |  | -4 | % |  | 37 |  |  | 9 | % |  | 416 |  |  | 6 | % |
| Global Products | 237 |  |  | (6 | ) |  | -3 | % |  | 231 |  |  | (7 | ) |  | -3 | % |  | 31 |  |  | 13 | % |  | 255 |  |  | 10 | % |
| Total adjusted segment EBITA | 630 |  |  | $ | (6 | ) |  | -1 | % |  | 624 |  |  | $ | (21 | ) |  | -3 | % |  | $ | 68 |  |  | 11 | % |  | 671 |  |  | 8 | % |
| Corporate expenses | (113 | ) |  | — |  |  |  |  | (113 | ) |  |  |  |  |  |  |  |  |  | (104 | ) |  | 8 | % |
| Amortization of intangible assets | (92 | ) |  | 2 |  |  |  |  | (90 | ) |  |  |  |  |  |  |  |  |  | (98 | ) |  | -9 | % |
| Total adjusted EBIT | $ | 425 |  |  | $ | (4 | ) |  |  |  | $ | 421 |  |  |  |  |  |  |  |  |  |  | $ | 469 |  |  | 11 | % |

[0000833444-19-000017:8k_2_02:119]
The components of the changes in segment EBITA and EBIT for the six months ended March 31, 2019 versus the six months ended March 31, 2018, including organic growth, is shown below (unaudited):

[0000833444-19-000017:8k_2_02:120]
| (in millions) | Adjusted Segment EBITA / EBIT for the Six Months Ended March 31, 2018 |  | Base Year Adjustments -Acquisitions and Divestitures |  | Adjusted Base Segment EBITA / EBIT for the Six Months Ended March 31, 2018 |  | Foreign Currency |  | Organic Growth |  | Adjusted SegmentEBITA / EBIT forthe SixMonths EndedMarch 31, 2019 |
| Building Solutions North America | $ | 480 |  |  | $ | — |  |  | — |  |  | $ | 480 |  |  | $ | (2 | ) |  | — |  |  | $ | 34 |  |  | 7 | % |  | $ | 512 |  |  | 7 | % |
| Building Solutions EMEA/LA | 149 |  |  | 1 |  |  | 1 | % |  | 150 |  |  | (17 | ) |  | -11 | % |  | 25 |  |  | 17 | % |  | 158 |  |  | 5 | % |
| Building Solutions Asia Pacific | 145 |  |  | — |  |  | — |  |  | 145 |  |  | (4 | ) |  | -3 | % |  | 1 |  |  | 1 | % |  | 142 |  |  | -2 | % |
| Total field | 774 |  |  | 1 |  |  | — |  |  | 775 |  |  | (23 | ) |  | -3 | % |  | 60 |  |  | 8 | % |  | 812 |  |  | 5 | % |
| Global Products | 415 |  |  | (12 | ) |  | -3 | % |  | 403 |  |  | (10 | ) |  | -2 | % |  | 56 |  |  | 14 | % |  | 449 |  |  | 11 | % |
| Total adjusted segment EBITA | 1,189 |  |  | $ | (11 | ) |  | -1 | % |  | 1,178 |  |  | $ | (33 | ) |  | -3 | % |  | $ | 116 |  |  | 10 | % |  | 1,261 |  |  | 7 | % |
| Corporate expenses | (218 | ) |  | — |  |  |  |  | (218 | ) |  |  |  |  |  |  |  |  |  | (197 | ) |  | 10 | % |
| Amortization of intangible assets | (184 | ) |  | 2 |  |  |  |  | (182 | ) |  |  |  |  |  |  |  |  |  | (195 | ) |  | -7 | % |
| Total adjusted EBIT | $ | 787 |  |  | $ | (9 | ) |  |  |  | $ | 778 |  |  |  |  |  |  |  |  |  |  | $ | 869 |  |  | 12 | % |

[0000833444-19-000017:8k_2_02:121]
Page 15 of 16

[0000833444-19-000017:8k_2_02:122]
4.  Adjusted Free Cash Flow Reconciliation

[0000833444-19-000017:8k_2_02:123]
The Company's press release contains financial information regarding free cash flow, adjusted free cash flow and adjusted free cash flow conversion, which are non-GAAP performance measures. Free cash flow is defined as cash provided by operating activities less capital expenditures. Adjusted free cash flow excludes special items, as included in the table below, because these cash flows are not considered to be directly related to its underlying businesses. Adjusted free cash flow conversion is defined as adjusted free cash flow divided by adjusted net income. Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash.

[0000833444-19-000017:8k_2_02:124]
The following is the three months and six months ended March 31, 2019 and 2018 reconciliation of free cash flow, adjusted free cash flow and adjusted free cash flow conversion for continuing operations (unaudited):

[0000833444-19-000017:8k_2_02:125]
| (in billions) | Three Months Ended March 31, 2019 |  | Three Months Ended March 31, 2018 |  | Six Months Ended March 31, 2019 |  | Six Months Ended March 31, 2018 |
| Cash provided by operating activities from continuing operations | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |
| Capital expenditures | (0.1 | ) |  | (0.2 | ) |  | (0.3 | ) |  | (0.3 | ) |
| Reported free cash flow* | 0.1 |  |  | 0.1 |  |  | (0.2 | ) |  | (0.1 | ) |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction/integration costs | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Restructuring payments | — |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |
| Nonrecurring tax payments, net of refunds | — |  |  | — |  |  | — |  |  | (0.1 | ) |
| Total adjusting items* | 0.1 |  |  | 0.2 |  |  | 0.2 |  |  | 0.2 |  |
| Adjusted free cash flow* | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | — |  |
| Adjusted net income from continuing operations |  |  |  |  |  |  |  |
| attributable to JCI | $ | 0.3 |  |  | $ | 0.2 |  |  | $ | 0.5 |  |  | $ | 0.4 |  |
| Adjusted free cash flow conversion | 67 | % |  | 150 | % |  | 0 | % |  | 0 | % |

[0000833444-19-000017:8k_2_02:126]
* May not sum due to rounding

[0000833444-19-000017:8k_2_02:127]
5.  Net Debt to Capitalization

[0000833444-19-000017:8k_2_02:128]
The Company provides financial information regarding net debt as a percentage of total capitalization, which is a non-GAAP performance measure. The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. The following is the March 31, 2019 and September 30, 2018 calculation of net debt as a percentage of total capitalization (unaudited):

[0000833444-19-000017:8k_2_02:129]
| (in millions) | March 31, 2019 |  | September 30, 2018 |
| Short-term debt and current portion of long-term debt | $ | 3,968 |  |  | $ | 1,307 |  |
| Long-term debt | 8,418 |  |  | 9,623 |  |
| Total debt | 12,386 |  |  | 10,930 |  |
| Less: cash and cash equivalents | 239 |  |  | 185 |  |
| Total net debt | 12,147 |  |  | 10,745 |  |
| Shareholders' equity attributable to JCI | 20,036 |  |  | 21,164 |  |
| Total capitalization | $ | 32,183 |  |  | $ | 31,909 |  |
| Total net debt as a % of total capitalization | 37.7 | % |  | 33.7 | % |

[0000833444-19-000017:8k_2_02:130]
6.  Divestitures

[0000833444-19-000017:8k_2_02:131]
On November 13, 2018, the Company entered into a definitive agreement to sell its Power Solutions business to BCP Acquisitions LLC for approximately $13.2 billion. BCP Acquisitions LLC is a newly-formed entity controlled by investment funds managed by Brookfield Capital Partners LLC. The  transaction closed on April 30, 2019 with net cash proceeds of $11.6 billion after tax and transaction-related expenses.

[0000833444-19-000017:8k_2_02:132]
On March 16, 2017, the Company announced that it signed a definitive agreement to sell its Scott Safety business to 3M for approximately $2.0 billion.  The transaction closed on October 4, 2017. Net cash proceeds from the transaction approximated $1.9 billion and the Company recorded a net gain of $114 million ($84 million after tax). Scott Safety is a leader in the design, manufacture and sale of high performance respiratory protection, gas and flame detection, thermal imaging and other critical products for fire services, law enforcement, industrial, oil and gas, chemical, armed forces, and homeland defense end markets.

[0000833444-19-000017:8k_2_02:133]
7.  Income Taxes

[0000833444-19-000017:8k_2_02:134]
The Company's effective tax rate from continuing operations before consideration of transaction/integration costs, gain on sale of the Scott Safety business, net mark-to-market adjustments, restructuring and impairment costs, and discrete tax items for the three and six months ending March 31, 2019 is 13.5% and 13.6%, respectively, and for the three and six months ending March 31, 2018 is approximately 11.9% and 12.1%, respectively.

[0000833444-19-000017:8k_2_02:135]
8.  Restructuring

[0000833444-19-000017:8k_2_02:136]
The six months ended March 31, 2018 include restructuring and impairment costs of $154 million related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions business and at Corporate.

[0000833444-19-000017:8k_2_02:137]
Page 16 of 16
