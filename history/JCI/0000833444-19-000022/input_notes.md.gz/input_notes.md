# JCI notes — 0000833444-19-000022


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-19-000022:notes:1]
[same as prior period, unchanged from 0000833444-19-000005:notes:171]

[0000833444-19-000022:notes:2]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2018 filed with the SEC on November 20, 2018. The results of operations for the three and six month periods ended March 31, 2019 are not necessarily indicative of results for the Company’s 2019 fiscal year because of seasonal and other factors.

[0000833444-19-000022:notes:3]
[same as prior period, unchanged from 0000833444-19-000005:notes:173]

[0000833444-19-000022:notes:4]
[same as prior period, unchanged from 0000833444-19-000005:notes:174]

[0000833444-19-000022:notes:5]
[same as prior period, unchanged from 0000833444-19-000005:notes:175]

[0000833444-19-000022:notes:6]
[same as prior period, unchanged from 0000833444-19-000005:notes:176]

[0000833444-19-000022:notes:7]
[same as prior period, unchanged from 0000833444-19-000005:notes:177]

[0000833444-19-000022:notes:8]
[same as prior period, unchanged from 0000833444-19-000005:notes:178]

[0000833444-19-000022:notes:9]
Under certain criteria as provided for in Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity ("VIE"). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting rights. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the

[0000833444-19-000022:notes:10]
VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.

[0000833444-19-000022:notes:11]
[same as prior period, unchanged from 0000833444-19-000005:notes:180]

[0000833444-19-000022:notes:12]
[same as prior period, unchanged from 0000833444-19-000005:notes:181]

[0000833444-19-000022:notes:13]
At March 31, 2019, the Company held restricted cash of approximately $19 million, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities. At September 30, 2018, the Company held restricted cash of approximately $15 million, of which $6 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position.

[0000833444-19-000022:notes:14]
[same as prior period, unchanged from 0000833444-19-000005:notes:183]

[0000833444-19-000022:notes:15]
[same as prior period, unchanged from 0000833444-19-000005:notes:184]

[0000833444-19-000022:notes:16]
In November 2016, the FASB issued Accounting Standards Update ("ASU") No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force)." The ASU requires amounts generally described as restricted cash and restricted cash equivalents to be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. ASU No. 2016-18 was effective retrospectively for the quarter ended December 31, 2018. The impact of this guidance did not have a significant impact on the Company's consolidated financial statements for the periods presented.

[0000833444-19-000022:notes:17]
In August 2016, the FASB issued ASU No. 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments." ASU No. 2016-15 provides clarification guidance on eight specific cash flow presentation issues in order to reduce the diversity in practice. ASU No. 2016-15 was effective retrospectively for the Company for the quarter ending December 31, 2018. The adoption of this guidance had an impact on the presentation of equity swap funding and settlement activities since the activity changed from an operating activity to an investing activity.


## us-gaap:ScheduleOfNewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000833444-19-000022:notes:18]
The impact of adoption of the New Revenue Standard to the Company's consolidated statement of financial position as of March 31, 2019 is as follows (in millions):

[0000833444-19-000022:notes:19]
|  | March 31, 2019 |
|  | As reported |  | Under previous accounting guidance |  | Impact from adopting the New Revenue Standard |
| Consolidated Statement of Financial Position |  |  |  |  |  |
| Assets |  |  |  |  |  |
| Accounts receivable - net | $ | 5,707 |  |  | $ | 5,741 |  |  | $ | (34 | ) |
| Inventories | 2,124 |  |  | 2,138 |  |  | (14 | ) |
| Assets held for sale | 2,999 |  |  | 2,983 |  |  | 16 |  |
| Other current assets | 1,767 |  |  | 1,792 |  |  | (25 | ) |
| Property, plant and equipment - net | 3,332 |  |  | 3,292 |  |  | 40 |  |
| Other noncurrent assets | 1,829 |  |  | 1,799 |  |  | 30 |  |
| Liabilities and Equity |  |  |  |  |  |
| Deferred revenue | 1,521 |  |  | 1,512 |  |  | 9 |  |
| Liabilities held for sale | 1,558 |  |  | 1,535 |  |  | 23 |  |
| Retained earnings | 6,416 |  |  | 6,435 |  |  | (19 | ) |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-19-000022:notes:20]
[same as prior period, unchanged from 0000833444-19-000005:notes:167]

[0000833444-19-000022:notes:21]
During the first six months of fiscal 2019, the Company completed certain divestitures within the Global Products and Building Solutions EMEA/LA businesses. The combined selling price was $18 million, $6 million of which was received as of March 31, 2019. In connection with the sale, the Company reduced goodwill by $1 million within the Building Solutions EMEA/LA segment. The divestitures were not material to the Company's consolidated financial statements.

[0000833444-19-000022:notes:22]
[same as prior period, unchanged from 0000833444-19-000005:notes:168]

[0000833444-19-000022:notes:23]
During the first six months of fiscal 2018, the Company completed certain acquisitions for a combined purchase price of $15 million, all of which was paid as of March 31, 2018. The acquisitions were not material to the Company’s consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $8 million within the Global Products segment.

[0000833444-19-000022:notes:24]
In the second quarter of fiscal 2018, the Company completed the sale of a certain Global Products business. The selling price was $103 million, all of which was received in the three months ended March 31, 2018. In connection with the sale, the Company reduced goodwill by $20 million. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-19-000022:notes:25]
[same as prior period, unchanged from 0000833444-19-000005:notes:170]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-19-000022:notes:26]
[same as prior period, unchanged from 0000833444-19-000005:notes:98]

[0000833444-19-000022:notes:27]
On November 13, 2018, the Company entered into a Stock and Asset Purchase Agreement (“Purchase Agreement”) with BCP Acquisitions LLC (“Purchaser”). The Purchaser is a newly-formed entity controlled by investment funds managed by Brookfield Capital Partners LLC. Pursuant to the Purchase Agreement, on the terms and subject to the conditions therein, the Company has agreed to sell, and Purchaser has agreed to acquire, the Company’s Power Solutions business for a purchase price of $13.2 billion. The transaction closed on April 30, 2019 with net cash proceeds of $11.6 billion after tax and transaction-related expenses.

[0000833444-19-000022:notes:28]
[same as prior period, unchanged from 0000833444-19-000005:notes:100]

[0000833444-19-000022:notes:29]
The following table summarizes the results of Power Solutions reclassified as discontinued operations for the three and six month periods ended March 31, 2019 and 2018 (in millions):

[0000833444-19-000022:notes:30]
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales | $ | 2,012 |  |  | $ | 1,845 |  |  | $ | 4,439 |  |  | $ | 3,975 |  |
| Income from discontinued operations before income taxes | 334 |  |  | 307 |  |  | 724 |  |  | 675 |  |
| Provision for income taxes on discontinued operations | (50 | ) |  | (42 | ) |  | (177 | ) |  | (92 | ) |
| Income from discontinued operations attributable to noncontrolling interests, net of tax | (9 | ) |  | (11 | ) |  | (24 | ) |  | (24 | ) |
| Income from discontinued operations | $ | 275 |  |  | $ | 254 |  |  | $ | 523 |  |  | $ | 559 |  |

[0000833444-19-000022:notes:31]
For the three months ended March 31, 2019, income from discontinued operations before income taxes included transaction costs of $18 million and a favorable impact of $64 million for ceasing depreciation and amortization expense as the business was held for sale. For the six months ended March 31, 2019, income from discontinued operations before income taxes included transaction costs of $46 million and a favorable impact of $96 million for ceasing depreciation and amortization expense as the business was held for sale. The increase in net sales for the three and six months ended March 31, 2019 was primarily due to the impact of the adoption of the New Revenue Standard. Refer to Note 2, "New Accounting Standards," of the notes to consolidated financial statements for further information.

[0000833444-19-000022:notes:32]
For the three months ended March 31, 2019, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to tax rate differentials. For the six months ended March 31, 2019, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to establishment of a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries related to the planned divestiture of the business and tax rate differentials. For the three and six months ended March 31, 2018, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to tax rate differentials.

[0000833444-19-000022:notes:33]
[same as prior period, unchanged from 0000833444-19-000005:notes:103]

[0000833444-19-000022:notes:34]
The following table summarizes the carrying value of the Power Solutions assets and liabilities held for sale at March 31, 2019 and September 30, 2018 (in millions):

[0000833444-19-000022:notes:35]
|  | March 31, 2019 |  | September 30, 2018 |
| Cash | $ | 45 |  |  | $ | 15 |  |
| Accounts receivable - net | 1,228 |  |  | 1,443 |  |
| Inventories | 1,524 |  |  | 1,405 |  |
| Other current assets | 202 |  |  | 152 |  |
| Assets held for sale | $ | 2,999 |  |  | $ | 3,015 |  |
| Property, plant and equipment - net | $ | 2,981 |  |  | $ | 2,871 |  |
| Goodwill | 1,081 |  |  | 1,092 |  |
| Other intangible assets - net | 156 |  |  | 161 |  |
| Investments in partially-owned affiliates | 476 |  |  | 453 |  |
| Other noncurrent assets | 535 |  |  | 611 |  |
| Noncurrent assets held for sale | $ | 5,229 |  |  | $ | 5,188 |  |
| Short-term debt | $ | 6 |  |  | $ | 9 |  |
| Current portion of long-term debt | 8 |  |  | 25 |  |
| Accounts payable | 1,128 |  |  | 1,237 |  |
| Accrued compensation and benefits | 99 |  |  | 125 |  |
| Deferred revenue | 23 |  |  | — |  |
| Other current liabilities | 294 |  |  | 395 |  |
| Liabilities held for sale | $ | 1,558 |  |  | $ | 1,791 |  |
| Long-term debt | $ | 28 |  |  | $ | 31 |  |
| Pension and postretirement benefits | 94 |  |  | 101 |  |
| Other noncurrent liabilities | 63 |  |  | 75 |  |
| Noncurrent liabilities held for sale | $ | 185 |  |  | $ | 207 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-19-000022:notes:36]
[same as prior period, unchanged from 0000833444-19-000005:notes:213]

[0000833444-19-000022:notes:37]
[same as prior period, unchanged from 0000833444-19-000005:notes:214]

[0000833444-19-000022:notes:38]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company elected the practical expedient which permits the promised amount of consideration to not be adjusted for the effects of a significant financing component as at contract inception the Company expects to receive the payment within the twelve months of transfer of goods or services.

[0000833444-19-000022:notes:39]
[same as prior period, unchanged from 0000833444-19-000005:notes:216]

[0000833444-19-000022:notes:40]
[same as prior period, unchanged from 0000833444-19-000005:notes:217]

[0000833444-19-000022:notes:41]
[same as prior period, unchanged from 0000833444-19-000005:notes:218]

[0000833444-19-000022:notes:42]
The Company considers the contractual consideration payable by the customer and assess variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

[0000833444-19-000022:notes:43]
[same as prior period, unchanged from 0000833444-19-000005:notes:220]

[0000833444-19-000022:notes:44]
[same as prior period, unchanged from 0000833444-19-000005:notes:221]

[0000833444-19-000022:notes:45]
The following table presents the Company's revenues disaggregated by segment and by product versus services revenue for the three and six months ended March 31, 2019 (in millions):

[0000833444-19-000022:notes:46]
|  |  | Three Months EndedMarch 31, 2019 |  | Six Months EndedMarch 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,387 |  |  | $ | 800 |  |  | $ | 2,187 |  |  | $ | 2,708 |  |  | $ | 1,595 |  |  | $ | 4,303 |  |
| Building Solutions EMEA/LA |  | 416 |  |  | 462 |  |  | 878 |  |  | 833 |  |  | 952 |  |  | 1,785 |  |
| Building Solutions Asia Pacific |  | 351 |  |  | 277 |  |  | 628 |  |  | 707 |  |  | 534 |  |  | 1,241 |  |
| Global Products |  | 2,086 |  |  | — |  |  | 2,086 |  |  | 3,914 |  |  | — |  |  | 3,914 |  |
| Total |  | $ | 4,240 |  |  | $ | 1,539 |  |  | $ | 5,779 |  |  | $ | 8,162 |  |  | $ | 3,081 |  |  | $ | 11,243 |  |

[0000833444-19-000022:notes:47]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and six months ended March 31, 2019 (in millions):

[0000833444-19-000022:notes:48]
|  |  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  |  | 2019 |  | 2019 |
| Building Management |  | $ | 320 |  |  | $ | 601 |  |
| HVAC & Refrigeration Equipment |  | 1,474 |  |  | 2,759 |  |
| Specialty |  | 292 |  |  | 554 |  |
| Total Global Products |  | $ | 2,086 |  |  | $ | 3,914 |  |

[0000833444-19-000022:notes:49]
[same as prior period, unchanged from 0000833444-19-000005:notes:222]

[0000833444-19-000022:notes:50]
[same as prior period, unchanged from 0000833444-19-000005:notes:223]

[0000833444-19-000022:notes:51]
The following table presents the location and amount of contract balances in the Company's consolidated statements of financial position (in millions):

[0000833444-19-000022:notes:52]
|  |  | Location of contract balances |  | March 31, 2019 |  | October 1, 2018 |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,343 |  |  | $ | 1,261 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 85 |  |  | 85 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,521 | ) |  | (1,335 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (119 | ) |  | (113 | ) |
| Total |  |  |  | $ | (212 | ) |  | $ | (102 | ) |

[0000833444-19-000022:notes:53]
For the three and six months ended March 31, 2019, the Company recognized revenue of $214 million and $926 million, respectively, that was included in the beginning of period contract liability balance.

[0000833444-19-000022:notes:54]
[same as prior period, unchanged from 0000833444-19-000005:notes:225]

[0000833444-19-000022:notes:55]
[same as prior period, unchanged from 0000833444-19-000005:notes:226]

[0000833444-19-000022:notes:56]
Performance obligations are satisfied as of a point in time or over time. Performance obligations are supported by contracts with customers, providing a framework for the nature of the distinct goods, services, or bundle of goods and services. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of March 31, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $13.9 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company has applied the practical expedient for certain revenue streams to exclude the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-19-000022:notes:57]
[same as prior period, unchanged from 0000833444-19-000005:notes:228]

[0000833444-19-000022:notes:58]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and bid/proposal costs. Costs to obtain or fulfill a contract are capitalized and amortized to revenue over the period of contract performance.

[0000833444-19-000022:notes:59]
As of March 31, 2019, the Company recorded the costs to obtain or fulfill a contract of $184 million, of which $98 million is recorded within other current assets and $86 million is recorded within other noncurrent assets in the consolidated statements of financial position.

[0000833444-19-000022:notes:60]
During the three and six months ended March 31, 2019, the Company recognized amortization expense of $34 million and $69 million, respectively related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and six months ended March 31, 2019.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-19-000022:notes:61]
[same as prior period, unchanged from 0000833444-19-000005:notes:164]

[0000833444-19-000022:notes:62]
[same as prior period, unchanged from 0000833444-19-000005:notes:165]

[0000833444-19-000022:notes:63]
|  | March 31, 2019 |  | September 30, 2018 |
| Raw materials and supplies | $ | 687 |  |  | $ | 606 |  |
| Work-in-process | 188 |  |  | 155 |  |
| Finished goods | 1,249 |  |  | 1,058 |  |
| Inventories | $ | 2,124 |  |  | $ | 1,819 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-19-000022:notes:64]
[same as prior period, unchanged from 0000833444-19-000005:notes:130]

[0000833444-19-000022:notes:65]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the six month period ended March 31, 2019 were as follows (in millions):

[0000833444-19-000022:notes:66]
|  |  |  | Business Acquisitions |  | Business Divestitures |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  |  | March 31, |
|  | 2018 |  |  |  |  | 2019 |
| Building Solutions North America | $ | 9,603 |  |  | $ | — |  |  | $ | — |  |  | $ | (22 | ) |  | $ | 9,581 |  |
| Building Solutions EMEA/LA | 1,950 |  |  | — |  |  | (1 | ) |  | (36 | ) |  | 1,913 |  |
| Building Solutions Asia Pacific | 1,235 |  |  | — |  |  | — |  |  | 4 |  |  | 1,239 |  |
| Global Products | 5,593 |  |  | 9 |  |  | — |  |  | (24 | ) |  | 5,578 |  |
| Total | $ | 18,381 |  |  | $ | 9 |  |  | $ | (1 | ) |  | $ | (78 | ) |  | $ | 18,311 |  |

[0000833444-19-000022:notes:67]
At September 30, 2018, accumulated goodwill impairment charges included $47 million related to the Building Solutions EMEA/LA - Latin America reporting unit.

[0000833444-19-000022:notes:68]
The Company’s other intangible assets, primarily from business acquisitions valued based on independent appraisals, consisted of (in millions):

[0000833444-19-000022:notes:69]
|  | March 31, 2019 |  | September 30, 2018 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Amortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,309 |  |  | $ | (310 | ) |  | $ | 999 |  |  | $ | 1,317 |  |  | $ | (251 | ) |  | $ | 1,066 |  |
| Customer relationships | 2,930 |  |  | (702 | ) |  | 2,228 |  |  | 2,941 |  |  | (599 | ) |  | 2,342 |  |
| Miscellaneous | 542 |  |  | (216 | ) |  | 326 |  |  | 458 |  |  | (185 | ) |  | 273 |  |
| Total amortized intangible assets | 4,781 |  |  | (1,228 | ) |  | 3,553 |  |  | 4,716 |  |  | (1,035 | ) |  | 3,681 |  |
| Unamortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,372 |  |  | — |  |  | 2,372 |  |  | 2,386 |  |  | — |  |  | 2,386 |  |
| Miscellaneous | 90 |  |  | — |  |  | 90 |  |  | 120 |  |  | — |  |  | 120 |  |
|  | 2,462 |  |  | — |  |  | 2,462 |  |  | 2,506 |  |  | — |  |  | 2,506 |  |
| Total intangible assets | $ | 7,243 |  |  | $ | (1,228 | ) |  | $ | 6,015 |  |  | $ | 7,222 |  |  | $ | (1,035 | ) |  | $ | 6,187 |  |

[0000833444-19-000022:notes:70]
Amortization of other intangible assets included within continuing operations for the three month periods ended March 31, 2019 and 2018 was $98 million and $92 million, respectively. Amortization of other intangible assets included within continuing operations for the six month periods ended March 31, 2019 and 2018 was $195 million and $184 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2020, 2021, 2022, 2023 and 2024 will be approximately $392 million, $385 million, $377 million, $368 million and $355 million per year, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-19-000022:notes:71]
[same as prior period, unchanged from 0000833444-19-000005:notes:197]

[0000833444-19-000022:notes:72]
[same as prior period, unchanged from 0000833444-19-000005:notes:198]

[0000833444-19-000022:notes:73]
[same as prior period, unchanged from 0000833444-19-000005:notes:199]

[0000833444-19-000022:notes:74]
[same as prior period, unchanged from 0000833444-19-000005:notes:200]

[0000833444-19-000022:notes:75]
[same as prior period, unchanged from 0000833444-19-000005:notes:201]

[0000833444-19-000022:notes:76]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 209 |  |  | $ | 42 |  |  | $ | 12 |  |  | $ | 263 |  |
| Utilized—cash | (45 | ) |  | — |  |  | (2 | ) |  | (47 | ) |
| Utilized—noncash | — |  |  | (42 | ) |  | — |  |  | (42 | ) |
| Balance at September 30, 2018 | $ | 164 |  |  | $ | — |  |  | $ | 10 |  |  | $ | 174 |  |
| Utilized—cash | (42 | ) |  | — |  |  | (4 | ) |  | (46 | ) |
| Transfer to liabilities held for sale | (4 | ) |  | — |  |  | — |  |  | (4 | ) |
| Balance at March 31, 2019 | $ | 118 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 124 |  |

[0000833444-19-000022:notes:77]
[same as prior period, unchanged from 0000833444-19-000005:notes:203]

[0000833444-19-000022:notes:78]
[same as prior period, unchanged from 0000833444-19-000005:notes:204]

[0000833444-19-000022:notes:79]
[same as prior period, unchanged from 0000833444-19-000005:notes:205]

[0000833444-19-000022:notes:80]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 276 |  |  | $ | 77 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 367 |  |
| Utilized—cash | (75 | ) |  | — |  |  | — |  |  | — |  |  | (75 | ) |
| Utilized—noncash | — |  |  | (77 | ) |  | (1 | ) |  | — |  |  | (78 | ) |
| Adjustment to restructuring reserves | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |
| Balance at September 30, 2017 | $ | 226 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 239 |  |
| Utilized—cash | (152 | ) |  | — |  |  | (6 | ) |  | — |  |  | (158 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Balance at September 30, 2018 | $ | 74 |  |  | $ | — |  |  | $ | 7 |  |  | $ | (1 | ) |  | $ | 80 |  |
| Utilized—cash | (3 | ) |  | — |  |  | (1 | ) |  | — |  |  | (4 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (2 | ) |  | (2 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Balance at March 31, 2019 | $ | 68 |  |  | $ | — |  |  | $ | 6 |  |  | $ | (3 | ) |  | $ | 71 |  |

[0000833444-19-000022:notes:81]
[same as prior period, unchanged from 0000833444-19-000005:notes:207]

[0000833444-19-000022:notes:82]
[same as prior period, unchanged from 0000833444-19-000005:notes:208]

[0000833444-19-000022:notes:83]
[same as prior period, unchanged from 0000833444-19-000005:notes:209]

[0000833444-19-000022:notes:84]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 368 |  |  | $ | 190 |  |  | $ | 62 |  |  | $ | — |  |  | $ | 620 |  |
| Acquired Tyco restructuring reserves | 78 |  |  | — |  |  | — |  |  | — |  |  | 78 |  |
| Utilized—cash | (32 | ) |  | — |  |  | — |  |  | — |  |  | (32 | ) |
| Utilized—noncash | — |  |  | (190 | ) |  | (32 | ) |  | 1 |  |  | (221 | ) |
| Balance at September 30, 2016 | $ | 414 |  |  | $ | — |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 445 |  |
| Adient spin-off impact | (194 | ) |  | — |  |  | (22 | ) |  | — |  |  | (216 | ) |
| Utilized—cash | (86 | ) |  | — |  |  | (2 | ) |  | — |  |  | (88 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Adjustment to restructuring reserves | (25 | ) |  | — |  |  | — |  |  | — |  |  | (25 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Adjustment to acquired Tyco restructuring reserves | (22 | ) |  | — |  |  | — |  |  | — |  |  | (22 | ) |
| Balance at September 30, 2017 | $ | 84 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 2 |  |  | $ | 92 |  |
| Utilized—cash | (17 | ) |  | — |  |  | (2 | ) |  | — |  |  | (19 | ) |
| Balance at September 30, 2018 | $ | 67 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 2 |  |  | $ | 73 |  |
| Utilized—cash | (9 | ) |  | — |  |  | — |  |  | — |  |  | (9 | ) |
| Balance at March 31, 2019 | $ | 58 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 2 |  |  | $ | 64 |  |

[0000833444-19-000022:notes:85]
The Company's fiscal 2018, 2017 and 2016 restructuring plans included workforce reductions of approximately 11,300 employees (9,100 for the Building Technologies & Solutions business and 2,200 for Corporate). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of March 31, 2019, approximately 5,100 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included twelve plant closures in the Building Technologies & Solutions business. As of March 31, 2019, ten of the twelve plants have been closed.

[0000833444-19-000022:notes:86]
[same as prior period, unchanged from 0000833444-19-000005:notes:212]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-19-000022:notes:87]
[same as prior period, unchanged from 0000833444-19-000005:notes:146]

[0000833444-19-000022:notes:88]
[same as prior period, unchanged from 0000833444-19-000005:notes:147]

[0000833444-19-000022:notes:89]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended March 31, 2019, the Company's effective tax rate for continuing operations was 15% and was higher than the statutory tax rate of 12.5% primarily due to tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the six months ended March 31, 2019, the Company's effective tax rate for continuing operations was 27%

[0000833444-19-000022:notes:90]
and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments as a result of tax law changes and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the three months ended March 31, 2018, the Company's effective tax rate for continuing operations was 14% and was higher than the statutory tax rate of 12.5% primarily due to tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the six months ended March 31, 2018, the Company's effective tax rate for continuing operations was 60% and was higher than the statutory tax rate of 12.5% primarily due to the discrete net impacts of U.S. Tax Reform, the tax impact of the divestiture of the Scott Safety business and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives and tax audit closures.

[0000833444-19-000022:notes:91]
[same as prior period, unchanged from 0000833444-19-000005:notes:149]

[0000833444-19-000022:notes:92]
[same as prior period, unchanged from 0000833444-19-000005:notes:150]

[0000833444-19-000022:notes:93]
In the first quarter of fiscal 2019, as a result of changes to U.S. tax law, the Company recorded a discrete tax charge of $76 million related to valuation allowances on certain U.S. deferred tax assets.

[0000833444-19-000022:notes:94]
[same as prior period, unchanged from 0000833444-19-000005:notes:152]

[0000833444-19-000022:notes:95]
At September 30, 2018, the Company had gross tax effected unrecognized tax benefits of $2,358 million, of which $2,225 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2018 was approximately $119 million (net of tax benefit). The interest and penalties accrued during the six months ended March 31, 2019 was approximately $31 million (net of tax benefit). Interest and penalties accrued during the six months ended March 31, 2018 were immaterial. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-19-000022:notes:96]
[same as prior period, unchanged from 0000833444-19-000005:notes:154]

[0000833444-19-000022:notes:97]
[same as prior period, unchanged from 0000833444-19-000005:notes:155]

[0000833444-19-000022:notes:98]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2017 |
| China |  | 2008 - 2016 |
| France |  | 2010 - 2012; 2015 - 2016 |
| Germany |  | 2007 - 2016 |
| Japan |  | 2017 - 2018 |
| United Kingdom |  | 2012 - 2015 |

[0000833444-19-000022:notes:99]
[same as prior period, unchanged from 0000833444-19-000005:notes:157]

[0000833444-19-000022:notes:100]
[same as prior period, unchanged from 0000833444-19-000005:notes:158]

[0000833444-19-000022:notes:101]
In connection with the Company’s analysis of the impact of the U.S. tax law changes, the Company recorded a provisional net tax charge of $108 million during fiscal 2018 consistent with guidance prescribed by Staff Accounting Bulletin 118. This provisional net tax charge arises from a benefit of $108 million due to the remeasurement of U.S. deferred tax assets and liabilities, offset by the Company’s tax charge relating to the one-time transition tax on deemed repatriated earnings, inclusive

[0000833444-19-000022:notes:102]
of all relevant taxes, of $216 million. The Company’s estimated benefit of the remeasurement of U.S. deferred tax assets and liabilities increased from $101 million as of December 31, 2017 to $108 million as of September 30, 2018 due to calculation refinement of the Company’s estimated impact. The Company remeasured certain deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future, which is generally 21% or the blended fiscal 2018 rate of 24.5%. The Company’s tax charge for transition tax decreased from $305 million as of December 31, 2017 to $216 million as of September 30, 2018 due to further analysis of the Company’s post-1986 non-U.S. earnings and profits (“E&P”) previously deferred from U.S. federal taxation and refinement of the estimated impact of tax law changes. In the first quarter of fiscal 2019, the Company completed its analysis of all enactment-date income tax effects of the U.S. tax law change with no further adjustment to the provisional amounts recorded as of September 30, 2018.

[0000833444-19-000022:notes:103]
During the six months ended March 31, 2019 and 2018, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-19-000022:notes:104]
[same as prior period, unchanged from 0000833444-19-000005:notes:161]

[0000833444-19-000022:notes:105]
[same as prior period, unchanged from 0000833444-19-000005:notes:162]

[0000833444-19-000022:notes:106]
[same as prior period, unchanged from 0000833444-19-000005:notes:163]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-19-000022:notes:107]
[same as prior period, unchanged from 0000833444-19-000005:notes:187]

[0000833444-19-000022:notes:108]
[same as prior period, unchanged from 0000833444-19-000005:notes:188]

[0000833444-19-000022:notes:109]
|  | U.S. Pension Plans |
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Service cost | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Interest cost | 25 |  |  | 23 |  |  | 50 |  |  | 46 |  |
| Expected return on plan assets | (46 | ) |  | (50 | ) |  | (92 | ) |  | (100 | ) |
| Net periodic benefit credit | $ | (21 | ) |  | $ | (26 | ) |  | $ | (42 | ) |  | $ | (53 | ) |

[0000833444-19-000022:notes:110]
|  | Non-U.S. Pension Plans |
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Service cost | $ | 6 |  |  | $ | 6 |  |  | $ | 11 |  |  | $ | 11 |  |
| Interest cost | 12 |  |  | 14 |  |  | 26 |  |  | 28 |  |
| Expected return on plan assets | (25 | ) |  | (29 | ) |  | (52 | ) |  | (57 | ) |
| Settlement loss | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Net periodic benefit credit | $ | (6 | ) |  | $ | (9 | ) |  | $ | (14 | ) |  | $ | (18 | ) |

[0000833444-19-000022:notes:111]
|  | Postretirement Benefits |
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Service cost | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest cost | 1 |  |  | 1 |  |  | 3 |  |  | 3 |  |
| Expected return on plan assets | (3 | ) |  | (3 | ) |  | (5 | ) |  | (5 | ) |
| Net periodic benefit credit | $ | (1 | ) |  | $ | (1 | ) |  | $ | (1 | ) |  | $ | (1 | ) |


## us-gaap:DebtDisclosureTextBlock

[0000833444-19-000022:notes:112]
Debt and Financing Arrangements

[0000833444-19-000022:notes:113]
On May 1, 2019, the Company announced that it has commenced a cash tender offer to purchase up to $1.5 billion in aggregate principal amount of certain of its outstanding notes.

[0000833444-19-000022:notes:114]
In March 2019, a 364-day $250 million committed revolving credit facility expired.  The Company entered into a new $250 million committed revolving credit facility scheduled to expire in March 2020.  As of March 31, 2019 there were no draws on the facility.

[0000833444-19-000022:notes:115]
In February 2019, the Company repurchased, at a discount, $12 million of its 3.9% fixed rate notes, plus accrued interest, scheduled to mature in 2026.

[0000833444-19-000022:notes:116]
In February 2019, a 364-day $150 million committed revolving credit facility expired.  The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2020.  As of March 31, 2019 there were no draws on the facility.

[0000833444-19-000022:notes:117]
In January 2019, the Company entered into a $750 million term loan due the earlier of January 2020 or five business days from the closing on the sale of the Power Solutions business.  Proceeds from the term loan were used for general corporate purposes.

[0000833444-19-000022:notes:118]
In January 2019, a 364-day $200 million committed revolving credit facility expired.  The Company entered into a new $350 million committed revolving credit facility scheduled to expire in January 2020.  As of March 31, 2019 there were no draws on the facility.

[0000833444-19-000022:notes:119]
Net Financing Charges

[0000833444-19-000022:notes:120]
The Company's net financing charges line item in the consolidated statements of income for the three and six months ended March 31, 2019 and 2018 contained the following components (in millions):

[0000833444-19-000022:notes:121]
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Interest expense, net of capitalized interest costs | $ | 97 |  |  | $ | 99 |  |  | $ | 188 |  |  | $ | 201 |  |
| Banking fees and bond cost amortization | 7 |  |  | 8 |  |  | 13 |  |  | 15 |  |
| Interest income | (6 | ) |  | (1 | ) |  | (13 | ) |  | (8 | ) |
| Net foreign exchange results for financing activities | — |  |  | 1 |  |  | (5 | ) |  | 1 |  |
| Net financing charges | $ | 98 |  |  | $ | 107 |  |  | $ | 183 |  |  | $ | 209 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-19-000022:notes:122]
[same as prior period, unchanged from 0000833444-19-000005:notes:86]

[0000833444-19-000022:notes:123]
During September 2016, the Board of Directors of the Company approved amendments to the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based compensation awards. The Compensation Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter. A summary of the stock-based awards granted during the six month periods ended March 31, 2019 and 2018 is presented below:

[0000833444-19-000022:notes:124]
|  | Six Months Ended March 31, |
|  | 2019 |  | 2018 |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  | Number Granted |  | Weighted Average Grant Date Fair Value |
| Stock options | 1,741,510 |  |  | $ | 5.56 |  |  | 1,355,595 |  |  | $ | 7.05 |  |
| Restricted stock/units | 2,307,864 |  |  | 33.43 |  |  | 2,095,225 |  |  | 37.37 |  |
| Performance shares | 583,989 |  |  | 36.28 |  |  | 496,478 |  |  | 36.31 |  |

[0000833444-19-000022:notes:125]
[same as prior period, unchanged from 0000833444-19-000005:notes:89]

[0000833444-19-000022:notes:126]
[same as prior period, unchanged from 0000833444-19-000005:notes:90]

[0000833444-19-000022:notes:127]
[same as prior period, unchanged from 0000833444-19-000005:notes:91]

[0000833444-19-000022:notes:128]
|  | Six Months Ended March 31, |
|  | 2019 |  | 2018 |
| Expected life of option (years) | 6.4 |  | 6.5 |
| Risk-free interest rate | 2.77% |  | 2.28% |
| Expected volatility of the Company’s stock | 21.8% |  | 23.7% |
| Expected dividend yield on the Company’s stock | 3.29% |  | 2.78% |

[0000833444-19-000022:notes:129]
[same as prior period, unchanged from 0000833444-19-000005:notes:93]

[0000833444-19-000022:notes:130]
[same as prior period, unchanged from 0000833444-19-000005:notes:94]

[0000833444-19-000022:notes:131]
[same as prior period, unchanged from 0000833444-19-000005:notes:95]

[0000833444-19-000022:notes:132]
The Plan permits the grant of performance-based share unit ("PSU") awards. The PSUs are generally contingent on the achievement of pre-determined performance goals over a performance period of three years as well as on the award holder's continuous employment until the vesting date. The PSUs are also indexed to the achievement of specified levels of total shareholder return versus a peer group over the performance period. Each PSU that is earned will be settled with shares of the Company's ordinary shares following the completion of the performance period, unless the award holder elected to defer a portion or all of the award until retirement which would then be settled in cash.

[0000833444-19-000022:notes:133]
The fair value of each PSU is estimated on the date of grant with the use of a Monte Carlo simulation that uses the assumptions noted in the following table. The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant. For fiscal 2019 and fiscal 2018, the expected volatility is based on the historical volatility of the Company’s stock since October 2016 blended with the historical volatility of certain peer companies’ stock prior to October 2016 over the most recent three-year period as of the grant date.

[0000833444-19-000022:notes:134]
|  | Six Months Ended March 31, |
|  | 2019 |  | 2018 |
| Risk-free interest rate | 2.76% |  | 1.92% |
| Expected volatility of the Company’s stock | 22.9% |  | 21.7% |


## us-gaap:EarningsPerShareTextBlock

[0000833444-19-000022:notes:135]
[same as prior period, unchanged from 0000833444-19-000005:notes:106]

[0000833444-19-000022:notes:136]
[same as prior period, unchanged from 0000833444-19-000005:notes:107]

[0000833444-19-000022:notes:137]
[same as prior period, unchanged from 0000833444-19-000005:notes:108]

[0000833444-19-000022:notes:138]
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Income Available to Ordinary Shareholders |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 240 |  |  | $ | 184 |  |  | $ | 347 |  |  | $ | 109 |  |
| Income from discontinued operations | 275 |  |  | 254 |  |  | 523 |  |  | 559 |  |
| Basic and diluted income available to shareholders | $ | 515 |  |  | $ | 438 |  |  | $ | 870 |  |  | $ | 668 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 902.5 |  |  | 926.2 |  |  | 912.1 |  |  | 926.2 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 3.4 |  |  | 6.3 |  |  | 3.5 |  |  | 6.7 |  |
| Diluted weighted average shares outstanding | 905.9 |  |  | 932.5 |  |  | 915.6 |  |  | 932.9 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Options to purchase shares | 2.2 |  |  | 1.4 |  |  | 2.4 |  |  | 1.2 |  |

[0000833444-19-000022:notes:139]
During the three months ended March 31, 2019 and 2018, the Company declared dividends of $0.26 per share. During the six months ended March 31, 2019 and 2018, the Company declared dividends of $0.52 per share. The Company paid all dividends in the month subsequent to the end of each fiscal quarter.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-19-000022:notes:140]
[same as prior period, unchanged from 0000833444-19-000005:notes:251]

[0000833444-19-000022:notes:141]
[same as prior period, unchanged from 0000833444-19-000005:notes:252]

[0000833444-19-000022:notes:142]
|  | Three Months Ended March 31, 2019 |  | Three Months Ended March 31, 2018 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, December 31, | $ | 20,102 |  |  | $ | 1,305 |  |  | $ | 21,407 |  |  | $ | 20,535 |  |  | $ | 965 |  |  | $ | 21,500 |  |
| Total comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 515 |  |  | 43 |  |  | 558 |  |  | 438 |  |  | 33 |  |  | 471 |  |
| Foreign currency translation adjustments | 114 |  |  | 3 |  |  | 117 |  |  | 168 |  |  | 31 |  |  | 199 |  |
| Realized and unrealized gains (losses) on derivatives | 14 |  |  | 3 |  |  | 17 |  |  | (6 | ) |  | 1 |  |  | (5 | ) |
| Realized and unrealized losses on marketable securities | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Other comprehensive income | 128 |  |  | 6 |  |  | 134 |  |  | 160 |  |  | 32 |  |  | 192 |  |
| Comprehensive income | 643 |  |  | 49 |  |  | 692 |  |  | 598 |  |  | 65 |  |  | 663 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (235 | ) |  | — |  |  | (235 | ) |  | (240 | ) |  | — |  |  | (240 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (89 | ) |  | (89 | ) |  | — |  |  | (43 | ) |  | (43 | ) |
| Repurchases of ordinary shares | (533 | ) |  | — |  |  | (533 | ) |  | (49 | ) |  | — |  |  | (49 | ) |
| Change in noncontrolling interest share | — |  |  | — |  |  | — |  |  | — |  |  | 19 |  |  | 19 |  |
| Other, including options exercised | 59 |  |  | — |  |  | 59 |  |  | 30 |  |  | — |  |  | 30 |  |
| Ending balance, March 31 | $ | 20,036 |  |  | $ | 1,265 |  |  | $ | 21,301 |  |  | $ | 20,874 |  |  | $ | 1,006 |  |  | $ | 21,880 |  |

[0000833444-19-000022:notes:143]
|  | Six Months Ended March 31, 2019 |  | Six Months Ended March 31, 2018 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, September 30, | $ | 21,164 |  |  | $ | 1,294 |  |  | $ | 22,458 |  |  | $ | 20,447 |  |  | $ | 920 |  |  | $ | 21,367 |  |
| Total comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 870 |  |  | 87 |  |  | 957 |  |  | 668 |  |  | 61 |  |  | 729 |  |
| Foreign currency translation adjustments | (13 | ) |  | 12 |  |  | (1 | ) |  | 226 |  |  | 47 |  |  | 273 |  |
| Realized and unrealized gains (losses) on derivatives | 15 |  |  | 4 |  |  | 19 |  |  | (5 | ) |  | 2 |  |  | (3 | ) |
| Realized and unrealized losses on marketable securities | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Other comprehensive income | 2 |  |  | 16 |  |  | 18 |  |  | 219 |  |  | 49 |  |  | 268 |  |
| Comprehensive income | 872 |  |  | 103 |  |  | 975 |  |  | 887 |  |  | 110 |  |  | 997 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (475 | ) |  | — |  |  | (475 | ) |  | (482 | ) |  | — |  |  | (482 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (132 | ) |  | (132 | ) |  | — |  |  | (43 | ) |  | (43 | ) |
| Repurchases of ordinary shares | (1,000 | ) |  | — |  |  | (1,000 | ) |  | (199 | ) |  | — |  |  | (199 | ) |
| Change in noncontrolling interest share | — |  |  | — |  |  | — |  |  | — |  |  | 19 |  |  | 19 |  |
| Adoption of ASC 606 | (45 | ) |  | — |  |  | (45 | ) |  | — |  |  | — |  |  | — |  |
| Adoption of ASU 2016-16 | (546 | ) |  | — |  |  | (546 | ) |  | — |  |  | — |  |  | — |  |
| Adoption of ASU 2016-09 | — |  |  | — |  |  | — |  |  | 179 |  |  | — |  |  | 179 |  |
| Other, including options exercised | 66 |  |  | — |  |  | 66 |  |  | 42 |  |  | — |  |  | 42 |  |
| Ending balance, March 31 | $ | 20,036 |  |  | $ | 1,265 |  |  | $ | 21,301 |  |  | $ | 20,874 |  |  | $ | 1,006 |  |  | $ | 21,880 |  |

[0000833444-19-000022:notes:144]
[same as prior period, unchanged from 0000833444-19-000005:notes:253]

[0000833444-19-000022:notes:145]
As previously disclosed, during the quarter ended December 31, 2018, the Company adopted ASU 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory." As a result, the Company recognized deferred taxes of $546 million related to the tax effects of all intra-entity sales of assets other than inventory on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2018.

[0000833444-19-000022:notes:146]
As previously disclosed, during the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09, "Compensation - Stock Compensation (Topic 718) Improvements to Employee Share-Based Payment Accounting." As a result, the Company recognized deferred tax assets of $179 million related to certain operating loss carryforwards resulting from the exercise of employee stock options and restricted stock vestings on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2017.

[0000833444-19-000022:notes:147]
Following the Tyco Merger, the Company adopted, subject to the ongoing existence of sufficient distributable reserves, the existing Tyco International plc $1 billion share repurchase program in September 2016. In December 2017, the Company's Board of Directors approved a $1 billion increase to its share repurchase authorization. In November 2018, the Company's Board of Directors approved an additional $1 billion increase to its share repurchase authorization. In March 2019, the Company's Board of Directors approved an additional $8.5 billion increase to its share repurchase authorization, subject to the completion of the previously announced sale of the Company's Power Solutions business. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. During the three and six months ended March 31, 2019, the Company repurchased $533 million and $1 billion of its ordinary

[0000833444-19-000022:notes:148]
shares, respectively. For the three and six months ended March 31, 2018, the Company repurchased $49 million and $199 million of its ordinary shares, respectively. As of March 31, 2019, approximately $1.0 billion remains available under the share repurchase program, with an additional $8.5 billion available upon completion of the previously announced sale of the Company's Power Solutions business.

[0000833444-19-000022:notes:149]
On May 1, 2019, the Company announced that it plans to launch a "modified Dutch auction" tender offer for up to $4.0 billion of its ordinary shares with a price range between $36.00 and $40.00 per share.

[0000833444-19-000022:notes:150]
[same as prior period, unchanged from 0000833444-19-000005:notes:257]

[0000833444-19-000022:notes:151]
The following schedule present changes in the redeemable noncontrolling interests for the three and six months ended March 31, 2018 (in millions):

[0000833444-19-000022:notes:152]
|  | Three Months Ended March 31, 2018 |
| Beginning balance, December 31, 2017 | $ | 226 |  |
| Net income | 12 |  |
| Foreign currency translation adjustments | 5 |  |
| Realized and unrealized losses on derivatives | (5 | ) |
| Dividends | (3 | ) |
| Ending balance, March 31, 2018 | $ | 235 |  |

[0000833444-19-000022:notes:153]
|  | Six Months Ended March 31, 2018 |
| Beginning balance, September 30, 2017 | $ | 211 |  |
| Net income | 25 |  |
| Foreign currency translation adjustments | 10 |  |
| Realized and unrealized losses on derivatives | (8 | ) |
| Dividends | (3 | ) |
| Ending balance, March 31, 2018 | $ | 235 |  |

[0000833444-19-000022:notes:154]
The following schedules present changes in accumulated other comprehensive income ("AOCI") attributable to Johnson Controls (in millions, net of tax):

[0000833444-19-000022:notes:155]
|  | Three Months EndedMarch 31, |
|  | 2019 |  | 2018 |
| Foreign currency translation adjustments ("CTA") |  |  |  |
| Balance at beginning of period | $ | (1,066 | ) |  | $ | (423 | ) |
| Aggregate adjustment for the period (net of tax effect of $0) | 114 |  |  | 168 |  |
| Balance at end of period | (952 | ) |  | (255 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (12 | ) |  | 7 |  |
| Current period changes in fair value (net of tax effect of $6 and $(2)) | 12 |  |  | (4 | ) |
| Reclassification to income (net of tax effect of $2 and $0) ** | 2 |  |  | (2 | ) |
| Balance at end of period | 2 |  |  | 1 |  |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | — |  |  | 4 |  |
| Current period changes in fair value (net of tax effect of $0) | — |  |  | (2 | ) |
| Balance at end of period | — |  |  | 2 |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (2 | ) |  | (2 | ) |
| Other changes | — |  |  | — |  |
| Balance at end of period | (2 | ) |  | (2 | ) |
| Accumulated other comprehensive loss, end of period | $ | (952 | ) |  | $ | (254 | ) |

[0000833444-19-000022:notes:156]
|  | Six Months EndedMarch 31, |
|  | 2019 |  | 2018 |
| CTA |  |  |  |
| Balance at beginning of period | $ | (939 | ) |  | $ | (481 | ) |
| Aggregate adjustment for the period (net of tax effect of $0 and $1) * | (13 | ) |  | 226 |  |
| Balance at end of period | (952 | ) |  | (255 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (13 | ) |  | 6 |  |
| Current period changes in fair value (net of tax effect of $4 and $1) | 8 |  |  | 2 |  |
| Reclassification to income (net of tax effect of $3 and $(2)) ** | 7 |  |  | (7 | ) |
| Balance at end of period | 2 |  |  | 1 |  |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | 8 |  |  | 4 |  |
| Adoption of ASU 2016-01 *** | (8 | ) |  | — |  |
| Current period changes in fair value (net of tax effect of $0) | — |  |  | (2 | ) |
| Balance at end of period | — |  |  | 2 |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (2 | ) |  | (2 | ) |
| Other changes | — |  |  | — |  |
| Balance at end of period | (2 | ) |  | (2 | ) |
| Accumulated other comprehensive loss, end of period | $ | (952 | ) |  | $ | (254 | ) |

[0000833444-19-000022:notes:157]
* During the six months ended March 31, 2018, $12 million of cumulative CTA was recognized as part of the divestiture-related gain recognized as part of the divestiture of Scott Safety.

[0000833444-19-000022:notes:158]
** Refer to Note 15, "Derivative Instruments and Hedging Activities," of the notes to consolidated financial statements for disclosure of the line items in the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.

[0000833444-19-000022:notes:159]
*** As previously disclosed, during the quarter ended December 31, 2018, the Company adopted ASU 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." As a result the Company reclassified $8 million of unrealized gains on marketable securities to retained earnings as of October 1, 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-19-000022:notes:160]
[same as prior period, unchanged from 0000833444-19-000005:notes:56]

[0000833444-19-000022:notes:161]
[same as prior period, unchanged from 0000833444-19-000005:notes:57]

[0000833444-19-000022:notes:162]
[same as prior period, unchanged from 0000833444-19-000005:notes:58]

[0000833444-19-000022:notes:163]
The Company has global operations and participates in the foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three and six months ended March 31, 2019 and 2018.

[0000833444-19-000022:notes:164]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of lead, copper, tin, aluminum and polypropylene in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As cash flow hedges, the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in commodity prices during the three and six months ended March 31, 2019 and 2018.

[0000833444-19-000022:notes:165]
[same as prior period, unchanged from 0000833444-19-000005:notes:61]

[0000833444-19-000022:notes:166]
|  |  | Volume Outstanding as of |
| Commodity |  | March 31, 2019 |  | September 30, 2018 |
| Copper |  | 3,071 |  |  | 3,175 |  |
| Polypropylene |  | 12,392 |  |  | 15,868 |  |
| Lead |  | 4,500 |  |  | 49,066 |  |
| Aluminum |  | 2,637 |  |  | 3,381 |  |
| Tin |  | 1,594 |  |  | 3,076 |  |

[0000833444-19-000022:notes:167]
[same as prior period, unchanged from 0000833444-19-000005:notes:63]

[0000833444-19-000022:notes:168]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company’s net investments globally. At March 31, 2019, the Company had one billion euro, 750 million euro, 423 million euro and 58 million euro in bonds and a 215 million euro term loan designated as net investment hedges in the Company's net investment in Europe and 35 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan. Also, at September 30, 2018, the Company had one billion euro, 750 million euro, 423 million euro and 58 million euro in bonds and a 215 million euro term loan designated as net investment hedges in the Company's net investment in Europe and 35 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan.

[0000833444-19-000022:notes:169]
[same as prior period, unchanged from 0000833444-19-000005:notes:65]

[0000833444-19-000022:notes:170]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount.  As of March 31, 2019, the Company hedged approximately 1.6 million shares of its ordinary shares, which have a cost basis of $66 million.

[0000833444-19-000022:notes:171]
As of September 30, 2018, the Company hedged approximately 1.8 million shares of its ordinary shares, which have a cost basis of $73 million.

[0000833444-19-000022:notes:172]
[same as prior period, unchanged from 0000833444-19-000005:notes:67]

[0000833444-19-000022:notes:173]
[same as prior period, unchanged from 0000833444-19-000005:notes:68]

[0000833444-19-000022:notes:174]
[same as prior period, unchanged from 0000833444-19-000005:notes:69]

[0000833444-19-000022:notes:175]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | March 31, |  | September 30, |  | March 31, |  | September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 9 |  |  | $ | 6 |  |  | $ | 12 |  |  | $ | 10 |  |
| Commodity derivatives | 1 |  |  | 1 |  |  | — |  |  | — |  |
| Assets held for sale |  |  |  |  |  |  |  |
| Commodity derivatives | 7 |  |  | — |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 59 |  |  | 63 |  |
| Total assets | $ | 17 |  |  | $ | 7 |  |  | $ | 71 |  |  | $ | 73 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 7 |  |  | $ | 10 |  |  | $ | 5 |  |  | $ | 2 |  |
| Commodity derivatives | — |  |  | 2 |  |  | — |  |  | — |  |
| Liabilities held for sale |  |  |  |  |  |  |  |
| Commodity derivatives | 8 |  |  | 12 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,065 |  |  | 3,149 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,080 |  |  | $ | 3,173 |  |  | $ | 5 |  |  | $ | 2 |  |

[0000833444-19-000022:notes:176]
[same as prior period, unchanged from 0000833444-19-000005:notes:71]

[0000833444-19-000022:notes:177]
[same as prior period, unchanged from 0000833444-19-000005:notes:72]

[0000833444-19-000022:notes:178]
The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position. Collateral is generally not required of the Company or the counterparties under the master netting agreements. As of March 31, 2019 and September 30, 2018, no cash collateral was received or pledged under the master netting agreements.

[0000833444-19-000022:notes:179]
The gross and net amounts of derivative assets and liabilities were as follows (in millions):

[0000833444-19-000022:notes:180]
|  |  | Fair Value of Assets |  | Fair Value of Liabilities |
|  |  | March 31, |  | September 30, |  | March 31, |  | September 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Gross amount recognized |  | $ | 88 |  |  | $ | 80 |  |  | $ | 3,085 |  |  | $ | 3,175 |  |
| Gross amount eligible for offsetting |  | (10 | ) |  | (12 | ) |  | (10 | ) |  | (12 | ) |
| Net amount |  | $ | 78 |  |  | $ | 68 |  |  | $ | 3,075 |  |  | $ | 3,163 |  |

[0000833444-19-000022:notes:181]
[same as prior period, unchanged from 0000833444-19-000005:notes:74]

[0000833444-19-000022:notes:182]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the three and six months ended March 31, 2019 and 2018 (in millions):

[0000833444-19-000022:notes:183]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Foreign currency exchange derivatives |  | $ | 9 |  |  | $ | (5 | ) |  | $ | 9 |  |  | $ | 1 |  |
| Commodity derivatives |  | 9 |  |  | (1 | ) |  | 3 |  |  | 2 |  |
| Total |  | $ | 18 |  |  | $ | (6 | ) |  | $ | 12 |  |  | $ | 3 |  |

[0000833444-19-000022:notes:184]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the three and six months ended March 31, 2019 and 2018 (in millions):

[0000833444-19-000022:notes:185]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 2 |  |  | $ | (3 | ) |  | $ | 2 |  |  | $ | (1 | ) |
| Foreign currency exchange derivatives |  | Income from discontinued operations |  | (1 | ) |  | 1 |  |  | — |  |  | 1 |  |
| Commodity derivatives |  | Cost of sales |  | (1 | ) |  | 1 |  |  | (3 | ) |  | 3 |  |
| Commodity derivatives |  | Income from discontinued operations |  | (4 | ) |  | 3 |  |  | (9 | ) |  | 6 |  |
| Total |  |  |  | $ | (4 | ) |  | $ | 2 |  |  | $ | (10 | ) |  | $ | 9 |  |

[0000833444-19-000022:notes:186]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the three and six months ended March 31, 2019 and 2018 (in millions):

[0000833444-19-000022:notes:187]
|  |  |  |  | Amount of Gain (Loss) Recognized inIncome on Derivative |
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (2 | ) |  | $ | (3 | ) |  | $ | (6 | ) |  | $ | (1 | ) |
| Foreign currency exchange derivatives |  | Net financing charges |  | (3 | ) |  | — |  |  | (24 | ) |  | 3 |  |
| Foreign currency exchange derivatives |  | Income from discontinued operations |  | 28 |  |  | (4 | ) |  | 54 |  |  | (1 | ) |
| Equity swap |  | Selling, general and administrative |  | 12 |  |  | (5 | ) |  | 3 |  |  | (7 | ) |
| Total |  |  |  | $ | 35 |  |  | $ | (12 | ) |  | $ | 27 |  |  | $ | (6 | ) |

[0000833444-19-000022:notes:188]
The pre-tax gains (losses) recorded in CTA within other comprehensive income (loss) related to net investment hedges were $50 million and $(100) million for the three months ended March 31, 2019 and 2018, respectively. The pre-tax gains (losses) recorded in CTA within other comprehensive income (loss) related to net investment hedges were $84 million and $(136) million for the six months ended March 31, 2019 and 2018, respectively. For the three and six months ended March 31, 2019 and 2018, no gains or losses were reclassified from CTA into income for the Company’s outstanding net investment hedges.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-19-000022:notes:189]
[same as prior period, unchanged from 0000833444-19-000005:notes:112]

[0000833444-19-000022:notes:190]
[same as prior period, unchanged from 0000833444-19-000005:notes:113]

[0000833444-19-000022:notes:191]
[same as prior period, unchanged from 0000833444-19-000005:notes:114]

[0000833444-19-000022:notes:192]
[same as prior period, unchanged from 0000833444-19-000005:notes:115]

[0000833444-19-000022:notes:193]
[same as prior period, unchanged from 0000833444-19-000005:notes:116]

[0000833444-19-000022:notes:194]
[same as prior period, unchanged from 0000833444-19-000005:notes:117]

[0000833444-19-000022:notes:195]
[same as prior period, unchanged from 0000833444-19-000005:notes:118]

[0000833444-19-000022:notes:196]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of March 31, 2019 and September 30, 2018 (in millions):

[0000833444-19-000022:notes:197]
|  | Fair Value Measurements Using: |
|  | Total as of March 31, 2019 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Exchange traded funds (fixed income)1 | 19 |  |  | 19 |  |  | — |  |  | — |  |
| Assets held for sale |  |  |  |  |  |  |  |
| Commodity derivatives | 7 |  |  | — |  |  | 7 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 99 |  |  | 99 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 133 |  |  | 133 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 111 |  |  | 111 |  |  | — |  |  | — |  |
| Equity swap | 59 |  |  | — |  |  | 59 |  |  | — |  |
| Noncurrent assets held for sale |  |  |  |  |  |  |  |
| Investments in marketable common stock | 3 |  |  | 3 |  |  | — |  |  | — |  |
| Total assets | $ | 453 |  |  | $ | 365 |  |  | $ | 88 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |  | $ | — |  |
| Liabilities held for sale |  |  |  |  |  |  |  |
| Commodity derivatives | 8 |  |  | — |  |  | 8 |  |  | — |  |
| Total liabilities | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |

[0000833444-19-000022:notes:198]
[same as prior period, unchanged from 0000833444-19-000005:notes:121]

[0000833444-19-000022:notes:199]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 20, "Commitments and Contingencies," of the notes to consolidated financial statements for further details.

[0000833444-19-000022:notes:200]
[same as prior period, unchanged from 0000833444-19-000005:notes:123]

[0000833444-19-000022:notes:201]
[same as prior period, unchanged from 0000833444-19-000005:notes:124]

[0000833444-19-000022:notes:202]
[same as prior period, unchanged from 0000833444-19-000005:notes:125]

[0000833444-19-000022:notes:203]
[same as prior period, unchanged from 0000833444-19-000005:notes:126]

[0000833444-19-000022:notes:204]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. During the three and six months ended March 31, 2019, the Company recognized unrealized gains of $7 million and unrealized losses of $2 million, respectively, in the consolidated statements of income on these investments that were still held as of March 31, 2019, where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-19-000022:notes:205]
Investments in marketable common stock and exchange traded funds:  Investments in marketable common stock and exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. During the three and six months ended March 31, 2019, the Company recognized unrealized gains of $21 million and unrealized losses of $1 million, respectively, in the consolidated statements of income on

[0000833444-19-000022:notes:206]
these investments that were still held as of March 31, 2019, of which $20 million of gains and $1 million of losses, respectively, related to restricted investments. Refer to Note 20, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-19-000022:notes:207]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The fair value of long-term debt was $9.6 billion at March 31, 2019 and September 30, 2018. The fair value of public debt was $8.6 billion at March 31, 2019 and September 30, 2018, which was determined primarily using market quotes classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was $1.0 billion at March 31, 2019 and September 30, 2018, which was determined based on quoted market prices for similar instruments classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0000833444-19-000022:notes:208]
[same as prior period, unchanged from 0000833444-19-000005:notes:142]

[0000833444-19-000022:notes:209]
[same as prior period, unchanged from 0000833444-19-000005:notes:143]

[0000833444-19-000022:notes:210]
[same as prior period, unchanged from 0000833444-19-000005:notes:144]

[0000833444-19-000022:notes:211]
At March 31, 2019 and 2018, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-19-000022:notes:212]
[same as prior period, unchanged from 0000833444-19-000005:notes:242]

[0000833444-19-000022:notes:213]
[same as prior period, unchanged from 0000833444-19-000005:notes:243]

[0000833444-19-000022:notes:214]
| • | Building Solutions North America designs, sells, installs, and services HVAC and controls systems, integrated electronic security systems (including monitoring), and integrated fire detection and suppression systems for commercial, industrial, |

[0000833444-19-000022:notes:215]
retail, small business, institutional and governmental customers in North America. Building Solutions North America also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems, to non-residential building and industrial applications in the North American marketplace.

[0000833444-19-000022:notes:216]
[same as prior period, unchanged from 0000833444-19-000005:notes:245]

[0000833444-19-000022:notes:217]
[same as prior period, unchanged from 0000833444-19-000005:notes:246]

[0000833444-19-000022:notes:218]
[same as prior period, unchanged from 0000833444-19-000005:notes:247]

[0000833444-19-000022:notes:219]
[same as prior period, unchanged from 0000833444-19-000005:notes:248]

[0000833444-19-000022:notes:220]
On October 1, 2018, the Company adopted ASU No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." The new standard requires the mark-to-market of marketable securities investments previously recorded within accumulated other comprehensive income on the statement of financial position be recorded in the statement of income on a prospective basis beginning as of the adoption date. As these restricted investments do not relate to the underlying operating performance of its business, the Company’s definition of segment earnings excludes the mark-to-market adjustments beginning in the first quarter of fiscal 2019.

[0000833444-19-000022:notes:221]
[same as prior period, unchanged from 0000833444-19-000005:notes:250]

[0000833444-19-000022:notes:222]
Financial information relating to the Company’s reportable segments is as follows (in millions):

[0000833444-19-000022:notes:223]
|  | Net Sales |
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Building Solutions North America | $ | 2,187 |  |  | $ | 2,097 |  |  | $ | 4,303 |  |  | $ | 4,109 |  |
| Building Solutions EMEA/LA | 878 |  |  | 907 |  |  | 1,785 |  |  | 1,822 |  |
| Building Solutions Asia Pacific | 628 |  |  | 586 |  |  | 1,241 |  |  | 1,183 |  |
| Global Products | 2,086 |  |  | 2,040 |  |  | 3,914 |  |  | 3,821 |  |
| Total net sales | $ | 5,779 |  |  | $ | 5,630 |  |  | $ | 11,243 |  |  | $ | 10,935 |  |

[0000833444-19-000022:notes:224]
|  | Segment EBITA |
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Building Solutions North America | $ | 257 |  |  | $ | 239 |  |  | $ | 507 |  |  | $ | 466 |  |
| Building Solutions EMEA/LA | 80 |  |  | 77 |  |  | 157 |  |  | 146 |  |
| Building Solutions Asia Pacific | 76 |  |  | 71 |  |  | 142 |  |  | 145 |  |
| Global Products | 251 |  |  | 228 |  |  | 441 |  |  | 514 |  |
| Total segment EBITA | $ | 664 |  |  | $ | 615 |  |  | $ | 1,247 |  |  | $ | 1,271 |  |
| Corporate expenses | $ | (167 | ) |  | $ | (162 | ) |  | $ | (303 | ) |  | $ | (300 | ) |
| Amortization of intangible assets | (98 | ) |  | (92 | ) |  | (195 | ) |  | (184 | ) |
| Restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (154 | ) |
| Net mark-to-market adjustments | 20 |  |  | — |  |  | (1 | ) |  | — |  |
| Net financing charges | (98 | ) |  | (107 | ) |  | (183 | ) |  | (209 | ) |
| Income from continuing operations before income taxes | $ | 321 |  |  | $ | 254 |  |  | $ | 565 |  |  | $ | 424 |  |


## us-gaap:GuaranteesTextBlock

[0000833444-19-000022:notes:225]
[same as prior period, unchanged from 0000833444-19-000005:notes:135]

[0000833444-19-000022:notes:226]
[same as prior period, unchanged from 0000833444-19-000005:notes:136]

[0000833444-19-000022:notes:227]
[same as prior period, unchanged from 0000833444-19-000005:notes:137]

[0000833444-19-000022:notes:228]
[same as prior period, unchanged from 0000833444-19-000005:notes:138]

[0000833444-19-000022:notes:229]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations, including extended warranties for which deferred revenue is recorded, for the six months ended March 31, 2019 and 2018 were as follows (in millions):

[0000833444-19-000022:notes:230]
|  | Six Months EndedMarch 31, |
|  | 2019 |  | 2018 |
| Balance at beginning of period | $ | 315 |  |  | $ | 323 |  |
| Accruals for warranties issued during the period | 48 |  |  | 52 |  |
| Accruals from acquisition and divestitures | — |  |  | 1 |  |
| Accruals related to pre-existing warranties | (9 | ) |  | (9 | ) |
| Settlements made (in cash or in kind) during the period | (51 | ) |  | (56 | ) |
| Currency translation | 1 |  |  | 4 |  |
| Balance at end of period | $ | 304 |  |  | $ | 315 |  |

[0000833444-19-000022:notes:231]
As a result of the Tyco merger in the fourth quarter of fiscal 2016, the Company recorded, as part of the acquired liabilities of Tyco, $290 million of post sale contingent tax indemnification liabilities. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. At March 31, 2019 and September 30, 2018, the Company recorded liabilities of $255 million. Of the $255 million recorded at March 31, 2019, $235 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements. Based on the current status of certain indemnifications, it is reasonably possible that tax indemnification liabilities may change in the near-term.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-19-000022:notes:232]
Commitments and Contingencies

[0000833444-19-000022:notes:233]
Environmental Matters

[0000833444-19-000022:notes:234]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of March 31, 2019, reserves for environmental liabilities for continuing operations totaled $30 million, of which $15 million was recorded within other current liabilities and $15 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $37 million at September 30, 2018, of which $10 million was recorded within other current liabilities and $27 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At March 31, 2019 and September 30, 2018, the Company recorded conditional asset retirement obligations for continuing operations of $29 million.

[0000833444-19-000022:notes:235]
Asbestos Matters

[0000833444-19-000022:notes:236]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability

[0000833444-19-000022:notes:237]
claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-19-000022:notes:238]
As of March 31, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $175 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $541 million, of which $55 million was recorded in other current liabilities and $486 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $366 million, of which $51 million was recorded in other current assets, and $315 million was recorded in other noncurrent assets. Assets included $19 million of cash and $263 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at March 31, 2019 was $84 million. As of September 30, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $173 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $550 million, of which $55 million was recorded in other current liabilities and $495 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $33 million was recorded in other current assets, and $344 million was recorded in other noncurrent assets. Assets included $6 million of cash and $281 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2018 was $90 million.

[0000833444-19-000022:notes:239]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-19-000022:notes:240]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-19-000022:notes:241]
Insurable Liabilities

[0000833444-19-000022:notes:242]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At March 31, 2019 and September 30, 2018, the insurable liabilities totaled $423 million and $417 million, respectively, of which $95 million and $95 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $306 million and $300 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at March 31, 2019 and September 30, 2018 were $26 million, of which $6 million was recorded within other current assets and $20 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-19-000022:notes:243]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-19-000022:notes:244]
Two of our subsidiaries, Chemguard, Inc. ("Chemguard") and Tyco Fire Products L.P. ("Tyco Fire Products"), have been named, along with other defendant manufacturers, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated ("PFAS") compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued regulatory limits, however; while those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

[0000833444-19-000022:notes:245]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-19-000022:notes:246]
In September of 2018, the Company filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to the MDL.

[0000833444-19-000022:notes:247]
AFFF Putative Class Actions

[0000833444-19-000022:notes:248]
Chemguard and Tyco Fire Products are named in 21 putative class actions in federal and state courts in Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania and Washington. Each of these cases has been transferred to the MDL. The following putative class actions were filed in fiscal year 2019:

[0000833444-19-000022:notes:249]
| • | Grubb v. The 3M Company et al., filed October 30, 2018 in the United States District Court, District of Delaware. |

[0000833444-19-000022:notes:250]
| • | County of Dutchess v. The 3M Company et al., filed October 12, 2018 in the United States District Court, Southern District of New York. |

[0000833444-19-000022:notes:251]
| • | Battisti et al. v. The 3M Company et al., filed December 20, 2018 in the United States District Court, Middle District of Florida. |

[0000833444-19-000022:notes:252]
| • | Jackson et al. v. The 3M Company et al., filed February 5, 2019 in the United States District Court, Western District of Washington. |

[0000833444-19-000022:notes:253]
AFFF Individual or Mass Actions

[0000833444-19-000022:notes:254]
There are approximately 58 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases), Pennsylvania (11 cases) and New Mexico (2 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania and two plaintiffs in New Mexico.  These matters have been transferred to the MDL.  The Company is also on notice of approximately 660 other possible individual product liability claims and three possible municipal claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, but the Company anticipates that they soon will be.

[0000833444-19-000022:notes:255]
AFFF Municipal Cases

[0000833444-19-000022:notes:256]
Chemguard and Tyco Fire Products are also defendants in 17 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, Florida, Massachusetts, New Jersey, New York, Maryland and Ohio.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  All but one of these cases either have been transferred or identified for transfer to the MDL. The following municipal actions were filed in fiscal year 2019:

[0000833444-19-000022:notes:257]
| • | Dutchess County v. The 3M Company et al. filed October 12, 2018 (removed to the United States District Court, Southern District of New York) and styled as a class action. |

[0000833444-19-000022:notes:258]
| • | City of Dayton v. The 3M Company et al., filed October 3, 2018 in the United States District Court, Southern District of Ohio. |

[0000833444-19-000022:notes:259]
| • | City of Stuart v. The 3M Company et al., filed October 18, 2018 in the United States District Court, Southern District of Florida. |

[0000833444-19-000022:notes:260]
| • | City of Tucson and Town of Marana v. The 3M Company et al., filed November 8, 2018 in the Superior Court of the State of Arizona, County of Pima (removed to the United States District Court for the District of Arizona). |

[0000833444-19-000022:notes:261]
| • | New Jersey-American Water Company, Inc. v. The 3M Company et al., filed November 8, 2018 in the United States District Court for the District of New Jersey. |

[0000833444-19-000022:notes:262]
| • | Village of Farmingdale v. The 3M Company et al., filed December 19, 2018 in the Supreme Court of the State of New York, County of Nassau (removed to the United States District Court for the Eastern District of New York). |

[0000833444-19-000022:notes:263]
| • | Town of East Hampton v. The 3M Company et al., filed December 28, 2018 in the Supreme Court of the State of New York, County of Suffolk. |

[0000833444-19-000022:notes:264]
| • | Ridgewood Water v. The 3M Company et al., filed February 25, 2019, in the Superior Court of the State of New Jersey, Bergen County (removed to the United States District Court for the District of New Jersey). |

[0000833444-19-000022:notes:265]
| • | Atlantic City Municipal Utilities Authority v. The 3M Company et al., filed April 10, 2019 in the United States District Court, District of New Jersey. |

[0000833444-19-000022:notes:266]
| • | Town of Vienna v. The 3M Company et al., filed March 30, 2019 in the United States District Court, District of Maryland. |

[0000833444-19-000022:notes:267]
| • | New York American Water Company, Inc. v. The 3M Company et al., filed April 11, 2019 in the United States District Court, Eastern District of New York. |

[0000833444-19-000022:notes:268]
| • | City of Fairbanks v. The 3M Company et al., filed April 26, 2019 in the United States District Court, District of Alaska. |

[0000833444-19-000022:notes:269]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base. In addition, three water districts in Pennsylvania, Horsham Water and Sewer Authority, Warminster Municipal Authority, and Warrington Township have filed praecipes for summons against Chemguard and Tyco Fire Products and other AFFF manufacturers relating to alleged PFOS and PFOA contamination.  These praecipes are not active suits, but have the effect of tolling the statute of limitations. In addition, in February 2019, the County of Westchester, New York sent a Notice of Intent to File Suit against Chemguard, Tyco Fire Products, other AFFF manufacturers, and various governmental entities including the United States and the State of New York in connection with PFOS and PFOA contamination allegedly resulting from the use of AFFF in and around the County of Westchester.

[0000833444-19-000022:notes:270]
State Attorneys General Litigation related to AFFF

[0000833444-19-000022:notes:271]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al., No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-19-000022:notes:272]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This second complaint has not been served.

[0000833444-19-000022:notes:273]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752 -000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio.  The lawsuit seeks to recover costs and natural resource damages associated with the contamination.  This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-19-000022:notes:274]
AFFF Matters Related to the Tyco Fire Products Fire Technology Center in Marinette, Wisconsin

[0000833444-19-000022:notes:275]
Tyco Fire Products, in coordination with the Wisconsin Department of Natural Resources ("WDNR") and the Wisconsin Department of Health Services ("DHS"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin.  In connection with the assessment, PFOS and PFOA have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC.  Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working closely with WDNR and DHS to develop interim measures to remove these compounds from certain areas where they have been detected.

[0000833444-19-000022:notes:276]
Tyco Fire Products and its subsidiary Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFOA/PFOS contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.

[0000833444-19-000022:notes:277]
The Company is vigorously defending the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

[0000833444-19-000022:notes:278]
Bosch Litigation

[0000833444-19-000022:notes:279]
On March 15, 2019, a German subsidiary of the Company received a complaint from Robert Bosch GmbH (“Bosch”), filed in a German court. The complaint relates to a joint venture in which JCI’s ownership interest will be transferred to entities controlled by the Purchaser in connection with the previously announced sale of the Company’s Power Solutions business.

[0000833444-19-000022:notes:280]
The Company and Bosch are 80/20 parties to this joint venture, which operates a business related to automotive starter batteries and is separate from the Company’s supply agreement with Bosch.

[0000833444-19-000022:notes:281]
The complaint alleges that certain internal Company reorganization transactions were not in compliance with the arrangements relating to such joint venture. The complaint seeks a declaration that such internal reorganization transactions are void. In the alternative, the complaint seeks a declaration of damages that represent an alleged difference between (i) the value ascribed to the joint venture interests in connection with the Power Solutions sale and (ii) the value that was assigned to those interests in connection with such internal reorganization transactions. The Company believes that it has several strong defenses to the substance of the complaint and that the complaint substantially overstates any reasonable valuation of the joint venture interests. The Company does not believe the complaint has merit, and intends to defend it vigorously. While litigation is inherently uncertain, the Company believes that any ultimate liability that may arise from this proceeding would be immaterial to its business, financial condition and results of operations.

[0000833444-19-000022:notes:282]
Under the previously announced Stock and Asset Purchase Agreement dated November 13, 2018 between the Company and the Purchaser, the Company has agreed to indemnify the Purchaser for any damages that could arise from this litigation.

[0000833444-19-000022:notes:283]
Other Matters

[0000833444-19-000022:notes:284]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-19-000022:notes:285]
Related Party Transactions

[0000833444-19-000022:notes:286]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-19-000022:notes:287]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $54 million and $16 million, respectively, for the three months ended March 31, 2019; and $59 million and $15 million, respectively, for the three months ended March 31, 2018. The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $97 million and $30 million, respectively, for the six months ended March 31, 2019; and $104 million and $24 million, respectively, for the six months ended March 31, 2018.

[0000833444-19-000022:notes:288]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position for continuing operations (in millions):

[0000833444-19-000022:notes:289]
|  |  | March 31, 2019 |  | September 30, 2018 |  |
| Receivable from related parties |  | $ | 48 |  |  | $ | 36 |  |
| Payable to related parties |  | 12 |  |  | 18 |  |
