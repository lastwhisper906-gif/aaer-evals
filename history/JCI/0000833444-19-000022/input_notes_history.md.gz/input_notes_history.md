# JCI note change history — 0000833444-19-000005 → 0000833444-19-000022


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0000833444-19-000022:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of March 31, 2019, reserves for environmental liabilities for continuing operations totaled $30 million, of which $15 million was recorded within other current liabilities and $15 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $37 million at September 30, 2018, of which $10 million was recorded within other current liabilities and $27 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At March 31, 2019 and September 30, 2018, the Company recorded conditional asset retirement obligations for continuing operations of $29 million.
  (was, 2019-02-01, similarity 0.994):
[0000833444-19-000005:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of December 31, 2018, reserves for environmental liabilities for continuing operations totaled $32 million, of which $13 million was recorded within other current liabilities and $19 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $37 million at September 30, 2018, of which $10 million was recorded within other current liabilities and $27 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At December 31, 2018 and September 30, 2018, the Company recorded conditional asset retirement obligations for continuing operations of $29 million.

- changed (2019-05-03):
[0000833444-19-000022:note_history:2]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability
  (was, 2019-02-01, similarity 0.7372):
[0000833444-19-000005:note_history:2]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

- added (2019-05-03):
[0000833444-19-000022:note_history:3]
claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

- changed (2019-05-03):
[0000833444-19-000022:note_history:4]
As of March 31, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $175 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $541 million, of which $55 million was recorded in other current liabilities and $486 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $366 million, of which $51 million was recorded in other current assets, and $315 million was recorded in other noncurrent assets. Assets included $19 million of cash and $263 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at March 31, 2019 was $84 million. As of September 30, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $173 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $550 million, of which $55 million was recorded in other current liabilities and $495 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $33 million was recorded in other current assets, and $344 million was recorded in other noncurrent assets. Assets included $6 million of cash and $281 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2018 was $90 million.
  (was, 2019-02-01, similarity 0.9942):
[0000833444-19-000005:note_history:4]
As of December 31, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $194 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $546 million, of which $55 million was recorded in other current liabilities and $491 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $352 million, of which $33 million was recorded in other current assets, and $319 million was recorded in other noncurrent assets. Assets included $20 million of cash and $243 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at December 31, 2018 was $89 million. As of September 30, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $173 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $550 million, of which $55 million was recorded in other current liabilities and $495 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $33 million was recorded in other current assets, and $344 million was recorded in other noncurrent assets. Assets included $6 million of cash and $281 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2018 was $90 million.

- changed (2019-05-03):
[0000833444-19-000022:note_history:5]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At March 31, 2019 and September 30, 2018, the insurable liabilities totaled $423 million and $417 million, respectively, of which $95 million and $95 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $306 million and $300 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at March 31, 2019 and September 30, 2018 were $26 million, of which $6 million was recorded within other current assets and $20 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.
  (was, 2019-02-01, similarity 0.9137):
[0000833444-19-000005:note_history:5]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At December 31, 2018 and September 30, 2018, the insurable liabilities totaled $415 million and $417 million, respectively, of which $94 million and $95 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $299 million and $300 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at December 31, 2018 and September 30, 2018 were $26 million, of which $6 million was recorded within other current assets and $20 million was recorded within other noncurrent assets. The Company maintains captive insurance companies to manage its insurable liabilities.

- changed (2019-05-03):
[0000833444-19-000022:note_history:6]
Chemguard and Tyco Fire Products are named in 21 putative class actions in federal and state courts in Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania and Washington. Each of these cases has been transferred to the MDL. The following putative class actions were filed in fiscal year 2019:
  (was, 2019-02-01, similarity 0.9951):
[0000833444-19-000005:note_history:6]
Chemguard and Tyco Fire Products are named in 20 putative class actions in federal and state courts in Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania and Washington.  Each of these cases have been transferred to the MDL. The following putative class actions were filed in fiscal year 2019:

- changed (2019-05-03):
[0000833444-19-000022:note_history:7]
| • | County of Dutchess v. The 3M Company et al., filed October 12, 2018 in the United States District Court, Southern District of New York. |
  (was, 2019-02-01, similarity 0.9853):
[0000833444-19-000005:note_history:7]
| • | County of Dutchess v. 3M Company et al., filed October 12, 2018 in the United States District Court, Southern District of New York. |

- changed (2019-05-03):
[0000833444-19-000022:note_history:8]
| • | Jackson et al. v. The 3M Company et al., filed February 5, 2019 in the United States District Court, Western District of Washington. |
  (was, 2019-02-01, similarity 0.722):
[0000833444-19-000005:note_history:8]
| • | Dutchess County v. The 3M Company et al. filed October 12, 2018 (and removed to the United States District Court, Southern District of New York) and styled as a class action. |

- added (2019-05-03):
[0000833444-19-000022:note_history:9]
There are approximately 58 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases), Pennsylvania (11 cases) and New Mexico (2 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania and two plaintiffs in New Mexico.  These matters have been transferred to the MDL.  The Company is also on notice of approximately 660 other possible individual product liability claims and three possible municipal claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, but the Company anticipates that they soon will be.

- added (2019-05-03):
[0000833444-19-000022:note_history:10]
Chemguard and Tyco Fire Products are also defendants in 17 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, Florida, Massachusetts, New Jersey, New York, Maryland and Ohio.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  All but one of these cases either have been transferred or identified for transfer to the MDL. The following municipal actions were filed in fiscal year 2019:

- added (2019-05-03):
[0000833444-19-000022:note_history:11]
| • | Dutchess County v. The 3M Company et al. filed October 12, 2018 (removed to the United States District Court, Southern District of New York) and styled as a class action. |

- added (2019-05-03):
[0000833444-19-000022:note_history:12]
| • | Ridgewood Water v. The 3M Company et al., filed February 25, 2019, in the Superior Court of the State of New Jersey, Bergen County (removed to the United States District Court for the District of New Jersey). |

- added (2019-05-03):
[0000833444-19-000022:note_history:13]
| • | Atlantic City Municipal Utilities Authority v. The 3M Company et al., filed April 10, 2019 in the United States District Court, District of New Jersey. |

- added (2019-05-03):
[0000833444-19-000022:note_history:14]
| • | Town of Vienna v. The 3M Company et al., filed March 30, 2019 in the United States District Court, District of Maryland. |

- added (2019-05-03):
[0000833444-19-000022:note_history:15]
| • | New York American Water Company, Inc. v. The 3M Company et al., filed April 11, 2019 in the United States District Court, Eastern District of New York. |

- added (2019-05-03):
[0000833444-19-000022:note_history:16]
| • | City of Fairbanks v. The 3M Company et al., filed April 26, 2019 in the United States District Court, District of Alaska. |

- changed (2019-05-03):
[0000833444-19-000022:note_history:17]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base. In addition, three water districts in Pennsylvania, Horsham Water and Sewer Authority, Warminster Municipal Authority, and Warrington Township have filed praecipes for summons against Chemguard and Tyco Fire Products and other AFFF manufacturers relating to alleged PFOS and PFOA contamination.  These praecipes are not active suits, but have the effect of tolling the statute of limitations. In addition, in February 2019, the County of Westchester, New York sent a Notice of Intent to File Suit against Chemguard, Tyco Fire Products, other AFFF manufacturers, and various governmental entities including the United States and the State of New York in connection with PFOS and PFOA contamination allegedly resulting from the use of AFFF in and around the County of Westchester.
  (was, 2019-02-01, similarity 0.7844):
[0000833444-19-000005:note_history:17]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base. In addition, three water districts in Pennsylvania, Horsham Water and Sewer Authority, Warminster Municipal Authority, and Warrington Township have filed praecipes for summons against Chemguard and Tyco Fire Products and other AFFF manufacturers relating to alleged PFOS and PFOA contamination.  These praecipes are not active suits, but have the effect of tolling the statute of limitations.

- changed (2019-05-03):
[0000833444-19-000022:note_history:18]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al., No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.
  (was, 2019-02-01, similarity 0.9562):
[0000833444-19-000005:note_history:18]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. 3M Co., No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and identified for transfer to the MDL.

- added (2019-05-03):
[0000833444-19-000022:note_history:19]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This second complaint has not been served.

- changed (2019-05-03):
[0000833444-19-000022:note_history:20]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752 -000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio.  The lawsuit seeks to recover costs and natural resource damages associated with the contamination.  This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.
  (was, 2019-02-01, similarity 0.9609):
[0000833444-19-000005:note_history:20]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. 3M Co., No. G-4801-CI-021804752 -000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio.  The lawsuit seeks to recover costs and natural resource damages associated with the contamination.  This lawsuit has been removed to the United States District Court for the Northern District of Ohio and identified for transfer to the MDL.

- changed (2019-05-03):
[0000833444-19-000022:note_history:21]
Tyco Fire Products and its subsidiary Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFOA/PFOS contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.
  (was, 2019-02-01, similarity 0.9413):
[0000833444-19-000005:note_history:21]
Tyco Fire Products and its subsidiary Chemguard are defendants in two lawsuits in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFOA/PFOS contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and will identify it for transfer to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater.

- added (2019-05-03):
[0000833444-19-000022:note_history:22]
Bosch Litigation

- added (2019-05-03):
[0000833444-19-000022:note_history:23]
On March 15, 2019, a German subsidiary of the Company received a complaint from Robert Bosch GmbH (“Bosch”), filed in a German court. The complaint relates to a joint venture in which JCI’s ownership interest will be transferred to entities controlled by the Purchaser in connection with the previously announced sale of the Company’s Power Solutions business.

- added (2019-05-03):
[0000833444-19-000022:note_history:24]
The Company and Bosch are 80/20 parties to this joint venture, which operates a business related to automotive starter batteries and is separate from the Company’s supply agreement with Bosch.

- added (2019-05-03):
[0000833444-19-000022:note_history:25]
The complaint alleges that certain internal Company reorganization transactions were not in compliance with the arrangements relating to such joint venture. The complaint seeks a declaration that such internal reorganization transactions are void. In the alternative, the complaint seeks a declaration of damages that represent an alleged difference between (i) the value ascribed to the joint venture interests in connection with the Power Solutions sale and (ii) the value that was assigned to those interests in connection with such internal reorganization transactions. The Company believes that it has several strong defenses to the substance of the complaint and that the complaint substantially overstates any reasonable valuation of the joint venture interests. The Company does not believe the complaint has merit, and intends to defend it vigorously. While litigation is inherently uncertain, the Company believes that any ultimate liability that may arise from this proceeding would be immaterial to its business, financial condition and results of operations.

- added (2019-05-03):
[0000833444-19-000022:note_history:26]
Under the previously announced Stock and Asset Purchase Agreement dated November 13, 2018 between the Company and the Purchaser, the Company has agreed to indemnify the Purchaser for any damages that could arise from this litigation.

- removed (2019-05-03):
[0000833444-19-000005:note_history:27]
There are approximately 55 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases) and Pennsylvania (10 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York and 14 plaintiffs in Pennsylvania.  These matters have been transferred to the MDL.  The Company is also on notice of approximately 660 other possible individual product liability claims and 3 possible municipal claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, and, under Pennsylvania’s procedural rules, they may or may not result in lawsuits.

- removed (2019-05-03):
[0000833444-19-000005:note_history:28]
Chemguard and Tyco Fire Products are also defendants in 14 cases in federal and state courts involving municipal plaintiffs in Arizona, Florida, Massachusetts, New Jersey, New York and Ohio.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  All but two of these cases either have been transferred or identified for transfer to the MDL.   The following municipal actions were filed in fiscal year 2019:


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0000833444-19-000022:note_history:29]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2018 filed with the SEC on November 20, 2018. The results of operations for the three and six month periods ended March 31, 2019 are not necessarily indicative of results for the Company’s 2019 fiscal year because of seasonal and other factors.
  (was, 2019-02-01, similarity 0.9778):
[0000833444-19-000005:note_history:29]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2018 filed with the SEC on November 20, 2018. The results of operations for the three month period ended December 31, 2018 are not necessarily indicative of results for the Company’s 2019 fiscal year because of seasonal and other factors.

- changed (2019-05-03):
[0000833444-19-000022:note_history:30]
Under certain criteria as provided for in Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity ("VIE"). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting rights. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the
  (was, 2019-02-01, similarity 0.8188):
[0000833444-19-000005:note_history:30]
Under certain criteria as provided for in Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity ("VIE"). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting rights. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.

- added (2019-05-03):
[0000833444-19-000022:note_history:31]
VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.

- changed (2019-05-03):
[0000833444-19-000022:note_history:32]
At March 31, 2019, the Company held restricted cash of approximately $19 million, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities. At September 30, 2018, the Company held restricted cash of approximately $15 million, of which $6 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position.
  (was, 2019-02-01, similarity 0.9886):
[0000833444-19-000005:note_history:32]
At December 31, 2018, the Company held restricted cash of approximately $20 million, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities. At September 30, 2018, the Company held restricted cash of approximately $15 million, of which $6 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-05-03):
[0000833444-19-000022:note_history:33]
On May 1, 2019, the Company announced that it has commenced a cash tender offer to purchase up to $1.5 billion in aggregate principal amount of certain of its outstanding notes.

- added (2019-05-03):
[0000833444-19-000022:note_history:34]
In March 2019, a 364-day $250 million committed revolving credit facility expired.  The Company entered into a new $250 million committed revolving credit facility scheduled to expire in March 2020.  As of March 31, 2019 there were no draws on the facility.

- added (2019-05-03):
[0000833444-19-000022:note_history:35]
In February 2019, the Company repurchased, at a discount, $12 million of its 3.9% fixed rate notes, plus accrued interest, scheduled to mature in 2026.

- added (2019-05-03):
[0000833444-19-000022:note_history:36]
In February 2019, a 364-day $150 million committed revolving credit facility expired.  The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2020.  As of March 31, 2019 there were no draws on the facility.

- added (2019-05-03):
[0000833444-19-000022:note_history:37]
In February 2019, a 364-day $150 million committed revolving credit facility expired.  The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2020.  As of March 31, 2019 there were no draws on the facility.

- added (2019-05-03):
[0000833444-19-000022:note_history:38]
In January 2019, the Company entered into a $750 million term loan due the earlier of January 2020 or five business days from the closing on the sale of the Power Solutions business.  Proceeds from the term loan were used for general corporate purposes.

- added (2019-05-03):
[0000833444-19-000022:note_history:39]
In January 2019, a 364-day $200 million committed revolving credit facility expired.  The Company entered into a new $350 million committed revolving credit facility scheduled to expire in January 2020.  As of March 31, 2019 there were no draws on the facility.

- changed (2019-05-03):
[0000833444-19-000022:note_history:40]
The Company's net financing charges line item in the consolidated statements of income for the three and six months ended March 31, 2019 and 2018 contained the following components (in millions):
  (was, 2019-02-01, similarity 0.9539):
[0000833444-19-000005:note_history:40]
The Company's net financing charges line item in the consolidated statements of income for the three months ended December 31, 2018 and 2017 contained the following components (in millions):

- changed (2019-05-03):
[0000833444-19-000022:note_history:41]
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Interest expense, net of capitalized interest costs | $ | 97 |  |  | $ | 99 |  |  | $ | 188 |  |  | $ | 201 |  |
| Banking fees and bond cost amortization | 7 |  |  | 8 |  |  | 13 |  |  | 15 |  |
| Interest income | (6 | ) |  | (1 | ) |  | (13 | ) |  | (8 | ) |
| Net foreign exchange results for financing activities | — |  |  | 1 |  |  | (5 | ) |  | 1 |  |
| Net financing charges | $ | 98 |  |  | $ | 107 |  |  | $ | 183 |  |  | $ | 209 |  |
  (was, 2019-02-01, similarity 0.7803):
[0000833444-19-000005:note_history:41]
|  | Three Months EndedDecember 31, |
|  | 2018 |  | 2017 |
| Interest expense, net of capitalized interest costs | $ | 91 |  |  | $ | 102 |  |
| Banking fees and bond cost amortization | 6 |  |  | 7 |  |
| Interest income | (7 | ) |  | (7 | ) |
| Net foreign exchange results for financing activities | (5 | ) |  | — |  |
| Net financing charges | $ | 85 |  |  | $ | 102 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0000833444-19-000022:note_history:42]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $54 million and $16 million, respectively, for the three months ended March 31, 2019; and $59 million and $15 million, respectively, for the three months ended March 31, 2018. The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $97 million and $30 million, respectively, for the six months ended March 31, 2019; and $104 million and $24 million, respectively, for the six months ended March 31, 2018.
  (was, 2019-02-01, similarity 0.6327):
[0000833444-19-000005:note_history:42]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $43 million and $14 million, respectively, for the three months ended December 31, 2018; and $45 million and $9 million, respectively, for the three months ended December 31, 2017.

- changed (2019-05-03):
[0000833444-19-000022:note_history:43]
|  |  | March 31, 2019 |  | September 30, 2018 |  |
| Receivable from related parties |  | $ | 48 |  |  | $ | 36 |  |
| Payable to related parties |  | 12 |  |  | 18 |  |
  (was, 2019-02-01, similarity 0.9691):
[0000833444-19-000005:note_history:43]
|  |  | December 31, 2018 |  | September 30, 2018 |  |
| Receivable from related parties |  | $ | 41 |  |  | $ | 36 |  |
| Payable to related parties |  | 7 |  |  | 18 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0000833444-19-000022:note_history:44]
|  |  | March 31, 2019 |  | September 30, 2018 |  |
| Receivable from related parties |  | $ | 48 |  |  | $ | 36 |  |
| Payable to related parties |  | 12 |  |  | 18 |  |
  (was, 2019-02-01, similarity 0.9691):
[0000833444-19-000005:note_history:44]
|  |  | December 31, 2018 |  | September 30, 2018 |  |
| Receivable from related parties |  | $ | 41 |  |  | $ | 36 |  |
| Payable to related parties |  | 7 |  |  | 18 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0000833444-19-000022:note_history:45]
The following table presents the Company's revenues disaggregated by segment and by product versus services revenue for the three and six months ended March 31, 2019 (in millions):
  (was, 2019-02-01, similarity 0.9507):
[0000833444-19-000005:note_history:45]
The following table presents the Company's revenues disaggregated by segment and by product versus services revenue for the three months ended December 31, 2018 (in millions):

- added (2019-05-03):
[0000833444-19-000022:note_history:46]
|  |  | Three Months EndedMarch 31, 2019 |  | Six Months EndedMarch 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,387 |  |  | $ | 800 |  |  | $ | 2,187 |  |  | $ | 2,708 |  |  | $ | 1,595 |  |  | $ | 4,303 |  |
| Building Solutions EMEA/LA |  | 416 |  |  | 462 |  |  | 878 |  |  | 833 |  |  | 952 |  |  | 1,785 |  |
| Building Solutions Asia Pacific |  | 351 |  |  | 277 |  |  | 628 |  |  | 707 |  |  | 534 |  |  | 1,241 |  |
| Global Products |  | 2,086 |  |  | — |  |  | 2,086 |  |  | 3,914 |  |  | — |  |  | 3,914 |  |
| Total |  | $ | 4,240 |  |  | $ | 1,539 |  |  | $ | 5,779 |  |  | $ | 8,162 |  |  | $ | 3,081 |  |  | $ | 11,243 |  |

- changed (2019-05-03):
[0000833444-19-000022:note_history:47]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and six months ended March 31, 2019 (in millions):
  (was, 2019-02-01, similarity 0.947):
[0000833444-19-000005:note_history:47]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2018 (in millions):

- changed (2019-05-03):
[0000833444-19-000022:note_history:48]
|  |  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  |  | 2019 |  | 2019 |
| Building Management |  | $ | 320 |  |  | $ | 601 |  |
| HVAC & Refrigeration Equipment |  | 1,474 |  |  | 2,759 |  |
| Specialty |  | 292 |  |  | 554 |  |
| Total Global Products |  | $ | 2,086 |  |  | $ | 3,914 |  |
  (was, 2019-02-01, similarity 0.8118):
[0000833444-19-000005:note_history:48]
|  |  | Three Months EndedDecember 31, |
|  |  | 2018 |
| Building Management |  | $ | 281 |  |
| HVAC & Refrigeration Equipment |  | 1,285 |  |
| Specialty |  | 262 |  |
| Total Global Products |  | $ | 1,828 |  |

- removed (2019-05-03):
[0000833444-19-000005:note_history:49]
|  |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,321 |  |  | $ | 795 |  |  | $ | 2,116 |  |
| Building Solutions EMEA/LA |  | 417 |  |  | 490 |  |  | 907 |  |
| Building Solutions Asia Pacific |  | 356 |  |  | 257 |  |  | 613 |  |
| Global Products |  | 1,828 |  |  | — |  |  | 1,828 |  |
| Total |  | $ | 3,922 |  |  | $ | 1,542 |  |  | $ | 5,464 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: title_similarity, score: 1.0

- changed (2019-05-03):
[0000833444-19-000022:note_history:50]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company elected the practical expedient which permits the promised amount of consideration to not be adjusted for the effects of a significant financing component as at contract inception the Company expects to receive the payment within the twelve months of transfer of goods or services.
  (was, 2019-02-01, similarity 0.9769):
[0000833444-19-000005:note_history:50]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. Claims against customers are recognized as revenue upon settlement. The Company elected the practical expedient which permits the promised amount of consideration to not be adjusted for the effects of a significant financing component as at contract inception the Company expects to receive the payment within the twelve months of transfer of goods or services.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-03):
[0000833444-19-000022:note_history:51]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company elected the practical expedient which permits the promised amount of consideration to not be adjusted for the effects of a significant financing component as at contract inception the Company expects to receive the payment within the twelve months of transfer of goods or services.
  (was, 2019-02-01, similarity 0.9769):
[0000833444-19-000005:note_history:51]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. Claims against customers are recognized as revenue upon settlement. The Company elected the practical expedient which permits the promised amount of consideration to not be adjusted for the effects of a significant financing component as at contract inception the Company expects to receive the payment within the twelve months of transfer of goods or services.

- changed (2019-05-03):
[0000833444-19-000022:note_history:52]
The following table presents the Company's revenues disaggregated by segment and by product versus services revenue for the three and six months ended March 31, 2019 (in millions):
  (was, 2019-02-01, similarity 0.9507):
[0000833444-19-000005:note_history:52]
The following table presents the Company's revenues disaggregated by segment and by product versus services revenue for the three months ended December 31, 2018 (in millions):

- added (2019-05-03):
[0000833444-19-000022:note_history:53]
|  |  | Three Months EndedMarch 31, 2019 |  | Six Months EndedMarch 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,387 |  |  | $ | 800 |  |  | $ | 2,187 |  |  | $ | 2,708 |  |  | $ | 1,595 |  |  | $ | 4,303 |  |
| Building Solutions EMEA/LA |  | 416 |  |  | 462 |  |  | 878 |  |  | 833 |  |  | 952 |  |  | 1,785 |  |
| Building Solutions Asia Pacific |  | 351 |  |  | 277 |  |  | 628 |  |  | 707 |  |  | 534 |  |  | 1,241 |  |
| Global Products |  | 2,086 |  |  | — |  |  | 2,086 |  |  | 3,914 |  |  | — |  |  | 3,914 |  |
| Total |  | $ | 4,240 |  |  | $ | 1,539 |  |  | $ | 5,779 |  |  | $ | 8,162 |  |  | $ | 3,081 |  |  | $ | 11,243 |  |

- changed (2019-05-03):
[0000833444-19-000022:note_history:54]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and six months ended March 31, 2019 (in millions):
  (was, 2019-02-01, similarity 0.947):
[0000833444-19-000005:note_history:54]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2018 (in millions):

- changed (2019-05-03):
[0000833444-19-000022:note_history:55]
|  |  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  |  | 2019 |  | 2019 |
| Building Management |  | $ | 320 |  |  | $ | 601 |  |
| HVAC & Refrigeration Equipment |  | 1,474 |  |  | 2,759 |  |
| Specialty |  | 292 |  |  | 554 |  |
| Total Global Products |  | $ | 2,086 |  |  | $ | 3,914 |  |
  (was, 2019-02-01, similarity 0.8118):
[0000833444-19-000005:note_history:55]
|  |  | Three Months EndedDecember 31, |
|  |  | 2018 |
| Building Management |  | $ | 281 |  |
| HVAC & Refrigeration Equipment |  | 1,285 |  |
| Specialty |  | 262 |  |
| Total Global Products |  | $ | 1,828 |  |

- changed (2019-05-03):
[0000833444-19-000022:note_history:56]
The following table presents the location and amount of contract balances in the Company's consolidated statements of financial position (in millions):
  (was, 2019-02-01, similarity 0.9869):
[0000833444-19-000005:note_history:56]
The following table presents the location and amount of contract balances in the the Company's consolidated statements of financial position (in millions):

- added (2019-05-03):
[0000833444-19-000022:note_history:57]
|  |  | Location of contract balances |  | March 31, 2019 |  | October 1, 2018 |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,343 |  |  | $ | 1,261 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 85 |  |  | 85 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,521 | ) |  | (1,335 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (119 | ) |  | (113 | ) |
| Total |  |  |  | $ | (212 | ) |  | $ | (102 | ) |

- changed (2019-05-03):
[0000833444-19-000022:note_history:58]
For the three and six months ended March 31, 2019, the Company recognized revenue of $214 million and $926 million, respectively, that was included in the beginning of period contract liability balance.
  (was, 2019-02-01, similarity 0.8653):
[0000833444-19-000005:note_history:58]
For the three months ended December 31, 2018, the Company recognized revenue of $712 million that was included in the beginning of period contract liability balance.

- changed (2019-05-03):
[0000833444-19-000022:note_history:59]
Performance obligations are satisfied as of a point in time or over time. Performance obligations are supported by contracts with customers, providing a framework for the nature of the distinct goods, services, or bundle of goods and services. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of March 31, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $13.9 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company has applied the practical expedient for certain revenue streams to exclude the value of remaining performance obligations for contracts with an original expected duration of one year or less.
  (was, 2019-02-01, similarity 0.9947):
[0000833444-19-000005:note_history:59]
Performance obligations are satisfied as of a point in time or over time. Performance obligations are supported by contracts with customers, providing a framework for the nature of the distinct goods, services, or bundle of goods and services. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of December 31, 2018, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $13.7 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company has applied the practical expedient for certain revenue streams to exclude the value of remaining performance obligations for contracts with an original expected duration of one year or less.

- changed (2019-05-03):
[0000833444-19-000022:note_history:60]
As of March 31, 2019, the Company recorded the costs to obtain or fulfill a contract of $184 million, of which $98 million is recorded within other current assets and $86 million is recorded within other noncurrent assets in the consolidated statements of financial position.
  (was, 2019-02-01, similarity 0.9756):
[0000833444-19-000005:note_history:60]
As of December 31, 2018, the Company recorded the costs to obtain or fulfill a contract of $175 million, of which $91 million is recorded within other current assets and $84 million is recorded within other noncurrent assets in the consolidated statements of financial position.

- changed (2019-05-03):
[0000833444-19-000022:note_history:61]
During the three and six months ended March 31, 2019, the Company recognized amortization expense of $34 million and $69 million, respectively related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and six months ended March 31, 2019.
  (was, 2019-02-01, similarity 0.7396):
[0000833444-19-000005:note_history:61]
During the three months ended December 31, 2018, the Company recognized amortization expense of $35 million related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three months ended December 31, 2018.

- removed (2019-05-03):
[0000833444-19-000005:note_history:62]
|  |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,321 |  |  | $ | 795 |  |  | $ | 2,116 |  |
| Building Solutions EMEA/LA |  | 417 |  |  | 490 |  |  | 907 |  |
| Building Solutions Asia Pacific |  | 356 |  |  | 257 |  |  | 613 |  |
| Global Products |  | 1,828 |  |  | — |  |  | 1,828 |  |
| Total |  | $ | 3,922 |  |  | $ | 1,542 |  |  | $ | 5,464 |  |

- removed (2019-05-03):
[0000833444-19-000005:note_history:63]
|  |  | Location of contract balances |  | December 31, 2018 |  |  | October 1, 2018 |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,320 |  |  | $ | 1,261 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 73 |  |  | 85 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,378 | ) |  | (1,335 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (110 | ) |  | (113 | ) |
| Total |  |  |  | $ | (95 | ) |  | $ | (102 | ) |
