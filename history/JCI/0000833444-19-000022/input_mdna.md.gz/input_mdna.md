# JCI MD&A — 0000833444-19-000022


## mdna

[0000833444-19-000022:mdna:1]
[same as prior period, unchanged from 0000833444-19-000005:mdna:1]

[0000833444-19-000022:mdna:2]
[same as prior period, unchanged from 0000833444-19-000005:mdna:2]

[0000833444-19-000022:mdna:3]
[same as prior period, unchanged from 0000833444-19-000005:mdna:3]

[0000833444-19-000022:mdna:4]
[same as prior period, unchanged from 0000833444-19-000005:mdna:4]

[0000833444-19-000022:mdna:5]
[same as prior period, unchanged from 0000833444-19-000005:mdna:5]

[0000833444-19-000022:mdna:6]
[same as prior period, unchanged from 0000833444-19-000005:mdna:6]

[0000833444-19-000022:mdna:7]
In the fourth quarter of fiscal 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco completed their combination, with JCI Inc. merging with a wholly owned, indirect subsidiary of Tyco (the "Merger"). Following the Merger, Tyco changed its name to “Johnson Controls International plc” and JCI Inc. is a wholly-owned subsidiary of Johnson Controls International plc. The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes.

[0000833444-19-000022:mdna:8]
[same as prior period, unchanged from 0000833444-19-000005:mdna:40]

[0000833444-19-000022:mdna:9]
Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company.

[0000833444-19-000022:mdna:10]
[same as prior period, unchanged from 0000833444-19-000005:mdna:9]

[0000833444-19-000022:mdna:11]
[same as prior period, unchanged from 0000833444-19-000005:mdna:10]

[0000833444-19-000022:mdna:12]
On November 13, 2018, the Company entered into a Stock and Asset Purchase Agreement (“Purchase Agreement”) with BCP Acquisitions LLC (“Purchaser”). The Purchaser is a newly-formed entity controlled by investment funds managed by Brookfield Capital Partners LLC. Pursuant to the Purchase Agreement, on the terms and subject to the conditions therein, the Company has agreed to sell, and Purchaser has agreed to acquire, the Company’s Power Solutions business for a purchase price of $13.2 billion. The transaction closed on April 30, 2019 with net cash proceeds of $11.6 billion after tax and transaction-related expenses.

[0000833444-19-000022:mdna:13]
[same as prior period, unchanged from 0000833444-19-000005:mdna:12]

[0000833444-19-000022:mdna:14]
The following information should be read in conjunction with the September 30, 2018 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2018 filed with the SEC on November 20, 2018. References in the following discussion and analysis to "Three Months"(or similar language) refer to the three months ended March 31, 2019 compared to the three months ended March 31, 2018, while "Year-to-Date" refers to the six months ended March 31, 2019 compared to the six months ended March 31, 2018.

[0000833444-19-000022:mdna:15]
[same as prior period, unchanged from 0000833444-19-000005:mdna:14]

[0000833444-19-000022:mdna:16]
|  | Three Months EndedMarch 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Net sales | $ | 5,779 |  |  | $ | 5,630 |  |  | 3 | % |  | $ | 11,243 |  |  | $ | 10,935 |  |  | 3 | % |

[0000833444-19-000022:mdna:17]
The increase in consolidated net sales for the three months ended March 31, 2019 was due to higher organic sales ($352 million) and acquisitions ($5 million), partially offset by the unfavorable impact of foreign currency translation ($165 million) and lower sales due to business divestitures ($43 million). The increase in organic sales related to higher volumes across all segments. Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 6% as compared to the prior year. Refer to the "Segment Analysis" below within Item 2 for a discussion of net sales by segment.

[0000833444-19-000022:mdna:18]
The increase in consolidated net sales for the six months ended March 31, 2019 was due to higher organic sales ($658 million) and acquisitions ($13 million), partially offset by the unfavorable impact of foreign currency translation ($265 million) and lower sales due to business divestitures ($98 million). The increase in organic sales related to higher volumes across all segments. Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 6% as compared to the prior year. Refer to the "Segment Analysis" below within Item 2 for a discussion of net sales by segment.

[0000833444-19-000022:mdna:19]
[same as prior period, unchanged from 0000833444-19-000005:mdna:17]

[0000833444-19-000022:mdna:20]
|  | Three Months EndedMarch 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Cost of sales | $ | 3,935 |  |  | $ | 3,806 |  |  | 3 | % |  | $ | 7,674 |  |  | $ | 7,413 |  |  | 4 | % |
| Gross profit | 1,844 |  |  | 1,824 |  |  | 1 | % |  | 3,569 |  |  | 3,522 |  |  | 1 | % |
| % of sales | 31.9 | % |  | 32.4 | % |  |  |  | 31.7 | % |  | 32.2 | % |  |  |

[0000833444-19-000022:mdna:21]
Cost of sales for the three month period ended March 31, 2019 increased as compared to the three month period ended March 31, 2018, and gross profit as a percentage of sales decreased by 50 basis points. Gross profit increased due to higher volumes across all segments, partially offset by business divestitures and higher operating costs. Foreign currency translation had a favorable impact on cost of sales of approximately $111 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-19-000022:mdna:22]
Cost of sales for the six month period ended March 31, 2019 increased as compared to the six month period ended March 31, 2018, and gross profit as a percentage of sales decreased by 50 basis points. Gross profit increased due to higher volumes across all segments, partially offset by business divestitures and higher operating costs. Foreign currency translation had a favorable impact on cost of sales of approximately $177 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-19-000022:mdna:23]
[same as prior period, unchanged from 0000833444-19-000005:mdna:20]

[0000833444-19-000022:mdna:24]
|  | Three Months EndedMarch 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Selling, general and administrative expenses | $ | 1,458 |  |  | $ | 1,490 |  |  | -2 | % |  | $ | 2,896 |  |  | $ | 2,809 |  |  | 3 | % |
| % of sales | 25.2 | % |  | 26.5 | % |  |  |  | 25.8 | % |  | 25.7 | % |  |  |

[0000833444-19-000022:mdna:25]
Selling, general and administrative expenses ("SG&A") for the three month period ended March 31, 2019 decreased 2% as compared to the three month period ended March 31, 2018. The decrease in SG&A was primarily due to productivity savings and costs synergies, net of incremental investments, and a current year net mark-to-market gain on restricted asbestos investments. Foreign currency translation had a favorable impact on SG&A of $33 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-19-000022:mdna:26]
SG&A for the six month period ended March 31, 2019 increased 3% as compared to the six month period ended March 31, 2018. The increase in SG&A was primarily due to a $114 million gain on sale of the Scott Safety business in the Global Products segment in the prior year, partially offset by productivity savings and costs synergies, net of incremental investments. Foreign currency translation had a favorable impact on SG&A of $55 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-19-000022:mdna:27]
[same as prior period, unchanged from 0000833444-19-000005:mdna:23]

[0000833444-19-000022:mdna:28]
|  | Three Months EndedMarch 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Restructuring and impairment costs | $ | — |  |  | $ | — |  |  | — |  | $ | — |  |  | $ | 154 |  |  | * |

[0000833444-19-000022:mdna:29]
[same as prior period, unchanged from 0000833444-19-000005:mdna:25]

[0000833444-19-000022:mdna:30]
[same as prior period, unchanged from 0000833444-19-000005:mdna:26]

[0000833444-19-000022:mdna:31]
[same as prior period, unchanged from 0000833444-19-000005:mdna:27]

[0000833444-19-000022:mdna:32]
|  | Three Months EndedMarch 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Net financing charges | $ | 98 |  |  | $ | 107 |  |  | -8 | % |  | $ | 183 |  |  | $ | 209 |  |  | -12 | % |

[0000833444-19-000022:mdna:33]
[same as prior period, unchanged from 0000833444-19-000005:mdna:29]

[0000833444-19-000022:mdna:34]
[same as prior period, unchanged from 0000833444-19-000005:mdna:30]

[0000833444-19-000022:mdna:35]
|  | Three Months EndedMarch 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Equity income | $ | 33 |  |  | $ | 27 |  |  | 22 | % |  | $ | 75 |  |  | $ | 74 |  |  | 1 | % |

[0000833444-19-000022:mdna:36]
The increase in equity income for the three months ended March 31, 2019 was primarily due to higher income at certain partially-owned affiliates within Building Solutions EMEA/LA segment. The increase in equity income for the six months ended March 31, 2019 was primarily due to higher income at certain partially-owned affiliates within Building Solutions EMEA/LA segment, partially offset by lower income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-19-000022:mdna:37]
[same as prior period, unchanged from 0000833444-19-000005:mdna:33]

[0000833444-19-000022:mdna:38]
|  | Three Months EndedMarch 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Income tax provision | $ | 47 |  |  | $ | 36 |  |  | 31 | % |  | $ | 155 |  |  | $ | 253 |  |  | -39 | % |
| Effective tax rate | 15 | % |  | 14 | % |  |  |  | 27 | % |  | 60 | % |  |  |

[0000833444-19-000022:mdna:39]
[same as prior period, unchanged from 0000833444-19-000005:mdna:35]

[0000833444-19-000022:mdna:40]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended March 31, 2019, the Company's effective tax rate for continuing operations was 15% and was higher than the statutory tax rate of 12.5% primarily due to tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the six months ended March 31, 2019, the Company's effective tax rate for continuing operations was 27% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments as a result of tax law changes and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the three months ended March 31, 2018, the Company's effective tax rate for continuing operations was 14% and was higher than the statutory tax rate of 12.5% primarily due to tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the six months ended March 31, 2018, the Company's effective tax rate for continuing operations was 60% and was higher than the statutory tax rate of 12.5% primarily due to the discrete net impacts of U.S. Tax Reform, the tax impact of the divestiture of the Scott Safety business and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives and tax audit closures. The effective tax rate for the six months ended March 31, 2019 decreased as compared to the six months ended March 31, 2018 primarily due to the discrete tax items described below and tax planning initiatives. The global tax planning initiatives related primarily to foreign tax credit planning, global financing structures and alignment of our global business functions in a tax efficient manner.

[0000833444-19-000022:mdna:41]
[same as prior period, unchanged from 0000833444-19-000005:mdna:37]

[0000833444-19-000022:mdna:42]
[same as prior period, unchanged from 0000833444-19-000005:mdna:38]

[0000833444-19-000022:mdna:43]
In the first quarter of fiscal 2019, as a result of changes to U.S. tax law, the Company recorded a discrete tax charge of $76 million related to valuation allowances on certain U.S. deferred tax assets.

[0000833444-19-000022:mdna:44]
[same as prior period, unchanged from 0000833444-19-000005:mdna:41]

[0000833444-19-000022:mdna:45]
[same as prior period, unchanged from 0000833444-19-000005:mdna:42]

[0000833444-19-000022:mdna:46]
[same as prior period, unchanged from 0000833444-19-000005:mdna:43]

[0000833444-19-000022:mdna:47]
|  | Three Months EndedMarch 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Income from discontinued operations, net of tax | $ | 284 |  |  | $ | 265 |  |  | 7 | % |  | $ | 547 |  |  | $ | 583 |  |  | -6 | % |

[0000833444-19-000022:mdna:48]
[same as prior period, unchanged from 0000833444-19-000005:mdna:45]

[0000833444-19-000022:mdna:49]
[same as prior period, unchanged from 0000833444-19-000005:mdna:46]

[0000833444-19-000022:mdna:50]
|  | Three Months EndedMarch 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 34 |  |  | $ | 34 |  |  | — | % |  | $ | 63 |  |  | $ | 62 |  |  | 2 | % |
| Income from discontinued operations attributable to noncontrolling interests | 9 |  |  | 11 |  |  | -18 | % |  | 24 |  |  | 24 |  |  | — | % |

[0000833444-19-000022:mdna:51]
The increase in income from continuing operations attributable to noncontrolling interests for the six months ended March 31, 2019 was primarily due to higher net income at a certain partially-owned affiliate.

[0000833444-19-000022:mdna:52]
[same as prior period, unchanged from 0000833444-19-000005:mdna:49]

[0000833444-19-000022:mdna:53]
[same as prior period, unchanged from 0000833444-19-000005:mdna:50]

[0000833444-19-000022:mdna:54]
|  | Three Months EndedMarch 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Net income attributable to Johnson Controls | $ | 515 |  |  | $ | 438 |  |  | 18 | % |  | $ | 870 |  |  | $ | 668 |  |  | 30 | % |

[0000833444-19-000022:mdna:55]
The increase in net income attributable to Johnson Controls for the three months ended March 31, 2019 was primarily due to a decrease in SG&A, higher gross profit and higher income from discontinued operations. The increase in net income attributable to Johnson Controls for the six months ended March 31, 2019 was primarily due to a decrease in restructuring and impairment costs and income tax provision, and higher gross profit, partially offset by higher SG&A.

[0000833444-19-000022:mdna:56]
Diluted earnings per share attributable to Johnson Controls for the three months ended March 31, 2019 was $0.57 compared to $0.47 for the three months ended March 31, 2018. Diluted earnings per share attributable to Johnson Controls for the six months ended March 31, 2019 was $0.95 compared to $0.72 for the six months ended March 31, 2018.

[0000833444-19-000022:mdna:57]
[same as prior period, unchanged from 0000833444-19-000005:mdna:53]

[0000833444-19-000022:mdna:58]
|  | Three Months EndedMarch 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 643 |  |  | $ | 598 |  |  | 8 | % |  | $ | 872 |  |  | $ | 887 |  |  | -2 | % |

[0000833444-19-000022:mdna:59]
The increase in comprehensive income attributable to Johnson Controls for the three months ended March 31, 2019 was due to higher net income attributable to Johnson Controls ($77 million), partially offset by a decrease in other comprehensive income attributable to Johnson Controls ($32 million) resulting primarily from unfavorable foreign currency translation adjustments, partially offset by higher realized and unrealized gains on derivatives.

[0000833444-19-000022:mdna:60]
The decrease in comprehensive income attributable to Johnson Controls for the six months ended March 31, 2019 was primarily due to a decrease in other comprehensive income attributable to Johnson Controls ($217 million) resulting primarily from unfavorable foreign currency translation adjustments, partially offset by higher net income attributable to Johnson Controls ($202 million). These year-over-year unfavorable foreign currency translation adjustments were primarily driven by the strengthening of the British pound and euro currencies against the U.S. dollar in the prior year.

[0000833444-19-000022:mdna:61]
[same as prior period, unchanged from 0000833444-19-000005:mdna:56]

[0000833444-19-000022:mdna:62]
On October 1, 2018, the Company adopted Accounting Standards Update ("ASU") No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." The new standard requires the mark-to-market of marketable securities investments previously recorded within accumulated other comprehensive income on the statement of financial position be recorded in the statement of income on a prospective basis beginning as of the adoption date. As these restricted investments do not relate to the underlying operating performance of its business, the Company’s definition of segment earnings excludes the mark-to-market adjustments beginning in the first quarter of fiscal 2019.

[0000833444-19-000022:mdna:63]
[same as prior period, unchanged from 0000833444-19-000005:mdna:58]

[0000833444-19-000022:mdna:64]
[same as prior period, unchanged from 0000833444-19-000005:mdna:59]

[0000833444-19-000022:mdna:65]
|  | Three Months EndedMarch 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Building Solutions North America | $ | 2,187 |  |  | $ | 2,097 |  |  | 4 | % |  | $ | 4,303 |  |  | $ | 4,109 |  |  | 5 | % |
| Building Solutions EMEA/LA | 878 |  |  | 907 |  |  | -3 | % |  | 1,785 |  |  | 1,822 |  |  | -2 | % |
| Building Solutions Asia Pacific | 628 |  |  | 586 |  |  | 7 | % |  | 1,241 |  |  | 1,183 |  |  | 5 | % |
| Global Products | 2,086 |  |  | 2,040 |  |  | 2 | % |  | 3,914 |  |  | 3,821 |  |  | 2 | % |
|  | $ | 5,779 |  |  | $ | 5,630 |  |  | 3 | % |  | $ | 11,243 |  |  | $ | 10,935 |  |  | 3 | % |

[0000833444-19-000022:mdna:66]
Three Months:

[0000833444-19-000022:mdna:67]
| • | The increase in Building Solutions North America was due to higher volumes ($100 million), partially offset by the unfavorable impact of foreign currency translation ($10 million). The increase in volumes was primarily attributable to higher installation / service sales. |

[0000833444-19-000022:mdna:68]
| • | The decrease in Building Solutions EMEA/LA was due to the unfavorable impact of foreign currency translation ($69 million), partially offset by higher volumes ($40 million). The increase in volumes was primarily attributable to higher installation / service sales. |

[0000833444-19-000022:mdna:69]
| • | The increase in Building Solutions Asia Pacific was due to higher volumes ($68 million), partially offset by the unfavorable impact of foreign currency translation ($26 million). The increase in volumes was primarily attributable to higher installation / service sales. |

[0000833444-19-000022:mdna:70]
| • | The increase in Global Products was due to higher volumes ($144 million) and incremental sales related to business acquisitions ($5 million), partially offset by the unfavorable impact of foreign currency translation ($60 million) and lower volumes related to business divestitures ($43 million). The increase in volumes was primarily attributable to higher building management, HVAC and refrigeration equipment, and specialty products sales. |

[0000833444-19-000022:mdna:71]
Year-to-Date:

[0000833444-19-000022:mdna:72]
| • | The increase in Building Solutions North America was due to higher volumes ($212 million), partially offset by the unfavorable impact of foreign currency translation ($18 million). The increase in volumes was primarily attributable to higher installation / service sales. |

[0000833444-19-000022:mdna:73]
| • | The decrease in Building Solutions EMEA/LA was due to the unfavorable impact of foreign currency translation ($112 million), partially offset by higher volumes ($73 million) and incremental sales related to a business acquisition ($2 million). The increase in volumes was primarily attributable to higher service sales. |

[0000833444-19-000022:mdna:74]
| • | The increase in Building Solutions Asia Pacific was due to higher volumes ($102 million), partially offset by the unfavorable impact of foreign currency translation ($44 million). The increase in volumes was primarily attributable to higher installation / service sales. |

[0000833444-19-000022:mdna:75]
| • | The increase in Global Products was due to higher volumes ($271 million) and incremental sales related to business acquisitions ($11 million), partially offset by lower volumes related to business divestitures ($98 million) and the unfavorable impact of foreign currency translation ($91 million). The increase in volumes was primarily attributable to higher building management, HVAC and refrigeration equipment, and specialty products sales. |

[0000833444-19-000022:mdna:76]
53

[0000833444-19-000022:mdna:77]
[same as prior period, unchanged from 0000833444-19-000005:mdna:66]

[0000833444-19-000022:mdna:78]
|  | Three Months EndedMarch 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Building Solutions North America | $ | 257 |  |  | $ | 239 |  |  | 8 | % |  | $ | 507 |  |  | $ | 466 |  |  | 9 | % |
| Building Solutions EMEA/LA | 80 |  |  | 77 |  |  | 4 | % |  | 157 |  |  | 146 |  |  | 8 | % |
| Building Solutions Asia Pacific | 76 |  |  | 71 |  |  | 7 | % |  | 142 |  |  | 145 |  |  | -2 | % |
| Global Products | 251 |  |  | 228 |  |  | 10 | % |  | 441 |  |  | 514 |  |  | -14 | % |
|  | $ | 664 |  |  | $ | 615 |  |  | 8 | % |  | $ | 1,247 |  |  | $ | 1,271 |  |  | -2 | % |

[0000833444-19-000022:mdna:79]
Three Months:

[0000833444-19-000022:mdna:80]
| • | The increase in Building Solutions North America was due to net favorable volumes / mix ($19 million), prior year integration costs ($5 million) and lower SG&A ($5 million), partially offset by incremental sales investments ($8 million), current year integration costs ($2 million) and the unfavorable impact of foreign currency translation ($1 million). |

[0000833444-19-000022:mdna:81]
| • | The increase in Building Solutions EMEA/LA was due to lower SG&A ($7 million), favorable volumes / mix ($6 million), higher equity income ($3 million) and prior year integration costs ($1 million), partially offset by the unfavorable impact of foreign currency translation ($10 million), incremental sales investments ($3 million) and current year integration costs ($1 million). |

[0000833444-19-000022:mdna:82]
| • | The increase in Building Solutions Asia Pacific was due to higher volumes ($18 million) and lower SG&A ($3 million), partially offset by unfavorable mix / margin rates ($12 million), the unfavorable impact of foreign currency translation ($3 million) and incremental investments ($1 million). |

[0000833444-19-000022:mdna:83]
| • | The increase in Global Products was due to favorable volumes / mix ($52 million), prior year integration costs ($9 million) and higher equity income ($1 million). These items were partially offset by higher SG&A and operating expenses including product investments and a prior year insignificant gain on a business divestiture, partially offset by productivity savings ($22 million), the unfavorable impact of foreign currency translation ($7 million), lower income due to business divestitures and acquisitions ($6 million), and current year integration costs ($4 million). |

[0000833444-19-000022:mdna:84]
Year-to-Date:

[0000833444-19-000022:mdna:85]
| • | The increase in Building Solutions North America was due to net favorable volumes / mix ($48 million), prior year integration costs ($14 million) and lower SG&A ($5 million), partially offset by incremental sales investments ($19 million), current year integration costs ($5 million) and the unfavorable impact of foreign currency translation ($2 million). |

[0000833444-19-000022:mdna:86]
| • | The increase in Building Solutions EMEA/LA was due to favorable volumes / mix ($17 million), lower SG&A ($12 million), prior year integration costs ($3 million), higher equity income ($3 million) and incremental income related to a business acquisition ($1 million), partially offset by the unfavorable impact of foreign currency translation ($17 million), incremental sales investments ($7 million) and current year integration costs ($1 million). |

[0000833444-19-000022:mdna:87]
| • | The decrease in Building Solutions Asia Pacific was due to unfavorable mix / margin rates ($20 million), the unfavorable impact of foreign currency translation ($4 million), higher SG&A ($2 million) and incremental investments ($2 million), partially offset by higher volumes ($25 million). |

[0000833444-19-000022:mdna:88]
| • | The decrease in Global Products was due to a prior year gain on sale of Scott Safety ($114 million), higher SG&A and operating expenses including product investments and a prior year insignificant gain on a business divestiture, partially offset by productivity savings ($43 million), the unfavorable impact of foreign currency translation ($10 million), lower income due to business divestitures and acquisitions ($12 million), current year integration costs ($8 million) and lower equity income ($4 million). These items were partially offset by favorable volumes / mix ($103 million) and prior year integration costs ($15 million). |

[0000833444-19-000022:mdna:89]
[same as prior period, unchanged from 0000833444-19-000005:mdna:72]

[0000833444-19-000022:mdna:90]
The Company’s backlog relating to the Building Technologies & Solutions business is applicable to its sales of systems and services. At March 31, 2019, the backlog was $9.1 billion, of which $8.8 billion is attributable to the field business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-19-000022:mdna:91]
In the first quarter of fiscal 2019, the Company adopted ASC 606, “Revenue from Contracts with Customers,” and as a result is required to disclose remaining performance obligations. At March 31, 2019, remaining performance obligations were $13.9 billion, which is $4.8 billion higher than the Company's backlog of $9.1 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-19-000022:mdna:92]
[same as prior period, unchanged from 0000833444-19-000005:mdna:75]

[0000833444-19-000022:mdna:93]
[same as prior period, unchanged from 0000833444-19-000005:mdna:76]

[0000833444-19-000022:mdna:94]
[same as prior period, unchanged from 0000833444-19-000005:mdna:77]

[0000833444-19-000022:mdna:95]
[same as prior period, unchanged from 0000833444-19-000005:mdna:78]

[0000833444-19-000022:mdna:96]
[same as prior period, unchanged from 0000833444-19-000005:mdna:79]

[0000833444-19-000022:mdna:97]
[same as prior period, unchanged from 0000833444-19-000005:mdna:80]

[0000833444-19-000022:mdna:98]
|  | March 31, |  | September 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Current assets | $ | 12,836 |  |  | $ | 11,823 |  |  |  |
| Current liabilities | (13,441 | ) |  | (11,250 | ) |  |  |
|  | (605 | ) |  | 573 |  |  | * |  |
| Less: Cash | (239 | ) |  | (185 | ) |  |  |
| Add: Short-term debt | 2,862 |  |  | 1,306 |  |  |  |
| Add: Current portion of long-term debt | 1,106 |  |  | 1 |  |  |  |
| Less: Assets held for sale | (2,999 | ) |  | (3,015 | ) |  |  |
| Add: Liabilities held for sale | 1,558 |  |  | 1,791 |  |  |  |
| Working capital (as defined) | $ | 1,683 |  |  | $ | 471 |  |  | * |  |
| Accounts receivable - net | $ | 5,707 |  |  | $ | 5,622 |  |  | 2 | % |
| Inventories | 2,124 |  |  | 1,819 |  |  | 17 | % |
| Accounts payable | 3,482 |  |  | 3,407 |  |  | 2 | % |
| * Measure not meaningful |  |  |  |  |  |

[0000833444-19-000022:mdna:99]
[same as prior period, unchanged from 0000833444-19-000005:mdna:82]

[0000833444-19-000022:mdna:100]
55

[0000833444-19-000022:mdna:101]
| • | The increase in working capital at March 31, 2019 as compared to September 30, 2018, was primarily due to an increase in income tax receivables, an increase in inventory to meet anticipated customer demand and timing of employee benefit payments. |

[0000833444-19-000022:mdna:102]
| • | The Company’s days sales in accounts receivable at March 31, 2019 were 71 days, higher than 68 days at September 30, 2018. There has been no significant adverse changes in the level of overdue receivables or significant changes in revenue recognition methods. |

[0000833444-19-000022:mdna:103]
| • | The Company’s inventory turns for the three months ended March 31, 2019 were lower than the comparable period ended September 30, 2018, primarily due to changes in inventory production levels. |

[0000833444-19-000022:mdna:104]
| • | Days in accounts payable at March 31, 2019 were 75 days, higher than 72 days at the comparable period ended September 30, 2018. |

[0000833444-19-000022:mdna:105]
[same as prior period, unchanged from 0000833444-19-000005:mdna:88]

[0000833444-19-000022:mdna:106]
|  |  | Six Months Ended March 31, |
| (in millions) |  | 2019 |  | 2018 |
| Cash provided by operating activities |  | $ | 103 |  |  | $ | 140 |  |
| Cash provided (used) by investing activities |  | (259 | ) |  | 1,811 |  |
| Cash used by financing activities |  | (39 | ) |  | (2,263 | ) |
| Capital expenditures |  | (278 | ) |  | (280 | ) |

[0000833444-19-000022:mdna:107]
| • | The decrease in cash provided by operating activities for the six months ended March 31, 2019 was primarily due to income tax refunds in the prior year and unfavorable changes in inventory and accounts receivable, partially offset by favorable movements in other assets and lower restructuring payments. |

[0000833444-19-000022:mdna:108]
| • | The increase in cash used by investing activities for the six months ended March 31, 2019 was primarily due to net cash proceeds received from the Scott Safety business divestiture in the prior year. |

[0000833444-19-000022:mdna:109]
| • | The decrease in cash used by financing activities for the six months ended March 31, 2019 was primarily due to current year short-term borrowings and prior year net repayments of long-term debt, partially offset by higher stock repurchases in the current year. |

[0000833444-19-000022:mdna:110]
[same as prior period, unchanged from 0000833444-19-000005:mdna:94]

[0000833444-19-000022:mdna:111]
|  | March 31, |  | September 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Short-term debt | $ | 2,862 |  |  | $ | 1,306 |  |  |  |
| Current portion of long-term debt | 1,106 |  |  | 1 |  |  |  |
| Long-term debt | 8,418 |  |  | 9,623 |  |  |  |
| Total debt | 12,386 |  |  | 10,930 |  |  | 13 | % |
| Less: cash and cash equivalents | 239 |  |  | 185 |  |  |  |
| Total net debt | 12,147 |  |  | 10,745 |  |  | 13 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 20,036 |  |  | 21,164 |  |  | -5 | % |
| Total capitalization | $ | 32,183 |  |  | $ | 31,909 |  |  | 1 | % |
| Total net debt as a % of total capitalization | 37.7 | % |  | 33.7 | % |  |  |

[0000833444-19-000022:mdna:112]
[same as prior period, unchanged from 0000833444-19-000005:mdna:96]

[0000833444-19-000022:mdna:113]
| • | The Company believes its capital resources and liquidity position at March 31, 2019 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in the remainder of fiscal 2019 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company and Tyco International Holding S.à.r.l ("TSarl") are unable to issue commercial paper, they would have the ability to draw on their $2.0 billion and $1.25 billion revolving credit facilities, respectively. Both facilities mature in August 2020. There were no draws on the revolving credit facilities as of March 31, 2019 and September 30, 2018. The Company also selectively makes use of short-term credit lines other than its revolving credit facilities at the Company and TSarl. The Company estimates that, as of March 31, 2019, it could borrow up to $1.7 billion based on average borrowing levels during the quarter on committed credit lines. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future. |

[0000833444-19-000022:mdna:114]
| • | On May 1, 2019, the Company announced that it plans to launch a "modified Dutch auction" tender offer for up to $4.0 billion of its ordinary shares with a price range between $36.00 and $40.00 per share. The Company also announced that it has commenced a cash tender offer to purchase up to $1.5 billion in aggregate principal amount of certain of its outstanding notes. |

[0000833444-19-000022:mdna:115]
| • | The Company’s debt financial covenant in its revolving credit facility require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. TSarl's revolving credit facility contains customary terms and conditions, and a financial covenant that limits the ratio of TSarl's debt to earnings before interest, taxes, depreciation, and amortization as adjusted for certain items set forth in the agreement to 3.5x. TSarl's revolving credit facility also limits its ability to incur subsidiary debt or grant liens on its and its subsidiaries' property. As of March 31, 2019, the Company and TSarl were in compliance with all covenants and other requirements set forth in their credit agreements and the indentures, governing their notes, and expect to remain in compliance for the foreseeable future. None of the Company’s or TSarl's debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the respective borrower's credit rating. |

[0000833444-19-000022:mdna:116]
| • | The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2019, the Company believes the long-term rate of return will approximate 7.10%, 5.20% and 5.65% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first six months of fiscal 2019, the Company made approximately $37 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $120 million in cash to its defined benefit pension plans in fiscal 2019. The Company expects to contribute $15 million in cash to its postretirement plans in fiscal 2019. |

[0000833444-19-000022:mdna:117]
| • | The Company earns a significant amount of its operating income outside of the parent company. Outside basis differences in consolidated subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in fiscal 2019, the Company provided income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain subsidiaries as a result of the planned divestiture of the Power Solutions business. Also, in fiscal 2018, due to U.S. Tax Reform, the Company provided income tax related to the change in the Company’s assertion over the outside basis difference of certain non-U.S. subsidiaries owned directly or indirectly by U.S. subsidiaries. Under U.S. Tax Reform, the U.S. has adopted a territorial tax system that provides an exemption for dividends received by U.S. corporations from 10% or more owned non-U.S. corporations. However, certain non-U.S, U.S. state and withholding taxes may still apply when closing an outside basis difference via distribution or other transactions. The Company currently does not intend nor foresee a need to repatriate undistributed earnings or reduce outside basis differences other than as noted above or in tax efficient manners. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated |

[0000833444-19-000022:mdna:118]
57

[0000833444-19-000022:mdna:119]
by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in a tax efficient manner, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-19-000022:mdna:120]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2018 and recorded $255 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2018 restructuring plan will reduce annual operating costs for continuing operations by approximately $300 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in 2020. For fiscal 2019, the savings, net of execution costs, are expected to be approximately 70% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in 2020. The restructuring plan reserve balance of $124 million at March 31, 2019 is expected to be paid in cash. |

[0000833444-19-000022:mdna:121]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2017 and recorded $347 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs for continuing operations by approximately $260 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2019. The restructuring action is expected to be substantially complete in fiscal 2019. The restructuring plan reserve balance of $71 million at March 31, 2019 is expected to be paid in cash. |

[0000833444-19-000022:mdna:122]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2016 and recorded $222 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2016 restructuring plan will reduce annual operating costs for continuing operations by approximately $127 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2019. The restructuring action is expected to be substantially complete in fiscal 2019. The restructuring plan reserve balance of $64 million at March 31, 2019 is expected to be paid in cash. |

[0000833444-19-000022:mdna:123]
[same as prior period, unchanged from 0000833444-19-000005:mdna:107]

[0000833444-19-000022:mdna:124]
[same as prior period, unchanged from 0000833444-19-000005:mdna:108]
