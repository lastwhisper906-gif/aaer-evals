# JCI 8-K — 0000833444-14-000121 filed 2014-11-13

## item codes, every 8-K on or before 2014-11-14

- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2014-11-14

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-14-000121:8k_2_02:1]
EX-99.1
2
exhibit991-q414.htm
EXHIBIT 99.1

[0000833444-14-000121:8k_2_02:2]
Exhibit 99.1 - Q414

[0000833444-14-000121:8k_2_02:3]
Exhibit 99.1

[0000833444-14-000121:8k_2_02:4]
| Investor Contacts: |  | Media Contact: |  |
| Antonella Franzen |  | Stephen Wasdick |  |
| +1-609-720-4665 |  | +1-609-806-2262 |  |
| afranzen@tyco.com |  | swasdick@tyco.com |  |
| Leila Peters |  |  |  |
| +1-609-720-4545 |  |  |  |
| lpeters@tyco.com |  |  |  |

[0000833444-14-000121:8k_2_02:5]
FOR IMMEDIATE RELEASE

[0000833444-14-000121:8k_2_02:6]
TYCO REPORTS FOURTH QUARTER 2014 EARNINGS FROM CONTINUING OPERATIONS BEFORE SPECIAL ITEMS OF $0.56 PER SHARE AND GAAP LOSS OF $0.17 PER SHARE

[0000833444-14-000121:8k_2_02:7]
| • | Revenue in the quarter of $2.7 billion increases 4%, with 3% organic growth, led by the Global Products segment, which had organic growth of 8% |

[0000833444-14-000121:8k_2_02:8]
| • | Full year revenue of $10.3 billion increases 3% on a nominal and organic basis |

[0000833444-14-000121:8k_2_02:9]
| • | Before special items, segment operating margin improves 20 basis points for the quarter and increases 90 basis points for the year to 13.9% |

[0000833444-14-000121:8k_2_02:10]
| • | Diluted EPS from continuing operations before special items increases 19% for the quarter and 20% for the year |

[0000833444-14-000121:8k_2_02:11]
| • | The company repurchased 23 million shares for $1.0 billion during the quarter, bringing the full-year total to 42 million shares repurchased for $1.8 billion |

[0000833444-14-000121:8k_2_02:12]
| • | As previously announced, the Board of Directors approved an additional $1.0 billion authorization for share repurchases |

[0000833444-14-000121:8k_2_02:13]
(Income and EPS amounts are attributable to Tyco common shareholders)

[0000833444-14-000121:8k_2_02:14]
($ millions, except per-share amounts)

[0000833444-14-000121:8k_2_02:15]
(All prior periods have been recast to reflect certain businesses as discontinued operations)

[0000833444-14-000121:8k_2_02:16]
|  | Q4 2014 |  | Q4 2013 |  | % Change |  | FY14 |  | FY13 |  | % Change |
| Revenue | $ | 2,704 |  |  | $ | 2,610 |  |  | 4 | % |  | $ | 10,340 |  |  | $ | 10,073 |  |  | 3 | % |
| Segment Operating Income | $ | 347 |  |  | $ | 315 |  |  | 10 | % |  | $ | 1,317 |  |  | $ | 1,028 |  |  | 28 | % |
| Operating (Loss) Income | $ | (200 | ) |  | $ | 235 |  |  |  |  | $ | 697 |  |  | $ | 709 |  |  |  |
| (Loss) Income from Continuing Operations | $ | (76 | ) |  | $ | 135 |  |  |  |  | $ | 794 |  |  | $ | 443 |  |  |  |
| Diluted EPS from Continuing Operations | $ | (0.17 | ) |  | $ | 0.29 |  |  |  |  | $ | 1.71 |  |  | $ | 0.94 |  |  |  |
| Special Items | $ | (0.73 | ) |  | $ | (0.18 | ) |  |  |  | $ | (0.28 | ) |  | $ | (0.72 | ) |  |  |
| Segment Operating Income Before Special Items | $ | 383 |  |  | $ | 365 |  |  | 5 | % |  | $ | 1,435 |  |  | $ | 1,308 |  |  | 10 | % |
| Income from Continuing Ops Before Special Items | $ | 252 |  |  | $ | 218 |  |  | 16 | % |  | $ | 922 |  |  | $ | 785 |  |  | 17 | % |
| Diluted EPS from Continuing Ops Before Special Items | $ | 0.56 |  |  | $ | 0.47 |  |  | 19 | % |  | $ | 1.99 |  |  | $ | 1.66 |  |  | 20 | % |

[0000833444-14-000121:8k_2_02:17]
NEUHAUSEN, Switzerland, Nov. 13, 2014 - Tyco (NYSE: TYC) today reported GAAP diluted loss per share from continuing operations for the fiscal fourth quarter of 2014 of $0.17 and diluted earnings per share (EPS) from continuing operations before special items of $0.56. Revenue in the quarter increased 4% versus the prior year to $2.7 billion. Organic revenue grew 3% in the quarter, with growth across all segments, led by Global Products with an 8% increase from the prior year quarter. Acquisitions contributed 1 percentage point of growth, which was partially offset by the impact of divestitures.

[0000833444-14-000121:8k_2_02:18]
For the full year, the company reported GAAP diluted EPS from continuing operations of $1.71 and diluted EPS from continuing operations before special items of $1.99. Revenue of $10.3 billion increased 3%. Organic revenue growth for the year was 3% led by Global Products with 6% organic growth. Acquisitions contributed 2 percentage points of growth, which was offset by divestitures and changes in foreign currency exchange rates.

[0000833444-14-000121:8k_2_02:19]
“This was another solid quarter and a strong finish to our second year as the new Tyco,” said Tyco Chief Executive Officer George Oliver. “Our organic growth in the quarter was led by our strong technology position in our Global Products businesses, where we grew 8%. This, coupled with our continued productivity initiatives and capital allocation, drove a 19% increase in earnings per share for the quarter.

[0000833444-14-000121:8k_2_02:20]
“Overall, I am very pleased with our performance this past year -- we delivered strong results, have taken strategic action with our portfolio management with focused acquisitions and divestitures, and have returned excess cash to shareholders, all of which resulted in a 20% increase in earnings per share for the year,” Mr. Oliver added.

[0000833444-14-000121:8k_2_02:21]
As previously disclosed, the company recorded charges totaling $465 million in the quarter ended Sept. 26, 2014, related to legacy asbestos liabilities, including $225 million related to an agreement in principle to settle Yarway claims and $240 million in respect of non-Yarway liabilities.

[0000833444-14-000121:8k_2_02:22]
Organic revenue, free cash flow, operating income, segment operating income, and diluted EPS from continuing operations before special items are non-GAAP financial measures and are described below. For a reconciliation of these non-GAAP measures, see the attached tables. Additional schedules as well as fourth quarter review slides can be found in the Investor Relations section of Tyco’s website at http://investors.tyco.com.

[0000833444-14-000121:8k_2_02:23]
SEGMENT RESULTS

[0000833444-14-000121:8k_2_02:24]
The financial results presented in the tables below are in accordance with GAAP unless otherwise indicated. All dollar amounts are pre-tax and stated in millions. As previously disclosed, during the fiscal third quarter the company decided to sell certain businesses previously reported within its Rest of World Installation & Services operating segment. Additionally, in the fiscal third quarter, the company completed the sale of its South Korean security business, ADT Korea.  The results of these businesses have been classified as discontinued operations for the current and historical periods. The revenue and operating income results shown below have been adjusted to reflect these changes in all periods presented. All comparisons are to the fiscal fourth quarter or full year of 2013 unless otherwise indicated.

[0000833444-14-000121:8k_2_02:25]
North America Installation & Services

[0000833444-14-000121:8k_2_02:26]
|  | Q4 2014 |  | Q4 2013 |  | % Change |  | FY 14 |  | FY 13 |  | % Change |
| Revenue | $ | 1,012 |  |  | $ | 996 |  |  | 2 | % |  | $ | 3,876 |  |  | $ | 3,891 |  |  | - |  |
| Operating Income | $ | 117 |  |  | $ | 113 |  |  | 4 | % |  | $ | 450 |  |  | $ | 388 |  |  | 16 | % |
| Operating Margin | 11.6 | % |  | 11.3 | % |  |  |  | 11.6 | % |  | 10.0 | % |  |  |
| Special Items | $ | (17 | ) |  | $ | (20 | ) |  |  |  | $ | (64 | ) |  | $ | (86 | ) |  |  |
| Operating Income Before Special Items | $ | 134 |  |  | $ | 133 |  |  | 1 | % |  | $ | 514 |  |  | $ | 474 |  |  | 8 | % |
| Operating Margin Before Special Items | 13.2 | % |  | 13.4 | % |  |  |  | 13.3 | % |  | 12.2 | % |  |  |

[0000833444-14-000121:8k_2_02:27]
Revenue of $1.0 billion for the quarter increased 2% over the prior year.  Installation revenue growth of 6% was partially offset by a 2% decline in service, for total organic revenue growth of 2%. Backlog of $2.5 billion increased 3% year over year and increased 1% on a quarter sequential basis, excluding the impact of foreign currency.

[0000833444-14-000121:8k_2_02:28]
Operating income for the quarter was $117 million and the operating margin was 11.6%. Special items of $17 million consisted primarily of separation and restructuring charges. Before special items, operating income was $134 million and the operating margin was 13.2%. Improved execution and the benefit of restructuring and productivity initiatives were more than offset by a $10 million charge related to a legal matter that arose in 2007, which negatively impacted the operating margin by 100 basis points.

[0000833444-14-000121:8k_2_02:29]
Revenue for the full year of $3.9 billion was relatively consistent with the prior year. Organic growth of 1% and the benefit of acquisitions were offset by the impact of divestitures and changes in foreign currency exchange rates.  Operating income was $450 million and included $64 million of special items. Before special items, operating income was $514 million and the operating margin increased 110 basis points to 13.3%.

[0000833444-14-000121:8k_2_02:30]
Rest of World Installation & Services

[0000833444-14-000121:8k_2_02:31]
|  | Q4 2014 |  | Q4 2013 |  | % Change |  | FY 14 |  | FY 13 |  | % Change |
| Revenue | $ | 1,011 |  |  | $ | 987 |  |  | 2 | % |  | $ | 3,920 |  |  | $ | 3,843 |  |  | 2 | % |
| Operating Income | $ | 101 |  |  | $ | 83 |  |  | 22 | % |  | $ | 409 |  |  | $ | 333 |  |  | 23 | % |
| Operating Margin | 10.0 | % |  | 8.4 | % |  |  |  | 10.4 | % |  | 8.7 | % |  |  |
| Special Items | $ | (17 | ) |  | $ | (27 | ) |  |  |  | $ | (42 | ) |  | $ | (80 | ) |  |  |
| Operating Income Before Special Items | $ | 118 |  |  | $ | 110 |  |  | 7 | % |  | $ | 451 |  |  | $ | 413 |  |  | 9 | % |
| Operating Margin Before Special Items | 11.7 | % |  | 11.1 | % |  |  |  | 11.5 | % |  | 10.7 | % |  |  |

[0000833444-14-000121:8k_2_02:32]
Revenue of $1.0 billion for the quarter increased 2% compared to the prior year.  Organic revenue growth of 2% consisted of 6% growth in installation, partially offset by a 2% decline in service revenue.  Acquisitions contributed 2% to revenue growth, which was offset by the impact of divestitures.  Backlog of $2.2 billion increased 6% year over year and, due to normal seasonality, declined 3% on a quarter sequential basis, excluding the impact of foreign currency.

[0000833444-14-000121:8k_2_02:33]
Operating income for the quarter was $101 million and the operating margin was 10.0%. Special items of $17 million consisted primarily of restructuring charges. Before special items, operating income was $118 million, and the operating margin improved 60 basis points to 11.7%.

[0000833444-14-000121:8k_2_02:34]
Revenue for the full year was $3.9 billion, increasing 2% year over year with organic revenue growth of 2%. Acquisitions contributed 3 percentage points of growth, which was offset by the impact of divestitures and changes in foreign currency exchange rates. Operating income was $409 million and included $42 million of special items. Before special items, operating income was $451 million and the operating margin expanded 80 basis points to 11.5%.

[0000833444-14-000121:8k_2_02:35]
Global Products

[0000833444-14-000121:8k_2_02:36]
|  | Q4 2014 |  | Q4 2013 |  | % Change |  | FY 14 |  | FY 13 |  | % Change |
| Revenue | $ | 681 |  |  | $ | 627 |  |  | 9 | % |  | $ | 2,544 |  |  | $ | 2,339 |  |  | 9 | % |
| Operating Income | $ | 129 |  |  | $ | 119 |  |  | 8 | % |  | $ | 458 |  |  | $ | 307 |  |  | 49 | % |
| Operating Margin | 18.9 | % |  | 19.0 | % |  |  |  | 18.0 | % |  | 13.1 | % |  |  |
| Special Items | $ | (2 | ) |  | $ | (3 | ) |  |  |  | $ | (12 | ) |  | $ | (114 | ) |  |  |
| Operating Income Before Special Items | $ | 131 |  |  | $ | 122 |  |  | 7 | % |  | $ | 470 |  |  | $ | 421 |  |  | 12 | % |
| Operating Margin Before Special Items | 19.2 | % |  | 19.5 | % |  |  |  | 18.5 | % |  | 18.0 | % |  |  |

[0000833444-14-000121:8k_2_02:37]
Revenue of $681 million for the quarter increased 9%, including a 1% benefit from acquisitions. Organic revenue grew 8%, with growth across all three product platforms.

[0000833444-14-000121:8k_2_02:38]
Operating income for the quarter was $129 million and the operating margin was 18.9%. Special items totaled $2 million. Before special items, operating income was $131 million and the operating margin was 19.2%. Operating leverage on increased revenue and the benefit of productivity initiatives were more than offset by the timing of incremental R&D investments as well as non-cash purchase accounting.  Together, these items impacted the operating margin by 220 basis points.

[0000833444-14-000121:8k_2_02:39]
Revenue for the full year of $2.5 billion increased 9% year over year, with organic revenue growth of 6%. Acquisitions contributed 3 percentage points to growth. Operating income was $458 million and included $12 million of special items. Before special items, operating income was $470 million and the operating margin expanded 50 basis points to 18.5%.

[0000833444-14-000121:8k_2_02:40]
OTHER ITEMS

[0000833444-14-000121:8k_2_02:41]
| • | For the full year, cash from operating activities was $831 million and free cash flow was $528 million, which included a cash outflow of $473 million, primarily related to payments under the company's tax sharing agreements, as well as restructuring and separation activities. Adjusted free cash flow for the year was $1.0 billion. |

[0000833444-14-000121:8k_2_02:42]
| • | Corporate expense was $63 million for the quarter and $230 million for the year, both before special items. On a GAAP basis, corporate expense was $547 million for the quarter and $620 million for the year, both of which included a charge of $465 million related to asbestos liabilities. |

[0000833444-14-000121:8k_2_02:43]
| • | The tax rate before special items was 17.5% for the quarter and 17.2% for the year. |

[0000833444-14-000121:8k_2_02:44]
| • | The company repurchased 23 million shares for $1.0 billion during the quarter, bringing the full-year total to 42 million shares repurchased for $1.8 billion. Since the close of the fiscal fourth quarter, the company repurchased 10 million shares for $417 million. The company now has $1.0 billion remaining on its share repurchase authorization. |

[0000833444-14-000121:8k_2_02:45]
| • | Subsequent to the quarter's close, the company completed the previously announced acquisition of a security business in Brazil. |

[0000833444-14-000121:8k_2_02:46]
| • | The company expects to complete the change in its jurisdiction of incorporation to Ireland, which was approved by shareholders on September 9, 2014, in November 2014. |

[0000833444-14-000121:8k_2_02:47]
| • | The company will host an investor meeting on November 21, 2014, in New York to discuss its growth strategy and long-term outlook through fiscal year 2018. Investors and the general public are invited to attend the event by registering at http://www.tycid2014.com/ or to view a webcast of the meeting in listen-only mode through Tyco’s website at http://investors.tyco.com. A replay of the webcast and the supporting presentation materials will be available at the same website. |

[0000833444-14-000121:8k_2_02:48]
ABOUT TYCO

[0000833444-14-000121:8k_2_02:49]
Tyco (NYSE: TYC) is the world’s largest pure-play fire protection and security company. Tyco provides more than three million customers around the globe with the latest fire protection and security products and services. A company with $10+ billion in annual revenue, Tyco has over 57,000 employees in more than 900 locations across 50 countries serving various end markets, including commercial, institutional, governmental, retail, industrial, energy, residential and small business. For more information, visit www.tyco.com.

[0000833444-14-000121:8k_2_02:50]
CONFERENCE CALL AND WEBCAST

[0000833444-14-000121:8k_2_02:51]
Management will discuss the company’s fourth quarter results for 2014 during a conference call and webcast for investors today beginning at 8:00 a.m. Eastern time (ET), which can be accessed in the following ways:

[0000833444-14-000121:8k_2_02:52]
| • | Live via webcast - through the Investor Relations section of Tyco’s website at http://investors.tyco.com, |

[0000833444-14-000121:8k_2_02:53]
| • | Live via telephone (for “listen-only” participants and those who would like to ask a question) - by dialing 800-857-9797 (in the United States) or 517-308-9262 (outside the United States), passcode “Tyco”, |

[0000833444-14-000121:8k_2_02:54]
| • | Replay via telephone - by dialing 866-499-4547 (in the United States) or 203-369-1805 (outside the United States), passcode 7522, from 10:00 a.m. (ET) on November 13, 2014, until 11:59 p.m. (ET) on November 20, 2014, and |

[0000833444-14-000121:8k_2_02:55]
| • | Replay via webcast - through the “Presentations & Webcasts” link on the Investor Relations section of Tyco’s website: http://investors.tyco.com. |

[0000833444-14-000121:8k_2_02:56]
NON-GAAP MEASURES

[0000833444-14-000121:8k_2_02:57]
Organic revenue, free cash flow (outflow) (FCF), and income from continuing operations, earnings per share (EPS) from continuing operations, operating income and segment operating income, in each case “before special items,” are non-GAAP measures and should not be considered replacements for GAAP results.

[0000833444-14-000121:8k_2_02:58]
Organic revenue is a useful measure used by the company to measure the underlying results and trends in the business. The difference between reported net revenue (the most comparable GAAP measure) and organic revenue (the non-GAAP measure) consists of the impact from foreign currency, acquisitions and divestitures, and other changes that either do not reflect the underlying results and trends of the Company’s businesses or are not completely under management’s control. There are limitations associated with organic revenue, such as the fact that, as presented herein, the metric may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using organic revenue in combination with the GAAP numbers. Organic revenue may be used as a component in the company’s incentive compensation plans.

[0000833444-14-000121:8k_2_02:59]
FCF is a useful measure of the company's cash that permits management and investors to gain insight into the number that management employs to measure cash that is free from any significant existing obligation and is available to service debt and make investments. The difference between Cash Flows from Operating Activities (the most comparable GAAP measure) and FCF (the non-GAAP measure) consists mainly of significant cash flows that the company believes are useful to identify. It, or a measure that is based on it, may be used as a component in the company's incentive compensation plans. The difference reflects the impact from:

[0000833444-14-000121:8k_2_02:60]
| • | net capital expenditures, |

[0000833444-14-000121:8k_2_02:61]
| • | dealer generated accounts and bulk accounts purchased, |

[0000833444-14-000121:8k_2_02:62]
| • | cash paid for purchase accounting and holdback liabilities, and |

[0000833444-14-000121:8k_2_02:63]
| • | voluntary pension contributions. |

[0000833444-14-000121:8k_2_02:64]
Capital expenditures and dealer generated and bulk accounts purchased are subtracted because they represent long-term investments that are required for normal business activities. Cash paid for purchase accounting and holdback liabilities is subtracted because these cash outflows are not available for general corporate uses. Voluntary pension contributions are added because this activity is driven by economic financing decisions rather than operating activity. In addition, the company presents adjusted free cash flow, which is free cash flow, adjusted to exclude the cash impact of the special items highlighted below. This number provides information to investors regarding the cash impact of certain items management believes are useful to identify, as described below.

[0000833444-14-000121:8k_2_02:65]
The limitation associated with using these cash flow metrics is that they adjust for cash items that are ultimately within management's and the Board of Directors' discretion to direct and therefore may imply that there is less or more cash that is available for the company's programs than the most comparable GAAP measure. Furthermore, these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using FCF in combination with the GAAP cash flow numbers.

[0000833444-14-000121:8k_2_02:66]
The company has presented its income and EPS from continuing operations, operating income and segment operating income before special items. Special items include charges and gains related to divestitures, acquisitions, restructurings, impairments, certain changes to accounting methodologies, legacy legal and tax charges and other income or charges that may mask the underlying operating results and/or business trends of the company or business segment, as applicable. The company utilizes these measures to assess overall operating performance and segment level core operating performance, as well as to provide insight to management in evaluating overall and segment operating plan execution and underlying market conditions. The Company also presents its effective tax rate as adjusted for special items for consistency, and presents corporate expense excluding special items. One or more of these measures may be used as components in the company's incentive compensation plans. These measures are useful for investors because they may permit more meaningful comparisons of the company's underlying operating results and business trends between periods. The difference between income and EPS from continuing operations before special items and income and EPS from continuing operations (the most comparable GAAP measures) consists of the impact of the special items noted above on the applicable GAAP measure. The limitation of these measures is that they exclude the impact (which may be material) of items that increase or decrease the company's reported GAAP metrics, and these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using the non-GAAP measures in combination with the most comparable GAAP measures in order to better understand the amounts, character and impact of any increase or decrease on reported results.

[0000833444-14-000121:8k_2_02:67]
The company provides general corporate services to its segments and those costs are reported in the "Corporate and Other" segment. This segment's operating income (loss) is presented as "Corporate Expense." Segment Operating Income represents Tyco’s operating income excluding the Corporate and

[0000833444-14-000121:8k_2_02:68]
Other segment, and reflects the results of Tyco’s three operating segments. Segment Operating Income before special items reflects GAAP operating income adjusted for the special items noted in the paragraph above.

[0000833444-14-000121:8k_2_02:69]
FORWARD-LOOKING STATEMENTS

[0000833444-14-000121:8k_2_02:70]
# # #

[0000833444-14-000121:8k_2_02:71]
TYCO INTERNATIONAL LTD.

[0000833444-14-000121:8k_2_02:72]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0000833444-14-000121:8k_2_02:73]
(in millions, except per share data)

[0000833444-14-000121:8k_2_02:74]
(Unaudited)

[0000833444-14-000121:8k_2_02:75]
|  |  | Quarters Ended |  | Twelve Months Ended |
|  |  | September 26, 2014 |  | September 27, 2013 |  | September 26, 2014 |  | September 27, 2013 |
| Revenue from product sales |  | $ | 1,668 |  |  | $ | 1,536 |  |  | $ | 6,221 |  |  | $ | 5,855 |  |
| Service revenue |  | 1,036 |  |  | 1,074 |  |  | 4,119 |  |  | 4,218 |  |
| Net revenue |  | 2,704 |  |  | 2,610 |  |  | 10,340 |  |  | 10,073 |  |
| Cost of product sales |  | 1,145 |  |  | 1,034 |  |  | 4,253 |  |  | 3,990 |  |
| Cost of services |  | 577 |  |  | 599 |  |  | 2,302 |  |  | 2,412 |  |
| Selling, general and administrative expenses |  | 1,162 |  |  | 714 |  |  | 3,040 |  |  | 2,843 |  |
| Separation costs |  | — |  |  | (1 | ) |  | 1 |  |  | 8 |  |
| Restructuring and asset impairment charges, net |  | 20 |  |  | 29 |  |  | 47 |  |  | 111 |  |
| Operating (loss) income |  | (200 | ) |  | 235 |  |  | 697 |  |  | 709 |  |
| Interest income |  | 4 |  |  | 3 |  |  | 14 |  |  | 16 |  |
| Interest expense |  | (24 | ) |  | (25 | ) |  | (97 | ) |  | (100 | ) |
| Other expense, net |  | 1 |  |  | 1 |  |  | (1 | ) |  | (29 | ) |
| (Loss) income from continuing operations before income taxes |  | (219 | ) |  | 214 |  |  | 613 |  |  | 596 |  |
| Income tax benefit (expense) |  | 140 |  |  | (52 | ) |  | (24 | ) |  | (108 | ) |
| Equity (loss) income in earnings of unconsolidated subsidiaries |  | — |  |  | (30 | ) |  | 206 |  |  | (48 | ) |
| (Loss) income from continuing operations |  | (79 | ) |  | 132 |  |  | 795 |  |  | 440 |  |
| (Loss) income from discontinued operations, net of income taxes |  | (13 | ) |  | 31 |  |  | 1,044 |  |  | 93 |  |
| Net (loss) income |  | (92 | ) |  | 163 |  |  | 1,839 |  |  | 533 |  |
| Less: noncontrolling interest in subsidiaries net (loss) income |  | (3 | ) |  | (3 | ) |  | 1 |  |  | (3 | ) |
| Net (loss) income attributable to Tyco common shareholders |  | $ | (89 | ) |  | $ | 166 |  |  | $ | 1,838 |  |  | $ | 536 |  |
| Amounts attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| (Loss) income from continuing operations |  | $ | (76 | ) |  | $ | 135 |  |  | $ | 794 |  |  | $ | 443 |  |
| (Loss) income from discontinued operations |  | (13 | ) |  | 31 |  |  | 1,044 |  |  | 93 |  |
| Net (loss) income attributable to Tyco common shareholders |  | $ | (89 | ) |  | $ | 166 |  |  | $ | 1,838 |  |  | $ | 536 |  |
| Basic earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| (Loss) income from continuing operations |  | $ | (0.17 | ) |  | $ | 0.29 |  |  | $ | 1.74 |  |  | $ | 0.96 |  |
| (Loss) income from discontinued operations |  | (0.03 | ) |  | 0.07 |  |  | 2.30 |  |  | 0.19 |  |
| Net (loss) income attributable to Tyco common shareholders |  | $ | (0.20 | ) |  | $ | 0.36 |  |  | $ | 4.04 |  |  | $ | 1.15 |  |
| Diluted earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |  |  |  |
| (Loss) income from continuing operations |  | $ | (0.17 | ) |  | $ | 0.29 |  |  | $ | 1.71 |  |  | $ | 0.94 |  |
| (Loss) income from discontinued operations |  | (0.03 | ) |  | 0.06 |  |  | 2.26 |  |  | 0.20 |  |
| Net (loss) income attributable to Tyco common shareholders |  | $ | (0.20 | ) |  | $ | 0.35 |  |  | $ | 3.97 |  |  | $ | 1.14 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 438 |  |  | 463 |  |  | 455 |  |  | 465 |  |
| Diluted |  | 438 |  |  | 471 |  |  | 463 |  |  | 472 |  |

[0000833444-14-000121:8k_2_02:76]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Current Report on Form 8-K filed on May 16, 2014 for the fiscal year ended September 27, 2013 and Quarterly Report on Form 10-Q for the quarter ended June 27, 2014.

[0000833444-14-000121:8k_2_02:77]
TYCO INTERNATIONAL LTD.

[0000833444-14-000121:8k_2_02:78]
RESULTS OF SEGMENTS

[0000833444-14-000121:8k_2_02:79]
(in millions)

[0000833444-14-000121:8k_2_02:80]
(Unaudited)

[0000833444-14-000121:8k_2_02:81]
|  |  | Quarters Ended |  |  |  | Twelve Months Ended |  |  |
|  |  | September 26, 2014 |  |  |  | September 27, 2013 |  |  |  | September 26, 2014 |  |  |  | September 27, 2013 |  |  |
| Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Installation & Services |  | $ | 1,012 |  |  |  |  |  | $ | 996 |  |  |  |  |  | $ | 3,876 |  |  |  |  |  | $ | 3,891 |  |  |  |  |
| ROW Installation & Services |  | 1,011 |  |  |  |  |  | 987 |  |  |  |  |  | 3,920 |  |  |  |  |  | 3,843 |  |  |  |  |
| Global Products |  | 681 |  |  |  |  |  | 627 |  |  |  |  |  | 2,544 |  |  |  |  |  | 2,339 |  |  |  |  |
| Total Net Revenue |  | $ | 2,704 |  |  |  |  |  | $ | 2,610 |  |  |  |  |  | $ | 10,340 |  |  |  |  |  | $ | 10,073 |  |  |  |  |
| Operating (Loss) Income and Margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Installation & Services |  | $ | 117 |  |  | 11.6 | % |  | $ | 113 |  |  | 11.3 | % |  | $ | 450 |  |  | 11.6 | % |  | $ | 388 |  |  | 10.0 | % |
| ROW Installation & Services |  | 101 |  |  | 10.0 | % |  | 83 |  |  | 8.4 | % |  | 409 |  |  | 10.4 | % |  | 333 |  |  | 8.7 | % |
| Global Products |  | 129 |  |  | 18.9 | % |  | 119 |  |  | 19.0 | % |  | 458 |  |  | 18.0 | % |  | 307 |  |  | 13.1 | % |
| Corporate and Other |  | (547 | ) |  | N/M |  |  | (80 | ) |  | N/M |  |  | (620 | ) |  | N/M |  |  | (319 | ) |  | N/M |  |
| Operating (Loss) Income and Margin |  | $ | (200 | ) |  | N/M |  |  | $ | 235 |  |  | 9.0 | % |  | $ | 697 |  |  | 6.7 | % |  | $ | 709 |  |  | 7.0 | % |

[0000833444-14-000121:8k_2_02:82]
TYCO INTERNATIONAL LTD.

[0000833444-14-000121:8k_2_02:83]
CONSOLIDATED BALANCE SHEETS

[0000833444-14-000121:8k_2_02:84]
(in millions)

[0000833444-14-000121:8k_2_02:85]
(Unaudited)

[0000833444-14-000121:8k_2_02:86]
|  |  | September 26, 2014 |  | September 27, 2013 |
| Assets |  |  |  |  |
| Current Assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 892 |  |  | $ | 563 |  |
| Accounts receivable, net |  | 1,750 |  |  | 1,704 |  |
| Inventories |  | 628 |  |  | 645 |  |
| Prepaid expenses and other current assets |  | 1,153 |  |  | 839 |  |
| Deferred income taxes |  | 307 |  |  | 250 |  |
| Assets held for sale |  | 21 |  |  | 856 |  |
| Total Current Assets |  | 4,751 |  |  | 4,857 |  |
| Property, plant and equipment, net |  | 1,269 |  |  | 1,284 |  |
| Goodwill |  | 4,126 |  |  | 4,162 |  |
| Intangible assets, net |  | 737 |  |  | 791 |  |
| Other assets |  | 926 |  |  | 1,082 |  |
| Total Assets |  | $ | 11,809 |  |  | $ | 12,176 |  |
| Liabilities and Equity |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |
| Loans payable and current maturities of long-term debt |  | $ | 20 |  |  | $ | 20 |  |
| Accounts payable |  | 871 |  |  | 848 |  |
| Accrued and other current liabilities |  | 2,167 |  |  | 1,852 |  |
| Deferred revenue |  | 400 |  |  | 393 |  |
| Liabilities held for sale |  | 13 |  |  | 236 |  |
| Total Current Liabilities |  | 3,471 |  |  | 3,349 |  |
| Long-term debt |  | 1,443 |  |  | 1,443 |  |
| Deferred revenue |  | 335 |  |  | 370 |  |
| Other liabilities |  | 1,877 |  |  | 1,881 |  |
| Total Liabilities |  | 7,126 |  |  | 7,043 |  |
| Redeemable noncontrolling interest |  | 13 |  |  | 12 |  |
| Total Tyco shareholders' equity |  | 4,647 |  |  | 5,098 |  |
| Nonredeemable noncontrolling interest |  | 23 |  |  | 23 |  |
| Total Equity |  | 4,670 |  |  | 5,121 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity |  | $ | 11,809 |  |  | $ | 12,176 |  |

[0000833444-14-000121:8k_2_02:87]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Current Report on Form 8-K filed on May 16, 2014 for the fiscal year ended September 27, 2013 and Quarterly Report on Form 10-Q for the quarter ended June 27, 2014.

[0000833444-14-000121:8k_2_02:88]
TYCO INTERNATIONAL LTD.

[0000833444-14-000121:8k_2_02:89]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000833444-14-000121:8k_2_02:90]
(in millions)

[0000833444-14-000121:8k_2_02:91]
(Unaudited)

[0000833444-14-000121:8k_2_02:92]
|  |  | For the Quarters Ended |  | For the Twelve Months Ended |
|  |  | September 26, 2014 |  | September 27, 2013 |  | September 26, 2014 |  | September 27, 2013 |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net (loss) income attributable to Tyco common shareholders |  | $ | (89 | ) |  | $ | 166 |  |  | $ | 1,838 |  |  | $ | 536 |  |
| Noncontrolling interest in subsidiaries net (loss) income |  | (3 | ) |  | (3 | ) |  | 1 |  |  | (3 | ) |
| Income (loss) from discontinued operations, net of income taxes |  | 13 |  |  | (31 | ) |  | (1,044 | ) |  | (93 | ) |
| (Loss) income from continuing operations |  | (79 | ) |  | 132 |  |  | 795 |  |  | 440 |  |
| Adjustments to reconcile net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  | 91 |  |  | 98 |  |  | 361 |  |  | 382 |  |
| Non-cash compensation expense |  | 24 |  |  | 16 |  |  | 72 |  |  | 63 |  |
| Deferred income taxes |  | (191 | ) |  | 57 |  |  | (106 | ) |  | 5 |  |
| Provision for losses on accounts receivable and inventory |  | 13 |  |  | 18 |  |  | 44 |  |  | 70 |  |
| Non-cash restructuring and asset impairment charges, net |  | 1 |  |  | — |  |  | 2 |  |  | 1 |  |
| Legacy legal matters |  | — |  |  | — |  |  | (92 | ) |  | — |  |
| Loss (gain) on divestitures |  | — |  |  | 10 |  |  | (2 | ) |  | 20 |  |
| (Gain) loss on investments |  | (1 | ) |  | 28 |  |  | (215 | ) |  | 42 |  |
| Other non-cash items |  | 6 |  |  | 1 |  |  | 25 |  |  | 64 |  |
| Changes in assets and liabilities, net of the effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (54 | ) |  | (43 | ) |  | (93 | ) |  | (75 | ) |
| Contracts in progress |  | (49 | ) |  | (7 | ) |  | (98 | ) |  | (20 | ) |
| Inventories |  | — |  |  | 35 |  |  | (13 | ) |  | (36 | ) |
| Prepaid expenses and other assets |  | (52 | ) |  | (15 | ) |  | (91 | ) |  | 31 |  |
| Accounts payable |  | 38 |  |  | 32 |  |  | 53 |  |  | (12 | ) |
| Accrued and other liabilities |  | 565 |  |  | 5 |  |  | 205 |  |  | (226 | ) |
| Deferred revenue |  | (11 | ) |  | (31 | ) |  | (24 | ) |  | (32 | ) |
| Income taxes, net |  | 22 |  |  | (36 | ) |  | 28 |  |  | (31 | ) |
| Other |  | (12 | ) |  | 34 |  |  | (20 | ) |  | 8 |  |
| Net cash provided by operating activities |  | 311 |  |  | 334 |  |  | 831 |  |  | 694 |  |
| Net cash (used in) provided by discontinued operating activities |  | (19 | ) |  | 39 |  |  | 81 |  |  | 156 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures |  | (78 | ) |  | (65 | ) |  | (288 | ) |  | (270 | ) |
| Proceeds from disposal of assets |  | 3 |  |  | 1 |  |  | 10 |  |  | 5 |  |
| Acquisition of businesses, net of cash acquired |  | (2 | ) |  | (154 | ) |  | (65 | ) |  | (229 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (5 | ) |  | (5 | ) |  | (25 | ) |  | (19 | ) |
| Divestiture of business, net of cash divested |  | — |  |  | — |  |  | 1 |  |  | 17 |  |
| Sales and maturities of investments |  | — |  |  | 79 |  |  | 283 |  |  | 182 |  |
| Purchases of investments |  | (54 | ) |  | (45 | ) |  | (386 | ) |  | (227 | ) |
| Sale of equity investment |  | — |  |  | — |  |  | 250 |  |  | — |  |
| Decrease (increase) in restricted cash |  | 2 |  |  | 1 |  |  | 3 |  |  | (8 | ) |
| Other |  | (4 | ) |  | 6 |  |  | (4 | ) |  | 4 |  |
| Net cash used in investing activities |  | (138 | ) |  | (182 | ) |  | (221 | ) |  | (545 | ) |
| Net cash (used in) provided by discontinued investing activities |  | — |  |  | (28 | ) |  | 1,789 |  |  | (110 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt |  | — |  |  | 95 |  |  | 830 |  |  | 475 |  |
| Repayment of short-term debt |  | — |  |  | (114 | ) |  | (831 | ) |  | (505 | ) |
| Proceeds from exercise of share options |  | 12 |  |  | 28 |  |  | 91 |  |  | 153 |  |
| Dividends paid |  | (80 | ) |  | (74 | ) |  | (311 | ) |  | (288 | ) |
| Repurchase of common shares by treasury |  | (1,027 | ) |  | — |  |  | (1,833 | ) |  | (300 | ) |
| Purchase of noncontrolling interest |  | (66 | ) |  | — |  |  | (66 | ) |  | — |  |
| Transfer from discontinued operations |  | (19 | ) |  | 11 |  |  | 1,870 |  |  | 76 |  |
| Other |  | (1 | ) |  | 5 |  |  | (11 | ) |  | (30 | ) |
| Net cash used in financing activities |  | (1,181 | ) |  | (49 | ) |  | (261 | ) |  | (419 | ) |
| Net cash provided by (used in) discontinued financing activities |  | 19 |  |  | (11 | ) |  | (1,870 | ) |  | (76 | ) |
| Effect of currency translation on cash |  | (12 | ) |  | 5 |  |  | (20 | ) |  | (11 | ) |
| Net (decrease) increase in cash and cash equivalents |  | (1,020 | ) |  | 108 |  |  | 329 |  |  | (311 | ) |
| Less: net decrease in cash and cash equivalents related to discontinued operations |  | — |  |  | — |  |  | — |  |  | (30 | ) |
| Cash and cash equivalents at beginning of period |  | 1,912 |  |  | 455 |  |  | 563 |  |  | 844 |  |
| Cash and cash equivalents at end of period |  | $ | 892 |  |  | $ | 563 |  |  | $ | 892 |  |  | $ | 563 |  |

[0000833444-14-000121:8k_2_02:93]
| Reconciliation to "Free Cash Flow": |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 311 |  |  | $ | 334 |  |  | $ | 831 |  |  | $ | 694 |  |
| Capital expenditures, net |  | (75 | ) |  | (64 | ) |  | (278 | ) |  | (265 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (5 | ) |  | (5 | ) |  | (25 | ) |  | (19 | ) |
| Purchase accounting and holdback liabilities |  | — |  |  | 5 |  |  | — |  |  | (2 | ) |
| Free Cash Flow |  | $ | 231 |  |  | $ | 270 |  |  | $ | 528 |  |  | $ | 408 |  |
| Reconciliation to "Adjusted Free Cash Flow": |  |  |  |  |  |  |  |  |
| CIT settlement |  | $ | — |  |  | $ | — |  |  | $ | (17 | ) |  | $ | — |  |
| IRS litigation costs |  | (1 | ) |  | — |  |  | — |  |  | — |  |
| Separation costs |  | 37 |  |  | 20 |  |  | 108 |  |  | 188 |  |
| Restructuring and repositioning costs |  | 25 |  |  | 34 |  |  | 104 |  |  | 95 |  |
| Environmental remediation payments |  | 3 |  |  | 27 |  |  | 63 |  |  | 51 |  |
| Legal settlements |  | — |  |  | — |  |  | 6 |  |  | 46 |  |
| Net asbestos payments (recoveries) |  | 5 |  |  | 10 |  |  | 18 |  |  | (14 | ) |
| Cash payment from Covidien/TE Connectivity |  | — |  |  | — |  |  | 149 |  |  | 11 |  |
| Cash payment from ADT Resi/Pentair |  | 9 |  |  | — |  |  | 39 |  |  | — |  |
| Acquisition/integration costs |  | 3 |  |  | 1 |  |  | 3 |  |  | 1 |  |
| Special Items |  | $ | 81 |  |  | $ | 92 |  |  | $ | 473 |  |  | $ | 378 |  |
| Adjusted Free Cash Flow |  | $ | 312 |  |  | $ | 362 |  |  | $ | 1,001 |  |  | $ | 786 |  |

[0000833444-14-000121:8k_2_02:94]
NOTE: Free cash flow is a non-GAAP measure.  See description of non-GAAP measures contained in this release.

[0000833444-14-000121:8k_2_02:95]
TYCO INTERNATIONAL LTD.

[0000833444-14-000121:8k_2_02:96]
ORGANIC GROWTH RECONCILIATION - REVENUE

[0000833444-14-000121:8k_2_02:97]
(in millions)

[0000833444-14-000121:8k_2_02:98]
(Unaudited)

[0000833444-14-000121:8k_2_02:99]
|  |  |  |  | Quarter Ended September 26, 2014 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Quarter Ended September 27, 2013 |  | Adjustments |  | Adjusted Fiscal 2013 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Quarter Ended September 26, 2014 |
|  |  |  | Divestitures / Other |  |  | Foreign Currency |  | Acquisitions |  | Organic Revenue(1) |  |
| NA Installation & Services |  | $ | 996 |  |  | $ | — |  |  | — | % |  | $ | 996 |  |  | $ | (5 | ) |  | (0.5 | )% |  | $ | 5 |  |  | 0.5 | % |  | $ | 16 |  |  | 1.6 | % |  | $ | 1,012 |  |  | 1.6 | % |
| ROW Installation & Services |  | 987 |  |  | (20 | ) |  | (2.0 | )% |  | 967 |  |  | 6 |  |  | 0.6 | % |  | 20 |  |  | 2.0 | % |  | 18 |  |  | 1.9 | % |  | 1,011 |  |  | 2.4 | % |
| Global Products |  | 627 |  |  | — |  |  | — | % |  | 627 |  |  | (1 | ) |  | (0.2 | )% |  | 7 |  |  | 1.1 | % |  | 48 |  |  | 7.7 | % |  | 681 |  |  | 8.6 | % |
| Total Net Revenue |  | $ | 2,610 |  |  | $ | (20 | ) |  | (0.8 | )% |  | $ | 2,590 |  |  | $ | — |  |  | — | % |  | $ | 32 |  |  | 1.2 | % |  | $ | 82 |  |  | 3.2 | % |  | $ | 2,704 |  |  | 3.6 | % |

[0000833444-14-000121:8k_2_02:100]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2013 base revenue. |

[0000833444-14-000121:8k_2_02:101]
|  |  |  |  | Year Ended September 26, 2014 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Twelve Months Ended September 27, 2013 |  | Adjustments |  | Adjusted Fiscal 2013 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Twelve Months Ended September 26, 2014 |
|  |  |  | Divestitures / Other (2) |  |  | Foreign Currency |  | Acquisitions |  |  | Organic Revenue(1) |  |
| NA Installation & Services |  | $ | 3,891 |  |  | $ | (42 | ) |  | (1.1 | )% |  | $ | 3,849 |  |  | $ | (29 | ) |  | (0.7 | )% |  | $ | 19 |  |  | 0.5 | % |  |  | $ | 37 |  |  | 1.0 | % |  | $ | 3,876 |  |  | (0.4 | )% |
| ROW Installation & Services |  | 3,843 |  |  | (67 | ) |  | (1.7 | )% |  | 3,776 |  |  | (46 | ) |  | (1.2 | )% |  | 119 |  |  | 3.1 | % |  |  | 71 |  |  | 1.9 | % |  | 3,920 |  |  | 2.0 | % |
| Global Products |  | 2,339 |  |  | 2 |  |  | 0.1 | % |  | 2,341 |  |  | (7 | ) |  | (0.3 | )% |  | 63 |  |  | 2.7 | % |  |  | 147 |  |  | 6.3 | % |  | 2,544 |  |  | 8.8 | % |
| Total Net Revenue |  | $ | 10,073 |  |  | $ | (107 | ) |  | (1.1 | )% |  | $ | 9,966 |  |  | $ | (82 | ) |  | (0.8 | )% |  | $ | 201 |  |  | 2.0 | % |  |  | $ | 255 |  |  | 2.6 | % |  | $ | 10,340 |  |  | 2.7 | % |

[0000833444-14-000121:8k_2_02:102]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2013 base revenue. |
|  | (2)Amounts include the transfer of a business from NA Installation & Services to Global Products. |

[0000833444-14-000121:8k_2_02:103]
Earnings Per Share Summary

[0000833444-14-000121:8k_2_02:104]
(Unaudited)

[0000833444-14-000121:8k_2_02:105]
|  |  | Quarter Ended |  | Year Ended |  | Quarter Ended |  | Year Ended |
|  |  | Sept. 26, 2014 |  | Sept. 26, 2014 |  | Sept. 27, 2013 |  | Sept. 27, 2013 |
| Diluted EPS from Continuing Operations Attributable to Tyco Shareholders (GAAP) |  | $ | (0.17 | ) |  | $ | 1.71 |  |  | $ | 0.29 |  |  | $ | 0.94 |  |
| expense / (benefit) |  |  |  |  |  |  |  |  |  |
| Restructuring and repositioning activities |  | 0.05 |  |  | 0.14 |  |  | 0.06 |  |  | 0.21 |  |
| Separation costs included in SG&A |  | 0.02 |  |  | 0.08 |  |  | 0.02 |  |  | 0.10 |  |
| (Gains) / losses on divestitures, net included in SG&A |  | — |  |  | (0.01 | ) |  | 0.02 |  |  | 0.04 |  |
| Acquisition / integration costs |  | — |  |  | — |  |  | — |  |  | 0.01 |  |
| Asbestos |  | 0.66 |  |  | 0.63 |  |  | — |  |  | 0.03 |  |
| Environmental remediation |  | — |  |  | — |  |  | — |  |  | 0.13 |  |
| Tyco share of Atkore impairment |  | — |  |  | — |  |  | 0.04 |  |  | 0.03 |  |
| Legacy legal items |  | — |  |  | — |  |  | — |  |  | 0.04 |  |
| Loss on sale of investment |  | — |  |  | 0.02 |  |  | — |  |  | — |  |
| CIT settlement |  | — |  |  | (0.03 | ) |  | — |  |  | — |  |
| Settlement with former management |  | — |  |  | (0.13 | ) |  | — |  |  | — |  |
| Separation costs |  | — |  |  | — |  |  | — |  |  | 0.02 |  |
| Tax items |  | — |  |  | 0.03 |  |  | 0.04 |  |  | 0.04 |  |
| 2012 Tax Sharing Agreement |  | — |  |  | 0.01 |  |  | — |  |  | 0.07 |  |
| Gain on sale of Atkore divestiture |  | — |  |  | (0.46 | ) |  | — |  |  | — |  |
| Total Before Special Items |  | $ | 0.56 |  |  | $ | 1.99 |  |  | $ | 0.47 |  |  | $ | 1.66 |  |

[0000833444-14-000121:8k_2_02:106]
Tyco International Ltd.

[0000833444-14-000121:8k_2_02:107]
For the Quarter Ended September 26, 2014

[0000833444-14-000121:8k_2_02:108]
(in millions, except per share data)

[0000833444-14-000121:8k_2_02:109]
(Unaudited)

[0000833444-14-000121:8k_2_02:110]
expense / (benefit)

[0000833444-14-000121:8k_2_02:111]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $1,012 |  |  |  |  |  | $1,011 |  |  |  |  |  | $681 |  |  |  |  |  | $2,704 |  |  |  |  |  | $— |  |  |  |  |  | $2,704 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | (Loss)IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $117 |  |  | 11.6 | % |  |  | $101 |  |  | 10.0 | % |  |  | $129 |  |  | 18.9 | % |  |  | $347 |  |  | 12.8 | % |  |  | ($547 | ) |  | N/M |  |  | ($200 | ) |  | N/M |  |  |  | ($20 | ) |  |  | $1 |  |  |  | $140 |  |  | — |  |  |  | $3 |  |  |  | ($76 | ) |  | ($0.17 | ) |
| Restructuring and repositioning activities |  | 6 |  |  |  |  | 16 |  |  |  |  | 1 |  |  |  |  | 23 |  |  |  |  | 13 |  |  |  |  | 36 |  |  |  |  |  |  |  |  | (11 | ) |  |  |  |  |  | 25 |  | 0.05 |  |
| Restructuring charges in cost of sales and SG&A |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  | — |  |
| Separation costs included in SG&A |  | 11 |  |  |  |  |  |  |  |  |  |  |  |  | 11 |  |  |  |  |  |  |  |  | 11 |  |  |  |  |  |  |  |  | (3 | ) |  |  |  |  |  | 8 |  | 0.02 |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  | (2 | ) | — |  |
| Acquisition / integration costs |  |  |  |  |  | 1 |  |  |  |  | (1 | ) |  |  |  | — |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | (1 | ) | — |  |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 467 |  |  |  |  | 467 |  |  |  |  |  |  |  |  | (173 | ) |  |  |  |  |  | 294 |  | 0.66 |  |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  |  |  |  | 4 |  |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  | 2 |  | — |  |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | (1 | ) | — |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Total Before Special Items |  |  | $134 |  |  | 13.2 | % |  |  | $118 |  |  | 11.7 | % |  |  | $131 |  |  | 19.2 | % |  |  | $383 |  |  | 14.2 | % |  |  | ($63 | ) |  | N/M |  |  | $320 |  |  | 11.8 | % |  |  | ($20 | ) |  |  | $2 |  |  |  | ($53 | ) |  |  | $— |  |  |  | $3 |  |  |  | $252 |  |  | $0.56 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 438 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 447 |  |

[0000833444-14-000121:8k_2_02:112]
Tyco International Ltd.

[0000833444-14-000121:8k_2_02:113]
For the Year Ended September 26, 2014

[0000833444-14-000121:8k_2_02:114]
(in millions, except per share data)

[0000833444-14-000121:8k_2_02:115]
(Unaudited)

[0000833444-14-000121:8k_2_02:116]
expense / (benefit)

[0000833444-14-000121:8k_2_02:117]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $3,876 |  |  |  |  |  | $3,920 |  |  |  |  |  | $2,544 |  |  |  |  |  | $10,340 |  |  |  |  |  | $— |  |  |  |  |  | $10,340 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $450 |  |  | 11.6 | % |  |  | $409 |  |  | 10.4 | % |  |  | $458 |  |  | 18.0 | % |  |  | $1,317 |  |  | 12.7 | % |  |  | ($620 | ) |  | N/M |  |  | $697 |  |  | 6.7 | % |  |  | ($83 | ) |  |  | ($1 | ) |  |  | ($24 | ) |  |  | $206 |  |  |  | ($1 | ) |  |  | $794 |  |  | $1.71 |  |
| Restructuring and repositioning activities |  | 13 |  |  |  |  | 31 |  |  |  |  | 10 |  |  |  |  | 54 |  |  |  |  | 37 |  |  |  |  | 91 |  |  |  |  |  |  |  |  | (28 | ) |  |  |  |  |  | 63 |  | 0.14 |  |
| Restructuring charges in cost of sales and SG&A |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  | — |  |
| Separation costs included in SG&A |  | 51 |  |  |  |  |  |  |  |  |  |  |  |  | 51 |  |  |  |  | 1 |  |  |  |  | 52 |  |  |  |  |  |  |  |  | (15 | ) |  |  |  |  |  | 37 |  | 0.08 |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  | (3 | ) |  |  |  | (2 | ) |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  | (4 | ) | (0.01 | ) |
| Acquisition / integration costs |  |  |  |  |  | 3 |  |  |  |  |  |  |  |  | 3 |  |  |  |  |  |  |  |  | 3 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | 2 |  | — |  |
| Settlement with former management |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (96 | ) |  |  |  | (96 | ) |  |  |  |  |  |  |  | 37 |  |  |  |  |  |  | (59 | ) | (0.13 | ) |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 462 |  |  |  |  | 462 |  |  |  |  |  |  |  |  | (171 | ) |  |  |  |  |  | 291 |  | 0.63 |  |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  |  |  |  | 4 |  |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  | 2 |  | — |  |
| CIT settlement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (16 | ) |  |  |  | (16 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (16 | ) | (0.03 | ) |
| Loss on sale of investment |  |  |  |  |  | 7 |  |  |  |  |  |  |  |  | 7 |  |  |  |  |  |  |  |  | 7 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 7 |  | 0.02 |  |
| Separation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 12 |  |  |  |  |  |  | 12 |  | 0.03 |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 6 |  |  |  |  |  |  |  |  | 6 |  | 0.01 |  |
| Gain on sale of Atkore divestiture |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (216 | ) |  |  |  | (216 | ) | (0.46 | ) |
| Total Before Special Items |  |  | $514 |  |  | 13.3 | % |  |  | $451 |  |  | 11.5 | % |  |  | $470 |  |  | 18.5 | % |  |  | $1,435 |  |  | 13.9 | % |  |  | ($230 | ) |  | N/M |  |  | $1,205 |  |  | 11.7 | % |  |  | ($83 | ) |  |  | $5 |  |  |  | ($194 | ) |  |  | ($10 | ) |  |  | ($1 | ) |  |  | $922 |  |  | $1.99 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 463 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 463 |  |

[0000833444-14-000121:8k_2_02:118]
Tyco International Ltd.

[0000833444-14-000121:8k_2_02:119]
For the Quarter Ended September 27, 2013

[0000833444-14-000121:8k_2_02:120]
(in millions, except per share data)

[0000833444-14-000121:8k_2_02:121]
(Unaudited)

[0000833444-14-000121:8k_2_02:122]
expense / (benefit)

[0000833444-14-000121:8k_2_02:123]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $996 |  |  |  |  |  | $987 |  |  |  |  |  | $627 |  |  |  |  |  | $2,610 |  |  |  |  |  | $— |  |  |  |  |  | $2,610 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $113 |  |  | 11.3 | % |  |  | $83 |  |  | 8.4 | % |  |  | $119 |  |  | 19.0 | % |  |  | $315 |  |  | 12.1 | % |  |  | ($80 | ) |  | N/M |  |  | $235 |  |  | 9.0 | % |  |  | ($22 | ) |  |  | $1 |  |  |  | ($52 | ) |  |  | ($30 | ) |  |  | $3 |  |  |  | $135 |  |  | $0.29 |  |
| Restructuring and repositioning activities |  | 14 |  |  |  |  | 12 |  |  |  |  | 2 |  |  |  |  | 28 |  |  |  |  | 11 |  |  |  |  | 39 |  |  |  |  |  |  |  |  | (14 | ) |  |  |  |  |  | 25 |  | 0.06 |  |
| Separation costs included in SG&A |  | 9 |  |  |  |  |  |  |  |  |  |  |  |  | 9 |  |  |  |  | 5 |  |  |  |  | 14 |  |  |  |  |  |  |  |  | (8 | ) |  |  |  |  |  | 6 |  | 0.02 |  |
| (Gains) / losses on divestitures, net included in SG&A |  | (3 | ) |  |  |  | 13 |  |  |  |  |  |  |  |  | 10 |  |  |  |  |  |  |  |  | 10 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 10 |  | 0.02 |  |
| Acquisition / integration costs |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  | — |  |
| Asset impairment charges |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  | — |  |
| Tyco share of Atkore impairment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 21 |  |  |  |  | 21 |  | 0.04 |  |
| Separation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (1 | ) |  |  |  | (1 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (1 | ) | — |  |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 16 |  |  |  |  |  |  | 16 |  | 0.04 |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Total Before Special Items |  |  | $133 |  |  | 13.4 | % |  |  | $110 |  |  | 11.1 | % |  |  | $122 |  |  | 19.5 | % |  |  | $365 |  |  | 14.0 | % |  |  | ($63 | ) |  | N/M |  |  | $302 |  |  | 11.6 | % |  |  | ($22 | ) |  |  | $2 |  |  |  | ($58 | ) |  |  | ($9 | ) |  |  | $3 |  |  |  | $218 |  |  | $0.47 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 471 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 471 |  |

[0000833444-14-000121:8k_2_02:124]
Tyco International Ltd.

[0000833444-14-000121:8k_2_02:125]
For the Year Ended September 27, 2013

[0000833444-14-000121:8k_2_02:126]
(in millions, except per share data)

[0000833444-14-000121:8k_2_02:127]
(Unaudited)

[0000833444-14-000121:8k_2_02:128]
expense / (benefit)

[0000833444-14-000121:8k_2_02:129]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $3,891 |  |  |  |  |  | $3,843 |  |  |  |  |  | $2,339 |  |  |  |  |  | $10,073 |  |  |  |  |  | $— |  |  |  |  |  | $10,073 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $388 |  |  | 10.0 | % |  |  | $333 |  |  | 8.7 | % |  |  | $307 |  |  | 13.1 | % |  |  | $1,028 |  |  | 10.2 | % |  |  | ($319 | ) |  | N/M |  |  | $709 |  |  | 7.0 | % |  |  | ($84 | ) |  |  | ($29 | ) |  |  | ($108 | ) |  |  | ($48 | ) |  |  | $3 |  |  |  | $443 |  |  | $0.94 |  |
| Restructuring and repositioning activities |  | 36 |  |  |  |  | 63 |  |  |  |  | 12 |  |  |  |  | 111 |  |  |  |  | 19 |  |  |  |  | 130 |  |  |  |  |  |  |  |  | (33 | ) |  |  |  |  |  | 97 |  | 0.21 |  |
| Separation costs included in SG&A |  | 49 |  |  |  |  |  |  |  |  |  |  |  |  | 49 |  |  |  |  | 12 |  |  |  |  | 61 |  |  |  |  |  |  |  |  | (13 | ) |  |  |  |  |  | 48 |  | 0.10 |  |
| (Gains) / losses on divestitures, net included in SG&A |  | 1 |  |  |  |  | 14 |  |  |  |  |  |  |  |  | 15 |  |  |  |  | 5 |  |  |  |  | 20 |  |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  | 18 |  | 0.04 |  |
| Acquisition / integration costs |  |  |  |  |  | 2 |  |  |  |  | 2 |  |  |  |  | 4 |  |  |  |  |  |  |  |  | 4 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  | 0.01 |  |
| Asset impairment charges |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 12 |  |  |  |  | 12 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 12 |  | 0.03 |  |
| Environmental remediation |  |  |  |  |  |  |  |  |  | 100 |  |  |  |  | 100 |  |  |  |  |  |  |  |  | 100 |  |  |  |  |  |  |  |  | (39 | ) |  |  |  |  |  | 61 |  | 0.13 |  |
| Tyco share of Atkore impairment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 21 |  |  |  |  | 21 |  | 0.03 |  |
| Legacy legal items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27 |  |  |  |  | 27 |  |  |  |  |  |  |  |  | (9 | ) |  |  |  |  |  | 18 |  | 0.04 |  |
| Separation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 8 |  |  |  |  | 8 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 8 |  | 0.02 |  |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 22 |  |  |  |  |  |  | 22 |  | 0.04 |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 32 |  |  |  |  |  |  |  |  | 32 |  | 0.07 |  |
| Total Before Special Items |  |  | $474 |  |  | 12.2 | % |  |  | $413 |  |  | 10.7 | % |  |  | $421 |  |  | 18.0 | % |  |  | $1,308 |  |  | 13.0 | % |  |  | ($236 | ) |  | N/M |  |  | $1,072 |  |  | 10.6 | % |  |  | ($84 | ) |  |  | $3 |  |  |  | ($182 | ) |  |  | ($27 | ) |  |  | $3 |  |  |  | $785 |  |  | $1.66 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 472 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 472 |  |
