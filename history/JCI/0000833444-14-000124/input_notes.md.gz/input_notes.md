# JCI notes — 0000833444-14-000124


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000833444-14-000124:notes:1]
Advertising—Advertising costs are expensed when incurred and are included in selling, general and administrative expenses, which amounted to $48 million, $60 million and $39 million for fiscal years 2014, 2013 and 2012, respectively.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000833444-14-000124:notes:2]
As of September 26, 2014 ($ in millions):

[0000833444-14-000124:notes:3]
|  |  | Fair Value |  | ConsolidatedBalance SheetClassification |
| Investment Assets: |  | Level 1 |  | Level 2 |  | Total |  | Prepaidsand OtherCurrentAssets |  | OtherAssets |
| Time deposits |  | $ | 275 |  |  | $ | — |  |  | $ | 275 |  |  | $ | 275 |  |  | $ | — |  |
| Exchange traded equity funds |  | 62 |  |  | — |  |  | 62 |  |  | 62 |  |  | — |  |
|  |  | $ | 337 |  |  | $ | — |  |  | $ | 337 |  |  | $ | 337 |  |  | $ | — |  |

[0000833444-14-000124:notes:4]
As of September 27, 2013 ($ in millions):

[0000833444-14-000124:notes:5]
|  |  | Fair Value |  | ConsolidatedBalance SheetClassification |
| Available-for-sale securities: |  | Level 1 |  | Level 2 |  | Total |  | Prepaidsand OtherCurrentAssets |  | OtherAssets |
| Corporate debt securities |  | $ | — |  |  | $ | 34 |  |  | $ | 34 |  |  | $ | 11 |  |  | $ | 23 |  |
| U.S. Government debt securities |  | 171 |  |  | 38 |  |  | 209 |  |  | 89 |  |  | 120 |  |
|  |  | $ | 171 |  |  | $ | 72 |  |  | $ | 243 |  |  | $ | 100 |  |  | $ | 143 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000833444-14-000124:notes:6]
Basis of Presentation—The Consolidated Financial Statements include the consolidated accounts of Tyco International Ltd., a corporation organized under the laws of Switzerland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The financial statements have been prepared in United States dollars ("USD") and in accordance with generally accepted accounting principles in the United States ("GAAP"). Unless otherwise indicated, references to 2014, 2013 and 2012 are to Tyco's fiscal years ending September 26, 2014, September 27, 2013 and September 28, 2012, respectively.

[0000833444-14-000124:notes:7]
Effective September 28, 2012, Tyco completed the spin-offs of The ADT Corporation ("ADT") and Pentair Ltd. (formerly known as Tyco Flow Control International Ltd. ("Tyco Flow Control")), formerly the North American residential security and flow control businesses of Tyco, respectively, into separate, publicly traded companies in the form of a distribution to Tyco shareholders. Immediately following the spin-off, Pentair, Inc. was merged with a subsidiary of Tyco Flow Control in a tax-free, all-stock merger (the "Merger"), with Pentair Ltd. ("Pentair") succeeding Pentair Inc. as an independent publicly traded company. The distribution was made on September 28, 2012, to Tyco shareholders of record on September 17, 2012. Each Tyco shareholder received 0.50 of a common share of ADT and approximately 0.24 of a common share of Pentair for each Tyco common share held on the record date. The distribution was structured to be tax-free to Tyco shareholders except to the extent of cash received in lieu of fractional shares. The distributions, the Merger and related transactions are collectively referred to herein as the "2012 Separation". As a result of the distribution, the operations of Tyco's former flow control and North American residential security businesses are classified as discontinued operations in all periods prior to the 2012 Separation.

[0000833444-14-000124:notes:8]
The Company operates and reports financial and operating information in the following three segments: North America Installation & Services ("NA Installation & Services"), Rest of World Installation & Services ("ROW Installation & Services") and Global Products. The Company also provides general corporate services to its segments which is reported as a fourth, non-operating segment, Corporate and Other.

[0000833444-14-000124:notes:9]
Change of Jurisdiction— On May 30, 2014, Tyco entered into a Merger Agreement ("Merger Agreement") with Tyco International plc, a newly-formed Irish public limited company and a wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement, Tyco will merge with and into Tyco Ireland, with Tyco Ireland being the surviving company.  This Merger will result in Tyco Ireland becoming Tyco's publicly-traded parent company and change the jurisdiction of organization of Tyco from Switzerland to Ireland.  Tyco's shareholders are expected to receive one ordinary share of Tyco Ireland for each common share of Tyco held immediately prior to the Merger.  Upon completion of the Merger, Tyco Ireland is expected to conduct, through its subsidiaries, the same businesses as conducted by Tyco before the Merger.  The Merger is subject to certain conditions including shareholder approval, which was received at the special general meeting of shareholders held on September 9, 2014. The Merger is expected to become effective in November 2014.

[0000833444-14-000124:notes:10]
Reclassifications— Certain prior period amounts have been reclassified to conform with current period presentation as discussed below.

[0000833444-14-000124:notes:11]
During the third quarter of fiscal 2014, the Company completed the sale of its South Korean security business (“ADT Korea”) to an affiliate of The Carlyle Group. The Company has reclassified the operations of its South Korean security business to Income from discontinued operations in the Consolidated Statements of Operations for all periods presented, and the assets and liabilities as held for sale within the Consolidated Balance Sheets as of September 27, 2013 as it satisfied the criteria to be presented as a discontinued operation for those periods.  See Note 3 for additional information.

[0000833444-14-000124:notes:12]
In addition, the Company has reclassified several businesses in the Rest of World ("ROW") Installation & Services segment to Income from discontinued operations in the Consolidated Statements of Operations, and the assets and liabilities as held for sale within the Consolidated Balance Sheets as they satisfied the criteria to be presented as discontinued operations.  The Company expects to complete the sale of these businesses by the end of the third quarter of fiscal 2015. See Note 3 for additional information.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000833444-14-000124:notes:13]
Acquisitions

[0000833444-14-000124:notes:14]
During the year ended September 26, 2014, total consideration for acquisitions included in continuing operations was $66 million, which was comprised of $65 million of cash paid, net of cash acquired of $1 million, and $1 million of contingent consideration. This was primarily comprised of $53 million of cash paid, net of $1 million cash acquired, and $1 million of contingent consideration for the acquisition of Westfire, Inc. ("Westfire") on November 8, 2013. Westfire, a fire protection services company with operations in the United States, Chile and Peru, provides critical special-hazard suppression and detection applications in mining, telecommunications and other vertical markets and has been integrated with the NA Installation & Services and ROW Installation & Services segments.  The balance of the acquisitions for the year ended September 26, 2014 were included in the Company's ROW Installation & Services segment, none of which were material individually or in the aggregate.

[0000833444-14-000124:notes:15]
During the quarter ended September 26, 2014, the Company also paid $66 million in cash to purchase the remaining ownership interest of a joint venture in Brazil, which has been consolidated into the Company's ROW Installation & Services segment. In connection with Tyco’s acquisition of the remaining ownership interest in this joint venture, the Company recorded an indemnification asset of approximately $11 million relating to the indemnification of Tyco for certain pre-acquisition tax liabilities, in accordance with the purchase agreement.

[0000833444-14-000124:notes:16]
During the year ended September 27, 2013, total consideration for acquisitions included in continuing operations was  $257 million, which was comprised of $229 million cash paid, net of cash acquired of $9 million, and $28 million of consideration that is primarily contingent on the successful transfer of a business license in China to Tyco.  The transfer of this license occurred during the first quarter of fiscal 2015. Cash paid for acquisitions primarily related to the acquisition of Exacq Technologies ("Exacq") on July 26, 2013 by the Company's Global Products segment.  Exacq is a developer of open architecture video management systems for security and surveillance applications.  Cash paid for Exacq totaled approximately $148 million, net of cash acquired of $2 million.  The balance of the acquisitions for the year ended September 27, 2013 were included within the Company's NA Installation & Services and ROW Installation & Services segments, none of which were material individually or in the aggregate.

[0000833444-14-000124:notes:17]
During the year ended September 28, 2012, cash paid for acquisitions included in continuing operations totaled $217 million, net of cash acquired of $17 million, which primarily related to the acquisition of Visonic Ltd. ("Visonic") on December 6, 2011. Visonic is a global developer and manufacturer of electronic security systems and components. Cash paid for Visonic totaled approximately $94 million, net of cash acquired of $5 million by the Company's Global Products segment. The balance of the acquisitions for the year ended September 28, 2012, were included within the Company's NA and ROW Installation & Services and Global Products segments, none of which were material individually or in the aggregate.

[0000833444-14-000124:notes:18]
The Company recorded redeemable noncontrolling interest of $12 million related to an acquisition in the second quarter of 2012.  Net loss and adjustments related to changes in the redemption value were immaterial during the years ended September 26, 2014 and September 27, 2013.  The Company's redeemable noncontrolling interest balance was $13 million as of September 26, 2014 and $12 million as of September 27, 2013.

[0000833444-14-000124:notes:19]
Acquisition and Integration Related Costs

[0000833444-14-000124:notes:20]
Acquisition and integration costs are expensed as incurred. During the years ended  September 26, 2014, September 27, 2013 and September 28, 2012, the Company incurred acquisition and integration costs of $3 million, $4 million and $9 million, respectively. Such costs are recorded in Selling, general and administrative expenses in the Company's Consolidated Statements of Operations.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000833444-14-000124:notes:21]
Cash and Cash Equivalents—All highly liquid investments with original maturities of three months or less are considered to be cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-14-000124:notes:22]
Commitments and Contingencies

[0000833444-14-000124:notes:23]
The Company has facility, vehicle and equipment leases that expire at various dates beyond fiscal 2015. Rental expense under these leases was $280 million, $284 million and $292 million for fiscal years 2014, 2013 and 2012, respectively. Following is a schedule of minimum lease payments for non-cancelable operating leases as of September 26, 2014 ($ in millions):

[0000833444-14-000124:notes:24]
|  | OperatingLeases |
| 2015 | $ | 185 |  |
| 2016 | 163 |  |
| 2017 | 122 |  |
| 2018 | 81 |  |
| 2019 | 44 |  |
| Thereafter | 82 |  |
|  | $ | 677 |  |

[0000833444-14-000124:notes:25]
The Company also has purchase obligations related to commitments to purchase certain goods and services. As of September 26, 2014, such obligations were as follows: $375 million in 2015, $66 million in 2016, $28 million in 2017, $1 million in 2018 and $1 million in 2019 and thereafter.

[0000833444-14-000124:notes:26]
In the normal course of business, the Company is liable for contract completion and product performance. In the opinion of management, such obligations will not significantly affect the Company's financial position, results of operations or cash flows.

[0000833444-14-000124:notes:27]
Legacy Matters Related to Former Management

[0000833444-14-000124:notes:28]
The Company has been a party to several lawsuits involving disputes with former management, including its former chief executive officer, Mr. L. Dennis Kozlowski, and its former chief financial officer, Mr. Mark Swartz. The Company filed civil complaints against Mr. Kozlowski and Mr. Swartz for breach of fiduciary duty and other wrongful conduct relating to alleged abuses of the Company's Key Employee Loan Program and relocation program, unauthorized bonuses, unauthorized payments, self-dealing transactions and other improper conduct. In connection with Tyco's affirmative actions against Mr. Kozlowski and Mr. Swartz, Mr. Kozlowski, through counterclaims, and Mr. Swartz, through a separate lawsuit, sought an aggregate of approximately $140 million allegedly due in connection with their compensation and retention arrangements and under the Employee Retirement Income Security Act ("ERISA").

[0000833444-14-000124:notes:29]
With respect to Mr. Kozlowski, in the first quarter of fiscal 2014, the parties signed an agreement resolving all outstanding disputes with Mr. Kozlowski, and with Mr. Kozlowski agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements, including the Key Employee Loan Program, that were alleged to have existed between him and the Company. As a result, in the first quarter of fiscal 2014, the Company reversed the net liability of approximately $92 million, which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations for the amounts allegedly due to him.  Additionally, the Company will be entitled to a portion of the proceeds, if any, from the future sale of certain assets owned by Mr. Kozlowski, the timing and amount of which is uncertain at this time.  During the quarter ended June 27, 2014, the Company received a $4 million recovery from the sale of property owned by Mr. Kozlowski, which was recognized as a reduction to Selling, general and administrative expenses.

[0000833444-14-000124:notes:30]
With respect to Mr. Swartz, during the second quarter of fiscal 2012, the Company reversed a $50 million liability related to Mr. Swartz's pay and benefits due to the expiration of the statute of limitations and in July 2013, the parties reached an agreement in principle to resolve the matter, with Mr. Swartz agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements alleged to have existed between him and the Company. In November 2014, the parties executed a definitive settlement agreement and the Company received approximately $12 million in cash from Mr. Swartz, a portion of which will be shared with the members of the class action settlement.

[0000833444-14-000124:notes:31]
Environmental Matters

[0000833444-14-000124:notes:32]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of September 26, 2014, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $38 million to $79 million. As of September 26, 2014, Tyco concluded that the best estimate within this range is approximately $42 million, of which $23 million is included in Accrued and other current liabilities and Accounts payable and $19 million is included in Other liabilities in the Company's Consolidated Balance Sheet.

[0000833444-14-000124:notes:33]
The majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. Prior to Tyco's acquisition, Ansul manufactured arsenic-based agricultural herbicides at the Marinette facility, which resulted in significant arsenic contamination of soil and groundwater on the Marinette site and in parts of the adjoining Menominee River. Ansul has been engaged in ongoing remediation efforts at the Marinette site since 1990, and in February 2009 entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the Marinette site. Under this agreement, Ansul's principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment.  As of September 26, 2014, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $27 million to $54 million. The Company's best estimate within that range is approximately $30 million, of which $18 million is included in Accrued and other current liabilities and $12 million is included in Other liabilities in the Company's Consolidated Balance Sheet. During the years ended September 26, 2014, September 27, 2013, and September 28, 2012, the Company recorded charges of nil, $100 million, and $17 million, respectively, in Selling, general and administrative expenses in the Consolidated Statement of Operations.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor the arsenic contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.

[0000833444-14-000124:notes:34]
Asbestos Matters

[0000833444-14-000124:notes:35]
The Company and certain of its subsidiaries, including Yarway Corporation (“Yarway”) and Grinnell LLC (“Grinnell”), along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. Over 90% of cases pending against affiliates of the Company have been filed against Yarway or Grinnell, and have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components. Claims filed against Yarway derive from Yarway’s purported use of asbestos-containing gaskets and packing in the sale or distribution of steam valves and traps and from its alleged manufacture of asbestos-containing expansion joint packing. Yarway’s alleged manufacture, distribution and/or sale of asbestos-containing materials ceased by 1988, and Yarway ceased substantially all of its manufacturing, distribution and sales operations in 2003. Claims filed against Grinnell typically allege that it manufactured, sold or distributed valves, gaskets, piping and sprinkler systems containing asbestos.

[0000833444-14-000124:notes:36]
As of September 26, 2014, the Company has determined that there were approximately 5,600 claims pending against it, which includes approximately 3,200 claims pending against Yarway. This amount reflects the Company's current estimate of the number of viable claims made against it and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties. Additionally, as a result of the Yarway bankruptcy filing described below, claims against Yarway have been stayed since April 2013.

[0000833444-14-000124:notes:37]
The following table summarizes the activity in the asset and liability accounts related to these asbestos matters for the year ended September 26, 2014 ($ in millions):

[0000833444-14-000124:notes:38]
|  |  | As of September 27, 2013 |  | (Charge)/Benefit |  | Payments/(Receipts) |  | As of September 26, 2014 |
| Yarway: |  |  |  |  |  |  |  |  |
| Insurance assets |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Gross asbestos liabilities |  | (90 | ) |  | (225 | ) |  | — |  |  | (315 | ) |
| Net liability position |  | $ | (90 | ) |  | $ | (225 | ) |  | $ | — |  |  | $ | (315 | ) |
| Other Claims: |  |  |  |  |  |  |  |  |
| Insurance assets |  | $ | 152 |  |  | $ | 93 |  |  | $ | — |  |  | $ | 245 |  |
| Gross asbestos liabilities |  | (231 | ) |  | (325 | ) |  | 18 |  |  | (538 | ) |
| Net liability position |  | $ | (79 | ) |  | $ | (232 | ) |  | $ | 18 |  |  | $ | (293 | ) |
| Total Tyco: |  |  |  |  |  |  |  |  |
| Insurance assets |  | $ | 152 |  |  | $ | 93 |  |  | $ | — |  |  | $ | 245 |  |
| Gross asbestos liabilities |  | (321 | ) |  | (550 | ) |  | 18 |  |  | (853 | ) |
| Total net liability position |  | $ | (169 | ) |  | $ | (457 | ) |  | $ | 18 |  |  | $ | (608 | ) |

[0000833444-14-000124:notes:39]
Yarway

[0000833444-14-000124:notes:40]
As previously disclosed, on April 22, 2013 Yarway filed a voluntary petition for relief under Chapter 11 of the U.S. Bankruptcy Code (“Chapter 11”) in the United States Bankruptcy Court for the District of Delaware (“Bankruptcy Court”). As a result of this filing, the continuation or commencement of asbestos-related litigation against Yarway has been enjoined by the automatic stay imposed by the U.S. Bankruptcy Code. Yarway's goal has been to negotiate, obtain approval of, and consummate a plan of reorganization that establishes a trust to fairly and equitably value and pay current and future Yarway asbestos claims, and that, in exchange for funding of the trust by the Company and/or its subsidiaries, provides permanent injunctive relief protecting the Company, each of its current and former affiliates and various other parties (the “Company Protected Parties”) from any further asbestos claims based on products manufactured, sold, and/or distributed by Yarway. On October 9, 2014, the Company reached an agreement in principle with Yarway, the Official Committee of Asbestos Claimants (“ACC”) appointed in the Yarway Chapter 11 case as the representative of current Yarway asbestos claimants, and the Future Claimants Representative (“FCR”) appointed in the Yarway Chapter 11 case as the representative of future Yarway asbestos claimants, to fund a section 524(g) trust for the resolution and payment of current and future Yarway asbestos claims. The agreement in principle, which will be implemented through a Chapter 11 plan for Yarway, will resolve the potential liability of the Company Protected Parties for pending and future derivative personal injury claims related to exposure to asbestos-containing products that were allegedly manufactured, distributed, and/or sold by Yarway (“Yarway Asbestos Claims”). Under the Chapter 11 plan, an asbestos settlement trust (the “Yarway Trust”) that conforms to the provisions of Section 524(g) of the U.S. Bankruptcy Code will be established and, on the effective date of the Chapter 11 plan, the Company and Yarway will contribute to the Yarway Trust a total of $325 million in cash (“Settlement Consideration”), which includes approximately $100 million relating to the settlement of intercompany amounts allegedly due to Yarway. In exchange for the Settlement Consideration, each of the Company Protected Parties will receive the benefit of a release from Yarway and an injunction under section 524(g) of the Bankruptcy Code permanently enjoining the assertion of Yarway Asbestos Claims against those Parties. The agreement in principle is subject, among other things, to the negotiation and filing of a Chapter 11 plan of reorganization for Yarway incorporating the terms of such agreement (the “Plan”), acceptance of the Plan by at least 75% of Yarway’s current asbestos claimants voting on such Plan, confirmation of the Plan by the Bankruptcy Court and approval of the injunction in favor of the Company Protected Parties by the United States District Court for the District of Delaware (“District Court”). On the effective date of the Plan, which is anticipated to occur in the second half of fiscal 2015, the Company and Yarway will pay the Settlement Consideration and Yarway Asbestos Claims against the Company Protected Parties will be permanently enjoined. Yarway is anticipated to become a wholly-owned subsidiary of the Yarway Trust and, accordingly, would no longer be owned by or be part of a consolidated group with the Company. Unless extended by a further agreement, the agreement in principle will expire if the order confirming the Plan and implementing the injunction has not been entered or affirmed by the District Court by April 30, 2015, or if the effective date of the Plan has not occurred by September 15, 2016. As a result of the agreement in principle to settle, the Company has recorded a charge of $225 million in Selling, general and administrative expenses in the Consolidated Statement of Operations during the fourth fiscal quarter of 2014.

[0000833444-14-000124:notes:41]
As a result of filing the voluntary bankruptcy petition during the third quarter of fiscal 2013, the Company recorded an expected loss upon deconsolidation of $10 million related to the Yarway Chapter 11 filing, which continues to represent the Company’s best estimate of its loss.

[0000833444-14-000124:notes:42]
Other Claims

[0000833444-14-000124:notes:43]
The Company continuously assesses the sufficiency of its estimated liability for pending and future asbestos claims and defense costs. On a quarterly basis, the Company evaluates actual experience regarding asbestos claims filed, settled and dismissed, amounts paid in settlements, and the recoverability of its insurance assets. If and when data from actual experience demonstrate an unfavorable discernible trend, the Company performs a valuation of its asbestos related liabilities and corresponding insurance assets including a comprehensive review of the underlying assumptions. In addition, the Company evaluates its ability to reasonably estimate claim activity beyond its current look-forward period in order to assess whether such period is appropriate. In addition to claims and litigation experience, the Company considers additional qualitative and quantitative factors such as changes in legislation, the legal environment, the Company’s strategy in managing claims and obtaining insurance, including its defense strategy, and health related trends in the overall population of individuals potentially exposed to asbestos. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance assets is warranted.

[0000833444-14-000124:notes:44]
During the fourth quarter of fiscal 2014, the Company concluded that an unfavorable trend had developed in actual claim filing activity compared to projected claim filing activity established during the Company’s most recent valuation. Accordingly, the Company, with the assistance of independent actuarial service providers, performed a revised valuation of its asbestos-related liabilities and corresponding insurance assets. As part of the revised valuation, the Company assessed whether a change in its look-forward period was appropriate, taking into consideration its more extensive history and experience with asbestos-related claims and litigation (including its experience with Yarway), and determined that it was now possible to make a reasonable estimate of the actuarially determined ultimate risk of loss for pending and unasserted potential future asbestos-related claims through 2056. In connection with the revised valuation, the Company considered a recent settlement with one of its insurers calling for the establishment of a qualified settlement fund, and the results of a separate independent actuarial consulting firm report conducted in the fourth quarter to assist the Company in obtaining insurance to fully fund all estimable asbestos-related claims (excluding Yarway claims) incurred through 2056.

[0000833444-14-000124:notes:45]
The independent actuarial service firm calculated a total estimated liability for asbestos-related claims of the Company, which reflects the Company’s best estimate of its ultimate risk of loss to resolve all pending and future claims (excluding Yarway claims) through 2056, which is the Company’s reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates.

[0000833444-14-000124:notes:46]
In conjunction with determining the total estimated liability, the Company retained an independent third party to assist it in valuing its insurance assets responsive to asbestos-related claims, excluding Yarway claims. These insurance assets represent amounts due to the Company for previously settled claims and the probable reimbursements relating to its total liability for pending and unasserted potential future asbestos claims and defense costs. In calculating this amount, the Company used the estimated asbestos liability for pending and projected future claims and defense costs described above, and it also considered the amount of insurance available, the solvency risk with respect to the Company's insurance carriers, resolution of insurance coverage issues, gaps in coverage, allocation methodologies, and the terms of existing settlement agreements with insurance carriers.

[0000833444-14-000124:notes:47]
As a result of the activity described above, the Company recorded a net charge, in addition to the amounts described above for Yarway, of $240 million in Selling, general and administrative expenses in the Consolidated Statement of Operations during the quarter ended September 26, 2014. Although the Company’s methodology established a range of estimates of reasonably possible outcomes, the Company recorded its best estimate within such range based upon currently known information. The Company's estimated gross asbestos liability, excluding Yarway, of $538 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs, and separately as an asset for insurance recoveries of $245 million. The aforementioned total estimated liability is on a pre-tax basis, not discounted for the time-value of money, and includes defense costs, which is consistent with the Company’s historical accounting practices.

[0000833444-14-000124:notes:48]
The effect of the change in our look-forward period reduced income from continuing operations before income taxes and net income by approximately $116 million and $71 million, respectively.  In addition, the effect of the change decreased the Company's basic income from continuing operations and net income by $0.16 per share, and decreased  the Company's diluted income from continuing operations and net income by $0.15 per share.

[0000833444-14-000124:notes:49]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-14-000124:notes:50]
In connection with the foregoing, during the third quarter of fiscal 2014, the Company resolved disputes with certain of its historical insurers and agreed that certain insurance proceeds will be used to establish and fund a qualified settlement fund (“QSF”), within the meaning of the Internal Revenue Code, which will be used for the resolution of asbestos liabilities of the Company, other than Yarway asbestos claims. It is intended that the QSF will receive future insurance payments and proceeds from third party insurers and, in addition, will fund and manage liabilities for certain historical operations  of the Company. In addition, the Company expects to make cash contributions to the QSF structure within the next 12 months of approximately $275 million to purchase insurance that will be dedicated to, and is expected to fully fund, these liabilities.

[0000833444-14-000124:notes:51]
Tax Matters

[0000833444-14-000124:notes:52]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation. The issues and proposed adjustments related to such years are generally subject to the sharing provisions of a tax sharing agreement entered in 2007 with Covidien and TE Connectivity (the "2007 Tax Sharing Agreement") under which Tyco, Covidien and TE Connectivity share 27%, 42% and 31%, respectively, of shared income tax liabilities that arise from adjustments made by tax authorities to Tyco's, Covidien's and TE Connectivity's U.S. and certain non-U.S. income tax returns. The costs and expenses associated with the management of these shared tax liabilities are generally shared equally among the parties. Tyco has previously disclosed that in connection with U.S. federal tax audits, the IRS has raised a number of issues and proposed tax adjustments for periods beginning with the 1997 tax year. Although Tyco has been able to resolve substantially all of the issues and adjustments proposed by the IRS for tax years through 2007, it has not been able to resolve matters related to the treatment of certain intercompany debt transactions during the period. As a result, on June 20, 2013, Tyco received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owe additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million is expected to be asserted. These amounts exclude interest and do not reflect the impact on subsequent periods if the IRS position described below is ultimately proved correct.

[0000833444-14-000124:notes:53]
The IRS asserted in the Notices of Deficiency that substantially all of Tyco's intercompany debt originated during the 1997 - 2000 period should not be treated as debt for U.S. federal income tax purposes, and has disallowed interest and related deductions recognized on U.S. income tax returns totaling approximately $2.9 billion. Tyco strongly disagrees with the IRS position and has filed petitions with the U.S. Tax Court contesting the IRS proposed adjustments. A trial date has been set for February 2016. Tyco believes that it has meritorious defenses for its tax filings, that the IRS positions with regard to these matters are inconsistent with the applicable tax laws and existing Treasury regulations, and that the previously reported taxes for the years in question are appropriate.

[0000833444-14-000124:notes:54]
No payments with respect to these matters would be required until the dispute is definitively resolved, which, based on the experience of other companies, could take several years. Tyco believes that its income tax reserves and the liabilities recorded in the Consolidated Balance Sheet for the tax sharing agreements continue to be appropriate. However, the ultimate resolution of these matters, and the impact of that resolution, are uncertain and could have a material impact on Tyco's financial condition, results of operations and cash flows. In particular, if the IRS is successful in asserting its claim, it would have an adverse impact on interest deductions related to the same intercompany debt in subsequent time periods, totaling approximately $6.6 billion, which is expected to be disallowed by the IRS.

[0000833444-14-000124:notes:55]
See Note 6 for additional information related to income tax matters.

[0000833444-14-000124:notes:56]
Other Matters

[0000833444-14-000124:notes:57]
During the fourth quarter of fiscal 2012, Tyco disclosed the improper recording of revenue in the Company's ROW Installation & Services segment related to security contracts in China.  The Company pursued collection under its insurance policy and in the second fiscal quarter of 2014, the Company recorded a $21 million insurance recovery within the ROW Installation & Services segment as a result of a settlement with the insurance carrier.  The insurance recovery was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations.

[0000833444-14-000124:notes:58]
During the first quarter of fiscal 2014, Tyco settled a tax dispute with its former subsidiary, CIT Group, Inc. ("CIT").  Under the terms of the settlement agreement, Tyco received $60 million during the first quarter of 2014, which was subject to the sharing provisions of the 2007 Tax Sharing Agreement. As a result, the Company recorded a $16 million gain in Selling, general and administrative expenses in the Consolidated Statement of Operations and established payables of $25 million and $19 million due to Covidien and TE Connectivity, respectively, as of December 27, 2013. The Company paid these amounts to Covidien and TE Connectivity during the second fiscal quarter of 2014.

[0000833444-14-000124:notes:59]
SimplexGrinnell LP (“SG”), a subsidiary of the Company in the North America Installation & Services segment, has been named as a defendant in several lawsuits seeking damages for SG’s alleged failure to pay prevailing wages in connection with work performed on state and local municipal projects.   In New York, the U.S. District Court had granted SG’s  motion for summary judgment dismissing plaintiffs’ claims for prevailing wages on testing and inspection work, which was based primarily on a 2009 opinion of the New York Department of Labor (“DOL”) that testing and inspection work would be considered covered by the prevailing wage law only on a prospective basis.   Plaintiffs appealed this decision to the U.S. Court of Appeals for the Second Circuit, which in turn asked the NY Court of Appeals whether the lower court should have given deference to the DOL’s prospective-only application of law.  The NY Court of Appeals recently ruled that the lower court did not have to give deference to the DOL based on an amicus brief submitted by the DOL in which it stated the Court need not have given it deference.  As a result, the Company recorded a $10 million charge in Cost of services in the Consolidated Statement of Operations during the fourth quarter of fiscal 2014. SG also is a defendant in two other lawsuits related to prevailing wages in New Jersey and California.   SG has agreed in principle to settle the California lawsuit for approximately $5 million subject to Court approval, which the Company had previously reserved.

[0000833444-14-000124:notes:60]
In November 2014, the Company received and responded to recent inquiries from the US Department of the Navy regarding the formulation of certain aqueous film forming foam (AFFF) concentrates.  The Company is investigating such matters and ceased selling certain AFFF and other foam products pending the outcome of its investigation.  One AFFF product has been removed from the Navy’s Qualified Products List (QPL).  The Company is in communication with appropriate governmental authorities about its investigation and is also communicating with the government regarding the qualification of these products.  At this time, we cannot predict the outcome of these inquiries and whether this will result in further action by the Navy or other governmental authorities, but it is possible that the Company could be required to pay material fines, consent to injunctions on future conduct, experience suspension or debarment from government contracts, or suffer other criminal or civil penalties or adverse impacts, including being subject to lawsuits brought by private litigants, each of which may have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-14-000124:notes:61]
In addition to the foregoing, the Company is subject to claims and suits, including from time to time, contractual disputes and product and general liability claims, incidental to present and former operations, acquisitions and dispositions. With respect to many of these claims, the Company either self-insures or maintains insurance through third-parties, with varying deductibles. While the ultimate outcome of these matters cannot be predicted with certainty, the Company believes that the resolution of any such proceedings, whether the underlying claims are covered by insurance or not, will not have a material adverse effect on the Company's financial condition, results of operations or cash flows beyond amounts recorded for such matters.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-14-000124:notes:62]
Tyco International Finance S.A.

[0000833444-14-000124:notes:63]
TIFSA, a 100% owned subsidiary of the Company, has public debt securities outstanding which are fully and unconditionally guaranteed by Tyco. See Note 10 for additional information. The following tables present condensed consolidating financial information for Tyco, TIFSA and all other subsidiaries. Condensed financial information for Tyco and TIFSA on a stand-alone basis is presented using the equity method of accounting for subsidiaries.

[0000833444-14-000124:notes:64]
CONDENSED CONSOLIDATING STATEMENT OF OPERATIONS

[0000833444-14-000124:notes:65]
For the Year Ended September 26, 2014

[0000833444-14-000124:notes:66]
($ in millions)

[0000833444-14-000124:notes:67]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | 10,340 |  |  | $ | — |  |  | $ | 10,340 |  |
| Cost of product sales | — |  |  | — |  |  | 4,253 |  |  | — |  |  | 4,253 |  |
| Cost of services | — |  |  | — |  |  | 2,302 |  |  | — |  |  | 2,302 |  |
| Selling, general and administrative expenses | (7 | ) |  | 4 |  |  | 3,043 |  |  | — |  |  | 3,040 |  |
| Separation costs | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | 47 |  |  | — |  |  | 47 |  |
| Operating income (loss) | 7 |  |  | (4 | ) |  | 694 |  |  | — |  |  | 697 |  |
| Interest income | — |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Interest expense | — |  |  | (95 | ) |  | (2 | ) |  | — |  |  | (97 | ) |
| Other (expense) income, net | (6 | ) |  | — |  |  | 5 |  |  | — |  |  | (1 | ) |
| Equity in net income of subsidiaries | 1,866 |  |  | 1,761 |  |  | — |  |  | (3,627 | ) |  | — |  |
| Intercompany interest and fees | (28 | ) |  | 105 |  |  | (72 | ) |  | (5 | ) |  | — |  |
| Income from continuing operations before income taxes | 1,839 |  |  | 1,767 |  |  | 639 |  |  | (3,632 | ) |  | 613 |  |
| Income tax benefit (expense) | 1 |  |  | (1 | ) |  | (24 | ) |  | — |  |  | (24 | ) |
| Equity gain in earnings of unconsolidated subsidiaries | — |  |  | — |  |  | 206 |  |  | — |  |  | 206 |  |
| Income from continuing operations | 1,840 |  |  | 1,766 |  |  | 821 |  |  | (3,632 | ) |  | 795 |  |
| (Loss) income from discontinued operations, net of income taxes | (2 | ) |  | — |  |  | 1,041 |  |  | 5 |  |  | 1,044 |  |
| Net income | 1,838 |  |  | 1,766 |  |  | 1,862 |  |  | (3,627 | ) |  | 1,839 |  |
| Less: noncontrolling interest in subsidiaries net income | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net income attributable to Tyco common shareholders | $ | 1,838 |  |  | $ | 1,766 |  |  | $ | 1,861 |  |  | $ | (3,627 | ) |  | $ | 1,838 |  |

[0000833444-14-000124:notes:68]
CONDENSED CONSOLIDATING STATEMENT OF COMPREHENSIVE INCOME

[0000833444-14-000124:notes:69]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 1,838 |  |  | $ | 1,766 |  |  | $ | 1,862 |  |  | $ | (3,627 | ) |  | $ | 1,839 |  |
| Other comprehensive loss, net of tax |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (174 | ) |  | — |  |  | (174 | ) |  | 174 |  |  | (174 | ) |
| Defined benefit and post retirement plans | (64 | ) |  | — |  |  | (64 | ) |  | 64 |  |  | (64 | ) |
| Total other comprehensive loss, net of tax | (238 | ) |  | — |  |  | (238 | ) |  | 238 |  |  | (238 | ) |
| Comprehensive income | 1,600 |  |  | 1,766 |  |  | 1,624 |  |  | (3,389 | ) |  | 1,601 |  |
| Less: comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Comprehensive income attributable to Tyco common shareholders | $ | 1,600 |  |  | $ | 1,766 |  |  | $ | 1,623 |  |  | $ | (3,389 | ) |  | $ | 1,600 |  |

[0000833444-14-000124:notes:70]
For the Year Ended September 27, 2013

[0000833444-14-000124:notes:71]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | 10,073 |  |  | $ | — |  |  | $ | 10,073 |  |
| Cost of product sales | — |  |  | — |  |  | 3,990 |  |  | — |  |  | 3,990 |  |
| Cost of services | — |  |  | — |  |  | 2,412 |  |  | — |  |  | 2,412 |  |
| Selling, general and administrative expenses | 11 |  |  | 1 |  |  | 2,831 |  |  | — |  |  | 2,843 |  |
| Separation costs | 3 |  |  | — |  |  | 5 |  |  | — |  |  | 8 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | 111 |  |  | — |  |  | 111 |  |
| Operating (loss) income | (14 | ) |  | (1 | ) |  | 724 |  |  | — |  |  | 709 |  |
| Interest income | 2 |  |  | — |  |  | 14 |  |  | — |  |  | 16 |  |
| Interest expense | (1 | ) |  | (95 | ) |  | (4 | ) |  | — |  |  | (100 | ) |
| Other (expense) income, net | (31 | ) |  | — |  |  | 2 |  |  | — |  |  | (29 | ) |
| Equity in net (loss) income of subsidiaries | (12,666 | ) |  | 575 |  |  | — |  |  | 12,091 |  |  | — |  |
| Intercompany interest and fees | 13,248 |  |  | 122 |  |  | (13,362 | ) |  | (8 | ) |  | — |  |
| Income (loss) from continuing operations before income taxes | 538 |  |  | 601 |  |  | (12,626 | ) |  | 12,083 |  |  | 596 |  |
| Income tax expense | (2 | ) |  | (2 | ) |  | (104 | ) |  | — |  |  | (108 | ) |
| Equity loss in earnings of unconsolidated subsidiaries | — |  |  | — |  |  | (48 | ) |  | — |  |  | (48 | ) |
| Income (loss) from continuing operations | 536 |  |  | 599 |  |  | (12,778 | ) |  | 12,083 |  |  | 440 |  |
| Income from discontinued operations, net of income taxes | — |  |  | — |  |  | 85 |  |  | 8 |  |  | 93 |  |
| Net income (loss) | 536 |  |  | 599 |  |  | (12,693 | ) |  | 12,091 |  |  | 533 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Net income (loss) attributable to Tyco common shareholders | $ | 536 |  |  | $ | 599 |  |  | $ | (12,690 | ) |  | $ | 12,091 |  |  | $ | 536 |  |

[0000833444-14-000124:notes:72]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income (loss) | $ | 536 |  |  | $ | 599 |  |  | $ | (12,693 | ) |  | $ | 12,091 |  |  | $ | 533 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (100 | ) |  | — |  |  | (100 | ) |  | 100 |  |  | (100 | ) |
| Defined benefit and post retirement plans | 79 |  |  | — |  |  | 79 |  |  | (79 | ) |  | 79 |  |
| Total other comprehensive loss, net of tax | (21 | ) |  | — |  |  | (21 | ) |  | 21 |  |  | (21 | ) |
| Comprehensive income (loss) | 515 |  |  | 599 |  |  | (12,714 | ) |  | 12,112 |  |  | 512 |  |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Comprehensive income (loss) attributable to Tyco common shareholders | $ | 515 |  |  | $ | 599 |  |  | $ | (12,711 | ) |  | $ | 12,112 |  |  | $ | 515 |  |

[0000833444-14-000124:notes:73]
For the Year Ended September 28, 2012

[0000833444-14-000124:notes:74]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | 9,892 |  |  | $ | — |  |  | $ | 9,892 |  |
| Cost of product sales | — |  |  | — |  |  | 3,905 |  |  | — |  |  | 3,905 |  |
| Cost of services | — |  |  | — |  |  | 2,411 |  |  | — |  |  | 2,411 |  |
| Selling, general and administrative expenses | 15 |  |  | 15 |  |  | 2,793 |  |  | — |  |  | 2,823 |  |
| Separation costs | 3 |  |  | 1 |  |  | 67 |  |  | — |  |  | 71 |  |
| Restructuring and asset impairment charges, net | 1 |  |  | — |  |  | 103 |  |  | — |  |  | 104 |  |
| Operating (loss) income | (19 | ) |  | (16 | ) |  | 613 |  |  | — |  |  | 578 |  |
| Interest income | — |  |  | — |  |  | 18 |  |  | — |  |  | 18 |  |
| Interest expense | — |  |  | (204 | ) |  | (5 | ) |  | — |  |  | (209 | ) |
| Other (expense) income, net | (4 | ) |  | (453 | ) |  | 3 |  |  | — |  |  | (454 | ) |
| Equity in net income of subsidiaries | 913 |  |  | 1,065 |  |  | — |  |  | (1,978 | ) |  | — |  |
| Intercompany interest and fees | (412 | ) |  | 282 |  |  | 230 |  |  | (100 | ) |  | — |  |
| Income (loss) from continuing operations before income taxes | 478 |  |  | 674 |  |  | 859 |  |  | (2,078 | ) |  | (67 | ) |
| Income tax expense | (2 | ) |  | (2 | ) |  | (316 | ) |  | — |  |  | (320 | ) |
| Equity loss in earnings of unconsolidated subsidiaries | — |  |  | — |  |  | (26 | ) |  | — |  |  | (26 | ) |
| Income (loss) from continuing operations | 476 |  |  | 672 |  |  | 517 |  |  | (2,078 | ) |  | (413 | ) |
| (Loss) income from discontinued operations, net of income taxes | (4 | ) |  | — |  |  | 788 |  |  | 100 |  |  | 884 |  |
| Net income | 472 |  |  | 672 |  |  | 1,305 |  |  | (1,978 | ) |  | 471 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net income attributable to Tyco common shareholders | $ | 472 |  |  | $ | 672 |  |  | $ | 1,306 |  |  | $ | (1,978 | ) |  | $ | 472 |  |

[0000833444-14-000124:notes:75]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 472 |  |  | $ | 672 |  |  | $ | 1,305 |  |  | $ | (1,978 | ) |  | $ | 471 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | 93 |  |  | 11 |  |  | 82 |  |  | (93 | ) |  | 93 |  |
| Defined benefit and post retirement plans | (163 | ) |  | — |  |  | (163 | ) |  | 163 |  |  | (163 | ) |
| Total other comprehensive (loss) income, net of tax | (70 | ) |  | 11 |  |  | (81 | ) |  | 70 |  |  | (70 | ) |
| Comprehensive income | 402 |  |  | 683 |  |  | 1,224 |  |  | (1,908 | ) |  | 401 |  |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Comprehensive income attributable to Tyco common shareholders | $ | 402 |  |  | $ | 683 |  |  | $ | 1,225 |  |  | $ | (1,908 | ) |  | $ | 402 |  |

[0000833444-14-000124:notes:76]
CONDENSED CONSOLIDATING BALANCE SHEET

[0000833444-14-000124:notes:77]
As of September 26, 2014

[0000833444-14-000124:notes:78]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | 892 |  |  | $ | — |  |  | $ | 892 |  |
| Accounts receivable, net | — |  |  | — |  |  | 1,750 |  |  | — |  |  | 1,750 |  |
| Inventories | — |  |  | — |  |  | 628 |  |  | — |  |  | 628 |  |
| Intercompany receivables | 18 |  |  | 245 |  |  | 8,102 |  |  | (8,365 | ) |  | — |  |
| Prepaid expenses and other current assets | 7 |  |  | 62 |  |  | 1,084 |  |  | — |  |  | 1,153 |  |
| Deferred income taxes | — |  |  | — |  |  | 307 |  |  | — |  |  | 307 |  |
| Assets held for sale | — |  |  | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Total current assets | 25 |  |  | 307 |  |  | 12,784 |  |  | (8,365 | ) |  | 4,751 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | 1,269 |  |  | — |  |  | 1,269 |  |
| Goodwill | — |  |  | — |  |  | 4,126 |  |  | — |  |  | 4,126 |  |
| Intangible assets, net | — |  |  | — |  |  | 737 |  |  | — |  |  | 737 |  |
| Investment in subsidiaries | 12,738 |  |  | 16,258 |  |  | — |  |  | (28,996 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | 3,693 |  |  | 5,346 |  |  | (9,039 | ) |  | — |  |
| Other assets | 26 |  |  | 4 |  |  | 896 |  |  | — |  |  | 926 |  |
| Total Assets | $ | 12,789 |  |  | $ | 20,262 |  |  | $ | 25,158 |  |  | $ | (46,400 | ) |  | $ | 11,809 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |
| Accounts payable | 1 |  |  | — |  |  | 870 |  |  | — |  |  | 871 |  |
| Accrued and other current liabilities | 191 |  |  | 23 |  |  | 1,953 |  |  | — |  |  | 2,167 |  |
| Deferred revenue | — |  |  | — |  |  | 400 |  |  | — |  |  | 400 |  |
| Intercompany payables | 3,517 |  |  | 4,593 |  |  | 255 |  |  | (8,365 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Total current liabilities | 3,709 |  |  | 4,616 |  |  | 3,511 |  |  | (8,365 | ) |  | 3,471 |  |
| Long-term debt | — |  |  | 1,441 |  |  | 2 |  |  | — |  |  | 1,443 |  |
| Intercompany loans payable | 4,180 |  |  | 1,888 |  |  | 2,971 |  |  | (9,039 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | 335 |  |  | — |  |  | 335 |  |
| Other liabilities | 253 |  |  | — |  |  | 1,624 |  |  | — |  |  | 1,877 |  |
| Total Liabilities | 8,142 |  |  | 7,945 |  |  | 8,443 |  |  | (17,404 | ) |  | 7,126 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |
| Common shares | 208 |  |  | — |  |  | — |  |  | — |  |  | 208 |  |
| Common shares held in treasury | — |  |  | — |  |  | (2,515 | ) |  | — |  |  | (2,515 | ) |
| Other shareholders' equity | 4,439 |  |  | 12,317 |  |  | 19,194 |  |  | (28,996 | ) |  | 6,954 |  |
| Total Tyco Shareholders' Equity | 4,647 |  |  | 12,317 |  |  | 16,679 |  |  | (28,996 | ) |  | 4,647 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Total Equity | 4,647 |  |  | 12,317 |  |  | 16,702 |  |  | (28,996 | ) |  | 4,670 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity | $ | 12,789 |  |  | $ | 20,262 |  |  | $ | 25,158 |  |  | $ | (46,400 | ) |  | $ | 11,809 |  |

[0000833444-14-000124:notes:79]
As of September 27, 2013

[0000833444-14-000124:notes:80]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | 563 |  |  | $ | — |  |  | $ | 563 |  |
| Accounts receivable, net | — |  |  | — |  |  | 1,704 |  |  | — |  |  | 1,704 |  |
| Inventories | — |  |  | — |  |  | 645 |  |  | — |  |  | 645 |  |
| Intercompany receivables | 22 |  |  | 2,079 |  |  | 7,354 |  |  | (9,455 | ) |  | — |  |
| Prepaid expenses and other current assets | 9 |  |  | — |  |  | 830 |  |  | — |  |  | 839 |  |
| Deferred income taxes | — |  |  | — |  |  | 250 |  |  | — |  |  | 250 |  |
| Assets held for sale | — |  |  | — |  |  | 856 |  |  | — |  |  | 856 |  |
| Total current assets | 31 |  |  | 2,079 |  |  | 12,202 |  |  | (9,455 | ) |  | 4,857 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | 1,284 |  |  | — |  |  | 1,284 |  |
| Goodwill | — |  |  | — |  |  | 4,162 |  |  | — |  |  | 4,162 |  |
| Intangible assets, net | — |  |  | — |  |  | 791 |  |  | — |  |  | 791 |  |
| Investment in subsidiaries | 12,826 |  |  | 14,690 |  |  | — |  |  | (27,516 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | 1,141 |  |  | 5,310 |  |  | (6,451 | ) |  | — |  |
| Other assets | 68 |  |  | 6 |  |  | 1,008 |  |  | — |  |  | 1,082 |  |
| Total Assets | $ | 12,925 |  |  | $ | 17,916 |  |  | $ | 24,757 |  |  | $ | (43,422 | ) |  | $ | 12,176 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |
| Accounts payable | 1 |  |  | — |  |  | 847 |  |  | — |  |  | 848 |  |
| Accrued and other current liabilities | 353 |  |  | 23 |  |  | 1,476 |  |  | — |  |  | 1,852 |  |
| Deferred revenue | — |  |  | — |  |  | 393 |  |  | — |  |  | 393 |  |
| Intercompany payables | 3,515 |  |  | 3,845 |  |  | 2,095 |  |  | (9,455 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | 236 |  |  | — |  |  | 236 |  |
| Total current liabilities | 3,869 |  |  | 3,868 |  |  | 5,067 |  |  | (9,455 | ) |  | 3,349 |  |
| Long-term debt | — |  |  | 1,443 |  |  | — |  |  | — |  |  | 1,443 |  |
| Intercompany loans payable | 3,660 |  |  | 1,852 |  |  | 939 |  |  | (6,451 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | 370 |  |  | — |  |  | 370 |  |
| Other liabilities | 298 |  |  | — |  |  | 1,583 |  |  | — |  |  | 1,881 |  |
| Total Liabilities | 7,827 |  |  | 7,163 |  |  | 7,959 |  |  | (15,906 | ) |  | 7,043 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |
| Common shares | 208 |  |  | — |  |  | — |  |  | — |  |  | 208 |  |
| Common shares held in treasury | — |  |  | — |  |  | (912 | ) |  | — |  |  | (912 | ) |
| Other shareholders' equity | 4,890 |  |  | 10,753 |  |  | 17,675 |  |  | (27,516 | ) |  | 5,802 |  |
| Total Tyco Shareholders' Equity | 5,098 |  |  | 10,753 |  |  | 16,763 |  |  | (27,516 | ) |  | 5,098 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Total Equity | 5,098 |  |  | 10,753 |  |  | 16,786 |  |  | (27,516 | ) |  | 5,121 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity | $ | 12,925 |  |  | $ | 17,916 |  |  | $ | 24,757 |  |  | $ | (43,422 | ) |  | $ | 12,176 |  |

[0000833444-14-000124:notes:81]
CONDENSED CONSOLIDATING STATEMENT OF CASH FLOWS

[0000833444-14-000124:notes:82]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (205 | ) |  | $ | 592 |  |  | $ | 444 |  |  | $ | — |  |  | $ | 831 |  |
| Net cash provided by discontinued operating activities | — |  |  | — |  |  | 81 |  |  | — |  |  | 81 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | (288 | ) |  | — |  |  | (288 | ) |
| Proceeds from disposal of assets | — |  |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (65 | ) |  | — |  |  | (65 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | (25 | ) |  | — |  |  | (25 | ) |
| Divestiture of businesses, net of cash divested | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net increase in intercompany loans | — |  |  | (521 | ) |  | — |  |  | 521 |  |  | — |  |
| (Increase) decrease in investment in subsidiaries | (4 | ) |  | (9 | ) |  | 4 |  |  | 9 |  |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | 283 |  |  | — |  |  | 283 |  |
| Purchases of investments | — |  |  | (62 | ) |  | (324 | ) |  | — |  |  | (386 | ) |
| Sale of equity investment | — |  |  | — |  |  | 250 |  |  | — |  |  | 250 |  |
| Decrease in restricted cash | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Other | — |  |  | — |  |  | (4 | ) |  | — |  |  | (4 | ) |
| Net cash used in investing activities | (4 | ) |  | (592 | ) |  | (155 | ) |  | 530 |  |  | (221 | ) |
| Net cash provided by discontinued investing activities | — |  |  | — |  |  | 1,789 |  |  | — |  |  | 1,789 |  |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt | — |  |  | 830 |  |  | — |  |  | — |  |  | 830 |  |
| Repayments of short-term debt | — |  |  | (830 | ) |  | (1 | ) |  | — |  |  | (831 | ) |
| Proceeds from exercise of share options | — |  |  | — |  |  | 91 |  |  | — |  |  | 91 |  |
| Dividends paid | (311 | ) |  | — |  |  | — |  |  | — |  |  | (311 | ) |
| Repurchase of common shares by treasury | — |  |  | — |  |  | (1,833 | ) |  | — |  |  | (1,833 | ) |
| Net intercompany loan borrowings | 520 |  |  | — |  |  | 1 |  |  | (521 | ) |  | — |  |
| Increase in equity from parent | — |  |  | — |  |  | 9 |  |  | (9 | ) |  | — |  |
| Purchase of noncontrolling interest |  |  |  |  |  |  | (66 | ) |  |  |  |  | (66 | ) |
| Transfer from discontinued operations | — |  |  | — |  |  | 1,870 |  |  | — |  |  | 1,870 |  |
| Other | — |  |  | — |  |  | (11 | ) |  | — |  |  | (11 | ) |
| Net cash provided by (used in) financing activities | 209 |  |  | — |  |  | 60 |  |  | (530 | ) |  | (261 | ) |
| Net cash used in discontinued financing activities | — |  |  | — |  |  | (1,870 | ) |  | — |  |  | (1,870 | ) |
| Effect of currency translation on cash | — |  |  | — |  |  | (20 | ) |  | — |  |  | (20 | ) |
| Net increase in cash and cash equivalents | — |  |  | — |  |  | 329 |  |  | — |  |  | 329 |  |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | 563 |  |  | — |  |  | 563 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | 892 |  |  | $ | — |  |  | $ | 892 |  |

[0000833444-14-000124:notes:83]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (251 | ) |  | $ | 452 |  |  | $ | 493 |  |  | $ | — |  |  | $ | 694 |  |
| Net cash provided by discontinued operating activities | — |  |  | — |  |  | 156 |  |  | — |  |  | 156 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | (270 | ) |  | — |  |  | (270 | ) |
| Proceeds from disposal of assets | — |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (229 | ) |  | — |  |  | (229 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | (19 | ) |  | — |  |  | (19 | ) |
| Divestiture of businesses, net of cash divested | — |  |  | — |  |  | 17 |  |  | — |  |  | 17 |  |
| Intercompany dividend from subsidiary | — |  |  | 32 |  |  | — |  |  | (32 | ) |  | — |  |
| Net increase in intercompany loans | — |  |  | (431 | ) |  | — |  |  | 431 |  |  | — |  |
| Decrease in investment in subsidiaries | — |  |  | 8 |  |  | — |  |  | (8 | ) |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | 182 |  |  | — |  |  | 182 |  |
| Purchases of investments | — |  |  | — |  |  | (227 | ) |  | — |  |  | (227 | ) |
| Increase in restricted cash | — |  |  | — |  |  | (8 | ) |  | — |  |  | (8 | ) |
| Other | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Net cash used in investing activities | — |  |  | (391 | ) |  | (545 | ) |  | 391 |  |  | (545 | ) |
| Net cash used in discontinued investing activities | — |  |  | — |  |  | (110 | ) |  | — |  |  | (110 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short term debt | — |  |  | 475 |  |  | — |  |  | — |  |  | 475 |  |
| Repayment of short term debt | — |  |  | (475 | ) |  | (30 | ) |  | — |  |  | (505 | ) |
| Proceeds from exercise of share options | — |  |  | — |  |  | 153 |  |  | — |  |  | 153 |  |
| Dividends paid | (288 | ) |  | — |  |  | — |  |  | — |  |  | (288 | ) |
| Intercompany dividend to parent | — |  |  | — |  |  | (32 | ) |  | 32 |  |  | — |  |
| Repurchase of common shares by treasury | — |  |  | — |  |  | (300 | ) |  | — |  |  | (300 | ) |
| Net intercompany loan borrowings (repayments) | 449 |  |  | — |  |  | (18 | ) |  | (431 | ) |  | — |  |
| Decrease in equity from parent | — |  |  | — |  |  | (8 | ) |  | 8 |  |  | — |  |
| Transfer from (to) discontinued operations | 90 |  |  | (61 | ) |  | 47 |  |  | — |  |  | 76 |  |
| Other | — |  |  | — |  |  | (30 | ) |  | — |  |  | (30 | ) |
| Net cash provided by (used in) financing activities | 251 |  |  | (61 | ) |  | (218 | ) |  | (391 | ) |  | (419 | ) |
| Net cash used in discontinued financing activities | — |  |  | — |  |  | (76 | ) |  | — |  |  | (76 | ) |
| Effect of currency translation on cash | — |  |  | — |  |  | (11 | ) |  | — |  |  | (11 | ) |
| Net decrease in cash and cash equivalents | — |  |  | — |  |  | (311 | ) |  | — |  |  | (311 | ) |
| Less: net decrease in cash and cash equivalents related to discontinued operations | — |  |  | — |  |  | (30 | ) |  | — |  |  | (30 | ) |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | 844 |  |  | — |  |  | 844 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | 563 |  |  | $ | — |  |  | $ | 563 |  |

[0000833444-14-000124:notes:84]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (467 | ) |  | $ | 3,542 |  |  | $ | (2,519 | ) |  | $ | — |  |  | $ | 556 |  |
| Net cash provided by discontinued operating activities | — |  |  | — |  |  | 2,030 |  |  | — |  |  | 2,030 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | (295 | ) |  | — |  |  | (295 | ) |
| Proceeds from disposal of assets | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (217 | ) |  | — |  |  | (217 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | (23 | ) |  | — |  |  | (23 | ) |
| Divestiture of businesses, net of cash divested | — |  |  | — |  |  | (5 | ) |  | — |  |  | (5 | ) |
| Intercompany dividend from subsidiary | — |  |  | 409 |  |  | — |  |  | (409 | ) |  | — |  |
| Net increase in intercompany loans | — |  |  | (1,119 | ) |  | — |  |  | 1,119 |  |  | — |  |
| (Increase) decrease in investment in subsidiaries | (495 | ) |  | 207 |  |  | 16 |  |  | 272 |  |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | 128 |  |  | — |  |  | 128 |  |
| Purchases of investments | — |  |  | — |  |  | (87 | ) |  | — |  |  | (87 | ) |
| Increase in restricted cash | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Other | — |  |  | — |  |  | 27 |  |  | — |  |  | 27 |  |
| Net cash used in investing activities | (495 | ) |  | (503 | ) |  | (454 | ) |  | 982 |  |  | (470 | ) |
| Net cash used in discontinued investing activities | — |  |  | — |  |  | (1,327 | ) |  | 11 |  |  | (1,316 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short term debt | — |  |  | 2,008 |  |  | — |  |  | — |  |  | 2,008 |  |
| Repayment of short term debt | — |  |  | (2,008 | ) |  | (1 | ) |  | — |  |  | (2,009 | ) |
| Proceeds from issuance of long term debt | — |  |  | — |  |  | 19 |  |  | — |  |  | 19 |  |
| Repayment of long term debt | — |  |  | (3,039 | ) |  | (1 | ) |  | — |  |  | (3,040 | ) |
| Proceeds from exercise of share options | — |  |  | — |  |  | 226 |  |  | — |  |  | 226 |  |
| Dividends paid | (461 | ) |  | — |  |  | — |  |  | — |  |  | (461 | ) |
| Repurchase of common shares by treasury | — |  |  | — |  |  | (500 | ) |  | — |  |  | (500 | ) |
| Net intercompany loan borrowings (repayments) | 1,423 |  |  | — |  |  | (304 | ) |  | (1,119 | ) |  | — |  |
| Increase in equity from parent | — |  |  | — |  |  | 71 |  |  | (71 | ) |  | — |  |
| Transfer from discontinued operations | — |  |  | — |  |  | 3,099 |  |  | 208 |  |  | 3,307 |  |
| Other | — |  |  | — |  |  | (25 | ) |  | — |  |  | (25 | ) |
| Net cash provided by (used in) financing activities | 962 |  |  | (3,039 | ) |  | 2,584 |  |  | (982 | ) |  | (475 | ) |
| Net cash used in discontinued financing activities | — |  |  | — |  |  | (481 | ) |  | 197 |  |  | (284 | ) |
| Effect of currency translation on cash | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Effect of currency translation on cash related to discontinued operations | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Net (decrease) increase in cash and cash equivalents | — |  |  | — |  |  | (159 | ) |  | 208 |  |  | 49 |  |
| Less: net increase in cash and cash equivalents related to discontinued operations | — |  |  | — |  |  | 226 |  |  | 208 |  |  | 434 |  |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | 1,229 |  |  | — |  |  | 1,229 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | 844 |  |  | $ | — |  |  | $ | 844 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0000833444-14-000124:notes:85]
Principles of Consolidation—Tyco conducts business through its operating subsidiaries. The Company consolidates companies in which it owns or controls more than fifty percent of the voting shares or has the ability to control through similar rights. Also, the Company consolidates variable interest entities ("VIE") in which the Company has the power to direct the significant activities of the entity and the obligation to absorb losses or receive benefits from the entity that may be significant. The VIEs which the Company consolidates, individually or in the aggregate, did not have a material impact on the Company's financial position, results of operations or cash flows. All intercompany transactions have been eliminated. The results of companies acquired or disposed of during the year are included in the Consolidated Financial Statements from the effective date of acquisition or up to the date of disposal.

[0000833444-14-000124:notes:86]
The Company has a 52 or 53-week fiscal year that ends on the last Friday in September. Fiscal 2014, 2013 and 2012 were 52 week years which ended on September 26, 2014, September 27, 2013 and September 28, 2012, respectively.


## us-gaap:DebtDisclosureTextBlock

[0000833444-14-000124:notes:87]
Debt

[0000833444-14-000124:notes:88]
Debt as of September 26, 2014 and September 27, 2013 is as follows ($ in millions):

[0000833444-14-000124:notes:89]
|  | As ofSeptember 26,2014 |  | As ofSeptember 27,2013 |
| 3.375% public notes due 2015 | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | 364 |  |  | 364 |  |
| 7.0% public notes due 2019 | 245 |  |  | 246 |  |
| 6.875% public notes due 2021 | 465 |  |  | 466 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| Other(1) | 22 |  |  | 20 |  |
| Total debt | 1,463 |  |  | 1,463 |  |
| Less: current portion | 20 |  |  | 20 |  |
| Long-term debt | $ | 1,443 |  |  | $ | 1,443 |  |

[0000833444-14-000124:notes:90]
_______________________________________________________________________________

[0000833444-14-000124:notes:91]
| (1) | $20 million of the amount shown as other, comprises the current portion of the Company's total debt as of both September 26, 2014 and September 27, 2013. |

[0000833444-14-000124:notes:92]
Fair Value

[0000833444-14-000124:notes:93]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of September 26, 2014 and September 27, 2013 was $1,441 million and $1,443 million, respectively. The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets. As of September 26, 2014 and September 27, 2013, the fair value of the Company's debt which was actively traded was $1,670 million and $1,676 million, respectively. As of September 26, 2014 and September 27, 2013, the Company's debt that was subject to the fair value disclosure requirements was all actively traded and is classified as Level 1 in the fair value hierarchy. See Note 1 for further details on the fair value hierarchy.

[0000833444-14-000124:notes:94]
Commercial Paper

[0000833444-14-000124:notes:95]
From time to time, TIFSA may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program was $1 billion as of September 26, 2014.  As of September 26, 2014 and September 27, 2013, TIFSA had no commercial paper outstanding.

[0000833444-14-000124:notes:96]
Fiscal 2014 and 2013 Debt Issuance/Repayment

[0000833444-14-000124:notes:97]
During fiscal years 2014 and 2013, except for the issuance of commercial paper as described above, there were no material debt issuances or repayments.

[0000833444-14-000124:notes:98]
Fiscal 2012 Debt Issuance/Repayment

[0000833444-14-000124:notes:99]
During the fourth quarter of 2012, in connection with the Separation, Tyco and its finance subsidiary, Tyco International Finance S.A. ("TIFSA"), redeemed various debt securities maturing from 2013 to 2023 issued by TIFSA and/or Tyco, in an aggregate principal amount of $2.6 billion as set forth below ($ in millions):

[0000833444-14-000124:notes:100]
| 6.0% public notes due 2013 | $ | 656 |  |
| 4.125% public notes due 2014 | 500 |  |
| 3.375% public notes due 2015 | 242 |  |
| 3.750% public notes due 2018 | 183 |  |
| 8.5% public notes due 2019 | 386 |  |
| 7.0% public notes due 2019 | 180 |  |
| 6.875% public notes due 2021 | 245 |  |
| 4.625% public notes due 2023 | 208 |  |
| Total amounts redeemed | $ | 2,600 |  |

[0000833444-14-000124:notes:101]
In conjunction with the debt redemptions, the Company terminated associated interest rate swap contracts related to the 6.0% Notes due 2013 and 4.125% Notes due 2014. As a result of the debt redemptions, the Company recorded a loss on extinguishment of debt of $453 million which was recorded within Other expense, net in the Company's Consolidated Statement of Operations for the year ended September 28, 2012. The charge was comprised of the premium paid in the tender offers, write-off of the unamortized debt issuance costs and discount related to the extinguished notes, and a net gain recognized upon termination of the associated interest rate swap contracts.

[0000833444-14-000124:notes:102]
Credit Facilities

[0000833444-14-000124:notes:103]
On June 22, 2012, TIFSA, as the Borrower, and the Company as the Guarantor, entered into a Five-Year Senior Unsecured Credit Agreement, expiring June 22, 2017, and providing for revolving credit commitments in the aggregate amount of $1.0 billion (the "2012 Credit Agreement"). In connection with entering into the 2012 Credit Agreement, TIFSA and the Company terminated the existing Four-Year Senior Unsecured Credit Agreement, dated March 24, 2011, which provided for revolving credit commitments in the aggregate amount of $750 million.  Additionally, the Company's Five-Year Senior Unsecured Credit Agreement, dated April 25, 2007 and as amended, terminated on September 28, 2012.

[0000833444-14-000124:notes:104]
As a result of entering into the 2012 Credit Agreement, the Company's committed revolving credit facility totaled $1.0 billion as of September 26, 2014. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of September 26, 2014 and September 27, 2013, there were no amounts drawn under the Company's revolving credit facilities. Interest under the revolving credit facilities is variable and is calculated by reference to LIBOR or an alternate base rate.

[0000833444-14-000124:notes:105]
Other Debt Information

[0000833444-14-000124:notes:106]
The aggregate amounts of principal public debt maturing during the next five fiscal years and thereafter are as follows: nil in 2015, $258 million in 2016, nil in 2017, $67 million in 2018, $364 million in 2019 and $746 million thereafter.

[0000833444-14-000124:notes:107]
As of September 26, 2014, the weighted-average interest rate on total debt was 6.5%.  As of September 27, 2013, the weighted-average interest rate on total debt, excluding the impact of interest rate swaps, was 6.5%.  There was no public short-term debt outstanding as of September 26, 2014 and September 27, 2013. As of September 28, 2012, the Company had terminated all interest rate swaps. The impact of the Company's interest rate swap agreements on reported interest expense prior to termination was a net decrease of $18 million for the year ended September 28, 2012.


## us-gaap:DerivativesPolicyTextBlock

[0000833444-14-000124:notes:108]
Financial Instruments—The Company may use interest rate swaps, currency swaps, forward and option contracts and commodity swaps to manage risks generally associated with interest rate risk, foreign exchange risk and commodity prices. Derivatives used for hedging purposes are designated and effective as a hedge of the identified risk exposure at the inception of the contract. Accordingly, changes in fair value of the derivative contract are highly effective at offsetting the changes in the fair value of the underlying hedged item at inception of the hedge and are expected to remain highly effective over the life of the hedge contract.

[0000833444-14-000124:notes:109]
All derivative financial instruments are reported on the Consolidated Balance Sheets at fair value. Derivatives used to economically hedge foreign currency denominated balance sheet items related to operating activities are reported in Selling, general and administrative expenses along with offsetting transaction gains and losses on the items being hedged. Derivatives used to manage the exposure to changes in interest rates are reported in interest expense along with offsetting transaction gains and losses on the items being hedged. Gains and losses on net investment hedges are included in the cumulative translation adjustment component of accumulated other comprehensive loss to the extent they are effective. Gains and losses on derivatives designated as cash flow hedges are recorded in accumulated other comprehensive loss and reclassified to earnings in a manner that matches the timing of the earnings impact of the hedged transactions. The Company classifies cash flows associated with the settlement of derivatives consistent with the nature of the transaction being hedged. The ineffective portion of all hedges, if any, is recognized currently in earnings. Instruments that do not qualify for hedge accounting are marked to market with changes recognized in current earnings.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-14-000124:notes:110]
Share Plans

[0000833444-14-000124:notes:111]
Total share-based compensation cost recognized within continuing and discontinued operations during 2014, 2013 and 2012 consisted of the following ($ in millions):

[0000833444-14-000124:notes:112]
|  | 2014 |  | 2013 |  | 2012 |
| Selling, general and administrative expenses | $ | 72 |  |  | $ | 63 |  |  | $ | 81 |  |
| Separation costs | — |  |  | — |  |  | 28 |  |
| Restructuring and asset impairments charges, net | — |  |  | — |  |  | 4 |  |
| Total share-based compensation costs included in continuing operations | 72 |  |  | 63 |  |  | 113 |  |
| Discontinued operations | — |  |  | — |  |  | 27 |  |
| Total share-based compensation costs | $ | 72 |  |  | $ | 63 |  |  | $ | 140 |  |

[0000833444-14-000124:notes:113]
The Company has recognized a related tax benefit associated with its share-based compensation arrangements during 2014, 2013 and 2012 of $25 million, and $20 million and $43 million, of which nil, nil and $8 million is included in Discontinued operations, respectively.

[0000833444-14-000124:notes:114]
The share-based compensation disclosures were not recast for the divestiture of the South Korean security business as the amounts were not material.

[0000833444-14-000124:notes:115]
In connection with the 2012 Separation, most employees' outstanding stock option awards were converted into options to acquire the stock of the employee's post-Separation employer in a manner designed to preserve the intrinsic value of such awards.  However, for certain corporate employees and for all terminated employees, all or a portion of such employees' stock option awards were converted into options to acquire the stock of each of the Company, Pentair and ADT.  The modifications made to the share options as a result of the 2012 Separation constituted a modification under the authoritative guidance for accounting for stock compensation, which requires a comparison of fair values of the stock option awards immediately before the 2012 Separation and the fair values immediately after the 2012 Separation. In certain instances, the fair value immediately after the 2012 Separation was higher. As a result, the modification resulted in incremental compensation cost of $1 million, the majority of which was recorded in Discontinued operations within the Consolidated Statement of Operations for the year ended September 28, 2012. Except for the changes described, the material terms of the stock option awards remained unchanged from the original grant.  While the equity awards held by employees were converted as of September 28, 2012, the 2012 grant date fair values, intrinsic values, vested values and Black-Scholes assumptions are on a pre-conversion basis.

[0000833444-14-000124:notes:116]
Also in connection with the 2012 Separation, restricted stock units held by Tyco employees and deferred stock units held by Tyco directors were converted, in some cases, into restricted stock units in the Company, Pentair and ADT, and in other cases, solely into restricted stock units of the employee's post-Separation employer. All such modifications were designed in a manner to preserve the intrinsic value of such awards. Except for the changes described, the material terms of the restricted stock units and deferred stock units remained unchanged from the original grant.

[0000833444-14-000124:notes:117]
On July 12, 2012, in connection with the 2012 Separation, the Board of Directors approved the conversion of all outstanding performance share units of the Company into restricted stock units based on performance achieved through June 29, 2012. Each performance share unit converted into a number of restricted stock units at a ratio determined by the Compensation Committee on August 2, 2012 based on its review and certification of performance results through June 29, 2012. Upon vesting of the resulting restricted stock units, each award will be settled in stock. All awards maintained their original vesting terms. The modifications made to the market-based condition of outstanding performance share units as a result of the 2012 Separation also constituted a modification similar to the modification described above. As a result, the modification resulted in incremental compensation cost of $8 million, of which $7 million was recorded in Separation costs and $1 million in Discontinued operations within the Consolidated Statement of Operations for the year ended September 28, 2012.  In addition, incremental expense was recognized in the same quarter the performance was achieved through June 29, 2012. Such expense totaled $7 million, of which $6 million was recorded in Separation costs and $1 million in Discontinued operations within the Consolidated Statement of Operations for the year ended September 28, 2012.

[0000833444-14-000124:notes:118]
On September 17, 2012, shareholders approved the Tyco International 2012 Stock and Incentive Plan (the "2012 Plan") which replaced the 2004 Tyco International Ltd. Stock and Incentive Plan (the "2004 Plan").  The 2012 Plan provides for the award of stock options, stock appreciation rights, annual performance bonuses, long term performance awards, restricted units, restricted shares, deferred stock units, promissory stock and other stock-based awards (collectively, "Awards").  Pursuant to the 2012 Plan, effective October 1, 2012, 50 million common shares were available for equity-based awards, subject to adjustments as provided under the terms of the 2012 Plan. No additional awards may be granted under the 2004 Plan. In addition, any common shares which have been awarded under the 2004 Plan but which are not issued, owing to expiration, forfeiture, cancellation, return to the Company or settlement in cash in lieu of common shares on or after January 1, 2004 and which are no longer available for any reason will also be available for issuance under the 2012 Plan. When common shares are issued pursuant to a grant of a full value award (for example, restricted stock units and performance share units), the total number of common shares remaining available for grant will be decreased by 3.32 shares under the 2012 Plan.  As of September 26, 2014, there were approximately 35 million shares available for grant under the 2012 Plan.

[0000833444-14-000124:notes:119]
Share Options—Options are granted to purchase common shares at prices that are equal to or greater than the closing market price of the common shares on the date the option is granted. Conditions of vesting are determined at the time of grant. Options are generally exercisable in equal annual installments over a period of four years and will generally expire 10 years after the date of grant. Historically, the Company's practice has been to settle stock option exercises through either newly issued shares or from shares held in treasury.

[0000833444-14-000124:notes:120]
The grant-date fair value of each option grant is estimated using the Black-Scholes option pricing model. The fair value is then amortized on a straight-line basis over the requisite service period of the awards, which is generally the vesting period. Use of a valuation model requires management to make certain assumptions with respect to selected model inputs. Expected volatility is calculated based on an analysis of historic and implied volatility measures for a set of peer companies. The average expected life is based on the contractual term of the option and expected employee exercise and post-vesting employment termination behavior. The risk-free interest rate is based on U.S. Treasury zero-coupon issues with a remaining term equal to the expected life assumed at the date of grant. The compensation expense recognized is net of estimated forfeitures. Forfeitures are estimated based on voluntary termination behavior, as well as an analysis of actual share option forfeitures. The weighted-average assumptions used in the Black-Scholes option pricing model for 2014, 2013 and 2012 are as follows:

[0000833444-14-000124:notes:121]
|  | 2014 |  | 2013 |  | 2012 |
| Expected stock price volatility | 33 | % |  | 35 | % |  | 36 | % |
| Risk free interest rate | 1.64 | % |  | 0.87 | % |  | 1.46 | % |
| Expected annual dividend per share | $ | 0.64 |  |  | $ | 0.60 |  |  | $ | 1.00 |  |
| Expected life of options (years) | 5.5 |  |  | 5.8 |  |  | 5.8 |  |

[0000833444-14-000124:notes:122]
The weighted-average grant-date fair values of options granted during 2014, 2013 and 2012 was $10.24, $7.21 and $12.56, respectively.  The total intrinsic value of options exercised during 2014, 2013 and 2012 was $76 million, $73 million and $85 million, respectively. The related excess cash tax benefit classified as a financing cash inflow for 2014, 2013 and 2012 was not material.

[0000833444-14-000124:notes:123]
A summary of the option activity as of September 26, 2014, and changes during the year then ended is presented below:

[0000833444-14-000124:notes:124]
|  | Shares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemainingContractual Term(in years) |  | AggregateIntrinsicValue($ in millions) |
| Outstanding as of September 27, 2013 | 17,799,189 |  |  | $ | 22.34 |  |  |  |  |  |
| Granted | 1,996,237 |  |  | 37.56 |  |  |  |  |  |
| Exercised | (4,148,851 | ) |  | 21.96 |  |  |  |  |  |
| Expired | (476,722 | ) |  | 26.39 |  |  |  |  |  |
| Forfeited | (43,488 | ) |  | 24.46 |  |  |  |  |  |
| Outstanding as of September 26, 2014 | 15,126,365 |  |  | 24.31 |  |  | 6.07 |  | $ | 301 |  |
| Vested and unvested expected to vest as of September 26, 2014 | 14,536,978 |  |  | 24.08 |  |  | 6.00 |  | $ | 293 |  |
| Exercisable as of September 26, 2014 | 7,936,033 |  |  | 20.75 |  |  | 4.33 |  | $ | 185 |  |

[0000833444-14-000124:notes:125]
As of September 26, 2014, there was $30 million of total unrecognized compensation cost related to unvested options granted. The cost is expected to be recognized over a weighted-average period of 2.5 fiscal years.

[0000833444-14-000124:notes:126]
Employee Stock Purchase Plans—The Tyco Employee Stock Purchase Plan ("ESPP") was suspended indefinitely during the fourth quarter of 2009.  As of September 26, 2014, there were approximately 3 million shares available for grant under the ESPP.

[0000833444-14-000124:notes:127]
Restricted Share Awards—Restricted share awards, including restricted stock units and performance share units are granted subject to certain restrictions. Conditions of vesting are determined at the time of grant. Restrictions on the award generally lapse upon normal retirement, if more than twelve months from the grant date, death or disability of the employee.

[0000833444-14-000124:notes:128]
The fair market value of restricted awards, both time vesting and those subject to specific performance criteria, are expensed over the period of vesting. Restricted stock units, which vest based solely upon passage of time generally vest over a period of four years. The fair value of restricted stock units is determined based on the closing market price of the Company's shares on the grant date. Performance share units, which are restricted share awards that vest dependent upon attainment of various levels of performance that equal or exceed targeted levels generally vest in their entirety three years from the grant date. The fair value of performance share units is determined based on the Monte Carlo valuation model. The compensation expense recognized for all restricted share awards is net of estimated forfeitures.

[0000833444-14-000124:notes:129]
Recipients of restricted stock units have no voting rights and receive dividend equivalent units ("DEUs"). Recipients of performance share units have no voting rights and receive DEUs depending on the attainment of performance levels.

[0000833444-14-000124:notes:130]
A summary of the activity of the Company's restricted stock unit awards as of September 26, 2014 and changes during the year then ended is presented in the tables below:

[0000833444-14-000124:notes:131]
| Non-vested Restricted Stock Units | Shares |  | Weighted-AverageGrant-DateFair Value |
| Non-vested as of September 27, 2013 | 3,969,127 |  |  | $ | 22.63 |  |
| Granted | 717,217 |  |  | 38.73 |  |
| Vested | (1,990,298 | ) |  | 20.63 |  |
| Forfeited | (284,746 | ) |  | 24.25 |  |
| Non-vested as of September 26, 2014 | 2,411,300 |  |  | 28.59 |  |

[0000833444-14-000124:notes:132]
The weighted-average grant-date fair value of restricted stock units granted during 2014, 2013 and 2012 was $38.73, $27.66 and $45.54, respectively. The total fair value of restricted stock units vested during 2014, 2013 and 2012 was $79 million, $64 million and $90 million, respectively.

[0000833444-14-000124:notes:133]
As of September 26, 2014, there was $37 million of total unrecognized compensation cost related to all unvested restricted share awards. The cost is expected to be recognized over a weighted-average period of 2.5 fiscal years.

[0000833444-14-000124:notes:134]
A summary of the activity of the Company's performance share unit awards as of September 26, 2014 and changes during the year then ended is presented in the table below:

[0000833444-14-000124:notes:135]
| Non-vested Performance Share Units | Shares |  | Weighted-AverageGrant-DateFair Value |
| Non-vested as of September 27, 2013 | 855,842 |  |  |  |  |
| Granted | 631,373 |  |  | $ | 39.01 |  |
| Vested | — |  |  |  |  |
| Forfeited | (99,564 | ) |  | 32.40 |  |
| Non-vested as of September 26, 2014 | 1,387,651 |  |  | 34.10 |  |

[0000833444-14-000124:notes:136]
The weighted-average grant-date fair value of performance share units granted during 2014, 2013 and 2012 was $39.01, $30.36 and $48.86, respectively. The total fair value of performance share units vested during 2014, 2013 and 2012 was $22 million, $25 million and nil.  As of August 2, 2012, all performance share units then outstanding were converted to restricted stock units; the outstanding shares at that time have been moved to the restricted stock units reporting table.

[0000833444-14-000124:notes:137]
As of September 26, 2014, there was $22 million of total unrecognized compensation cost related to all unvested performance share awards. The cost is expected to be recognized over a weighted-average period of 1.8 fiscal years.

[0000833444-14-000124:notes:138]
Deferred Stock Units—Deferred Stock Units ("DSUs") are notional units that are tied to the value of Tyco common shares with distribution deferred until termination of employment or service to the Company. Distribution, when made, will be in the form of actual shares on a one-for-one basis. Similar to restricted stock units that vest over time, the fair value of DSUs is determined based on the closing market price of the Company's shares on the grant date and is amortized to expense over the vesting period. Recipients of DSUs do not have the right to vote and do not receive cash dividends. However, they have the right to receive dividend equivalent units. Conditions of vesting are determined at the time of grant. Under the 2004 Plan, grants made to executives generally vested in equal annual installments over three years while DSUs granted to the Board of Directors were immediately vested. The Company had 1.1 million DSUs outstanding as of September 28, 2012, all of which are fully vested and 1.0 million of which were delivered six months following September 28, 2012.

[0000833444-14-000124:notes:139]
There were no DSU awards granted during 2014, 2013 and 2012; however, participants continue to earn DEUs on their existing awards. The total fair value of DSUs including DEUs vested during 2014, 2013 and 2012 was nil, nil and $1 million, respectively.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-14-000124:notes:140]
Divestitures

[0000833444-14-000124:notes:141]
The Company has continued to assess the strategic fit of its various businesses and has pursued the divestiture of certain businesses which do not align with its long-term strategy.

[0000833444-14-000124:notes:142]
Fiscal 2014

[0000833444-14-000124:notes:143]
On May 22, 2014, the Company, together with its wholly-owned subsidiary Tyco Far East Holdings Ltd. (the “Seller”) completed the sale of Tyco Fire & Security Services Korea Co. Ltd. and its subsidiaries that formed and operated the Company’s ADT Korea business to an affiliate of The Carlyle Group. The transaction took the form of a sale by the Seller of all of the stock of Tyco Fire & Security Services Korea Co. Ltd. for an aggregate purchase price of $1.93 billion, subject to customary adjustments as set forth in the stock purchase agreement.  During the third quarter of fiscal 2014, the Company recognized a gain of $1.0 billion, net of a $212 million charge related to the indemnification at fair value for certain tax related matters borne by the buyer that are probable of being paid.  The net gain was recorded in Income from discontinued operations, net of income taxes, on the Consolidated Statements of Operations for the year ended September 26, 2014.  During the fourth quarter of fiscal 2014, the Company recorded a working capital adjustment, which reduced the net gain by $15 million.  This business was accounted for as held for sale on the Consolidated Balance Sheets as of September 27, 2013, and its results of operations have been presented within discontinued operations on the Consolidated Statements of Operations for the years ended September 26, 2014, September 27, 2013 and September 28, 2012.

[0000833444-14-000124:notes:144]
The Company intends to sell several businesses in the ROW Installation and Services segment by the end of the third quarter of fiscal 2015.  The businesses are accounted for as held for sale on the Consolidated Balance Sheets as of September 26, 2014 and September 27, 2013, and their results of operations have been presented as discontinued operations on the Consolidated Statements of Operations during the years ended September 26, 2014 and September 27, 2013.  During the quarter ended June 27, 2014, the Company recorded a $1 million impairment loss related to writing down the net assets to their fair value.

[0000833444-14-000124:notes:145]
On March 6, 2014, the Company announced Atkore International Group Inc.'s (“Atkore”) intention to redeem all of the Company’s remaining common equity stake in Atkore.  The redemption was completed on April 9, 2014 for aggregate cash proceeds of $250 million.  This amount may be adjusted upward by up to $25 million if, prior to December 31, 2014, there is a sale or merger of Atkore, a sale of substantially all of Atkore's assets or an initial public offering of Atkore's stock.  The Company recognized a net gain of $216 million related to this transaction, which is included in Equity income (loss) in earnings of unconsolidated subsidiaries in the Consolidated Statement of Operations for the year ended September 26, 2014.  The net gain is comprised of a $227 million gain on the sale of the equity investment, partially offset by an $11 million loss, which is the Company's share of loss on Atkore's debt extinguishment undertaken in connection with the redemption.

[0000833444-14-000124:notes:146]
Fiscal 2013

[0000833444-14-000124:notes:147]
During the fourth quarter of fiscal 2013, the Company approved a plan to sell its armored guard business in New Zealand and its fire and security business in Fiji, both of which were in its ROW Installation & Services segment.  The sale was completed during the first quarter of fiscal 2014. The assets and liabilities have not been presented separately as held-for-sale in the Consolidated Balance Sheets as the amounts were not material to the presentation of all periods.  A pre-tax loss of approximately $13 million for the write-down to fair value, less cost to sell was recorded in Restructuring and asset impairment charges, net in the Company's Consolidated Statements of Operations for the year ended September 27, 2013.  This business has not been presented in discontinued operations as the amounts were not material to the Consolidated Financial Statements.

[0000833444-14-000124:notes:148]
During the third quarter of fiscal 2013, the Company completed the sale of its North America guarding business in its NA Installation & Services segment for approximately $25 million of cash proceeds, net of $2 million of cash divested on sale.  The pre-tax loss for the write-down to fair value, less cost to sell, was not material.  This business was accounted for as held for sale during the second quarter of fiscal 2013; however, its results of operations have not been presented in discontinued operations as the amounts were not material to the Consolidated Financial Statements.

[0000833444-14-000124:notes:149]
Fiscal 2012

[0000833444-14-000124:notes:150]
On September 28, 2012, Tyco completed the 2012 Separation and has presented its former North American residential security and flow control businesses as discontinued operations in all periods prior to the completion of the 2012 Separation. See Note 2 for additional information regarding the 2012 Separation. At the time of the 2012 Separation, the Company used available information to develop its best estimates for certain assets and liabilities related to the Separation. In limited instances, final determination of the balances will be made in subsequent periods, such as in the case of when final income tax returns are filed in certain jurisdictions where those returns include a combination of Tyco, ADT and/or Tyco Flow Control legal entities.

[0000833444-14-000124:notes:151]
During the year ended September 27, 2013, a net increase of $1 million was recorded within the Consolidated Statement of Shareholders' Equity as Other, primarily related to a cash true-up adjustment received from Pentair in the third quarter of fiscal 2013, offset by a cash true-up adjustment paid to ADT during the first quarter of fiscal 2013 and adjustments for the impact of filing final income tax returns.  Any additional adjustments are not expected to be material.

[0000833444-14-000124:notes:152]
During the year ended September 28, 2012, the Company sold its Fire Equipment de Mexico, S.A. business, which was part of the Company's Global Products segment. The sale was completed for approximately $1 million of cash consideration and a pre-tax loss of $3 million was recorded in Income from discontinued operations, net of income taxes in the Company's Consolidated Statements of Operations.

[0000833444-14-000124:notes:153]
Discontinued Operations

[0000833444-14-000124:notes:154]
The components of income from discontinued operations, net of income taxes are as follows ($ in millions):

[0000833444-14-000124:notes:155]
|  | For the Years Ended |
|  | September 26, 2014 |  | September 27,2013 |  | September 28,2012 |
| Net revenue | $ | 395 |  |  | $ | 573 |  |  | $ | 7,657 |  |
| Pre-tax income from discontinued operations | $ | 58 |  |  | $ | 101 |  |  | $ | 1,316 |  |
| Pre-tax separation (income) charges included within discontinued operations (See Note 2) | (1 | ) |  | 8 |  |  | (278 | ) |
| Pre-tax gain on sale of discontinued operations | 1,160 |  |  | — |  |  | 4 |  |
| Income tax expense | (173 | ) |  | (16 | ) |  | (158 | ) |
| Income from discontinued operations, net of income taxes | $ | 1,044 |  |  | $ | 93 |  |  | $ | 884 |  |

[0000833444-14-000124:notes:156]
Total assets and total liabilities of discontinued operations as of September 26, 2014 and September 27, 2013 were as follows ($ in millions):

[0000833444-14-000124:notes:157]
|  | As of |
|  | September 26,2014 |  | September 27,2013 |
| Accounts receivables, net | $ | 11 |  |  | $ | 34 |  |
| Inventories | 3 |  |  | 10 |  |
| Prepaid expenses and other current assets | 5 |  |  | 22 |  |
| Property, plant and equipment, net | — |  |  | 393 |  |
| Goodwill and intangible assets, net | — |  |  | 370 |  |
| Other assets | 2 |  |  | 27 |  |
| Total assets | $ | 21 |  |  | $ | 856 |  |
| Accounts payable | 2 |  |  | 52 |  |
| Accrued and other current liabilities | 9 |  |  | 66 |  |
| Other liabilities | 2 |  |  | 118 |  |
| Total liabilities | $ | 13 |  |  | $ | 236 |  |

[0000833444-14-000124:notes:158]
The Company has used available information to develop its best estimates for certain assets and liabilities related to the 2007 Separation. In limited instances, final determination of the balances will be made in subsequent periods. There were no adjustments recorded through Tyco shareholders' equity for the years ended September 26, 2014, September 27, 2013, and September 28, 2012.  Adjustments in the future for the impact of filing final income tax returns in certain jurisdictions where those returns include a combination of Tyco, Covidien and/or TE Connectivity legal entities and for certain amended income tax returns for the periods prior to the 2007 Separation may be recorded to either Tyco shareholders' equity or the Consolidated Statement of Operations depending on the specific item giving rise to the adjustment.

[0000833444-14-000124:notes:159]
Additionally, the year ended September 28, 2012 included $21 million of income tax expense associated with pre-2007 Separation tax liabilities, which was recorded in Income from discontinued operations, net of income taxes in the Company's Consolidated Statements of Operations. There was no income tax expense associated with pre-2007 Separation tax liabilities for both years ended September 26, 2014 and September 27, 2013.  During the year ended September 28, 2012, the Company was reimbursed $8 million pursuant to a tax sharing agreement entered into in conjunction with the 2007 Separation (the "2007 Tax Sharing Agreement"), which has been recorded in Income from discontinued operations, net of income taxes in the Company's Consolidated Statements of Operations.  See Note 6 for additional information.

[0000833444-14-000124:notes:160]
Divestiture (Gains) Charges, Net

[0000833444-14-000124:notes:161]
During 2014, 2013 and 2012, the Company recorded a net gain of $2 million, and net losses of $20 million and $14 million, respectively, in Selling, general and administrative expenses in the Company's Consolidated Statements of Operations. The net gain for the year ended September 26, 2014 was primarily the result of a favorable court judgment relating to a divested business in our ROW Installation & Services segment.  The net loss for the year ended September 27, 2013 primarily resulted from the write-down to fair value, less cost to sell, of the armored guard business in New Zealand and the fire and security business in Fiji, both of which are in our ROW Installation & Services segment.  The net loss for the year ended September 28, 2012 primarily resulted from an indemnification resulting from the divestiture of the Company's Electrical and Metal products business.


## us-gaap:EarningsPerShareTextBlock

[0000833444-14-000124:notes:162]
Earnings Per Share

[0000833444-14-000124:notes:163]
The reconciliations between basic and diluted earnings per share attributable to Tyco common shareholders for the years ended September 26, 2014, September 27, 2013 and September 28, 2012 are as follows (in millions, except per share data):

[0000833444-14-000124:notes:164]
|  | For the Years Ended |
|  | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
|  | Income |  | Shares |  | PerShareAmount |  | Income |  | Shares |  | PerShareAmount |  | (Loss) |  | Shares |  | PerShareAmount |
| Basic earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) from continuing operations | $ | 794 |  |  | 455 |  |  | $ | 1.74 |  |  | $ | 443 |  |  | 465 |  |  | $ | 0.96 |  |  | $ | (412 | ) |  | 463 |  |  | $ | (0.89 | ) |
| Share options and restricted share awards |  |  |  | 8 |  |  |  |  |  |  |  |  | 7 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Diluted earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) from continuing operations attributable to Tyco common shareholders, giving effect to dilutive adjustments | $ | 794 |  |  | 463 |  |  | $ | 1.71 |  |  | $ | 443 |  |  | 472 |  |  | $ | 0.94 |  |  | $ | (412 | ) |  | 463 |  |  | $ | (0.89 | ) |

[0000833444-14-000124:notes:165]
The computation of diluted earnings per share for the years ended September 26, 2014, September 27, 2013 and September 28, 2012 excludes the effect of the potential exercise of share options to purchase approximately 2 million, 4 million, and 12 million shares, respectively, and excludes restricted share awards of 2 million, 1 million, and 2 million shares, respectively, because the effect would be anti-dilutive.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000833444-14-000124:notes:166]
Financial Instruments

[0000833444-14-000124:notes:167]
The Company's financial instruments consist primarily of cash and cash equivalents, accounts receivable, investments, accounts payable, debt and derivative financial instruments. The fair value of cash and cash equivalents, accounts receivable and accounts payable approximated book value as of September 26, 2014 and September 27, 2013. The fair value of derivative financial instruments was not material to any of the periods presented. See below for the fair value of investments and Note 10 for the fair value of debt.

[0000833444-14-000124:notes:168]
Derivative Instruments

[0000833444-14-000124:notes:169]
In the normal course of business, Tyco is exposed to market risk arising from changes in currency exchange rates, interest rates and commodity prices. The Company may use derivative financial instruments to manage exposures to foreign currency, commodity and interest rate risks. The Company's objective for utilizing derivative financial instruments is to manage these risks using the most effective methods to eliminate or reduce the impacts of these exposures. The Company does not use derivative financial instruments for trading or speculative purposes. Additionally, the Company did not have any derivative instruments designated as hedging instruments for accounting purposes during the years ended September 26, 2014 and September 27, 2013.  During the year ended September 28, 2012, the Company terminated its interest rate swaps.

[0000833444-14-000124:notes:170]
Foreign Currency Exposures

[0000833444-14-000124:notes:171]
The Company manages foreign currency exchange rate risk through the use of derivative financial instruments comprised principally of forward contracts on foreign currency which are not designated as hedging instruments for accounting purposes. The objective of the derivative instruments is to minimize the income statement impact and potential variability in cash flows associated with intercompany loans, accounts receivable, accounts payable and forecasted transactions that are denominated in certain foreign currencies. As of September 26, 2014 and September 27, 2013, the total gross notional amount of the Company's foreign exchange contracts was $258 million and $278 million, respectively, including contracts of nil and $60 million, respectively, related to the South Korean security business.

[0000833444-14-000124:notes:172]
Counterparty Credit Risk

[0000833444-14-000124:notes:173]
The use of derivative financial instruments exposes the Company to counterparty credit risk. Tyco has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association master agreements with substantially all of its counterparties.  The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties.  The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of our counterparties and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-14-000124:notes:174]
Investments

[0000833444-14-000124:notes:175]
Investments primarily include marketable securities such as U.S. government obligations, U.S. government agency securities and corporate debt securities, equity securities and time deposits with banks.

[0000833444-14-000124:notes:176]
When available, the Company uses quoted market prices to determine the fair value of investment securities. Such investments are included in Level 1. When quoted market prices are not readily available, pricing determinations are made based on the results of market approach valuation models using observable market data such as recently reported trades, bid and offer information and benchmark securities. These investments are included in Level 2 and consist primarily of U.S. government agency securities and corporate debt securities.

[0000833444-14-000124:notes:177]
During the year ended September 26, 2014, the Company liquidated its portfolio of corporate and U.S. Government debt securities and recorded a $1 million gain on the sale of investments related to this liquidation. As of September 26, 2014, the Company held time deposits with original time to maturity greater than three months of $275 million, which are recorded in Prepaid expenses and other current assets in the Consolidated Balance Sheet.

[0000833444-14-000124:notes:178]
During the year ended September 26, 2014, the Company also purchased $62 million of trading securities that will serve to partially offset changes in the market value of liabilities for an unfunded non-qualified defined contribution pension plan.  These securities, which primarily consist of exchange traded equity funds, are recorded in Prepaid expenses and other current assets in the Consolidated Balance Sheet, and gains or losses are recorded in Other income, expense (net) in the Consolidated Statement of Operations.  For the year ended September 26, 2014, the trading securities had a realized gain of nil.

[0000833444-14-000124:notes:179]
The following tables present the cost and fair market value of the Company's investments measured at fair value, by type of security, by level, and by classification on the Company's Consolidated Balance Sheets as of September 26, 2014 and September 27, 2013.

[0000833444-14-000124:notes:180]
During 2014 and 2013, the Company did not have any significant transfers within the fair value hierarchy.

[0000833444-14-000124:notes:181]
Investments with continuous unrealized losses for less than 12 months and 12 months or greater as of September 26, 2014 and September 27, 2013 were not material. The Company did not record any other-than-temporary impairments for the years  2014, 2013 and 2012.

[0000833444-14-000124:notes:182]
Derivative Financial Instruments

[0000833444-14-000124:notes:183]
The fair values for the Company's derivative financial instruments are derived from market approach pricing models that take into account the contractual terms and features of each instrument and forward foreign currency rates for the Company's foreign exchange contracts. Valuations are adjusted to reflect creditworthiness of the counterparty for assets and the creditworthiness of the Company for liabilities. Such adjustments are based on observable market evidence and are categorized as Level 2 exposures. Derivative financial instruments fair value details are not presented as the derivative financial instruments were not material to any of the periods presented.

[0000833444-14-000124:notes:184]
Other

[0000833444-14-000124:notes:185]
In addition to the gain related to the liquidation of the Company's investment portfolio as described above, the year ended September 26, 2014 also included a $7 million loss on the sale of an investment related to the Company's ROW Installation and Services business.

[0000833444-14-000124:notes:186]
The Company had $1.5 billion and $1.4 billion of intercompany loans designated as permanent in nature as of  September 26, 2014 and September 27, 2013, respectively. For the years ended September 26, 2014 and September 27, 2013, and September 28, 2012 the Company recorded a cumulative translation loss of $28 million, gain of $3 million and gain of $48 million, respectively, through Accumulated other comprehensive loss related to these loans.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000833444-14-000124:notes:187]
Translation of Foreign Currency—For the Company's non-U.S. subsidiaries whose books are in a functional currency other than U.S. dollars, assets and liabilities are translated into U.S. dollars using period-end exchange rates. Revenue and expenses are translated at the average exchange rates in effect during the period. Foreign currency translation gains and losses are included as a component of accumulated other comprehensive loss in Tyco's shareholders' equity.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-14-000124:notes:188]
Goodwill and Intangible Assets

[0000833444-14-000124:notes:189]
There were no goodwill impairments as a result of performing the Company's 2014, 2013 and 2012 annual impairment tests.  The changes in the carrying amount of goodwill by segment for 2014 and 2013 are as follows ($ in millions):

[0000833444-14-000124:notes:190]
|  | NA Installation& Services |  | ROWInstallation& Services |  | GlobalProducts |  | Total |
| Gross goodwill | $ | 2,127 |  |  | $ | 1,972 |  |  | $ | 1,696 |  |  | $ | 5,795 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 28, 2012 | $ | 2,001 |  |  | $ | 904 |  |  | $ | 1,129 |  |  | $ | 4,034 |  |
| 2013 activity: |  |  |  |  |  |  |  |
| Acquisitions/ Purchase accounting adjustments | 24 |  |  | 42 |  |  | 90 |  |  | 156 |  |
| Transfers | (39 | ) |  | — |  |  | 39 |  |  | — |  |
| Currency translation | (8 | ) |  | (19 | ) |  | (1 | ) |  | (28 | ) |
| Gross goodwill | $ | 2,104 |  |  | $ | 1,995 |  |  | $ | 1,824 |  |  | $ | 5,923 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 27, 2013 | $ | 1,978 |  |  | $ | 927 |  |  | $ | 1,257 |  |  | $ | 4,162 |  |
| 2014 activity: |  |  |  |  |  |  |  |
| Acquisitions/ Purchase accounting adjustments | 10 |  |  | 15 |  |  | (4 | ) |  | 21 |  |
| Currency translation | (12 | ) |  | (34 | ) |  | (11 | ) |  | (57 | ) |
| Gross goodwill | $ | 2,102 |  |  | $ | 1,976 |  |  | $ | 1,809 |  |  | $ | 5,887 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 26, 2014 | $ | 1,976 |  |  | $ | 908 |  |  | $ | 1,242 |  |  | $ | 4,126 |  |

[0000833444-14-000124:notes:191]
Intangible Assets

[0000833444-14-000124:notes:192]
There were no indefinite-lived intangible asset impairments as a result of performing the Company's 2014, 2013 and 2012 annual impairment tests.

[0000833444-14-000124:notes:193]
The following table sets forth the gross carrying amount and accumulated amortization of the Company's intangible assets as of September 26, 2014 and September 27, 2013 ($ in millions):

[0000833444-14-000124:notes:194]
|  | As of |
|  | September 26, 2014 |  | September 27, 2013 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Gross CarryingAmount |  | AccumulatedAmortization |
| Amortizable: |  |  |  |  |  |  |  |
| Contracts and related customer relationships | $ | 1,405 |  |  | $ | 1,117 |  |  | $ | 1,420 |  |  | $ | 1,101 |  |
| Intellectual property | 622 |  |  | 492 |  |  | 623 |  |  | 477 |  |
| Other | 38 |  |  | 16 |  |  | 40 |  |  | 13 |  |
| Total | $ | 2,065 |  |  | $ | 1,625 |  |  | $ | 2,083 |  |  | $ | 1,591 |  |
| Non-Amortizable: |  |  |  |  |  |  |  |
| Intellectual property | $ | 221 |  |  |  |  |  | $ | 223 |  |  |  |  |
| Franchise rights | 76 |  |  |  |  |  | 76 |  |  |  |  |
| Total | $ | 297 |  |  |  |  |  | $ | 299 |  |  |  |  |

[0000833444-14-000124:notes:195]
Intangible asset amortization expense for 2014, 2013 and 2012 was $93 million, $95 million and $99 million, respectively, and was recorded in Selling, general and administrative expense in the Consolidated Statements of Operations.

[0000833444-14-000124:notes:196]
The estimated aggregate amortization expense on intangible assets is expected to be approximately $66 million for 2015, $62 million for 2016, $53 million for 2017, $51 million for 2018 and $208 million for 2019 and thereafter.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000833444-14-000124:notes:197]
Long-Lived Asset Impairments—The Company reviews long-lived assets, including property, plant and equipment and amortizable intangible assets, for impairment whenever events or changes in business circumstances indicate that the carrying amount of the asset may not be fully recoverable. Tyco performs undiscounted operating cash flow analyses to determine if impairment exists. For purposes of recognition and measurement of an impairment for assets held for use, Tyco groups assets and liabilities at the lowest level for which cash flows are separately identified. If an impairment is determined to exist, any related impairment loss is calculated based on fair value. Impairment losses on assets to be disposed of, if any, are based on the estimated proceeds to be received, less costs of disposal.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-14-000124:notes:198]
Income Taxes

[0000833444-14-000124:notes:199]
Significant components of the income tax provision for fiscal 2014, 2013 and 2012 are as follows ($ in millions):

[0000833444-14-000124:notes:200]
|  | For the Years Ended |
|  | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
| Current: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | $ | 10 |  |  | $ | 14 |  |  | $ | (4 | ) |
| State | 18 |  |  | 8 |  |  | 6 |  |
| Non U.S. | 95 |  |  | 81 |  |  | 147 |  |
| Current income tax provision | $ | 123 |  |  | $ | 103 |  |  | $ | 149 |  |
| Deferred: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | $ | (79 | ) |  | $ | (12 | ) |  | $ | (10 | ) |
| State | (24 | ) |  | 5 |  |  | (2 | ) |
| Non U.S. | 4 |  |  | 12 |  |  | 183 |  |
| Deferred income tax provision | $ | (99 | ) |  | $ | 5 |  |  | $ | 171 |  |
|  | $ | 24 |  |  | $ | 108 |  |  | $ | 320 |  |

[0000833444-14-000124:notes:201]
Non-U.S. income from continuing operations before income taxes was $1.1 billion, $844 million and $87 million for fiscal 2014, 2013 and 2012, respectively.

[0000833444-14-000124:notes:202]
The reconciliation between U.S. federal income taxes at the statutory rate and the Company's provision for income taxes on continuing operations for the years ended September 26, 2014, September 27, 2013 and September 28, 2012 is as follows ($ in millions):

[0000833444-14-000124:notes:203]
|  | For the Years Ended |
|  | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
| Notional U.S. federal income tax expense at the statutory rate | $ | 215 |  |  | $ | 206 |  |  | $ | (24 | ) |
| Adjustments to reconcile to the income tax provision: |  |  |  |  |  |
| U.S. state income tax provision, net | (12 | ) |  | (3 | ) |  | 6 |  |
| Non U.S. net earnings(1) | (232 | ) |  | (172 | ) |  | 33 |  |
| Nondeductible charges | 47 |  |  | 78 |  |  | 61 |  |
| Valuation allowance | 4 |  |  | 4 |  |  | 235 |  |
| Other | 2 |  |  | (5 | ) |  | 9 |  |
| Provision for income taxes | $ | 24 |  |  | $ | 108 |  |  | $ | 320 |  |

[0000833444-14-000124:notes:204]
| (1) | Excludes nondeductible charges and other items which are broken out separately in the table. |

[0000833444-14-000124:notes:205]
2012 Separation related charges associated with the early extinguishment of debt further increased a net operating loss carryforward in 2012, which the Company does not expect to realize in future periods. The valuation allowance on this loss carryforward is included in the Valuation allowance line of the table above.

[0000833444-14-000124:notes:206]
Nondeductible charges during fiscal 2013 and 2012 are primarily related to separation costs incurred.

[0000833444-14-000124:notes:207]
Deferred income taxes result from temporary differences between the amount of assets and liabilities recognized for financial reporting and tax purposes. The components of the net deferred income tax asset as of September 26, 2014 and September 27, 2013 are as follows ($ in millions):

[0000833444-14-000124:notes:208]
|  | As of |
|  | September 26, 2014 |  | September 27, 2013 |
| Deferred tax assets: |  |  |  |
| Accrued liabilities and reserves | $ | 483 |  |  | $ | 285 |  |
| Tax loss and credit carryforwards | 2,312 |  |  | 2,432 |  |
| Postretirement benefits | 106 |  |  | 183 |  |
| Deferred revenue | 120 |  |  | 111 |  |
| Other | 173 |  |  | 102 |  |
|  | 3,194 |  |  | 3,113 |  |
| Deferred tax liabilities: |  |  |  |
| Property, plant and equipment | (92 | ) |  | (132 | ) |
| Intangibles assets | (537 | ) |  | (566 | ) |
| Other | (160 | ) |  | (167 | ) |
|  | (789 | ) |  | (865 | ) |
| Net deferred tax asset before valuation allowance | 2,405 |  |  | 2,248 |  |
| Valuation allowance | (1,995 | ) |  | (1,948 | ) |
| Net deferred tax asset | $ | 410 |  |  | $ | 300 |  |

[0000833444-14-000124:notes:209]
The valuation allowance for deferred tax assets of $2.0 billion and $1.9 billion as of September 26, 2014 and September 27, 2013, respectively, relates principally to the uncertainty of the utilization of certain deferred tax assets, primarily tax loss and credit carryforwards in various jurisdictions. The valuation allowance as of September 26, 2014 and September 27, 2013 includes separation related charges associated with the early extinguishment of debt which further increased a net operating loss carryforward which the Company does not expect to realize in future periods. The valuation allowance was calculated and recorded when the Company determined that it was more-likely-than-not that all or a portion of our deferred tax assets would not be realized. The Company believes that it will generate sufficient future taxable income to realize the tax benefits related to the remaining net deferred tax assets on the Company's Consolidated Balance Sheets.

[0000833444-14-000124:notes:210]
As of September 26, 2014, deferred tax assets of approximately $140 million relate to certain operating loss carryforwards resulting from the exercise of employee stock options and restricted stock vestings, the tax benefit of which, when recognized, will be accounted for as a credit to additional paid-in capital rather than a reduction of income tax provision.

[0000833444-14-000124:notes:211]
As of September 26, 2014, the Company had $7,713 million of net operating loss carryforwards in certain non-U.S. jurisdictions. Of these, $7,140 million have no expiration, and the remaining $573 million will expire in future years through 2034. In the U.S., there were approximately $352 million of federal and $223 million of state net operating loss carryforwards as of September 26, 2014, which will expire in future years through 2034.

[0000833444-14-000124:notes:212]
As of September 26, 2014 and September 27, 2013, the Company had unrecognized tax benefits of $267 million and $256 million, respectively, of which $247 million and $235 million, if recognized, would affect the effective tax rate. The Company recognizes interest and penalties related to unrecognized tax benefits in income tax expense. The Company accrued interest and penalties related to the unrecognized tax benefits of $36 million and $39 million as of September 26, 2014 and September 27, 2013, respectively. The Company recognized $1 million, $1 million and $2 million of income tax expense for interest and penalties related to unrecognized tax benefits for the years ended September 26, 2014, September 27, 2013 and September 28, 2012, respectively.

[0000833444-14-000124:notes:213]
A rollforward of unrecognized tax benefits as of September 26, 2014, September 27, 2013 and September 28, 2012 is as follows ($ in millions):

[0000833444-14-000124:notes:214]
|  | As of |
|  | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
| Balance as of beginning of year | $ | 256 |  |  | $ | 120 |  |  | $ | 144 |  |
| Additions based on tax positions related to the current year | 46 |  |  | 137 |  |  | 18 |  |
| Additions based on tax positions related to prior years | 7 |  |  | 7 |  |  | 7 |  |
| Reductions based on tax positions related to prior years | (39 | ) |  | (6 | ) |  | (38 | ) |
| Reductions related to settlements | (1 | ) |  | — |  |  | (1 | ) |
| Reductions related to lapse of the applicable statute of limitations | (2 | ) |  | (2 | ) |  | (3 | ) |
| Foreign currency translation adjustments | — |  |  | — |  |  | (7 | ) |
| Balance as of end of year | $ | 267 |  |  | $ | 256 |  |  | $ | 120 |  |

[0000833444-14-000124:notes:215]
Certain of Tyco's uncertain tax positions relate to tax years that remain subject to audit by the taxing authorities in the U.S. federal, state and local or foreign jurisdictions. Open tax years in significant jurisdictions are as follows:

[0000833444-14-000124:notes:216]
| Jurisdiction | YearsOpen To Audit |
| Australia | 2004-2013 |
| Canada | 2006-2013 |
| Germany | 2005-2013 |
| Switzerland | 2004-2013 |
| United Kingdom | 2012-2013 |
| United States | 1997-2013 |

[0000833444-14-000124:notes:217]
Based on the current status of its income tax audits, the Company believes that it is reasonably possible that between nil and $20 million in unrecognized tax benefits may be resolved in the next twelve months.

[0000833444-14-000124:notes:218]
Tax Sharing Agreements and Other Income Tax Matters

[0000833444-14-000124:notes:219]
In connection with the 2012 and 2007 Separations, the Company entered into the 2012 and 2007 Tax Sharing Agreements, respectively, that govern the respective rights, responsibilities, and obligations of Tyco, Pentair and ADT after the 2012 Separation and Tyco, Covidien and TE Connectivity after the 2007 Separation with respect to taxes. Specifically this includes ordinary course of business taxes and taxes, if any, incurred as a result of any failure of the distribution of all of the shares of Pentair, ADT, Covidien or TE Connectivity to qualify as a tax-free distribution for U.S. federal income tax purposes within the meaning of Section 355 of the Internal Revenue Code ("the Code") or certain internal transactions undertaken in anticipation of the spin-offs to qualify for tax-favored treatment under the Code.

[0000833444-14-000124:notes:220]
Under the 2012 Tax Sharing Agreement Tyco, Pentair and ADT share (i) certain pre-Distribution income tax liabilities that arise from adjustments made by tax authorities to ADT's, Tyco Flow Control's and Tyco's income tax returns, and (ii) payments required to be made by Tyco with respect to the 2007 Tax Sharing Agreement, excluding approximately $175 million of pre-2012 Separation related tax liabilities that were anticipated to be paid prior to the 2012 Separation (collectively, "Shared Tax Liabilities"). Tyco will be responsible for the first $500 million of Shared Tax Liabilities. Pentair and ADT will share 42% and 58%, respectively, of the next $225 million of Shared Tax Liabilities. Tyco, Pentair and ADT will share 52.5% 20% and 27.5%, respectively, of Shared Tax Liabilities above $725 million. All costs and expenses associated with the management of these shared tax liabilities will generally be shared 20%, 27.5%, and 52.5% by Pentair, ADT and Tyco, respectively. In connection with the execution of the 2012 Tax Sharing Arrangement, Tyco established liabilities representing the fair market value of its obligations which was recorded in other liabilities in the Company's Consolidated Balance Sheet with an offset to Tyco shareholders' equity.

[0000833444-14-000124:notes:221]
Under the 2007 Tax Sharing Agreement, Tyco shares responsibility for certain of its, Covidien's and TE Connectivity's income tax liabilities, which result in cash payments, based on a sharing formula for periods prior to and including June 29, 2007. More specifically, Tyco, Covidien and TE Connectivity share 27%, 42% and 31%, respectively, of shared income tax liabilities that arise from adjustments made by tax authorities to Tyco's, Covidien's and TE Connectivity's U.S. and certain non-U.S. income tax returns. The costs and expenses associated with the management of these shared tax liabilities are generally shared equally among the parties. In connection with the execution of the 2007 Tax Sharing Agreement, Tyco established a net receivable from Covidien and TE Connectivity representing the amount Tyco expected to receive for pre-2007 Separation uncertain tax positions, including amounts owed to the Internal Revenue Service ("IRS"). Tyco also established liabilities representing the fair market value of its share of Covidien's and TE Connectivity's estimated obligations, primarily to the IRS, for their pre-2007 Separation taxes covered by the 2007 Tax Sharing Agreement. During the year ended September 26, 2014, Tyco made a net cash payment of $155 million to Covidien under the terms of the 2007 Tax Sharing Agreement.  The cash exchanged was a reimbursement between the parties for various payments made to the IRS for federal income taxes related to the audit of fiscal years 2005 through 2007.  During the year ended September 27, 2013, Tyco made a net cash payment of $16 million to Covidien and TE Connectivity related to the resolution of certain IRS audit and pre-Separation tax matters.

[0000833444-14-000124:notes:222]
Tyco assesses the shared tax liabilities and guarantee liabilities related to both the 2012 and 2007 Tax Sharing Agreements at each reporting period. Tyco will provide payment to Pentair and ADT under the 2012 Tax Sharing Agreement and to Covidien and TE Connectivity under the 2007 Tax Sharing Agreement as the shared income tax liabilities are settled. Settlement is expected to occur as the tax, audit and legal processes are completed for the impacted years and cash payments are made. Due to the nature of the unresolved adjustments described in the next paragraph, the maximum amount of future payments under the 2012 and 2007 Tax Sharing Agreements is not known. Such cash payments, when they occur, will reduce the guarantor liability as such payments represent an equivalent reduction of risk. Tyco also assesses the sufficiency of the 2012 and 2007 Tax Sharing Agreements guarantee liabilities on a quarterly basis and will increase the liability when it is probable that cash payments expected to be made under the 2012 or 2007 Tax Sharing Agreements exceed the recorded balance.

[0000833444-14-000124:notes:223]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation. The issues and proposed adjustments related to such years are generally subject to the sharing provisions of the 2007 Tax Sharing Agreement and Tyco's liabilities under the 2007 Tax Sharing Agreement are further subject to the sharing provisions in the 2012 Tax Sharing Agreement. Tyco has previously disclosed that in connection with U.S. federal tax audits, the IRS has raised a number of issues and proposed tax adjustments for periods beginning with the 1997 tax year. Although Tyco has been able to resolve substantially all of the issues and adjustments proposed by the IRS for tax years through 2007, it has not been able to resolve matters related to the treatment of certain intercompany debt transactions during the period. As a result, on June 20, 2013, Tyco received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owe additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million is expected to be asserted. These amounts exclude interest and do not reflect the impact on subsequent periods if the IRS position described below is ultimately proved correct.

[0000833444-14-000124:notes:224]
The IRS asserted in the Notices of Deficiency that substantially all of Tyco's intercompany debt originated during the 1997 - 2000 period should not be treated as debt for U.S. federal income tax purposes, and has disallowed interest and related deductions recognized on U.S. income tax returns totaling approximately $2.9 billion. Tyco strongly disagrees with the IRS position and had filed petitions with the U.S. Tax Court contesting the IRS proposed adjustments. A trial date has been set for February 2016. Tyco believes that it has meritorious defenses for its tax filings, that the IRS positions with regard to these matters are inconsistent with the applicable tax laws and existing Treasury regulations, and that the previously reported taxes for the years in question are appropriate.

[0000833444-14-000124:notes:225]
No payments with respect to these matters would be required until the dispute is definitively resolved, which, based on the experience of other companies, could take several years. Tyco believes that its income tax reserves and the liabilities recorded in the Consolidated Balance Sheet for the tax sharing agreements continue to be appropriate. However, the ultimate resolution of these matters, and the impact of that resolution, are uncertain and could have a material impact on Tyco's financial condition, results of operations and cash flows. In particular, if the IRS is successful in asserting its claim, it would have an adverse impact on interest deductions related to the same intercompany debt in subsequent time periods, totaling approximately $6.6 billion, which is also expected to be disallowed by the IRS.

[0000833444-14-000124:notes:226]
As noted above, Tyco has assessed its obligations under the 2007 Tax Sharing Agreement to determine that its recorded liability is sufficient to cover the indemnifications made by it under such agreement. In the absence of observable transactions for identical or similar guarantees, Tyco determined the fair value of these guarantees and indemnifications utilizing expected present value measurement techniques. Significant assumptions utilized to determine fair value included determining a range of potential outcomes, assigning a probability weighting to each potential outcome and estimating the anticipated timing of resolution. The probability weighted outcomes were discounted using Tyco's incremental borrowing rate.  However, the ultimate resolution of these matters is uncertain and could result in a material adverse impact to the Company's financial position, results of operations, cash flows, or the effective tax rate in future reporting periods.

[0000833444-14-000124:notes:227]
In connection with the aforementioned audits, the IRS has assessed a civil fraud penalty of $21 million during the first quarter of fiscal 2013 against a prior subsidiary that was distributed to TE Connectivity in connection with the 2007 Separation. The penalties arise from actions of former executives taken in connection with intercompany transfers of stock of Simplex Technologies in 1998 and 1999. This is a pre-2007 Separation tax liability that is covered by the provisions of the 2007 Tax Sharing Agreement.

[0000833444-14-000124:notes:228]
In addition to dealing with tax liabilities for periods prior to the respective Separations, the 2012 and 2007 Tax Sharing Agreements contain sharing provisions to address the contingencies that the 2012 or 2007 Separations, or internal transactions related thereto, may be deemed taxable by U.S. or non U.S. taxing authorities. In the event the 2012 Separation is determined to be taxable and such determination was the result of actions taken after the 2012 Separations by Tyco, ADT or Pentair, the party responsible for such failure would be responsible for all taxes imposed on each company as a result thereof. If such determination is not the result of actions taken by Tyco, ADT or Pentair after the 2012 Separation, then Tyco, ADT and Pentair would be responsible for any taxes imposed on any of the companies as a result of such determination in the same manner and in the same proportions as described above. Similar provisions exist in the 2007 Tax Sharing Agreement. If either of the 2007 or 2012 Separation, or internal transactions taken in anticipation thereof, were deemed taxable, the associated liability could be significant. Tyco is responsible for all of its own taxes that are not shared pursuant to the 2012 and 2007 Tax Sharing Agreements' sharing formulas. In addition, Pentair and ADT, and Covidien and TE Connectivity are responsible for their tax liabilities that are not subject to the 2012 or 2007 Tax Sharing Agreements' sharing formula, respectively.

[0000833444-14-000124:notes:229]
Each of the 2012 and 2007 Tax Sharing Agreements provides that, if any party to such agreement were to default in its obligation to another party to pay its share of the distribution taxes that arise as a result of no party's fault, each non-defaulting party to the agreement would be required to pay, equally with any other non-defaulting party to the agreement, the amounts in default. In addition, if another party to the 2012 or 2007 Tax Sharing Agreements that is responsible for all or a portion of an income tax liability were to default in its payment of such liability to a taxing authority, Tyco could be liable under applicable tax law for such liabilities and required to make additional tax payments. Accordingly, under certain circumstances, Tyco may be obligated to pay amounts in excess of its agreed-upon share of its tax liabilities under either of the 2012 or 2007 Tax Sharing Agreements.

[0000833444-14-000124:notes:230]
The receivables and liabilities related to the 2012 and 2007 Tax Sharing Agreements as of September 26, 2014 and September 27, 2013 are as follows ($ in millions):

[0000833444-14-000124:notes:231]
|  | 2012 Tax Sharing Agreement |  | 2007 Tax Sharing Agreement |
|  | As ofSeptember 26,2014 |  | As ofSeptember 27,2013 |  | As ofSeptember 26,2014 |  | As ofSeptember 27,2013 |
| Net receivable: |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | — |  |
| Other assets | — |  |  | — |  |  | 23 |  |  | 67 |  |
|  | — |  |  | — |  |  | 26 |  |  | 67 |  |
| Tax sharing agreement related liabilities |  |  |  |  |  |  |  |
| Accrued and other current liabilities | — |  |  | (33 | ) |  | (21 | ) |  | (130 | ) |
| Other liabilities | (46 | ) |  | (36 | ) |  | (194 | ) |  | (254 | ) |
|  | (46 | ) |  | (69 | ) |  | (215 | ) |  | (384 | ) |
| Net liability | $ | (46 | ) |  | $ | (69 | ) |  | $ | (189 | ) |  | $ | (317 | ) |

[0000833444-14-000124:notes:232]
The Company recorded (expense) income in conjunction with the 2012 and 2007 Tax Sharing Agreements for the years ended September 26, 2014, September 27, 2013 and September 28, 2012 as follows ($ in millions):

[0000833444-14-000124:notes:233]
|  | For the Years Ended |
|  | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
| (Expense)/income |  |  |  |  |  |
| 2007 Tax Sharing Agreement | $ | (21 | ) |  | $ | — |  |  | $ | (4 | ) |
| 2012 Tax Sharing Agreement | 15 |  |  | (32 | ) |  | — |  |

[0000833444-14-000124:notes:234]
As a result of the 2012 Separation, equity awards of certain employees were converted into the three companies. Pursuant to the terms of the 2012 Separation and Distribution Agreement, each of the three companies is responsible for issuing its own shares upon employee exercise of a stock option award or vesting of a restricted unit award. However, the 2012 Tax Sharing Agreement provides that any allowable compensation tax deduction for such awards is to be claimed by the employee's current employer. The 2012 Tax Sharing Agreement requires the employer claiming a tax deduction for shares issued by the other companies to pay a percentage of the allowable tax deduction to the company issuing the equity.

[0000833444-14-000124:notes:235]
During 2014, Tyco incurred a charge of $6 million, to make payments to ADT and Pentair based on estimated allowable deductions for ADT and Pentair shares issued to Company employees, offset by income of $1 million to be received from ADT and Pentair for Company shares issued to their employees, resulting in a net impact of approximately $5 million which was recorded in Other expense, net within Tyco's Consolidated Statement of Operations.  Offsetting this charge was approximately $20 million related to the finalization of audits of fiscal years 2005 through 2007.  Additionally, a charge of $21 million was recorded primarily related to the finalization of various audits under the 2007 Tax Sharing Agreement.

[0000833444-14-000124:notes:236]
During 2013, Tyco incurred a charge of $38 million, to make payments to ADT and Pentair based on estimated allowable deductions for ADT and Pentair shares issued to Company employees, offset by income of $6 million to be received from ADT and Pentair for Company shares issued to their employees, resulting in a net impact of approximately $32 million which was recorded in Other expense, net within Tyco's Consolidated Statement of Operations.

[0000833444-14-000124:notes:237]
Other Income Tax Matters

[0000833444-14-000124:notes:238]
Except for earnings that are currently distributed, no additional material provision has been made for U.S. or non-U.S. income taxes on the undistributed earnings of subsidiaries or for  deferred tax liabilities for temporary differences related to investments in subsidiaries, since the earnings are expected to be permanently reinvested, the investments are essentially permanent in duration, or Tyco has concluded that no additional tax liability will arise as a result of the distribution of such earnings. A liability could arise if amounts are distributed by such subsidiaries or if such subsidiaries are ultimately disposed. It is not practicable to estimate the additional income taxes related to permanently reinvested earnings or the basis differences related to investments in subsidiaries.


## us-gaap:IncomeTaxPolicyTextBlock

[0000833444-14-000124:notes:239]
Income Taxes—Deferred tax liabilities and assets are recognized for the expected future tax consequences of events that have been reflected in the Consolidated Financial Statements. Deferred tax liabilities and assets are determined based on the differences between the book and tax bases of particular assets and liabilities and operating loss carryforwards, using tax rates in effect for the years in which the differences are expected to reverse. A valuation allowance is provided to offset deferred tax assets if, based upon the available evidence, including consideration of tax planning strategies, it is more-likely-than-not that some or all of the deferred tax assets will not be realized.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-14-000124:notes:240]
Inventory

[0000833444-14-000124:notes:241]
Inventories consisted of the following ($ in millions):

[0000833444-14-000124:notes:242]
|  | As ofSeptember 26,2014 |  | As ofSeptember 27,2013 |
| Purchased materials and manufactured parts | $ | 159 |  |  | $ | 157 |  |
| Work in process | 86 |  |  | 93 |  |
| Finished goods | 383 |  |  | 395 |  |
| Inventories | $ | 628 |  |  | $ | 645 |  |

[0000833444-14-000124:notes:243]
Inventories are recorded at the lower of cost (primarily first-in, first-out) or market value.


## us-gaap:InventoryPolicyTextBlock

[0000833444-14-000124:notes:244]
Inventories—Inventories are recorded at the lower of cost (primarily first-in, first-out) or market value.


## us-gaap:InvestmentPolicyTextBlock

[0000833444-14-000124:notes:245]
Investments—The Company invests in debt and equity securities. Long-term investments in marketable equity securities that represent less than twenty percent ownership are marked to market at the end of each accounting period. Unrealized gains and losses are recognized in Accumulated other comprehensive loss within Tyco shareholders' equity for available for sale securities unless an unrealized loss is deemed to be other than temporary, in which case such loss is charged to earnings.  Unrealized gains and losses are recognized in Other income (expense), net for trading securities. Management determines the proper classification of investments at the time of purchase and reevaluates such classifications as of each balance sheet date. Realized gains and losses on sales of investments are recorded in Other income (expense), net in the Consolidated Statements of Operations.

[0000833444-14-000124:notes:246]
Other equity investments for which the Company does not have the ability to exercise significant influence and for which there is not a readily determinable market value are accounted for under the cost method of accounting. Each reporting period, the Company evaluates the carrying value of its investments accounted for under the cost method of accounting, such that they are recorded at the lower of cost or estimated net realizable value. For equity investments in which the Company exerts significant influence over operating and financial policies but does not control, the equity method of accounting is used. The Company's share of net income or losses of equity investments is included in Equity income (loss) in earnings of unconsolidated subsidiaries or Selling, general and administrative expenses in the Consolidated Statements of Operations, depending on the nature of the investment.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000833444-14-000124:notes:247]
Recently Adopted Accounting Pronouncements—In January 2013, the Financial Accounting Standards Board ("FASB") issued authoritative guidance clarifying the scope of disclosures about offsetting assets and liabilities. The guidance clarifies that the scope of the disclosures applies to derivatives accounted for in accordance with authoritative guidance for derivatives and hedging, including bifurcated embedded derivatives, repurchase agreements and reverse repurchase agreements, and securities borrowing and securities lending transactions that either offset or are subject to an enforceable master netting agreement or similar agreement. The guidance is applied retrospectively and became effective for Tyco in the first quarter of fiscal 2014.  The adoption of this guidance did not have a material impact on the Company's disclosures.

[0000833444-14-000124:notes:248]
In February 2013, the FASB issued authoritative guidance for the reporting of amounts reclassified out of Accumulated other comprehensive income ("AOCI"). The amendment did not change the current requirements for reporting net income or Other comprehensive income ("OCI") in the financial statements. The guidance requires the presentation, either on the face of the statement where net income is presented or in the notes, of the significant reclassifications out of AOCI by the respective line items of net income if the amount reclassified is required under GAAP to be reclassified to net income in its entirety in the same reporting period. For other amounts that are not required under GAAP to be reclassified in their entirety to net income, the amendment requires a cross-reference to other disclosures under GAAP that provide additional detail about those amounts. The guidance became effective for Tyco in the first quarter of fiscal 2014 and additional disclosures are provided in Note 15.

[0000833444-14-000124:notes:249]
Recently Issued Accounting Pronouncements—In March 2013, the FASB issued authoritative guidance to resolve diversity in practice on the accounting for cumulative translation adjustment ("CTA") when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within a foreign entity. The guidance requires that the parent release any CTA into net income when the parent ceases to have a controlling financial interest in a subsidiary or group of assets within a foreign entity which results in a substantially complete liquidation of the foreign entity; when the sale of an investment in a foreign entity results in the loss of a controlling financial interest; or where an acquirer obtains control of an acquiree in which it had an equity interest immediately before the acquisition date. The guidance does not change the requirement to release a pro rata portion of the CTA into net income upon a partial sale of an equity method investment that is a foreign entity. The guidance will be effective for Tyco in the first quarter of fiscal 2015. The adoption of this guidance is not expected to have a significant impact on the Company's disclosures.

[0000833444-14-000124:notes:250]
In July 2013, the FASB issued authoritative guidance for the presentation of an unrecognized tax benefit when a net operating loss (“NOL”) carryforward, a similar tax loss, or a tax credit carryforward exists. The guidance requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, in the financial statements as a reduction to a deferred tax asset for a NOL carryforward, a similar tax loss, or a tax credit carryforward. If the NOL carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the jurisdiction or the tax law of the jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit will be presented in the financial statements as a liability and will not be combined with deferred tax assets.  This guidance will be effective for Tyco the first fiscal quarter of fiscal 2015. The Company does not expect the guidance to have a significant impact on its disclosures.

[0000833444-14-000124:notes:251]
In April 2014, the FASB issued authoritative guidance to change the criteria for reporting discontinued operations.  Under the new guidance, only disposals representing a strategic shift in a company's operations and financial results should be reported as discontinued operations, with expanded disclosures. In addition, disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify as a discontinued operation is required.  This guidance is effective for Tyco in the first quarter of fiscal 2016, with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance will have upon adoption.

[0000833444-14-000124:notes:252]
In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires both quantitative and qualitative disclosures, which are more comprehensive than existing revenue standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. This guidance will be effective for Tyco in the first fiscal quarter of 2018, with early adoption not permitted. The Company is currently assessing the impact the guidance will have upon adoption.

[0000833444-14-000124:notes:253]
In August 2014, the FASB issued authoritative guidance to determine when and how a company is required to disclose going-concern uncertainties in the financial statements. The guidance requires management to perform interim and annual assessments of an entity’s ability to continue as a going concern within one year of the date the financial statements are issued. An entity must provide certain disclosures if conditions or events raise substantial doubt about the entity’s ability to continue as a going concern. This guidance is effective for Tyco in the first quarter of fiscal 2018, with early adoption permitted. The Company is currently assessing the impact the guidance will have upon adoption.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-14-000124:notes:254]
Retirement Plans

[0000833444-14-000124:notes:255]
The Company sponsors a number of pension plans. The Company measures its pension plans as of its fiscal year end. The following disclosures exclude the impact of plans which are immaterial individually and in the aggregate.

[0000833444-14-000124:notes:256]
Defined Benefit Pension Plans—The Company has a number of noncontributory and contributory defined benefit retirement plans covering certain of its U.S. and non-U.S. employees, designed in accordance with conditions and practices in the countries concerned. Net periodic pension benefit cost is based on periodic actuarial valuations which use the projected unit credit method of calculation and is charged to the Consolidated Statements of Operations on a systematic basis over the expected average remaining service lives of current participants. Contribution amounts are determined based on local regulations and the advice of professionally qualified actuaries in the countries concerned. The benefits under the defined benefit plans are based on various factors, such as years of service and compensation.

[0000833444-14-000124:notes:257]
The net periodic benefit cost for material U.S. and non-U.S. defined benefit pension plans for 2014, 2013 and 2012 is as follows ($ in millions):

[0000833444-14-000124:notes:258]
|  | U.S. Plans |  | Non-U.S. Plans |
|  | 2014 |  | 2013 |  | 2012 |  | 2014 |  | 2013 |  | 2012 |
| Service cost | $ | 8 |  |  | $ | 6 |  |  | $ | 5 |  |  | $ | 9 |  |  | $ | 8 |  |  | $ | 6 |  |
| Interest cost | 38 |  |  | 33 |  |  | 35 |  |  | 57 |  |  | 50 |  |  | 53 |  |
| Expected return on plan assets | (51 | ) |  | (48 | ) |  | (42 | ) |  | (76 | ) |  | (67 | ) |  | (60 | ) |
| Amortization of initial net (asset) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (1 | ) |
| Amortization of net actuarial loss | 9 |  |  | 14 |  |  | 13 |  |  | 13 |  |  | 11 |  |  | 7 |  |
| Plan settlements, curtailments and special termination benefits | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 4 |  |  | $ | 5 |  |  | $ | 11 |  |  | $ | 4 |  |  | $ | 2 |  |  | $ | 5 |  |
| Weighted-average assumptions used to determine net periodic pension cost during the year: |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 4.9 | % |  | 3.6 | % |  | 4.5 | % |  | 4.2 | % |  | 4.2 | % |  | 5.2 | % |
| Expected return on plan assets | 8.0 | % |  | 8.0 | % |  | 8.0 | % |  | 6.7 | % |  | 6.8 | % |  | 6.8 | % |
| Rate of compensation increase | N/A |  |  | N/A |  |  | N/A |  |  | 2.8 | % |  | 2.8 | % |  | 2.7 | % |

[0000833444-14-000124:notes:259]
During fiscal 2011, the Company froze its last remaining active U.S. pension plan. For inactive plans the Company amortizes its actuarial gains and losses over the average remaining life expectancy of the pension plan participants.

[0000833444-14-000124:notes:260]
The estimated net loss for material U.S. and non-U.S. pension benefit plans that will be amortized from accumulated other comprehensive loss into net periodic benefit cost over the next fiscal year is expected to be $9 million, and $14 million, respectively.

[0000833444-14-000124:notes:261]
The change in benefit obligations, plan assets and the amounts recognized on the Consolidated Balance Sheets for material U.S. and non-U.S. defined benefit plans as of September 26, 2014 and September 27, 2013 is as follows ($ in millions):

[0000833444-14-000124:notes:262]
|  | U.S. Plans |  | Non-U.S. Plans |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Change in benefit obligations: |  |  |  |  |  |  |  |
| Benefit obligations as of beginning of year | $ | 792 |  |  | $ | 931 |  |  | $ | 1,327 |  |  | $ | 1,219 |  |
| Service cost | 8 |  |  | 6 |  |  | 9 |  |  | 8 |  |
| Interest cost | 38 |  |  | 33 |  |  | 57 |  |  | 50 |  |
| Employee contributions | — |  |  | — |  |  | 2 |  |  | 2 |  |
| Actuarial loss (gain) | 55 |  |  | (132 | ) |  | 106 |  |  | 93 |  |
| Acquisitions and mergers | — |  |  | — |  |  | 2 |  |  | 5 |  |
| Benefits and administrative expenses paid | (47 | ) |  | (46 | ) |  | (50 | ) |  | (54 | ) |
| Plan settlements, curtailments and special termination benefits | — |  |  | — |  |  | (10 | ) |  | (2 | ) |
| Currency translation | — |  |  | — |  |  | 7 |  |  | 6 |  |
| Benefit obligations as of end of year | $ | 846 |  |  | $ | 792 |  |  | $ | 1,450 |  |  | $ | 1,327 |  |
| Change in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets as of beginning of year | $ | 652 |  |  | $ | 623 |  |  | $ | 1,119 |  |  | $ | 1,016 |  |
| Actual return on plan assets | 90 |  |  | 66 |  |  | 98 |  |  | 114 |  |
| Employer contributions | 25 |  |  | 9 |  |  | 29 |  |  | 41 |  |
| Employee contributions | — |  |  | — |  |  | 2 |  |  | 2 |  |
| Acquisitions and mergers | — |  |  | — |  |  | 2 |  |  | 1 |  |
| Benefits and administrative expenses paid | (47 | ) |  | (46 | ) |  | (50 | ) |  | (54 | ) |
| Plan settlements, curtailments and special termination benefits | — |  |  | — |  |  | (10 | ) |  | (2 | ) |
| Currency translation | — |  |  | — |  |  | 12 |  |  | 1 |  |
| Fair value of plan assets as of end of year | $ | 720 |  |  | $ | 652 |  |  | $ | 1,202 |  |  | $ | 1,119 |  |
| Funded status | $ | (126 | ) |  | $ | (140 | ) |  | $ | (248 | ) |  | $ | (208 | ) |
| Net amount recognized | $ | (126 | ) |  | $ | (140 | ) |  | $ | (248 | ) |  | $ | (208 | ) |

[0000833444-14-000124:notes:263]
|  | U.S. Plans |  | Non-U.S. Plans |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Amounts recognized in the Consolidated Balance Sheets consist of: |  |  |  |  |  |  |  |
| Current liabilities | $ | (3 | ) |  | $ | (3 | ) |  | $ | (6 | ) |  | $ | (6 | ) |
| Non-current liabilities | (123 | ) |  | (137 | ) |  | (242 | ) |  | (202 | ) |
| Net amount recognized | $ | (126 | ) |  | $ | (140 | ) |  | $ | (248 | ) |  | $ | (208 | ) |
| Amounts recognized in accumulated other comprehensive loss (before income taxes) consist of: |  |  |  |  |  |  |  |
| Transition asset | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 2 |  |
| Net actuarial loss | (278 | ) |  | (271 | ) |  | (491 | ) |  | (418 | ) |
| Total loss recognized | $ | (278 | ) |  | $ | (271 | ) |  | $ | (489 | ) |  | $ | (416 | ) |
| Weighted-average assumptions used to determine pension benefit obligations at year end: |  |  |  |  |  |  |  |
| Discount rate | 4.3 | % |  | 4.9 | % |  | 3.7 | % |  | 4.2 | % |
| Rate of compensation increase | N/A |  |  | N/A |  |  | 2.9 | % |  | 2.8 | % |

[0000833444-14-000124:notes:264]
The accumulated and aggregate benefit obligation and fair value of plan assets with accumulated benefit obligations in excess of plan assets as of September 26, 2014 and September 27, 2013 were as follows ($ in millions):

[0000833444-14-000124:notes:265]
|  | U.S. Plans |  | Non-U.S. Plans |
|  | As ofSeptember 26,2014 |  | As ofSeptember 27,2013 |  | As ofSeptember 26,2014 |  | As ofSeptember 27,2013 |
| Accumulated benefit obligation | $ | 846 |  |  | $ | 792 |  |  | $ | 1,431 |  |  | $ | 1,312 |  |
| Accumulated benefit obligation and fair value of plan assets for plans with accumulated benefit obligations in excess of plan assets: |  |  |  |  |  |  |  |
| Accumulated benefit obligation | $ | 846 |  |  | $ | 792 |  |  | $ | 1,429 |  |  | $ | 1,291 |  |
| Fair value of plan assets | 720 |  |  | 652 |  |  | 1,200 |  |  | 1,095 |  |
| Aggregate benefit obligation and fair value of plan assets for plans with benefit obligations in excess of plan assets: |  |  |  |  |  |  |  |
| Aggregate benefit obligation | $ | 846 |  |  | $ | 792 |  |  | $ | 1,449 |  |  | $ | 1,323 |  |
| Fair value of plan assets | 720 |  |  | 652 |  |  | 1,202 |  |  | 1,108 |  |

[0000833444-14-000124:notes:266]
In determining the expected return on plan assets, the Company considers the relative weighting of plan assets by asset class, historical performance of asset classes over long-term periods, asset class performance expectations as well as current and future economic conditions.

[0000833444-14-000124:notes:267]
The Company's investment strategy for its pension plans is to manage the plans on a going-concern basis. Current investment policy is to maintain an adequate level of diversification while maximizing the return on assets, subject to a prudent level of portfolio risk, for the purpose of enhancing the security of benefits for participants as well as providing adequate liquidity to meet immediate and future benefit payment requirements. In addition, local regulations and local financial considerations are factors in determining the appropriate investment strategy in each country. For U.S. pension plans, this policy targets a 60% allocation to equity securities and a 40% allocation to debt securities. Various asset allocation strategies are in place for non-U.S. pension plans, with a weighted-average target allocation of 51% to equity securities, 44% to debt securities and 5% to other asset classes.

[0000833444-14-000124:notes:268]
Pension plans have the following weighted-average asset allocations:

[0000833444-14-000124:notes:269]
|  | U.S. Plans |  | Non-U.S.Plans |
|  | 2014 |  | 2013 |  | 2014 |  | 2013 |
| Asset Category: |  |  |  |  |  |  |  |
| Equity securities | 62 | % |  | 63 | % |  | 51 | % |  | 52 | % |
| Debt securities | 36 | % |  | 35 | % |  | 49 | % |  | 48 | % |
| Cash and cash equivalents | 2 | % |  | 2 | % |  | — |  |  | — |  |
| Total | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |

[0000833444-14-000124:notes:270]
Although the Company does not buy or sell any of its own securities as a direct investment for its pension funds, due to external investment management in certain commingled funds, the plans may indirectly hold Tyco securities. The aggregate amount of the securities would not be considered material relative to the total fund assets.

[0000833444-14-000124:notes:271]
The Company evaluates its defined benefit plans' asset portfolios for the existence of significant concentrations of risk. Types of investment concentration risks that are evaluated include, but are not limited to, concentrations in a single entity, industry, foreign country and individual fund manager. As of September 26, 2014, there were no significant concentrations of risk in the Company's defined benefit plan assets.

[0000833444-14-000124:notes:272]
The Company's plan assets are accounted for at fair value and are classified in their entirety based on the lowest level of input that is significant to the fair value measurement. The Company's assessment of the significance of a particular input to the fair value measurement requires judgment, and may affect the valuation of fair value of assets and their placement within the fair value hierarchy levels. The Company's asset allocations by level within the fair value hierarchy as of September 26, 2014 and September 27, 2013 are presented in the table below for the Company's material defined benefit plans.

[0000833444-14-000124:notes:273]
|  | As ofSeptember 26, 2014 |
| ($ in millions) | Level 1 |  | Level 2 |  | Total |
| Equity securities: |  |  |  |  |  |
| U.S. equity securities | $ | 207 |  |  | $ | 326 |  |  | $ | 533 |  |
| Non-U.S. equity securities | 165 |  |  | 363 |  |  | 528 |  |
| Fixed income securities: |  |  |  |  |  |
| Government and government agency securities | 45 |  |  | 325 |  |  | 370 |  |
| Corporate debt securities | — |  |  | 408 |  |  | 408 |  |
| Mortgage and other asset-backed securities | — |  |  | 69 |  |  | 69 |  |
| Cash and cash equivalents | 14 |  |  | — |  |  | 14 |  |
| Total | $ | 431 |  |  | $ | 1,491 |  |  | $ | 1,922 |  |

[0000833444-14-000124:notes:274]
|  | As ofSeptember 27, 2013 |
| ($ in millions) | Level 1 |  | Level 2 |  | Total |
| Equity securities: |  |  |  |  |  |
| U.S. equity securities | $ | 187 |  |  | $ | 296 |  |  | $ | 483 |  |
| Non-U.S. equity securities | 165 |  |  | 351 |  |  | 516 |  |
| Fixed income securities: |  |  |  |  |  |
| Government and government agency securities | 34 |  |  | 292 |  |  | 326 |  |
| Corporate debt securities | — |  |  | 379 |  |  | 379 |  |
| Mortgage and other asset-backed securities | — |  |  | 54 |  |  | 54 |  |
| Cash and cash equivalents | 13 |  |  | — |  |  | 13 |  |
| Total | $ | 399 |  |  | $ | 1,372 |  |  | $ | 1,771 |  |

[0000833444-14-000124:notes:275]
Equity securities consist primarily of publicly traded U.S. and non-U.S. equities. Publicly traded securities are valued at the last trade or closing price reported in the active market in which the individual securities are traded. Certain equity securities are held within commingled funds which are valued at the unitized net asset value ("NAV") or percentage of the net asset value as determined by the custodian of the fund. These values are based on the fair value of the underlying net assets owned by the fund.

[0000833444-14-000124:notes:276]
Fixed income securities consist primarily of government and government agency securities, corporate debt securities, and mortgage and other asset-backed securities. When available, fixed income securities are valued at the closing price reported in the active market in which the individual security is traded. Government and government agency securities and corporate debt securities are valued using the most recent bid prices or occasionally the mean of the latest bid and ask prices when markets are less liquid. Asset-backed securities including mortgage backed securities are valued using broker/dealer quotes when available. When quotes are not available, fair value is determined utilizing a discounted cash flow approach, which incorporates other observable inputs such as cash flows, underlying security structure and market information including interest rates and bid evaluations of comparable securities. Certain fixed income securities are held within commingled funds which are valued unitizing NAV determined by the custodian of the fund. These values are based on the fair value of the underlying net assets owned by the fund.

[0000833444-14-000124:notes:277]
Cash and cash equivalents consist primarily of short-term commercial paper, bonds and other cash or cash-like instruments including settlement proceeds due from brokers, stated at cost, which approximates fair value.

[0000833444-14-000124:notes:278]
The following tables set forth a summary of pension plan assets valued using NAV or its equivalent as of September 26, 2014 and September 27, 2013 ($ in millions):

[0000833444-14-000124:notes:279]
|  | As ofSeptember 26, 2014 |
| Investment ($ in millions) | FairValue |  | RedemptionFrequency |  | RedemptionNoticePeriod |
| U.S. equity securities | $ | 323 |  |  | Daily |  | 1 day, 5 days |
| Non-U.S. equity securities | 403 |  |  | Daily, Semi-monthly |  | 1 day, 2 days |
| Government and government agency securities | 159 |  |  | Daily |  | 1 day, 2 days |
| Corporate debt securities | 136 |  |  | Daily |  | 1 day, 2 days |
|  | $ | 1,021 |  |  |  |  |  |

[0000833444-14-000124:notes:280]
|  | As ofSeptember 27, 2013 |
| Investment ($ in millions) | FairValue |  | RedemptionFrequency |  | RedemptionNoticePeriod |
| U.S. equity securities | $ | 292 |  |  | Daily |  | 1 day, 5 days |
| Non-U.S. equity securities | 390 |  |  | Daily, Semi-monthly |  | 1 day, 2 days, 3 days |
| Government and government agency securities | 148 |  |  | Daily |  | 1 day, 2 days |
| Corporate debt securities | 121 |  |  | Daily |  | 1 day, 2 days |
|  | $ | 951 |  |  |  |  |  |

[0000833444-14-000124:notes:281]
The strategy of the Company's investment managers with regard to the investments valued using NAV or its equivalent is to either match or exceed relevant benchmarks associated with the respective asset category. None of the investments valued using NAV or its equivalent contain any redemption restrictions or unfunded commitments.

[0000833444-14-000124:notes:282]
During 2014, the Company contributed $25 million to its U.S. and $29 million to its non-U.S. pension plans, which represented the Company's minimum required contributions to its pension plans for fiscal year 2014. The Company did not make any voluntary contributions to its U.S. and non-U.S. plans during 2014.

[0000833444-14-000124:notes:283]
The Company's funding policy is to make contributions in accordance with the laws and customs of the various countries in which it operates as well as to make voluntary contributions from time-to-time. The Company anticipates that it will contribute at least the minimum required to its pension plans in 2015 of $13 million for the U.S. plans and $23 million for non-U.S. plans.

[0000833444-14-000124:notes:284]
Benefit payments, including those amounts to be paid out of corporate assets and reflecting future expected service as appropriate, are expected to be paid as follows ($ in millions):

[0000833444-14-000124:notes:285]
|  | U.S. Plans |  | Non-U.S. Plans |
| 2015 | $ | 43 |  |  | $ | 52 |  |
| 2016 | 44 |  |  | 50 |  |
| 2017 | 45 |  |  | 51 |  |
| 2018 | 47 |  |  | 53 |  |
| 2019 | 47 |  |  | 54 |  |
| 2020 - 2023 | 251 |  |  | 296 |  |

[0000833444-14-000124:notes:286]
The Company also participates in a number of multi-employer defined benefit plans on behalf of certain employees. Pension expense related to multi-employer plans was not material for 2014, 2013 and 2012.

[0000833444-14-000124:notes:287]
Executive Retirement Arrangements—Messrs. Kozlowski and Swartz participated in individual Executive Retirement Arrangements maintained by Tyco (the "ERA"). Under the ERA, Messrs. Kozlowski and Swartz would have fixed lifetime benefits commencing at their normal retirement age of 65.  Due to the legal settlements as described in Note 13, the Company reversed the liabilities to Messrs. Kozlowski and Swartz in fiscal years 2014 and 2012, respectively.

[0000833444-14-000124:notes:288]
Defined Contribution Retirement Plans—The Company maintains several defined contribution retirement plans, which include 401(k) matching programs, as well as qualified and nonqualified profit sharing and share bonus retirement plans. Expense for the defined contribution plans is computed as a percentage of participants' compensation and was $65 million, $63 million and $58 million for 2014, 2013 and 2012, respectively. The Company maintained an unfunded Supplemental Executive Retirement Plan ("SERP") for fiscal years 2012. This plan was nonqualified and restored the employer match that certain employees lost due to IRS limits on eligible compensation under the defined contribution plans. The expense related to the SERP was not material for 2012. The SERP was merged with the other nonqualified deferred compensation plans, discussed in the next paragraph, as of September 28, 2012.

[0000833444-14-000124:notes:289]
Deferred Compensation Plans—The Company has nonqualified deferred compensation plans, which permit eligible employees to defer a portion of their compensation. A record keeping account is set up for each participant and the participant chooses from a variety of measurement funds for the deemed investment of their accounts. The measurement funds correspond to a number of funds in the Company's 401(k) plans and the account balance fluctuates with the investment returns on those funds. Deferred compensation liabilities were $95 million and $113 million as of September 26, 2014 and September 27, 2013, respectively. Deferred compensation expense was not material for 2014, 2013 and 2012.

[0000833444-14-000124:notes:290]
Postretirement Benefit Plans—The Company generally does not provide postretirement benefits other than pensions for its employees. However, certain acquired operations provide these benefits to employees who were eligible at the date of acquisition, and a small number of U.S. and Canadian operations provide ongoing eligibility for such benefits.

[0000833444-14-000124:notes:291]
Net periodic postretirement benefit cost was not material for 2014, 2013 and 2012. The Company's Consolidated Balance Sheets include unfunded postretirement benefit obligations of $32 million and $33 million as of September 26, 2014 and September 27, 2013, respectively within other liabilities. The Company's Consolidated Balance Sheets include nil of postretirement benefit assets as of both September 26, 2014 and September 27, 2013. In addition, the Company recorded a net actuarial gain of $6 million and $8 million within accumulated other comprehensive loss as of September 26, 2014 and September 27, 2013, respectively.

[0000833444-14-000124:notes:292]
The Company expects to make contributions to its postretirement benefit plans of $3 million in 2015.

[0000833444-14-000124:notes:293]
| 2015 | $ | 3 |  |
| 2016 | 3 |  |
| 2017 | 3 |  |
| 2018 | 3 |  |
| 2019 | 3 |  |
| 2020-2023 | 11 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-14-000124:notes:294]
Property, Plant and Equipment

[0000833444-14-000124:notes:295]
Property, plant and equipment consisted of the following ($ in millions):

[0000833444-14-000124:notes:296]
|  | As ofSeptember 26,2014 |  | As ofSeptember 27,2013 |
| Land | $ | 36 |  |  | $ | 35 |  |
| Buildings | 417 |  |  | 376 |  |
| Subscriber systems | 2,213 |  |  | 2,414 |  |
| Machinery and equipment | 1,271 |  |  | 1,203 |  |
| Construction in progress | 90 |  |  | 67 |  |
| Accumulated depreciation | (2,758 | ) |  | (2,811 | ) |
| Property, Plant and Equipment, net | $ | 1,269 |  |  | $ | 1,284 |  |


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000833444-14-000124:notes:297]
Property, Plant and Equipment, Net—Property, Plant and Equipment, net is recorded at cost less accumulated depreciation. Depreciation expense for fiscal years 2014, 2013 and 2012 was $268 million, $287 million and $281 million, respectively, and is recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations. Maintenance and repair expenditures are charged to expense when incurred. Except for pooled subscriber systems which are depreciated on an accelerated basis over a period of up to 15 years, depreciation is calculated using the straight-line method over the estimated useful lives of the related assets as follows:

[0000833444-14-000124:notes:298]
| Buildings and related improvements | Up to 50 years |
| Leasehold improvements | Lesser of remaining term of the lease or economic useful life |
| Subscriber systems | Up to 14 years |
| Other machinery, equipment and furniture and fixtures | Up to 21 years |

[0000833444-14-000124:notes:299]
See below for discussion of depreciation method and estimated useful lives related to subscriber systems.


## us-gaap:ReceivablesPolicyTextBlock

[0000833444-14-000124:notes:300]
Allowance for Doubtful Accounts—The allowance for doubtful accounts receivable reflects the best estimate of probable losses inherent in Tyco's receivable portfolio determined on the basis of historical experience, specific allowances for known troubled accounts and other currently available evidence.


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0000833444-14-000124:notes:301]
Total assets by segment as of September 26, 2014, September 27, 2013 and September 28, 2012 are as follows ($ in millions):

[0000833444-14-000124:notes:302]
|  | 2014 |  | 2013 |  | 2012 |
| Total Assets: |  |  |  |  |  |
| NA Installation & Services | $ | 3,870 |  |  | $ | 3,842 |  |  | $ | 3,965 |  |
| ROW Installation & Services | 3,188 |  |  | 3,113 |  |  | 3,152 |  |
| Global Products | 2,676 |  |  | 2,726 |  |  | 2,377 |  |
| Corporate and Other | 2,054 |  |  | 1,639 |  |  | 2,058 |  |
| Assets held for sale | 21 |  |  | 856 |  |  | 813 |  |
|  | $ | 11,809 |  |  | $ | 12,176 |  |  | $ | 12,365 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-14-000124:notes:303]
Related Party Transactions

[0000833444-14-000124:notes:304]
The Company has amounts due related to loans and advances issued to employees in prior years under the Company's Key Employee Loan Program, relocation programs and other advances made to executives. Loans were provided to employees under the Company's Key Employee Loan Program, which is now discontinued, except for outstanding loans for the payment of taxes upon the vesting of shares granted under our Restricted Share Ownership Plans. During the fourth quarter of 2002, the Board of Directors and new senior management at that time adopted a policy under which no new loans are allowed to be granted to any officers of the Company and existing loans are not allowed to be extended or modified. There have been no loans made to any of the Company's current executives. The outstanding loans are not collateralized and bear interest, payable annually, at a rate based on the six-month LIBOR, calculated annually as the average of the rates in effect on the first day of each of the preceding 12 months. Loans are generally repayable in 10 years; however, earlier payments are required under certain circumstances, such as when an employee is terminated. In addition, the Company made mortgage loans to certain employees under employee relocation programs. These loans are generally payable in 15 years and are collateralized by the underlying property. The maximum amount outstanding under these programs was nil and $21 million as of September 26, 2014 and September 27, 2013. Loans receivable under these programs, as well as other unsecured advances outstanding, were nil and $21 million as of September 26, 2014 and September 27, 2013. As of September 27, 2013, the total outstanding loans receivable included loans to L. Dennis Kozlowski, the Company's former chairman and chief executive officer (until June 2002). The amount outstanding under these loans, plus accrued interest, was nil and $28 million as of September 26, 2014 and September 27, 2013 and the rate of interest charged on such loans was 0.4% in 2013. Interest income on these interest bearing loans was not material for all periods presented. Certain of the above loans totaling nil and $1 million as of September 26, 2014 and September 27, 2013 are non-interest bearing.

[0000833444-14-000124:notes:305]
The Company filed civil complaints against Mr. Kozlowski, its former chief financial officer, Mark Swartz, and Frank E. Walsh, Jr., a former director for breach of fiduciary duty and other wrongful conduct. The Company has resolved each of these matters.  See Note 13 for additional information.

[0000833444-14-000124:notes:306]
During 2014, 2013 and 2012, the Company engaged in commercial transactions in the normal course of business with companies where the Company's Directors were employed and served as officers. Purchases from these companies during each year aggregated less than 1% of consolidated net revenue.


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000833444-14-000124:notes:307]
Restructuring and Asset Impairment Charges, Net

[0000833444-14-000124:notes:308]
During fiscal 2014, the Company identified and pursued opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across the Company's businesses. The Company expects to incur restructuring and restructuring related charges of in the range of $75 million to $100 million in fiscal 2015, which does not include repositioning charges as discussed below.

[0000833444-14-000124:notes:309]
The Company recorded restructuring and asset impairment charges by action and Consolidated Statement of Operations classification as follows ($ in millions):

[0000833444-14-000124:notes:310]
|  | For the Years Ended |
|  | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
| 2014 actions | $ | 44 |  |  | $ | — |  |  | $ | — |  |
| 2013 actions | 6 |  |  | 99 |  |  | — |  |
| 2012 and prior actions | (1 | ) |  | 12 |  |  | 104 |  |
| Total restructuring and asset impairment charges, net | $ | 49 |  |  | $ | 111 |  |  | $ | 104 |  |
| Charges reflected in SG&A | 2 |  |  | — |  |  | — |  |
| Charges reflected in restructuring and asset impairment charges, net | $ | 47 |  |  | $ | 111 |  |  | $ | 104 |  |

[0000833444-14-000124:notes:311]
2014 Actions

[0000833444-14-000124:notes:312]
Restructuring and asset impairment charges, net, during the year ended September 26, 2014 related to the 2014 actions are as follows ($ in millions):

[0000833444-14-000124:notes:313]
|  | For the Year EndedSeptember 26, 2014 |
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Charges Reflected in SG&A |  | Total |
| NA Installation & Services | $ | 16 |  |  | $ | — |  |  | $ | — |  |  | $ | 16 |  |
| ROW Installation & Services | 18 |  |  | 5 |  |  | — |  |  | 23 |  |
| Global Products | 3 |  |  | — |  |  | 2 |  |  | 5 |  |
| Total | $ | 37 |  |  | $ | 5 |  |  | $ | 2 |  |  | $ | 44 |  |

[0000833444-14-000124:notes:314]
The rollforward of the reserves related to 2014 actions from September 27, 2013 to September 26, 2014 is as follows ($ in millions):

[0000833444-14-000124:notes:315]
| Balance as of September 27, 2013 | $ | — |  |
| Charges | 43 |  |
| Reversals | (1 | ) |
| Utilization | (12 | ) |
| Currency translation | (1 | ) |
| Balance as of September 26, 2014 | $ | 29 |  |

[0000833444-14-000124:notes:316]
Restructuring reserves for businesses that are included within Liabilities held for sale on the Consolidated Balance Sheets are excluded from the table above.  See Note 3 for additional information.

[0000833444-14-000124:notes:317]
2013 Actions

[0000833444-14-000124:notes:318]
Restructuring and asset impairment charges, net, during the years ended September 26, 2014 and September 27, 2013 related to the 2013 actions are as follows ($ in millions):

[0000833444-14-000124:notes:319]
|  | For the Year EndedSeptember 26, 2014 |
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Total |
| NA Installation & Services | $ | (3 | ) |  | $ | 1 |  |  | $ | (2 | ) |
| ROW Installation & Services | 3 |  |  | — |  |  | 3 |  |
| Global Products | 4 |  |  | 1 |  |  | 5 |  |
| Total | $ | 4 |  |  | $ | 2 |  |  | $ | 6 |  |

[0000833444-14-000124:notes:320]
|  | For the Year EndedSeptember 27, 2013 |
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Total |
| NA Installation & Services | $ | 34 |  |  | $ | 1 |  |  | $ | 35 |  |
| ROW Installation & Services | 46 |  |  | 4 |  |  | 50 |  |
| Global Products | 9 |  |  | 2 |  |  | 11 |  |
| Corporate and Other | 3 |  |  | — |  |  | 3 |  |
| Total | $ | 92 |  |  | $ | 7 |  |  | $ | 99 |  |

[0000833444-14-000124:notes:321]
Restructuring and asset impairment charges, net, incurred cumulative to date from initiation of the 2013 actions are as follows ($ in millions):

[0000833444-14-000124:notes:322]
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Total |
| NA Installation & Services | $ | 31 |  |  | $ | 2 |  |  | $ | 33 |  |
| ROW Installation & Services | 49 |  |  | 4 |  |  | 53 |  |
| Global Products | 13 |  |  | 3 |  |  | 16 |  |
| Corporate and Other | 3 |  |  | — |  |  | 3 |  |
| Total | $ | 96 |  |  | $ | 9 |  |  | $ | 105 |  |

[0000833444-14-000124:notes:323]
The rollforward of the reserves related to 2013 actions from September 27, 2013 to September 26, 2014 is as follows ($ in millions):

[0000833444-14-000124:notes:324]
| Balance as of September 27, 2013 | $ | 68 |  |
| Charges | 13 |  |
| Reversals | (8 | ) |
| Utilization | (40 | ) |
| Currency translation | (1 | ) |
| Balance as of September 26, 2014 | $ | 32 |  |

[0000833444-14-000124:notes:325]
2012 and prior actions

[0000833444-14-000124:notes:326]
The Company continues to maintain restructuring reserves related to actions initiated prior to fiscal 2013. The total amount of these reserves was $38 million, $62 million and $102 million as of September 26, 2014, September 27, 2013 and September 28, 2012, respectively. The Company recorded $1 million of restructuring reversals, net and $12 million and $104 million of restructuring charges, net, and utilized $22 million, $52 million and $89 million for the year ended September 26, 2014, September 27, 2013 and September 28, 2012, respectively, related to 2012 and prior actions.  The aggregate remaining reserves primarily relate to facility exit costs for long-term non-cancelable lease obligations primarily within the Company's ROW Installation & Services segment.

[0000833444-14-000124:notes:327]
Total Restructuring Reserves

[0000833444-14-000124:notes:328]
As of  September 26, 2014 and September 27, 2013 , restructuring reserves related to all actions were included in the Company's Consolidated Balance Sheets as follows ($ in millions):

[0000833444-14-000124:notes:329]
|  | As of |
|  | September 26,2014 |  | September 27,2013 |
| Accrued and other current liabilities | $ | 83 |  |  | $ | 112 |  |
| Other liabilities | 16 |  |  | 18 |  |
| Total | $ | 99 |  |  | $ | 130 |  |

[0000833444-14-000124:notes:330]
Repositioning

[0000833444-14-000124:notes:331]
The Company has initiated certain global actions designed to reduce its cost structure and improve future profitability by streamlining operations and better aligning functions, which the Company refers to as repositioning actions. These actions may or may not lead to a future restructuring action. During the years ended September 26, 2014 and September 27, 2013, the Company recorded repositioning charges of $44 million and $20 million, respectively,  primarily related to professional fees which have been reflected in Selling, general and administrative expenses in the Consolidated Statement of Operations.  There were no repositioning charges incurred during fiscal 2012.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000833444-14-000124:notes:332]
Revenue Recognition—The Company recognizes revenue principally on four types of transactions—sales of products, security systems, monitoring and maintenance services, and contract sales, including the installation of fire and security systems and other construction-related projects.

[0000833444-14-000124:notes:333]
Revenue from the sales of products is recognized at the time title and risks and rewards of ownership pass. This is generally when the products reach the free-on-board shipping point, the sales price is fixed and determinable and collection is reasonably assured.

[0000833444-14-000124:notes:334]
Provisions for certain rebates, sales incentives, trade promotions, product returns and discounts to customers are accounted for as reductions in determining net revenue in the same period the related sales are recorded. These provisions are based on terms of arrangements with direct, indirect and other market participants. Rebates are estimated based on sales terms, historical experience and trend analysis.

[0000833444-14-000124:notes:335]
Sales of security monitoring systems may have multiple elements, including equipment, installation, monitoring services and maintenance agreements. The Company assesses its revenue arrangements to determine the appropriate units of accounting. When ownership of the system is transferred to the customer, each deliverable provided under the arrangement is considered a separate unit of accounting. Revenues associated with sale of equipment and related installations are recognized once delivery, installation and customer acceptance is completed, while the revenue for monitoring and maintenance services are recognized as services are rendered. Amounts assigned to each unit of accounting are based on an allocation of total arrangement consideration using a hierarchy of estimated selling price for the deliverables. The selling price used for each deliverable will be based on Vendor Specific Objective Evidence ("VSOE") if available, Third Party Evidence ("TPE") if VSOE is not available, or estimated selling price if neither VSOE or TPE is available. Revenue recognized for equipment and installation is limited to the lesser of their allocated amounts under the estimated selling price hierarchy or the non-contingent up-front consideration received at the time of installation, since collection of future amounts under the arrangement with the customer is contingent upon the delivery of monitoring and maintenance services. While the Company does not expect situations where VSOE is not available for sales of security systems and services, if such cases were to arise the Company would follow the selling price hierarchy to allocate arrangement consideration. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the customer relationship.

[0000833444-14-000124:notes:336]
Revenue from the sale of services is recognized as services are rendered. Customer billings for services not yet rendered are deferred and recognized as revenue as the services are rendered and the associated deferred revenue is included in current liabilities or long-term liabilities, as appropriate.

[0000833444-14-000124:notes:337]
Contract sales for the installation of fire protection systems, large security intruder systems and other construction-related projects are recorded primarily under the percentage-of-completion method. Profits recognized on contracts in process are based upon estimated contract revenue and related total cost of the project at completion. The extent of progress toward completion is generally measured based on the ratio of actual cost incurred to total estimated cost at completion. Revisions to cost estimates as contracts progress have the effect of increasing or decreasing profits each period. Provisions for anticipated losses are made in the period in which they become determinable. Estimated warranty costs are included in total estimated contract costs and are accrued over the construction period of the respective contracts under percentage-of-completion accounting.

[0000833444-14-000124:notes:338]
The Company recorded retainage receivables of $53 million and $48 million as of September 26, 2014 and September 27, 2013, respectively, of which $42 million were unbilled during both periods. The retainage provisions consist primarily of fire protection contracts which become due upon contract completion and acceptance. The Company expects approximately $41 million to be collected during fiscal 2015, which are reflected within Accounts receivable on the Consolidated Balance Sheet as of September 26, 2014.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-14-000124:notes:339]
The components of Accumulated other comprehensive loss are as follows ($ in millions):

[0000833444-14-000124:notes:340]
|  | CurrencyTranslationAdjustments |  | RetirementPlans |  | Accumulated OtherComprehensive Loss |
| Balance as of September 30, 2011 | $ | 70 |  |  | $ | (506 | ) |  | $ | (436 | ) |
| Other comprehensive income (loss), net of tax | 93 |  |  | (163 | ) |  | (70 | ) |
| Distribution of Tyco Flow Control and ADT | (582 | ) |  | 122 |  |  | (460 | ) |
| Balance as of September 28, 2012 | (419 | ) |  | (547 | ) |  | (966 | ) |
| Other comprehensive (loss) income, net of tax | (100 | ) |  | 79 |  |  | (21 | ) |
| Balance as of September 27, 2013 | (519 | ) |  | (468 | ) |  | (987 | ) |
| Other comprehensive loss, net of tax | (174 | ) |  | (64 | ) |  | (238 | ) |
| Balance as of September 26, 2014 | $ | (693 | ) |  | $ | (532 | ) |  | $ | (1,225 | ) |


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0000833444-14-000124:notes:341]
|  | 2014 |  | 2013 |  | 2012 |
| Net income | $ | 1,839 |  |  | $ | 533 |  |  | $ | 471 |  |
| Foreign currency translation | (133 | ) |  | (85 | ) |  | 92 |  |
| Liquidation of foreign entities (1) | (40 | ) |  | (9 | ) |  | 2 |  |
| Income tax expense (2) | (1 | ) |  | (6 | ) |  | (1 | ) |
| Foreign currency translation, net of tax | (174 | ) |  | (100 | ) |  | 93 |  |
| Net actuarial (losses) gains | (102 | ) |  | 109 |  |  | (212 | ) |
| Amortization reclassified into earnings (3) | 22 |  |  | 26 |  |  | 22 |  |
| Foreign currency and other | (2 | ) |  | (2 | ) |  | (15 | ) |
| Income tax benefit (expense) | 18 |  |  | (54 | ) |  | 42 |  |
| Defined benefit and post retirement plans, net of tax | (64 | ) |  | 79 |  |  | (163 | ) |
| Unrealized (loss) gain on marketable securities and derivative instruments (4) | (1 | ) |  | 2 |  |  | (1 | ) |
| Income tax benefit (expense) | 1 |  |  | (2 | ) |  | 1 |  |
| Unrealized loss on marketable securities and derivative instruments, net of tax | — |  |  | — |  |  | — |  |
| Total other comprehensive loss, net of tax | (238 | ) |  | (21 | ) |  | (70 | ) |
| Comprehensive income | 1,601 |  |  | 512 |  |  | 401 |  |
| Less: comprehensive gain (loss) attributable to noncontrolling interests | 1 |  |  | (3 | ) |  | (1 | ) |
| Comprehensive income attributable to Tyco common shareholders | $ | 1,600 |  |  | $ | 515 |  |  | $ | 402 |  |

[0000833444-14-000124:notes:342]
| (1) | During the years ended September 26, 2014, September 27, 2013 and September 28, 2012, $40 million of cumulative translation gains, $9 million of cumulative translation gains and $2 million of cumulative translation losses, respectively, were transferred from currency translation adjustments as a result of the sale of foreign entities. Of these amounts, $40 million, nil and $2 million, respectively, are included in Income from discontinued operations in the Consolidated Statements of Operations. |

[0000833444-14-000124:notes:343]
| (2) | Income tax expense on the net investment hedge was $1 million, $6 million, and $1 million for the years ended September 26, 2014, September 27, 2013 and September 28, 2012. |

[0000833444-14-000124:notes:344]
| (3) | Reclassified to net periodic benefit cost. See Note 14 Retirement Plans for additional information. During the year ended September 26, 2014, $6 million of net actuarial losses were transferred from amortization of net actuarial losses and included in Income from discontinued operations in the Consolidated Statements of Operations as a result of the sale of foreign entities. |

[0000833444-14-000124:notes:345]
| (4) | Reclassified realized gain (loss) on marketable securities and derivative instruments to Other expense, net. |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0000833444-14-000124:notes:346]
Long-lived assets by geographic area as of September 26, 2014, September 27, 2013 and September 28, 2012 are as follows ($ in millions):

[0000833444-14-000124:notes:347]
|  | 2014 |  | 2013 |  | 2012 |
| Long-lived assets(1): |  |  |  |  |  |
| North America(2) | $ | 905 |  |  | $ | 905 |  |  | $ | 936 |  |
| Latin America | 113 |  |  | 129 |  |  | 151 |  |
| Europe, Middle East and Africa | 338 |  |  | 340 |  |  | 359 |  |
| Asia-Pacific | 144 |  |  | 163 |  |  | 198 |  |
| Corporate and Other | 20 |  |  | 32 |  |  | 29 |  |
|  | $ | 1,520 |  |  | $ | 1,569 |  |  | $ | 1,673 |  |

[0000833444-14-000124:notes:348]
| (1) | Long-lived assets are comprised primarily of subscriber system assets, net, property, plant and equipment, net, deferred subscriber acquisition costs, net and dealer intangibles. They exclude goodwill, other intangible assets and other assets. |

[0000833444-14-000124:notes:349]
| (2) | Includes U.S. long-lived assets of $836 million, $828 million and $856 million for 2014, 2013 and 2012, respectively. |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000833444-14-000124:notes:350]
The changes in the carrying amount of the Company's warranty accrual from September 27, 2013 to September 26, 2014 were as follows ($ in millions):

[0000833444-14-000124:notes:351]
| Balance as of September 27, 2013 | $ | 31 |  |
| Warranties issued | 8 |  |
| Changes in estimates | (5 | ) |
| Settlements | (6 | ) |
| Balance as of September 26, 2014 | $ | 28 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0000833444-14-000124:notes:352]
Net revenue by geographic area for the years ended September 26, 2014, September 27, 2013 and September 28, 2012 is as follows ($ in millions):

[0000833444-14-000124:notes:353]
|  | 2014 |  | 2013 |  | 2012 |
| Net Revenue(1): |  |  |  |  |  |
| North America(2) | $ | 5,496 |  |  | $ | 5,343 |  |  | $ | 5,257 |  |
| Latin America | 500 |  |  | 456 |  |  | 427 |  |
| Europe, Middle East and Africa (3) | 2,836 |  |  | 2,758 |  |  | 2,766 |  |
| Asia-Pacific | 1,508 |  |  | 1,516 |  |  | 1,442 |  |
|  | $ | 10,340 |  |  | $ | 10,073 |  |  | $ | 9,892 |  |

[0000833444-14-000124:notes:354]
| (1) | Net revenue is attributed to individual countries based on the reporting entity that records the transaction. |

[0000833444-14-000124:notes:355]
| (2) | Includes U.S. net revenue of $4,717 million, $4,568 million and $4,478 million for 2014, 2013 and 2012, respectively. |

[0000833444-14-000124:notes:356]
| (3) | The U.K. represents the largest portion of net revenue in the Europe, Middle East and Africa region with net revenue of $1,262 million, $1,168 million and $1,162 million for 2014, 2013 and 2012, respectively. |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000833444-14-000124:notes:357]
TYCO INTERNATIONAL LTD.

[0000833444-14-000124:notes:358]
SCHEDULE II—VALUATION AND QUALIFYING ACCOUNTS

[0000833444-14-000124:notes:359]
| Description | Balance atBeginningof Year |  | AdditionsCharged toIncome |  | Acquisitions(Divestitures)and Other |  | Deductions(1) |  | Balance atEnd ofYear |
| Accounts Receivable: |  |  |  |  |  |  |  |  |  |
| Year Ended September 28, 2012 | $ | 54 |  |  | $ | 40 |  |  | $ | 6 |  |  | $ | (40 | ) |  | $ | 60 |  |
| Year Ended September 27, 2013 | $ | 60 |  |  | 55 |  |  | 1 |  |  | (36 | ) |  | $ | 80 |  |
| Year Ended September 26, 2014 | $ | 80 |  |  | 30 |  |  | 1 |  |  | (36 | ) |  | $ | 75 |  |

[0000833444-14-000124:notes:360]
| (1) | Deductions represent uncollectible accounts written off, net of recoveries. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-14-000124:notes:361]
Consolidated Segment Data

[0000833444-14-000124:notes:362]
Segment information is consistent with how management reviews the businesses, make investing and resource allocation decisions and assesses operating performance. The Company operates and reports financial and operating information in the following three segments:

[0000833444-14-000124:notes:363]
| • | NA Installation & Services designs, sells, installs, services and monitors electronic security systems and fire detection and suppression systems for commercial, industrial, retail, institutional and governmental customers in North America. |

[0000833444-14-000124:notes:364]
| • | ROW Installation & Services designs, sells, installs, services and monitors electronic security systems and fire detection and suppression systems for commercial, industrial, retail, residential, small business, institutional and governmental customers in the Rest of World ("ROW") regions. |

[0000833444-14-000124:notes:365]
| • | Global Products designs, manufactures and sells fire protection, security and life safety products, including intrusion security, anti-theft devices, breathing apparatus and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide, including products installed and serviced by our NA and ROW Installation & Services segments. |

[0000833444-14-000124:notes:366]
The Company also provides general corporate services to its segments which are reported as a fourth, non-operating segment, Corporate and Other.

[0000833444-14-000124:notes:367]
Selected information by segment is presented in the following tables ($ in millions):

[0000833444-14-000124:notes:368]
|  | 2014 |  | 2013 |  | 2012 |
| Net Revenue(1): |  |  |  |  |  |
| NA Installation & Services | $ | 3,876 |  |  | $ | 3,891 |  |  | $ | 3,962 |  |
| ROW Installation & Services | 3,920 |  |  | 3,843 |  |  | 3,830 |  |
| Global Products | 2,544 |  |  | 2,339 |  |  | 2,100 |  |
|  | $ | 10,340 |  |  | $ | 10,073 |  |  | $ | 9,892 |  |

[0000833444-14-000124:notes:369]
| (1) | Net revenue by operating segment excludes intercompany transactions. |

[0000833444-14-000124:notes:370]
|  | 2014 |  | 2013 |  | 2012 |
| Operating income (loss): |  |  |  |  |  |
| NA Installation & Services | $ | 450 |  |  | $ | 388 |  |  | $ | 374 |  |
| ROW Installation & Services | 409 |  |  | 333 |  |  | 349 |  |
| Global Products | 458 |  |  | 307 |  |  | 353 |  |
| Corporate and Other(1) | (620 | ) |  | (319 | ) |  | (498 | ) |
|  | $ | 697 |  |  | $ | 709 |  |  | $ | 578 |  |

[0000833444-14-000124:notes:371]
| (1) | Operating loss for fiscal 2014 includes asbestos related charges of $225 million related to the Yarway settlement and $240 million related to an updated valuation performed over the Company's liability for asbestos related claims (excluding Yarway claims), partially offset by $96 million of legacy legal reversal and recoveries. See Note 13 to the Consolidated Financial Statements. |

[0000833444-14-000124:notes:372]
Depreciation and amortization and capital expenditures by segment for the years ended September 26, 2014, September 27, 2013 and September 28, 2012 are as follows ($ in millions):

[0000833444-14-000124:notes:373]
|  | 2014 |  | 2013 |  | 2012 |
| Depreciation and amortization: |  |  |  |  |  |
| NA Installation & Services | $ | 137 |  |  | $ | 139 |  |  | $ | 137 |  |
| ROW Installation & Services | 144 |  |  | 178 |  |  | 172 |  |
| Global Products | 72 |  |  | 58 |  |  | 63 |  |
| Corporate and Other | 8 |  |  | 7 |  |  | 7 |  |
|  | $ | 361 |  |  | $ | 382 |  |  | $ | 379 |  |

[0000833444-14-000124:notes:374]
|  | 2014 |  | 2013 |  | 2012 |
| Capital expenditures |  |  |  |  |  |
| NA Installation & Services | $ | 133 |  |  | $ | 92 |  |  | $ | 107 |  |
| ROW Installation & Services | 102 |  |  | 110 |  |  | 100 |  |
| Global Products | 45 |  |  | 58 |  |  | 74 |  |
| Corporate and Other | 8 |  |  | 10 |  |  | 14 |  |
|  | $ | 288 |  |  | $ | 270 |  |  | $ | 295 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-14-000124:notes:375]
Shareholders' Equity and Comprehensive Income

[0000833444-14-000124:notes:376]
Dividends

[0000833444-14-000124:notes:377]
The Company makes dividend payments from its contributed surplus equity position in its Swiss statutory accounts. These payments are made free of Swiss withholding taxes and are effectively denominated in U.S. dollars.

[0000833444-14-000124:notes:378]
Under Swiss law, the authority to declare dividends is vested in the general meeting of shareholders.  On March 5, 2014, the Company's shareholders approved an annual cash dividend of $0.72 per common share.  Payment of the dividend is to be made in four quarterly installments of $0.18 from May 2014 through February 2015.  As a result, during the quarter ended March 28, 2014, the Company recorded an accrued dividend of $332 million within Accrued and other current liabilities and a corresponding reduction to Contributed surplus on the Company's Consolidated Balance Sheet. The first installment was paid on May 21, 2014 to shareholders of record on April 25, 2014.  The second installment was paid on August 20, 2014 to shareholders of record on July 25, 2014.  The third installment was paid on November 13, 2014 to stockholders of record on October 24, 2014.  The fourth installment will be paid in February 2015.

[0000833444-14-000124:notes:379]
Upon the closing of the merger transaction between Tyco International Ltd. and its wholly-owned subsidiary, Tyco Ireland, which is expected to occur in November 2014, the Company's jurisdiction of incorporation will change from Switzerland to Ireland. As a result, the authority to declare and pay dividends will be vested in the Board of Directors. The timing, declaration and payment of future dividends to holders of our common shares will be determined by the Company's Board of Directors and will depend upon many factors, including the Company's financial condition and results of operations, the capital requirements of the Company's businesses, industry practice and any other relevant factors.

[0000833444-14-000124:notes:380]
Under Irish law, dividends may only be paid (and share repurchases and redemptions must generally be funded) out of “distributable reserves,” which Tyco Ireland will not have immediately following the closing of the merger between Tyco International Ltd. and Tyco Ireland. The creation of distributable reserves of Tyco Ireland by way of a capital reduction of Tyco Ireland requires the approval of the Irish High Court and, in connection with seeking such court approval, the Company has obtained the approval of its shareholders to create distributable reserves for Tyco Ireland (through the reduction of the share premium account of Tyco Ireland).

[0000833444-14-000124:notes:381]
The approval of the Irish High Court is expected within approximately six to twelve weeks following the closing of the merger between Tyco International Ltd. and Tyco Ireland. The Company is not aware of any reason why the Irish High Court would not approve the creation of distributable reserves. However, the issuance of the required order is a matter for the discretion of the Irish High Court. In the event that distributable reserves of Tyco Ireland are not created, no distributions by way of dividends, share repurchases or otherwise will be permitted under Irish law (with the exception of the dividend that is scheduled to be paid in February 2015) until such time as the group has created sufficient distributable reserves from its trading activities.

[0000833444-14-000124:notes:382]
On March 6, 2013, the Company's shareholders approved a cash dividend of $0.64 per share, payable to shareholders in four quarterly installments of $0.16 in May 2013, August 2013, November 2013 and February 2014.  As a result, during the quarter ended March 29, 2013, the Company recorded an accrued dividend of $296 million within Accrued and other current liabilities and a corresponding reduction to Contributed surplus on the Company's Consolidated Balance Sheet.  The first installment of $0.16 was paid on May 22, 2013 to shareholders of record on April 26, 2013.  The second installment of $0.16 was paid on August 21, 2013 to shareholders of record on July 26, 2013.  The third installment of $0.16 was paid on November 14, 2013 to shareholders of record on October 25, 2013.  The fourth installment of $0.16 was paid on February 19, 2014 to shareholders of record on January 24, 2014.

[0000833444-14-000124:notes:383]
On March 7, 2012, the Company's shareholders approved a cash dividend of $0.50 per share, payable to shareholders in two quarterly installments of $0.25 on May 23, 2012 and August 22, 2012. The first installment of $0.25 of the $0.50 dividend was paid on May 23, 2012 to shareholders on record on April 27, 2012. The second installment of $0.25 of the $0.50 dividend was paid on August 22, 2012 to shareholders on record on July 27, 2012. On September 17, 2012, the Company's shareholders approved a cash dividend of $0.30 per share, payable to shareholders in two quarterly installments of $0.15 on November 15, 2012 and February 20, 2013. The $0.30 dividend reflects the impact of the 2012 Separation on the Company's dividend policy.  The first installment of $0.15 of the $0.30 dividend was paid on November 15, 2012 to shareholders of record on October 16, 2012. The second installment of $0.15 of the $0.30 dividend was paid on February 20, 2013 to shareholders of record on January 25, 2013. As a result, the Company recorded an accrued dividend of $231 million as of March 7, 2012 and an additional accrued dividend of $139 million as of September 17, 2012 within Accrued and other current liabilities and a corresponding reduction to Contributed surplus on the Company's Consolidated Balance Sheet.

[0000833444-14-000124:notes:384]
Common Stock

[0000833444-14-000124:notes:385]
As of September 26, 2014, the Company's share capital amounted to CHF 243,181,525, or 486,363,050 registered common shares with a par value of CHF 0.50 per share. Until March 6, 2015, the Board of Directors may increase the Company's share capital by a maximum amount of CHF 121,500,000 by issuing a maximum of 243,000,000 shares. In addition, (i) the share capital of the Company may be increased by an amount not exceeding CHF 23,964,755 through the issue of a maximum of 47,929,510 shares through the exercise of conversion and/or option or warrant rights granted in connection with bonds, notes or similar instruments and (ii) the share capital of the Company may be increased by an amount not exceeding CHF 23,964,755 through the issue of a maximum of 47,929,510 shares to employees and other persons providing services to the Company. Although the Company states its par value in Swiss francs, it continues to use the U.S. dollar as its reporting currency for preparing its Consolidated Financial Statements.

[0000833444-14-000124:notes:386]
On March 6, 2013, shareholders of the Company approved a reduction of the Company's registered share capital from CHF 3,258,632,435 to CHF 243,181,525 by reducing the par value of each share from CHF 6.70 to CHF 0.50 per share and correspondingly increasing the Company's contributed surplus by CHF 3,015,450,910. The reduction in registered share capital and corresponding increase in contributed surplus, which did not result in any changes to total Shareholders' Equity, was recorded during the year ended September 27, 2013.

[0000833444-14-000124:notes:387]
On September 9, 2014, shareholders of the Company approved the merger between the Company and Tyco Ireland, and the merger is expected to be completed in November 2014.  Upon completion of the merger, the Company’s authorized share capital will be $11,000,000 and €40,000, divided into 1,000,000,000 ordinary shares with a par value of $0.01 per share, 100,000,000 preferred shares with a par value of $0.01 per share and 40,000 ordinary A shares with a par value of €1.00 per share. Based on the number of Company shares outstanding as of November 7, 2014, Tyco Ireland is expected to issue 418,465,546 ordinary shares with a nominal value of $0.01 per share to the former shareholders of the Company on the completion of the Merger, which will constitute all of the Company’s outstanding share capital.

[0000833444-14-000124:notes:388]
Share Repurchase Program

[0000833444-14-000124:notes:389]
The Company's Board of Directors approved the $1 billion and $1.75 billion 2014 share repurchase programs and the $600 million 2013 share repurchase program in September 2014, March 2014 and January 2013, respectively. Share repurchases reduce the amount of common shares outstanding and decrease the dividends declared on the Consolidated Statement of Shareholders' Equity. Shares repurchased by the Company by fiscal year and share repurchase program are provided below:

[0000833444-14-000124:notes:390]
|  | 2014 ShareRepurchase Programs |  | 2013 ShareRepurchase Program |  | 2011 ShareRepurchase Program |
|  | Shares(in millions) |  | Amounts($ in billions) |  | Shares(in millions) |  | Amounts($ in billions) |  | Shares(in millions) |  | Amounts($ in billions) |
| Approved Repurchase Amount |  |  |  | $ | 2.8 |  |  |  |  |  | $ | 0.6 |  |  |  |  |  | $ | 1.0 |  |
| Repurchases |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal 2014 | 30.0 |  |  | 1.4 |  |  | 12.0 |  |  | 0.5 |  |  |  |  |  |
| Fiscal 2013 | N/A |  |  | N/A |  |  | 3.0 |  |  | 0.1 |  |  | 7.0 |  |  | 0.2 |  |
| Fiscal 2012 | N/A |  |  | N/A |  |  | N/A |  |  | N/A |  |  | 11.0 |  |  | 0.5 |  |
| Fiscal 2011 | N/A |  |  | N/A |  |  | N/A |  |  | N/A |  |  | 6.0 |  |  | 0.3 |  |
| Remaining Amount Available |  |  | $ | 1.4 |  |  |  |  | $ | — |  |  |  |  | $ | — |  |

[0000833444-14-000124:notes:391]
Comprehensive Income

[0000833444-14-000124:notes:392]
Accumulated Other Comprehensive Loss


## us-gaap:SubsequentEventsTextBlock

[0000833444-14-000124:notes:393]
Subsequent Events

[0000833444-14-000124:notes:394]
Subsequent to September 26, 2014, the Company repurchased approximately 10 million common shares for approximately $417 million which completed the $1.75 billion share repurchase authority approved by the Company's Board of Directors in March 2014.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000833444-14-000124:notes:395]
Supplementary Consolidated Balance Sheet Information

[0000833444-14-000124:notes:396]
Selected supplementary Consolidated Balance Sheet information as of September 26, 2014 and September 27, 2013 is as follows ($ in millions):

[0000833444-14-000124:notes:397]
|  | As ofSeptember 26,2014 |  | As ofSeptember 27,2013 |
| Contracts in process | $ | 470 |  |  | $ | 370 |  |
| Other | 683 |  |  | 469 |  |
| Prepaid expenses and other current assets | $ | 1,153 |  |  | $ | 839 |  |
| Accrued payroll and payroll related costs | $ | 318 |  |  | $ | 311 |  |
| Accrued guarantees | 218 |  |  | 25 |  |
| Accrued insurance commitments - asbestos | 346 |  |  | 58 |  |
| Other | 1,285 |  |  | 1,458 |  |
| Accrued and other current liabilities | $ | 2,167 |  |  | $ | 1,852 |  |
| Accrued insurance commitments - asbestos | $ | 487 |  |  | $ | 250 |  |
| Long-term pension and postretirement liabilities | 417 |  |  | 391 |  |
| Other | 973 |  |  | 1,240 |  |
| Other liabilities | $ | 1,877 |  |  | $ | 1,881 |  |


## tyc:AcquisitionCostsPolicyTextBlock

[0000833444-14-000124:notes:398]
Acquisition Costs—Costs incurred to acquire new businesses, new product lines or similar assets are expensed when incurred and are included in Selling, general and administrative expenses. See Note 5 for additional information.


## tyc:AsbestosContingenciesAndInsuranceReceivablesPolicyTextBlock

[0000833444-14-000124:notes:399]
Asbestos-Related Contingencies and Insurance Receivables—The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made in the future during a defined period of time (the look-forward period). On a quarterly basis, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on a quarterly basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-14-000124:notes:400]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims. In determining the amount of insurance recoverable, the Company considers a number of factors, including available insurance, allocation methodologies, solvency and creditworthiness of the insurers. See Note 13 for additional information.


## tyc:GuaranteesDisclosureTextBlock

[0000833444-14-000124:notes:401]
Guarantees

[0000833444-14-000124:notes:402]
Certain of the Company's business segments have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the fiscal year 2015 through the completion of such transactions and would typically be triggered in the event of nonperformance. The Company's performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-14-000124:notes:403]
There are certain guarantees or indemnifications extended among Tyco, Covidien, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 Separation and Distribution Agreements and Tax Sharing Agreements. These guarantees primarily relate to certain contingent tax liabilities included in the Tax Sharing Agreements. See Note 6 for additional information.

[0000833444-14-000124:notes:404]
In addition, Tyco historically provided support in the form of financial and/or performance guarantees to various Covidien, TE Connectivity, ADT and Tyco Flow Control operating entities. In connection with both the 2007 and 2012 Separations, the Company worked with the guarantee counterparties to cancel or assign these guarantees to Covidien, TE Connectivity, ADT or Pentair, as appropriate. To the extent these guarantees were not assigned prior to the Separation dates, Tyco assumed primary liability on any remaining such support. The Company's obligations related to the 2012 Separation were $3 million, which were included in Other liabilities on the Company's Consolidated Balance Sheets as of both September 26, 2014 and September 27, 2013, with an offset to Tyco shareholders' equity on the 2012 Separation date. The Company's obligations related to the 2007 Separation were $3 million, which were included in Other liabilities on the Company's Consolidated Balance Sheets as of both September 26, 2014 and September 27, 2013, respectively, with an offset to Tyco shareholders' equity on the 2007 Separation date.

[0000833444-14-000124:notes:405]
In disposing of assets or businesses, the Company often provides representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities and unidentified tax liabilities and legal fees related to periods prior to disposition. The Company has no reason to believe that these uncertainties would have a material adverse effect on the Company's financial position, results of operations or cash flows.

[0000833444-14-000124:notes:406]
During the year ended September 26, 2014, Tyco replaced available for sale investments held as collateral for the Company's insurable liabilities with letters of credit of approximately $137 million.  As of September 26, 2014 and September 27, 2013, the Company had total outstanding letters of credit and bank guarantees of approximately $662 million and $424 million respectively.

[0000833444-14-000124:notes:407]
The Company records estimated product warranty costs at the time of sale. See Note 1 for additional information.

[0000833444-14-000124:notes:408]
Warranty accruals for businesses that are included within Liabilities held for sale on the Consolidated Balance Sheets are excluded from the table above.  See Note 3 for additional information.


## tyc:InsurableLiabilitiesPolicyTextBlock

[0000833444-14-000124:notes:409]
Insurable Liabilities—The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. Certain insurable liabilities, such as workers' compensation, are discounted using a risk-free rate of return when the pattern and timing of the future obligation is reliably determinable. The impact of the discount on the Consolidated Balance Sheets was to reduce the obligation by $17 million to $74 million as of September 26, 2014 and by $14 million to $58 million as of September 27, 2013. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage certain of its insurable liabilities. During fiscal 2013 and a portion of 2014, the captive insurance companies held certain investment accounts for the purpose of providing collateral for the Company's insurable liabilities. These investment accounts were liquidated during fiscal 2014 and replaced with other investments. See Note 12 for additional information.


## tyc:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesAndNewAccountingPronouncementsTextBlock

[0000833444-14-000124:notes:410]
Basis of Presentation and Summary of Significant Accounting Policies

[0000833444-14-000124:notes:411]
Use of Estimates—The preparation of the Consolidated Financial Statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amount of assets and liabilities, disclosure of contingent assets and liabilities and reported amounts of revenues and expenses. Significant estimates in these Consolidated Financial Statements include restructuring charges, allowances for doubtful accounts receivable, estimates of future cash flows associated with asset impairments, useful lives for depreciation and amortization, loss contingencies (including legal, environmental and asbestos reserves), insurance reserves, net realizable value of inventories, fair values of financial instruments, estimated contract revenue and related costs, income taxes and tax valuation allowances, and pension and postretirement employee benefit liabilities and expenses. Actual results could differ materially from these estimates.

[0000833444-14-000124:notes:412]
Research and Development—Research and development expenditures are expensed when incurred and are included in cost of product sales, which amounted to $193 million, $172 million and $145 million for fiscal years 2014, 2013 and 2012, respectively, related to new product development. Research and development expenses include salaries, direct costs incurred and building and overhead expenses.

[0000833444-14-000124:notes:413]
Subscriber System Assets, Dealer Intangibles and Related Deferred Revenue Accounts—The Company considers assets related to the acquisition of new customers in its electronic security business in three asset categories: internally generated residential subscriber systems outside of North America, internally generated commercial subscriber systems (collectively referred to as subscriber system assets) and customer accounts acquired through the ADT dealer program, primarily outside of North America (referred to as dealer intangibles). Subscriber system assets include installed property, plant and equipment for which Tyco retains ownership and deferred costs directly related to the customer acquisition and system installation. Subscriber system assets represent capitalized equipment (e.g. security control panels, touchpad, motion detectors, window sensors, and other equipment) and installation costs associated with electronic security monitoring arrangements under which the Company retains ownership of the security system assets in a customer's place of business or, outside of North America, residence. Installation costs represent costs incurred to prepare the asset for its intended use. The Company pays property taxes on the subscriber system assets and upon customer termination, may retrieve such assets. These assets embody a probable future economic benefit as they generate future monitoring revenue for the Company.

[0000833444-14-000124:notes:414]
Costs related to the subscriber system equipment and installation are categorized as property, plant and equipment rather than deferred costs. Deferred costs associated with subscriber system assets represent direct and incremental selling expenses (i.e. commissions) related to acquiring the customer. Commissions related to up-front consideration paid by customers in connection with the establishment of the monitoring arrangement are determined based on a percentage of the up-front fees and do not exceed deferred revenue. Such deferred costs are recorded as non-current assets and are included in Other assets within the Consolidated Balance Sheets.

[0000833444-14-000124:notes:415]
Subscriber system assets and any deferred revenue resulting from the customer acquisition are accounted for over the expected life of the subscriber. In certain geographical areas where the Company has a large number of customers that behave in a similar manner over time, the Company accounts for subscriber system assets and related deferred revenue using pools, with separate pools for the components of subscriber system assets and any related deferred revenue based on the same month and year of acquisition. The Company depreciates its pooled subscriber system assets and related deferred revenue using an accelerated method with lives up to 15 years. The accelerated method utilizes declining balance rates based on geographical area ranging from 140% to 360% for commercial subscriber pools and dealer intangibles and converts to a straight-line methodology when the resulting depreciation charge is greater than that from the accelerated method. The Company uses a straight-line method with a 14-year life for non-pooled subscriber system assets (primarily in Europe, Latin America and Asia) and related deferred revenue, with remaining balances written off upon customer termination.

[0000833444-14-000124:notes:416]
Certain contracts and related customer relationships result from purchasing residential security monitoring contracts from an external network of independent dealers who operate under the ADT dealer program, primarily outside of North America. Acquired contracts and related customer relationships are recorded at their contractually determined purchase price.

[0000833444-14-000124:notes:417]
During the first 6 months (12 months in certain circumstances) after the purchase of the customer contract, any cancellation of monitoring service, including those that result from customer payment delinquencies, results in a chargeback by the Company to the dealer for the full amount of the contract purchase price. The Company records the amount charged back to the dealer as a reduction of the previously recorded intangible asset.

[0000833444-14-000124:notes:418]
Intangible assets arising from the ADT dealer program described above are amortized in pools determined by the same month and year of contract acquisition on an accelerated basis over the period and pattern of economic benefit that is expected to be obtained from the customer relationship.

[0000833444-14-000124:notes:419]
The estimated useful life of dealer intangibles ranges from 12 to 15 years. The Company amortizes dealer intangible assets on an accelerated basis.

[0000833444-14-000124:notes:420]
Other Amortizable Intangible Assets, Net—Intangible assets primarily include contracts and related customer relationships (dealer accounts discussed above) and intellectual property.

[0000833444-14-000124:notes:421]
Other contracts and related customer relationships, as well as intellectual property consisting primarily of patents, trademarks, copyrights and unpatented technology, are amortized on a straight-line basis over 4 to 40 years. The Company evaluates the amortization methods and remaining useful lives of intangible assets on a periodic basis to determine whether events and circumstances warrant a revision to the amortization method or remaining useful lives.

[0000833444-14-000124:notes:422]
Goodwill and Indefinite-Lived Intangible Asset Impairments—Goodwill and indefinite-lived intangible assets are assessed for impairment annually and more frequently if triggering events occur (see Note 8 for additional information). In performing these assessments, management relies on and considers a number of factors, including operating results, business plans, economic projections, anticipated future cash flows, comparable market transactions (to the extent available), other market data and the Company's overall market capitalization. There are inherent uncertainties related to these factors which require judgment in applying them to the analysis of goodwill and indefinite-lived intangible assets for impairment. The Company elected to make the first day of the fourth quarter the annual impairment assessment date for all goodwill and indefinite-lived intangible assets.

[0000833444-14-000124:notes:423]
When testing for goodwill impairment, the Company first assesses qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount.  If the Company concludes it is more likely than not that the fair value of a reporting unit is less than its carrying amount, a quantitative fair value test is performed.  Based upon the Company’s most recent annual impairment test completed as of June 30, 2014, it is not more likely than not that the fair value of each reporting unit was less than its carrying value.

[0000833444-14-000124:notes:424]
Indefinite-lived intangible assets consisting primarily of trade names and franchise rights are tested for impairment using either a relief-from-royalty method or excess earnings method, respectively.

[0000833444-14-000124:notes:425]
Product Warranty—The Company records estimated product warranty costs at the time of sale. Products are warranted against defects in material and workmanship when properly used for their intended purpose, installed correctly, and appropriately maintained. Generally, product warranties are implicit in the sale; however, the customer may purchase an extended warranty. However, in most instances the warranty is either negotiated in the contract or sold as a separate component. The warranty liability is determined based on historical information such as past experience, product failure rates or number of units repaired, estimated cost of material and labor, and in certain instances estimated property damage.

[0000833444-14-000124:notes:426]
Environmental Costs—The Company is subject to laws and regulations relating to protecting the environment. Tyco provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated.

[0000833444-14-000124:notes:427]
Fair Value of Financial Instruments—Authoritative guidance for fair value measurements establishes a three-level hierarchy that ranks the quality and reliability of information used in developing fair value estimates for financial instruments. The hierarchy gives the highest priority to quoted prices in active markets and the lowest priority to unobservable data. In cases where two or more levels of inputs are used to determine fair value, a financial instrument's level is determined based on the lowest level input that is considered significant to the fair value measurement in its entirety. The three levels of the fair value hierarchy are summarized as follows:

[0000833444-14-000124:notes:428]
| • | Level 1—inputs are based upon quoted prices (unadjusted) in active markets for identical assets or liabilities which are accessible as of the measurement date. |

[0000833444-14-000124:notes:429]
| • | Level 2—inputs are based upon quoted prices for similar assets or liabilities in active markets, quoted prices for identical or similar assets or liabilities in markets that are not active, and model-derived valuations for the asset or liability that are derived principally from or corroborated by market data for which the primary inputs are observable, including forward interest rates, yield curves, credit risk and exchange rates. |

[0000833444-14-000124:notes:430]
| • | Level 3—inputs for the valuations are unobservable and are based on management's estimates and assumptions that market participants would use similar inputs in pricing the asset or liability. The fair values are therefore determined using model-based techniques such as option pricing models and discounted cash flow models. |

[0000833444-14-000124:notes:431]
All derivative financial instruments are reported on the Consolidated Balance Sheets at fair value. Derivatives used to economically hedge foreign currency denominated balance sheet items related to operating activities are reported in Selling, general and administrative expenses along with offsetting transaction gains and losses on the items being hedged. Derivatives used to manage the exposure to changes in interest rates are reported in interest expense along with offsetting transaction gains and losses on the items being hedged. Gains and losses on net investment hedges are included in the cumulative translation adjustment component of accumulated other comprehensive loss to the extent they are effective. Gains and losses on derivatives designated as cash flow hedges are recorded in accumulated other comprehensive loss and reclassified to earnings in a manner that matches the timing of the earnings impact of the hedged transactions. The Company classifies cash flows associated with the settlement of derivatives consistent with the nature of the transaction being hedged. The ineffective portion of all hedges, if any, is recognized currently in earnings. Instruments that do not qualify for hedge accounting are marked to market with changes recognized in current earnings.  See Note 12 for additional information.

[0000833444-14-000124:notes:432]
Redeemable Noncontrolling Interests—Noncontrolling interest with redemption features, such as put options, that are not solely within the Company's control are considered redeemable noncontrolling interests. The Company accretes changes in the redemption value through noncontrolling interest in subsidiaries net income attributable to the noncontrolling interest over the period from the date of issuance to the earliest redemption date. Redeemable noncontrolling interest is considered to be temporary equity and is therefore reported in the mezzanine section between liabilities and equity on the Company's Consolidated Balance Sheet at the greater of the initial carrying amount increased or decreased for the noncontrolling interest's share of net income or loss or its redemption value.


## tyc:ScheduleOfComponentsOfSeparationRelatedCostsClassificationTableTextBlock

[0000833444-14-000124:notes:433]
The components of the Separation Charges incurred within continuing operations and discontinued operations consisted of the following ($ in millions):

[0000833444-14-000124:notes:434]
|  | For the Year EndedSeptember 26, 2014 |  | For the Year EndedSeptember 27, 2013 |  | For the Year EndedSeptember 28, 2012 |
|  | ContinuingOperations |  | DiscontinuedOperations |  | Total |  | ContinuingOperations |  | DiscontinuedOperations |  | Total |  | ContinuingOperations |  | DiscontinuedOperations |  | Total |
| Loss on extinguishment of debt (See Note 10) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 453 |  |  | $ | — |  |  | $ | 453 |  |
| Professional fees | 2 |  |  | — |  |  | 2 |  |  | 5 |  |  | 1 |  |  | 6 |  |  | — |  |  | 191 |  |  | 191 |  |
| Non-cash impairment charges | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Information technology related costs | 12 |  |  | — |  |  | 12 |  |  | 10 |  |  | — |  |  | 10 |  |  | — |  |  | 30 |  |  | 30 |  |
| Employee compensation costs | — |  |  | 1 |  |  | 1 |  |  | 3 |  |  | 1 |  |  | 4 |  |  | 74 |  |  | 17 |  |  | 91 |  |
| Marketing costs | 32 |  |  | — |  |  | 32 |  |  | 40 |  |  | — |  |  | 40 |  |  | 3 |  |  | 5 |  |  | 8 |  |
| Interest expense | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | 3 |  |
| Other costs (income) | 7 |  |  | — |  |  | 7 |  |  | 11 |  |  | (10 | ) |  | 1 |  |  | 8 |  |  | 32 |  |  | 40 |  |
| Total pre-tax separation charges (income) | 53 |  |  | 1 |  |  | 54 |  |  | 69 |  |  | (8 | ) |  | 61 |  |  | 561 |  |  | 278 |  |  | 839 |  |
| Tax-related separation charges (income) | 9 |  |  | — |  |  | 9 |  |  | 22 |  |  | — |  |  | 22 |  |  | 266 |  |  | (2 | ) |  | 264 |  |
| Tax benefit on pre-tax separation charges | (15 | ) |  | — |  |  | (15 | ) |  | (13 | ) |  | — |  |  | (13 | ) |  | (5 | ) |  | (5 | ) |  | (10 | ) |
| Total separation charges, net of tax benefit | $ | 47 |  |  | $ | 1 |  |  | $ | 48 |  |  | $ | 78 |  |  | $ | (8 | ) |  | $ | 70 |  |  | $ | 822 |  |  | $ | 271 |  |  | $ | 1,093 |  |


## tyc:ScheduleOfSeparationCostsClassificationTableTextBlock

[0000833444-14-000124:notes:435]
Pre-tax separation charges were classified in continuing operations within the Company's Consolidated Statement of Operations as follows ($ in millions):

[0000833444-14-000124:notes:436]
|  | For the Years Ended |
|  | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
| Selling, general and administrative expenses ("SG&A") | $ | 52 |  |  | $ | 61 |  |  | $ | 4 |  |
| Separation costs | 1 |  |  | 8 |  |  | 71 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | 33 |  |
| Other expense, net | — |  |  | — |  |  | 453 |  |
| Total | $ | 53 |  |  | $ | 69 |  |  | $ | 561 |  |


## tyc:SeparationTransactionDisclosureTextBlock

[0000833444-14-000124:notes:437]
2012 Separation Transaction

[0000833444-14-000124:notes:438]
On September 28, 2012, the Company completed the spin-offs of ADT and Tyco Flow Control, formerly the North American residential security and flow control businesses of Tyco, respectively, into separate, publicly traded companies in the form of a distribution to Tyco shareholders.  In connection with activities taken to complete the 2012 Separation and to create the revised organizational structure of the Company, the Company incurred pre-tax charges ("Separation Charges") of $54 million, $61 million and $839 million for the years ended September 26, 2014, September 27, 2013 and September 28, 2012 respectively. The amounts presented within discontinued operations are costs directly related to the 2012 Separation that are not expected to provide a future benefit to the Company. The components of the Separation Charges incurred within continuing operations and discontinued operations consisted of the following ($ in millions):
