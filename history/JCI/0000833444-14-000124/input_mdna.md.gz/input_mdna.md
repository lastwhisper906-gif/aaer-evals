# JCI MD&A — 0000833444-14-000124


## mdna

[0000833444-14-000124:mdna:1]
Item 7.    Management's Discussion and Analysis of Financial Condition and Results of Operations

[0000833444-14-000124:mdna:2]
Results of Operations

[0000833444-14-000124:mdna:3]
Organization

[0000833444-14-000124:mdna:4]
The Consolidated Financial Statements include the consolidated results of Tyco International Ltd., a company organized under the laws of Switzerland, and its subsidiaries (hereinafter collectively referred to as "we", the "Company" or "Tyco"). The financial statements have been prepared in United States dollars ("USD"), in accordance with accounting principles generally accepted in the United States ("GAAP").

[0000833444-14-000124:mdna:5]
On May 30, 2014, we entered into a Merger Agreement ("Merger Agreement") with Tyco International plc, a newly-formed Irish public limited company and a wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement, Tyco will merge with and into Tyco Ireland, with Tyco Ireland being the surviving company.  This Merger will result in Tyco Ireland becoming Tyco's publicly-traded parent company and change the jurisdiction of organization of Tyco from Switzerland to Ireland.  The Merger received shareholder approval at the special general meeting of shareholders on September 9, 2014.  We expect the Merger to become effective in November 2014.

[0000833444-14-000124:mdna:6]
We operate and report financial and operating information in the following three segments:

[0000833444-14-000124:mdna:7]
| • | North America Installation & Services ("NA Installation & Services") designs, sells, installs, services and monitors electronic security systems and fire detection and suppression systems for commercial, industrial, retail, institutional and governmental customers in North America. |

[0000833444-14-000124:mdna:8]
| • | Rest of World Installation & Services ("ROW Installation & Services") designs, sells, installs, services and monitors electronic security systems and fire detection and suppression systems for commercial, industrial, retail, residential, small business, institutional and governmental customers in the Rest of World ("ROW") regions. |

[0000833444-14-000124:mdna:9]
| • | Global Products designs, manufactures and sells fire protection, security and life safety products, including intrusion security, anti-theft devices, breathing apparatus and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide, including products installed and serviced by our NA and ROW Installation & Services segments. |

[0000833444-14-000124:mdna:10]
We also provide general corporate services to our segments which is reported as a fourth, non-operating segment, Corporate and Other. References to the segment data are to the Company's continuing operations.

[0000833444-14-000124:mdna:11]
Certain prior period amounts have been reclassified to conform with current period presentation.  Specifically, the Company has reclassified the operations of its ADT Korea business and several other ROW Installation & Services businesses to Income from discontinued operations in the Consolidated Statements of Operations and the Assets and liabilities as held for sale within the Consolidated Balance Sheets as they satisfied the criteria to be presented as discontinued operations.  We completed the sale of ADT Korea on May 22, 2014 and we expect to complete the sale of the other identified ROW Installation & Services businesses by the third quarter of fiscal 2015.  See Note 3 to our Consolidated Financial Statements for additional information.

[0000833444-14-000124:mdna:12]
Recent Transactions

[0000833444-14-000124:mdna:13]
On May 22, 2014, the Company, together with its wholly-owned subsidiary Tyco Far East Holdings Ltd. (the “Seller”) completed the sale of Tyco Fire & Security Services Korea Co. Ltd. and its subsidiaries that form and operate the Company’s ADT Korea business to an affiliate of The Carlyle Group. The transaction took the form of a sale by the Seller of all of the stock of Tyco Fire & Security Services Korea Co. Ltd. for an aggregate purchase price of $1.93 billion.

[0000833444-14-000124:mdna:14]
On March 6, 2014, the Company announced Atkore International Group Inc.'s (“Atkore”) intention to redeem all of the Company’s remaining common equity stake in Atkore.  The redemption was completed on April 9, 2014 for aggregate cash proceeds of $250 million.

[0000833444-14-000124:mdna:15]
Effective September 28, 2012, Tyco completed the spin-offs of The ADT Corporation ("ADT") and Pentair Ltd. (formerly known as Tyco Flow Control International Ltd. ("Tyco Flow Control")), formerly our North American residential security and

[0000833444-14-000124:mdna:16]
flow control businesses, respectively, into separate, publicly traded companies in the form of a distribution to Tyco shareholders. Immediately following the spin-off, Pentair, Inc. was merged with a subsidiary of Tyco Flow Control in a tax-free, all-stock merger ("the Merger"), with Pentair Ltd. ("Pentair") succeeding Pentair Inc. as an independent publicly traded company. The distribution was made on September 28, 2012, to Tyco shareholders of record on September 17, 2012.  The distributions, the Merger and related transactions are collectively referred to herein as the "2012 Separation".

[0000833444-14-000124:mdna:17]
As a result of the 2012 Separation, we incurred separation related costs during fiscal 2014, 2013 and 2012 including professional services, marketing and information technology related costs, and we expect to continue to incur separation related costs during fiscal 2015.  During fiscal 2014, the Company incurred pre-tax costs related to the 2012 Separation of $53 million recorded within continuing operations (primarily in Selling, general and administrative expenses) and pre-tax costs of $1 million within discontinued operations.  During 2013, the Company incurred pre-tax costs related to the 2012 Separation of $69 million recorded within continuing operations (primarily within Selling, general and administrative expenses) and pre-tax gain of $8 million within discontinued operations.  During 2012, we incurred separation related costs including debt refinancing, tax restructuring, professional services, restructuring and impairment charges and employee-related costs.  During 2012, the Company incurred pre-tax costs related to the 2012 Separation of $561 million recorded within continuing operations and $278 million within discontinued operations. Costs incurred within continuing operations in fiscal 2012 include a charge of $453 million due to the early extinguishment of debt, as the Company refinanced its long-term debt as a result of the 2012 Separation.

[0000833444-14-000124:mdna:18]
During fiscal 2014 and 2013, respectively, the Company paid $58 million and $165 million in separation costs, all of which is included within continuing operations.  During fiscal 2012, the Company paid $186 million in separation costs, $18 million of which is included within continuing operations. See Note 2 to the Consolidated Financial Statements.

[0000833444-14-000124:mdna:19]
Business Overview

[0000833444-14-000124:mdna:20]
We are a leading global provider of security products and services, fire detection and suppression products and services and life safety products. We utilize our extensive global footprint of approximately 900 locations, including manufacturing facilities, service and distribution centers, monitoring centers and sales offices, to provide solutions and localized expertise to our global customer base. We provide an extensive range of product and service offerings to over 3 million customers in more than 100 countries through multiple channels. Our revenues are broadly diversified across the United States and Canada (collectively “North America”); Central America and South America (collectively “Latin America”); Europe, the Middle East, and Africa (collectively “EMEA”) and the Asia-Pacific geographic areas. The following chart reflects our fiscal 2014 net revenue by geographic area.

[0000833444-14-000124:mdna:21]
36

[0000833444-14-000124:mdna:22]
Fiscal 2014 Net Revenue by Geographic Area

[0000833444-14-000124:mdna:23]
Our end-use customers, to whom we may sell directly or through wholesalers, distributors, commercial builders or contractors, are also broadly diversified and include:

[0000833444-14-000124:mdna:24]
| • | Commercial customers, including residential and commercial property developers, financial institutions, food service businesses and commercial enterprises; |

[0000833444-14-000124:mdna:25]
| • | Industrial customers, including companies in the oil and gas, power generation, mining, petrochemical and other industries; |

[0000833444-14-000124:mdna:26]
| • | Retail customers, including international, regional and local consumer outlets, from national chains to specialty stores; |

[0000833444-14-000124:mdna:27]
| • | Institutional customers, including a broad range of healthcare facilities, academic institutions, museums and foundations; |

[0000833444-14-000124:mdna:28]
| • | Governmental customers, including federal, state and local governments, defense installations, mass transportation networks, public utilities and other government-affiliated entities and applications; and |

[0000833444-14-000124:mdna:29]
| • | Residential and small business customers outside of North America, including owners of single family homes and local providers of a wide range of goods and services. |

[0000833444-14-000124:mdna:30]
As a global business with a varied customer base and an extensive range of products and services, our operations and results are impacted by global, regional and industry specific factors, and by political factors. Our geographic diversity and the diversity in our customer base and our products and services has helped mitigate the impact of any one industry or the economy of any single country on our consolidated operating results, financial condition and cash flows. Due to the global nature of our business and the variety of our customers, products and services, no single factor is predominantly used to forecast Company results. Rather, management monitors a number of factors to develop expectations regarding future results, including the activity of key competitors and customers, order rates for longer lead time projects, and capital expenditure budgets and spending patterns of our customers. We also monitor trends throughout the commercial and residential fire and security markets, including building codes and fire-safety standards. Our commercial installation businesses are impacted by trends in

[0000833444-14-000124:mdna:31]
37

[0000833444-14-000124:mdna:32]
commercial construction starts, while our residential business, which is located outside of North America, is impacted by new housing starts.

[0000833444-14-000124:mdna:33]
Results of Operations

[0000833444-14-000124:mdna:34]
Consolidated financial information is as follows:

[0000833444-14-000124:mdna:35]
|  | For the Years Ended |  |
| ($ in millions) | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |  |
| Net revenue | $ | 10,340 |  |  | $ | 10,073 |  |  | $ | 9,892 |  |  |
| Net revenue growth | 2.7 | % |  | 1.8 | % |  | NA |  |  |
| Organic revenue growth | 2.6 | % |  | 0.8 | % |  | NA |  |  |
| Operating income | $ | 697 |  |  | $ | 709 |  |  | $ | 578 |  |  |
| Operating margin | 6.7 | % |  | 7.0 | % |  | 5.8 | % |  |
| Interest income | $ | 14 |  |  | $ | 16 |  |  | $ | 18 |  |  |
| Interest expense | 97 |  |  | 100 |  |  | 209 |  |  |
| Other expense, net | 1 |  |  | 29 |  |  | 454 |  |  |
| Income tax expense | (24 | ) |  | (108 | ) |  | (320 | ) |  |
| Equity income (loss) in earnings of unconsolidated subsidiaries | 206 |  |  | (48 | ) |  | (26 | ) |  |
| Income (loss) from continuing operations attributable to Tyco common shareholders | 794 |  |  | 443 |  |  | (412 | ) |  |

[0000833444-14-000124:mdna:36]
Net Revenue:

[0000833444-14-000124:mdna:37]
Fiscal 2014

[0000833444-14-000124:mdna:38]
Net revenue for the year ended September 26, 2014 increased by $267 million, or 2.7%, to $10,340 million as compared to net revenue of $10,073 million for the year ended September 27, 2013. On an organic basis, net revenue grew by $255 million, or 2.6%, year over year as a result of growth in all three segments, led primarily by Global Products and to a lesser extent ROW and NA Installation & Services.  Net revenue was favorably impacted by $201 million, or 2.0%, as a result of acquisitions primarily within our ROW Installation & Services and Global Products segments.  Net revenue growth was unfavorably impacted by divestitures of $107 million, or 1.1%, primarily in our ROW and NA Installation & Services segments.  Changes in foreign currency exchange rates, primarily in our ROW Installation & Services segment, unfavorably impacted net revenue by $82 million, or 0.8%.

[0000833444-14-000124:mdna:39]
Fiscal 2013

[0000833444-14-000124:mdna:40]
Net revenue for the year ended September 27, 2013 increased by $181 million, or 1.8%, to $10,073 million as compared to net revenue of $9,892 million for the year ended September 28, 2012. On an organic basis, net revenue grew by $82 million, or 0.8%, year over year, primarily as a result of revenue growth in our Global Products segment, partially offset by a decline in our NA Installation & Services segment driven by our security business.  Net revenue was favorably impacted by acquisitions of $168 million, or 1.7%, primarily within our ROW Installation & Services and Global Products segments.  Changes in foreign currency exchange rates, primarily in our ROW Installation & Services segment, unfavorably impacted net revenue by $70 million, or 0.7%.  Net revenue growth was also unfavorably impacted by divestitures of $38 million, or 0.4%, primarily in our NA Installation & Services segment.

[0000833444-14-000124:mdna:41]
Operating Income:

[0000833444-14-000124:mdna:42]
Operating income for the year ended September 26, 2014 decreased $12 million, or 1.7%, to $697 million, as compared to operating income of $709 million for the year ended September 27, 2013. Operating income for the year ended September 26, 2014 was unfavorably impacted by asbestos related charges of $225 million relating to an agreement in principle reached with creditors of Yarway, an indirect subsidiary of the Company, and $240 million as a result of an updated valuation performed over the Company's estimated liability for asbestos related claims (excluding Yarway claims). Operating income for the year ended September 26, 2014 was favorably impacted by the reversal of a compensation reserve of $92 million established in respect of legacy litigation with former management, a gain of $16 million relating to a settlement with CIT, a former subsidiary of the Company, and a $21 million insurance recovery related to China. In addition, the year ended September 26, 2014 was also favorably impacted by a $100 million decline in environmental remediation costs related to our Global Products facility in Marinette, Wisconsin and a decrease in restructuring charges of $62 million. See Note 13 to our Consolidated Financial Statements for further information on our asbestos, environmental and legacy legal matters.

[0000833444-14-000124:mdna:43]
38

[0000833444-14-000124:mdna:44]
Operating income for the year ended September 27, 2013 increased $131 million, or 22.7%, to $709 million, as compared to operating income of $578 million for the year ended September 28, 2012. Operating income for the year ended September 27, 2013 was favorably impacted by our net revenue growth, a smaller corporate footprint as a result of the 2012 Separation, as well as a higher mix of service revenue and operational improvements across all of our businesses.  Operating income for the year ended September 27, 2013 was also favorably impacted by a $99 million decline in net asbestos charges.  Operating income for the year ended September 27, 2013 was unfavorably impacted by an $83 million increase in environmental remediation charges as well as an increase in restructuring charges.  Operating income for the year ended September 27, 2013 was also unfavorably impacted by a charge of $27 million resulting from the write-off of an insurance receivable that had been established in respect of a legacy claim.

[0000833444-14-000124:mdna:45]
Items impacting operating income for fiscal 2014, 2013 and 2012 are as follows:

[0000833444-14-000124:mdna:46]
|  | For the Years Ended |  |  |
| ($ in millions) | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |  |  |
| Restructuring, repositioning and asset impairment charges, net | $ | 93 |  |  | $ | 131 |  |  | $ | 104 |  |  |  |
| Environmental remediation costs - Marinette | — |  |  | 100 |  |  | 17 |  |  |  |
| Asbestos related charges | 462 |  |  | 12 |  |  | 111 |  |  |  |
| (Gain) loss on divestitures | (2 | ) |  | 20 |  |  | 14 |  |  |  |
| Separation costs | 53 |  |  | 69 |  |  | 75 |  |  |  |
| Legacy legal (gains) charges | (96 | ) |  | 27 |  |  | (4 | ) |  |  |
| China insurance recovery | (21 | ) |  | — |  |  | — |  |  |  |
| CIT settlement gain | (16 | ) |  | — |  |  | — |  |  |  |
| Loss on sale of investment | 7 |  |  | — |  |  | — |  |  |  |
| Acquisition and integration costs | 3 |  |  | 4 |  |  | 9 |  |  |  |
| IRS litigation costs | 4 |  |  | — |  |  | — |  |  |  |

[0000833444-14-000124:mdna:47]
We continue to identify and pursue opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across our businesses. Additionally, we initiated certain global actions during fiscal 2013 designed to reduce our cost structure and improve future profitability by streamlining operations and better aligning functions, which we refer to as repositioning actions. The Company expects to incur approximately $100 million to $150 million of restructuring and repositioning charges in fiscal 2015. See Note 4 to the Consolidated Financial Statements.

[0000833444-14-000124:mdna:48]
Income (loss) from continuing operations attributable to Tyco common shareholders:

[0000833444-14-000124:mdna:49]
Interest Income and Expense

[0000833444-14-000124:mdna:50]
Interest income was $14 million in 2014, as compared to $16 million and $18 million in 2013 and 2012, respectively. Interest income decreased in 2014 compared to 2013 primarily due to interest income received in fiscal 2013 related to a working capital adjustment related to the 2012 spin-off of Tyco Flow Control.

[0000833444-14-000124:mdna:51]
Interest expense was $97 million in 2014, as compared to $100 million and $209 million in 2013 and 2012, respectively. The weighted-average interest rate on total debt outstanding was 6.5% for all three fiscal years. The decrease in interest expense from 2012 to 2013 was primarily related to savings realized from the $2.6 billion debt redemptions in 2012. See Note 10 to the Consolidated Financial Statements.

[0000833444-14-000124:mdna:52]
39

[0000833444-14-000124:mdna:53]
Other Income (Expense), Net

[0000833444-14-000124:mdna:54]
Significant components of other income (expense), net for fiscal 2014, 2013 and 2012 are as follows:

[0000833444-14-000124:mdna:55]
|  | For the Years Ended |
| ($ in millions) | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
| Loss on extinguishment of debt (see Note 10 to the Consolidated Financial Statements) | $ | — |  |  | $ | — |  |  | $ | (453 | ) |
| 2012 Tax Sharing Agreement income (see Note 6 to the Consolidated Financial Statements) | 15 |  |  | (32 | ) |  | — |  |
| 2007 Tax Sharing Agreement loss (see Note 6 to the Consolidated Financial Statements) | (21 | ) |  | — |  |  | (4 | ) |
| Other | 5 |  | 3 |  | 3 |  |
| Total | $ | (1 | ) |  | $ | (29 | ) |  | $ | (454 | ) |

[0000833444-14-000124:mdna:56]
Effective Income Tax Rate

[0000833444-14-000124:mdna:57]
Our effective income tax rate was 3.9% during the year ended September 26, 2014.  Our effective tax rate is affected by the mix of jurisdictions in which income is earned. Our effective tax rate for the year was favorably impacted by asbestos related charges that generated a tax benefit in a high tax jurisdiction, partially offset by a reversal of a compensation reserve established in respect of legacy litigation with former management that generated tax expense in a high tax jurisdiction.

[0000833444-14-000124:mdna:58]
Our effective income tax rate was 18.1% during the year ended September 27, 2013. Our effective tax rate for the year was favorably impacted by taxes on the environmental remediation charges incurred during the second quarter of 2013, partially offset by Tax Sharing Agreement adjustments incurred throughout the year and enacted tax law changes in the fourth quarter of 2013.

[0000833444-14-000124:mdna:59]
Our effective income tax rate for the year ended September 28, 2012 was not meaningful primarily as a result of separation related charges which were incurred for which no tax benefit was recognized, as well as a valuation allowance of $235 million recorded due to net operating loss carryforwards which we do not expect to realize in future periods. Additionally, our effective income tax rate for the year ended September 28, 2012 was impacted by enacted tax law changes, favorable audit resolutions in multiple jurisdictions and a non-recurring item generating a tax benefit.

[0000833444-14-000124:mdna:60]
The rate can vary from period to period due to discrete items such as the settlement of income tax audits and changes in tax laws, as well as recurring factors, such as the geographic mix of income before taxes.

[0000833444-14-000124:mdna:61]
The valuation allowance for deferred tax assets of $2.0 billion and $1.9 billion as of September 26, 2014 and September 27, 2013, respectively, relates principally to the uncertainty of the utilization of certain deferred tax assets, primarily tax loss and credit carryforwards in various jurisdictions. Specifically, the valuation allowance as of September 26, 2014 and September 27, 2013 includes separation related charges associated with the early extinguishment of debt which further increased a net operating loss carryforward which the Company does not expect to realize in future periods. The valuation allowance was calculated and recorded when the Company determined that it was more-likely-than-not that all or a portion of our deferred tax assets would not be realized. The Company believes that it will generate sufficient future taxable income to realize the tax benefits related to the remaining net deferred tax assets on the Company's Consolidated Balance Sheets.

[0000833444-14-000124:mdna:62]
The calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax regulations in a multitude of jurisdictions across our global operations. We record tax liabilities for anticipated tax audit issues in the U.S. and other tax jurisdictions based on our estimate of whether, and the extent to which, additional taxes will be due. These tax liabilities are reflected net of related tax loss carryforwards. We adjust these liabilities in light of changing facts and circumstances; however, due to the complexity of some of these uncertainties, the ultimate resolution may result in a payment that is materially different from our current estimate of the tax liabilities. Substantially all of these potential tax liabilities are recorded in Other liabilities in the Consolidated Balance Sheets as payment is not expected within one year.

[0000833444-14-000124:mdna:63]
Equity Income (Loss) in Earnings of Unconsolidated Subsidiaries

[0000833444-14-000124:mdna:64]
Equity income (loss) in earnings of unconsolidated subsidiaries in 2014, 2013 and 2012 reflects our share of Atkore International Group Inc.'s ("Atkore") net income or loss, which is accounted for under the equity method of accounting.  Equity income (loss) in earnings of unconsolidated subsidiaries during the years ended September 26, 2014, September 27, 2013 and  September 28, 2012 was a gain of $206 million, and losses of $48 million and $26 million, respectively.

[0000833444-14-000124:mdna:65]
40

[0000833444-14-000124:mdna:66]
On March 6, 2014, we announced Atkore's intention to redeem all of our remaining common equity stake in Atkore, and on April 9, 2014, the redemption was completed for aggregate cash proceeds of $250 million.  We recognized a net gain of $216 million related to this transaction, which is comprised of a $227 million gain on the sale of the equity investment, partially offset by an $11 million loss, which is our share of loss on Atkore's debt extinguishment undertaken in connection with the redemption. See Note 3 to the Consolidated Financial Statements for additional information.

[0000833444-14-000124:mdna:67]
Segment Results

[0000833444-14-000124:mdna:68]
The following chart reflects our net revenue by operating segment, as well as the percent of net revenue by operating segment, for the years ended September 26, 2014, September 27, 2013 and September 28, 2012, respectively.

[0000833444-14-000124:mdna:69]
The segment discussions that follow describe the significant factors contributing to the changes in results for each of our segments included in continuing operations.

[0000833444-14-000124:mdna:70]
NA Installation & Services

[0000833444-14-000124:mdna:71]
NA Installation & Services designs, sells, installs, services and monitors electronic security systems and fire detection and suppression systems for commercial, industrial, retail, institutional and governmental customers in North America.

[0000833444-14-000124:mdna:72]
Financial information for NA Installation & Services for the years ended September 26, 2014, September 27, 2013 and September 28, 2012 were as follows:

[0000833444-14-000124:mdna:73]
|  | For the Years Ended |
| ($ in millions) | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
| Net revenue | $ | 3,876 |  |  | $ | 3,891 |  |  | $ | 3,962 |  |
| Net revenue decline | (0.4 | )% |  | (1.8 | )% |  | NA |  |
| Organic revenue growth (decline) | 1.0 | % |  | (1.1 | )% |  | NA |  |
| Operating income | $ | 450 |  |  | $ | 388 |  |  | $ | 374 |  |
| Operating margin | 11.6 | % |  | 10.0 | % |  | 9.4 | % |

[0000833444-14-000124:mdna:74]
41

[0000833444-14-000124:mdna:75]
The change in net revenue compared to the prior periods is attributable to the following:

[0000833444-14-000124:mdna:76]
| Factors Contributing to Year-Over-Year Change | Fiscal 2014Compared toFiscal 2013 |  | Fiscal 2013Compared toFiscal 2012 |
| Organic revenue growth (decline) | $ | 37 |  |  | $ | (45 | ) |
| Acquisitions | 19 |  |  | 7 |  |
| Divestitures | (42 | ) |  | (28 | ) |
| Impact of foreign currency | (29 | ) |  | (3 | ) |
| Other | — |  |  | (2 | ) |
| Total change | $ | (15 | ) |  | $ | (71 | ) |

[0000833444-14-000124:mdna:77]
Net revenue decreased $15 million, or 0.4%, to $3,876 million for the year ended September 26, 2014 as compared to $3,891 million for the year ended September 27, 2013.  The organic revenue growth for the year ended September 26, 2014 was primarily driven by an increase in both service and installation revenue. The impact of acquisitions was $19 million, or 0.5%, due to the acquisition of Westfire, Inc. ("Westfire"), a fire protection services company, in the first quarter of fiscal 2014, which was integrated into the NA Installation & Services and ROW Installation and Services segments.  See Note 5 to our Consolidated Financial Statements. Net revenue was unfavorably impacted by $42 million, or 1.1%, primarily due to the divestiture of our North America guarding business in the third quarter of fiscal 2013.  Changes in foreign currency exchange rates unfavorably impacted net revenue by $29 million, or 0.7%.

[0000833444-14-000124:mdna:78]
Net revenue decreased $71 million, or 1.8% to $3,891 million for the year ended September 27, 2013 as compared to $3,962 million for the year ended September 28, 2012.  Organic revenue decline for the year ended September 27, 2013 was primarily driven by a decline in revenue in the North America security business as a result of the non-residential construction market and project selectivity, partially offset by increased service revenue growth in our North America fire business.  Net revenue was unfavorably impacted by $28 million, or 0.7%, primarily due to the divestiture of our North America guarding business in the third quarter of fiscal 2013.

[0000833444-14-000124:mdna:79]
Operating Income

[0000833444-14-000124:mdna:80]
Operating income for the year ended September 26, 2014 increased $62 million, or 16.0%, to $450 million, as compared to operating income of $388 million for the year ended September 27, 2013. Operating income for the year ended September 26, 2014 increased due to a higher mix of service revenue, improved execution, lower restructuring costs, and savings realized from restructuring activities and productivity initiatives.

[0000833444-14-000124:mdna:81]
Operating income for the year ended September 27, 2013 increased $14 million, or 3.7%, to $388 million, as compared to operating income of $374 million for the year ended September 28, 2012. Operating income for the year ended September 27, 2013 increased due to a higher mix of service revenue and efficiencies gained through improved installation execution and project selectivity for the North American security business. Additionally, the year ended September 28, 2012 included a charge of $29 million for the settlement of an ERISA partial withdrawal liability assessment.  These items were partially offset by unfavorable impacts due to separation costs as well as dis-synergy costs related to the 2012 separation.

[0000833444-14-000124:mdna:82]
Key items impacting operating income for  the years ended September 26, 2014, September 27, 2013 and September 28, 2012  were as follows:

[0000833444-14-000124:mdna:83]
|  | For the Years Ended |
| ($ in millions) | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
| Separation costs | $ | 51 |  |  | $ | 49 |  |  | $ | 2 |  |
| Restructuring, repositioning and asset impairment charges, net | 13 |  |  | 36 |  |  | 45 |  |
| Legacy legal charges | — |  |  | — |  |  | 29 |  |

[0000833444-14-000124:mdna:84]
ROW Installation & Services:

[0000833444-14-000124:mdna:85]
ROW Installation & Services designs, sells, installs, services and monitors electronic security systems and fire detection and suppression systems for commercial, industrial, retail, residential, small business, institutional and governmental customers in our Continental Europe, United Kingdom, Asia, Pacific and Growth Markets regions, which are collectively our ROW regions.

[0000833444-14-000124:mdna:86]
Financial information for ROW Installation & Services for the years ended September 26, 2014, September 27, 2013 and September 28, 2012 were as follows:

[0000833444-14-000124:mdna:87]
|  | For the Years Ended |
| ($ in millions) | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
| Net revenue | $ | 3,920 |  |  | $ | 3,843 |  |  | $ | 3,830 |  |
| Net revenue growth (decline) | 2.0 | % |  | 0.3 | % |  | NA |  |
| Organic revenue growth | 1.9 | % |  | (0.2 | )% |  | NA |  |
| Operating income | $ | 409 |  |  | $ | 333 |  |  | $ | 349 |  |
| Operating margin | 10.4 | % |  | 8.7 | % |  | 9.1 | % |

[0000833444-14-000124:mdna:88]
The change in net revenue compared to the prior periods is attributable to the following:

[0000833444-14-000124:mdna:89]
| Factors Contributing to Year-Over-Year Change | Fiscal 2014Compared toFiscal 2013 |  | Fiscal 2013Compared toFiscal 2012 |
| Organic revenue growth | $ | 71 |  |  | $ | (6 | ) |
| Acquisitions | 119 |  |  | 93 |  |
| Divestitures | (67 | ) |  | (10 | ) |
| Impact of foreign currency | (46 | ) |  | (64 | ) |
| Total change | $ | 77 |  |  | $ | 13 |  |

[0000833444-14-000124:mdna:90]
Net revenue increased $77 million, or 2.0%, to $3,920 million for the year ended September 26, 2014 as compared to $3,843 million for the year ended September 27, 2013.  Organic revenue growth for the year ended September 26, 2014 was driven by service and installation growth in Growth Markets and installation growth in Asia.  Growth in these regions were offset by declines in both service and installation revenue in our Pacific, and to a lesser extent, Continental Europe regions.   Net revenue was favorably impacted by $119 million, or 3.1%, primarily due to the acquisitions within the Growth Markets and our Pacific regions during fiscal 2013. Net revenue was unfavorably impacted by $67 million, or 1.7% due to divestitures in the Pacific region. Changes in foreign currency exchanges rates unfavorably impacted net revenue by $46 million or 1.2%.

[0000833444-14-000124:mdna:91]
Net revenue increased $13 million, or 0.3%, to $3,843 million for the year ended September 27, 2013 as compared to $3,830 million for the year ended September 28, 2012.  Organic revenue decline for the year ended September 27, 2013 was primarily driven by declines in the United Kingdom, Pacific and Continental Europe, partially offset by an increase in Growth Markets.  Net revenue was favorably impacted by the impact of acquisitions of $93 million, or 2.4%, primarily due to the acquisitions within the United Kingdom and our Pacific regions during fiscal 2013 as well as acquisitions in Asia during fiscal 2012.  Net revenue was unfavorably impacted by the impact of divestitures of $10 million, or 0.3%. Changes in foreign currency exchanges rates unfavorably impacted net revenue by $64 million, or 1.7%.

[0000833444-14-000124:mdna:92]
Operating Income

[0000833444-14-000124:mdna:93]
Operating income for the year ended September 26, 2014 increased $76 million, or 22.8%, to $409 million, as compared to operating income of $333 million for the year ended September 27, 2013. Operating income for the year ended September 26, 2014 was favorably impacted by a decrease in restructuring charges and loss on divestitures, a $21 million insurance recovery related to China and the benefit of ongoing productivity initiatives, partially offset by a lower mix of high-margin service revenue in the Pacific region.

[0000833444-14-000124:mdna:94]
Operating income for the year ended September 27, 2013 decreased $16 million, or 4.6%, to $333 million, as compared to operating income of $349 million for the year ended September 28, 2012. Operating income for the year ended September 27, 2013 declined primarily due higher restructuring costs, partially offset by increased price focus on higher margin products and services and the ongoing benefit of cost containment and restructuring savings in most regions.

[0000833444-14-000124:mdna:95]
Key items impacting operating income for the years ended September 26, 2014, September 27, 2013 and September 28, 2012 were as follows:

[0000833444-14-000124:mdna:96]
|  | For the Years Ended |
| ($ in millions) | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
| Restructuring, repositioning and asset impairment charges, net | $ | 31 |  |  | $ | 64 |  |  | $ | 36 |  |
| China insurance recovery | (21 | ) |  | — |  |  | — |  |
| Loss on divestitures | 1 |  |  | 14 |  |  | 7 |  |
| Acquisition and integration costs | 3 |  |  | 2 |  |  | 4 |  |
| Loss on sale of investment | 7 |  |  | — |  |  | — |  |

[0000833444-14-000124:mdna:97]
Global Products:

[0000833444-14-000124:mdna:98]
Global Products designs, manufactures and sells fire protection, security and life safety products, including intrusion security, anti-theft devices, breathing apparatus and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide, including products installed and serviced by our NA and ROW Installation & Services segments.

[0000833444-14-000124:mdna:99]
Financial information for Global Products for the years ended September 26, 2014, September 27, 2013 and September 28, 2012 were as follows:

[0000833444-14-000124:mdna:100]
|  | For the Years Ended |
| ($ in millions) | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
| Net revenue | $ | 2,544 |  |  | $ | 2,339 |  |  | $ | 2,100 |  |
| Net revenue growth | 8.8 | % |  | 11.4 | % |  | NA |  |
| Organic revenue growth | 6.3 | % |  | 6.3 | % |  | NA |  |
| Operating income | $ | 458 |  |  | $ | 307 |  |  | $ | 353 |  |
| Operating margin | 18.0 | % |  | 13.1 | % |  | 16.8 | % |

[0000833444-14-000124:mdna:101]
The change in net revenue compared to the prior periods is attributable to the following:

[0000833444-14-000124:mdna:102]
| Factors Contributing to Year-Over-Year Change | Fiscal 2014Compared toFiscal 2013 |  | Fiscal 2013Compared toFiscal 2012 |
| Organic revenue growth | $ | 147 |  |  | $ | 133 |  |
| Acquisitions | 63 |  |  | 68 |  |
| Impact of foreign currency | (7 | ) |  | (3 | ) |
| Other | 2 |  |  | 41 |  |
| Total change | $ | 205 |  |  | $ | 239 |  |

[0000833444-14-000124:mdna:103]
Net revenue increased $205 million, or 8.8%, to $2,544 million for the year ended September 26, 2014 as compared to $2,339 million for the year ended September 27, 2013.  Organic revenue growth for the year ended September 26, 2014 was driven by growth across all three of our product platforms, particularly in security products. The impact of acquisitions was $63 million, or 2.7%, primarily due to the acquisition of Exacq Technologies ("Exacq"), a developer of open architecture video management systems for security and surveillance applications, during 2013.  Exacq has been integrated into the Global Products segment.  See Note 5 to our Consolidated Financial Statements.

[0000833444-14-000124:mdna:104]
Net revenue increased $239 million, or 11.4%, to $2,339 million for the year ended September 27, 2013 as compared to $2,100 million for the year ended September 28, 2012.  Organic revenue growth for the year ended September 27, 2013 was driven by growth across all three of our product platforms.  Net revenue was favorably impacted by acquisitions of $68 million, or 3.2%, primarily due to acquisitions within our fire and security products businesses during fiscal 2013 and 2012.  Net revenue was also favorably impacted by contractual revenue from ADT under the 2012 Separation and Distribution Agreement of $39 million or 1.9%, included within Other above.

[0000833444-14-000124:mdna:105]
44

[0000833444-14-000124:mdna:106]
Operating Income

[0000833444-14-000124:mdna:107]
Operating income for the year ended September 26, 2014 increased $151 million, or 49.2%, to $458 million, as compared to operating income of $307 million for the year ended September 27, 2013. The increase was driven by net revenue growth in the current year and the unfavorable impact of an environmental remediation charge in the comparable period, partially offset by additional investments in research and development and sales and marketing costs. See Note 13 to our Consolidated Financial Statements for further information.

[0000833444-14-000124:mdna:108]
Operating income for the year ended September 27, 2013 decreased $46 million, or 13.0%, to  $307 million, as compared to operating income of $353 million for the year ended September 28, 2012. Operating income for the year ended September 27, 2013 was unfavorably impacted by charges of $100 million recorded in the first half of fiscal 2013 for additional environmental remediation activities planned for a facility located in Marinette, Wisconsin.  Our operating income for the year ended September 27, 2013 was favorably impacted by net revenue growth and operational improvements partially offset by additional investments in research and development and sales and marketing costs.

[0000833444-14-000124:mdna:109]
Key items impacting operating income for the years ended September 26, 2014, September 27, 2013 and September 28, 2012 are as follows:

[0000833444-14-000124:mdna:110]
|  | For the Years Ended |
| ($ in millions) | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
| Environmental remediation costs - Marinette | $ | — |  |  | $ | 100 |  |  | $ | 17 |  |
| Restructuring, repositioning and asset impairment charges, net | 12 |  |  | 12 |  |  | 10 |  |
| Acquisition and integration costs | — |  |  | 2 |  |  | 4 |  |

[0000833444-14-000124:mdna:111]
Corporate and Other

[0000833444-14-000124:mdna:112]
Corporate expense increased $301 million, or 94.4%, to $620 million for the year ended September 26, 2014 as compared to $319 million for the year ended September 27, 2013. The increase in Corporate expense for the year ended September 26, 2014 was primarily due to asbestos related charges of $225 million relating to an agreement in principle reached with creditors of Yarway, an indirect subsidiary of the Company, and $240 million as a result of an updated valuation performed over the Company's estimated liability for asbestos related claims (excluding Yarway claims). The increase in expense was also due to higher restructuring, repositioning and asset impairment charges, partially offset by a $96 million reversal and recoveries from settlements with former management.  The increase in expense was also partially offset to a lesser extent by lower separation costs and a gain related to a legal settlement with CIT.  See Note 13 to our Consolidated Financial Statements for additional information related to our asbestos and legacy legal matters.

[0000833444-14-000124:mdna:113]
Corporate expense decreased $179 million, or 35.9%, to $319 million for the year ended September 27, 2013 as compared to $498 million for the year ended September 28, 2012. The decrease in Corporate expense for the year ended September 27, 2013 was primarily due to a smaller corporate footprint as a result of the 2012 Separation as well as lower separation costs.  Corporate expense also decreased due to a decline in net asbestos charges to $12 million in the year ended September 27, 2013 from $111 million in the prior year period. The net asbestos charges for the year ended September 27, 2013 primarily relate to the Yarway Corporation, which filed for bankruptcy protection during the third quarter of fiscal 2013.  The net asbestos charges during the year ended September 28, 2012 were primarily due to the Company revising its look-back period for historical claim experience and its look-forward period related to the projection of future claims.  The decreases in Corporate expense were partially offset by a charge of $27 million resulting from the write-off of an insurance receivable that had been established in respect of a legacy claim as well as a net benefit in the prior year period of approximately $33 million, primarily resulting from the reversal of a compensation reserve established in respect of legacy litigation with former management.  See Note 13 to the Consolidated Financial Statements for additional information related to our asbestos and legacy legal matters.

[0000833444-14-000124:mdna:114]
45

[0000833444-14-000124:mdna:115]
Key items included in corporate expense for the years ended September 26, 2014, September 27, 2013 and September 28, 2012  were as follows:

[0000833444-14-000124:mdna:116]
|  | For the Years Ended |
| ($ in millions) | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
| Legacy legal (gains) charges | $ | (96 | ) |  | $ | 27 |  |  | $ | 17 |  |
| Separation costs | 2 |  |  | 20 |  |  | 70 |  |
| Restructuring, repositioning and asset impairment charges, net | 37 |  |  | 19 |  |  | 13 |  |
| Asbestos related charges | 462 |  |  | 12 |  |  | 111 |  |
| (Gain) loss on divestitures | (3 | ) |  | 5 |  |  | 7 |  |
| Former management compensation reversal | — |  |  | — |  |  | (50 | ) |
| CIT settlement gain | (16 | ) |  | — |  |  | — |  |
| IRS litigation costs | 4 |  |  | — |  |  | — |  |

[0000833444-14-000124:mdna:117]
Critical Accounting Policies and Estimates

[0000833444-14-000124:mdna:118]
The preparation of the Consolidated Financial Statements in conformity with U.S. GAAP requires management to use judgment in making estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of contingent assets and liabilities and the reported amounts of revenue and expenses. The following accounting policies are based on, among other things, judgments and assumptions made by management that include inherent risks and uncertainties. Management's estimates are based on the relevant information available at the end of each period.

[0000833444-14-000124:mdna:119]
Depreciation and Amortization Methods for Security Monitoring-Related Assets—Tyco considers assets related to the acquisition of new customers in its electronic security business in three asset categories: internally generated residential subscriber systems outside of North America, internally generated commercial subscriber systems (collectively referred to as subscriber system assets) and customer accounts acquired through the ADT dealer program primarily outside of North America (referred to as dealer intangibles). Subscriber system assets include installed property, plant and equipment for which Tyco retains ownership and deferred costs directly related to the customer acquisition and system installation. Subscriber system assets and any deferred revenue resulting from the customer acquisition are accounted for over the expected life of the subscriber. In certain geographical areas where the Company has a large number of customers that behave in a similar manner over time, the Company accounts for subscriber system assets and related deferred revenue using pools, with separate pools for the components of subscriber system assets and any related deferred revenue based on the month and year of acquisition. The Company depreciates its pooled subscriber system assets and related deferred revenue using an accelerated method with lives up to 15 years. The accelerated method utilizes declining balance rates based on geographical area ranging from 140% to 360% for commercial subscriber pools and dealer intangibles and converts to a straight line methodology when the resulting depreciation charge is greater than that from the accelerated method. The Company uses a straight-line method with a 14-year life for non-pooled subscriber system assets (primarily in Europe, Latin America and Asia) and related deferred revenue, with remaining balances written off upon customer termination.

[0000833444-14-000124:mdna:120]
Revenue Recognition—Contract sales for the installation of fire protection systems, large security intruder systems and other construction-related projects are recorded primarily under the percentage-of-completion method. Profits recognized on contracts in process are based upon estimated contract revenue and related total cost of the project at completion. The risk of this methodology is its dependence upon estimates of costs at completion, which are subject to the uncertainties inherent in long-term contracts. Provisions for anticipated losses are made in the period in which they become determinable.

[0000833444-14-000124:mdna:121]
Sales of security monitoring systems may have multiple elements, including equipment, installation, monitoring services and maintenance agreements. We assess our revenue arrangements to determine the appropriate units of accounting. When ownership of the system is transferred to the customer, each deliverable provided under the arrangement is considered a separate unit of accounting. Revenues associated with sale of equipment and related installations are recognized once delivery, installation and customer acceptance is completed, while the revenue for monitoring and maintenance services are recognized as services are rendered. Amounts assigned to each unit of accounting are based on an allocation of total arrangement consideration using a hierarchy of estimated selling price for the deliverables. The selling price used for each deliverable will be based on Vendor Specific Objective Evidence ("VSOE") if available, Third Party Evidence ("TPE") if VSOE is not available, or estimated selling price if neither VSOE or TPE is available. Revenue recognized for equipment and installation is limited to the lesser of their allocated amounts under the estimated selling price hierarchy or the non-contingent up-front consideration received at the time of installation, since collection of future amounts under the arrangement with the customer is contingent upon the delivery of monitoring and maintenance services.

[0000833444-14-000124:mdna:122]
Product discounts granted are based on the terms of arrangements with direct, indirect and other market participants. Rebates are estimated based on sales terms, historical experience and trend analysis.

[0000833444-14-000124:mdna:123]
Loss Contingencies—Accruals are recorded for various contingencies including legal proceedings, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-14-000124:mdna:124]
Asbestos-Related Contingencies and Insurance Receivables—We and certain of our subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. We estimate the liability and corresponding insurance recovery for pending and future claims and defense costs based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made in the future during a defined period of time (the look-forward period). On a quarterly basis, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on a quarterly basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-14-000124:mdna:125]
In connection with the recognition of liabilities for asbestos-related matters, we record asbestos-related insurance recoveries that are probable. The estimate of asbestos-related insurance recoveries represents estimated amounts due to us for previously paid and settled claims and the probable reimbursements relating to estimated liability for pending and future claims. In determining the amount of insurance recoverable, we consider available insurance, allocation methodologies, solvency and creditworthiness of the insurers. See Note 13 to the Consolidated Financial Statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.

[0000833444-14-000124:mdna:126]
Insurable Liabilities—The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. Certain insurable liabilities are discounted using a risk-free rate of return when the pattern and timing of the future obligation is reliably determinable. The Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-14-000124:mdna:127]
Income Taxes—In determining taxable income for financial statement purposes, we must make certain estimates and judgments. These estimates and judgments affect the calculation of certain tax liabilities and the determination of the recoverability of certain of the deferred tax assets, which arise from temporary differences between the tax and financial statement recognition of revenue and expense.

[0000833444-14-000124:mdna:128]
In evaluating our ability to recover our deferred tax assets we consider all available positive and negative evidence including our past operating results, the existence of cumulative losses in the most recent years and our forecast of future taxable income. In estimating future taxable income, we develop assumptions including the amount of future pre-tax operating income, the reversal of temporary differences and the implementation of feasible and prudent tax planning strategies. These assumptions require significant judgment about the forecasts of future taxable income and are consistent with the plans and estimates we are using to manage the underlying businesses.

[0000833444-14-000124:mdna:129]
We currently have recorded valuation allowances that we will maintain until it is more-likely-than-not the deferred tax assets will be realized. Our income tax expense recorded in the future may be reduced to the extent of decreases in our valuation allowances. The realization of our remaining deferred tax assets is primarily dependent on future taxable income in the appropriate jurisdiction. Any reduction in future taxable income including but not limited to any future restructuring activities may require that we record an additional valuation allowance against our deferred tax assets. An increase in the valuation allowance could result in additional income tax expense in such period and could have a significant impact on our future earnings.

[0000833444-14-000124:mdna:130]
Changes in tax laws and rates could also affect recorded deferred tax assets and liabilities in the future. Management records the effect of a tax rate or law change on the Company's deferred tax assets and liabilities in the period of enactment. Future tax rate or law changes could have a material effect on the Company's financial condition, results of operations or cash flows.

[0000833444-14-000124:mdna:131]
In addition, the calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax regulations in a multitude of jurisdictions across our global operations. We recognize potential liabilities and record tax liabilities for anticipated tax audit issues in the U.S. and other tax jurisdictions based on our estimate of whether, and the extent to which, additional taxes will be due. These tax liabilities are reflected net of related tax loss carryforwards. We adjust these reserves in light of changing facts and circumstances; however, due to the complexity of some of these uncertainties, the ultimate resolution may result in a payment that is materially different from our current estimate of the tax liabilities. If our estimate of tax liabilities proves to be less than the ultimate assessment, an additional charge to expense would result. If payment of these amounts ultimately proves to be less than the recorded amounts, the reversal of the liabilities would result in tax benefits being recognized in the period when we determine the liabilities are no longer necessary.

[0000833444-14-000124:mdna:132]
Goodwill and Indefinite-Lived Intangible Asset Impairments—Goodwill and indefinite-lived intangible assets are assessed for impairment annually and more frequently if triggering events occur. In performing these assessments, management relies on and considers a number of factors, including operating results, business plans, economic projections, anticipated future cash flows, comparable market transactions (to the extent available), other market data and the Company's overall market capitalization.  We elected to make the first day of the fourth quarter the annual impairment assessment date for all goodwill and indefinite-lived intangible assets.

[0000833444-14-000124:mdna:133]
When testing for goodwill impairment, we first assess qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount.  If we conclude it is more likely than not that the fair value of a reporting unit is less than its carrying amount, a quantitative fair value test is performed.  Based upon our most recent annual impairment test completed as of June 30, 2014, it is more likely than not that the fair value of each reporting unit was in excess of its carrying value.

[0000833444-14-000124:mdna:134]
We recorded no goodwill impairments in conjunction with our annual goodwill impairment assessment performed during the fourth quarter of fiscal 2014.

[0000833444-14-000124:mdna:135]
Fair value determinations require considerable judgment and are sensitive to changes in underlying assumptions and factors. As a result, there can be no assurance that the estimates and assumptions made for purposes of the annual goodwill impairment test will prove to be accurate predictions of the future. Examples of events or circumstances that could reasonably be expected to negatively affect the underlying key assumptions and ultimately impact the estimated fair value of the aforementioned reporting units may include such items as follows:

[0000833444-14-000124:mdna:136]
| • | A prolonged downturn in the business environment in which the reporting units operate (i.e. sales volumes and prices) especially in the commercial construction and retailer end markets; |

[0000833444-14-000124:mdna:137]
| • | An economic recovery that significantly differs from our assumptions in timing or degree; |

[0000833444-14-000124:mdna:138]
| • | Volatility in equity and debt markets resulting in higher discount rates; and |

[0000833444-14-000124:mdna:139]
| • | Unexpected regulatory changes. |

[0000833444-14-000124:mdna:140]
While historical performance and current expectations have resulted in fair values of goodwill in excess of carrying values, if our assumptions are not realized, it is possible that in the future an impairment charge may need to be recorded. However, it is not possible at this time to determine if an impairment charge would result or if such a charge would be material.

[0000833444-14-000124:mdna:141]
Long-Lived Assets—Asset groups held and used by the Company, including property, plant and equipment and amortizable intangible assets, are reviewed for impairment whenever events or changes in business circumstances indicate that the carrying amount of the asset group may not be fully recoverable. Tyco performs undiscounted operating cash flow analyses to determine if impairment exists. For purposes of recognition and measurement of an impairment for assets held for use, Tyco groups assets and liabilities at the lowest level for which cash flows are separately identified. If an impairment is determined to exist, any related impairment loss is calculated based on fair value. Impairments to long-lived assets to be disposed of are recorded based upon the fair value less cost to sell of the applicable assets. The calculation of the fair value of long-lived assets is based on assumptions concerning the amount and timing of estimated future cash flows and assumed discount rates, reflecting varying degrees of perceived risk. Since judgment is involved in determining the fair value and useful lives of long-lived assets, there is a risk that the carrying value of our long-lived assets may be overstated or understated.

[0000833444-14-000124:mdna:142]
Pension and Postretirement Benefits—Our pension expense and obligations are developed from actuarial valuations. Two critical assumptions in determining pension expense and obligations are the discount rate and expected long-term return on plan assets. We evaluate these assumptions at least annually. Other assumptions reflect demographic factors such as retirement, mortality and turnover and are evaluated periodically and updated to reflect our actual experience. Actual results may differ from actuarial assumptions resulting in actuarial gains and losses. For active plans, such actuarial gains and losses will be amortized over the average expected service period of the participants and in the case of inactive plans over the average remaining life expectancy of participants. The discount rate represents the market rate for high-quality fixed income investments and is used to calculate the present value of the expected future cash flows for benefit obligations under our

[0000833444-14-000124:mdna:143]
pension plans. A decrease in the discount rate increases the present value of pension benefit obligations. A 25 basis point decrease in the discount rate would increase the present value of pension obligations by approximately $87 million and increase our annual pension expense by approximately $2 million. We consider the relative weighting of plan assets by class, historical performance of asset classes over long-term periods, asset class performance expectations as well as current and future economic conditions in determining the expected long-term return on plan assets. A 25 basis point decrease in the expected long-term return on plan assets would increase our annual pension expense by approximately $5 million.

[0000833444-14-000124:mdna:144]
Liquidity and Capital Resources

[0000833444-14-000124:mdna:145]
A fundamental objective of the Company is to have sufficient liquidity, balance sheet strength, and financial flexibility to fund the operating and capital requirements of its core businesses around the world. The primary source of funds to finance our operations and capital expenditures is cash generated by operations. In addition, we maintain a commercial paper program, have access to a committed revolving credit facility and have access to equity and debt capital from public and private sources. We continue to balance our operating, investing and financing uses of cash through investments and acquisitions in our core businesses, dividends and share repurchases. In addition, we believe our cash position, amounts available under our credit facility, commercial paper program and cash provided by operating activities will be adequate to cover our operational and business needs in the foreseeable future.

[0000833444-14-000124:mdna:146]
As of September 26, 2014 and September 27, 2013, our cash and cash equivalents, short- and long-term debt, and Tyco shareholder's equity are as follows:

[0000833444-14-000124:mdna:147]
|  | As of |
| ($ in millions) | September 26, 2014 |  | September 27, 2013 |
| Cash and cash equivalents | $ | 892 |  |  | $ | 563 |  |
| Total debt | $ | 1,463 |  |  | $ | 1,463 |  |
| Shareholders' equity | $ | 4,647 |  |  | $ | 5,098 |  |
| Total debt as a % of total capital (1) | 23.9 | % |  | 22.3 | % |

[0000833444-14-000124:mdna:148]
(1) Total capital represents the aggregate amount of total debt and total shareholders' equity which was $6,110 million and $6,561 million as of September 26, 2014 and September 27, 2013, respectively.

[0000833444-14-000124:mdna:149]
Sources and uses of cash

[0000833444-14-000124:mdna:150]
In summary, our cash flows from operating, investing, and financing from continuing operations for fiscal 2014, 2013 and 2012 were as follows:

[0000833444-14-000124:mdna:151]
|  | For the Years Ended |
| ($ in millions) | September 26, 2014 |  | September 27, 2013 |  | September 28, 2012 |
| Net cash provided by operating activities | $ | 831 |  |  | $ | 694 |  |  | $ | 556 |  |
| Net cash used in investing activities | (221 | ) |  | (545 | ) |  | (470 | ) |
| Net cash used in financing activities | (261 | ) |  | (419 | ) |  | (475 | ) |

[0000833444-14-000124:mdna:152]
Cash flow from operating activities

[0000833444-14-000124:mdna:153]
Cash flow from operating activities can fluctuate significantly from period to period as working capital needs and the timing of payments for items such as restructuring activities, pension funding, income taxes and other items impact reported cash flow.

[0000833444-14-000124:mdna:154]
The net change in working capital reduced operating cash flow by $53 million in fiscal 2014. The significant changes in working capital included a $93 million increase in accounts receivable, a $98 million increase in contracts in progress and a $91 million increase in prepaid expenses and other assets, partially offset by a $205 million increase in accrued expenses and other liabilities and a $53 million increase in accounts payable.

[0000833444-14-000124:mdna:155]
The net change in working capital reduced operating cash flow by $393 million in fiscal 2013. The significant changes in working capital included a $226 million decrease in accrued expenses and other liabilities, a $75 million increase in accounts receivable, a $36 million increase in inventories, a $32 million decrease in deferred revenue and a $31 million decrease in income taxes payable, partially offset by a $31 million decrease in prepaid expenses and other assets.

[0000833444-14-000124:mdna:156]
49

[0000833444-14-000124:mdna:157]
The net change in working capital reduced operating cash flow by $481 million in fiscal 2012. The significant changes in working capital included a $179 million decrease in income taxes payable, a $121 million increase in accounts receivable, an $81 million decrease in accrued and other liabilities, and a $71 million increase in inventories, partially offset by a $44 million increase in accounts payable.

[0000833444-14-000124:mdna:158]
During fiscal 2014, 2013 and 2012, we paid approximately $74 million, $81 million and $89 million, respectively, in cash related to restructuring activities. See Note 4 to our Consolidated Financial Statements for further information regarding our restructuring activities.

[0000833444-14-000124:mdna:159]
In connection with the 2012 Separation, we paid $58 million, $165 million and $18 million in separation costs during fiscal 2014, 2013 and 2012, respectively.

[0000833444-14-000124:mdna:160]
During fiscal 2014, 2013 and 2012, we made environmental remediation payments related to environmental remediation activities for a facility located in Marinette, Wisconsin, of $63 million, $51 million and $10 million, respectively.

[0000833444-14-000124:mdna:161]
During the years ended September 26, 2014, September 27, 2013 and September 28, 2012 we made required contributions of $54 million, $50 million and $81 million, respectively, to our U.S. and non-U.S. pension plans. We also made voluntary contributions of nil during the years ended September 26, 2014, September 27, 2013 and September 28, 2012 to our U.S. plans. The Company anticipates that it will contribute at least the minimum required to its pension plans in 2015 of $13 million for the U.S. plans and $23 million for non-U.S. plans.

[0000833444-14-000124:mdna:162]
Income taxes paid, net of refunds, related to continuing operations were $102 million, $134 million and $129 million in fiscal 2014, 2013 and 2012, respectively.

[0000833444-14-000124:mdna:163]
Net interest paid related to continuing operations was $84 million, $80 million and $202 million in fiscal 2014, 2013 and 2012, respectively.

[0000833444-14-000124:mdna:164]
Cash flow from investing activities

[0000833444-14-000124:mdna:165]
Cash flows related to investing activities consist primarily of cash used for capital expenditures and acquisitions, proceeds derived from divestitures of businesses and assets and the purchase and sales and maturities of investments.

[0000833444-14-000124:mdna:166]
We made capital expenditures of $288 million, $270 million and $295 million during fiscal 2014, 2013 and 2012, respectively. The level of capital expenditures in fiscal year 2015 is expected to exceed the spending levels in fiscal year 2014 and is also expected to exceed depreciation expense.

[0000833444-14-000124:mdna:167]
During 2014, we paid cash for acquisitions included in continuing operations totaling $65 million, net of $1 million cash acquired, which is related to acquisitions included in our NA Installation & Services and ROW Installation & Services segments.  During 2013, we paid cash for acquisitions included in continuing operations totaling $229 million, net of $9 million cash acquired, which primarily related to the acquisition of Exacq Technologies within our Global Products segment.  During 2012, we paid cash for acquisitions included in continuing operations totaling $217 million, net of cash acquired of $17 million, which primarily related to the acquisition of Visonic Ltd. within our Global Products segment.

[0000833444-14-000124:mdna:168]
During fiscal 2014 and 2013, we received cash proceeds, net of cash divested, of $1 million and $17 million, respectively, for divestitures. During 2012, cash paid related to divestitures was $5 million.  See Note 3 to our Consolidated Financial Statements for further information.

[0000833444-14-000124:mdna:169]
We maintain captive insurance companies to manage certain of our insurable liabilities.  The captive insurance companies held certain investment accounts for the purposes of providing collateral for our insurable liabilities.  During fiscal 2014, the portfolio of investments was liquidated and we now provide letters of credit as collateral.

[0000833444-14-000124:mdna:170]
During fiscal 2014, we made net purchases of investments of $103 million. This represented the purchase of time deposits of $275 million, and $62 million of trading securities which will serve to partially offset changes in the market value of liabilities for an unfunded non-qualified defined contribution pension plan.  These purchases were partially offset by the liquidation of the portfolio of investments held by the captive insurance companies. During fiscal 2013 and 2012, we made  purchases of investments of $45 million, and sales of investments of $41 million, respectively. See Note 12 to our Consolidated Financial Statements for further information.

[0000833444-14-000124:mdna:171]
During fiscal 2014, we also generated $250 million in proceeds from the sale of our equity method investment in Atkore, as described in Note 3 to our Consolidated Financial Statements.

[0000833444-14-000124:mdna:172]
Cash flow from financing activities

[0000833444-14-000124:mdna:173]
Cash flows from financing activities relate primarily to proceeds received from incurring debt and issuing stock, and cash used to repay debt, repurchase stock, and make dividend payments to shareholders.

[0000833444-14-000124:mdna:174]
During the fourth quarter of 2012, in connection with the Separation, Tyco and its finance subsidiary, Tyco International Finance S.A. ("TIFSA"), redeemed various debt securities maturing from 2013 to 2023 issued by TIFSA and/or Tyco, in an aggregate principal amount of $2.6 billion.  See Note 10 to our Consolidated Financial Statements for further information.

[0000833444-14-000124:mdna:175]
On June 22, 2012, TIFSA, as the Borrower, and the Company as the Guarantor, entered into a Five-Year Senior Unsecured Credit Agreement providing for revolving credit commitments in the aggregate amount of $1.0 billion.  As of September 26, 2014, there were no amounts drawn under this revolving credit facility.

[0000833444-14-000124:mdna:176]
TIFSA's revolving credit facility contains customary terms and conditions, and financial covenants that limit the ratio of our debt to earnings before interest, taxes, depreciation, and amortization and that limit our ability to incur subsidiary debt or grant liens on our property. Our indentures contain customary covenants including limits on negative pledges, subsidiary debt and sale/leaseback transactions. None of these covenants are considered restrictive to our business.

[0000833444-14-000124:mdna:177]
During 2014, 2013 and 2012, TIFSA issued commercial paper to U.S. institutional accredited investors and qualified institutional buyers. Borrowings under the commercial paper program are available for general corporate purposes. As of September 26, 2014 and September 27, 2013, TIFSA had no commercial paper outstanding. The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1 billion as of September 26, 2014.

[0000833444-14-000124:mdna:178]
Pursuant to our share repurchase program, we may repurchase Tyco shares from time to time in open market purchases at prevailing market prices, in negotiated transactions off the market, or pursuant to an approved trading plan in accordance with applicable regulations. In January 2013, the Company's Board of Directors approved a $600 million share repurchase program.  In March 2014, and September 2014, the Company's Board of Directors authorized an additional $1.75 billion and $1 billion in share repurchases.  During the year ended September 26, 2014, we repurchased approximately 42 million common shares for approximately $1.8 billion.  During the year ended September 27, 2013, we repurchased approximately 10 million common shares for approximately $300 million. During the year ended September 28, 2012, we repurchased approximately 11 million common shares for approximately $500 million.

[0000833444-14-000124:mdna:179]
On March 5, 2014, our shareholders approved a cash dividend of $0.72 per common share payable to shareholders in four quarterly installments of $0.18 in May 2014, August 2014, November 2014 and February 2015. During fiscal years 2014, 2013 and 2012, we paid cash dividends of approximately $311 million, $288 million and $461 million, respectively. See Note 15 to our Consolidated Financial Statements for further information.

[0000833444-14-000124:mdna:180]
During fiscal 2014, we paid $66 million in cash to purchase the remaining ownership interest of a joint venture in Brazil, which is part of the Company's ROW Installation & Services segment.

[0000833444-14-000124:mdna:181]
Management believes that cash generated by or available to us should be sufficient to fund our capital and operational business needs for the foreseeable future, including capital expenditures, quarterly dividend payments, share repurchases, separation-related and other expenses.

[0000833444-14-000124:mdna:182]
Commitments and Contingencies

[0000833444-14-000124:mdna:183]
For a detailed discussion of contingencies related to tax and litigation matters and governmental investigations, see Notes 6 and 13 to our Consolidated Financial Statements.

[0000833444-14-000124:mdna:184]
51

[0000833444-14-000124:mdna:185]
Contractual Obligations

[0000833444-14-000124:mdna:186]
Contractual obligations and commitments for debt, minimum lease payment obligations under non-cancelable operating leases and purchase obligations as of September 26, 2014 are as follows ($ in millions):

[0000833444-14-000124:mdna:187]
|  | Fiscal Year |  |  |  |  |
|  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | Thereafter |  | Total |
| Debt principal(1) | $ | — |  |  | $ | 258 |  |  | $ | — |  |  | $ | 67 |  |  | $ | 364 |  |  | $ | 746 |  |  | $ | 1,435 |  |
| Interest payments(2) | 93 |  |  | 88 |  |  | 84 |  |  | 83 |  |  | 66 |  |  | 63 |  |  | 477 |  |
| Operating leases | 185 |  |  | 163 |  |  | 122 |  |  | 81 |  |  | 44 |  |  | 82 |  |  | 677 |  |
| Purchase obligations(3) | 375 |  |  | 66 |  |  | 28 |  |  | 1 |  |  | 1 |  |  | — |  |  | 471 |  |
| Total contractual cash obligations(4) | $ | 653 |  |  | $ | 575 |  |  | $ | 234 |  |  | $ | 232 |  |  | $ | 475 |  |  | $ | 891 |  |  | $ | 3,060 |  |

[0000833444-14-000124:mdna:188]
_______________________________________________________________________________

[0000833444-14-000124:mdna:189]
| (1) | Debt principal consists of the aggregate principal amount of our public debt outstanding, excluding debt discount, swap activity and interest. |

[0000833444-14-000124:mdna:190]
| (2) | Interest payments consist of interest on our fixed interest rate debt. |

[0000833444-14-000124:mdna:191]
| (3) | Purchase obligations consist of commitments for purchases of goods and services. |

[0000833444-14-000124:mdna:192]
| (4) | Other long-term liabilities excluded from the above contractual obligation table primarily consist of the following: pension and postretirement costs (see Note 14 to the Consolidated Financial Statements), income taxes (see Note 6 to the Consolidated Financial Statements), contingent consideration (see Note 5 to the Consolidated Financial Statements), warranties (see Note 11 to the Consolidated Financial Statements) and environmental liabilities (see Note 13 to the Consolidated Financial Statements). We are unable to estimate the timing of payment for these items due to the inherent uncertainties related to these obligations. However, the minimum required contributions to our pension plans are expected to be approximately $36 million in 2015 and we do not expect to make any material contributions in 2015 related to other postretirement benefit plans. |

[0000833444-14-000124:mdna:193]
As of September 26, 2014, we recorded gross unrecognized tax benefits of $267 million and gross interest and penalties of $36 million. We are unable to make a reasonably reliable estimate of the timing for the remaining payments in future years; therefore, such amounts have been excluded from the above contractual obligation table. However, based on the current status of our income tax audits, we believe that it is reasonably possible that between nil and $20 million in unrecognized tax benefits may be resolved in the next twelve months.  Although the Company had unrecognized tax benefits that, if recognized, would affect the effective tax rate, the Company had net operating loss carryforwards which would offset the cash impact of any such recognition of unrecognized tax benefits relating to the current year.

[0000833444-14-000124:mdna:194]
In the normal course of business, we are liable for contract completion and product performance. In the opinion of management, such obligations will not significantly affect our financial position, results of operations or cash flows.

[0000833444-14-000124:mdna:195]
In connection with the 2012 Separation we entered into a liability sharing agreement regarding certain actions that were pending against Tyco prior to the 2012 Separation. Under the 2012 Tax Sharing Agreement, Pentair, Tyco and ADT share (i) certain pre-Distribution income tax liabilities that arise from adjustments made by tax authorities to Tyco Flow Control's, Tyco's and ADT's U.S. income tax returns, and (ii) payments required to be made by Tyco with respect to the 2007 Tax Sharing Agreement, excluding approximately $175 million of pre-2012 Separation related tax liabilities that were anticipated to be paid prior to the 2012 Separation (collectively, "Shared Tax Liabilities"). The Company will be responsible for the first $500 million of Shared Tax Liabilities. Pentair and ADT will share 42% and 58%, respectively, of the next $225 million of Shared Tax Liabilities. Pentair, ADT and Tyco will share 20%, 27.5% and 52.5%, respectively, of Shared Tax Liabilities above $725 million.  The Company expects to pay $21 million to settle certain pre-2012 Separation related tax liabilities.  The timing and amounts of these payments are subject to a number of uncertainties and could change.  See Notes 13 and 6, respectively, to the Consolidated Financial Statements.

[0000833444-14-000124:mdna:196]
In connection with the 2007 Separation, we entered into a liability sharing agreement regarding certain actions that were pending against Tyco prior to the 2007 Separation. Under the 2007 Separation and Distribution Agreement and 2007 Tax Sharing Agreement, we have assumed 27%, Covidien has assumed 42% and TE Connectivity has assumed 31% of certain Tyco pre-Separation contingent and other corporate liabilities, which, as of September 26, 2014, primarily relate to tax contingencies and potential actions with respect to the spin-offs or the distributions made or brought by any third party.

[0000833444-14-000124:mdna:197]
Backlog

[0000833444-14-000124:mdna:198]
We had a backlog of unfilled orders of $4,862 million and $4,812 million as of September 26, 2014 and September 27, 2013, respectively.

[0000833444-14-000124:mdna:199]
The Company's backlog includes recurring revenue-in-force and long-term deferred revenue for upfront fees from its NA and ROW Installation & Services segments. Revenue-in-force represents 12 months' revenue associated with monitoring and maintenance services under contract in the security and fire business. Backlog by segment was as follows ($ in millions):

[0000833444-14-000124:mdna:200]
|  | NA Installation& Services |  | ROWInstallation& Services |  | GlobalProducts |  | Total |
| As of September 27, 2013 |  |  |  |  |  |  |  |
| Backlog | $ | 908 |  |  | $ | 939 |  |  | $ | 196 |  |  | $ | 2,043 |  |
| Recurring Revenue in Force | 1,239 |  |  | 1,194 |  |  | — |  |  | 2,433 |  |
| Deferred Revenue | 296 |  |  | 40 |  |  | — |  |  | 336 |  |
| Total Backlog | $ | 2,443 |  |  | $ | 2,173 |  |  | $ | 196 |  |  | $ | 4,812 |  |
| As of September 26, 2014 |  |  |  |  |  |  |  |
| Backlog | $ | 992 |  |  | $ | 999 |  |  | $ | 181 |  |  | $ | 2,172 |  |
| Recurring Revenue in Force | 1,243 |  |  | 1,143 |  |  | — |  |  | 2,386 |  |
| Deferred Revenue | 266 |  |  | 38 |  |  | — |  |  | 304 |  |
| Total Backlog | $ | 2,501 |  |  | $ | 2,180 |  |  | $ | 181 |  |  | $ | 4,862 |  |

[0000833444-14-000124:mdna:201]
Backlog increased $50 million, or 1.0%, to $4,862 million as of September 26, 2014 as compared to $4,812 million in the prior year. The net increase in backlog as of September 26, 2014 was primarily due to a $58 million increase in total backlog in our NA Installation & Services segment relating to our fire business.  This increase was partially offset by a decline in recurring revenue in force and deferred revenue in our security business. The $7 million increase in our ROW Installation & Services segment total backlog was driven by an increase in Growth Markets and Asia, which was further improved by the Westfire and other acquisitions.  Total backlog for our Global Products segment declined by $15 million due to our fire products and life safety businesses, which was partially offset by growth in our security business. Changes in foreign currency had an unfavorable impact on backlog of $128 million, or 2.7%, and primarily related to the ROW Installation & Services segment.

[0000833444-14-000124:mdna:202]
Guarantees

[0000833444-14-000124:mdna:203]
Certain of our business segments have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from fiscal year 2015 through the completion of such transactions and would typically be triggered in the event of nonperformance. The Company's performance under the guarantees, if required, would not have a material effect on our financial position, results of operations or cash flows.

[0000833444-14-000124:mdna:204]
There are certain guarantees or indemnifications extended among Tyco, Covidien, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 Separation and Distribution Agreements and the Tax Sharing Agreements. The guarantees primarily relate to certain contingent tax liabilities included in the Tax Sharing Agreements. At the time of the 2007 and 2012 Separations, we recorded liabilities necessary to recognize the fair value of such guarantees and indemnifications. See Note 6 to the Consolidated Financial Statements for further discussion of the Tax Sharing Agreements. In addition, prior to the 2007 and 2012 Separations we provided support in the form of financial and/or performance guarantees to various Covidien, TE Connectivity, ADT and Tyco Flow Control operating entities. To the extent these guarantees were not assigned in connection with the 2007 and 2012 Separations, we assumed primary liability on any remaining such support. See Note 11 to the Consolidated Financial Statements for a discussion of these liabilities.

[0000833444-14-000124:mdna:205]
In disposing of assets or businesses, we often provide representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities, and unidentified tax liabilities and legal fees related to periods prior to disposition. We have no reason to believe that these uncertainties would have a material adverse effect on our financial position, results of operations or cash flows. We have recorded liabilities for known indemnifications included as part of environmental liabilities.

[0000833444-14-000124:mdna:206]
53

[0000833444-14-000124:mdna:207]
In the normal course of business, we are liable for contract completion and product performance. We record estimated product warranty costs at the time of sale. In the opinion of management, such obligations will not significantly affect our financial position, results of operations or cash flows.

[0000833444-14-000124:mdna:208]
During the year ended September 26, 2014, Tyco replaced available for sale investments held as collateral for the Company's insurable liabilities with letters of credit of approximately $137 million. As of September 26, 2014 and September 27, 2013, we had total outstanding letters of credit and bank guarantees of approximately $662 million and $424 million, respectively.

[0000833444-14-000124:mdna:209]
For a detailed discussion of guarantees and indemnifications, see Note 11 to the Consolidated Financial Statements.

[0000833444-14-000124:mdna:210]
Accounting Pronouncements

[0000833444-14-000124:mdna:211]
See Note 1 to the Consolidated Financial Statements for Recently Adopted Accounting Pronouncements and Recently Issued Accounting Pronouncements.

[0000833444-14-000124:mdna:212]
Non-U.S. GAAP Measure

[0000833444-14-000124:mdna:213]
In an effort to provide investors with additional information regarding our results as determined by U.S. GAAP, we also disclose the non-U.S. GAAP measure of organic revenue growth (decline). We believe that this measure is useful to investors in evaluating our operating performance for the periods presented. When read in conjunction with our U.S. GAAP revenue, it enables investors to better evaluate our operations without giving effect to fluctuations in foreign exchange rates and acquisition and divestiture activity, either of which may be significant from period to period. In addition, organic revenue growth (decline) is a factor we use in internal evaluations of the overall performance of our business. This measure is not a financial measure under U.S. GAAP and should not be considered as a substitute for revenue as determined in accordance with U.S. GAAP, and it may not be comparable to similarly titled measures reported by other companies. Organic revenue growth (decline) presented herein is defined as revenue growth (decline) excluding the effects of foreign currency fluctuations, acquisitions and divestitures and other changes that may not reflect underlying results and trends. Our organic growth (decline) calculations incorporate an estimate of prior year reported net revenue associated with acquired entities that have been fully integrated within the first year, and exclude prior year net revenue associated with entities that do not meet the criteria for discontinued operations which have been divested within the past year ("adjusted number"). We calculate the rate of organic growth (decline) based on the adjusted number to better reflect the rate of growth (decline) of the combined business, in the case of acquisitions, or the remaining business, in the case of dispositions. We base the rate of organic growth (decline) for acquired businesses that are not fully integrated within the first year upon unadjusted historical net revenue.  Foreign currency fluctuations are calculated by subtracting (i) the U.S. dollar equivalent of local currencies for the current period using monthly weighted average exchange rates for the prior period from (ii) the U.S. dollar equivalent of local currencies for the current period using monthly weighted average exchange rates for the current period. We may use organic revenue growth (decline) as a component of our compensation programs.

[0000833444-14-000124:mdna:214]
The table below details the components of organic revenue growth and reconciles the non-U.S. GAAP measure to U.S. GAAP net revenue growth.

[0000833444-14-000124:mdna:215]
Fiscal 2014

[0000833444-14-000124:mdna:216]
|  | NetRevenueforFiscal 2013 |  | Base YearAdjustments(Divestitures) |  | AdjustedFiscal 2013Base Revenue |  | ForeignCurrency |  | Acquisitions |  | OrganicRevenue |  | Organic GrowthPercentage(1) |  | NetRevenueforFiscal 2014 |
|  | ($ in millions) |
| NA Installation & Services | $ | 3,891 |  |  | $ | (42 | ) |  | $ | 3,849 |  |  | $ | (29 | ) |  | $ | 19 |  |  | $ | 37 |  |  | 1.0 | % |  | $ | 3,876 |  |
| ROW Installation & Services | 3,843 |  |  | (67 | ) |  | 3,776 |  |  | (46 | ) |  | 119 |  |  | 71 |  |  | 1.9 | % |  | 3,920 |  |
| Global Products | 2,339 |  |  | 2 |  |  | 2,341 |  |  | (7 | ) |  | 63 |  |  | 147 |  |  | 6.3 | % |  | 2,544 |  |
| Total Net Revenue | $ | 10,073 |  |  | $ | (107 | ) |  | $ | 9,966 |  |  | $ | (82 | ) |  | $ | 201 |  |  | $ | 255 |  |  | 2.6 | % |  | $ | 10,340 |  |

[0000833444-14-000124:mdna:217]
_______________________________________________________________________________

[0000833444-14-000124:mdna:218]
| (1) | Organic revenue growth percentage based on adjusted fiscal 2013 base revenue. |

[0000833444-14-000124:mdna:219]
Fiscal 2013

[0000833444-14-000124:mdna:220]
|  | NetRevenueforFiscal 2012 |  | Base YearAdjustments(Divestitures) |  | AdjustedFiscal 2012Base Revenue |  | ForeignCurrency |  | Acquisitions |  | Other(2) |  | OrganicRevenue |  | OrganicGrowth (Decline)Percentage(1) |  | NetRevenueforFiscal 2013 |
|  | ($ in millions) |
| NA Installation & Services | $ | 3,962 |  |  | $ | (30 | ) |  | $ | 3,932 |  |  | $ | (3 | ) |  | $ | 7 |  |  | $ | — |  |  | $ | (45 | ) |  | (1.1 | )% |  | $ | 3,891 |  |
| ROW Installation & Services | 3,830 |  |  | (10 | ) |  | 3,820 |  |  | (64 | ) |  | 93 |  |  | — |  |  | (6 | ) |  | (0.2 | )% |  | 3,843 |  |
| Global Products | 2,100 |  |  | 2 |  |  | 2,102 |  |  | (3 | ) |  | 68 |  |  | 39 |  |  | 133 |  |  | 6.3 | % |  | 2,339 |  |
| Total Net Revenue | $ | 9,892 |  |  | $ | (38 | ) |  | $ | 9,854 |  |  | $ | (70 | ) |  | $ | 168 |  |  | $ | 39 |  |  | $ | 82 |  |  | 0.8 | % |  | $ | 10,073 |  |

[0000833444-14-000124:mdna:221]
_______________________________________________________________________________

[0000833444-14-000124:mdna:222]
| (1) | Organic revenue growth percentage based on adjusted fiscal 2012 base revenue. |

[0000833444-14-000124:mdna:223]
| (2) | Amount represents contractual revenue from ADT under the 2012 Separation and Distribution Agreement which is excluded from the organic revenue calculation |

[0000833444-14-000124:mdna:224]
Forward-Looking Information

[0000833444-14-000124:mdna:225]
| • | overall economic and business conditions, and overall demand for Tyco's goods and services; |

[0000833444-14-000124:mdna:226]
| • | economic and competitive conditions in the industries, end markets and regions served by our businesses; |

[0000833444-14-000124:mdna:227]
| • | changes in legal and tax requirements (including tax rate changes, new tax laws or treaties and revised tax law interpretations); |

[0000833444-14-000124:mdna:228]
| • | our, and our employees' and agents' ability to comply with complex and continually changing laws and regulations that govern our international operations, including the U.S. Foreign Corrupt Practices Act, similar anti-bribery laws in other jurisdictions, a variety of export control, customs, currency exchange control and transfer pricing regulations, and our corporate policies governing these matters; |

[0000833444-14-000124:mdna:229]
| • | the outcome of litigation, arbitrations and governmental proceedings; |

[0000833444-14-000124:mdna:230]
| • | effect of income tax audits, litigation, settlements and appeals; |

[0000833444-14-000124:mdna:231]
| • | our ability to repay or refinance our outstanding indebtedness as it matures; |

[0000833444-14-000124:mdna:232]
| • | our ability to operate within the limitations imposed by financing arrangements and to maintain our credit ratings; |

[0000833444-14-000124:mdna:233]
| • | interest rate fluctuations and other changes in borrowing costs, or other consequences of volatility in the capital or credit markets; |

[0000833444-14-000124:mdna:234]
| • | other capital market conditions, including availability of funding sources and currency exchange rate fluctuations; |

[0000833444-14-000124:mdna:235]
| • | availability of and fluctuations in the prices of key raw materials; |

[0000833444-14-000124:mdna:236]
| • | changes affecting customers or suppliers; |

[0000833444-14-000124:mdna:237]
| • | economic and political conditions in international markets, including governmental changes and restrictions on the ability to transfer capital across borders; |

[0000833444-14-000124:mdna:238]
| • | our ability to achieve anticipated cost savings; |

[0000833444-14-000124:mdna:239]
| • | our ability to execute our portfolio refinement and acquisition strategies, including successfully integrating acquired operations; |

[0000833444-14-000124:mdna:240]
55

[0000833444-14-000124:mdna:241]
| • | potential impairment of our goodwill, intangibles and/or our long-lived assets; |

[0000833444-14-000124:mdna:242]
| • | our ability to realize the intended benefits of the 2012 Separation, including the integration of our commercial security and fire protection businesses; |

[0000833444-14-000124:mdna:243]
| • | other risks associated with the 2012 Separation, for example the risk that we may be liable for certain contingent liabilities of the spun-off entities if they were to become insolvent; |

[0000833444-14-000124:mdna:244]
| • | risks associated with our jurisdiction of incorporation, including the possibility of reduced flexibility with respect to certain aspects of capital management and corporate governance, increased or different regulatory burdens, and the possibility that we may not realize anticipated tax benefits; |

[0000833444-14-000124:mdna:245]
| • | the possible effects on Tyco of future legislation in the United States that may limit or eliminate potential U.S. tax benefits resulting from Tyco International's incorporation outside of the U.S. or deny U.S. government contracts to Tyco based upon its jurisdiction of incorporation; |

[0000833444-14-000124:mdna:246]
| • | risks associated with the proposed change in our global headquarters to Ireland; and |

[0000833444-14-000124:mdna:247]
| • | natural events such as severe weather, fires, floods and earthquakes, or acts of terrorism or cyber-attacks. |
