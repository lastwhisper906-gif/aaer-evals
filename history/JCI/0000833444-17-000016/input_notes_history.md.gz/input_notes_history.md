# JCI note change history — 0000833444-17-000007 → 0000833444-17-000016


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0000833444-17-000016:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of March 31, 2017, reserves for environmental liabilities totaled $46 million, of which $9 million was recorded within other current liabilities and $37 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at  September 30, 2016. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At March 31, 2017 and September 30, 2016, the Company recorded conditional asset retirement obligations of $72 million and $74 million, respectively.
  (was, 2017-02-08, similarity 0.9933):
[0000833444-17-000007:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of December 31, 2016, reserves for environmental liabilities totaled $45 million, of which $9 million was recorded within other current liabilities and $36 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at  September 30, 2016. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At December 31, 2016 and September 30, 2016, the Company recorded conditional asset retirement obligations of $70 million and $74 million, respectively.

- changed (2017-05-04):
[0000833444-17-000016:note_history:2]
As of March 31, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position is $152 million. The net liability within the consolidated statements of financial position is comprised of a liability for pending and future claims and related defense costs of $540 million, of which $35 million is recorded in other current liabilities and $505 million is recorded in other noncurrent liabilities. The Company also maintains separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $388 million, of which $57 million is recorded in other current assets, and $331 million is recorded in other noncurrent assets. Assets include $33 million of cash and $258 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at March 31, 2017 is $97 million. As of September 30, 2016, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position is $148 million. The net liability within the consolidated statements of financial position is comprised of a liability for pending and future claims and related defense costs of $548 million, of which $35 million is recorded in other current liabilities and $513 million is recorded in other noncurrent liabilities. The Company also maintains separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $400 million, of which $41 million is recorded in other current assets, and $359 million is recorded in other noncurrent assets. Assets include $16 million of cash and $264 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2016 is $120 million. The Company believes that the asbestos related liabilities and insurance related receivables recorded as of March 31, 2017 and September 30, 2016 are appropriate.
  (was, 2017-02-08, similarity 0.9918):
[0000833444-17-000007:note_history:2]
As of December 31, 2016, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position is $156 million. The net liability within the consolidated statements of financial position is comprised of a liability for pending and future claims and related defense costs of $544 million, of which $35 million is recorded in other current liabilities and $509 million is recorded in other noncurrent liabilities. The Company also maintains separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $388 million, of which $42 million is recorded in other current assets, and $346 million is recorded in other noncurrent assets. Assets include $32 million of cash and $252 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at December 31, 2016 is $104 million. As of September 30, 2016, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position is $148 million. The net liability within the consolidated statements of financial position is comprised of a liability for pending and future claims and related defense costs of $548 million, of which $35 million is recorded in other current liabilities and $513 million is recorded in other noncurrent liabilities. The Company also maintains separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $400 million, of which $41 million is recorded in other current assets, and $359 million is recorded in other noncurrent assets. Assets include $16 million of cash and $264 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2016 is $120 million. The Company believes that the asbestos related liabilities and insurance related receivables recorded as of December 31, 2016 and September 30, 2016 are appropriate.

- added (2017-05-04):
[0000833444-17-000016:note_history:3]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At March 31, 2017 and September 30, 2016, the insurable liabilities for continuing operations totaled $468 million and $422 million, respectively, of which $86 million and $60 million was recorded within other current liabilities, $32 million and $28 million was recorded within accrued compensation and benefits, and $350 million and $334 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at March 31, 2017 was $48 million, of which $30 million was recorded within other current assets and $18 million was recorded within other noncurrent assets. Insurance receivables recorded at September 30, 2016 were $21 million, primarily recorded within other noncurrent assets. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

- removed (2017-05-04):
[0000833444-17-000007:note_history:4]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At December 31, 2016 and September 30, 2016, the insurable liabilities for continuing operations totaled $421 million and $422 million, respectively, of which $61 million and $60 million was recorded within other current liabilities, $31 million and $28 million was recorded within accrued compensation and benefits, and $329 million and $334 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage certain of its insurable liabilities.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0000833444-17-000016:note_history:5]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (SEC). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2016 filed with the SEC on November 23, 2016, portions of which (including Part I, Item 1. Business and Item 3. Legal Proceedings, and the following items from Part II of the Annual Report: Item 6. Selected Financial Data, Item 7. Management’s Discussion and Analysis, and Item 8. Financial Statements and Supplementary Data) were recast in the Company's Current Report on Form 8-K filed with the SEC on February 23, 2017. The results of operations for the three and six month periods ended March 31, 2017 are not necessarily indicative of results for the Company’s 2017 fiscal year because of seasonal and other factors.
  (was, 2017-02-08, similarity 0.8355):
[0000833444-17-000007:note_history:5]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (SEC). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2016 filed with the SEC on November 23, 2016. The results of operations for the three month period ended December 31, 2016 are not necessarily indicative of results for the Company’s 2017 fiscal year because of seasonal and other factors.

- changed (2017-05-04):
[0000833444-17-000016:note_history:6]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience Business from Johnson Controls to Adient plc and the issuance of ordinary shares of Adient directly to holders of Johnson Controls ordinary shares on a pro rata basis. Prior to the open of business on October 31, 2016, each of the Company's shareholders received one ordinary share of Adient plc for every 10 ordinary shares of Johnson Controls held as of the close of business on October 19, 2016, the record date for the distribution. Company shareholders received cash in lieu of fractional shares of Adient, if any. Following the separation and distribution, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc. Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information.
  (was, 2017-02-08, similarity 0.9925):
[0000833444-17-000007:note_history:6]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience Business from Johnson Controls to Adient plc and the issuance of ordinary shares of Adient directly to holders of Johnson Controls ordinary shares on a pro rata basis. Prior to the open of business on October 31, 2016, each of the Company's shareholders received one ordinary share of Adient plc for every 10 ordinary shares of Johnson Controls held as of the close of business on October 19, 2016, the record date for the distribution. Company shareholders received cash in lieu of fractional shares of Adient, if any. Following the separation and distribution, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc. Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation at December 31, 2016. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information.

- changed (2017-05-04):
[0000833444-17-000016:note_history:7]
Based upon the criteria set forth in ASC 810, the Company has determined that it was the primary beneficiary in one VIE for the reporting period ended March 31, 2017 and three VIEs for the reporting period ended  September 30, 2016, as the Company absorbs significant economics of the entities and has the power to direct the activities that are considered most significant to the entities.
  (was, 2017-02-08, similarity 0.9827):
[0000833444-17-000007:note_history:7]
Based upon the criteria set forth in ASC 810, the Company has determined that it was the primary beneficiary in one VIE for the reporting period ended December 31, 2016 and three VIEs for the reporting period ended  September 30, 2016, as the Company absorbs significant economics of the entities and has the power to direct the activities that are considered most significant to the entities.

- changed (2017-05-04):
[0000833444-17-000016:note_history:8]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE has been consolidated within the Company’s consolidated statements of financial position. The impact of consolidation of the entity on the Company’s consolidated statements of income for the three and six month periods ended March 31, 2017 and 2016 was not material. The VIE is named as a co-obligor under a third party debt agreement in the amount of $168 million, maturing in fiscal 2020, under which it could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business.
  (was, 2017-02-08, similarity 0.9854):
[0000833444-17-000007:note_history:8]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE has been consolidated within the Company’s consolidated statements of financial position. The impact of consolidation of the entity on the Company’s consolidated statements of income for the three month periods ended December 31, 2016 and 2015 was not material. The VIE is named as a co-obligor under a third party debt agreement in the amount of $170 million, maturing in fiscal 2020, under which it could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business.

- changed (2017-05-04):
[0000833444-17-000016:note_history:9]
|  | March 31, 2017 |  | September 30, 2016 |
| Current assets | $ | 2 |  |  | $ | 284 |  |
| Noncurrent assets | 53 |  |  | 98 |  |
| Total assets | $ | 55 |  |  | $ | 382 |  |
| Current liabilities | $ | 3 |  |  | $ | 230 |  |
| Noncurrent liabilities | 44 |  |  | 29 |  |
| Total liabilities | $ | 47 |  |  | $ | 259 |  |
  (was, 2017-02-08, similarity 0.9805):
[0000833444-17-000007:note_history:9]
|  | December 31, 2016 |  | September 30, 2016 |
| Current assets | $ | 2 |  |  | $ | 284 |  |
| Noncurrent assets | 54 |  |  | 98 |  |
| Total assets | $ | 56 |  |  | $ | 382 |  |
| Current liabilities | $ | 3 |  |  | $ | 230 |  |
| Noncurrent liabilities | 44 |  |  | 29 |  |
| Total liabilities | $ | 47 |  |  | $ | 259 |  |

- changed (2017-05-04):
[0000833444-17-000016:note_history:10]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is not considered to be the primary beneficiary of two of the entities as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balances of $62 million  and $59 million at March 31, 2017 and September 30, 2016 respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned previously within the "Consolidated VIEs" section above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.
  (was, 2017-02-08, similarity 0.9943):
[0000833444-17-000007:note_history:10]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is not considered to be the primary beneficiary of two of the entities as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balance of $60 million  and $59 million at December 31, 2016 and September 30, 2016 respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned previously within the "Consolidated VIEs" section above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.

- changed (2017-05-04):
[0000833444-17-000016:note_history:11]
At March 31, 2017, the Company held restricted cash of approximately $42 million, of which $33 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash restricted for payment of asbestos liabilities. At September 30, 2016, the Company held restricted cash of approximately $88 million, of which $79 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash held in escrow from business divestitures and cash restricted for payment of asbestos liabilities.
  (was, 2017-02-08, similarity 0.9863):
[0000833444-17-000007:note_history:11]
At December 31, 2016, the Company held restricted cash of approximately $42 million, of which $33 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities. At September 30, 2016, the Company held restricted cash of approximately $88 million, of which $79 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash held in escrow from business divestitures and cash restricted for payment of asbestos liabilities.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0000833444-17-000016:note_history:12]
In connection with the Tyco Merger, on December 28, 2016, the Company completed its offers to exchange all validly tendered and accepted notes of certain series (the "existing notes") issued by JCI Inc. or Tyco International Finance S.A. ("TIFSA"), as applicable, each of which is a wholly owned subsidiary of the Company, for new notes (the New Notes) to be issued by the Company, and the related solicitation of consents to amend the indentures governing the existing notes (the offers to exchange and the related consent solicitation together the "exchange offers"). Pursuant to the exchange offers, the Company exchanged approximately $5.6 billion of $6.0 billion in aggregate principal amount of dollar denominated notes and approximately 423 million euro of 500 million euro in aggregate principal amount of euro denominated notes. All validly tendered and accepted existing notes have been canceled. Immediately following such cancellation, $380.9 million aggregate principal amount of existing notes (not including the TIFSA Euro Notes) remained outstanding across seventeen series of dollar-denominated existing notes and 77.4 million euro aggregate principal amount of TIFSA Euro Notes remained outstanding across one series. In connection with the settlement of the exchange offers, the New Notes were registered under the Securities Act of 1933 and their terms are described in the Company’s Prospectus dated December 19, 2016, as filed with the SEC under Rule 424(b)(3) of the Act on that date. The issuance of the New Notes occurred on December 28, 2016. The New Notes are unsecured and unsubordinated obligations of the Company and will rank equally with all other unsecured and unsubordinated indebtedness of the Company issued from time to time.
  (was, 2017-02-08, similarity 0.9001):
[0000833444-17-000007:note_history:12]
In connection with the Tyco Merger, on December 28, 2016, the Company completed its offers to exchange all validly tendered and accepted notes of certain series (the "existing notes") issued by JCI Inc. or Tyco International Finance S.A. ("TIFSA"), as applicable, each of which is a wholly owned subsidiary of the Company, for the new notes to be issued by the Company and the related solicitation of consents to amend the indentures governing the existing notes (the offers to exchange and the related consent solicitation together the "exchange offers"). Pursuant to the exchange offers, the Company exchanged approximately $5.6 billion of $6.0 billion in aggregate principal amount of dollar denominated notes and approximately 423 million euro of 500 million euro in aggregate principal amount of euro denominated notes. All were validly tendered and accepted and notes have been canceled. Following such cancellation, $380,948,000 aggregate principal amount of existing notes (not including the TIFSA Euro Notes) will remain outstanding across seventeen series of dollar-denominated existing notes and 77,394,000 euro aggregate principal amount of TIFSA Euro Notes remain outstanding across one series. In connection with the settlement of the exchange offers, the new notes ("the New Notes") issued by the Company have been registered under the Securities Act of 1933. The terms of the New Notes are described in the Company’s Prospectus dated December 19, 2016, as filed with the SEC under Rule 424(b)(3) of the Act on that date. The issuance of the New Notes occurred on December 28, 2016. The New Notes are unsecured and unsubordinated obligations of the Company and will rank equally with all other unsecured and unsubordinated indebtedness of the Company issued from time to time.

- added (2017-05-04):
[0000833444-17-000016:note_history:13]
In March 2017, the Company issued one billion euro in principal amount of 1.0% senior unsecured fixed rate notes due in         fiscal 2023. Proceeds from the issuance were used to repay existing debt and for other general corporate purposes.

- changed (2017-05-04):
[0000833444-17-000016:note_history:14]
In March 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in March 2018. As of March 31, 2017, there were no draws on the facility.
  (was, 2017-02-08, similarity 0.6116):
[0000833444-17-000007:note_history:14]
In December 2016, the Company entered into a 364-day 100 million euro floating rate term loan scheduled to mature in December 2017. Proceeds from the term loan were used for general corporate purposes.

- changed (2017-05-04):
[0000833444-17-000016:note_history:15]
In March 2017, the Company retired $46 million in principal amount, plus accrued interest, of its 2.355% fixed rate notes that matured in March 2017.
  (was, 2017-02-08, similarity 0.8904):
[0000833444-17-000007:note_history:15]
In December 2016, the Company retired, at maturity, $400 million in principal amount, plus accrued interest, of its 2.6% fixed rate notes that matured in December 2016.

- added (2017-05-04):
[0000833444-17-000016:note_history:16]
In March and February 2017, the Company repurchased, at a discount, 15 million euro of its TIFSA 1.375% fixed rate notes, plus accrued interest, scheduled to mature in February 2025.

- added (2017-05-04):
[0000833444-17-000016:note_history:17]
In February 2017, the Company issued $500 million aggregate principal amount of 4.5% senior unsecured fixed rate notes due in fiscal 2047. Proceeds from the issuance were used to repay outstanding commercial paper borrowings and for other general corporate purposes.

- added (2017-05-04):
[0000833444-17-000016:note_history:18]
In February 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in February 2018. As of March 31, 2017, there were no draws on the facility.

- added (2017-05-04):
[0000833444-17-000016:note_history:19]
In January 2017, the Company entered into a 364-day $250 million committed revolving credit facility scheduled to expire                      in January 2018. As of March 31, 2017, there were no draws on the facility outstanding.

- added (2017-05-04):
[0000833444-17-000016:note_history:20]
In December 2016, the Company retired $400 million in principal amount, plus accrued interest, of its 2.6% fixed rate notes that matured in December 2016.

- added (2017-05-04):
[0000833444-17-000016:note_history:21]
In December 2016, the Company entered into a 364-day 100 million euro floating rate term loan scheduled to mature in December 2017. Proceeds from the term loan were used for general corporate purposes. Principal and accrued interest were fully repaid in March 2017.

- changed (2017-05-04):
[0000833444-17-000016:note_history:22]
The Company's net financing charges line item in the consolidated statements of income for the three and six month periods ended March 31, 2017 and 2016 contained the following components (in millions):
  (was, 2017-02-08, similarity 0.9556):
[0000833444-17-000007:note_history:22]
The Company's net financing charges line item in the consolidated statements of income for the three month periods ended December 31, 2016 and 2015 contained the following components (in millions):

- changed (2017-05-04):
[0000833444-17-000016:note_history:23]
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Interest expense, net of capitalized interest costs | $ | 118 |  |  | $ | 65 |  |  | $ | 228 |  |  | $ | 137 |  |
| Banking fees and bond cost amortization | 11 |  |  | 5 |  |  | 41 |  |  | 12 |  |
| Interest income | (5 | ) |  | (2 | ) |  | (12 | ) |  | (4 | ) |
| Net foreign exchange results for financing activities | (8 | ) |  | 3 |  |  | (5 | ) |  | (8 | ) |
| Net financing charges | $ | 116 |  |  | $ | 71 |  |  | $ | 252 |  |  | $ | 137 |  |
  (was, 2017-02-08, similarity 0.7819):
[0000833444-17-000007:note_history:23]
|  | Three Months EndedDecember 31, |
|  | 2016 |  | 2015 |
| Interest expense, net of capitalized interest costs | $ | 110 |  |  | $ | 72 |  |
| Banking fees and bond cost amortization | 30 |  |  | 7 |  |
| Interest income | (7 | ) |  | (2 | ) |
| Net foreign exchange results for financing activities | 3 |  |  | (11 | ) |
| Net financing charges | $ | 136 |  |  | $ | 66 |  |

- changed (2017-05-04):
[0000833444-17-000016:note_history:24]
Net financing charges for the six month period ended March 31, 2017 included $17 million of transaction costs related primarily to the debt exchange offers.
  (was, 2017-02-08, similarity 0.9443):
[0000833444-17-000007:note_history:24]
Net financing charges for the three month period ended December 31, 2016 included $17 million of transaction costs related primarily to the debt exchange offers.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0000833444-17-000016:note_history:25]
The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $229 million and $52 million, respectively, for the three months ended March 31, 2017; and $236 million and $45 million, respectively, for the three months ended March 31, 2016. The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $454 million and $101 million, respectively, for the six months ended March 31, 2017; and $470 million and $83 million, respectively, for the six months ended March 31, 2016.
  (was, 2017-02-08, similarity 0.6327):
[0000833444-17-000007:note_history:25]
The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $225 million and $49 million, respectively, for the three months ended December 31, 2016; and $234 million and $38 million, respectively, for the three months ended December 31, 2015.

- changed (2017-05-04):
[0000833444-17-000016:note_history:26]
|  |  | March 31, 2017 |  | September 30, 2016 |  |
| Receivable from related parties |  | $ | 57 |  |  | $ | 66 |  |
| Payable to related parties |  | 20 |  |  | 11 |  |
  (was, 2017-02-08, similarity 0.9691):
[0000833444-17-000007:note_history:26]
|  |  | December 31, 2016 |  | September 30, 2016 |  |
| Receivable from related parties |  | $ | 50 |  |  | $ | 66 |  |
| Payable to related parties |  | 29 |  |  | 11 |  |

- changed (2017-05-04):
[0000833444-17-000016:note_history:27]
The Company has also provided financial support to certain of its VIE's; see Note 1, "Financial Statements," of the notes to consolidated financial statements for additional information.
  (was, 2017-02-08, similarity 0.9946):
[0000833444-17-000007:note_history:27]
The Company has also provided financial support to certain of its VIE's, see Note 1, "Financial Statements," of the notes to consolidated financial statements for additional information.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0000833444-17-000016:note_history:28]
|  |  | March 31, 2017 |  | September 30, 2016 |  |
| Receivable from related parties |  | $ | 57 |  |  | $ | 66 |  |
| Payable to related parties |  | 20 |  |  | 11 |  |
  (was, 2017-02-08, similarity 0.9691):
[0000833444-17-000007:note_history:28]
|  |  | December 31, 2016 |  | September 30, 2016 |  |
| Receivable from related parties |  | $ | 50 |  |  | $ | 66 |  |
| Payable to related parties |  | 29 |  |  | 11 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2017-05-04):
[0000833444-17-000007:note_history:29]
Subsequent Event

- removed (2017-05-04):
[0000833444-17-000007:note_history:30]
On February 2, 2017, the Company issued $500 million aggregate principal amount of 4.5% senior unsecured fixed rate notes due in February 2047. Proceeds were used for general corporate purposes.
