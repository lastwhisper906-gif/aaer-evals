# JCI 8-K — 0000833444-17-000013 filed 2017-04-27

## item codes, every 8-K on or before 2017-05-04

- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2017-05-04

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-17-000013:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq2fy17.htm
EXHIBIT 99.1

[0000833444-17-000013:8k_2_02:2]
Exhibit

[0000833444-17-000013:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000833444-17-000013:8k_2_02:4]
| CONTACT: | Investors:Antonella Franzen(609) 720-4665Ryan Edelman(609) 720-4545Media:Fraser Engerman(414) 524-2733 | Exhibit 99.1 |

[0000833444-17-000013:8k_2_02:5]
Johnson Controls reports second quarter results                                                                                                and increases share repurchase program by $500 million

[0000833444-17-000013:8k_2_02:6]
________________________________________________________________________________

[0000833444-17-000013:8k_2_02:7]
| ▪ | GAAP loss of $0.16 per share driven by non-cash tax charge and other special items |

[0000833444-17-000013:8k_2_02:8]
| ▪ | Adjusted EPS from continuing operations of $0.50, up 11 percent versus prior year |

[0000833444-17-000013:8k_2_02:9]
| ▪ | Adjusted sales of $7.2 billion, reflecting organic growth of 2 percent versus prior year |

[0000833444-17-000013:8k_2_02:10]
| ▪ | Adjusted EBIT margin expansion of 20 basis points year-over-year, to 9.8 percent |

[0000833444-17-000013:8k_2_02:11]
| ▪ | Third quarter adjusted EPS from continuing operations guidance of $0.70 to $0.73, an increase of 15 percent to 20 percent year-over-year |

[0000833444-17-000013:8k_2_02:12]
| ▪ | 2017 adjusted EPS from continuing operations guidance range tightened to $2.60 to $2.68, a 13 percent to 16 percent increase year-over-year |

[0000833444-17-000013:8k_2_02:13]
________________________________________________________________________________

[0000833444-17-000013:8k_2_02:14]
CORK, Ireland, Apr. 27, 2017 -- Johnson Controls International, plc (NYSE: JCI) today reported a fiscal second quarter 2017 GAAP loss per share (“EPS”) from continuing operations of $0.16 driven by a non-cash tax charge and other special items (see attached footnotes for additional information).  Adjusted EPS from continuing operations was $0.50, up 11 percent versus the prior year period.

[0000833444-17-000013:8k_2_02:15]
Adjusted sales of $7.2 billion increased 3 percent compared to the prior year.  Organic sales growth of 2 percent and higher lead pass-through were partially offset by the negative impact of net acquisition and divestiture activity and changes in foreign currency exchange rates.

[0000833444-17-000013:8k_2_02:16]
Earnings before interest and taxes (“EBIT”) was $509 million and EBIT margin was 7.0 percent. Adjusted EBIT was $711 million, up 5 percent over last year (up 7 percent excluding foreign exchange and lead cost increases) with adjusted EBIT margin expansion of 20 basis points, to 9.8 percent.

[0000833444-17-000013:8k_2_02:17]
Page 1 of 16

[0000833444-17-000013:8k_2_02:18]
“Strong second quarter results, ongoing portfolio actions and an increase in our share repurchase program all demonstrate solid progress towards our 2017 priorities and commitments as a newly combined company.  Our leading brands, along with our global footprint and strategic customer relationships, uniquely position us as a world leader in buildings and energy solutions and technologies,” said Alex Molinaroli, Johnson Controls chairman & CEO.  “Another quarter of double-digit EPS growth, accelerating organic sales growth in Buildings and a continued focus on integration, supports our expectations of 13% to 16% EPS growth for the year,” Molinaroli continued.

[0000833444-17-000013:8k_2_02:19]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders                                                             ($ millions, except per-share amounts)

[0000833444-17-000013:8k_2_02:20]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the second quarter of 2016, which are adjusted to reflect the combination of Johnson Controls’ historical Building Efficiency business with historical Tyco results of operations as if these businesses had been operated together during the periods presented, along with certain other adjustments.  For additional information, see the unaudited supplemental financial information included in the Current Report on Form 8-K filed by Johnson Controls with the SEC on Nov. 8, 2016 as well as the attached footnotes.  The spin-off of Adient plc occurred on Oct. 31, 2016 and the results of this business are reported in discontinued operations for all historical periods presented.

[0000833444-17-000013:8k_2_02:21]
|  |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2017 |  | Q2 2017 |  | Q2 2016 |  | Change |
|  |  |  |  |  |  | (Combined) |  |  |
| Sales |  | $7,267 |  | $7,237 |  | $7,058 |  | 3% |
| Segment EBITA |  | 956 |  | 931 |  | 917 |  | 2% |
| EBIT |  | 509 |  | 711 |  | 680 |  | 5% |
| Net (loss) income from continuing operations |  | (148) |  | 473 |  | 426 |  | 11% |
| EPS from continuing operations |  | $(0.16) |  | $0.50 |  | $0.45 |  | 11% |

[0000833444-17-000013:8k_2_02:22]
Organic adjusted sales growth, adjusted segment EBITA, adjusted EBIT, and adjusted EPS from continuing operations are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes.  A slide presentation reviewing second quarter results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-17-000013:8k_2_02:23]
Page 2 of 16

[0000833444-17-000013:8k_2_02:24]
BUSINESS RESULTS

[0000833444-17-000013:8k_2_02:25]
Building Technologies & Solutions (Buildings)

[0000833444-17-000013:8k_2_02:26]
|  |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2017 |  | Q2 2017 |  | Q2 2016 |  | Change |
|  |  |  |  |  |  | (Combined) |  |  |
| Sales |  | $5,571 |  | $5,541 |  | $5,475 |  | 1% |
| Segment EBITA |  | $653 |  | $628 |  | $635 |  | (1)% |
| Segment EBITA margin % |  | 11.7% |  | 11.3% |  | 11.6% |  | (30bps) |

[0000833444-17-000013:8k_2_02:27]
Buildings sales in the second quarter of 2017 were $5.5 billion, up 1 percent versus the prior year quarter.  Excluding M&A and foreign exchange, organic sales increased 3 percent versus the prior year led by 4 percent growth in field sales, which were partially offset by a 1 percent decline in product sales.

[0000833444-17-000013:8k_2_02:28]
Orders in the quarter, excluding M&A and adjusted for foreign exchange, increased 2 percent year-over-year, with 3 percent growth in field orders, including early cross-selling wins, and a 1 percent decline in product orders.  Backlog at the end of the quarter of $8.3 billion, increased 6 percent year-over-year, excluding M&A and adjusted for foreign exchange.

[0000833444-17-000013:8k_2_02:29]
Buildings adjusted segment EBITA was $628 million, down 1 percent versus the prior year.  Adjusted segment EBITA margin of 11.3 percent decreased 30 basis points compared with the prior year quarter as the benefit of volume leverage, productivity savings and cost synergies were more than offset by incremental product and channel investments, as well as mix.

[0000833444-17-000013:8k_2_02:30]
Power Solutions

[0000833444-17-000013:8k_2_02:31]
|  |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2017 |  | Q2 2017 |  | Q2 2016 |  | Change |
|  |  |  |  |  |  | (Combined) |  |  |
| Sales |  | $1,696 |  | $1,696 |  | $1,583 |  | 7% |
| Segment EBITA |  | $303 |  | $303 |  | $282 |  | 7% |
| Segment EBITA margin % |  | 17.9% |  | 17.9% |  | 17.8% |  | 10bps |

[0000833444-17-000013:8k_2_02:32]
Power Solutions sales in the second quarter of 2017 were $1.7 billion, an increase of 7 percent versus the prior year quarter.  Excluding the impact of higher lead pass-through and foreign exchange, organic sales declined 1 percent versus the prior year, as positive mix was offset by lower unit volumes in North America and China.  Global original equipment battery shipments were consistent with the prior year, while aftermarket shipments declined 3 percent in the quarter due to timing of shipments related to customer demand patterns.  Start-Stop battery shipments increased 36 percent year-over-year, with growth in all regions.

[0000833444-17-000013:8k_2_02:33]
Power Solutions adjusted segment EBITA was $303 million, up 7 percent from the prior year quarter, due to favorable product mix, as well as productivity savings, partially offset by lower volumes and the impact of lead.  Adjusted segment EBITA increased 12 percent excluding the impact of foreign exchange and lead.  Adjusted segment EBITA margin of 17.9 percent increased 10 basis points compared with the prior year quarter, including

[0000833444-17-000013:8k_2_02:34]
Page 3 of 16

[0000833444-17-000013:8k_2_02:35]
a 220 basis point headwind related to the impact of lead.  Excluding the impact of lead, adjusted segment EBITA margin increased 230 basis points year-over-year.

[0000833444-17-000013:8k_2_02:36]
Corporate

[0000833444-17-000013:8k_2_02:37]
|  |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2017 |  | Q2 2017 |  | Q2 2016 |  | Change |
|  |  |  |  |  |  | (Combined) |  |  |
| Corporate expense |  | $(240) |  | $(128) |  | $(130) |  | (2)% |

[0000833444-17-000013:8k_2_02:38]
Adjusted corporate expense was $128 million in the second quarter, a decrease of 2 percent compared to the prior year quarter driven by productivity initiatives and cost synergies, partially offset by the timing of expenses.

[0000833444-17-000013:8k_2_02:39]
OTHER ITEMS

[0000833444-17-000013:8k_2_02:40]
| • | During the quarter, the Company repurchased $119 million of its shares and expanded its full year share repurchase program by $500 million. The Company now expects to complete up to $750 million of share repurchases during fiscal 2017. |

[0000833444-17-000013:8k_2_02:41]
| • | On Feb. 7, 2017, the Company issued $500 million in 30 year senior notes at a fixed annual interest rate of 4.5%. Proceeds were used to repay outstanding commercial paper borrowings and for other general corporate purposes. |

[0000833444-17-000013:8k_2_02:42]
| • | On March 15, 2017, the Company issued €1 billion in 6.5 year senior notes at a fixed annual interest rate of 1.0%. Proceeds were used to repay existing debt and for other general corporate purposes. |

[0000833444-17-000013:8k_2_02:43]
| • | On March 15, 2017, the Company announced a definitive agreement to sell its Scott Safety business to 3M in an all cash transaction valued at approximately $2.0 billion. Net cash proceeds from the transaction are expected to approximate $1.8 to $1.9 billion, and will be used to repay a portion of Tyco International Holding Sarl's (“TSarl”) $4.0 billion of merger-related debt. The transaction is expected to close in the second half of calendar 2017, subject to customary closing conditions including required regulatory approvals. |

[0000833444-17-000013:8k_2_02:44]
| • | On March 15, 2017, the Company completed its previously announced divestiture of its ADT South Africa business. Proceeds from the transaction of approximately $130 million will be used to repay a portion of the TSarl merger-related debt. |

[0000833444-17-000013:8k_2_02:45]
###

[0000833444-17-000013:8k_2_02:46]
About Johnson Controls

[0000833444-17-000013:8k_2_02:47]
Johnson Controls is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. Our 120,000 employees create intelligent buildings, efficient energy solutions, integrated infrastructure and next generation transportation systems that work seamlessly together to deliver on the promise of smart cities and communities. Our commitment to sustainability dates back to our roots in 1885, with the invention of the first electric room thermostat. We are committed to helping our customers win and creating greater value

[0000833444-17-000013:8k_2_02:48]
Page 4 of 16

[0000833444-17-000013:8k_2_02:49]
for all of our stakeholders through strategic focus on our buildings and energy growth platforms. For additional information, please visit http://www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter.

[0000833444-17-000013:8k_2_02:50]
###

[0000833444-17-000013:8k_2_02:51]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-17-000013:8k_2_02:52]
###

[0000833444-17-000013:8k_2_02:53]
Non GAAP Financial Information

[0000833444-17-000013:8k_2_02:54]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include mark-to-market for pension plans, transaction/integration/separation costs, restructuring and impairment costs, nonrecurring purchase accounting impacts related to the Tyco merger and discrete tax items. Financial information regarding adjusted sales, organic sales, adjusted segment EBITA and adjusted segment EBITA margin are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as transaction/integration/separation costs and nonrecurring purchase accounting impacts because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.

[0000833444-17-000013:8k_2_02:55]
###

[0000833444-17-000013:8k_2_02:56]
Page 5 of 16

[0000833444-17-000013:8k_2_02:57]
| April 27, 2017JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Three Months Ended March 31, |
|  |  | 2017 |  |  | 2016 |
| Net sales | $ | 7,267 |  |  |  | $ | 4,733 |  |
| Cost of sales | 4,986 |  |  |  | 3,446 |  |
|  | Gross profit | 2,281 |  |  |  | 1,287 |  |
| Selling, general and administrative expenses | (1,726 | ) |  |  | (899 | ) |
| Restructuring and impairment costs | (99 | ) |  |  | (60 | ) |
| Net financing charges | (116 | ) |  |  | (71 | ) |
| Equity income | 53 |  |  |  | 40 |  |
| Income from continuing operations before income taxes | 393 |  |  |  | 297 |  |
| Income tax provision | 508 |  |  |  | 41 |  |
| Income (loss) from continuing operations | (115 | ) |  |  | 256 |  |
| Loss from discontinued operations, net of tax | — |  |  |  | (725 | ) |
| Net loss | (115 | ) |  |  | (469 | ) |
| Less: Income from continuing operations attributable to noncontrolling interests | 33 |  |  |  | 38 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 23 |  |
| Net loss attributable to JCI | $ | (148 | ) |  |  | $ | (530 | ) |
| Income (loss) from continuing operations | $ | (148 | ) |  |  | $ | 218 |  |
| Loss from discontinued operations | — |  |  |  | (748 | ) |
| Net loss attributable to JCI | $ | (148 | ) |  |  | $ | (530 | ) |
| Diluted earnings (loss) per share from continuing operations | $ | (0.16 | ) |  |  | $ | 0.33 |  |
| Diluted loss per share from discontinued operations | — |  |  |  | (1.15 | ) |
| Diluted loss per share * | $ | (0.16 | ) |  |  | $ | (0.81 | ) |
| Diluted weighted average shares | 939.2 |  |  |  | 652.1 |  |
| Shares outstanding at period end | 938.1 |  |  |  | 648.4 |  |

[0000833444-17-000013:8k_2_02:58]
* May not sum due to rounding.

[0000833444-17-000013:8k_2_02:59]
Page 6 of 16

[0000833444-17-000013:8k_2_02:60]
| April 27, 2017JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Six Months Ended March 31, |
|  |  | 2017 |  |  | 2016 |
| Net sales | $ | 14,353 |  |  |  | $ | 9,429 |  |
| Cost of sales | 9,958 |  |  |  | 6,885 |  |
|  | Gross profit | 4,395 |  |  |  | 2,544 |  |
| Selling, general and administrative expenses | (3,296 | ) |  |  | (1,746 | ) |
| Restructuring and impairment costs | (177 | ) |  |  | (60 | ) |
| Net financing charges | (252 | ) |  |  | (137 | ) |
| Equity income | 108 |  |  |  | 82 |  |
| Income from continuing operations before income taxes | 778 |  |  |  | 683 |  |
| Income tax provision | 481 |  |  |  | 124 |  |
| Income from continuing operations | 297 |  |  |  | 559 |  |
| Income from discontinued operations, net of tax | (34 | ) |  |  | (538 | ) |
| Net income | 263 |  |  |  | 21 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 73 |  |  |  | 61 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | 9 |  |  |  | 40 |  |
| Net income (loss) attributable to JCI | $ | 181 |  |  |  | $ | (80 | ) |
| Income from continuing operations | $ | 224 |  |  |  | $ | 498 |  |
| Loss from discontinued operations | (43 | ) |  |  | (578 | ) |
| Net income (loss) attributable to JCI | $ | 181 |  |  |  | $ | (80 | ) |
| Diluted earnings per share from continuing operations | $ | 0.24 |  |  |  | $ | 0.76 |  |
| Diluted loss per share from discontinued operations | (0.05 | ) |  |  | (0.89 | ) |
| Diluted earnings (loss) per share * | $ | 0.19 |  |  |  | $ | (0.12 | ) |
| Diluted weighted average shares | 948.0 |  |  |  | 652.5 |  |
| Shares outstanding at period end | 938.1 |  |  |  | 648.4 |  |

[0000833444-17-000013:8k_2_02:61]
* May not sum due to rounding.

[0000833444-17-000013:8k_2_02:62]
Page 7 of 16

[0000833444-17-000013:8k_2_02:63]
| April 27, 2017JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | March 31,2017 |  | September 30,2016 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 412 |  |  | $ | 579 |  |
| Accounts receivable - net | 6,094 |  |  | 6,394 |  |
| Inventories | 3,138 |  |  | 2,888 |  |
| Assets held for sale | 2,037 |  |  | 5,812 |  |
| Other current assets | 1,548 |  |  | 1,436 |  |
|  | Current assets | 13,229 |  |  | 17,109 |  |
| Property, plant and equipment - net | 5,601 |  |  | 5,632 |  |
| Goodwill | 19,644 |  |  | 21,024 |  |
| Other intangible assets - net | 6,687 |  |  | 7,540 |  |
| Investments in partially-owned affiliates | 1,099 |  |  | 990 |  |
| Noncurrent assets held for sale | — |  |  | 7,374 |  |
| Other noncurrent assets | 3,347 |  |  | 3,510 |  |
|  | Total assets | $ | 49,607 |  |  | $ | 63,179 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 1,666 |  |  | $ | 1,706 |  |
| Accounts payable and accrued expenses | 4,802 |  |  | 5,333 |  |
| Liabilities held for sale | 237 |  |  | 4,276 |  |
| Other current liabilities | 4,037 |  |  | 5,016 |  |
|  | Current liabilities | 10,742 |  |  | 16,331 |  |
| Long-term debt | 11,810 |  |  | 11,053 |  |
| Other noncurrent liabilities | 6,686 |  |  | 6,583 |  |
| Noncurrent liabilities held for sale | — |  |  | 3,888 |  |
| Redeemable noncontrolling interests | 168 |  |  | 234 |  |
| Shareholders' equity attributable to JCI | 19,388 |  |  | 24,118 |  |
| Noncontrolling interests | 813 |  |  | 972 |  |
|  | Total liabilities and equity | $ | 49,607 |  |  | $ | 63,179 |  |

[0000833444-17-000013:8k_2_02:64]
Page 8 of 16

[0000833444-17-000013:8k_2_02:65]
| April 27, 2017JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended March 31, |
|  |  |  |  |  |  | 2017 |  |  | 2016 |
| Operating Activities |  |  |  |  |
| Net loss attributable to JCI | $ | (148 | ) |  |  | $ | (530 | ) |
| Income from continuing operations attributable to noncontrolling interests | 33 |  |  |  | 38 |  |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 23 |  |
| Net loss | (115 | ) |  |  | (469 | ) |
| Adjustments to reconcile net loss to cash provided by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 292 |  |  |  | 219 |  |
|  |  | Pension and postretirement benefit income | (47 | ) |  |  | (17 | ) |
|  |  | Pension and postretirement contributions | (11 | ) |  |  | (34 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (52 | ) |  |  | (97 | ) |
|  |  | Deferred income taxes | 479 |  |  |  | 345 |  |
|  |  | Non-cash restructuring and impairment costs | 23 |  |  |  | 29 |  |
|  |  | Other - net | 45 |  |  |  | 23 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (58 | ) |  |  | (124 | ) |
|  |  |  |  | Inventories | (228 | ) |  |  | (98 | ) |
|  |  |  |  | Other assets | (63 | ) |  |  | 242 |  |
|  |  |  |  | Restructuring reserves | 27 |  |  |  | 141 |  |
|  |  |  |  | Accounts payable and accrued liabilities | 195 |  |  |  | 83 |  |
|  |  |  |  | Accrued income taxes | (123 | ) |  |  | 391 |  |
|  |  |  |  |  | Cash provided by operating activities | 364 |  |  |  | 634 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (263 | ) |  |  | (261 | ) |
| Sale of property, plant and equipment | 16 |  |  |  | 5 |  |
| Acquisition of businesses, net of cash acquired | (3 | ) |  |  | — |  |
| Business divestitures, net of cash divested | 133 |  |  |  | 22 |  |
| Other - net | (24 | ) |  |  | 1 |  |
|  |  |  |  |  | Cash used by investing activities | (141 | ) |  |  | (233 | ) |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | 220 |  |  |  | (188 | ) |
| Debt financing costs | (11 | ) |  |  | — |  |
| Stock repurchases | (119 | ) |  |  | — |  |
| Payment of cash dividends | (235 | ) |  |  | (188 | ) |
| Proceeds from the exercise of stock options | 59 |  |  |  | 4 |  |
| Dividends paid to noncontrolling interests | (47 | ) |  |  | (73 | ) |
| Cash transferred to Adient related to spin-off | (101 | ) |  |  | — |  |
| Cash received related to prior acquisitions | 8 |  |  |  | — |  |
| Other - net | 8 |  |  |  | (3 | ) |
|  |  |  |  |  | Cash used by financing activities | (218 | ) |  |  | (448 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 30 |  |  |  | (9 | ) |
| Cash held for sale | — |  |  |  | (8 | ) |
| Increase (decrease) in cash and cash equivalents | $ | 35 |  |  |  | $ | (64 | ) |

[0000833444-17-000013:8k_2_02:66]
Page 9 of 16

[0000833444-17-000013:8k_2_02:67]
| April 27, 2017JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Six Months Ended March 31, |
|  |  |  |  |  |  | 2017 |  |  | 2016 |
| Operating Activities |  |  |  |  |
| Net income (loss) attributable to JCI | $ | 181 |  |  |  | $ | (80 | ) |
| Income from continuing operations attributable to noncontrolling interests | 73 |  |  |  | 61 |  |
| Income from discontinued operations attributable to noncontrolling interests | 9 |  |  |  | 40 |  |
| Net income | 263 |  |  |  | 21 |  |
| Adjustments to reconcile net income to cash provided (used) by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 638 |  |  |  | 445 |  |
|  |  | Pension and postretirement benefit income | (202 | ) |  |  | (34 | ) |
|  |  | Pension and postretirement contributions | (258 | ) |  |  | (53 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (116 | ) |  |  | (207 | ) |
|  |  | Deferred income taxes | 1,059 |  |  |  | 331 |  |
|  |  | Non-cash restructuring and impairment costs | 39 |  |  |  | 29 |  |
|  |  | Other - net | 82 |  |  |  | 52 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (21 | ) |  |  | 75 |  |
|  |  |  |  | Inventories | (370 | ) |  |  | (168 | ) |
|  |  |  |  | Other assets | (150 | ) |  |  | 134 |  |
|  |  |  |  | Restructuring reserves | 47 |  |  |  | 67 |  |
|  |  |  |  | Accounts payable and accrued liabilities | (616 | ) |  |  | (311 | ) |
|  |  |  |  | Accrued income taxes | (1,931 | ) |  |  | 240 |  |
|  |  |  |  |  | Cash provided (used) by operating activities | (1,536 | ) |  |  | 621 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (634 | ) |  |  | (543 | ) |
| Sale of property, plant and equipment | 18 |  |  |  | 14 |  |
| Acquisition of businesses, net of cash acquired | (6 | ) |  |  | (133 | ) |
| Business divestitures, net of cash divested | 180 |  |  |  | 40 |  |
| Other - net | (30 | ) |  |  | 5 |  |
|  |  |  |  |  | Cash used by investing activities | (472 | ) |  |  | (617 | ) |
| Financing Activities |  |  |  |  |
| Increase in short and long-term debt - net | 776 |  |  |  | 326 |  |
| Debt financing costs | (17 | ) |  |  | — |  |
| Stock repurchases | (119 | ) |  |  | — |  |
| Payment of cash dividends | (235 | ) |  |  | (356 | ) |
| Proceeds from the exercise of stock options | 88 |  |  |  | 20 |  |
| Dividends paid to noncontrolling interests | (78 | ) |  |  | (227 | ) |
| Dividend from Adient spin-off | 2,050 |  |  |  | — |  |
| Cash transferred to Adient related to spin-off | (665 | ) |  |  | — |  |
| Cash paid related to prior acquisitions | (37 | ) |  |  | — |  |
| Other - net | (2 | ) |  |  | 3 |  |
|  |  |  |  |  | Cash provided (used) by financing activities | 1,761 |  |  |  | (234 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (25 | ) |  |  | (9 | ) |
| Cash held for sale | 105 |  |  |  | (22 | ) |
| Decrease in cash and cash equivalents | $ | (167 | ) |  |  | $ | (261 | ) |

[0000833444-17-000013:8k_2_02:68]
Page 10 of 16

[0000833444-17-000013:8k_2_02:69]
April 27, 2017

[0000833444-17-000013:8k_2_02:70]
FOOTNOTES

[0000833444-17-000013:8k_2_02:71]
1. Financial Summary

[0000833444-17-000013:8k_2_02:72]
In the first quarter of fiscal 2017, the Company began evaluating the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans.  Historical information has been revised to present the comparable periods on a consistent basis.  Also in the first quarter of fiscal 2017, the Company began reporting the Automotive Experience business as a discontinued operation, which required retrospective application to previously reported financial information.  As a result, the segment EBITA amounts shown below are for continuing operations and exclude the Automotive Experience business.  In addition, the financial results for the three and six months ended March 31, 2016 exclude the Tyco business.

[0000833444-17-000013:8k_2_02:73]
|  | Three Months Ended March 31, |
| (in millions; unaudited) | 2017 |  | 2016 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Technologies & Solutions | $ | 5,571 |  |  | $ | 5,541 |  |  | $ | 3,150 |  |  | $ | 3,150 |  |
| Power Solutions | 1,696 |  |  | 1,696 |  |  | 1,583 |  |  | 1,583 |  |
| Net Sales | $ | 7,267 |  |  | $ | 7,237 |  |  | $ | 4,733 |  |  | $ | 4,733 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Technologies & Solutions | $ | 653 |  |  | $ | 628 |  |  | $ | 276 |  |  | $ | 282 |  |
| Power Solutions | 303 |  |  | 303 |  |  | 282 |  |  | 282 |  |
| Segment EBITA | 956 |  |  | 931 |  |  | 558 |  |  | 564 |  |
| Corporate expenses (2) | (240 | ) |  | (128 | ) |  | (110 | ) |  | (75 | ) |
| Amortization of intangible assets (3) | (126 | ) |  | (92 | ) |  | (20 | ) |  | (20 | ) |
| Mark-to-market gain for pension plans (4) | 18 |  |  | — |  |  | — |  |  | — |  |
| Restructuring and impairment costs (5) | (99 | ) |  | — |  |  | (60 | ) |  | — |  |
| EBIT (6) | 509 |  |  | 711 |  |  | 368 |  |  | 469 |  |
| Net financing charges (7) | (116 | ) |  | (116 | ) |  | (71 | ) |  | (71 | ) |
| Income from continuing operations before income taxes | 393 |  |  | 595 |  |  | 297 |  |  | 398 |  |
| Income tax provision (8) | (508 | ) |  | (89 | ) |  | (41 | ) |  | (70 | ) |
| Income (loss) from continuing operations | (115 | ) |  | 506 |  |  | 256 |  |  | 328 |  |
| Income from continuing operations attributable to noncontrolling interests (9) | (33 | ) |  | (33 | ) |  | (38 | ) |  | (45 | ) |
| Net income (loss) from continuing operations attributable to JCI | $ | (148 | ) |  | $ | 473 |  |  | $ | 218 |  |  | $ | 283 |  |

[0000833444-17-000013:8k_2_02:74]
|  | Six Months Ended March 31, |
| (in millions; unaudited) | 2017 |  | 2016 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Technologies & Solutions | $ | 10,757 |  |  | $ | 10,737 |  |  | $ | 6,106 |  |  | $ | 6,106 |  |
| Power Solutions | 3,596 |  |  | 3,596 |  |  | 3,323 |  |  | 3,323 |  |
| Net Sales | $ | 14,353 |  |  | $ | 14,333 |  |  | $ | 9,429 |  |  | $ | 9,429 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Technologies & Solutions | $ | 1,088 |  |  | $ | 1,206 |  |  | $ | 475 |  |  | $ | 493 |  |
| Power Solutions | 692 |  |  | 693 |  |  | 642 |  |  | 642 |  |
| Segment EBITA | 1,780 |  |  | 1,899 |  |  | 1,117 |  |  | 1,135 |  |
| Corporate expenses (2) | (433 | ) |  | (236 | ) |  | (197 | ) |  | (143 | ) |
| Amortization of intangible assets (3) | (275 | ) |  | (195 | ) |  | (40 | ) |  | (40 | ) |
| Mark-to-market gain for pension plans (4) | 135 |  |  | — |  |  | — |  |  | — |  |
| Restructuring and impairment costs (5) | (177 | ) |  | — |  |  | (60 | ) |  | — |  |
| EBIT (6) | 1,030 |  |  | 1,468 |  |  | 820 |  |  | 952 |  |
| Net financing charges (7) | (252 | ) |  | (235 | ) |  | (137 | ) |  | (137 | ) |
| Income from continuing operations before income taxes | 778 |  |  | 1,233 |  |  | 683 |  |  | 815 |  |
| Income tax provision (8) | (481 | ) |  | (185 | ) |  | (124 | ) |  | (141 | ) |
| Income from continuing operations | 297 |  |  | 1,048 |  |  | 559 |  |  | 674 |  |
| Income from continuing operations attributable to noncontrolling interests (9) | (73 | ) |  | (73 | ) |  | (61 | ) |  | (74 | ) |
| Net income from continuing operations attributable to JCI | $ | 224 |  |  | $ | 975 |  |  | $ | 498 |  |  | $ | 600 |  |

[0000833444-17-000013:8k_2_02:75]
Building Technology & Solutions - Provides facility systems and services including comfort, energy and security management for the non-residential buildings market, and provides heating, ventilating, and air conditioning products and services, security products and services, fire detection and suppression products and services, and life safety products for the residential and non-residential building markets.

[0000833444-17-000013:8k_2_02:76]
Power Solutions -  Services both automotive original equipment manufacturers and the battery aftermarket by providing advanced battery technology, coupled with systems engineering, marketing and service expertise.

[0000833444-17-000013:8k_2_02:77]
Page 11 of 16

[0000833444-17-000013:8k_2_02:78]
April 27, 2017

[0000833444-17-000013:8k_2_02:79]
(1) The Company's press release contains financial information regarding adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures.  The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-17-000013:8k_2_02:80]
The following is the three months ended March 31, 2017 and 2016 reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-17-000013:8k_2_02:81]
| (in millions) | Building Technologies & Solutions |  | Power Solutions |  | Consolidated JCI plc |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales as reported | $ | 5,571 |  |  | $ | 3,150 |  |  | $ | 1,696 |  |  | $ | 1,583 |  |  | $ | 7,267 |  |  | $ | 4,733 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | (30 | ) |  | — |  |  | — |  |  | — |  |  | (30 | ) |  | — |  |
| Adjusted net sales | $ | 5,541 |  |  | $ | 3,150 |  |  | $ | 1,696 |  |  | $ | 1,583 |  |  | $ | 7,237 |  |  | $ | 4,733 |  |
| Segment EBITA as reported | $ | 653 |  |  | $ | 276 |  |  | $ | 303 |  |  | $ | 282 |  |  | $ | 956 |  |  | $ | 558 |  |
| Segment EBITA margin as reported | 11.7 | % |  | 8.8 | % |  | 17.9 | % |  | 17.8 | % |  | 13.2 | % |  | 11.8 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | 10 |  |  | 1 |  |  | — |  |  | — |  |  | 10 |  |  | 1 |  |
| Integration costs | 16 |  |  | 5 |  |  | — |  |  | — |  |  | 16 |  |  | 5 |  |
| Nonrecurring purchase accounting impacts | (51 | ) |  | — |  |  | — |  |  | — |  |  | (51 | ) |  | — |  |
| Adjusted segment EBITA | $ | 628 |  |  | $ | 282 |  |  | $ | 303 |  |  | $ | 282 |  |  | $ | 931 |  |  | $ | 564 |  |
| Adjusted segment EBITA margin | 11.3 | % |  | 9.0 | % |  | 17.9 | % |  | 17.8 | % |  | 12.9 | % |  | 11.9 | % |

[0000833444-17-000013:8k_2_02:82]
The following is the six months ended March 31, 2017 and 2016 reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-17-000013:8k_2_02:83]
| (in millions) | Building Technologies & Solutions |  | Power Solutions |  | Consolidated JCI plc |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales as reported | $ | 10,757 |  |  | $ | 6,106 |  |  | $ | 3,596 |  |  | $ | 3,323 |  |  | $ | 14,353 |  |  | $ | 9,429 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | (20 | ) |  | — |  |  | — |  |  | — |  |  | (20 | ) |  | — |  |
| Adjusted net sales | $ | 10,737 |  |  | $ | 6,106 |  |  | $ | 3,596 |  |  | $ | 3,323 |  |  | $ | 14,333 |  |  | $ | 9,429 |  |
| Segment EBITA as reported | $ | 1,088 |  |  | $ | 475 |  |  | $ | 692 |  |  | $ | 642 |  |  | $ | 1,780 |  |  | $ | 1,117 |  |
| Segment EBITA margin as reported | 10.1 | % |  | 7.8 | % |  | 19.2 | % |  | 19.3 | % |  | 12.4 | % |  | 11.8 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | 27 |  |  | 10 |  |  | 1 |  |  | — |  |  | 28 |  |  | 10 |  |
| Integration costs | 30 |  |  | 8 |  |  | — |  |  | — |  |  | 30 |  |  | 8 |  |
| Nonrecurring purchase accounting impacts | 61 |  |  | — |  |  | — |  |  | — |  |  | 61 |  |  | — |  |
| Adjusted segment EBITA | $ | 1,206 |  |  | $ | 493 |  |  | $ | 693 |  |  | $ | 642 |  |  | $ | 1,899 |  |  | $ | 1,135 |  |
| Adjusted segment EBITA margin | 11.2 | % |  | 8.1 | % |  | 19.3 | % |  | 19.3 | % |  | 13.2 | % |  | 12.0 | % |

[0000833444-17-000013:8k_2_02:84]
(2) Adjusted Corporate expenses for the three months ended March 31, 2017 excludes $95 million of integration costs and $17 million of transaction costs. Adjusted Corporate expenses for the six months ended March 31, 2017 excludes $145 million of integration costs, $48 million of transaction costs and $4 million of separation costs.  Adjusted Corporate expenses for the three months ended March 31, 2016 excludes $18 million of transaction costs and $17 million of separation costs. Adjusted Corporate expenses for the six months ended March 31, 2016 excludes $35 million of separation costs and $19 million of transaction costs.

[0000833444-17-000013:8k_2_02:85]
(3) Adjusted amortization of intangible assets for the three and six months ended March 31, 2017 excludes $34 million and $80 million, respectively, of nonrecurring asset amortization related to Tyco purchase accounting.

[0000833444-17-000013:8k_2_02:86]
Page 12 of 16

[0000833444-17-000013:8k_2_02:87]
April 27, 2017

[0000833444-17-000013:8k_2_02:88]
(4) The three and six months ended March 31, 2017 pension mark-to-market gains of $18 million and $135 million, respectively, due to lump sum payouts for certain U.S. pension plans are excluded from the adjusted non-GAAP results.

[0000833444-17-000013:8k_2_02:89]
(5) The three and six months ended March 31, 2017 restructuring and impairment charges of $99 million and $177 million, respectively, are excluded from the adjusted non-GAAP results.  The three and six months ended March 31, 2016 restructuring and impairment charge of $60 million is excluded from the adjusted non-GAAP results.

[0000833444-17-000013:8k_2_02:90]
(6) Management defines earnings before interest and taxes (EBIT) as income from continuing operations before net financing charges, income taxes and noncontrolling interests.

[0000833444-17-000013:8k_2_02:91]
(7) Adjusted net financing charges for the six months ended March 31, 2017 exclude $17 million of transaction costs related to the debt exchange offers.

[0000833444-17-000013:8k_2_02:92]
(8) Adjusted income tax provision for the three months ended March 31, 2017 excludes the non-cash tax charge of $457 million related to establishment of a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries of the Scott Safety business and the tax provisions for the pension mark-to-market gain of $8 million and Tyco nonrecurring purchase accounting impacts of $5 million, partially offset by the tax benefits of integration costs of $25 million, restructuring and impairment costs of $20 million and transaction costs of $6 million. Adjusted income tax provision for the six months ended March 31, 2017 excludes the non-cash tax charge of $457 million related to establishment of a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries of the Scott Safety business and the tax provision for the pension mark-to-market gains of $54 million, partially offset by the tax benefits of changes in entity tax status of $101 million, Tyco nonrecurring purchase accounting impacts of $38 million, restructuring and impairment costs of $34 million, integration costs of $32 million and transaction costs of $10 million. Adjusted income tax provision for the three months ended March 31, 2016 excludes the tax benefits related to the first quarter impact of the reduction in the Company's annual effective tax rate of $15 million, restructuring and impairment costs of $12 million, transaction costs of $1 million and integration costs of $1 million. Adjusted income tax provision for the six months ended March 31, 2016 excludes the tax benefits of restructuring and impairment costs of $12 million, transaction costs of $3 million, integration costs of $1 million and separation costs of $1 million.

[0000833444-17-000013:8k_2_02:93]
(9) Adjusted income from continuing operations attributable to noncontrolling interests for the three months ended March 31, 2016 excludes $6 million for the noncontrolling interest impact of restructuring and impairment costs and $1 million for the noncontrolling interest impact of integration costs. Adjusted income from continuing operations attributable to noncontrolling interests for the six months ended March 31, 2016, excludes $7 million for the noncontrolling interest impact of transaction/integration costs and $6 million for the noncontrolling interest impact of restructuring and impairment costs.

[0000833444-17-000013:8k_2_02:94]
2. 2016 Supplemental Combined Information

[0000833444-17-000013:8k_2_02:95]
As a result of the reverse merger between JCI and Tyco, which closed on September 2, 2016, the Company is providing supplemental combined financial information.  As supplemental information that management believes will be useful to investors, the Company has provided unaudited selected historical information which combines JCI’s historical Building Efficiency business with historical Tyco results of operations as if these businesses had been operated together during the periods presented.

[0000833444-17-000013:8k_2_02:96]
The merger is accounted for as a reverse acquisition with JCI considered to be acquiring Tyco for accounting purposes.  As a result, the amounts reflected in Column A in the below table present the historical results of JCI, revised for the reporting changes described within footnote 1 above.  The amounts in Column B reflect the impact of the special items, as set forth in the notes to the table and within footnote 1 above. The amounts in Column C reflect the inclusion of Tyco’s historical results for the period prior to the merger on an adjusted basis.

[0000833444-17-000013:8k_2_02:97]
For the avoidance of doubt, this supplemental combined information is not intended to be, and was not, prepared on a basis consistent with the unaudited pro forma condensed combined financial information in Exhibit 99.3 to the Company’s Current Report on Form 8-K/A filed October 3, 2016 with the U.S. Securities and Exchange Commission (the “Pro Forma 8-K/A Filing”), which provides the pro forma financial information required by Item 9.01(b) of Form 8-K. The supplemental combined information is intentionally different from, but does not supersede, the pro forma financial information in the Pro Forma 8-K/A Filing.

[0000833444-17-000013:8k_2_02:98]
In addition, the supplemental combined information does not purport to indicate the results that actually would have been obtained had the JCI and Tyco businesses been operated together on the basis of the new segment structure during the periods presented, or which may be realized in the future.

[0000833444-17-000013:8k_2_02:99]
Page 13 of 16

[0000833444-17-000013:8k_2_02:100]
April 27, 2017

[0000833444-17-000013:8k_2_02:101]
Amounts Adjusted for Certain Special Items

[0000833444-17-000013:8k_2_02:102]
The supplemental combined information includes line items, such as net sales, income from continuing operations before income taxes, income tax provision, noncontrolling interest, net income and diluted EPS, that have been adjusted for the special items set forth in the notes to the table. Such amounts should be viewed in addition to, and not in lieu of, net sales, income from continuing operations before income taxes, income tax provision, noncontrolling interest, net income and diluted EPS and other financial measures on an unadjusted basis. In addition, per share amounts presented in the tables take into account the effects of (i) the issuance of ordinary shares to JCI shareholders in connection with the merger, and (ii) the consolidation of Tyco ordinary shares immediately prior to the merger. As a result, share counts reflect shares outstanding as of September 2, 2016 immediately following the consummation of the merger transaction.

[0000833444-17-000013:8k_2_02:103]
The Company’s management believes that these adjusted amounts, when considered together with the unadjusted amounts, provide information that is useful to investors in understanding period-over-period operating results separate and apart from items that may, or could, have a disproportionate positive or negative impact on results in any particular period. The Company’s management also believes that these adjusted amounts enhance the ability of investors to analyze trends in the Company’s underlying business and to better understand the Company’s performance. In addition, the Company may utilize adjusted amounts as guides in forecasting, budgeting and long-term planning processes and to measure operating performance for compensation purposes. Adjusted amounts should be considered in addition to, and not as a substitute for, or superior to, unadjusted amounts.

[0000833444-17-000013:8k_2_02:104]
| (in millions, except per share data; unaudited) |  | Three Months Ended March 31, 2016 |
|  |  | A |  | B |  | C |  | D |
| Net sales |  |  |  |  |  |  |  |  |
| Building Technologies & Solutions |  | $ | 3,150 |  |  | $ | — |  |  | $ | 2,325 |  |  | $ | 5,475 |  |
| Power Solutions |  | 1,583 |  |  | — |  |  | — |  |  | 1,583 |  |
| Net sales |  | $ | 4,733 |  |  | $ | — |  |  | $ | 2,325 |  |  | $ | 7,058 |  |
| Income from continuing operations |  |  |  |  |  |  |  |  |
| Building Technologies & Solutions |  | $ | 276 |  |  | $ | 6 |  |  | $ | 353 |  |  | $ | 635 |  |
| Power Solutions |  | 282 |  |  | — |  |  | — |  |  | 282 |  |
| Segment EBITA |  | 558 |  |  | 6 |  |  | 353 |  |  | 917 |  |
| Corporate expenses |  | (110 | ) |  | 35 |  |  | (55 | ) |  | (130 | ) |
| Amortization of intangible assets |  | (20 | ) |  | — |  |  | (87 | ) |  | (107 | ) |
| Restructuring and impairment costs |  | (60 | ) |  | 60 |  |  | — |  |  | — |  |
| EBIT |  | 368 |  |  | 101 |  |  | 211 |  |  | 680 |  |
| Net financing charges |  | (71 | ) |  | — |  |  | (43 | ) |  | (114 | ) |
| Income from continuing operations before income taxes |  | 297 |  |  | 101 |  |  | 168 |  |  | 566 |  |
| Income tax provision |  | (41 | ) |  | (29 | ) |  | (26 | ) |  | (96 | ) |
| Noncontrolling interest |  | (38 | ) |  | (7 | ) |  | 1 |  |  | (44 | ) |
| Net income |  | $ | 218 |  |  | $ | 65 |  |  | $ | 143 |  |  | $ | 426 |  |
| Diluted weighted average shares |  | 652.1 |  |  |  |  |  |  | 940.0 |  |
| Diluted earnings per share |  | $ | 0.33 |  |  |  |  |  |  | $ | 0.45 |  |

[0000833444-17-000013:8k_2_02:105]
| (in millions, except per share data; unaudited) |  | Six Months Ended March 31, 2016 |
|  |  | A |  | B |  | C |  | D |
| Net sales |  |  |  |  |  |  |  |  |
| Building Technologies & Solutions |  | $ | 6,106 |  |  | $ | — |  |  | $ | 4,695 |  |  | $ | 10,801 |  |
| Power Solutions |  | 3,323 |  |  | — |  |  | — |  |  | 3,323 |  |
| Net sales |  | $ | 9,429 |  |  | $ | — |  |  | $ | 4,695 |  |  | $ | 14,124 |  |
| Income from continuing operations |  |  |  |  |  |  |  |  |
| Building Technologies & Solutions |  | $ | 475 |  |  | $ | 18 |  |  | $ | 701 |  |  | $ | 1,194 |  |
| Power Solutions |  | 642 |  |  | — |  |  | — |  |  | 642 |  |
| Segment EBITA |  | 1,117 |  |  | 18 |  |  | 701 |  |  | 1,836 |  |
| Corporate expenses |  | (197 | ) |  | 54 |  |  | (110 | ) |  | (253 | ) |
| Amortization of intangible assets |  | (40 | ) |  | — |  |  | (173 | ) |  | (213 | ) |
| Restructuring and impairment costs |  | (60 | ) |  | 60 |  |  | — |  |  | — |  |
| EBIT |  | 820 |  |  | 132 |  |  | 418 |  |  | 1,370 |  |
| Net financing charges |  | (137 | ) |  | — |  |  | (88 | ) |  | (225 | ) |
| Income from continuing operations before income taxes |  | 683 |  |  | 132 |  |  | 330 |  |  | 1,145 |  |
| Income tax provision |  | (124 | ) |  | (17 | ) |  | (53 | ) |  | (194 | ) |
| Noncontrolling interest |  | (61 | ) |  | (13 | ) |  | 1 |  |  | (73 | ) |
| Net income |  | $ | 498 |  |  | $ | 102 |  |  | $ | 278 |  |  | $ | 878 |  |
| Diluted weighted average shares |  | 652.5 |  |  |  |  |  |  | 940.0 |  |
| Diluted earnings per share |  | $ | 0.76 |  |  |  |  |  |  | $ | 0.93 |  |

[0000833444-17-000013:8k_2_02:106]
A - Johnson Controls, as reported.

[0000833444-17-000013:8k_2_02:107]
B - Adjusted to exclude special items because these costs are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in better understanding the ongoing operations and business trends of the Company.  The special items are described by line item in footnote 1 above.  The income tax provision and noncontrolling interest adjustments are a result of the special items discussed in footnote 1.

[0000833444-17-000013:8k_2_02:108]
C - Includes Tyco adjusted non-GAAP results for the three and six months ended March 31, 2016, as if the merger occurred October 1, 2015. Tyco’s first three fiscal quarters of 2016 ended on the last Friday of December, March and June, while JCI’s fiscal quarters ended on the last day of each such month. Because the historical statements of income of each company represent full and equivalent quarterly periods, no adjustments were made to align the fiscal quarters.  The income tax provision also includes an adjustment to arrive at an annualized 17% tax rate for fiscal 2016 as a combined company.

[0000833444-17-000013:8k_2_02:109]
D - Combined financial information as if the merger with Tyco was completed on October 1, 2015. Reflects annual 17% tax rate and 940 million share count.

[0000833444-17-000013:8k_2_02:110]
Page 14 of 16

[0000833444-17-000013:8k_2_02:111]
April 27, 2017

[0000833444-17-000013:8k_2_02:112]
3. Organic Adjusted Net Sales Growth Reconciliation

[0000833444-17-000013:8k_2_02:113]
The components of the changes in adjusted net sales for the three months ended March 31, 2017 versus the three months ended March 31, 2016, including organic net sales, is shown below (unaudited):

[0000833444-17-000013:8k_2_02:114]
| (in millions) | Combined Adjusted Net Sales for the Three Months Ended March 31, 2016 |  | Foreign Currency |  | Acquisitions/Divestitures, Net |  | Lead Impact |  | Organic Net Sales |  | Adjusted Net Sales for the Three Months EndedMarch 31, 2017 |
| Building Technologies & Solutions | $ | 5,475 |  |  | $ | (21 | ) |  | -0.4 | % |  | $ | (51 | ) |  | -0.9 | % |  | $ | — |  |  | — |  |  | $ | 138 |  |  | 2.5 | % |  | $ | 5,541 |  |  | 1.2 | % |
| Power Solutions | 1,583 |  |  | (4 | ) |  | -0.3 | % |  | — |  |  | — |  |  | 127 |  |  | 8.0 | % |  | (10 | ) |  | -0.6 | % |  | 1,696 |  |  | 7.1 | % |
| Total net sales | $ | 7,058 |  |  | $ | (25 | ) |  | -0.4 | % |  | $ | (51 | ) |  | -0.7 | % |  | $ | 127 |  |  | 1.8 | % |  | $ | 128 |  |  | 1.8 | % |  | $ | 7,237 |  |  | 2.5 | % |

[0000833444-17-000013:8k_2_02:115]
The components of the changes in adjusted net sales for the six months ended March 31, 2017 versus the six months ended March 31, 2016, including organic net sales, is shown below (unaudited):

[0000833444-17-000013:8k_2_02:116]
| (in millions) | Combined Adjusted Net Sales for the Six Months Ended March 31, 2016 |  | Foreign Currency |  | Acquisitions/Divestitures, Net |  | Lead Impact |  | Organic Net Sales |  | Adjusted Net Sales for the Six Months EndedMarch 31, 2017 |
| Building Technologies & Solutions | $ | 10,801 |  |  | $ | (67 | ) |  | -0.6 | % |  | $ | (101 | ) |  | -0.9 | % |  | $ | — |  |  | — |  |  | $ | 104 |  |  | 1.0 | % |  | $ | 10,737 |  |  | -0.6 | % |
| Power Solutions | 3,323 |  |  | (15 | ) |  | -0.5 | % |  | — |  |  | — |  |  | 174 |  |  | 5.2 | % |  | 114 |  |  | 3.4 | % |  | 3,596 |  |  | 8.2 | % |
| Total net sales | $ | 14,124 |  |  | $ | (82 | ) |  | -0.6 | % |  | $ | (101 | ) |  | -0.7 | % |  | $ | 174 |  |  | 1.2 | % |  | $ | 218 |  |  | 1.5 | % |  | $ | 14,333 |  |  | 1.5 | % |

[0000833444-17-000013:8k_2_02:117]
4.  Diluted Earnings Per Share Reconciliation

[0000833444-17-000013:8k_2_02:118]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure.  The adjusting items include transaction/integration/separation costs,  nonrecurring purchase accounting impacts related to the Tyco merger, mark-to-market gain for pension plans, restructuring and impairment costs, and discrete tax items.  The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company.  Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-17-000013:8k_2_02:119]
A reconciliation of diluted earnings per share as reported to diluted adjusted earnings per share for the respective periods is shown below (unaudited):

[0000833444-17-000013:8k_2_02:120]
|  | Net Income Attributableto JCI plc |  | Net Income Attributable toJCI plc from ContinuingOperations |
|  | Three Months Ended |  | Three Months Ended |
|  | March 31, |  | March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Earnings (loss) per share as reported for JCI plc | $ | (0.16 | ) |  | $ | (0.81 | ) |  | $ | (0.16 | ) |  | $ | 0.33 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | 0.03 |  |  | 0.03 |  |  | 0.03 |  |  | 0.03 |  |
| Related tax impact | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |
| Integration costs | 0.12 |  |  | 0.01 |  |  | 0.12 |  |  | 0.01 |  |
| Related tax impact | (0.03) |  |  | — |  |  | (0.03) |  |  | — |  |
| Separation costs | — |  |  | 0.16 |  |  | — |  |  | 0.03 |  |
| Related tax impact | — |  |  | (0.01) |  |  | — |  |  | — |  |
| Nonrecurring purchase accounting impacts | (0.02) |  |  | — |  |  | (0.02) |  |  | — |  |
| Related tax impact | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Mark-to-market gain for pension plans | (0.02) |  |  | — |  |  | (0.02) |  |  | — |  |
| Related tax impact | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Restructuring and impairment costs | 0.10 |  |  | 0.34 |  |  | 0.10 |  |  | 0.08 |  |
| Related tax impact | (0.02) |  |  | (0.03) |  |  | (0.02) |  |  | (0.02) |  |
| Discrete tax items | 0.48 |  |  | 1.17 |  |  | 0.48 |  |  | (0.02) |  |
| Adjusted earnings per share for JCI plc * | $ | 0.50 |  |  | $ | 0.86 |  |  | $ | 0.50 |  |  | $ | 0.43 |  |

[0000833444-17-000013:8k_2_02:121]
|  | Net Income Attributableto JCI plc |  | Net Income Attributable toJCI plc from ContinuingOperations |
|  | Six Months Ended |  | Six Months Ended |
|  | March 31, |  | March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Earnings (loss) per share as reported for JCI plc | $ | 0.19 |  |  | $ | (0.12 | ) |  | $ | 0.24 |  |  | $ | 0.76 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | 0.10 |  |  | 0.04 |  |  | 0.10 |  |  | 0.04 |  |
| Related tax impact | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |
| Integration costs | 0.18 |  |  | 0.01 |  |  | 0.18 |  |  | 0.01 |  |
| Related tax impact | (0.03) |  |  | — |  |  | (0.03) |  |  | — |  |
| Separation costs | 0.09 |  |  | 0.30 |  |  | — |  |  | 0.05 |  |
| Related tax impact | — |  |  | (0.02) |  |  | — |  |  | — |  |
| Nonrecurring purchase accounting impacts | 0.15 |  |  | — |  |  | 0.15 |  |  | — |  |
| Related tax impact | (0.04) |  |  | — |  |  | (0.04) |  |  | — |  |
| Mark-to-market gain for pension plans | (0.14) |  |  | — |  |  | (0.14) |  |  | — |  |
| Related tax impact | 0.06 |  |  | — |  |  | 0.06 |  |  | — |  |
| Restructuring and impairment costs | 0.19 |  |  | 0.34 |  |  | 0.19 |  |  | 0.08 |  |
| Related tax impact | (0.04) |  |  | (0.03) |  |  | (0.04) |  |  | (0.02) |  |
| Discrete tax items | 0.40 |  |  | 1.20 |  |  | 0.38 |  |  | — |  |
| Adjusted earnings per share for JCI plc * | $ | 1.09 |  |  | $ | 1.71 |  |  | $ | 1.03 |  |  | $ | 0.92 |  |

[0000833444-17-000013:8k_2_02:122]
* May not sum due to rounding.

[0000833444-17-000013:8k_2_02:123]
A reconciliation of the differences between earnings per share as reported and adjusted earnings per share provided on a forward-looking basis is not available due to the high variability of the net mark-to-market adjustments related to pension and postretirement plans and unpredictability of any other potential adjusting items.

[0000833444-17-000013:8k_2_02:124]
Page 15 of 16

[0000833444-17-000013:8k_2_02:125]
April 27, 2017

[0000833444-17-000013:8k_2_02:126]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-17-000013:8k_2_02:127]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, |  | March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Weighted Average Shares Outstanding for JCI plc |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 939.2 |  |  | 648.2 |  |  | 938.2 |  |  | 648.0 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |
| and unvested performance share awards | — |  |  | 3.9 |  |  | 9.8 |  |  | 4.5 |  |
| Diluted weighted average shares outstanding | 939.2 |  |  | 652.1 |  |  | 948.0 |  |  | 652.5 |  |

[0000833444-17-000013:8k_2_02:128]
For the three months ended March 31, 2017, the total number of potential dilutive shares due to stock options, unvested restricted stock and unvested performance share awards was 9.4 million. However, these items were not included in the computation of diluted loss per share for the three months ended March 31, 2017, since to do so would decrease the loss per share.  On an adjusted diluted outstanding share basis, inclusion of the effect of dilutive securities results in diluted weighted average shares outstanding of 948.6 million for the three months ended March 31, 2017.

[0000833444-17-000013:8k_2_02:129]
5.  Mark-to-Market of Pension and Postretirement Plans

[0000833444-17-000013:8k_2_02:130]
The pension and postretirement mark-to-market gain or loss for each period is excluded from adjusted diluted earnings per share. The three and six months ended March 31, 2017 includes mark-to-market gains for pension plans of $18 million and $135 million, respectively, due to lump sum payouts for certain U.S. pension plans. There was no mark-to-market gain or loss for pension and postretirement plans in the three or six months ended March 31, 2016.

[0000833444-17-000013:8k_2_02:131]
6.  Acquisitions and Divestitures

[0000833444-17-000013:8k_2_02:132]
On March 16, 2017, the Company announced that it signed a definitive agreement to sell its Scott Safety business to 3M for approximately $2.0 billion. Net cash proceeds from the transaction are expected to approximate $1.8 to $1.9 billion. Scott Safety is a leader in the design, manufacture and sale of high performance respiratory protection, gas and flame detection, thermal imaging and other critical products for fire services, law enforcement, industrial, oil and gas, chemical, armed forces, and homeland defense end markets. The transaction is expected to close in the second half of calendar 2017, subject to customary closing conditions including required regulatory approval. The Scott Safety business is included within assets held for sale and liabilities held for sale in the accompanying condensed consolidated statement of financial position as of March 31, 2017.

[0000833444-17-000013:8k_2_02:133]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience business from JCI plc to Adient plc and the issuance of ordinary shares of Adient plc directly to holders of JCI plc ordinary shares on a pro rata basis.  Following the separation, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc.  Beginning in the first quarter of fiscal 2017, Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation.

[0000833444-17-000013:8k_2_02:134]
On September 2, 2016, JCI Inc. and Tyco completed their combination which was announced on January 25, 2016.  The merger is accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification (ASC) 805, "Business Combinations."  JCI Inc. is the accounting acquirer for financial reporting purposes.  Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historical financial statements of the Company.  The total fair value of the consideration transferred was $19.7 billion.  As part of the transaction in the fiscal 2016 fourth quarter, the Company recorded $16.4 billion of goodwill and $6.2 billion of intangible assets, of which $3.9 billion are subject to amortization.

[0000833444-17-000013:8k_2_02:135]
On October 1, 2015, the Company formed a joint venture with Hitachi to expand its legacy Building Efficiency product offerings.  The Company acquired a 60 percent ownership stake in the new entity for approximately $133 million ($563 million purchase price less cash acquired of $430 million).

[0000833444-17-000013:8k_2_02:136]
7. Income Taxes

[0000833444-17-000013:8k_2_02:137]
The Company's effective tax rate from continuing operations before consideration of the transaction/integration/separation costs, nonrecurring purchase accounting impacts related to the Tyco merger, mark-to-market gains for pension plans, restructuring and impairment costs, and discrete tax items for the three months ending March 31, 2017 and 2016 is approximately 15 percent and 18 percent, respectively. The three months ended March 31, 2017 includes a non-cash tax charge of $457 million ($0.48) in continuing operations related to establishment of a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries of the Scott Safety business. The three months ended March 31, 2016 includes a non-cash tax charge of $780 million ($1.20) in discontinued operations related to the Company's change in assertion over permanently reinvested earnings as a result of the spin-off of the Automotive Experience business and a tax benefit of $15 million ($0.02) in continuing operations related to the first quarter impact of the reduction in the Company's annual effective tax rate.

[0000833444-17-000013:8k_2_02:138]
8. Restructuring

[0000833444-17-000013:8k_2_02:139]
The three and six months ended March 31, 2017 includes restructuring and impairment costs of $99 million and $177 million, respectively, related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions business and at Corporate.  The three and six months ended March 31, 2016 restructuring and impairment costs of $60 million related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions business and at Corporate.

[0000833444-17-000013:8k_2_02:140]
Page 16 of 16
