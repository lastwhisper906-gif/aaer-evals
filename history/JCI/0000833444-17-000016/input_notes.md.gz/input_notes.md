# JCI notes — 0000833444-17-000016


## jci:AdientassetsandliabilitiesheldforsaleTableTextBlock

[0000833444-17-000016:notes:1]
[same as prior period, unchanged from 0000833444-17-000007:notes:1]

[0000833444-17-000016:notes:2]
[same as prior period, unchanged from 0000833444-17-000007:notes:2]


## jci:AdientdiscontinuedoperationscashflowTableTextBlock

[0000833444-17-000016:notes:3]
The following table summarizes depreciation and amortization, capital expenditures, and significant operating and investing noncash items related to Adient for the six month period ended March 31, 2017, and the three and six month periods ended March 31, 2016 (in millions):

[0000833444-17-000016:notes:4]
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2016 |  | 2017 |  | 2016 |
| Depreciation and amortization | $ | 85 |  |  | $ | 29 |  |  | $ | 171 |  |
| Equity in earnings of partially-owned affiliates | (77 | ) |  | (31 | ) |  | (171 | ) |
| Deferred income taxes | 769 |  |  | 562 |  |  | 765 |  |
| Non-cash restructuring and impairment charges | 14 |  |  | — |  |  | 14 |  |
| Equity-based compensation | 4 |  |  | 1 |  |  | 7 |  |
| Accrued income taxes | — |  |  | (808 | ) |  | — |  |
| Capital expenditures | (75 | ) |  | (91 | ) |  | (175 | ) |


## jci:AssetsandLiabilitiesHeldforSaleSpecificTransactionsTableTextBlock

[0000833444-17-000016:notes:5]
The following table summarizes the carrying value of the Tyco segment assets and liabilities held for sale at March 31, 2017 and September 30, 2016 (in millions):

[0000833444-17-000016:notes:6]
|  | March 31, 2017 |  | September 30, 2016 |
| Accounts receivable - net | $ | 93 |  |  | $ | 9 |  |
| Inventories | 66 |  |  | 7 |  |
| Other current assets | 10 |  |  | 3 |  |
| Property, plant and equipment - net | 74 |  |  | 15 |  |
| Goodwill | 1,261 |  |  | 89 |  |
| Other intangible assets - net | 533 |  |  | 30 |  |
| Other noncurrent assets | — |  |  | 4 |  |
| Assets held for sale | $ | 2,037 |  |  | $ | 157 |  |
| Accounts payable | $ | 33 |  |  | $ | 9 |  |
| Accrued compensation and benefits | 9 |  |  | — |  |
| Other current liabilities | 22 |  |  | 19 |  |
| Other noncurrent liabilities | 173 |  |  | — |  |
| Liabilities held for sale | $ | 237 |  |  | $ | 28 |  |


## jci:ComponentsOfNetFinancingChargesTableTextBlock

[0000833444-17-000016:notes:7]
The Company's net financing charges line item in the consolidated statements of income for the three and six month periods ended March 31, 2017 and 2016 contained the following components (in millions):

[0000833444-17-000016:notes:8]
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Interest expense, net of capitalized interest costs | $ | 118 |  |  | $ | 65 |  |  | $ | 228 |  |  | $ | 137 |  |
| Banking fees and bond cost amortization | 11 |  |  | 5 |  |  | 41 |  |  | 12 |  |
| Interest income | (5 | ) |  | (2 | ) |  | (12 | ) |  | (4 | ) |
| Net foreign exchange results for financing activities | (8 | ) |  | 3 |  |  | (5 | ) |  | (8 | ) |
| Net financing charges | $ | 116 |  |  | $ | 71 |  |  | $ | 252 |  |  | $ | 137 |  |

[0000833444-17-000016:notes:9]
Net financing charges for the six month period ended March 31, 2017 included $17 million of transaction costs related primarily to the debt exchange offers.


## jci:DiscontinuedOperationsbyDisposalGroupAdientspinoffTableTextBlock

[0000833444-17-000016:notes:10]
The following table summarizes the results of Adient, reclassified as discontinued operations for the six month period ended March 31, 2017, and the three and six month periods ended March 31, 2016 (in millions). As the Adient spin-off occurred on October 31, 2016, there is only one month of Adient results included in the six month period ended March 31, 2017.

[0000833444-17-000016:notes:11]
|  | Three Months Ended March 31, |  | Six Months EndedMarch 31, |
|  | 2016 |  | 2017 |  | 2016 |
| Net sales | $ | 4,298 |  |  | $ | 1,434 |  |  | $ | 8,531 |  |
| Income from discontinued operations before income taxes | 102 |  |  | 1 |  |  | 335 |  |
| Provision for income taxes on discontinued operations | 827 |  |  | 35 |  |  | 873 |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax | 23 |  |  | 9 |  |  | 40 |  |
| Loss from discontinued operations | $ | (748 | ) |  | $ | (43 | ) |  | $ | (578 | ) |


## jci:EquityAttributableToParentAndNoncontrollingInterestsTableTextBlock

[0000833444-17-000016:notes:12]
[same as prior period, unchanged from 0000833444-17-000007:notes:12]

[0000833444-17-000016:notes:13]
|  | Three Months Ended March 31, 2017 |  | Three Months Ended March 31, 2016 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, December 31 | $ | 19,577 |  |  | $ | 819 |  |  | $ | 20,396 |  |  | $ | 10,506 |  |  | $ | 931 |  |  | $ | 11,437 |  |
| Total comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | (148 | ) |  | 25 |  |  | (123 | ) |  | (530 | ) |  | 50 |  |  | (480 | ) |
| Foreign currency translation adjustments | 241 |  |  | 10 |  |  | 251 |  |  | 175 |  |  | 18 |  |  | 193 |  |
| Realized and unrealized gains (losses) on derivatives | (6 | ) |  | (2 | ) |  | (8 | ) |  | 4 |  |  | 1 |  |  | 5 |  |
| Realized and unrealized gains on marketable securities | 11 |  |  | — |  |  | 11 |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income | 246 |  |  | 8 |  |  | 254 |  |  | 179 |  |  | 19 |  |  | 198 |  |
| Comprehensive income (loss) | 98 |  |  | 33 |  |  | 131 |  |  | (351 | ) |  | 69 |  |  | (282 | ) |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (235 | ) |  | — |  |  | (235 | ) |  | (189 | ) |  | — |  |  | (189 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (47 | ) |  | (47 | ) |  | — |  |  | (29 | ) |  | (29 | ) |
| Repurchases of ordinary shares | (119 | ) |  | — |  |  | (119 | ) |  | — |  |  | — |  |  | — |  |
| Change in noncontrolling interest share | — |  |  | 8 |  |  | 8 |  |  | — |  |  | (73 | ) |  | (73 | ) |
| Spin-off of Adient | (18 | ) |  | — |  |  | (18 | ) |  | — |  |  | — |  |  | — |  |
| Other, including options exercised | 85 |  |  | — |  |  | 85 |  |  | 18 |  |  | — |  |  | 18 |  |
| Ending balance, March 31 | $ | 19,388 |  |  | $ | 813 |  |  | $ | 20,201 |  |  | $ | 9,984 |  |  | $ | 898 |  |  | $ | 10,882 |  |

[0000833444-17-000016:notes:14]
|  | Six Months Ended March 31, 2017 |  | Six Months Ended March 31, 2016 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, September 30 | $ | 24,118 |  |  | $ | 972 |  |  | $ | 25,090 |  |  | $ | 10,376 |  |  | $ | 163 |  |  | $ | 10,539 |  |
| Total comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | 181 |  |  | 61 |  |  | 242 |  |  | (80 | ) |  | 70 |  |  | (10 | ) |
| Foreign currency translation adjustments | (418 | ) |  | (25 | ) |  | (443 | ) |  | 15 |  |  | 9 |  |  | 24 |  |
| Realized and unrealized gains (losses) on derivatives | (6 | ) |  | 2 |  |  | (4 | ) |  | 3 |  |  | 1 |  |  | 4 |  |
| Realized and unrealized gains on marketable securities | 9 |  |  | — |  |  | 9 |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | (415 | ) |  | (23 | ) |  | (438 | ) |  | 18 |  |  | 10 |  |  | 28 |  |
| Comprehensive income (loss) | (234 | ) |  | 38 |  |  | (196 | ) |  | (62 | ) |  | 80 |  |  | 18 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (471 | ) |  | — |  |  | (471 | ) |  | (377 | ) |  | — |  |  | (377 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (47 | ) |  | (47 | ) |  | — |  |  | (36 | ) |  | (36 | ) |
| Repurchases of ordinary shares | (119 | ) |  | — |  |  | (119 | ) |  | — |  |  | — |  |  | — |  |
| Change in noncontrolling interest share | — |  |  | (12 | ) |  | (12 | ) |  | — |  |  | 691 |  |  | 691 |  |
| Spin-off of Adient | (4,038 | ) |  | (138 | ) |  | (4,176 | ) |  | — |  |  | — |  |  | — |  |
| Other, including options exercised | 132 |  |  | — |  |  | 132 |  |  | 47 |  |  | — |  |  | 47 |  |
| Ending balance, March 31 | $ | 19,388 |  |  | $ | 813 |  |  | $ | 20,201 |  |  | $ | 9,984 |  |  | $ | 898 |  |  | $ | 10,882 |  |


## jci:OffsettingDerivativeAssetsandLiabilitiesTableTextBlock

[0000833444-17-000016:notes:15]
[same as prior period, unchanged from 0000833444-17-000007:notes:14]

[0000833444-17-000016:notes:16]
|  | Fair Value of Assets |  | Fair Value of Liabilities |
|  | March 31, |  | September 30, |  | March 31, |  | September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Gross amount recognized | $ | 32 |  |  | $ | 95 |  |  | $ | 1,608 |  |  | $ | 2,980 |  |
| Gross amount eligible for offsetting | (16 | ) |  | (21 | ) |  | (16 | ) |  | (21 | ) |
| Net amount | $ | 16 |  |  | $ | 74 |  |  | $ | 1,592 |  |  | $ | 2,959 |  |


## jci:ScheduleOfIntangibleAssetsTableTextBlock

[0000833444-17-000016:notes:17]
[same as prior period, unchanged from 0000833444-17-000007:notes:16]

[0000833444-17-000016:notes:18]
|  | March 31, 2017 |  | September 30, 2016 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Amortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,170 |  |  | $ | (94 | ) |  | $ | 1,076 |  |  | $ | 1,528 |  |  | $ | (24 | ) |  | $ | 1,504 |  |
| Customer relationships | 3,097 |  |  | (339 | ) |  | 2,758 |  |  | 3,168 |  |  | (226 | ) |  | 2,942 |  |
| Miscellaneous | 544 |  |  | (228 | ) |  | 316 |  |  | 519 |  |  | (130 | ) |  | 389 |  |
| Total amortized intangible assets | 4,811 |  |  | (661 | ) |  | 4,150 |  |  | 5,215 |  |  | (380 | ) |  | 4,835 |  |
| Unamortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,410 |  |  | — |  |  | 2,410 |  |  | 2,555 |  |  | — |  |  | 2,555 |  |
| Miscellaneous | 127 |  |  | — |  |  | 127 |  |  | 150 |  |  | — |  |  | 150 |  |
| Total intangible assets | $ | 7,348 |  |  | $ | (661 | ) |  | $ | 6,687 |  |  | $ | 7,920 |  |  | $ | (380 | ) |  | $ | 7,540 |  |


## jci:ScheduleofFairValueofConsiderationTransferredTableTextBlock

[0000833444-17-000016:notes:19]
[same as prior period, unchanged from 0000833444-17-000007:notes:18]

[0000833444-17-000016:notes:20]
[same as prior period, unchanged from 0000833444-17-000007:notes:19]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-17-000016:notes:21]
Commitments and Contingencies

[0000833444-17-000016:notes:22]
Environmental Matters

[0000833444-17-000016:notes:23]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of March 31, 2017, reserves for environmental liabilities totaled $46 million, of which $9 million was recorded within other current liabilities and $37 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at  September 30, 2016. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At March 31, 2017 and September 30, 2016, the Company recorded conditional asset retirement obligations of $72 million and $74 million, respectively.

[0000833444-17-000016:notes:24]
Asbestos Matters

[0000833444-17-000016:notes:25]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-17-000016:notes:26]
As of March 31, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position is $152 million. The net liability within the consolidated statements of financial position is comprised of a liability for pending and future claims and related defense costs of $540 million, of which $35 million is recorded in other current liabilities and $505 million is recorded in other noncurrent liabilities. The Company also maintains separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $388 million, of which $57 million is recorded in other current assets, and $331 million is recorded in other noncurrent assets. Assets include $33 million of cash and $258 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at March 31, 2017 is $97 million. As of September 30, 2016, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position is $148 million. The net liability within the consolidated statements of financial position is comprised of a liability for pending and future claims and related defense costs of $548 million, of which $35 million is recorded in other current liabilities and $513 million is recorded in other noncurrent liabilities. The Company also maintains separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $400 million, of which $41 million is recorded in other current assets, and $359 million is recorded in other noncurrent assets. Assets include $16 million of cash and $264 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2016 is $120 million. The Company believes that the asbestos related liabilities and insurance related receivables recorded as of March 31, 2017 and September 30, 2016 are appropriate.

[0000833444-17-000016:notes:27]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2069 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2069. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-17-000016:notes:28]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-17-000016:notes:29]
Insurable Liabilities

[0000833444-17-000016:notes:30]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At March 31, 2017 and September 30, 2016, the insurable liabilities for continuing operations totaled $468 million and $422 million, respectively, of which $86 million and $60 million was recorded within other current liabilities, $32 million and $28 million was recorded within accrued compensation and benefits, and $350 million and $334 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at March 31, 2017 was $48 million, of which $30 million was recorded within other current assets and $18 million was recorded within other noncurrent assets. Insurance receivables recorded at September 30, 2016 were $21 million, primarily recorded within other noncurrent assets. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

[0000833444-17-000016:notes:31]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-17-000016:notes:32]
[same as prior period, unchanged from 0000833444-17-000007:notes:31]

[0000833444-17-000016:notes:33]
[same as prior period, unchanged from 0000833444-17-000007:notes:32]

[0000833444-17-000016:notes:34]
The TIFSA public debt securities were assumed as part of the Tyco acquisition. Therefore, no consolidating financial information for the period ended March 31, 2016 is presented related to the guarantee of the TIFSA public debt securities. Additional information regarding TIFSA and TIFSCA for the period ended March 25, 2016 can be found in Tyco's Quarterly report on Form 10-Q filed with the SEC on April 29, 2016.

[0000833444-17-000016:notes:35]
[same as prior period, unchanged from 0000833444-17-000007:notes:34]

[0000833444-17-000016:notes:36]
For the Three Months Ended March 31, 2017

[0000833444-17-000016:notes:37]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 7,267 |  |  | $ | — |  |  | $ | 7,267 |  |
| Cost of sales | — |  |  | — |  |  |  |  |  | 4,986 |  |  | — |  |  | 4,986 |  |
| Gross profit | — |  |  | — |  |  | — |  |  | 2,281 |  |  | — |  |  | 2,281 |  |
| Selling, general and administrative expenses | (4 | ) |  | — |  |  | (1 | ) |  | (1,721 | ) |  | — |  |  | (1,726 | ) |
| Restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (99 | ) |  | — |  |  | (99 | ) |
| Net financing charges | (59 | ) |  | — |  |  | 5 |  |  | (62 | ) |  | — |  |  | (116 | ) |
| Equity income (loss) | (103 | ) |  | (201 | ) |  | (405 | ) |  | 53 |  |  | 709 |  |  | 53 |  |
| Intercompany interest and fees | 18 |  |  | 73 |  |  | 20 |  |  | (111 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes | (148 | ) |  | (128 | ) |  | (381 | ) |  | 341 |  |  | 709 |  |  | 393 |  |
| Income tax provision | — |  |  | — |  |  | — |  |  | 508 |  |  | — |  |  | 508 |  |
| Net loss | (148 | ) |  | (128 | ) |  | (381 | ) |  | (167 | ) |  | 709 |  |  | (115 | ) |
| Income from continuing operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 33 |  |  | — |  |  | 33 |  |
| Net loss attributable to Johnson Controls | $ | (148 | ) |  | $ | (128 | ) |  | $ | (381 | ) |  | $ | (200 | ) |  | $ | 709 |  |  | $ | (148 | ) |

[0000833444-17-000016:notes:38]
[same as prior period, unchanged from 0000833444-17-000007:notes:37]

[0000833444-17-000016:notes:39]
| (in millions) | Johnson ControlsInternationalplc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net income (loss) | $ | (148 | ) |  | $ | (128 | ) |  | $ | (381 | ) |  | $ | (167 | ) |  | $ | 709 |  |  | $ | (115 | ) |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments | 241 |  |  | (7 | ) |  | (1 | ) |  | 260 |  |  | (241 | ) |  | 252 |  |
| Realized and unrealized losses on derivatives | (6 | ) |  | — |  |  | — |  |  | (8 | ) |  | 6 |  |  | (8 | ) |
| Realized and unrealized gains on marketable securities | 11 |  |  | — |  |  | 7 |  |  | 4 |  |  | (11 | ) |  | 11 |  |
| Other comprehensive income (loss) | 246 |  |  | (7 | ) |  | 6 |  |  | 256 |  |  | (246 | ) |  | 255 |  |
| Total comprehensive income (loss) | 98 |  |  | (135 | ) |  | (375 | ) |  | 89 |  |  | 463 |  |  | 140 |  |
| Comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 42 |  |  | — |  |  | 42 |  |
| Comprehensive income (loss) attributable to Johnson Controls | $ | 98 |  |  | $ | (135 | ) |  | $ | (375 | ) |  | $ | 47 |  |  | $ | 463 |  |  | $ | 98 |  |

[0000833444-17-000016:notes:40]
For the Six Months Ended March 31, 2017

[0000833444-17-000016:notes:41]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 14,353 |  |  | $ | — |  |  | $ | 14,353 |  |
| Cost of sales | — |  |  | — |  |  | — |  |  | 9,958 |  |  | — |  |  | 9,958 |  |
| Gross profit | — |  |  | — |  |  | — |  |  | 4,395 |  |  | — |  |  | 4,395 |  |
| Selling, general and administrative expenses | (6 | ) |  | — |  |  | — |  |  | (3,290 | ) |  | — |  |  | (3,296 | ) |
| Restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (177 | ) |  | — |  |  | (177 | ) |
| Net financing charges | (78 | ) |  | — |  |  | (14 | ) |  | (160 | ) |  | — |  |  | (252 | ) |
| Equity income (loss) | 215 |  |  | (500 | ) |  | (501 | ) |  | 108 |  |  | 786 |  |  | 108 |  |
| Intercompany interest and fees | 50 |  |  | 73 |  |  | 37 |  |  | (160 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes | 181 |  |  | (427 | ) |  | (478 | ) |  | 716 |  |  | 786 |  |  | 778 |  |
| Income tax provision | — |  |  | — |  |  | — |  |  | 481 |  |  | — |  |  | 481 |  |
| Income (loss) from continuing operations | 181 |  |  | (427 | ) |  | (478 | ) |  | 235 |  |  | 786 |  |  | 297 |  |
| Income (loss) from sale of intercompany investment, net of tax | — |  |  | — |  |  | (935 | ) |  | — |  |  | 935 |  |  | — |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | — |  |  | (34 | ) |  | — |  |  | (34 | ) |
| Net income (loss) | 181 |  |  | (427 | ) |  | (1,413 | ) |  | 201 |  |  | 1,721 |  |  | 263 |  |
| Income from continuing operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 73 |  |  | — |  |  | 73 |  |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Net income (loss) attributable to Johnson Controls | $ | 181 |  |  | $ | (427 | ) |  | $ | (1,413 | ) |  | $ | 119 |  |  | $ | 1,721 |  |  | $ | 181 |  |

[0000833444-17-000016:notes:42]
| (in millions) | Johnson ControlsInternationalplc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net income (loss) | $ | 181 |  |  | $ | (427 | ) |  | $ | (1,413 | ) |  | $ | 201 |  |  | $ | 1,721 |  |  | $ | 263 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments | (418 | ) |  | (7 | ) |  | 26 |  |  | (470 | ) |  | 418 |  |  | (451 | ) |
| Realized and unrealized losses on derivatives | (6 | ) |  | — |  |  | — |  |  | (4 | ) |  | 6 |  |  | (4 | ) |
| Realized and unrealized gains on marketable securities | 9 |  |  | — |  |  | 7 |  |  | 2 |  |  | (9 | ) |  | 9 |  |
| Other comprehensive income (loss) | (415 | ) |  | (7 | ) |  | 33 |  |  | (472 | ) |  | 415 |  |  | (446 | ) |
| Total comprehensive loss | (234 | ) |  | (434 | ) |  | (1,380 | ) |  | (271 | ) |  | 2,136 |  |  | (183 | ) |
| Comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 51 |  |  | — |  |  | 51 |  |
| Comprehensive loss attributable to Johnson Controls | $ | (234 | ) |  | $ | (434 | ) |  | $ | (1,380 | ) |  | $ | (322 | ) |  | $ | 2,136 |  |  | $ | (234 | ) |

[0000833444-17-000016:notes:43]
[same as prior period, unchanged from 0000833444-17-000007:notes:39]

[0000833444-17-000016:notes:44]
As of March 31, 2017

[0000833444-17-000016:notes:45]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 3 |  |  | $ | — |  |  | $ | 288 |  |  | $ | 482 |  |  | $ | (361 | ) |  | $ | 412 |  |
| Accounts receivable - net | — |  |  | — |  |  | — |  |  | 6,094 |  |  | — |  |  | 6,094 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 3,138 |  |  | — |  |  | 3,138 |  |
| Intercompany receivables | 1,803 |  |  | 2,039 |  |  | 382 |  |  | 4,576 |  |  | (8,800 | ) |  | — |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 2,037 |  |  | — |  |  | 2,037 |  |
| Other current assets | 14 |  |  | — |  |  | 1 |  |  | 1,533 |  |  | — |  |  | 1,548 |  |
| Current assets | $ | 1,820 |  |  | $ | 2,039 |  |  | $ | 671 |  |  | $ | 17,860 |  |  | $ | (9,161 | ) |  | $ | 13,229 |  |
| Property, plant and equipment - net | — |  |  | — |  |  | — |  |  | 5,601 |  |  | — |  |  | 5,601 |  |
| Goodwill | 243 |  |  | — |  |  | 32 |  |  | 19,369 |  |  | — |  |  | 19,644 |  |
| Other intangible assets - net | — |  |  | — |  |  | — |  |  | 6,687 |  |  | — |  |  | 6,687 |  |
| Investments in partially-owned affiliates | — |  |  | — |  |  | — |  |  | 1,099 |  |  | — |  |  | 1,099 |  |
| Investments in affiliates | 17,112 |  |  | 28,629 |  |  | 22,254 |  |  | — |  |  | (67,995 | ) |  | — |  |
| Intercompany loans receivable | 18,205 |  |  | 4,140 |  |  | 2,836 |  |  | 8,398 |  |  | (33,579 | ) |  | — |  |
| Other noncurrent assets | — |  |  | — |  |  | 18 |  |  | 3,329 |  |  | — |  |  | 3,347 |  |
| Total assets | $ | 37,380 |  |  | $ | 34,808 |  |  | $ | 25,811 |  |  | $ | 62,343 |  |  | $ | (110,735 | ) |  | $ | 49,607 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | 885 |  |  | $ | 76 |  |  | $ | — |  |  | $ | 524 |  |  | $ | (361 | ) |  | $ | 1,124 |  |
| Current portion of long-term debt | 444 |  |  | — |  |  | 18 |  |  | 80 |  |  | — |  |  | 542 |  |
| Accounts payable | 1 |  |  | — |  |  | — |  |  | 3,719 |  |  | — |  |  | 3,720 |  |
| Accrued compensation and benefits | — |  |  | — |  |  | — |  |  | 1,082 |  |  | — |  |  | 1,082 |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 237 |  |  | — |  |  | 237 |  |
| Intercompany payables | 2,588 |  |  | 1,007 |  |  | 4,343 |  |  | 862 |  |  | (8,800 | ) |  | — |  |
| Other current liabilities | 292 |  |  | 2 |  |  | 23 |  |  | 3,720 |  |  | — |  |  | 4,037 |  |
| Current liabilities | 4,210 |  |  | 1,085 |  |  | 4,384 |  |  | 10,224 |  |  | (9,161 | ) |  | 10,742 |  |
| Long-term debt | 7,347 |  |  | — |  |  | 149 |  |  | 4,314 |  |  | — |  |  | 11,810 |  |
| Pension and postretirement benefits | — |  |  | — |  |  | — |  |  | 1,048 |  |  | — |  |  | 1,048 |  |
| Intercompany loans payable | 6,435 |  |  | 18,205 |  |  | 1,964 |  |  | 6,975 |  |  | (33,579 | ) |  | — |  |
| Other noncurrent liabilities | — |  |  | — |  |  | 24 |  |  | 5,614 |  |  | — |  |  | 5,638 |  |
| Long-term liabilities | 13,782 |  |  | 18,205 |  |  | 2,137 |  |  | 17,951 |  |  | (33,579 | ) |  | 18,496 |  |
| Redeemable noncontrolling interests | — |  |  | — |  |  | — |  |  | 168 |  |  | — |  |  | 168 |  |
| Ordinary shares | 9 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Ordinary shares held in treasury | (172 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (172 | ) |
| Other shareholders' equity | 19,551 |  |  | 15,518 |  |  | 19,290 |  |  | 33,187 |  |  | (67,995 | ) |  | 19,551 |  |
| Shareholders’ equity attributable to Johnson Controls | 19,388 |  |  | 15,518 |  |  | 19,290 |  |  | 33,187 |  |  | (67,995 | ) |  | 19,388 |  |
| Noncontrolling interests | — |  |  | — |  |  | — |  |  | 813 |  |  | — |  |  | 813 |  |
| Total equity | 19,388 |  |  | 15,518 |  |  | 19,290 |  |  | 34,000 |  |  | (67,995 | ) |  | 20,201 |  |
| Total liabilities and equity | $ | 37,380 |  |  | $ | 34,808 |  |  | $ | 25,811 |  |  | $ | 62,343 |  |  | $ | (110,735 | ) |  | $ | 49,607 |  |

[0000833444-17-000016:notes:46]
[same as prior period, unchanged from 0000833444-17-000007:notes:41]

[0000833444-17-000016:notes:47]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Operating Activities |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided (used) by operating activities | $ | 80 |  |  | $ | — |  |  | $ | 67 |  |  | $ | (1,683 | ) |  | $ | — |  |  | $ | (1,536 | ) |
| Investing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (634 | ) |  | — |  |  | (634 | ) |
| Sale of property, plant and equipment | — |  |  | — |  |  | — |  |  | 18 |  |  | — |  |  | 18 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (6 | ) |  | — |  |  | — |  |  | (6 | ) |
| Business divestitures | — |  |  | — |  |  | — |  |  | 180 |  |  | — |  |  | 180 |  |
| Changes in long-term investments | — |  |  | — |  |  | (11 | ) |  | (19 | ) |  | — |  |  | (30 | ) |
| Net change in intercompany loans receivable | — |  |  | — |  |  | 10 |  |  | 165 |  |  | (175 | ) |  | — |  |
| Increase in intercompany investment in subsidiaries | (1,924 | ) |  | (1,716 | ) |  | (76 | ) |  | — |  |  | 3,716 |  |  | — |  |
| Net cash used by investing activities | (1,924 | ) |  | (1,716 | ) |  | (83 | ) |  | (290 | ) |  | 3,541 |  |  | (472 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Increase (decrease) in short-term debt - net | 885 |  |  | 76 |  |  | — |  |  | (545 | ) |  | (361 | ) |  | 55 |  |
| Increase in long-term debt | 1,544 |  |  | — |  |  | — |  |  | 8 |  |  | — |  |  | 1,552 |  |
| Repayment of long-term debt | (46 | ) |  | — |  |  | (16 | ) |  | (769 | ) |  | — |  |  | (831 | ) |
| Debt financing costs | (17 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (17 | ) |
| Stock repurchases | (119 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (119 | ) |
| Payment of cash dividends | (235 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (235 | ) |
| Proceeds from the exercise of stock options | 88 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 88 |  |
| Net change in intercompany loans payable | (165 | ) |  | — |  |  | — |  |  | (10 | ) |  | 175 |  |  | — |  |
| Increase in equity from parent | — |  |  | 1,640 |  |  | 76 |  |  | 2,000 |  |  | (3,716 | ) |  | — |  |
| Dividends paid to noncontrolling interests | — |  |  | — |  |  | — |  |  | (78 | ) |  | — |  |  | (78 | ) |
| Dividend from Adient spin-off | — |  |  | — |  |  | — |  |  | 2,050 |  |  | — |  |  | 2,050 |  |
| Cash transferred to Adient related to spin-off | (87 | ) |  | — |  |  | — |  |  | (578 | ) |  | — |  |  | (665 | ) |
| Cash paid related to prior acquisitions | — |  |  | — |  |  | — |  |  | (37 | ) |  | — |  |  | (37 | ) |
| Other | (12 | ) |  | — |  |  | — |  |  | 10 |  |  | — |  |  | (2 | ) |
| Net cash provided by financing activities | 1,836 |  |  | 1,716 |  |  | 60 |  |  | 2,051 |  |  | (3,902 | ) |  | 1,761 |  |
| Effect of exchange rate changes on cash and cash equivalents | — |  |  | — |  |  | — |  |  | (25 | ) |  | — |  |  | (25 | ) |
| Changes in cash held for sale | — |  |  | — |  |  | — |  |  | 105 |  |  | — |  |  | 105 |  |
| Increase (decrease) in cash and cash equivalents | (8 | ) |  | — |  |  | 44 |  |  | 158 |  |  | (361 | ) |  | (167 | ) |
| Cash and cash equivalents at beginning of period | 11 |  |  | — |  |  | 244 |  |  | 324 |  |  | — |  |  | 579 |  |
| Cash and cash equivalents at end of period | $ | 3 |  |  | $ | — |  |  | $ | 288 |  |  | $ | 482 |  |  | $ | (361 | ) |  | $ | 412 |  |

[0000833444-17-000016:notes:48]
As of September 30, 2016

[0000833444-17-000016:notes:49]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 11 |  |  | $ | — |  |  | $ | 244 |  |  | $ | 324 |  |  | $ | — |  |  | $ | 579 |  |
| Accounts receivable - net | — |  |  | — |  |  | — |  |  | 6,394 |  |  | — |  |  | 6,394 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 2,888 |  |  | — |  |  | 2,888 |  |
| Intercompany receivables | 16 |  |  | — |  |  | 2 |  |  | 6,188 |  |  | (6,206 | ) |  | — |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 5,812 |  |  | — |  |  | 5,812 |  |
| Other current assets | 6 |  |  | — |  |  | 1 |  |  | 1,429 |  |  | — |  |  | 1,436 |  |
| Current assets | $ | 33 |  |  | $ | — |  |  | $ | 247 |  |  | $ | 23,035 |  |  | $ | (6,206 | ) |  | $ | 17,109 |  |
| Property, plant and equipment - net | — |  |  | — |  |  | — |  |  | 5,632 |  |  | — |  |  | 5,632 |  |
| Goodwill | — |  |  | — |  |  | 274 |  |  | 20,750 |  |  | — |  |  | 21,024 |  |
| Other intangible assets - net | — |  |  | — |  |  | — |  |  | 7,540 |  |  | — |  |  | 7,540 |  |
| Investments in partially-owned affiliates | — |  |  | — |  |  | — |  |  | 990 |  |  | — |  |  | 990 |  |
| Investments in affiliates | 12,460 |  |  | 31,142 |  |  | 27,643 |  |  | — |  |  | (71,245 | ) |  | — |  |
| Intercompany loans receivable | 18,680 |  |  | — |  |  | 13,336 |  |  | 15,631 |  |  | (47,647 | ) |  | — |  |
| Noncurrent assets held for sale | — |  |  | — |  |  | — |  |  | 7,374 |  |  | — |  |  | 7,374 |  |
| Other noncurrent assets | — |  |  | — |  |  | — |  |  | 3,510 |  |  | — |  |  | 3,510 |  |
| Total assets | $ | 31,173 |  |  | $ | 31,142 |  |  | $ | 41,500 |  |  | $ | 84,462 |  |  | $ | (125,098 | ) |  | $ | 63,179 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,078 |  |  | $ | — |  |  | $ | 1,078 |  |
| Current portion of long-term debt | — |  |  | — |  |  | — |  |  | 628 |  |  | — |  |  | 628 |  |
| Accounts payable | 1 |  |  | — |  |  | — |  |  | 3,999 |  |  | — |  |  | 4,000 |  |
| Accrued compensation and benefits | — |  |  | — |  |  | — |  |  | 1,333 |  |  | — |  |  | 1,333 |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 4,276 |  |  | — |  |  | 4,276 |  |
| Intercompany payables | 3,873 |  |  | — |  |  | 2,315 |  |  | 18 |  |  | (6,206 | ) |  | — |  |
| Other current liabilities | 3 |  |  | 2 |  |  | 32 |  |  | 4,979 |  |  | — |  |  | 5,016 |  |
| Current liabilities | 3,877 |  |  | 2 |  |  | 2,347 |  |  | 16,311 |  |  | (6,206 | ) |  | 16,331 |  |
| Long-term debt | — |  |  | — |  |  | 2,413 |  |  | 8,640 |  |  | — |  |  | 11,053 |  |
| Pension and postretirement benefits | — |  |  | — |  |  | — |  |  | 1,550 |  |  | — |  |  | 1,550 |  |
| Intercompany loans payable | 3,178 |  |  | 18,680 |  |  | 12,453 |  |  | 13,336 |  |  | (47,647 | ) |  | — |  |
| Noncurrent liabilities held for sale | — |  |  | — |  |  | — |  |  | 3,888 |  |  | — |  |  | 3,888 |  |
| Other noncurrent liabilities | — |  |  | — |  |  | 22 |  |  | 5,011 |  |  | — |  |  | 5,033 |  |
| Long-term liabilities | 3,178 |  |  | 18,680 |  |  | 14,888 |  |  | 32,425 |  |  | (47,647 | ) |  | 21,524 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 234 |  |  | — |  |  | 234 |  |
| Ordinary shares | 9 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Ordinary shares held in treasury | (20 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (20 | ) |
| Other shareholders' equity | 24,129 |  |  | 12,460 |  |  | 24,265 |  |  | 34,520 |  |  | (71,245 | ) |  | 24,129 |  |
| Shareholders’ equity attributable to Johnson Controls | 24,118 |  |  | 12,460 |  |  | 24,265 |  |  | 34,520 |  |  | (71,245 | ) |  | 24,118 |  |
| Noncontrolling interests | — |  |  | — |  |  | — |  |  | 972 |  |  | — |  |  | 972 |  |
| Total equity | 24,118 |  |  | 12,460 |  |  | 24,265 |  |  | 35,492 |  |  | (71,245 | ) |  | 25,090 |  |
| Total liabilities and equity | $ | 31,173 |  |  | $ | 31,142 |  |  | $ | 41,500 |  |  | $ | 84,462 |  |  | $ | (125,098 | ) |  | $ | 63,179 |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-17-000016:notes:50]
Debt and Financing Arrangements

[0000833444-17-000016:notes:51]
Debt exchange

[0000833444-17-000016:notes:52]
In connection with the Tyco Merger, on December 28, 2016, the Company completed its offers to exchange all validly tendered and accepted notes of certain series (the "existing notes") issued by JCI Inc. or Tyco International Finance S.A. ("TIFSA"), as applicable, each of which is a wholly owned subsidiary of the Company, for new notes (the New Notes) to be issued by the Company, and the related solicitation of consents to amend the indentures governing the existing notes (the offers to exchange and the related consent solicitation together the "exchange offers"). Pursuant to the exchange offers, the Company exchanged approximately $5.6 billion of $6.0 billion in aggregate principal amount of dollar denominated notes and approximately 423 million euro of 500 million euro in aggregate principal amount of euro denominated notes. All validly tendered and accepted existing notes have been canceled. Immediately following such cancellation, $380.9 million aggregate principal amount of existing notes (not including the TIFSA Euro Notes) remained outstanding across seventeen series of dollar-denominated existing notes and 77.4 million euro aggregate principal amount of TIFSA Euro Notes remained outstanding across one series. In connection with the settlement of the exchange offers, the New Notes were registered under the Securities Act of 1933 and their terms are described in the Company’s Prospectus dated December 19, 2016, as filed with the SEC under Rule 424(b)(3) of the Act on that date. The issuance of the New Notes occurred on December 28, 2016. The New Notes are unsecured and unsubordinated obligations of the Company and will rank equally with all other unsecured and unsubordinated indebtedness of the Company issued from time to time.

[0000833444-17-000016:notes:53]
Other financing arrangements

[0000833444-17-000016:notes:54]
In March 2017, the Company issued one billion euro in principal amount of 1.0% senior unsecured fixed rate notes due in         fiscal 2023. Proceeds from the issuance were used to repay existing debt and for other general corporate purposes.

[0000833444-17-000016:notes:55]
In March 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in March 2018. As of March 31, 2017, there were no draws on the facility.

[0000833444-17-000016:notes:56]
In March 2017, the Company retired $46 million in principal amount, plus accrued interest, of its 2.355% fixed rate notes that matured in March 2017.

[0000833444-17-000016:notes:57]
In March and February 2017, the Company repurchased, at a discount, 15 million euro of its TIFSA 1.375% fixed rate notes, plus accrued interest, scheduled to mature in February 2025.

[0000833444-17-000016:notes:58]
In February 2017, the Company issued $500 million aggregate principal amount of 4.5% senior unsecured fixed rate notes due in fiscal 2047. Proceeds from the issuance were used to repay outstanding commercial paper borrowings and for other general corporate purposes.

[0000833444-17-000016:notes:59]
In February 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in February 2018. As of March 31, 2017, there were no draws on the facility.

[0000833444-17-000016:notes:60]
In January 2017, the Company entered into a 364-day $250 million committed revolving credit facility scheduled to expire                      in January 2018. As of March 31, 2017, there were no draws on the facility outstanding.

[0000833444-17-000016:notes:61]
In December 2016, the Company retired $400 million in principal amount, plus accrued interest, of its 2.6% fixed rate notes that matured in December 2016.

[0000833444-17-000016:notes:62]
In December 2016, the Company entered into a 364-day 100 million euro floating rate term loan scheduled to mature in December 2017. Proceeds from the term loan were used for general corporate purposes. Principal and accrued interest were fully repaid in March 2017.

[0000833444-17-000016:notes:63]
In December 2016, a $100 million committed revolving credit facility expired. There were no draws on the facility.

[0000833444-17-000016:notes:64]
In November 2016, the Company fully repaid its 37 billion yen syndicated floating rate term loan, plus accrued interest, scheduled to mature in June 2020.

[0000833444-17-000016:notes:65]
In November 2016, a $35 million committed revolving credit facility expired. There were no draws on the facility.

[0000833444-17-000016:notes:66]
In October 2016, the Company repaid two ten-month floating rate term loans totaling $325 million, plus accrued interest, scheduled to mature in October 2016.

[0000833444-17-000016:notes:67]
In October 2016, the Company repaid a nine-month $100 million floating rate term loan, plus accrued interest, scheduled to mature in November 2016.

[0000833444-17-000016:notes:68]
In October 2016, the Company repaid a nine-month 100 million euro floating rate term loan, plus accrued interest, scheduled to mature in October 2016.

[0000833444-17-000016:notes:69]
Net Financing Charges


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-17-000016:notes:70]
[same as prior period, unchanged from 0000833444-17-000007:notes:58]

[0000833444-17-000016:notes:71]
[same as prior period, unchanged from 0000833444-17-000007:notes:59]

[0000833444-17-000016:notes:72]
[same as prior period, unchanged from 0000833444-17-000007:notes:60]

[0000833444-17-000016:notes:73]
The Company has global operations and participates in the foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. As cash flow hedges under ASC 815, "Derivatives and Hedging," the effective portion of the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. Any ineffective portion of the hedge is reflected in the consolidated statements of income. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three and six months ended March 31, 2017 and 2016.

[0000833444-17-000016:notes:74]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of lead, copper, tin and aluminum in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As cash flow hedges, the effective portion of the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions, typically sales, occur and affect earnings. Any ineffective portion of the hedge is reflected in the consolidated statements of income. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in commodity prices during the three and six months ended March 31, 2017 and 2016.

[0000833444-17-000016:notes:75]
[same as prior period, unchanged from 0000833444-17-000007:notes:63]

[0000833444-17-000016:notes:76]
|  |  |  |  | Volume Outstanding as of |
| Commodity |  | Units |  | March 31, 2017 |  | September 30, 2016 |
| Copper |  | Pounds |  | 7,350,000 |  |  | 5,849,000 |  |
| Lead |  | Metric Tons |  | 560 |  |  | 5,185 |  |
| Aluminum |  | Metric Tons |  | 2,349 |  |  | 2,620 |  |
| Tin |  | Metric Tons |  | 740 |  |  | 185 |  |

[0000833444-17-000016:notes:77]
[same as prior period, unchanged from 0000833444-17-000007:notes:65]

[0000833444-17-000016:notes:78]
[same as prior period, unchanged from 0000833444-17-000007:notes:66]

[0000833444-17-000016:notes:79]
The Company selectively uses interest rate swaps to reduce market risk associated with changes in interest rates for its fixed-rate bonds. As fair value hedges, the interest rate swaps and related debt balances are valued under a market approach using publicized swap curves. Changes in the fair value of the swap and hedged portion of the debt are recorded in the consolidated statements of income. In the third quarter of fiscal 2014, the Company entered into four fixed to floating interest rate swaps totaling $400 million to hedge the coupon of its 2.6% notes that matured in December 2016, three fixed to floating interest rate swaps totaling $300 million to hedge the coupon of its 1.4% notes maturing November 2017 and one fixed to floating interest rate swap totaling $150 million to hedge the coupon of its 7.125% notes maturing July 2017.  In December 2016, the four remaining outstanding interest rate swaps were terminated. The Company had no interest rate swaps outstanding at March 31, 2017. There were eight interest rate swaps outstanding as of September 30, 2016.

[0000833444-17-000016:notes:80]
[same as prior period, unchanged from 0000833444-17-000007:notes:68]

[0000833444-17-000016:notes:81]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.  At March 31, 2017, the Company had one billion euro and 485 million euro bonds designated as net investment hedges in the Company's net investment in Europe. At September 30, 2016, the Company had 37 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan and one billion euro and 500 million euro bonds designated as net investment hedges in the Company's net investment in Europe.

[0000833444-17-000016:notes:82]
[same as prior period, unchanged from 0000833444-17-000007:notes:70]

[0000833444-17-000016:notes:83]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount. As of March 31, 2017 and September 30, 2016, the Company had no equity swaps outstanding.

[0000833444-17-000016:notes:84]
[same as prior period, unchanged from 0000833444-17-000007:notes:72]

[0000833444-17-000016:notes:85]
[same as prior period, unchanged from 0000833444-17-000007:notes:73]

[0000833444-17-000016:notes:86]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | March 31, |  | September 30, |  | March 31, |  | September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 20 |  |  | $ | 41 |  |  | $ | 9 |  |  | $ | 49 |  |
| Commodity derivatives | 3 |  |  | 4 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Interest rate swaps | — |  |  | 1 |  |  | — |  |  | — |  |
| Total assets | $ | 23 |  |  | $ | 46 |  |  | $ | 9 |  |  | $ | 49 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 5 |  |  | $ | 48 |  |  | $ | 15 |  |  | $ | 18 |  |
| Liabilities held for sale |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | — |  |  | — |  |  | — |  |  | 5 |  |
| Current portion of long-term debt |  |  |  |  |  |  |  |
| Fixed rate debt swapped to floating | — |  |  | 551 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 1,588 |  |  | 938 |  |  | — |  |  | — |  |
| Fixed rate debt swapped to floating | — |  |  | 301 |  |  | — |  |  | — |  |
| Noncurrent liabilities held for sale |  |  |  |  |  |  |  |
| Foreign currency denominated debt | — |  |  | 1,119 |  |  | — |  |  | — |  |
| Total liabilities | $ | 1,593 |  |  | $ | 2,957 |  |  | $ | 15 |  |  | $ | 23 |  |

[0000833444-17-000016:notes:87]
[same as prior period, unchanged from 0000833444-17-000007:notes:75]

[0000833444-17-000016:notes:88]
[same as prior period, unchanged from 0000833444-17-000007:notes:76]

[0000833444-17-000016:notes:89]
The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position. Collateral is generally not required of the Company or the counterparties under the master netting agreements. As of March 31, 2017, and September 30, 2016, no cash collateral was received or pledged under the master netting agreements.

[0000833444-17-000016:notes:90]
[same as prior period, unchanged from 0000833444-17-000007:notes:78]

[0000833444-17-000016:notes:91]
The following table presents the effective portion of pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the three and six months ended March 31, 2017 and 2016 (in millions):

[0000833444-17-000016:notes:92]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Foreign currency exchange derivatives |  | $ | (2 | ) |  | $ | (4 | ) |  | $ | 6 |  |  | $ | (6 | ) |
| Commodity derivatives |  | 3 |  |  | 1 |  |  | 5 |  |  | (1 | ) |
| Total |  | $ | 1 |  |  | $ | (3 | ) |  | $ | 11 |  |  | $ | (7 | ) |

[0000833444-17-000016:notes:93]
The following tables present the location and amount of the effective portion of pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the three and six months ended March 31, 2017 and 2016 (in millions):

[0000833444-17-000016:notes:94]
| Derivatives in ASC 815 Cash FlowHedging Relationships |  | Location of Gain (Loss) Reclassifiedfrom AOCI into Income |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 8 |  |  | $ | 4 |  |  | $ | 16 |  |  | $ | 9 |  |
| Foreign currency exchange derivatives |  | Loss from discontinued operations |  | — |  |  | (9 | ) |  | — |  |  | (14 | ) |
| Commodity derivatives |  | Cost of sales |  | 3 |  |  | (5 | ) |  | 4 |  |  | (9 | ) |
| Forward treasury locks |  | Net financing charges |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total |  |  |  | $ | 11 |  |  | $ | (9 | ) |  | $ | 20 |  |  | $ | (13 | ) |

[0000833444-17-000016:notes:95]
The following table presents the location and amount of pre-tax gains (losses) on fair value hedges recognized in the Company’s consolidated statements of income for the three and six months ended March 31, 2017 and 2016 (in millions):

[0000833444-17-000016:notes:96]
| Derivatives in ASC 815 Fair ValueHedging Relationships |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Interest rate swap |  | Net financing charges |  | $ | — |  |  | $ | 2 |  |  | $ | (1 | ) |  | $ | (3 | ) |
| Fixed rate debt swapped to floating |  | Net financing charges |  | — |  |  | (2 | ) |  | 2 |  |  | 3 |  |
| Total |  |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |

[0000833444-17-000016:notes:97]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the three and six months ended March 31, 2017 and 2016 (in millions):

[0000833444-17-000016:notes:98]
|  |  |  |  | Amount of Gain (Loss) Recognized in Income on Derivative |
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 2 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | 3 |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 5 |  |  | (7 | ) |  | 9 |  |  | (7 | ) |
| Foreign currency exchange derivatives |  | Income tax provision |  | — |  |  | — |  |  | (3 | ) |  | — |  |
| Foreign currency exchange derivatives |  | Income (loss) from discontinued operations |  | — |  |  | (8 | ) |  | 5 |  |  | (11 | ) |
| Equity swap |  | Selling, general and administrative |  | — |  |  | (2 | ) |  | — |  |  | (8 | ) |
| Total |  |  |  | $ | 7 |  |  | $ | (16 | ) |  | $ | 14 |  |  | $ | (23 | ) |

[0000833444-17-000016:notes:99]
The effective portion of pre-tax gains (losses) recorded in foreign currency translation adjustment ("CTA") within other comprehensive income (loss) related to net investment hedges were $(19) million and $1 million for the for the three months ended March 31, 2017 and 2016, respectively. The effective portion of pre-tax gains (losses) recorded in CTA within other comprehensive income (loss) related to net investment hedges were $28 million and $16 million for the for the six months ended March 31, 2017 and 2016, respectively. For the three and six months ended March 31, 2017 and 2016, no gains or losses were reclassified from CTA into income for the Company’s outstanding net investment hedges, and no gains or losses were recognized in income for the ineffective portion of cash flow hedges.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-17-000016:notes:100]
[same as prior period, unchanged from 0000833444-17-000007:notes:88]

[0000833444-17-000016:notes:101]
References to the Company's stock throughout Note 13 refer to stock of JCI Inc. prior to the Tyco merger date of September 2, 2016 (the "Merger Date") and to ordinary shares of the Company subsequent to the Merger Date.

[0000833444-17-000016:notes:102]
During September 2016, the Board of Directors of the Company approved amendments to the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based compensation awards. The Compensation Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter. A summary of the stock-based awards granted during the six month periods ended March 31, 2017 and 2016 is presented below:

[0000833444-17-000016:notes:103]
|  | Six Months Ended March 31, |
|  | 2017 |  | 2016 |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  | Number Granted |  | Weighted Average Grant Date Fair Value |
| Stock options | 2,830,826 |  |  | $ | 7.81 |  |  | 961,705 |  |  | $ | 13.14 |  |
| Stock appreciation rights | 15,693 |  |  | 8.28 |  |  | 54,749 |  |  | 13.15 |  |
| Restricted stock | 1,582,962 |  |  | 41.74 |  |  | 2,290,575 |  |  | 43.68 |  |
| Performance shares | 846,725 |  |  | 48.40 |  |  | — |  |  | — |  |

[0000833444-17-000016:notes:104]
[same as prior period, unchanged from 0000833444-17-000007:notes:92]

[0000833444-17-000016:notes:105]
[same as prior period, unchanged from 0000833444-17-000007:notes:93]

[0000833444-17-000016:notes:106]
[same as prior period, unchanged from 0000833444-17-000007:notes:94]

[0000833444-17-000016:notes:107]
|  | Six Months Ended March 31, |
|  | 2017 |  | 2016 |
| Expected life of option (years) | 4.75 & 6.5 |  | 6.4 |
| Risk-free interest rate | 1.23% - 1.48% |  | 1.64% |
| Expected volatility of the Company’s stock | 24.60% |  | 36.00% |
| Expected dividend yield on the Company’s stock | 2.21% |  | 2.11% |

[0000833444-17-000016:notes:108]
[same as prior period, unchanged from 0000833444-17-000007:notes:96]

[0000833444-17-000016:notes:109]
[same as prior period, unchanged from 0000833444-17-000007:notes:97]

[0000833444-17-000016:notes:110]
[same as prior period, unchanged from 0000833444-17-000007:notes:98]

[0000833444-17-000016:notes:111]
[same as prior period, unchanged from 0000833444-17-000007:notes:99]

[0000833444-17-000016:notes:112]
[same as prior period, unchanged from 0000833444-17-000007:notes:100]

[0000833444-17-000016:notes:113]
[same as prior period, unchanged from 0000833444-17-000007:notes:101]

[0000833444-17-000016:notes:114]
[same as prior period, unchanged from 0000833444-17-000007:notes:102]

[0000833444-17-000016:notes:115]
|  | Six Months EndedMarch 31, 2017 |
| Risk-free interest rate | 1.40% |
| Expected volatility of the Company’s stock | 21.00% |

[0000833444-17-000016:notes:116]
[same as prior period, unchanged from 0000833444-17-000007:notes:104]

[0000833444-17-000016:notes:117]
[same as prior period, unchanged from 0000833444-17-000007:notes:105]

[0000833444-17-000016:notes:118]
[same as prior period, unchanged from 0000833444-17-000007:notes:106]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-17-000016:notes:119]
[same as prior period, unchanged from 0000833444-17-000007:notes:107]

[0000833444-17-000016:notes:120]
[same as prior period, unchanged from 0000833444-17-000007:notes:108]

[0000833444-17-000016:notes:121]
For the six months ended March 31, 2017, the income from discontinued operations before income taxes included separation costs of $79 million. For the three and six months ended March 31, 2016, the income from discontinued operations before income taxes included separation costs of $90 million and $160 million, respectively.

[0000833444-17-000016:notes:122]
For the six months ended March 31, 2017, the effective tax rate was more than the U.S. federal statutory rate of 35% primarily due to the tax impacts of separation costs and Adient spin-off related tax expense, partially offset by non-U.S. tax rate differentials. For the three and six months ended March 31, 2016, the effective tax rate was more than the U.S. federal statutory rate of 35% primarily due to $780 million of income tax expense recorded on foreign undistributed earnings of certain non-U.S. subsidiaries, the jurisdictional mix of restructuring and impairment costs, and the tax impacts of separation costs, partially offset by non-U.S. tax rate differentials.

[0000833444-17-000016:notes:123]
[same as prior period, unchanged from 0000833444-17-000007:notes:111]

[0000833444-17-000016:notes:124]
During the second quarter of fiscal 2017, the Company completed the divestiture of its ADT security business in South Africa within the Tyco segment. The assets and liabilities of this business were presented as held for sale in the consolidated statements of financial position as of September 30, 2016. The business did not meet the criteria to be classified as a discontinued operation.

[0000833444-17-000016:notes:125]
During the second quarter of fiscal 2017, the Company signed a definitive agreement to sell its Scott Safety business of the Tyco segment to 3M Company. The transaction is expected to close in the second half of calendar 2017, subject to customary closing conditions including required regulatory approval. The assets and liabilities of this business were presented as held for sale in the consolidated statements of financial position as of March 31, 2017. The business did not meet the criteria to be classified as a discontinued operation as the divestiture of the Scott Safety business will not have a major effect on the Company’s operations and financial results.

[0000833444-17-000016:notes:126]
At September 30, 2016, $17 million of certain Corporate assets were classified as held for sale. The assets were sold during the second quarter of fiscal 2017.


## us-gaap:EarningsPerShareTextBlock

[0000833444-17-000016:notes:127]
[same as prior period, unchanged from 0000833444-17-000007:notes:115]

[0000833444-17-000016:notes:128]
[same as prior period, unchanged from 0000833444-17-000007:notes:116]

[0000833444-17-000016:notes:129]
[same as prior period, unchanged from 0000833444-17-000007:notes:117]

[0000833444-17-000016:notes:130]
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Income (loss) Available to Ordinary Shareholders |  |  |  |  |  |  |  |
| Income (loss) from continuing operations | $ | (148 | ) |  | $ | 218 |  |  | $ | 224 |  |  | $ | 498 |  |
| Loss from discontinued operations | — |  |  | (748 | ) |  | (43 | ) |  | (578 | ) |
| Basic and diluted income (loss) available to shareholders | $ | (148 | ) |  | $ | (530 | ) |  | $ | 181 |  |  | $ | (80 | ) |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 939.2 |  |  | 648.2 |  |  | 938.2 |  |  | 648.0 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | — |  |  | 3.9 |  |  | 9.8 |  |  | 4.5 |  |
| Diluted weighted average shares outstanding | 939.2 |  |  | 652.1 |  |  | 948.0 |  |  | 652.5 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Options to purchase shares | — |  |  | 0.4 |  |  | 0.1 |  |  | 0.3 |  |

[0000833444-17-000016:notes:131]
For the three months ended March 31, 2017, the total number of potential dilutive shares due to stock options, unvested restricted stock and unvested performance share awards was 9.4 million. However, these items were not included in the computation of diluted loss per share for the three months ended March 31, 2017 since to do so would decrease the loss per share.

[0000833444-17-000016:notes:132]
During the three months ended March 31, 2017 and 2016, the Company declared a dividend of $0.25 and $0.29, respectively, per share. During the six months ended March 31, 2017 and 2016, the Company declared dividends totaling $0.50 and $0.58, respectively, per share. The Company paid all dividends in the month subsequent to the end of each fiscal quarter.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-17-000016:notes:133]
[same as prior period, unchanged from 0000833444-17-000007:notes:120]

[0000833444-17-000016:notes:134]
[same as prior period, unchanged from 0000833444-17-000007:notes:121]

[0000833444-17-000016:notes:135]
[same as prior period, unchanged from 0000833444-17-000007:notes:122]

[0000833444-17-000016:notes:136]
[same as prior period, unchanged from 0000833444-17-000007:notes:123]

[0000833444-17-000016:notes:137]
[same as prior period, unchanged from 0000833444-17-000007:notes:124]

[0000833444-17-000016:notes:138]
[same as prior period, unchanged from 0000833444-17-000007:notes:125]

[0000833444-17-000016:notes:139]
[same as prior period, unchanged from 0000833444-17-000007:notes:126]

[0000833444-17-000016:notes:140]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of March 31, 2017 and September 30, 2016 (in millions):

[0000833444-17-000016:notes:141]
|  | Fair Value Measurements Using: |
|  | Total as of March 31, 2017 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |
| Commodity derivatives | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Exchange traded funds (fixed income)1 | 14 |  |  | 14 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Investments in marketable common stock | 21 |  |  | 21 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 86 |  |  | 86 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 150 |  |  | 150 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 94 |  |  | 94 |  |  | — |  |  | — |  |
| Total assets | $ | 397 |  |  | $ | 365 |  |  | $ | 32 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 1,588 |  |  | 1,588 |  |  | — |  |  | — |  |
| Total liabilities | $ | 1,608 |  |  | $ | 1,588 |  |  | $ | 20 |  |  | $ | — |  |

[0000833444-17-000016:notes:142]
[same as prior period, unchanged from 0000833444-17-000007:notes:129]

[0000833444-17-000016:notes:143]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for further details.

[0000833444-17-000016:notes:144]
[same as prior period, unchanged from 0000833444-17-000007:notes:131]

[0000833444-17-000016:notes:145]
[same as prior period, unchanged from 0000833444-17-000007:notes:132]

[0000833444-17-000016:notes:146]
[same as prior period, unchanged from 0000833444-17-000007:notes:133]

[0000833444-17-000016:notes:147]
[same as prior period, unchanged from 0000833444-17-000007:notes:134]

[0000833444-17-000016:notes:148]
[same as prior period, unchanged from 0000833444-17-000007:notes:137]

[0000833444-17-000016:notes:149]
Investments in marketable common stock and exchange traded funds:  Investments in marketable common stock and exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. There was an unrealized gain recorded on these investments of $8 million as of March 31, 2017 within AOCI in the consolidated statements of  financial position. There was an unrealized loss recorded on these investments of $1 million as of September 30, 2016 within AOCI in the consolidated statements of financial position.

[0000833444-17-000016:notes:150]
Foreign currency denominated debt: The Company has entered into a foreign currency denominated debt obligation to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effect of the debt obligation are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally. The foreign denominated debt obligation is remeasured to current exchange rates under a market approach using publicized spot prices. At March 31, 2017, the Company had one billion euro and 485 million euro bonds designated as net investment hedges in the Company's net investment in Europe. At September 30, 2016, the Company had 37 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan and one billion euro and 500 million euro bonds designated as net investment hedges in the Company's net investment in Europe.

[0000833444-17-000016:notes:151]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The fair value of long-term debt was $12.6 billion and $15.7 billion at March 31, 2017 and September 30, 2016, respectively. The fair value of public debt was $8.5 billion and $9.7 billion, at March 31, 2017 and September 30, 2016, respectively, which was determined primarily using market quotes classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was $4.1 billion and $6.0 billion at March 31, 2017 and September 30, 2016, respectively, which was determined based on quoted market prices for similar instruments classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:FiniteLivedAndIndefiniteLivedIntangibleAssetsAcquiredAsPartOfBusinessCombinationTableTextBlock

[0000833444-17-000016:notes:152]
[same as prior period, unchanged from 0000833444-17-000007:notes:141]

[0000833444-17-000016:notes:153]
|  |  | Preliminary Fair Value (in millions) |  | Weighted Average Life (in years) |
| Customer relationships |  | $ | 2,280 |  |  | 11 |
| Completed technology |  | 1,530 |  |  | 10 |
| Other definite-lived intangibles |  | 233 |  |  | 8 |
| Indefinite-lived trademarks |  | 2,020 |  |  |  |
| Other indefinite-lived intangibles |  | 90 |  |  |  |
| In-process research and development |  | 60 |  |  |  |
| Total identifiable intangible assets |  | $ | 6,213 |  |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-17-000016:notes:154]
[same as prior period, unchanged from 0000833444-17-000007:notes:143]

[0000833444-17-000016:notes:155]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the six month period ended March 31, 2017 were as follows (in millions):

[0000833444-17-000016:notes:156]
|  |  |  | Business Acquisitions |  | Business Divestitures |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  |  | March 31, |
|  | 2016 |  |  |  |  | 2017 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |  |  |
| Building Efficiency |  |  |  |  |  |  |  |  |  |
| Systems and Service North America | $ | 975 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 975 |  |
| Products North America | 1,697 |  |  | 1 |  |  | — |  |  | (2 | ) |  | 1,696 |  |
| Asia | 657 |  |  | — |  |  | — |  |  | (23 | ) |  | 634 |  |
| Rest of World | 301 |  |  | 1 |  |  | — |  |  | (9 | ) |  | 293 |  |
| Tyco | 16,308 |  |  | 49 |  |  | (1,261 | ) |  | (124 | ) |  | 14,972 |  |
| Power Solutions | 1,086 |  |  | — |  |  | — |  |  | (12 | ) |  | 1,074 |  |
| Total | $ | 21,024 |  |  | $ | 51 |  |  | $ | (1,261 | ) |  | $ | (170 | ) |  | $ | 19,644 |  |

[0000833444-17-000016:notes:157]
At September 30, 2016, accumulated goodwill impairment charges included $47 million related to the Building Efficiency Rest of World - Latin America reporting unit. The six months ended March 31, 2017 Tyco business divestiture amount includes $1,261 million of goodwill transferred to assets held for sale on the consolidated statement of financial position. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's assets and liabilities held for sale.

[0000833444-17-000016:notes:158]
Amortization of other intangible assets included within continuing operations for the three month periods ended March 31, 2017 and 2016 was $126 million and $20 million, respectively. Amortization of other intangible assets included within continuing operations for the six month periods ended March 31, 2017 and 2016 was $275 million and $40 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2018, 2019, 2020, 2021 and 2022 will be approximately $389 million, $376 million, $365 million, $359 million and $351 million per year, respectively.


## us-gaap:GuaranteesTextBlock

[0000833444-17-000016:notes:159]
[same as prior period, unchanged from 0000833444-17-000007:notes:148]

[0000833444-17-000016:notes:160]
[same as prior period, unchanged from 0000833444-17-000007:notes:149]

[0000833444-17-000016:notes:161]
[same as prior period, unchanged from 0000833444-17-000007:notes:150]

[0000833444-17-000016:notes:162]
[same as prior period, unchanged from 0000833444-17-000007:notes:151]

[0000833444-17-000016:notes:163]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations, including extended warranties for which deferred revenue is recorded, for the six months ended March 31, 2017 and 2016 were as follows (in millions):

[0000833444-17-000016:notes:164]
|  | Six Months EndedMarch 31, |
|  | 2017 |  | 2016 |
| Balance at beginning of period | $ | 374 |  |  | $ | 288 |  |
| Accruals for warranties issued during the period | 152 |  |  | 153 |  |
| Accruals from acquisition and divestitures (1) | (5 | ) |  | 36 |  |
| Accruals related to pre-existing warranties | (2 | ) |  | 7 |  |
| Settlements made (in cash or in kind) during the period | (146 | ) |  | (150 | ) |
| Currency translation | (2 | ) |  | — |  |
| Balance at end of period | $ | 371 |  |  | $ | 334 |  |

[0000833444-17-000016:notes:165]
(1) The six months ended March 31, 2017 includes $11 million of product warranties transferred to liabilities held for sale on the consolidated statement of financial position. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's disposal groups classified as held for sale.

[0000833444-17-000016:notes:166]
As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded, as part of the acquired liabilities of Tyco, $290 million of post sale contingent tax indemnification liabilities within other noncurrent liabilities in the consolidated statements of financial position. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. Of the $290 million recorded as of September 30, 2016 and March 31, 2017, $255 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements. In addition, the Company has recorded  $11 million of tax indemnification liabilities as of March 31, 2017 related to other divestitures.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0000833444-17-000016:notes:167]
[same as prior period, unchanged from 0000833444-17-000007:notes:155]

[0000833444-17-000016:notes:168]
[same as prior period, unchanged from 0000833444-17-000007:notes:156]

[0000833444-17-000016:notes:169]
In the first and second quarters of fiscal 2017, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2017. As a result, the Company reviewed the long-lived assets for impairment and recorded $38 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income, of which $15 million was recorded in the first quarter and $23 million was recorded in the second quarter. Of the total impairment charges, $20 million related to the Building Efficiency Products North America segment, $17 million related to Corporate assets and $1 million related to the Tyco segment. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000016:notes:170]
In the second quarter of fiscal 2016, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2016. As a result, the Company reviewed the long-lived assets for impairment and recorded $15 million of asset impairment charge within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charge, $8 million related to the Building Efficiency Products North America segment, $4 million related to the Building Efficiency Asia segment and $3 million related to the Building Efficiency Rest of World segment. In addition, the Company recorded $14 million of asset impairments within discontinued operations related to Adient in the second quarter of fiscal 2016. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000016:notes:171]
At March 31, 2017 and 2016, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-17-000016:notes:172]
[same as prior period, unchanged from 0000833444-17-000007:notes:159]

[0000833444-17-000016:notes:173]
In calculating the provision for income taxes, the Company uses an estimate of the annual effective tax rate based upon the facts and circumstances known at each interim period. On a quarterly basis, the actual effective tax rate is adjusted, as appropriate, based upon changed facts and circumstances, if any, as compared to those forecasted at the beginning of the fiscal year and each interim period thereafter. The U.S. federal statutory tax rate is being used as a comparison since the Company was a U.S. domiciled company for 11 months of 2016 and due to the Company's current legal entity structure. For the three months ended March 31, 2017, the Company's effective tax rate for continuing operations was 129%. The effective tax rate was higher than the U.S. federal statutory rate of 35% primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the pending divestiture of the Scott Safety business, the jurisdictional mix of significant restructuring and impairment costs, and Tyco Merger transaction and integration costs, partially offset by the benefits of continuing global tax planning initiatives and non-U.S. tax rate differentials.

[0000833444-17-000016:notes:174]
For the six months ended March 31, 2017, the Company's effective tax rate for continuing operations was 62%. The effective tax rate was higher than the U.S. federal statutory rate of 35% primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the pending divestiture of the Scott Safety business, the jurisdictional mix of significant restructuring and impairment costs, and Tyco Merger transaction /integration costs and purchase accounting impacts, partially offset by the benefits of continuing global tax planning initiatives, non-U.S. tax rate differentials and a tax benefit due to changes in entity tax status. For the three and six months ended March 31, 2016, the Company's effective tax rate for continuing operations was 14% and 18%, respectively. The effective rate was lower than the U.S. federal statutory rate of 35% primarily due to the benefits of continuing global tax planning initiatives and non-U.S. tax rate differentials, partially offset by the jurisdictional mix of significant restructuring and impairment costs, as well as the tax impact of transaction and separation costs.

[0000833444-17-000016:notes:175]
[same as prior period, unchanged from 0000833444-17-000007:notes:161]

[0000833444-17-000016:notes:176]
[same as prior period, unchanged from 0000833444-17-000007:notes:162]

[0000833444-17-000016:notes:177]
[same as prior period, unchanged from 0000833444-17-000007:notes:163]

[0000833444-17-000016:notes:178]
At September 30, 2016, exclusive of items included in noncurrent liabilities held for sale, the Company had gross tax effected unrecognized tax benefits of $1,706 million, of which $1,604 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2016 was approximately $55 million (net of tax benefit). The interest and penalties accrued during the six months ended March 31, 2017 and 2016 was not material. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-17-000016:notes:179]
In the U.S., fiscal years 2010 through 2014 are currently under exam by the Internal Revenue Service ("IRS"). Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions:

[0000833444-17-000016:notes:180]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2012 - 2013 |
| Brazil |  | 2011 - 2012 |
| Canada |  | 2012 - 2014 |
| France |  | 2010 - 2015 |
| Germany |  | 2007 - 2015 |
| Spain |  | 2010 - 2014 |
| United Kingdom |  | 2011 - 2014 |

[0000833444-17-000016:notes:181]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could be up to a $150 million impact to tax expense.

[0000833444-17-000016:notes:182]
[same as prior period, unchanged from 0000833444-17-000007:notes:168]

[0000833444-17-000016:notes:183]
On October 13, 2016, the U.S. Treasury and the IRS released final and temporary Section 385 regulations. These regulations address whether certain instruments between related parties are treated as debt or equity. The Company does not expect that the regulations will have a material impact on its consolidated financial statements.

[0000833444-17-000016:notes:184]
During the six months ended March 31, 2017 and 2016, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-17-000016:notes:185]
[same as prior period, unchanged from 0000833444-17-000007:notes:171]

[0000833444-17-000016:notes:186]
In the second quarter of fiscal 2017, the Company recorded a discrete non-cash tax charge of $457 million related to establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries of the Scott Safety business. This business is now reported as net assets held for sale given the announced sale to 3M Company in calendar 2017. Refer to Note 4, "Acquisitions and Divestitures" and Note 5, "Discontinued Operations," of the notes to consolidated financial statements for additional information.

[0000833444-17-000016:notes:187]
In the second quarter of fiscal 2017, the Company recorded $138 million of transaction and integration costs which generated a $31 million tax benefit.

[0000833444-17-000016:notes:188]
In the second quarter of fiscal 2017, the Company recorded $99 million of significant restructuring and impairment costs. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $20 million tax benefit, which was impacted by the Company’s current tax position in these jurisdictions.

[0000833444-17-000016:notes:189]
In the first quarter of fiscal 2017, the Company recorded a discrete tax benefit of $101 million due to changes in entity tax status.

[0000833444-17-000016:notes:190]
[same as prior period, unchanged from 0000833444-17-000007:notes:173]

[0000833444-17-000016:notes:191]
In the first quarter of fiscal 2017, the Company recorded $78 million of significant restructuring and impairment costs. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $14 million tax benefit, which was impacted by the Company’s current tax position in these jurisdictions.

[0000833444-17-000016:notes:192]
In the second quarter of fiscal 2016, the Company recorded $60 million of significant restructuring and impairment costs.  Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $12 million tax benefit, which was impacted by the geographic mix, the Company’s current tax position in these jurisdictions and the underlying tax basis in the impaired assets.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-17-000016:notes:193]
[same as prior period, unchanged from 0000833444-17-000007:notes:175]

[0000833444-17-000016:notes:194]
[same as prior period, unchanged from 0000833444-17-000007:notes:176]

[0000833444-17-000016:notes:195]
|  | March 31, 2017 |  | September 30, 2016 |
| Raw materials and supplies | $ | 877 |  |  | $ | 852 |  |
| Work-in-process | 509 |  |  | 503 |  |
| Finished goods | 1,752 |  |  | 1,533 |  |
| Inventories | $ | 3,138 |  |  | $ | 2,888 |  |


## us-gaap:LongTermContractsOrProgramsDisclosureTextBlock

[0000833444-17-000016:notes:196]
[same as prior period, unchanged from 0000833444-17-000007:notes:178]

[0000833444-17-000016:notes:197]
The Building Technologies & Solutions business records certain long-term contracts under the percentage-of-completion method of accounting. Under this method, sales and gross profit are recognized as work is performed based on the relationship between actual costs incurred and total estimated costs at completion. The Company records costs and earnings in excess of billings on uncompleted contracts primarily within accounts receivable - net and billings in excess of costs and earnings on uncompleted contracts primarily within other current liabilities in the consolidated statements of financial position. Costs and earnings in excess of billings related to these contracts were $863 million and $841 million at March 31, 2017 and September 30, 2016, respectively. Billings in excess of costs and earnings related to these contracts were $472 million and $431 million at March 31, 2017 and September 30, 2016, respectively.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-17-000016:notes:198]
[same as prior period, unchanged from 0000833444-17-000007:notes:180]

[0000833444-17-000016:notes:199]
[same as prior period, unchanged from 0000833444-17-000007:notes:181]

[0000833444-17-000016:notes:200]
[same as prior period, unchanged from 0000833444-17-000007:notes:182]

[0000833444-17-000016:notes:201]
[same as prior period, unchanged from 0000833444-17-000007:notes:183]

[0000833444-17-000016:notes:202]
[same as prior period, unchanged from 0000833444-17-000007:notes:184]

[0000833444-17-000016:notes:203]
[same as prior period, unchanged from 0000833444-17-000007:notes:185]

[0000833444-17-000016:notes:204]
[same as prior period, unchanged from 0000833444-17-000007:notes:186]

[0000833444-17-000016:notes:205]
[same as prior period, unchanged from 0000833444-17-000007:notes:187]

[0000833444-17-000016:notes:206]
[same as prior period, unchanged from 0000833444-17-000007:notes:188]

[0000833444-17-000016:notes:207]
[same as prior period, unchanged from 0000833444-17-000007:notes:189]

[0000833444-17-000016:notes:208]
[same as prior period, unchanged from 0000833444-17-000007:notes:190]

[0000833444-17-000016:notes:209]
| Cash and cash equivalents |  | $ | 489 |  |
| Accounts receivable |  | 2,097 |  |
| Inventories |  | 823 |  |
| Other current assets |  | 610 |  |
| Property, plant, and equipment - net |  | 1,219 |  |
| Goodwill |  | 16,412 |  |
| Intangible assets - net |  | 6,213 |  |
| Other noncurrent assets |  | 536 |  |
| Total assets acquired |  | $ | 28,399 |  |
| Short-term debt |  | $ | 462 |  |
| Accounts payable |  | 724 |  |
| Accrued compensation and benefits |  | 312 |  |
| Other current liabilities |  | 1,418 |  |
| Long-term debt |  | 6,416 |  |
| Long-term deferred tax liabilities |  | 1,173 |  |
| Long-term pension and postretirement benefits |  | 774 |  |
| Other noncurrent liabilities |  | 1,279 |  |
| Total liabilities acquired |  | $ | 12,558 |  |
| Noncontrolling interests |  | 34 |  |
| Net assets acquired |  | $ | 15,807 |  |
| Cash consideration paid to JCI Inc. shareholders |  | 3,864 |  |
| Total fair value of consideration transferred |  | $ | 19,671 |  |

[0000833444-17-000016:notes:210]
In connection with the merger, the Company recorded goodwill of $16.4 billion, which is attributable primarily to expected synergies, expanded market opportunities, and other benefits that the Company believes will result from combining its operations with the operations of Tyco. The goodwill created in the merger is not deductible for tax purposes and is subject to potential significant changes as the purchase price allocation is completed. Goodwill has preliminarily been allocated to the Tyco segment based on how the business was reviewed by the Company's Chief Operating Decision Maker as shown in Note 8, "Goodwill and Other Intangible Assets." In connection with the Tyco Merger, the Company recorded additional goodwill of $49 million in the first six months of fiscal 2017 related to purchase price allocations.

[0000833444-17-000016:notes:211]
[same as prior period, unchanged from 0000833444-17-000007:notes:193]

[0000833444-17-000016:notes:212]
In the first six months of fiscal 2017, the Company completed three acquisitions for a combined purchase price, net of cash acquired, of $9 million, $6 million of which was paid in the six months ended March 31, 2017. The acquisitions in the aggregate were not material to the Company’s consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $2 million.

[0000833444-17-000016:notes:213]
In the second quarter of fiscal 2017, the Company announced it signed a definitive agreement to sell its Scott Safety business to 3M Company for approximately $2.0 billion. Net cash proceeds from the transaction are expected to approximate $1.8 to $1.9 billion. Scott Safety is a leader in the design, manufacture and sale of high performance respiratory protection, gas and flame detection, thermal imaging and other critical products for fire services, law enforcement, industrial, oil and gas, chemical, armed forces, and homeland defense end markets. The transaction is expected to close in the second half of calendar 2017, subject to customary closing conditions including required regulatory approval. The Scott Safety business is included in the Tyco segment and is reported within assets and liabilities held for sale in the consolidated statements of financial position as of March 31, 2017. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further disclosure related to the Company's net assets held for sale.

[0000833444-17-000016:notes:214]
In the second quarter of fiscal 2017, the Company completed the sale of its ADT security business in South Africa within the Tyco segment. The selling price, net of cash divested, was $129 million, all of which was received in the six months ended March 31, 2017. In connection with the sale, the Company reduced goodwill in assets held for sale by $92 million. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-17-000016:notes:215]
In the first six months of fiscal 2017, the Company completed one additional divestiture for a sales price of $4 million, all of which was received in the six months ended March 31, 2017. The divestiture decreased the Company's ownership from a controlling to noncontrolling interest, and as a result, the Company deconsolidated cash of $5 million.The divestiture was not material to the Company's consolidated financial statements.

[0000833444-17-000016:notes:216]
In the first six months of fiscal 2017, the Company received $52 million in net cash proceeds related to prior year business divestitures.

[0000833444-17-000016:notes:217]
In the first quarter of fiscal 2016, the Company formed a joint venture with Hitachi to expand its Building Efficiency product offerings. The Company acquired a 60% ownership interest in the new entity for approximately $170 million ($600 million purchase price less cash acquired of $430 million), $133 million of which was paid in the six months ended March 31, 2016 and $37 million was paid in the six months ended March 31, 2017. In connection with the acquisition, the Company recorded goodwill of $253 million related to purchase price allocations.

[0000833444-17-000016:notes:218]
In the first six months of fiscal 2016, the Company completed one additional acquisition for a purchase price, net of cash acquired, of $3 million, none of which was paid as of March 31, 2016. The acquisition was not material to the Company's consolidated financial statements. In connection with the acquisition, the Company recorded goodwill of $4 million. The acquisition increased the Company's ownership from a noncontrolling to controlling interest. As a result, the Company recorded a non-cash gain of $4 million in equity income for the Building Efficiency Rest of World segment to adjust the Company's existing equity investment in the partially-owned affiliate to fair value.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-17-000016:notes:219]
[same as prior period, unchanged from 0000833444-17-000007:notes:198]

[0000833444-17-000016:notes:220]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (SEC). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2016 filed with the SEC on November 23, 2016, portions of which (including Part I, Item 1. Business and Item 3. Legal Proceedings, and the following items from Part II of the Annual Report: Item 6. Selected Financial Data, Item 7. Management’s Discussion and Analysis, and Item 8. Financial Statements and Supplementary Data) were recast in the Company's Current Report on Form 8-K filed with the SEC on February 23, 2017. The results of operations for the three and six month periods ended March 31, 2017 are not necessarily indicative of results for the Company’s 2017 fiscal year because of seasonal and other factors.

[0000833444-17-000016:notes:221]
[same as prior period, unchanged from 0000833444-17-000007:notes:200]

[0000833444-17-000016:notes:222]
[same as prior period, unchanged from 0000833444-17-000007:notes:201]

[0000833444-17-000016:notes:223]
[same as prior period, unchanged from 0000833444-17-000007:notes:202]

[0000833444-17-000016:notes:224]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience Business from Johnson Controls to Adient plc and the issuance of ordinary shares of Adient directly to holders of Johnson Controls ordinary shares on a pro rata basis. Prior to the open of business on October 31, 2016, each of the Company's shareholders received one ordinary share of Adient plc for every 10 ordinary shares of Johnson Controls held as of the close of business on October 19, 2016, the record date for the distribution. Company shareholders received cash in lieu of fractional shares of Adient, if any. Following the separation and distribution, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc. Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-17-000016:notes:225]
[same as prior period, unchanged from 0000833444-17-000007:notes:204]

[0000833444-17-000016:notes:226]
[same as prior period, unchanged from 0000833444-17-000007:notes:205]

[0000833444-17-000016:notes:227]
[same as prior period, unchanged from 0000833444-17-000007:notes:206]

[0000833444-17-000016:notes:228]
[same as prior period, unchanged from 0000833444-17-000007:notes:207]

[0000833444-17-000016:notes:229]
Based upon the criteria set forth in ASC 810, the Company has determined that it was the primary beneficiary in one VIE for the reporting period ended March 31, 2017 and three VIEs for the reporting period ended  September 30, 2016, as the Company absorbs significant economics of the entities and has the power to direct the activities that are considered most significant to the entities.

[0000833444-17-000016:notes:230]
[same as prior period, unchanged from 0000833444-17-000007:notes:209]

[0000833444-17-000016:notes:231]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE has been consolidated within the Company’s consolidated statements of financial position. The impact of consolidation of the entity on the Company’s consolidated statements of income for the three and six month periods ended March 31, 2017 and 2016 was not material. The VIE is named as a co-obligor under a third party debt agreement in the amount of $168 million, maturing in fiscal 2020, under which it could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business.

[0000833444-17-000016:notes:232]
[same as prior period, unchanged from 0000833444-17-000007:notes:211]

[0000833444-17-000016:notes:233]
|  | March 31, 2017 |  | September 30, 2016 |
| Current assets | $ | 2 |  |  | $ | 284 |  |
| Noncurrent assets | 53 |  |  | 98 |  |
| Total assets | $ | 55 |  |  | $ | 382 |  |
| Current liabilities | $ | 3 |  |  | $ | 230 |  |
| Noncurrent liabilities | 44 |  |  | 29 |  |
| Total liabilities | $ | 47 |  |  | $ | 259 |  |

[0000833444-17-000016:notes:234]
[same as prior period, unchanged from 0000833444-17-000007:notes:213]

[0000833444-17-000016:notes:235]
[same as prior period, unchanged from 0000833444-17-000007:notes:214]

[0000833444-17-000016:notes:236]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is not considered to be the primary beneficiary of two of the entities as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balances of $62 million  and $59 million at March 31, 2017 and September 30, 2016 respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned previously within the "Consolidated VIEs" section above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.

[0000833444-17-000016:notes:237]
[same as prior period, unchanged from 0000833444-17-000007:notes:216]

[0000833444-17-000016:notes:238]
[same as prior period, unchanged from 0000833444-17-000007:notes:217]

[0000833444-17-000016:notes:239]
At March 31, 2017, the Company held restricted cash of approximately $42 million, of which $33 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash restricted for payment of asbestos liabilities. At September 30, 2016, the Company held restricted cash of approximately $88 million, of which $79 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash held in escrow from business divestitures and cash restricted for payment of asbestos liabilities.

[0000833444-17-000016:notes:240]
[same as prior period, unchanged from 0000833444-17-000007:notes:219]

[0000833444-17-000016:notes:241]
[same as prior period, unchanged from 0000833444-17-000007:notes:220]

[0000833444-17-000016:notes:242]
[same as prior period, unchanged from 0000833444-17-000007:notes:221]

[0000833444-17-000016:notes:243]
[same as prior period, unchanged from 0000833444-17-000007:notes:222]

[0000833444-17-000016:notes:244]
In April 2015, the FASB issued Accounting Standards Update (ASU) No. 2015-03, "Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." ASU No. 2015-03 requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability.

[0000833444-17-000016:notes:245]
During the quarter ended December 31, 2016, the Company adopted ASU No. 2015-03 and applied the change retrospectively to all periods presented. This change did not have an impact to any period presented on the consolidated statements of income. The financial statement impact of this change for the period ending September 30, 2016 was a decrease to noncurrent assets held for sale of $44 million, a decrease to noncurrent liabilities held for sale of $44 million, a decrease to other noncurrent assets of $30 million and a decrease to long-term debt of $30 million.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-17-000016:notes:246]
[same as prior period, unchanged from 0000833444-17-000007:notes:225]

[0000833444-17-000016:notes:247]
[same as prior period, unchanged from 0000833444-17-000007:notes:226]

[0000833444-17-000016:notes:248]
|  | U.S. Pension Plans |
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Service cost | $ | 4 |  |  | $ | 4 |  |  | $ | 9 |  |  | $ | 8 |  |
| Interest cost | 29 |  |  | 25 |  |  | 57 |  |  | 50 |  |
| Expected return on plan assets | (58 | ) |  | (46 | ) |  | (117 | ) |  | (92 | ) |
| Net actuarial gain | (18 | ) |  | — |  |  | (135 | ) |  | — |  |
| Settlement gain | (1 | ) |  | — |  |  | (9 | ) |  | — |  |
| Net periodic benefit credit | $ | (44 | ) |  | $ | (17 | ) |  | $ | (195 | ) |  | $ | (34 | ) |

[0000833444-17-000016:notes:249]
|  | Non-U.S. Pension Plans |
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Service cost | $ | 8 |  |  | $ | 2 |  |  | $ | 16 |  |  | $ | 5 |  |
| Interest cost | 11 |  |  | 6 |  |  | 23 |  |  | 12 |  |
| Expected return on plan assets | (22 | ) |  | (7 | ) |  | (45 | ) |  | (15 | ) |
| Net periodic benefit cost (credit) | $ | (3 | ) |  | $ | 1 |  |  | $ | (6 | ) |  | $ | 2 |  |

[0000833444-17-000016:notes:250]
|  | Postretirement Benefits |
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |
| Interest cost | 2 |  |  | 2 |  |  | 3 |  |  | 3 |  |
| Expected return on plan assets | (2 | ) |  | (2 | ) |  | (5 | ) |  | (4 | ) |
| Amortization of prior service credit | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net periodic benefit credit | $ | — |  |  | $ | (1 | ) |  | $ | (1 | ) |  | $ | (2 | ) |

[0000833444-17-000016:notes:251]
During the three and six months ended March 31, 2017, the amount of lump sum payouts triggered a remeasurement event for certain U.S. pension plans resulting in the recognition of net actuarial gains of $18 million and $135 million, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-17-000016:notes:252]
Related Party Transactions

[0000833444-17-000016:notes:253]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-17-000016:notes:254]
The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $229 million and $52 million, respectively, for the three months ended March 31, 2017; and $236 million and $45 million, respectively, for the three months ended March 31, 2016. The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $454 million and $101 million, respectively, for the six months ended March 31, 2017; and $470 million and $83 million, respectively, for the six months ended March 31, 2016.

[0000833444-17-000016:notes:255]
The following table sets forth the amount of accounts receivable due from and payable to related parties for continuing operations in the consolidated statements of financial position (in millions):

[0000833444-17-000016:notes:256]
|  |  | March 31, 2017 |  | September 30, 2016 |  |
| Receivable from related parties |  | $ | 57 |  |  | $ | 66 |  |
| Payable to related parties |  | 20 |  |  | 11 |  |

[0000833444-17-000016:notes:257]
The Company has also provided financial support to certain of its VIE's; see Note 1, "Financial Statements," of the notes to consolidated financial statements for additional information.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-17-000016:notes:258]
[same as prior period, unchanged from 0000833444-17-000007:notes:237]

[0000833444-17-000016:notes:259]
[same as prior period, unchanged from 0000833444-17-000007:notes:238]

[0000833444-17-000016:notes:260]
In fiscal 2017, the Company committed to a significant restructuring plan (2017 Plan) and recorded $177 million of restructuring and impairment costs in the consolidated statements of income, of which $78 million was recorded in the first quarter and $99 million was recorded in the second quarter of fiscal 2017. This is the total amount incurred to date for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $67 million related to Corporate, $49 million related to the Tyco segment, $27 million related to the Building Efficiency Products North America segment, $16 million related to the Building Efficiency Rest of World segment, $9 million related to the Building Efficiency Asia segment and $9 million related to the Building Efficiency Systems and Service North America segment. The restructuring actions are expected to be substantially complete in fiscal 2018.

[0000833444-17-000016:notes:261]
[same as prior period, unchanged from 0000833444-17-000007:notes:240]

[0000833444-17-000016:notes:262]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 62 |  |  | $ | 15 |  |  | $ | 1 |  |  | $ | 78 |  |
| Utilized—noncash | — |  |  | (15 | ) |  | (1 | ) |  | (16 | ) |
| Balance at December 31, 2016 | $ | 62 |  |  | $ | — |  |  | $ | — |  |  | $ | 62 |  |
| Additional restructuring costs | 67 |  |  | 23 |  |  | 9 |  |  | 99 |  |
| Utilized—cash | (13 | ) |  | — |  |  | — |  |  | (13 | ) |
| Utilized—noncash | — |  |  | (23 | ) |  | — |  |  | (23 | ) |
| Balance at March 31, 2017 | $ | 116 |  |  | $ | — |  |  | $ | 9 |  |  | $ | 125 |  |

[0000833444-17-000016:notes:263]
In fiscal 2016, the Company committed to a significant restructuring plan (2016 Plan) and recorded $288 million of restructuring and impairment costs in the consolidated statements of income. This is the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. Of the restructuring and impairment costs recorded, $161 million related to Corporate, $66 million related to the Power Solutions segment, $26 million related to the Building Efficiency Asia segment, $16 million related to the Building Efficiency Rest of World segment, $9 million related to the Building Efficiency Products North America segment, $8 million related to the Tyco segment, and $2 million related to the Building Efficiency Systems and Service North America segment. The restructuring actions are expected to be substantially complete in fiscal 2018. Included in the 2016 Plan is $74 million of committed restructuring actions taken by Tyco for liabilities assumed as part of the Tyco acquisition.

[0000833444-17-000016:notes:264]
[same as prior period, unchanged from 0000833444-17-000007:notes:243]

[0000833444-17-000016:notes:265]
The following table summarizes the changes in the Company’s 2016 Plan reserve, included within other current liabilities and Adient liabilities held for sale in the consolidated statements of financial position (in millions):

[0000833444-17-000016:notes:266]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 368 |  |  | $ | 190 |  |  | $ | 62 |  |  | $ | — |  |  | $ | 620 |  |
| Acquired Tyco restructuring reserves | 78 |  |  | — |  |  | — |  |  | — |  |  | 78 |  |
| Utilized—cash | (32 | ) |  | — |  |  | — |  |  | — |  |  | (32 | ) |
| Utilized—noncash | — |  |  | (190 | ) |  | (32 | ) |  | 1 |  |  | (221 | ) |
| Balance at September 30, 2016 | $ | 414 |  |  | $ | — |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 445 |  |
| Adient spin-off impact | (194 | ) |  | — |  |  | (22 | ) |  | — |  |  | (216 | ) |
| Utilized—cash | (49 | ) |  | — |  |  | (2 | ) |  | — |  |  | (51 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (3 | ) |  | (3 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Adjustment to acquired Tyco restructuring reserves | (4 | ) |  | — |  |  | — |  |  | — |  |  | (4 | ) |
| Balance at March 31, 2017 | $ | 164 |  |  | $ | — |  |  | $ | 6 |  |  | $ | (2 | ) |  | $ | 168 |  |

[0000833444-17-000016:notes:267]
The Company's fiscal 2017 and 2016 restructuring plans included workforce reductions of approximately 4,500 employees (3,900 for the Building Technologies & Solutions business and 600 for Corporate). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of March 31, 2017, approximately 900 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included twelve plant closures in the Building Technologies & Solutions business. As of March 31, 2017, four of the twelve plants have been closed.

[0000833444-17-000016:notes:268]
[same as prior period, unchanged from 0000833444-17-000007:notes:247]


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-17-000016:notes:269]
[same as prior period, unchanged from 0000833444-17-000007:notes:248]

[0000833444-17-000016:notes:270]
|  | Three Months Ended March 31, |
|  | 2017 |  | 2016 |
| Foreign currency translation adjustments |  |  |  |
| Balance at beginning of period | $ | (1,248 | ) |  | $ | (1,207 | ) |
| Aggregate adjustment for the period (net of tax effect of $0 and $5) | 241 |  |  | 175 |  |
| Balance at end of period | (1,007 | ) |  | (1,032 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 20 |  |  | (8 | ) |
| Current period changes in fair value (net of tax effect of $0 and $(1)) | 1 |  |  | (2 | ) |
| Reclassification to income (net of tax effect of $(4) and $3) * | (7 | ) |  | 6 |  |
| Balance at end of period | 14 |  |  | (4 | ) |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | (3 | ) |  | — |  |
| Current period changes in fair value (net of tax effect of $0) | 11 |  |  | — |  |
| Balance at end of period | 8 |  |  | — |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (2 | ) |  | (3 | ) |
| Reclassification to income (net of tax effect of $0) ** | — |  |  | (1 | ) |
| Other changes (net of tax effect of $0) | — |  |  | 1 |  |
| Balance at end of period | (2 | ) |  | (3 | ) |
| Accumulated other comprehensive loss, end of period | $ | (987 | ) |  | $ | (1,039 | ) |

[0000833444-17-000016:notes:271]
|  | Six Months EndedMarch 31, |
|  | 2017 |  | 2016 |
| Foreign currency translation adjustments |  |  |  |
| Balance at beginning of period | $ | (1,152 | ) |  | $ | (1,047 | ) |
| Aggregate adjustment for the period (net of tax effect of $5 and $1) | (418 | ) |  | 15 |  |
| Adient spin-off impact (net of tax effect of $0) | 563 |  |  | — |  |
| Balance at end of period | (1,007 | ) |  | (1,032 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 4 |  |  | (7 | ) |
| Current period changes in fair value (net of tax effect of $4 and $(1)) | 7 |  |  | (6 | ) |
| Reclassification to income (net of tax effect of $(7) and $4) * | (13 | ) |  | 9 |  |
| Adient spin-off impact (net of tax effect of $6 and $0) | 16 |  |  | — |  |
| Balance at end of period | 14 |  |  | (4 | ) |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | (1 | ) |  | — |  |
| Current period changes in fair value (net of tax effect of $0) | 9 |  |  | — |  |
| Balance at end of period | 8 |  |  | — |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (4 | ) |  | (3 | ) |
| Reclassification to income (net of tax effect of $0) ** | — |  |  | (1 | ) |
| Adient spin-off impact (net of tax effect of $0) | 2 |  |  | — |  |
| Other changes (net of tax effect of $0) | — |  |  | 1 |  |
| Balance at end of period | (2 | ) |  | (3 | ) |
| Accumulated other comprehensive loss, end of period | $ | (987 | ) |  | $ | (1,039 | ) |

[0000833444-17-000016:notes:272]
[same as prior period, unchanged from 0000833444-17-000007:notes:250]

[0000833444-17-000016:notes:273]
**  Refer to Note 11, "Pension and Postretirement Plans," of the notes to consolidated financial statements for disclosure of the components of the Company's net periodic benefit costs associated with its defined benefit pension and postretirement plans. For the three and six months ended March 31, 2016, the amounts reclassified from AOCI into income for pension and postretirement plans were primarily recorded in selling, general and administrative expenses on the consolidated statements of income.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000833444-17-000016:notes:274]
[same as prior period, unchanged from 0000833444-17-000007:notes:251]

[0000833444-17-000016:notes:275]
|  | Net Sales |
|  | Three Months EndedMarch 31, |  | Six Months Ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |
| Building Efficiency |  |  |  |  |  |  |  |
| Systems and Service North America | $ | 1,047 |  |  | $ | 1,034 |  |  | $ | 1,975 |  |  | $ | 2,018 |  |
| Products North America | 585 |  |  | 546 |  |  | 1,128 |  |  | 1,103 |  |
| Asia | 1,173 |  |  | 1,162 |  |  | 2,215 |  |  | 2,154 |  |
| Rest of World | 424 |  |  | 408 |  |  | 822 |  |  | 831 |  |
|  | 3,229 |  |  | 3,150 |  |  | 6,140 |  |  | 6,106 |  |
| Tyco | 2,342 |  |  | — |  |  | 4,617 |  |  | — |  |
|  | 5,571 |  |  | 3,150 |  |  | 10,757 |  |  | 6,106 |  |
| Power Solutions | 1,696 |  |  | 1,583 |  |  | 3,596 |  |  | 3,323 |  |
| Total net sales | $ | 7,267 |  |  | $ | 4,733 |  |  | $ | 14,353 |  |  | $ | 9,429 |  |

[0000833444-17-000016:notes:276]
|  | Segment EBITA |
|  | Three Months EndedMarch 31, |  | Six Months Ended March 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |
| Building Efficiency |  |  |  |  |  |  |  |
| Systems and Service North America | $ | 90 |  |  | $ | 101 |  |  | $ | 165 |  |  | $ | 200 |  |
| Products North America | 57 |  |  | 47 |  |  | 94 |  |  | 80 |  |
| Asia | 118 |  |  | 118 |  |  | 237 |  |  | 188 |  |
| Rest of World | 9 |  |  | 10 |  |  | (1 | ) |  | 7 |  |
|  | 274 |  |  | 276 |  |  | 495 |  |  | 475 |  |
| Tyco | 379 |  |  | — |  |  | 593 |  |  | — |  |
|  | 653 |  |  | 276 |  |  | 1,088 |  |  | 475 |  |
| Power Solutions | 303 |  |  | 282 |  |  | 692 |  |  | 642 |  |
| Segment EBITA | $ | 956 |  |  | $ | 558 |  |  | $ | 1,780 |  |  | $ | 1,117 |  |
| Corporate expenses | $ | (240 | ) |  | $ | (110 | ) |  | $ | (433 | ) |  | $ | (197 | ) |
| Amortization of intangible assets | (126 | ) |  | (20 | ) |  | (275 | ) |  | (40 | ) |
| Restructuring and impairment costs | (99 | ) |  | (60 | ) |  | (177 | ) |  | (60 | ) |
| Net mark-to-market adjustments on pension plans | 18 |  |  | — |  |  | 135 |  |  | — |  |
| Net financing charges | (116 | ) |  | (71 | ) |  | (252 | ) |  | (137 | ) |
| Income from continuing operations before income taxes | $ | 393 |  |  | $ | 297 |  |  | $ | 778 |  |  | $ | 683 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-17-000016:notes:277]
[same as prior period, unchanged from 0000833444-17-000007:notes:254]

[0000833444-17-000016:notes:278]
[same as prior period, unchanged from 0000833444-17-000007:notes:255]

[0000833444-17-000016:notes:279]
In the first quarter of fiscal 2017, the Company began evaluating the performance of its business segments primarily on segment EBITA, which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans.  Historical information has been revised to present the comparable periods on a consistent basis.

[0000833444-17-000016:notes:280]
[same as prior period, unchanged from 0000833444-17-000007:notes:257]

[0000833444-17-000016:notes:281]
[same as prior period, unchanged from 0000833444-17-000007:notes:258]

[0000833444-17-000016:notes:282]
[same as prior period, unchanged from 0000833444-17-000007:notes:259]

[0000833444-17-000016:notes:283]
[same as prior period, unchanged from 0000833444-17-000007:notes:260]

[0000833444-17-000016:notes:284]
[same as prior period, unchanged from 0000833444-17-000007:notes:261]

[0000833444-17-000016:notes:285]
[same as prior period, unchanged from 0000833444-17-000007:notes:262]

[0000833444-17-000016:notes:286]
[same as prior period, unchanged from 0000833444-17-000007:notes:263]

[0000833444-17-000016:notes:287]
[same as prior period, unchanged from 0000833444-17-000007:notes:264]

[0000833444-17-000016:notes:288]
[same as prior period, unchanged from 0000833444-17-000007:notes:265]

[0000833444-17-000016:notes:289]
[same as prior period, unchanged from 0000833444-17-000007:notes:266]

[0000833444-17-000016:notes:290]
[same as prior period, unchanged from 0000833444-17-000007:notes:267]

[0000833444-17-000016:notes:291]
[same as prior period, unchanged from 0000833444-17-000007:notes:268]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-17-000016:notes:292]
[same as prior period, unchanged from 0000833444-17-000007:notes:269]

[0000833444-17-000016:notes:293]
[same as prior period, unchanged from 0000833444-17-000007:notes:270]

[0000833444-17-000016:notes:294]
As previously disclosed, on October 31, 2016, the Company completed the Adient spin-off. As a result of the spin-off, the Company divested net assets of $4,038 million.

[0000833444-17-000016:notes:295]
[same as prior period, unchanged from 0000833444-17-000007:notes:272]

[0000833444-17-000016:notes:296]
Following the Tyco Merger, the Company adopted, subject to the ongoing existence of sufficient distributable reserves, the existing Tyco International plc $1 billion share repurchase program in September 2016. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. For the three and six month periods ended March 31, 2017, the Company repurchased approximately $119 million of its ordinary shares.

[0000833444-17-000016:notes:297]
In April 2017, the Company announced its intention to utilize up to $750 million of the $1 billion authorization during fiscal 2017. Shares may be repurchased from time to time in open market purchases at prevailing market prices, in negotiated transactions off the market, or pursuant to a trading plan in accordance with applicable regulations.

[0000833444-17-000016:notes:298]
[same as prior period, unchanged from 0000833444-17-000007:notes:274]

[0000833444-17-000016:notes:299]
[same as prior period, unchanged from 0000833444-17-000007:notes:275]

[0000833444-17-000016:notes:300]
|  | Three Months EndedMarch 31, |
|  | 2017 |  | 2016 |
| Beginning balance, December 31 | $ | 159 |  |  | $ | 216 |  |
| Net income | 8 |  |  | 11 |  |
| Foreign currency translation adjustments | 1 |  |  | 10 |  |
| Ending balance, March 31 | $ | 168 |  |  | $ | 237 |  |

[0000833444-17-000016:notes:301]
|  | Six Months EndedMarch 31, |
|  | 2017 |  | 2016 |
| Beginning balance, September 30 | $ | 234 |  |  | $ | 212 |  |
| Net income | 21 |  |  | 31 |  |
| Foreign currency translation adjustments | (8 | ) |  | 2 |  |
| Realized and unrealized losses on derivatives | — |  |  | (2 | ) |
| Dividends | (43 | ) |  | (6 | ) |
| Spin-off of Adient | (36 | ) |  | — |  |
| Ending balance, March 31 | $ | 168 |  |  | $ | 237 |  |
