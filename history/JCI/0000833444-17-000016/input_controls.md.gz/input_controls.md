# JCI 10-Q controls and the auditor's report


## item_4_controls

[0000833444-17-000016:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0000833444-17-000016:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0000833444-17-000016:item_4_controls:3]
Under the supervision and with the participation of our management, including our principal executive officer and principal financial officer, we conducted an evaluation of our disclosure controls and procedures, as such term is defined under Rule 13a-15(e) promulgated under the Securities Exchange Act of 1934, as amended (Exchange Act). Based upon their evaluation of these disclosure controls and procedures, the principal executive officer and principal financial officer concluded that the disclosure controls and procedures were effective as of March 31, 2017 to ensure that information required to be disclosed by the Company in the reports it files or submits under the Exchange Act is recorded, processed, summarized and reported, within the time period specified in the SEC’s rules and forms, and to ensure that information required to be disclosed by the Company in the reports it files or submits under the Exchange Act is accumulated and communicated to the Company’s management, including its principal executive and principal financial officers, as appropriate, to allow timely decisions regarding disclosure.

[0000833444-17-000016:item_4_controls:4]
Changes in Internal Control Over Financial Reporting

[0000833444-17-000016:item_4_controls:5]
There have been no significant changes in the Company’s internal control over financial reporting during the three months ended March 31, 2017 that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.
