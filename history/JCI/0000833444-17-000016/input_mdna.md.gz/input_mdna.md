# JCI MD&A — 0000833444-17-000016


## mdna

[0000833444-17-000016:mdna:1]
[same as prior period, unchanged from 0000833444-17-000007:mdna:1]

[0000833444-17-000016:mdna:2]
[same as prior period, unchanged from 0000833444-17-000007:mdna:2]

[0000833444-17-000016:mdna:3]
[same as prior period, unchanged from 0000833444-17-000007:mdna:3]

[0000833444-17-000016:mdna:4]
[same as prior period, unchanged from 0000833444-17-000007:mdna:4]

[0000833444-17-000016:mdna:5]
[same as prior period, unchanged from 0000833444-17-000007:mdna:5]

[0000833444-17-000016:mdna:6]
[same as prior period, unchanged from 0000833444-17-000007:mdna:6]

[0000833444-17-000016:mdna:7]
[same as prior period, unchanged from 0000833444-17-000007:mdna:7]

[0000833444-17-000016:mdna:8]
[same as prior period, unchanged from 0000833444-17-000007:mdna:8]

[0000833444-17-000016:mdna:9]
[same as prior period, unchanged from 0000833444-17-000007:mdna:9]

[0000833444-17-000016:mdna:10]
[same as prior period, unchanged from 0000833444-17-000007:mdna:10]

[0000833444-17-000016:mdna:11]
The Building Efficiency business is a global market leader in designing, producing, marketing and installing integrated heating, ventilating and air conditioning (HVAC) systems, building management systems, controls, security and mechanical equipment. In addition, the Buildings business provides technical services and energy management consulting. The Company also provides residential air conditioning and heating systems and industrial refrigeration products.

[0000833444-17-000016:mdna:12]
[same as prior period, unchanged from 0000833444-17-000007:mdna:12]

[0000833444-17-000016:mdna:13]
[same as prior period, unchanged from 0000833444-17-000007:mdna:13]

[0000833444-17-000016:mdna:14]
The following information should be read in conjunction with the September 30, 2016 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2016 filed with the SEC on November 23, 2016, portions of which (including Part I, Item 1. Business and Item 3. Legal Proceedings, and the following items from Part II of the Annual Report: Item 6. Selected Financial Data, Item 7. Management’s Discussion and Analysis, and Item 8. Financial Statements and Supplementary Data) were recast in the Company's Current Report on Form 8-K filed with the SEC on February 23, 2017. References in the following discussion and analysis to "Three Months"(or similar language) refer to the three months ended March 31, 2017 compared to the three months ended March 31, 2016, while references to "Year-to-Date" refer to the six months ended March 31, 2017 compared to the six months ended March 31, 2016.

[0000833444-17-000016:mdna:15]
[same as prior period, unchanged from 0000833444-17-000007:mdna:15]

[0000833444-17-000016:mdna:16]
The Company believes its capital resources and liquidity position at March 31, 2017 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in fiscal 2017 will continue be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets.  In the event the Company and its wholly-owned indirect subsidiary, Tyco International Holding S.à.r.l ("TSarl"), are unable to issue commercial paper, they would have the ability to draw on their $2.0 billion and $1.0 billion revolving credit facilities, respectively. Both facilities mature in August 2020. There were no draws on the revolving credit facilities as of March 31, 2017. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-17-000016:mdna:17]
The Company’s debt financial covenant in its revolving credit facility require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification (ASC) 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. TSarl's, revolving credit facility contains customary terms and conditions, and a financial covenant that limits the ratio of TSarl's debt to earnings before interest, taxes, depreciation, and amortization as adjusted for certain items set forth in the agreement to 3.5x. The TSarl's revolving credit facility also limits its ability to incur subsidiary debt or grant liens on its and its subsidiaries' property. As of March 31, 2017, the Company and TSarl were in compliance with all covenants and other requirements set forth in their credit agreements and the indentures, governing their notes, and expect to remain in compliance for the foreseeable future. None of the Company’s or TSarl's debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the respective borrower's credit rating.

[0000833444-17-000016:mdna:18]
The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2017, the Company believes the long-term rate of return will approximate 7.50%, 3.40% and 5.60% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first six months of fiscal 2017, the Company made approximately $258 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $326 million in cash to its defined benefit pension plans in fiscal 2017. The Company expects to contribute $4 million in cash to its postretirement plans in fiscal 2017.

[0000833444-17-000016:mdna:19]
To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2017 and recorded $177 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and  asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs from continuing operations by approximately $185 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2018. For fiscal 2017, the savings from continuing operations, net of execution costs, are expected to be approximately 60% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in fiscal 2018. The restructuring plan reserve balance of $125 million at March 31, 2017 is expected to be paid in cash.

[0000833444-17-000016:mdna:20]
To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2016 and recorded $288 million of restructuring and impairment costs in the consolidated statements of income within continuing operations. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2016 restructuring plan will reduce annual operating costs from continuing operations by approximately $135 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized by the end of fiscal 2018. For fiscal 2017, the savings from continuing operations, net of execution costs, are expected to be approximately 35% of

[0000833444-17-000016:mdna:21]
57

[0000833444-17-000016:mdna:22]
the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in fiscal 2018. The restructuring plan reserve balance of $168 million at March 31, 2017 is expected to be paid in cash.

[0000833444-17-000016:mdna:23]
[same as prior period, unchanged from 0000833444-17-000007:mdna:23]

[0000833444-17-000016:mdna:24]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Net sales | $ | 7,267 |  |  | $ | 4,733 |  |  | 54 | % |  | $ | 14,353 |  |  | $ | 9,429 |  |  | 52 | % |

[0000833444-17-000016:mdna:25]
The increase in consolidated net sales for the three months ended March 31, 2017 was due to higher sales in the Building Technologies & Solutions business ($2,411 million) and the Power Solutions business ($117 million), and the favorable impact of foreign currency translation ($6 million). Incremental sales resulted from the Tyco Merger, the impact of higher lead costs on pricing in the Power Solutions business and higher volumes across all Building Efficiency segments. Excluding the favorable impacts of the Tyco Merger and foreign currency translation, consolidated net sales increased 4% as compared to the prior year. Refer to the "Segment Analysis" below within Item 2 for a discussion of net sales by segment.

[0000833444-17-000016:mdna:26]
The increase in consolidated net sales for the six months ended March 31, 2017 was due to higher sales in the Building Technologies & Solutions business ($4,620 million) and the Power Solutions business ($288 million), and the favorable impact of foreign currency translation ($16 million). Incremental sales resulted from the Tyco Merger, the impact of higher lead costs on pricing and higher global shipments in the Power Solutions business, and higher volumes in the Building Efficiency Products North America and Asia segments. Excluding the favorable impacts of the Tyco Merger and foreign currency translation, consolidated net sales increased 3% as compared to the prior year. Refer to the "Segment Analysis" below within Item 2 for a discussion of net sales by segment.

[0000833444-17-000016:mdna:27]
[same as prior period, unchanged from 0000833444-17-000007:mdna:26]

[0000833444-17-000016:mdna:28]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Cost of sales | $ | 4,986 |  |  | $ | 3,446 |  |  | 45 | % |  | $ | 9,958 |  |  | $ | 6,885 |  |  | 45 | % |
| Gross profit | 2,281 |  |  | 1,287 |  |  | 77 | % |  | 4,395 |  |  | 2,544 |  |  | 73 | % |
| % of sales | 31.4 | % |  | 27.2 | % |  |  |  | 30.6 | % |  | 27.0 | % |  |  |

[0000833444-17-000016:mdna:29]
Cost of sales for the three month period ended March 31, 2017 increased as compared to the three month period ended March 31, 2016, and gross profit as a percentage of sales increased by 420 basis points. Gross profit in the Building Technologies & Solutions business increased due to the incremental gross profit related to the Tyco Merger and higher volumes across all Building Efficiency segments, partially offset by higher operating costs in the Building Efficiency Asia and Systems and Service North America segments as a result of product and channel investments as well as mix. Gross profit in the Power Solutions business was impacted by favorable pricing and product mix net of lead cost increases, partially offset by higher operating costs. Net mark-to-market adjustments on pension plans had a favorable impact on cost of sales of $5 million primarily due to favorable investment returns versus expectations. Foreign currency translation had a unfavorable impact on cost of sales of approximately $3 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment earnings before interest, taxes and amortization (EBITA) by segment.

[0000833444-17-000016:mdna:30]
Cost of sales for the six month period ended March 31, 2017 increased as compared to the six month period ended March 31, 2016, and gross profit as a percentage of sales increased by 360 basis points. Gross profit in the Building Technologies & Solutions business increased due to the incremental gross profit related to the Tyco Merger and lower operating costs in the Building Efficiency Products North America segment, partially offset by higher operating costs in the Building Efficiency Systems and Service North America and Asia segments. Gross profit in the Power Solutions business was impacted by favorable pricing and product mix net of lead cost increases, and higher volumes, partially offset by higher operating costs. Net mark-to-market adjustments on pension plans had a favorable impact on cost of sales of $15 million primarily due to an increase in discount rates. Foreign currency translation had a unfavorable impact on cost of sales of approximately $15 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-17-000016:mdna:31]
[same as prior period, unchanged from 0000833444-17-000007:mdna:29]

[0000833444-17-000016:mdna:32]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Selling, general and administrative expenses | $ | 1,726 |  |  | $ | 899 |  |  | 92 | % |  | $ | 3,296 |  |  | $ | 1,746 |  |  | 89 | % |
| % of sales | 23.8 | % |  | 19.0 | % |  |  |  | 23.0 | % |  | 18.5 | % |  |  |

[0000833444-17-000016:mdna:33]
Selling, general and administrative expenses (SG&A) for the three month period ended March 31, 2017 increased 92% as compared to the three month period ended March 31, 2016. The increase in SG&A was primarily due to incremental SG&A related to the Tyco Merger, partially offset by productivity savings and costs synergies as well as net mark-to-market adjustments on pension plans. The net mark-to-market adjustments had a favorable impact on SG&A of $13 million primarily due to favorable investment returns versus expectations. Foreign currency translation had an unfavorable impact on SG&A of $3 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-17-000016:mdna:34]
SG&A for the six month period ended March 31, 2017 increased 89% as compared to the six month period ended March 31, 2016. The increase in SG&A was primarily due to incremental SG&A related to the Tyco Merger, partially offset by productivity savings and costs synergies as well as net mark-to-market adjustments on pension plans. The net mark-to-market adjustments had a favorable impact on SG&A of $120 million primarily due to an increase in discount rates. Foreign currency translation had an unfavorable impact on SG&A of $7 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-17-000016:mdna:35]
[same as prior period, unchanged from 0000833444-17-000007:mdna:33]

[0000833444-17-000016:mdna:36]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Restructuring and impairment costs | $ | 99 |  |  | $ | 60 |  |  | 65 | % |  | $ | 177 |  |  | $ | 60 |  |  | * |

[0000833444-17-000016:mdna:37]
[same as prior period, unchanged from 0000833444-17-000007:mdna:35]

[0000833444-17-000016:mdna:38]
[same as prior period, unchanged from 0000833444-17-000007:mdna:36]

[0000833444-17-000016:mdna:39]
[same as prior period, unchanged from 0000833444-17-000007:mdna:37]

[0000833444-17-000016:mdna:40]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Net financing charges | $ | 116 |  |  | $ | 71 |  |  | 63 | % |  | $ | 252 |  |  | $ | 137 |  |  | 84 | % |

[0000833444-17-000016:mdna:41]
Net financing charges were higher for the three month period ended March 31, 2017 primarily due to higher interest rates and higher average borrowing levels as a result of the debt assumed with the Tyco Merger. Net financing charges were higher for the six month period ended March 31, 2017 primarily due to higher interest rates, higher average borrowing levels as a result of the debt assumed with the Tyco Merger and debt exchange offer fees.

[0000833444-17-000016:mdna:42]
[same as prior period, unchanged from 0000833444-17-000007:mdna:41]

[0000833444-17-000016:mdna:43]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Equity income | $ | 53 |  |  | $ | 40 |  |  | 33 | % |  | $ | 108 |  |  | $ | 82 |  |  | 32 | % |

[0000833444-17-000016:mdna:44]
The increase in equity income for the three and six months ended March 31, 2017 was primarily due to higher income at certain partially-owned affiliates of the Power Solutions business and the Johnson Controls - Hitachi (JCH) joint venture in the Building Technologies & Solutions business. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-17-000016:mdna:45]
Income Tax Provision

[0000833444-17-000016:mdna:46]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Income tax provision | $ | 508 |  |  | $ | 41 |  |  | * |  | $ | 481 |  |  | $ | 124 |  |  | * |
| Effective tax rate | 129 | % |  | 14 | % |  |  |  | 62 | % |  | 18 | % |  |  |

[0000833444-17-000016:mdna:47]
[same as prior period, unchanged from 0000833444-17-000007:mdna:39]

[0000833444-17-000016:mdna:48]
[same as prior period, unchanged from 0000833444-17-000007:mdna:47]

[0000833444-17-000016:mdna:49]
The U.S. federal statutory tax rate is being used as a comparison since the Company was a U.S. domiciled company for 11 months of 2016 and due to the Company's current legal entity structure. For the three months ended March 31, 2017, the Company's effective tax rate for continuing operations was 129%. The effective tax rate was higher than the U.S. federal statutory rate of 35% primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the pending divestiture of the Scott Safety business, the jurisdictional mix of significant restructuring and impairment costs, and Tyco Merger transaction and integration costs, partially offset by the benefits of continuing global tax planning initiatives and non-U.S. tax rate differentials. For the six months ended March 31, 2017, the Company's effective tax rate for continuing operations was 62%. The effective tax rate was higher than the U.S. federal statutory rate of 35% primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the pending divestiture of the Scott Safety business, the jurisdictional mix of significant restructuring and impairment costs, and Tyco Merger transaction / integration costs and purchase accounting impacts, partially offset by the benefits of continuing global tax planning initiatives, non-U.S. tax rate differentials and a tax benefit due to changes in entity tax status. For the three and six months ended March 31, 2016, the Company's effective tax rate for continuing operations was 14% and 18%, respectively. The effective rate was lower than the U.S. federal statutory rate of 35% primarily due to the benefits of continuing global tax planning initiatives and non-U.S. tax rate differentials. The effective tax rate for the six months ended March 31, 2017, increased as compared to the six months ended March 31, 2016, primarily due to the discrete tax items described below, partially offset by tax planning initiatives. The global tax planning initiatives related primarily to foreign tax credit planning, global financing structures and alignment of our global business functions in a tax efficient manner.

[0000833444-17-000016:mdna:50]
In the second quarter of fiscal 2017, the Company recorded a discrete non-cash tax charge of $457 million related to establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries of the Scott Safety business. This business is now reported as net assets held for sale given the announced sale to 3M Company in calendar 2017. Refer to Note 4, "Acquisitions and Divestitures" and Note 5, "Discontinued Operations," of the notes to consolidated financial statements for additional information.

[0000833444-17-000016:mdna:51]
In the second quarter of fiscal 2017, the Company recorded $138 million of transaction and integration costs which generated a $31 million tax benefit.

[0000833444-17-000016:mdna:52]
60

[0000833444-17-000016:mdna:53]
In the second quarter of fiscal 2017, the Company recorded $99 million of significant restructuring and impairment costs. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $20 million tax benefit, which was impacted by the Company’s current tax position in these jurisdictions.

[0000833444-17-000016:mdna:54]
[same as prior period, unchanged from 0000833444-17-000007:mdna:50]

[0000833444-17-000016:mdna:55]
[same as prior period, unchanged from 0000833444-17-000007:mdna:51]

[0000833444-17-000016:mdna:56]
In the first quarter of fiscal 2017, the Company recorded $78 million of significant restructuring and impairment costs. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $14 million tax benefit, which was impacted by the Company’s current tax position in these jurisdictions.

[0000833444-17-000016:mdna:57]
In the second quarter of fiscal 2016, the Company recorded $60 million of significant restructuring and impairment costs.  Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $12 million tax benefit, which was impacted by the geographic mix, the Company’s current tax position in these jurisdictions and the underlying tax basis in the impaired assets.

[0000833444-17-000016:mdna:58]
Loss From Discontinued Operations, Net of Tax

[0000833444-17-000016:mdna:59]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Loss from discontinued operations, net of tax | $ | — |  |  | $ | (725 | ) |  | * |  | $ | (34 | ) |  | $ | (538 | ) |  | * |

[0000833444-17-000016:mdna:60]
[same as prior period, unchanged from 0000833444-17-000007:mdna:46]

[0000833444-17-000016:mdna:61]
[same as prior period, unchanged from 0000833444-17-000007:mdna:56]

[0000833444-17-000016:mdna:62]
[same as prior period, unchanged from 0000833444-17-000007:mdna:57]

[0000833444-17-000016:mdna:63]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 33 |  |  | $ | 38 |  |  | -13 | % |  | $ | 73 |  |  | $ | 61 |  |  | 20 | % |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | 23 |  |  | * |  |  | 9 |  |  | 40 |  |  | -78 | % |

[0000833444-17-000016:mdna:64]
[same as prior period, unchanged from 0000833444-17-000007:mdna:55]

[0000833444-17-000016:mdna:65]
The decrease in income from continuing operations attributable to noncontrolling interests for the three months ended March 31, 2017, was primarily due to the mix of earnings and underlying tax rates related to the JCH joint venture in the Building Technologies & Solutions business. The increase in income from continuing operations attributable to noncontrolling interests for the six months ended March 31, 2017, was primarily due to higher net income related to the JCH joint venture in the Building Technologies & Solutions business.

[0000833444-17-000016:mdna:66]
[same as prior period, unchanged from 0000833444-17-000007:mdna:60]

[0000833444-17-000016:mdna:67]
61

[0000833444-17-000016:mdna:68]
Net Income (Loss) Attributable to Johnson Controls

[0000833444-17-000016:mdna:69]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Net income (loss) attributable to Johnson Controls | $ | (148 | ) |  | $ | (530 | ) |  | * |  | $ | 181 |  |  | $ | (80 | ) |  | * |

[0000833444-17-000016:mdna:70]
[same as prior period, unchanged from 0000833444-17-000007:mdna:63]

[0000833444-17-000016:mdna:71]
The increase in net income attributable to Johnson Controls for the three and six months ended March 31, 2017 was primarily due to incremental operating income as a result of the Tyco Merger and a prior year loss from discontinued operations, partially offset by an increase in the income tax provision and higher net financing charges. Diluted earnings (loss) per share attributable to Johnson Controls for the three months ended March 31, 2017 was $(0.16) compared to $(0.81) for the three months ended March 31, 2016. Diluted earnings (loss) per share attributable to Johnson Controls for the six months ended March 31, 2017 was $0.19 compared to $(0.12) for the six months ended March 31, 2016.

[0000833444-17-000016:mdna:72]
[same as prior period, unchanged from 0000833444-17-000007:mdna:65]

[0000833444-17-000016:mdna:73]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Comprehensive income (loss) attributable to Johnson Controls | $ | 98 |  |  | $ | (351 | ) |  | * |  | $ | (234 | ) |  | $ | (62 | ) |  | * |

[0000833444-17-000016:mdna:74]
[same as prior period, unchanged from 0000833444-17-000007:mdna:67]

[0000833444-17-000016:mdna:75]
The increase in comprehensive income attributable to Johnson Controls for the three months ended March 31, 2017 was primarily due to lower net loss attributable to Johnson Controls ($382 million) and an increase in other comprehensive income attributable to Johnson Controls ($67 million) resulting primarily from favorable foreign currency translation adjustments. These year-over-year favorable foreign currency translation adjustments were primarily driven by the strengthening of the Brazilian real, euro and Japanese yen currencies against the U.S. dollar.

[0000833444-17-000016:mdna:76]
The decrease in comprehensive income attributable to Johnson Controls for the six months ended March 31, 2017 was primarily due to an increase in other comprehensive loss attributable to Johnson Controls ($433 million) resulting primarily from unfavorable foreign currency translation adjustments, partially offset by higher net income attributable to Johnson Controls ($261 million). These year-over-year unfavorable foreign currency translation adjustments were primarily driven by the weakening of the British pound, euro and Japanese yen currencies against the U.S. dollar.

[0000833444-17-000016:mdna:77]
[same as prior period, unchanged from 0000833444-17-000007:mdna:69]

[0000833444-17-000016:mdna:78]
[same as prior period, unchanged from 0000833444-17-000007:mdna:70]

[0000833444-17-000016:mdna:79]
62

[0000833444-17-000016:mdna:80]
Building Technologies & Solutions - Net Sales

[0000833444-17-000016:mdna:81]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Building Efficiency |  |  |  |  |  |  |  |  |  |  |  |
| Systems and Service North America | $ | 1,047 |  |  | $ | 1,034 |  |  | 1 | % |  | $ | 1,975 |  |  | $ | 2,018 |  |  | -2 | % |
| Products North America | 585 |  |  | 546 |  |  | 7 | % |  | 1,128 |  |  | 1,103 |  |  | 2 | % |
| Asia | 1,173 |  |  | 1,162 |  |  | 1 | % |  | 2,215 |  |  | 2,154 |  |  | 3 | % |
| Rest of World | 424 |  |  | 408 |  |  | 4 | % |  | 822 |  |  | 831 |  |  | -1 | % |
|  | 3,229 |  |  | 3,150 |  |  | 3 | % |  | 6,140 |  |  | 6,106 |  |  | 1 | % |
| Tyco | 2,342 |  |  | — |  |  | * |  |  | 4,617 |  |  | — |  |  | * |  |
|  | $ | 5,571 |  |  | $ | 3,150 |  |  | 77 | % |  | $ | 10,757 |  |  | $ | 6,106 |  |  | 76 | % |

[0000833444-17-000016:mdna:82]
[same as prior period, unchanged from 0000833444-17-000007:mdna:73]

[0000833444-17-000016:mdna:83]
Three Months:

[0000833444-17-000016:mdna:84]
| • | The increase in Systems and Service North America was due to higher volumes of controls systems and service ($24 million), and the favorable impact of foreign currency translation ($3 million), partially offset by a prior year business divestiture ($14 million). The increase in volumes was primarily attributable to market share changes. |

[0000833444-17-000016:mdna:85]
| • | The increase in Products North America was due to higher volumes ($42 million), partially offset by a prior year business divestiture ($2 million) and the unfavorable impact of foreign currency translation ($1 million). The increase in volumes was primarily attributable to market share changes and new product offerings. |

[0000833444-17-000016:mdna:86]
| • | The increase in Asia was due to the favorable impact of foreign currency translation ($12 million) and higher service volumes ($10 million), partially offset by lower volumes related to a business deconsolidation ($11 million). The increase in volumes was primarily due to favorable local market conditions. |

[0000833444-17-000016:mdna:87]
| • | The increase in Rest of World was due to higher volumes in Europe ($23 million), the Middle East ($3 million) and Latin America ($3 million), partially offset by a prior year business divestiture ($9 million) and the unfavorable impact of foreign currency translation ($4 million). The increase in volumes was primarily due to favorable local market conditions. |

[0000833444-17-000016:mdna:88]
| • | The increase in Tyco was due to incremental sales related to the Tyco Merger ($2,342 million). |

[0000833444-17-000016:mdna:89]
Year-to-Date:

[0000833444-17-000016:mdna:90]
| • | The decrease in Systems and Service North America was due to a prior year business divestiture ($28 million), and lower volumes of controls systems and service ($18 million), partially offset by the favorable impact of foreign currency translation ($3 million). The decrease in volumes was primarily attributable to lower performance contracting activity. |

[0000833444-17-000016:mdna:91]
| • | The increase in Products North America was due to higher volumes ($32 million), partially offset by a prior year business divestiture ($5 million) and the unfavorable impact of foreign currency translation ($2 million). The increase in volumes was primarily attributable to market share changes and new product offerings. |

[0000833444-17-000016:mdna:92]
| • | The increase in Asia was due to the favorable impact of foreign currency translation ($41 million), higher service volumes ($21 million), and higher volumes of equipment and control systems ($17 million), partially offset by lower volumes related to a business deconsolidation ($18 million). The increase in volumes was primarily due to favorable local market conditions. |

[0000833444-17-000016:mdna:93]
| • | The decrease in Rest of World was due to lower volumes in the Middle East ($17 million), a prior year business divestiture ($16 million) and the unfavorable impact of foreign currency translation ($11 million), partially offset by higher volumes in Europe ($25 million) and Latin America ($10 million). |

[0000833444-17-000016:mdna:94]
| • | The increase in Tyco was due to incremental sales related to the Tyco Merger ($4,617 million). |

[0000833444-17-000016:mdna:95]
63

[0000833444-17-000016:mdna:96]
Building Technologies & Solutions - Segment EBITA

[0000833444-17-000016:mdna:97]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Building Efficiency |  |  |  |  |  |  |  |  |  |  |  |
| Systems and Service North America | $ | 90 |  |  | $ | 101 |  |  | -11 | % |  | $ | 165 |  |  | $ | 200 |  |  | -18 | % |
| Products North America | 57 |  |  | 47 |  |  | 21 | % |  | 94 |  |  | 80 |  |  | 18 | % |
| Asia | 118 |  |  | 118 |  |  | 0 | % |  | 237 |  |  | 188 |  |  | 26 | % |
| Rest of World | 9 |  |  | 10 |  |  | -10 | % |  | (1 | ) |  | 7 |  |  | * |  |
|  | 274 |  |  | 276 |  |  | -1 | % |  | 495 |  |  | 475 |  |  | 4 | % |
| Tyco | 379 |  |  | — |  |  | * |  |  | 593 |  |  | — |  |  | * |  |
|  | $ | 653 |  |  | $ | 276 |  |  | * |  |  | $ | 1,088 |  |  | $ | 475 |  |  | * |  |

[0000833444-17-000016:mdna:98]
[same as prior period, unchanged from 0000833444-17-000007:mdna:117]

[0000833444-17-000016:mdna:99]
Three Months:

[0000833444-17-000016:mdna:100]
| • | The decrease in Systems and Service North America was due to higher operating costs as a result of mix and channel investments ($19 million), current year transaction costs ($1 million) and a prior year business divestiture ($1 million), partially offset by higher volumes ($6 million), and lower selling, general and administrative expenses ($4 million). |

[0000833444-17-000016:mdna:101]
| • | The increase in Products North America was due to higher volumes ($11 million), lower operating costs ($6 million), and favorable pricing and mix ($3 million), partially offset by higher selling, general and administrative expenses ($4 million), current year integration costs ($3 million), current year transaction costs ($2 million) and the unfavorable impact of foreign currency translation ($1 million). |

[0000833444-17-000016:mdna:102]
| • | Asia was level with the prior year due to lower selling, general and administrative expenses as a result of productivity savings ($19 million), prior year integration costs ($5 million), higher volumes ($2 million), the favorable impact of foreign currency translation ($2 million), higher equity income ($1 million) and prior year transaction costs ($1 million), offset by higher operating costs due to mix and product investments ($30 million). |

[0000833444-17-000016:mdna:103]
| • | The decrease in Rest of World was due to a prior year gain on acquisition of a partially-owned affiliate ($4 million), higher operating costs ($2 million), lower equity income ($2 million), a prior year business divestiture ($1 million) and the unfavorable impact of foreign currency translation ($1 million), partially offset by higher volumes ($7 million), and lower selling, general and administrative expenses ($2 million). |

[0000833444-17-000016:mdna:104]
| • | The increase in Tyco was due to incremental operating income related to the Tyco Merger ($348 million) and the impact of nonrecurring purchasing accounting adjustments ($51 million), partially offset by current year integration costs ($14 million) and current year transaction costs ($6 million). |

[0000833444-17-000016:mdna:105]
Year-to-Date:

[0000833444-17-000016:mdna:106]
| • | The decrease in Systems and Service North America was due to higher operating costs as a result of mix and channel investments ($29 million), lower volumes ($6 million), current year integration costs ($3 million), current year transaction costs ($3 million) and a prior year business divestiture ($2 million), partially offset by lower selling, general and administrative expenses ($8 million). |

[0000833444-17-000016:mdna:107]
| • | The increase in Products North America was due to lower operating costs as a result of cost reduction initiatives ($15 million), higher volumes ($7 million), and favorable pricing and mix ($2 million), partially offset by current year integration costs ($4 million), current year transaction costs ($3 million), the unfavorable impact of foreign currency translation ($2 million) and lower equity income ($1 million). |

[0000833444-17-000016:mdna:108]
| • | The increase in Asia was due to lower selling, general and administrative expenses as a result of productivity savings ($26 million), higher equity income ($14 million), prior year transaction costs ($10 million), higher volumes ($9 million) and prior year integration costs ($8 million), partially offset by higher operating costs due to mix and product investments ($18 million). |

[0000833444-17-000016:mdna:109]
| • | The decrease in Rest of World was due to lower equity income ($8 million), a prior year gain on acquisition of a partially-owned affiliate ($4 million), higher operating costs ($3 million), the unfavorable impact of foreign currency translation ($2 million), a prior year business divestiture ($1 million) and current year integration costs ($1 million), partially offset by lower selling, general and administrative expenses ($9 million), and higher volumes ($2 million). |

[0000833444-17-000016:mdna:110]
| • | The increase in Tyco was due to incremental operating income related to the Tyco Merger ($697 million), partially offset by the impact of nonrecurring purchasing accounting adjustments ($61 million), current year integration costs ($23 million) and current year transaction costs ($20 million). |

[0000833444-17-000016:mdna:111]
[same as prior period, unchanged from 0000833444-17-000007:mdna:86]

[0000833444-17-000016:mdna:112]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Net sales | $ | 1,696 |  |  | $ | 1,583 |  |  | 7 | % |  | $ | 3,596 |  |  | $ | 3,323 |  |  | 8 | % |
| Segment EBITA | 303 |  |  | 282 |  |  | 7 | % |  | 692 |  |  | 642 |  |  | 8 | % |

[0000833444-17-000016:mdna:113]
Three Months:

[0000833444-17-000016:mdna:114]
| • | Net sales increased due to the impact of higher lead costs on pricing ($127 million), and favorable pricing and product mix ($30 million), partially offset by lower volumes ($40 million) and the unfavorable impact of foreign currency translation ($4 million). The decrease in volumes was driven by changes in customer demand patterns in North America and China, partially offset by an increase in start-stop battery volumes. Additionally, higher start-stop volumes contributed to favorable product mix. |

[0000833444-17-000016:mdna:115]
| • | Segment EBITA increased due to favorable pricing and product mix net of lead cost increases ($19 million), higher equity income ($14 million), and lower selling, general and administrative expenses as a result of productivity savings ($10 million), partially offset by lower volumes ($12 million) and higher operating costs ($10 million). |

[0000833444-17-000016:mdna:116]
Year-to-Date:

[0000833444-17-000016:mdna:117]
| • | Net sales increased due to the impact of higher lead costs on pricing ($174 million), favorable pricing and product mix ($58 million), and higher volumes ($56 million), partially offset by the unfavorable impact of foreign currency translation ($15 million). The increase in volumes was driven by start-stop battery volumes and growth in China. Additionally, higher start-stop volumes contributed to favorable product mix. |

[0000833444-17-000016:mdna:118]
| • | Segment EBITA increased due to favorable pricing and product mix net of lead cost increases ($40 million), higher equity income ($18 million), higher volumes ($15 million), and lower selling, general and administrative expenses as a result of productivity savings ($9 million), partially offset by higher operating costs primarily driven by efforts to satisfy growing customer demand ($29 million), the unfavorable impact of foreign currency translation ($2 million) and transaction costs ($1 million). |

[0000833444-17-000016:mdna:119]
[same as prior period, unchanged from 0000833444-17-000007:mdna:91]

[0000833444-17-000016:mdna:120]
The Company's backlog relating to the Building Technologies & Solutions business is applicable to its sales of systems and services. At March 31, 2017, the backlog was $8.3 billion and reflects harmonization of the Company's method for determining backlog subsequent to the Tyco Merger. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned during the fiscal year.

[0000833444-17-000016:mdna:121]
65

[0000833444-17-000016:mdna:122]
[same as prior period, unchanged from 0000833444-17-000007:mdna:93]

[0000833444-17-000016:mdna:123]
[same as prior period, unchanged from 0000833444-17-000007:mdna:94]

[0000833444-17-000016:mdna:124]
|  | March 31, |  | September 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Current assets | $ | 13,229 |  |  | $ | 17,109 |  |  |  |
| Current liabilities | (10,742 | ) |  | (16,331 | ) |  |  |
|  | 2,487 |  |  | 778 |  |  | * |  |
| Less: Cash | (412 | ) |  | (579 | ) |  |  |
| Add: Short-term debt | 1,124 |  |  | 1,078 |  |  |  |
| Add: Current portion of long-term debt | 542 |  |  | 628 |  |  |  |
| Less: Assets held for sale | (2,037 | ) |  | (5,812 | ) |  |  |
| Add: Liabilities held for sale | 237 |  |  | 4,276 |  |  |  |
| Working capital (as defined) | $ | 1,941 |  |  | $ | 369 |  |  | * |  |
| Accounts receivable - net | $ | 6,094 |  |  | $ | 6,394 |  |  | -5 | % |
| Inventories | 3,138 |  |  | 2,888 |  |  | 9 | % |
| Accounts payable | 3,720 |  |  | 4,000 |  |  | -7 | % |
| * Measure not meaningful |  |  |  |  |  |

[0000833444-17-000016:mdna:125]
[same as prior period, unchanged from 0000833444-17-000007:mdna:96]

[0000833444-17-000016:mdna:126]
| • | Excluding the impact of amounts classified as held for sale, the increase in working capital at March 31, 2017 as compared to September 30, 2016 was primarily due to income tax payments related to the Adient spin-off, a decrease in accounts payable due to timing of supplier payments and an increase in inventory due to changes in production levels. |

[0000833444-17-000016:mdna:127]
| • | The Company’s days sales in accounts receivable at March 31, 2017 were 65 days, higher than 61 days at September 30, 2016. There have been no significant adverse changes in the level of overdue receivables or changes in revenue recognition methods. |

[0000833444-17-000016:mdna:128]
| • | The Company’s inventory turns for the three months ended March 31, 2017 were lower than the comparable period ended September 30, 2016, primarily due to changes in inventory production levels. |

[0000833444-17-000016:mdna:129]
| • | Days in accounts payable at March 31, 2017 were 63 days, lower than 69 days at the comparable period ended September 30, 2016. |

[0000833444-17-000016:mdna:130]
[same as prior period, unchanged from 0000833444-17-000007:mdna:101]

[0000833444-17-000016:mdna:131]
|  | Six Months EndedMarch 31, |
| (in millions) | 2017 |  | 2016 |
| Cash provided (used) by operating activities | $ | (1,536 | ) |  | $ | 621 |  |
| Cash used by investing activities | (472 | ) |  | (617 | ) |
| Cash provided (used) by financing activities | 1,761 |  |  | (234 | ) |
| Capital expenditures | (634 | ) |  | (543 | ) |

[0000833444-17-000016:mdna:132]
| • | The increase in cash used by operating activities for the six months ended March 31, 2017 was primarily due to higher income tax payments primarily due to the Adient spin-off ($1.2 billion in the first quarter of fiscal 2017), and unfavorable changes in accounts payable and accrued liabilities, other assets and inventories. |

[0000833444-17-000016:mdna:133]
| • | The decrease in cash used by investing activities for the six months ended March 31, 2017 was primarily due to cash received from a business divestiture in the current year and cash paid for the JCH joint venture in the prior year, partially offset by an increase in capital expenditures. |

[0000833444-17-000016:mdna:134]
| • | The increase in cash provided by financing activities for the six months ended March 31, 2017 was primarily due to the dividend from the Adient spin-off and an increase in long-term debt, partially offset by a decrease in short-term debt and cash transferred to Adient related to the spin-off. |

[0000833444-17-000016:mdna:135]
| • | The increase in capital expenditures for the six months ended March 31, 2017 primarily relates to Tyco capital investments in the current year and higher capital investments in the Building Efficiency business. |

[0000833444-17-000016:mdna:136]
[same as prior period, unchanged from 0000833444-17-000007:mdna:107]

[0000833444-17-000016:mdna:137]
[same as prior period, unchanged from 0000833444-17-000007:mdna:108]

[0000833444-17-000016:mdna:138]
[same as prior period, unchanged from 0000833444-17-000007:mdna:109]

[0000833444-17-000016:mdna:139]
[same as prior period, unchanged from 0000833444-17-000007:mdna:110]

[0000833444-17-000016:mdna:140]
[same as prior period, unchanged from 0000833444-17-000007:mdna:111]

[0000833444-17-000016:mdna:141]
In the first and second quarters of fiscal 2017, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2017. As a result, the Company reviewed the long-lived assets for impairment and recorded $38 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income, of which $15 million was recorded in the first quarter and $23 million was recorded in the second quarter. Of the total impairment charges, $20 million related to the Building Efficiency Products North

[0000833444-17-000016:mdna:142]
America segment, $17 million related to Corporate assets and $1 million related to the Tyco segment. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000016:mdna:143]
In the second quarter of fiscal 2016, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2016. As a result, the Company reviewed the long-lived assets for impairment and recorded $15 million of asset impairment charge within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charge, $8 million related to the Building Efficiency Products North America segment, $4 million related to the Building Efficiency Asia segment and $3 million related to the Building Efficiency Rest of World segment. In addition, the Company recorded $14 million of asset impairments within discontinued operations related to Adient in the second quarter of fiscal 2016. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000016:mdna:144]
At March 31, 2017 and 2016, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets

[0000833444-17-000016:mdna:145]
[same as prior period, unchanged from 0000833444-17-000007:mdna:115]

[0000833444-17-000016:mdna:146]
|  | March 31, |  | September 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Short-term debt | $ | 1,124 |  |  | $ | 1,078 |  |  |  |
| Current portion of long-term debt | 542 |  |  | 628 |  |  |  |
| Long-term debt | 11,810 |  |  | 11,053 |  |  |  |
| Total debt | 13,476 |  |  | 12,759 |  |  | 6 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 19,388 |  |  | 24,118 |  |  | -20 | % |
| Total capitalization | $ | 32,864 |  |  | $ | 36,877 |  |  | -11 | % |
| Total debt as a % of total capitalization | 41 | % |  | 35 | % |  |  |

[0000833444-17-000016:mdna:147]
[same as prior period, unchanged from 0000833444-17-000007:mdna:118]

[0000833444-17-000016:mdna:148]
| • | Shareholders' equity attributable to Johnson Controls ordinary shareholders decreased as a result of the Adient spin-off in October 2016. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information. |

[0000833444-17-000016:mdna:149]
| • | In connection with the Tyco Merger, on December 28, 2016, the Company completed its offers to exchange all validly tendered and accepted notes of certain series (the "existing notes") issued by JCI Inc. or Tyco International Finance S.A. ("TIFSA"), as applicable, each of which is a wholly owned subsidiary of the Company, for new notes (the New Notes) to be issued by the Company, and the related solicitation of consents to amend the indentures governing the existing notes (the offers to exchange and the related consent solicitation together the "exchange offers"). Pursuant to the exchange offers, the Company exchanged approximately $5.6 billion of $6.0 billion in aggregate principal amount of dollar denominated notes and approximately 423 million euro of 500 million euro in aggregate principal amount of euro denominated notes. All validly tendered and accepted existing notes have been canceled. Immediately following such cancellation, $380.9 million aggregate principal amount of existing notes (not including the TIFSA Euro Notes) remained outstanding across seventeen series of dollar-denominated existing notes and 77.4 million euro aggregate principal amount of TIFSA Euro Notes remained outstanding |

[0000833444-17-000016:mdna:150]
68

[0000833444-17-000016:mdna:151]
across one series. In connection with the settlement of the exchange offers, the New Notes were registered under the Securities Act of 1933 and their terms are described in the Company’s Prospectus dated December 19, 2016, as filed with the SEC under Rule 424(b)(3) of the Act on that date. The issuance of the New Notes occurred on December 28, 2016. The New Notes are unsecured and unsubordinated obligations of the Company and will rank equally with all other unsecured and unsubordinated indebtedness of the Company issued from time to time.

[0000833444-17-000016:mdna:152]
| • | In March 2017, the Company issued one billion euro in principal amount of 1.0% senior unsecured fixed rate notes due in fiscal 2023. Proceeds from the issuance were used to repay existing debt and for other general corporate purposes. |

[0000833444-17-000016:mdna:153]
| • | In March 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in March 2018. As of March 31, 2017, there were no draws on the facility. |

[0000833444-17-000016:mdna:154]
| • | In March 2017, the Company retired $46 million in principal amount, plus accrued interest, of its 2.355% fixed rate notes that matured in March 2017. |

[0000833444-17-000016:mdna:155]
| • | In March 2017 and February 2017, the Company repurchased, at a discount, 15 million euro of its TIFSA 1.375% fixed rate notes, plus accrued interest, scheduled to mature in February 2025. |

[0000833444-17-000016:mdna:156]
| • | In February 2017, the Company issued $500 million aggregate principal amount of 4.5% senior unsecured fixed rate notes due in fiscal 2047. Proceeds from the issuance were used to repay outstanding commercial paper borrowings and for other general corporate purposes. |

[0000833444-17-000016:mdna:157]
| • | In February 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in February 2018. As of March 31, 2017, there were no draws on the facility. |

[0000833444-17-000016:mdna:158]
| • | In January 2017, the Company entered into a 364-day $250 million committed revolving credit facility scheduled to expire in January 2018. As of March 31, 2017, there were no draws on the facility outstanding. |

[0000833444-17-000016:mdna:159]
| • | In December 2016, the Company retired $400 million in principal amount, plus accrued interest, of its 2.6% fixed rate notes that matured in December 2016. |

[0000833444-17-000016:mdna:160]
| • | In December 2016, the Company entered into a 364-day 100 million euro floating rate term loan scheduled to mature in December 2017. Proceeds from the term loan were used for general corporate purposes. Principal and accrued interest were fully repaid in March 2017. |

[0000833444-17-000016:mdna:161]
| • | In December 2016, a $100 million committed revolving credit facility expired. There were no draws on the facility. |

[0000833444-17-000016:mdna:162]
[same as prior period, unchanged from 0000833444-17-000007:mdna:124]

[0000833444-17-000016:mdna:163]
| • | In November 2016, a $35 million committed revolving credit facility expired. There were no draws on the facility. |

[0000833444-17-000016:mdna:164]
| • | In October 2016, the Company repaid two ten-month floating rate term loans totaling $325 million, plus accrued interest, scheduled to mature in October 2016. |

[0000833444-17-000016:mdna:165]
[same as prior period, unchanged from 0000833444-17-000007:mdna:128]

[0000833444-17-000016:mdna:166]
[same as prior period, unchanged from 0000833444-17-000007:mdna:129]

[0000833444-17-000016:mdna:167]
| • | The Company also selectively makes use of short-term credit lines other than its revolving credit facilities at the Company and TSarl. The Company estimates that, as of March 31, 2017, it could borrow up to $1.4 billion based on average borrowing levels during the quarter on committed credit lines. |

[0000833444-17-000016:mdna:168]
| • | The Company believes its capital resources and liquidity position at March 31, 2017 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension |

[0000833444-17-000016:mdna:169]
69

[0000833444-17-000016:mdna:170]
contributions, debt maturities and any potential acquisitions in the remainder of fiscal 2017 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company and TSarl are unable to issue commercial paper, they would have the ability to draw on their $2.0 billion and $1.0 billion revolving credit facilities, respectively. Both facilities mature in August 2020. There were no draws on the revolving credit facility as of March 31, 2017 and September 30, 2016. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-17-000016:mdna:171]
| • | The Company earns a significant amount of its operating income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested. However, in fiscal 2017, the Company provided income tax expense related to a change in the Company’s assertion over the outside basis difference of the Scott Safety business as a result of the pending divestiture. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. However, in fiscal 2016, the Company did provide income tax expense related to a change in the Company's assertion over a portion of the permanently reinvested earnings as a result of the planned spin-off of the Automotive Experience business. Except as noted, the Company’s intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital in the U.S. than is generated by operations in the U.S., the Company could elect to raise capital in the U.S. through debt or equity issuances. In addition, should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. This alternative could result in increased interest expense or other dilution of the Company’s earnings. |

[0000833444-17-000016:mdna:172]
| • | The Company’s debt financial covenant in its revolving credit facility require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification (ASC) 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. TSarl's, revolving credit facility contains customary terms and conditions, and a financial covenant that limits the ratio of TSarl's debt to earnings before interest, taxes, depreciation, and amortization as adjusted for certain items set forth in the agreement to 3.5x. The TSarl's revolving credit facility also limits its ability to incur subsidiary debt or grant liens on its and its subsidiaries' property. As of March 31, 2017, the Company and TSarl were in compliance with all covenants and other requirements set forth in their credit agreements and the indentures, governing their notes, and expect to remain in compliance for the foreseeable future. None of the Company’s or TSarl's debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the respective borrower's credit rating. |

[0000833444-17-000016:mdna:173]
[same as prior period, unchanged from 0000833444-17-000007:mdna:134]

[0000833444-17-000016:mdna:174]
Recently Adopted Accounting Pronouncements

[0000833444-17-000016:mdna:175]
In October 2016, the FASB issued Accounting Standards Update (ASU) No. 2016-17, "Consolidations (Topic 810): Interests Held through Related Parties that are under Common Control." The ASU changes how a single decision maker of a VIE that holds indirect interest in the entity through related parties that are under common control determines whether it is the primary beneficiary of the VIE. The new guidance amends ASU 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis" issued in February 2015. ASU No. 2016-17 was effective for the Company for the quarter ending December 31, 2016. The adoption of this guidance did not have an impact on the Company's consolidated financial statements.

[0000833444-17-000016:mdna:176]
In May 2015, the FASB issued ASU No. 2015-07, "Disclosures for Investments in Certain Entities That Calculate Net Asset Value per Share (or Its Equivalent)." ASU No. 2015-07 removes the requirement to categorize within the fair value hierarchy all investments for which fair value is measured using the net asset value per share practical expedient. Such investments should be disclosed separate from the fair value hierarchy. ASU No. 2015-07 was effective retrospectively for the Company for the quarter ending December 31, 2016. The adoption of this guidance did not have an impact on the Company's consolidated financial statements, but did impact pension asset disclosures.

[0000833444-17-000016:mdna:177]
In April 2015, the FASB issued ASU No. 2015-03, "Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." ASU No. 2015-03 requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability. ASU No. 2015-03 was effective retrospectively for the Company for the quarter ending December 31, 2016. The adoption of this guidance did not have a significant impact on the Company's consolidated financial statements.

[0000833444-17-000016:mdna:178]
In February 2015, the FASB issued ASU No. 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis." ASU No. 2015-02 amends the analysis performed to determine whether a reporting entity should consolidate certain types of legal entities. ASU No. 2015-02 was effective retrospectively for the Company for the quarter ending December 31, 2016. The adoption of this guidance did not have an impact on the Company's consolidated financial statements.

[0000833444-17-000016:mdna:179]
Recently Issued Accounting Pronouncements

[0000833444-17-000016:mdna:180]
In March 2017, the FASB issued ASU No. 2017-07, "Compensation—Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost." The ASU requires the service cost component of net periodic benefit cost to be presented with other compensation costs. The other components of net periodic benefit cost are required to be presented in the income statement separately from the service cost component and outside a subtotal of income from operations, if one is presented. The ASU also allows only the service cost component of net periodic benefit cost to be eligible for capitalization. The guidance will be effective for the Company for the quarter ending December 31, 2018. Early adoption is permitted as of the beginning of an annual period for which financial statements (interim or annual) have not been issued or made available for issuance. The guidance will be effective retrospectively except for the capitalization of the service cost component which should be applied prospectively. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-17-000016:mdna:181]
In January 2017, the FASB issued ASU No. 2017-04, "Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment," which eliminates the requirement to calculate the implied fair value of goodwill to measure a goodwill impairment charge (Step 2) from the goodwill impairment test. Instead, an impairment charge will equal the amount by which a reporting unit’s carrying amount exceeds its fair value, not to exceed the amount of goodwill allocated to the reporting unit. The guidance will be effective prospectively for the Company for the quarter ending December 31, 2020, with early adoption permitted after January 1, 2017. The impact of this guidance for the Company will depend on the outcomes of future goodwill impairment tests.

[0000833444-17-000016:mdna:182]
In November 2016, the FASB issued ASU No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force)." The ASU requires amounts generally described as restricted cash and restricted cash equivalents to be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. The guidance will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted. The amendments in this update should be applied retrospectively to all periods presented. The impact of this guidance for the Company will depend on the levels of restricted cash balances in the periods presented.

[0000833444-17-000016:mdna:183]
In October 2016, the FASB issued ASU No. 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory." The ASU requires the tax effects of all intra-entity sales of assets other than inventory to be recognized in the period in which the transaction occurs. The guidance will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted but only in the first interim period of a fiscal year. The changes are required to be applied by means of a cumulative-effect adjustment recorded in retained earnings as of the beginning of the fiscal year of adoption. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000016:mdna:184]
In August 2016, the FASB issued ASU No. 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments." ASU No. 2016-15 provides clarification guidance on eight specific cash flow presentation issues in order to reduce the diversity in practice. ASU No. 2016-15 will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted. The guidance should be applied retrospectively to all periods presented, unless deemed impracticable, in which case prospective application is permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000016:mdna:185]
In June 2016, the FASB issued ASU No. 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments." ASU No. 2016-13 changes the impairment model for financial assets measured at amortized cost, requiring presentation at the net amount expected to be collected. The measurement of expected credit losses is based upon historical experience, current conditions, and reasonable and supportable forecasts. Available-for-sale debt securities with

[0000833444-17-000016:mdna:186]
71

[0000833444-17-000016:mdna:187]
unrealized losses will now be recorded through an allowance for credit losses. ASU No. 2016-13 will be effective for the Company for the quarter ended December 31, 2020, with early adoption permitted for the quarter ended December 31, 2019. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-17-000016:mdna:188]
In March 2016, the FASB issued ASU No. 2016-09, "Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." ASU No. 2016-09 impacts certain aspects of the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the statements of cash flows. ASU No. 2016-09 will be effective for the Company for the quarter ending December 31, 2017, with early adoption permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000016:mdna:189]
In March 2016, the FASB issued ASU No. 2016-07, "Investments - Equity Method and Joint Ventures (Topic 323): Simplifying the Transition to the Equity Method of Accounting." ASU No. 2016-07 eliminates the requirement for an investment that qualifies for the use of the equity method of accounting as a result of an increase in the level of ownership or degree of influence to adjust the investment, results of operations and retained earnings retrospectively. ASU No. 2016-07 will be effective prospectively for the Company for increases in the level of ownership interest or degree of influence that result in the adoption of the equity method that occur during or after the quarter ending December 31, 2017, with early adoption permitted. The impact of this guidance for the Company is dependent on any future increases in the level of ownership interest or degree of influence that result in the adoption of the equity method.

[0000833444-17-000016:mdna:190]
In February 2016, the FASB issued ASU No. 2016-02, "Leases (Topic 842)." ASU No. 2016-02 requires recognition of operating leases as lease assets and liabilities on the balance sheet, and disclosure of key information about leasing arrangements. ASU No. 2016-02 will be effective retrospectively for the Company for the quarter ending December 31, 2019, with early adoption permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.  The Company has started the assessment process by evaluating the population of leases under the revised definition of what qualifies as a leased asset. The Company is the lessee under various agreements for facilities and equipment that are currently accounted for as operating leases. The new guidance will require the Company to record operating leases on the balance sheet with a right-of-use asset and corresponding liability for future payment obligations. The Company expects the new guidance will have a material impact on its consolidated statements of financial position for the addition of right-of-use assets and lease liabilities, but the Company does not expect it to have a material impact on its consolidated statements of income.

[0000833444-17-000016:mdna:191]
In January 2016, the FASB issued ASU No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." ASU No. 2016-01 amends certain aspects of recognition, measurement, presentation and disclosure of financial instruments, including marketable securities. ASU No. 2016-01 will be effective for the Company for the quarter ending December 31, 2018, and early adoption is not permitted, with certain exceptions. The changes are required to be applied by means of a cumulative-effect adjustment on the balance sheet as of the beginning of the fiscal year of adoption. The impact of this guidance for the Company will depend on the magnitude of the unrealized gains and losses on the Company's marketable securities investments.

[0000833444-17-000016:mdna:192]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory." ASU No. 2015-11 requires inventory that is recorded using the first-in, first-out method to be measured at the lower of cost or net realizable value. ASU No. 2015-11 will be effective prospectively for the Company for the quarter ending December 31, 2017, with early adoption permitted. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-17-000016:mdna:193]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)." ASU No. 2014-09 clarifies the principles for recognizing revenue when an entity either enters into a contract with customers to transfer goods or services or enters into a contract for the transfer of non-financial assets. The original standard was effective retrospectively for the Company for the quarter ending December 31, 2017; however in August 2015, the FASB issued ASU No. 2015-14, "Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date," which defers the effective date of ASU No. 2014-09 by one-year for all entities. The new standard will become effective retrospectively for the Company for the quarter ending December 31, 2018, with early adoption permitted, but not before the original effective date. Additionally, in March 2016, the FASB issued ASU No. 2016-08, "Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net)," in April 2016, the FASB issued ASU No. 2016-10, "Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing," and in May 2016, the FASB issued ASU No. 2016-12, "Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients," and in December 2016, the FASB issued ASU No. 2016-20, "Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers," all of which provide additional clarification on certain topics addressed in ASU No. 2014-09. ASU No. 2016-08, ASU No. 2016-10, ASU No. 2016-12 and ASU No. 2016-20 follow the same implementation guidelines as ASU No. 2014-09 and ASU

[0000833444-17-000016:mdna:194]
No. 2015-14. The Company has elected to adopt the new revenue guidance as of October 1, 2018.  In preparation for adoption of the new guidance, the Company has reviewed representative samples of contracts and other forms of agreements with customers globally and is in the process of evaluating the impact of the new revenue standard. Based on its procedures to date, the Company cannot quantify the potential impact the new revenue standard will have to its consolidated financial statements.  The Company will decide which retrospective application to apply once its revenue standard assessment is finalized.
