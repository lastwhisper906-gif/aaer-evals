# JCI note change history — 0000833444-21-000020 → 0000833444-21-000040


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-07-30):
[0000833444-21-000040:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of June 30, 2021, reserves for environmental liabilities for continuing operations totaled $100 million, of which $50 million was recorded within other current liabilities and $50 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $130 million at September 30, 2020, of which $61 million was recorded within other current liabilities and $69 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.
  (was, 2021-04-30, similarity 0.9939):
[0000833444-21-000020:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of March 31, 2021, reserves for environmental liabilities for continuing operations totaled $112 million, of which $46 million was recorded within other current liabilities and $66 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $130 million at September 30, 2020, of which $61 million was recorded within other current liabilities and $69 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

- added (2021-07-30):
[0000833444-21-000040:note_history:2]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin. In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluoroalkyl substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.

- changed (2021-07-30):
[0000833444-21-000040:note_history:3]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.
  (was, 2021-04-30, similarity 0.7976):
[0000833444-21-000020:note_history:3]
order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

- changed (2021-07-30):
[0000833444-21-000040:note_history:4]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22,
  (was, 2021-04-30, similarity 0.6885):
[0000833444-21-000020:note_history:4]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation.

- added (2021-07-30):
[0000833444-21-000040:note_history:5]
2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation. On November 6, 2020, WDNR received further recommendations from WDHS regarding individual standards for 12 additional PFAS and a combined standard for four additional PFAS, PFOA, and PFOS.

- changed (2021-07-30):
[0000833444-21-000040:note_history:6]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).” The WDNR issued a further letter regarding the issue on November 4, 2019.  In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.
  (was, 2021-04-30, similarity 0.9993):
[0000833444-21-000020:note_history:6]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter.  The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).” The WDNR issued a further letter regarding the issue on November 4, 2019.  In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

- added (2021-07-30):
[0000833444-21-000040:note_history:7]
In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, WDNR approved Tyco Fire Products’ proposed Groundwater Extraction and Treatment System (“GETS”), a permanent groundwater remediation system that will extract groundwater that contains PFAS, treat it using advanced filtration systems, and return the treated water to the environment. Tyco Fire Products has commenced construction on the GETS. Tyco Fire Products also has started the process of removing PFAS-affected soil from the FTC.

- changed (2021-07-30):
[0000833444-21-000040:note_history:8]
In December 2020, the Company received a notice from the Wisconsin Department of Justice (“WDOJ”) that the WDOJ was considering a potential civil enforcement action against the Company relating to environmental matters at the FTC including, but not limited to, the investigation and remediation of PFAS at or near the FTC as discussed above and the Company’s alleged failure to timely report the presence of PFAS chemicals at the FTC. Such enforcement action could seek civil monetary penalties and/or injunctive relief. The Company is presently unable to predict the duration, scope, or results of any potential civil enforcement action that may result, the consequences of any such action, or the nature of any resolution of these potential claims with the WDOJ.
  (was, 2021-04-30, similarity 0.9818):
[0000833444-21-000020:note_history:8]
In December 2020, the Company received a notice from the Wisconsin Department of Justice (“WDOJ”) that the WDOJ was considering a potential civil enforcement action against the Company relating to environmental matters at the FTC including, but not limited to, the investigation and remediation of PFAS at or near the FTC as discussed in the prior paragraphs and the Company’s alleged failure to timely report the presence of PFAS chemicals at the FTC. Such enforcement action could seek civil monetary penalties and/or injunctive relief. The Company is presently unable to predict the duration, scope, or results of any potential civil enforcement action that may result, the consequences of any such action, or the nature of any resolution of these potential claims with the WDOJ.

- changed (2021-07-30):
[0000833444-21-000040:note_history:9]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and
  (was, 2021-04-30, similarity 0.8899):
[0000833444-21-000020:note_history:9]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to

- changed (2021-07-30):
[0000833444-21-000040:note_history:10]
risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At June 30, 2021 and September 30, 2020, the Company recorded conditional asset retirement obligations for continuing operations of $29 million and $29 million, respectively.
  (was, 2021-04-30, similarity 0.9467):
[0000833444-21-000020:note_history:10]
the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At March 31, 2021 and September 30, 2020, the Company recorded conditional asset retirement obligations for continuing operations of $29 million and $29 million, respectively.

- changed (2021-07-30):
[0000833444-21-000040:note_history:11]
As of June 30, 2021, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $78 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $466 million, of which $49 million was recorded in other current liabilities and $417 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $388 million, of which $19 million was recorded in other current assets, and $369 million was recorded in other noncurrent assets. Assets included $7 million of cash and $320 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at June 30, 2021 was $61 million. As of September 30, 2020, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $115 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $483 million, of which $49 million was recorded in other current liabilities and $434 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $368 million, of which $39 million was recorded in other current assets, and $329 million was recorded in other noncurrent assets. Assets included $9 million of cash and $291 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2020 was $68 million.
  (was, 2021-04-30, similarity 0.996):
[0000833444-21-000020:note_history:11]
As of March 31, 2021, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $93 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $470 million, of which $49 million was recorded in other current liabilities and $421 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $22 million was recorded in other current assets, and $355 million was recorded in other noncurrent assets. Assets included $11 million of cash and $304 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at March 31, 2021 was $62 million. As of September 30, 2020, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $115 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $483 million, of which $49 million was recorded in other current liabilities and $434 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $368 million, of which $39 million was recorded in other current assets, and $329 million was recorded in other noncurrent assets. Assets included $9 million of cash and $291 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2020 was $68 million.

- changed (2021-07-30):
[0000833444-21-000040:note_history:12]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At June 30, 2021 and September 30, 2020, the insurable liabilities totaled $359 million and $363 million, respectively, of which $89 million and $83 million was recorded within other current liabilities, $23 million and $22 million was recorded within accrued compensation and benefits, and $247 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at June 30, 2021 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2020 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.
  (was, 2021-04-30, similarity 0.9935):
[0000833444-21-000020:note_history:12]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At March 31, 2021 and September 30, 2020, the insurable liabilities totaled $366 million and $363 million, respectively, of which $90 million and $83 million was recorded within other current liabilities, $23 million and $22 million was recorded within accrued compensation and benefits, and $253 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at March 31, 2021 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2020 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

- added (2021-07-30):
[0000833444-21-000040:note_history:13]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

- added (2021-07-30):
[0000833444-21-000040:note_history:14]
PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. The EPA also announced in January 2021 that it will issue an advance notice of proposed rulemaking to solicit public comment on whether the agency should take additional regulatory steps to address PFAS contamination, including designating PFOA and PFOS and other PFAS as hazardous substances under the Comprehensive Environmental Response, Compensation, and Liability Act and seeking comment on whether PFOA and PFOS and other PFAS should be subject to regulation as hazardous waste under the Resource Conservation and Recovery

- added (2021-07-30):
[0000833444-21-000040:note_history:15]
Act. The Agency reissued those actions in February 2021. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

- changed (2021-07-30):
[0000833444-21-000040:note_history:16]
Chemguard and Tyco Fire Products are named in 32 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington, New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan, Texas and South Dakota. All of these cases except one have been direct-filed in or transferred to the MDL, with one recently-filed case expected to be transferred to the MDL shortly. Since the beginning of fiscal year 2021, three putative class actions (Jackson v. 3M Company, et al., direct filed on January 15, 2021 in the MDL pending in the United States District Court, District of South Carolina; Ogden v. Intercontinental Terminals Company LLC, et al., filed in the United States District Court, Southern District of Texas on January 27, 2021, and transferred to the MDL; Miller v. 3M Company et al., filed in the United States District Court, Northern District of West Virginia on July 8, 2021, and tagged to the MDL) have been filed against the Company.
  (was, 2021-04-30, similarity 0.7648):
[0000833444-21-000020:note_history:16]
Chemguard and Tyco Fire Products are named in 31 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington, New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan, Texas and South Dakota. All of these cases have been direct-filed in or transferred to the MDL. Since the beginning of fiscal year 2021, two putative class actions (Jackson v. 3M Company, et al., direct filed on January 15, 2021 in the MDL pending in the United States District Court, District of South Carolina; Ogden v. Intercontinental Terminals Company LLC, et al., filed in the United States District Court, Southern District of Texas on January 27, 2021, and tagged to the MDL) have been filed against the Company.

- added (2021-07-30):
[0000833444-21-000040:note_history:17]
There are approximately 1,270 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, and approximately 1,000 other plaintiffs. All but two of these matters have been transferred to or directly-filed in the MDL. One case, Young v. Chemguard et al., was filed in superior court in Maricopa County, Arizona, removed to the United States District Court, District of Arizona, and tagged to the MDL, but was remanded to state court prior to being transferred to the MDL. The decision to remand the case to state court is currently being appealed. Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court. The Company anticipates that the remainder of the possible individual product liability claims filed in Pennsylvania state court will either soon be filed in the MDL (and that all such claims in state court will be dismissed accordingly) or will be dismissed in Pennsylvania without a corresponding filing in South Carolina.

- changed (2021-07-30):
[0000833444-21-000040:note_history:18]
Chemguard and Tyco Fire Products have been named as defendants in 119 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Alabama, Arizona, California, Colorado, Florida, Idaho, Kentucky, Louisiana, Massachusetts, New Jersey, New York, Maryland, North Carolina, Ohio, Pennsylvania, Virginia, Washington, the District of Columbia and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but seven of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.
  (was, 2021-04-30, similarity 0.9953):
[0000833444-21-000020:note_history:18]
Chemguard and Tyco Fire Products have been named as defendants in 87 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Alabama, Arizona, California, Colorado, Florida, Idaho, Kentucky, Louisiana, Massachusetts, New Jersey, New York, Maryland, North Carolina, Ohio, Pennsylvania, Virginia, Washington, the District of Columbia and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but five of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.

- added (2021-07-30):
[0000833444-21-000040:note_history:19]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly

- changed (2021-07-30):
[0000833444-21-000040:note_history:20]
resulting from the use of those products at the Peterson Air Force Base. In May 2020, the Company was also notified by the Lakewood Water District in Pierce County, Washington that it may assert claims regarding remediation in connection with PFOA, PFOS, and other PFAS contamination allegedly resulting from the use of those products at Joint Base Lewis-McChord.
  (was, 2021-04-30, similarity 0.6175):
[0000833444-21-000020:note_history:20]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base. In May 2020, the Company was also notified by the Lakewood Water District in Pierce County, Washington that it may assert claims regarding remediation in connection with PFOA, PFOS, and other PFAS contamination allegedly resulting from the use of those products at Joint Base Lewis-McChord.

- changed (2021-07-30):
[0000833444-21-000040:note_history:21]
In August 2020, Attorney General of the State of Michigan filed two substantially similar lawsuits—one in federal court and one in state court—against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within the State. The federal action has been transferred to the MDL, and the state court action has been removed to federal court and transferred to the MDL.
  (was, 2021-04-30, similarity 0.9716):
[0000833444-21-000020:note_history:21]
In August 2020, Attorney General of the State of Michigan filed two substantially similar lawsuits—one in federal court and one in state court—against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within the State.  The federal action has been transferred to the MDL, and the state court action has been removed to federal court and tagged for transfer to the MDL.

- changed (2021-07-30):
[0000833444-21-000040:note_history:22]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. On January 7, 2021, the parties agreed to settle the lawsuit. The settlement provides that Tyco will pay up to $17.5 million to compensate Town of Peshtigo residents who live in the area affected by PFAS from the FTC for claims related to loss of real property value, exposure and/or personal injury. The settlement does not constitute an admission of wrongdoing by Tyco or Chemguard and is subject to approval by the federal court presiding over the lawsuit and other contingencies. The court conducted a hearing regarding the proposed settlement in May 2021; following this hearing the parties will submit for final approval an amended settlement agreement. The Company does not expect the settlement to have a significant impact on its fiscal year 2021 results of operations or cash flows.
  (was, 2021-04-30, similarity 0.8727):
[0000833444-21-000020:note_history:22]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. On January 7, 2021, the parties agreed to settle the lawsuit. The settlement provides that Tyco will pay up to $17.5 million to compensate Town of Peshtigo residents who live in the area affected by PFAS from the FTC for claims related to loss of real property value, exposure and/or personal injury. The settlement does not constitute an admission of wrongdoing by Tyco or Chemguard and is subject to approval by the federal court presiding over the lawsuit and other contingencies. The court is scheduled to conduct a hearing regarding the proposed settlement in May 2021. The Company does not expect the settlement to have a significant impact on its fiscal year 2021 results of operations or cash flows.

- removed (2021-07-30):
[0000833444-21-000020:note_history:23]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin. In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.

- removed (2021-07-30):
[0000833444-21-000020:note_history:24]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in

- removed (2021-07-30):
[0000833444-21-000020:note_history:25]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but had stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. The EPA also announced in January 2021 that it will issue an advance notice of proposed rulemaking to solicit public comment on whether the agency should take additional regulatory steps to address PFAS contamination, including designating PFOA and PFOS and other PFAS as hazardous substances under the Comprehensive Environmental Response, Compensation, and Liability Act and seeking comment on whether PFOA and PFOS and other PFAS should be subject to regulation as hazardous waste under the Resource Conservation and Recovery Act. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

- removed (2021-07-30):
[0000833444-21-000020:note_history:26]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

- removed (2021-07-30):
[0000833444-21-000020:note_history:27]
There are approximately 1,000 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, and approximately 1,000 other plaintiffs. All but five of these matters have been transferred to or directly-filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL.  Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court.  The Company anticipates that the remainder of the possible individual product liability claims filed in Pennsylvania state court will either soon be filed in the MDL (and that all such claims in state court will be dismissed accordingly) or will be dismissed in Pennsylvania without a corresponding filing in South Carolina.

- removed (2021-07-30):
[0000833444-21-000020:note_history:28]
In April 2020, the Weirton Area Water Board in West Virginia filed a lawsuit in the Circuit Court of Brooke County, West Virginia against a number of PFAS chemical manufacturers, including Chemguard, with respect to PFAS contamination. This case has been removed to the United States District Court for the Northern District of West Virginia and transferred to the MDL in the District of South Carolina.

- removed (2021-07-30):
[0000833444-21-000020:note_history:29]
A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-07-30):
[0000833444-21-000040:note_history:30]
Financial Statements
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2020 filed with the SEC on November 16, 2020. The results of operations for the three and nine month periods ended June 30, 2021 are not necessarily indicative of results for the Company’s 2021 fiscal year because of seasonal and other factors.
  (was, 2021-04-30, similarity 0.9791):
[0000833444-21-000020:note_history:30]
Financial Statements
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2020 filed with the SEC on November 16, 2020. The results of operations for the three and six month periods ended March 31, 2021 are not necessarily indicative of results for the Company’s 2021 fiscal year because of seasonal and other factors.

- changed (2021-07-30):
[0000833444-21-000040:note_history:31]
At June 30, 2021 and September 30, 2020, the Company held restricted cash of approximately $7 million and $9 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.
  (was, 2021-04-30, similarity 0.9856):
[0000833444-21-000020:note_history:31]
At March 31, 2021 and September 30, 2020, the Company held restricted cash of approximately $11 million and $9 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-07-30):
[0000833444-21-000040:note_history:32]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Interest expense, net of capitalized interest costs | $ | 55 |  |  | $ | 58 |  |  | $ | 167 |  |  | $ | 182 |  |
| Banking fees and bond cost amortization | 7 |  |  | 8 |  |  | 19 |  |  | 18 |  |
| Interest income | (1) |  |  | (3) |  |  | (7) |  |  | (21) |  |
| Net foreign exchange results for financing activities | (5) |  |  | (5) |  |  | (20) |  |  | (10) |  |
| Net financing charges | $ | 56 |  |  | $ | 58 |  |  | $ | 159 |  |  | $ | 169 |  |
  (was, 2021-04-30, similarity 0.9314):
[0000833444-21-000020:note_history:32]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Interest expense, net of capitalized interest costs | $ | 53 |  |  | $ | 62 |  |  | $ | 112 |  |  | $ | 124 |  |
| Banking fees and bond cost amortization | 4 |  |  | 5 |  |  | 12 |  |  | 10 |  |
| Interest income | (3) |  |  | (5) |  |  | (6) |  |  | (18) |  |
| Net foreign exchange results for financing activities | (10) |  |  | (3) |  |  | (15) |  |  | (5) |  |
| Net financing charges | $ | 44 |  |  | $ | 59 |  |  | $ | 103 |  |  | $ | 111 |  |

- changed (2021-07-30):
[0000833444-21-000040:note_history:33]
As of June 30, 2021, the Company has a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2021. As of June 30, 2021, there were no draws on the facilities.
  (was, 2021-04-30, similarity 0.9076):
[0000833444-21-000020:note_history:33]
As of March 31, 2021, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which was renewed in December 2020 and is now scheduled to expire in December 2021. As of March 31, 2021, there were no draws on the facilities.

- added (2021-07-30):
[0000833444-21-000040:note_history:34]
In July 2021, the Company issued a notice of redemption for all of its outstanding 3.75% senior notes maturing December 1, 2021. The notes have an aggregate principal amount of $171 million and will be redeemed on September 1, 2021.

- added (2021-07-30):
[0000833444-21-000040:note_history:35]
In May 2021, the Company retired €35 million in principal amount, plus accrued interest, of its 1.00% fixed rate notes expiring in September 2023.

- changed (2021-07-30):
[0000833444-21-000040:note_history:36]
In March 2021, the Company entered into a bank term loan arrangement totaling €200 million due in March 2022 and retired $257 million in principal amount, plus accrued interest, of its 4.25% fixed rate notes that expired in March 2021.
  (was, 2021-04-30, similarity 0.8249):
[0000833444-21-000020:note_history:36]
In March 2021, the Company entered into a bank term loan arrangement totaling $235 million due in March 2022 and retired $257 million in principal amount, plus accrued interest, of its 4.25% fixed rate notes that expired in March 2021.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-07-30):
[0000833444-21-000040:note_history:37]
The following table presents net sales to and purchases from related parties for the three and nine months ended June 30, 2021 and 2020 (in millions):
  (was, 2021-04-30, similarity 0.9507):
[0000833444-21-000020:note_history:37]
The following table presents net sales to and purchases from related parties for the three and six months ended March 31, 2021 and 2020 (in millions):

- changed (2021-07-30):
[0000833444-21-000040:note_history:38]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales to related parties |  | $ | 46 |  |  | $ | 52 |  |  | $ | 143 |  |  | $ | 135 |  |
| Purchases from related parties |  | 55 |  |  | 25 |  |  | 121 |  |  | 47 |  |
  (was, 2021-04-30, similarity 0.8637):
[0000833444-21-000020:note_history:38]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales to related parties |  | $ | 53 |  |  | $ | 38 |  |  | $ | 97 |  |  | $ | 83 |  |
| Purchases from related parties |  | 37 |  |  | 10 |  |  | 66 |  |  | 22 |  |

- changed (2021-07-30):
[0000833444-21-000040:note_history:39]
|  |  | June 30, 2021 |  | September 30, 2020 |
| Receivable from related parties |  | $ | 73 |  |  | $ | 48 |  |
| Payable to related parties |  | 33 |  |  | 11 |  |
  (was, 2021-04-30, similarity 0.9682):
[0000833444-21-000020:note_history:39]
|  |  | March 31, 2021 |  | September 30, 2020 |
| Receivable from related parties |  | $ | 62 |  |  | $ | 48 |  |
| Payable to related parties |  | 19 |  |  | 11 |  |

- added (2021-07-30):
[0000833444-21-000040:note_history:40]
Additionally, the Company leases certain facilities used in its operations from a related party. As of June 30, 2021, the right-of-use asset associated with these leases was $12 million and the lease liability was $11 million. Amounts paid for these leases were not material.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-07-30):
[0000833444-21-000040:note_history:41]
The following table presents net sales to and purchases from related parties for the three and nine months ended June 30, 2021 and 2020 (in millions):
  (was, 2021-04-30, similarity 0.9507):
[0000833444-21-000020:note_history:41]
The following table presents net sales to and purchases from related parties for the three and six months ended March 31, 2021 and 2020 (in millions):

- changed (2021-07-30):
[0000833444-21-000040:note_history:42]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales to related parties |  | $ | 46 |  |  | $ | 52 |  |  | $ | 143 |  |  | $ | 135 |  |
| Purchases from related parties |  | 55 |  |  | 25 |  |  | 121 |  |  | 47 |  |
  (was, 2021-04-30, similarity 0.8637):
[0000833444-21-000020:note_history:42]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales to related parties |  | $ | 53 |  |  | $ | 38 |  |  | $ | 97 |  |  | $ | 83 |  |
| Purchases from related parties |  | 37 |  |  | 10 |  |  | 66 |  |  | 22 |  |

- changed (2021-07-30):
[0000833444-21-000040:note_history:43]
|  |  | June 30, 2021 |  | September 30, 2020 |
| Receivable from related parties |  | $ | 73 |  |  | $ | 48 |  |
| Payable to related parties |  | 33 |  |  | 11 |  |
  (was, 2021-04-30, similarity 0.9682):
[0000833444-21-000020:note_history:43]
|  |  | March 31, 2021 |  | September 30, 2020 |
| Receivable from related parties |  | $ | 62 |  |  | $ | 48 |  |
| Payable to related parties |  | 19 |  |  | 11 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-07-30):
[0000833444-21-000040:note_history:44]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and nine months ended June 30, 2021 and 2020 (in millions):
  (was, 2021-04-30, similarity 0.9639):
[0000833444-21-000020:note_history:44]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and six months ended March 31, 2021 and 2020 (in millions):

- changed (2021-07-30):
[0000833444-21-000040:note_history:45]
|  |  | Three Months Ended June 30, 2021 |  | Three Months Ended June 30, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,355 |  |  | $ | 857 |  |  | $ | 2,212 |  |  | $ | 1,250 |  |  | $ | 770 |  |  | $ | 2,020 |  |
| Building Solutions EMEA/LA |  | 468 |  |  | 494 |  |  | 962 |  |  | 346 |  |  | 410 |  |  | 756 |  |
| Building Solutions Asia Pacific |  | 422 |  |  | 290 |  |  | 712 |  |  | 344 |  |  | 244 |  |  | 588 |  |
| Global Products |  | 2,455 |  |  | — |  |  | 2,455 |  |  | 1,979 |  |  | — |  |  | 1,979 |  |
| Total |  | $ | 4,700 |  |  | $ | 1,641 |  |  | $ | 6,341 |  |  | $ | 3,919 |  |  | $ | 1,424 |  |  | $ | 5,343 |  |
  (was, 2021-04-30, similarity 0.9369):
[0000833444-21-000020:note_history:45]
|  |  | Three Months Ended March 31, 2021 |  | Three Months Ended March 31, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,272 |  |  | $ | 820 |  |  | $ | 2,092 |  |  | $ | 1,357 |  |  | $ | 818 |  |  | $ | 2,175 |  |
| Building Solutions EMEA/LA |  | 429 |  |  | 468 |  |  | 897 |  |  | 400 |  |  | 450 |  |  | 850 |  |
| Building Solutions Asia Pacific |  | 329 |  |  | 274 |  |  | 603 |  |  | 271 |  |  | 254 |  |  | 525 |  |
| Global Products |  | 2,002 |  |  | — |  |  | 2,002 |  |  | 1,894 |  |  | — |  |  | 1,894 |  |
| Total |  | $ | 4,032 |  |  | $ | 1,562 |  |  | $ | 5,594 |  |  | $ | 3,922 |  |  | $ | 1,522 |  |  | $ | 5,444 |  |

- changed (2021-07-30):
[0000833444-21-000040:note_history:46]
|  |  | Nine Months Ended June 30, 2021 |  | Nine Months Ended June 30, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,869 |  |  | $ | 2,469 |  |  | $ | 6,338 |  |  | $ | 3,963 |  |  | $ | 2,399 |  |  | $ | 6,362 |  |
| Building Solutions EMEA/LA |  | 1,323 |  |  | 1,442 |  |  | 2,765 |  |  | 1,203 |  |  | 1,331 |  |  | 2,534 |  |
| Building Solutions Asia Pacific |  | 1,096 |  |  | 834 |  |  | 1,930 |  |  | 986 |  |  | 756 |  |  | 1,742 |  |
| Global Products |  | 6,243 |  |  | — |  |  | 6,243 |  |  | 5,725 |  |  | — |  |  | 5,725 |  |
| Total |  | $ | 12,531 |  |  | $ | 4,745 |  |  | $ | 17,276 |  |  | $ | 11,877 |  |  | $ | 4,486 |  |  | $ | 16,363 |  |
  (was, 2021-04-30, similarity 0.9348):
[0000833444-21-000020:note_history:46]
|  |  | Six Months Ended March 31, 2021 |  | Six Months Ended March 31, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 2,514 |  |  | $ | 1,612 |  |  | $ | 4,126 |  |  | $ | 2,713 |  |  | $ | 1,629 |  |  | $ | 4,342 |  |
| Building Solutions EMEA/LA |  | 855 |  |  | 948 |  |  | 1,803 |  |  | 857 |  |  | 921 |  |  | 1,778 |  |
| Building Solutions Asia Pacific |  | 674 |  |  | 544 |  |  | 1,218 |  |  | 642 |  |  | 512 |  |  | 1,154 |  |
| Global Products |  | 3,788 |  |  | — |  |  | 3,788 |  |  | 3,746 |  |  | — |  |  | 3,746 |  |
| Total |  | $ | 7,831 |  |  | $ | 3,104 |  |  | $ | 10,935 |  |  | $ | 7,958 |  |  | $ | 3,062 |  |  | $ | 11,020 |  |

- changed (2021-07-30):
[0000833444-21-000040:note_history:47]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and nine months ended June 30, 2021 and 2020 (in millions):
  (was, 2021-04-30, similarity 0.9586):
[0000833444-21-000020:note_history:47]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and six months ended March 31, 2021 and 2020 (in millions):

- changed (2021-07-30):
[0000833444-21-000040:note_history:48]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 1,811 |  |  | $ | 1,503 |  |  | $ | 4,462 |  |  | $ | 4,127 |  |
| Fire & Security |  | 580 |  |  | 422 |  |  | 1,605 |  |  | 1,425 |  |
| Industrial Refrigeration |  | 64 |  |  | 54 |  |  | 176 |  |  | 173 |  |
| Total |  | $ | 2,455 |  |  | $ | 1,979 |  |  | $ | 6,243 |  |  | $ | 5,725 |  |
  (was, 2021-04-30, similarity 0.9388):
[0000833444-21-000020:note_history:48]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 1,402 |  |  | $ | 1,324 |  |  | $ | 2,651 |  |  | $ | 2,624 |  |
| Fire & Security |  | 537 |  |  | 511 |  |  | 1,025 |  |  | 1,003 |  |
| Industrial Refrigeration |  | 63 |  |  | 59 |  |  | 112 |  |  | 119 |  |
| Total |  | $ | 2,002 |  |  | $ | 1,894 |  |  | $ | 3,788 |  |  | $ | 3,746 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-07-30):
[0000833444-21-000040:note_history:49]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and nine months ended June 30, 2021 and 2020 (in millions):
  (was, 2021-04-30, similarity 0.9639):
[0000833444-21-000020:note_history:49]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and six months ended March 31, 2021 and 2020 (in millions):

- changed (2021-07-30):
[0000833444-21-000040:note_history:50]
|  |  | Three Months Ended June 30, 2021 |  | Three Months Ended June 30, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,355 |  |  | $ | 857 |  |  | $ | 2,212 |  |  | $ | 1,250 |  |  | $ | 770 |  |  | $ | 2,020 |  |
| Building Solutions EMEA/LA |  | 468 |  |  | 494 |  |  | 962 |  |  | 346 |  |  | 410 |  |  | 756 |  |
| Building Solutions Asia Pacific |  | 422 |  |  | 290 |  |  | 712 |  |  | 344 |  |  | 244 |  |  | 588 |  |
| Global Products |  | 2,455 |  |  | — |  |  | 2,455 |  |  | 1,979 |  |  | — |  |  | 1,979 |  |
| Total |  | $ | 4,700 |  |  | $ | 1,641 |  |  | $ | 6,341 |  |  | $ | 3,919 |  |  | $ | 1,424 |  |  | $ | 5,343 |  |
  (was, 2021-04-30, similarity 0.9369):
[0000833444-21-000020:note_history:50]
|  |  | Three Months Ended March 31, 2021 |  | Three Months Ended March 31, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,272 |  |  | $ | 820 |  |  | $ | 2,092 |  |  | $ | 1,357 |  |  | $ | 818 |  |  | $ | 2,175 |  |
| Building Solutions EMEA/LA |  | 429 |  |  | 468 |  |  | 897 |  |  | 400 |  |  | 450 |  |  | 850 |  |
| Building Solutions Asia Pacific |  | 329 |  |  | 274 |  |  | 603 |  |  | 271 |  |  | 254 |  |  | 525 |  |
| Global Products |  | 2,002 |  |  | — |  |  | 2,002 |  |  | 1,894 |  |  | — |  |  | 1,894 |  |
| Total |  | $ | 4,032 |  |  | $ | 1,562 |  |  | $ | 5,594 |  |  | $ | 3,922 |  |  | $ | 1,522 |  |  | $ | 5,444 |  |

- changed (2021-07-30):
[0000833444-21-000040:note_history:51]
|  |  | Nine Months Ended June 30, 2021 |  | Nine Months Ended June 30, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,869 |  |  | $ | 2,469 |  |  | $ | 6,338 |  |  | $ | 3,963 |  |  | $ | 2,399 |  |  | $ | 6,362 |  |
| Building Solutions EMEA/LA |  | 1,323 |  |  | 1,442 |  |  | 2,765 |  |  | 1,203 |  |  | 1,331 |  |  | 2,534 |  |
| Building Solutions Asia Pacific |  | 1,096 |  |  | 834 |  |  | 1,930 |  |  | 986 |  |  | 756 |  |  | 1,742 |  |
| Global Products |  | 6,243 |  |  | — |  |  | 6,243 |  |  | 5,725 |  |  | — |  |  | 5,725 |  |
| Total |  | $ | 12,531 |  |  | $ | 4,745 |  |  | $ | 17,276 |  |  | $ | 11,877 |  |  | $ | 4,486 |  |  | $ | 16,363 |  |
  (was, 2021-04-30, similarity 0.9348):
[0000833444-21-000020:note_history:51]
|  |  | Six Months Ended March 31, 2021 |  | Six Months Ended March 31, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 2,514 |  |  | $ | 1,612 |  |  | $ | 4,126 |  |  | $ | 2,713 |  |  | $ | 1,629 |  |  | $ | 4,342 |  |
| Building Solutions EMEA/LA |  | 855 |  |  | 948 |  |  | 1,803 |  |  | 857 |  |  | 921 |  |  | 1,778 |  |
| Building Solutions Asia Pacific |  | 674 |  |  | 544 |  |  | 1,218 |  |  | 642 |  |  | 512 |  |  | 1,154 |  |
| Global Products |  | 3,788 |  |  | — |  |  | 3,788 |  |  | 3,746 |  |  | — |  |  | 3,746 |  |
| Total |  | $ | 7,831 |  |  | $ | 3,104 |  |  | $ | 10,935 |  |  | $ | 7,958 |  |  | $ | 3,062 |  |  | $ | 11,020 |  |

- changed (2021-07-30):
[0000833444-21-000040:note_history:52]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and nine months ended June 30, 2021 and 2020 (in millions):
  (was, 2021-04-30, similarity 0.9586):
[0000833444-21-000020:note_history:52]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and six months ended March 31, 2021 and 2020 (in millions):

- changed (2021-07-30):
[0000833444-21-000040:note_history:53]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 1,811 |  |  | $ | 1,503 |  |  | $ | 4,462 |  |  | $ | 4,127 |  |
| Fire & Security |  | 580 |  |  | 422 |  |  | 1,605 |  |  | 1,425 |  |
| Industrial Refrigeration |  | 64 |  |  | 54 |  |  | 176 |  |  | 173 |  |
| Total |  | $ | 2,455 |  |  | $ | 1,979 |  |  | $ | 6,243 |  |  | $ | 5,725 |  |
  (was, 2021-04-30, similarity 0.9388):
[0000833444-21-000020:note_history:53]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 1,402 |  |  | $ | 1,324 |  |  | $ | 2,651 |  |  | $ | 2,624 |  |
| Fire & Security |  | 537 |  |  | 511 |  |  | 1,025 |  |  | 1,003 |  |
| Industrial Refrigeration |  | 63 |  |  | 59 |  |  | 112 |  |  | 119 |  |
| Total |  | $ | 2,002 |  |  | $ | 1,894 |  |  | $ | 3,788 |  |  | $ | 3,746 |  |

- changed (2021-07-30):
[0000833444-21-000040:note_history:54]
|  |  | Location of contract balances |  | June 30, 2021 |  | September 30, 2020 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,553 |  |  | $ | 1,395 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 95 |  |  | 104 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,649) |  |  | (1,435) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (263) |  |  | (245) |  |  |  |
| Total |  |  |  | $ | (264) |  |  | $ | (181) |  |  |  |
  (was, 2021-04-30, similarity 0.9903):
[0000833444-21-000020:note_history:54]
|  |  | Location of contract balances |  | March 31, 2021 |  | September 30, 2020 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,387 |  |  | $ | 1,395 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 102 |  |  | 104 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,710) |  |  | (1,435) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (258) |  |  | (245) |  |  |  |
| Total |  |  |  | $ | (479) |  |  | $ | (181) |  |  |  |

- added (2021-07-30):
[0000833444-21-000040:note_history:55]
For the three months ended June 30, 2021 and June 30, 2020, the Company recognized revenue of $149 million and $125 million, respectively, that was included in the beginning of period contract liability balance. For the nine months ended June 30, 2021 and June 30, 2020, the Company recognized revenue of $1,084 million and $1,137 million, respectively, that was included in the beginning of period contract liability balance.

- changed (2021-07-30):
[0000833444-21-000040:note_history:56]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of June 30, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $15.6 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.
  (was, 2021-04-30, similarity 0.9954):
[0000833444-21-000020:note_history:56]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of March 31, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $15.0 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

- added (2021-07-30):
[0000833444-21-000040:note_history:57]
As of June 30, 2021, the Company recorded the costs to obtain or fulfill a contract of $258 million, of which $143 million is recorded within other current assets and $115 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2020, the Company recorded the costs to obtain or fulfill a contract of $223 million, of which $119 million is recorded within other current assets and $104 million is recorded within other noncurrent assets in the consolidated statements of financial position.

- changed (2021-07-30):
[0000833444-21-000040:note_history:58]
During the three months ended June 30, 2021 and 2020, the Company recognized amortization expense of $48 million and $47 million, respectively, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2021 and 2020, the Company recognized amortization expense of $136 million and $116 million, respectively, related to costs to 
obtain or fulfill a contract. There were no impairment losses recognized in the three and nine months ended June 30, 2021 and 2020.
  (was, 2021-04-30, similarity 0.8721):
[0000833444-21-000020:note_history:58]
During the three months ended March 31, 2021 and 2020, the Company recognized amortization expense of $47 million and $43 million, respectively, related to costs to obtain or fulfill a contract. During the six months ended March 31, 2021 and 2020, the Company recognized amortization expense of $88 million and $69 million, respectively, related to costs to 
obtain or fulfill a contract. There were no impairment losses recognized in the three and six months ended March 31, 2021 and 2020.

- removed (2021-07-30):
[0000833444-21-000020:note_history:59]
For the three months ended March 31, 2021 and March 31, 2020, the Company recognized revenue of $221 million and $326 million, respectively, that was included in the beginning of period contract liability balance. For the six months ended March 31, 2021 and March 31, 2020, the Company recognized revenue of $935 million and $1,012 million, respectively, that was included in the beginning of period contract liability balance.

- removed (2021-07-30):
[0000833444-21-000020:note_history:60]
As of March 31, 2021, the Company recorded the costs to obtain or fulfill a contract of $241 million, of which $130 million is recorded within other current assets and $111 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2020, the Company recorded the costs to obtain or fulfill a contract of $223 million, of which $119 million is recorded within other current assets and $104 million is recorded within other noncurrent assets in the consolidated statements of financial position.
