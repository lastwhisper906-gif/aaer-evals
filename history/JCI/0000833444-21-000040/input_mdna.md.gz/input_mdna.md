# JCI MD&A — 0000833444-21-000040


## mdna

[0000833444-21-000040:mdna:1]
[same as prior period, unchanged from 0000833444-21-000020:mdna:1]

[0000833444-21-000040:mdna:2]
[same as prior period, unchanged from 0000833444-21-000020:mdna:2]

[0000833444-21-000040:mdna:3]
[same as prior period, unchanged from 0000833444-21-000020:mdna:3]

[0000833444-21-000040:mdna:4]
[same as prior period, unchanged from 0000833444-21-000020:mdna:4]

[0000833444-21-000040:mdna:5]
[same as prior period, unchanged from 0000833444-21-000020:mdna:5]

[0000833444-21-000040:mdna:6]
[same as prior period, unchanged from 0000833444-21-000020:mdna:6]

[0000833444-21-000040:mdna:7]
45

[0000833444-21-000040:mdna:8]
[same as prior period, unchanged from 0000833444-21-000020:mdna:7]

[0000833444-21-000040:mdna:9]
[same as prior period, unchanged from 0000833444-21-000020:mdna:8]

[0000833444-21-000040:mdna:10]
[same as prior period, unchanged from 0000833444-21-000020:mdna:9]

[0000833444-21-000040:mdna:11]
The following information should be read in conjunction with the September 30, 2020 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2020 filed with the SEC on November 16, 2020. References in the following discussion and analysis to "Three Months" (or similar language) refer to the three months ended June 30, 2021 compared to the three months ended June 30, 2020, while "Year-to-Date" refers to the nine months ended June 30, 2021 compared to the nine months ended June 30, 2020.

[0000833444-21-000040:mdna:12]
[same as prior period, unchanged from 0000833444-21-000020:mdna:11]

[0000833444-21-000040:mdna:13]
The global outbreak of COVID-19 severely restricted the level of economic activity around the world and caused a significant contraction in the global economy. The Company’s affiliates, employees, suppliers, customers and others have been and may continue to be restricted or prevented from conducting normal business activities, including as a result of shutdowns, travel restrictions and other actions that may be requested or mandated by governmental authorities. Although shutdown orders and similar restrictions have been lifted in many jurisdictions in conjunction with the global distribution of vaccines, challenges in achieving sufficient vaccination levels and the spread of new variants of COVID-19 have caused some governments to extend or reinstitute restrictions in impacted areas. While a substantial portion of the Company's businesses have been classified as essential businesses in jurisdictions in which facility closures have been mandated, some of its facilities have at times nevertheless been ordered to close, and we can give no assurance that there will not be additional closures in the future or that the Company's businesses will be classified as essential in each of the jurisdictions in which it operates.

[0000833444-21-000040:mdna:14]
In response to the challenges presented by COVID-19, the Company has focused its efforts on preserving the health and safety of its employees and customers, as well as maintaining the continuity of its operations. The Company modified its business practices in response to the COVID-19 outbreak, including restricting non-essential employee travel, implementation of remote work protocols, and limiting physical participation in meetings, events and conferences. The Company also instituted preventive measures at its facilities, including enhanced health and safety protocols, temperature screening, requiring face coverings for all unvaccinated employees and encouraging employees to follow similar protocols when away from work. The Company has adopted a multifaceted framework to guide its decision making as it reopens its offices and facilities to employees, and will continue to monitor and audit its facilities to ensure that they are in compliance with the Company’s COVID-19 safety requirements.

[0000833444-21-000040:mdna:15]
The Company initially experienced a decline in demand and volumes in its global businesses as a result of the impact of efforts to contain the spread of COVID-19. Specifically, the Company experienced lower demand due to restricted access to customer sites to perform service and installation work as well as reduced discretionary capital spending by the Company's customers. In fiscal 2021, the Company has experienced increases in both demand and volumes as governments have distributed vaccines and lifted COVID-19-related restrictions, leading to increases in retrofit activity and, to a lesser extent, commercial building construction. The global pandemic has also provided the Company with the opportunity to help its customers prepare to re-open by delivering solutions and support that enhance the safety and increase the efficiency of their operations. As a result of the pandemic, the Company has seen an increase in demand for its products and solutions that promote building health and

[0000833444-21-000040:mdna:16]
optimize customers’ infrastructure, including thermal cameras, indoor air quality, location-based services for contact tracing and touchless access control.

[0000833444-21-000040:mdna:17]
However, the Company continues to be influenced by COVID-19 related trends impacting site access, the labor force and the global supply chain, which have and may continue to negatively impact the Company’s revenues and margins.  Challenges in achieving sufficient vaccination levels to achieve herd immunity and the introduction of new variants of COVID-19 have caused some governments to extend or reinstitute lockdowns and similar restrictive measures, which, in some cases, have limited the Company’s ability to access customer sites to install and maintain its products and deliver services. In addition, the Company has experienced and continues to experience labor shortages at certain facilities as the Company expands its production capacity to meet increased customer demand. Although the Company is mitigating these shortages through focused recruitment efforts and competitive compensation packages, the Company could continue to experience such shortages in the future. In addition, the Company has experienced, and expects to continue to experience, increased input material costs and component shortages, as well as disruptions and delays in its supply chain, as a result of government-mandated actions and increased demand. While actions taken by the Company to mitigate supply chain issues, including expanding and redistributing its supplier network, supplier financing, price increases and productivity improvements, have generally been successful in mitigating these trends, the Company could experience further disruptions, shortages and price increases in the future.

[0000833444-21-000040:mdna:18]
In the third and fourth quarter of fiscal 2020, the Company executed temporary and permanent cost mitigation actions to offset a portion of the impact of COVID-19 on the demand for its products and services. As a result of these actions, including the Company's 2020 restructuring plan, the Company experienced a positive impact on its results of operations in the first half of fiscal 2021, but the Company has experienced, and expects to experience, a negative impact on its results of operations in the second half of fiscal 2021 as the temporary cost reduction actions reverse. Although the Company has largely ceased temporary cost mitigation actions initiated in fiscal 2020, the necessity of future cost mitigation actions will depend on the continued impact of COVID-19, which is highly uncertain.

[0000833444-21-000040:mdna:19]
During portions of fiscal 2020, the Company experienced temporary reductions of its manufacturing and operating capacity, particularly in China, India and Mexico. Currently, the Company’s facilities have been operating at normal levels.

[0000833444-21-000040:mdna:20]
During fiscal 2020, the Company determined that it had triggering events requiring assessment of impairment for certain of its indefinite-lived intangible assets due to declines in revenue directly attributable to the COVID-19 pandemic and for certain of its indefinite-lived intangible assets, long-lived assets and goodwill due to declines in revenue and further declines in forecasted cash flows in its North America Retail reporting unit. As a result, the Company recorded an impairment charge of $62 million related primarily to the Company's retail business indefinite-lived intangible assets and an impairment charge of $424 million related to the Company's North America Retail reporting unit's goodwill. There were no triggering events requiring that an impairment assessment be conducted for indefinite-lived intangible assets or goodwill in the nine months ended June 30, 2021. However, it is possible that future changes in circumstances, including a more prolonged and/or severe COVID-19 pandemic, would require the Company to record additional non-cash impairment charges.

[0000833444-21-000040:mdna:21]
[same as prior period, unchanged from 0000833444-21-000020:mdna:20]

[0000833444-21-000040:mdna:22]
The extent to which the COVID-19 pandemic continues to impact the Company’s results of operations and financial condition will depend on future developments that are highly uncertain and cannot be predicted, including the resurgence of COVID-19 and its variants in regions recovering from the impacts of the pandemic, the effectiveness of COVID-19 vaccines and the speed at which populations are vaccinated around the globe, the impact of COVID-19 on economic activity, and regulatory actions taken to contain its impact on public health and the global economy. See Part I, Item 1A, of the Company’s Annual Report on Form 10-K for the year ended September 30, 2020 for an additional discussion of risks related to COVID-19.

[0000833444-21-000040:mdna:23]
[same as prior period, unchanged from 0000833444-21-000020:mdna:22]

[0000833444-21-000040:mdna:24]
[same as prior period, unchanged from 0000833444-21-000020:mdna:23]

[0000833444-21-000040:mdna:25]
47

[0000833444-21-000040:mdna:26]
[same as prior period, unchanged from 0000833444-21-000020:mdna:25]

[0000833444-21-000040:mdna:27]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Net sales | $ | 6,341 |  |  | $ | 5,343 |  |  | 19 | % |  | $ | 17,276 |  |  | $ | 16,363 |  |  | 6 | % |

[0000833444-21-000040:mdna:28]
The increase in consolidated net sales for the three months ended June 30, 2021 was due to higher organic sales ($803 million), the favorable impact of foreign currency translation ($165 million) and incremental sales from acquisitions ($90 million), partially offset by lower sales due to business divestitures ($57 million) and the impact of nonrecurring purchase accounting adjustments ($3 million). Excluding the impact of foreign currency translation, business acquisitions and divestitures and nonrecurring adjustments, consolidated net sales increased 15% as compared to the prior year, primarily attributable to the increased demand generated by the COVID-19 pandemic recovery. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-21-000040:mdna:29]
The increase in consolidated net sales for the nine months ended June 30, 2021 was due to higher organic sales ($617 million), the favorable impact of foreign currency translation ($390 million) and incremental sales from acquisitions ($103 million), partially offset by lower sales due to business divestitures ($194 million) and the impact of nonrecurring purchase accounting adjustments ($3 million). Excluding the impact of foreign currency translation, business acquisitions and divestitures and nonrecurring adjustments, consolidated net sales increased 4% as compared to the prior year, primarily attributable to the increased demand generated by the COVID-19 pandemic recovery. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-21-000040:mdna:30]
[same as prior period, unchanged from 0000833444-21-000020:mdna:29]

[0000833444-21-000040:mdna:31]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Cost of sales | $ | 4,144 |  |  | $ | 3,511 |  |  | 18 | % |  | $ | 11,408 |  |  | $ | 10,927 |  |  | 4 | % |
| Gross profit | 2,197 |  |  | 1,832 |  |  | 20 | % |  | 5,868 |  |  | 5,436 |  |  | 8 | % |
| % of sales | 34.6 | % |  | 34.3 | % |  |  |  | 34.0 | % |  | 33.2 | % |  |  |

[0000833444-21-000040:mdna:32]
Cost of sales and gross profit increased for the three month period ended June 30, 2021, and gross profit as a percentage of sales increased by 30 basis points. Gross profit increased due to organic sales growth, business acquisitions and favorable year-over-year impact of net pension mark-to-market adjustments ($34 million), partially offset by business divestitures. Foreign currency translation had an unfavorable impact on cost of sales of approximately $111 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-21-000040:mdna:33]
Cost of sales and gross profit increased for the nine month period ended June 30, 2021, and gross profit as a percentage of sales increased by 80 basis points. Gross profit increased due to organic sales growth, favorable year-over-year impact of net pension mark-to-market adjustments ($83 million) and business acquisitions, partially offset by business divestitures. Foreign currency translation had an unfavorable impact on cost of sales of approximately $269 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-21-000040:mdna:34]
48

[0000833444-21-000040:mdna:35]
[same as prior period, unchanged from 0000833444-21-000020:mdna:33]

[0000833444-21-000040:mdna:36]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Selling, general and administrative expenses | $ | 1,367 |  |  | $ | 1,334 |  |  | 2 | % |  | $ | 3,914 |  |  | $ | 4,212 |  |  | -7 | % |
| % of sales | 21.6 | % |  | 25.0 | % |  |  |  | 22.7 | % |  | 25.7 | % |  |  |

[0000833444-21-000040:mdna:37]
Selling, general and administrative expenses ("SG&A") for the three month period ended June 30, 2021 increased $33 million, and SG&A as a percentage of sales decreased by 340 basis points. The increase in SG&A was primarily due to prior year temporary cost mitigation actions and the unfavorable impact of foreign currency translation, partially offset by favorable year-over-year impact of net mark-to-market adjustments on pension plans ($179 million). Foreign currency translation had an unfavorable impact on SG&A of $36 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-21-000040:mdna:38]
SG&A for the nine month period ended June 30, 2021 decreased $298 million, and SG&A as a percentage of sales decreased by 300 basis points. The decrease in SG&A was primarily due to favorable year-over-year impact of net mark-to-market adjustments on pension plans ($337 million) and favorable impacts of cost mitigation actions and reductions in discretionary spend in the current year, partially offset by an unfavorable impact of foreign currency translation. Foreign currency translation had an unfavorable impact on SG&A of $88 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-21-000040:mdna:39]
[same as prior period, unchanged from 0000833444-21-000020:mdna:38]

[0000833444-21-000040:mdna:40]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Restructuring and impairment costs | $ | 79 |  |  | $ | 610 |  |  | -87 | % |  | $ | 175 |  |  | $ | 783 |  |  | -78 | % |

[0000833444-21-000040:mdna:41]
Refer to Note 10, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements and "Restructuring" below within this Item 2 for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-21-000040:mdna:42]
[same as prior period, unchanged from 0000833444-21-000020:mdna:41]

[0000833444-21-000040:mdna:43]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Net financing charges | $ | 56 |  |  | $ | 58 |  |  | -3 | % |  | $ | 159 |  |  | $ | 169 |  |  | -6 | % |

[0000833444-21-000040:mdna:44]
[same as prior period, unchanged from 0000833444-21-000020:mdna:43]

[0000833444-21-000040:mdna:45]
[same as prior period, unchanged from 0000833444-21-000020:mdna:44]

[0000833444-21-000040:mdna:46]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Equity income | $ | 74 |  |  | $ | 47 |  |  | 57 | % |  | $ | 188 |  |  | $ | 110 |  |  | 71 | % |

[0000833444-21-000040:mdna:47]
The increase in equity income for the three months ended June 30, 2021 was primarily due to higher income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture. Foreign currency translation had a favorable impact on equity income of $4 million for the three months ended June 30, 2021. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-21-000040:mdna:48]
The increase in equity income for the nine months ended June 30, 2021 was primarily due to higher income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture. Foreign currency translation had a favorable impact on equity income of $8 million for the nine months ended June 30, 2021. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-21-000040:mdna:49]
[same as prior period, unchanged from 0000833444-21-000020:mdna:49]

[0000833444-21-000040:mdna:50]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Income tax provision (benefit) | $ | 108 |  |  | $ | (1) |  |  | * |  | $ | 378 |  |  | $ | 77 |  |  | * |
| Effective tax rate | 14 | % |  | 1 | % |  |  |  | 21 | % |  | 20 | % |  |  |

[0000833444-21-000040:mdna:51]
[same as prior period, unchanged from 0000833444-21-000020:mdna:46]

[0000833444-21-000040:mdna:52]
[same as prior period, unchanged from 0000833444-21-000020:mdna:52]

[0000833444-21-000040:mdna:53]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended June 30, 2021, the Company's effective tax rate for continuing operations was 14% and was higher than the statutory tax rate of 12.5% primarily due to the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the nine months ended June 30, 2021, the Company's effective tax rate for continuing operations was 21% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the three months ended June 30, 2020, the Company's effective tax rate for continuing operations was 1% and was lower than the statutory tax rate of 12.5% primarily due to tax audit reserve adjustments, the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives, partially offset by the tax impact of an impairment charge and tax rate differentials. For the nine months ended June 30, 2020, the Company's effective tax rate for continuing operations was 20% and was higher than the statutory tax rate of 12.5% primarily due to a discrete tax charge related to the remeasurement of deferred tax assets and liabilities as a result of Swiss tax reform, the tax impact of an impairment charge and tax rate differentials, partially offset by tax audit reserve adjustments, the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives. The effective tax rate for the nine months ended June 30, 2021 increased as compared to the nine months ended June 30, 2020 primarily due to the discrete tax items. Refer to Note 11, "Income Taxes," of the notes to consolidated financial statements for further detail.

[0000833444-21-000040:mdna:54]
[same as prior period, unchanged from 0000833444-21-000020:mdna:54]

[0000833444-21-000040:mdna:55]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Income from discontinued operations, net of tax | $ | — |  |  | $ | — |  |  | * |  | $ | 124 |  |  | $ | — |  |  | * |

[0000833444-21-000040:mdna:56]
[same as prior period, unchanged from 0000833444-21-000020:mdna:51]

[0000833444-21-000040:mdna:57]
[same as prior period, unchanged from 0000833444-21-000020:mdna:57]

[0000833444-21-000040:mdna:58]
[same as prior period, unchanged from 0000833444-21-000020:mdna:58]

[0000833444-21-000040:mdna:59]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 87 |  |  | $ | 60 |  |  | 45 | % |  | $ | 186 |  |  | $ | 115 |  |  | 62 | % |

[0000833444-21-000040:mdna:60]
The increase in income from continuing operations attributable to noncontrolling interests for the three and nine months ended June 30, 2021 was primarily due to higher net income at certain partially-owned affiliates within the Global Products segment.

[0000833444-21-000040:mdna:61]
Net Income (Loss) Attributable to Johnson Controls

[0000833444-21-000040:mdna:62]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Net income (loss) attributable to Johnson Controls | $ | 574 |  |  | $ | (182) |  |  | * |  | $ | 1,368 |  |  | $ | 190 |  |  | * |

[0000833444-21-000040:mdna:63]
[same as prior period, unchanged from 0000833444-21-000020:mdna:56]

[0000833444-21-000040:mdna:64]
The increase in net income attributable to Johnson Controls for the three months ended June 30, 2021 was primarily due to lower restructuring and impairment costs and higher gross profit, partially offset by higher income tax provision. The increase in net income attributable to Johnson Controls for the nine months ended June 30, 2021 was primarily due to lower restructuring and impairment costs, higher gross profit, lower SG&A and the current year income from discontinued operations, partially offset by higher income tax provision.

[0000833444-21-000040:mdna:65]
Diluted earnings (loss) per share attributable to Johnson Controls for the three months ended June 30, 2021 was $0.80 compared to $(0.24) for the three months ended June 30, 2020. Diluted earnings per share attributable to Johnson Controls for the nine months ended June 30, 2021 was $1.89 compared to $0.25 for the nine months ended June 30, 2020.

[0000833444-21-000040:mdna:66]
[same as prior period, unchanged from 0000833444-21-000020:mdna:67]

[0000833444-21-000040:mdna:67]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Comprehensive income (loss) attributable to Johnson Controls | $ | 633 |  |  | $ | (104) |  |  | * |  | $ | 1,793 |  |  | $ | 42 |  |  | * |

[0000833444-21-000040:mdna:68]
[same as prior period, unchanged from 0000833444-21-000020:mdna:60]

[0000833444-21-000040:mdna:69]
The increase in comprehensive income attributable to Johnson Controls for the three months ended June 30, 2021 was due to higher net income attributable to Johnson Controls ($756 million), partially offset by a decrease in other comprehensive income attributable to Johnson Controls ($19 million) resulting primarily from the realized and unrealized losses on derivatives.

[0000833444-21-000040:mdna:70]
The increase in comprehensive income attributable to Johnson Controls for the nine months ended June 30, 2021 was due to higher net income attributable to Johnson Controls ($1,178 million) and an increase in other comprehensive income attributable to Johnson Controls ($573 million) resulting primarily from favorable currency translation adjustments. The year-over-year favorable foreign currency translation adjustments were primarily driven by the strengthening of the British pound, Canadian dollar and Mexican peso against the U.S. dollar in the current year.

[0000833444-21-000040:mdna:71]
[same as prior period, unchanged from 0000833444-21-000020:mdna:72]

[0000833444-21-000040:mdna:72]
[same as prior period, unchanged from 0000833444-21-000020:mdna:73]

[0000833444-21-000040:mdna:73]
[same as prior period, unchanged from 0000833444-21-000020:mdna:74]

[0000833444-21-000040:mdna:74]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Building Solutions North America | $ | 2,212 |  |  | $ | 2,020 |  |  | 10 | % |  | $ | 6,338 |  |  | $ | 6,362 |  |  | — | % |
| Building Solutions EMEA/LA | 962 |  |  | 756 |  |  | 27 | % |  | 2,765 |  |  | 2,534 |  |  | 9 | % |
| Building Solutions Asia Pacific | 712 |  |  | 588 |  |  | 21 | % |  | 1,930 |  |  | 1,742 |  |  | 11 | % |
| Global Products | 2,455 |  |  | 1,979 |  |  | 24 | % |  | 6,243 |  |  | 5,725 |  |  | 9 | % |
|  | $ | 6,341 |  |  | $ | 5,343 |  |  | 19 | % |  | $ | 17,276 |  |  | $ | 16,363 |  |  | 6 | % |

[0000833444-21-000040:mdna:75]
[same as prior period, unchanged from 0000833444-21-000020:mdna:76]

[0000833444-21-000040:mdna:76]
•The increase in Building Solutions North America was due to higher volumes ($171 million) and the favorable impact of foreign currency translation ($21 million). The increase in volumes was primarily attributable to the increased demand generated by the COVID-19 pandemic recovery.

[0000833444-21-000040:mdna:77]
•The increase in Building Solutions EMEA/LA was due to higher volumes ($140 million), the favorable impact of foreign currency translation ($56 million) and incremental sales related to business acquisitions ($10 million). The increase in volumes was primarily attributable to the increased demand generated by the COVID-19 pandemic recovery.

[0000833444-21-000040:mdna:78]
•The increase in Building Solutions Asia Pacific was due to favorable volumes ($86 million) and the favorable impact of foreign currency translation ($41 million), partially offset by business divestitures ($3 million). The increase in volumes was primarily attributable to the increased demand generated by the COVID-19 pandemic recovery.

[0000833444-21-000040:mdna:79]
•The increase in Global Products was due to favorable volumes ($406 million), incremental sales related to business acquisitions ($80 million) and the favorable impact of foreign currency translation ($47 million), partially offset by business divestitures ($54 million) and the impact of nonrecurring purchase accounting adjustments ($3 million). The increase in volumes was primarily attributable to the increased demand generated by the COVID-19 pandemic recovery.

[0000833444-21-000040:mdna:80]
[same as prior period, unchanged from 0000833444-21-000020:mdna:81]

[0000833444-21-000040:mdna:81]
•The decrease in Building Solutions North America was due to lower volumes ($61 million), partially offset by the favorable impact of foreign currency translation ($37 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic in the first half of the year.

[0000833444-21-000040:mdna:82]
•The increase in Building Solutions EMEA/LA was due to the favorable impact of foreign currency translation ($119 million), higher volumes ($89 million) and incremental sales related to business acquisitions ($23 million). The increase in volumes was primarily attributable to the COVID-19 pandemic recovery.

[0000833444-21-000040:mdna:83]
•The increase in Building Solutions Asia Pacific was due to the favorable impact of foreign currency translation ($99 million) and favorable volumes ($96 million), partially offset by business divestitures ($7 million). The increase in volumes was primarily attributable to the COVID-19 pandemic recovery.

[0000833444-21-000040:mdna:84]
•The increase in Global Products was due to favorable volumes ($493 million), the favorable impact of foreign currency translation ($135 million) and incremental sales related to business acquisitions ($80 million), partially offset by business divestitures ($187 million) and the impact of nonrecurring purchase accounting adjustments ($3 million). The increase in volumes was primarily attributable to the COVID-19 pandemic recovery.

[0000833444-21-000040:mdna:85]
[same as prior period, unchanged from 0000833444-21-000020:mdna:86]

[0000833444-21-000040:mdna:86]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Building Solutions North America | $ | 326 |  |  | $ | 307 |  |  | 6 | % |  | $ | 847 |  |  | $ | 816 |  |  | 4 | % |
| Building Solutions EMEA/LA | 103 |  |  | 62 |  |  | 66 | % |  | 284 |  |  | 237 |  |  | 20 | % |
| Building Solutions Asia Pacific | 84 |  |  | 92 |  |  | -9 | % |  | 237 |  |  | 229 |  |  | 3 | % |
| Global Products | 507 |  |  | 378 |  |  | 34 | % |  | 1,005 |  |  | 797 |  |  | 26 | % |
|  | $ | 1,020 |  |  | $ | 839 |  |  | 22 | % |  | $ | 2,373 |  |  | $ | 2,079 |  |  | 14 | % |

[0000833444-21-000040:mdna:87]
[same as prior period, unchanged from 0000833444-21-000020:mdna:88]

[0000833444-21-000040:mdna:88]
•The increase in Building Solutions North America was due to favorable volumes and productivity savings, net of prior year temporary cost mitigation actions ($13 million), prior year integration costs ($4 million) and the favorable impact of foreign currency translation ($2 million).

[0000833444-21-000040:mdna:89]
•The increase in Building Solutions EMEA/LA was due to favorable volumes ($34 million), the favorable impact of foreign currency translation ($4 million), higher equity income ($2 million) and higher income due to business acquisitions ($1 million).

[0000833444-21-000040:mdna:90]
•The decrease in Building Solutions Asia Pacific was due to prior year temporary cost mitigation actions, net of favorable volumes ($12 million) and lower income due to business divestitures ($1 million), partially offset by the favorable impact of foreign currency translation ($5 million).

[0000833444-21-000040:mdna:91]
•The increase in Global Products was due to favorable volumes and productivity savings, net of prior year temporary cost mitigation actions ($97 million), higher equity income ($19 million) driven primarily by certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture, the favorable impact of foreign currency translation ($11 million), prior year integration costs ($7 million) and incremental income related to business acquisitions ($4 million), partially offset by Silent-Aire transaction costs and nonrecurring purchase accounting adjustments ($7 million) and lower income due to business divestitures ($2 million).

[0000833444-21-000040:mdna:92]
[same as prior period, unchanged from 0000833444-21-000020:mdna:93]

[0000833444-21-000040:mdna:93]
•The increase in Building Solutions North America was due to productivity savings, net of unfavorable volumes ($23 million), prior year integration costs ($5 million) and the favorable impact of foreign currency translation ($3 million).

[0000833444-21-000040:mdna:94]
•The increase in Building Solutions EMEA/LA was due to productivity savings and favorable volumes ($40 million), the favorable impact of foreign currency translation ($5 million) and higher income due to business acquisitions ($3 million), partially offset by lower equity income ($1 million).

[0000833444-21-000040:mdna:95]
•The increase in Building Solutions Asia Pacific was due to the favorable impact of foreign currency translation ($11 million), partially offset by lower income due to business divestitures ($2 million) and prior year temporary cost mitigation actions, net of productivity savings and favorable volumes ($1 million).

[0000833444-21-000040:mdna:96]
•The increase in Global Products was due to favorable volumes and productivity savings, net of prior year temporary cost mitigation actions ($131 million), higher equity income ($64 million) driven primarily by certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture, the favorable impact of foreign currency translation ($22 million), prior year integration costs ($8 million) and incremental income related to business acquisitions ($4 million), partially offset by lower income due to business divestitures ($14 million) and Silent-Aire transaction costs and nonrecurring purchase accounting adjustments ($7 million).

[0000833444-21-000040:mdna:97]
[same as prior period, unchanged from 0000833444-21-000020:mdna:98]

[0000833444-21-000040:mdna:98]
The Company’s backlog is applicable to its sales of systems and services. At June 30, 2021, the backlog was $10.5 billion, of which $10.0 billion was attributable to the field business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-21-000040:mdna:99]
At June 30, 2021, remaining performance obligations were $15.6 billion, which is $5.1 billion higher than the Company's backlog of $10.5 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-21-000040:mdna:100]
[same as prior period, unchanged from 0000833444-21-000020:mdna:101]

[0000833444-21-000040:mdna:101]
[same as prior period, unchanged from 0000833444-21-000020:mdna:102]

[0000833444-21-000040:mdna:102]
[same as prior period, unchanged from 0000833444-21-000020:mdna:103]

[0000833444-21-000040:mdna:103]
[same as prior period, unchanged from 0000833444-21-000020:mdna:104]

[0000833444-21-000040:mdna:104]
[same as prior period, unchanged from 0000833444-21-000020:mdna:105]

[0000833444-21-000040:mdna:105]
[same as prior period, unchanged from 0000833444-21-000020:mdna:106]

[0000833444-21-000040:mdna:106]
|  | June 30, |  | September 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |
| Current assets | $ | 10,310 |  |  | $ | 10,053 |  |  |  |
| Current liabilities | (9,285) |  |  | (8,248) |  |  |  |
|  | 1,025 |  |  | 1,805 |  |  | -43 | % |
| Less: Cash | (1,450) |  |  | (1,951) |  |  |  |
| Add: Short-term debt | 265 |  |  | 31 |  |  |  |
| Add: Current portion of long-term debt | 196 |  |  | 262 |  |  |  |
| Working capital (as defined) | $ | 36 |  |  | $ | 147 |  |  | -76 | % |
| Accounts receivable - net | $ | 5,668 |  |  | $ | 5,294 |  |  | 7 | % |
| Inventories | 2,064 |  |  | 1,773 |  |  | 16 | % |
| Accounts payable | 3,719 |  |  | 3,120 |  |  | 19 | % |

[0000833444-21-000040:mdna:107]
[same as prior period, unchanged from 0000833444-21-000020:mdna:108]

[0000833444-21-000040:mdna:108]
•The decrease in working capital at June 30, 2021 as compared to September 30, 2020, was primarily due to an increase in accounts payable and accrued compensation and benefits liabilities, partially offset by an increase in inventory to meet anticipated customer demand, an increase in accounts receivable, and the favorable resolution of certain post-closing working capital and net debt adjustments related to the Power Solutions sale.

[0000833444-21-000040:mdna:109]
•The Company’s days sales in accounts receivable at June 30, 2021 and September 30, 2020 were 61 days and 63 days, respectively. There has been no significant adverse changes in the level of overdue receivables or significant changes in revenue recognition methods.

[0000833444-21-000040:mdna:110]
•The Company’s inventory turns for the three months ended June 30, 2021 were lower than the comparable period ended September 30, 2020, primarily due to changes in inventory production levels.

[0000833444-21-000040:mdna:111]
•Days in accounts payable at June 30, 2021 were 77 days, higher than 69 days at the comparable period ended September 30, 2020, primarily due to timing.

[0000833444-21-000040:mdna:112]
[same as prior period, unchanged from 0000833444-21-000020:mdna:113]

[0000833444-21-000040:mdna:113]
|  |  | Nine Months Ended June 30, |
| (in millions) |  | 2021 |  | 2020 |
| Cash provided by operating activities |  | $ | 2,022 |  |  | $ | 1,499 |  |
| Cash used by investing activities |  | (886) |  |  | (309) |  |
| Cash used by financing activities |  | (1,650) |  |  | (1,316) |  |

[0000833444-21-000040:mdna:114]
•The increase in cash provided by operating activities was primarily due to favorable changes in accounts payable and accrued liabilities, partially offset by prior year income tax refunds and unfavorable changes in accounts receivable.

[0000833444-21-000040:mdna:115]
•The increase in cash used by investing activities was primarily due to higher cash payments made for acquisitions.

[0000833444-21-000040:mdna:116]
•The increase in cash used by financing activities was primarily due to lower short-term debt borrowings, partially offset by lower stock repurchases.

[0000833444-21-000040:mdna:117]
[same as prior period, unchanged from 0000833444-21-000020:mdna:118]

[0000833444-21-000040:mdna:118]
|  | June 30, |  | September 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |
| Short-term debt | $ | 265 |  |  | $ | 31 |  |  |  |
| Current portion of long-term debt | 196 |  |  | 262 |  |  |  |
| Long-term debt | 7,318 |  |  | 7,526 |  |  |  |
| Total debt | 7,779 |  |  | 7,819 |  |  | -1 | % |
| Less: cash and cash equivalents | 1,450 |  |  | 1,951 |  |  |  |
| Total net debt | 6,329 |  |  | 5,868 |  |  | 8 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 17,840 |  |  | 17,447 |  |  | 2 | % |
| Total capitalization | $ | 24,169 |  |  | $ | 23,315 |  |  | 4 | % |
| Total net debt as a % of total capitalization | 26.2 | % |  | 25.2 | % |  |  |

[0000833444-21-000040:mdna:119]
[same as prior period, unchanged from 0000833444-21-000020:mdna:120]

[0000833444-21-000040:mdna:120]
•The Company believes its capital resources and liquidity position at June 30, 2021 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, minimum pension contributions, debt maturities and any potential acquisitions or stock repurchases in the remainder of fiscal 2021 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company is unable to issue commercial paper, it would have the ability to draw on its $2.5 billion revolving credit facility which expires in December 2024 or its $0.5 billion 364-day revolving credit facility which expires in December 2021. There were no draws on the revolving credit facilities as of June 30, 2021 and September 30, 2020. In addition, the Company held cash and cash equivalents of $1.5 billion as of June 30, 2021. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-21-000040:mdna:121]
•Financial covenants in the Company's revolving credit facilities requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity

[0000833444-21-000040:mdna:122]
56

[0000833444-21-000040:mdna:123]
attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of June 30, 2021, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-21-000040:mdna:124]
•The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2021, the Company believes the long-term rate of return will approximate 6.50%, 4.90% and 5.30% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first nine months of fiscal 2021, the Company made approximately $40 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $80 million in cash to its defined benefit pension plans in fiscal 2021. The Company expects to contribute $3 million in cash to its postretirement plans in fiscal 2021.

[0000833444-21-000040:mdna:125]
[same as prior period, unchanged from 0000833444-21-000020:mdna:124]

[0000833444-21-000040:mdna:126]
•We may from time to time purchase our outstanding debt through open market purchases, privately negotiated transactions or otherwise. Purchases or retirement of debt, if any, will depend on prevailing market conditions, liquidity requirements, contractual restrictions and other factors. The amounts involved may be material. In July 2021, the Company issued a notice of redemption for all of its outstanding 3.75% senior notes maturing December 1, 2021. The notes have an aggregate principal amount of $171 million and will be redeemed on September 1, 2021.

[0000833444-21-000040:mdna:127]
[same as prior period, unchanged from 0000833444-21-000020:mdna:126]

[0000833444-21-000040:mdna:128]
[same as prior period, unchanged from 0000833444-21-000020:mdna:127]

[0000833444-21-000040:mdna:129]
[same as prior period, unchanged from 0000833444-21-000020:mdna:128]

[0000833444-21-000040:mdna:130]
•In fiscal 2021, the Company announced its plans to optimize its cost structure through broad-based SG&A actions focused on simplification, standardization and centralization, with the intent to deliver annualized savings of $300 million by fiscal 2023. Additionally, the Company announced cost of sales actions to drive $250 million in annual run rate savings by fiscal 2023. The one-time pre-tax costs associated with these actions are estimated to be approximately $385 million across all segments and at Corporate. During the three and nine months ended June 30, 2021, the Company recorded $79 million and $175 million of costs resulting from the 2021 restructuring plan. The Company has outstanding restructuring reserves of $58 million at June 30, 2021, all of which is expected to be paid in cash.

[0000833444-21-000040:mdna:131]
57

[0000833444-21-000040:mdna:132]
•In fiscal 2020, the Company recorded $297 million of costs resulting from the 2020 restructuring plan. The Company currently estimates that upon completion of the restructuring action, the fiscal 2020 restructuring plans will reduce annual operating costs for continuing operations by approximately $430 million. The Company expects the annual benefit of these actions will be substantially realized in 2021. The restructuring action is expected to be substantially complete in fiscal 2021. The Company has outstanding restructuring reserves of $45 million at June 30, 2021, all of which is expected to be paid in cash.

[0000833444-21-000040:mdna:133]
[same as prior period, unchanged from 0000833444-21-000020:mdna:131]

[0000833444-21-000040:mdna:134]
The following information is provided in compliance with Rule 13-01 of Regulation S-X under the Securities Exchange Act of 1934 with respect to the (i) $625 million aggregate principal amount of 1.750% Senior Notes due 2030 (the “2030 Notes”), (ii) €500 million aggregate principal amount of 0.375% Senior Notes due 2027 (the “2027 Notes”) and (iii) €500 million aggregate principal amount of 1.000% Senior Notes due 2032 (the “2032 Notes” and together with the 2030 Notes and the 2027 Notes, the “Notes”), each issued by Johnson Controls International plc ("Parent Company") and Tyco Fire & Security Finance S.C.A. (“TFSCA”), a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”).

[0000833444-21-000040:mdna:135]
[same as prior period, unchanged from 0000833444-21-000020:mdna:133]

[0000833444-21-000040:mdna:136]
[same as prior period, unchanged from 0000833444-21-000020:mdna:134]

[0000833444-21-000040:mdna:137]
[same as prior period, unchanged from 0000833444-21-000020:mdna:135]

[0000833444-21-000040:mdna:138]
|  |  | Nine Months Ended June 30, 2021 |  | Year EndedSeptember 30, 2020 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Loss from continuing operations |  | (155) |  |  | (450) |  |  |
| Net loss |  | (155) |  |  | (450) |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net loss attributable to the entity |  | (155) |  |  | (450) |  |  |

[0000833444-21-000040:mdna:139]
58

[0000833444-21-000040:mdna:140]
[same as prior period, unchanged from 0000833444-21-000020:mdna:138]

[0000833444-21-000040:mdna:141]
|  |  | Nine Months Ended June 30, 2021 |  | Year EndedSeptember 30, 2020 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Income from continuing operations |  | 211 |  |  | 702 |  |  |
| Net income |  | 211 |  |  | 702 |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net income attributable to the entity |  | 211 |  |  | 702 |  |  |

[0000833444-21-000040:mdna:142]
The following table presents summarized balance sheet information as of June 30, 2021 and September 30, 2020 (in millions):

[0000833444-21-000040:mdna:143]
|  |  | June 30, 2021 |  | September 30, 2020 |  |
| Current assets |  | $ | 1,133 |  |  | $ | 522 |  |  |
| Noncurrent assets |  | 280 |  |  | 318 |  |  |
| Current liabilities |  | 1,536 |  |  | 7,612 |  |  |
| Noncurrent liabilities |  | 7,069 |  |  | 7,258 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-21-000040:mdna:144]
[same as prior period, unchanged from 0000833444-21-000020:mdna:142]

[0000833444-21-000040:mdna:145]
|  |  | June 30, 2021 |  | September 30, 2020 |  |
| Current assets |  | $ | 571 |  |  | $ | 838 |  |  |
| Noncurrent assets |  | 3,026 |  |  | 7,338 |  |  |
| Current liabilities |  | 2,100 |  |  | 2,724 |  |  |
| Noncurrent liabilities |  | 7,044 |  |  | 3,406 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-21-000040:mdna:146]
[same as prior period, unchanged from 0000833444-21-000020:mdna:144]

[0000833444-21-000040:mdna:147]
[same as prior period, unchanged from 0000833444-21-000020:mdna:145]

[0000833444-21-000040:mdna:148]
[same as prior period, unchanged from 0000833444-21-000020:mdna:146]
