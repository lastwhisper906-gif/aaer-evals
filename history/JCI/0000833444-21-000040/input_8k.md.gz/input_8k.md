# JCI 8-K — 0000833444-21-000038 filed 2021-07-30

## item codes, every 8-K on or before 2021-07-30

- 2021-07-30 0000833444-21-000038 — 2.02, 9.01
- 2021-05-03 0000833444-21-000023 — 8.01
- 2021-04-30 0000833444-21-000017 — 2.02, 9.01
- 2021-03-11 0000833444-21-000013 — 5.02, 5.07, 9.01
- 2021-02-17 0001193125-21-045768 — 7.01, 9.01
- 2021-01-29 0000833444-21-000009 — 2.02, 9.01
- 2021-01-07 0000833444-21-000004 — 7.01
- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2021-07-30

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-21-000038:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq3fy21.htm
EX-99.1

[0000833444-21-000038:8k_2_02:2]
Document

[0000833444-21-000038:8k_2_02:3]
Exhibit 99.1

[0000833444-21-000038:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-21-000038:8k_2_02:5]
Johnson Controls reports solid third quarter results and raises full year guidance

[0000833444-21-000038:8k_2_02:6]
________________________________________________________________________________

[0000833444-21-000038:8k_2_02:7]
▪GAAP EPS of $0.80; Adjusted EPS of $0.83, up 24% versus prior year

[0000833444-21-000038:8k_2_02:8]
▪Reported sales +19% versus prior year; +15% organic

[0000833444-21-000038:8k_2_02:9]
▪Organic order growth accelerated to +18% year-over-year, with strong underlying momentum; Backlog of $10.0 billion increased 7% organically year-over-year

[0000833444-21-000038:8k_2_02:10]
▪Cash provided by operating activities was $0.9 billion; Free cash flow of $0.7 billion

[0000833444-21-000038:8k_2_02:11]
▪Completed acquisition of Silent-Aire, establishing a leading position in the high growth hyperscale data center vertical

[0000833444-21-000038:8k_2_02:12]
▪Provides fiscal 2021 fourth quarter adjusted earnings per share guidance range of $0.86 to $0.88

[0000833444-21-000038:8k_2_02:13]
▪Raises fiscal 2021 adjusted EPS guidance to $2.64 to $2.66, an increase of 18% to 19% year-over-year

[0000833444-21-000038:8k_2_02:14]
________________________________________________________________________________

[0000833444-21-000038:8k_2_02:15]
CORK, Ireland, July 30, 2021 -- Johnson Controls International plc (NYSE: JCI), the global leader for smart, healthy and sustainable buildings, today reported fiscal third quarter 2021 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.80. Excluding these items, adjusted EPS from continuing operations was $0.83, up 24% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-21-000038:8k_2_02:16]
Sales of $6.3 billion increased 19% compared to the prior year on an as reported basis, and up 15% organically. GAAP net income from continuing operations was $574 million. Adjusted net income from continuing operations of $598 million increased 19% versus the prior year. Earnings before interest and taxes (“EBIT”) was $825 million and EBIT margin was 13.0%. Adjusted EBIT was $848 million and adjusted EBIT margin was 13.4%, an increase of 20 basis points versus prior year results.

[0000833444-21-000038:8k_2_02:17]
“We delivered another strong quarter of growth, profitability and cash flow in the third quarter,” said George Oliver, chairman and CEO. “We remain committed to executing both on our core operating fundamentals and on the strategic actions underway to accelerate growth, deliver on sustainability, expand our digital and service offerings, and strengthen future profitability.  Additionally, we welcomed the Silent-Aire family into Johnson Controls, increasing our focus on the very attractive data center vertical,” Oliver said.

[0000833444-21-000038:8k_2_02:18]
“Overall demand patterns continue to improve, including our longer cycle project installations, and most of our businesses are back to operating at or near pre-pandemic levels. We continue to proactively manage short-term challenges related to global supply chain disruptions, inflation and regional COVID resurgences and our team has remained laser focused on meeting our customer needs. Looking ahead, we are confident that the strength in orders, resilient backlog, and actions we’ve taken over the last year position us well to deliver on our commitments,” Oliver added.

[0000833444-21-000038:8k_2_02:19]
Page 1 of 19

[0000833444-21-000038:8k_2_02:20]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-21-000038:8k_2_02:21]
($ millions, except per-share amounts)

[0000833444-21-000038:8k_2_02:22]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the third fiscal quarter of 2020.

[0000833444-21-000038:8k_2_02:23]
Organic sales, adjusted sales, total segment EBITA, adjusted segment EBITA, adjusted corporate expense, EBIT, adjusted EBIT, adjusted net income from continuing operations, adjusted EPS from continuing operations and free cash flow are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes. A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at

[0000833444-21-000038:8k_2_02:24]
http://investors.johnsoncontrols.com.

[0000833444-21-000038:8k_2_02:25]
|  |  | Fiscal Q3 |  |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |  |
| Sales |  | $5,343 |  |  | $6,341 |  |  | $5,343 |  |  | $6,344 |  |  |  |  |  |  |  |  |
| Segment EBITA |  | 839 |  | 1,020 |  |  | 850 |  | 1,027 |  |  |  |  |  |  |  |
| EBIT |  | (65) |  |  | 825 |  | 707 |  | 848 |  |  |  |  |  |  |  |
| Net income (loss) from continuing operations |  | (182) |  |  | 574 |  | 502 |  | 598 |  |  |  |  |  |  |  |
| Diluted EPS from continuing operations |  | ($0.24) |  |  | $0.80 |  |  | $0.67 |  |  | $0.83 |  |  |  |  |  |  |  |  |

[0000833444-21-000038:8k_2_02:26]
Page 2 of 19

[0000833444-21-000038:8k_2_02:27]
SEGMENT RESULTS

[0000833444-21-000038:8k_2_02:28]
Building Solutions North America

[0000833444-21-000038:8k_2_02:29]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |
| Sales |  | $2,020 |  |  | $2,212 |  |  | $2,020 |  |  | $2,212 |  |  |  |  |  |  |  |
| Segment EBITA |  | 307 |  | 326 |  | 311 |  | 326 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 15.2% |  | 14.7% |  | 15.4% |  | 14.7% |  |  |  |  |  |  |

[0000833444-21-000038:8k_2_02:30]
Sales in the quarter of $2.2 billion increased 10% versus the prior year. Organic sales increased 8% over the prior year, with growth in both service and project installations, driven by double digit growth in Fire & Security and Performance Contracting and to a lesser extent growth in HVAC & Controls.

[0000833444-21-000038:8k_2_02:31]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 18% year-over-year. Backlog at the end of the quarter of $6.2 billion increased 6% compared to the prior year, excluding M&A and adjusted for foreign currency.

[0000833444-21-000038:8k_2_02:32]
Adjusted segment EBITA was $326 million, up 5% versus the prior year. Adjusted segment EBITA margin of 14.7% declined 70 basis points versus the prior year as the benefit of volume leverage and the SG&A actions taken this year were more than offset by the significant temporary cost mitigation actions taken in the prior year.

[0000833444-21-000038:8k_2_02:33]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-21-000038:8k_2_02:34]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |
| Sales |  | $756 |  |  | $962 |  |  | $756 |  |  | $962 |  |  |  |  |  |  |  |
| Segment EBITA |  | 62 |  | 103 |  | 62 |  | 103 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 8.2% |  | 10.7% |  | 8.2% |  | 10.7% |  |  |  |  |  |  |

[0000833444-21-000038:8k_2_02:35]
Sales in the quarter of $962 million increased 27% versus the prior year. Organic sales grew 17% versus the prior year led by a sharp rebound in project installation activity.  Additionally, service revenues grew double digits organically. Strength was broad based across our businesses, led by Fire & Security and Industrial Refrigeration. By region, Europe experienced strong growth, while growth in Latin America was more modest and the Middle East remained under pressure.

[0000833444-21-000038:8k_2_02:36]
Page 3 of 19

[0000833444-21-000038:8k_2_02:37]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 22% year-over-year. Backlog at the end of the quarter of $2.0 billion increased 9% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-21-000038:8k_2_02:38]
Adjusted segment EBITA was $103 million, up 66% versus the prior year. Adjusted segment EBITA margin of 10.7% expanded 250 basis points over the prior year driven by volume leverage and the benefit of SG&A actions taken this year.

[0000833444-21-000038:8k_2_02:39]
Building Solutions Asia Pacific

[0000833444-21-000038:8k_2_02:40]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |
| Sales |  | $588 |  |  | $712 |  |  | $588 |  |  | $712 |  |  |  |  |  |  |  |
| Segment EBITA |  | 92 |  | 84 |  | 92 |  | 84 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 15.6% |  | 11.8% |  | 15.6% |  | 11.8% |  |  |  |  |  |  |

[0000833444-21-000038:8k_2_02:41]
Sales in the quarter of $712 million increased 21% versus the prior year. Organic sales grew 14% versus the prior year with solid growth in both service and project installations, driven by strong growth in Commercial Applied HVAC & Controls. China remains the primary source of growth, with the rest of Asia mixed due to ongoing lockdown restrictions in many regions.

[0000833444-21-000038:8k_2_02:42]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 14% year-over-year, led by continued strong demand for Commercial HVAC in China and recovery in the Controls business in Japan. Backlog at the end of the quarter of $1.8 billion increased 5% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-21-000038:8k_2_02:43]
Adjusted segment EBITA was $84 million, down 9% versus the prior year.  Adjusted segment EBITA margin of 11.8% declined 380 basis points versus the prior year including a 20 basis point headwind related to foreign currency.  The benefit of volume leverage and the SG&A actions taken this year were more than offset by the significant temporary cost mitigation actions taken in the prior year and geographic mix.

[0000833444-21-000038:8k_2_02:44]
Page 4 of 19

[0000833444-21-000038:8k_2_02:45]
Global Products

[0000833444-21-000038:8k_2_02:46]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |
| Sales |  | $1,979 |  |  | $2,455 |  |  | $1,979 |  |  | $2,458 |  |  |  |  |  |  |  |
| Segment EBITA |  | 378 |  | 507 |  | 385 |  | 514 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 19.1% |  | 20.7% |  | 19.5% |  | 20.9% |  |  |  |  |  |  |

[0000833444-21-000038:8k_2_02:47]
Sales in the quarter of $2.5 billion increased 24% versus the prior year. Organic sales grew 21% versus the prior year driven by strong growth across Commercial and Residential HVAC and Fire & Security products.

[0000833444-21-000038:8k_2_02:48]
Adjusted segment EBITA was $514 million, up 34% versus the prior year. Adjusted segment EBITA margin of 20.9% expanded 140 basis points versus the prior year as volume leverage, positive mix, increased equity income and the benefit of SG&A actions taken this year more than offset the significant temporary cost mitigation actions taken in the prior year as well as price cost pressure.

[0000833444-21-000038:8k_2_02:49]
Corporate

[0000833444-21-000038:8k_2_02:50]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |
| Corporate Expense |  | ($67) |  | ($70) |  | ($48) |  | ($70) |  |  |  |  |  |  |

[0000833444-21-000038:8k_2_02:51]
Adjusted Corporate expense was $70 million in the quarter, an increase of 46% compared to the prior  year, driven primarily by the non-recurrence of the significant temporary cost mitigation actions taken in the prior year.

[0000833444-21-000038:8k_2_02:52]
OTHER ITEMS

[0000833444-21-000038:8k_2_02:53]
▪For the quarter, cash provided by operating activities from continuing operations was $0.9 billion and capital expenditures were $0.1 billion, resulting in free cash flow from continuing operations of $0.7 billion.

[0000833444-21-000038:8k_2_02:54]
▪During the quarter, the company repurchased approximately 5 million shares for $340 million.

[0000833444-21-000038:8k_2_02:55]
Page 5 of 19

[0000833444-21-000038:8k_2_02:56]
▪During the quarter, the company completed the acquisition of Silent-Aire in an all-cash transaction valued at up to $900 million, including an upfront payment of approximately $660 million and additional payments to be made subject to the achievement of post-closing earnout milestones. Revenue for fiscal year 2021 (May) was approximately $650 million.

[0000833444-21-000038:8k_2_02:57]
FULL YEAR GUIDANCE

[0000833444-21-000038:8k_2_02:58]
The company raised fiscal 2021 full year guidance:

[0000833444-21-000038:8k_2_02:59]
▪Organic revenue growth up mid-single digits year-over-year

[0000833444-21-000038:8k_2_02:60]
▪Adjusted segment EBITA margin expansion of 80 to 90 basis points, year-over-year

[0000833444-21-000038:8k_2_02:61]
▪Adjusted EPS before special items of $2.64 to $2.66; represents 18 to 19% growth year-over-year

[0000833444-21-000038:8k_2_02:62]
CONFERENCE CALL & WEBCAST INFO

[0000833444-21-000038:8k_2_02:63]
Johnson Controls will host a conference call to discuss this quarter’s results at 8:30 a.m. ET today, which can be accessed by dialing 888-324-9610 (in the United States) or 630-395-0255 (outside the United States), or via webcast. The passcode is “Johnson Controls”. A slide presentation will accompany the prepared remarks and has been posted on the investor relations section of the Johnson Controls website at https://investors.johnsoncontrols.com/news-and-events/events-and-presentations. A replay will be made available approximately two hours following the conclusion of the conference call.

[0000833444-21-000038:8k_2_02:64]
About Johnson Controls:

[0000833444-21-000038:8k_2_02:65]
At Johnson Controls (NYSE:JCI) we transform the environments where people live, work, learn and play. As the global leader in smart, healthy and sustainable buildings, our mission is to reimagine the performance of buildings to serve people, places and the planet.

[0000833444-21-000038:8k_2_02:66]
With a history of more than 135 years of innovation, Johnson Controls delivers the blueprint of the future for industries such as healthcare, schools, data centers, airports, stadiums, manufacturing and beyond through its comprehensive digital offering OpenBlue. With a global team of 100,000 experts in more than 150 countries, Johnson Controls offers the world`s largest portfolio of building technology, software as well as service solutions with some of the most trusted names in the industry. For more information,

[0000833444-21-000038:8k_2_02:67]
visit www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter.

[0000833444-21-000038:8k_2_02:68]
Page 6 of 19

[0000833444-21-000038:8k_2_02:69]
JOHNSON CONTROLS CONTACTS:

[0000833444-21-000038:8k_2_02:70]
| INVESTOR CONTACTS: | MEDIA CONTACTS: |  |  |  |
| Antonella Franzen | Chaz Bickers |  |  |  |
| Direct: 609.720.4665 | Direct: 224.307.0655 |  |  |  |
| Email: antonella.franzen@jci.com | Email: charles.norman.bickers@jci.com |  |  |  |
| Ryan Edelman |  |  |  |  |
| Direct: 609.720.4545 |  |  |  |  |
| Email: ryan.edelman@jci.com |  |  |  |  |

[0000833444-21-000038:8k_2_02:71]
###

[0000833444-21-000038:8k_2_02:72]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-21-000038:8k_2_02:73]
Page 7 of 19

[0000833444-21-000038:8k_2_02:74]
K for the 2020 fiscal year filed with the SEC on November 16, 2020, which is available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-21-000038:8k_2_02:75]
###

[0000833444-21-000038:8k_2_02:76]
Non-GAAP Financial Information

[0000833444-21-000038:8k_2_02:77]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include restructuring and impairment costs, integration costs, net mark-to-market adjustments, Silent-Aire transaction costs and other nonrecurring costs, Power Solutions divestiture reserve adjustment and discrete tax items. Financial information regarding organic sales, adjusted sales, EBIT, EBIT margin, adjusted EBIT, adjusted EBIT margin, total segment EBITA, adjusted segment EBITA, adjusted segment EBITA margin, adjusted corporate expense, free cash flow, and adjusted net income (loss) from continuing operations are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as integration costs, Silent-Aire transaction costs and other nonrecurring costs because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.  For further information on the calculation of the non-GAAP measures and a reconciliation of these non-GAAP measures, refer to the attached footnotes.

[0000833444-21-000038:8k_2_02:78]
###

[0000833444-21-000038:8k_2_02:79]
Page 8 of 19

[0000833444-21-000038:8k_2_02:80]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |  |
|  |  | Three Months Ended June 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Net sales | $ | 6,341 |  |  |  | $ | 5,343 |  |  |
| Cost of sales | 4,144 |  |  |  | 3,511 |  |  |
|  | Gross profit | 2,197 |  |  |  | 1,832 |  |  |
| Selling, general and administrative expenses | (1,367) |  |  |  | (1,334) |  |  |
| Restructuring and impairment costs | (79) |  |  |  | (610) |  |  |
| Net financing charges | (56) |  |  |  | (58) |  |  |
| Equity income | 74 |  |  |  | 47 |  |  |
| Income (loss) from continuing operations before income taxes | 769 |  |  |  | (123) |  |  |
| Income tax provision (benefit) | 108 |  |  |  | (1) |  |  |
| Income (loss) from continuing operations | 661 |  |  |  | (122) |  |  |
| Income from discontinued operations, net of tax | — |  |  |  | — |  |  |
| Net income (loss) | 661 |  |  |  | (122) |  |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 87 |  |  |  | 60 |  |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |  |
| Net income (loss) attributable to JCI | $ | 574 |  |  |  | $ | (182) |  |  |
| Income (loss) from continuing operations | $ | 574 |  |  |  | $ | (182) |  |  |
| Income from discontinued operations | — |  |  |  | — |  |  |
| Net income (loss) attributable to JCI | $ | 574 |  |  |  | $ | (182) |  |  |
| Diluted earnings (loss) per share from continuing operations | $ | 0.80 |  |  |  | $ | (0.24) |  |  |
| Diluted earnings per share from discontinued operations | — |  |  |  | — |  |  |
| Diluted earnings (loss) per share | $ | 0.80 |  |  |  | $ | (0.24) |  |  |
| Diluted weighted average shares | 719.7 |  |  |  | 744.0 |  |  |
| Shares outstanding at period end | 712.2 |  |  |  | 744.0 |  |  |

[0000833444-21-000038:8k_2_02:81]
Page 9 of 19

[0000833444-21-000038:8k_2_02:82]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Nine Months Ended June 30, |
|  |  | 2021 |  |  | 2020 |
| Net sales | $ | 17,276 |  |  |  | $ | 16,363 |  |
| Cost of sales | 11,408 |  |  |  | 10,927 |  |
|  | Gross profit | 5,868 |  |  |  | 5,436 |  |
| Selling, general and administrative expenses | (3,914) |  |  |  | (4,212) |  |
| Restructuring and impairment costs | (175) |  |  |  | (783) |  |
| Net financing charges | (159) |  |  |  | (169) |  |
| Equity income | 188 |  |  |  | 110 |  |
| Income from continuing operations before income taxes | 1,808 |  |  |  | 382 |  |
| Income tax provision | 378 |  |  |  | 77 |  |
| Income from continuing operations | 1,430 |  |  |  | 305 |  |
| Income from discontinued operations, net of tax | 124 |  |  |  | — |  |
| Net income | 1,554 |  |  |  | 305 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 186 |  |  |  | 115 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |
| Net income attributable to JCI | $ | 1,368 |  |  |  | $ | 190 |  |
| Income from continuing operations | $ | 1,244 |  |  |  | $ | 190 |  |
| Income from discontinued operations | 124 |  |  |  | — |  |
| Net income attributable to JCI | $ | 1,368 |  |  |  | $ | 190 |  |
| Diluted earnings per share from continuing operations | $ | 1.72 |  |  |  | $ | 0.25 |  |
| Diluted earnings per share from discontinued operations | 0.17 |  |  |  | — |  |
| Diluted earnings per share | $ | 1.89 |  |  |  | $ | 0.25 |  |
| Diluted weighted average shares | 722.5 |  |  |  | 758.9 |  |
| Shares outstanding at period end | 712.2 |  |  |  | 744.0 |  |

[0000833444-21-000038:8k_2_02:83]
Page 10 of 19

[0000833444-21-000038:8k_2_02:84]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | June 30,2021 |  | September 30,2020 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 1,450 |  |  | $ | 1,951 |  |
| Accounts receivable - net | 5,668 |  |  | 5,294 |  |
| Inventories | 2,064 |  |  | 1,773 |  |
| Other current assets | 1,128 |  |  | 1,035 |  |
|  | Current assets | 10,310 |  |  | 10,053 |  |
| Property, plant and equipment - net | 3,111 |  |  | 3,059 |  |
| Goodwill | 18,445 |  |  | 17,932 |  |
| Other intangible assets - net | 5,679 |  |  | 5,356 |  |
| Investments in partially-owned affiliates | 1,016 |  |  | 914 |  |
| Noncurrent assets held for sale | 185 |  |  | 147 |  |
| Other noncurrent assets | 3,389 |  |  | 3,354 |  |
|  | Total assets | $ | 42,135 |  |  | $ | 40,815 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 461 |  |  | $ | 293 |  |
| Accounts payable and accrued expenses | 4,715 |  |  | 3,958 |  |
| Other current liabilities | 4,109 |  |  | 3,997 |  |
|  | Current liabilities | 9,285 |  |  | 8,248 |  |
| Long-term debt | 7,318 |  |  | 7,526 |  |
| Other noncurrent liabilities | 6,535 |  |  | 6,508 |  |
| Shareholders' equity attributable to JCI | 17,840 |  |  | 17,447 |  |
| Noncontrolling interests | 1,157 |  |  | 1,086 |  |
|  | Total liabilities and equity | $ | 42,135 |  |  | $ | 40,815 |  |

[0000833444-21-000038:8k_2_02:85]
Page 11 of 19

[0000833444-21-000038:8k_2_02:86]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended June 30, |
|  |  |  |  |  |  | 2021 |  |  | 2020 |
| Operating Activities |  |  |  |  |
| Net income (loss) from continuing operations attributable to JCI | $ | 574 |  |  |  | $ | (182) |  |
| Income from continuing operations attributable to noncontrolling interests | 87 |  |  |  | 60 |  |
| Net income (loss) from continuing operations | 661 |  |  |  | (122) |  |
| Adjustments to reconcile net income (loss) from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 208 |  |  |  | 202 |  |
|  |  | Pension and postretirement benefit expense (income) | (94) |  |  |  | 122 |  |
|  |  | Pension and postretirement contributions | (15) |  |  |  | (16) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | 41 |  |  |  | 20 |  |
|  |  | Deferred income taxes | (19) |  |  |  | (87) |  |
|  |  | Non-cash restructuring and impairment costs | 40 |  |  |  | 466 |  |
|  |  | Other - net | (6) |  |  |  | (33) |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (324) |  |  |  | 184 |  |
|  |  |  |  | Inventories | 7 |  |  |  | 56 |  |
|  |  |  |  | Other assets | 60 |  |  |  | 30 |  |
|  |  |  |  | Restructuring reserves | (3) |  |  |  | 96 |  |
|  |  |  |  | Accounts payable and accrued liabilities | 344 |  |  |  | (126) |  |
|  |  |  |  | Accrued income taxes | (38) |  |  |  | 41 |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 862 |  |  |  | 833 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (127) |  |  |  | (97) |  |
| Acquisition of businesses, net of cash acquired | (697) |  |  |  | (1) |  |
| Other - net | 57 |  |  |  | 77 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (767) |  |  |  | (21) |  |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | (31) |  |  |  | 974 |  |
| Stock repurchases and retirements | (340) |  |  |  | — |  |
| Payment of cash dividends | (193) |  |  |  | (194) |  |
| Dividends paid to noncontrolling interests | (32) |  |  |  | (62) |  |
| Proceeds from the exercise of stock options | 27 |  |  |  | 3 |  |
| Employee equity-based compensation withholding taxes | (1) |  |  |  | (1) |  |
| Other - net | (1) |  |  |  | — |  |
|  |  |  |  |  | Cash provided (used) by financing activities from continuing operations | (571) |  |  |  | 720 |  |
| Discontinued Operations |  |  |  |  |
| Net cash used by operating activities | (19) |  |  |  | (47) |  |
| Net cash used by investing activities | — |  |  |  | — |  |
| Net cash used by financing activities | — |  |  |  | (113) |  |
|  |  |  |  |  | Net cash flows used by discontinued operations | (19) |  |  |  | (160) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 58 |  |  |  | (36) |  |
| Changes in cash held for sale | — |  |  |  | — |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | $ | (437) |  |  |  | $ | 1,336 |  |

[0000833444-21-000038:8k_2_02:87]
Page 12 of 19

[0000833444-21-000038:8k_2_02:88]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Nine Months Ended June 30, |
|  |  |  |  |  |  | 2021 |  |  | 2020 |
| Operating Activities |  |  |  |  |
| Net income from continuing operations attributable to JCI | $ | 1,244 |  |  |  | $ | 190 |  |
| Income from continuing operations attributable to noncontrolling interests | 186 |  |  |  | 115 |  |
| Net income from continuing operations | 1,430 |  |  |  | 305 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 627 |  |  |  | 616 |  |
|  |  | Pension and postretirement benefit expense (income) | (393) |  |  |  | 42 |  |
|  |  | Pension and postretirement contributions | (40) |  |  |  | (43) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (66) |  |  |  | 9 |  |
|  |  | Deferred income taxes | 6 |  |  |  | (148) |  |
|  |  | Non-cash restructuring and impairment costs | 94 |  |  |  | 582 |  |
|  |  | Other - net | (38) |  |  |  | 23 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (157) |  |  |  | 428 |  |
|  |  |  |  | Inventories | (204) |  |  |  | (205) |  |
|  |  |  |  | Other assets | (30) |  |  |  | (120) |  |
|  |  |  |  | Restructuring reserves | (27) |  |  |  | 58 |  |
|  |  |  |  | Accounts payable and accrued liabilities | 854 |  |  |  | (731) |  |
|  |  |  |  | Accrued income taxes | (34) |  |  |  | 683 |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 2,022 |  |  |  | 1,499 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (324) |  |  |  | (347) |  |
| Acquisition of businesses, net of cash acquired | (707) |  |  |  | (59) |  |
| Business divestitures, net of cash divested | 19 |  |  |  | — |  |
| Other - net | 126 |  |  |  | 97 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (886) |  |  |  | (309) |  |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | (64) |  |  |  | 807 |  |
| Stock repurchases and retirements | (1,001) |  |  |  | (1,467) |  |
| Payment of cash dividends | (570) |  |  |  | (596) |  |
| Proceeds from the exercise of stock options | 160 |  |  |  | 42 |  |
| Dividends paid to noncontrolling interests | (133) |  |  |  | (67) |  |
| Cash paid to acquire a noncontrolling interest | (14) |  |  |  | — |  |
| Employee equity-based compensation withholding taxes | (30) |  |  |  | (33) |  |
| Other - net | 2 |  |  |  | (2) |  |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (1,650) |  |  |  | (1,316) |  |
| Discontinued Operations |  |  |  |  |
| Net cash used by operating activities | (56) |  |  |  | (255) |  |
| Net cash used by investing activities | — |  |  |  | — |  |
| Net cash used by financing activities | — |  |  |  | (113) |  |
|  |  |  |  |  | Net cash flows used by discontinued operations | (56) |  |  |  | (368) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 67 |  |  |  | 28 |  |
| Changes in cash held for sale | — |  |  |  | — |  |
| Decrease in cash, cash equivalents and restricted cash | $ | (503) |  |  |  | $ | (466) |  |

[0000833444-21-000038:8k_2_02:89]
Page 13 of 19

[0000833444-21-000038:8k_2_02:90]
FOOTNOTES

[0000833444-21-000038:8k_2_02:91]
1. Financial Summary

[0000833444-21-000038:8k_2_02:92]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income (loss) from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans. The financial results shown below are for continuing operations and exclude the Power Solutions business.

[0000833444-21-000038:8k_2_02:93]
| (in millions; unaudited) | Three Months Ended June 30, |
|  | 2021 |  | 2020 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,212 |  |  | $ | 2,212 |  |  | $ | 2,020 |  |  | $ | 2,020 |  |
| Building Solutions EMEA/LA | 962 |  |  | 962 |  |  | 756 |  |  | 756 |  |
| Building Solutions Asia Pacific | 712 |  |  | 712 |  |  | 588 |  |  | 588 |  |
| Global Products | 2,455 |  |  | 2,458 |  |  | 1,979 |  |  | 1,979 |  |
| Net sales | $ | 6,341 |  |  | $ | 6,344 |  |  | $ | 5,343 |  |  | $ | 5,343 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 326 |  |  | $ | 326 |  |  | $ | 307 |  |  | $ | 311 |  |
| Building Solutions EMEA/LA | 103 |  |  | 103 |  |  | 62 |  |  | 62 |  |
| Building Solutions Asia Pacific | 84 |  |  | 84 |  |  | 92 |  |  | 92 |  |
| Global Products | 507 |  |  | 514 |  |  | 378 |  |  | 385 |  |
| Segment EBITA | 1,020 |  |  | 1,027 |  |  | 839 |  |  | 850 |  |
| Corporate expenses (2) | (70) |  |  | (70) |  |  | (67) |  |  | (48) |  |
| Amortization of intangible assets (3) | (112) |  |  | (109) |  |  | (95) |  |  | (95) |  |
| Net mark-to-market adjustments (4) | 66 |  |  | — |  |  | (132) |  |  | — |  |
| Restructuring and impairment costs (5) | (79) |  |  | — |  |  | (610) |  |  | — |  |
| EBIT (6) | 825 |  |  | 848 |  |  | (65) |  |  | 707 |  |
| EBIT margin | 13.0 | % |  | 13.4 | % |  | -1.2 | % |  | 13.2 | % |
| Net financing charges | (56) |  |  | (56) |  |  | (58) |  |  | (58) |  |
| Income (loss) from continuing operations before income taxes | 769 |  |  | 792 |  |  | (123) |  |  | 649 |  |
| Income tax benefit (provision) (7) | (108) |  |  | (107) |  |  | 1 |  |  | (87) |  |
| Income from continuing operations | 661 |  |  | 685 |  |  | (122) |  |  | 562 |  |
| Income from continuing operations attributable to noncontrolling interests | (87) |  |  | (87) |  |  | (60) |  |  | (60) |  |
| Net income (loss) from continuing operations attributable to JCI | $ | 574 |  |  | $ | 598 |  |  | $ | (182) |  |  | $ | 502 |  |

[0000833444-21-000038:8k_2_02:94]
| (in millions; unaudited) | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 6,338 |  |  | $ | 6,338 |  |  | $ | 6,362 |  |  | $ | 6,362 |  |
| Building Solutions EMEA/LA | 2,765 |  |  | 2,765 |  |  | 2,534 |  |  | 2,534 |  |
| Building Solutions Asia Pacific | 1,930 |  |  | 1,930 |  |  | 1,742 |  |  | 1,742 |  |
| Global Products | 6,243 |  |  | 6,246 |  |  | 5,725 |  |  | 5,725 |  |
| Net sales | $ | 17,276 |  |  | $ | 17,279 |  |  | $ | 16,363 |  |  | $ | 16,363 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 847 |  |  | $ | 847 |  |  | $ | 816 |  |  | $ | 823 |  |
| Building Solutions EMEA/LA | 284 |  |  | 284 |  |  | 237 |  |  | 237 |  |
| Building Solutions Asia Pacific | 237 |  |  | 237 |  |  | 229 |  |  | 229 |  |
| Global Products | 1,005 |  |  | 1,012 |  |  | 797 |  |  | 805 |  |
| Segment EBITA | 2,373 |  |  | 2,380 |  |  | 2,079 |  |  | 2,094 |  |
| Corporate expenses (2) | (207) |  |  | (207) |  |  | (303) |  |  | (211) |  |
| Amortization of intangible assets (3) | (320) |  |  | (317) |  |  | (288) |  |  | (288) |  |
| Net mark-to-market adjustments (4) | 296 |  |  | — |  |  | (154) |  |  | — |  |
| Restructuring and impairment costs (5) | (175) |  |  | — |  |  | (783) |  |  | — |  |
| EBIT (6) | 1,967 |  |  | 1,856 |  |  | 551 |  |  | 1,595 |  |
| EBIT margin | 11.4 | % |  | 10.7 | % |  | 3.4 | % |  | 9.7 | % |
| Net financing charges | (159) |  |  | (159) |  |  | (169) |  |  | (169) |  |
| Income (loss) from continuing operations before income taxes | 1,808 |  |  | 1,697 |  |  | 382 |  |  | 1,426 |  |
| Income tax benefit (provision) (7) | (378) |  |  | (229) |  |  | (77) |  |  | (192) |  |
| Income from continuing operations | 1,430 |  |  | 1,468 |  |  | 305 |  |  | 1,234 |  |
| Income from continuing operations attributable to noncontrolling interests | (186) |  |  | (186) |  |  | (115) |  |  | (109) |  |
| Net income (loss) from continuing operations attributable to JCI | $ | 1,244 |  |  | $ | 1,282 |  |  | $ | 190 |  |  | $ | 1,125 |  |

[0000833444-21-000038:8k_2_02:95]
(1) The Company's press release contains financial information regarding adjusted net sales, segment EBITA, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted net sales and adjusted segment EBITA excludes special items because these items are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-21-000038:8k_2_02:96]
A reconciliation of segment EBITA to income (loss) from continuing operations is shown earlier within this footnote. The following is the three months ended June 30, 2021 and 2020 reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-21-000038:8k_2_02:97]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales as reported | $ | 2,212 |  |  | $ | 2,020 |  |  | $ | 962 |  |  | $ | 756 |  |  | $ | 712 |  |  | $ | 588 |  |  | $ | 2,455 |  |  | $ | 1,979 |  |  | $ | 6,341 |  |  | $ | 5,343 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring Silent-Aire purchase accounting impacts | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Adjusted net sales | $ | 2,212 |  |  | $ | 2,020 |  |  | $ | 962 |  |  | $ | 756 |  |  | $ | 712 |  |  | $ | 588 |  |  | $ | 2,458 |  |  | $ | 1,979 |  |  | $ | 6,344 |  |  | $ | 5,343 |  |
| Segment EBITA as reported | $ | 326 |  |  | $ | 307 |  |  | $ | 103 |  |  | $ | 62 |  |  | $ | 84 |  |  | $ | 92 |  |  | $ | 507 |  |  | $ | 378 |  |  | $ | 1,020 |  |  | $ | 839 |  |
| Segment EBITA margin as reported | 14.7 | % |  | 15.2 | % |  | 10.7 | % |  | 8.2 | % |  | 11.8 | % |  | 15.6 | % |  | 20.7 | % |  | 19.1 | % |  | 16.1 | % |  | 15.7 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring Silent-Aire purchase accounting impacts and transaction costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |  | — |  |
| Integration costs | — |  |  | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 11 |  |
| Adjusted segment EBITA | $ | 326 |  |  | $ | 311 |  |  | $ | 103 |  |  | $ | 62 |  |  | $ | 84 |  |  | $ | 92 |  |  | $ | 514 |  |  | $ | 385 |  |  | $ | 1,027 |  |  | $ | 850 |  |
| Adjusted segment EBITA margin | 14.7 | % |  | 15.4 | % |  | 10.7 | % |  | 8.2 | % |  | 11.8 | % |  | 15.6 | % |  | 20.9 | % |  | 19.5 | % |  | 16.2 | % |  | 15.9 | % |

[0000833444-21-000038:8k_2_02:98]
Page 14 of 19

[0000833444-21-000038:8k_2_02:99]
The following is the nine months ended June 30, 2021 and 2020 reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-21-000038:8k_2_02:100]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales as reported | $ | 6,338 |  |  | $ | 6,362 |  |  | $ | 2,765 |  |  | $ | 2,534 |  |  | $ | 1,930 |  |  | $ | 1,742 |  |  | $ | 6,243 |  |  | $ | 5,725 |  |  | $ | 17,276 |  |  | $ | 16,363 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring Silent-Aire purchase accounting impacts | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Adjusted net sales | $ | 6,338 |  |  | $ | 6,362 |  |  | $ | 2,765 |  |  | $ | 2,534 |  |  | $ | 1,930 |  |  | $ | 1,742 |  |  | $ | 6,246 |  |  | $ | 5,725 |  |  | $ | 17,279 |  |  | $ | 16,363 |  |
| Segment EBITA as reported | $ | 847 |  |  | $ | 816 |  |  | $ | 284 |  |  | $ | 237 |  |  | $ | 237 |  |  | $ | 229 |  |  | $ | 1,005 |  |  | $ | 797 |  |  | $ | 2,373 |  |  | $ | 2,079 |  |
| Segment EBITA margin as reported | 13.4 | % |  | 12.8 | % |  | 10.3 | % |  | 9.4 | % |  | 12.3 | % |  | 13.1 | % |  | 16.1 | % |  | 13.9 | % |  | 13.7 | % |  | 12.7 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring Silent-Aire purchase accounting impacts and transaction costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |  | — |  |
| Integration costs | — |  |  | 7 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 8 |  |  | — |  |  | 15 |  |
| Adjusted segment EBITA | $ | 847 |  |  | $ | 823 |  |  | $ | 284 |  |  | $ | 237 |  |  | $ | 237 |  |  | $ | 229 |  |  | $ | 1,012 |  |  | $ | 805 |  |  | $ | 2,380 |  |  | $ | 2,094 |  |
| Adjusted segment EBITA margin | 13.4 | % |  | 12.9 | % |  | 10.3 | % |  | 9.4 | % |  | 12.3 | % |  | 13.1 | % |  | 16.2 | % |  | 14.1 | % |  | 13.8 | % |  | 12.8 | % |

[0000833444-21-000038:8k_2_02:101]
(2) Adjusted Corporate expenses excludes special items because these costs are not considered to be directly related to the underlying operating performance of the Company's business. Adjusted Corporate expenses for the three months ended June 30, 2020 excludes $19 million of integration costs. Adjusted Corporate expenses for the nine months ended June 30, 2020 excludes $92 million of integration costs.

[0000833444-21-000038:8k_2_02:102]
(3) Adjusted amortization of intangible assets for the three and nine months ended June 30, 2021 excludes $3 million of nonrecurring asset amortization related to Silent-Aire purchase accounting.

[0000833444-21-000038:8k_2_02:103]
(4) The three months ended June 30, 2021 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $66 million. The nine months ended June 30, 2021 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $296 million. The three months ended June 30, 2020 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $132 million. The nine months ended June 30, 2020 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $154 million.

[0000833444-21-000038:8k_2_02:104]
(5) Restructuring and impairment costs for the three months ended June 30, 2021 of $79 million are excluded from the adjusted non-GAAP results. Restructuring and impairment costs for the nine months ended June 30, 2021 of $175 million are excluded from the adjusted non-GAAP results. Restructuring and impairment costs for the three months ended June 30, 2020 of $610 million are excluded from the adjusted non-GAAP results. Restructuring and impairment costs for the nine months ended June 30, 2020 of $783 million are excluded from the adjusted non-GAAP results. The restructuring actions and impairment costs related primarily to workforce reductions, plant closures and asset impairments.

[0000833444-21-000038:8k_2_02:105]
(6) Management defines earnings before interest and taxes (EBIT) as income (loss) from continuing operations before net financing charges, income taxes and noncontrolling interests. EBIT is a non-GAAP performance measure. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company. A reconciliation of EBIT to income from continuing operations is shown earlier within this footnote.

[0000833444-21-000038:8k_2_02:106]
(7) Adjusted income tax provision for the three months ended June 30, 2021 excludes tax provisions from net mark-to-market adjustments of $17 million, partially offset by tax benefits related to restructuring and impairment costs of $15 million, and tax benefits related to Silent-Aire nonrecurring purchase accounting of $1 million. Adjusted income tax provision for the nine months ended June 30, 2021 excludes tax provisions from a Mexico valuation allowance adjustment of $105 million and net mark-to-market adjustments of $75 million, partially offset by tax benefits related to restructuring and impairment costs of $30 million, and tax benefits related to Silent-Aire nonrecurring purchase accounting of $1 million. Adjusted income tax provision for the three months ended June 30, 2020 excludes tax benefits from net mark-to-market adjustments of $34 million, restructuring and impairment costs of $28 million, tax audit reserve adjustments of $22 million, and integration costs of $4 million. Adjusted income tax provision for the nine months ended June 30, 2020 excludes tax benefits from restructuring and impairment costs of $48 million, tax audit reserve adjustments of $44 million, net mark-to-market adjustments of $38 million, and integration costs of $15 million, partially offset by tax provisions related to Switzerland tax reform of $30 million.

[0000833444-21-000038:8k_2_02:107]
Page 15 of 19

[0000833444-21-000038:8k_2_02:108]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-21-000038:8k_2_02:109]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include integration costs, net mark-to-market adjustments, restructuring and impairment costs, Silent-Aire transaction costs and other nonrecurring costs, Power Solutions divestiture reserve adjustment and discrete tax items. The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-21-000038:8k_2_02:110]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-21-000038:8k_2_02:111]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Three Months Ended |  | Three Months Ended |  | Nine Months Ended |  | Nine Months Ended |
|  | June 30, |  | June 30, |  | June 30, |  | June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Earnings per share as reported for JCI plc | $ | 0.80 |  |  | $ | (0.24) |  |  | $ | 0.80 |  |  | $ | (0.24) |  |  | $ | 1.89 |  |  | $ | 0.25 |  |  | $ | 1.72 |  |  | $ | 0.25 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | — |  |  | 0.04 |  |  | — |  |  | 0.04 |  |  | — |  |  | 0.14 |  |  | — |  |  | 0.14 |  |
| Related tax impact | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.02) |  |  | — |  |  | (0.02) |  |
| Net mark-to-market adjustments | (0.09) |  |  | 0.18 |  |  | (0.09) |  |  | 0.18 |  |  | (0.41) |  |  | 0.20 |  |  | (0.41) |  |  | 0.20 |  |
| Related tax impact | 0.02 |  |  | (0.05) |  |  | 0.02 |  |  | (0.05) |  |  | 0.10 |  |  | (0.05) |  |  | 0.10 |  |  | (0.05) |  |
| Restructuring and impairment costs | 0.11 |  |  | 0.82 |  |  | 0.11 |  |  | 0.82 |  |  | 0.24 |  |  | 1.03 |  |  | 0.24 |  |  | 1.03 |  |
| Related tax impact | (0.02) |  |  | (0.04) |  |  | (0.02) |  |  | (0.04) |  |  | (0.04) |  |  | (0.06) |  |  | (0.04) |  |  | (0.06) |  |
| NCI impact of restructuring and impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |
| Silent-Aire transaction costs and other nonrecurring costs | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Power Solutions divestiture reserve adjustment | — |  |  | — |  |  | — |  |  | — |  |  | (0.21) |  |  | — |  |  | — |  |  | — |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |  | 0.04 |  |  | — |  |  | — |  |  | — |  |
| Discrete tax items | — |  |  | (0.03) |  |  | — |  |  | (0.03) |  |  | 0.15 |  |  | (0.02) |  |  | 0.15 |  |  | (0.02) |  |
| NCI impact of discrete tax items | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |
| Adjusted earnings per share for JCI plc* | $ | 0.83 |  |  | $ | 0.67 |  |  | $ | 0.83 |  |  | $ | 0.67 |  |  | $ | 1.77 |  |  | $ | 1.48 |  |  | $ | 1.77 |  |  | $ | 1.48 |  |

[0000833444-21-000038:8k_2_02:112]
* May not sum due to rounding

[0000833444-21-000038:8k_2_02:113]
Page 16 of 19

[0000833444-21-000038:8k_2_02:114]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-21-000038:8k_2_02:115]
|  | Three Months Ended |  | Nine Months Ended |  |  |  |  |
|  | June 30, |  | June 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 714.5 |  |  | 744.0 |  |  | 718.2 |  |  | 756.3 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |  |  |  |  |
| and unvested performance share awards | 5.2 |  |  | — |  |  | 4.3 |  |  | 2.6 |  |  |  |  |  |
| Diluted weighted average shares outstanding | 719.7 |  |  | 744.0 |  |  | 722.5 |  |  | 758.9 |  |  |  |  |  |

[0000833444-21-000038:8k_2_02:116]
The Company has presented forward-looking statements regarding adjusted corporate expense, adjusted EPS, organic revenue, adjusted segment EBITA margin and free cash flow conversion, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, or income from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments and the effect of foreign currency exchange fluctuations. Our fiscal 2021 full year and fourth quarter guidance for organic revenue also excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s full year and fourth quarter 2021 GAAP financial results.

[0000833444-21-000038:8k_2_02:117]
3. Organic Growth Reconciliation

[0000833444-21-000038:8k_2_02:118]
The components of the changes in adjusted net sales for the three months ended June 30, 2021 versus the three months ended June 30, 2020, including organic growth, is shown below (unaudited):

[0000833444-21-000038:8k_2_02:119]
| (in millions) | Adjusted Net Sales for theThree Months EndedJune 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the ThreeMonths EndedJune 30, 2020 |  | Acquisitions |  | Organic Growth |  | Adjusted Net Sales for the Three Months EndedJune 30, 2021 |
| Building Solutions North America | $ | 2,020 |  |  | $ | — |  | — |  |  | $ | 21 |  | 1 | % |  | $ | 2,041 |  |  | $ | — |  | — |  |  | $ | 171 |  | 8 | % |  | $ | 2,212 |  | 10 | % |
| Building Solutions EMEA/LA | 756 |  |  | — |  | — |  |  | 56 |  | 7 | % |  | 812 |  |  | 10 |  | 1 | % |  | 140 |  | 17 | % |  | 962 |  | 27 | % |
| Building Solutions Asia Pacific | 588 |  |  | (3) |  | -1 | % |  | 41 |  | 7 | % |  | 626 |  |  | — |  | — |  |  | 86 |  | 14 | % |  | 712 |  | 21 | % |
| Total field | 3,364 |  |  | (3) |  | — |  |  | 118 |  | 4 | % |  | 3,479 |  |  | 10 |  | — |  |  | 397 |  | 11 | % |  | 3,886 |  | 16 | % |
| Global Products | 1,979 |  |  | (54) |  | -3 | % |  | 47 |  | 2 | % |  | 1,972 |  |  | 80 |  | 4 | % |  | 406 |  | 21 | % |  | 2,458 |  | 24 | % |
| Total net sales | $ | 5,343 |  |  | $ | (57) |  | -1 | % |  | $ | 165 |  | 3 | % |  | $ | 5,451 |  |  | $ | 90 |  | 2 | % |  | $ | 803 |  | 15 | % |  | $ | 6,344 |  | 19 | % |

[0000833444-21-000038:8k_2_02:120]
The components of the changes in adjusted net sales for the nine months ended June 30, 2021 versus the nine months ended June 30, 2020, including organic growth, is shown below (unaudited):

[0000833444-21-000038:8k_2_02:121]
| (in millions) | Adjusted Net Sales for theNine Months Ended June 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the NineMonths EndedJune 30, 2020 |  | Acquisitions |  | Organic Growth |  | Adjusted Net Sales for the Nine Months EndedJune 30, 2021 |
| Building Solutions North America | $ | 6,362 |  |  | $ | — |  | — |  |  | $ | 37 |  | 1 | % |  | $ | 6,399 |  |  | $ | — |  | — |  |  | $ | (61) |  | -1 | % |  | $ | 6,338 |  | — |  |
| Building Solutions EMEA/LA | 2,534 |  | — |  | — |  |  | 119 | 5 | % |  | 2,653 |  |  | 23 |  | 1 | % |  | 89 |  | 3 | % |  | 2,765 |  | 9 | % |
| Building Solutions Asia Pacific | 1,742 |  | (7) |  | — |  |  | 99 | 6 | % |  | 1,834 |  |  | — |  | — |  |  | 96 |  | 5 | % |  | 1,930 |  | 11 | % |
| Total field | 10,638 |  | (7) |  | — |  |  | 255 |  | 2 | % |  | 10,886 |  |  | 23 |  | — |  |  | 124 |  | 1 | % |  | 11,033 |  | 4 | % |
| Global Products | 5,725 |  | (187) |  | -3 | % |  | 135 | 2 | % |  | 5,673 |  |  | 80 |  | 1 | % |  | 493 |  | 9 | % |  | 6,246 |  | 9 | % |
| Total net sales | $ | 16,363 |  |  | $ | (194) |  | -1 | % |  | $ | 390 |  | 2 | % |  | $ | 16,559 |  |  | $ | 103 |  | 1 | % |  | $ | 617 |  | 4 | % |  | $ | 17,279 |  | 6 | % |

[0000833444-21-000038:8k_2_02:122]
4.  Free Cash Flow Reconciliation

[0000833444-21-000038:8k_2_02:123]
The Company's press release contains financial information regarding free cash flow which is a non-GAAP performance measure. Free cash flow is defined as cash provided by operating activities less capital expenditures. Management believes this non-GAAP measure is useful to investors in understanding the strength of the Company and its ability to generate cash.

[0000833444-21-000038:8k_2_02:124]
The following is the three months and nine months ended June 30, 2021 and 2020 reconciliation of free cash flow for continuing operations (unaudited):

[0000833444-21-000038:8k_2_02:125]
| (in millions) | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |  |  |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |
| Cash provided by operating activities from continuing operations | $ | 862 |  |  | $ | 833 |  |  | $ | 2,022 |  |  | $ | 1,499 |  |  |  |
| Capital expenditures | (127) |  |  | (97) |  |  | (324) |  |  | (347) |  |  |  |
| Reported free cash flow | $ | 735 |  |  | $ | 736 |  |  | $ | 1,698 |  |  | $ | 1,152 |  |  |  |

[0000833444-21-000038:8k_2_02:126]
Page 17 of 19

[0000833444-21-000038:8k_2_02:127]
5.  Net Debt to EBITDA

[0000833444-21-000038:8k_2_02:128]
The Company provides financial information regarding net debt to adjusted EBITDA, which is a non-GAAP performance measure. The Company believes the total net debt to adjusted EBITDA ratio is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. The following is the June 30, 2021 calculation of net debt to adjusted EBITDA (unaudited):

[0000833444-21-000038:8k_2_02:129]
| (in millions) | June 30, 2021 |  |  |
| Short-term debt and current portion of long-term debt | $ | 461 |  |  |  |
| Long-term debt | 7,318 |  |  |  |
| Total debt | 7,779 |  |  |  |
| Less: cash and cash equivalents | 1,450 |  |  |  |
| Total net debt | $ | 6,329 |  |  |  |
| Last twelve months adjusted EBITDA | $ | 3,459 |  |  |  |
| Total net debt to adjusted EBITDA | 1.8x |  |  |

[0000833444-21-000038:8k_2_02:130]
The following is the last twelve months ended June 30, 2021 reconciliation of income from continuing operations to adjusted EBIT and adjusted EBITDA, which are non-GAAP performance measures (unaudited):

[0000833444-21-000038:8k_2_02:131]
| (in millions) | Last Twelve MonthsEndedJune 30, 2021 |  |  |
| Income from continuing operations | $ | 1,920 |  |  |  |
| Income tax provision | 409 |  |  |  |
| Net financing charges | 221 |  |  |  |
| EBIT | 2,550 |  |  |  |
| Adjusting items: |  |  |  |
| Integration costs | 28 |  |  |  |
| Silent-Aire transaction costs and other nonrecurring costs | 10 |  |  |  |
| Net mark-to-market adjustments | (176) |  |  |  |
| Restructuring and impairment costs | 175 |  |  |  |
| Acquisition related compensation charge | 39 |  |  |  |
| Adjusted EBIT (1) | 2,626 |  |  |  |
| Depreciation and amortization | 833 |  |  |  |
| Adjusted EBITDA (1) | $ | 3,459 |  |  |  |

[0000833444-21-000038:8k_2_02:132]
(1) The Company's definition of adjusted EBIT and adjusted EBITDA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-21-000038:8k_2_02:133]
Page 18 of 19

[0000833444-21-000038:8k_2_02:134]
6.  Trade Working Capital as a Percentage of Net Sales

[0000833444-21-000038:8k_2_02:135]
The Company provides financial information regarding trade working capital as a percentage of net sales, which is a non-GAAP performance measure. Trade working capital is defined as current assets less current liabilities, excluding cash, short-term debt, the current portion of long-term debt, the current portion of assets and liabilities held for sale, accrued compensation and benefits, and other current assets and liabilities.  Management believes this non-GAAP measure, which excludes financing-related items, non-trade related items and businesses to be divested, is a more useful measurement of the Company's operating performance. The following is the June 30, 2021 and June 30, 2020 calculation of trade working capital as a percentage of net sales (unaudited):

[0000833444-21-000038:8k_2_02:136]
| (in millions) | June 30, 2021 |  | June 30, 2020 |
| Current assets | $ | 10,310 |  |  | $ | 11,140 |  |
| Current liabilities | (9,285) |  |  | (10,304) |  |
| Total working capital | 1,025 |  |  | 836 |  |
| Less: cash and cash equivalents | (1,450) |  |  | (2,342) |  |
| Less: assets held for sale | — |  |  | (89) |  |
| Less: other current assets | (1,128) |  |  | (1,369) |  |
| Add: short-term debt | 265 |  |  | 1,321 |  |
| Add: current portion of long-term debt | 196 |  |  | 1,102 |  |
| Add: accrued compensation and benefits | 996 |  |  | 685 |  |
| Add: liabilities held for sale | — |  |  | 38 |  |
| Add: other current liabilities | 2,460 |  |  | 2,650 |  |
| Trade working capital | $ | 2,364 |  |  | $ | 2,832 |  |
| Last twelve months net sales | $ | 23,230 |  |  | $ | 22,637 |  |
| Trade working capital as a percentage of net sales | 10.2 | % |  | 12.5 | % |

[0000833444-21-000038:8k_2_02:137]
7.  Income Taxes

[0000833444-21-000038:8k_2_02:138]
The Company's effective tax rate from continuing operations before consideration of transaction/integration costs, net mark-to-market adjustments, Silent-Aire nonrecurring purchase accounting, restructuring and impairment costs, and discrete tax items for the three and nine months ended June 30, 2021 and June 30, 2020 was approximately 13.5%.

[0000833444-21-000038:8k_2_02:139]
8.  Restructuring and Impairment Costs

[0000833444-21-000038:8k_2_02:140]
The three months ended June 30, 2021 include restructuring and impairment costs of $79 million related primarily to workforce reductions, asset impairments and other related costs. The nine months ended June 30, 2021 include restructuring and impairment costs of $175 million related primarily to workforce reductions, asset impairments and other related costs. The three months ended June 30, 2020 include restructuring and impairment costs of $610 million related to workforce reductions, asset impairments and goodwill impairments related to the Company's retail business. The nine months ended June 30, 2020 include restructuring and impairment costs of $783 million related primarily to workforce reductions, plant closures, asset impairments, and indefinite-lived intangible asset and goodwill impairments related to the Company's retail business.

[0000833444-21-000038:8k_2_02:141]
Page 19 of 19
