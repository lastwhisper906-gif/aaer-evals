# JCI notes — 0000833444-21-000040


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-21-000040:notes:1]
Financial Statements
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2020 filed with the SEC on November 16, 2020. The results of operations for the three and nine month periods ended June 30, 2021 are not necessarily indicative of results for the Company’s 2021 fiscal year because of seasonal and other factors.

[0000833444-21-000040:notes:2]
[same as prior period, unchanged from 0000833444-21-000020:notes:2]

[0000833444-21-000040:notes:3]
[same as prior period, unchanged from 0000833444-21-000020:notes:3]

[0000833444-21-000040:notes:4]
[same as prior period, unchanged from 0000833444-21-000020:notes:4]

[0000833444-21-000040:notes:5]
[same as prior period, unchanged from 0000833444-21-000020:notes:5]

[0000833444-21-000040:notes:6]
[same as prior period, unchanged from 0000833444-21-000020:notes:6]

[0000833444-21-000040:notes:7]
[same as prior period, unchanged from 0000833444-21-000020:notes:7]

[0000833444-21-000040:notes:8]
[same as prior period, unchanged from 0000833444-21-000020:notes:8]

[0000833444-21-000040:notes:9]
At June 30, 2021 and September 30, 2020, the Company held restricted cash of approximately $7 million and $9 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000833444-21-000040:notes:10]
New Accounting Standards
Recently Adopted Accounting Pronouncements

[0000833444-21-000040:notes:11]
In June 2016, the FASB issued ASU No. 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments." ASU No. 2016-13 and its related amendments replace the previous expected credit loss methodology with a new incurred loss methodology. The new standard applies to financial instruments, including, but not limited to, trade receivables. Under the new standard, companies must consider historical information, current conditions and a reasonable forecast period when estimating credit losses. The Company adopted ASU No. 2016-13 and the related amendments effective October 1, 2020. The adoption did not have a material impact on the Company's consolidated financial statements. Refer to Note 6, “Accounts Receivable, Net,” of the notes to the consolidated financial statements for further information.

[0000833444-21-000040:notes:12]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-21-000040:notes:13]
Acquisitions and Divestitures
Silent-Aire Acquisition

[0000833444-21-000040:notes:14]
On May 12, 2021, the Company completed its acquisition of Silent-Aire, a global leader in hyperscale data center cooling and modular critical infrastructure solutions, for approximately $751 million, net of cash acquired, which is comprised of an upfront net cash payment of approximately $661 million and the estimated fair value of contingent earn-out liabilities of approximately $90 million. The contingent earn-out liabilities are based upon the achievement of certain defined operating results in each of the three years following the acquisition, with a maximum payout of approximately $250 million. The fair value of contingent earn-out liabilities is reassessed on a quarterly basis and could differ materially from the initial estimates. Subsequent changes in the estimated fair value of contingent earn-out liabilities will be recorded in the consolidated statements of income when incurred. The earn-out payments that are less than or equal to the contingent earn-out liabilities on the acquisition date are reflected as financing cash outflows and amounts paid in excess of the contingent earn-out liabilities on the acquisition date are reflected as operating cash outflows. The Silent-Aire business is reported within the Global Products segment.

[0000833444-21-000040:notes:15]
In connection with the acquisition, the Company recorded goodwill of $235 million in the Global Products segment. Goodwill is attributable primarily to expected synergies, expanded market opportunities and other benefits that the Company believes will result from combining its operations with the operations of Silent-Aire. The goodwill created in the acquisition is not deductible for tax purposes and is subject to change as the purchase price allocation is completed.

[0000833444-21-000040:notes:16]
The preliminary fair values of the assets acquired and liabilities assumed related to Silent-Aire are as follows (in millions):

[0000833444-21-000040:notes:17]
| Cash and cash equivalents |  | $ | 5 |  |
| Accounts receivable |  | 141 |  |
| Inventories |  | 61 |  |
| Other current assets |  | 3 |  |
| Property, plant, and equipment - net |  | 33 |  |
| Goodwill |  | 235 |  |
| Intangible assets - net |  | 499 |  |
| Other noncurrent assets |  | 83 |  |
| Total assets acquired |  | $ | 1,060 |  |
| Accounts payable |  | 62 |  |
| Accrued compensation and benefits |  | 5 |  |
| Deferred revenue |  | 32 |  |
| Other current liabilities |  | 10 |  |
| Other noncurrent liabilities |  | 195 |  |
| Total liabilities acquired |  | $ | 304 |  |
| Net assets acquired |  | $ | 756 |  |

[0000833444-21-000040:notes:18]
The preliminary purchase price allocation to identifiable intangible assets acquired related to Silent-Aire are as follows:

[0000833444-21-000040:notes:19]
|  |  | Preliminary Fair Value (in millions) |  | Weighted Average Life (in years) |
| Customer relationships |  | $ | 275 |  |  | 19 |
| Technology |  | 126 |  |  | 13 |
| Other definite-lived intangibles |  | 21 |  |  | 1 |
| Indefinite-lived trademarks |  | 77 |  |  |  |
| Total identifiable intangible assets |  | $ | 499 |  |  |  |

[0000833444-21-000040:notes:20]
The purchase price allocations may be subsequently adjusted to reflect final valuation studies.

[0000833444-21-000040:notes:21]
Other acquisitions and divestitures

[0000833444-21-000040:notes:22]
During the first nine months of fiscal 2021, the Company completed certain additional acquisitions for a combined purchase price, net of cash acquired, of $58 million, of which $46 million was paid as of June 30, 2021.  In connection with the acquisitions, the Company recorded goodwill of $21 million within the Building Solutions EMEA/LA segment and $17 million within the Building Solutions North America segment.

[0000833444-21-000040:notes:23]
During the first nine months of fiscal 2021, the Company completed certain divestitures within the Buildings Solutions Asia Pacific segment. The combined selling price was $27 million, of which $19 million was received as of June 30, 2021. In connection with the divestitures, the Company reduced goodwill by $7 million.

[0000833444-21-000040:notes:24]
During the first nine months of fiscal 2020, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $63 million, of which $59 million was paid as of June 30, 2020. In connection with the acquisitions, the Company recorded goodwill of $19 million within the Global Products segment and $23 million within the Building Solutions EMEA/LA segment.
Acquisitions and divestitures were not material to the Company's consolidated financial statements in the first nine months of fiscal 2021 or 2020.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-21-000040:notes:25]
Discontinued Operations
On April 30, 2019, the Company completed the sale of its Power Solutions business, which met the criteria to be classified as a discontinued operation, to BCP Acquisitions LLC for a purchase price of $13.2 billion. The net cash proceeds after tax and transaction-related expenses were $11.6 billion. In connection with the sale, the Company recorded a gain, net of transaction and other costs, of $5.2 billion ($4.0 billion after tax), subject to post-closing working capital and net debt adjustments, within income from discontinued operations, net of tax, in the consolidated statements of income. In December 2020, the favorable resolution of certain post-closing working capital and net debt adjustments resulted in income from discontinued operations, net of tax, of $124 million due to a reversal of a reserve established in connection with the sale of Power Solutions.

[0000833444-21-000040:notes:26]
The following table summarizes the results of Power Solutions which are classified as discontinued operations for the nine months ended June 30, 2021 (in millions). There is no Power Solutions related activity for the three months ended June 30, 2021 and the three and nine months ended June 30, 2020.

[0000833444-21-000040:notes:27]
|  |  |  | Nine Months Ended June 30, 2021 |
| Net sales |  |  | $ | — |  |
| Income from discontinued operations before income taxes |  |  | 150 |  |
| Provision for income taxes on discontinued operations |  |  | (26) |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax |  |  | — |  |
| Income from discontinued operations |  |  | $ | 124 |  |

[0000833444-21-000040:notes:28]
[same as prior period, unchanged from 0000833444-21-000020:notes:17]

[0000833444-21-000040:notes:29]
During the second quarter of fiscal 2021, the Company determined that certain corporate assets met the criteria to be classified as held for sale. The carrying value of these assets was $29 million at June 30, 2021.
During the third quarter of fiscal 2020, the Company determined that certain assets of the Building Solutions Asia Pacific segment met the criteria to be classified as held for sale. The estimated fair value, less costs to sell, of these assets was $156 million at June 30, 2021 and $147 million at September 30, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-21-000040:notes:30]
[same as prior period, unchanged from 0000833444-21-000020:notes:19]

[0000833444-21-000040:notes:31]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and nine months ended June 30, 2021 and 2020 (in millions):

[0000833444-21-000040:notes:32]
|  |  | Three Months Ended June 30, 2021 |  | Three Months Ended June 30, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,355 |  |  | $ | 857 |  |  | $ | 2,212 |  |  | $ | 1,250 |  |  | $ | 770 |  |  | $ | 2,020 |  |
| Building Solutions EMEA/LA |  | 468 |  |  | 494 |  |  | 962 |  |  | 346 |  |  | 410 |  |  | 756 |  |
| Building Solutions Asia Pacific |  | 422 |  |  | 290 |  |  | 712 |  |  | 344 |  |  | 244 |  |  | 588 |  |
| Global Products |  | 2,455 |  |  | — |  |  | 2,455 |  |  | 1,979 |  |  | — |  |  | 1,979 |  |
| Total |  | $ | 4,700 |  |  | $ | 1,641 |  |  | $ | 6,341 |  |  | $ | 3,919 |  |  | $ | 1,424 |  |  | $ | 5,343 |  |

[0000833444-21-000040:notes:33]
|  |  | Nine Months Ended June 30, 2021 |  | Nine Months Ended June 30, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,869 |  |  | $ | 2,469 |  |  | $ | 6,338 |  |  | $ | 3,963 |  |  | $ | 2,399 |  |  | $ | 6,362 |  |
| Building Solutions EMEA/LA |  | 1,323 |  |  | 1,442 |  |  | 2,765 |  |  | 1,203 |  |  | 1,331 |  |  | 2,534 |  |
| Building Solutions Asia Pacific |  | 1,096 |  |  | 834 |  |  | 1,930 |  |  | 986 |  |  | 756 |  |  | 1,742 |  |
| Global Products |  | 6,243 |  |  | — |  |  | 6,243 |  |  | 5,725 |  |  | — |  |  | 5,725 |  |
| Total |  | $ | 12,531 |  |  | $ | 4,745 |  |  | $ | 17,276 |  |  | $ | 11,877 |  |  | $ | 4,486 |  |  | $ | 16,363 |  |

[0000833444-21-000040:notes:34]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and nine months ended June 30, 2021 and 2020 (in millions):

[0000833444-21-000040:notes:35]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 1,811 |  |  | $ | 1,503 |  |  | $ | 4,462 |  |  | $ | 4,127 |  |
| Fire & Security |  | 580 |  |  | 422 |  |  | 1,605 |  |  | 1,425 |  |
| Industrial Refrigeration |  | 64 |  |  | 54 |  |  | 176 |  |  | 173 |  |
| Total |  | $ | 2,455 |  |  | $ | 1,979 |  |  | $ | 6,243 |  |  | $ | 5,725 |  |

[0000833444-21-000040:notes:36]
[same as prior period, unchanged from 0000833444-21-000020:notes:25]

[0000833444-21-000040:notes:37]
[same as prior period, unchanged from 0000833444-21-000020:notes:26]

[0000833444-21-000040:notes:38]
[same as prior period, unchanged from 0000833444-21-000020:notes:27]

[0000833444-21-000040:notes:39]
|  |  | Location of contract balances |  | June 30, 2021 |  | September 30, 2020 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,553 |  |  | $ | 1,395 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 95 |  |  | 104 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,649) |  |  | (1,435) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (263) |  |  | (245) |  |  |  |
| Total |  |  |  | $ | (264) |  |  | $ | (181) |  |  |  |

[0000833444-21-000040:notes:40]
For the three months ended June 30, 2021 and June 30, 2020, the Company recognized revenue of $149 million and $125 million, respectively, that was included in the beginning of period contract liability balance. For the nine months ended June 30, 2021 and June 30, 2020, the Company recognized revenue of $1,084 million and $1,137 million, respectively, that was included in the beginning of period contract liability balance.

[0000833444-21-000040:notes:41]
[same as prior period, unchanged from 0000833444-21-000020:notes:30]

[0000833444-21-000040:notes:42]
[same as prior period, unchanged from 0000833444-21-000020:notes:31]

[0000833444-21-000040:notes:43]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of June 30, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $15.6 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-21-000040:notes:44]
[same as prior period, unchanged from 0000833444-21-000020:notes:33]

[0000833444-21-000040:notes:45]
[same as prior period, unchanged from 0000833444-21-000020:notes:34]

[0000833444-21-000040:notes:46]
As of June 30, 2021, the Company recorded the costs to obtain or fulfill a contract of $258 million, of which $143 million is recorded within other current assets and $115 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2020, the Company recorded the costs to obtain or fulfill a contract of $223 million, of which $119 million is recorded within other current assets and $104 million is recorded within other noncurrent assets in the consolidated statements of financial position.

[0000833444-21-000040:notes:47]
During the three months ended June 30, 2021 and 2020, the Company recognized amortization expense of $48 million and $47 million, respectively, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2021 and 2020, the Company recognized amortization expense of $136 million and $116 million, respectively, related to costs to 
obtain or fulfill a contract. There were no impairment losses recognized in the three and nine months ended June 30, 2021 and 2020.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0000833444-21-000040:notes:48]
[same as prior period, unchanged from 0000833444-21-000020:notes:37]

[0000833444-21-000040:notes:49]
[same as prior period, unchanged from 0000833444-21-000020:notes:38]

[0000833444-21-000040:notes:50]
|  |  | June 30, 2021 |  | September 30, 2020 |  |  |
| Accounts receivable |  | $ | 5,798 |  |  | $ | 5,467 |  |  |  |
| Less: Allowance for expected credit losses (1) |  | (130) |  |  | (173) |  |  |  |
| Accounts receivable, net |  | $ | 5,668 |  |  | $ | 5,294 |  |  |  |

[0000833444-21-000040:notes:51]
(1) Allowance for doubtful accounts as of September 30, 2020, prior to the adoption of ASU 2016-13.

[0000833444-21-000040:notes:52]
The changes in the allowance for expected credit losses related to accounts receivable for the nine month period ended June 30, 2021 were as follows (in millions):

[0000833444-21-000040:notes:53]
|  |  | Nine Months Ended June 30, 2021 |
| Balance as of September 30, 2020 |  | $ | 173 |  |  |  |
| Write-offs charged against the allowance for expected credit losses |  | (50) |  |  |  |
| Other (including impact of adoption of ASU 2016-13) |  | 7 |  |  |  |
| Balance as of June 30, 2021 |  | $ | 130 |  |  |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-21-000040:notes:54]
[same as prior period, unchanged from 0000833444-21-000020:notes:43]

[0000833444-21-000040:notes:55]
The following table presents supplemental consolidated statement of financial position information as of June 30, 2021 and September 30, 2020 (in millions):

[0000833444-21-000040:notes:56]
|  | Location of lease balances |  | June 30, 2021 |  | September 30, 2020 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,369 |  |  | $ | 1,190 |  |
| Operating lease liabilities - current | Other current liabilities |  | 323 |  |  | 332 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 1,058 |  |  | 875 |  |

[0000833444-21-000040:notes:57]
The following table presents supplemental noncash operating lease activity, excluding leases acquired in business combinations, for the nine months ended June 30, 2021 and 2020 (in millions):

[0000833444-21-000040:notes:58]
|  |  |  |  | Nine Months Ended June 30, |  |  |
|  |  |  |  |  |  | 2021 |  | 2020 |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  |  |  |  |  | $ | 411 |  |  | $ | 315 |  |  |  |


## us-gaap:InventoryDisclosureTextBlock

[0000833444-21-000040:notes:59]
[same as prior period, unchanged from 0000833444-21-000020:notes:48]

[0000833444-21-000040:notes:60]
|  | June 30, 2021 |  | September 30, 2020 |
| Raw materials and supplies | $ | 754 |  |  | $ | 629 |  |
| Work-in-process | 162 |  |  | 142 |  |
| Finished goods | 1,148 |  |  | 1,002 |  |
| Inventories | $ | 2,064 |  |  | $ | 1,773 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-21-000040:notes:61]
Goodwill and Other Intangible Assets
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the nine month period ended June 30, 2021 were as follows (in millions):

[0000833444-21-000040:notes:62]
|  |  |  | Business Acquisitions |  |  |  | Business Divestitures |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  |  |  | June 30, |
|  | 2020 |  |  |  |  |  | 2021 |
| Building Solutions North America | $ | 9,160 |  |  | $ | 17 |  |  |  |  | $ | — |  |  | $ | 53 |  |  | $ | 9,230 |  |
| Building Solutions EMEA/LA | 1,967 |  |  | 21 |  |  |  |  | — |  |  | 76 |  |  | 2,064 |  |
| Building Solutions Asia Pacific | 1,226 |  |  | — |  |  |  |  | (7) |  |  | 46 |  |  | 1,265 |  |
| Global Products | 5,579 |  |  | 235 |  |  |  |  | — |  |  | 72 |  |  | 5,886 |  |
| Total | $ | 17,932 |  |  | $ | 273 |  |  |  |  | $ | (7) |  |  | $ | 247 |  |  | $ | 18,445 |  |

[0000833444-21-000040:notes:63]
[same as prior period, unchanged from 0000833444-21-000020:notes:52]

[0000833444-21-000040:notes:64]
The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. There were no triggering events requiring that an impairment assessment be conducted in the nine months ended June 30, 2021. However, it is possible that future changes in circumstances, including a more prolonged and/or severe COVID-19 pandemic, would require the Company to record additional non-cash impairment charges.

[0000833444-21-000040:notes:65]
[same as prior period, unchanged from 0000833444-21-000020:notes:54]

[0000833444-21-000040:notes:66]
|  | June 30, 2021 |  | September 30, 2020 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,484 |  |  | $ | (601) |  |  | $ | 883 |  |  | $ | 1,332 |  |  | $ | (497) |  |  | $ | 835 |  |
| Customer relationships | 3,107 |  |  | (1,146) |  |  | 1,961 |  |  | 2,773 |  |  | (969) |  |  | 1,804 |  |
| Miscellaneous | 719 |  |  | (329) |  |  | 390 |  |  | 657 |  |  | (268) |  |  | 389 |  |
|  | 5,310 |  |  | (2,076) |  |  | 3,234 |  |  | 4,762 |  |  | (1,734) |  |  | 3,028 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,365 |  |  | — |  |  | 2,365 |  |  | 2,248 |  |  | — |  |  | 2,248 |  |
| Miscellaneous | 80 |  |  | — |  |  | 80 |  |  | 80 |  |  | — |  |  | 80 |  |
|  | 2,445 |  |  | — |  |  | 2,445 |  |  | 2,328 |  |  | — |  |  | 2,328 |  |
| Total intangible assets | $ | 7,755 |  |  | $ | (2,076) |  |  | $ | 5,679 |  |  | $ | 7,090 |  |  | $ | (1,734) |  |  | $ | 5,356 |  |

[0000833444-21-000040:notes:67]
Amortization of other intangible assets included within continuing operations for the three month periods ended June 30, 2021 and 2020 was $112 million and $95 million, respectively. Amortization of other intangible assets included within continuing operations for the nine month periods ended June 30, 2021 and 2020 was $320 million and $288 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2022, 2023, 2024, 2025 and 2026 will be approximately $454 million, $436 million, $419 million, $401 million and $332 million per year, respectively.

[0000833444-21-000040:notes:68]
The Company reviews indefinite-lived intangible assets for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. There were no triggering events requiring that an impairment assessment be conducted in the nine months ended June 30, 2021. However, it is possible that future changes in circumstances, including a more prolonged and/or severe COVID-19 pandemic, would require the Company to record additional non-cash impairment charges.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-21-000040:notes:69]
[same as prior period, unchanged from 0000833444-21-000020:notes:58]

[0000833444-21-000040:notes:70]
In fiscal 2021, the Company committed to a significant restructuring plan ("2021 Plan"). During the three and nine months ended June 30, 2021, the Company recorded $79 million and $175 million of restructuring and impairment costs in the consolidated statements of income, respectively. The total amount expected to be incurred for this restructuring plan is $385 million across all segments and at Corporate. Of the restructuring and impairment costs recorded in the nine months ended June 30, 2021, $77 million related to the Global Products segment, $44 million related to the Building Solutions North America segment, $20 million related to the Building Solutions EMEA/LA segment, $19 million related to Corporate and $15 million related to the Building Solutions Asia Pacific segment.

[0000833444-21-000040:notes:71]
[same as prior period, unchanged from 0000833444-21-000020:notes:60]

[0000833444-21-000040:notes:72]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  | Total |
| Original reserve | $ | 32 |  |  | $ | 54 |  |  | $ | 10 |  |  |  |  | $ | 96 |  |
| Utilized—cash | (2) |  |  | — |  |  | (3) |  |  |  |  | (5) |  |
| Utilized—noncash | — |  |  | (54) |  |  | — |  |  |  |  | (54) |  |
| Balance at March 31, 2021 | $ | 30 |  |  | $ | — |  |  | $ | 7 |  |  |  |  | $ | 37 |  |
| Additional restructuring costs | 10 |  |  | 40 |  |  | 29 |  |  |  |  | 79 |  |
| Utilized—cash | (7) |  |  | — |  |  | (11) |  |  |  |  | (18) |  |
| Utilized—noncash | — |  |  | (40) |  |  | — |  |  |  |  | (40) |  |
| Balance at June 30, 2021 | $ | 33 |  |  | $ | — |  |  | $ | 25 |  |  |  |  | $ | 58 |  |

[0000833444-21-000040:notes:73]
[same as prior period, unchanged from 0000833444-21-000020:notes:62]

[0000833444-21-000040:notes:74]
[same as prior period, unchanged from 0000833444-21-000020:notes:63]

[0000833444-21-000040:notes:75]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  | Total |
| Original reserve | $ | 196 |  |  | $ | 96 |  |  | $ | 5 |  |  |  |  | $ | 297 |  |
| Utilized—cash | (92) |  |  | — |  |  | (3) |  |  |  |  | (95) |  |
| Utilized—noncash | — |  |  | (96) |  |  | — |  |  |  |  | (96) |  |
| Currency translation | 2 |  |  | — |  |  | — |  |  |  |  | 2 |  |
| Balance at September 30, 2020 | $ | 106 |  |  | $ | — |  |  | $ | 2 |  |  |  |  | $ | 108 |  |
| Utilized—cash | (62) |  |  | — |  |  | (2) |  |  |  |  | (64) |  |
| Currency translation | 1 |  |  | — |  |  | — |  |  |  |  | 1 |  |
| Balance at June 30, 2021 | $ | 45 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 45 |  |

[0000833444-21-000040:notes:76]
Also included in restructuring and impairment costs in the consolidated statements of income in fiscal 2020 are goodwill impairment related to the North America Retail reporting unit of $424 million and indefinite-lived intangible asset impairments of $62 million.

[0000833444-21-000040:notes:77]
The Company's fiscal 2021 and 2020 restructuring plans included workforce reductions of approximately 8,400 employees. Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of June 30, 2021, approximately 6,700 of the employees have been separated from the Company pursuant to the restructuring plans.

[0000833444-21-000040:notes:78]
Company management closely monitors its overall cost structure and continually analyzes each of its businesses for opportunities to consolidate current operations, improve operating efficiencies and locate facilities in close proximity to 
customers. This ongoing analysis includes a review of its manufacturing, engineering and purchasing operations, as well as the overall global footprint for all its businesses.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-21-000040:notes:79]
[same as prior period, unchanged from 0000833444-21-000020:notes:67]

[0000833444-21-000040:notes:80]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended June 30, 2021, the Company's effective tax rate for continuing operations was 14% and was higher than the statutory tax rate of 12.5% primarily due to the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the nine months ended June 30, 2021, the Company's effective tax rate for continuing operations was 21% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the three months ended June 30, 2020, the Company's effective tax rate for continuing operations was 1% and was lower than the statutory tax rate of 12.5% primarily due to tax audit reserve adjustments, the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives, partially offset by the tax impact of an impairment charge and tax rate differentials. For the nine months ended June 30, 2020, the Company's effective tax rate for continuing operations was 20% and was higher than the statutory tax rate of 12.5% primarily due to a discrete tax charge related to the remeasurement of deferred tax assets and liabilities as a result of Swiss tax reform, the tax impact of an impairment charge and tax rate differentials, partially offset by tax audit reserve adjustments, the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives.

[0000833444-21-000040:notes:81]
[same as prior period, unchanged from 0000833444-21-000020:notes:69]

[0000833444-21-000040:notes:82]
[same as prior period, unchanged from 0000833444-21-000020:notes:70]

[0000833444-21-000040:notes:83]
[same as prior period, unchanged from 0000833444-21-000020:notes:71]

[0000833444-21-000040:notes:84]
[same as prior period, unchanged from 0000833444-21-000020:notes:72]

[0000833444-21-000040:notes:85]
At September 30, 2020, the Company had gross tax effected unrecognized tax benefits of $2,528 million, of which $2,132 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2020 was approximately $205 million (net of tax benefit). Total net accrued interest during the nine months ended June 30, 2021 and 2020 was approximately $37 million (net of tax benefit) and approximately $55 million (net of tax benefit), respectively. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-21-000040:notes:86]
In the third quarter of fiscal 2020, tax audit resolutions resulted in a $22 million net benefit to income tax expense.

[0000833444-21-000040:notes:87]
[same as prior period, unchanged from 0000833444-21-000020:notes:74]

[0000833444-21-000040:notes:88]
[same as prior period, unchanged from 0000833444-21-000020:notes:75]

[0000833444-21-000040:notes:89]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2020 |
| China |  | 2017 - 2019 |
| Germany |  | 2007 - 2018 |
| Luxembourg |  | 2017 - 2018 |
| Mexico |  | 2015 - 2020 |
| United Kingdom |  | 2014 - 2015, 2018 |

[0000833444-21-000040:notes:90]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-21-000040:notes:91]
[same as prior period, unchanged from 0000833444-21-000020:notes:78]

[0000833444-21-000040:notes:92]
In the third quarter of fiscal 2021, the Company recorded net mark-to-market gains of $66 million. The gains generated tax expense of $17 million, which reflects the Company’s current tax position in the impacted jurisdictions.

[0000833444-21-000040:notes:93]
In the third quarter of fiscal 2021, the Company recorded $79 million of restructuring and impairment costs. Refer to Note 10, “Significant Restructuring and Impairment Costs,” of the notes to consolidated financial statements for additional information. The restructuring costs generated a $15 million tax benefit, which reflects the Company’s current tax position in the impacted jurisdictions.

[0000833444-21-000040:notes:94]
In the second quarter of fiscal 2021, the Company recorded net mark-to-market gains of $209 million. The gains generated tax expense of $53 million, which reflects the Company’s current tax position in the impacted jurisdictions.

[0000833444-21-000040:notes:95]
[same as prior period, unchanged from 0000833444-21-000020:notes:80]

[0000833444-21-000040:notes:96]
In the third quarter of fiscal 2020, the Company recorded net mark-to-market losses of $132 million. These losses generated a tax benefit of $34 million, which reflects the Company's current tax position in the impacted jurisdictions.

[0000833444-21-000040:notes:97]
In the third quarter of fiscal 2020, the Company recorded $610 million of restructuring and impairment costs. Refer to Note 10, “Significant Restructuring and Impairment Costs,” of the notes to consolidated financial statements for additional information. The restructuring costs generated a $28 million tax benefit, which reflects the Company’s current tax position in the impacted jurisdictions.

[0000833444-21-000040:notes:98]
[same as prior period, unchanged from 0000833444-21-000020:notes:81]

[0000833444-21-000040:notes:99]
[same as prior period, unchanged from 0000833444-21-000020:notes:82]

[0000833444-21-000040:notes:100]
[same as prior period, unchanged from 0000833444-21-000020:notes:83]

[0000833444-21-000040:notes:101]
[same as prior period, unchanged from 0000833444-21-000020:notes:84]

[0000833444-21-000040:notes:102]
In the first quarter of fiscal 2020, the Company recorded a noncash discrete tax charge of $30 million due to the remeasurement of deferred tax assets and liabilities related to Switzerland and the canton of Schaffhausen. On September 28, 2018, the Swiss Parliament approved the Federal Act on Tax Reform and AHV Financing (“TRAF”), which was subsequently approved by the Swiss electorate on May 19, 2019. During the fourth quarter of fiscal 2019, the Swiss Federal Council enacted TRAF which became effective for the Company on January 1, 2020. The impacts of the federal enactment did not have a material impact to the Company’s financial statements. TRAF also provides for parameters which enable the Swiss cantons to adjust tax rates and establish new regulations for companies. As of September 30, 2019, the canton of Schaffhausen had not concluded its public referendum; however, the enactment did occur during the first quarter of fiscal 2020.
During the nine months ended June 30, 2021 and 2020, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-21-000040:notes:103]
[same as prior period, unchanged from 0000833444-21-000020:notes:86]

[0000833444-21-000040:notes:104]
|  | U.S. Pension Plans |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Interest cost | $ | 14 |  |  | $ | 18 |  |  | $ | 36 |  |  | $ | 55 |  |
| Expected return on plan assets | (42) |  |  | (46) |  |  | (126) |  |  | (136) |  |
| Net actuarial loss (gain) | (49) |  |  | 157 |  |  | (252) |  |  | 157 |  |
| Settlement loss (gain) | (1) |  |  | 6 |  |  | (5) |  |  | 6 |  |
| Net periodic benefit cost (credit) | $ | (78) |  |  | $ | 135 |  |  | $ | (347) |  |  | $ | 82 |  |

[0000833444-21-000040:notes:105]
|  | Non-U.S. Pension Plans |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Service cost | $ | 7 |  |  | $ | 6 |  |  | $ | 20 |  |  | $ | 19 |  |
| Interest cost | 8 |  |  | 9 |  |  | 24 |  |  | 27 |  |
| Expected return on plan assets | (29) |  |  | (27) |  |  | (84) |  |  | (83) |  |
| Amortization of prior service cost | 1 |  |  | — |  |  | 1 |  |  | 1 |  |
| Net periodic benefit credit | $ | (13) |  |  | $ | (12) |  |  | $ | (39) |  |  | $ | (36) |  |

[0000833444-21-000040:notes:106]
|  | Postretirement Benefits |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Service cost | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest cost | — |  |  | 1 |  |  | 1 |  |  | 3 |  |
| Expected return on plan assets | (2) |  |  | (3) |  |  | (6) |  |  | (7) |  |
| Amortization of prior service credit | (1) |  |  | — |  |  | (3) |  |  | (1) |  |
| Net periodic benefit credit | $ | (3) |  |  | $ | (1) |  |  | $ | (7) |  |  | $ | (4) |  |

[0000833444-21-000040:notes:107]
During the second quarter of fiscal 2021, the amount of cumulative fiscal 2021 lump sum payouts triggered a remeasurement event for certain U.S. pension plans. During the three months ended June 30, 2021, the Company recognized net actuarial gains of $49 million, primarily due to favorable plan asset performance, partially offset by a decrease in discount rates. During the nine months ended June 30, 2021, the Company recognized the net actuarial gains of  $252 million, primarily due to an increase in discount rates and favorable plan asset performance.

[0000833444-21-000040:notes:108]
During the three months ended June 30, 2020, the amount of cumulative fiscal 2020 lump sum payouts triggered a remeasurement event for certain U.S. pension plans resulting in the recognition of net actuarial losses of $157 million, primarily due to a decrease in discount rates.


## us-gaap:DebtDisclosureTextBlock

[0000833444-21-000040:notes:109]
Debt and Financing Arrangements
Net Financing Charges

[0000833444-21-000040:notes:110]
Net financing charges consisted of the following (in millions):

[0000833444-21-000040:notes:111]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Interest expense, net of capitalized interest costs | $ | 55 |  |  | $ | 58 |  |  | $ | 167 |  |  | $ | 182 |  |
| Banking fees and bond cost amortization | 7 |  |  | 8 |  |  | 19 |  |  | 18 |  |
| Interest income | (1) |  |  | (3) |  |  | (7) |  |  | (21) |  |
| Net foreign exchange results for financing activities | (5) |  |  | (5) |  |  | (20) |  |  | (10) |  |
| Net financing charges | $ | 56 |  |  | $ | 58 |  |  | $ | 159 |  |  | $ | 169 |  |

[0000833444-21-000040:notes:112]
As of June 30, 2021, the Company has a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2021. As of June 30, 2021, there were no draws on the facilities.

[0000833444-21-000040:notes:113]
In July 2021, the Company issued a notice of redemption for all of its outstanding 3.75% senior notes maturing December 1, 2021. The notes have an aggregate principal amount of $171 million and will be redeemed on September 1, 2021.

[0000833444-21-000040:notes:114]
In May 2021, the Company retired €35 million in principal amount, plus accrued interest, of its 1.00% fixed rate notes expiring in September 2023.

[0000833444-21-000040:notes:115]
In March 2021, the Company entered into a bank term loan arrangement totaling €200 million due in March 2022 and retired $257 million in principal amount, plus accrued interest, of its 4.25% fixed rate notes that expired in March 2021.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-21-000040:notes:116]
Stock-Based Compensation
On March 10, 2021, the shareholders of the Company approved the Johnson Controls International plc 2021 Equity and Incentive Plan, which terminated the 2012 Share and Incentive Plan, as amended in September 2016 (collectively, the "Plans"). Both plans authorize stock options, stock appreciation rights, restricted (non-vested) stock/units, performance shares, performance units and other stock-based awards. The Compensation and Talent Development Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter.

[0000833444-21-000040:notes:117]
A summary of the stock-based awards granted during the nine month periods ended June 30, 2021 and 2020 is presented below:

[0000833444-21-000040:notes:118]
|  | Nine Months Ended June 30, |  |  |
|  | 2021 |  |  |  | 2020 |  |  |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |
| Stock options | 932,678 |  |  | $ | 9.36 |  |  |  |  | 1,347,310 |  |  | $ | 7.29 |  |  |  |
| Stock appreciation rights | 35,254 |  |  | 9.36 |  |  |  |  | — |  |  | — |  |  |  |
| Restricted stock/units | 1,773,617 |  |  | 47.08 |  |  |  |  | 1,896,383 |  |  | 41.41 |  |  |  |
| Performance shares | 410,934 |  |  | 50.53 |  |  |  |  | 476,939 |  |  | 42.48 |  |  |  |

[0000833444-21-000040:notes:119]
[same as prior period, unchanged from 0000833444-21-000020:notes:99]

[0000833444-21-000040:notes:120]
[same as prior period, unchanged from 0000833444-21-000020:notes:100]

[0000833444-21-000040:notes:121]
[same as prior period, unchanged from 0000833444-21-000020:notes:101]

[0000833444-21-000040:notes:122]
|  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |
| Expected life of option (years) | 6.5 |  | 6.5 |
| Risk-free interest rate | 0.6% |  | 1.67% |
| Expected volatility of the Company’s stock | 27.6% |  | 22.4% |
| Expected dividend yield on the Company’s stock | 2.28% |  | 2.49% |

[0000833444-21-000040:notes:123]
[same as prior period, unchanged from 0000833444-21-000020:notes:103]

[0000833444-21-000040:notes:124]
SARs vest under the same terms and conditions as stock option awards; however, they are settled in cash for the difference between the market price on the date of the exercise and the exercise price. As a result, SARs are recorded in the Company's consolidated financial statements of financial position as a liability until the date of exercise. The fair value of

[0000833444-21-000040:notes:125]
each SAR award is estimated using a similar method described for stock options. The fair value of each SAR award is recalculated at the end of each reporting period and the liability and expense are adjusted based on the new fair value.

[0000833444-21-000040:notes:126]
[same as prior period, unchanged from 0000833444-21-000020:notes:105]

[0000833444-21-000040:notes:127]
Restricted stock or restricted stock units are typically share settled unless the employee is a non-U.S. employee or elects to defer settlement until retirement at which point the award would be settled in cash. Restricted awards typically vest over a period of three years from the grant date. The Plans allow for different vesting terms on specific grants with approval by the Compensation and Talent Development Committee. The fair value of each share-settled restricted award is based on the closing market value of the Company’s ordinary shares on the date of grant. The fair value of each cash-settled restricted award is recalculated at the end of each reporting period based on the closing market value of the Company's ordinary shares at the end of the reporting period, and the liability and expense are adjusted based on the new fair value.

[0000833444-21-000040:notes:128]
[same as prior period, unchanged from 0000833444-21-000020:notes:107]

[0000833444-21-000040:notes:129]
[same as prior period, unchanged from 0000833444-21-000020:notes:108]

[0000833444-21-000040:notes:130]
The fair value of each PSU is estimated on the date of grant using a Monte Carlo simulation that uses the assumptions noted in the following table. The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant. The expected volatility is based on the historical volatility of the Company's stock over the most recent three-year period as of the grant date.

[0000833444-21-000040:notes:131]
|  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |
| Risk-free interest rate | 0.20% |  | 1.60% |
| Expected volatility of the Company’s stock | 30.9% |  | 21.8% |


## us-gaap:EarningsPerShareTextBlock

[0000833444-21-000040:notes:132]
Earnings Per ShareThe Company presents both basic and diluted earnings per share ("EPS") amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future and compensation cost for future service that the Company has not yet recognized. For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method include unamortized compensation cost.
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-21-000040:notes:133]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Income (Loss) Available to Ordinary Shareholders |  |  |  |  |  |  |  |
| Income (loss) from continuing operations | $ | 574 |  |  | $ | (182) |  |  | $ | 1,244 |  |  | $ | 190 |  |
| Income from discontinued operations | — |  |  | — |  |  | 124 |  |  | — |  |
| Basic and diluted income (loss) available to shareholders | $ | 574 |  |  | $ | (182) |  |  | $ | 1,368 |  |  | $ | 190 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 714.5 |  |  | 744.0 |  |  | 718.2 |  |  | 756.3 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 5.2 |  |  | — |  |  | 4.3 |  |  | 2.6 |  |
| Diluted weighted average shares outstanding | 719.7 |  |  | 744.0 |  |  | 722.5 |  |  | 758.9 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Options to purchase shares | — |  |  | — |  |  | 0.1 |  |  | 1.6 |  |

[0000833444-21-000040:notes:134]
For the three months ended June 30, 2020, the total number of potential dilutive shares due to stock options, unvested restricted stock and unvested performance share awards was 1.5 million. However, these items were not included in the computation of diluted loss per share for the three months ended June 30, 2020 since to do so would decrease the loss per share.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-21-000040:notes:135]
Equity and Noncontrolling Interests
Other comprehensive income includes activity relating to discontinued operations. The following schedules present changes in consolidated equity attributable to Johnson Controls and noncontrolling interests (in millions, net of tax):

[0000833444-21-000040:notes:136]
|  | Three Months Ended June 30, 2021 |  | Three Months Ended June 30, 2020 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, March 31 | $ | 17,698 |  |  | $ | 1,059 |  |  | $ | 18,757 |  |  | $ | 18,084 |  |  | $ | 1,004 |  |  | $ | 19,088 |  |
| Total comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | 574 |  |  | 87 |  |  | 661 |  |  | (182) |  |  | 60 |  |  | (122) |  |
| Foreign currency translation adjustments | 75 |  |  | 14 |  |  | 89 |  |  | 72 |  |  | 4 |  |  | 76 |  |
| Realized and unrealized gains (losses) on derivatives | (15) |  |  | (3) |  |  | (18) |  |  | 6 |  |  | — |  |  | 6 |  |
| Pension and postretirement plans | (1) |  |  | — |  |  | (1) |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income | 59 |  |  | 11 |  |  | 70 |  |  | 78 |  |  | 4 |  |  | 82 |  |
| Comprehensive income (loss) | 633 |  |  | 98 |  |  | 731 |  |  | (104) |  |  | 64 |  |  | (40) |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (193) |  |  | — |  |  | (193) |  |  | (195) |  |  | — |  |  | (195) |  |
| Repurchases and retirements of ordinary shares | (340) |  |  | — |  |  | (340) |  |  | — |  |  | — |  |  | — |  |
| Other, including options exercised | 42 |  |  | — |  |  | 42 |  |  | 20 |  |  | — |  |  | 20 |  |
| Ending balance, June 30 | $ | 17,840 |  |  | $ | 1,157 |  |  | $ | 18,997 |  |  | $ | 17,805 |  |  | $ | 1,068 |  |  | $ | 18,873 |  |

[0000833444-21-000040:notes:137]
|  | Nine Months Ended June 30, 2021 |  | Nine Months Ended June 30, 2020 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, September 30 | $ | 17,447 |  |  | $ | 1,086 |  |  | $ | 18,533 |  |  | $ | 19,766 |  |  | $ | 1,063 |  |  | $ | 20,829 |  |
| Total comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 1,368 |  |  | 186 |  |  | 1,554 |  |  | 190 |  |  | 115 |  |  | 305 |  |
| Foreign currency translation adjustments | 435 |  |  | 25 |  |  | 460 |  |  | (148) |  |  | (9) |  |  | (157) |  |
| Realized and unrealized gains (losses) on derivatives | (8) |  |  | (1) |  |  | (9) |  |  | 1 |  |  | 2 |  |  | 3 |  |
| Pension and postretirement plans | (2) |  |  | — |  |  | (2) |  |  | (1) |  |  | — |  |  | (1) |  |
| Other comprehensive income (loss) | 425 |  |  | 24 |  |  | 449 |  |  | (148) |  |  | (7) |  |  | (155) |  |
| Comprehensive income | 1,793 |  |  | 210 |  |  | 2,003 |  |  | 42 |  |  | 108 |  |  | 150 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (577) |  |  | — |  |  | (577) |  |  | (590) |  |  | — |  |  | (590) |  |
| Dividends attributable to noncontrolling interests | — |  |  | (133) |  |  | (133) |  |  | — |  |  | (103) |  |  | (103) |  |
| Repurchases and retirements of ordinary shares | (1,001) |  |  | — |  |  | (1,001) |  |  | (1,467) |  |  | — |  |  | (1,467) |  |
| Change in noncontrolling interest share | (8) |  |  | (6) |  |  | (14) |  |  | — |  |  | — |  |  | — |  |
| Adoption of ASC 842 | — |  |  | — |  |  | — |  |  | (5) |  |  | — |  |  | (5) |  |
| Adoption of ASU 2016-13 | (4) |  |  | — |  |  | (4) |  |  | — |  |  | — |  |  | — |  |
| Other, including options exercised | 190 |  |  | — |  |  | 190 |  |  | 59 |  |  | — |  |  | 59 |  |
| Ending balance, June 30 | $ | 17,840 |  |  | $ | 1,157 |  |  | $ | 18,997 |  |  | $ | 17,805 |  |  | $ | 1,068 |  |  | $ | 18,873 |  |

[0000833444-21-000040:notes:138]
During the quarter ended December 31, 2020, the Company recorded $4 million to beginning retained earnings for the cumulative effect of adopting ASU 2016-13, "Financial Instruments - Credit Losses."

[0000833444-21-000040:notes:139]
[same as prior period, unchanged from 0000833444-21-000020:notes:119]

[0000833444-21-000040:notes:140]
For the three and nine months ended June 30, 2021, the Company repurchased and immediately retired $340 million and $1,001 million of its ordinary shares, respectively. No shares were repurchased during the three months ended June 30, 2020.  For the nine months ended June 30, 2020, the Company repurchased and immediately retired $1,467 million of its ordinary shares. In March 2021, the Company's Board of Directors approved a $4.0 billion increase to the Company's share repurchase authorization, adding to the $2.0 billion remaining as of December 31, 2020 under the prior share repurchase authorization approved in 2019. As of June 30, 2021, approximately $5.4 billion remains available under the Company's share repurchase authorization.

[0000833444-21-000040:notes:141]
[same as prior period, unchanged from 0000833444-21-000020:notes:121]

[0000833444-21-000040:notes:142]
|  | Three Months Ended June 30, |
|  | 2021 |  | 2020 |
| Foreign currency translation adjustments ("CTA") |  |  |  |
| Balance at beginning of period | $ | (418) |  |  | $ | (1,005) |  |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | 75 |  |  | 72 |  |
| Balance at end of period | (343) |  |  | (933) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 9 |  |  | (7) |  |
| Current period changes in fair value (net of tax effect of $3 and $1) | (5) |  |  | 4 |  |
| Reclassification to income (net of tax effect of $(3) and $0) * | (10) |  |  | 2 |  |
| Balance at end of period | (6) |  |  | (1) |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (1) |  |  | (9) |  |
| Reclassification to income (net of tax effect of $0 and $0) | (1) |  |  | — |  |
| Balance at end of period | (2) |  |  | (9) |  |
| Accumulated other comprehensive loss, end of period | $ | (351) |  |  | $ | (943) |  |

[0000833444-21-000040:notes:143]
|  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |
| CTA |  |  |  |
| Balance at beginning of period | $ | (778) |  |  | $ | (785) |  |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | 435 |  |  | (148) |  |
| Balance at end of period | (343) |  |  | (933) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 2 |  |  | (2) |  |
| Current period changes in fair value (net of tax effect of $7 and $0) | 2 |  |  | 1 |  |
| Reclassification to income (net of tax effect of $(3) and $0) * | (10) |  |  | — |  |
| Balance at end of period | (6) |  |  | (1) |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | — |  |  | (8) |  |
| Reclassification to income (net of tax effect of $0 and $0) | (2) |  |  | (1) |  |
| Balance at end of period | (2) |  |  | (9) |  |
| Accumulated other comprehensive loss, end of period | $ | (351) |  |  | $ | (943) |  |

[0000833444-21-000040:notes:144]
[same as prior period, unchanged from 0000833444-21-000020:notes:124]

[0000833444-21-000040:notes:145]
[same as prior period, unchanged from 0000833444-21-000020:notes:125]

[0000833444-21-000040:notes:146]
[same as prior period, unchanged from 0000833444-21-000020:notes:126]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-21-000040:notes:147]
[same as prior period, unchanged from 0000833444-21-000020:notes:127]

[0000833444-21-000040:notes:148]
[same as prior period, unchanged from 0000833444-21-000020:notes:128]

[0000833444-21-000040:notes:149]
[same as prior period, unchanged from 0000833444-21-000020:notes:129]

[0000833444-21-000040:notes:150]
[same as prior period, unchanged from 0000833444-21-000020:notes:130]

[0000833444-21-000040:notes:151]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three and nine months ended June 30, 2021 and 2020.

[0000833444-21-000040:notes:152]
[same as prior period, unchanged from 0000833444-21-000020:notes:132]

[0000833444-21-000040:notes:153]
|  |  | Volume Outstanding as of |
| Commodity |  | June 30, 2021 |  | September 30, 2020 |
| Copper |  | 2,452 |  |  | 2,497 |  |
| Aluminum |  | 2,415 |  |  | 3,036 |  |

[0000833444-21-000040:notes:154]
In April 2021, the Company entered into two interest rate swaps with a combined notional amount of $500 million to reduce the market risk associated with changes in interest rates. The interest rate swaps are designated as cash flow hedges. The fair value of each interest rate swap, or the difference between the swap's reference rate and the fixed rate when notes are issued, will be amortized to interest expense over the life of the respective note issuance.

[0000833444-21-000040:notes:155]
[same as prior period, unchanged from 0000833444-21-000020:notes:134]

[0000833444-21-000040:notes:156]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on its net investments globally. At June 30, 2021 the Company had 853 million euro, 500 million euro, 500 million euro, 423 million euro and 54 million euro in bonds designated as net investment hedges of a portion of its net investment in European subsidiaries and 25 billion yen of foreign denominated debt designated as net investment hedge of a portion of its net investment in Japanese subsidiaries. At September 30, 2020, the Company had 888 million euro, 500 million euro, 500 million euro, 423 million euro and 54 million euro in bonds designated as net investment hedges of a portion of its net investment in European subsidiaries and 25 billion yen of foreign denominated debt designated as net investment hedge of a portion of its net investment in Japanese subsidiaries.

[0000833444-21-000040:notes:157]
[same as prior period, unchanged from 0000833444-21-000020:notes:136]

[0000833444-21-000040:notes:158]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount. The Company hedged approximately 0.3 million of its ordinary shares, which have a cost basis of $23 million, as of June 30, 2021 and 1.4 million ordinary shares, which have a cost basis of $60 million, as of September 30, 2020.

[0000833444-21-000040:notes:159]
[same as prior period, unchanged from 0000833444-21-000020:notes:138]

[0000833444-21-000040:notes:160]
[same as prior period, unchanged from 0000833444-21-000020:notes:139]

[0000833444-21-000040:notes:161]
[same as prior period, unchanged from 0000833444-21-000020:notes:140]

[0000833444-21-000040:notes:162]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | June 30, |  | September 30, |  | June 30, |  | September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 11 |  |  | $ | 10 |  |  | $ | 10 |  |  | $ | 17 |  |
| Commodity derivatives | 4 |  |  | 2 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 23 |  |  | 58 |  |
| Total assets | $ | 15 |  |  | $ | 12 |  |  | $ | 33 |  |  | $ | 75 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 4 |  |  | $ | 10 |  |  | $ | 5 |  |  | $ | — |  |
| Interest rate swaps | 13 |  |  | — |  |  | — |  |  | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 2,999 |  |  | 3,010 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,017 |  |  | $ | 3,020 |  |  | $ | 5 |  |  | $ | — |  |

[0000833444-21-000040:notes:163]
[same as prior period, unchanged from 0000833444-21-000020:notes:142]

[0000833444-21-000040:notes:164]
[same as prior period, unchanged from 0000833444-21-000020:notes:143]

[0000833444-21-000040:notes:165]
The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that

[0000833444-21-000040:notes:166]
share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-21-000040:notes:167]
[same as prior period, unchanged from 0000833444-21-000020:notes:145]

[0000833444-21-000040:notes:168]
|  |  | Fair Value of Assets |  |  |  | Fair Value of Liabilities |  |  |
|  |  | June 30, |  | September 30, |  |  |  | June 30, |  | September 30, |  |  |
|  |  | 2021 |  | 2020 |  |  |  | 2021 |  | 2020 |  |  |
| Gross amount recognized |  | $ | 48 |  |  | $ | 87 |  |  |  |  | $ | 3,022 |  |  | $ | 3,020 |  |  |  |
| Gross amount eligible for offsetting |  | (8) |  |  | (10) |  |  |  |  | (8) |  |  | (10) |  |  |  |
| Net amount |  | $ | 40 |  |  | $ | 77 |  |  |  |  | $ | 3,014 |  |  | $ | 3,010 |  |  |  |

[0000833444-21-000040:notes:169]
[same as prior period, unchanged from 0000833444-21-000020:notes:147]

[0000833444-21-000040:notes:170]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the three and nine months ended June 30, 2021 and 2020 (in millions):

[0000833444-21-000040:notes:171]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Foreign currency exchange derivatives |  | $ | 1 |  |  | $ | — |  |  | $ | 14 |  |  | $ | 2 |  |
| Commodity derivatives |  | 10 |  |  | 5 |  |  | 11 |  |  | 2 |  |
| Interest rate swaps |  | (13) |  |  | — |  |  | (13) |  |  | — |  |
| Total |  | $ | (2) |  |  | $ | 5 |  |  | $ | 12 |  |  | $ | 4 |  |

[0000833444-21-000040:notes:172]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the three and nine months ended June 30, 2021 and 2020 (in millions):

[0000833444-21-000040:notes:173]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 7 |  |  | $ | (4) |  |  | $ | 10 |  |  | $ | (1) |  |
| Commodity derivatives |  | Cost of sales |  | 10 |  |  | 2 |  |  | 7 |  |  | 1 |  |
| Total |  |  |  | $ | 17 |  |  | $ | (2) |  |  | $ | 17 |  |  | $ | — |  |

[0000833444-21-000040:notes:174]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the three and nine months ended June 30, 2021 and 2020 (in millions):

[0000833444-21-000040:notes:175]
|  |  |  |  | Amount of Gain (Loss) Recognized inIncome on Derivative |
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (3) |  |  | $ | (2) |  |  | $ | (7) |  |  | $ | 2 |  |
| Foreign currency exchange derivatives |  | Selling, general and administrative |  | (2) |  |  | — |  |  | (1) |  |  | — |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | (17) |  |  | 19 |  |  | 128 |  |  | 68 |  |
| Equity swap |  | Selling, general and administrative |  | 4 |  |  | 10 |  |  | 28 |  |  | (14) |  |
| Total |  |  |  | $ | (18) |  |  | $ | 27 |  |  | $ | 148 |  |  | $ | 56 |  |

[0000833444-21-000040:notes:176]
Pre-tax gains (losses) on net investment hedges recorded in CTA within other comprehensive income (loss) were $(39) million and $(46) million for the three months ended June 30, 2021 and 2020, respectively. Pre-tax gains (losses) on net investment hedges recorded in CTA within other comprehensive income (loss) were $(30) million and $(58) million for the 
nine months ended June 30, 2021 and 2020, respectively. For the three and nine months ended June 30, 2021 and 2020, no gains or losses were reclassified from CTA into income.


## us-gaap:DerivativesPolicyTextBlock

[0000833444-21-000040:notes:177]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings.The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on its net investments globally.The Company also holds certain foreign currency forward and option contracts not designated as hedging instruments under ASC 815. The change in fair value of these foreign currency exchange derivatives are recorded in the consolidated statements of income in the period in which they occur.The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-21-000040:notes:178]
[same as prior period, unchanged from 0000833444-21-000020:notes:156]

[0000833444-21-000040:notes:179]
[same as prior period, unchanged from 0000833444-21-000020:notes:157]

[0000833444-21-000040:notes:180]
[same as prior period, unchanged from 0000833444-21-000020:notes:158]

[0000833444-21-000040:notes:181]
[same as prior period, unchanged from 0000833444-21-000020:notes:159]

[0000833444-21-000040:notes:182]
[same as prior period, unchanged from 0000833444-21-000020:notes:160]

[0000833444-21-000040:notes:183]
[same as prior period, unchanged from 0000833444-21-000020:notes:161]

[0000833444-21-000040:notes:184]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of June 30, 2021 and September 30, 2020 (in millions):

[0000833444-21-000040:notes:185]
|  | Fair Value Measurements Using: |
|  | Total as of June 30, 2021 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 21 |  |  | $ | — |  |  | $ | 21 |  |  | $ | — |  |
| Commodity derivatives | 4 |  |  | — |  |  | 4 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 64 |  |  | 64 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 151 |  |  | 151 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 169 |  |  | 169 |  |  | — |  |  | — |  |
| Equity swap | 23 |  |  | — |  |  | 23 |  |  | — |  |
| Total assets | $ | 432 |  |  | $ | 384 |  |  | $ | 48 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |  | $ | — |  |
| Interest rate swaps | 13 |  |  | — |  |  | 13 |  |  | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Contingent earn-out liability | 33 |  |  | — |  |  | — |  |  | 33 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liability | 54 |  |  | — |  |  | — |  |  | 54 |  |
| Total liabilities | $ | 110 |  |  | $ | — |  |  | $ | 23 |  |  | $ | 87 |  |

[0000833444-21-000040:notes:186]
[same as prior period, unchanged from 0000833444-21-000020:notes:164]

[0000833444-21-000040:notes:187]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for further details.

[0000833444-21-000040:notes:188]
[same as prior period, unchanged from 0000833444-21-000020:notes:166]

[0000833444-21-000040:notes:189]
[same as prior period, unchanged from 0000833444-21-000020:notes:167]

[0000833444-21-000040:notes:190]
[same as prior period, unchanged from 0000833444-21-000020:notes:168]

[0000833444-21-000040:notes:191]
[same as prior period, unchanged from 0000833444-21-000020:notes:169]

[0000833444-21-000040:notes:192]
[same as prior period, unchanged from 0000833444-21-000020:notes:170]

[0000833444-21-000040:notes:193]
Investments in exchange traded funds:  Investments in exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.  Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-21-000040:notes:194]
Contingent earn-out liability:  The contingent earn-out liability related to the Silent-Aire acquisition was established using a Monte Carlo simulation based on the forecasted operating results and the earn-out formula specified in the purchase agreement.

[0000833444-21-000040:notes:195]
The following table presents the portion of unrealized gains (losses) recognized in the consolidated statements of income for the three and nine months ended June 30, 2021 and 2020 that relate to equity securities still held at June 30, 2021 and 2020 (in millions):

[0000833444-21-000040:notes:196]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Deferred compensation plan assets |  | $ | — |  |  | $ | 6 |  |  | $ | 7 |  |  | $ | (1) |  |
| Investments in exchange traded funds |  | 16 |  |  | 31 |  |  | 39 |  |  | 9 |  |

[0000833444-21-000040:notes:197]
All of the gains and losses on investments in exchange traded funds related to restricted investments. 
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. At June 30, 2021, the fair value of long-term debt was $8.3 billion, including public debt of $8.1 billion and other long-term debt of $0.2 billion. At September 30, 2020, the fair value of long-term debt was $8.6 billion, including public debt of $8.4 billion and other long-term debt of $0.2 billion. The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy.  The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000833444-21-000040:notes:198]
[same as prior period, unchanged from 0000833444-21-000020:notes:175]

[0000833444-21-000040:notes:199]
Investments in exchange traded funds:  Investments in exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.  Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.
Contingent earn-out liability:  The contingent earn-out liability related to the Silent-Aire acquisition was established using a Monte Carlo simulation based on the forecasted operating results and the earn-out formula specified in the purchase agreement.The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy.  The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:AssetImpairmentChargesTextBlock

[0000833444-21-000040:notes:200]
[same as prior period, unchanged from 0000833444-21-000020:notes:177]

[0000833444-21-000040:notes:201]
[same as prior period, unchanged from 0000833444-21-000020:notes:178]

[0000833444-21-000040:notes:202]
In the third quarter of fiscal 2021, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2021. As a result, the Company reviewed the long-lived assets for impairment and recorded $40 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $32 million related to the Global Products segment, $5 million related to the Building Solutions EMEA/LA segment and $3 million related to the Building Solutions North America segment. Refer to Note 10, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement.

[0000833444-21-000040:notes:203]
In the second quarter of fiscal 2021, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2021. As a result, the

[0000833444-21-000040:notes:204]
Company reviewed the long-lived assets for impairment and recorded $54 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $29 million related to the Building Solutions North America segment, $16 million related to the Global Products segment, $5 million related to Corporate assets and $4 million related to the Building Solutions Asia Pacific segment. Refer to Note 10, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-21-000040:notes:205]
[same as prior period, unchanged from 0000833444-21-000020:notes:180]

[0000833444-21-000040:notes:206]
In the third quarter of fiscal 2020, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2020. As a result, the Company reviewed the long-lived assets for impairment and recorded $42 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $24 million related to the Building Solutions Asia Pacific segment, $9 million related to the Global Products segment and $9 million related to the Building Solutions North America segment. Refer to Note 10, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were primarily measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-21-000040:notes:207]
[same as prior period, unchanged from 0000833444-21-000020:notes:181]

[0000833444-21-000040:notes:208]
[same as prior period, unchanged from 0000833444-21-000020:notes:182]

[0000833444-21-000040:notes:209]
At June 30, 2021 and 2020, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets.

[0000833444-21-000040:notes:210]
Refer to Note 10, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for further information regarding the indefinite-lived intangible and goodwill impairment charges recorded in fiscal 2020.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-21-000040:notes:211]
Segment InformationASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has four reportable segments for financial reporting purposes. 
•Building Solutions North America: Building Solutions North America designs, sells, installs, and services HVAC, controls, refrigeration, integrated electronic security, and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in North America. Building Solutions North America also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems, as well as data-driven "smart building" solutions, to non-residential building and industrial applications in the North American marketplace.

[0000833444-21-000040:notes:212]
[same as prior period, unchanged from 0000833444-21-000020:notes:187]

[0000833444-21-000040:notes:213]
[same as prior period, unchanged from 0000833444-21-000020:notes:188]

[0000833444-21-000040:notes:214]
•Global Products: Global Products designs and produces heating and air conditioning for residential and commercial applications, and markets products and refrigeration systems to replacement and new construction market customers globally. The Global Products business also designs, manufactures and sells fire protection and security products, including intrusion security, anti-theft devices, and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide.  Global Products also includes the Johnson Controls-Hitachi joint venture.

[0000833444-21-000040:notes:215]
Management evaluates the performance of its business segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income (loss) from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-21-000040:notes:216]
[same as prior period, unchanged from 0000833444-21-000020:notes:192]

[0000833444-21-000040:notes:217]
|  | Net Sales |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Building Solutions North America | $ | 2,212 |  |  | $ | 2,020 |  |  | $ | 6,338 |  |  | $ | 6,362 |  |
| Building Solutions EMEA/LA | 962 |  |  | 756 |  |  | 2,765 |  |  | 2,534 |  |
| Building Solutions Asia Pacific | 712 |  |  | 588 |  |  | 1,930 |  |  | 1,742 |  |
| Global Products | 2,455 |  |  | 1,979 |  |  | 6,243 |  |  | 5,725 |  |
| Total net sales | $ | 6,341 |  |  | $ | 5,343 |  |  | $ | 17,276 |  |  | $ | 16,363 |  |

[0000833444-21-000040:notes:218]
|  | Segment EBITA |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Building Solutions North America | $ | 326 |  |  | $ | 307 |  |  | $ | 847 |  |  | $ | 816 |  |
| Building Solutions EMEA/LA | 103 |  |  | 62 |  |  | 284 |  |  | 237 |  |
| Building Solutions Asia Pacific | 84 |  |  | 92 |  |  | 237 |  |  | 229 |  |
| Global Products | 507 |  |  | 378 |  |  | 1,005 |  |  | 797 |  |
| Total segment EBITA | $ | 1,020 |  |  | $ | 839 |  |  | $ | 2,373 |  |  | $ | 2,079 |  |
| Corporate expenses | $ | (70) |  |  | $ | (67) |  |  | $ | (207) |  |  | $ | (303) |  |
| Amortization of intangible assets | (112) |  |  | (95) |  |  | (320) |  |  | (288) |  |
| Restructuring and impairment costs | (79) |  |  | (610) |  |  | (175) |  |  | (783) |  |
| Net mark-to-market adjustments | 66 |  |  | (132) |  |  | 296 |  |  | (154) |  |
| Net financing charges | (56) |  |  | (58) |  |  | (159) |  |  | (169) |  |
| Income (loss) from continuing operations before income taxes | $ | 769 |  |  | $ | (123) |  |  | $ | 1,808 |  |  | $ | 382 |  |


## us-gaap:GuaranteesTextBlock

[0000833444-21-000040:notes:219]
[same as prior period, unchanged from 0000833444-21-000020:notes:195]

[0000833444-21-000040:notes:220]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate for future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-21-000040:notes:221]
[same as prior period, unchanged from 0000833444-21-000020:notes:198]

[0000833444-21-000040:notes:222]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations, for the nine months ended June 30, 2021 and 2020 were as follows (in millions). Extended warranty for which deferred revenue is recorded is not included in the table below, but rather included within the contract balances table in the Note 5, "Revenue Recognition," of the notes to consolidated financial statements for all periods presented.

[0000833444-21-000040:notes:223]
|  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |
| Balance at beginning of period | $ | 167 |  |  | $ | 156 |  |
| Accruals for warranties issued during the period | 64 |  |  | 47 |  |
| Accruals related to pre-existing warranties | 21 |  |  | — |  |
| Settlements made (in cash or in kind) during the period | (52) |  |  | (44) |  |
| Currency translation | 1 |  |  | — |  |
| Balance at end of period | $ | 201 |  |  | $ | 159 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-21-000040:notes:224]
Commitments and Contingencies
Environmental Matters

[0000833444-21-000040:notes:225]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of June 30, 2021, reserves for environmental liabilities for continuing operations totaled $100 million, of which $50 million was recorded within other current liabilities and $50 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $130 million at September 30, 2020, of which $61 million was recorded within other current liabilities and $69 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

[0000833444-21-000040:notes:226]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin. In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluoroalkyl substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.

[0000833444-21-000040:notes:227]
During the third quarter of 2019, the Company increased its environmental reserves, which included $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.

[0000833444-21-000040:notes:228]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

[0000833444-21-000040:notes:229]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22,

[0000833444-21-000040:notes:230]
2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation. On November 6, 2020, WDNR received further recommendations from WDHS regarding individual standards for 12 additional PFAS and a combined standard for four additional PFAS, PFOA, and PFOS.

[0000833444-21-000040:notes:231]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).” The WDNR issued a further letter regarding the issue on November 4, 2019.  In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

[0000833444-21-000040:notes:232]
In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, WDNR approved Tyco Fire Products’ proposed Groundwater Extraction and Treatment System (“GETS”), a permanent groundwater remediation system that will extract groundwater that contains PFAS, treat it using advanced filtration systems, and return the treated water to the environment. Tyco Fire Products has commenced construction on the GETS. Tyco Fire Products also has started the process of removing PFAS-affected soil from the FTC.

[0000833444-21-000040:notes:233]
In December 2020, the Company received a notice from the Wisconsin Department of Justice (“WDOJ”) that the WDOJ was considering a potential civil enforcement action against the Company relating to environmental matters at the FTC including, but not limited to, the investigation and remediation of PFAS at or near the FTC as discussed above and the Company’s alleged failure to timely report the presence of PFAS chemicals at the FTC. Such enforcement action could seek civil monetary penalties and/or injunctive relief. The Company is presently unable to predict the duration, scope, or results of any potential civil enforcement action that may result, the consequences of any such action, or the nature of any resolution of these potential claims with the WDOJ.

[0000833444-21-000040:notes:234]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility in the third quarter of 2019 was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation of PFAS in the Marinette region.

[0000833444-21-000040:notes:235]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and

[0000833444-21-000040:notes:236]
risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At June 30, 2021 and September 30, 2020, the Company recorded conditional asset retirement obligations for continuing operations of $29 million and $29 million, respectively.

[0000833444-21-000040:notes:237]
Asbestos Matters

[0000833444-21-000040:notes:238]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-21-000040:notes:239]
As of June 30, 2021, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $78 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $466 million, of which $49 million was recorded in other current liabilities and $417 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $388 million, of which $19 million was recorded in other current assets, and $369 million was recorded in other noncurrent assets. Assets included $7 million of cash and $320 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at June 30, 2021 was $61 million. As of September 30, 2020, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $115 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $483 million, of which $49 million was recorded in other current liabilities and $434 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $368 million, of which $39 million was recorded in other current assets, and $329 million was recorded in other noncurrent assets. Assets included $9 million of cash and $291 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2020 was $68 million.

[0000833444-21-000040:notes:240]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-21-000040:notes:241]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-21-000040:notes:242]
Insurable Liabilities

[0000833444-21-000040:notes:243]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At June 30, 2021 and September 30, 2020, the insurable liabilities totaled $359 million and $363 million, respectively, of which $89 million and $83 million was recorded within other current liabilities, $23 million and $22 million was recorded within accrued compensation and benefits, and $247 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at June 30, 2021 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2020 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-21-000040:notes:244]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-21-000040:notes:245]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-21-000040:notes:246]
PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. The EPA also announced in January 2021 that it will issue an advance notice of proposed rulemaking to solicit public comment on whether the agency should take additional regulatory steps to address PFAS contamination, including designating PFOA and PFOS and other PFAS as hazardous substances under the Comprehensive Environmental Response, Compensation, and Liability Act and seeking comment on whether PFOA and PFOS and other PFAS should be subject to regulation as hazardous waste under the Resource Conservation and Recovery

[0000833444-21-000040:notes:247]
Act. The Agency reissued those actions in February 2021. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

[0000833444-21-000040:notes:248]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-21-000040:notes:249]
AFFF Putative Class Actions

[0000833444-21-000040:notes:250]
Chemguard and Tyco Fire Products are named in 32 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington, New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan, Texas and South Dakota. All of these cases except one have been direct-filed in or transferred to the MDL, with one recently-filed case expected to be transferred to the MDL shortly. Since the beginning of fiscal year 2021, three putative class actions (Jackson v. 3M Company, et al., direct filed on January 15, 2021 in the MDL pending in the United States District Court, District of South Carolina; Ogden v. Intercontinental Terminals Company LLC, et al., filed in the United States District Court, Southern District of Texas on January 27, 2021, and transferred to the MDL; Miller v. 3M Company et al., filed in the United States District Court, Northern District of West Virginia on July 8, 2021, and tagged to the MDL) have been filed against the Company.

[0000833444-21-000040:notes:251]
AFFF Individual or Mass Actions

[0000833444-21-000040:notes:252]
There are approximately 1,270 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, and approximately 1,000 other plaintiffs. All but two of these matters have been transferred to or directly-filed in the MDL. One case, Young v. Chemguard et al., was filed in superior court in Maricopa County, Arizona, removed to the United States District Court, District of Arizona, and tagged to the MDL, but was remanded to state court prior to being transferred to the MDL. The decision to remand the case to state court is currently being appealed. Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court. The Company anticipates that the remainder of the possible individual product liability claims filed in Pennsylvania state court will either soon be filed in the MDL (and that all such claims in state court will be dismissed accordingly) or will be dismissed in Pennsylvania without a corresponding filing in South Carolina.

[0000833444-21-000040:notes:253]
AFFF Municipal Cases

[0000833444-21-000040:notes:254]
Chemguard and Tyco Fire Products have been named as defendants in 119 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Alabama, Arizona, California, Colorado, Florida, Idaho, Kentucky, Louisiana, Massachusetts, New Jersey, New York, Maryland, North Carolina, Ohio, Pennsylvania, Virginia, Washington, the District of Columbia and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but seven of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.

[0000833444-21-000040:notes:255]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly

[0000833444-21-000040:notes:256]
resulting from the use of those products at the Peterson Air Force Base. In May 2020, the Company was also notified by the Lakewood Water District in Pierce County, Washington that it may assert claims regarding remediation in connection with PFOA, PFOS, and other PFAS contamination allegedly resulting from the use of those products at Joint Base Lewis-McChord.

[0000833444-21-000040:notes:257]
State or U.S. Territory Attorneys General Litigation related to AFFF

[0000833444-21-000040:notes:258]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-21-000040:notes:259]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-21-000040:notes:260]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752 -000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio. The lawsuit seeks to recover costs and natural resource damages associated with the contamination. This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-21-000040:notes:261]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

[0000833444-21-000040:notes:262]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-21-000040:notes:263]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

[0000833444-21-000040:notes:264]
In August 2020, Attorney General of the State of Michigan filed two substantially similar lawsuits—one in federal court and one in state court—against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within the State. The federal action has been transferred to the MDL, and the state court action has been removed to federal court and transferred to the MDL.

[0000833444-21-000040:notes:265]
In December 2020, the State of Mississippi filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

[0000833444-21-000040:notes:266]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint has not yet been served.

[0000833444-21-000040:notes:267]
AFFF Matters Related to the Tyco Fire Products Fire Technology Center in Marinette, Wisconsin

[0000833444-21-000040:notes:268]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. On January 7, 2021, the parties agreed to settle the lawsuit. The settlement provides that Tyco will pay up to $17.5 million to compensate Town of Peshtigo residents who live in the area affected by PFAS from the FTC for claims related to loss of real property value, exposure and/or personal injury. The settlement does not constitute an admission of wrongdoing by Tyco or Chemguard and is subject to approval by the federal court presiding over the lawsuit and other contingencies. The court conducted a hearing regarding the proposed settlement in May 2021; following this hearing the parties will submit for final approval an amended settlement agreement. The Company does not expect the settlement to have a significant impact on its fiscal year 2021 results of operations or cash flows.

[0000833444-21-000040:notes:269]
Other AFFF Related Matters

[0000833444-21-000040:notes:270]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-21-000040:notes:271]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-21-000040:notes:272]
Other Matters

[0000833444-21-000040:notes:273]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-21-000040:notes:274]
Related Party Transactions
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-21-000040:notes:275]
The following table presents net sales to and purchases from related parties for the three and nine months ended June 30, 2021 and 2020 (in millions):

[0000833444-21-000040:notes:276]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales to related parties |  | $ | 46 |  |  | $ | 52 |  |  | $ | 143 |  |  | $ | 135 |  |
| Purchases from related parties |  | 55 |  |  | 25 |  |  | 121 |  |  | 47 |  |

[0000833444-21-000040:notes:277]
The following table presents receivables from and payables to related parties in the consolidated statements of financial position (in millions):

[0000833444-21-000040:notes:278]
|  |  | June 30, 2021 |  | September 30, 2020 |
| Receivable from related parties |  | $ | 73 |  |  | $ | 48 |  |
| Payable to related parties |  | 33 |  |  | 11 |  |

[0000833444-21-000040:notes:279]
Additionally, the Company leases certain facilities used in its operations from a related party. As of June 30, 2021, the right-of-use asset associated with these leases was $12 million and the lease liability was $11 million. Amounts paid for these leases were not material.
