# JCI notes — 0000833444-23-000048


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000833444-23-000048:notes:1]
Portions of the definitive Proxy Statement to be delivered to shareholders in connection with the annual general meeting of shareholders to be held on March 13, 2024 are incorporated by reference into Part III.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000833444-23-000048:notes:2]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited  company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," "Johnson Controls" or "JCI plc").

[0000833444-23-000048:notes:3]
The Company's fiscal year ends on September 30. Unless otherwise stated, references to years in this report relate to fiscal years rather than calendar years.

[0000833444-23-000048:notes:4]
Nature of Operations

[0000833444-23-000048:notes:5]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers in more than 150 countries. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-23-000048:notes:6]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management and repair of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its OpenBlue software platform and capabilities. The Company partners with customers by leveraging its broad product portfolio and digital capabilities powered by OpenBlue, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

[0000833444-23-000048:notes:7]
Principles of Consolidation

[0000833444-23-000048:notes:8]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the year are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.

[0000833444-23-000048:notes:9]
The Company consolidates variable interest entities ("VIE") when it has the power to direct the significant activities of the entity and the obligation to absorb losses or receive benefits from the entity that may be significant. The Company did not have any material consolidated or nonconsolidated VIEs in its continuing operations for the presented reporting periods.

[0000833444-23-000048:notes:10]
Use of Estimates

[0000833444-23-000048:notes:11]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0000833444-23-000048:notes:12]
Fair Value of Financial Instruments

[0000833444-23-000048:notes:13]
ASC 820, "Fair Value Measurement," defines fair value as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0000833444-23-000048:notes:14]
Level 1: Observable inputs such as quoted prices in active markets for identical assets or liabilities;

[0000833444-23-000048:notes:15]
Level 2: Quoted prices in active markets for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0000833444-23-000048:notes:16]
Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0000833444-23-000048:notes:17]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0000833444-23-000048:notes:18]
Acquisitions

[0000833444-23-000048:notes:19]
The purchase price of acquired businesses is allocated to the related identifiable assets and liabilities based on estimated fair values. The excess of the purchase price over the amount allocated to the assets and liabilities, if any, is recorded as goodwill. In addition, any contingent consideration is recorded at the estimated fair value as of the date of the acquisition and is recorded as part of the purchase price. This estimate is updated in future periods and any changes in the estimate, which are not considered an adjustment to the purchase price, are recorded in our consolidated statements of operations. Payments for contingent earn-out liabilities that are less than or equal to estimates on the acquisition date are reflected as financing cash outflows. Amounts paid in excess of the estimated contingent earn-out liabilities on the acquisition date are reflected as operating cash outflows.

[0000833444-23-000048:notes:20]
All available information is used to estimate fair values. External valuation specialists are typically engaged to assist in the fair value determination of identifiable intangible assets and any other significant assets or liabilities. The preliminary purchase price allocation is adjusted, as necessary, up to one year after the acquisition closing date as more information is obtained regarding assets acquired and liabilities assumed based on facts and circumstances that existed as of the acquisition date.

[0000833444-23-000048:notes:21]
The purchase price allocation methodology contains uncertainties because it requires the Company to make assumptions and to apply judgment to estimate the fair value of acquired assets and assumed liabilities. The fair value of assets and liabilities is estimated based upon the carrying value of the acquired assets and assumed liabilities and widely accepted valuation techniques, including discounted cash flows. Unanticipated events or circumstances may occur which could affect the accuracy of fair value estimates, including assumptions regarding industry economic factors and business strategies.

[0000833444-23-000048:notes:22]
Other estimates used in determining fair value include, but are not limited to, future cash flows or income related to intangibles, market rate assumptions and discount rates. Fair value estimates are based upon assumptions believed to be reasonable, but that are inherently uncertain, and therefore, may not be realized. Accordingly, there can be no assurance that the estimates, assumptions, and values reflected in the valuations will be realized, and actual results could differ materially.

[0000833444-23-000048:notes:23]
Assets and Liabilities Held for Sale

[0000833444-23-000048:notes:24]
Assets and liabilities (disposal groups) to be sold are classified as held for sale in the period in which all of the following criteria are met:

[0000833444-23-000048:notes:25]
•Management, having the authority to approve the action, commits to a plan to sell the disposal group;

[0000833444-23-000048:notes:26]
•The disposal group is available for immediate sale in its present condition subject only to terms that are usual and customary for sales of such disposal groups;

[0000833444-23-000048:notes:27]
•An active program to locate a buyer and other actions required to complete the plan to sell the disposal group have been initiated;

[0000833444-23-000048:notes:28]
•Sale of the disposal group is probable and transfer of the disposal group is expected to qualify for recognition as a completed sale within one year, except if events or circumstances beyond the Company's control extend the period of time required to sell the disposal group beyond one year;

[0000833444-23-000048:notes:29]
•The disposal group is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and

[0000833444-23-000048:notes:30]
•Actions required to complete the plan indicate that it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn.

[0000833444-23-000048:notes:31]
The Company initially measures a disposal group that is classified as held for sale at the lower of its carrying value or fair value less any costs to sell in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets." The carrying amount of any assets, including goodwill, that are part of the disposal group, but not in the scope of ASC 360-10, are tested for impairment under the relevant guidance prior to measuring the disposal group at fair value, less cost to sell.

[0000833444-23-000048:notes:32]
Any loss resulting from this measurement is recognized in the period in which the held for sale criteria are met. Conversely, gains are not recognized on the sale of a disposal group until the date of sale. The Company assesses the fair value of a disposal group, less any costs to sell, each reporting period it remains classified as held for sale and reports any subsequent changes as an adjustment to the carrying value of the disposal group, as long as the new carrying value does not exceed the carrying value of the disposal group at the time it was initially classified as held for sale.

[0000833444-23-000048:notes:33]
Upon determining that a disposal group meets the criteria to be classified as held for sale, the Company reports the assets and liabilities of the disposal group, if material, in the line items assets held for sale and liabilities held for sale in the consolidated statements of financial position.

[0000833444-23-000048:notes:34]
Cash and Cash Equivalents

[0000833444-23-000048:notes:35]
Cash equivalents include all highly liquid investments with an original maturity of three months or less when purchased.

[0000833444-23-000048:notes:36]
Restricted Cash

[0000833444-23-000048:notes:37]
Restricted cash relates to amounts restricted for payment of asbestos liabilities and certain litigation and environmental matters and is recorded within other current assets in the consolidated statements of financial position.

[0000833444-23-000048:notes:38]
Receivables

[0000833444-23-000048:notes:39]
Receivables consist of billed receivables which are currently due from customers and unbilled receivables where the Company has satisfied its performance obligations, but has not yet issued the invoice to the customer. Incentives are periodically offered to customers, including early payment discounts and extended payment terms of certain receivables. The Company extends credit to customers in the normal course of business and maintains an allowance for expected credit losses resulting from the inability or unwillingness of customers to make required payments. The allowance for expected credit losses is based on historical experience, existing economic conditions, reasonable and supportable forecasts, and any specific customer collection issues the Company has identified. The Company evaluates the reasonableness of the allowance for expected credit losses on a quarterly basis.

[0000833444-23-000048:notes:40]
The Company enters into various factoring agreements to sell certain accounts receivable to third-party financial institutions. The Company collects the majority of the factored receivables on behalf of the financial institutions, but maintains no other continuing involvement with the factored receivables. Sales of accounts receivable are reflected as a reduction of accounts receivable in the consolidated statements of financial position and the proceeds are included in cash flows from operating activities in the consolidated statements of cash flows.

[0000833444-23-000048:notes:41]
Inventories

[0000833444-23-000048:notes:42]
Inventories are stated at the lower of cost or net realizable value using the first-in, first-out ("FIFO") method. Finished goods and work-in-process inventories include material, labor and manufacturing overhead costs.

[0000833444-23-000048:notes:43]
Property, Plant and Equipment

[0000833444-23-000048:notes:44]
Property, plant and equipment are recorded at cost. Depreciation is provided over the estimated useful lives of the respective assets using the straight-line method for financial reporting purposes and accelerated methods for income tax purposes. Estimated useful lives generally range from 3 to 40 years for buildings and improvements, up to 15 years for subscriber systems, and from 3 to 15 years for machinery and equipment. Interest on borrowings is capitalized during the active construction period of major capital projects, added to the cost of the underlying assets and amortized over the useful lives of the assets.

[0000833444-23-000048:notes:45]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-23-000048:notes:46]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. Goodwill is reviewed for impairment during the fourth fiscal quarter (as of July 31) or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses the multiples of earnings approach based on the average of published multiples of earnings of comparable entities with similar operations and economic characteristics and applies the multiples to the Company's average of historical and future financial results for each reporting unit. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared to the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value.

[0000833444-23-000048:notes:47]
Indefinite-lived intangible assets are also subject to at least annual impairment testing in the fourth fiscal quarter or as events occur or circumstances change that indicate the assets may be impaired. Indefinite-lived intangible assets primarily consist of trademarks and trade names and are tested for impairment using a relief-from-royalty method. The Company considers the implications of both external (e.g., market growth, competition and local economic conditions) and internal (e.g., product sales and expected product growth) factors and their potential impact on cash flows related to the intangible asset in both the near- and long-term. The Company also considers the profitability of the business, among other factors, to determine the royalty rate for use in the impairment assessment.

[0000833444-23-000048:notes:48]
While the Company believes that the estimates and assumptions underlying the valuation methodologies are reasonable, different estimates and assumptions could result in different outcomes.

[0000833444-23-000048:notes:49]
Leases

[0000833444-23-000048:notes:50]
Lessee arrangements

[0000833444-23-000048:notes:51]
The Company leases certain administrative, production and other facilities, fleet vehicles, information technology equipment and other equipment under arrangements that are accounted for as operating leases. The Company determines whether an arrangement contains a lease at contract inception based on whether the arrangement involves the use of a physically distinct identified asset and whether the Company has the right to obtain substantially all of the economic benefits from the use of the asset throughout the period as well as the right to direct the use of the asset.

[0000833444-23-000048:notes:52]
Right-of-use assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent its obligation to make lease payments arising from the lease. Right-of-use assets and the corresponding lease liabilities are recognized at commencement date based on the present value of lease payments for all leases with terms longer than twelve months. The majority of the Company's leases do not provide an implicit interest rate. To determine the present value of lease payments, the Company uses its incremental borrowing rate based on information available on the lease commencement date or  the implicit rate if it is readily determinable. The Company determines its incremental borrowing rate based on a comparable market yield curve consistent with its credit rating, term of the lease and relative economic environment. The Company has elected to combine lease and nonlease components for its leases.

[0000833444-23-000048:notes:53]
Most leases contain options to renew or terminate the lease. Right-of-use assets and lease liabilities reflect only the options which the Company is reasonably certain to exercise.

[0000833444-23-000048:notes:54]
The Company has certain real estate leases that contain variable lease payments which are based on changes in the Consumer Price Index (CPI). Additionally, the Company's leases generally require it to pay for fuel, maintenance, repair, insurance and taxes. These payments are not included in the right-of-use asset or lease liability and are expensed as incurred.

[0000833444-23-000048:notes:55]
Lease expense is recognized on a straight-line basis over the lease term.

[0000833444-23-000048:notes:56]
Lessor arrangements

[0000833444-23-000048:notes:57]
The Company has monitoring services and maintenance agreements within its security business that include subscriber system assets for which the Company retains ownership. These agreements contain both lease and nonlease components. The Company has elected to combine lease and nonlease components for these arrangements where the timing and pattern of transfer of the lease and nonlease components are the same and the lease component would be classified as an operating lease if accounted for separately. The Company has concluded that in these arrangements the nonlease components are the predominant characteristic, and as a result, the combined component is accounted for under the revenue guidance.

[0000833444-23-000048:notes:58]
Impairment of Long-Lived Assets

[0000833444-23-000048:notes:59]
Long-lived assets, including right-of-use assets under operating leases, other tangible assets and intangible assets with definite lives, are reviewed for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of Software to be Sold, Leased, or Marketed."

[0000833444-23-000048:notes:60]
Assets and liabilities are grouped at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluates the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals.

[0000833444-23-000048:notes:61]
Intangible assets acquired in a business combination that are used in research and development activities are considered indefinite-lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they are not amortized but are tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired. If the carrying amount of an intangible asset exceeds its fair value, the Company recognizes an impairment loss in an amount equal to that excess.

[0000833444-23-000048:notes:62]
Unamortized capitalized costs of a computer software product are compared to the net realizable value of the product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset is written off.

[0000833444-23-000048:notes:63]
Revenue Recognition

[0000833444-23-000048:notes:64]
Revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services is recognized on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company does not adjust the promised amount of consideration for the effects of a significant financing component because at contract inception it expects to receive the payment within twelve months of transfer of goods or services.

[0000833444-23-000048:notes:65]
The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term.

[0000833444-23-000048:notes:66]
The Company also sells certain HVAC and refrigeration products and services in bundled arrangements with multiple performance obligations, such as equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered. There may also be extended warranty arrangements with durations of one to five years commencing upon the end of the standard warranty period. In addition, the Company sells security monitoring systems that may have multiple performance obligations, including equipment, installation, monitoring services and maintenance agreements. Revenue associated with the sale of equipment and related installations are recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. The transaction price is allocated to each performance obligation based on the relative standalone selling price method. In order to estimate relative standalone selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach. If the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized over the contract term on a straight-line basis. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the contract.

[0000833444-23-000048:notes:67]
In all other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

[0000833444-23-000048:notes:68]
The Company assesses variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

[0000833444-23-000048:notes:69]
Shipping and handling costs billed to customers are included in sales and the related costs are included in cost of sales when control transfers to the customer. The Company presents amounts collected from customers for sales and other taxes net of the related amounts remitted.

[0000833444-23-000048:notes:70]
Subscriber System Assets, Dealer Intangibles and Related Deferred Revenue Accounts

[0000833444-23-000048:notes:71]
The Company considers assets related to the acquisition of new customers in its electronic security business in three asset categories:

[0000833444-23-000048:notes:72]
•Internally generated residential subscriber systems outside of North America;

[0000833444-23-000048:notes:73]
•Internally generated commercial subscriber systems; and

[0000833444-23-000048:notes:74]
•Customer accounts acquired through the ADT dealer program, primarily outside of North America (referred to as dealer intangibles).

[0000833444-23-000048:notes:75]
Subscriber system assets include installed property, plant and equipment for which the Company retains ownership and deferred costs directly related to the customer acquisition and system installation. Subscriber system assets represent capitalized equipment (e.g. security control panels, touch pad, motion detectors, window sensors, and other equipment) and installation costs associated with electronic security monitoring arrangements under which the Company retains ownership of the security system assets in a customer's place of business or residence. Installation costs represent costs incurred to prepare the asset for its intended use. The Company pays property taxes on the subscriber system assets and may retrieve such assets when the agreement is terminated. These assets embody a probable future economic benefit as they generate future monitoring revenue for the Company.

[0000833444-23-000048:notes:76]
Costs related to the subscriber system equipment and installation are categorized as property, plant and equipment rather than deferred costs. Deferred costs associated with subscriber system assets represent direct and incremental selling expenses (such as commissions) related to acquiring the customer. Commissions related to up-front consideration paid by customers in connection with the establishment of the monitoring arrangement are determined based on a percentage of the up-front fees and do not exceed deferred revenue. Such deferred costs are recorded as other current and noncurrent assets within the consolidated statements of financial position.

[0000833444-23-000048:notes:77]
Subscriber system assets and any deferred revenue resulting from the customer acquisition are accounted for over the expected life of the subscriber. In certain geographical areas which have a large number of customers that behave in a similar manner over time, the Company accounts for subscriber system assets and related deferred revenue using pools, with separate pools for

[0000833444-23-000048:notes:78]
the components of subscriber system assets and any related deferred revenue based on the same month and year of acquisition. Pooled subscriber system assets and related deferred revenue are depreciated using a straight-line method with lives up to 12 years and considering customer attrition. Non-pooled subscriber systems (primarily in Europe, Latin America and Asia) and related deferred revenue are depreciated using a straight-line method with a 15-year life, with remaining balances written off upon customer termination.

[0000833444-23-000048:notes:79]
Certain contracts and related customer relationships result from purchasing residential security monitoring contracts from an external network of independent dealers who operate under the ADT dealer program, primarily outside of North America. Acquired contracts and related customer relationships are recorded at their contractually determined purchase price.

[0000833444-23-000048:notes:80]
During the first 6 months (12 months in certain circumstances) after the purchase of the customer contract, any cancellation of monitoring service, including those that result from customer payment delinquencies, results in a chargeback by the Company to the dealer for the full amount of the contract purchase price. The Company records the amount charged back to the dealer as a reduction of the previously recorded intangible asset.

[0000833444-23-000048:notes:81]
Intangible assets arising from the ADT dealer program described above are amortized in pools determined by the same month and year of contract acquisition on a straight-line basis over the period of the customer relationship. The estimated useful life of dealer intangibles ranges from 12 to 15 years.

[0000833444-23-000048:notes:82]
Research and Development Costs

[0000833444-23-000048:notes:83]
Expenditures for research activities relating to product development and improvement are charged against income as incurred and included within selling, general and administrative expenses in the consolidated statements of income. Such expenditures for the years ended September 30, 2023, 2022 and 2021 were $320 million, $295 million and $275 million, respectively.

[0000833444-23-000048:notes:84]
Stock-Based Compensation

[0000833444-23-000048:notes:85]
Restricted (Non-vested) Stock /Units

[0000833444-23-000048:notes:86]
Restricted stock and restricted stock units are typically settled in shares for employees in the U.S. and in cash for employees not in the U.S. Restricted awards typically vest over a period of three years from the grant date. The Company's Compensation and Talent Development Committee may approve different vesting terms on specific grants. The fair value of each share-settled restricted award is based on the closing market value of the Company’s ordinary shares on the date of grant. The fair value of each cash-settled restricted award is recalculated at the end of each reporting period based on the closing market value of the Company's ordinary shares at the end of the reporting period, and the liability and expense are adjusted based on the new fair value.

[0000833444-23-000048:notes:87]
Performance Share Awards

[0000833444-23-000048:notes:88]
Performance-based share unit ("PSU") awards are generally contingent on the achievement of predetermined performance goals over a performance period of one to three years and on the award holder's continuous employment until the vesting date. The majority of PSUs are also indexed to the achievement of specified levels of total shareholder return versus a peer group over the performance period.

[0000833444-23-000048:notes:89]
Upon completion of the performance period, earned PSUs are typically settled with shares of the Company's ordinary shares for employees in the U.S. and in cash for employees not in the U.S.

[0000833444-23-000048:notes:90]
The fair value of the portion of the PSU which is linked to the achievement of performance goals is based on the closing market value of the Company's ordinary shares on the date of grant. Share-based compensation expense for these PSUs is recognized over the performance period based on the probability of achieving the performance targets.

[0000833444-23-000048:notes:91]
The fair value of the portion of the PSU that is indexed to total shareholder return is estimated on the date of grant using a Monte Carlo simulation that uses the following assumptions:

[0000833444-23-000048:notes:92]
•The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant.

[0000833444-23-000048:notes:93]
•The expected volatility is based on the historical volatility of the Company's stock over the most recent three-year period as of the grant date.

[0000833444-23-000048:notes:94]
Share-based compensation expense for PSUs which are indexed to total shareholder return is not adjusted for changes in performance subsequent to the grant date because the likelihood of achieving the market condition is incorporated in the grant date fair value of the award.

[0000833444-23-000048:notes:95]
Stock Options

[0000833444-23-000048:notes:96]
Stock options are granted with an exercise price equal to the market price of the Company’s stock at the date of grant. Stock option awards typically vest between two and three years after the grant date and expire ten years from the grant date.

[0000833444-23-000048:notes:97]
The fair value of each option is estimated on the date of grant using a Black-Scholes option valuation model that uses the following assumptions:

[0000833444-23-000048:notes:98]
•The expected life of options represents the period of time that options granted are expected to be outstanding.

[0000833444-23-000048:notes:99]
•The risk-free interest rate for periods during the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant.

[0000833444-23-000048:notes:100]
•For grants in fiscal 2023, expected volatility is based on the historical volatility of the Company's stock corresponding to the expected life as of the grant date. For grants in fiscal 2022 and fiscal 2021, expected volatility is based on the historical volatility of the Company's stock since October 2016 and certain peer companies' stock prior to October 2016 over the most recent period corresponding to the expected life as of the grant date.

[0000833444-23-000048:notes:101]
•The expected dividend yield is based on the expected annual dividend as a percentage of the market value of the Company’s ordinary shares as of the grant date.

[0000833444-23-000048:notes:102]
The Company uses historical data to estimate option exercises and employee terminations within the valuation model.

[0000833444-23-000048:notes:103]
Earnings Per Share

[0000833444-23-000048:notes:104]
The Company presents both basic and diluted earnings per share ("EPS") amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future and compensation cost for future service that the Company has not yet recognized. For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method include unamortized compensation cost.

[0000833444-23-000048:notes:105]
Foreign Currency Translation

[0000833444-23-000048:notes:106]
Substantially all of the Company’s international operations use the respective local currency as the functional currency. Assets and liabilities of international entities have been translated at period-end exchange rates, and income and expenses have been translated using average exchange rates for the period. Monetary assets and liabilities denominated in non-functional currencies are adjusted to reflect period-end exchange rates. Aggregate transaction gains, net of the impact of foreign currency hedges, for the years ended September 30, 2023, 2022 and 2021 were $28 million, $49 million and $56 million, respectively.

[0000833444-23-000048:notes:107]
Derivative Financial Instruments

[0000833444-23-000048:notes:108]
The Company has written policies and procedures that place all derivative financial instruments under the direction of Corporate treasury and restrict all derivative transactions to those intended for hedging purposes. The use of derivatives for speculative purposes is strictly prohibited. The Company selectively uses derivatives to manage the market risk from changes in foreign exchange rates, commodity prices, stock-based compensation liabilities and interest rates.

[0000833444-23-000048:notes:109]
The fair values of all derivatives are recorded in the consolidated statements of financial position. The change in a derivative’s fair value is recorded each period in current earnings or accumulated other comprehensive income ("AOCI"), depending on whether the derivative is designated as part of a hedge transaction and if so, the type of hedge transaction.

[0000833444-23-000048:notes:110]
Investments

[0000833444-23-000048:notes:111]
Investments in debt and equity securities and deferred compensation plan assets are marked to market at the end of each accounting period. Unrealized gains and losses are recognized in the consolidated statements of income.

[0000833444-23-000048:notes:112]
Pension and Postretirement Benefits

[0000833444-23-000048:notes:113]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event.

[0000833444-23-000048:notes:114]
Guarantees

[0000833444-23-000048:notes:115]
The Company records an estimate for future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-23-000048:notes:116]
The Company’s product warranty liability is recorded in the consolidated statements of financial position in other current liabilities if the warranty is less than one year and in other noncurrent liabilities if the warranty extends longer than one year.

[0000833444-23-000048:notes:117]
Loss Contingencies

[0000833444-23-000048:notes:118]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarial determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-23-000048:notes:119]
The Company is subject to laws and regulations relating to protecting the environment. Expenses associated with environmental remediation obligations are recognized when such amounts are probable and can be reasonably estimated.

[0000833444-23-000048:notes:120]
Liabilities and expenses for workers' compensation, product, general and auto liabilities is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. Receivables from third party insurers are recorded when recovery has been determined to be probable. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-23-000048:notes:121]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-23-000048:notes:122]
The Company and certain of its subsidiaries, along with numerous other companies, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The estimated liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarial determined time period through which asbestos-related claims will be filed against its affiliates). Estimated asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-23-000048:notes:123]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. Estimated asbestos-related insurance recoveries represent estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers.

[0000833444-23-000048:notes:124]
Income Taxes

[0000833444-23-000048:notes:125]
Deferred tax liabilities and assets are recognized for the expected future tax consequences of events that have been reflected in the consolidated financial statements. Deferred tax asset and liabilities are determined based on the differences between the book and tax basis of particular assets and liabilities and operating loss carryforwards, using tax rates in effect for the years in which the differences are expected to reverse. A valuation allowance is provided to reduce the carrying or book value of deferred tax assets if, based upon the available evidence, including consideration of tax planning strategies, it is more-likely-than-not that some or all of the deferred tax assets will not be realized.

[0000833444-23-000048:notes:126]
Prior Period Revision – Statement of Cash Flows

[0000833444-23-000048:notes:127]
The Company revised the amounts previously reported as net proceeds from borrowings with maturities less than three months and proceeds from debt for certain short-term debt transactions that were incorrectly presented on a net basis within the financing activities section of the consolidated statements of cash flows for the years ended September 30, 2022 and 2021. Cash provided by financing activities and the total increase (decrease) in cash, cash equivalents and restricted cash were unchanged for all affected periods. The Company does not believe the impact of the incorrect presentation was material to any period.

[0000833444-23-000048:notes:128]
New Accounting Pronouncements

[0000833444-23-000048:notes:129]
Recently Issued Accounting Pronouncements

[0000833444-23-000048:notes:130]
In September 2022, the FASB issued ASU 2022-04, "Disclosure of Supplier Finance Program Obligations", which is intended to enhance the transparency surrounding the use of supplier finance programs. Supplier finance programs may also be referred to as reverse factoring, payables finance, or structured payables arrangements. The amendments require a buyer that uses supplier finance programs to make annual disclosures about the program’s key terms, the balance sheet presentation of related amounts, the confirmed amount outstanding at the end of the period, and associated rollforward information. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company expects to adopt the new disclosures, other than the rollforward disclosure, as required at the beginning of fiscal 2024. The rollforward disclosures will be adopted as required at the beginning of fiscal 2025.

[0000833444-23-000048:notes:131]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-23-000048:notes:132]
ACQUISITIONS AND DIVESTITURES
FM:Systems Acquisition

[0000833444-23-000048:notes:133]
In July 2023, the Company completed its acquisition of FM:Systems, a leading digital workplace management and Internet of Things ("IoT") solutions provider for facilities and real estate professionals, for $540 million, net of cash acquired, which was comprised of an upfront cash payment of $465 million, net of cash acquired, and the estimated fair value at the acquisition date of contingent earn-out liabilities of $75 million. The contingent earn-out liabilities are primarily based upon the achievement of certain defined operating results in the two years following the acquisition, with a maximum payout of $155 million.

[0000833444-23-000048:notes:134]
In connection with the acquisition, the Company recorded goodwill of $399 million in the Building Solutions North America segment. Goodwill is attributable primarily to expected synergies, expanded market opportunities and other benefits that the Company believes will result from integrating the products and capabilities of FM:Systems into its operations. The goodwill created in the acquisition is not deductible for tax purposes.

[0000833444-23-000048:notes:135]
The preliminary fair values of the assets acquired and liabilities assumed related to FM:Systems are as follows (in millions):

[0000833444-23-000048:notes:136]
| Cash and cash equivalents |  | $ | 8 |  |
| Accounts receivable |  | 15 |  |
| All other current assets |  | 9 |  |
| Goodwill |  | 399 |  |
| Intangible assets |  | 194 |  |
| All other noncurrent assets |  | 7 |  |
| Total assets acquired |  | 632 |  |
| Deferred revenue |  | 24 |  |
| All other current liabilities |  | 49 |  |
| Other noncurrent liabilities |  | 11 |  |
| Total liabilities acquired |  | 84 |  |
| Net assets acquired |  | $ | 548 |  |

[0000833444-23-000048:notes:137]
The purchase price allocation to identifiable intangible assets acquired is as follows:

[0000833444-23-000048:notes:138]
|  |  | Fair Value (in millions) |  | Weighted Average Life (in years) |
| Customer relationships |  | $ | 117 |  |  | 10 |
| Technology |  | 74 |  |  | 10 |
| Trademarks and other definite-lived intangibles |  | 3 |  |  | 4 |
| Total identifiable intangible assets |  | $ | 194 |  |  |  |

[0000833444-23-000048:notes:139]
Silent-Aire Acquisition

[0000833444-23-000048:notes:140]
In May 2021, the Company completed its acquisition of Silent-Aire, a global leader in hyperscale data center cooling and modular critical infrastructure solutions, for approximately $755 million, net of cash acquired, which was comprised of an upfront net cash payment of approximately $661 million, the estimated fair value of contingent earn-out liabilities at the acquisition date of approximately $86 million and a working capital adjustment of $8 million. The contingent earn-out liabilities are based upon the achievement of certain defined operating results in each of the three years following the acquisition, with a maximum payout of approximately $250 million. The Company recorded reductions in the fair value of the contingent earn-out liability of $30 million and $43 million during the years ended September 30, 2023 and 2022, respectively. No earn-out payments were made for the twelve-month earn-out periods ended April 30, 2023 and 2022, as the performance measures for the periods were not achieved.

[0000833444-23-000048:notes:141]
Other Acquisitions

[0000833444-23-000048:notes:142]
During fiscal 2023, the Company acquired several other businesses for a combined purchase price, net of cash acquired, of $306 million, of which $260 million was paid as of September 30, 2023. Intangible assets associated with these acquisitions totaled $116 million and primarily relate to customer relationships and technology. The Company recorded goodwill associated with these acquisitions of $119 million in the Global Products segment, $55 million in the Building Solutions Asia Pacific segment and $13 million in the Building Solutions EMEA/LA segment.

[0000833444-23-000048:notes:143]
During fiscal 2022, the Company acquired several businesses for a combined purchase price, net of cash acquired, of $323 million, of which $269 million was paid as of September 30, 2022. Intangible assets associated with these acquisitions totaled $123 million and primarily relate to customer relationships and technology. The Company recorded goodwill associated with these acquisitions of $194 million, of which $68 million was assigned to the Building Solutions EMEA/LA segment, $45 million was assigned to the Global Products segment, $44 million was assigned to the Building Solutions Asia Pacific segment and $36 million was assigned to the Building Solutions North America segment.

[0000833444-23-000048:notes:144]
Other acquisitions were not material individually or in the aggregate in fiscal 2023 and 2022.

[0000833444-23-000048:notes:145]
Divestitures

[0000833444-23-000048:notes:146]
Refer to Note 3, "Assets and Liabilities Held for Sale & Discontinued Operations," of the notes to the consolidated financial statements for disclosure of a business in the Building Solutions Asia Pacific segment that was sold on August 1, 2023. No divestitures were material individually or in the aggregate in fiscal 2023 and 2022.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-23-000048:notes:147]
ASSETS AND LIABILITIES HELD FOR SALE AND DISCONTINUED OPERATIONS
Assets and Liabilities Held for Sale

[0000833444-23-000048:notes:148]
During fiscal 2023, the Company concluded that its Global Retail business, which is included in the Building Solutions North America, Building Solutions Asia Pacific and Building Solutions EMEA/LA segments and was previously presented as held for sale in the consolidated statements of financial position as of September 30, 2022, no longer met the criteria to be classified as held for sale. The Company discontinued sales efforts based on market factors and other considerations and determined that it was no longer probable that the business would be sold within one year. As a result, the assets and liabilities are now reported as held and used on the consolidated statements of financial position as of both September 30, 2023 and September 30, 2022. The net assets were reclassified to held and used at the lower of fair value or adjusted carrying value in the current period. Due to impairment charges recorded in prior periods, there was no impact to the consolidated statements of income as a result of the reclassification.

[0000833444-23-000048:notes:149]
A business in the Building Solutions Asia Pacific segment, which was previously classified as held for sale, was sold on August 1, 2023. The net assets were not significant to the consolidated statements of financial position.

[0000833444-23-000048:notes:150]
During fiscal 2022, the Company determined that certain assets of the Building Solutions Asia Pacific segment no longer met the criteria to be classified as held for sale because the Company could no longer assert that the sale of the assets was probable within one year due to declines in the Chinese real estate market after the COVID-19 lockdowns. As a result, the Company reclassified the held for sale assets to held and used as of September 30, 2022. As a result, the Company reclassified the held for sale assets to held and used as of September 30, 2022. Upon reclassification, an impairment of $45 million was recorded within restructuring and impairment costs in the consolidated statements of income to adjust the asset to the lower of its carrying value adjusted for depreciation and the fair value of the asset as of September 30, 2022.

[0000833444-23-000048:notes:151]
The following table summarizes impairment charges for the various assets held for sale (in millions):

[0000833444-23-000048:notes:152]
|  |  | Year Ended September 30, |  |
|  |  | 2023 |  | 2022 |  |  |
| Global Retail business |  | $ | 438 |  |  | $ | 359 |  |  |  |
| Business in the Building Solutions Asia Pacific segment |  | 60 |  |  | 60 |  |  |  |
| Certain assets in the Building Solution Asia Pacific segment |  | — |  |  | 45 |  |  |  |

[0000833444-23-000048:notes:153]
The impairment charges were recorded within restructuring and impairment costs in the consolidated statements of income and  include costs to write down the disposal groups to their estimated fair values, less costs to sell; impairment of goodwill; and the write-off of internal-use software projects that were no longer probable of being completed. Refer to Note 8, "Goodwill and Other Intangible Assets," of the notes to the consolidated financial statements for further information regarding the goodwill impairment charges.

[0000833444-23-000048:notes:154]
The businesses did not meet the criteria to be classified as discontinued operations as neither planned divestiture represented a strategic shift that would have a major effect on the Company's operations and financial results.

[0000833444-23-000048:notes:155]
Discontinued Operations
The Company completed the sale of its Power Solutions business on April 30, 2019. In fiscal 2021, the favorable resolution of certain post-closing working capital and net debt adjustments resulted in income from discontinued operations of $124 million, net of tax of $26 million, due to a reversal of a reserve established in connection with the sale


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-23-000048:notes:156]
REVENUE RECOGNITION
Disaggregated Revenue

[0000833444-23-000048:notes:157]
The following table presents the Company's revenues disaggregated by segment and by products and systems versus services revenue (in millions):

[0000833444-23-000048:notes:158]
|  |  | Year Ended September 30, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 6,368 |  |  | $ | 3,962 |  |  | $ | 10,330 |  |  | $ | 5,708 |  |  | $ | 3,659 |  |  | $ | 9,367 |  |
| Building Solutions EMEA/LA |  | 2,275 |  |  | 1,821 |  |  | 4,096 |  |  | 2,188 |  |  | 1,657 |  |  | 3,845 |  |
| Building Solutions Asia Pacific |  | 1,987 |  |  | 759 |  |  | 2,746 |  |  | 2,005 |  |  | 709 |  |  | 2,714 |  |
| Global Products |  | 9,621 |  |  | — |  |  | 9,621 |  |  | 9,373 |  |  | — |  |  | 9,373 |  |
| Total |  | $ | 20,251 |  |  | $ | 6,542 |  |  | $ | 26,793 |  |  | $ | 19,274 |  |  | $ | 6,025 |  |  | $ | 25,299 |  |

[0000833444-23-000048:notes:159]
The following table presents further disaggregation of Global Products revenues by product type (in millions):

[0000833444-23-000048:notes:160]
|  |  | Year Ended September 30, |
|  |  | 2023 |  | 2022 |
| HVAC |  | $ | 6,820 |  |  | $ | 6,756 |  |
| Fire & Security |  | 2,446 |  |  | 2,367 |  |
| Industrial Refrigeration |  | 355 |  |  | 250 |  |
| Total |  | $ | 9,621 |  |  | $ | 9,373 |  |

[0000833444-23-000048:notes:161]
Contract Balances

[0000833444-23-000048:notes:162]
Contract assets represent the Company’s right to consideration for performance obligations that have been satisfied but not billed and consist of unbilled receivables and costs in excess of billings. Contract liabilities are customer payments received before performance obligations are satisfied. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

[0000833444-23-000048:notes:163]
The following table presents the location and amount of contract balances in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000048:notes:164]
|  |  |  |  | September 30, |  |  |
|  |  | Location of contract balances |  | 2023 |  | 2022 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,370 |  |  | $ | 2,067 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 12 |  |  | 79 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 1,996 |  |  | 1,804 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 297 |  |  | 282 |  |  |  |

[0000833444-23-000048:notes:165]
The Company recognized revenue that was included in the beginning of period contract liability balance of approximately $1.6 billion and $1.5 billion for the years ended September 30, 2023 and 2022, respectively.

[0000833444-23-000048:notes:166]
Performance Obligations

[0000833444-23-000048:notes:167]
A performance obligation is a distinct good, service, or bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

[0000833444-23-000048:notes:168]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of September 30, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $19.6 billion, of which approximately 65% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with average initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-23-000048:notes:169]
Costs to Obtain or Fulfill a Contract

[0000833444-23-000048:notes:170]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when the costs are recoverable. These costs consist primarily of sales commissions and bid/proposal costs. Costs to obtain or fulfill a contract are capitalized when incurred and amortized to expense over the period of contract performance.

[0000833444-23-000048:notes:171]
The following table presents the location and amount of costs to obtain or fulfill a contract recorded in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000048:notes:172]
|  |  | September 30, |  |  |
|  |  | 2023 |  | 2022 |  |  |
| Other current assets |  | $ | 156 |  |  | $ | 139 |  |  |  |
| Other noncurrent assets |  | 224 |  |  | 174 |  |  |  |
| Total |  | $ | 380 |  |  | $ | 313 |  |  |  |

[0000833444-23-000048:notes:173]
Amortization of costs to obtain or fulfill a contract were $251 million and $191 million during the years ended September 30, 2023 and 2022, respectively. There were no impairment losses recognized in the year ended September 30, 2023 or 2022.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0000833444-23-000048:notes:174]
ACCOUNTS RECEIVABLEThe Company sold $1,962 million and $1,115 million of accounts receivable under factoring agreements during the years ended September 30, 2023, and 2022, respectively. The cost of factoring such receivables was not material. Previously sold receivables still outstanding were $681 million and $476 million as of September 30, 2023 and September 30, 2022, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-23-000048:notes:175]
INVENTORIES
Inventories consisted of the following (in millions):

[0000833444-23-000048:notes:176]
|  | September 30, |
|  | 2023 |  | 2022 |
| Raw materials and supplies | $ | 1,203 |  |  | $ | 1,040 |  |
| Work-in-process | 226 |  |  | 203 |  |
| Finished goods | 1,347 |  |  | 1,422 |  |
| Inventories | $ | 2,776 |  |  | $ | 2,665 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-23-000048:notes:177]
PROPERTY, PLANT AND EQUIPMENT
Property, plant and equipment consisted of the following (in millions):

[0000833444-23-000048:notes:178]
|  | September 30, |
|  | 2023 |  | 2022 |
| Buildings and improvements | $ | 1,337 |  |  | $ | 1,320 |  |
| Subscriber systems | 823 |  |  | 762 |  |
| Machinery and equipment | 4,227 |  |  | 3,745 |  |
| Construction in progress | 540 |  |  | 514 |  |
| Land | 194 |  |  | 197 |  |
| Total property, plant and equipment | 7,121 |  |  | 6,538 |  |
| Less: Accumulated depreciation | (3,985) |  |  | (3,407) |  |
| Property, plant and equipment - net | $ | 3,136 |  |  | $ | 3,131 |  |

[0000833444-23-000048:notes:179]
During the fourth quarter of fiscal 2023, the Company determined that a triggering event had occurred in the asset group comprising the security subscriber business of Argentina, primarily as a result of the significant devaluation of the Argentine peso that occurred during the quarter and the resulting impact on operating results and cash flows. The Company conducted the two-step impairment test required in accordance with ASC 360, "Property, Plant & Equipment" and determined that the carrying amount of the asset group exceeded its fair value. A non-cash impairment charge to the subscriber system assets of $78 million was recorded and is included in restructuring and impairment costs in the consolidated statements of income. The Company used a discounted cash flow model to estimate the fair value of the asset group. The primary assumptions and inputs used in the model included management's internal projections of future cash flows, the weighted-average cost of capital and the long-term growth rate. The fair value measurement is classified as Level 3 within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement" due to the unobservable inputs used.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-23-000048:notes:180]
GOODWILL AND OTHER INTANGIBLE ASSETS
Goodwill

[0000833444-23-000048:notes:181]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments were as follows (in millions):

[0000833444-23-000048:notes:182]
|  |  | Year Ended September 30, 2023 |
|  |  | Building Solutions North America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total |
| Goodwill |  | $ | 9,630 |  |  | $ | 1,794 |  |  | $ | 1,116 |  |  | $ | 5,591 |  |  | 18,131 |  |
| Accumulated impairment loss |  | (659) |  |  | (47) |  |  | — |  |  | (75) |  |  | (781) |  |
| Balance at beginning of period |  | 8,971 |  |  | 1,747 |  |  | 1,116 |  |  | 5,516 |  |  | 17,350 |  |
| Acquisitions (1) |  | 399 |  |  | 13 |  |  | 55 |  |  | 119 |  |  | 586 |  |
| Impairments |  | — |  |  | — |  |  | — |  |  | (184) |  |  | (184) |  |
| Foreign currency translation and other |  | 11 |  |  | 125 |  |  | 8 |  |  | 40 |  |  | 184 |  |
| Balance at end of period |  | $ | 9,381 |  |  | $ | 1,885 |  |  | $ | 1,179 |  |  | $ | 5,491 |  |  | $ | 17,936 |  |

[0000833444-23-000048:notes:183]
|  |  | Year Ended September 30, 2022 |  |
|  |  | Building Solutions North America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total |  |
| Goodwill |  | $ | 9,639 |  |  | $ | 2,088 |  |  | $ | 1,237 |  |  | $ | 5,842 |  |  | 18,806 |  |  |
| Accumulated impairment loss |  | (424) |  |  | (47) |  |  | — |  |  | — |  |  | (471) |  |  |
| Balance at beginning of period |  | 9,215 |  |  | 2,041 |  |  | 1,237 |  |  | 5,842 |  |  | 18,335 |  |  |
| Acquisitions (1) |  | 37 |  |  | 78 |  |  | 44 |  |  | 60 |  |  | 219 |  |  |
| Divestitures |  | — |  |  | (5) |  |  | (14) |  |  | — |  |  | (19) |  |  |
| Impairments |  | (235) |  |  | — |  |  | — |  |  | (75) |  |  | (310) |  |  |
| Foreign currency translation and other |  | (46) |  |  | (367) |  |  | (151) |  |  | (311) |  |  | (875) |  |  |
| Balance at end of period |  | $ | 8,971 |  |  | $ | 1,747 |  |  | $ | 1,116 |  |  | $ | 5,516 |  |  | $ | 17,350 |  |  |

[0000833444-23-000048:notes:184]
(1)  Includes measurement period adjustments

[0000833444-23-000048:notes:185]
In the second quarter of fiscal 2023, management completed an updated comprehensive review of the Silent-Aire reporting unit, which is included in the Global Products segment. Because actual results were lower than planned and the nearer term forecast was revised to reflect lower margins and earnings, the Company determined a triggering event had occurred and a quantitative test of goodwill for possible impairment was necessary. As a result of the goodwill impairment test, the Company recorded a non-cash impairment charge of $184 million within restructuring and impairment costs in the consolidated statements of income in fiscal 2023, which was determined by comparing the carrying amount of the reporting unit to its fair value. The Silent-Aire reporting unit has no remaining goodwill balance as of September 30, 2023.

[0000833444-23-000048:notes:186]
Management completed its fiscal 2023 annual impairment test as of July 31. The fair value of all reporting units substantially exceeded their carrying values, with the exception of one reporting unit with $455 million of goodwill whose fair value in excess of its carrying value was approximately 10%. For this reporting unit, a 1% increase in the discount rate, or a 1.5% decrease in the revenue growth rates, would cause the fair value to be less than the carrying value. While no impairment was recorded, it is possible that future changes in circumstances could result in a non-cash impairment charge.

[0000833444-23-000048:notes:187]
During its fiscal 2022 annual impairment test, the Company determined that goodwill in the Silent-Are reporting unit was impaired and recorded a non-cash impairment charge of $75 million within restructuring and impairment costs in the consolidated statements of income. The impairment charge was determined by comparing the carrying amount of the reporting unit to its fair value.

[0000833444-23-000048:notes:188]
The Company used a discounted cash flow model to estimate the fair value of the Silent-Aire reporting unit in both fiscal 2023 and 2022. The primary assumptions and inputs used in the model included management's internal projections of future cash flows, the weighted-average cost of capital and the long-term growth rate. The fair value measurement is classified as Level 3 within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement" due to the unobservable inputs used.

[0000833444-23-000048:notes:189]
In fiscal 2022, the Company concluded it had a triggering event requiring assessment of goodwill impairment for its North America Retail reporting unit in conjunction with classifying its Global Retail business as held for sale. As a result, the Company recorded a non-cash impairment charge of $235 million within restructuring and impairment costs in the consolidated statements of income in fiscal 2022. The North America Retail reporting unit had no remaining goodwill balance as of September 30, 2023 or 2022. The Company used the market approach to estimate the fair value of the reporting unit based on the relative estimated sales proceeds for the planned disposal of the Global Retail business attributable to the North America Retail reporting unit. The inputs utilized in the analysis are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-23-000048:notes:190]
Refer to Note 3, "Assets and Liabilities Held for Sale & Discontinued Operations," of the notes to the consolidated financial statements for further disclosure.

[0000833444-23-000048:notes:191]
There were no other triggering events requiring that an impairment assessment be conducted in fiscal 2023, 2022 or 2021. However, it is possible that future changes in circumstances would require the Company to record additional non-cash impairment charges.

[0000833444-23-000048:notes:192]
Other Intangible Assets

[0000833444-23-000048:notes:193]
The Company’s other intangible assets, primarily from business acquisitions, consisted of (in millions):

[0000833444-23-000048:notes:194]
|  | September 30, |
|  | 2023 |  | 2022 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,575 |  |  | $ | (806) |  |  | $ | 769 |  |  | $ | 1,481 |  |  | $ | (728) |  |  | $ | 753 |  |
| Customer relationships | 3,047 |  |  | (1,496) |  |  | 1,551 |  |  | 3,011 |  |  | (1,340) |  |  | 1,671 |  |
| Miscellaneous | 889 |  |  | (435) |  |  | 454 |  |  | 949 |  |  | (425) |  |  | 524 |  |
|  | 5,511 |  |  | (2,737) |  |  | 2,774 |  |  | 5,441 |  |  | (2,493) |  |  | 2,948 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/tradenames | 2,114 |  |  | — |  |  | 2,114 |  |  | 2,207 |  |  | — |  |  | 2,207 |  |
| Total intangible assets | $ | 7,625 |  |  | $ | (2,737) |  |  | $ | 4,888 |  |  | $ | 7,648 |  |  | $ | (2,493) |  |  | $ | 5,155 |  |

[0000833444-23-000048:notes:195]
During the fourth quarter of fiscal 2023, the Company impaired $18 million of Miscellaneous intangible assets in the Global Products segment and $10 million of a trademark in the Building Solutions Asia Pacific segment. These non-cash charges were recorded within restructuring and impairment costs in the consolidated statements of income.

[0000833444-23-000048:notes:196]
There was no impairment of other indefinite-lived intangible assets in any of these years, other than as disclosed above. For all other remaining indefinite lived intangible assets, the Company estimated fair values were greater than the carrying values, with the exception of three other registered trademarks in which the estimated fair values were consistent with their carrying values which totaled $412 million.

[0000833444-23-000048:notes:197]
Amortization of other intangible assets included within continuing operations for the years ended September 30, 2023, 2022 and 2021 was $439 million, $427 million and $435 million, respectively.

[0000833444-23-000048:notes:198]
The following table summarizes the expected amortization of definite-lived intangible assets, excluding the impact of future acquisitions, by year (in millions):

[0000833444-23-000048:notes:199]
| 2024 |  | $ | 508 |  |
| 2025 |  | 479 |
| 2026 |  | 410 |
| 2027 |  | 365 |
| 2028 |  | 252 |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-23-000048:notes:200]
LEASES
The following table presents the Company’s lease costs (in millions):

[0000833444-23-000048:notes:201]
|  |  | Year Ended September 30, |  |
|  |  | 2023 |  | 2022 |  | 2021 |  |
| Operating lease cost |  | $ | 384 |  |  | $ | 352 |  |  | $ | 384 |  |  |
| Variable lease cost |  | 165 |  |  | 165 |  |  | 130 |  |  |
| Total lease costs |  | $ | 549 |  |  | $ | 517 |  |  | $ | 514 |  |  |

[0000833444-23-000048:notes:202]
The following table presents supplemental consolidated statement of financial position information (in millions):

[0000833444-23-000048:notes:203]
|  |  |  | September 30, |
|  | Location of lease balances |  | 2023 |  | 2022 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,389 |  |  | $ | 1,271 |  |
| Operating lease liabilities - current | Other current liabilities |  | 318 |  |  | 280 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 1,086 |  |  | 987 |  |
| Weighted-average remaining lease term |  |  | 7 years |  | 7 years |
| Weighted-average discount rate |  |  | 3.5 | % |  | 2.1 | % |

[0000833444-23-000048:notes:204]
The following table presents supplemental cash flow information related to operating leases (in millions):

[0000833444-23-000048:notes:205]
|  |  | Year Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Cash paid for amounts included in the measurement of lease liability: |  |  |  |  |  |  |
| Operating cash outflows from operating leases |  | $ | 373 |  |  | $ | 367 |  |  | $ | 398 |  |
| Noncash operating lease activity: |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  | 427 |  |  | 369 |  |  | 515 |  |

[0000833444-23-000048:notes:206]
The following table presents future minimum rental payments for operating lease liabilities as of September 30, 2023 (in millions):

[0000833444-23-000048:notes:207]
| 2024 |  | $ | 358 |  |
| 2025 |  | 300 |  |
| 2026 |  | 227 |  |
| 2027 |  | 171 |  |
| 2028 |  | 123 |  |
| After 2028 |  | 404 |  |
| Total operating lease payments |  | 1,583 |  |
| Less: Interest |  | (179) |  |
| Present value of lease payments |  | $ | 1,404 |  |


## us-gaap:LeaseCostTableTextBlock

[0000833444-23-000048:notes:208]
The following table presents the Company’s lease costs (in millions):


## us-gaap:DebtDisclosureTextBlock

[0000833444-23-000048:notes:209]
DEBT AND FINANCING ARRANGEMENTS
Short-Term Debt

[0000833444-23-000048:notes:210]
Short-term debt consisted of the following (in millions):

[0000833444-23-000048:notes:211]
|  | September 30, |
|  | 2023 |  | 2022 |
| Bank borrowings | $ | 26 |  |  | $ | 10 |  |
| Commercial paper | 200 |  |  | 172 |  |
| Term loans | 159 |  |  | 487 |  |
|  | $ | 385 |  |  | $ | 669 |  |
| Weighted average interest rate on short-term debt outstanding | 5.1 | % |  | 0.5 | % |

[0000833444-23-000048:notes:212]
Long-Term Debt

[0000833444-23-000048:notes:213]
Long-term debt consisted of the following (in millions; due dates by fiscal year):

[0000833444-23-000048:notes:214]
|  |  |  |  | Carrying Value |
| Issuer | Interest Rate | Due Date | Par Value | September 30, 2023 | September 30, 2022 |
| JCI plc | 4.625% | 2023 | $ | 25 |  | $ | — |  | $ | 25 |  |
| TIFSA1 | 4.625% | 2023 | $ | 7 |  | — |  | 7 |  |
| JCI plc | 1.00% | 2023 | € | 846 |  | — |  | 830 |  |
| JCI plc | 3.625% | 2024 | $ | 453 |  | 453 | 453 |  |
| JCI Inc. | 3.625% | 2024 | $ | 31 |  | 31 | 31 |  |
| JCI plc | EURIBOR plus 0.70% | 2024 | € | 150 |  | 159 |  | — |  |
| JCI plc | 1.375% | 2025 | € | 423 |  | 450 | 419 |  |
| TIFSA1 | 1.375% | 2025 | € | 54 |  | 57 | 53 |  |
| JCI plc | 3.90% | 2026 | $ | 487 |  | 499 | 505 |  |
| TIFSA1 | 3.90% | 2026 | $ | 51 |  | 50 | 51 |  |
| JCI plc | TORF plus 0.40% | 2027 | ¥ | 30,000 |  | 202 | 208 |  |
| JCI plc and TFSCA2 | 0.375% | 2027 | € | 500 |  | 528 | 488 |  |
| JCI plc and TFSCA2 | 3.00% | 2028 | € | 600 |  | 634 | 586 |  |
| JCI plc and TFSCA2 | 1.75% | 2030 | $ | 625 |  | 624 | 623 |  |
| JCI plc and TFSCA2 | 2.00% | 2031 | $ | 500 |  | 497 | 496 |  |
| JCI plc and TFSCA2 | 1.00% | 2032 | € | 500 |  | 529 | 489 |  |
| JCI plc and TFSCA2 | 4.90% | 2032 | $ | 400 |  | 394 | 394 |  |
| JCI plc and TFSCA2 | 4.25% | 2035 | € | 800 |  | 839 | — |  |
| JCI plc | 6.00% | 2036 | $ | 342 |  | 339 | 339 |  |
| JCI Inc. | 6.00% | 2036 | $ | 8 |  | 8 | 8 |  |
| JCI plc | 5.70% | 2041 | $ | 190 |  | 189 | 189 |  |
| JCI Inc. | 5.70% | 2041 | $ | 30 |  | 30 | 30 |  |
| JCI plc | 5.25% | 2042 | $ | 155 |  | 155 | 155 |  |
| JCI Inc. | 5.25% | 2042 | $ | 6 |  | 6 | 6 |  |
| JCI plc | 4.625% | 2044 | $ | 444 |  | 442 | 441 |  |
| JCI Inc. | 4.625% | 2044 | $ | 6 |  | 6 | 6 |  |
| JCI plc | 5.125% | 2045 | $ | 477 |  | 431 | 557 |  |
| TIFSA1 | 5.125% | 2045 | $ | 23 |  | 23 | 23 |  |
| JCI plc | 6.95% | 2046 | $ | 32 |  | 32 | 32 |  |
| JCI Inc. | 6.95% | 2046 | $ | 4 |  | 4 | 4 |  |
| JCI plc | 4.50% | 2047 | $ | 500 |  | 496 | 496 |  |
| JCI plc | 4.95% | 2064 | $ | 341 |  | 340 | 340 |  |
| JCI Inc. | 4.95% | 2064 | $ | 15 |  | 15 | 15 |  |
| Other |  |  |  | 36 |  | 25 |  |
| Gross long-term debt |  |  |  | 8,498 |  | 8,324 |  |
| Less: current portion |  |  |  | 645 |  | 865 |  |
| Less: debt issuance costs |  |  |  | 35 |  | 33 |  |
| Long-term debt |  |  |  | $ | 7,818 |  | $ | 7,426 |  |

[0000833444-23-000048:notes:215]
1 TIFSA = Tyco International Finance S.A.

[0000833444-23-000048:notes:216]
2 TFSCA = Tyco Fire & Security Finance S.C.A.

[0000833444-23-000048:notes:217]
The following table presents maturities of long-term debt as of September 30, 2023 (in millions):

[0000833444-23-000048:notes:218]
| 2024 |  | $ | 646 |  |
| 2025 |  | 508 |  |
| 2026 |  | 550 |  |
| 2027 |  | 731 |  |
| 2028 |  | 634 |  |
| After 2028 |  | 5,429 |  |
| Total |  | $ | 8,498 |  |

[0000833444-23-000048:notes:219]
Other

[0000833444-23-000048:notes:220]
As of September 30, 2023, the Company had a syndicated $2.5 billion committed revolving credit facility, which was scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which expired in November 2023. Both credit facilities were renewed on December 11, 2023. The $2.5 billion facility is now scheduled to expire in December 2028 and the $500 million facility is now scheduled to expire in December 2024. There were no draws on the facilities as of September 30, 2023.

[0000833444-23-000048:notes:221]
As of September 30, 2023, the Company was in compliance with all financial covenants set forth in its credit agreements and the indentures governing its outstanding notes, and expects to remain in compliance for the foreseeable future. 
Total interest paid on both short and long-term debt for the years ended September 30, 2023, 2022 and 2021 was $298 million, $226 million and $242 million, respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-23-000048:notes:222]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES
Cash Flow Hedges

[0000833444-23-000048:notes:223]
The Company has global operations and participates in foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange forward contracts. The Company hedges 70% to 90% of the notional amount of each of its known foreign exchange transactional exposures.

[0000833444-23-000048:notes:224]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with its purchases of copper and aluminum in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-23-000048:notes:225]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the years ended September 30, 2023 and 2022.

[0000833444-23-000048:notes:226]
The Company had the following outstanding contracts to hedge forecasted commodity purchases (in metric tons):

[0000833444-23-000048:notes:227]
|  |  | Volume Outstanding as of September 30, |
| Commodity |  | 2023 |  | 2022 |
| Copper |  | 2,812 |  |  | 3,629 |  |
| Aluminum |  | 5,976 |  |  | 6,758 |  |

[0000833444-23-000048:notes:228]
The Company enters into forward-starting interest rate swaps in conjunction with anticipated note issuances. The following table summarizes forward-starting interest rate swaps and the related anticipated note issuances (in millions):

[0000833444-23-000048:notes:229]
|  |  | Year Ended September 30, |
|  | 2023 |  | 2022 |
| US dollar denominated |  |  |  |  |
| Forward-starting interest swaps |  | $ | 600 |  |  | $ | 300 |  |
| Anticipated note issuance |  | 800 |  |  | 400 |  |
| Euro denominated |  |  |  |  |
| Forward-starting interest swap |  | € | 400 |  |  | € | 200 |  |
| Anticipated note issuance |  | 800 |  |  | 600 |  |

[0000833444-23-000048:notes:230]
Forward-starting interest swaps are terminated when the anticipated notes are issued. As of September 30, 2023, $600 million of forward-starting interest swaps were outstanding. Accumulated amounts recorded in AOCI as of the date of the note issuance are amortized to interest expense over the life of the related note to reflect the difference between the swap's reference rate and the fixed rate of the note.

[0000833444-23-000048:notes:231]
Net Investment Hedges

[0000833444-23-000048:notes:232]
The Company enters into cross-currency interest rate swaps and foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the cross-currency interest rate swaps and debt obligations are reflected in the AOCI account within shareholders’equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-23-000048:notes:233]
The following table summarizes net investment hedges (in billions):

[0000833444-23-000048:notes:234]
|  |  | September 30, |
|  | 2023 |  | 2022 |
| Euro-denominated bonds designated as net investment hedges in Europe |  | € | 2.9 |  |  | € | 2.9 |  |
| Yen-denominated debt designated as a net investment hedge in Japan |  | ¥ | 30 |  |  | ¥ | 30 |  |
| US dollar vs. Yen cross-currency interest rate swap designated as a net investment hedge in Japan |  | ¥ | 14 |  |  | ¥ | — |  |

[0000833444-23-000048:notes:235]
Derivatives Not Designated as Hedging Instruments

[0000833444-23-000048:notes:236]
The Company holds certain foreign currency forward contracts not designated as hedging instruments under ASC 815 to hedge foreign currency exposure resulting from monetary assets and liabilities denominated in nonfunctional currencies. The changes in fair value of these foreign currency exchange derivatives are recorded in the consolidated statements of income where they offset foreign currency transactional gains and losses on the nonfunctional currency denominated assets and liabilities being hedged.

[0000833444-23-000048:notes:237]
Fair Value of Derivative Instruments

[0000833444-23-000048:notes:238]
The following table presents the location and fair values of derivative instruments and hedging activities included in the Company’s consolidated statements of financial position (in millions):

[0000833444-23-000048:notes:239]
|  | Designated as Hedging Instruments |  | Not Designatedas Hedging Instruments |
|  | September 30, 2023 |  | September 30, 2022 |  | September 30, 2023 |  | September 30, 2022 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 16 |  |  | $ | 30 |  |  | $ | 13 |  |  | $ | 24 |  |
| Interest rate swaps | 22 |  |  | — |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Cross-currency interest rate swap | 5 |  |  | — |  |  | — |  |  | — |  |
| Total assets | $ | 43 |  |  | $ | 30 |  |  | $ | 13 |  |  | $ | 24 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 20 |  |  | $ | 24 |  |  | $ | 5 |  |  | $ | 27 |  |
| Commodity derivatives | 2 |  |  | 10 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,253 |  |  | 3,077 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,275 |  |  | $ | 3,111 |  |  | $ | 5 |  |  | $ | 27 |  |

[0000833444-23-000048:notes:240]
Counterparty Credit Risk

[0000833444-23-000048:notes:241]
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with substantially all of its counterparties. The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position.

[0000833444-23-000048:notes:242]
The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-23-000048:notes:243]
The gross and net amounts of derivative assets and liabilities were as follows (in millions):

[0000833444-23-000048:notes:244]
|  | Fair Value of Assets |  | Fair Value of Liabilities |
|  | September 30, 2023 |  | September 30, 2022 |  | September 30, 2023 |  | September 30, 2022 |  |
| Gross amount recognized | $ | 56 |  |  | $ | 54 |  |  | $ | 3,280 |  |  | $ | 3,138 |  |  |
| Gross amount eligible for offsetting | (19) |  |  | (42) |  |  | (19) |  |  | (42) |  |  |
| Net amount | $ | 37 |  |  | $ | 12 |  |  | $ | 3,261 |  |  | $ | 3,096 |  |  |

[0000833444-23-000048:notes:245]
Derivatives Impact on the Statements of Income and Statements of Comprehensive Income

[0000833444-23-000048:notes:246]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges (in millions):

[0000833444-23-000048:notes:247]
| Derivatives in Cash Flow Hedging Relationships |  | Year Ended September 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Foreign currency exchange derivatives |  | $ | (13) |  |  | $ | 26 |  |  | $ | 15 |  |
| Commodity derivatives |  | 1 |  |  | (21) |  |  | 4 |  |
| Interest rate swaps |  | 27 |  |  | 16 |  |  | (21) |  |
| Total |  | $ | 15 |  |  | $ | 21 |  |  | $ | (2) |  |

[0000833444-23-000048:notes:248]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income (in millions):

[0000833444-23-000048:notes:249]
| Derivatives in Cash FlowHedging Relationships |  | Location of Gain (Loss)Reclassified from AOCI into Income |  | Year Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (4) |  |  | $ | 25 |  |  | $ | 11 |  |
| Commodity derivatives |  | Cost of sales |  | (8) |  |  | (7) |  |  | 3 |  |
| Interest rate swaps |  | Net financing charges |  | — |  |  | (2) |  |  | — |  |
| Total |  |  |  | $ | (12) |  |  | $ | 16 |  |  | $ | 14 |  |

[0000833444-23-000048:notes:250]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income (in millions):

[0000833444-23-000048:notes:251]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2023 |  | 2022 |  | 2021 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (16) |  |  | $ | 10 |  |  | $ | (6) |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | (103) |  |  | 85 |  |  | 174 |  |
| Foreign currency exchange derivatives |  | Selling, general and administrative |  | — |  |  | — |  |  | (2) |  |
| Foreign currency exchange derivatives |  | Income tax provision |  | — |  |  | — |  |  | (1) |  |
| Interest rate swaps |  | Net financing charges |  | 1 |  |  | — |  |  | — |  |
| Equity swap |  | Selling, general and administrative |  | — |  |  | (5) |  |  | 28 |  |
| Total |  |  |  | $ | (118) |  |  | $ | 90 |  |  | $ | 193 |  |

[0000833444-23-000048:notes:252]
Pre-tax gains (losses) on net investment hedges recorded as foreign currency translation adjustment ("CTA") within other comprehensive income (loss) were $(223) million, $470 million and $42 million for the years ended September 30, 2023, 2022 and 2021, respectively. No gains or losses were reclassified from CTA into income for the years ended September 30, 2023, 2022 and 2021.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-23-000048:notes:253]
FAIR VALUE MEASUREMENTS
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value (in millions):

[0000833444-23-000048:notes:254]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2023 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |
| Interest rate swaps | 22 |  |  | — |  |  | 22 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Cross-currency interest rate swap | 5 |  |  | — |  |  | 5 |  |  | — |  |
| Deferred compensation plan assets | 45 |  |  | 45 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 76 |  |  | 76 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 155 |  |  | 155 |  |  | — |  |  | — |  |
| Total assets | $ | 332 |  |  | $ | 276 |  |  | $ | 56 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 25 |  |  | $ | — |  |  | $ | 25 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Contingent earn-out liabilities | 48 |  |  | — |  |  | — |  |  | 48 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 76 |  |  | — |  |  | — |  |  | 76 |  |
| Total liabilities | $ | 151 |  |  | $ | — |  |  | $ | 27 |  |  | $ | 124 |  |

[0000833444-23-000048:notes:255]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2022 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |
| Exchange traded funds (fixed income)1 | 22 |  |  | 22 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 46 |  |  | 46 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 86 |  |  | 86 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 131 |  |  | 131 |  |  | — |  |  | — |  |
| Total assets | $ | 339 |  |  | $ | 285 |  |  | $ | 54 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 51 |  |  | $ | — |  |  | $ | 51 |  |  | $ | — |  |
| Commodity derivatives | 10 |  |  | — |  |  | 10 |  |  | — |  |
| Contingent earn-out liabilities | 30 |  |  | — |  |  | — |  |  | 30 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 30 |  |  | — |  |  | — |  |  | 30 |  |
| Total liabilities | $ | 121 |  |  | $ | — |  |  | $ | 61 |  |  | $ | 60 |  |

[0000833444-23-000048:notes:256]
1Classified as restricted investments for payment of asbestos liabilities. Refer to Note 21, "Commitments and Contingencies" of the notes to consolidated financial statements for further details.

[0000833444-23-000048:notes:257]
The following table summarizes the changes in contingent earn-out liabilities, which are valued using significant unobservable inputs (Level 3) (in millions):

[0000833444-23-000048:notes:258]
| Balance at September 30, 2022 | $ | 60 |  |  |
| Acquisitions | 112 |  |  |
| Payments | (10) |  |  |
| Reduction for change in estimates | (39) |  |  |
| Currency translation | 1 |  |  |
| Balance at September 30, 2023 | $ | 124 |  |  |

[0000833444-23-000048:notes:259]
Valuation Methods

[0000833444-23-000048:notes:260]
Commodity derivatives: The commodity derivatives are valued under a market approach using publicized prices, where available, or dealer quotes.

[0000833444-23-000048:notes:261]
Contingent earn-out liabilities: The contingent earn-out liabilities are generally established using a Monte Carlo simulation based on the forecasted operating results and the earn-out formulas specified in the purchase agreements.

[0000833444-23-000048:notes:262]
Cross-currency interest rate swaps: The fair value of cross-currency interest rate swaps represents the difference between the swap's reference rate and exchange rate and the interest and exchange rates for a similar instrument as of the reporting period. Cross-currency interest rate swaps are valued under a market approach using publicized prices.

[0000833444-23-000048:notes:263]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. Unrealized gains (losses) on the deferred compensation plan assets are recognized in the consolidated statements of income where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-23-000048:notes:264]
Foreign currency exchange derivatives: The foreign currency exchange derivatives are valued under a market approach using publicized spot and forward prices.

[0000833444-23-000048:notes:265]
Interest rate swaps: The fair value of interest rate swaps represents the difference between the swap's reference rate and the interest rate for a similar instrument as of the reporting period. Interest rate swaps are valued under a market approach using publicized prices.

[0000833444-23-000048:notes:266]
Investments in exchange traded funds: Investments in exchange traded funds are valued using a market approach based on quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. Refer to Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-23-000048:notes:267]
The following table presents the portion of unrealized gains (losses) recognized in the consolidated statements of income that relate to equity securities still held at September 30, 2023 and 2022 (in millions):

[0000833444-23-000048:notes:268]
|  |  | Year Ended September 30, |  |
|  | 2023 |  | 2022 |  |
| Deferred compensation plan assets |  | $ | 5 |  |  | $ | (10) |  |  |
| Investments in exchange traded funds |  | 24 |  |  | (55) |  |  |

[0000833444-23-000048:notes:269]
All of the gains and losses on investments in exchange traded funds related to restricted investments.

[0000833444-23-000048:notes:270]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values.

[0000833444-23-000048:notes:271]
The fair value of long-term debt at September 30, 2023 and 2022 was as follows (in billions):

[0000833444-23-000048:notes:272]
|  |  | Year Ended September 30, |  |
|  | 2023 |  | 2022 |  |
| Public debt |  | $ | 7.1 |  |  | $ | 7.1 |  |  |
| Other long-term debt |  | 0.4 |  |  | 0.2 |  |  |
| Total fair value of long-term debt |  | $ | 7.5 |  |  | $ | 7.3 |  |  |

[0000833444-23-000048:notes:273]
The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-23-000048:notes:274]
STOCK-BASED COMPENSATION
The Johnson Controls International plc 2021 Equity and Incentive Plan authorizes stock options, stock appreciation rights, restricted (non-vested) stock/units, performance shares, performance units and other stock-based awards. The Compensation and Talent Development Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Annual awards are typically granted in the first quarter of the fiscal year. As of September 30, 2023, there were 55 million shares of the Company's common stock reserved and 41 million shares available for issuance under the 2021 Equity and Incentive Plan.

[0000833444-23-000048:notes:275]
The following table summarizes stock-based compensation related charges and benefits (in millions):

[0000833444-23-000048:notes:276]
|  |  | Year Ended September 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Compensation expense |  | $ | 101 |  |  | $ | 104 |  |  | $ | 97 |  |
| Income tax benefit resulting from share-based compensation arrangements |  | 25 |  |  | 26 |  |  | 24 |  |
| Tax impact from exercise and vesting of equity settled awards |  | 7 |  |  | 12 |  |  | 12 |  |

[0000833444-23-000048:notes:277]
Compensation expense is recorded in selling, general and administrative expenses. The Company does not settle stock options granted under share-based payment arrangements in cash.

[0000833444-23-000048:notes:278]
Restricted (Non-vested) Stock / Units

[0000833444-23-000048:notes:279]
A summary of non-vested restricted stock awards at September 30, 2023, and changes for the year then ended, is presented below:

[0000833444-23-000048:notes:280]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toRestriction |
| Non-vested, September 30, 2022 | $ | 58.78 |  |  | 2,949,194 |  |
| Granted | 65.72 |  |  | 2,010,495 |  |
| Vested | 53.55 |  |  | (1,487,685) |  |
| Forfeited | 64.14 |  |  | (664,891) |  |
| Non-vested, September 30, 2023 | $ | 64.90 |  |  | 2,807,113 |  |

[0000833444-23-000048:notes:281]
At September 30, 2023, the Company had approximately $113 million of total unrecognized compensation cost related to non-vested restricted stock arrangements granted which is expected to be recognized over a weighted-average period of 1.9 years.

[0000833444-23-000048:notes:282]
Performance Share Awards (PSU's)

[0000833444-23-000048:notes:283]
The following table summarizes the assumptions used in determining the fair value of stock options granted:

[0000833444-23-000048:notes:284]
|  | Year Ended September 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Risk-free interest rate | 4.04% |  | 0.99% |  | 0.20% |
| Expected volatility of the Company’s stock | 33.50% |  | 30.00% |  | 30.90% |

[0000833444-23-000048:notes:285]
A summary of the status of the Company’s non-vested PSU's at September 30, 2023, and changes for the year then ended, is presented below:

[0000833444-23-000048:notes:286]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toPSU |
| Non-vested, September 30, 2022 | $ | 60.30 |  |  | 1,143,071 |  |
| Granted | 79.45 |  |  | 344,029 |  |
| Vested | 43.19 |  |  | (361,117) |  |
| Forfeited | 71.18 |  |  | (258,459) |  |
| Non-vested, September 30, 2023 | $ | 71.77 |  |  | 867,524 |  |

[0000833444-23-000048:notes:287]
At September 30, 2023, the Company had approximately $32 million of total unrecognized compensation cost related to non-vested performance-based share unit awards which is expected to be recognized over a weighted-average period of 1.9 years.

[0000833444-23-000048:notes:288]
|  | Year Ended September 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Expected life of option (years) | 5.8 |  | 6.0 |  | 6.5 |
| Risk-free interest rate | 3.59% |  | 1.35% |  | 0.60% |
| Expected volatility of the Company’s stock | 29.40% |  | 27.80% |  | 27.60% |
| Expected dividend yield on the Company’s stock | 2.10% |  | 1.71% |  | 2.28% |

[0000833444-23-000048:notes:289]
A summary of stock option activity at September 30, 2023, and changes for the year then ended, is presented below:

[0000833444-23-000048:notes:290]
|  | WeightedAverageOption Price |  | SharesSubject toOption |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2022 | $ | 42.46 |  |  | 5,683,847 |  |  |  |  |  |
| Granted | 66.77 |  |  | 570,140 |  |  |  |  |  |
| Exercised | 38.17 |  |  | (1,068,612) |  |  |  |  |  |
| Forfeited or expired | 59.31 |  |  | (265,459) |  |  |  |  |  |
| Outstanding, September 30, 2023 | $ | 45.44 |  |  | 4,919,916 |  |  | 5.75 |  | $ | 56 |  |
| Exercisable, September 30, 2023 | $ | 39.11 |  |  | 3,762,092 |  |  | 3.83 |  | $ | 53 |  |

[0000833444-23-000048:notes:291]
The following table summarizes additional stock option information:

[0000833444-23-000048:notes:292]
|  |  | Year Ended September 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Weighted-average grant-date fair value of options granted |  | $ | 18.21 |  |  | $ | 18.59 |  |  | $ | 9.36 |  |
| Intrinsic value of options exercised (in millions) |  | 27 |  |  | 19 |  |  | 94 |  |

[0000833444-23-000048:notes:293]
At September 30, 2023, the Company had approximately $10 million of total unrecognized compensation cost related to non-vested stock options which is expected to be recognized over a weighted-average period of 1.6 years.


## us-gaap:EarningsPerShareTextBlock

[0000833444-23-000048:notes:294]
EARNINGS PER SHARE
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-23-000048:notes:295]
|  | Year Ended September 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Income Available to Ordinary Shareholders |  |  |  |  |  |
| Income from continuing operations | $ | 1,849 |  |  | $ | 1,532 |  |  | $ | 1,513 |  |
| Income from discontinued operations | — |  |  | — |  |  | 124 |  |
| Basic and diluted income available to shareholders | $ | 1,849 |  |  | $ | 1,532 |  |  | $ | 1,637 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |
| Basic weighted average shares outstanding | 684.3 |  |  | 696.1 |  |  | 716.6 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 3.1 |  |  | 3.5 |  |  | 4.5 |  |
| Diluted weighted average shares outstanding | 687.4 |  |  | 699.6 |  |  | 721.1 |  |
| Antidilutive Securities |  |  |  |  |  |
| Stock options and unvested restricted stock | 0.2 |  |  | 0.4 |  |  | — |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-23-000048:notes:296]
EQUITY
Dividends

[0000833444-23-000048:notes:297]
The authority to declare and pay dividends is vested in the Board of Directors. The timing, declaration and payment of future dividends to holders of the Company's ordinary shares is determined by the Company's Board of Directors and depends upon many factors, including the Company's financial condition and results of operations, the capital requirements of the Company's businesses, industry practice and any other relevant factors.

[0000833444-23-000048:notes:298]
Under Irish law, dividends may only be paid (and share repurchases and redemptions must generally be funded) out of "distributable reserves." The creation of distributable reserves was accomplished by way of a capital reduction, which the Irish High Court approved on December 18, 2014 and as acquired in conjunction with the Merger.

[0000833444-23-000048:notes:299]
Share Repurchase Program

[0000833444-23-000048:notes:300]
As of September 30, 2023, approximately $3.0 billion remained available under the share repurchase program which was approved by the Company's Board of Directors in March 2021. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice.

[0000833444-23-000048:notes:301]
Accumulated Other Comprehensive Income

[0000833444-23-000048:notes:302]
The following table includes changes in AOCI attributable to Johnson Controls (in millions, net of tax):

[0000833444-23-000048:notes:303]
|  | Year Ended September 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Foreign currency translation adjustments |  |  |  |  |  |
| Balance at beginning of period | $ | (901) |  |  | $ | (421) |  |  | $ | (778) |  |
| Aggregate adjustment for the period | (69) |  |  | (480) |  |  | 357 |  |
| Balance at end of period | (970) |  |  | (901) |  |  | (421) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |  |  |
| Balance at beginning of period | (11) |  |  | (17) |  |  | 2 |  |
| Current period changes in fair value | 19 |  |  | 20 |  |  | (3) |  |
| Reclassification to income (1) | 11 |  |  | (16) |  |  | (14) |  |
| Net tax impact | (4) |  |  | 2 |  |  | (2) |  |
| Balance at end of period | 15 |  |  | (11) |  |  | (17) |  |
| Pension and postretirement plans |  |  |  |  |  |
| Balance at beginning of period | 1 |  |  | 4 |  |  | — |  |
| Reclassification to income | (1) |  |  | (3) |  |  | (3) |  |
| Other changes | — |  |  | — |  |  | 8 |  |
| Net tax impact | — |  |  | — |  |  | (1) |  |
| Balance at end of period | — |  |  | 1 |  |  | 4 |  |
| Accumulated other comprehensive loss, end of period | $ | (955) |  |  | $ | (911) |  |  | $ | (434) |  |

[0000833444-23-000048:notes:304]
(1)   Refer to Note 11, "Derivative Instruments and Hedging Activities," of the notes to consolidated financial statements for disclosure of the line items in the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-23-000048:notes:305]
RETIREMENT PLANS
Pension Benefits

[0000833444-23-000048:notes:306]
The Company has non-contributory defined benefit pension plans covering certain U.S. and non-U.S. employees. The benefits provided are primarily based on years of service and average compensation or a monthly retirement benefit amount. Certain of the Company’s U.S. pension plans no longer allow new participants to enter the plans and no longer accrue benefits. Funding for U.S. pension plans equals or exceeds the minimum requirements of the Employee Retirement Income Security Act of 1974. Funding for non-U.S. plans observes the local legal and regulatory limits. Also, the Company makes contributions to union-trusteed pension funds for construction and service personnel.

[0000833444-23-000048:notes:307]
The following table includes information for pension plans with accumulated benefit obligations ("ABO") in excess of plan assets (in millions):

[0000833444-23-000048:notes:308]
|  |  | September 30, |  |
|  |  | 2023 |  | 2022 |  |
| Accumulated benefit obligation |  | $ | 1,834 |  |  | $ | 2,004 |  |  |
| Fair value of plan assets |  | 1,618 |  |  | 1,720 |  |  |

[0000833444-23-000048:notes:309]
The following table includes information for pension plans with projected benefit obligations ("PBO") in excess of plan assets (in millions):

[0000833444-23-000048:notes:310]
|  |  | September 30, |  |
|  |  | 2023 |  | 2022 |  |
| Projected benefit obligation |  | $ | 1,846 |  |  | $ | 2,013 |  |  |
| Fair value of plan assets |  | 1,633 |  |  | 1,729 |  |  |

[0000833444-23-000048:notes:311]
The Company contributed $55 million to the defined benefit plans in fiscal 2023 and expects to contribute approximately $24 million in cash in fiscal 2024. None of contributions made by the Company were voluntary.

[0000833444-23-000048:notes:312]
Projected benefit payments from the plans as of September 30, 2023 are estimated as follows (in millions):

[0000833444-23-000048:notes:313]
| 2024 | $ | 277 |  |
| 2025 | 235 |  |
| 2026 | 235 |  |
| 2027 | 233 |  |
| 2028 | 172 |  |
| 2029 - 2033 | 1,160 |  |

[0000833444-23-000048:notes:314]
Postretirement Benefits

[0000833444-23-000048:notes:315]
The Company provides certain health care and life insurance benefits for eligible retirees and their dependents primarily in the U.S. and Canada. Most non-U.S. employees are covered by government sponsored programs. The cost to the Company is not significant.

[0000833444-23-000048:notes:316]
Eligibility for coverage is based on meeting certain years of service and retirement age qualifications. These benefits may be subject to deductibles, co-payment provisions and other limitations. The Company has reserved the right to modify these benefits.

[0000833444-23-000048:notes:317]
The health care cost trend assumption does not have a significant effect on the amounts reported.

[0000833444-23-000048:notes:318]
The following table includes information for postretirement plans with accumulated postretirement benefit obligations ("APBO") in excess of plan assets (in millions):

[0000833444-23-000048:notes:319]
|  |  | September 30, |  |
|  |  | 2023 |  | 2022 |  |
| Accumulated postretirement benefit obligation |  | $ | 58 |  |  | $ | 68 |  |  |
| Fair value of plan assets |  | 24 |  |  | 28 |  |  |

[0000833444-23-000048:notes:320]
The Company contributed $2 million to the postretirement benefit plans in fiscal 2023 and expects to contribute approximately $2 million in cash in fiscal 2024.

[0000833444-23-000048:notes:321]
| 2024 | $ | 10 |  |
| 2025 | 10 |  |
| 2026 | 9 |  |
| 2027 | 9 |  |
| 2028 | 7 |  |
| 2029 - 2033 | 27 |  |

[0000833444-23-000048:notes:322]
Defined Contribution Plans

[0000833444-23-000048:notes:323]
The Company sponsors various defined contribution savings plans that allow employees to contribute a portion of their pre-tax and/or after-tax income in accordance with plan specified guidelines. Under specified conditions, the Company will contribute to certain savings plans based on predetermined percentages of compensation earned by the employee and/or will match a percentage of the employee contributions up to certain limits. Defined contribution plan contributions charged to expense amounted to $209 million, $196 million and $118 million during the years ended September 30, 2023, 2022 and 2021, respectively. The Company temporarily suspended certain contributions in fiscal 2021 in response to the COVID-19 pandemic.

[0000833444-23-000048:notes:324]
Multiemployer Benefit Plans

[0000833444-23-000048:notes:325]
The Company contributes to multiemployer benefit plans based on obligations arising from collective bargaining agreements related to certain of its hourly employees in the U.S. These plans provide retirement benefits to participants based on their service to contributing employers. The benefits are paid from assets held in trust for that purpose. The trustees typically are responsible for determining the level of benefits to be provided to participants as well as for such matters as the investment of the assets and the administration of the plans.

[0000833444-23-000048:notes:326]
The risks of participating in these multiemployer benefit plans are different from single-employer benefit plans in the following aspects:

[0000833444-23-000048:notes:327]
•Assets contributed to the multiemployer benefit plan by one employer may be used to provide benefits to employees of other participating employers.

[0000833444-23-000048:notes:328]
•If a participating employer stops contributing to the multiemployer benefit plan, the unfunded obligations of the plan may be borne by the remaining participating employers.

[0000833444-23-000048:notes:329]
•If the Company stops participating in some of its multiemployer benefit plans, it may be required to pay those plans an amount based on its allocable share of the underfunded status of the plan, referred to as a withdrawal liability.

[0000833444-23-000048:notes:330]
The Company participates in approximately 260 multiemployer benefit plans, none of which are individually significant to the Company. The number of employees covered by the Company’s multiemployer benefit plans has remained consistent over the past three years, and there have been no significant changes that affect the comparability of fiscal 2023, 2022 and 2021 contributions. The Company recognizes expense for the contractually-required contribution for each period. The Company contributed $67 million, $71 million and $67 million to multiemployer benefit plans during the years ended September 30, 2023, 2022 and 2021, respectively.

[0000833444-23-000048:notes:331]
Based on the most recent information available, the Company believes that the present value of actuarial accrued liabilities in certain of these multiemployer benefit plans may exceed the value of the assets held in trust to pay benefits. Currently, the Company is not aware of any significant multiemployer benefit plans for which it is probable or reasonably possible that the Company will be obligated to make up any shortfall in funds. Moreover, if the Company were to exit certain markets or otherwise cease making contributions to these funds, the Company could trigger a withdrawal liability. Currently, the Company is not aware of any multiemployer benefit plans for which it is probable or reasonably possible that the Company will have a significant withdrawal liability. Any accrual for a shortfall or withdrawal liability will be recorded when it is probable that a liability exists and it can be reasonably estimated.

[0000833444-23-000048:notes:332]
Plan Assets

[0000833444-23-000048:notes:333]
The Company’s investment policies employ an approach whereby a mix of equities, fixed income and alternative investments are used to maximize the long-term return of plan assets for a prudent level of risk. The investment portfolio primarily contains a diversified blend of equity and fixed income investments. Equity investments are diversified across U.S. and non-U.S. stocks, as well as growth, value and small to large capitalization. Fixed income investments include corporate and government issues, with short-, mid- and long-term maturities, with a focus on investment grade when purchased and a target duration close to that of the plan liability. Investment and market risks are measured and monitored on an ongoing basis through regular investment portfolio reviews, annual liability measurements and periodic asset/liability studies. The majority of the real estate component of the portfolio is invested in a diversified portfolio of high-quality, operating properties with cash yields greater than the targeted appreciation. Investments in other alternative asset classes, including hedge funds, diversify the expected investment returns relative to the equity and fixed income investments. As a result of the Company's diversification strategies, there are no significant concentrations of risk within the portfolio of investments.

[0000833444-23-000048:notes:334]
The Company’s actual asset allocations are in line with target allocations. The Company rebalances asset allocations as appropriate, in order to stay within a range of allocation for each asset category.

[0000833444-23-000048:notes:335]
The expected return on plan assets is based on the Company’s expectation of the long-term average rate of return of the capital markets in which the plans invest. The average market returns are adjusted, where appropriate, for active asset management returns. The expected return reflects the investment policy target asset mix and considers the historical returns earned for each asset category.

[0000833444-23-000048:notes:336]
The Company’s plan assets at September 30, 2023 and 2022, by asset category, are as follows (in millions):

[0000833444-23-000048:notes:337]
|  |  | Fair Value Measurements Using: |
| Asset Category |  | Total as of September 30, 2023 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 61 |  |  | $ | — |  |  | $ | 61 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Large-Cap |  | 60 |  |  | 60 |  |  | — |  |  | — |  |
| Small-Cap |  | 65 |  |  | 65 |  |  | — |  |  | — |  |
| International - Developed |  | 108 |  |  | 108 |  |  | — |  |  | — |  |
| International - Emerging |  | 20 |  |  | 20 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 225 |  |  | 225 |  |  | — |  |  | — |  |
| Corporate/Other |  | 583 |  |  | 583 |  |  | — |  |  | — |  |
| Alternative |  | 211 |  |  | — |  |  | 211 |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 1,333 |  |  | $ | 1,061 |  |  | $ | 272 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value(1) |  | 295 |  |  |  |  |  |  |  |
| Due to Broker |  | (129) |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 1,499 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 52 |  |  | $ | 52 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Large-Cap |  | 52 |  |  | 9 |  |  | 43 |  |  | — |  |
| International - Developed |  | 52 |  |  | 12 |  |  | 40 |  |  | — |  |
| International - Emerging |  | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 701 |  |  | 40 |  |  | 661 |  |  | — |  |
| Corporate/Other |  | 415 |  |  | 271 |  |  | 144 |  |  | — |  |
| Hedge Fund |  | 15 |  |  | — |  |  | 15 |  |  | — |  |
| Real Estate |  | 9 |  |  | 9 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 1,298 |  |  | $ | 393 |  |  | $ | 905 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value(1) |  | 90 |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 1,388 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 8 |  |  | $ | 8 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities - Global |  | 71 |  |  | — |  |  | 71 |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 79 |  |  | $ | 8 |  |  | $ | 71 |  |  | $ | — |  |
| Multi-Credit Strategy Investments Measured at Net Asset Value(1) |  | 65 |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 144 |  |  |  |  |  |  |  |

[0000833444-23-000048:notes:338]
|  |  | Fair Value Measurements Using: |
| Asset Category |  | Total as of September 30, 2022 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 40 |  |  | $ | — |  |  | $ | 40 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Large-Cap |  | 160 |  |  | 160 |  |  | — |  |  | — |  |
| Small-Cap |  | 175 |  |  | 175 |  |  | — |  |  | — |  |
| International - Developed |  | 139 |  |  | 139 |  |  | — |  |  | — |  |
| International - Emerging |  | 39 |  |  | 39 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 217 |  |  | 216 |  |  | 1 |  |  | — |  |
| Corporate/Other |  | 804 |  |  | 804 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 1,574 |  |  | $ | 1,533 |  |  | $ | 41 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value(1) |  | 322 |  |  |  |  |  |  |  |
| Due to Broker |  | (166) |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 1,730 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 150 |  |  | $ | 150 |  |  | $ | — |  |  | $ | — |  |
| Large-Cap |  | 45 |  |  | 8 |  |  | 37 |  |  | — |  |
| International - Developed |  | 43 |  |  | 12 |  |  | 31 |  |  | — |  |
| International - Emerging |  | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 650 |  |  | 50 |  |  | 600 |  |  | — |  |
| Corporate/Other |  | 418 |  |  | 277 |  |  | 141 |  |  | — |  |
| Hedge Fund |  | 18 |  |  | — |  |  | 18 |  |  | — |  |
| Real Estate |  | 9 |  |  | 9 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 1,336 |  |  | $ | 506 |  |  | $ | 830 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value(1) |  | 97 |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 1,433 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 13 |  |  | $ | 13 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Global |  | 66 |  |  | — |  |  | 66 |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 79 |  |  | 13 |  |  | 66 |  |  | — |  |
| Multi-Credit Strategy Investments Measured at Net Asset Value(1) |  | 65 |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 144 |  |  |  |  |  |  |  |

[0000833444-23-000048:notes:339]
(1)The fair value of certain real estate and multi-credit strategy investments do not have a readily determinable fair value and require the fund managers to independently arrive at fair value by calculating net asset value ("NAV") per share. In order to calculate NAV per share, the fund managers value the investments using any one, or a combination of, the following methods: independent third party appraisals, discounted cash flow analysis of net cash flows projected to be generated by the investment and recent sales of comparable investments. Assumptions used to revalue the investments are updated every quarter. Due to the fact that the fund managers calculate NAV per share, the Company utilizes a practical expedient for measuring the fair value of its real estate and multi-credit strategy investments, as provided for under ASC 820, "Fair Value Measurement." In applying the

[0000833444-23-000048:notes:340]
practical expedient, the Company is not required to further adjust the NAV provided by the fund manager in order to determine the fair value of its investments as the NAV per share is calculated in a manner consistent with the measurement principles of ASC 946, "Financial Services - Investment Companies," and as of the Company's measurement date. The Company believes this is an appropriate methodology to obtain the fair value of these assets. For the component of the real estate portfolio under development, the investments are carried at cost until they are completed and valued by a third party appraiser. In accordance with ASU No. 2015-07, "Disclosures for Investments in Certain Entities That Calculate Net Asset Value per Share (or Its Equivalent)," investments for which fair value is measured using the net asset value per share practical expedient are disclosed separate from the fair value hierarchy. The fair value amounts presented in these tables are intended to permit reconciliation of total plan assets to the amounts presented in the notes to consolidated financial statements.

[0000833444-23-000048:notes:341]
The following is a description of the valuation methodologies used for assets measured at fair value. Certain assets are held within commingled funds which are valued at the unitized NAV or percentage of the net asset value as determined by the manager of the fund. These values are based on the fair value of the underlying net assets owned by the fund.

[0000833444-23-000048:notes:342]
Cash and Cash Equivalents: The fair value of cash and cash equivalents is valued at cost.

[0000833444-23-000048:notes:343]
Equity Securities: The fair value of equity securities is determined by direct quoted market prices. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-23-000048:notes:344]
Fixed Income Securities: The fair value of fixed income securities is determined by direct or indirect quoted market prices. If indirect quoted market prices are utilized, the value of assets held in separate accounts is not published, but the investment managers report daily the underlying holdings. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-23-000048:notes:345]
Hedge Funds: The fair value of hedge funds is accounted for by the custodian. The custodian obtains valuations from underlying managers based on market quotes for the most liquid assets and alternative methods for assets that do not have sufficient trading activity to derive prices. The Company and custodian review the methods used by the underlying managers to value the assets. The Company believes this is an appropriate methodology to obtain the fair value of these assets.

[0000833444-23-000048:notes:346]
Real Estate: The fair value of real estate is determined by quoted market prices of the underlying Real Estate Investment Trusts

[0000833444-23-000048:notes:347]
("REITs"), which are securities traded on an open exchange.

[0000833444-23-000048:notes:348]
The methods described above may produce a fair value calculation that may not be indicative of net realizable value or reflective of future fair values. Furthermore, while the Company believes its valuation methods are appropriate and consistent with other market participants, the use of different methodologies or assumptions to determine the fair value of certain financial instruments could result in a different fair value measurement at the reporting date.

[0000833444-23-000048:notes:349]
Funded Status

[0000833444-23-000048:notes:350]
The following table contains the ABO and reconciliations of the changes in the PBO, the changes in plan assets and the funded status (in millions):

[0000833444-23-000048:notes:351]
|  | Pension Benefits |  | PostretirementBenefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| September 30, | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Accumulated Benefit Obligation | $ | 1,564 |  |  | $ | 1,822 |  |  | $ | 1,424 |  |  | $ | 1,417 |  |  | $ | 76 |  |  | $ | 89 |  |
| Change in Projected Benefit Obligation |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of year | $ | 1,822 |  |  | $ | 2,629 |  |  | $ | 1,471 |  |  | $ | 2,625 |  |  | $ | 89 |  |  | $ | 123 |  |
| Service cost | — |  |  | — |  |  | 16 |  |  | 20 |  |  | — |  |  | 1 |  |
| Interest cost | 78 |  |  | 56 |  |  | 68 |  |  | 39 |  |  | 4 |  |  | 2 |  |
| Plan participant contributions | — |  |  | — |  |  | 3 |  |  | 2 |  |  | 3 |  |  | 3 |  |
| Actuarial gain | (37) |  |  | (587) |  |  | (62) |  |  | (651) |  |  | (7) |  |  | (25) |  |
| Benefits and settlements paid | (299) |  |  | (276) |  |  | (126) |  |  | (166) |  |  | (12) |  |  | (14) |  |
| Other | — |  |  | — |  |  | (3) |  |  | (3) |  |  | — |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | 106 |  |  | (395) |  |  | — |  |  | (1) |  |
| Projected benefit obligation at end of year | $ | 1,564 |  |  | $ | 1,822 |  |  | $ | 1,473 |  |  | $ | 1,471 |  |  | $ | 77 |  |  | $ | 89 |  |
| Change in Plan Assets |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 1,730 |  |  | $ | 2,459 |  |  | $ | 1,433 |  |  | $ | 2,344 |  |  | $ | 144 |  |  | $ | 172 |  |
| Actual return on plan assets | 66 |  |  | (454) |  |  | (77) |  |  | (459) |  |  | 7 |  |  | (20) |  |
| Employer and employee contributions | 3 |  |  | 1 |  |  | 55 |  |  | 94 |  |  | 5 |  |  | 6 |  |
| Benefits paid | (85) |  |  | (85) |  |  | (61) |  |  | (74) |  |  | (12) |  |  | (14) |  |
| Settlement payments | (215) |  |  | (191) |  |  | (65) |  |  | (92) |  |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | (2) |  |  | (2) |  |  | — |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | 105 |  |  | (378) |  |  | — |  |  | — |  |
| Fair value of plan assets at end of year | $ | 1,499 |  |  | $ | 1,730 |  |  | $ | 1,388 |  |  | $ | 1,433 |  |  | $ | 144 |  |  | $ | 144 |  |
| Funded status | $ | (65) |  |  | $ | (92) |  |  | $ | (85) |  |  | $ | (38) |  |  | $ | 67 |  |  | $ | 55 |  |
| Amounts recognized in the statement of financial position consist of: |
| Prepaid benefit cost | $ | 1 |  |  | $ | 37 |  |  | $ | 97 |  |  | $ | 151 |  |  | $ | 101 |  |  | $ | 95 |  |
| Accrued benefit liability | (66) |  |  | (129) |  |  | (182) |  |  | (189) |  |  | (34) |  |  | (40) |  |
| Net amount recognized | $ | (65) |  |  | $ | (92) |  |  | $ | (85) |  |  | $ | (38) |  |  | $ | 67 |  |  | $ | 55 |  |
| Weighted Average Assumptions (1) |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate (2) | 5.48 | % |  | 5.08 | % |  | 4.72 | % |  | 4.36 | % |  | 5.42 | % |  | 4.92 | % |
| Rate of compensation increase | N/A |  | N/A |  | 2.90 | % |  | 3.00 | % |  | N/A |  | N/A |
| Interest crediting rate | N/A |  | N/A |  | 1.63 | % |  | 1.69 | % |  | N/A |  | N/A |

[0000833444-23-000048:notes:352]
(1)Plan assets and obligations are determined based on a September 30 measurement date at September 30, 2023 and 2022.

[0000833444-23-000048:notes:353]
(2) The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension and postretirement plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for determining the various discount rates. The Company has elected to utilize a full yield curve approach in the estimation of service and interest components of net periodic benefit cost (credit) for pension and other postretirement for plans that utilize a

[0000833444-23-000048:notes:354]
yield curve approach. The full yield curve approach applies the specific spot rates along the yield curve used in the determination of the benefit obligation to the relevant projected cash flows.

[0000833444-23-000048:notes:355]
The fiscal 2023 and fiscal 2022 net actuarial gains related to changes in the projected benefit obligation were primarily the result of the increase in discount rates globally.

[0000833444-23-000048:notes:356]
Net Periodic Benefit Cost

[0000833444-23-000048:notes:357]
The following table contains the components of net periodic benefit costs, which are recorded in selling, general and administrative expenses or cost of sales consistent with the related employees' salaries in the consolidated statements of income (in millions):

[0000833444-23-000048:notes:358]
|  | Pension Benefits |  | Postretirement Benefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| Year ended September 30, | 2023 |  | 2022 |  | 2021 |  | 2023 |  | 2022 |  | 2021 |  | 2023 |  | 2022 |  | 2021 |
| Components of Net Periodic Benefit Cost (Credit): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 16 |  |  | $ | 20 |  |  | $ | 27 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest cost | 78 |  |  | 56 |  |  | 47 |  |  | 68 |  |  | 39 |  |  | 32 |  |  | 4 |  |  | 2 |  |  | 2 |  |
| Expected return on plan assets | (131) |  |  | (150) |  |  | (171) |  |  | (77) |  |  | (81) |  |  | (112) |  |  | (9) |  |  | (9) |  |  | (8) |  |
| Net actuarial (gain) loss | 28 |  |  | 16 |  |  | (214) |  |  | 86 |  |  | (116) |  |  | (115) |  |  | (5) |  |  | 4 |  |  | (35) |  |
| Settlement (gain) loss | 1 |  |  | 1 |  |  | — |  |  | 6 |  |  | 5 |  |  | (1) |  |  | — |  |  | — |  |  | — |  |
| Amortization of prior service cost (credit) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | (4) |  |  | (4) |  |  | (4) |  |
| Other | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (1) |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (credit) included in continuing operations | $ | (24) |  |  | $ | (77) |  |  | $ | (338) |  |  | $ | 99 |  |  | $ | (133) |  |  | $ | (169) |  |  | $ | (14) |  |  | $ | (6) |  |  | $ | (44) |  |
| Expense Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 5.08 | % |  | 2.52 | % |  | 2.25 | % |  | 4.36 | % |  | 1.79 | % |  | 1.35 | % |  | 4.92 | % |  | 2.30 | % |  | 1.90 | % |
| Expected return on plan assets | 8.25 | % |  | 7.00 | % |  | 6.90 | % |  | 5.02 | % |  | 3.70 | % |  | 4.90 | % |  | 6.64 | % |  | 5.29 | % |  | 5.30 | % |
| Rate of compensation increase | N/A |  | N/A |  | N/A |  | 3.00 | % |  | 2.85 | % |  | 2.75 | % |  | N/A |  | N/A |  | N/A |
| Interest crediting rate | N/A |  | N/A |  | N/A |  | 1.69 | % |  | 1.44 | % |  | 1.50 | % |  | N/A |  | N/A |  | N/A |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-23-000048:notes:359]
RESTRUCTURING AND RELATED COSTS
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to restructuring plans as necessary. Restructuring activities generally result in charges for workforce reductions, plant closures, asset impairments and other related costs which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The Company expects the restructuring actions to reduce cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-23-000048:notes:360]
In the third quarter of fiscal 2023, the Company began developing a restructuring plan with certain actions focused on continued scaling of SG&A expenses to its planned growth. The scope of the plan was substantially finalized in the fourth quarter of fiscal 2023 and certain actions related to this plan were committed and executed during the fourth quarter, primarily related to workforce reductions, and were recorded to restructuring and impairment costs in the consolidated statements of income. Additional restructuring charges are expected in subsequent quarters. Restructuring charges incurred during the first and second quarters of fiscal 2023 were the result of other segment and Corporate-level restructuring plans.

[0000833444-23-000048:notes:361]
Refer to Note 3, "Assets and Liabilities Held for Sale & Discontinued Operations," Note 7, "Property, Plant and Equipment," and Note 8, "Goodwill and Other Intangible Assets," of the notes to the consolidated financial statements for disclosure of other impairment costs.

[0000833444-23-000048:notes:362]
The following table summarizes restructuring and related costs (in millions):

[0000833444-23-000048:notes:363]
|  |  |  | Year Ended September 30, 2023 |  |  |
| Building Solutions North America |  |  | $ | 43 |  |  |  |
| Building Solutions EMEA/LA |  |  | 97 |  |  |  |
| Building Solutions Asia Pacific |  |  | 18 |  |  |  |
| Global Products |  |  | 69 |  |  |  |
| Corporate |  |  | 49 |  |  |  |
| Total |  |  | $ | 276 |  |  |  |

[0000833444-23-000048:notes:364]
The following table summarizes changes in the restructuring reserve, which is included within other current liabilities in the consolidated statements of financial position, for new restructuring actions taken in the year ended September 30, 2023 (in millions):

[0000833444-23-000048:notes:365]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Restructuring and related costs | 204 |  | 38 |  |  | 34 |  |  | 276 |  |
| Utilized—cash | (111) |  |  | — |  |  | (19) |  |  | (130) |  |
| Utilized—noncash | — |  |  | (38) |  |  | (3) |  |  | (41) |  |
| Balance at September 30, 2023 | $ | 93 |  |  | $ | — |  |  | $ | 12 |  |  | $ | 105 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-23-000048:notes:366]
INCOME TAXES
The more significant components of the Company’s income tax provision from continuing operations are as follows (in millions):

[0000833444-23-000048:notes:367]
|  | 2023 |  | 2022 |  | 2021 |
| Tax expense at Ireland statutory rate of 12.5% | $ | 214 |  |  | $ | 214 |  |  | $ | 327 |  |
| U.S. state income tax, net of federal benefit | 39 |  |  | (23) |  |  | 34 |  |
| Income subject to the U.S. federal tax rate | 56 |  |  | (95) |  |  | 3 |  |
| Income subject to rates different than the statutory rate | 92 |  |  | 125 |  |  | 30 |  |
| Reserve and valuation allowance adjustments | (559) |  |  | (274) |  |  | 66 |  |
| Intellectual property transactions and adjustments | (176) |  |  | — |  |  | 417 |  |
| Restructuring and impairment costs | 11 |  |  | 40 |  |  | (9) |  |
| Income tax provision (benefit) | $ | (323) |  |  | $ | (13) |  |  | $ | 868 |  |
| Effective tax rate | (19) | % |  | (1)% |  | 33% |

[0000833444-23-000048:notes:368]
For fiscal 2023, the effective tax rate for continuing operations was (19)% and was lower than the statutory tax rate primarily due to the favorable tax impacts of intellectual property tax adjustments, tax reserve adjustments as the result of tax audit resolutions and remeasurements, valuation allowance adjustments and the benefits of continuing global tax planning initiatives, partially offset by the unfavorable impact of impairment and restructuring charges.

[0000833444-23-000048:notes:369]
For fiscal 2022, the effective tax rate for continuing operations was (1)% and was lower than the statutory tax rate primarily due to favorable impact of tax reserve adjustments as the result of expired statute of limitations for certain tax years and the benefits of continuing global tax planning initiatives, partially offset by the unfavorable impact of impairment and restructuring charges, valuation allowance adjustments, and the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestitures and tax rate differentials.

[0000833444-23-000048:notes:370]
For fiscal 2021, the effective tax rate for continuing operations was 33% and was higher than the statutory tax rate primarily due to the unfavorable impact of tax impacts of an intercompany transfer of certain of the Company’s intellectual property rights, valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives.

[0000833444-23-000048:notes:371]
Valuation Allowances

[0000833444-23-000048:notes:372]
The Company reviews the realizability of its deferred tax assets and related valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-23-000048:notes:373]
In fiscal 2023, due to changes in forecasted taxable income, the Company determined that it was more likely than not that certain deferred tax assets of Canada, Mexico, and Spain would be realized. The valuation allowance adjustment resulted in a tax benefit of $121 million.

[0000833444-23-000048:notes:374]
In fiscal 2022, due to changes in forecasted taxable income, the Company determined that it was more likely than not that certain deferred tax assets of Japan would not be realized. The valuation allowance adjustment resulted in a tax charge of $27 million.

[0000833444-23-000048:notes:375]
In fiscal 2021, as a result of an intercompany transfer of certain of the Company’s intellectual property rights, the Company determined that it was more likely than not that certain deferred tax assets of Switzerland would be realized and certain deferred tax assets of Canada would not be realized. The valuation allowance adjustments resulted in a $39 million net benefit to income tax expense. Due to changes in forecasted taxable income, the Company also recorded a discrete tax charge of $105 million related to valuation allowances on certain Mexico deferred tax assets which were considered unrealizable.

[0000833444-23-000048:notes:376]
The following table summarizes changes in the valuation allowance (in millions):

[0000833444-23-000048:notes:377]
|  | Year Ended September 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Balance at beginning of period | $ | 5,973 |  |  | $ | 5,853 |  |  | $ | 5,518 |  |
| Allowance provision for new operating and other loss carryforwards | 573 |  |  | 325 |  |  | 505 |  |
| Allowance benefits | (168) |  |  | (205) |  |  | (170) |  |
| Balance at end of period | $ | 6,378 |  |  | $ | 5,973 |  |  | $ | 5,853 |  |

[0000833444-23-000048:notes:378]
Uncertain Tax Positions

[0000833444-23-000048:notes:379]
The Company is subject to income taxes in the U.S. and numerous non-U.S. jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-23-000048:notes:380]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0000833444-23-000048:notes:381]
|  | 2023 |  | 2022 |  | 2021 |
| Beginning balance, October 1 | $ | 2,537 |  |  | $ | 2,726 |  |  | $ | 2,528 |  |
| Additions for tax positions related to the current year | 72 |  |  | 169 |  |  | 240 |  |
| Additions for tax positions of prior years | 96 |  |  | 31 |  |  | 33 |  |
| Reductions for tax positions of prior years | (27) |  |  | (48) |  |  | (6) |  |
| Settlements with taxing authorities | (6) |  |  | (7) |  |  | (24) |  |
| Statute closings and audit resolutions | (446) |  |  | (334) |  |  | (45) |  |
| Ending balance, September 30 | $ | 2,226 |  |  | $ | 2,537 |  |  | $ | 2,726 |  |

[0000833444-23-000048:notes:382]
The following table summarizes tax effected unrecognized tax benefits that, if recognized, would impact the effective tax rate and the related accrued interest, net of tax benefit (in millions):

[0000833444-23-000048:notes:383]
|  | September 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Tax effected unrecognized tax benefits that, if recognized, would affect the effective tax rate | $ | 1,581 |  |  | $ | 1,973 |  |  | $ | 2,268 |  |
| Net accrued interest | 335 |  |  | 284 |  |  | 252 |  |

[0000833444-23-000048:notes:384]
In fiscal 2023, as the result of tax audit resolutions, statute expirations, and remeasurements of ongoing controversy matters in various jurisdictions, the Company adjusted its reserve for uncertain tax positions which resulted in a $438 million net benefit to income tax expense.

[0000833444-23-000048:notes:385]
In fiscal 2022, the statute of limitations for certain tax years expired, which resulted in a $301 million benefit to income tax expense.

[0000833444-23-000048:notes:386]
In the U.S., fiscal years 2017 through 2018 are currently under appeal by the Internal Revenue Service (“IRS”) for certain legal entities. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions for continuing operations:

[0000833444-23-000048:notes:387]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2022 |
| Germany |  | 2007 - 2021 |
| Luxembourg |  | 2017 - 2018 |
| Mexico |  | 2015 - 2018 |
| United Kingdom |  | 2014 - 2015; 2018; 2020 - 2021 |

[0000833444-23-000048:notes:388]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-23-000048:notes:389]
Other Tax Matters

[0000833444-23-000048:notes:390]
During fiscal 2023, 2022 and 2021, the Company incurred charges for restructuring and impairment costs of $1,064 million, $721 million and $242 million, which generated tax benefits of $122 million, $50 million and $39 million, respectively.

[0000833444-23-000048:notes:391]
In fiscal 2021, the Company completed an intercompany transfer of certain of the Company’s intellectual property rights which resulted in a net tax charge of $417 million.

[0000833444-23-000048:notes:392]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-23-000048:notes:393]
On September 11, 2023, the Schaffhausen parliament approved a partial revision of the cantonal act on direct taxation: Immediate Minimum Taxation Measure (“IMTM”). The IMTM increases Switzerland’s combined statutory income tax rate to approximately 15%. On November 19, 2023, IMTM was approved in a public referendum in the canton of Schaffhausen, was published in the cantonal official gazette on December 8,2023, and is effective starting January 1, 2024. The Company is still evaluating the impact on its deferred tax assets in the canton of Schaffhausen, however the revaluation of these assets could have a noncash impact of less than $100 million to its consolidated financial statements.

[0000833444-23-000048:notes:394]
On August 16, 2022, the U.S. enacted the Inflation Reduction Act (“IRA”) which, among other things, creates a new book minimum tax of at least 15% of consolidated GAAP pre-tax income for corporations with average book income in excess of $1 billion. The book minimum tax is first applicable in fiscal year 2024. The Company does not expect this provision to have a material impact on its effective tax rate.

[0000833444-23-000048:notes:395]
During the fiscal years ended 2023, 2022 and 2021, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-23-000048:notes:396]
Selected Income Tax Data

[0000833444-23-000048:notes:397]
Selected income tax data related to continuing operations were as follows (in millions):

[0000833444-23-000048:notes:398]
|  | 2023 |  | 2022 |  | 2021 |
| Components of income (loss) from continuing operations before income taxes: |  |  |  |  |  |
| U.S. | $ | (130) |  |  | $ | 67 |  |  | $ | 543 |  |
| Non-U.S. | 1,840 |  |  | 1,643 |  |  | 2,071 |  |
| Income from continuing operations before income taxes | $ | 1,710 |  |  | $ | 1,710 |  |  | $ | 2,614 |  |
| Components of the provision (benefit) for income taxes: |  |  |  |  |  |
| Current |  |  |  |  |  |
| U.S. federal | $ | (165) |  |  | $ | (219) |  |  | $ | 459 |  |
| U.S. state | 105 |  |  | 53 |  |  | 108 |  |
| Non-U.S. | 413 |  |  | 294 |  |  | 265 |  |
|  | 353 |  |  | 128 |  |  | 832 |  |
| Deferred |  |  |  |  |  |
| U.S. federal | (267) |  |  | (175) |  |  | (7) |  |
| U.S. state | (25) |  |  | (69) |  |  | 46 |  |
| Non-U.S. | (384) |  |  | 103 |  |  | (3) |  |
|  | (676) |  |  | (141) |  |  | 36 |  |
| Income tax provision (benefit) | $ | (323) |  |  | $ | (13) |  |  | $ | 868 |  |
| Income taxes paid | $ | 430 |  |  | $ | 568 |  |  | $ | 504 |  |

[0000833444-23-000048:notes:399]
At September 30, 2023 and 2022, the Company recorded within the consolidated statements of financial position in other current assets approximately $65 million and $253 million, respectively, of income tax assets. At September 30, 2023 and 2022, the Company recorded within the consolidated statements of financial position in other current liabilities approximately $249 million and $143 million, respectively, of accrued income tax liabilities.

[0000833444-23-000048:notes:400]
The Company has not provided U.S. or non-U.S. income taxes on approximately $24.4 billion of outside basis differences of consolidated subsidiaries of Johnson Controls International plc. The Company is indefinitely reinvested in these basis differences. The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income. The Company's intent is to reduce the outside basis differences only when it would be tax efficient. Given the numerous ways in which the basis differences may be reduced, it is not practicable to estimate the amount of unrecognized withholding taxes and deferred tax liability on the outside basis differences.

[0000833444-23-000048:notes:401]
Deferred taxes were classified in the consolidated statements of financial position as follows (in millions):

[0000833444-23-000048:notes:402]
|  | September 30, |
|  | 2023 |  | 2022 |
| Other noncurrent assets | $ | 1,499 |  |  | $ | 954 |  |
| Other noncurrent liabilities | (411) |  |  | (503) |  |
| Net deferred tax asset | $ | 1,088 |  |  | $ | 451 |  |

[0000833444-23-000048:notes:403]
Temporary differences and carryforwards which gave rise to deferred tax assets and liabilities included (in millions):

[0000833444-23-000048:notes:404]
|  | September 30, |
|  | 2023 |  | 2022 |
| Deferred tax assets |  |  |  |
| Accrued expenses and reserves | $ | 507 |  |  | $ | 376 |  |
| Employee and retiree benefits | 71 |  |  | 78 |  |
| Property, plant and equipment | 629 |  |  | 444 |  |
| Net operating loss and other credit carryforwards | 6,748 |  |  | 6,488 |  |
| Research and development | 171 |  |  | 52 |  |
| Operating lease liabilities | 348 |  |  | 309 |  |
| Other, net | 38 |  |  | 58 |  |
|  | 8,512 |  |  | 7,805 |  |
| Valuation allowances | (6,378) |  |  | (5,973) |  |
|  | 2,134 |  |  | 1,832 |  |
| Deferred tax liabilities |  |  |  |
| Subsidiaries, joint ventures and partnerships | 446 |  |  | 338 |  |
| Intangible assets | 252 |  |  | 734 |  |
| Operating lease right-of-use assets | 348 |  |  | 309 |  |
|  | 1,046 |  |  | 1,381 |  |
| Net deferred tax asset | $ | 1,088 |  |  | $ | 451 |  |

[0000833444-23-000048:notes:405]
At September 30, 2023, the Company had available net operating loss carryforwards of approximately $24.4 billion, of which $14.1 billion will expire at various dates between 2024 and 2043, and the remainder has an indefinite carryforward period. The Company had available U.S. foreign tax credit carryforwards at September 30, 2023 of $35 million which will expire in 2029. The valuation allowance, generally, is for loss and credit carryforwards for which realization is uncertain because it is unlikely that the losses and/or credits will be realized given the lack of sustained profitability and/or limited carryforward periods in certain countries.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-23-000048:notes:406]
SEGMENT INFORMATION
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has four reportable segments for financial reporting purposes.

[0000833444-23-000048:notes:407]
The Company conducts its business through four business segments:

[0000833444-23-000048:notes:408]
•Building Solutions North America which operates in the United States and Canada;

[0000833444-23-000048:notes:409]
•Building Solutions EMEA/LA which operates in Europe, the Middle East, Africa and Latin America;

[0000833444-23-000048:notes:410]
•Building Solutions Asia Pacific which operates in Asia Pacific; and

[0000833444-23-000048:notes:411]
•Global Products which operates worldwide and includes the Johnson Controls-Hitachi joint venture.

[0000833444-23-000048:notes:412]
The Building Solutions segments:

[0000833444-23-000048:notes:413]
•Design, sell, install and service HVAC, controls, building management, refrigeration, integrated electronic security and integrated fire-detection and suppression systems; and

[0000833444-23-000048:notes:414]
•Provide energy-efficiency solutions and technical services, including data-driven "smart building" solutions as well as inspection, scheduled maintenance, and repair and replacement of mechanical and controls systems.

[0000833444-23-000048:notes:415]
The Global Products segment designs, manufactures and sells:

[0000833444-23-000048:notes:416]
•HVAC equipment, controls software and software services for residential and commercial applications;

[0000833444-23-000048:notes:417]
•Refrigeration equipment and controls;

[0000833444-23-000048:notes:418]
•Fire protection and suppression; and

[0000833444-23-000048:notes:419]
•Security products, including intrusion security, anti-theft devices, access control, and video surveillance and management systems.

[0000833444-23-000048:notes:420]
The Company’s segments provide products and services to commercial, institutional, industrial, data center, governmental and residential customers.

[0000833444-23-000048:notes:421]
Management evaluates the performance of its business segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-23-000048:notes:422]
Financial information relating to the Company’s reportable segments is as follows (in millions):

[0000833444-23-000048:notes:423]
|  | Year Ended September 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Net Sales |  |  |  |  |  |
| Building Solutions North America | $ | 10,330 |  |  | $ | 9,367 |  |  | $ | 8,685 |  |
| Building Solutions EMEA/LA | 4,096 |  |  | 3,845 |  |  | 3,884 |  |
| Building Solutions Asia Pacific | 2,746 |  |  | 2,714 |  |  | 2,616 |  |
| Global Products | 9,621 |  |  | 9,373 |  |  | 8,483 |  |
| Total net sales | $ | 26,793 |  |  | $ | 25,299 |  |  | $ | 23,668 |  |

[0000833444-23-000048:notes:424]
|  | Year Ended September 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Segment EBITA (1) |  |  |  |  |  |
| Building Solutions North America | $ | 1,394 |  |  | $ | 1,122 |  |  | $ | 1,204 |  |
| Building Solutions EMEA/LA | 316 |  |  | 358 |  |  | 401 |  |
| Building Solutions Asia Pacific | 343 |  |  | 332 |  |  | 344 |  |
| Global Products | 1,965 |  |  | 1,594 |  |  | 1,436 |  |
| Total segment EBITA | 4,018 |  |  | 3,406 |  |  | 3,385 |  |
| Amortization of intangible assets | (439) |  |  | (427) |  |  | (435) |  |
| Corporate expenses | (432) |  |  | (369) |  |  | (290) |  |
| Net financing charges | (281) |  |  | (213) |  |  | (206) |  |
| Restructuring and impairment costs | (1,064) |  |  | (721) |  |  | (242) |  |
| Net mark-to-market adjustments | (92) |  |  | 34 |  |  | 402 |  |
| Income from continuing operations before income taxes | $ | 1,710 |  |  | $ | 1,710 |  |  | $ | 2,614 |  |

[0000833444-23-000048:notes:425]
|  | September 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Assets (2) |  |  |  |  |  |
| Building Solutions North America | $ | 15,603 |  |  | $ | 15,226 |  |  | $ | 15,317 |  |
| Building Solutions EMEA/LA | 5,202 |  |  | 4,991 |  |  | 5,397 |  |
| Building Solutions Asia Pacific | 2,645 |  |  | 2,474 |  |  | 2,728 |  |
| Global Products | 15,406 |  |  | 15,185 |  |  | 15,227 |  |
|  | 38,856 |  |  | 37,876 |  |  | 38,669 |  |
| Assets held for sale | — |  |  | 66 |  |  | 156 |  |
| Unallocated | 3,386 |  |  | 4,216 |  |  | 3,065 |  |
| Total | $ | 42,242 |  |  | $ | 42,158 |  |  | $ | 41,890 |  |

[0000833444-23-000048:notes:426]
|  | Year Ended September 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Depreciation/Amortization |  |  |  |  |  |
| Building Solutions North America | $ | 225 |  |  | $ | 213 |  |  | $ | 245 |  |
| Building Solutions EMEA/LA | 101 |  |  | 96 |  |  | 103 |  |
| Building Solutions Asia Pacific | 23 |  |  | 21 |  |  | 25 |  |
| Global Products | 454 |  |  | 461 |  |  | 432 |  |
|  | 803 |  |  | 791 |  |  | 805 |  |
| Corporate | 45 |  |  | 39 |  |  | 40 |  |
| Total | $ | 848 |  |  | $ | 830 |  |  | $ | 845 |  |

[0000833444-23-000048:notes:427]
|  | Year Ended September 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Capital Expenditures |  |  |  |  |  |
| Building Solutions North America | $ | 104 |  |  | $ | 141 |  |  | $ | 87 |  |
| Building Solutions EMEA/LA | 119 |  |  | 119 |  |  | 128 |  |
| Building Solutions Asia Pacific | 33 |  |  | 22 |  |  | 31 |  |
| Global Products | 233 |  |  | 257 |  |  | 265 |  |
|  | 489 |  |  | 539 |  |  | 511 |  |
| Corporate | 50 |  |  | 53 |  |  | 41 |  |
| Total | $ | 539 |  |  | $ | 592 |  |  | $ | 552 |  |

[0000833444-23-000048:notes:428]
(1)For the years ended September 30, 2023, 2022 and 2021, segment EBITA includes $262 million, $240 million and $250 million, respectively, of equity income for the Global Products segment. Equity income for other segments is immaterial.

[0000833444-23-000048:notes:429]
(2)Building Solutions EMEA/LA assets as of September 30, 2023, 2022 and 2021 include $130 million, $115 million and $111 million, respectively, of investments in partially-owned affiliates. Global Products assets as of September 30, 2023, 2022 and 2021 include $905 million, $834 million and $945 million, respectively, of investments in partially-owned affiliates. Investments in partially-owned affiliates for other segments are immaterial.

[0000833444-23-000048:notes:430]
In fiscal 2023, 2022 and 2021, no customer exceeded 10% of consolidated net sales.

[0000833444-23-000048:notes:431]
Geographic Segments

[0000833444-23-000048:notes:432]
Financial information relating to the Company’s operations by geographic area is as follows (in millions):

[0000833444-23-000048:notes:433]
|  | Year Ended September 30, |
|  | 2023 |  | 2022 |  | 2021 |
| Net Sales |  |  |  |  |  |
| United States | $ | 13,989 |  |  | $ | 12,864 |  |  | $ | 11,577 |  |
| Europe | 4,882 |  |  | 4,186 |  |  | 4,069 |  |
| Asia Pacific | 5,610 |  |  | 5,791 |  |  | 5,748 |  |
| Other Non-U.S. | 2,312 |  |  | 2,458 |  |  | 2,274 |  |
| Total | $ | 26,793 |  |  | $ | 25,299 |  |  | $ | 23,668 |  |
| Long-Lived Assets (Year-end) |  |  |  |  |  |
| United States | $ | 1,594 |  |  | $ | 1,582 |  |  | $ | 1,638 |  |
| Europe | 514 |  |  | 462 |  |  | 436 |  |
| Asia Pacific | 630 |  |  | 658 |  |  | 727 |  |
| Other Non-U.S. | 398 |  |  | 429 |  |  | 427 |  |
| Total | $ | 3,136 |  |  | $ | 3,131 |  |  | $ | 3,228 |  |

[0000833444-23-000048:notes:434]
Net sales attributed to geographic locations are based on the location of where the sale originated. Long-lived assets by geographic location consist of net property, plant and equipment.


## us-gaap:GuaranteesTextBlock

[0000833444-23-000048:notes:435]
GUARANTEES
Certain of the Company's subsidiaries at the business segment level have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance. Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-23-000048:notes:436]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale.

[0000833444-23-000048:notes:437]
The changes in the carrying amount of the Company’s total product warranty liability were as follows (in millions).

[0000833444-23-000048:notes:438]
|  | Year Ended September 30, |
|  | 2023 |  | 2022 |
| Balance at beginning of period | $ | 180 |  |  | $ | 192 |  |
| Accruals for warranties issued during the period | 134 |  |  | 119 |  |
| Settlements made (in cash or in kind) during the period | (112) |  |  | (114) |  |
| Changes in estimates to pre-existing warranties | 1 |  |  | (6) |  |
| Accruals from acquisitions and divestitures | 1 |  |  | — |  |
| Currency translation | (1) |  |  | (11) |  |
| Balance at end of period | $ | 203 |  |  | $ | 180 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-23-000048:notes:439]
COMMITMENTS AND CONTINGENCIES
Environmental Matters

[0000833444-23-000048:notes:440]
The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000048:notes:441]
|  | September 30, |
|  | 2023 |  | 2022 |
| Other current liabilities | $ | 31 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 211 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 242 |  |  | $ | 286 |  |

[0000833444-23-000048:notes:442]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

[0000833444-23-000048:notes:443]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to fire-fighting foams containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).

[0000833444-23-000048:notes:444]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. On July 18, 2023, Tyco Fire Products announced that it plans to discontinue the production and sale of fluorinated firefighting foams by June 2024, including AFFF products, and will transition to non-fluorinated foam alternatives.

[0000833444-23-000048:notes:445]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency (“EPA”) to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

[0000833444-23-000048:notes:446]
Tyco Fire Products is operating and monitoring the recently constructed Groundwater Extraction and Treatment System ("GETS"), a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. The Company's reserves for continued remediation of the FTC, the Stanton Street Facility and surrounding areas in Marinette and Peshtigo are based on estimates of costs associated with the long-term remediation actions, including the continued operation of the GETS, the implementation of long-term drinking water solutions, continued monitoring and testing of the wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

[0000833444-23-000048:notes:447]
PFOA, PFOS, and other PFAS compounds are being studied by EPA and other environmental and health agencies and researchers. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. In March

[0000833444-23-000048:notes:448]
2023, EPA announced a proposed National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR proposes establishing legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion for each of PFOA and PFOS. EPA indicated that it anticipates finalizing the regulation by the end of 2023.

[0000833444-23-000048:notes:449]
In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In April 2023, EPA issued an Advanced Notice of Proposed Rulemaking ("ANPR") seeking input on whether it should expand the proposed rule to designate as "hazardous substances" under CERCLA: (1) seven additional PFAS; (2) the precursors to PFOA, PFOS, and the seven additional PFAS; or (3) entire categories of PFAS.

[0000833444-23-000048:notes:450]
It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-23-000048:notes:451]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $13 million and $17 million at September 30, 2023 and 2022, respectively.

[0000833444-23-000048:notes:452]
FTC-Related Remediation and Litigation

[0000833444-23-000048:notes:453]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. The WDNR has initiated a rulemaking proceeding for a rule that would establish groundwater quality standards for PFOA, PFOS, perfluorobutane sulfonic acid and its potassium salt (“PFBS”) and hexafluoropropylene oxide dimer acid and its ammonium salt (“HFPO-DA”). WDNR indicates that the rule could be finalized by the winter of 2023-2024.

[0000833444-23-000048:notes:454]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

[0000833444-23-000048:notes:455]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in

[0000833444-23-000048:notes:456]
accordance with the WDNR's requests. The parties are proceeding with fact discovery and the court has set a trial date of December 3, 2024. The Company is vigorously defending this civil enforcement action and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

[0000833444-23-000048:notes:457]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina. The Company plans to vigorously defend against this case and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

[0000833444-23-000048:notes:458]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. Subsequently, several additional plaintiffs have direct-filed in the MDL complaints with similar allegations. These lawsuits are presently at the beginning stages of litigation. The Company is vigorously defending these cases and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

[0000833444-23-000048:notes:459]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-23-000048:notes:460]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-23-000048:notes:461]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to the MDL. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-23-000048:notes:462]
AFFF Putative Class Actions

[0000833444-23-000048:notes:463]
Chemguard and Tyco Fire Products are named in 43 pending putative class actions in federal courts originating from 16 states and territories. All of these cases have been direct-filed in or transferred to the MDL.

[0000833444-23-000048:notes:464]
AFFF Individual or Mass Actions

[0000833444-23-000048:notes:465]
There are more than 5,400 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 5,400 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona, Illinois and Virginia.

[0000833444-23-000048:notes:466]
Tyco and Chemguard are also periodically notified by other individuals that they may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-23-000048:notes:467]
AFFF Municipal and Water Provider Cases

[0000833444-23-000048:notes:468]
Chemguard and Tyco Fire Products have been named as defendants in more than 720 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 35 states and territories. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation. The MDL court set the first case for trial on June 5, 2023 (City of Stuart (Florida) v. 3M Co. et al.). On April 26, 2023, the parties entered a stipulation dismissing Chemguard with prejudice from the City of Stuart case, and on May 4, 2023 the parties entered into a stipulation dismissing Tyco with prejudice from the City of Stuart case. On June 5, 2023, the MDL court continued the trial date for the City of Stuart case, and the parties remaining in that case later reached settlement. The parties in the MDL have designated four additional plaintiffs as water provider bellwether cases and are conducting initial discovery into those cases. The parties are also working to identify potential personal injury cases for an additional bellwether phase.

[0000833444-23-000048:notes:469]
Tyco and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-23-000048:notes:470]
State or U.S. Territory Attorneys General Litigation related to AFFF

[0000833444-23-000048:notes:471]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-23-000048:notes:472]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-23-000048:notes:473]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

[0000833444-23-000048:notes:474]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. These two cases have also been removed to federal court and transferred to the MDL.

[0000833444-23-000048:notes:475]
In addition, 29 other states and territories have filed 31 lawsuits against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of each of those State's environmental and natural resources

[0000833444-23-000048:notes:476]
allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within each respective State. The states and territories are: Arkansas, Arizona, California, Colorado, Delaware, the District of Columbia, Florida, Illinois, Kentucky, Massachusetts, Maryland, Maine, Michigan, Mississippi, New Hampshire, New Jersey, New Mexico, Ohio, Oregon, Rhode Island, South Carolina, Tennessee, Texas, Vermont, Washington, Wisconsin, Guam, the Northern Mariana Islands, and Puerto Rico. All of these complaints, other than Delaware and South Carolina, have been removed to federal court and transferred to the MDL. It is anticipated that the Delaware and South Carolina complaints will be removed to federal court and transferred to the MDL.

[0000833444-23-000048:notes:477]
Other AFFF Related Matters

[0000833444-23-000048:notes:478]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-23-000048:notes:479]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This complaint has been transferred to the MDL.

[0000833444-23-000048:notes:480]
In July 2023, the Fond du Lac Band of Lake Superior Chippewa (a federally recognized tribe) direct-filed a lawsuit in the MDL against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota.

[0000833444-23-000048:notes:481]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin and a federal district court in South Carolina. The insurance litigation involves numerous factual and legal issues and remains at a relatively early stage. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-23-000048:notes:482]
Asbestos Matters

[0000833444-23-000048:notes:483]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-23-000048:notes:484]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000048:notes:485]
|  | September 30, |
|  | 2023 |  | 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 364 |  |  | 380 |  |
| Total asbestos-related liabilities | 422 |  |  | 438 |  |
| Other current assets | 28 |  |  | 37 |  |
| Other noncurrent assets | 273 |  |  | 263 |  |
| Total asbestos-related assets | 301 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 121 |  |  | $ | 138 |  |

[0000833444-23-000048:notes:486]
The following table presents the components of asbestos-related assets (in millions):

[0000833444-23-000048:notes:487]
|  | September 30, |
|  | 2023 |  | 2022 |
| Restricted |  |  |  |
| Cash | $ | 20 |  |  | $ | 6 |  |
| Investments | 231 |  |  | 239 |  |
| Total restricted assets | 251 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 50 |  |  | 55 |  |
| Total asbestos-related assets | $ | 301 |  |  | $ | 300 |  |

[0000833444-23-000048:notes:488]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-23-000048:notes:489]
Self-Insured Liabilities

[0000833444-23-000048:notes:490]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-23-000048:notes:491]
The following table presents the location and amount of insurable liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000048:notes:492]
|  | September 30, |
|  | 2023 |  | 2022 |
| Other current liabilities | $ | 86 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 21 |  |  | 22 |  |
| Other noncurrent liabilities | 226 |  |  | 230 |  |
| Total self-insured liabilities | $ | 333 |  |  | $ | 341 |  |

[0000833444-23-000048:notes:493]
The following table presents the location and amount of insurable receivables in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000048:notes:494]
|  | September 30, |
|  | 2023 |  | 2022 |
| Other current assets | $ | 6 |  |  | $ | 10 |  |
| Other noncurrent assets | 14 |  |  | 20 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 30 |  |

[0000833444-23-000048:notes:495]
Other Matters 
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:SubsequentEventsTextBlock

[0000833444-23-000048:notes:496]
SUBSEQUENT EVENTS
During the weekend of September 23, 2023, the Company experienced a cybersecurity incident impacting its internal information technology ("IT") infrastructure and applications. The incident was detected shortly after receiving reports of outages to certain of the Company’s systems. Promptly after detecting the issue, the Company implemented its incident management and response plan and business continuity plans, including implementing remediation measures to mitigate the impact of the incident and restore affected systems and functions. The Company also engaged leading cybersecurity experts and other specialized consultants to assist in its investigation and remediation of the incident, as well as the restoration of impacted applications and systems. The cybersecurity incident consisted of unauthorized access, data exfiltration and deployment of ransomware by a third party to a portion of the Company’s internal IT infrastructure. The incident caused disruptions and limitation of access to portions of the Company’s business applications supporting aspects of the Company’s operations and corporate functions.

[0000833444-23-000048:notes:497]
Lost and deferred revenues and expenses related to the cybersecurity incident had an immaterial impact on fiscal 2023 net income. During the first quarter of fiscal 2024, expenses have been and will continue to be incurred, primarily related to third-party expenditures, including IT recovery and forensic experts and others performing professional services to investigate and remediate the incident, as well as incremental operating expenses incurred from the resulting disruption to the Company’s business operations. The overall impact in fiscal 2024 is not expected to be material to net income, net of insurance recoveries, or cash flows from continuing operations; however, the timing of recognizing the insurance recoveries may differ from the timing of recognizing the associated expenses.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000833444-23-000048:notes:498]
On August 8, 2023, Marc Vandiepenbeeck, the Company’s Vice President and President, Building Solutions, Europe, Middle East, Africa and Latin America, entered into a Rule 10b5–1 trading arrangement (the “Vandiepenbeeck 10b5-1 Plan”) during the Company’s third quarter open trading window. The Vandiepenbeeck 10b5-1 Plan contemplates the sale in regular intervals of up to 12,974 ordinary shares of Company stock issued upon the vesting of restricted stock units and performance stock units. The restricted stock units and performance stock units are scheduled to vest in December 2023. The number of shares to be sold under the Vandiepenbeeck 10b5-1 Plan represents the maximum actual number of shares issuable under the applicable restricted stock unit and performance stock unit awards. The actual number of shares to be sold under the Vandiepenbeeck 10b5-1 Plan will depend on the achievement of applicable performance conditions under the performance share units and the number of shares withheld to satisfy tax obligations upon the vesting of the applicable awards. The Vandiepenbeeck 10b5-1 Plan is expected to become effective on or about December 20, 2023 and is scheduled to terminate upon the earlier of the sale of all shares contemplated under the Vandiepenbeeck 10b5-1 Plan or December 26, 2024.
