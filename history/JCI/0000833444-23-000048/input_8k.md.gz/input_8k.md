# JCI 8-K — 0000833444-23-000044 filed 2023-12-12

## item codes, every 8-K on or before 2023-12-14

- 2023-12-12 0000833444-23-000044 — 2.02, 9.01
- 2023-12-08 0000833444-23-000042 — 5.02
- 2023-11-13 0000833444-23-000038 — 8.01
- 2023-09-27 0000833444-23-000036 — 8.01
- 2023-09-08 0000833444-23-000033 — 5.02
- 2023-08-21 0001193125-23-217018 — 8.01, 9.01
- 2023-08-07 0001193125-23-205014 — 8.01, 9.01
- 2023-08-02 0000833444-23-000028 — 2.02, 9.01
- 2023-05-23 0001193125-23-151889 — 8.01, 9.01
- 2023-05-05 0000833444-23-000011 — 2.02, 9.01
- 2023-03-14 0000833444-23-000007 — 5.07
- 2023-02-01 0000833444-23-000003 — 2.02, 9.01
- 2022-12-22 0000833444-22-000047 — 5.02
- 2022-12-09 0000833444-22-000045 — 5.02
- 2022-11-03 0000833444-22-000038 — 2.02, 9.01
- 2022-09-14 0001193125-22-244741 — 8.01, 9.01
- 2022-09-07 0001193125-22-240030 — 8.01, 9.01
- 2022-08-04 0000833444-22-000034 — 2.02, 9.01
- 2022-07-06 0000833444-22-000029 — 5.02, 9.01
- 2022-06-30 0000833444-22-000027 — 5.02
- 2022-05-04 0000833444-22-000014 — 2.02, 9.01
- 2022-03-11 0001193125-22-073382 — 5.07
- 2022-02-15 0000833444-22-000010 — 5.02
- 2022-02-02 0000833444-22-000003 — 2.02, 9.01
- 2021-12-10 0000833444-21-000050 — 5.02
- 2021-11-05 0000833444-21-000043 — 2.02, 9.01
- 2021-09-16 0001193125-21-275152 — 1.01, 8.01, 9.01
- 2021-07-30 0000833444-21-000038 — 2.02, 9.01
- 2021-05-03 0000833444-21-000023 — 8.01
- 2021-04-30 0000833444-21-000017 — 2.02, 9.01
- 2021-03-11 0000833444-21-000013 — 5.02, 5.07, 9.01
- 2021-02-17 0001193125-21-045768 — 7.01, 9.01
- 2021-01-29 0000833444-21-000009 — 2.02, 9.01
- 2021-01-07 0000833444-21-000004 — 7.01
- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2023-12-14

- 2023-11-29 0000833444-23-000040 — NT 10-K, for the period ended 2023-09-30
- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-23-000044:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq4fy23.htm
EX-99.1

[0000833444-23-000044:8k_2_02:2]
Document

[0000833444-23-000044:8k_2_02:3]
Exhibit 99.1

[0000833444-23-000044:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-23-000044:8k_2_02:5]
Johnson Controls Reports Q4 and FY23 Results Highlighted by Strong Sales Growth and Margin Expansion; Initiates FY24 Guidance

[0000833444-23-000044:8k_2_02:6]
________________________________________________________________________________

[0000833444-23-000044:8k_2_02:7]
▪Q4 reported sales increased 3% versus prior year and up 2% organically; full year reported sales up 6% and increased 8% organically

[0000833444-23-000044:8k_2_02:8]
▪Q4 GAAP EPS of $0.80; Q4 Adjusted EPS of $1.05, including a $0.04 headwind from the cyber incident, up 6% versus prior year; full year GAAP EPS of $2.69; full year Adjusted EPS of $3.50, up 17% versus prior year. Results include a $0.04 headwind from the cyber incident.

[0000833444-23-000044:8k_2_02:9]
▪Q4 Orders +9% organically year-over year; full year orders +7% organically year-over-year

[0000833444-23-000044:8k_2_02:10]
▪Record backlog of $12.1 billion, increased 9% organically year-over-year

[0000833444-23-000044:8k_2_02:11]
______________________________________________________________________________

[0000833444-23-000044:8k_2_02:12]
CORK, Ireland — Dec. 12, 2023 -- Johnson Controls International plc (NYSE: JCI), a global leader for smart, healthy and sustainable buildings, today reported fiscal fourth quarter 2023 GAAP earnings per share (“EPS”) from continuing operations of $0.80. Excluding special items, adjusted EPS from continuing operations was $1.05, up 6% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-23-000044:8k_2_02:13]
Sales in the quarter of $6.9 billion increased 3% compared to the prior year on an as reported basis and grew 2% organically. GAAP net income from continuing operations was $549 million. Adjusted net income from continuing operations of $719 million was up 5% versus the prior year. Earnings before interest and taxes (“EBIT”) was $587 million and EBIT margin was 8.5%. Adjusted EBIT was $936 million and adjusted EBIT margin was 13.6%, flat versus the prior year.

[0000833444-23-000044:8k_2_02:14]
“Our fiscal 2023 results, highlighted by strong sales growth and margin expansion, further validate that our strategy of providing solutions that make buildings smarter, healthier, and more sustainable continues to gain momentum,” said Chairman and CEO George Oliver. “We made significant progress during the year in advancing our service strategy, enabled by digital, and we continue to see strong order momentum and record backlog entering our new fiscal year.”

[0000833444-23-000044:8k_2_02:15]
“Our resilient backlog continues to grow as we saw strong order growth in both our Install and Service businesses throughout the fiscal year,” said Chief Financial Officer Olivier Leonetti. “Our value proposition continues to resonate with our customers globally and we have plenty of runway for ongoing top line growth, margin expansion, and improving cash flow going forward.”

[0000833444-23-000044:8k_2_02:16]
Page 1 of 19

[0000833444-23-000044:8k_2_02:17]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-23-000044:8k_2_02:18]
($ millions, except per-share amounts)

[0000833444-23-000044:8k_2_02:19]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal fourth quarter of 2022.

[0000833444-23-000044:8k_2_02:20]
Organic sales growth, total segment EBITA, adjusted segment EBITA, adjusted corporate expense, EBIT, adjusted EBIT, adjusted net income from continuing operations, adjusted EPS from continuing operations, cash provided by operating activities from continuing operations, excluding JC Capital, and free cash flow are non-GAAP financial measures. For a reconciliation of non-GAAP measures and detail of the special items, refer to the attached footnotes.

[0000833444-23-000044:8k_2_02:21]
This press release includes forward-looking statements regarding organic revenue growth, adjusted segment EBITA margin improvement and adjusted EPS, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as mark-to-market adjustments. Organic revenue growth excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company's fiscal 2024 first quarter and full year GAAP financial results.

[0000833444-23-000044:8k_2_02:22]
A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-23-000044:8k_2_02:23]
|  |  | Fiscal Q4 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Sales |  | $6,725 |  | $6,906 |  | $6,725 |  | $6,906 |  |  |  |  |  |  |
| Segment EBITA |  | 885 |  | 1,105 |  | 1,107 |  | 1,105 |  |  |  |  |  |  |
| EBIT |  | 666 |  | 587 |  | 917 |  | 936 |  |  |  |  |  |  |
| Net income attributable to JCI |  | 761 |  | 549 |  | 682 |  | 719 |  |  |  |  |  |  |
| Diluted EPS from continuing operations |  | $1.10 |  | $0.80 |  | $0.99 |  | $1.05 |  |  |  |  |  |  |

[0000833444-23-000044:8k_2_02:24]
Page 2 of 19

[0000833444-23-000044:8k_2_02:25]
SEGMENT RESULTS

[0000833444-23-000044:8k_2_02:26]
Building Solutions North America

[0000833444-23-000044:8k_2_02:27]
|  |  | Fiscal Q4 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Sales |  | $2,562 |  | $2,778 |  | $2,562 |  | $2,778 |  |  |  |  |  |  |
| Segment EBITA |  | 377 |  | 427 |  | 377 |  | 427 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 14.7% |  | 15.4% |  | 14.7% |  | 15.4% |  |  |  |  |  |  |

[0000833444-23-000044:8k_2_02:28]
Sales in the quarter of $2.8 billion increased 8% versus the prior year. Organic sales increased 8% over the prior year with strong growth in both Service and Install, led by another strong quarter of double-digit growth in Applied HVAC & Controls.

[0000833444-23-000044:8k_2_02:29]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 8% year-over-year. Backlog at the end of the quarter of $8.3 billion increased 10% compared to the prior year, excluding M&A and adjusted for foreign currency.

[0000833444-23-000044:8k_2_02:30]
Segment EBITA was $427 million, up 13% versus the prior year. Segment EBITA margin of 15.4% expanded 70 basis points versus the prior year led by higher margin backlog conversion and continued strong growth in Services.

[0000833444-23-000044:8k_2_02:31]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-23-000044:8k_2_02:32]
|  |  | Fiscal Q4 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Sales |  | $976 |  | $1,045 |  | $976 |  | $1,045 |  |  |  |  |  |  |
| Segment EBITA |  | 92 |  | 82 |  | 92 |  | 82 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 9.4% |  | 7.8% |  | 9.4% |  | 7.8% |  |  |  |  |  |  |

[0000833444-23-000044:8k_2_02:33]
Sales in the quarter of $1.0 billion increased 7% versus the prior year. Organic sales grew 3% versus the prior year led by growth in Applied HVAC & Controls and Fire & Security. Service grew mid-teens in the quarter.

[0000833444-23-000044:8k_2_02:34]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 16% year-over-year. Backlog at the end of the quarter of $2.3 billion increased 10% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-23-000044:8k_2_02:35]
Page 3 of 19

[0000833444-23-000044:8k_2_02:36]
Segment EBITA of $82 million, declined 11% versus the prior year. Segment EBITA margin of 7.8% declined 160 basis points versus the prior year as lower margin backlog was converted, in addition to ongoing pension headwinds.

[0000833444-23-000044:8k_2_02:37]
Building Solutions Asia Pacific

[0000833444-23-000044:8k_2_02:38]
|  |  | Fiscal Q4 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Sales |  | $751 |  | $697 |  | $751 |  | $697 |  |  |  |  |  |  |
| Segment EBITA |  | 105 |  | 94 |  | 105 |  | 94 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 14.0% |  | 13.5% |  | 14.0% |  | 13.5% |  |  |  |  |  |  |

[0000833444-23-000044:8k_2_02:39]
Sales in the quarter of $697 million declined 7% versus the prior year. Organic sales declined 6% versus the prior year as the Install business has been negatively impacted by weakness in China partially offset by double-digit growth in Service.

[0000833444-23-000044:8k_2_02:40]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 3% year-over-year. Backlog at the end of the quarter of $1.5 billion decreased 2% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-23-000044:8k_2_02:41]
Segment EBITA was $94 million, down 11% versus the prior year. Segment EBITA margin of 13.5% declined 50 basis points versus the prior year owing primarily to weakness in the Install business.

[0000833444-23-000044:8k_2_02:42]
Page 4 of 19

[0000833444-23-000044:8k_2_02:43]
Global Products

[0000833444-23-000044:8k_2_02:44]
|  |  | Fiscal Q4 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Sales |  | $2,436 |  | $2,386 |  | $2,436 |  | $2,386 |  |  |  |  |  |  |
| Segment EBITA |  | 311 |  | 502 |  | 533 |  | 502 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 12.8% |  | 21.0% |  | 21.9% |  | 21.0% |  |  |  |  |  |  |

[0000833444-23-000044:8k_2_02:45]
Sales in the quarter of $2.4 billion declined 2% versus the prior year. Organic sales were down 2% versus the prior year as high single-digit growth in Commercial HVAC was not enough to offset declines in global Residential sales.

[0000833444-23-000044:8k_2_02:46]
Adjusted segment EBITA was $502 million, down 6% versus the prior year. Adjusted segment EBITA margin of 21.0% declined 85 basis points versus the prior year as the result of lower manufacturing absorption and mix. Segment EBITA in Q4 2022 includes the unfavorable impact of certain environmental remediation and related reserve adjustments.

[0000833444-23-000044:8k_2_02:47]
Corporate

[0000833444-23-000044:8k_2_02:48]
|  |  | Fiscal Q4 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Corporate Expense |  | ($143) |  | ($70) |  | ($89) |  | ($49) |  |  |  |  |  |  |

[0000833444-23-000044:8k_2_02:49]
Corporate expense was $70 million in the quarter, a decrease of 51% compared to the prior year. Adjusted Corporate expense excludes transaction/separation costs in both Q4 2022 and Q4 2023.

[0000833444-23-000044:8k_2_02:50]
OTHER Q4 ITEMS

[0000833444-23-000044:8k_2_02:51]
▪Cash provided by operating activities from continuing operations was $1,390 million, while cash provided by operating activities from continuing operations, excluding JC Capital, was $1,446 million. Capital expenditures were $173 million, resulting in a free cash flow from continuing operations of $1,273 million.

[0000833444-23-000044:8k_2_02:52]
▪The Company repurchased 0.2 million shares for approximately $12 million. During fiscal year 2023, the Company repurchased 10.5 million shares for approximately $625 million.

[0000833444-23-000044:8k_2_02:53]
Page 5 of 19

[0000833444-23-000044:8k_2_02:54]
▪The Company completed a $105 million cash tender offer for a portion of its outstanding 5.125% Senior Notes due 2045.

[0000833444-23-000044:8k_2_02:55]
▪The Company recorded net pre-tax mark-to-market losses of $108 million related primarily to the remeasurement of the Company’s pension and postretirement benefit plans and restricted asbestos investments.

[0000833444-23-000044:8k_2_02:56]
▪The Company recorded pre-tax restructuring and impairment costs of $220 million.

[0000833444-23-000044:8k_2_02:57]
▪The Company recorded a discrete period net tax benefit of $121 million related to favorable valuation allowance adjustments on certain deferred tax assets.

[0000833444-23-000044:8k_2_02:58]
FIRST QUARTER GUIDANCE

[0000833444-23-000044:8k_2_02:59]
The Company initiated fiscal 2024 first quarter guidance:

[0000833444-23-000044:8k_2_02:60]
▪Organic revenue ~flat year-over-year

[0000833444-23-000044:8k_2_02:61]
▪Adjusted segment EBITA margin of ~13.0%

[0000833444-23-000044:8k_2_02:62]
▪Adjusted EPS before special items of ~$0.48 to $0.50

[0000833444-23-000044:8k_2_02:63]
FULL YEAR GUIDANCE

[0000833444-23-000044:8k_2_02:64]
The Company initiated fiscal 2024 full year EPS guidance:

[0000833444-23-000044:8k_2_02:65]
▪Organic revenue growth up ~MSD year-over year

[0000833444-23-000044:8k_2_02:66]
▪Adjusted segment EBITA margin improvement of ~25+ basis points, year-over-year

[0000833444-23-000044:8k_2_02:67]
▪Adjusted EPS before special items of ~$3.65 to $3.80

[0000833444-23-000044:8k_2_02:68]
CONFERENCE CALL & WEBCAST INFO

[0000833444-23-000044:8k_2_02:69]
Johnson Controls will host a conference call to discuss this quarter’s results at 8:30 a.m. ET today, which can be accessed by dialing 844-763-8274 (in the United States) or +1-412-717-9224 (outside the United States), or via webcast. A slide presentation will accompany the prepared remarks and has been posted on the investor relations section of the Johnson Controls website at https://investors.johnsoncontrols.com/news-and-events/events-and-presentations. A replay will be made available approximately two hours following the conclusion of the conference call.

[0000833444-23-000044:8k_2_02:70]
About Johnson Controls:

[0000833444-23-000044:8k_2_02:71]
At Johnson Controls (NYSE:JCI), we transform the environments where people live, work, learn and play. As the global leader in smart, healthy and sustainable buildings, our mission is to reimagine the performance of buildings to serve people, places and the planet.

[0000833444-23-000044:8k_2_02:72]
Page 6 of 19

[0000833444-23-000044:8k_2_02:73]
Building on a proud history of nearly 140 years of innovation, we deliver the blueprint of the future for industries such as healthcare, schools, data centers, airports, stadiums, manufacturing and beyond through OpenBlue, our comprehensive digital offering.

[0000833444-23-000044:8k_2_02:74]
Today, with a global team of 100,000 experts in more than 150 countries, Johnson Controls offers the world`s largest portfolio of building technology and software as well as service solutions from some of the most trusted names in the industry.

[0000833444-23-000044:8k_2_02:75]
Visit www.johnsoncontrols.com for more information and follow @Johnson Controls on social platforms.

[0000833444-23-000044:8k_2_02:76]
JOHNSON CONTROLS CONTACTS:

[0000833444-23-000044:8k_2_02:77]
| INVESTOR CONTACTS: | MEDIA CONTACT: |  |  |  |
| Jim Lucas | Danielle Canzanella |  |  |  |
| Direct: +1 651.391.3182 | Direct: +1 203.499.8297 |  |  |  |
| Email: jim.lucas@jci.com | Email: danielle.canzanella@jci.com |  |  |  |
| Michael Gates |  |  |  |  |
| Direct: +1 414.524.5785 |  |  |  |  |
| Email: michael.j.gates@jci.com |  |  |  |  |

[0000833444-23-000044:8k_2_02:78]
###

[0000833444-23-000044:8k_2_02:79]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-23-000044:8k_2_02:80]
Page 7 of 19

[0000833444-23-000044:8k_2_02:81]
Hamas; managing the risks and impacts of potential and actual security breaches, cyberattacks, privacy breaches or data breaches, including business, service, or operational disruptions, the unauthorized access to or disclosure of data, financial loss, reputational damage, increased response and remediation costs, legal, and regulatory proceedings or other unfavorable outcomes; maintaining and improving the capacity, reliability and security of Johnson Controls enterprise information technology infrastructure; the ability to manage the lifecycle cybersecurity risk in the development, deployment and operation of Johnson Controls digital platforms and services; changes to laws or policies governing foreign trade, including economic sanctions, tariffs, foreign exchange and capital controls, import/export controls or other trade restrictions; fluctuations in currency exchange rates; changes or uncertainty in laws, regulations, rates, policies, or interpretations that impact Johnson Controls business operations or tax status; the ability to adapt to global climate change, climate change regulation and successfully meet Johnson Controls public sustainability commitments; the outcome of litigation and governmental proceedings; the risk of infringement or expiration of intellectual property rights; Johnson Controls ability to manage the disruptions caused by catastrophic or geopolitical events, such as natural disasters, armed conflict, political change, climate change, pandemics and outbreaks of contagious diseases and other adverse public health developments; the ability of Johnson Controls to drive organizational improvement; any delay or inability of Johnson Controls to realize the expected benefits and synergies of recent portfolio transactions; the ability to hire and retain senior management and other key personnel; the tax treatment of recent portfolio transactions; significant transaction costs and/or unknown liabilities associated with such transactions; labor shortages, work stoppages, union negotiations, labor disputes and other matters associated with the labor force; and the cancellation of or changes to commercial arrangements. A detailed discussion of risks related to Johnson Controls business is included in the section entitled "Risk Factors" in Johnson Controls Annual Report on Form 10-K for the 2022 fiscal year filed with the SEC on November 15, 2022, which is available at www.sec.gov and www.johnsoncontrols.com under the "Investors" tab. The description of certain of these risks is supplemented in Item 1A of Part II of Johnson Controls subsequently filed Quarterly Reports on Form 10-Q. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-23-000044:8k_2_02:82]
###

[0000833444-23-000044:8k_2_02:83]
Non-GAAP Financial Information

[0000833444-23-000044:8k_2_02:84]
This press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include restructuring and impairment costs, net mark-to-market adjustments, Silent-Aire other nonrecurring items, certain transaction/separation costs, Silent-Aire earn-out adjustment, charges attributable to the suspension of operations in Russia, warehouse fire loss, and discrete tax items. Financial information regarding organic sales growth, EBIT, EBIT margin, adjusted EBIT, adjusted EBIT margin, total segment EBITA, adjusted segment EBITA, adjusted segment EBITA margin, adjusted Corporate expense, cash provided by operating activities from continuing operations, excluding JC Capital, free cash flow, and adjusted net income from continuing operations are also presented, which are non-GAAP performance measures. Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of Johnson Controls. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation

[0000833444-23-000044:8k_2_02:85]
Page 8 of 19

[0000833444-23-000044:8k_2_02:86]
purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.  For further information on the calculation of the non-GAAP measures and a reconciliation of these non-GAAP measures, refer to the attached footnotes.

[0000833444-23-000044:8k_2_02:87]
###

[0000833444-23-000044:8k_2_02:88]
Page 9 of 19

[0000833444-23-000044:8k_2_02:89]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |  |
|  |  | Three Months Ended September 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Net sales | $ | 6,906 |  |  |  | $ | 6,725 |  |  |
| Cost of sales | 4,698 |  |  |  | 4,430 |  |  |
|  | Gross profit | 2,208 |  |  |  | 2,295 |  |  |
| Selling, general and administrative expenses | (1,476) |  |  |  | (1,533) |  |  |
| Restructuring and impairment costs | (220) |  |  |  | (167) |  |  |
| Net financing charges | (63) |  |  |  | (60) |  |  |
| Equity income | 75 |  |  |  | 71 |  |  |
| Income before income taxes | 524 |  |  |  | 606 |  |  |
| Income tax benefit | (57) |  |  |  | (203) |  |  |
| Net income | 581 |  |  |  | 809 |  |  |
| Income attributable to noncontrolling interests | 32 |  |  |  | 48 |  |  |
| Net income attributable to JCI | $ | 549 |  |  |  | $ | 761 |  |  |
| Diluted earnings per share | $ | 0.80 |  |  |  | $ | 1.10 |  |  |
| Diluted weighted average shares | 683.3 |  |  |  | 691.2 |  |  |
| Shares outstanding at period end | 680.4 |  |  |  | 688.7 |  |  |

[0000833444-23-000044:8k_2_02:90]
Page 10 of 19

[0000833444-23-000044:8k_2_02:91]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Twelve Months Ended September 30, |
|  |  | 2023 |  |  | 2022 |
| Net sales | $ | 26,793 |  |  |  | $ | 25,299 |  |
| Cost of sales | 17,822 |  |  |  | 16,956 |  |
|  | Gross profit | 8,971 |  |  |  | 8,343 |  |
| Selling, general and administrative expenses | (6,181) |  |  |  | (5,945) |  |
| Restructuring and impairment costs | (1,064) |  |  |  | (721) |  |
| Net financing charges | (281) |  |  |  | (213) |  |
| Equity income | 265 |  |  |  | 246 |  |
| Income before income taxes | 1,710 |  |  |  | 1,710 |  |
| Income tax benefit | (323) |  |  |  | (13) |  |
| Net income | 2,033 |  |  |  | 1,723 |  |
| Income attributable to noncontrolling interests | 184 |  |  |  | 191 |  |
| Net income attributable to JCI | $ | 1,849 |  |  |  | $ | 1,532 |  |
| Diluted earnings per share | $ | 2.69 |  |  |  | $ | 2.19 |  |
| Diluted weighted average shares | 687.4 |  |  |  | 699.6 |  |
| Shares outstanding at period end | 680.4 |  |  |  | 688.7 |  |

[0000833444-23-000044:8k_2_02:92]
Page 11 of 19

[0000833444-23-000044:8k_2_02:93]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | September 30,2023 |  | September 30,2022 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 835 |  |  | $ | 2,031 |  |
| Accounts receivable - net | 6,006 |  |  | 5,727 |  |
| Inventories | 2,776 |  |  | 2,665 |  |
| Other current assets | 1,120 |  |  | 1,262 |  |
|  | Current assets | 10,737 |  |  | 11,685 |  |
| Property, plant and equipment - net | 3,136 |  |  | 3,131 |  |
| Goodwill | 17,936 |  |  | 17,350 |  |
| Other intangible assets - net | 4,888 |  |  | 5,155 |  |
| Investments in partially-owned affiliates | 1,056 |  |  | 963 |  |
| Other noncurrent assets | 4,489 |  |  | 3,874 |  |
|  | Total assets | $ | 42,242 |  |  | $ | 42,158 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 1,030 |  |  | $ | 1,534 |  |
| Accounts payable and accrued expenses | 5,226 |  |  | 5,371 |  |
| Other current liabilities | 4,828 |  |  | 4,334 |  |
|  | Current liabilities | 11,084 |  |  | 11,239 |  |
| Long-term debt | 7,818 |  |  | 7,426 |  |
| Other noncurrent liabilities | 5,646 |  |  | 6,091 |  |
| Shareholders' equity attributable to JCI | 16,545 |  |  | 16,268 |  |
| Noncontrolling interests | 1,149 |  |  | 1,134 |  |
|  | Total liabilities and equity | $ | 42,242 |  |  | $ | 42,158 |  |

[0000833444-23-000044:8k_2_02:94]
Page 12 of 19

[0000833444-23-000044:8k_2_02:95]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |  |  |
|  |  |  |  |  |  | Three Months Ended September 30, |  |  |
|  |  |  |  |  |  | 2023 |  |  | 2022 |  |  |
| Operating Activities |  |  |  |  |  |  |
| Net income attributable to JCI | $ | 549 |  |  |  | $ | 761 |  |  |  |
| Income attributable to noncontrolling interests | 32 |  |  |  | 48 |  |  |  |
| Net income | 581 |  |  |  | 809 |  |  |  |
| Adjustments to reconcile net income to cash provided (used) by operating activities: |  |  |  |  |  |  |
|  |  | Depreciation and amortization | 227 |  |  |  | 197 |  |  |  |
|  |  | Pension and postretirement benefit expense (income) | 84 |  |  |  | (224) |  |  |  |
|  |  | Pension and postretirement contributions | (19) |  |  |  | (13) |  |  |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (71) |  |  |  | 55 |  |  |  |
|  |  | Deferred income taxes | (406) |  |  |  | 100 |  |  |  |
|  |  | Non-cash restructuring and impairment costs | 126 |  |  |  | 125 |  |  |  |
|  |  | Other - net | — |  |  |  | 12 |  |  |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |  |  |
|  |  |  |  | Accounts receivable | 499 |  |  |  | 210 |  |  |  |
|  |  |  |  | Inventories | 302 |  |  |  | (12) |  |  |  |
|  |  |  |  | Other assets | (2) |  |  |  | (86) |  |  |  |
|  |  |  |  | Restructuring reserves | 26 |  |  |  | (5) |  |  |  |
|  |  |  |  | Accounts payable and accrued liabilities | (93) |  |  |  | 482 |  |  |  |
|  |  |  |  | Accrued income taxes | 136 |  |  |  | (471) |  |  |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 1,390 |  |  |  | 1,179 |  |  |  |
| Investing Activities |  |  |  |  |  |  |
| Capital expenditures | (173) |  |  |  | (162) |  |  |  |
| Acquisition of businesses, net of cash acquired | (466) |  |  |  | (33) |  |  |  |
| Other - net | 31 |  |  |  | 90 |  |  |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (608) |  |  |  | (105) |  |  |  |
| Financing Activities |  |  |  |  |  |  |
| Decrease in short and long-term debt - net | (820) |  |  |  | (268) |  |  |  |
| Stock repurchases and retirements | (12) |  |  |  | (14) |  |  |  |
| Payment of cash dividends | (251) |  |  |  | (242) |  |  |  |
| Other - net | 20 |  |  |  | (21) |  |  |  |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (1,063) |  |  |  | (545) |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 62 |  |  |  | (4) |  |  |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | $ | (219) |  |  |  | $ | 525 |  |  |  |

[0000833444-23-000044:8k_2_02:96]
Page 13 of 19

[0000833444-23-000044:8k_2_02:97]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Twelve Months Ended September 30, |
|  |  |  |  |  |  | 2023 |  |  | 2022 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI | $ | 1,849 |  |  |  | $ | 1,532 |  |
| Income attributable to noncontrolling interests | 184 |  |  |  | 191 |  |
| Net income | 2,033 |  |  |  | 1,723 |  |
| Adjustments to reconcile net income to cash provided (used) by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 848 |  |  |  | 830 |  |
|  |  | Pension and postretirement benefit expense (income) | 61 |  |  |  | (216) |  |
|  |  | Pension and postretirement contributions | (57) |  |  |  | (96) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (98) |  |  |  | 30 |  |
|  |  | Deferred income taxes | (676) |  |  |  | (141) |  |
|  |  | Non-cash restructuring and impairment costs | 827 |  |  |  | 555 |  |
|  |  | Other - net | (12) |  |  |  | 44 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (168) |  |  |  | (427) |  |
|  |  |  |  | Inventories | (81) |  |  |  | (773) |  |
|  |  |  |  | Other assets | (216) |  |  |  | (362) |  |
|  |  |  |  | Restructuring reserves | 59 |  |  |  | (7) |  |
|  |  |  |  | Accounts payable and accrued liabilities | (222) |  |  |  | 1,270 |  |
|  |  |  |  | Accrued income taxes | (77) |  |  |  | (440) |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 2,221 |  |  |  | 1,990 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (539) |  |  |  | (592) |  |
| Acquisition of businesses, net of cash acquired | (726) |  |  |  | (269) |  |
| Other - net | 81 |  |  |  | 168 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (1,184) |  |  |  | (693) |  |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | (433) |  |  |  | 1,966 |  |
| Stock repurchases and retirements | (625) |  |  |  | (1,441) |  |
| Payment of cash dividends | (980) |  |  |  | (916) |  |
| Dividends paid to noncontrolling interests | (149) |  |  |  | (121) |  |
| Other - net | 13 |  |  |  | (4) |  |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (2,174) |  |  |  | (516) |  |
| Discontinued Operations - Cash used by operating activities | — |  |  |  | (4) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (5) |  |  |  | (53) |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | $ | (1,142) |  |  |  | $ | 724 |  |

[0000833444-23-000044:8k_2_02:98]
Page 14 of 19

[0000833444-23-000044:8k_2_02:99]
FOOTNOTES

[0000833444-23-000044:8k_2_02:100]
1. Financial Summary

[0000833444-23-000044:8k_2_02:101]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans, restructuring and impairment costs and net financing charges.

[0000833444-23-000044:8k_2_02:102]
| (in millions; unaudited) | Three Months Ended September 30, |
|  | 2023 |  | 2022 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 427 |  |  | $ | 427 |  |  | $ | 377 |  |  | $ | 377 |  |
| Building Solutions EMEA/LA | 82 |  |  | 82 |  |  | 92 |  |  | 92 |  |
| Building Solutions Asia Pacific | 94 |  |  | 94 |  |  | 105 |  |  | 105 |  |
| Global Products | 502 |  |  | 502 |  |  | 311 |  |  | 533 |  |
| Segment EBITA | 1,105 |  |  | 1,105 |  |  | 885 |  |  | 1,107 |  |
| Corporate expenses (2) | (70) |  |  | (49) |  |  | (143) |  |  | (89) |  |
| Amortization of intangible assets (3) | (120) |  |  | (120) |  |  | (101) |  |  | (101) |  |
| Net mark-to-market gains (losses) (4) | (108) |  |  | — |  |  | 192 |  |  | — |  |
| Restructuring and impairment costs (5) | (220) |  |  | — |  |  | (167) |  |  | — |  |
| EBIT (6) | 587 |  |  | 936 |  |  | 666 |  |  | 917 |  |
| EBIT margin (6) | 8.5 | % |  | 13.6 | % |  | 9.9 | % |  | 13.6 | % |
| Net financing charges | (63) |  |  | (63) |  |  | (60) |  |  | (60) |  |
| Income before income taxes | 524 |  |  | 873 |  |  | 606 |  |  | 857 |  |
| Income tax benefit (provision) (7) | 57 |  |  | (118) |  |  | 203 |  |  | (116) |  |
| Net income | 581 |  |  | 755 |  |  | 809 |  |  | 741 |  |
| Income attributable to noncontrolling interests (8) | (32) |  |  | (36) |  |  | (48) |  |  | (59) |  |
| Net income attributable to JCI | $ | 549 |  |  | $ | 719 |  |  | $ | 761 |  |  | $ | 682 |  |

[0000833444-23-000044:8k_2_02:103]
| (in millions; unaudited) | Twelve Months Ended September 30, |
|  | 2023 |  | 2022 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 1,394 |  |  | $ | 1,394 |  |  | $ | 1,122 |  |  | $ | 1,122 |  |
| Building Solutions EMEA/LA | 316 |  |  | 316 |  |  | 358 |  |  | 369 |  |
| Building Solutions Asia Pacific | 343 |  |  | 343 |  |  | 332 |  |  | 332 |  |
| Global Products | 1,965 |  |  | 1,975 |  |  | 1,594 |  |  | 1,773 |  |
| Segment EBITA | 4,018 |  |  | 4,028 |  |  | 3,406 |  |  | 3,596 |  |
| Corporate expenses (2) | (432) |  |  | (310) |  |  | (369) |  |  | (306) |  |
| Amortization of intangible assets (3) | (439) |  |  | (439) |  |  | (427) |  |  | (414) |  |
| Net mark-to-market gains (losses) (4) | (92) |  |  | — |  |  | 34 |  |  | — |  |
| Restructuring and impairment costs (5) | (1,064) |  |  | — |  |  | (721) |  |  | — |  |
| EBIT (6) | 1,991 |  |  | 3,279 |  |  | 1,923 |  |  | 2,876 |  |
| EBIT margin (6) | 7.4 | % |  | 12.2 | % |  | 7.6 | % |  | 11.4 | % |
| Net financing charges | (281) |  |  | (281) |  |  | (213) |  |  | (213) |  |
| Income before income taxes | 1,710 |  |  | 2,998 |  |  | 1,710 |  |  | 2,663 |  |
| Income tax benefit (provision) (7) | 323 |  |  | (405) |  |  | 13 |  |  | (359) |  |
| Net income | 2,033 |  |  | 2,593 |  |  | 1,723 |  |  | 2,304 |  |
| Income attributable to noncontrolling interests (8) | (184) |  |  | (188) |  |  | (191) |  |  | (207) |  |
| Net income attributable to JCI | $ | 1,849 |  |  | $ | 2,405 |  |  | $ | 1,532 |  |  | $ | 2,097 |  |

[0000833444-23-000044:8k_2_02:104]
(1) The Company's press release contains financial information regarding total segment EBITA, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted segment EBITA excludes other non-recurring items that are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-23-000044:8k_2_02:105]
A reconciliation of segment EBITA to net income is shown earlier within this footnote. The following is the three months ended September 30, 2023 and 2022 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-23-000044:8k_2_02:106]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building Solutions Asia Pacific |  | Total Building Solutions |  | Global Products |  | ConsolidatedJCI plc |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Segment EBITA as reported | $ | 427 |  |  | $ | 377 |  |  | $ | 82 |  |  | $ | 92 |  |  | $ | 94 |  |  | $ | 105 |  |  | $ | 603 |  |  | $ | 574 |  |  | $ | 502 |  |  | $ | 311 |  |  | $ | 1,105 |  |  | $ | 885 |  |
| Segment EBITA margin as reported (9) | 15.4 | % |  | 14.7 | % |  | 7.8 | % |  | 9.4 | % |  | 13.5 | % |  | 14.0 | % |  | 13.3 | % |  | 13.4 | % |  | 21.0 | % |  | 12.8 | % |  | 16.0 | % |  | 13.2 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Environmental remediation and related reserves adjustment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 222 |  |  | — |  |  | 222 |  |
| Adjusted segment EBITA | $ | 427 |  |  | $ | 377 |  |  | $ | 82 |  |  | $ | 92 |  |  | $ | 94 |  |  | $ | 105 |  |  | $ | 603 |  |  | $ | 574 |  |  | $ | 502 |  |  | $ | 533 |  |  | $ | 1,105 |  |  | $ | 1,107 |  |
| Adjusted segment EBITA margin (9) | 15.4 | % |  | 14.7 | % |  | 7.8 | % |  | 9.4 | % |  | 13.5 | % |  | 14.0 | % |  | 13.3 | % |  | 13.4 | % |  | 21.0 | % |  | 21.9 | % |  | 16.0 | % |  | 16.5 | % |

[0000833444-23-000044:8k_2_02:107]
A reconciliation of segment EBITA to net income is shown earlier within this footnote. The following is the twelve months ended September 30, 2023 and 2022 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-23-000044:8k_2_02:108]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building Solutions Asia Pacific |  | Total Building Solutions |  | Global Products |  | ConsolidatedJCI plc |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Segment EBITA as reported | $ | 1,394 |  |  | $ | 1,122 |  |  | $ | 316 |  |  | $ | 358 |  |  | $ | 343 |  |  | $ | 332 |  |  | $ | 2,053 |  |  | $ | 1,812 |  |  | $ | 1,965 |  |  | $ | 1,594 |  |  | $ | 4,018 |  |  | $ | 3,406 |  |
| Segment EBITA margin as reported (9) | 13.5 | % |  | 12.0 | % |  | 7.7 | % |  | 9.3 | % |  | 12.5 | % |  | 12.2 | % |  | 12.0 | % |  | 11.4 | % |  | 20.4 | % |  | 17.0 | % |  | 15.0 | % |  | 13.5 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Silent-Aire earn-out adjustment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (30) |  |  | (43) |  |  | (30) |  |  | (43) |  |
| Warehouse fire loss | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 40 |  |  | — |  |  | 40 |  |  | — |  |
| Environmental remediation and related reserves adjustment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 222 |  |  | — |  |  | 222 |  |
| Charges attributable to the suspension of operations in Russia | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Adjusted segment EBITA | $ | 1,394 |  |  | $ | 1,122 |  |  | $ | 316 |  |  | $ | 369 |  |  | $ | 343 |  |  | $ | 332 |  |  | $ | 2,053 |  |  | $ | 1,823 |  |  | $ | 1,975 |  |  | $ | 1,773 |  |  | $ | 4,028 |  |  | $ | 3,596 |  |
| Adjusted segment EBITA margin (9) | 13.5 | % |  | 12.0 | % |  | 7.7 | % |  | 9.6 | % |  | 12.5 | % |  | 12.2 | % |  | 12.0 | % |  | 11.4 | % |  | 20.5 | % |  | 18.9 | % |  | 15.0 | % |  | 14.2 | % |

[0000833444-23-000044:8k_2_02:109]
Page 15 of 19

[0000833444-23-000044:8k_2_02:110]
(2) Adjusted Corporate expenses for the three and twelve months ended September 30, 2023 excludes certain transaction/separation costs of $21 million and $122 million, respectively. Adjusted Corporate expenses for the three months ended September 30, 2022 excludes $33 million of an environmental remediation and related reserves adjustment and transaction/separation costs of $21 million. Adjusted Corporate expenses for the twelve months ended September 30, 2022 excludes $33 million of an environmental remediation and related reserves adjustment and transaction/separation costs of $30 million.

[0000833444-23-000044:8k_2_02:111]
(3) Adjusted amortization of intangible assets for the twelve months ended September 30, 2022 excludes nonrecurring intangible asset amortization related to Silent-Aire purchase accounting of $13 million.

[0000833444-23-000044:8k_2_02:112]
(4) Adjusted results for the three and twelve months ended September 30, 2023 exclude net mark-to-market losses on restricted asbestos investments and pension and postretirement plans of $108 million and $92 million, respectively. The three and twelve months ended September 30, 2022 exclude the net mark-to-market gains on restricted asbestos investments and pension and postretirement plans of $192 million and $34 million, respectively.

[0000833444-23-000044:8k_2_02:113]
(5) Adjusted results for the three and twelve months ended September 30, 2023 exclude restructuring and impairment costs of $220 million and $1,064 million, respectively. The restructuring actions and impairment costs for the three months ended September 30, 2023 are related primarily to workforce reductions and other asset impairments. The restructuring actions and impairment costs for the twelve months ended September 30, 2023 are related primarily to workforce reductions, impairment of goodwill attributable to the Company's Silent-Aire reporting unit, impairment of assets associated with businesses previously classified as held for sale and other asset impairments. Adjusted results for the three and twelve months ended September 30, 2022 exclude restructuring and impairment costs of $167 million and $721 million, respectively. The restructuring actions and impairment costs for the three months ended September 30, 2022 are related primarily to workforce reductions, impairment of goodwill attributable to the Company's Silent-Aire reporting unit and other asset impairments. The restructuring actions and impairment costs for the twelve months ended September 30, 2022 are related primarily to the impairment of assets associated with businesses classified as held for sale, workforce reductions, impairment of goodwill attributable to the Company's Silent-Aire reporting unit and other asset impairments.

[0000833444-23-000044:8k_2_02:114]
(6) Management defines earnings before interest and taxes (EBIT) as income before net financing charges, income taxes and noncontrolling interests. EBIT margin is defined as EBIT divided by net sales. EBIT and EBIT margin are non-GAAP performance measures. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company. A reconciliation of EBIT to net income is shown earlier within this footnote.

[0000833444-23-000044:8k_2_02:115]
7) Adjusted income tax provision for the three months ended September 30, 2023 excludes net tax benefits related to valuation allowance adjustments of $121 million and the tax effect of other pre-tax adjusting items of $54 million. Adjusted income tax provision for the twelve months ended September 30, 2023 excludes net tax benefits related to adjustments to reserves for uncertain tax positions of $438 million, the net tax effect of other pre-tax adjusting items of $169 million and valuation allowance adjustments of $121 million. Adjusted income tax provision for the three months ended September 30, 2022 excludes tax benefits related to the expiration of the statute of limitations for certain tax years of $301 million and the net tax effect of other pre-tax adjusting items of $45 million, partially offset by tax provisions related to a Japan valuation allowance establishment of $27 million. Adjusted income tax provision for the twelve months ended September 30, 2022 excludes tax benefits related to the expiration of the statute of limitations for certain tax years of $301 million and the net tax effect of other pre-tax adjusting items of $119 million, partially offset by tax provisions related to a Japan valuation allowance establishment of $27 million and APB23 adjustments attributable to businesses classified as held for sale of $21 million.

[0000833444-23-000044:8k_2_02:116]
(8) Adjusted income from continuing operations attributable to noncontrolling interests for the three and twelve months ended September 30, 2023 excludes $4 million impact from restructuring and impairment costs. Adjusted income from continuing operations attributable to noncontrolling interests for the three months ended September 30, 2022 excludes $11 million impact from a Japan valuation allowance establishment. Adjusted income from continuing operations attributable to noncontrolling interests for the twelve months ended September 30, 2022 excludes $11 million impact from a Japan valuation allowance establishment and $5 million impact from restructuring and impairment costs.

[0000833444-23-000044:8k_2_02:117]
(9) Segment EBITA margin is defined as segment EBITA divided by segment net sales, as disclosed in the Company's press release.

[0000833444-23-000044:8k_2_02:118]
The Company's press release and earnings presentation include forward-looking statements regarding organic revenue growth, adjusted segment EBITA margin improvement, free cash flow and adjusted EPS, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as mark-to-market adjustments. Organic revenue growth excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s fiscal 2024 first quarter and full year GAAP financial results.

[0000833444-23-000044:8k_2_02:119]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-23-000044:8k_2_02:120]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items shown in the table below are excluded because these items are not considered to be directly related to the underlying operating performance of the Company. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-23-000044:8k_2_02:121]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-23-000044:8k_2_02:122]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc |  |
|  | Three Months Ended |  | Twelve Months Ended |  |
|  | September 30, |  | September 30, |  |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |
| Earnings per share as reported for JCI plc | $ | 0.80 |  |  | $ | 1.10 |  |  | $ | 2.69 |  |  | $ | 2.19 |  |  |
| Adjusting items: |  |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | 0.16 |  |  | (0.28) |  |  | 0.13 |  |  | (0.05) |  |  |
| Related tax impact | (0.04) |  |  | 0.05 |  |  | (0.04) |  |  | (0.01) |  |  |
| Restructuring and impairment costs | 0.32 |  |  | 0.24 |  |  | 1.55 |  |  | 1.03 |  |  |
| Related tax impact | (0.04) |  |  | (0.03) |  |  | (0.18) |  |  | (0.07) |  |  |
| NCI impact of restructuring and impairment costs | (0.01) |  |  | — |  |  | (0.01) |  |  | (0.01) |  |  |
| Silent-Aire other nonrecurring costs | — |  |  | — |  |  | — |  |  | 0.02 |  |  |
| Environmental remediation and related reserves adjustment | — |  |  | 0.37 |  |  | — |  |  | 0.36 |  |  |
| Related tax impact | — |  |  | (0.08) |  |  | — |  |  | (0.08) |  |  |
| Transaction/separation costs | 0.03 |  |  | 0.03 |  |  | 0.18 |  |  | 0.04 |  |  |
| Related tax impact | — |  |  | — |  |  | (0.02) |  |  | — |  |  |
| Silent-Aire earn-out adjustment | — |  |  | — |  |  | (0.04) |  |  | (0.06) |  |  |
| Warehouse fire loss | — |  |  | — |  |  | 0.06 |  |  | — |  |  |
| Related tax impact | — |  |  | — |  |  | (0.01) |  |  | — |  |  |
| Charges attributable to the suspension of operations in Russia | — |  |  | — |  |  | — |  |  | 0.01 |  |  |
| Discrete tax items | (0.18) |  |  | (0.40) |  |  | (0.81) |  |  | (0.36) |  |  |
| NCI impact of discrete tax items | — |  |  | (0.02) |  |  | — |  |  | (0.02) |  |  |
| Adjusted earnings per share for JCI plc* | $ | 1.05 |  |  | $ | 0.99 |  |  | $ | 3.50 |  |  | $ | 3.00 |  |  |

[0000833444-23-000044:8k_2_02:123]
* May not sum due to rounding

[0000833444-23-000044:8k_2_02:124]
Page 16 of 19

[0000833444-23-000044:8k_2_02:125]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-23-000044:8k_2_02:126]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 30, |  | September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 680.3 |  |  | 688.6 |  |  | 684.3 |  |  | 696.1 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |
| and unvested performance share awards | 3.0 |  |  | 2.6 |  |  | 3.1 |  |  | 3.5 |  |
| Diluted weighted average shares outstanding | 683.3 |  |  | 691.2 |  |  | 687.4 |  |  | 699.6 |  |

[0000833444-23-000044:8k_2_02:127]
3. Organic Growth Reconciliation

[0000833444-23-000044:8k_2_02:128]
The components of the change in net sales for the three months ended September 30, 2023 versus the three months ended September 30, 2022, including organic growth, are shown below (unaudited):

[0000833444-23-000044:8k_2_02:129]
| (in millions) | Net Sales for the Three Months Ended September 30, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the Three Months EndedSeptember 30, 2022 |  | Acquisitions |  | Organic Growth |  | Net Sales for the Three Months EndedSeptember 30, 2023 |
| Building Solutions North America | $ | 2,562 |  |  | $ | — |  | — |  |  | $ | (4) |  | — |  |  | $ | 2,558 |  |  | $ | 12 |  | — |  |  | $ | 208 |  | 8 | % |  | $ | 2,778 |  | 8 | % |
| Building Solutions EMEA/LA | 976 |  |  | (5) |  | -1 | % |  | 39 |  | 4 | % |  | 1,010 |  |  | 7 |  | 1 | % |  | 28 |  | 3 | % |  | 1,045 |  | 7 | % |
| Building Solutions Asia Pacific | 751 |  |  | (13) |  | -2 | % |  | (22) |  | -3 | % |  | 716 |  |  | 24 |  | 3 | % |  | (43) |  | -6 | % |  | 697 |  | -7 | % |
| Total Building Solutions | 4,289 |  |  | (18) |  | — |  |  | 13 |  | — |  |  | 4,284 |  |  | 43 |  | 1 | % |  | 193 |  | 5 | % |  | 4,520 |  | 5 | % |
| Global Products | 2,436 |  |  | — |  | — |  |  | (31) |  | -1 | % |  | 2,405 |  |  | 31 |  | 1 | % |  | (50) |  | -2 | % |  | 2,386 |  | -2 | % |
| Total net sales | $ | 6,725 |  |  | $ | (18) |  | — |  |  | $ | (18) |  | — |  |  | $ | 6,689 |  |  | $ | 74 |  | 1 | % |  | $ | 143 |  | 2 | % |  | $ | 6,906 |  | 3 | % |

[0000833444-23-000044:8k_2_02:130]
The components of the change in net sales for the twelve months ended September 30, 2023 versus the twelve months ended September 30, 2022, including organic growth, are shown below (unaudited):

[0000833444-23-000044:8k_2_02:131]
| (in millions) | Net Sales for the Twelve Months Ended September 30, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for theTwelve Months Ended September 30, 2022 |  | Acquisitions |  | Organic Growth |  | Net Sales for the Twelve Months EndedSeptember 30, 2023 |
| Building Solutions North America | $ | 9,367 |  |  | $ | — |  | — |  |  | $ | (45) |  | — |  |  | $ | 9,322 |  |  | $ | 29 |  | — |  |  | $ | 979 |  | 11 | % |  | $ | 10,330 |  | 10 | % |
| Building Solutions EMEA/LA | 3,845 |  |  | (32) |  | -1 | % |  | (102) |  | -3 | % |  | 3,711 |  |  | 61 |  | 2 | % |  | 324 |  | 9 | % |  | 4,096 |  | 7 | % |
| Building Solutions Asia Pacific | 2,714 |  |  | (13) |  | — |  |  | (169) |  | -6 | % |  | 2,532 |  |  | 32 |  | 1 | % |  | 182 |  | 7 | % |  | 2,746 |  | 1 | % |
| Total Building Solutions | 15,926 |  |  | (45) |  | — |  |  | (316) |  | -2 | % |  | 15,565 |  |  | 122 |  | 1 | % |  | 1,485 |  | 10 | % |  | 17,172 |  | 8 | % |
| Global Products | 9,373 |  |  | — |  | — |  |  | (300) |  | -3 | % |  | 9,073 |  |  | 36 |  | — |  |  | 512 |  | 6 | % |  | 9,621 |  | 3 | % |
| Total net sales | $ | 25,299 |  |  | $ | (45) |  | — |  |  | $ | (616) |  | -2 | % |  | $ | 24,638 |  |  | $ | 158 |  | 1 | % |  | $ | 1,997 |  | 8 | % |  | $ | 26,793 |  | 6 | % |

[0000833444-23-000044:8k_2_02:132]
The components of the change in total service revenue for the three months ended September 30, 2023 versus the three months ended September 30, 2022, including organic growth, are shown below (unaudited):

[0000833444-23-000044:8k_2_02:133]
| (in millions) | Service Revenuefor the Three Months Ended September 30, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base Service Revenue for the Three Months Ended September 30, 2022 |  | Acquisitions |  | Organic Growth |  | Service Revenuefor the Three Months EndedSeptember 30, 2023 |
| Building Solutions North America | $ | 977 |  |  | $ | — |  | — |  |  | $ | (3) |  | — |  |  | $ | 974 |  |  | $ | 11 |  | 1 | % |  | $ | 66 |  | 7 | % |  | $ | 1,051 |  | 8 | % |
| Building Solutions EMEA/LA | 405 |  |  | (1) |  | — |  |  | 9 |  | 2 | % |  | 413 |  |  | 3 |  | 1 | % |  | 59 |  | 14 | % |  | 475 |  | 17 | % |
| Building Solutions Asia Pacific | 188 |  |  | (13) |  | -7 | % |  | (4) |  | -2 | % |  | 171 |  |  | 9 |  | 5 | % |  | 19 |  | 11 | % |  | 199 |  | 6 | % |
| Total Building Solutions | 1,570 |  |  | (14) |  | -1 | % |  | 2 |  | — |  |  | 1,558 |  |  | 23 |  | 1 | % |  | 144 |  | 9 | % |  | 1,725 |  | 10 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 1,570 |  |  | $ | (14) |  | -1 | % |  | $ | 2 |  | — |  |  | $ | 1,558 |  |  | $ | 23 |  | 1 | % |  | $ | 144 |  | 9 | % |  | $ | 1,725 |  | 10 | % |

[0000833444-23-000044:8k_2_02:134]
The components of the change in total service revenue for the twelve months ended September 30, 2023 versus the twelve months ended September 30, 2022, including organic growth, are shown below (unaudited):

[0000833444-23-000044:8k_2_02:135]
| (in millions) | Service Revenue for the Twelve Months EndedSeptember 30, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base Service Revenue for the Twelve Months Ended September 30, 2022 |  | Acquisitions |  | Organic Growth |  | Service Revenuefor the Twelve Months EndedSeptember 30, 2023 |
| Building Solutions North America | $ | 3,659 |  |  | $ | — |  | — |  |  | $ | (18) |  | — |  |  | $ | 3,641 |  |  | $ | 28 |  | 1 | % |  | $ | 293 |  | 8 | % |  | $ | 3,962 |  | 8 | % |
| Building Solutions EMEA/LA | 1,657 |  |  | (13) |  | -1 | % |  | (63) |  | -4 | % |  | 1,581 |  |  | 13 |  | 1 | % |  | 227 |  | 14 | % |  | 1,821 |  | 10 | % |
| Building Solutions Asia Pacific | 709 |  |  | (13) |  | -2 | % |  | (40) |  | -6 | % |  | 656 |  |  | 12 |  | 2 | % |  | 91 |  | 14 | % |  | 759 |  | 7 | % |
| Total Building Solutions | 6,025 |  |  | (26) |  | — |  |  | (121) |  | -2 | % |  | 5,878 |  |  | 53 |  | 1 | % |  | 611 |  | 10 | % |  | 6,542 |  | 9 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 6,025 |  |  | $ | (26) |  | — |  |  | $ | (121) |  | -2 | % |  | $ | 5,878 |  |  | $ | 53 |  | 1 | % |  | $ | 611 |  | 10 | % |  | $ | 6,542 |  | 9 | % |

[0000833444-23-000044:8k_2_02:136]
Page 17 of 19

[0000833444-23-000044:8k_2_02:137]
The components of the change in total install revenue for the three months ended September 30, 2023 versus the three months ended September 30, 2022, including organic growth, are shown below (unaudited):

[0000833444-23-000044:8k_2_02:138]
| (in millions) | Install Revenue for the Three Months EndedSeptember 30, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base Install Revenue for the Three Months Ended September 30, 2022 |  | Acquisitions |  | Organic Growth |  | Install Revenuefor the Three Months EndedJune 30, 2023 |
| Building Solutions North America | $ | 1,585 |  |  | $ | — |  | — |  |  | $ | (1) |  | — |  |  | $ | 1,584 |  |  | $ | 1 |  | — |  |  | $ | 142 |  | 9 | % |  | $ | 1,727 |  | 9 | % |
| Building Solutions EMEA/LA | 571 |  |  | (4) |  | -1 | % |  | 30 |  | 5 | % |  | 597 |  |  | 4 |  | 1 | % |  | (31) |  | -5 | % |  | 570 |  | — |  |
| Building Solutions Asia Pacific | 563 |  |  | — |  | — |  |  | (18) |  | -3 | % |  | 545 |  |  | 15 |  | 3 | % |  | (62) |  | -11 | % |  | 498 |  | -12 | % |
| Total Building Solutions | 2,719 |  |  | (4) |  | — |  |  | 11 |  | — |  |  | 2,726 |  |  | 20 |  | 1 | % |  | 49 |  | 2 | % |  | 2,795 |  | 3 | % |
| Global Products | 2,436 |  |  | — |  | — |  |  | (31) |  | -1 | % |  | 2,405 |  |  | 31 |  | 1 | % |  | (50) |  | -2 | % |  | 2,386 |  | -2 | % |
| Total install revenue | $ | 5,155 |  |  | $ | (4) |  | — |  |  | $ | (20) |  | — |  |  | $ | 5,131 |  |  | $ | 51 |  | 1 | % |  | $ | (1) |  | — |  |  | $ | 5,181 |  | 1 | % |

[0000833444-23-000044:8k_2_02:139]
The components of the change in total install revenue for the twelve months ended September 30, 2023 versus the twelve months ended September 30, 2022, including organic growth, are shown below (unaudited):

[0000833444-23-000044:8k_2_02:140]
| (in millions) | Install Revenue for the Twelve Months EndedSeptember 30, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base Install Revenue for the Twelve Months Ended September 30, 2022 |  | Acquisitions |  | Organic Growth |  | Install Revenuefor the Twelve Months EndedSeptember 30, 2023 |
| Building Solutions North America | $ | 5,708 |  |  | $ | — |  | — |  |  | $ | (27) |  | — |  |  | $ | 5,681 |  |  | $ | 1 |  | — |  |  | $ | 686 |  | 12 | % |  | $ | 6,368 |  | 12 | % |
| Building Solutions EMEA/LA | 2,188 |  |  | (19) |  | -1 | % |  | (39) |  | -2 | % |  | 2,130 |  |  | 48 |  | 2 | % |  | 97 |  | 5 | % |  | 2,275 |  | 4 | % |
| Building Solutions Asia Pacific | 2,005 |  |  | — |  | — |  |  | (129) |  | -6 | % |  | 1,876 |  |  | 20 |  | 1 | % |  | 91 |  | 5 | % |  | 1,987 |  | -1 | % |
| Total Building Solutions | 9,901 |  |  | (19) |  | — |  |  | (195) |  | -2 | % |  | 9,687 |  |  | 69 |  | 1 | % |  | 874 |  | 9 | % |  | 10,630 |  | 7 | % |
| Global Products | 9,373 |  |  | — |  | — |  |  | (300) |  | -3 | % |  | 9,073 |  |  | 36 |  | — |  |  | 512 |  | 6 | % |  | 9,621 |  | 3 | % |
| Total install revenue | $ | 19,274 |  |  | $ | (19) |  | — |  |  | $ | (495) |  | -3 | % |  | $ | 18,760 |  |  | $ | 105 |  | 1 | % |  | $ | 1,386 |  | 7 | % |  | $ | 20,251 |  | 5 | % |

[0000833444-23-000044:8k_2_02:141]
4.   Free Cash Flow Conversion

[0000833444-23-000044:8k_2_02:142]
The Company's press release contains financial information regarding free cash flow and free cash flow conversion, which are non-GAAP performance measures. We also present below free cash flow conversion from the GAAP measure of net income attributable to JCI. Effective January 1, 2023, the Company has excluded the impact of its financing entity, JC Capital, from the calculation of free cash flow. Management believes this provides a more true representation of the Company’s operational ability to convert cash, without the contrary impact from financing activities. The impact on interim and annual periods prior to January 1, 2023 was not material. JC Capital cash flows that are excluded from the calculation of free cash flow primarily include activity associated with finance/notes receivables and inventory and/or capital expenditures related to lease arrangements. JC Capital net income that is excluded is primarily related to interest income on the finance/notes receivable and profit recognized on arrangements with sales-type lease components.

[0000833444-23-000044:8k_2_02:143]
Free cash flow is defined as cash provided (used) by operating activities, excluding JC Capital, less capital expenditures, excluding JC Capital. Free cash flow conversion from net income is defined as free cash flow divided by net income attributable to JCI. Free cash flow conversion is defined as free cash flow divided by adjusted net income attributable to JCI, excluding JC Capital. Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash. These non-GAAP measures can also be used to evaluate our ability to generate cash flow from operations and the impact that this cash flow has on our liquidity.

[0000833444-23-000044:8k_2_02:144]
The following is the three and twelve months ended September 30, 2023 and 2022 calculation of free cash flow (unaudited):

[0000833444-23-000044:8k_2_02:145]
|  | Three Months Ended |  | Twelve Months Ended |
| (in millions) | September 30, 2023 |  | September 30, 2022 |  | September 30, 2023 |  | September 30, 2022 |
| Cash provided by operating activities from continuing operations | $ | 1,390 |  | $ | 1,179 |  | $ | 2,221 |  | $ | 1,990 |
| Less: JC Capital cash used by operating activities from continuing operations | (56) |  | — |  | (137) |  | — |
| Cash provided by operating activities from continuing operations, excluding JC Capital | $ | 1,446 |  | $ | 1,179 |  | $ | 2,358 |  | $ | 1,990 |
| Capital expenditures | $ | (173) |  | $ | (162) |  | $ | (539) |  | $ | (592) |
| Less: JC Capital capital expenditures | — |  | — |  | — |  | — |
| Capital expenditures, excluding JC Capital | $ | (173) |  | $ | (162) |  | $ | (539) |  | $ | (592) |
| Free cash flow | $ | 1,273 |  | $ | 1,017 |  | $ | 1,819 |  | $ | 1,398 |

[0000833444-23-000044:8k_2_02:146]
The following is the twelve months ended September 30, 2023 and 2022 calculation of free cash flow conversion from net income and free cash flow conversion (unaudited):

[0000833444-23-000044:8k_2_02:147]
|  | Twelve Months Ended |  |
| (in millions) | September 30, 2023 |  | September 30, 2022 |  |
| Net income attributable to JCI | $ | 1,849 |  | $ | 1,532 |  |
| Free cash flow conversion from net income | 98 | % |  | 91 | % |  |
| Adjusted net income attributable to JCI | $ | 2,405 |  | $ | 2,097 |  |
| Less: JC Capital net income | 11 |  | — |  |
| Adjusted net income attributable to JCI, excluding JC Capital | $ | 2,394 |  | $ | 2,097 |  |
| Free cash flow conversion | 76 | % |  | 67 | % |  |

[0000833444-23-000044:8k_2_02:148]
Page 18 of 19

[0000833444-23-000044:8k_2_02:149]
5.  Debt Ratios

[0000833444-23-000044:8k_2_02:150]
The Company's earnings presentation provides financial information regarding net debt to adjusted EBITDA, which is a non-GAAP performance measure. We also present below net debt to income before income taxes. The Company believes these ratios are useful to understanding the Company's financial condition as they provide an overview of the extent to which the Company relies on external debt financing for its funding and are a measure of risk to its shareholders. The following is the September 30, 2023, June 30, 2023, and September 30, 2022 calculation of net debt to income before income taxes and net debt to adjusted EBITDA (unaudited):

[0000833444-23-000044:8k_2_02:151]
| (in millions) | September 30, 2023 |  | June 30, 2023 |  | September 30, 2022 |  |  |
| Short-term debt and current portion of long-term debt | $ | 1,030 |  |  | $ | 1,267 |  |  | $ | 1,534 |  |  |  |
| Long-term debt | 7,818 |  |  | 8,497 |  |  | 7,426 |  |  |  |
| Total debt | 8,848 |  |  | 9,764 |  |  | 8,960 |  |  |  |
| Less: cash and cash equivalents | 835 |  |  | 1,057 |  |  | 2,031 |  |  |  |
| Total net debt | $ | 8,013 |  |  | $ | 8,707 |  |  | $ | 6,929 |  |  |  |
| Last twelve months income before income taxes | $ | 1,710 |  |  | $ | 1,792 |  |  | $ | 1,710 |  |  |  |
| Total net debt to income before income taxes | 4.7x |  | 4.9x |  | 4.1x |  |  |
| Last twelve months adjusted EBITDA | $ | 4,127 |  |  | $ | 4,078 |  |  | $ | 3,693 |  |  |  |
| Total net debt to adjusted EBITDA | 1.9x |  | 2.1x |  | 1.9x |  |  |

[0000833444-23-000044:8k_2_02:152]
The following is the last twelve months ended September 30, 2023, June 30, 2023, and September 30, 2022 reconciliation of income from continuing operations to adjusted EBIT and adjusted EBITDA, which are non-GAAP performance measures (unaudited):

[0000833444-23-000044:8k_2_02:153]
| (in millions) | Last Twelve MonthsEndedSeptember 30, 2023 |  | Last Twelve MonthsEndedJune 30, 2023 |  | Last Twelve MonthsEndedSeptember 30, 2022 |  |  |
| Income from continuing operations | $ | 2,033 |  |  | $ | 2,261 |  |  | $ | 1,723 |  |  |  |
| Income tax benefit | (323) |  |  | (469) |  |  | (13) |  |  |  |
| Net financing charges | 281 |  |  | 278 |  |  | 213 |  |  |  |
| EBIT | 1,991 |  |  | 2,070 |  |  | 1,923 |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | 92 |  |  | (208) |  |  | (34) |  |  |  |
| Restructuring and impairment costs | 1,064 |  |  | 1,011 |  |  | 721 |  |  |  |
| Environmental remediation and related reserves adjustment | — |  |  | 255 |  |  | 255 |  |  |  |
| Silent-Aire other nonrecurring costs | — |  |  | — |  |  | 13 |  |  |  |
| Silent-Aire earn-out adjustment | (30) |  |  | (30) |  |  | (43) |  |  |  |
| Charges attributable to the suspension of operations in Russia | — |  |  | — |  |  | 11 |  |  |  |
| Warehouse fire loss | 40 |  |  | 40 |  |  | — |  |  |  |
| Transaction/separation costs | 122 |  |  | 122 |  |  | 30 |  |  |  |
| Adjusted EBIT (1) | 3,279 |  |  | 3,260 |  |  | 2,876 |  |  |  |
| Depreciation and amortization | 848 |  |  | 818 |  |  | 817 |  |  |  |
| Adjusted EBITDA (1) | $ | 4,127 |  |  | $ | 4,078 |  |  | $ | 3,693 |  |  |  |

[0000833444-23-000044:8k_2_02:154]
(1) The Company's definition of adjusted EBIT and adjusted EBITDA excludes special items that are not considered to be directly related to the underlying operating performance of its businesses. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-23-000044:8k_2_02:155]
6.  Income Taxes

[0000833444-23-000044:8k_2_02:156]
The Company's effective tax rate from continuing operations before consideration of net mark-to-market adjustments, restructuring and impairment costs, Silent-Aire nonrecurring intangible asset amortization and purchase accounting, charges attributable to the suspension of operations in Russia, discrete tax items, certain transaction/separation costs and warehouse fire loss for the three and twelve months ending September 30, 2023 and September 30, 2022 is approximately 13.5%.

[0000833444-23-000044:8k_2_02:157]
Page 19 of 19
