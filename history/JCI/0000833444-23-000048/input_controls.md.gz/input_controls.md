# JCI 10-K controls and the auditor's report


## auditors_report

[0000833444-23-000048:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0000833444-23-000048:auditors_report:2]
To the Board of Directors and Shareholders of Johnson Controls International plc

[0000833444-23-000048:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0000833444-23-000048:auditors_report:4]
We have audited the accompanying consolidated statements of financial position of Johnson Controls International plc and its subsidiaries (the “Company”) as of September 30, 2023 and 2022, and the related consolidated statements of income, of comprehensive income, of shareholders' equity and of cash flows for each of the three years in the period ended September 30, 2023, including the related notes (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of September 30, 2023, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0000833444-23-000048:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of September 30, 2023 and 2022, and the results of its operations and its cash flows for each of the three years in the period ended September 30, 2023 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company did not maintain, in all material respects, effective internal control over financial reporting as of September 30, 2023, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO because a material weakness in internal control over financial reporting existed as of that date related to

[0000833444-23-000048:auditors_report:6]
ineffective design and maintenance of information technology controls to prevent or detect, on a timely basis, unauthorized access to certain of the Company's financial reporting systems.

[0000833444-23-000048:auditors_report:7]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis. The material weakness referred to above is described in Management’s Report on Internal Control Over Financial Reporting appearing under Item 9A. We considered this material weakness in determining the nature, timing, and extent of audit tests applied in our audit of the 2023 consolidated financial statements, and our opinion regarding the effectiveness of the Company’s internal control over financial reporting does not affect our opinion on those consolidated financial statements.

[0000833444-23-000048:auditors_report:8]
Basis for Opinions

[0000833444-23-000048:auditors_report:9]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting included in management’s report referred to above. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000833444-23-000048:auditors_report:10]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0000833444-23-000048:auditors_report:11]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0000833444-23-000048:auditors_report:12]
As described in Management’s Report on Internal Control Over Financial Reporting, management has excluded FM:Systems from its assessment of internal control over financial reporting as of September 30, 2023 because it was acquired by the Company in a purchase business combination in July 2023. We have also excluded FM:Systems from our audit of internal

[0000833444-23-000048:auditors_report:13]
48

[0000833444-23-000048:auditors_report:14]
control over financial reporting. FM:Systems is a wholly-owned subsidiary whose total assets and total revenues excluded from management’s assessment and our audit of internal control over financial reporting represent less than 1% of each of the related consolidated financial statement amounts as of and for the year ended September 30, 2023.

[0000833444-23-000048:auditors_report:15]
Definition and Limitations of Internal Control over Financial Reporting

[0000833444-23-000048:auditors_report:16]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000833444-23-000048:auditors_report:17]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000833444-23-000048:auditors_report:18]
Critical Audit Matters

[0000833444-23-000048:auditors_report:19]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0000833444-23-000048:auditors_report:20]
Revenue Recognition from Certain Contracts with Customers

[0000833444-23-000048:auditors_report:21]
As described in Notes 1 and 4 to the consolidated financial statements, the Company recognized $26,793 million of net sales for the year ended September 30, 2023, of which a majority relates to certain over time and point in time contracts with customers. Revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services is recognized on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and estimated losses are recorded when identified. The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term. Revenue associated with the sale of equipment and related installations are recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. In other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

[0000833444-23-000048:auditors_report:22]
The principal considerations for our determination that performing procedures relating to revenue recognition from certain contracts with customers is a critical audit matter are a high degree of auditor effort in performing procedures and evaluating audit evidence related to the revenue recognized on certain of the Company's over time and point in time contracts with customers.

[0000833444-23-000048:auditors_report:23]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the revenue recognition process for the Company’s over time and point in time contracts with customers. These procedures also included, among others, evaluating the appropriateness of the timing and amount of revenue recognized for a sample of over time and point in time contracts with customers. Evaluating the appropriateness of the timing and amount of revenue recognized for certain over time contracts with customers involved (i) obtaining and inspecting source documents, such as contracts or service tickets, change orders, and evidence of progress towards completion or services delivered; (ii) evaluating the appropriateness of the over time revenue recognition methods; (iii) testing, on a sample basis for certain over time contracts, the costs incurred to date; and (iv) performing a comparison of estimated gross margin in the prior year to gross margin at

[0000833444-23-000048:auditors_report:24]
49

[0000833444-23-000048:auditors_report:25]
completion of the arrangement in the current year for certain over time contracts with customers. Evaluating the appropriateness of the timing and amount of revenue recognized for certain point in time contracts with customers involved (i) obtaining and inspecting source documents, such as contracts or purchase orders, evidence of goods delivered, and consideration received in exchange for those goods and (ii) evaluating the appropriateness of the point in time revenue recognition method.

[0000833444-23-000048:auditors_report:26]
| /s/ PricewaterhouseCoopers LLP |
| Milwaukee, Wisconsin |
| December 14, 2023 |

[0000833444-23-000048:auditors_report:27]
We have served as the Company’s auditor since 1957.

[0000833444-23-000048:auditors_report:28]
50

[0000833444-23-000048:auditors_report:29]
Johnson Controls International plc


## item_9a

[0000833444-23-000048:item_9a:1]
ITEM 9A    CONTROLS AND PROCEDURES

[0000833444-23-000048:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0000833444-23-000048:item_9a:3]
The Company’s management, with the participation of the Company’s Chief Executive Officer and Chief Financial Officer, has evaluated the effectiveness of the Company’s disclosure controls and procedures (as such term is defined in Rule 13a-15(e) under the Securities Exchange Act of 1934, as amended (the "Exchange Act")) as of September 30, 2023. The Company’s disclosure controls and procedures are designed to ensure that information required to be disclosed by the Company in the reports it files or submits under the Exchange Act, is recorded, processed, summarized and reported, within the time periods specified in the Commissions’ rules and forms, and that such information is accumulated and communicated to the Company’s management, including the Company’s Chief Executive Officer and Chief Financial Officer, as appropriate to allow timely decisions regarding required disclosure. Based on such evaluations, the Company’s Chief Executive Officer and Chief Financial Officer have concluded that, as of September 30, 2023, the Company’s disclosure controls and procedures were not effective because of the material weakness in its internal control over financial reporting described below.

[0000833444-23-000048:item_9a:4]
Notwithstanding the material weakness in internal control over financial reporting described below, management believes and has concluded that the consolidated financial statements included in this Annual Report on Form 10-K fairly present, in all material respects, the Company’s financial position, results of operations and cash flows for the periods presented in conformity with U.S. generally accepted accounting principles.

[0000833444-23-000048:item_9a:5]
Management’s Report on Internal Control Over Financial Reporting

[0000833444-23-000048:item_9a:6]
The Company’s management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rule 13a-15(f). The Company’s management, with the participation of the Company’s Chief Executive Officer and Chief Financial Officer, has evaluated the effectiveness of the Company’s internal control over financial reporting based on the framework in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this evaluation, due to the material weakness described below, the Company’s management has concluded that, as of September 30, 2023, the Company did not maintain effective internal control over financial reporting. A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of its financial statements will not be prevented or detected on a timely basis.

[0000833444-23-000048:item_9a:7]
The Company did not maintain sufficient information technology controls to prevent or detect, on a timely basis, unauthorized access to certain of its financial reporting systems. Specifically, the Company did not design and maintain effective controls related to access monitoring, intrusion detection and response capability, patch management and backup and recovery such that recovery from a cybersecurity incident could be performed in a timely manner. This material weakness could result in a material misstatement to the annual or interim consolidated financial statements that would not be prevented or detected. However, this material weakness did not result in a misstatement to the annual or interim consolidated financial statements previously filed or included in this Annual Report on Form 10-K.

[0000833444-23-000048:item_9a:8]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000833444-23-000048:item_9a:9]
Management has excluded FM:Systems, which the Company acquired in July 2023, from its assessment of internal control over financial reporting as of September 30, 2023. FM:Systems is a wholly owned subsidiary of the Company whose total assets and total revenues excluded from management's assessment represented less than 1% each of the related consolidated financial statement amounts for the Company as of and for the year ended September 30, 2023.

[0000833444-23-000048:item_9a:10]
PricewaterhouseCoopers LLP, an independent registered public accounting firm, has audited the effectiveness of the Company's internal control over financial reporting as of September 30, 2023 as stated in its report which is included in Item 8 of this Form 10-K.

[0000833444-23-000048:item_9a:11]
107

[0000833444-23-000048:item_9a:12]
Remediation Plan for Material Weakness in Internal Control Over Financial Reporting

[0000833444-23-000048:item_9a:13]
The Company is committed to remediating the above noted material weakness and has actively implemented measures designed to help ensure the material weakness is remediated as soon as possible. Although some remediation measures have been completed, other actions with respect to the Company’s remediation plan are ongoing and include, among other things, the following:

[0000833444-23-000048:item_9a:14]
•engaging security specialists to assist in the review, assessment and remediation of the Company's IT controls;

[0000833444-23-000048:item_9a:15]
•additional strengthening of access requirements and unauthorized access detection to the Company's financial reporting systems; and

[0000833444-23-000048:item_9a:16]
•implementing additional procedures to facilitate more effective backup and recovery of the Company's financial reporting systems.

[0000833444-23-000048:item_9a:17]
Though the remediation plan is subject to continual review and revision, the Company expects the remediation plan described above will address the identified material weakness. The remediation plan is subject to oversight by the Audit Committee of the Board of Directors and the identified material weakness will not be considered remediated until the remediation plan has been fully implemented, the applicable controls operate for a sufficient period of time, and the Company has concluded that newly implemented controls are operating effectively.

[0000833444-23-000048:item_9a:18]
Changes in Internal Control Over Financial Reporting

[0000833444-23-000048:item_9a:19]
There were no changes in the Company’s internal control over financial reporting during the quarter ended September 30, 2023, that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.
