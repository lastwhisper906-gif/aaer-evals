# JCI MD&A — 0000833444-23-000014


## mdna

[0000833444-23-000014:mdna:1]
[same as prior period, unchanged from 0000833444-23-000005:mdna:1]

[0000833444-23-000014:mdna:2]
[same as prior period, unchanged from 0000833444-23-000005:mdna:2]

[0000833444-23-000014:mdna:3]
[same as prior period, unchanged from 0000833444-23-000005:mdna:3]

[0000833444-23-000014:mdna:4]
[same as prior period, unchanged from 0000833444-23-000005:mdna:4]

[0000833444-23-000014:mdna:5]
[same as prior period, unchanged from 0000833444-23-000005:mdna:5]

[0000833444-23-000014:mdna:6]
[same as prior period, unchanged from 0000833444-23-000005:mdna:6]

[0000833444-23-000014:mdna:7]
[same as prior period, unchanged from 0000833444-23-000005:mdna:7]

[0000833444-23-000014:mdna:8]
The following information should be read in conjunction with the September 30, 2022 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2022 filed with the SEC on November 15, 2022. References in the following discussion and analysis to "Three Months" (or similar language) refer to the three months ended March 31, 2023 compared to the three months ended March 31, 2022, while "Year-to-Date" refers to the six months ended March 31, 2023 compared to the six months ended March 31, 2022.

[0000833444-23-000014:mdna:9]
[same as prior period, unchanged from 0000833444-23-000005:mdna:9]

[0000833444-23-000014:mdna:10]
Much of the demand for the Company’s products and solutions is driven by construction, facility expansion, retrofit and maintenance projects within the commercial, institutional, industrial, data center, governmental and residential sectors. Construction projects are heavily dependent on general economic conditions, localized demand for real estate and the availability of credit, public funding or other financing sources. Positive or negative fluctuations in construction, industrial facility expansion, retrofit activity, maintenance projects and other capital investments in buildings within the sectors that the Company serves, as well as availability of credit, financing or funding for such projects, could have a corresponding impact on the Company’s financial condition, results of operations and cash flows.

[0000833444-23-000014:mdna:11]
As a result of the Company’s global presence, a significant portion of its revenues and expenses is denominated in currencies other than the U.S. dollar. The Company is therefore subject to non-U.S. currency risks and non-U.S. exchange exposure. While the Company employs financial instruments to hedge some of its transactional foreign exchange exposure, these activities do not insulate it completely from those exposures. In addition, the currency exposure from the translation of non-U.S. dollar functional currency subsidiaries are not able to be hedged. Exchange rates can be volatile and a substantial weakening or strengthening of foreign currencies against the U.S. dollar could increase or reduce the Company’s profit margin, respectively, and impact the comparability of results from period to period. During the three and six months ended March 31, 2023, revenue and profits were adversely impacted due to the strengthening of the U.S. dollar against foreign currencies.

[0000833444-23-000014:mdna:12]
The Company continues to observe trends demonstrating increased interest and demand for its products and services that enable smart, safe, efficient and sustainable buildings. This demand is driven in part by government tax incentives, building performance standards and other regulations designed to limit emissions and combat climate change. In particular, legislative and regulatory initiatives such as the U.S. Climate Smart Buildings Initiative, U.S. Inflation Reduction Act and EU Energy Performance of Buildings Directive include provisions designed to fund and encourage investment in decarbonization and digital technologies for buildings. This demand is supplemented by an increase in commitments in both the public and private sectors to reduce emissions and/or achieve net zero emissions. The Company seeks to capitalize on these trends to drive growth by developing and delivering technologies and solutions to create smart, sustainable and healthy buildings. The Company is investing in new digital and product capabilities, including its OpenBlue platform, to enable it to deliver sustainable, high-efficiency products and tailored services to enable customers to achieve their sustainability goals. The Company is leveraging its install base, together with data-driven products and services, to offer outcome-based solutions to customers with a focus on generating accelerated growth in services and recurring revenue.

[0000833444-23-000014:mdna:13]
The Company has experienced, and could continue to experience, increased material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends, including increased global demand, the conflict between Russia and Ukraine, government-mandated actions in response to COVID-19, particularly in China, and labor shortages. Actions taken by the Company to mitigate supply chain disruptions and inflation, including expanding and redistributing its supplier network, supplier financing, price increases and productivity improvements, have generally been successful in offsetting some, but not all, of the impact of these trends. The collective impact of these trends has been favorable to revenue due to increased demand and price increases to offset inflation, while negatively impacting margins due to supply chain disruptions and cost pressures. However, the Company is beginning to observe improved margins as supply chain disruptions ease and higher priced backlog is converted to sales. Although the Company has experienced recent improvement in its supply chain, the Company could experience further disruptions, shortages and cost increases in the future, the effect of which will depend on the Company’s ability to successfully mitigate and offset the impact of these events.

[0000833444-23-000014:mdna:14]
[same as prior period, unchanged from 0000833444-23-000005:mdna:14]

[0000833444-23-000014:mdna:15]
[same as prior period, unchanged from 0000833444-23-000005:mdna:48]

[0000833444-23-000014:mdna:16]
[same as prior period, unchanged from 0000833444-23-000005:mdna:16]

[0000833444-23-000014:mdna:17]
The COVID-19 pandemic has and could continue to impact aspects of the Company's operations and results. Recently, the Company’s facilities have generally operated at normal levels. As a result of the pandemic, the Company has seen an increase in demand for its products and solutions that promote building health and optimize customers’ infrastructure. However, the Company's results have been and could continue to be negatively influenced by COVID-19-related trends impacting site access and the labor force, which have and may continue to negatively impact the Company’s revenues and margins. This could include events such as the reinstitution of lockdowns or similar restrictive measures or the occurrence of labor shortages at the Company's facilities.

[0000833444-23-000014:mdna:18]
The extent to which the Company’s results of operations and financial condition are impacted in the future will depend on developments that are highly uncertain and cannot be predicted. See the section entitled "Risk Factors" in Johnson Controls' Annual Report on Form 10-K for the year ended September 30, 2022 filed with the United States Securities and Exchange Commission ("SEC") on November 15, 2022 for additional discussion of risks related to COVID-19.

[0000833444-23-000014:mdna:19]
[same as prior period, unchanged from 0000833444-23-000005:mdna:21]

[0000833444-23-000014:mdna:20]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Net sales | $ | 6,686 |  |  | $ | 6,098 |  |  | 10 | % |  | $ | 12,754 |  |  | $ | 11,960 |  |  | 7 | % |

[0000833444-23-000014:mdna:21]
The increase in consolidated net sales for the three months ended March 31, 2023 was due to higher organic sales ($762 million) and incremental sales from acquisitions ($28 million), partially offset by the unfavorable impact of foreign currency translation ($198 million) and lower sales due to business divestitures ($4 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 13% as compared to the prior year, attributable to increased pricing in response to inflation pressures and higher volumes. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-23-000014:mdna:22]
The increase in consolidated net sales for the six months ended March 31, 2023 was due to higher organic sales ($1,259 million) and incremental sales from acquisitions ($55 million), partially offset by the unfavorable impact of foreign currency translation ($498 million) and lower sales due to business divestitures ($22 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 11% as compared to the prior year, attributable to increased pricing in response to inflation pressures. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-23-000014:mdna:23]
[same as prior period, unchanged from 0000833444-23-000005:mdna:24]

[0000833444-23-000014:mdna:24]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Cost of sales | $ | 4,445 |  |  | $ | 4,141 |  |  | 7 | % |  | $ | 8,422 |  |  | $ | 8,112 |  |  | 4 | % |
| Gross profit | 2,241 |  |  | 1,957 |  |  | 15 | % |  | 4,332 |  |  | 3,848 |  |  | 13 | % |
| % of sales | 33.5 | % |  | 32.1 | % |  |  |  | 34.0 | % |  | 32.2 | % |  |  |

[0000833444-23-000014:mdna:25]
Cost of sales and gross profit increased for the three-month period ended March 31, 2023, and gross profit as a percentage of sales increased by 140 basis points. Gross profit increased due to sales growth and favorable price/cost, partially offset by unfavorable foreign currency translation ($62 million). Gross profit as a percentage of sales increased primarily due to favorable price/cost. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-23-000014:mdna:26]
42

[0000833444-23-000014:mdna:27]
Cost of sales and gross profit increased for the six-month period ended March 31, 2023, and gross profit as a percentage of sales increased by 180 basis points. Gross profit increased due to sales growth and favorable price/cost, partially offset by unfavorable foreign currency translation ($156 million). Gross profit as a percentage of sales increased primarily due to favorable price/cost. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-23-000014:mdna:28]
[same as prior period, unchanged from 0000833444-23-000005:mdna:27]

[0000833444-23-000014:mdna:29]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Selling, general and administrative expenses | $ | 1,579 |  |  | $ | 1,454 |  |  | 9 | % |  | $ | 3,150 |  |  | $ | 2,823 |  |  | 12 | % |
| % of sales | 23.6 | % |  | 23.8 | % |  |  |  | 24.7 | % |  | 23.6 | % |  |  |

[0000833444-23-000014:mdna:30]
Selling, general and administrative expenses ("SG&A") for the three-month period ended March 31, 2023 increased $125 million, and SG&A as a percentage of sales decreased by 20 basis points. The increase in SG&A was primarily due to certain investments to support growth, one-time transaction and separation costs, partially offset by favorable foreign currency translation ($40 million) and the favorable year-over-year impact of net mark-to-market adjustments. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-23-000014:mdna:31]
Selling, general and administrative expenses ("SG&A") for the six-month period ended March 31, 2023 increased $327 million, and SG&A as a percentage of sales increased by 110 basis points. The increase in SG&A was primarily due to certain investments to support growth, one-time transaction and separation costs and a loss associated with a fire at a leased warehouse facility, partially offset by favorable foreign currency translation ($105 million) and the favorable year-over-year impact of net mark-to-market adjustments. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-23-000014:mdna:32]
[same as prior period, unchanged from 0000833444-23-000005:mdna:30]

[0000833444-23-000014:mdna:33]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Restructuring and impairment costs | $ | 418 |  |  | $ | 384 |  |  | 9 | % |  | $ | 763 |  |  | $ | 433 |  |  | 76 | % |

[0000833444-23-000014:mdna:34]
Restructuring and impairment costs for the three-month period ended March 31, 2023 included $210 million of impairment costs related to the Global Retail business classified as held-for-sale, $184 million of goodwill impairment costs related to the Silent-Aire reporting unit, $17 million in severance charges and $7 million in other long-lived asset impairments and other restructuring costs.

[0000833444-23-000014:mdna:35]
Restructuring and impairment costs for the six-month period ended March 31, 2023 included $498 million of impairment costs related to businesses classified as held-for-sale, $184 million of goodwill impairment costs related to the Silent-Aire reporting unit, $47 million in severance charges and $34 million in other long-lived asset impairments and other restructuring costs.

[0000833444-23-000014:mdna:36]
Restructuring and impairment costs for the three and six month periods ended March 31, 2022 included $235 million of goodwill impairment costs related to the North America Retail reporting unit, $86 million of impairment costs related to businesses classified as held-for-sale, and $36 million of impairment related to internal-use software projects that were no longer probable of being completed. In addition, the three and six month periods ended March 31, 2022 included $9 million and $37 million of severance charges, respectively, and $18 million and $39 million, respectively, in other long-lived asset impairments and other restructuring costs.

[0000833444-23-000014:mdna:37]
Refer to Note 4, "Assets and Liabilities Held for Sale," Note 8, "Goodwill and Other Intangible Assets," and Note 17, "Significant Restructuring and Impairment Costs," of the notes to the consolidated financial statements for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-23-000014:mdna:38]
[same as prior period, unchanged from 0000833444-23-000005:mdna:36]

[0000833444-23-000014:mdna:39]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Net financing charges | $ | 71 |  |  | $ | 51 |  |  | 39 | % |  | $ | 138 |  |  | $ | 104 |  |  | 33 | % |

[0000833444-23-000014:mdna:40]
[same as prior period, unchanged from 0000833444-23-000005:mdna:38]

[0000833444-23-000014:mdna:41]
[same as prior period, unchanged from 0000833444-23-000005:mdna:39]

[0000833444-23-000014:mdna:42]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Equity income | $ | 50 |  |  | $ | 42 |  |  | 19 | % |  | $ | 112 |  |  | $ | 112 |  |  | — | % |

[0000833444-23-000014:mdna:43]
The increase in equity income for the three months ended March 31, 2023 was primarily due to higher income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-23-000014:mdna:44]
[same as prior period, unchanged from 0000833444-23-000005:mdna:42]

[0000833444-23-000014:mdna:45]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Income tax provision | $ | 49 |  |  | $ | 58 |  |  | -16 | % |  | $ | 63 |  |  | $ | 129 |  |  | -51 | % |
| Effective tax rate | 22.0 | % |  | 52.7 | % |  |  |  | 16.0 | % |  | 21.5 | % |  |  |

[0000833444-23-000014:mdna:46]
The effective tax rate for the three and six months ended March 31, 2023 decreased as compared to the three and six months ended March 31, 2022 primarily due to higher prior year tax impacts of impairment charges and the prior year establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestiture of its Global Retail business. Refer to Note 18, "Income Taxes," of the notes to the consolidated financial statements for further detail.

[0000833444-23-000014:mdna:47]
[same as prior period, unchanged from 0000833444-23-000005:mdna:46]

[0000833444-23-000014:mdna:48]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Income attributable to noncontrolling interests | $ | 41 |  |  | $ | 41 |  |  | — | % |  | $ | 79 |  |  | $ | 79 |  |  | — | % |

[0000833444-23-000014:mdna:49]
[same as prior period, unchanged from 0000833444-23-000005:mdna:49]

[0000833444-23-000014:mdna:50]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Net income attributable to Johnson Controls | $ | 133 |  |  | $ | 11 |  |  | * |  | $ | 251 |  |  | $ | 392 |  |  | -36 | % |

[0000833444-23-000014:mdna:51]
[same as prior period, unchanged from 0000833444-23-000005:mdna:32]

[0000833444-23-000014:mdna:52]
The increase in net income attributable to Johnson Controls for the three months ended March 31, 2023 was primarily due to higher gross profit, partially offset by higher SG&A, both of which are discussed above. The decrease in net income attributable to Johnson Controls for the six months ended March 31, 2023 was primarily due to higher restructuring and impairment costs and higher SG&A, partially offset by higher gross profit, all of which are discussed above.

[0000833444-23-000014:mdna:53]
Diluted earnings per share attributable to Johnson Controls for the three months ended March 31, 2023 was $0.19 compared to $0.02 for the three months ended March 31, 2022. Diluted earnings per share attributable to Johnson Controls for the six months ended March 31, 2023 was $0.36 compared to $0.56 for the six months ended March 31, 2022.

[0000833444-23-000014:mdna:54]
[same as prior period, unchanged from 0000833444-23-000005:mdna:53]

[0000833444-23-000014:mdna:55]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 151 |  |  | $ | 13 |  |  | * |  | $ | 316 |  |  | $ | 481 |  |  | -34 | % |

[0000833444-23-000014:mdna:56]
[same as prior period, unchanged from 0000833444-23-000005:mdna:81]

[0000833444-23-000014:mdna:57]
The increase in comprehensive income attributable to Johnson Controls for the three months ended March 31, 2023 was due to higher net income attributable to Johnson Controls ($122 million) and an increase in other comprehensive income attributable to Johnson Controls ($16 million) resulting from realized and unrealized gains on derivatives and currency translation adjustments.

[0000833444-23-000014:mdna:58]
The decrease in comprehensive income attributable to Johnson Controls for the six months ended March 31, 2023 was due to lower net income attributable to Johnson Controls ($141 million) and a decrease in other comprehensive income attributable to Johnson Controls ($24 million) resulting from currency translation adjustments and higher realized and unrealized gains on derivatives in the prior year.

[0000833444-23-000014:mdna:59]
[same as prior period, unchanged from 0000833444-23-000005:mdna:56]

[0000833444-23-000014:mdna:60]
Management evaluates the performance of its business units based primarily on segment EBITA, which represents income ns before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-23-000014:mdna:61]
[same as prior period, unchanged from 0000833444-23-000005:mdna:58]

[0000833444-23-000014:mdna:62]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Building Solutions North America | $ | 2,520 |  |  | $ | 2,227 |  |  | 13 | % |  | $ | 4,887 |  |  | $ | 4,379 |  |  | 12 | % |
| Building Solutions EMEA/LA | 1,031 |  |  | 958 |  |  | 8 | % |  | 2,006 |  |  | 1,917 |  |  | 5 | % |
| Building Solutions Asia Pacific | 667 |  |  | 623 |  |  | 7 | % |  | 1,313 |  |  | 1,298 |  |  | 1 | % |
| Global Products | 2,468 |  |  | 2,290 |  |  | 8 | % |  | 4,548 |  |  | 4,366 |  |  | 4 | % |
|  | $ | 6,686 |  |  | $ | 6,098 |  |  | 10 | % |  | $ | 12,754 |  |  | $ | 11,960 |  |  | 7 | % |

[0000833444-23-000014:mdna:63]
Three Months:

[0000833444-23-000014:mdna:64]
•The increase in Building Solutions North America was due to higher prices and volumes ($302 million) and incremental sales related to business acquisitions ($5 million), partially offset by the unfavorable impact of foreign currency translation ($14 million). Excluding the impacts of business acquisitions and foreign currency translation, sales growth was led by double-digit growth in HVAC & Controls and Fire & Security.

[0000833444-23-000014:mdna:65]
•The increase in Building Solutions EMEA/LA was due to higher prices ($104 million) and incremental sales related to business acquisitions ($23 million), partially offset by the unfavorable impact of foreign currency translation ($50 million) and business divestitures ($4 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales growth was led by low double-digit growth in Fire & Security and HVAC & Controls. By region, there was strong organic growth in Europe and Latin America, with more modest growth in the Middle East.

[0000833444-23-000014:mdna:66]
•The increase in Building Solutions Asia Pacific was due to higher prices and volumes ($85 million), partially offset by the unfavorable impact of foreign currency translation ($41 million). Excluding the impacts of foreign currency translation, sales growth was led by continued demand for HVAC & Controls. By region, sales in China rebounded in the quarter, with strong double-digit growth in the service and install businesses.

[0000833444-23-000014:mdna:67]
•The increase in Global Products was due to higher prices and volumes ($271 million), partially offset by the unfavorable impact of foreign currency translation ($93 million). Excluding the impacts of foreign currency translation, sales growth was driven by strong growth in Applied, Fire Detection, Industrial Refrigeration and Commercial HVAC products.

[0000833444-23-000014:mdna:68]
Year-to-Date:

[0000833444-23-000014:mdna:69]
•The increase in Building Solutions North America was due to higher prices and volumes ($525 million) and incremental sales related to business acquisitions ($12 million), partially offset by the unfavorable impact of foreign currency translation ($29 million). Excluding the impacts of business acquisitions and foreign currency translation, sales growth was led by growth in HVAC & Controls and Fire & Security.

[0000833444-23-000014:mdna:70]
•The increase in Building Solutions EMEA/LA was due to higher prices ($207 million) and incremental sales related to business acquisitions ($43 million), partially offset by the unfavorable impact of foreign currency translation ($139 million) and business divestitures ($22 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales growth was led by growth in Fire & Security and HVAC & Controls. By region, there was strong organic growth in Europe, Latin America and the Middle East.

[0000833444-23-000014:mdna:71]
•The increase in Building Solutions Asia Pacific was due to higher prices ($127 million), mostly offset by the unfavorable impact of foreign currency translation ($112 million). Excluding the impacts of foreign currency translation, sales growth was led by continued demand for HVAC & Controls. By region, sales in China grew, with strong growth in the service and install businesses.

[0000833444-23-000014:mdna:72]
•The increase in Global Products was due to the net impact of higher prices and lower volumes ($400 million), partially offset by the unfavorable impact of foreign currency translation ($218 million). Excluding the impacts of foreign

[0000833444-23-000014:mdna:73]
currency translation, sales growth was driven by strong price realization and strong growth in Commercial HVAC, Fire Detection, Applied and Industrial Refrigeration products.

[0000833444-23-000014:mdna:74]
[same as prior period, unchanged from 0000833444-23-000005:mdna:64]

[0000833444-23-000014:mdna:75]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Building Solutions North America | $ | 315 |  |  | $ | 235 |  |  | 34 | % |  | $ | 582 |  |  | $ | 485 |  |  | 20 | % |
| Building Solutions EMEA/LA | 69 |  |  | 79 |  |  | -13 | % |  | 144 |  |  | 183 |  |  | -21 | % |
| Building Solutions Asia Pacific | 79 |  |  | 74 |  |  | 7 | % |  | 147 |  |  | 142 |  |  | 4 | % |
| Global Products | 488 |  |  | 412 |  |  | 18 | % |  | 870 |  |  | 713 |  |  | 22 | % |
|  | $ | 951 |  |  | $ | 800 |  |  | 19 | % |  | $ | 1,743 |  |  | $ | 1,523 |  |  | 14 | % |

[0000833444-23-000014:mdna:76]
Three Months:

[0000833444-23-000014:mdna:77]
•The increase in Building Solutions North America was primarily due to favorable price/cost, volume leverage and productivity savings.

[0000833444-23-000014:mdna:78]
•The decrease in Building Solutions EMEA/LA was primarily due to the unfavorable impact of certain non-recurring items and foreign currency translation ($7 million).

[0000833444-23-000014:mdna:79]
•The increase in Building Solutions Asia Pacific was primarily due to favorable price/cost, partially offset by the unfavorable impact of foreign currency translation ($8 million).

[0000833444-23-000014:mdna:80]
•The increase in Global Products was primarily due to strong price realization and improved productivity, partially offset by the unfavorable impact of foreign currency translation ($10 million).

[0000833444-23-000014:mdna:81]
Year-to-Date:

[0000833444-23-000014:mdna:82]
•The increase in Building Solutions North America was primarily due to favorable price/cost, volume leverage and productivity savings, partially offset by unfavorable project mix.

[0000833444-23-000014:mdna:83]
•The decrease in Building Solutions EMEA/LA was primarily due to the unfavorable impact of foreign currency translation ($16 million) and unfavorable project mix, partially offset by favorable volume leverage and productivity savings.

[0000833444-23-000014:mdna:84]
•The increase in Building Solutions Asia Pacific was primarily due to favorable price/cost, partially offset by the unfavorable impact of foreign currency translation ($18 million).

[0000833444-23-000014:mdna:85]
•The increase in Global Products was primarily due to strong price realization and productivity savings, partially offset by an uninsured loss associated with a fire at a leased warehouse facility and the unfavorable impact of foreign currency translation ($25 million).

[0000833444-23-000014:mdna:86]
[same as prior period, unchanged from 0000833444-23-000005:mdna:70]

[0000833444-23-000014:mdna:87]
The Company’s backlog is applicable to its sales of systems and services. At March 31, 2023, the backlog was $13.0 billion, of which $11.7 billion was attributable to the building solutions (field) business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-23-000014:mdna:88]
At March 31, 2023, remaining performance obligations were $18.8 billion, which is $5.8 billion higher than the Company's backlog of $13.0 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-23-000014:mdna:89]
•Remaining performance obligations include large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which are services to be performed over the building's lifetime with average initial contract terms of 25 to 35 years for the entire term of the contract versus backlog which includes only the lifecycle period of these contracts which approximates five years;

[0000833444-23-000014:mdna:90]
[same as prior period, unchanged from 0000833444-23-000005:mdna:75]

[0000833444-23-000014:mdna:91]
[same as prior period, unchanged from 0000833444-23-000005:mdna:76]

[0000833444-23-000014:mdna:92]
[same as prior period, unchanged from 0000833444-23-000005:mdna:77]

[0000833444-23-000014:mdna:93]
[same as prior period, unchanged from 0000833444-23-000005:mdna:78]

[0000833444-23-000014:mdna:94]
[same as prior period, unchanged from 0000833444-23-000005:mdna:79]

[0000833444-23-000014:mdna:95]
|  | March 31, |  | September 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |
| Current assets | $ | 12,756 |  |  | $ | 11,685 |  |  |  |
| Current liabilities | (12,403) |  |  | (11,239) |  |  |  |
|  | 353 |  |  | 446 |  |  | (21 | %) |
| Less: Cash and cash equivalents | (1,975) |  |  | (2,031) |  |  |  |
| Less: Current assets held for sale | (446) |  |  | (387) |  |  |  |
| Add: Short-term debt | 1,737 |  |  | 669 |  |  |  |
| Add: Current portion of long-term debt | 922 |  |  | 865 |  |  |  |
| Add: Current liabilities held for sale | 316 |  |  | 236 |  |  |  |
| Working capital (as defined) | $ | 907 |  |  | $ | (202) |  |  | * |
| Accounts receivable - net | $ | 6,002 |  |  | $ | 5,528 |  |  | 9 | % |
| Inventories | 3,048 |  |  | 2,510 |  |  | 21 | % |
| Accounts payable | 4,348 |  |  | 4,241 |  |  | 3 | % |

[0000833444-23-000014:mdna:96]
* Measure not meaningful

[0000833444-23-000014:mdna:97]
[same as prior period, unchanged from 0000833444-23-000005:mdna:82]

[0000833444-23-000014:mdna:98]
•The increase in working capital at March 31, 2023 as compared to September 30, 2022, was primarily due to increases in inventory due to supply chain disruptions and softer demand in the residential end market and in accounts receivable.

[0000833444-23-000014:mdna:99]
•The Company’s days sales in accounts receivable at March 31, 2023 and September 30, 2022 were 58 days and 51 days, respectively. There have been no significant adverse changes in the level of overdue receivables or significant changes in revenue recognition methods.

[0000833444-23-000014:mdna:100]
•The Company’s inventory turns for the three months ended March 31, 2023 were lower than the comparable period ended September 30, 2022 primarily due to softer demand in the residential end market and certain other project delays.

[0000833444-23-000014:mdna:101]
•Days in accounts payable at both March 31, 2023 and September 30, 2022 were 85 days.

[0000833444-23-000014:mdna:102]
[same as prior period, unchanged from 0000833444-23-000005:mdna:87]

[0000833444-23-000014:mdna:103]
|  |  | Six Months Ended March 31, |
| (in millions) |  | 2023 |  | 2022 |
| Cash provided by operating activities |  | $ | 18 |  |  | $ | 324 |  |
| Cash used by investing activities |  | (314) |  |  | (332) |  |
| Cash provided by financing activities |  | 262 |  |  | 444 |  |

[0000833444-23-000014:mdna:104]
•The decrease in cash provided by operating activities was primarily due to the timing of accounts payable and accrued liabilities payments, partially offset by a lower cash outflow for inventory and lower net tax payments.

[0000833444-23-000014:mdna:105]
•The decrease in cash used by investing activities was primarily due to slightly lower capital expenditures and less cash paid for acquisitions.

[0000833444-23-000014:mdna:106]
•The decrease in cash provided by financing activities was primarily due to lower cash inflows from net debt and borrowings activity,  partially offset by lower cash outflows for stock repurchases.

[0000833444-23-000014:mdna:107]
[same as prior period, unchanged from 0000833444-23-000005:mdna:92]

[0000833444-23-000014:mdna:108]
|  | March 31, |  | September 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |
| Short-term debt | $ | 1,737 |  |  | $ | 669 |  |  |  |
| Current portion of long-term debt | 922 |  |  | 865 |  |  |  |
| Long-term debt | 7,832 |  |  | 7,426 |  |  |  |
| Total debt | 10,491 |  |  | 8,960 |  |  | 17 | % |
| Less: Cash and cash equivalents | 1,975 |  |  | 2,031 |  |  |  |
| Total net debt | 8,516 |  |  | 6,929 |  |  | 23 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 15,890 |  |  | 16,268 |  |  | (2) | % |
| Total capitalization | $ | 24,406 |  |  | $ | 23,197 |  |  | 5 | % |
| Total net debt as a % of total capitalization | 34.9 | % |  | 29.9 | % |  |  |

[0000833444-23-000014:mdna:109]
[same as prior period, unchanged from 0000833444-23-000005:mdna:94]

[0000833444-23-000014:mdna:110]
[same as prior period, unchanged from 0000833444-23-000005:mdna:95]

[0000833444-23-000014:mdna:111]
•As of March 31, 2023, approximately $3.4 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity, and the economic environment.

[0000833444-23-000014:mdna:112]
•The Company declared a dividend of $0.36 per common share in the quarter ended March 31, 2023 and intends to continue paying dividends throughout fiscal 2023.

[0000833444-23-000014:mdna:113]
49

[0000833444-23-000014:mdna:114]
•The Company believes its capital resources and liquidity position, including cash and cash equivalents of $2.0 billion at March 31, 2023, are adequate to fund operations and meet its obligations for the foreseeable future. The Company expects requirements for working capital, capital expenditures, dividends, minimum pension contributions, debt maturities and any potential acquisitions or stock repurchases in the remainder of fiscal 2023 will be funded from operations, supplemented by short- and long-term borrowings, if required.

[0000833444-23-000014:mdna:115]
–The Company manages its short-term debt position in the U.S. and euro commercial paper and bank loan markets. The Company had $1,554 million and $172 million of commercial paper outstanding as of March 31, 2023 and September 30, 2022, respectively.

[0000833444-23-000014:mdna:116]
–The Company maintains a shelf registration statement with the SEC under which it may issue additional debt securities, ordinary shares, preferred shares, depository shares, warrants purchase contracts and units that may be offered in one or more offerings on terms to be determined at the time of the offering. The Company anticipates that the proceeds of any offering would be used for general corporate purposes, including repayment of indebtedness, acquisitions, additions to working capital, repurchases of ordinary shares, dividends, capital expenditures and investments in the Company's subsidiaries.

[0000833444-23-000014:mdna:117]
–The Company also has the ability to draw on its $2.5 billion revolving credit facility which expires in December 2024 or its $0.5 billion 364-day revolving credit facility which expires in November 2023. There were no draws on the revolving credit facilities as of March 31, 2023 and September 30, 2022.

[0000833444-23-000014:mdna:118]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of March 31, 2023, the Company's credit ratings and outlook were as follows:

[0000833444-23-000014:mdna:119]
[same as prior period, unchanged from 0000833444-23-000005:mdna:104]

[0000833444-23-000014:mdna:120]
[same as prior period, unchanged from 0000833444-23-000005:mdna:105]

[0000833444-23-000014:mdna:121]
•Financial covenants in the Company's revolving credit facilities requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of March 31, 2023, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-23-000014:mdna:122]
•The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2023, the Company believes the long-term rate of return will approximate 8.25%, 3.70% and 6.65% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first six months of fiscal 2023, the Company made approximately $26 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $38 million in cash to its defined benefit pension plans in fiscal 2023. The Company expects to contribute $3 million in cash to its postretirement plans in fiscal 2023.

[0000833444-23-000014:mdna:123]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in fiscal 2022, the Company recorded income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain subsidiaries as a result of the planned divestitures. The Company currently does not

[0000833444-23-000014:mdna:124]
50

[0000833444-23-000014:mdna:125]
intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at its Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-23-000014:mdna:126]
[same as prior period, unchanged from 0000833444-23-000005:mdna:110]

[0000833444-23-000014:mdna:127]
[same as prior period, unchanged from 0000833444-23-000005:mdna:111]

[0000833444-23-000014:mdna:128]
[same as prior period, unchanged from 0000833444-23-000005:mdna:112]

[0000833444-23-000014:mdna:129]
The following information is provided in compliance with Rule 13-01 of Regulation S-X under the Securities Exchange Act of 1934 with respect to the following unsecured, unsubordinated senior notes (collectively, ("the Notes) which were issued by Johnson Controls International plc ("Parent Company") and Tyco Fire & Security Finance S.C.A. (“TFSCA”):

[0000833444-23-000014:mdna:130]
•€500 million aggregate principal amount of 0.375% Senior Notes due 2027

[0000833444-23-000014:mdna:131]
•€600 million aggregate principal amount of 3.000% Senior Notes due 2028

[0000833444-23-000014:mdna:132]
•$625 million aggregate principal amount of 1.750% Senior Notes due 2030

[0000833444-23-000014:mdna:133]
•$500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due 2031

[0000833444-23-000014:mdna:134]
•$400 million aggregate principal amount of 4.900% Senior Notes due 2032

[0000833444-23-000014:mdna:135]
•€500 million aggregate principal amount of 1.000% Senior Notes due 2032

[0000833444-23-000014:mdna:136]
TFSCA is a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”) and is a wholly-owned consolidated subsidiary of the Company that is 99.924% owned directly by the Parent Company and 0.076% owned by TFSCA’s sole general partner and manager, Tyco Fire & Security S.à r.l., which is itself wholly-owned by the Company. The Parent Company is incorporated and organized under the laws of Ireland. TFSCA is incorporated and organized under the laws of Luxembourg. The bankruptcy, insolvency, administrative, debtor relief and other laws of Luxembourg or Ireland, as applicable, may be materially different from, or in conflict with, those of the United States, including in the areas of rights of creditors, priority of governmental and other creditors, ability to obtain post-petition interest and duration of the proceeding. The application of these laws, or any conflict among them, could adversely affect noteholders’ ability to enforce their rights under the Notes in those jurisdictions or limit any amounts that they may receive.

[0000833444-23-000014:mdna:137]
The tables below set forth summarized financial information of the Parent Company and TFSCA (collectively, the “Obligor Group”) on a combined basis after intercompany transactions have been eliminated, including adjustments to remove the receivable and payable balances, investment in, and equity in earnings from, those subsidiaries of the Parent Company other than TFSCA (collectively, the "Non-Obligor Subsidiaries").

[0000833444-23-000014:mdna:138]
51

[0000833444-23-000014:mdna:139]
[same as prior period, unchanged from 0000833444-23-000005:mdna:116]

[0000833444-23-000014:mdna:140]
|  |  | Six Months Ended March 31, 2023 |  | Year EndedSeptember 30, 2022 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Net loss |  | (228) |  |  | (268) |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net loss attributable to the entity |  | (228) |  |  | (268) |  |  |

[0000833444-23-000014:mdna:141]
[same as prior period, unchanged from 0000833444-23-000005:mdna:118]

[0000833444-23-000014:mdna:142]
|  |  | Six Months Ended March 31, 2023 |  | Year EndedSeptember 30, 2022 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Net income (loss) |  | (32) |  |  | 92 |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net income (loss) attributable to the entity |  | (32) |  |  | 92 |  |  |

[0000833444-23-000014:mdna:143]
The following table presents summarized balance sheet information as of March 31, 2023 and September 30, 2022 (in millions):

[0000833444-23-000014:mdna:144]
|  |  | March 31, 2023 |  | September 30, 2022 |  |
| Current assets |  | $ | 22 |  |  | $ | 1,231 |  |  |
| Noncurrent assets |  | 248 |  |  | 243 |  |  |
| Current liabilities |  | 7,493 |  |  | 5,463 |  |  |
| Noncurrent liabilities |  | 7,571 |  |  | 7,176 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-23-000014:mdna:145]
[same as prior period, unchanged from 0000833444-23-000005:mdna:122]

[0000833444-23-000014:mdna:146]
|  |  | March 31, 2023 |  | September 30, 2022 |  |
| Current assets |  | $ | 1,926 |  |  | $ | 455 |  |  |
| Noncurrent assets |  | 1,947 |  |  | 2,952 |  |  |
| Current liabilities |  | 6,401 |  |  | 2,538 |  |  |
| Noncurrent liabilities |  | 6,354 |  |  | 6,228 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-23-000014:mdna:147]
[same as prior period, unchanged from 0000833444-23-000005:mdna:124]

[0000833444-23-000014:mdna:148]
[same as prior period, unchanged from 0000833444-23-000005:mdna:126]

[0000833444-23-000014:mdna:149]
[same as prior period, unchanged from 0000833444-23-000005:mdna:127]

[0000833444-23-000014:mdna:150]
[same as prior period, unchanged from 0000833444-23-000005:mdna:128]

[0000833444-23-000014:mdna:151]
[same as prior period, unchanged from 0000833444-23-000005:mdna:129]
