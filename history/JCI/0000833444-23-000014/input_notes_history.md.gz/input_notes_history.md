# JCI note change history — 0000833444-23-000005 → 0000833444-23-000014


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000833444-23-000014:note_history:1]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 42 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 223 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 265 |  |  | $ | 286 |  |
  (was, 2023-02-01, similarity 0.9731):
[0000833444-23-000005:note_history:1]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current liabilities | $ | 48 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 227 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 275 |  |  | $ | 286 |  |

- changed (2023-05-05):
[0000833444-23-000014:note_history:2]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. During the three months ended September 30, 2022, with the assistance of independent environmental consultants and taking into consideration investigation and remediation actions previously completed, new information available to the Company during the fourth quarter of fiscal 2022 and ongoing discussions with the Wisconsin Department of Natural Resources ("WDNR"), the Company completed a comprehensive long-term analysis and cost assessment related to the Company’s ongoing environmental remediation obligations. As a result of this analysis, the Company increased its accrual for environmental liabilities by $228 million in the fourth quarter of fiscal 2022, which are recorded on an undiscounted basis. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.
  (was, 2023-02-01, similarity 0.7562):
[0000833444-23-000005:note_history:2]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. During the three months ended September 30, 2022, with the assistance of independent environmental consultants and taking into consideration investigation and remediation actions previously completed, new information available to the Company during the fourth quarter of fiscal 2022 and ongoing discussions with the Wisconsin Department of Natural Resources ("WDNR"), the Company completed a comprehensive long-term analysis and cost assessment related to the Company’s ongoing environmental remediation obligations. As a result of this analysis, the Company increased its accrual for environmental liabilities by $228 million, which are recorded on an undiscounted basis. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

- changed (2023-05-05):
[0000833444-23-000014:note_history:3]
A substantial portion of the increase to the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to fire-fighting foams containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The increase in reserves was recorded as a result of several events that occurred in the three months ended September 30, 2022, including the completion and testing of the Groundwater Extraction and Treatment System (“GETS”) at the FTC (as further discussed below), the completion of resident surveys in Peshtigo regarding long-term drinking water solutions, correspondence with regulators on planned remediation activities, finalization of cost estimates for system upgrades and related long-term run rate costs in response to new permit requirements at the Stanton
  (was, 2023-02-01, similarity 0.917):
[0000833444-23-000005:note_history:3]
A substantial portion of the increase to the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to fire-fighting foams containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The increase in reserves was recorded as a result of several events that occurred in the three months ended September 30, 2022, including the completion and testing of the Groundwater Extraction and Treatment System (“GETS”) at the FTC (as further discussed below), the completion of resident surveys in Peshtigo regarding long-term drinking water solutions, correspondence with regulators on planned remediation activities, finalization of cost estimates for system upgrades and related long-term run rate costs in response to new permit requirements at the Stanton Street Facility, and the development of additional information through ongoing investigation and analysis. These events allowed the Company to develop estimates of costs associated with the long-term remediation actions expected to be

- added (2023-05-05):
[0000833444-23-000014:note_history:4]
Street Facility, and the development of additional information through ongoing investigation and analysis. These events allowed the Company to develop estimates of costs associated with the long-term remediation actions expected to be performed over an estimated period of up to 20 years, including the continued operation of the GETS, the implementation of long-term drinking water solutions, continued monitoring and testing of the wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

- changed (2023-05-05):
[0000833444-23-000014:note_history:5]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports, or elsewhere. In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, the WDNR approved Tyco Fire Products’ proposed GETS, a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has completed construction of the GETS, which is now in operation. Tyco Fire Products is also in the process of completing the removal and disposal of PFAS-affected soil from the FTC. In December 2022, Tyco Fire Products also began implementation of a long-term drinking water solution for some Peshtigo residents with the installation of the first deep aquifer private drinking wells.
  (was, 2023-02-01, similarity 0.9728):
[0000833444-23-000005:note_history:5]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports, or elsewhere. In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, the WDNR approved Tyco Fire Products’ proposed GETS, a permanent groundwater remediation system that will extract groundwater that contains PFAS, treat it using advanced filtration systems, and return the treated water to the environment. Tyco Fire Products has completed construction of the GETS, which is now in operation. Tyco Fire Products is also in the process of completing the removal and disposal of PFAS-affected soil from the FTC. In December 2022, Tyco Fire Products also began implementation of a long-term drinking water solution for some Peshtigo residents with the installation of the first deep aquifer private drinking wells.

- changed (2023-05-05):
[0000833444-23-000014:note_history:6]
PFOA, PFOS, and other PFAS compounds are being studied by EPA and other environmental and health agencies and researchers. EPA initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water and in June 2022 an updated set of interim health advisory levels for PFOA and PFOS in drinking water, as well as final health advisory levels for two other types of PFAS (PFBS and GenX chemicals). In November 2022, EPA added a class definition of PFAS to the final version of EPA's fifth Contaminant Candidate List (CCL 5), which is a list of substances not currently subject to national drinking water regulation, but which EPA believes may require future regulation. In March 2023, EPA announced a proposed National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR proposes establishing legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion for each of PFOA and PFOS. EPA indicated that it anticipates finalizing the regulation by the end of 2023.
  (was, 2023-02-01, similarity 0.7678):
[0000833444-23-000005:note_history:6]
PFOA, PFOS, and other PFAS compounds are being studied by EPA and other environmental and health agencies and researchers. EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. While those studies continue, EPA issued in June 2022 an updated set of interim health advisory levels for PFOA and PFOS in drinking water, as well as final health advisory levels for two other types of PFAS (PFBS and GenX chemicals). In November 2022, EPA added a class definition of PFAS to the final version of EPA's fifth Contaminant Candidate List (CCL 5), which is a list of substances not currently subject to national drinking water regulation, but which EPA believes may require future regulation.

- changed (2023-05-05):
[0000833444-23-000014:note_history:7]
In October 2021, EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act (“CERCLA”) hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains. In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under CERCLA.
  (was, 2023-02-01, similarity 0.9956):
[0000833444-23-000005:note_history:7]
In October 2021, EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains. In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under CERCLA.

- added (2023-05-05):
[0000833444-23-000014:note_history:8]
It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- changed (2023-05-05):
[0000833444-23-000014:note_history:9]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $17 million at both March 31, 2023 and September 30, 2022.
  (was, 2023-02-01, similarity 0.9787):
[0000833444-23-000005:note_history:9]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $17 million at both December 31, 2022 and September 30, 2022.

- changed (2023-05-05):
[0000833444-23-000014:note_history:10]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. In September 2022, the Governor of Wisconsin signed a scope statement setting out parameters for the WDNR to draft a final rule regarding groundwater quality standards for PFOA and PFOS, among other compounds. The WDNR is now in the process of drafting the rule.
  (was, 2023-02-01, similarity 0.9943):
[0000833444-23-000005:note_history:10]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin recently approved final regulatory standards for PFOA and PFOS in drinking water and surface water, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. In September 2022, the Governor of Wisconsin signed a scope statement setting out parameters for the WDNR to draft a final rule regarding groundwater quality standards for PFOA and PFOS, among other compounds. The WDNR is now in the process of drafting the rule.

- changed (2023-05-05):
[0000833444-23-000014:note_history:11]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products responded to the WDNR’s letter by requesting additional necessary information. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. Tyco Fire Products responded to the WDNR’s September 2021 notice by the December 27, 2021 deadline set by WDNR and submitted additional updates to WDNR on October 25, 2022 and February 16, 2023. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.
  (was, 2023-02-01, similarity 0.7812):
[0000833444-23-000005:note_history:11]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products responded to the WDNR’s letter by requesting additional necessary information. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to date. Tyco Fire Products responded to the WDNR’s September 2021 notice by the December 27, 2021 deadline set by WDNR and submitted a Land Applied Biosolids Interim Site Status Update Report to WDNR on October 25, 2022. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

- changed (2023-05-05):
[0000833444-23-000014:note_history:12]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR’s requests. The parties are proceeding with fact discovery and the court has
  (was, 2023-02-01, similarity 0.7742):
[0000833444-23-000005:note_history:12]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR’s requests. The lawsuit is presently at the beginning stages of litigation: Tyco Fire Products and Johnson Controls, Inc. each filed Answers to the Complaint on April 4, 2022 and the parties are proceeding with initial fact discovery. The Company is vigorously defending this civil enforcement action and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

- added (2023-05-05):
[0000833444-23-000014:note_history:13]
set a trial date of December 3, 2024. The Company is vigorously defending this civil enforcement action and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

- changed (2023-05-05):
[0000833444-23-000014:note_history:14]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. These lawsuits are presently at the beginning stages of litigation. The Company is vigorously defending these cases and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.
  (was, 2023-02-01, similarity 0.9227):
[0000833444-23-000005:note_history:14]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits were removed to federal court on December 21, 2022, and were tagged to the MDL on December 22, 2022. The Plaintiffs have opposed removal and transfer to the MDL. These lawsuits are presently at the beginning stages of litigation. The Company is vigorously defending these cases and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

- added (2023-05-05):
[0000833444-23-000014:note_history:15]
Chemguard and Tyco Fire Products are named in 39 pending putative class actions in federal courts originating from 15 states and territories. All but two of these cases have been direct-filed in or transferred to the MDL and it is anticipated that the remaining cases will be transferred to the MDL.

- changed (2023-05-05):
[0000833444-23-000014:note_history:16]
There are more than 3,900 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 3,900 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and
  (was, 2023-02-01, similarity 0.9238):
[0000833444-23-000005:note_history:16]
There are more than 3,100 individual or “mass” actions pending that were filed in state or federal courts originating from 51 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 3,100 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona and Illinois.

- added (2023-05-05):
[0000833444-23-000014:note_history:17]
transferred. There are several matters that are proceeding in state courts, including actions in Arizona and Illinois.

- changed (2023-05-05):
[0000833444-23-000014:note_history:18]
Chemguard and Tyco Fire Products have been named as defendants in more than 350 cases involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 30 states. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation. The MDL court has set the first case for trial on June 5, 2023, (City of Stuart (Florida) v. 3M Co. et al.). On April 26, 2023, the parties entered a stipulation dismissing Chemguard with prejudice from the City of Stuart case, and it is expected that the parties will enter into a stipulation dismissing Tyco with prejudice from the City of Stuart case. The MDL Court has ordered the parties to conduct mediation of the water provider cases pending in the MDL.
  (was, 2023-02-01, similarity 0.7871):
[0000833444-23-000005:note_history:18]
Chemguard and Tyco Fire Products have been named as defendants in more than 290 cases involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 27 states. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation. The MDL Court has set the first case for trial on June 4, 2023, (City of Stuart (Florida) v. 3M Co. et al.) and has ordered the parties to conduct mediation of the water provider cases pending in the MDL.

- added (2023-05-05):
[0000833444-23-000014:note_history:19]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting

- changed (2023-05-05):
[0000833444-23-000014:note_history:20]
from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.
  (was, 2023-02-01, similarity 0.6887):
[0000833444-23-000005:note_history:20]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

- changed (2023-05-05):
[0000833444-23-000014:note_history:21]
In April 2022, the Attorney General of the State of Florida filed a lawsuit in Florida state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage to the State’s natural resources and public health allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.
  (was, 2023-02-01, similarity 0.9328):
[0000833444-23-000005:note_history:21]
In April 2022, the Attorney General of the State of Florida filed a lawsuit in Florida state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage to the State’s natural resources and public health allegedly resulting from the use of firefighting foams at various locations throughout the State. It is anticipated that this complaint will be removed to federal court and transferred to the MDL.

- changed (2023-05-05):
[0000833444-23-000014:note_history:22]
In May 2022, the Attorney General of the Commonwealth of Massachusetts filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the
  (was, 2023-02-01, similarity 0.6636):
[0000833444-23-000005:note_history:22]
In May 2022, the Attorney General of the Commonwealth of Massachusetts filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s natural resources, property, residents, and consumers allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

- added (2023-05-05):
[0000833444-23-000014:note_history:23]
State’s natural resources, property, residents, and consumers allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

- changed (2023-05-05):
[0000833444-23-000014:note_history:24]
In November 2022, the Attorney General of the State of California filed a lawsuit in California state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the manufacture, use, marketing, or sale of PFAS-containing products, including firefighting foams, at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.
  (was, 2023-02-01, similarity 0.8968):
[0000833444-23-000005:note_history:24]
In November 2022, the Attorney General of the State of California filed a lawsuit in California state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the manufacture, use, marketing, or sale of PFAS-containing products, including firefighting foams, at various locations throughout the State. On December 20, 2022, the case was removed to federal court and tagged to the MDL. The Attorney General has opposed removal and transfer.

- added (2023-05-05):
[0000833444-23-000014:note_history:25]
In March 2023, the Attorney General of the State of Maine filed a lawsuit in Maine state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of the State’s natural resources allegedly resulting from the manufacture, distribution, release, promotion, sale, and use of PFAS-containing AFFF within the state. It is anticipated that this complaint will be removed to federal court and transferred to the MDL.

- added (2023-05-05):
[0000833444-23-000014:note_history:26]
In March 2023, the Attorney General of the State of Illinois filed a lawsuit in Illinois state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of the State’s environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within the State. It is anticipated that this complaint will be removed to federal court and transferred to the MDL.

- changed (2023-05-05):
[0000833444-23-000014:note_history:27]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.
  (was, 2023-02-01, similarity 0.9947):
[0000833444-23-000005:note_history:27]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

- added (2023-05-05):
[0000833444-23-000014:note_history:28]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 370 |  |  | 380 |  |
| Total asbestos-related liabilities | 428 |  |  | 438 |  |
| Other current assets | 37 |  |  | 37 |  |
| Other noncurrent assets | 275 |  |  | 263 |  |
| Total asbestos-related assets | 312 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 116 |  |  | $ | 138 |  |

- added (2023-05-05):
[0000833444-23-000014:note_history:29]
|  | March 31, 2023 |  | September 30, 2022 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 253 |  |  | 239 |  |
| Total restricted assets | 259 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 53 |  |  | 55 |  |
| Total asbestos-related assets | $ | 312 |  |  | $ | 300 |  |

- added (2023-05-05):
[0000833444-23-000014:note_history:30]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and

- changed (2023-05-05):
[0000833444-23-000014:note_history:31]
assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.
  (was, 2023-02-01, similarity 0.9165):
[0000833444-23-000005:note_history:31]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

- changed (2023-05-05):
[0000833444-23-000014:note_history:32]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 92 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 233 |  |  | 230 |  |
| Total self-insured liabilities | $ | 347 |  |  | $ | 341 |  |
  (was, 2023-02-01, similarity 0.9773):
[0000833444-23-000005:note_history:32]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current liabilities | $ | 112 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 230 |  |  | 230 |  |
| Total self-insured liabilities | $ | 364 |  |  | $ | 341 |  |

- changed (2023-05-05):
[0000833444-23-000014:note_history:33]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current assets | $ | 10 |  |  | $ | 10 |  |
| Other noncurrent assets | 20 |  |  | 20 |  |
| Total insurance receivables | $ | 30 |  |  | $ | 30 |  |
  (was, 2023-02-01, similarity 0.9746):
[0000833444-23-000005:note_history:33]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current assets | $ | 10 |  |  | $ | 10 |  |
| Other noncurrent assets | 20 |  |  | 20 |  |
| Total insurance receivables | $ | 30 |  |  | $ | 30 |  |

- removed (2023-05-05):
[0000833444-23-000005:note_history:34]
performed over an estimated period of up to 20 years, including the continued operation of the GETS, the implementation of long-term drinking water solutions, continued monitoring and testing of the wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

- removed (2023-05-05):
[0000833444-23-000005:note_history:35]
It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of

- removed (2023-05-05):
[0000833444-23-000005:note_history:36]
the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- removed (2023-05-05):
[0000833444-23-000005:note_history:37]
Chemguard and Tyco Fire Products are named in 34 pending putative class actions in federal courts originating from 15 states and territories. All but one of these cases have been direct-filed in or transferred to the MDL and it is anticipated that the remaining case will be transferred to the MDL.

- removed (2023-05-05):
[0000833444-23-000005:note_history:38]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 375 |  |  | 380 |  |
| Total asbestos-related liabilities | 433 |  |  | 438 |  |
| Other current assets | 39 |  |  | 37 |  |
| Other noncurrent assets | 267 |  |  | 263 |  |
| Total asbestos-related assets | 306 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 127 |  |  | $ | 138 |  |

- removed (2023-05-05):
[0000833444-23-000005:note_history:39]
|  | December 31, 2022 |  | September 30, 2022 |
| Restricted |  |  |  |
| Cash | $ | 8 |  |  | $ | 6 |  |
| Investments | 244 |  |  | 239 |  |
| Total restricted assets | 252 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 54 |  |  | 55 |  |
| Total asbestos-related assets | $ | 306 |  |  | $ | 300 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000833444-23-000014:note_history:40]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 42 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 223 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 265 |  |  | $ | 286 |  |
  (was, 2023-02-01, similarity 0.9731):
[0000833444-23-000005:note_history:40]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current liabilities | $ | 48 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 227 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 275 |  |  | $ | 286 |  |

- added (2023-05-05):
[0000833444-23-000014:note_history:41]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 370 |  |  | 380 |  |
| Total asbestos-related liabilities | 428 |  |  | 438 |  |
| Other current assets | 37 |  |  | 37 |  |
| Other noncurrent assets | 275 |  |  | 263 |  |
| Total asbestos-related assets | 312 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 116 |  |  | $ | 138 |  |

- added (2023-05-05):
[0000833444-23-000014:note_history:42]
|  | March 31, 2023 |  | September 30, 2022 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 253 |  |  | 239 |  |
| Total restricted assets | 259 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 53 |  |  | 55 |  |
| Total asbestos-related assets | $ | 312 |  |  | $ | 300 |  |

- changed (2023-05-05):
[0000833444-23-000014:note_history:43]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 92 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 233 |  |  | 230 |  |
| Total self-insured liabilities | $ | 347 |  |  | $ | 341 |  |
  (was, 2023-02-01, similarity 0.9773):
[0000833444-23-000005:note_history:43]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current liabilities | $ | 112 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 230 |  |  | 230 |  |
| Total self-insured liabilities | $ | 364 |  |  | $ | 341 |  |

- changed (2023-05-05):
[0000833444-23-000014:note_history:44]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current assets | $ | 10 |  |  | $ | 10 |  |
| Other noncurrent assets | 20 |  |  | 20 |  |
| Total insurance receivables | $ | 30 |  |  | $ | 30 |  |
  (was, 2023-02-01, similarity 0.9746):
[0000833444-23-000005:note_history:44]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current assets | $ | 10 |  |  | $ | 10 |  |
| Other noncurrent assets | 20 |  |  | 20 |  |
| Total insurance receivables | $ | 30 |  |  | $ | 30 |  |

- removed (2023-05-05):
[0000833444-23-000005:note_history:45]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 375 |  |  | 380 |  |
| Total asbestos-related liabilities | 433 |  |  | 438 |  |
| Other current assets | 39 |  |  | 37 |  |
| Other noncurrent assets | 267 |  |  | 263 |  |
| Total asbestos-related assets | 306 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 127 |  |  | $ | 138 |  |

- removed (2023-05-05):
[0000833444-23-000005:note_history:46]
|  | December 31, 2022 |  | September 30, 2022 |
| Restricted |  |  |  |
| Cash | $ | 8 |  |  | $ | 6 |  |
| Investments | 244 |  |  | 239 |  |
| Total restricted assets | 252 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 54 |  |  | 55 |  |
| Total asbestos-related assets | $ | 306 |  |  | $ | 300 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000833444-23-000014:note_history:47]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2022 filed with the SEC on November 15, 2022. The results of operations for the three and six month periods ended March 31, 2023 are not necessarily indicative of results for the Company’s 2023 fiscal year because of seasonal and other factors.
  (was, 2023-02-01, similarity 0.9784):
[0000833444-23-000005:note_history:47]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2022 filed with the SEC on November 15, 2022. The results of operations for the three month period ended December 31, 2022 are not necessarily indicative of results for the Company’s 2023 fiscal year because of seasonal and other factors.

- added (2023-05-05):
[0000833444-23-000014:note_history:48]
Restricted Cash

- added (2023-05-05):
[0000833444-23-000014:note_history:49]
Restricted cash relates to amounts restricted for payment of asbestos liabilities and certain litigation and environmental matters. Restricted cash is recorded primarily within other current assets in the consolidated statements of financial position and totaled $65 million and $35 million at March 31, 2023 and September 30, 2022, respectively. 
Prior Period Revision – Statement of Cash FlowsThe Company revised the amounts previously reported as net proceeds from borrowings with maturities less than three months and proceeds from debt for certain short-term debt transactions that were incorrectly presented on a net basis within the financing activities section of the consolidated statements of cash flows for the six months ended March 31, 2022. Interim and annual amounts for the year ended September 30, 2022 and annual amounts for the years ended September 30, 2021 and 2020 were similarly impacted. Prior period amounts will be revised with future Quarterly Reports on Form 10-Q and Annual Report on Form 10-K filings. Cash provided by financing activities and the total increase (decrease) in cash, cash equivalents and restricted cash were unchanged for all affected periods. The Company does not believe the impact of incorrect presentation is material to any periods.

- removed (2023-05-05):
[0000833444-23-000005:note_history:50]
Restricted Cash
Restricted cash relates to amounts restricted for payment of asbestos liabilities and certain litigation and environmental matters. Restricted cash is recorded within other current assets in the consolidated statements of financial position and totaled $67 million and $35 million at December 31, 2022 and September 30, 2022, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-05-05):
[0000833444-23-000014:note_history:51]
Debt and Financing Arrangements
Short-term debt consisted of the following (in millions):

- added (2023-05-05):
[0000833444-23-000014:note_history:52]
|  | March 31, |  | September 30, |
|  | 2023 |  | 2022 |
| Bank borrowings | $ | 20 |  |  | $ | 10 |  |
| Commercial paper | 1,554 |  |  | 172 |  |
| Term loans | 163 |  |  | 487 |  |
|  | $ | 1,737 |  |  | $ | 669 |  |
| Weighted average interest rate on short-term debt outstanding | 2.9 | % |  | 0.5 | % |

- changed (2023-05-05):
[0000833444-23-000014:note_history:53]
As of March 31, 2023, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in November 2023. As of March 31, 2023, there were no draws on the facilities.
  (was, 2023-02-01, similarity 0.8896):
[0000833444-23-000005:note_history:53]
Debt and Financing Arrangements
As of December 31, 2022, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in November 2023. As of December 31, 2022, there were no draws on the facilities.

- added (2023-05-05):
[0000833444-23-000014:note_history:54]
Financing Activity

- changed (2023-05-05):
[0000833444-23-000014:note_history:55]
In October 2022, the Company repaid a €200 million ($196 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5% and entered into a €150 million ($163 million as of March 31, 2023) term loan with an interest rate of EURIBOR plus 0.7% which is due in April 2024.
  (was, 2023-02-01, similarity 0.9753):
[0000833444-23-000005:note_history:55]
In October 2022, the Company repaid a €200 million ($196 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5% and entered into a €150 million ($161 million as of December 31, 2022) term loan with an interest rate of EURIBOR plus 0.7% which is due in April 2024.

- added (2023-05-05):
[0000833444-23-000014:note_history:56]
In January 2023, the Company repaid $32 million of outstanding 4.625% Notes due 2023.

- added (2023-05-05):
[0000833444-23-000014:note_history:57]
In March 2023, the Company repaid a €150 million ($147 million as of September 30, 2022) term loan with an interest rate of 0.0%, repaid a €135 million ($133 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5% and entered into a €150 million ($163 million as of March 31, 2023) term loan with an interest rate of EURIBOR plus 0.4% which is due March 2024.

- changed (2023-05-05):
[0000833444-23-000014:note_history:58]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest expense, net of capitalized interest costs | $ | 71 |  |  | $ | 56 |  |  | $ | 140 |  |  | $ | 111 |  |
| Other financing charges | 11 |  |  | 5 |  |  | 21 |  |  | 10 |  |
| Interest income | (3) |  |  | (1) |  |  | (7) |  |  | (3) |  |
| Net foreign exchange results for financing activities | (8) |  |  | (9) |  |  | (16) |  |  | (14) |  |
| Net financing charges | $ | 71 |  |  | $ | 51 |  |  | $ | 138 |  |  | $ | 104 |  |
  (was, 2023-02-01, similarity 0.6776):
[0000833444-23-000005:note_history:58]
|  | Three Months Ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 69 |  |  | $ | 55 |  |  |  |  |  |
| Other financing charges | 10 |  |  | 5 |  |  |  |  |  |
| Interest income | (4) |  |  | (2) |  |  |  |  |  |
| Net foreign exchange results for financing activities | (8) |  |  | (5) |  |  |  |  |  |
| Net financing charges | $ | 67 |  |  | $ | 53 |  |  |  |  |  |

- removed (2023-05-05):
[0000833444-23-000005:note_history:59]
The Company had $715 million and $172 million of commercial paper outstanding as of December 31, 2022 and September 30, 2022, respectively.


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2023-05-05):
[0000833444-23-000014:note_history:60]
Short-term debt consisted of the following (in millions):

- added (2023-05-05):
[0000833444-23-000014:note_history:61]
|  | March 31, |  | September 30, |
|  | 2023 |  | 2022 |
| Bank borrowings | $ | 20 |  |  | $ | 10 |  |
| Commercial paper | 1,554 |  |  | 172 |  |
| Term loans | 163 |  |  | 487 |  |
|  | $ | 1,737 |  |  | $ | 669 |  |
| Weighted average interest rate on short-term debt outstanding | 2.9 | % |  | 0.5 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-05-05):
[0000833444-23-000014:note_history:62]
|  |  | Three Months Ended March 31, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,554 |  |  | $ | 966 |  |  | $ | 2,520 |  |  | $ | 1,343 |  |  | $ | 884 |  |  | $ | 2,227 |  |
| Building Solutions EMEA/LA |  | 582 |  |  | 449 |  |  | 1,031 |  |  | 536 |  |  | 422 |  |  | 958 |  |
| Building Solutions Asia Pacific |  | 479 |  |  | 188 |  |  | 667 |  |  | 448 |  |  | 175 |  |  | 623 |  |
| Global Products |  | 2,468 |  |  | — |  |  | 2,468 |  |  | 2,290 |  |  | — |  |  | 2,290 |  |
| Total |  | $ | 5,083 |  |  | $ | 1,603 |  |  | $ | 6,686 |  |  | $ | 4,617 |  |  | $ | 1,481 |  |  | $ | 6,098 |  |

- added (2023-05-05):
[0000833444-23-000014:note_history:63]
|  |  | Six Months Ended March 31, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,005 |  |  | $ | 1,882 |  |  | $ | 4,887 |  |  | $ | 2,642 |  |  | $ | 1,737 |  |  | $ | 4,379 |  |
| Building Solutions EMEA/LA |  | 1,134 |  |  | 872 |  |  | 2,006 |  |  | 1,080 |  |  | 837 |  |  | 1,917 |  |
| Building Solutions Asia Pacific |  | 952 |  |  | 361 |  |  | 1,313 |  |  | 949 |  |  | 349 |  |  | 1,298 |  |
| Global Products |  | 4,548 |  |  | — |  |  | 4,548 |  |  | 4,366 |  |  | — |  |  | 4,366 |  |
| Total |  | $ | 9,639 |  |  | $ | 3,115 |  |  | $ | 12,754 |  |  | $ | 9,037 |  |  | $ | 2,923 |  |  | $ | 11,960 |  |

- changed (2023-05-05):
[0000833444-23-000014:note_history:64]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 1,757 |  |  | $ | 1,658 |  |  | $ | 3,197 |  |  | $ | 3,141 |  |
| Fire & Security |  | 623 |  |  | 578 |  |  | 1,193 |  |  | 1,122 |  |
| Industrial Refrigeration |  | 88 |  |  | 54 |  |  | 158 |  |  | 103 |  |
| Total |  | $ | 2,468 |  |  | $ | 2,290 |  |  | $ | 4,548 |  |  | $ | 4,366 |  |
  (was, 2023-02-01, similarity 0.7092):
[0000833444-23-000005:note_history:64]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| HVAC |  | $ | 1,440 |  |  | $ | 1,483 |  |  |  |  |  |
| Fire & Security |  | 570 |  |  | 544 |  |  |  |  |  |
| Industrial Refrigeration |  | 70 |  |  | 49 |  |  |  |  |  |
| Total |  | $ | 2,080 |  |  | $ | 2,076 |  |  |  |  |  |

- removed (2023-05-05):
[0000833444-23-000005:note_history:65]
|  |  | Three Months Ended December 31, |
|  |  | 2022 |  | 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,451 |  |  | $ | 916 |  |  | $ | 2,367 |  |  | $ | 1,299 |  |  | $ | 853 |  |  | $ | 2,152 |  |
| Building Solutions EMEA/LA |  | 552 |  |  | 423 |  |  | 975 |  |  | 544 |  |  | 415 |  |  | 959 |  |
| Building Solutions Asia Pacific |  | 473 |  |  | 173 |  |  | 646 |  |  | 501 |  |  | 174 |  |  | 675 |  |
| Global Products |  | 2,080 |  |  | — |  |  | 2,080 |  |  | 2,076 |  |  | — |  |  | 2,076 |  |
| Total |  | $ | 4,556 |  |  | $ | 1,512 |  |  | $ | 6,068 |  |  | $ | 4,420 |  |  | $ | 1,442 |  |  | $ | 5,862 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-05):
[0000833444-23-000014:note_history:66]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.
  (was, 2023-02-01, similarity 0.9169):
[0000833444-23-000005:note_history:66]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed and consist of unbilled receivables and costs in excess of billings. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

- changed (2023-05-05):
[0000833444-23-000014:note_history:67]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $18.8 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.
  (was, 2023-02-01, similarity 0.9894):
[0000833444-23-000005:note_history:67]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $18.4 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-05-05):
[0000833444-23-000014:note_history:68]
|  |  | Three Months Ended March 31, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,554 |  |  | $ | 966 |  |  | $ | 2,520 |  |  | $ | 1,343 |  |  | $ | 884 |  |  | $ | 2,227 |  |
| Building Solutions EMEA/LA |  | 582 |  |  | 449 |  |  | 1,031 |  |  | 536 |  |  | 422 |  |  | 958 |  |
| Building Solutions Asia Pacific |  | 479 |  |  | 188 |  |  | 667 |  |  | 448 |  |  | 175 |  |  | 623 |  |
| Global Products |  | 2,468 |  |  | — |  |  | 2,468 |  |  | 2,290 |  |  | — |  |  | 2,290 |  |
| Total |  | $ | 5,083 |  |  | $ | 1,603 |  |  | $ | 6,686 |  |  | $ | 4,617 |  |  | $ | 1,481 |  |  | $ | 6,098 |  |

- added (2023-05-05):
[0000833444-23-000014:note_history:69]
|  |  | Six Months Ended March 31, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,005 |  |  | $ | 1,882 |  |  | $ | 4,887 |  |  | $ | 2,642 |  |  | $ | 1,737 |  |  | $ | 4,379 |  |
| Building Solutions EMEA/LA |  | 1,134 |  |  | 872 |  |  | 2,006 |  |  | 1,080 |  |  | 837 |  |  | 1,917 |  |
| Building Solutions Asia Pacific |  | 952 |  |  | 361 |  |  | 1,313 |  |  | 949 |  |  | 349 |  |  | 1,298 |  |
| Global Products |  | 4,548 |  |  | — |  |  | 4,548 |  |  | 4,366 |  |  | — |  |  | 4,366 |  |
| Total |  | $ | 9,639 |  |  | $ | 3,115 |  |  | $ | 12,754 |  |  | $ | 9,037 |  |  | $ | 2,923 |  |  | $ | 11,960 |  |

- changed (2023-05-05):
[0000833444-23-000014:note_history:70]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 1,757 |  |  | $ | 1,658 |  |  | $ | 3,197 |  |  | $ | 3,141 |  |
| Fire & Security |  | 623 |  |  | 578 |  |  | 1,193 |  |  | 1,122 |  |
| Industrial Refrigeration |  | 88 |  |  | 54 |  |  | 158 |  |  | 103 |  |
| Total |  | $ | 2,468 |  |  | $ | 2,290 |  |  | $ | 4,548 |  |  | $ | 4,366 |  |
  (was, 2023-02-01, similarity 0.7092):
[0000833444-23-000005:note_history:70]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| HVAC |  | $ | 1,440 |  |  | $ | 1,483 |  |  |  |  |  |
| Fire & Security |  | 570 |  |  | 544 |  |  |  |  |  |
| Industrial Refrigeration |  | 70 |  |  | 49 |  |  |  |  |  |
| Total |  | $ | 2,080 |  |  | $ | 2,076 |  |  |  |  |  |

- changed (2023-05-05):
[0000833444-23-000014:note_history:71]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.
  (was, 2023-02-01, similarity 0.9169):
[0000833444-23-000005:note_history:71]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed and consist of unbilled receivables and costs in excess of billings. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

- added (2023-05-05):
[0000833444-23-000014:note_history:72]
|  |  | Location of contract balances |  | March 31, 2023 |  | September 30, 2022 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,026 |  |  | $ | 2,020 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 81 |  |  | 79 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 1,939 |  |  | 1,768 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 292 |  |  | 282 |  |  |  |

- changed (2023-05-05):
[0000833444-23-000014:note_history:73]
For the three months ended March 31, 2023 and 2022, the Company recognized revenue of $319 million and $308 million, respectively, that was included in the beginning of period contract liability balance. For the six months ended March 31, 2023 and 2022, the Company recognized revenue of $1,165 million and $1,059 million, respectively, that was included in the beginning of period contract liability balance
  (was, 2023-02-01, similarity 0.655):
[0000833444-23-000005:note_history:73]
For the three months ended December 31, 2022 and 2021, the Company recognized revenue of $846 million and $751 million, respectively, that was included in the beginning of period contract liability balance.

- changed (2023-05-05):
[0000833444-23-000014:note_history:74]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $18.8 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.
  (was, 2023-02-01, similarity 0.9894):
[0000833444-23-000005:note_history:74]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $18.4 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

- changed (2023-05-05):
[0000833444-23-000014:note_history:75]
|  |  | March 31, 2023 |  | September 30, 2022 |  |  |
| Other current assets |  | $ | 154 |  |  | $ | 139 |  |  |  |
| Other noncurrent assets |  | 200 |  |  | 174 |  |  |  |
| Total |  | $ | 354 |  |  | $ | 313 |  |  |  |
  (was, 2023-02-01, similarity 0.9749):
[0000833444-23-000005:note_history:75]
|  |  | December 31, 2022 |  | September 30, 2022 |  |  |
| Other current assets |  | $ | 148 |  |  | $ | 139 |  |  |  |
| Other noncurrent assets |  | 191 |  |  | 174 |  |  |  |
| Total |  | $ | 339 |  |  | $ | 313 |  |  |  |

- added (2023-05-05):
[0000833444-23-000014:note_history:76]
During the three months ended March 31, 2023 and 2022, the Company recognized amortization expense of $61 million and $47 million, respectively, related to costs to obtain or fulfill a contract. During the six months ended March 31, 2023 and 2022, the Company recognized amortization expense of $122 million and $97 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and six months ended March 31, 2023 and 2022.

- removed (2023-05-05):
[0000833444-23-000005:note_history:77]
|  |  | Three Months Ended December 31, |
|  |  | 2022 |  | 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,451 |  |  | $ | 916 |  |  | $ | 2,367 |  |  | $ | 1,299 |  |  | $ | 853 |  |  | $ | 2,152 |  |
| Building Solutions EMEA/LA |  | 552 |  |  | 423 |  |  | 975 |  |  | 544 |  |  | 415 |  |  | 959 |  |
| Building Solutions Asia Pacific |  | 473 |  |  | 173 |  |  | 646 |  |  | 501 |  |  | 174 |  |  | 675 |  |
| Global Products |  | 2,080 |  |  | — |  |  | 2,080 |  |  | 2,076 |  |  | — |  |  | 2,076 |  |
| Total |  | $ | 4,556 |  |  | $ | 1,512 |  |  | $ | 6,068 |  |  | $ | 4,420 |  |  | $ | 1,442 |  |  | $ | 5,862 |  |

- removed (2023-05-05):
[0000833444-23-000005:note_history:78]
|  |  | Location of contract balances |  | December 31, 2022 |  | September 30, 2022 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,019 |  |  | $ | 2,020 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 83 |  |  | 79 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,774) |  |  | (1,768) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (293) |  |  | (282) |  |  |  |

- removed (2023-05-05):
[0000833444-23-000005:note_history:79]
For the three months ended December 31, 2022 and 2021, the Company recognized amortization expense of  $61 million, and $50 million related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three months ended December 31, 2022 and 2021.
