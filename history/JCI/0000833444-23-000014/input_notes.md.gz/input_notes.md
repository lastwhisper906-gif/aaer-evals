# JCI notes — 0000833444-23-000014


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-23-000014:notes:1]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2022 filed with the SEC on November 15, 2022. The results of operations for the three and six month periods ended March 31, 2023 are not necessarily indicative of results for the Company’s 2023 fiscal year because of seasonal and other factors.

[0000833444-23-000014:notes:2]
[same as prior period, unchanged from 0000833444-23-000005:notes:2]

[0000833444-23-000014:notes:3]
[same as prior period, unchanged from 0000833444-23-000005:notes:3]

[0000833444-23-000014:notes:4]
[same as prior period, unchanged from 0000833444-23-000005:notes:4]

[0000833444-23-000014:notes:5]
[same as prior period, unchanged from 0000833444-23-000005:notes:5]

[0000833444-23-000014:notes:6]
[same as prior period, unchanged from 0000833444-23-000005:notes:6]

[0000833444-23-000014:notes:7]
[same as prior period, unchanged from 0000833444-23-000005:notes:7]

[0000833444-23-000014:notes:8]
Restricted Cash

[0000833444-23-000014:notes:9]
Restricted cash relates to amounts restricted for payment of asbestos liabilities and certain litigation and environmental matters. Restricted cash is recorded primarily within other current assets in the consolidated statements of financial position and totaled $65 million and $35 million at March 31, 2023 and September 30, 2022, respectively. 
Prior Period Revision – Statement of Cash FlowsThe Company revised the amounts previously reported as net proceeds from borrowings with maturities less than three months and proceeds from debt for certain short-term debt transactions that were incorrectly presented on a net basis within the financing activities section of the consolidated statements of cash flows for the six months ended March 31, 2022. Interim and annual amounts for the year ended September 30, 2022 and annual amounts for the years ended September 30, 2021 and 2020 were similarly impacted. Prior period amounts will be revised with future Quarterly Reports on Form 10-Q and Annual Report on Form 10-K filings. Cash provided by financing activities and the total increase (decrease) in cash, cash equivalents and restricted cash were unchanged for all affected periods. The Company does not believe the impact of incorrect presentation is material to any periods.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000833444-23-000014:notes:10]
New Accounting Standards
Recently Issued Accounting Pronouncements

[0000833444-23-000014:notes:11]
In September 2022, the FASB issued ASU 2022-04, "Disclosure of Supplier Finance Program Obligations," which is intended to enhance the transparency surrounding the use of supplier finance programs. Supplier finance programs may also be referred to as reverse factoring, payables finance, or structured payables arrangements. The amendments require a buyer that uses supplier finance programs to make annual disclosures about the program’s key terms, the balance sheet presentation of related amounts, the confirmed amount outstanding at the end of the period, and associated rollforward information. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company expects to adopt the new disclosures, other than the rollforward disclosure, as required at the beginning of fiscal 2024. The rollforward disclosures will be adopted as required at the beginning of fiscal 2025.

[0000833444-23-000014:notes:12]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-23-000014:notes:13]
Acquisitions and Divestitures
During the first six months of fiscal 2023, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $115 million, of which $89 million was paid as of March 31, 2023. In connection with the acquisitions, the Company recorded goodwill of $53 million within the Global Products segment and $14 million within the Building Solutions EMEA/LA segment.

[0000833444-23-000014:notes:14]
The Company completed no divestitures during the first six months of fiscal 2023.

[0000833444-23-000014:notes:15]
During the first six months of fiscal 2022, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $160 million, of which $124 million was paid as of March 31, 2022. In connection with the acquisitions, the Company recorded goodwill of $45 million within the Building Solutions Asia Pacific segment, $24 million within the Building Solutions North America segment and $29 million within the Building Solutions EMEA/LA segment.

[0000833444-23-000014:notes:16]
During the first six months of fiscal 2022, the Company completed a divestiture within the Buildings Solutions EMEA/LA segment. The selling price, net of cash divested, was $18 million, of which $16 million was received as of March 31, 2022. In connection with the divestiture, the Company reduced goodwill by $5 million.

[0000833444-23-000014:notes:17]
Acquisitions and divestitures were not material individually or in the aggregate during the first six months of fiscal 2023 or 2022.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-23-000014:notes:18]
Assets and Liabilities Held for Sale
During fiscal 2022, the Company determined that its Global Retail business within its Building Solutions North America, Building Solutions Asia Pacific and Building Solutions EMEA/LA segments and a business within the Building Solutions Asia Pacific segment both met the criteria to be classified as held for sale. The assets and liabilities of both businesses are presented as held for sale in the consolidated statements of financial position as of March 31, 2023 and September 30, 2022. Assets and liabilities held for sale are recorded at the lower of carrying value or fair value, less costs to sell in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets." The carrying amount of any assets, including goodwill, that are part of the disposal group, but not in the scope of ASC 360-10, are tested for impairment under the relevant guidance prior to measuring the disposal group at fair value, less cost to sell.

[0000833444-23-000014:notes:19]
During the three and six months ended March 31, 2023, the Company recorded impairment charges for the Global Retail business of $210 million and $438 million, respectively. During the three and six months ended March 31, 2023, the Company recorded impairment charges for a business in the Building Solutions Asia Pacific segment of $0 and $60 million, respectively. The impairment charges were primarily due to reductions in the estimated fair values of the businesses to be disposed as a result of ongoing negotiations with potential buyers and were recorded within restructuring and impairment costs in the consolidated statements of income.

[0000833444-23-000014:notes:20]
[same as prior period, unchanged from 0000833444-23-000005:notes:19]

[0000833444-23-000014:notes:21]
[same as prior period, unchanged from 0000833444-23-000005:notes:20]

[0000833444-23-000014:notes:22]
|  |  |  | March 31, 2023 |  | September 30, 2022 |
| Accounts receivable - net |  |  | $ | 242 |  |  | $ | 199 |  |
| Inventories |  |  | 160 |  |  | 155 |  |
| Other current assets |  |  | 30 |  |  | 21 |  |
| Current assets held for sale |  |  | $ | 432 |  |  | $ | 375 |  |
| Property, plant and equipment - net |  |  | $ | 114 |  |  | $ | 89 |  |
| Goodwill |  |  | — |  |  | 22 |  |
| Other intangible assets - net |  |  | 190 |  |  | 514 |  |
| Other noncurrent assets |  |  | 71 |  |  | 72 |  |
| Noncurrent assets held for sale |  |  | $ | 375 |  |  | $ | 697 |  |
| Accounts payable |  |  | $ | 126 |  |  | $ | 127 |  |
| Accrued compensation and benefits |  |  | 16 |  |  | 25 |  |
| Deferred revenue |  |  | 47 |  |  | 36 |  |
| Other current liabilities |  |  | 116 |  |  | 33 |  |
| Current liabilities held for sale |  |  | $ | 305 |  |  | $ | 221 |  |
| Other noncurrent liabilities |  |  | $ | 58 |  |  | $ | 61 |  |
| Noncurrent liabilities held for sale |  |  | $ | 58 |  |  | $ | 61 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-23-000014:notes:23]
[same as prior period, unchanged from 0000833444-23-000005:notes:22]

[0000833444-23-000014:notes:24]
[same as prior period, unchanged from 0000833444-23-000005:notes:23]

[0000833444-23-000014:notes:25]
|  |  | Three Months Ended March 31, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,554 |  |  | $ | 966 |  |  | $ | 2,520 |  |  | $ | 1,343 |  |  | $ | 884 |  |  | $ | 2,227 |  |
| Building Solutions EMEA/LA |  | 582 |  |  | 449 |  |  | 1,031 |  |  | 536 |  |  | 422 |  |  | 958 |  |
| Building Solutions Asia Pacific |  | 479 |  |  | 188 |  |  | 667 |  |  | 448 |  |  | 175 |  |  | 623 |  |
| Global Products |  | 2,468 |  |  | — |  |  | 2,468 |  |  | 2,290 |  |  | — |  |  | 2,290 |  |
| Total |  | $ | 5,083 |  |  | $ | 1,603 |  |  | $ | 6,686 |  |  | $ | 4,617 |  |  | $ | 1,481 |  |  | $ | 6,098 |  |

[0000833444-23-000014:notes:26]
|  |  | Six Months Ended March 31, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,005 |  |  | $ | 1,882 |  |  | $ | 4,887 |  |  | $ | 2,642 |  |  | $ | 1,737 |  |  | $ | 4,379 |  |
| Building Solutions EMEA/LA |  | 1,134 |  |  | 872 |  |  | 2,006 |  |  | 1,080 |  |  | 837 |  |  | 1,917 |  |
| Building Solutions Asia Pacific |  | 952 |  |  | 361 |  |  | 1,313 |  |  | 949 |  |  | 349 |  |  | 1,298 |  |
| Global Products |  | 4,548 |  |  | — |  |  | 4,548 |  |  | 4,366 |  |  | — |  |  | 4,366 |  |
| Total |  | $ | 9,639 |  |  | $ | 3,115 |  |  | $ | 12,754 |  |  | $ | 9,037 |  |  | $ | 2,923 |  |  | $ | 11,960 |  |

[0000833444-23-000014:notes:27]
[same as prior period, unchanged from 0000833444-23-000005:notes:25]

[0000833444-23-000014:notes:28]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 1,757 |  |  | $ | 1,658 |  |  | $ | 3,197 |  |  | $ | 3,141 |  |
| Fire & Security |  | 623 |  |  | 578 |  |  | 1,193 |  |  | 1,122 |  |
| Industrial Refrigeration |  | 88 |  |  | 54 |  |  | 158 |  |  | 103 |  |
| Total |  | $ | 2,468 |  |  | $ | 2,290 |  |  | $ | 4,548 |  |  | $ | 4,366 |  |

[0000833444-23-000014:notes:29]
[same as prior period, unchanged from 0000833444-23-000005:notes:27]

[0000833444-23-000014:notes:30]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

[0000833444-23-000014:notes:31]
[same as prior period, unchanged from 0000833444-23-000005:notes:29]

[0000833444-23-000014:notes:32]
|  |  | Location of contract balances |  | March 31, 2023 |  | September 30, 2022 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,026 |  |  | $ | 2,020 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 81 |  |  | 79 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 1,939 |  |  | 1,768 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 292 |  |  | 282 |  |  |  |

[0000833444-23-000014:notes:33]
For the three months ended March 31, 2023 and 2022, the Company recognized revenue of $319 million and $308 million, respectively, that was included in the beginning of period contract liability balance. For the six months ended March 31, 2023 and 2022, the Company recognized revenue of $1,165 million and $1,059 million, respectively, that was included in the beginning of period contract liability balance

[0000833444-23-000014:notes:34]
[same as prior period, unchanged from 0000833444-23-000005:notes:32]

[0000833444-23-000014:notes:35]
[same as prior period, unchanged from 0000833444-23-000005:notes:33]

[0000833444-23-000014:notes:36]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $18.8 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.

[0000833444-23-000014:notes:37]
[same as prior period, unchanged from 0000833444-23-000005:notes:35]

[0000833444-23-000014:notes:38]
[same as prior period, unchanged from 0000833444-23-000005:notes:36]

[0000833444-23-000014:notes:39]
[same as prior period, unchanged from 0000833444-23-000005:notes:37]

[0000833444-23-000014:notes:40]
|  |  | March 31, 2023 |  | September 30, 2022 |  |  |
| Other current assets |  | $ | 154 |  |  | $ | 139 |  |  |  |
| Other noncurrent assets |  | 200 |  |  | 174 |  |  |  |
| Total |  | $ | 354 |  |  | $ | 313 |  |  |  |

[0000833444-23-000014:notes:41]
During the three months ended March 31, 2023 and 2022, the Company recognized amortization expense of $61 million and $47 million, respectively, related to costs to obtain or fulfill a contract. During the six months ended March 31, 2023 and 2022, the Company recognized amortization expense of $122 million and $97 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and six months ended March 31, 2023 and 2022.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0000833444-23-000014:notes:42]
Accounts ReceivableThe Company enters into various factoring agreements to sell certain accounts receivable to third-party financial institutions. For the majority of these agreements, for ease of administration, the Company collects customer payments related to the factored receivables on behalf of the financial institutions but otherwise maintains no continuing involvement with respect to the factored receivables. Sales of accounts receivable are reflected as a reduction of accounts receivable in the consolidated statements of financial position and the proceeds are included in cash flows from operating activities in the consolidated statements of cash flows. The Company sold $427 million and $836 million of accounts receivable under these factoring agreements during the three and six months ended March 31, 2023, respectively. The Company sold $234 million and $368 million of accounts receivable under these factoring agreements during the three and six months ended March 31, 2022, respectively. The cost of factoring such receivables was not material. Previously sold receivables still outstanding were $402 million and $476 million as of March 31, 2023 and  September 30, 2022, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-23-000014:notes:43]
[same as prior period, unchanged from 0000833444-23-000005:notes:41]

[0000833444-23-000014:notes:44]
|  | March 31, 2023 |  | September 30, 2022 |
| Raw materials and supplies | $ | 1,215 |  |  | $ | 1,009 |  |
| Work-in-process | 247 |  |  | 196 |  |
| Finished goods | 1,586 |  |  | 1,305 |  |
| Inventories | $ | 3,048 |  |  | $ | 2,510 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-23-000014:notes:45]
[same as prior period, unchanged from 0000833444-23-000005:notes:43]

[0000833444-23-000014:notes:46]
|  |  | Six Months Ended March 31, 2023 |
|  |  | Building Solutions North America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total |
| Goodwill |  | $ | 9,630 |  |  | $ | 1,772 |  |  | $ | 1,116 |  |  | $ | 5,591 |  |  | 18,109 |  |
| Accumulated impairment loss |  | (659) |  |  | (47) |  |  | — |  |  | (75) |  |  | (781) |  |
| Balance at beginning of period |  | 8,971 |  |  | 1,725 |  |  | 1,116 |  |  | 5,516 |  |  | 17,328 |  |
| Acquisitions (1) |  | — |  |  | 16 |  |  | — |  |  | 53 |  |  | 69 |  |
| Impairments |  | — |  |  | — |  |  | — |  |  | (184) |  |  | (184) |  |
| Foreign currency translation and other |  | 8 |  |  | 183 |  |  | 53 |  |  | 102 |  |  | 346 |  |
| Balance at end of period |  | $ | 8,979 |  |  | $ | 1,924 |  |  | $ | 1,169 |  |  | $ | 5,487 |  |  | $ | 17,559 |  |

[0000833444-23-000014:notes:47]
(1)  Includes measurement period adjustments

[0000833444-23-000014:notes:48]
The Company tests goodwill for impairment annually as of July 31 or more frequently if events or changes in circumstances indicate the asset might be impaired. In the second quarter of fiscal 2023, management completed an updated comprehensive review of the Silent-Aire reporting unit, including its current quarter results and its nearer term

[0000833444-23-000014:notes:49]
forecast. Due to current quarter results being lower than its business plan, and the nearer term forecast being revised to reflect lower margins and earnings, the Company determined a triggering event had occurred and a quantitative test of goodwill for possible impairment was necessary. As a result of the goodwill impairment test, the Company recorded a non-cash impairment charge of $184 million within restructuring and impairment costs in the consolidated statements of income in the second quarter of fiscal 2023, which was determined by comparing the carrying amount of the reporting unit to its fair value. The Silent-Aire reporting unit has no remaining goodwill balance as of March 31, 2023. The Company used a discounted cash flow model to estimate the fair value of the reporting unit. The primary assumptions used in the model were management's internal projections of future cash flows, the weighted-average cost of capital and the long-term growth rate, which are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." There were no other triggering events requiring an impairment assessment be conducted in the six months ended March 31, 2023. However, it is possible that future changes in circumstances would require the Company to record additional non-cash impairment charges.

[0000833444-23-000014:notes:50]
[same as prior period, unchanged from 0000833444-23-000005:notes:46]

[0000833444-23-000014:notes:51]
|  | March 31, 2023 |  | September 30, 2022 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,422 |  |  | $ | (733) |  |  | $ | 689 |  |  | $ | 1,353 |  |  | $ | (658) |  |  | $ | 695 |  |
| Customer relationships | 2,810 |  |  | (1,393) |  |  | 1,417 |  |  | 2,742 |  |  | (1,254) |  |  | 1,488 |  |
| Miscellaneous | 799 |  |  | (402) |  |  | 397 |  |  | 756 |  |  | (386) |  |  | 370 |  |
|  | 5,031 |  |  | (2,528) |  |  | 2,503 |  |  | 4,851 |  |  | (2,298) |  |  | 2,553 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,130 |  |  | — |  |  | 2,130 |  |  | 2,088 |  |  | — |  |  | 2,088 |  |
|  | 2,130 |  |  | — |  |  | 2,130 |  |  | 2,088 |  |  | — |  |  | 2,088 |  |
| Total intangible assets | $ | 7,161 |  |  | $ | (2,528) |  |  | $ | 4,633 |  |  | $ | 6,939 |  |  | $ | (2,298) |  |  | $ | 4,641 |  |

[0000833444-23-000014:notes:52]
Amortization of other intangible assets for the three-month periods ended March 31, 2023 and 2022 was $104 million and $106 million, respectively. Amortization of other intangible assets for the six month periods ended March 31, 2023 and 2022 was $208 million and $224 million, respectively.

[0000833444-23-000014:notes:53]
The Company tests indefinite-lived intangible assets for impairment annually as of July 31 or more frequently if events or changes in circumstances indicate the asset might be impaired. There were no triggering events requiring that an impairment assessment be conducted in the six months ended March 31, 2023. However, it is possible that future changes in circumstances would require the Company to record additional non-cash impairment charges.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-23-000014:notes:54]
[same as prior period, unchanged from 0000833444-23-000005:notes:50]

[0000833444-23-000014:notes:55]
|  | Location of lease balances |  | March 31, 2023 |  | September 30, 2022 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,323 |  |  | $ | 1,271 |  |
| Operating lease liabilities - current | Other current liabilities |  | 303 |  |  | 280 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 1,026 |  |  | 987 |  |

[0000833444-23-000014:notes:56]
[same as prior period, unchanged from 0000833444-23-000005:notes:52]

[0000833444-23-000014:notes:57]
|  |  |  |  | Six Months Ended March 31, |  |  |
|  |  |  |  |  |  | 2023 |  | 2022 |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  |  |  |  |  | $ | 215 |  |  | $ | 152 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-23-000014:notes:58]
Debt and Financing Arrangements
Short-term debt consisted of the following (in millions):

[0000833444-23-000014:notes:59]
|  | March 31, |  | September 30, |
|  | 2023 |  | 2022 |
| Bank borrowings | $ | 20 |  |  | $ | 10 |  |
| Commercial paper | 1,554 |  |  | 172 |  |
| Term loans | 163 |  |  | 487 |  |
|  | $ | 1,737 |  |  | $ | 669 |  |
| Weighted average interest rate on short-term debt outstanding | 2.9 | % |  | 0.5 | % |

[0000833444-23-000014:notes:60]
As of March 31, 2023, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in November 2023. As of March 31, 2023, there were no draws on the facilities.

[0000833444-23-000014:notes:61]
Financing Activity

[0000833444-23-000014:notes:62]
In October 2022, the Company repaid a €200 million ($196 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5% and entered into a €150 million ($163 million as of March 31, 2023) term loan with an interest rate of EURIBOR plus 0.7% which is due in April 2024.

[0000833444-23-000014:notes:63]
In January 2023, the Company repaid $32 million of outstanding 4.625% Notes due 2023.

[0000833444-23-000014:notes:64]
In March 2023, the Company repaid a €150 million ($147 million as of September 30, 2022) term loan with an interest rate of 0.0%, repaid a €135 million ($133 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5% and entered into a €150 million ($163 million as of March 31, 2023) term loan with an interest rate of EURIBOR plus 0.4% which is due March 2024.

[0000833444-23-000014:notes:65]
Net Financing Charges

[0000833444-23-000014:notes:66]
Net financing charges consisted of the following (in millions):

[0000833444-23-000014:notes:67]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest expense, net of capitalized interest costs | $ | 71 |  |  | $ | 56 |  |  | $ | 140 |  |  | $ | 111 |  |
| Other financing charges | 11 |  |  | 5 |  |  | 21 |  |  | 10 |  |
| Interest income | (3) |  |  | (1) |  |  | (7) |  |  | (3) |  |
| Net foreign exchange results for financing activities | (8) |  |  | (9) |  |  | (16) |  |  | (14) |  |
| Net financing charges | $ | 71 |  |  | $ | 51 |  |  | $ | 138 |  |  | $ | 104 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-23-000014:notes:68]
[same as prior period, unchanged from 0000833444-23-000005:notes:60]

[0000833444-23-000014:notes:69]
[same as prior period, unchanged from 0000833444-23-000005:notes:61]

[0000833444-23-000014:notes:70]
[same as prior period, unchanged from 0000833444-23-000005:notes:62]

[0000833444-23-000014:notes:71]
[same as prior period, unchanged from 0000833444-23-000005:notes:63]

[0000833444-23-000014:notes:72]
As cash flow hedges under ASC 815, "Derivatives and Hedging," hedge gains or losses due to changes in fair value are initially recorded as a component of accumulated other comprehensive income (loss) ("AOCI") and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three and six months ended March 31, 2023 and 2022.

[0000833444-23-000014:notes:73]
[same as prior period, unchanged from 0000833444-23-000005:notes:65]

[0000833444-23-000014:notes:74]
|  |  | Volume Outstanding as of |
| Commodity |  | March 31, 2023 |  | September 30, 2022 |
| Copper |  | 3,810 |  |  | 3,629 |  |
| Aluminum |  | 9,722 |  |  | 6,758 |  |

[0000833444-23-000014:notes:75]
In March 2023, the Company entered into two forward-starting interest rate swaps with a combined notional amount of €200 million to reduce the market risk associated with changes in interest rates on future potential debt issuances. The interest rate swaps are designated as cash flow hedges. If notes are issued, the fair value of each interest rate swap, which is the difference between the swap's reference rate and the fixed rate when the notes are issued, will be amortized to interest expense over the life of the respective note issuance.

[0000833444-23-000014:notes:76]
[same as prior period, unchanged from 0000833444-23-000005:notes:67]

[0000833444-23-000014:notes:77]
[same as prior period, unchanged from 0000833444-23-000005:notes:68]

[0000833444-23-000014:notes:78]
[same as prior period, unchanged from 0000833444-23-000005:notes:69]

[0000833444-23-000014:notes:79]
|  |  | March 31, |  | September 30, |
|  | 2023 |  | 2022 |
| Euro-denominated bonds designated as net investment hedges in Europe |  | € | 2.9 |  |  | € | 2.9 |  |
| Yen-denominated debt designated as a net investment hedge in Japan |  | ¥ | 30 |  |  | ¥ | 30 |  |

[0000833444-23-000014:notes:80]
[same as prior period, unchanged from 0000833444-23-000005:notes:71]

[0000833444-23-000014:notes:81]
[same as prior period, unchanged from 0000833444-23-000005:notes:72]

[0000833444-23-000014:notes:82]
[same as prior period, unchanged from 0000833444-23-000005:notes:73]

[0000833444-23-000014:notes:83]
[same as prior period, unchanged from 0000833444-23-000005:notes:74]

[0000833444-23-000014:notes:84]
|  | Derivatives and Hedging Activities Designated as Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | March 31, |  | September 30, |  | March 31, |  | September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 23 |  |  | $ | 30 |  |  | $ | 5 |  |  | $ | 24 |  |
| Interest rate swaps | 5 |  |  | — |  |  | — |  |  | — |  |
| Commodity derivatives | 3 |  |  | — |  |  | — |  |  | — |  |
| Total assets | $ | 31 |  |  | $ | 30 |  |  | $ | 5 |  |  | $ | 24 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 36 |  |  | $ | 24 |  |  | $ | 12 |  |  | $ | 27 |  |
| Commodity derivatives | 1 |  |  | 10 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,406 |  |  | 3,077 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,443 |  |  | $ | 3,111 |  |  | $ | 12 |  |  | $ | 27 |  |

[0000833444-23-000014:notes:85]
[same as prior period, unchanged from 0000833444-23-000005:notes:76]

[0000833444-23-000014:notes:86]
[same as prior period, unchanged from 0000833444-23-000005:notes:77]

[0000833444-23-000014:notes:87]
[same as prior period, unchanged from 0000833444-23-000005:notes:78]

[0000833444-23-000014:notes:88]
[same as prior period, unchanged from 0000833444-23-000005:notes:79]

[0000833444-23-000014:notes:89]
|  |  | Fair Value of Assets |  |  |  | Fair Value of Liabilities |  |  |
|  |  | March 31, |  | September 30, |  |  |  | March 31, |  | September 30, |  |  |
|  |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |  |  |
| Gross amount recognized |  | $ | 36 |  |  | $ | 54 |  |  |  |  | $ | 3,455 |  |  | $ | 3,138 |  |  |  |
| Gross amount eligible for offsetting |  | (16) |  |  | (42) |  |  |  |  | (16) |  |  | (42) |  |  |  |
| Net amount |  | $ | 20 |  |  | $ | 12 |  |  |  |  | $ | 3,439 |  |  | $ | 3,096 |  |  |  |

[0000833444-23-000014:notes:90]
[same as prior period, unchanged from 0000833444-23-000005:notes:81]

[0000833444-23-000014:notes:91]
[same as prior period, unchanged from 0000833444-23-000005:notes:82]

[0000833444-23-000014:notes:92]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Foreign currency exchange derivatives |  | $ | 9 |  |  | $ | 10 |  |  | $ | (12) |  |  | $ | 23 |  |
| Interest rate swaps |  | 5 |  |  | — |  |  | 5 |  |  | — |  |
| Commodity derivatives |  | 3 |  |  | 6 |  |  | 7 |  |  | 4 |  |
| Total |  | $ | 17 |  |  | $ | 16 |  |  | $ | — |  |  | $ | 27 |  |

[0000833444-23-000014:notes:93]
[same as prior period, unchanged from 0000833444-23-000005:notes:84]

[0000833444-23-000014:notes:94]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (5) |  |  | $ | 6 |  |  | $ | 4 |  |  | $ | 11 |  |
| Commodity derivatives |  | Cost of sales |  | (2) |  |  | (1) |  |  | (8) |  |  | (5) |  |
| Interest rate swaps |  | Net financing charges |  | — |  |  | — |  |  | — |  |  | (1) |  |
| Total |  |  |  | $ | (7) |  |  | $ | 5 |  |  | $ | (4) |  |  | $ | 5 |  |

[0000833444-23-000014:notes:95]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income (in millions):

[0000833444-23-000014:notes:96]
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of GainRecognized in Income on Derivative |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (6) |  |  | $ | (3) |  |  | $ | (8) |  |  | $ | 7 |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 15 |  |  | 1 |  |  | (64) |  |  | 88 |  |
| Equity swap |  | Selling, general and administrative |  | — |  |  | (6) |  |  | — |  |  | (1) |  |
| Total |  |  |  | $ | 9 |  |  | $ | (8) |  |  | $ | (72) |  |  | $ | 94 |  |

[0000833444-23-000014:notes:97]
Pre-tax gains (losses) on net investment hedges recorded as foreign currency translation adjustments ("CTA") within other comprehensive income (loss) were $(60) million and $50 million for the three months ended March 31, 2023 and 2022, respectively. Pre-tax gains (losses) on net investment hedges recorded as foreign currency translation adjustments ("CTA") 
within other comprehensive income (loss) were $(329) million and $123 million for the six months ended March 31, 2023 and 2022, respectively. No gains or losses were reclassified from CTA into income during the three and six months ended March 31, 2023 and 2022.


## us-gaap:DerivativesPolicyTextBlock

[0000833444-23-000014:notes:98]
As cash flow hedges under ASC 815, "Derivatives and Hedging," hedge gains or losses due to changes in fair value are initially recorded as a component of accumulated other comprehensive income (loss) ("AOCI") and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings.The currency effects of the debt obligations are reflected in AOCI attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company's net investments globally.The Company holds certain foreign currency forward contracts not designated as hedging instruments under ASC 815 to hedge foreign currency exposure resulting from monetary assets and liabilities denominated in nonfunctional currencies.  The changes in fair value of these foreign currency forward exchange derivatives are recorded in the consolidated statements of income where they offset foreign currency transactional gains and losses on the nonfunctional currency denominated assets and liabilities being hedged.The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with substantially all of its counterparties. The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position. The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-23-000014:notes:99]
[same as prior period, unchanged from 0000833444-23-000005:notes:90]

[0000833444-23-000014:notes:100]
[same as prior period, unchanged from 0000833444-23-000005:notes:91]

[0000833444-23-000014:notes:101]
[same as prior period, unchanged from 0000833444-23-000005:notes:92]

[0000833444-23-000014:notes:102]
[same as prior period, unchanged from 0000833444-23-000005:notes:93]

[0000833444-23-000014:notes:103]
[same as prior period, unchanged from 0000833444-23-000005:notes:94]

[0000833444-23-000014:notes:104]
[same as prior period, unchanged from 0000833444-23-000005:notes:95]

[0000833444-23-000014:notes:105]
[same as prior period, unchanged from 0000833444-23-000005:notes:96]

[0000833444-23-000014:notes:106]
|  | Fair Value Measurements Using: |
|  | Total as of March 31, 2023 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |
| Interest rate swaps | 5 |  |  | — |  |  | 5 |  |  | — |  |
| Commodity derivatives | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Exchange traded funds (fixed income)(1) | 23 |  |  | 23 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 52 |  |  | 52 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)(1) | 75 |  |  | 75 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)(1) | 155 |  |  | 155 |  |  | — |  |  | — |  |
| Total assets | $ | 341 |  |  | $ | 305 |  |  | $ | 36 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 48 |  |  | $ | — |  |  | $ | 48 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Contingent earn-out liabilities | 29 |  |  | — |  |  | — |  |  | 29 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 22 |  |  | — |  |  | — |  |  | 22 |  |
| Total liabilities | $ | 100 |  |  | $ | — |  |  | $ | 49 |  |  | $ | 51 |  |

[0000833444-23-000014:notes:107]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2022 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |
| Exchange traded funds (fixed income)(1) | 22 |  |  | 22 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 46 |  |  | 46 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)(1) | 86 |  |  | 86 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)(1) | 131 |  |  | 131 |  |  | — |  |  | — |  |
| Total assets | $ | 339 |  |  | $ | 285 |  |  | $ | 54 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 51 |  |  | $ | — |  |  | $ | 51 |  |  | $ | — |  |
| Commodity derivatives | 10 |  |  | — |  |  | 10 |  |  | — |  |
| Contingent earn-out liabilities | 30 |  |  | — |  |  | — |  |  | 30 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 30 |  |  | — |  |  | — |  |  | 30 |  |
| Total liabilities | $ | 121 |  |  | $ | — |  |  | $ | 61 |  |  | $ | 60 |  |

[0000833444-23-000014:notes:108]
(1)  Classified as restricted investments for payment of asbestos liabilities. See Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further details.

[0000833444-23-000014:notes:109]
[same as prior period, unchanged from 0000833444-23-000005:notes:100]

[0000833444-23-000014:notes:110]
| Balance at September 30, 2022 | $ | 60 |  |  |
| Acquisitions | 25 |  |  |
| Payments | (4) |  |  |
| Reduction for change in estimates | (30) |  |  |
| Balance at March 31, 2023 | $ | 51 |  |  |

[0000833444-23-000014:notes:111]
[same as prior period, unchanged from 0000833444-23-000005:notes:102]

[0000833444-23-000014:notes:112]
[same as prior period, unchanged from 0000833444-23-000005:notes:103]

[0000833444-23-000014:notes:113]
[same as prior period, unchanged from 0000833444-23-000005:notes:104]

[0000833444-23-000014:notes:114]
Interest rate swaps: The  fair value of interest rate swaps represent the difference between the swap's reference rate and the interest rate for a similar instrument as of the reporting period. Interest rate swaps are valued under a market approach using publicized prices.

[0000833444-23-000014:notes:115]
[same as prior period, unchanged from 0000833444-23-000005:notes:105]

[0000833444-23-000014:notes:116]
Investments in exchange traded funds:  Investments in exchange traded funds are valued using a market approach based on  quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.  Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further information.

[0000833444-23-000014:notes:117]
[same as prior period, unchanged from 0000833444-23-000005:notes:107]

[0000833444-23-000014:notes:118]
The following table presents the portion of unrealized gains (losses) recognized in the consolidated statements of income that relate to equity securities still held at March 31, 2023 and 2022 (in millions):

[0000833444-23-000014:notes:119]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Deferred compensation plan assets |  | $ | 2 |  |  | $ | (3) |  |  | $ | 5 |  |  | $ | — |  |
| Investments in exchange traded funds |  | 12 |  |  | (20) |  |  | 23 |  |  | (6) |  |

[0000833444-23-000014:notes:120]
All of the gains (losses) on investments in exchange traded funds related to restricted investments. 
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. At March 31, 2023, the fair value of long-term debt was $8.1 billion, including public debt of $7.7 billion and other long-term debt of $0.4 billion. At September 30, 2022, the fair value of long-term debt was $7.3 billion, including public debt of $7.1 billion and other long-term debt of $0.2 billion. The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000833444-23-000014:notes:121]
[same as prior period, unchanged from 0000833444-23-000005:notes:111]

[0000833444-23-000014:notes:122]
Investments in exchange traded funds:  Investments in exchange traded funds are valued using a market approach based on  quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.  Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further information.
Contingent earn-out liabilities:  The contingent earn-out liabilities were established using a Monte Carlo simulation based on the forecasted operating results and the earn-out formula specified in the purchase agreements.The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-23-000014:notes:123]
Stock-Based Compensation
The Johnson Controls International plc 2021 Equity and Incentive Plan authorizes stock options, stock appreciation rights, restricted (non-vested) stock/units, performance share units and other stock-based awards. The Compensation and Talent Development Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter.

[0000833444-23-000014:notes:124]
[same as prior period, unchanged from 0000833444-23-000005:notes:114]

[0000833444-23-000014:notes:125]
|  | Six Months Ended March 31, |  |  |
|  | 2023 |  |  |  | 2022 |  |  |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |
| Restricted stock/units | 1,720,662 |  |  | $ | 66.59 |  |  |  |  | 1,267,490 |  |  | $ | 78.50 |  |  |  |
| Performance shares | 339,191 |  |  | 79.54 |  |  |  |  | 482,030 |  |  | 82.88 |  |  |  |
| Stock options | 570,140 |  |  | 18.21 |  |  |  |  | 548,398 |  |  | 18.59 |  |  |  |

[0000833444-23-000014:notes:126]
[same as prior period, unchanged from 0000833444-23-000005:notes:116]

[0000833444-23-000014:notes:127]
[same as prior period, unchanged from 0000833444-23-000005:notes:117]

[0000833444-23-000014:notes:128]
|  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |
| Risk-free interest rate | 4.04% |  | 0.99% |
| Expected volatility of the Company’s stock | 33.5% |  | 30.0% |

[0000833444-23-000014:notes:129]
[same as prior period, unchanged from 0000833444-23-000005:notes:119]

[0000833444-23-000014:notes:130]
[same as prior period, unchanged from 0000833444-23-000005:notes:120]

[0000833444-23-000014:notes:131]
|  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |
| Expected life of option (years) | 5.8 |  | 6.0 |
| Risk-free interest rate | 3.59% |  | 1.35% |
| Expected volatility of the Company’s stock | 29.4% |  | 27.8% |
| Expected dividend yield on the Company’s stock | 2.10% |  | 1.71% |


## us-gaap:EarningsPerShareTextBlock

[0000833444-23-000014:notes:132]
[same as prior period, unchanged from 0000833444-23-000005:notes:122]

[0000833444-23-000014:notes:133]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net income attributable to Johnson Controls | $ | 133 |  |  | $ | 11 |  |  | $ | 251 |  |  | $ | 392 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 686.8 |  |  | 699.1 |  |  | 686.9 |  |  | 701.8 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 2.9 |  |  | 3.6 |  |  | 3.1 |  |  | 4.4 |  |
| Diluted weighted average shares outstanding | 689.7 |  |  | 702.7 |  |  | 690.0 |  |  | 706.2 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Stock options and unvested restricted stock | 0.3 |  |  | 0.3 |  |  | 0.3 |  |  | 0.2 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-23-000014:notes:134]
[same as prior period, unchanged from 0000833444-23-000005:notes:124]

[0000833444-23-000014:notes:135]
During  the three and six months ended March 31, 2023, the Company repurchased and immediately retired $93 million and $247 million of its ordinary shares, respectively. For the three and six months ended March 31, 2022, the Company repurchased and immediately retired $509 million and $1,035 million of its ordinary shares, respectively. As of March 31, 2023, approximately $3.4 billion remains available under the Company's share repurchase program, which was approved by the Company's Board of Directors in March 2021. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice.

[0000833444-23-000014:notes:136]
[same as prior period, unchanged from 0000833444-23-000005:notes:126]

[0000833444-23-000014:notes:137]
[same as prior period, unchanged from 0000833444-23-000005:notes:127]

[0000833444-23-000014:notes:138]
|  | Three Months Ended March 31, |
|  | 2023 |  | 2022 |
| Foreign currency translation adjustments |  |  |  |
| Balance at beginning of period | $ | (842) |  |  | $ | (337) |  |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | (1) |  |  | (6) |  |
| Balance at end of period | (843) |  |  | (343) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (22) |  |  | (13) |  |
| Current period changes in fair value (net of tax effect of $3 and $3) | 13 |  |  | 12 |  |
| Reclassification to income (net of tax effect of $1 and $(2))(1) | 6 |  |  | (3) |  |
| Balance at end of period | (3) |  |  | (4) |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | — |  |  | 3 |  |
| Reclassification to income (net of tax effect of $(1) and $(1)) | — |  |  | (1) |  |
| Balance at end of period | — |  |  | 2 |  |
| Accumulated other comprehensive loss, end of period | $ | (846) |  |  | $ | (345) |  |

[0000833444-23-000014:notes:139]
|  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |
| Foreign currency translation adjustments |  |  |  |
| Balance at beginning of period | $ | (901) |  |  | $ | (421) |  |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | 58 |  |  | 78 |  |
| Balance at end of period | (843) |  |  | (343) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (11) |  |  | (17) |  |
| Current period changes in fair value (net of tax effect of $1 and $6) | 4 |  |  | 16 |  |
| Reclassification to income (net of tax effect of $0 and $(2))(1) | 4 |  |  | (3) |  |
| Balance at end of period | (3) |  |  | (4) |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | 1 |  |  | 4 |  |
| Reclassification to income (net of tax effect of $(1) and $(1)) | (1) |  |  | (2) |  |
| Balance at end of period | — |  |  | 2 |  |
| Accumulated other comprehensive loss, end of period | $ | (846) |  |  | $ | (345) |  |

[0000833444-23-000014:notes:140]
(1)  Refer to Note 11, "Derivative Instruments and Hedging Activities," of the notes to the consolidated financial statements for disclosure of the line items in the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-23-000014:notes:141]
Pension and Postretirement Plans
The components of the Company’s net periodic benefit cost (credit) associated with its defined benefit pension and postretirement plans, which are primarily recorded in selling, general and administrative expenses in the consolidated statements of income, are shown in the tables below in accordance with ASC 715, "Compensation – Retirement Benefits" (in millions):

[0000833444-23-000014:notes:142]
|  | U.S. Pension Plans |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest cost | $ | 20 |  |  | $ | 11 |  |  | $ | 41 |  |  | $ | 21 |  |
| Expected return on plan assets | (33) |  |  | (41) |  |  | (67) |  |  | (82) |  |
| Net actuarial loss | 15 |  |  | 60 |  |  | 23 |  |  | 18 |  |
| Settlement loss | 1 |  |  | 2 |  |  | 1 |  |  | 1 |  |
| Net periodic benefit cost (credit) | $ | 3 |  |  | $ | 32 |  |  | $ | (2) |  |  | $ | (42) |  |

[0000833444-23-000014:notes:143]
|  | Non-U.S. Pension Plans |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Service cost | $ | 4 |  |  | $ | 5 |  |  | $ | 7 |  |  | $ | 11 |  |
| Interest cost | 17 |  |  | 10 |  |  | 33 |  |  | 20 |  |
| Expected return on plan assets | (19) |  |  | (21) |  |  | (37) |  |  | (42) |  |
| Net actuarial gain | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Settlement loss | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Net periodic benefit cost (credit) | $ | 2 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | (4) |  |

[0000833444-23-000014:notes:144]
|  | Postretirement Benefits |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest cost | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 1 |  |
| Expected return on plan assets | (2) |  |  | (2) |  |  | (4) |  |  | (4) |  |
| Amortization of prior service credit | (1) |  |  | (1) |  |  | (2) |  |  | (2) |  |
| Net periodic benefit credit | $ | (2) |  |  | $ | (2) |  |  | $ | (4) |  |  | $ | (5) |  |

[0000833444-23-000014:notes:145]
Cumulative fiscal 2023 lump sum payouts triggered remeasurement events for certain pension plans in both the first and second quarters of fiscal 2023. During the three and six months ended March 31, 2023, the Company recognized net actuarial losses of $15 million and $23 million, respectively, primarily due to decreases in discount rates, partially offset by favorable plan asset performance.

[0000833444-23-000014:notes:146]
Cumulative fiscal 2022 lump sum payouts triggered remeasurement events for certain pension plans in both the first and second quarters of fiscal 2022. During the three and six months ended March 31, 2022, the Company recognized net actuarial losses of $59 million and $17 million, respectively, primarily due to unfavorable plan asset performance, partially offset by increases in discount rates.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-23-000014:notes:147]
[same as prior period, unchanged from 0000833444-23-000005:notes:136]

[0000833444-23-000014:notes:148]
During the three and six months ended March 31, 2023, the Company recorded $24 million and $81 million of restructuring and impairment costs in the consolidated statements of income, respectively. These charges relate to restructuring plans within the segments and at Corporate to reduce and optimize our cost structure. Refer to Note 4, "Assets and Liabilities Held for Sale," and Note 8, "Goodwill and Other Intangible Assets,"  of the notes to the consolidated financial statements for disclosure of other impairment costs.

[0000833444-23-000014:notes:149]
[same as prior period, unchanged from 0000833444-23-000005:notes:139]

[0000833444-23-000014:notes:150]
|  | Three Months Ended March 31, 2023 |  | Six Months Ended March 31, 2023 |  |  |
| Building Solutions North America | $ | 4 |  |  | $ | 6 |  |  |  |
| Building Solutions EMEA/LA | — |  |  | 21 |  |  |  |
| Building Solutions Asia Pacific | 1 |  |  | 6 |  |  |  |
| Global Products | 4 |  |  | 27 |  |  |  |
| Corporate | 15 |  |  | 21 |  |  |  |
| Total | $ | 24 |  |  | $ | 81 |  |  |  |

[0000833444-23-000014:notes:151]
The following table summarizes changes in the restructuring reserve, which is included within other current liabilities in the consolidated statements of financial position, for new restructuring actions taken in the six months ended March 31, 2023 (in millions):

[0000833444-23-000014:notes:152]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  | Total |
| Original reserve | $ | 30 |  |  | $ | 6 |  |  | $ | 21 |  |  |  |  | $ | 57 |  |
| Utilized—cash | (3) |  |  | — |  |  | (5) |  |  |  |  | (8) |  |
| Utilized—noncash | — |  |  | (6) |  |  | — |  |  |  |  | (6) |  |
| Balance at December 31, 2022 | 27 |  |  | — |  |  | 16 |  |  |  |  | 43 |  |
| Additional restructuring costs | 17 |  |  | 4 |  |  | 3 |  |  |  |  | 24 |  |
| Utilized—cash | (32) |  |  | — |  |  | (8) |  |  |  |  | (40) |  |
| Utilized—noncash | — |  |  | (4) |  |  | — |  |  |  |  | (4) |  |
| Balance at March 31, 2023 | $ | 12 |  |  | $ | — |  |  | $ | 11 |  |  |  |  | $ | 23 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-23-000014:notes:153]
[same as prior period, unchanged from 0000833444-23-000005:notes:143]

[0000833444-23-000014:notes:154]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland.

[0000833444-23-000014:notes:155]
For the three months ended March 31, 2023, the Company's effective tax rate was 22.0% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of an impairment charge and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives.

[0000833444-23-000014:notes:156]
For the six months ended March 31, 2023, the Company's effective tax rate was 16.0% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of an impairment charge and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives.

[0000833444-23-000014:notes:157]
For the three months ended March 31, 2022, the Company's effective tax rate was 52.7% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of impairment charges, the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestiture of its Global Retail business, and tax rate differentials, partially offset by the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives.

[0000833444-23-000014:notes:158]
For the six months ended March 31, 2022, the Company's effective tax rate was 21.5% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of impairment charges, the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestiture of its Global Retail business, and tax rate differentials, partially offset by the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives.

[0000833444-23-000014:notes:159]
[same as prior period, unchanged from 0000833444-23-000005:notes:145]

[0000833444-23-000014:notes:160]
[same as prior period, unchanged from 0000833444-23-000005:notes:146]

[0000833444-23-000014:notes:161]
[same as prior period, unchanged from 0000833444-23-000005:notes:147]

[0000833444-23-000014:notes:162]
At September 30, 2022, the Company had gross tax-effected unrecognized tax benefits of $2,537 million, of which $1,973 million, if recognized, would impact the effective tax rate. Accrued interest, net at September 30, 2022 was approximately $284 million (net of tax benefit). Interest accrued during the six months ended March 31, 2023 and 2022 was approximately $56 million (net of tax benefit) and approximately $30 million (net of tax benefit), respectively. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-23-000014:notes:163]
In the U.S., fiscal years 2017 through 2018 are currently under exam by the Internal Revenue Service (“IRS”) for certain legal entities. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions:

[0000833444-23-000014:notes:164]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2021 |
| Germany |  | 2007 - 2018 |
| Luxembourg |  | 2017 - 2018 |
| Mexico |  | 2015 - 2017 |
| United Kingdom |  | 2014 - 2015; 2018; 2020 - 2021 |

[0000833444-23-000014:notes:165]
It is reasonably possible that tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-23-000014:notes:166]
[same as prior period, unchanged from 0000833444-23-000005:notes:152]

[0000833444-23-000014:notes:167]
The Company recorded restructuring and impairment costs of $418 million, which generated a $35 million tax benefit, during the three months ended March 31, 2023 and $384 million, which generated a $7 million tax benefit, during the three months ended March 31, 2022.

[0000833444-23-000014:notes:168]
The Company recorded restructuring and impairment costs of $763 million, which generated an $87 million tax benefit, during the six months ended March 31, 2023 and $433 million, which generated a $14 million tax benefit, during the six months ended March 31, 2022.

[0000833444-23-000014:notes:169]
During the three and six months ended March 31, 2022, the Company recorded a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries as a result of the planned divestiture of its Global Retail business which resulted in a tax charge of $13 million.

[0000833444-23-000014:notes:170]
[same as prior period, unchanged from 0000833444-23-000005:notes:154]

[0000833444-23-000014:notes:171]
Impacts of Tax Legislation
During the six months ended March 31, 2023 and 2022, tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-23-000014:notes:172]
[same as prior period, unchanged from 0000833444-23-000005:notes:156]

[0000833444-23-000014:notes:173]
[same as prior period, unchanged from 0000833444-23-000005:notes:157]

[0000833444-23-000014:notes:174]
[same as prior period, unchanged from 0000833444-23-000005:notes:158]

[0000833444-23-000014:notes:175]
[same as prior period, unchanged from 0000833444-23-000005:notes:159]

[0000833444-23-000014:notes:176]
[same as prior period, unchanged from 0000833444-23-000005:notes:160]

[0000833444-23-000014:notes:177]
Management evaluates the performance of its business segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-23-000014:notes:178]
[same as prior period, unchanged from 0000833444-23-000005:notes:162]

[0000833444-23-000014:notes:179]
|  | Net Sales |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Building Solutions North America | $ | 2,520 |  |  | $ | 2,227 |  |  | $ | 4,887 |  |  | $ | 4,379 |  |
| Building Solutions EMEA/LA | 1,031 |  |  | 958 |  |  | 2,006 |  |  | 1,917 |  |
| Building Solutions Asia Pacific | 667 |  |  | 623 |  |  | 1,313 |  |  | 1,298 |  |
| Global Products | 2,468 |  |  | 2,290 |  |  | 4,548 |  |  | 4,366 |  |
| Total net sales | $ | 6,686 |  |  | $ | 6,098 |  |  | $ | 12,754 |  |  | $ | 11,960 |  |

[0000833444-23-000014:notes:180]
|  | Segment EBITA |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Building Solutions North America | $ | 315 |  |  | $ | 235 |  |  | $ | 582 |  |  | $ | 485 |  |
| Building Solutions EMEA/LA | 69 |  |  | 79 |  |  | 144 |  |  | 183 |  |
| Building Solutions Asia Pacific | 79 |  |  | 74 |  |  | 147 |  |  | 142 |  |
| Global Products | 488 |  |  | 412 |  |  | 870 |  |  | 713 |  |
| Total segment EBITA | 951 |  |  | 800 |  |  | 1,743 |  |  | 1,523 |  |
| Corporate expenses | (131) |  |  | (60) |  |  | (240) |  |  | (130) |  |
| Amortization of intangible assets | (104) |  |  | (106) |  |  | (208) |  |  | (224) |  |
| Restructuring and impairment costs | (418) |  |  | (384) |  |  | (763) |  |  | (433) |  |
| Net mark-to-market adjustments | (4) |  |  | (89) |  |  | (1) |  |  | (32) |  |
| Net financing charges | (71) |  |  | (51) |  |  | (138) |  |  | (104) |  |
| Income before income taxes | $ | 223 |  |  | $ | 110 |  |  | $ | 393 |  |  | $ | 600 |  |


## us-gaap:GuaranteesTextBlock

[0000833444-23-000014:notes:181]
[same as prior period, unchanged from 0000833444-23-000005:notes:165]

[0000833444-23-000014:notes:182]
[same as prior period, unchanged from 0000833444-23-000005:notes:166]

[0000833444-23-000014:notes:183]
[same as prior period, unchanged from 0000833444-23-000005:notes:167]

[0000833444-23-000014:notes:184]
[same as prior period, unchanged from 0000833444-23-000005:notes:168]

[0000833444-23-000014:notes:185]
|  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |
| Balance at beginning of period | $ | 179 |  |  | $ | 192 |  |
| Accruals for warranties issued during the period | 69 |  |  | 44 |  |
| Settlements made (in cash or in kind) during the period | (57) |  |  | (39) |  |
| Accruals from acquisitions and divestitures | — |  |  | (1) |  |
| Changes in estimates to pre-existing warranties | 2 |  |  | (8) |  |
| Currency translation | 4 |  |  | (2) |  |
| Balance at end of period | $ | 197 |  |  | $ | 186 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-23-000014:notes:186]
Commitments and Contingencies
Environmental Matters

[0000833444-23-000014:notes:187]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000014:notes:188]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 42 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 223 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 265 |  |  | $ | 286 |  |

[0000833444-23-000014:notes:189]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. During the three months ended September 30, 2022, with the assistance of independent environmental consultants and taking into consideration investigation and remediation actions previously completed, new information available to the Company during the fourth quarter of fiscal 2022 and ongoing discussions with the Wisconsin Department of Natural Resources ("WDNR"), the Company completed a comprehensive long-term analysis and cost assessment related to the Company’s ongoing environmental remediation obligations. As a result of this analysis, the Company increased its accrual for environmental liabilities by $228 million in the fourth quarter of fiscal 2022, which are recorded on an undiscounted basis. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

[0000833444-23-000014:notes:190]
A substantial portion of the increase to the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to fire-fighting foams containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The increase in reserves was recorded as a result of several events that occurred in the three months ended September 30, 2022, including the completion and testing of the Groundwater Extraction and Treatment System (“GETS”) at the FTC (as further discussed below), the completion of resident surveys in Peshtigo regarding long-term drinking water solutions, correspondence with regulators on planned remediation activities, finalization of cost estimates for system upgrades and related long-term run rate costs in response to new permit requirements at the Stanton

[0000833444-23-000014:notes:191]
Street Facility, and the development of additional information through ongoing investigation and analysis. These events allowed the Company to develop estimates of costs associated with the long-term remediation actions expected to be performed over an estimated period of up to 20 years, including the continued operation of the GETS, the implementation of long-term drinking water solutions, continued monitoring and testing of the wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

[0000833444-23-000014:notes:192]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports, or elsewhere. In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, the WDNR approved Tyco Fire Products’ proposed GETS, a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has completed construction of the GETS, which is now in operation. Tyco Fire Products is also in the process of completing the removal and disposal of PFAS-affected soil from the FTC. In December 2022, Tyco Fire Products also began implementation of a long-term drinking water solution for some Peshtigo residents with the installation of the first deep aquifer private drinking wells.

[0000833444-23-000014:notes:193]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency (“EPA”) to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

[0000833444-23-000014:notes:194]
PFOA, PFOS, and other PFAS compounds are being studied by EPA and other environmental and health agencies and researchers. EPA initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water and in June 2022 an updated set of interim health advisory levels for PFOA and PFOS in drinking water, as well as final health advisory levels for two other types of PFAS (PFBS and GenX chemicals). In November 2022, EPA added a class definition of PFAS to the final version of EPA's fifth Contaminant Candidate List (CCL 5), which is a list of substances not currently subject to national drinking water regulation, but which EPA believes may require future regulation. In March 2023, EPA announced a proposed National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR proposes establishing legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion for each of PFOA and PFOS. EPA indicated that it anticipates finalizing the regulation by the end of 2023.

[0000833444-23-000014:notes:195]
In October 2021, EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act (“CERCLA”) hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains. In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under CERCLA.

[0000833444-23-000014:notes:196]
It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-23-000014:notes:197]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $17 million at both March 31, 2023 and September 30, 2022.

[0000833444-23-000014:notes:198]
FTC-Related Remediation and Litigation

[0000833444-23-000014:notes:199]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. In September 2022, the Governor of Wisconsin signed a scope statement setting out parameters for the WDNR to draft a final rule regarding groundwater quality standards for PFOA and PFOS, among other compounds. The WDNR is now in the process of drafting the rule.

[0000833444-23-000014:notes:200]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products responded to the WDNR’s letter by requesting additional necessary information. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. Tyco Fire Products responded to the WDNR’s September 2021 notice by the December 27, 2021 deadline set by WDNR and submitted additional updates to WDNR on October 25, 2022 and February 16, 2023. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

[0000833444-23-000014:notes:201]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR’s requests. The parties are proceeding with fact discovery and the court has

[0000833444-23-000014:notes:202]
set a trial date of December 3, 2024. The Company is vigorously defending this civil enforcement action and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

[0000833444-23-000014:notes:203]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina. The Company plans to vigorously defend against this case and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

[0000833444-23-000014:notes:204]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. These lawsuits are presently at the beginning stages of litigation. The Company is vigorously defending these cases and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

[0000833444-23-000014:notes:205]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-23-000014:notes:206]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-23-000014:notes:207]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to the MDL. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-23-000014:notes:208]
AFFF Putative Class Actions

[0000833444-23-000014:notes:209]
Chemguard and Tyco Fire Products are named in 39 pending putative class actions in federal courts originating from 15 states and territories. All but two of these cases have been direct-filed in or transferred to the MDL and it is anticipated that the remaining cases will be transferred to the MDL.

[0000833444-23-000014:notes:210]
AFFF Individual or Mass Actions

[0000833444-23-000014:notes:211]
There are more than 3,900 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 3,900 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and

[0000833444-23-000014:notes:212]
transferred. There are several matters that are proceeding in state courts, including actions in Arizona and Illinois.

[0000833444-23-000014:notes:213]
Tyco and Chemguard are also periodically notified by other individuals that they may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-23-000014:notes:214]
AFFF Municipal and Water Provider Cases

[0000833444-23-000014:notes:215]
Chemguard and Tyco Fire Products have been named as defendants in more than 350 cases involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 30 states. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation. The MDL court has set the first case for trial on June 5, 2023, (City of Stuart (Florida) v. 3M Co. et al.). On April 26, 2023, the parties entered a stipulation dismissing Chemguard with prejudice from the City of Stuart case, and it is expected that the parties will enter into a stipulation dismissing Tyco with prejudice from the City of Stuart case. The MDL Court has ordered the parties to conduct mediation of the water provider cases pending in the MDL.

[0000833444-23-000014:notes:216]
Tyco and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-23-000014:notes:217]
State or U.S. Territory Attorneys General Litigation related to AFFF

[0000833444-23-000014:notes:218]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-23-000014:notes:219]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-23-000014:notes:220]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752-000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio. The lawsuit seeks to recover costs and natural resource damages associated with the contamination. This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-23-000014:notes:221]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting

[0000833444-23-000014:notes:222]
from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

[0000833444-23-000014:notes:223]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000014:notes:224]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000014:notes:225]
In August 2020, Attorney General of the State of Michigan filed two substantially similar lawsuits—one in federal court and one in state court—against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within the State. The federal action has been transferred to the MDL, and the state court action has been removed to federal court and transferred to the MDL.

[0000833444-23-000014:notes:226]
In December 2020, the State of Mississippi filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

[0000833444-23-000014:notes:227]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

[0000833444-23-000014:notes:228]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. It is anticipated that these two cases will be removed to federal court and transferred to the MDL.

[0000833444-23-000014:notes:229]
In February 2022, the Attorney General of the State of Colorado filed a lawsuit in Colorado state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources, public health, and State property allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000014:notes:230]
In April 2022, the Attorney General of the State of Florida filed a lawsuit in Florida state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage to the State’s natural resources and public health allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000014:notes:231]
In May 2022, the Attorney General of the Commonwealth of Massachusetts filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the

[0000833444-23-000014:notes:232]
State’s natural resources, property, residents, and consumers allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

[0000833444-23-000014:notes:233]
In July 2022, the Attorney General of the State of Wisconsin filed a lawsuit in Wisconsin state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage to the State’s natural resources and public health allegedly resulting, in part, from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000014:notes:234]
In November 2022, the Attorney General of the State of California filed a lawsuit in California state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the manufacture, use, marketing, or sale of PFAS-containing products, including firefighting foams, at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000014:notes:235]
In March 2023, the Attorney General of the State of Maine filed a lawsuit in Maine state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of the State’s natural resources allegedly resulting from the manufacture, distribution, release, promotion, sale, and use of PFAS-containing AFFF within the state. It is anticipated that this complaint will be removed to federal court and transferred to the MDL.

[0000833444-23-000014:notes:236]
In March 2023, the Attorney General of the State of Illinois filed a lawsuit in Illinois state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of the State’s environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within the State. It is anticipated that this complaint will be removed to federal court and transferred to the MDL.

[0000833444-23-000014:notes:237]
Other AFFF Related Matters

[0000833444-23-000014:notes:238]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-23-000014:notes:239]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This complaint has been transferred to the MDL.

[0000833444-23-000014:notes:240]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-23-000014:notes:241]
Asbestos Matters

[0000833444-23-000014:notes:242]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-23-000014:notes:243]
The Company estimates the asbestos-related liability for pending and future claims and related defense costs on a discounted basis. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable.

[0000833444-23-000014:notes:244]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000014:notes:245]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 370 |  |  | 380 |  |
| Total asbestos-related liabilities | 428 |  |  | 438 |  |
| Other current assets | 37 |  |  | 37 |  |
| Other noncurrent assets | 275 |  |  | 263 |  |
| Total asbestos-related assets | 312 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 116 |  |  | $ | 138 |  |

[0000833444-23-000014:notes:246]
The following table presents the components of asbestos-related assets (in millions):

[0000833444-23-000014:notes:247]
|  | March 31, 2023 |  | September 30, 2022 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 253 |  |  | 239 |  |
| Total restricted assets | 259 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 53 |  |  | 55 |  |
| Total asbestos-related assets | $ | 312 |  |  | $ | 300 |  |

[0000833444-23-000014:notes:248]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be paid by Company affiliates). Estimated asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be paid through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-23-000014:notes:249]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and

[0000833444-23-000014:notes:250]
assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-23-000014:notes:251]
Self-Insured Liabilities

[0000833444-23-000014:notes:252]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage its self-insured liabilities.

[0000833444-23-000014:notes:253]
The following table presents the location and amount of self-insured liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000014:notes:254]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 92 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 233 |  |  | 230 |  |
| Total self-insured liabilities | $ | 347 |  |  | $ | 341 |  |

[0000833444-23-000014:notes:255]
The following table presents the location and amount of insurance receivables in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000014:notes:256]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current assets | $ | 10 |  |  | $ | 10 |  |
| Other noncurrent assets | 20 |  |  | 20 |  |
| Total insurance receivables | $ | 30 |  |  | $ | 30 |  |

[0000833444-23-000014:notes:257]
Other Matters

[0000833444-23-000014:notes:258]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock

[0000833444-23-000014:notes:259]
The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):
