# JCI 8-K — 0000833444-23-000011 filed 2023-05-05

## item codes, every 8-K on or before 2023-05-05

- 2023-05-05 0000833444-23-000011 — 2.02, 9.01
- 2023-03-14 0000833444-23-000007 — 5.07
- 2023-02-01 0000833444-23-000003 — 2.02, 9.01
- 2022-12-22 0000833444-22-000047 — 5.02
- 2022-12-09 0000833444-22-000045 — 5.02
- 2022-11-03 0000833444-22-000038 — 2.02, 9.01
- 2022-09-14 0001193125-22-244741 — 8.01, 9.01
- 2022-09-07 0001193125-22-240030 — 8.01, 9.01
- 2022-08-04 0000833444-22-000034 — 2.02, 9.01
- 2022-07-06 0000833444-22-000029 — 5.02, 9.01
- 2022-06-30 0000833444-22-000027 — 5.02
- 2022-05-04 0000833444-22-000014 — 2.02, 9.01
- 2022-03-11 0001193125-22-073382 — 5.07
- 2022-02-15 0000833444-22-000010 — 5.02
- 2022-02-02 0000833444-22-000003 — 2.02, 9.01
- 2021-12-10 0000833444-21-000050 — 5.02
- 2021-11-05 0000833444-21-000043 — 2.02, 9.01
- 2021-09-16 0001193125-21-275152 — 1.01, 8.01, 9.01
- 2021-07-30 0000833444-21-000038 — 2.02, 9.01
- 2021-05-03 0000833444-21-000023 — 8.01
- 2021-04-30 0000833444-21-000017 — 2.02, 9.01
- 2021-03-11 0000833444-21-000013 — 5.02, 5.07, 9.01
- 2021-02-17 0001193125-21-045768 — 7.01, 9.01
- 2021-01-29 0000833444-21-000009 — 2.02, 9.01
- 2021-01-07 0000833444-21-000004 — 7.01
- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2023-05-05

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-23-000011:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq2fy23.htm
EX-99.1

[0000833444-23-000011:8k_2_02:2]
Document

[0000833444-23-000011:8k_2_02:3]
Exhibit 99.1

[0000833444-23-000011:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-23-000011:8k_2_02:5]
Johnson Controls Reports Strong Revenue and EPS Growth in Q2 and Updates FY23 Guidance

[0000833444-23-000011:8k_2_02:6]
________________________________________________________________________________

[0000833444-23-000011:8k_2_02:7]
▪Q2 reported sales +10% versus prior year; +13% organically

[0000833444-23-000011:8k_2_02:8]
▪Q2 GAAP EPS of $0.19; Adjusted EPS of $0.75, up 19% versus prior year

[0000833444-23-000011:8k_2_02:9]
▪Q2 Orders +8% organically year-over year

[0000833444-23-000011:8k_2_02:10]
▪Record backlog of $11.7 billion, increased 9% organically year-over year

[0000833444-23-000011:8k_2_02:11]
▪Initiates fiscal Q3 and updates fiscal 2023 full year guidance

[0000833444-23-000011:8k_2_02:12]
______________________________________________________________________________

[0000833444-23-000011:8k_2_02:13]
CORK, Ireland, May 5, 2023 -- Johnson Controls International plc (NYSE: JCI), a global leader for smart, healthy and sustainable buildings, today reported fiscal second quarter 2023 GAAP earnings per share (“EPS”) from continuing operations of $0.19. Excluding special items, adjusted EPS from continuing operations was $0.75, up 19% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-23-000011:8k_2_02:14]
Sales in the quarter of $6.7 billion increased 10% compared to the prior year on an as reported basis and grew 13% organically. GAAP net income from continuing operations was $133 million. Adjusted net income from continuing operations of $517 million was up 17% versus the prior year. Earnings before interest and taxes (“EBIT”) was $294 million and EBIT margin was 4.4%. Adjusted EBIT was $716 million and adjusted EBIT margin was 10.7%, improving 70 basis points versus the prior year.

[0000833444-23-000011:8k_2_02:15]
“Johnson Controls delivered strong second quarter results led by double digit growth in sales and high single digit order growth,” said George Oliver, Chairman and CEO. “Our order pipeline remains healthy across all our vectors of growth and we are encouraged by the continued momentum within our Service business. Our leading technologies position us well in making buildings smarter, healthier, and more sustainable.”

[0000833444-23-000011:8k_2_02:16]
“Our second quarter results exceeded the high end of our guidance as healthy margin expansion contributed to strong double digit adjusted EPS growth,” said Olivier Leonetti, Chief Financial Officer. “Our backlog remains resilient and the pace of converting higher margin business gives us confidence in our ability to deliver on our full year expectations.”

[0000833444-23-000011:8k_2_02:17]
Page 1 of 18

[0000833444-23-000011:8k_2_02:18]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-23-000011:8k_2_02:19]
($ millions, except per-share amounts)

[0000833444-23-000011:8k_2_02:20]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal second quarter of 2022.

[0000833444-23-000011:8k_2_02:21]
Organic sales growth, adjusted sales, organic segment EBITA growth, total segment EBITA, adjusted segment EBITA, adjusted corporate expense, EBIT, adjusted EBIT, adjusted net income from continuing operations, adjusted EPS from continuing operations, and free cash flow are non-GAAP financial measures. For a reconciliation of non-GAAP measures and detail of the special items, refer to the attached footnotes.

[0000833444-23-000011:8k_2_02:22]
This press release includes forward-looking statements regarding organic revenue growth, adjusted segment EBITA margin improvement and adjusted EPS, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as mark-to-market adjustments. Organic revenue growth excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company's fiscal 2023 third quarter and full year GAAP financial results.

[0000833444-23-000011:8k_2_02:23]
A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-23-000011:8k_2_02:24]
|  |  | Fiscal Q2 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Sales |  | $6,098 |  | $6,686 |  | $6,098 |  | $6,686 |  |  |  |  |  |  |
| Segment EBITA |  | 800 |  | 951 |  | 768 |  | 921 |  |  |  |  |  |  |
| EBIT |  | 161 |  | 294 |  | 608 |  | 716 |  |  |  |  |  |  |
| Net income from continuing operations |  | 11 |  | 133 |  | 441 |  | 517 |  |  |  |  |  |  |
| Diluted EPS from continuing operations |  | $0.02 |  | $0.19 |  | $0.63 |  | $0.75 |  |  |  |  |  |  |

[0000833444-23-000011:8k_2_02:25]
Page 2 of 18

[0000833444-23-000011:8k_2_02:26]
SEGMENT RESULTS

[0000833444-23-000011:8k_2_02:27]
Building Solutions North America

[0000833444-23-000011:8k_2_02:28]
|  |  | Fiscal Q2 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Sales |  | $2,227 |  | $2,520 |  | $2,227 |  | $2,520 |  |  |  |  |  |  |
| Segment EBITA |  | 235 |  | 315 |  | 235 |  | 315 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 10.6% |  | 12.5% |  | 10.6% |  | 12.5% |  |  |  |  |  |  |

[0000833444-23-000011:8k_2_02:29]
Sales in the quarter of $2.5 billion increased 13% versus the prior year. Organic sales increased 14% over the prior year with growth in both Service and Install, led by strong performances in HVAC & Controls and Fire & Security.

[0000833444-23-000011:8k_2_02:30]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 8% year-over-year. Backlog at the end of the quarter of $7.7 billion increased 13% compared to the prior year, excluding M&A and adjusted for foreign currency.

[0000833444-23-000011:8k_2_02:31]
Segment EBITA was $315 million, up 34% versus the prior year. Segment EBITA margin of 12.5% expanded 190 basis points versus the prior year as higher margin backlog converted at a faster rate and productivity further accelerated.

[0000833444-23-000011:8k_2_02:32]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-23-000011:8k_2_02:33]
|  |  | Fiscal Q2 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Sales |  | $958 |  | $1,031 |  | $958 |  | $1,031 |  |  |  |  |  |  |
| Segment EBITA |  | 79 |  | 69 |  | 90 |  | 69 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 8.2% |  | 6.7% |  | 9.4% |  | 6.7% |  |  |  |  |  |  |

[0000833444-23-000011:8k_2_02:34]
Sales in the quarter of $1.0 billion increased 8% versus the prior year. Organic sales grew 12% versus the prior year, with low double-digit growth in Service and Install. Strength was broad based across our businesses, led by Fire & Security and HVAC & Controls. By region, Europe and Latin America experienced strong organic growth, while growth in the Middle East was more modest.

[0000833444-23-000011:8k_2_02:35]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 7% year-over-year. Backlog at the end of the quarter of $2.3 billion increased 5% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-23-000011:8k_2_02:36]
Page 3 of 18

[0000833444-23-000011:8k_2_02:37]
Segment EBITA was $69 million, down 13% versus the prior year. Segment EBITA margin of 6.7% declined 150 basis points versus the prior year as volume leverage was offset by FX headwinds and one-time nonrecurring items. Adjusted segment EBITA in Q2 2022 excludes a charge taken related to suspended Russian operations.

[0000833444-23-000011:8k_2_02:38]
Building Solutions Asia Pacific

[0000833444-23-000011:8k_2_02:39]
|  |  | Fiscal Q2 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Sales |  | $623 |  | $667 |  | $623 |  | $667 |  |  |  |  |  |  |
| Segment EBITA |  | 74 |  | 79 |  | 74 |  | 79 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 11.9% |  | 11.8% |  | 11.9% |  | 11.8% |  |  |  |  |  |  |

[0000833444-23-000011:8k_2_02:40]
Sales in the quarter of $667 million increased 7% versus the prior year. Sales increased 15% organically versus the prior year led by continued demand for HVAC & Controls. Organic Sales in China rebounded in the quarter, with strong double-digit growth in Service and Install.

[0000833444-23-000011:8k_2_02:41]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 9% year-over-year, led by demand for Commercial HVAC in China and Controls in Japan. Backlog at the end of the quarter of $1.7 billion declined 3% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-23-000011:8k_2_02:42]
Segment EBITA was $79 million, up 7% versus the prior year. Segment EBITA margin of 11.8% declined 10 basis points versus the prior year as higher margin backlog conversion was offset by FX headwinds.

[0000833444-23-000011:8k_2_02:43]
Page 4 of 18

[0000833444-23-000011:8k_2_02:44]
Global Products

[0000833444-23-000011:8k_2_02:45]
|  |  | Fiscal Q2 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Sales |  | $2,290 |  | $2,468 |  | $2,290 |  | $2,468 |  |  |  |  |  |  |
| Segment EBITA |  | 412 |  | 488 |  | 369 |  | 458 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 18.0% |  | 19.8% |  | 16.1% |  | 18.6% |  |  |  |  |  |  |

[0000833444-23-000011:8k_2_02:46]
Sales in the quarter of $2.5 billion increased 8% versus the prior year. Organic sales grew 12% versus the prior year driven by strong growth in Applied, Fire Detection, Industrial Refrigeration, and Commercial Ducted HVAC products.

[0000833444-23-000011:8k_2_02:47]
Segment EBITA was $488 million, up 18% versus the prior year. Segment EBITA margin of 19.8% expanded 180 basis points versus the prior year driven by strong price realization and improved productivity. Adjusted segment EBITA in Q2 2022 and Q2 2023 excludes the favorable impact of reductions to the Silent-Aire earnout liability.

[0000833444-23-000011:8k_2_02:48]
Corporate

[0000833444-23-000011:8k_2_02:49]
|  |  | Fiscal Q2 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Corporate Expense |  | ($60) |  | ($131) |  | ($60) |  | ($101) |  |  |  |  |  |  |

[0000833444-23-000011:8k_2_02:50]
Corporate expense was $131 million in the quarter, an increase of 118% compared to the prior year. Adjusted Corporate expense in Q2 2023 excludes transaction/separation costs.

[0000833444-23-000011:8k_2_02:51]
OTHER Q2 ITEMS

[0000833444-23-000011:8k_2_02:52]
▪Cash provided by operating activities from continuing operations was $314 million, while cash provided by operating activities from continuing operations, excluding JC Capital, was $356 million. Capital expenditures were $121 million, resulting in a free cash flow from continuing operations of $235 million.

[0000833444-23-000011:8k_2_02:53]
▪The Company repurchased 1.5 million shares for approximately $93 million. Year-to-date through March, the Company repurchased 4.3 million shares for approximately $247 million.

[0000833444-23-000011:8k_2_02:54]
Page 5 of 18

[0000833444-23-000011:8k_2_02:55]
▪The Company recorded net pre-tax mark-to-market losses of $4 million related primarily to the remeasurement of the Company’s pension and postretirement benefit plans and restricted asbestos investments.

[0000833444-23-000011:8k_2_02:56]
▪The Company recorded pre-tax restructuring and impairment costs of $418 million, including $24 million of restructuring charges, a $184 million goodwill impairment charge and a $210 million impairment related to a business classified as held for sale.

[0000833444-23-000011:8k_2_02:57]
THIRD QUARTER GUIDANCE

[0000833444-23-000011:8k_2_02:58]
The Company initiated fiscal 2023 third quarter guidance:

[0000833444-23-000011:8k_2_02:59]
▪Organic revenue growth of ~10% year-over-year

[0000833444-23-000011:8k_2_02:60]
▪Adjusted segment EBITA margin improvement of 120 to 130 basis points year-over-year

[0000833444-23-000011:8k_2_02:61]
▪Adjusted EPS before special items of $1.01 to $1.03; representing 19% to 21% growth year-over-year

[0000833444-23-000011:8k_2_02:62]
FULL YEAR GUIDANCE

[0000833444-23-000011:8k_2_02:63]
The Company updated its fiscal 2023 full year EPS guidance:

[0000833444-23-000011:8k_2_02:64]
▪Organic revenue growth ~10% year-over year (previously guided at a range from high single-digits to low double-digits growth)

[0000833444-23-000011:8k_2_02:65]
▪Adjusted segment EBITA margin improvement of 100 to 120 basis points, year-over-year (previously guided to 90 to 120 basis point improvement)

[0000833444-23-000011:8k_2_02:66]
▪Adjusted EPS before special items of $3.50 to $3.60; representing 17% to 20% growth year-over-year (previously guided to $3.30 to $3.60)

[0000833444-23-000011:8k_2_02:67]
CONFERENCE CALL & WEBCAST INFO

[0000833444-23-000011:8k_2_02:68]
Johnson Controls will host a conference call to discuss this quarter’s results at 8:30 a.m. ET today, which can be accessed by dialing 844-763-8274 (in the United States) or +1-412-717-9224 (outside the United States), or via webcast. A slide presentation will accompany the prepared remarks and has been posted on the investor relations section of the Johnson Controls website at https://investors.johnsoncontrols.com/news-and-events/events-and-presentations. A replay will be made available approximately two hours following the conclusion of the conference call.

[0000833444-23-000011:8k_2_02:69]
About Johnson Controls:

[0000833444-23-000011:8k_2_02:70]
At Johnson Controls (NYSE:JCI), we transform the environments where people live, work, learn and play. As the global leader in smart, healthy and sustainable buildings, our mission is to reimagine the performance of buildings to serve people, places and the planet.

[0000833444-23-000011:8k_2_02:71]
Page 6 of 18

[0000833444-23-000011:8k_2_02:72]
Building on a proud history of nearly 140 years of innovation, we deliver the blueprint of the future for industries such as healthcare, schools, data centers, airports, stadiums, manufacturing and beyond through OpenBlue, our comprehensive digital offering.

[0000833444-23-000011:8k_2_02:73]
Today, with a global team of 100,000 experts in more than 150 countries, Johnson Controls offers the world`s largest portfolio of building technology and software as well as service solutions from some of the most trusted names in the industry.

[0000833444-23-000011:8k_2_02:74]
Visit www.johnsoncontrols.com for more information and follow @Johnson Controls on social platforms.

[0000833444-23-000011:8k_2_02:75]
JOHNSON CONTROLS CONTACTS:

[0000833444-23-000011:8k_2_02:76]
| INVESTOR CONTACTS: | MEDIA CONTACT: |  |  |  |
| Jim Lucas | Danielle Canzanella |  |  |  |
| Direct: +1 651.391.3182 | Direct: +1 203.499.8297 |  |  |  |
| Email: jim.lucas@jci.com | Email: danielle.canzanella@jci.com |  |  |  |
| Michael Gates |  |  |  |  |
| Direct: +1 414.524.5785 |  |  |  |  |
| Email: michael.j.gates@jci.com |  |  |  |  |

[0000833444-23-000011:8k_2_02:77]
###

[0000833444-23-000011:8k_2_02:78]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-23-000011:8k_2_02:79]
Page 7 of 18

[0000833444-23-000011:8k_2_02:80]
including economic sanctions, increased tariffs or trade restrictions; maintaining the capacity, reliability and security of Johnson Controls enterprise information technology infrastructure; the ability to manage the lifecycle cybersecurity risk in the development, deployment and operation of Johnson Controls digital platforms and services; the risk of infringement or expiration of intellectual property rights; Johnson Controls ability to manage the impacts of natural disasters, climate change, pandemics and outbreaks of contagious diseases and other adverse public health developments, such as the COVID-19 pandemic; the ability of Johnson Controls to drive organizational improvement; any delay or inability of Johnson Controls to realize the expected benefits and synergies of recent portfolio transactions; the outcome of litigation and governmental proceedings; the ability to hire and retain senior management and other key personnel; the tax treatment of recent portfolio transactions; significant transaction costs and/or unknown liabilities associated with such transactions; labor shortages, work stoppages, union negotiations, labor disputes and other matters associated with the labor force; and the cancellation of or changes to commercial arrangements. A detailed discussion of risks related to Johnson Controls business is included in the section entitled "Risk Factors" in Johnson Controls Annual Report on Form 10-K for the 2022 fiscal year filed with the SEC on November 15, 2022, which is available at www.sec.gov and www.johnsoncontrols.com under the "Investors" tab. The description of certain of these risks is supplemented in Item 1A of Part II of Johnson Controls subsequently filed Quarterly Reports on Form 10-Q. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-23-000011:8k_2_02:81]
###

[0000833444-23-000011:8k_2_02:82]
Non-GAAP Financial Information

[0000833444-23-000011:8k_2_02:83]
This press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include restructuring and impairment costs, net mark-to-market adjustments, Silent-Aire other nonrecurring items, certain transaction/separation costs, Silent-Aire earn-out adjustment, charges attributable to the suspension of operations in Russia, and warehouse fire loss. Financial information regarding organic sales growth, adjusted sales, EBIT, EBIT margin, adjusted EBIT, adjusted EBIT margin, organic segment EBITA growth, total segment EBITA, adjusted segment EBITA, adjusted segment EBITA margin, adjusted Corporate expense, free cash flow, free cash flow conversion and adjusted net income from continuing operations are also presented, which are non-GAAP performance measures. Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of Johnson Controls. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.  For further information on the calculation of the non-GAAP measures and a reconciliation of these non-GAAP measures, refer to the attached footnotes.

[0000833444-23-000011:8k_2_02:84]
###

[0000833444-23-000011:8k_2_02:85]
Page 8 of 18

[0000833444-23-000011:8k_2_02:86]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Net sales | $ | 6,686 |  |  |  | $ | 6,098 |  |  |
| Cost of sales | 4,445 |  |  |  | 4,141 |  |  |
|  | Gross profit | 2,241 |  |  |  | 1,957 |  |  |
| Selling, general and administrative expenses | (1,579) |  |  |  | (1,454) |  |  |
| Restructuring and impairment costs | (418) |  |  |  | (384) |  |  |
| Net financing charges | (71) |  |  |  | (51) |  |  |
| Equity income | 50 |  |  |  | 42 |  |  |
| Income before income taxes | 223 |  |  |  | 110 |  |  |
| Income tax provision | 49 |  |  |  | 58 |  |  |
| Net income | 174 |  |  |  | 52 |  |  |
| Income attributable to noncontrolling interests | 41 |  |  |  | 41 |  |  |
| Net income attributable to JCI | $ | 133 |  |  |  | $ | 11 |  |  |
| Diluted earnings per share | $ | 0.19 |  |  |  | $ | 0.02 |  |  |
| Diluted weighted average shares | 689.7 |  |  |  | 702.7 |  |  |
| Shares outstanding at period end | 686.1 |  |  |  | 695.7 |  |  |

[0000833444-23-000011:8k_2_02:87]
Page 9 of 18

[0000833444-23-000011:8k_2_02:88]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Six Months Ended March 31, |
|  |  | 2023 |  |  | 2022 |
| Net sales | $ | 12,754 |  |  |  | $ | 11,960 |  |
| Cost of sales | 8,422 |  |  |  | 8,112 |  |
|  | Gross profit | 4,332 |  |  |  | 3,848 |  |
| Selling, general and administrative expenses | (3,150) |  |  |  | (2,823) |  |
| Restructuring and impairment costs | (763) |  |  |  | (433) |  |
| Net financing charges | (138) |  |  |  | (104) |  |
| Equity income | 112 |  |  |  | 112 |  |
| Income before income taxes | 393 |  |  |  | 600 |  |
| Income tax provision | 63 |  |  |  | 129 |  |
| Net income | 330 |  |  |  | 471 |  |
| Income attributable to noncontrolling interests | 79 |  |  |  | 79 |  |
| Net income attributable to JCI | $ | 251 |  |  |  | $ | 392 |  |
| Diluted earnings per share | $ | 0.36 |  |  |  | $ | 0.56 |  |
| Diluted weighted average shares | 690.0 |  |  |  | 706.2 |  |
| Shares outstanding at period end | 686.1 |  |  |  | 695.7 |  |

[0000833444-23-000011:8k_2_02:89]
Page 10 of 18

[0000833444-23-000011:8k_2_02:90]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | March 31,2023 |  | September 30,2022 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 1,975 |  |  | $ | 2,031 |  |
| Accounts receivable - net | 6,002 |  |  | 5,528 |  |
| Inventories | 3,048 |  |  | 2,510 |  |
| Assets held for sale | 446 |  |  | 387 |  |
| Other current assets | 1,285 |  |  | 1,229 |  |
|  | Current assets | 12,756 |  |  | 11,685 |  |
| Property, plant and equipment - net | 3,094 |  |  | 3,042 |  |
| Goodwill | 17,559 |  |  | 17,328 |  |
| Other intangible assets - net | 4,633 |  |  | 4,641 |  |
| Investments in partially-owned affiliates | 1,065 |  |  | 963 |  |
| Noncurrent assets held for sale | 378 |  |  | 751 |  |
| Other noncurrent assets | 3,935 |  |  | 3,748 |  |
|  | Total assets | $ | 43,420 |  |  | $ | 42,158 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 2,659 |  |  | $ | 1,534 |  |
| Accounts payable and accrued expenses | 5,095 |  |  | 5,219 |  |
| Liabilities held for sale | 316 |  |  | 236 |  |
| Other current liabilities | 4,333 |  |  | 4,250 |  |
|  | Current liabilities | 12,403 |  |  | 11,239 |  |
| Long-term debt | 7,832 |  |  | 7,426 |  |
| Other noncurrent liabilities | 6,048 |  |  | 6,029 |  |
| Noncurrent liabilities held for sale | 59 |  |  | 62 |  |
| Shareholders' equity attributable to JCI | 15,890 |  |  | 16,268 |  |
| Noncontrolling interests | 1,188 |  |  | 1,134 |  |
|  | Total liabilities and equity | $ | 43,420 |  |  | $ | 42,158 |  |

[0000833444-23-000011:8k_2_02:91]
Page 11 of 18

[0000833444-23-000011:8k_2_02:92]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |  |  |
|  |  |  |  |  |  | Three Months Ended March 31, |  |  |
|  |  |  |  |  |  | 2023 |  |  | 2022 |  |  |
| Operating Activities |  |  |  |  |  |  |
| Net income attributable to JCI | $ | 133 |  |  |  | $ | 11 |  |  |  |
| Income attributable to noncontrolling interests | 41 |  |  |  | 41 |  |  |  |
| Net income | 174 |  |  |  | 52 |  |  |  |
| Adjustments to reconcile net income to cash provided (used) by operating activities: |  |  |  |  |  |  |
|  |  | Depreciation and amortization | 206 |  |  |  | 208 |  |  |  |
|  |  | Pension and postretirement benefit expense | 3 |  |  |  | 31 |  |  |  |
|  |  | Pension and postretirement contributions | (17) |  |  |  | (35) |  |  |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | 1 |  |  |  | 38 |  |  |  |
|  |  | Deferred income taxes | (76) |  |  |  | (65) |  |  |  |
|  |  | Non-cash restructuring and impairment costs | 397 |  |  |  | 361 |  |  |  |
|  |  | Other - net | (29) |  |  |  | (8) |  |  |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |  |  |
|  |  |  |  | Accounts receivable | (272) |  |  |  | (231) |  |  |  |
|  |  |  |  | Inventories | (145) |  |  |  | (243) |  |  |  |
|  |  |  |  | Other assets | (101) |  |  |  | (143) |  |  |  |
|  |  |  |  | Restructuring reserves | (31) |  |  |  | (38) |  |  |  |
|  |  |  |  | Accounts payable and accrued liabilities | 183 |  |  |  | 156 |  |  |  |
|  |  |  |  | Accrued income taxes | 21 |  |  |  | (151) |  |  |  |
|  |  |  |  |  | Cash provided (used) by operating activities from continuing operations | 314 |  |  |  | (68) |  |  |  |
| Investing Activities |  |  |  |  |  |  |
| Capital expenditures | (121) |  |  |  | (125) |  |  |  |
| Acquisition of businesses, net of cash acquired | (10) |  |  |  | (16) |  |  |  |
| Other - net | 6 |  |  |  | 27 |  |  |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (125) |  |  |  | (114) |  |  |  |
| Financing Activities |  |  |  |  |  |  |
| Increase in short and long-term debt - net | 648 |  |  |  | 1,666 |  |  |  |
| Stock repurchases and retirements | (93) |  |  |  | (509) |  |  |  |
| Payment of cash dividends | (240) |  |  |  | (239) |  |  |  |
| Dividends paid to noncontrolling interests | (62) |  |  |  | (118) |  |  |  |
| Employee equity-based compensation withholding taxes | (2) |  |  |  | (2) |  |  |  |
| Other - net | 2 |  |  |  | 3 |  |  |  |
|  |  |  |  |  | Cash provided by financing activities from continuing operations | 253 |  |  |  | 801 |  |  |  |
| Discontinued Operations |  |  |  |  |  |  |
| Net cash used by operating activities | — |  |  |  | — |  |  |  |
| Net cash used by investing activities | — |  |  |  | — |  |  |  |
| Net cash used by financing activities | — |  |  |  | — |  |  |  |
|  |  |  |  |  | Net cash flows used by discontinued operations | — |  |  |  | — |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 22 |  |  |  | (21) |  |  |  |
| Increase in cash, cash equivalents and restricted cash | $ | 464 |  |  |  | $ | 598 |  |  |  |

[0000833444-23-000011:8k_2_02:93]
Page 12 of 18

[0000833444-23-000011:8k_2_02:94]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Six Months Ended March 31, |
|  |  |  |  |  |  | 2023 |  |  | 2022 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI | $ | 251 |  |  |  | $ | 392 |  |
| Income attributable to noncontrolling interests | 79 |  |  |  | 79 |  |
| Net income | 330 |  |  |  | 471 |  |
| Adjustments to reconcile net income to cash provided (used) by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 409 |  |  |  | 432 |  |
|  |  | Pension and postretirement benefit income | (3) |  |  |  | (51) |  |
|  |  | Pension and postretirement contributions | (26) |  |  |  | (76) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (55) |  |  |  | 20 |  |
|  |  | Deferred income taxes | (168) |  |  |  | (97) |  |
|  |  | Non-cash restructuring and impairment costs | 691 |  |  |  | 361 |  |
|  |  | Other - net | (26) |  |  |  | (7) |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (360) |  |  |  | (306) |  |
|  |  |  |  | Inventories | (493) |  |  |  | (619) |  |
|  |  |  |  | Other assets | (169) |  |  |  | (206) |  |
|  |  |  |  | Restructuring reserves | (17) |  |  |  | (19) |  |
|  |  |  |  | Accounts payable and accrued liabilities | (155) |  |  |  | 489 |  |
|  |  |  |  | Accrued income taxes | 60 |  |  |  | (68) |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 18 |  |  |  | 324 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (255) |  |  |  | (260) |  |
| Acquisition of businesses, net of cash acquired | (89) |  |  |  | (124) |  |
| Other - net | 30 |  |  |  | 52 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (314) |  |  |  | (332) |  |
| Financing Activities |  |  |  |  |
| Increase in short and long-term debt - net | 1,068 |  |  |  | 2,059 |  |
| Stock repurchases and retirements | (247) |  |  |  | (1,035) |  |
| Payment of cash dividends | (481) |  |  |  | (430) |  |
| Dividends paid to noncontrolling interests | (72) |  |  |  | (118) |  |
| Employee equity-based compensation withholding taxes | (32) |  |  |  | (49) |  |
| Other - net | 26 |  |  |  | 17 |  |
|  |  |  |  |  | Cash provided by financing activities from continuing operations | 262 |  |  |  | 444 |  |
| Discontinued Operations |  |  |  |  |
| Net cash used by operating activities | — |  |  |  | (4) |  |
| Net cash used by investing activities | — |  |  |  | — |  |
| Net cash used by financing activities | — |  |  |  | — |  |
|  |  |  |  |  | Net cash flows used by discontinued operations | — |  |  |  | (4) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 8 |  |  |  | 46 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | $ | (26) |  |  |  | $ | 478 |  |

[0000833444-23-000011:8k_2_02:95]
Page 13 of 18

[0000833444-23-000011:8k_2_02:96]
FOOTNOTES

[0000833444-23-000011:8k_2_02:97]
1. Financial Summary

[0000833444-23-000011:8k_2_02:98]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans, restructuring and impairment costs and net financing charges.

[0000833444-23-000011:8k_2_02:99]
| (in millions; unaudited) | Three Months Ended March 31, |
|  | 2023 |  | 2022 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 315 |  |  | $ | 315 |  |  | $ | 235 |  |  | $ | 235 |  |
| Building Solutions EMEA/LA | 69 |  |  | 69 |  |  | 79 |  |  | 90 |  |
| Building Solutions Asia Pacific | 79 |  |  | 79 |  |  | 74 |  |  | 74 |  |
| Global Products | 488 |  |  | 458 |  |  | 412 |  |  | 369 |  |
| Segment EBITA | 951 |  |  | 921 |  |  | 800 |  |  | 768 |  |
| Corporate expenses (2) | (131) |  |  | (101) |  |  | (60) |  |  | (60) |  |
| Amortization of intangible assets (3) | (104) |  |  | (104) |  |  | (106) |  |  | (100) |  |
| Net mark-to-market losses (4) | (4) |  |  | — |  |  | (89) |  |  | — |  |
| Restructuring and impairment costs (5) | (418) |  |  | — |  |  | (384) |  |  | — |  |
| EBIT (6) | 294 |  |  | 716 |  |  | 161 |  |  | 608 |  |
| EBIT margin (6) | 4.4 | % |  | 10.7 | % |  | 2.6 | % |  | 10.0 | % |
| Net financing charges | (71) |  |  | (71) |  |  | (51) |  |  | (51) |  |
| Income before income taxes | 223 |  |  | 645 |  |  | 110 |  |  | 557 |  |
| Income tax provision (7) | (49) |  |  | (87) |  |  | (58) |  |  | (75) |  |
| Net income | 174 |  |  | 558 |  |  | 52 |  |  | 482 |  |
| Income attributable to noncontrolling interests (8) | (41) |  |  | (41) |  |  | (41) |  |  | (41) |  |
| Net income attributable to JCI | $ | 133 |  |  | $ | 517 |  |  | $ | 11 |  |  | $ | 441 |  |

[0000833444-23-000011:8k_2_02:100]
| (in millions; unaudited) | Six Months Ended March 31, |
|  | 2023 |  | 2022 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 582 |  |  | $ | 582 |  |  | $ | 485 |  |  | $ | 485 |  |
| Building Solutions EMEA/LA | 144 |  |  | 144 |  |  | 183 |  |  | 194 |  |
| Building Solutions Asia Pacific | 147 |  |  | 147 |  |  | 142 |  |  | 142 |  |
| Global Products | 870 |  |  | 880 |  |  | 713 |  |  | 670 |  |
| Segment EBITA | 1,743 |  |  | 1,753 |  |  | 1,523 |  |  | 1,491 |  |
| Corporate expenses (2) | (240) |  |  | (183) |  |  | (130) |  |  | (130) |  |
| Amortization of intangible assets (3) | (208) |  |  | (208) |  |  | (224) |  |  | (211) |  |
| Net mark-to-market losses (4) | (1) |  |  | — |  |  | (32) |  |  | — |  |
| Restructuring and impairment costs (5) | (763) |  |  | — |  |  | (433) |  |  | — |  |
| EBIT (6) | 531 |  |  | 1,362 |  |  | 704 |  |  | 1,150 |  |
| EBIT margin (6) | 4.2 | % |  | 10.7 | % |  | 5.9 | % |  | 9.6 | % |
| Net financing charges | (138) |  |  | (138) |  |  | (104) |  |  | (104) |  |
| Income before income taxes | 393 |  |  | 1,224 |  |  | 600 |  |  | 1,046 |  |
| Income tax provision (7) | (63) |  |  | (165) |  |  | (129) |  |  | (141) |  |
| Net income | 330 |  |  | 1,059 |  |  | 471 |  |  | 905 |  |
| Income attributable to noncontrolling interests (8) | (79) |  |  | (79) |  |  | (79) |  |  | (84) |  |
| Net income attributable to JCI | $ | 251 |  |  | $ | 980 |  |  | $ | 392 |  |  | $ | 821 |  |

[0000833444-23-000011:8k_2_02:101]
(1) The Company's press release contains financial information regarding total segment EBITA, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted segment EBITA excludes other non-recurring items that are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-23-000011:8k_2_02:102]
A reconciliation of segment EBITA to net income is shown earlier within this footnote. The following is the three months ended March 31, 2023 and 2022 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-23-000011:8k_2_02:103]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building Solutions Asia Pacific |  | Total Field |  | Global Products |  | ConsolidatedJCI plc |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Segment EBITA as reported | $ | 315 |  |  | $ | 235 |  |  | $ | 69 |  |  | $ | 79 |  |  | $ | 79 |  |  | $ | 74 |  |  | $ | 463 |  |  | $ | 388 |  |  | $ | 488 |  |  | $ | 412 |  |  | $ | 951 |  |  | $ | 800 |  |
| Segment EBITA margin as reported (9) | 12.5 | % |  | 10.6 | % |  | 6.7 | % |  | 8.2 | % |  | 11.8 | % |  | 11.9 | % |  | 11.0 | % |  | 10.2 | % |  | 19.8 | % |  | 18.0 | % |  | 14.2 | % |  | 13.1 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Silent-Aire earn-out adjustment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (30) |  |  | (43) |  |  | (30) |  |  | (43) |  |
| Charges attributable to the suspension of operations in Russia | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Adjusted segment EBITA | $ | 315 |  |  | $ | 235 |  |  | $ | 69 |  |  | $ | 90 |  |  | $ | 79 |  |  | $ | 74 |  |  | $ | 463 |  |  | $ | 399 |  |  | $ | 458 |  |  | $ | 369 |  |  | $ | 921 |  |  | $ | 768 |  |
| Adjusted segment EBITA margin (9) | 12.5 | % |  | 10.6 | % |  | 6.7 | % |  | 9.4 | % |  | 11.8 | % |  | 11.9 | % |  | 11.0 | % |  | 10.5 | % |  | 18.6 | % | ` | 16.1 | % |  | 13.8 | % |  | 12.6 | % |

[0000833444-23-000011:8k_2_02:104]
Page 14 of 18

[0000833444-23-000011:8k_2_02:105]
The following is the six months ended March 31, 2023 and 2022 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-23-000011:8k_2_02:106]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building Solutions Asia Pacific |  | Total Field |  | Global Products |  | ConsolidatedJCI plc |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Segment EBITA as reported | $ | 582 |  |  | $ | 485 |  |  | $ | 144 |  |  | $ | 183 |  |  | $ | 147 |  |  | $ | 142 |  |  | $ | 873 |  |  | $ | 810 |  |  | $ | 870 |  |  | $ | 713 |  |  | $ | 1,743 |  |  | $ | 1,523 |  |
| Segment EBITA margin as reported | 11.9 | % |  | 11.1 | % |  | 7.2 | % |  | 9.5 | % |  | 11.2 | % |  | 10.9 | % |  | 10.6 | % |  | 10.7 | % |  | 19.1 | % |  | 16.3 | % |  | 13.7 | % |  | 12.7 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Silent-Aire earn-out adjustment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (30) |  |  | (43) |  |  | (30) |  |  | (43) |  |
| Warehouse fire loss | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 40 |  |  | — |  |  | 40 |  |  | — |  |
| Charges attributable to the suspension of operations in Russia | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Adjusted segment EBITA | $ | 582 |  |  | $ | 485 |  |  | $ | 144 |  |  | $ | 194 |  |  | $ | 147 |  |  | $ | 142 |  |  | $ | 873 |  | $ | 821 |  | $ | 880 |  | $ | 670 |  | $ | 1,753 |  | $ | 1,491 |
| Adjusted segment EBITA margin | 11.9 | % |  | 11.1 | % |  | 7.2 | % |  | 10.1 | % |  | 11.2 | % |  | 10.9 | % |  | 10.6 | % |  | 10.8 | % |  | 19.3 | % |  | 15.3 | % |  | 13.7 | % |  | 12.5 | % |

[0000833444-23-000011:8k_2_02:107]
(2) Adjusted Corporate expenses for the three and six months ended March 31, 2023 excludes certain transaction/separation costs of $30 million and $57 million, respectively.

[0000833444-23-000011:8k_2_02:108]
(3) Adjusted amortization of intangible assets for the three and six months ended March 31, 2022 excludes nonrecurring intangible asset amortization related to Silent-Aire purchase accounting of $6 million and $13 million, respectively.

[0000833444-23-000011:8k_2_02:109]
(4) Adjusted results for the three and six months ended March 31, 2023 exclude net mark-to-market losses on restricted asbestos investments and pension and postretirement plans of $4 million and $1 million, respectively. The three and six months ended March 31, 2022 exclude net mark-to-market losses on restricted asbestos investments and pension and postretirement plans of $89 million and $32 million, respectively.

[0000833444-23-000011:8k_2_02:110]
(5) Adjusted results for the three and six months ended March 31, 2023 exclude restructuring and impairment costs of $418 million and $763 million, respectively. The restructuring actions and impairment costs for the three and six months ended March 31, 2023 are related primarily to workforce reductions, impairment of goodwill attributable to the Company's Silent-Aire reporting unit, impairment of assets associated with businesses classified as held for sale and other asset impairments. Adjusted results for the three and six months ended March 31, 2022 exclude restructuring and impairment costs of $384 million and $433 million, respectively. The restructuring actions and impairment costs for the three and six months ended March 31, 2022 are related primarily to the impairment of assets associated with a business classified as held for sale, workforce reductions and other asset impairments.

[0000833444-23-000011:8k_2_02:111]
(6) Management defines earnings before interest and taxes (EBIT) as income before net financing charges, income taxes and noncontrolling interests. EBIT margin is defined as EBIT divided by net sales. EBIT and EBIT margin are non-GAAP performance measures. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company. A reconciliation of EBIT to net income is shown earlier within this footnote.

[0000833444-23-000011:8k_2_02:112]
(7) Adjusted income tax provision for the three and six months ended March 31, 2023 excludes the net tax benefit of pre-tax adjusting items of $38 million and $102 million, respectively. Adjusted income tax provision for the three months ended March 31, 2022 excludes the net tax benefit of pre-tax adjusting items of $30 million, partially offset by tax provisions related to APB23 adjustments attributable to a business classified as held for sale of $13 million. Adjusted income tax provision for the six months ended March 31, 2022 excludes the net tax benefit of pre-tax adjusting items of $25 million, partially offset by tax provisions related to APB23 adjustments attributable to a business classified as held for sale of $13 million.

[0000833444-23-000011:8k_2_02:113]
(8) Adjusted income from continuing operations attributable to noncontrolling interests for the six months ended March 31, 2022 excludes $5 million impact from restructuring and impairment costs.

[0000833444-23-000011:8k_2_02:114]
(9) Segment EBITA margin is defined as segment EBITA divided by segment net sales, as disclosed in the Company's press release.

[0000833444-23-000011:8k_2_02:115]
The Company's press release and earnings presentation include forward-looking statements regarding organic revenue growth, adjusted segment EBITA margin improvement, free cash flow and adjusted EPS, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as mark-to-market adjustments. Organic revenue growth excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s fiscal 2023 third quarter and full year GAAP financial results.

[0000833444-23-000011:8k_2_02:116]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-23-000011:8k_2_02:117]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items shown in the table below are excluded because these items are not considered to be directly related to the underlying operating performance of the Company. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-23-000011:8k_2_02:118]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-23-000011:8k_2_02:119]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc |  |
|  | Three Months Ended |  | Six Months Ended |  |
|  | March 31, |  | March 31, |  |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |
| Earnings per share as reported for JCI plc | $ | 0.19 |  |  | $ | 0.02 |  |  | $ | 0.36 |  |  | $ | 0.56 |  |  |
| Adjusting items: |  |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | 0.01 |  |  | 0.13 |  |  | — |  |  | 0.05 |  |  |
| Related tax impact | — |  |  | (0.03) |  |  | — |  |  | (0.01) |  |  |
| Restructuring and impairment costs | 0.61 |  |  | 0.55 |  |  | 1.11 |  |  | 0.61 |  |  |
| Related tax impact | (0.05) |  |  | (0.01) |  |  | (0.13) |  |  | (0.02) |  |  |
| NCI impact of restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (0.01) |  |  |
| Silent-Aire other nonrecurring costs | — |  |  | 0.01 |  |  | — |  |  | 0.02 |  |  |
| Transaction/separation costs | 0.04 |  |  | — |  |  | 0.08 |  |  | — |  |  |
| Related tax impact | — |  |  | — |  |  | (0.01) |  |  | — |  |  |
| Silent-Aire earn-out adjustment | (0.04) |  |  | (0.06) |  |  | (0.04) |  |  | (0.06) |  |  |
| Warehouse fire loss | — |  |  | — |  |  | 0.06 |  |  | — |  |  |
| Related tax impact | — |  |  | — |  |  | (0.01) |  |  | — |  |  |
| Charges attributable to the suspension of operations in Russia | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  |
| Discrete tax items | — |  |  | 0.02 |  |  | — |  |  | 0.02 |  |  |
| Adjusted earnings per share for JCI plc* | $ | 0.75 |  |  | $ | 0.63 |  |  | $ | 1.42 |  |  | $ | 1.16 |  |  |

[0000833444-23-000011:8k_2_02:120]
* May not sum due to rounding

[0000833444-23-000011:8k_2_02:121]
Page 15 of 18

[0000833444-23-000011:8k_2_02:122]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-23-000011:8k_2_02:123]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, |  | March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 686.8 |  |  | 699.1 |  |  | 686.9 |  |  | 701.8 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |
| and unvested performance share awards | 2.9 |  |  | 3.6 |  |  | 3.1 |  |  | 4.4 |  |
| Diluted weighted average shares outstanding | 689.7 |  |  | 702.7 |  |  | 690.0 |  |  | 706.2 |  |

[0000833444-23-000011:8k_2_02:124]
3. Organic Growth Reconciliation

[0000833444-23-000011:8k_2_02:125]
The components of the change in net sales for the three months ended March 31, 2023 versus the three months ended March 31, 2022, including organic growth, are shown below (unaudited):

[0000833444-23-000011:8k_2_02:126]
| (in millions) | Net Sales for the Three Months Ended March 31, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the Three Months EndedMarch 31, 2022 |  | Acquisitions |  | Organic Growth |  | Net Sales for the Three Months EndedMarch 31, 2023 |
| Building Solutions North America | $ | 2,227 |  |  | $ | — |  | — |  |  | $ | (14) |  | -1 | % |  | $ | 2,213 |  |  | $ | 5 |  | — |  |  | $ | 302 |  | 14 | % |  | $ | 2,520 |  | 13 | % |
| Building Solutions EMEA/LA | 958 |  |  | (4) |  | — |  |  | (50) |  | -5 | % |  | 904 |  |  | 23 |  | 3 | % |  | 104 |  | 12 | % |  | 1,031 |  | 8 | % |
| Building Solutions Asia Pacific | 623 |  |  | — |  | — |  |  | (41) |  | -7 | % |  | 582 |  |  | — |  | — |  |  | 85 |  | 15 | % |  | 667 |  | 7 | % |
| Total field | 3,808 |  |  | (4) |  | — |  |  | (105) |  | -3 | % |  | 3,699 |  |  | 28 |  | 1 | % |  | 491 |  | 13 | % |  | 4,218 |  | 11 | % |
| Global Products | 2,290 |  |  | — |  | — |  |  | (93) |  | -4 | % |  | 2,197 |  |  | — |  | — |  |  | 271 |  | 12 | % |  | 2,468 |  | 8 | % |
| Total net sales | $ | 6,098 |  |  | $ | (4) |  | — |  |  | $ | (198) |  | -3 | % |  | $ | 5,896 |  |  | $ | 28 |  | — |  |  | $ | 762 |  | 13 | % |  | $ | 6,686 |  | 10 | % |

[0000833444-23-000011:8k_2_02:127]
The components of the change in net sales for the six months ended March 31, 2023 versus the six months ended March 31, 2022, including organic growth, are shown below (unaudited):

[0000833444-23-000011:8k_2_02:128]
| (in millions) | Net Sales for the Six Months Ended March 31, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the Six Months EndedMarch 31, 2022 |  | Acquisitions |  | Organic Growth |  | Net Sales for the Six Months EndedMarch 31, 2023 |
| Building Solutions North America | $ | 4,379 |  |  | $ | — |  | — |  |  | $ | (29) |  | -1 | % |  | $ | 4,350 |  |  | $ | 12 |  | — |  |  | $ | 525 |  | 12 | % |  | $ | 4,887 |  | 12 | % |
| Building Solutions EMEA/LA | 1,917 |  |  | (22) |  | -1 | % |  | (139) |  | -7 | % |  | 1,756 |  |  | 43 |  | 2 | % |  | 207 |  | 12 | % |  | 2,006 |  | 5 | % |
| Building Solutions Asia Pacific | 1,298 |  |  | — |  | — |  |  | (112) |  | -9 | % |  | 1,186 |  |  | — |  | — |  |  | 127 |  | 11 | % |  | 1,313 |  | 1 | % |
| Total field | 7,594 |  |  | (22) |  | — |  |  | (280) |  | -4 | % |  | 7,292 |  |  | 55 |  | 1 | % |  | 859 |  | 12 | % |  | 8,206 |  | 8 | % |
| Global Products | 4,366 |  |  | — |  | — |  |  | (218) |  | -5 | % |  | 4,148 |  |  | — |  | — |  |  | 400 |  | 10 | % |  | 4,548 |  | 4 | % |
| Total net sales | $ | 11,960 |  |  | $ | (22) |  | — |  |  | $ | (498) |  | -4 | % |  | $ | 11,440 |  |  | $ | 55 |  | — |  |  | $ | 1,259 |  | 11 | % |  | $ | 12,754 |  | 7 | % |

[0000833444-23-000011:8k_2_02:129]
The components of the change in total service revenue for the three months ended March 31, 2023 versus the three months ended March 31, 2022, including organic growth, are shown below (unaudited):

[0000833444-23-000011:8k_2_02:130]
| (in millions) | Service Revenuefor the Three Months Ended March 31, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base Service Revenue for the Three Months Ended March 31, 2022 |  | Acquisitions |  | Organic Growth |  | Service Revenuefor the Three Months EndedMarch 31, 2023 |
| Building Solutions North America | $ | 884 |  |  | $ | — |  | — |  |  | $ | (5) |  | -1 | % |  | $ | 879 |  |  | $ | 6 |  | 1 | % |  | $ | 81 |  | 9 | % |  | $ | 966 |  | 9 | % |
| Building Solutions EMEA/LA | 422 |  |  | (1) |  | — |  |  | (24) |  | -6 | % |  | 397 |  |  | 3 |  | 1 | % |  | 49 |  | 12 | % |  | 449 |  | 6 | % |
| Building Solutions Asia Pacific | 175 |  |  | — |  | — |  |  | (11) |  | -6 | % |  | 164 |  |  | — |  | — |  |  | 24 |  | 15 | % |  | 188 |  | 7 | % |
| Total field | 1,481 |  |  | (1) |  | — |  |  | (40) |  | -3 | % |  | 1,440 |  |  | 9 |  | 1 | % |  | 154 |  | 11 | % |  | 1,603 |  | 8 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 1,481 |  |  | $ | (1) |  | — |  |  | $ | (40) |  | -3 | % |  | $ | 1,440 |  |  | $ | 9 |  | 1 | % |  | $ | 154 |  | 11 | % |  | $ | 1,603 |  | 8 | % |

[0000833444-23-000011:8k_2_02:131]
The components of the change in total service revenue for the six months ended March 31, 2023 versus the six months ended March 31, 2022, including organic growth, are shown below (unaudited):

[0000833444-23-000011:8k_2_02:132]
| (in millions) | Service Revenue for the Six Months Ended March 31, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base Service Revenue for the Six Months Ended March 31, 2022 |  | Acquisitions |  | Organic Growth |  | Service Revenuefor the Six Months EndedMarch 31, 2023 |
| Building Solutions North America | $ | 1,737 |  |  | $ | — |  | — |  |  | $ | (11) |  | -1 | % |  | $ | 1,726 |  |  | $ | 12 |  | 1 | % |  | $ | 144 |  | 8 | % |  | $ | 1,882 |  | 8 | % |
| Building Solutions EMEA/LA | 837 |  |  | (12) |  | -1 | % |  | (65) |  | -8 | % |  | 760 |  |  | 7 |  | 1 | % |  | 105 |  | 14 | % |  | 872 |  | 4 | % |
| Building Solutions Asia Pacific | 349 |  |  | — |  | — |  |  | (29) |  | -8 | % |  | 320 |  |  | — |  | — |  |  | 41 |  | 13 | % |  | 361 |  | 3 | % |
| Total field | 2,923 |  |  | (12) |  | — |  |  | (105) |  | -4 | % |  | 2,806 |  |  | 19 |  | 1 | % |  | 290 |  | 10 | % |  | 3,115 |  | 7 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 2,923 |  |  | $ | (12) |  | — |  |  | $ | (105) |  | -4 | % |  | $ | 2,806 |  |  | $ | 19 |  | 1 | % |  | $ | 290 |  | 10 | % |  | $ | 3,115 |  | 7 | % |

[0000833444-23-000011:8k_2_02:133]
Page 16 of 18

[0000833444-23-000011:8k_2_02:134]
4.   Free Cash Flow Conversion

[0000833444-23-000011:8k_2_02:135]
The Company's press release contains financial information regarding free cash flow and free cash flow conversion, which are non-GAAP performance measures. We also present below free cash flow conversion from the GAAP measure of net income attributable to JCI. Effective January 1, 2023, the Company has excluded the impact of its financing entity, JC Capital, from the calculation of free cash flow. Management believes this provides a more true representation of the Company’s operational ability to convert cash, without the contrary impact from financing activities. The impact on interim and annual periods prior to January 1, 2023 was not material. JC Capital cash flows that are excluded from the calculation of free cash flow primarily include activity associated with finance/notes receivables and inventory and/or capital expenditures related to lease arrangements. JC Capital net income that is excluded is primarily related to interest income on the finance/notes receivable and profit recognized on arrangements with sales-type lease components.

[0000833444-23-000011:8k_2_02:136]
Free cash flow is defined as cash provided (used) by operating activities, excluding JC Capital, less capital expenditures, excluding JC Capital. Free cash flow conversion from net income is defined as free cash flow divided by net income attributable to JCI. Free cash flow conversion is defined as free cash flow divided by adjusted net income attributable to JCI, excluding JC Capital. Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash. These non-GAAP measures can also be used to evaluate our ability to generate cash flow from operations and the impact that this cash flow has on our liquidity.

[0000833444-23-000011:8k_2_02:137]
The following is the three and six months ended March 31, 2023 and 2022 calculation of free cash flow (unaudited):

[0000833444-23-000011:8k_2_02:138]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | March 31, 2023 |  | March 31, 2022 |  | March 31, 2023 |  | March 31, 2022 |
| Cash provided (used) by operating activities from continuing operations | $ | 314 |  | $ | (68) |  | $ | 18 |  | $ | 324 |
| Less: JC Capital cash used by operating activities from continuing operations | (42) |  | — |  | (42) |  | — |
| Cash provided (used) by operating activities from continuing operations, excluding JC Capital | $ | 356 |  | $ | (68) |  | $ | 60 |  | $ | 324 |
| Capital expenditures | $ | (121) |  | $ | (125) |  | $ | (255) |  | $ | (260) |
| Less: JC Capital capital expenditures | — |  | — |  | — |  | — |
| Capital expenditures, excluding JC Capital | $ | (121) |  | $ | (125) |  | $ | (255) |  | $ | (260) |
| Free cash flow | $ | 235 |  | $ | (193) |  | $ | (195) |  | $ | 64 |

[0000833444-23-000011:8k_2_02:139]
The following is the six months ended March 31, 2023 and 2022 calculation of free cash flow conversion from net income and free cash flow conversion (unaudited):

[0000833444-23-000011:8k_2_02:140]
|  | Six Months Ended |  |
| (in millions) | March 31, 2023 |  | March 31, 2022 |  |
| Net income attributable to JCI | $ | 251 |  | $ | 392 |  |
| Free cash flow conversion from net income | -78 | % |  | 16 | % |  |
| Adjusted net income attributable to JCI | $ | 980 |  | $ | 821 |  |
| Less: JC Capital net income | 8 |  | — |  |
| Adjusted net income attributable to JCI, excluding JC Capital | $ | 972 |  | $ | 821 |  |
| Free cash flow conversion | -20 | % |  | 8 | % |  |

[0000833444-23-000011:8k_2_02:141]
Page 17 of 18

[0000833444-23-000011:8k_2_02:142]
5.  Debt Ratios

[0000833444-23-000011:8k_2_02:143]
The Company's earnings presentation provides financial information regarding net debt to adjusted EBITDA, which is a non-GAAP performance measure. We also present below net debt to income before income taxes. The Company believes these ratios are useful to understanding the Company's financial condition as they provide an overview of the extent to which the Company relies on external debt financing for its funding and are a measure of risk to its shareholders. The following is the March 31, 2023, December 31, 2022, and March 31, 2022 calculation of net debt to income before income taxes and net debt to adjusted EBITDA (unaudited):

[0000833444-23-000011:8k_2_02:144]
| (in millions) | March 31, 2023 |  | December 31, 2022 |  | March 31, 2022 |  |  |
| Short-term debt and current portion of long-term debt | $ | 2,659 |  |  | $ | 1,963 |  |  | $ | 2,284 |  |  |  |
| Long-term debt | 7,832 |  |  | 7,784 |  |  | 7,366 |  |  |  |
| Total debt | 10,491 |  |  | 9,747 |  |  | 9,650 |  |  |  |
| Less: cash and cash equivalents | 1,975 |  |  | 1,509 |  |  | 1,787 |  |  |  |
| Total net debt | $ | 8,516 |  |  | $ | 8,238 |  |  | $ | 7,863 |  |  |  |
| Last twelve months income before income taxes | $ | 1,503 |  |  | $ | 1,390 |  |  | $ | 2,175 |  |  |  |
| Total net debt to income before income taxes | 5.7x |  | 5.9x |  | 3.6x |  |  |
| Last twelve months adjusted EBITDA | $ | 3,895 |  |  | $ | 3,783 |  |  | $ | 3,660 |  |  |  |
| Total net debt to adjusted EBITDA | 2.2x |  | 2.2x |  | 2.1x |  |  |

[0000833444-23-000011:8k_2_02:145]
The following is the last twelve months ended March 31, 2023, December 31, 2022, and March 31, 2022 reconciliation of income from continuing operations to adjusted EBIT and adjusted EBITDA, which are non-GAAP performance measures (unaudited):

[0000833444-23-000011:8k_2_02:146]
| (in millions) | Last Twelve MonthsEndedMarch 31, 2023 |  | Last Twelve MonthsEndedDecember 31, 2022 |  | Last Twelve MonthsEndedMarch 31, 2022 |  |  |
| Income from continuing operations | $ | 1,582 |  |  | $ | 1,460 |  |  | $ | 1,448 |  |  |  |
| Income tax provision (benefit) | (79) |  |  | (70) |  |  | 727 |  |  |  |
| Net financing charges | 247 |  |  | 227 |  |  | 207 |  |  |  |
| EBIT | 1,750 |  |  | 1,617 |  |  | 2,382 |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (65) |  |  | 20 |  |  | (140) |  |  |  |
| Restructuring and impairment costs | 1,051 |  |  | 1,017 |  |  | 579 |  |  |  |
| Environmental remediation and related reserves adjustment | 255 |  |  | 255 |  |  | — |  |  |  |
| Silent-Aire other nonrecurring costs | — |  |  | 6 |  |  | 36 |  |  |  |
| Silent-Aire earn-out adjustment | (30) |  |  | (43) |  |  | (43) |  |  |  |
| Charges attributable to the suspension of operations in Russia | — |  |  | 11 |  |  | 11 |  |  |  |
| Warehouse fire loss | 40 |  |  | 40 |  |  | — |  |  |  |
| Transaction/separation costs | 87 |  |  | 57 |  |  | — |  |  |  |
| Adjusted EBIT (1) | 3,088 |  |  | 2,980 |  |  | 2,825 |  |  |  |
| Depreciation and amortization | 807 |  |  | 803 |  |  | 835 |  |  |  |
| Adjusted EBITDA (1) | $ | 3,895 |  |  | $ | 3,783 |  |  | $ | 3,660 |  |  |  |

[0000833444-23-000011:8k_2_02:147]
(1) The Company's definition of adjusted EBIT and adjusted EBITDA excludes special items that are not considered to be directly related to the underlying operating performance of its businesses. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-23-000011:8k_2_02:148]
6.  Income Taxes

[0000833444-23-000011:8k_2_02:149]
The Company's effective tax rate from continuing operations before consideration of net mark-to-market adjustments, restructuring and impairment costs, Silent-Aire nonrecurring intangible asset amortization and purchase accounting, charges attributable to the suspension of operations in Russia, discrete tax items, certain transaction/separation costs and warehouse fire loss for the three and six months ending March 31, 2023 and March 31, 2022 is approximately 13.5%.

[0000833444-23-000011:8k_2_02:150]
Page 18 of 18
