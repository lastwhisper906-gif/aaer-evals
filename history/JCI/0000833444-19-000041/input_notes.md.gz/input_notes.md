# JCI notes — 0000833444-19-000041


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-19-000041:notes:1]
[same as prior period, unchanged from 0000833444-19-000022:notes:1]

[0000833444-19-000041:notes:2]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2018 filed with the SEC on November 20, 2018. The results of operations for the three and nine month periods ended June 30, 2019 are not necessarily indicative of results for the Company’s 2019 fiscal year because of seasonal and other factors.

[0000833444-19-000041:notes:3]
[same as prior period, unchanged from 0000833444-19-000022:notes:3]

[0000833444-19-000041:notes:4]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. The Company creates intelligent buildings, efficient energy solutions and integrated infrastructure that work seamlessly together to deliver on the promise of smart cities and communities. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-19-000041:notes:5]
The Company is a global market leader in engineering, developing, manufacturing and installing building products and systems around the world, including heating, ventilating, air-conditioning ("HVAC") equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Company further serves customers by providing technical services (in the HVAC, security and fire-protection space), energy-management consulting and data-driven solutions via its data-enabled business. Finally, the Company has a strong presence in the North American residential air conditioning and heating systems market and is a global market leader in industrial refrigeration products.

[0000833444-19-000041:notes:6]
[same as prior period, unchanged from 0000833444-19-000022:notes:7]

[0000833444-19-000041:notes:7]
[same as prior period, unchanged from 0000833444-19-000022:notes:8]

[0000833444-19-000041:notes:8]
Under certain criteria as provided for in Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity ("VIE"). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting rights. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.

[0000833444-19-000041:notes:9]
[same as prior period, unchanged from 0000833444-19-000022:notes:11]

[0000833444-19-000041:notes:10]
[same as prior period, unchanged from 0000833444-19-000022:notes:12]

[0000833444-19-000041:notes:11]
At June 30, 2019, the Company held restricted cash of approximately $16 million, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities. At September 30, 2018, the Company held restricted cash of approximately $15 million, of which $6 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position.

[0000833444-19-000041:notes:12]
[same as prior period, unchanged from 0000833444-19-000022:notes:14]

[0000833444-19-000041:notes:13]
[same as prior period, unchanged from 0000833444-19-000022:notes:15]

[0000833444-19-000041:notes:14]
In November 2016, the FASB issued Accounting Standards Update ("ASU") No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force)." The ASU requires amounts generally described as restricted cash and restricted cash equivalents to be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. ASU No. 2016-18 was effective retrospectively for the quarter ended December 31, 2018. The impact of this guidance did not have a significant impact on the Company's consolidated financial statements for the periods presented.

[0000833444-19-000041:notes:15]
In August 2016, the FASB issued ASU No. 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments." ASU No. 2016-15 provides clarification guidance on eight specific cash flow presentation issues in order to reduce the diversity in practice. ASU No. 2016-15 was effective retrospectively for the Company for the quarter ending December 31, 2018. The adoption of this guidance had an impact on the presentation of equity swap funding and settlement activities since the activity changed from an operating activity to an investing activity.


## us-gaap:ScheduleOfNewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000833444-19-000041:notes:16]
The impact of adoption of the New Revenue Standard to the Company's consolidated statement of financial position as of June 30, 2019 is as follows (in millions):

[0000833444-19-000041:notes:17]
|  | June 30, 2019 |
|  | As reported |  | Under previous accounting guidance |  | Impact from adopting the New Revenue Standard |
| Consolidated Statement of Financial Position |  |  |  |  |  |
| Assets |  |  |  |  |  |
| Accounts receivable - net | $ | 6,033 |  |  | $ | 6,065 |  |  | $ | (32 | ) |
| Inventories | 2,050 |  |  | 2,064 |  |  | (14 | ) |
| Other current assets | 1,179 |  |  | 1,204 |  |  | (25 | ) |
| Property, plant and equipment - net | 3,282 |  |  | 3,242 |  |  | 40 |  |
| Other noncurrent assets | 1,787 |  |  | 1,758 |  |  | 29 |  |
| Liabilities and Equity |  |  |  |  |  |
| Deferred revenue | 1,389 |  |  | 1,380 |  |  | 9 |  |
| Retained earnings | 6,366 |  |  | 6,377 |  |  | (11 | ) |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-19-000041:notes:18]
[same as prior period, unchanged from 0000833444-19-000022:notes:20]

[0000833444-19-000041:notes:19]
On April 30, 2019, the Company completed the sale of its Power Solutions business to BCP Acquisitions LLC for a purchase price of $13.2 billion. The net cash proceeds after tax and transaction-related expenses were $11.6 billion. In connection with the sale, the Company recorded a gain, net of transaction and other costs, of $5.2 billion ($4.0 billion after tax), subject to

[0000833444-19-000041:notes:20]
post-closing working capital and net debt adjustments, within income from discontinued operations, net of tax, in the consolidated statements of income. During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation and, as a result, Power Solutions' historical financial results are reflected in the Company's consolidated financial statements as a discontinued operation. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further disclosure related to the Company's discontinued operations.

[0000833444-19-000041:notes:21]
During the first nine months of fiscal 2019, the Company completed certain divestitures within the Global Products and Building Solutions EMEA/LA businesses. The combined selling price was $18 million, $12 million of which was received as of June 30, 2019. In connection with the sale, the Company reduced goodwill by $1 million within the Building Solutions EMEA/LA segment. The divestitures were not material to the Company's consolidated financial statements.

[0000833444-19-000041:notes:22]
During the first nine months of fiscal 2019, the Company completed certain acquisitions for a combined purchase price of $16 million, all of which was paid as of June 30, 2019. The acquisitions were not material to the Company's consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $9 million within the Global Products segment and $1 million within the Building Solutions EMEA/LA segment.

[0000833444-19-000041:notes:23]
During the first nine months of fiscal 2018, the Company completed certain acquisitions for a combined purchase price of $24 million, all of which was paid as of June 30, 2018. The acquisitions were not material to the Company’s consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $12 million within the Global Products segment.

[0000833444-19-000041:notes:24]
[same as prior period, unchanged from 0000833444-19-000022:notes:24]

[0000833444-19-000041:notes:25]
[same as prior period, unchanged from 0000833444-19-000022:notes:25]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-19-000041:notes:26]
[same as prior period, unchanged from 0000833444-19-000022:notes:26]

[0000833444-19-000041:notes:27]
On November 13, 2018, the Company entered into a Stock and Asset Purchase Agreement (“Purchase Agreement”) with BCP Acquisitions LLC (“Purchaser”). The Purchaser is a newly-formed entity controlled by investment funds managed by Brookfield Capital Partners LLC. Pursuant to the Purchase Agreement, on the terms and subject to the conditions therein, the Company agreed to sell, and Purchaser agreed to acquire, the Company’s Power Solutions business for a purchase price of $13.2 billion. The transaction closed on April 30, 2019 with net cash proceeds of $11.6 billion after tax and transaction-related expenses.

[0000833444-19-000041:notes:28]
[same as prior period, unchanged from 0000833444-19-000022:notes:28]

[0000833444-19-000041:notes:29]
The following table summarizes the results of Power Solutions reclassified as discontinued operations for the three and nine month periods ended June 30, 2019 and 2018 (in millions). As the Power Solutions sale occurred on April 30, 2019, there is only one month of Power Solutions results included in the three month period ended June 30, 2019, and only seven months included in the nine month period ended June 30, 2019.

[0000833444-19-000041:notes:30]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net sales | $ | 562 |  |  | $ | 1,838 |  |  | $ | 5,001 |  |  | $ | 5,813 |  |
| Income from discontinued operations before income taxes | 5,315 |  |  | 303 |  |  | 6,039 |  |  | 978 |  |
| Provision for income taxes on discontinued operations | (1,264 | ) |  | (45 | ) |  | (1,441 | ) |  | (137 | ) |
| Income from discontinued operations attributable to noncontrolling interests, net of tax | — |  |  | (9 | ) |  | (24 | ) |  | (33 | ) |
| Income from discontinued operations | $ | 4,051 |  |  | $ | 249 |  |  | $ | 4,574 |  |  | $ | 808 |  |

[0000833444-19-000041:notes:31]
For the three months ended June 30, 2019, income from discontinued operations before income taxes included a gain on sale of the Power Solutions business, net of transaction and other costs, of $5.2 billion and a favorable impact of $21 million for ceasing depreciation and amortization expense as the business was held for sale. For the nine months ended June 30, 2019, income from discontinued operations before income taxes included a gain on sale of the Power Solutions business, net of transaction and other costs, of $5.2 billion and a favorable impact of $117 million for ceasing depreciation and amortization expense as the business was held for sale.

[0000833444-19-000041:notes:32]
For the three and nine months ended June 30, 2019, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to the tax impacts of the divestiture of the Power Solutions business and tax rate differentials. For the three and nine months ended June 30, 2018, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to tax rate differentials.

[0000833444-19-000041:notes:33]
[same as prior period, unchanged from 0000833444-19-000022:notes:33]

[0000833444-19-000041:notes:34]
The following table summarizes the carrying value of the Power Solutions assets and liabilities held for sale at September 30, 2018 (in millions):

[0000833444-19-000041:notes:35]
|  | September 30, 2018 |
| Cash | $ | 15 |  |
| Accounts receivable - net | 1,443 |  |
| Inventories | 1,405 |  |
| Other current assets | 152 |  |
| Assets held for sale | $ | 3,015 |  |
| Property, plant and equipment - net | $ | 2,871 |  |
| Goodwill | 1,092 |  |
| Other intangible assets - net | 161 |  |
| Investments in partially-owned affiliates | 453 |  |
| Other noncurrent assets | 611 |  |
| Noncurrent assets held for sale | $ | 5,188 |  |
| Short-term debt | $ | 9 |  |
| Current portion of long-term debt | 25 |  |
| Accounts payable | 1,237 |  |
| Accrued compensation and benefits | 125 |  |
| Other current liabilities | 395 |  |
| Liabilities held for sale | $ | 1,791 |  |
| Long-term debt | $ | 31 |  |
| Pension and postretirement benefits | 101 |  |
| Other noncurrent liabilities | 75 |  |
| Noncurrent liabilities held for sale | $ | 207 |  |

[0000833444-19-000041:notes:36]
During the third quarter of fiscal 2019, the Company determined that a business within its Global Products segment met the criteria to be classified as held for sale. The assets and liabilities of this business are presented as held for sale in the consolidated statements of financial position as of June 30, 2019. Assets and liabilities held for sale are required to be recorded at the lower of carrying value or fair value less any costs to sell. Accordingly, the Company recorded an impairment charge of $235 million within restructuring and impairment costs in the consolidated statements of income in the third quarter of fiscal 2019 to write down the carrying value of the assets held for sale to fair value less any costs to sell. Refer to Note 17, "Impairment of Long-Lived Assets" of the notes to consolidated financial statements for further information regarding the impairment charge. The divestiture of the business held for sale could result in a gain or loss on sale to the extent the ultimate selling price differs from the current carrying value of the net assets recorded. The business did not meet the criteria to be classified as a discontinued operation as the divestiture of the business will not have a major effect on the Company's operations and financial results.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-19-000041:notes:37]
[same as prior period, unchanged from 0000833444-19-000022:notes:36]

[0000833444-19-000041:notes:38]
[same as prior period, unchanged from 0000833444-19-000022:notes:37]

[0000833444-19-000041:notes:39]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion

[0000833444-19-000041:notes:40]
measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company elected the practical expedient which permits the promised amount of consideration to not be adjusted for the effects of a significant financing component as at contract inception the Company expects to receive the payment within the twelve months of transfer of goods or services.

[0000833444-19-000041:notes:41]
[same as prior period, unchanged from 0000833444-19-000022:notes:39]

[0000833444-19-000041:notes:42]
[same as prior period, unchanged from 0000833444-19-000022:notes:40]

[0000833444-19-000041:notes:43]
[same as prior period, unchanged from 0000833444-19-000022:notes:41]

[0000833444-19-000041:notes:44]
[same as prior period, unchanged from 0000833444-19-000022:notes:42]

[0000833444-19-000041:notes:45]
[same as prior period, unchanged from 0000833444-19-000022:notes:43]

[0000833444-19-000041:notes:46]
[same as prior period, unchanged from 0000833444-19-000022:notes:44]

[0000833444-19-000041:notes:47]
The following table presents the Company's revenues disaggregated by segment and by product versus services revenue for the three and nine months ended June 30, 2019 (in millions):

[0000833444-19-000041:notes:48]
|  |  | Three Months EndedJune 30, 2019 |  | Nine Months EndedJune 30, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,494 |  |  | $ | 833 |  |  | $ | 2,327 |  |  | $ | 4,202 |  |  | $ | 2,428 |  |  | $ | 6,630 |  |
| Building Solutions EMEA/LA |  | 464 |  |  | 458 |  |  | 922 |  |  | 1,297 |  |  | 1,410 |  |  | 2,707 |  |
| Building Solutions Asia Pacific |  | 427 |  |  | 264 |  |  | 691 |  |  | 1,134 |  |  | 798 |  |  | 1,932 |  |
| Global Products |  | 2,511 |  |  | — |  |  | 2,511 |  |  | 6,425 |  |  | — |  |  | 6,425 |  |
| Total |  | $ | 4,896 |  |  | $ | 1,555 |  |  | $ | 6,451 |  |  | $ | 13,058 |  |  | $ | 4,636 |  |  | $ | 17,694 |  |

[0000833444-19-000041:notes:49]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and nine months ended June 30, 2019 (in millions):

[0000833444-19-000041:notes:50]
|  |  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  |  | 2019 |  | 2019 |
| Building Management |  | $ | 342 |  |  | $ | 943 |  |
| HVAC & Refrigeration Equipment |  | 1,869 |  |  | 4,628 |  |
| Specialty |  | 300 |  |  | 854 |  |
| Total Global Products |  | $ | 2,511 |  |  | $ | 6,425 |  |

[0000833444-19-000041:notes:51]
[same as prior period, unchanged from 0000833444-19-000022:notes:49]

[0000833444-19-000041:notes:52]
[same as prior period, unchanged from 0000833444-19-000022:notes:50]

[0000833444-19-000041:notes:53]
[same as prior period, unchanged from 0000833444-19-000022:notes:51]

[0000833444-19-000041:notes:54]
|  |  | Location of contract balances |  | June 30, 2019 |  | October 1, 2018 |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,428 |  |  | $ | 1,261 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 85 |  |  | 85 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,389 | ) |  | (1,335 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (125 | ) |  | (113 | ) |
| Total |  |  |  | $ | (1 | ) |  | $ | (102 | ) |

[0000833444-19-000041:notes:55]
For the three and nine months ended June 30, 2019, the Company recognized revenue of $130 million and $1,056 million, respectively, that was included in the beginning of period contract liability balance.

[0000833444-19-000041:notes:56]
[same as prior period, unchanged from 0000833444-19-000022:notes:54]

[0000833444-19-000041:notes:57]
[same as prior period, unchanged from 0000833444-19-000022:notes:55]

[0000833444-19-000041:notes:58]
Performance obligations are satisfied as of a point in time or over time. Performance obligations are supported by contracts with customers, providing a framework for the nature of the distinct goods, services, or bundle of goods and services. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of June 30, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.2 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company has applied the practical expedient for certain revenue streams to exclude the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-19-000041:notes:59]
[same as prior period, unchanged from 0000833444-19-000022:notes:57]

[0000833444-19-000041:notes:60]
[same as prior period, unchanged from 0000833444-19-000022:notes:58]

[0000833444-19-000041:notes:61]
As of June 30, 2019, the Company recorded the costs to obtain or fulfill a contract of $190 million, of which $100 million is recorded within other current assets and $90 million is recorded within other noncurrent assets in the consolidated statements of financial position.

[0000833444-19-000041:notes:62]
During the three and nine months ended June 30, 2019, the Company recognized amortization expense of $50 million and $119 million, respectively related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and nine months ended June 30, 2019.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-19-000041:notes:63]
[same as prior period, unchanged from 0000833444-19-000022:notes:61]

[0000833444-19-000041:notes:64]
[same as prior period, unchanged from 0000833444-19-000022:notes:62]

[0000833444-19-000041:notes:65]
|  | June 30, 2019 |  | September 30, 2018 |
| Raw materials and supplies | $ | 685 |  |  | $ | 606 |  |
| Work-in-process | 215 |  |  | 155 |  |
| Finished goods | 1,150 |  |  | 1,058 |  |
| Inventories | $ | 2,050 |  |  | $ | 1,819 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-19-000041:notes:66]
[same as prior period, unchanged from 0000833444-19-000022:notes:64]

[0000833444-19-000041:notes:67]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the nine month period ended June 30, 2019 were as follows (in millions):

[0000833444-19-000041:notes:68]
|  |  |  | Business Acquisitions |  | Business Divestitures |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  |  | June 30, |
|  | 2018 |  |  |  |  | 2019 |
| Building Solutions North America | $ | 9,603 |  |  | $ | — |  |  | $ | — |  |  | $ | (5 | ) |  | $ | 9,598 |  |
| Building Solutions EMEA/LA | 1,950 |  |  | 1 |  |  | (1 | ) |  | (40 | ) |  | 1,910 |  |
| Building Solutions Asia Pacific | 1,235 |  |  | — |  |  | — |  |  | (9 | ) |  | 1,226 |  |
| Global Products | 5,593 |  |  | 9 |  |  | (22 | ) |  | (2 | ) |  | 5,578 |  |
| Total | $ | 18,381 |  |  | $ | 10 |  |  | $ | (23 | ) |  | $ | (56 | ) |  | $ | 18,312 |  |

[0000833444-19-000041:notes:69]
The fiscal 2019 Global Products business divestiture amount includes $22 million of goodwill transferred to noncurrent assets held for sale on the consolidated statements of financial position related to plans to dispose of a business within the Global Products segment.

[0000833444-19-000041:notes:70]
[same as prior period, unchanged from 0000833444-19-000022:notes:67]

[0000833444-19-000041:notes:71]
[same as prior period, unchanged from 0000833444-19-000022:notes:68]

[0000833444-19-000041:notes:72]
|  | June 30, 2019 |  | September 30, 2018 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Amortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,316 |  |  | $ | (342 | ) |  | $ | 974 |  |  | $ | 1,317 |  |  | $ | (251 | ) |  | $ | 1,066 |  |
| Customer relationships | 2,745 |  |  | (714 | ) |  | 2,031 |  |  | 2,941 |  |  | (599 | ) |  | 2,342 |  |
| Miscellaneous | 566 |  |  | (228 | ) |  | 338 |  |  | 458 |  |  | (185 | ) |  | 273 |  |
| Total amortized intangible assets | 4,627 |  |  | (1,284 | ) |  | 3,343 |  |  | 4,716 |  |  | (1,035 | ) |  | 3,681 |  |
| Unamortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,306 |  |  | — |  |  | 2,306 |  |  | 2,386 |  |  | — |  |  | 2,386 |  |
| Miscellaneous | 90 |  |  | — |  |  | 90 |  |  | 120 |  |  | — |  |  | 120 |  |
|  | 2,396 |  |  | — |  |  | 2,396 |  |  | 2,506 |  |  | — |  |  | 2,506 |  |
| Total intangible assets | $ | 7,023 |  |  | $ | (1,284 | ) |  | $ | 5,739 |  |  | $ | 7,222 |  |  | $ | (1,035 | ) |  | $ | 6,187 |  |

[0000833444-19-000041:notes:73]
Amortization of other intangible assets included within continuing operations for the three month periods ended June 30, 2019 and 2018 was $93 million and $98 million, respectively. Amortization of other intangible assets included within continuing operations for the nine month periods ended June 30, 2019 and 2018 was $288 million and $282 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2020, 2021, 2022, 2023 and 2024 will be approximately $399 million, $389 million, $378 million, $365 million and $352 million per year, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-19-000041:notes:74]
[same as prior period, unchanged from 0000833444-19-000022:notes:71]

[0000833444-19-000041:notes:75]
[same as prior period, unchanged from 0000833444-19-000022:notes:72]

[0000833444-19-000041:notes:76]
[same as prior period, unchanged from 0000833444-19-000022:notes:73]

[0000833444-19-000041:notes:77]
[same as prior period, unchanged from 0000833444-19-000022:notes:74]

[0000833444-19-000041:notes:78]
[same as prior period, unchanged from 0000833444-19-000022:notes:75]

[0000833444-19-000041:notes:79]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 209 |  |  | $ | 42 |  |  | $ | 12 |  |  | $ | 263 |  |
| Utilized—cash | (45 | ) |  | — |  |  | (2 | ) |  | (47 | ) |
| Utilized—noncash | — |  |  | (42 | ) |  | — |  |  | (42 | ) |
| Balance at September 30, 2018 | $ | 164 |  |  | $ | — |  |  | $ | 10 |  |  | $ | 174 |  |
| Utilized—cash | (59 | ) |  | — |  |  | (5 | ) |  | (64 | ) |
| Transfer to liabilities held for sale | (4 | ) |  | — |  |  | — |  |  | (4 | ) |
| Balance at June 30, 2019 | $ | 101 |  |  | $ | — |  |  | $ | 5 |  |  | $ | 106 |  |

[0000833444-19-000041:notes:80]
[same as prior period, unchanged from 0000833444-19-000022:notes:77]

[0000833444-19-000041:notes:81]
[same as prior period, unchanged from 0000833444-19-000022:notes:78]

[0000833444-19-000041:notes:82]
[same as prior period, unchanged from 0000833444-19-000022:notes:79]

[0000833444-19-000041:notes:83]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 276 |  |  | $ | 77 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 367 |  |
| Utilized—cash | (75 | ) |  | — |  |  | — |  |  | — |  |  | (75 | ) |
| Utilized—noncash | — |  |  | (77 | ) |  | (1 | ) |  | — |  |  | (78 | ) |
| Adjustment to restructuring reserves | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |
| Balance at September 30, 2017 | $ | 226 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 239 |  |
| Utilized—cash | (152 | ) |  | — |  |  | (6 | ) |  | — |  |  | (158 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Balance at September 30, 2018 | $ | 74 |  |  | $ | — |  |  | $ | 7 |  |  | $ | (1 | ) |  | $ | 80 |  |
| Utilized—cash | (5 | ) |  | — |  |  | (1 | ) |  | — |  |  | (6 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (2 | ) |  | (2 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Balance at June 30, 2019 | $ | 66 |  |  | $ | — |  |  | $ | 6 |  |  | $ | (3 | ) |  | $ | 69 |  |

[0000833444-19-000041:notes:84]
[same as prior period, unchanged from 0000833444-19-000022:notes:81]

[0000833444-19-000041:notes:85]
[same as prior period, unchanged from 0000833444-19-000022:notes:82]

[0000833444-19-000041:notes:86]
[same as prior period, unchanged from 0000833444-19-000022:notes:83]

[0000833444-19-000041:notes:87]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 368 |  |  | $ | 190 |  |  | $ | 62 |  |  | $ | — |  |  | $ | 620 |  |
| Acquired Tyco restructuring reserves | 78 |  |  | — |  |  | — |  |  | — |  |  | 78 |  |
| Utilized—cash | (32 | ) |  | — |  |  | — |  |  | — |  |  | (32 | ) |
| Utilized—noncash | — |  |  | (190 | ) |  | (32 | ) |  | 1 |  |  | (221 | ) |
| Balance at September 30, 2016 | $ | 414 |  |  | $ | — |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 445 |  |
| Adient spin-off impact | (194 | ) |  | — |  |  | (22 | ) |  | — |  |  | (216 | ) |
| Utilized—cash | (86 | ) |  | — |  |  | (2 | ) |  | — |  |  | (88 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Adjustment to restructuring reserves | (25 | ) |  | — |  |  | — |  |  | — |  |  | (25 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Adjustment to acquired Tyco restructuring reserves | (22 | ) |  | — |  |  | — |  |  | — |  |  | (22 | ) |
| Balance at September 30, 2017 | $ | 84 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 2 |  |  | $ | 92 |  |
| Utilized—cash | (17 | ) |  | — |  |  | (2 | ) |  | — |  |  | (19 | ) |
| Balance at September 30, 2018 | $ | 67 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 2 |  |  | $ | 73 |  |
| Utilized—cash | (14 | ) |  | — |  |  | — |  |  | — |  |  | (14 | ) |
| Balance at June 30, 2019 | $ | 53 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 2 |  |  | $ | 59 |  |

[0000833444-19-000041:notes:88]
The Company's fiscal 2018, 2017 and 2016 restructuring plans included workforce reductions of approximately 11,300 employees (9,100 for the Building Technologies & Solutions business and 2,200 for Corporate). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of June 30, 2019, approximately 5,200 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included twelve plant closures in the Building Technologies & Solutions business. As of June 30, 2019, ten of the twelve plants have been closed.

[0000833444-19-000041:notes:89]
[same as prior period, unchanged from 0000833444-19-000022:notes:86]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-19-000041:notes:90]
[same as prior period, unchanged from 0000833444-19-000022:notes:87]

[0000833444-19-000041:notes:91]
[same as prior period, unchanged from 0000833444-19-000022:notes:88]

[0000833444-19-000041:notes:92]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended June 30, 2019, the Company's effective tax rate for continuing operations was 52% and was higher than the statutory tax rate of 12.5% primarily due to a discrete tax charge related to newly enacted regulations related to U.S. Tax Reform, non-U.S. tax audit reserve adjustments and tax rate differentials, partially offset by a tax indemnification reserve release, the tax

[0000833444-19-000041:notes:93]
benefits of an asset held for sale impairment charge and continuing global tax planning initiatives. For the nine months ended June 30, 2019, the Company's effective tax rate for continuing operations was 38% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments as a result of tax law changes, a discrete tax charge related to newly enacted regulations related to U.S. Tax Reform, non-U.S. tax audit reserve adjustments and tax rate differentials, partially offset by a tax indemnification reserve release, the tax benefits of an asset held for sale impairment charge and continuing global tax planning initiatives. For the three months ended June 30, 2018, the Company's effective tax rate for continuing operations was 10% and was lower than the statutory tax rate of 12.5% primarily due to the benefits of continuing global tax planning initiatives. For the nine months ended June 30, 2018, the Company's effective tax rate for continuing operations was 30% and was higher than the statutory tax rate of 12.5% primarily due to the discrete net impacts of U.S. Tax Reform, the tax impact of the divestiture of the Scott Safety business and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives and tax audit closures.

[0000833444-19-000041:notes:94]
[same as prior period, unchanged from 0000833444-19-000022:notes:91]

[0000833444-19-000041:notes:95]
[same as prior period, unchanged from 0000833444-19-000022:notes:92]

[0000833444-19-000041:notes:96]
[same as prior period, unchanged from 0000833444-19-000022:notes:93]

[0000833444-19-000041:notes:97]
[same as prior period, unchanged from 0000833444-19-000022:notes:94]

[0000833444-19-000041:notes:98]
At September 30, 2018, the Company had gross tax effected unrecognized tax benefits of $2,358 million, of which $2,225 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2018 was approximately $119 million (net of tax benefit). The interest and penalties accrued during the nine months ended June 30, 2019 was approximately $49 million (net of tax benefit). Interest and penalties accrued during the nine months ended June 30, 2018 were immaterial. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-19-000041:notes:99]
In the third quarter of fiscal 2019, the Company recorded a discrete charge of $199 million related to newly enacted regulations related to U.S. Tax Reform which impacted the Company's reserves for uncertain tax positions.

[0000833444-19-000041:notes:100]
In the third quarter of fiscal 2019, the Company recorded a discrete charge of $27 million related to non-U.S. tax examinations.

[0000833444-19-000041:notes:101]
[same as prior period, unchanged from 0000833444-19-000022:notes:96]

[0000833444-19-000041:notes:102]
[same as prior period, unchanged from 0000833444-19-000022:notes:97]

[0000833444-19-000041:notes:103]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2017 |
| China |  | 2008 - 2016 |
| France |  | 2010 - 2012; 2015 - 2016 |
| Germany |  | 2007 - 2016 |
| Japan |  | 2015 - 2018 |
| United Kingdom |  | 2012 - 2015 |

[0000833444-19-000041:notes:104]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense.  Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-19-000041:notes:105]
[same as prior period, unchanged from 0000833444-19-000022:notes:99]

[0000833444-19-000041:notes:106]
[same as prior period, unchanged from 0000833444-19-000022:notes:100]

[0000833444-19-000041:notes:107]
In connection with the Company’s analysis of the impact of the U.S. tax law changes, the Company recorded a provisional net tax charge of $108 million during fiscal 2018 consistent with guidance prescribed by Staff Accounting Bulletin 118. This provisional net tax charge arises from a benefit of $108 million due to the remeasurement of U.S. deferred tax assets and liabilities, offset by the Company’s tax charge relating to the one-time transition tax on deemed repatriated earnings, inclusive of all relevant taxes, of $216 million. The Company’s estimated benefit of the remeasurement of U.S. deferred tax assets and liabilities increased from $101 million as of December 31, 2017 to $108 million as of September 30, 2018 due to calculation refinement of the Company’s estimated impact. The Company remeasured certain deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future, which is generally 21% or the blended fiscal 2018 rate of 24.5%. The Company’s tax charge for transition tax decreased from $305 million as of December 31, 2017 to $216 million as of September 30, 2018 due to further analysis of the Company’s post-1986 non-U.S. earnings and profits (“E&P”) previously deferred from U.S. federal taxation and refinement of the estimated impact of tax law changes. In the first quarter of fiscal 2019, the Company completed its analysis of all enactment-date income tax effects of the U.S. tax law change with no further adjustment to the provisional amounts recorded as of September 30, 2018.

[0000833444-19-000041:notes:108]
During the nine months ended June 30, 2019 and 2018, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-19-000041:notes:109]
[same as prior period, unchanged from 0000833444-19-000022:notes:104]

[0000833444-19-000041:notes:110]
In the third quarter of fiscal 2019, the Company recorded a $235 million impairment charge related to assets held for sale. Refer to Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for further information regarding the impairment charge.  The impairment charge generated a $53 million tax benefit.

[0000833444-19-000041:notes:111]
In the third quarter of fiscal 2019, the Company released a $226 million tax indemnification reserve. Refer to Note 19, "Guarantees," of the notes to consolidated financial statements for further information regarding the reserve release. The reserve release generated no income tax expense.

[0000833444-19-000041:notes:112]
[same as prior period, unchanged from 0000833444-19-000022:notes:105]

[0000833444-19-000041:notes:113]
[same as prior period, unchanged from 0000833444-19-000022:notes:106]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-19-000041:notes:114]
[same as prior period, unchanged from 0000833444-19-000022:notes:107]

[0000833444-19-000041:notes:115]
[same as prior period, unchanged from 0000833444-19-000022:notes:108]

[0000833444-19-000041:notes:116]
|  | U.S. Pension Plans |
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |
| Interest cost | 25 |  |  | 23 |  |  | 75 |  |  | 69 |  |
| Expected return on plan assets | (46 | ) |  | (49 | ) |  | (138 | ) |  | (149 | ) |
| Net periodic benefit credit | $ | (21 | ) |  | $ | (26 | ) |  | $ | (63 | ) |  | $ | (79 | ) |

[0000833444-19-000041:notes:117]
|  | Non-U.S. Pension Plans |
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Service cost | $ | 5 |  |  | $ | 6 |  |  | $ | 16 |  |  | $ | 17 |  |
| Interest cost | 14 |  |  | 14 |  |  | 40 |  |  | 42 |  |
| Expected return on plan assets | (26 | ) |  | (29 | ) |  | (78 | ) |  | (86 | ) |
| Settlement loss | — |  |  | — |  |  | 1 |  |  | — |  |
| Net periodic benefit credit | $ | (7 | ) |  | $ | (9 | ) |  | $ | (21 | ) |  | $ | (27 | ) |

[0000833444-19-000041:notes:118]
|  | Postretirement Benefits |
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest cost | 2 |  |  | 1 |  |  | 5 |  |  | 4 |  |
| Expected return on plan assets | (2 | ) |  | (2 | ) |  | (7 | ) |  | (7 | ) |
| Net periodic benefit credit | $ | — |  |  | $ | (1 | ) |  | $ | (1 | ) |  | $ | (2 | ) |


## us-gaap:DebtDisclosureTextBlock

[0000833444-19-000041:notes:119]
Debt and Financing Arrangements

[0000833444-19-000041:notes:120]
In June 2019, TSarl, a subsidiary of the Company, terminated its $1.25 billion committed revolving credit facility scheduled to expire in August 2020. In connection with the termination, the Company repaid all of the outstanding obligations in respect of principal, interest and fees under the credit facility. In relation to the termination of the credit facility, TSarl completed all of its obligations under the Term Loan Credit Agreement, dated as of March 10, 2016 (the "Term Facility") by repaying all of the outstanding obligations under the term facility, which included $364 million term loan scheduled to mature in March 2020. Other debt held at TSarl as of March 31, 2019 was also repaid, including a 364-day $250 million floating rate term loan scheduled to mature in March 2020 and an 18-month 215 million euro floating rate euro term loan scheduled to mature in July 2019. No amounts remain outstanding on the $4.0 billion TSarl merger-related debt as of June 30, 2019.

[0000833444-19-000041:notes:121]
In June 2019, the Company repurchased at par, $2.5 million of its 5.25% fixed rate notes, plus accrued interest, scheduled to mature in 2041.

[0000833444-19-000041:notes:122]
In May 2019, the Company completed the debt tender offer to purchase up to $1.5 billion in aggregate principal amount of certain of its outstanding notes for $1.6 billion total consideration. The Company recognized a loss on the extinguishment of debt of $60 million, which was recorded within net financing charges in the consolidated statements of income.

[0000833444-19-000041:notes:123]
In May 2019, the Company repaid 10 billion yen of the 35 billion yen five-year syndicated floating rate term loan, plus accrued interest, scheduled to mature in September 2022.

[0000833444-19-000041:notes:124]
In April 2019, the Company repurchased at a discount, 4.7 million euro of its 1.375% fixed rate euro notes, plus accrued interest, scheduled to mature in 2025.

[0000833444-19-000041:notes:125]
In March 2019, a 364-day $250 million committed revolving credit facility expired.  The Company entered into a new $250 million committed revolving credit facility scheduled to expire in March 2020.  As of June 30, 2019 there were no draws on the facility.

[0000833444-19-000041:notes:126]
In February 2019, the Company repurchased at a discount, $12 million of its 3.9% fixed rate notes, plus accrued interest, scheduled to mature in 2026.

[0000833444-19-000041:notes:127]
In February 2019, a 364-day $150 million committed revolving credit facility expired.  The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2020.  As of June 30, 2019 there were no draws on the facility.

[0000833444-19-000041:notes:128]
In January 2019, the Company entered into a $750 million term loan due the earlier of January 2020 or five business days from the closing on the sale of the Power Solutions business.  Proceeds from the term loan were used for general corporate purposes. Following the sale of the Power Solutions business, the loan was repaid in May 2019.

[0000833444-19-000041:notes:129]
In January 2019, a 364-day $200 million committed revolving credit facility expired.  The Company entered into a new $350 million committed revolving credit facility scheduled to expire in January 2020.  As of June 30, 2019 there were no draws on the facility.

[0000833444-19-000041:notes:130]
Net Financing Charges

[0000833444-19-000041:notes:131]
The Company's net financing charges line item in the consolidated statements of income for the three and nine months ended June 30, 2019 and 2018 contained the following components (in millions):

[0000833444-19-000041:notes:132]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Interest expense, net of capitalized interest costs | $ | 81 |  |  | $ | 106 |  |  | $ | 269 |  |  | $ | 307 |  |
| Banking fees and bond cost amortization | 7 |  |  | 8 |  |  | 20 |  |  | 23 |  |
| Loss on debt extinguishment | 60 |  |  | — |  |  | 60 |  |  | — |  |
| Interest income | (28 | ) |  | (5 | ) |  | (41 | ) |  | (13 | ) |
| Net foreign exchange results for financing activities | (1 | ) |  | (14 | ) |  | (6 | ) |  | (13 | ) |
| Net financing charges | $ | 119 |  |  | $ | 95 |  |  | $ | 302 |  |  | $ | 304 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-19-000041:notes:133]
[same as prior period, unchanged from 0000833444-19-000022:notes:122]

[0000833444-19-000041:notes:134]
During September 2016, the Board of Directors of the Company approved amendments to the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based compensation awards. The Compensation Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter. A summary of the stock-based awards granted during the nine month periods ended June 30, 2019 and 2018 is presented below:

[0000833444-19-000041:notes:135]
|  | Nine Months Ended June 30, |
|  | 2019 |  | 2018 |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  | Number Granted |  | Weighted Average Grant Date Fair Value |
| Stock options | 1,741,510 |  |  | $ | 5.56 |  |  | 1,376,807 |  |  | $ | 7.04 |  |
| Restricted stock/units | 2,334,423 |  |  | 33.50 |  |  | 2,188,131 |  |  | 37.26 |  |
| Performance shares | 583,989 |  |  | 36.28 |  |  | 496,478 |  |  | 36.31 |  |

[0000833444-19-000041:notes:136]
[same as prior period, unchanged from 0000833444-19-000022:notes:125]

[0000833444-19-000041:notes:137]
[same as prior period, unchanged from 0000833444-19-000022:notes:126]

[0000833444-19-000041:notes:138]
[same as prior period, unchanged from 0000833444-19-000022:notes:127]

[0000833444-19-000041:notes:139]
|  | Nine Months Ended June 30, |
|  | 2019 |  | 2018 |
| Expected life of option (years) | 6.4 |  | 6.5 |
| Risk-free interest rate | 2.77% |  | 2.28% |
| Expected volatility of the Company’s stock | 21.8% |  | 23.7% |
| Expected dividend yield on the Company’s stock | 3.29% |  | 2.78% |

[0000833444-19-000041:notes:140]
[same as prior period, unchanged from 0000833444-19-000022:notes:129]

[0000833444-19-000041:notes:141]
[same as prior period, unchanged from 0000833444-19-000022:notes:130]

[0000833444-19-000041:notes:142]
[same as prior period, unchanged from 0000833444-19-000022:notes:131]

[0000833444-19-000041:notes:143]
[same as prior period, unchanged from 0000833444-19-000022:notes:132]

[0000833444-19-000041:notes:144]
[same as prior period, unchanged from 0000833444-19-000022:notes:133]

[0000833444-19-000041:notes:145]
|  | Nine Months Ended June 30, |
|  | 2019 |  | 2018 |
| Risk-free interest rate | 2.76% |  | 1.92% |
| Expected volatility of the Company’s stock | 22.9% |  | 21.7% |


## us-gaap:EarningsPerShareTextBlock

[0000833444-19-000041:notes:146]
[same as prior period, unchanged from 0000833444-19-000022:notes:135]

[0000833444-19-000041:notes:147]
[same as prior period, unchanged from 0000833444-19-000022:notes:136]

[0000833444-19-000041:notes:148]
[same as prior period, unchanged from 0000833444-19-000022:notes:137]

[0000833444-19-000041:notes:149]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Income Available to Ordinary Shareholders |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 141 |  |  | $ | 474 |  |  | $ | 488 |  |  | $ | 583 |  |
| Income from discontinued operations | 4,051 |  |  | 249 |  |  | 4,574 |  |  | 808 |  |
| Basic and diluted income available to shareholders | $ | 4,192 |  |  | $ | 723 |  |  | $ | 5,062 |  |  | $ | 1,391 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 870.9 |  |  | 925.6 |  |  | 898.4 |  |  | 926.0 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 4.3 |  |  | 5.1 |  |  | 3.8 |  |  | 6.1 |  |
| Diluted weighted average shares outstanding | 875.2 |  |  | 930.7 |  |  | 902.2 |  |  | 932.1 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Options to purchase shares | 0.7 |  |  | 2.1 |  |  | 1.9 |  |  | 1.5 |  |

[0000833444-19-000041:notes:150]
During the three months ended June 30, 2019 and 2018, the Company declared dividends of $0.26 per share. During the nine months ended June 30, 2019 and 2018, the Company declared dividends of $0.78 per share. The Company paid all dividends in the month subsequent to the end of each fiscal quarter.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-19-000041:notes:151]
[same as prior period, unchanged from 0000833444-19-000022:notes:140]

[0000833444-19-000041:notes:152]
[same as prior period, unchanged from 0000833444-19-000022:notes:141]

[0000833444-19-000041:notes:153]
|  | Three Months Ended June 30, 2019 |  | Three Months Ended June 30, 2018 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, March 31, | $ | 20,036 |  |  | $ | 1,265 |  |  | $ | 21,301 |  |  | $ | 20,874 |  |  | $ | 1,006 |  |  | $ | 21,880 |  |
| Total comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 4,192 |  |  | 84 |  |  | 4,276 |  |  | 723 |  |  | 71 |  |  | 794 |  |
| Foreign currency translation adjustments | (90 | ) |  | (4 | ) |  | (94 | ) |  | (557 | ) |  | (44 | ) |  | (601 | ) |
| Realized and unrealized gains (losses) on derivatives | (5 | ) |  | (4 | ) |  | (9 | ) |  | 3 |  |  | (1 | ) |  | 2 |  |
| Other comprehensive loss | (95 | ) |  | (8 | ) |  | (103 | ) |  | (554 | ) |  | (45 | ) |  | (599 | ) |
| Comprehensive income | 4,097 |  |  | 76 |  |  | 4,173 |  |  | 169 |  |  | 26 |  |  | 195 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (208 | ) |  | — |  |  | (208 | ) |  | (240 | ) |  | — |  |  | (240 | ) |
| Repurchases and retirements of ordinary shares | (4,122 | ) |  | — |  |  | (4,122 | ) |  | (56 | ) |  | — |  |  | (56 | ) |
| Change in noncontrolling interest share | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | 4 |  |
| Divestiture of Power Solutions | 483 |  |  | (295 | ) |  | 188 |  |  | — |  |  | — |  |  | — |  |
| Other, including options exercised | 77 |  |  | — |  |  | 77 |  |  | 26 |  |  | — |  |  | 26 |  |
| Ending balance, June 30 | $ | 20,363 |  |  | $ | 1,046 |  |  | $ | 21,409 |  |  | $ | 20,773 |  |  | $ | 1,036 |  |  | $ | 21,809 |  |

[0000833444-19-000041:notes:154]
|  | Nine Months Ended June 30, 2019 |  | Nine Months Ended June 30, 2018 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, September 30, | $ | 21,164 |  |  | $ | 1,294 |  |  | $ | 22,458 |  |  | $ | 20,447 |  |  | $ | 920 |  |  | $ | 21,367 |  |
| Total comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 5,062 |  |  | 171 |  |  | 5,233 |  |  | 1,391 |  |  | 132 |  |  | 1,523 |  |
| Foreign currency translation adjustments | (103 | ) |  | 8 |  |  | (95 | ) |  | (331 | ) |  | 3 |  |  | (328 | ) |
| Realized and unrealized gains (losses) on derivatives | 10 |  |  | — |  |  | 10 |  |  | (2 | ) |  | 1 |  |  | (1 | ) |
| Realized and unrealized losses on marketable securities | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Other comprehensive income (loss) | (93 | ) |  | 8 |  |  | (85 | ) |  | (335 | ) |  | 4 |  |  | (331 | ) |
| Comprehensive income | 4,969 |  |  | 179 |  |  | 5,148 |  |  | 1,056 |  |  | 136 |  |  | 1,192 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (683 | ) |  | — |  |  | (683 | ) |  | (722 | ) |  | — |  |  | (722 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (132 | ) |  | (132 | ) |  | — |  |  | (43 | ) |  | (43 | ) |
| Repurchases and retirements of ordinary shares | (5,122 | ) |  | — |  |  | (5,122 | ) |  | (255 | ) |  | — |  |  | (255 | ) |
| Change in noncontrolling interest share | — |  |  | — |  |  | — |  |  | — |  |  | 23 |  |  | 23 |  |
| Divestiture of Power Solutions | 483 |  |  | (295 | ) |  | 188 |  |  | — |  |  | — |  |  | — |  |
| Adoption of ASC 606 | (45 | ) |  | — |  |  | (45 | ) |  | — |  |  | — |  |  | — |  |
| Adoption of ASU 2016-16 | (546 | ) |  | — |  |  | (546 | ) |  | — |  |  | — |  |  | — |  |
| Adoption of ASU 2016-09 | — |  |  | — |  |  | — |  |  | 179 |  |  | — |  |  | 179 |  |
| Other, including options exercised | 143 |  |  | — |  |  | 143 |  |  | 68 |  |  | — |  |  | 68 |  |
| Ending balance, June 30 | $ | 20,363 |  |  | $ | 1,046 |  |  | $ | 21,409 |  |  | $ | 20,773 |  |  | $ | 1,036 |  |  | $ | 21,809 |  |

[0000833444-19-000041:notes:155]
[same as prior period, unchanged from 0000833444-19-000022:notes:144]

[0000833444-19-000041:notes:156]
As previously disclosed, during the quarter ended December 31, 2018, the Company adopted ASU 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory." As a result, the Company recognized deferred taxes of $546 million related to the tax effects of all intra-entity sales of assets other than inventory on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2018.

[0000833444-19-000041:notes:157]
As previously disclosed, during the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09, "Compensation - Stock Compensation (Topic 718) Improvements to Employee Share-Based Payment Accounting." As a result, the Company recognized deferred tax assets of $179 million related to certain operating loss carryforwards resulting from the exercise of employee stock options and restricted stock vestings on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2017.

[0000833444-19-000041:notes:158]
Following the Tyco Merger, the Company adopted, subject to the ongoing existence of sufficient distributable reserves, the existing Tyco International plc $1 billion share repurchase program in September 2016. In December 2017, the Company's Board of Directors approved a $1 billion increase to its share repurchase authorization. In November 2018, the Company's Board of Directors approved an additional $1 billion increase to its share repurchase authorization. In March 2019, the Company's Board of Directors approved an additional $8.5 billion increase to its share repurchase authorization, subject to the completion of the previously announced sale of the Company's Power Solutions business, which closed on April 30, 2019.

[0000833444-19-000041:notes:159]
The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice.

[0000833444-19-000041:notes:160]
On May 1, 2019, the Company announced a "modified Dutch auction" tender offer for up to $4.0 billion of its ordinary shares with a price range between $36.00 and $40.00 per share. The tender offer expired on May 31, 2019. Through the tender offer, the Company accepted for payment 102 million shares at a purchase price of $39.25 per share, for a total of approximately $4,035 million, including fees and commissions. The shares purchased through the tender offer were immediately retired. Ordinary shares were reduced by the number of shares retired at $0.01 par value per share. The excess purchase price over par value was recorded in retained earnings in the consolidated statements of financial position.

[0000833444-19-000041:notes:161]
In addition to the equity tender offer described above, the Company repurchased $87 million and $1,087 million of its ordinary shares, respectively, during the three and nine months ended June 30, 2019.  For the three and nine months ended June 30, 2018, the Company repurchased $56 million and $255 million of its ordinary shares, respectively. As of June 30, 2019, approximately $5.4 billion remains available under the share repurchase program.

[0000833444-19-000041:notes:162]
[same as prior period, unchanged from 0000833444-19-000022:notes:150]

[0000833444-19-000041:notes:163]
The following schedule present changes in the redeemable noncontrolling interests for the three and nine months ended June 30, 2018 (in millions):

[0000833444-19-000041:notes:164]
|  | Three Months Ended June 30, 2018 |
| Beginning balance, March 31, 2018 | $ | 235 |  |
| Net income | 10 |  |
| Foreign currency translation adjustments | (13 | ) |
| Realized and unrealized losses on derivatives | (1 | ) |
| Ending balance, June 30, 2018 | $ | 231 |  |

[0000833444-19-000041:notes:165]
|  | Nine Months Ended June 30, 2018 |
| Beginning balance, September 30, 2017 | $ | 211 |  |
| Net income | 35 |  |
| Foreign currency translation adjustments | (3 | ) |
| Realized and unrealized losses on derivatives | (9 | ) |
| Dividends | (3 | ) |
| Ending balance, June 30, 2018 | $ | 231 |  |

[0000833444-19-000041:notes:166]
[same as prior period, unchanged from 0000833444-19-000022:notes:154]

[0000833444-19-000041:notes:167]
|  | Three Months EndedJune 30, |
|  | 2019 |  | 2018 |
| Foreign currency translation adjustments ("CTA") |  |  |  |
| Balance at beginning of period | $ | (952 | ) |  | $ | (255 | ) |
| Divestiture of Power Solutions | 479 |  |  | — |  |
| Aggregate adjustment for the period (net of tax effect of $0) | (90 | ) |  | (557 | ) |
| Balance at end of period | (563 | ) |  | (812 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 2 |  |  | 1 |  |
| Divestiture of Power Solutions (net of tax effect of $1 and $0) | 4 |  |  | — |  |
| Current period changes in fair value (net of tax effect of $(3) and $1) | (4 | ) |  | 5 |  |
| Reclassification to income (net of tax effect of $0 and $(2)) ** | (1 | ) |  | (2 | ) |
| Balance at end of period | 1 |  |  | 4 |  |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | — |  |  | 2 |  |
| Current period changes in fair value (net of tax effect of $0) | — |  |  | 1 |  |
| Reclassification to income (net of tax effect of $0 and $(1)) | — |  |  | (1 | ) |
| Balance at end of period | — |  |  | 2 |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (2 | ) |  | (2 | ) |
| Other changes | — |  |  | — |  |
| Balance at end of period | (2 | ) |  | (2 | ) |
| Accumulated other comprehensive loss, end of period | $ | (564 | ) |  | $ | (808 | ) |

[0000833444-19-000041:notes:168]
|  | Nine Months EndedJune 30, |
|  | 2019 |  | 2018 |
| CTA |  |  |  |
| Balance at beginning of period | $ | (939 | ) |  | $ | (481 | ) |
| Divestiture of Power Solutions | 479 |  |  | — |  |
| Aggregate adjustment for the period (net of tax effect of $0 and $1) * | (103 | ) |  | (331 | ) |
| Balance at end of period | (563 | ) |  | (812 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (13 | ) |  | 6 |  |
| Divestiture of Power Solutions (net of tax effect of $1 and $0) | 4 |  |  | — |  |
| Current period changes in fair value (net of tax effect of $1 and $2) | 4 |  |  | 7 |  |
| Reclassification to income (net of tax effect of $3 and $(4)) ** | 6 |  |  | (9 | ) |
| Balance at end of period | 1 |  |  | 4 |  |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | 8 |  |  | 4 |  |
| Adoption of ASU 2016-01 *** | (8 | ) |  | — |  |
| Current period changes in fair value (net of tax effect of $0) | — |  |  | (1 | ) |
| Reclassification to income (net of tax effect of $(1)) **** | — |  |  | (1 | ) |
| Balance at end of period | — |  |  | 2 |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (2 | ) |  | (2 | ) |
| Other changes | — |  |  | — |  |
| Balance at end of period | (2 | ) |  | (2 | ) |
| Accumulated other comprehensive loss, end of period | $ | (564 | ) |  | $ | (808 | ) |

[0000833444-19-000041:notes:169]
* During the nine months ended June 30, 2018, $12 million of cumulative CTA was recognized as part of the divestiture-related gain recognized as part of the divestiture of Scott Safety.

[0000833444-19-000041:notes:170]
[same as prior period, unchanged from 0000833444-19-000022:notes:158]

[0000833444-19-000041:notes:171]
*** As previously disclosed, during the quarter ended December 31, 2018, the Company adopted ASU 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." As a result the Company reclassified $8 million of unrealized gains on marketable securities to retained earnings as of October 1, 2018.

[0000833444-19-000041:notes:172]
**** During the nine months ended June 30, 2018, the Company sold certain marketable common stock for approximately $3 million. As a result, the Company recorded $2 million of realized gains within selling, general and administrative expenses.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-19-000041:notes:173]
[same as prior period, unchanged from 0000833444-19-000022:notes:160]

[0000833444-19-000041:notes:174]
[same as prior period, unchanged from 0000833444-19-000022:notes:161]

[0000833444-19-000041:notes:175]
[same as prior period, unchanged from 0000833444-19-000022:notes:162]

[0000833444-19-000041:notes:176]
The Company has global operations and participates in the foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three and nine months ended June 30, 2019 and 2018.

[0000833444-19-000041:notes:177]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of lead, copper, tin, aluminum and polypropylene in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As cash flow hedges, the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in commodity prices during the three and nine months ended June 30, 2019 and 2018.

[0000833444-19-000041:notes:178]
[same as prior period, unchanged from 0000833444-19-000022:notes:165]

[0000833444-19-000041:notes:179]
|  |  | Volume Outstanding as of |
| Commodity |  | June 30, 2019 |  | September 30, 2018 |
| Copper |  | 3,357 |  |  | 3,175 |  |
| Polypropylene |  | — |  |  | 15,868 |  |
| Lead |  | — |  |  | 49,066 |  |
| Aluminum |  | 4,649 |  |  | 3,381 |  |
| Tin |  | — |  |  | 3,076 |  |

[0000833444-19-000041:notes:180]
[same as prior period, unchanged from 0000833444-19-000022:notes:167]

[0000833444-19-000041:notes:181]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company’s net investments globally. At June 30, 2019, the Company had 888 million euro, 750 million euro, 423 million euro and 54 million euro in bonds designated as net investment hedges in the Company's net investment in Europe and 25 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan. Also, at September 30, 2018, the Company had one billion euro, 750 million euro, 423 million euro and 58 million euro in bonds and a 215 million euro term loan designated as net investment hedges in the Company's net investment in Europe and 35 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan.

[0000833444-19-000041:notes:182]
[same as prior period, unchanged from 0000833444-19-000022:notes:169]

[0000833444-19-000041:notes:183]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount.  As of June 30, 2019, the Company hedged approximately 1.4 million shares of its ordinary shares, which have a cost basis of $60 million. As of September 30, 2018, the Company hedged approximately 1.8 million shares of its ordinary shares, which have a cost basis of $73 million.

[0000833444-19-000041:notes:184]
[same as prior period, unchanged from 0000833444-19-000022:notes:172]

[0000833444-19-000041:notes:185]
[same as prior period, unchanged from 0000833444-19-000022:notes:173]

[0000833444-19-000041:notes:186]
[same as prior period, unchanged from 0000833444-19-000022:notes:174]

[0000833444-19-000041:notes:187]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | June 30, |  | September 30, |  | June 30, |  | September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 4 |  |  | $ | 6 |  |  | $ | 6 |  |  | $ | 10 |  |
| Commodity derivatives | — |  |  | 1 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 59 |  |  | 63 |  |
| Total assets | $ | 4 |  |  | $ | 7 |  |  | $ | 65 |  |  | $ | 73 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 6 |  |  | $ | 10 |  |  | $ | 1 |  |  | $ | 2 |  |
| Commodity derivatives | 1 |  |  | 2 |  |  | — |  |  | — |  |
| Liabilities held for sale |  |  |  |  |  |  |  |
| Commodity derivatives | — |  |  | 12 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 2,640 |  |  | 3,149 |  |  | — |  |  | — |  |
| Total liabilities | $ | 2,647 |  |  | $ | 3,173 |  |  | $ | 1 |  |  | $ | 2 |  |

[0000833444-19-000041:notes:188]
[same as prior period, unchanged from 0000833444-19-000022:notes:176]

[0000833444-19-000041:notes:189]
[same as prior period, unchanged from 0000833444-19-000022:notes:177]

[0000833444-19-000041:notes:190]
The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts

[0000833444-19-000041:notes:191]
with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position. Collateral is generally not required of the Company or the counterparties under the master netting agreements. As of June 30, 2019 and September 30, 2018, no cash collateral was received or pledged under the master netting agreements.

[0000833444-19-000041:notes:192]
[same as prior period, unchanged from 0000833444-19-000022:notes:179]

[0000833444-19-000041:notes:193]
|  |  | Fair Value of Assets |  | Fair Value of Liabilities |
|  |  | June 30, |  | September 30, |  | June 30, |  | September 30, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Gross amount recognized |  | $ | 69 |  |  | $ | 80 |  |  | $ | 2,648 |  |  | $ | 3,175 |  |
| Gross amount eligible for offsetting |  | (6 | ) |  | (12 | ) |  | (6 | ) |  | (12 | ) |
| Net amount |  | $ | 63 |  |  | $ | 68 |  |  | $ | 2,642 |  |  | $ | 3,163 |  |

[0000833444-19-000041:notes:194]
[same as prior period, unchanged from 0000833444-19-000022:notes:181]

[0000833444-19-000041:notes:195]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the three and nine months ended June 30, 2019 and 2018 (in millions):

[0000833444-19-000041:notes:196]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Foreign currency exchange derivatives |  | $ | (2 | ) |  | $ | 6 |  |  | $ | 7 |  |  | $ | 7 |  |
| Commodity derivatives |  | (5 | ) |  | — |  |  | (2 | ) |  | 2 |  |
| Total |  | $ | (7 | ) |  | $ | 6 |  |  | $ | 5 |  |  | $ | 9 |  |

[0000833444-19-000041:notes:197]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the three and nine months ended June 30, 2019 and 2018 (in millions):

[0000833444-19-000041:notes:198]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 2 |  |  | $ | 1 |  |  | $ | 4 |  |  | $ | — |  |
| Foreign currency exchange derivatives |  | Income from discontinued operations |  | — |  |  | 1 |  |  | — |  |  | 2 |  |
| Commodity derivatives |  | Cost of sales |  | — |  |  | — |  |  | (3 | ) |  | 3 |  |
| Commodity derivatives |  | Income from discontinued operations |  | (1 | ) |  | 2 |  |  | (10 | ) |  | 8 |  |
| Total |  |  |  | $ | 1 |  |  | $ | 4 |  |  | $ | (9 | ) |  | $ | 13 |  |

[0000833444-19-000041:notes:199]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the three and nine months ended June 30, 2019 and 2018 (in millions):

[0000833444-19-000041:notes:200]
|  |  |  |  | Amount of Gain (Loss) Recognized inIncome on Derivative |
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (3 | ) |  | $ | (4 | ) |  | $ | (9 | ) |  | $ | (5 | ) |
| Foreign currency exchange derivatives |  | Net financing charges |  | (18 | ) |  | (32 | ) |  | (42 | ) |  | (29 | ) |
| Foreign currency exchange derivatives |  | Income from discontinued operations |  | (2 | ) |  | 5 |  |  | 52 |  |  | 4 |  |
| Equity swap |  | Selling, general and administrative |  | 7 |  |  | (3 | ) |  | 10 |  |  | (10 | ) |
| Total |  |  |  | $ | (16 | ) |  | $ | (34 | ) |  | $ | 11 |  |  | $ | (40 | ) |

[0000833444-19-000041:notes:201]
The pre-tax gains (losses) recorded in CTA within other comprehensive income (loss) related to net investment hedges were $(36) million and $165 million for the three months ended June 30, 2019 and 2018, respectively. The pre-tax gains (losses) recorded in CTA within other comprehensive income (loss) related to net investment hedges were $48 million and $29 million for the nine months ended June 30, 2019 and 2018, respectively. For the three and nine months ended June 30, 2019 and 2018, no gains or losses were reclassified from CTA into income for the Company’s outstanding net investment hedges.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-19-000041:notes:202]
[same as prior period, unchanged from 0000833444-19-000022:notes:189]

[0000833444-19-000041:notes:203]
[same as prior period, unchanged from 0000833444-19-000022:notes:190]

[0000833444-19-000041:notes:204]
[same as prior period, unchanged from 0000833444-19-000022:notes:191]

[0000833444-19-000041:notes:205]
[same as prior period, unchanged from 0000833444-19-000022:notes:192]

[0000833444-19-000041:notes:206]
[same as prior period, unchanged from 0000833444-19-000022:notes:193]

[0000833444-19-000041:notes:207]
[same as prior period, unchanged from 0000833444-19-000022:notes:194]

[0000833444-19-000041:notes:208]
[same as prior period, unchanged from 0000833444-19-000022:notes:195]

[0000833444-19-000041:notes:209]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of June 30, 2019 and September 30, 2018 (in millions):

[0000833444-19-000041:notes:210]
|  | Fair Value Measurements Using: |
|  | Total as of June 30, 2019 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |
| Exchange traded funds (fixed income)1 | 19 |  |  | 19 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Investments in marketable common stock | 1 |  |  | 1 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 69 |  |  | 69 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 138 |  |  | 138 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 115 |  |  | 115 |  |  | — |  |  | — |  |
| Equity swap | 59 |  |  | — |  |  | 59 |  |  | — |  |
| Total assets | $ | 411 |  |  | $ | 342 |  |  | $ | 69 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Total liabilities | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |  | $ | — |  |

[0000833444-19-000041:notes:211]
[same as prior period, unchanged from 0000833444-19-000022:notes:198]

[0000833444-19-000041:notes:212]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 20, "Commitments and Contingencies," of the notes to consolidated financial statements for further details.

[0000833444-19-000041:notes:213]
[same as prior period, unchanged from 0000833444-19-000022:notes:200]

[0000833444-19-000041:notes:214]
[same as prior period, unchanged from 0000833444-19-000022:notes:201]

[0000833444-19-000041:notes:215]
[same as prior period, unchanged from 0000833444-19-000022:notes:202]

[0000833444-19-000041:notes:216]
[same as prior period, unchanged from 0000833444-19-000022:notes:203]

[0000833444-19-000041:notes:217]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. During the three and nine months ended June 30, 2019, the Company recognized no unrealized gains/losses and unrealized losses of $2 million, respectively, in the consolidated statements of income on these investments that were still held as of June 30, 2019, where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-19-000041:notes:218]
Investments in marketable common stock and exchange traded funds:  Investments in marketable common stock and exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. During the three and nine months ended June 30, 2019, the Company recognized unrealized gains of $9 million and $8 million, respectively, in the consolidated statements of income on these investments

[0000833444-19-000041:notes:219]
that were still held as of June 30, 2019, all of which related to restricted investments. Refer to Note 20, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-19-000041:notes:220]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The fair value of long-term debt was $7.5 billion at June 30, 2019 and $9.6 billion at September 30, 2018. The fair value of public debt was $7.3 billion at June 30, 2019 and $8.6 billion at September 30, 2018, which was determined primarily using market quotes classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was $0.2 billion at June 30, 2019 and $1.0 billion at September 30, 2018, which was determined based on quoted market prices for similar instruments classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0000833444-19-000041:notes:221]
[same as prior period, unchanged from 0000833444-19-000022:notes:208]

[0000833444-19-000041:notes:222]
[same as prior period, unchanged from 0000833444-19-000022:notes:209]

[0000833444-19-000041:notes:223]
During the third quarter of fiscal 2019, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with the plans to dispose of a business within its Global Products segment that met the criteria to be classified as held for sale. Assets and liabilities held for sale are required to be recorded at the lower of carrying value or fair value less any costs to sell. Accordingly, the Company recorded an impairment charge of $235 million within restructuring and impairment costs in the consolidated statements of income in the third quarter of fiscal 2019 to write down the carrying value of the assets held for sale to fair value less any costs to sell. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-19-000041:notes:224]
[same as prior period, unchanged from 0000833444-19-000022:notes:210]

[0000833444-19-000041:notes:225]
At June 30, 2019 and 2018, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-19-000041:notes:226]
[same as prior period, unchanged from 0000833444-19-000022:notes:212]

[0000833444-19-000041:notes:227]
[same as prior period, unchanged from 0000833444-19-000022:notes:213]

[0000833444-19-000041:notes:228]
| • | Building Solutions North America designs, sells, installs, and services HVAC and controls systems, integrated electronic security systems (including monitoring), and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in North America. Building Solutions North America also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems, to non-residential building and industrial applications in the North American marketplace. |

[0000833444-19-000041:notes:229]
[same as prior period, unchanged from 0000833444-19-000022:notes:216]

[0000833444-19-000041:notes:230]
[same as prior period, unchanged from 0000833444-19-000022:notes:217]

[0000833444-19-000041:notes:231]
[same as prior period, unchanged from 0000833444-19-000022:notes:218]

[0000833444-19-000041:notes:232]
[same as prior period, unchanged from 0000833444-19-000022:notes:219]

[0000833444-19-000041:notes:233]
On October 1, 2018, the Company adopted ASU No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." The new standard requires the mark-to-market of marketable securities investments previously recorded within accumulated other comprehensive income on the statement of financial position be recorded in the statement of income on a prospective basis beginning as of the adoption date. As these restricted investments do not relate to the underlying operating performance of its business, the Company’s definition of segment earnings excludes the mark-to-market adjustments beginning in the first quarter of fiscal 2019.

[0000833444-19-000041:notes:234]
[same as prior period, unchanged from 0000833444-19-000022:notes:221]

[0000833444-19-000041:notes:235]
[same as prior period, unchanged from 0000833444-19-000022:notes:222]

[0000833444-19-000041:notes:236]
|  | Net Sales |
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Building Solutions North America | $ | 2,327 |  |  | $ | 2,246 |  |  | $ | 6,630 |  |  | $ | 6,355 |  |
| Building Solutions EMEA/LA | 922 |  |  | 926 |  |  | 2,707 |  |  | 2,748 |  |
| Building Solutions Asia Pacific | 691 |  |  | 681 |  |  | 1,932 |  |  | 1,864 |  |
| Global Products | 2,511 |  |  | 2,429 |  |  | 6,425 |  |  | 6,250 |  |
| Total net sales | $ | 6,451 |  |  | $ | 6,282 |  |  | $ | 17,694 |  |  | $ | 17,217 |  |

[0000833444-19-000041:notes:237]
|  | Segment EBITA |
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Building Solutions North America | $ | 300 |  |  | $ | 314 |  |  | $ | 807 |  |  | $ | 780 |  |
| Building Solutions EMEA/LA | 101 |  |  | 96 |  |  | 258 |  |  | 242 |  |
| Building Solutions Asia Pacific | 98 |  |  | 97 |  |  | 240 |  |  | 242 |  |
| Global Products | 333 |  |  | 435 |  |  | 774 |  |  | 949 |  |
| Total segment EBITA | $ | 832 |  |  | $ | 942 |  |  | $ | 2,079 |  |  | $ | 2,213 |  |
| Corporate expenses | $ | 70 |  |  | $ | (142 | ) |  | $ | (233 | ) |  | $ | (442 | ) |
| Amortization of intangible assets | (93 | ) |  | (98 | ) |  | (288 | ) |  | (282 | ) |
| Restructuring and impairment costs | (235 | ) |  | — |  |  | (235 | ) |  | (154 | ) |
| Net mark-to-market adjustments | 9 |  |  | — |  |  | 8 |  |  | — |  |
| Net financing charges | (119 | ) |  | (95 | ) |  | (302 | ) |  | (304 | ) |
| Income from continuing operations before income taxes | $ | 464 |  |  | $ | 607 |  |  | $ | 1,029 |  |  | $ | 1,031 |  |


## us-gaap:GuaranteesTextBlock

[0000833444-19-000041:notes:238]
[same as prior period, unchanged from 0000833444-19-000022:notes:225]

[0000833444-19-000041:notes:239]
[same as prior period, unchanged from 0000833444-19-000022:notes:226]

[0000833444-19-000041:notes:240]
[same as prior period, unchanged from 0000833444-19-000022:notes:227]

[0000833444-19-000041:notes:241]
[same as prior period, unchanged from 0000833444-19-000022:notes:228]

[0000833444-19-000041:notes:242]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations, including extended warranties for which deferred revenue is recorded, for the nine months ended June 30, 2019 and 2018 were as follows (in millions):

[0000833444-19-000041:notes:243]
|  | Nine Months EndedJune 30, |
|  | 2019 |  | 2018 |
| Balance at beginning of period | $ | 315 |  |  | $ | 323 |  |
| Accruals for warranties issued during the period | 85 |  |  | 73 |  |
| Accruals from acquisition and divestitures | 2 |  |  | 1 |  |
| Accruals related to pre-existing warranties | (20 | ) |  | (21 | ) |
| Settlements made (in cash or in kind) during the period | (79 | ) |  | (67 | ) |
| Currency translation | 1 |  |  | — |  |
| Balance at end of period | $ | 304 |  |  | $ | 309 |  |

[0000833444-19-000041:notes:244]
As a result of the Tyco merger in the fourth quarter of fiscal 2016, the Company recorded, as part of the acquired liabilities of Tyco, $290 million of post sale contingent tax indemnification liabilities. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. At September 30, 2018, the Company recorded liabilities of $255 million, of which $235 million was related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements. In the third quarter of fiscal 2019, the majority of tax indemnification liabilities were resolved including a $226 million release as a result of changes to the likelihood of payments due to the expiration of certain statute of limitations.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-19-000041:notes:245]
Commitments and Contingencies

[0000833444-19-000041:notes:246]
Environmental Matters

[0000833444-19-000041:notes:247]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of June 30, 2019, reserves for environmental liabilities for continuing operations totaled $163 million, of which $52 million was recorded within other current liabilities and $111 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $37 million at September 30, 2018, of which $10 million was recorded within other current liabilities and $27 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

[0000833444-19-000041:notes:248]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin.  In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working closely with WDNR to address these issues insofar as they related to this migration.

[0000833444-19-000041:notes:249]
The increase in reserves as of June 30, 2019 includes $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).  The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.

[0000833444-19-000041:notes:250]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure

[0000833444-19-000041:notes:251]
that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

[0000833444-19-000041:notes:252]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990.  Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River.  In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts.

[0000833444-19-000041:notes:253]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At June 30, 2019 and September 30, 2018, the Company recorded conditional asset retirement obligations for continuing operations of $30 million and $29 million, respectively.

[0000833444-19-000041:notes:254]
Asbestos Matters

[0000833444-19-000041:notes:255]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-19-000041:notes:256]
As of June 30, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $167 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $538 million, of which $55 million was recorded in other current liabilities and $483 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $371 million, of which $49 million was recorded in other current assets, and $322 million was recorded in other noncurrent assets. Assets included $16 million of cash and $272 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at June 30, 2019 was $83 million. As of September 30, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $173 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $550 million, of which $55 million was recorded in other current liabilities and $495 million was recorded in other noncurrent liabilities. The

[0000833444-19-000041:notes:257]
Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $33 million was recorded in other current assets, and $344 million was recorded in other noncurrent assets. Assets included $6 million of cash and $281 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2018 was $90 million.

[0000833444-19-000041:notes:258]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-19-000041:notes:259]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-19-000041:notes:260]
Insurable Liabilities

[0000833444-19-000041:notes:261]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At June 30, 2019 and September 30, 2018, the insurable liabilities totaled $451 million and $417 million, respectively, of which $118 million and $95 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $311 million and $300 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at June 30, 2019 and September 30, 2018 were $26 million, of which $6 million was recorded within other current assets and $20 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-19-000041:notes:262]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-19-000041:notes:263]
Two of our subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the

[0000833444-19-000041:notes:264]
firefighting foam products manufactured by defendants contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued regulatory limits, however; while those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

[0000833444-19-000041:notes:265]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-19-000041:notes:266]
In September of 2018, the Company filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to the MDL.

[0000833444-19-000041:notes:267]
AFFF Putative Class Actions

[0000833444-19-000041:notes:268]
Chemguard and Tyco Fire Products are named in 23 putative class actions in federal and state courts in Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington New Hampshire, and Michigan. Each of these cases has been transferred to the MDL. The following putative class actions were filed in fiscal year 2019:

[0000833444-19-000041:notes:269]
| • | Grubb v. The 3M Company et al., filed October 30, 2018 in the United States District Court, District of Delaware. |

[0000833444-19-000041:notes:270]
| • | County of Dutchess v. The 3M Company et al., filed October 12, 2018 in the United States District Court, Southern District of New York. |

[0000833444-19-000041:notes:271]
| • | Battisti et al. v. The 3M Company et al., filed December 20, 2018 in the United States District Court, Middle District of Florida. |

[0000833444-19-000041:notes:272]
| • | Jackson et al. v. The 3M Company et al., filed February 5, 2019 in the United States District Court, Western District of Washington. |

[0000833444-19-000041:notes:273]
| • | Smith et al. v. The 3M Company et al., filed May 24, 2019 in the United States District Court, District of New Hampshire. |

[0000833444-19-000041:notes:274]
| • | Cadrette et al. v. The 3M Company et al., filed May 24, 2019 in the United States District Court, Eastern District of Michigan. |

[0000833444-19-000041:notes:275]
AFFF Individual or Mass Actions

[0000833444-19-000041:notes:276]
There are approximately 60 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases), Pennsylvania (11 cases), New Mexico (2 cases) and South Carolina (2 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania and two plaintiffs in New Mexico.  These matters have been transferred to or directly-filed in the MDL.  The Company is also on notice of approximately 660 other possible individual product liability claims and three possible municipal claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, but the Company anticipates that they soon will be.

[0000833444-19-000041:notes:277]
AFFF Municipal Cases

[0000833444-19-000041:notes:278]
Chemguard and Tyco Fire Products are also defendants in 23 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio and South Carolina.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  All of these cases have been transferred to the MDL. The following municipal actions were filed in fiscal year 2019:

[0000833444-19-000041:notes:279]
| • | Dutchess County v. The 3M Company et al. filed October 12, 2018 (removed to the United States District Court, Southern District of New York) and styled as a class action. |

[0000833444-19-000041:notes:280]
| • | City of Dayton v. The 3M Company et al., filed October 3, 2018 in the United States District Court, Southern District of Ohio. |

[0000833444-19-000041:notes:281]
| • | City of Stuart v. The 3M Company et al., filed October 18, 2018 in the United States District Court, Southern District of Florida. |

[0000833444-19-000041:notes:282]
| • | City of Tucson and Town of Marana v. The 3M Company et al., filed November 8, 2018 in the Superior Court of the State of Arizona, County of Pima (removed to the United States District Court for the District of Arizona). |

[0000833444-19-000041:notes:283]
| • | New Jersey-American Water Company, Inc. v. The 3M Company et al., filed November 8, 2018 in the United States District Court for the District of New Jersey. |

[0000833444-19-000041:notes:284]
| • | Village of Farmingdale v. The 3M Company et al., filed December 19, 2018 in the Supreme Court of the State of New York, County of Nassau (removed to the United States District Court for the Eastern District of New York). |

[0000833444-19-000041:notes:285]
| • | Town of East Hampton v. The 3M Company et al., filed December 28, 2018 in the Supreme Court of the State of New York, County of Suffolk. |

[0000833444-19-000041:notes:286]
| • | Ridgewood Water v. The 3M Company et al., filed February 25, 2019, in the Superior Court of the State of New Jersey, Bergen County (removed to the United States District Court for the District of New Jersey). |

[0000833444-19-000041:notes:287]
| • | Atlantic City Municipal Utilities Authority v. The 3M Company et al., filed April 10, 2019 in the United States District Court, District of New Jersey. |

[0000833444-19-000041:notes:288]
| • | Town of Vienna v. The 3M Company et al., filed March 30, 2019 in the United States District Court, District of Maryland. |

[0000833444-19-000041:notes:289]
| • | New York American Water Company, Inc. v. The 3M Company et al., filed April 11, 2019 in the United States District Court, Eastern District of New York. |

[0000833444-19-000041:notes:290]
| • | City of Fairbanks v. The 3M Company et al., filed April 26, 2019 in the United States District Court, District of Alaska. |

[0000833444-19-000041:notes:291]
| • | County of Westchester v. The 3M Company et al., filed May 24, 2019 in the United States District Court, Southern District of New York. |

[0000833444-19-000041:notes:292]
| • | Diane Hebrank et al. v. City of Newburgh v. The 3M Company et al., third-party complaint filed June 10, 2019, in the Supreme Court of New York, Orange County. |

[0000833444-19-000041:notes:293]
| • | California-American Water v. The 3M Company et al., direct-filed on June 21, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-19-000041:notes:294]
| • | City of Sioux Falls v. The 3M Company et al., direct-filed on June 26, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-19-000041:notes:295]
| • | Sioux Falls Regional Airport Authority v. The 3M Company et al., direct-filed on June 28, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-19-000041:notes:296]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base. In addition, three water districts in Pennsylvania, Horsham Water and Sewer Authority, Warminster Municipal Authority, and Warrington Township have filed praecipes for summons against Chemguard and Tyco Fire Products and other AFFF manufacturers relating to alleged PFOS and PFOA contamination.  These praecipes are not active suits, but have the effect of tolling the statute of limitations.

[0000833444-19-000041:notes:297]
State Attorneys General Litigation related to AFFF

[0000833444-19-000041:notes:298]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al., No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-19-000041:notes:299]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and tagged for transfer to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York.  This third complaint has not been served.

[0000833444-19-000041:notes:300]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752 -000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio.  The lawsuit seeks to recover costs and natural resource damages associated with the contamination.  This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-19-000041:notes:301]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.).  The State of New Jersey action has been removed to the United State District Court for the District of New Jersey and tagged for transfer to the MDL.  The State of Vermont and State of New Hampshire actions were recently served.

[0000833444-19-000041:notes:302]
AFFF Matters Related to the Tyco Fire Products Fire Technology Center in Marinette, Wisconsin

[0000833444-19-000041:notes:303]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFOA/PFOS contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.

[0000833444-19-000041:notes:304]
The Company is vigorously defending the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

[0000833444-19-000041:notes:305]
Bosch Litigation

[0000833444-19-000041:notes:306]
On March 15, 2019, a German subsidiary of the Company received a complaint from Robert Bosch GmbH (“Bosch”), filed in a German court. The complaint relates to an automotive starter batteries joint venture in which the Company and Bosch were 80/20 parties to this joint venture. At the time the complaint was filed, JCI’s ownership interest in the joint venture was to be transferred to entities controlled by the Purchaser upon consummation of the previously announced sale of the Company’s Power Solutions business.

[0000833444-19-000041:notes:307]
The complaint alleges that certain internal Company reorganization transactions were not in compliance with the arrangements relating to such joint venture. The complaint seeks a declaration that such internal reorganization transactions are void. In the alternative, the complaint seeks a declaration of damages that represent an alleged difference between (i) the value ascribed to the joint venture interests in connection with the Power Solutions sale and (ii) the value that was assigned to those interests in connection with such internal reorganization transactions. The Company believes that it has several strong defenses to the substance of the complaint and that the complaint substantially overstates any reasonable valuation of the joint venture interests. The Company does not believe the complaint has merit, and intends to defend it vigorously. While litigation is inherently uncertain, the Company believes that any ultimate liability that may arise from this proceeding would be immaterial to its business, financial condition and results of operations.

[0000833444-19-000041:notes:308]
Under the previously announced Stock and Asset Purchase Agreement dated November 13, 2018 between the Company and the Purchaser, the Company has agreed to indemnify the Purchaser for any damages that could arise from this litigation.

[0000833444-19-000041:notes:309]
Other Matters

[0000833444-19-000041:notes:310]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-19-000041:notes:311]
Related Party Transactions

[0000833444-19-000041:notes:312]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-19-000041:notes:313]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $65 million and $27 million, respectively, for the three months ended June 30, 2019; and $65 million and $19 million, respectively, for the three months ended June 30, 2018. The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $162 million and $57 million, respectively, for the nine months ended June 30, 2019; and $169 million and $43 million, respectively, for the nine months ended June 30, 2018.

[0000833444-19-000041:notes:314]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position for continuing operations (in millions):

[0000833444-19-000041:notes:315]
|  |  | June 30, 2019 |  | September 30, 2018 |  |
| Receivable from related parties |  | $ | 55 |  |  | $ | 36 |  |
| Payable to related parties |  | 8 |  |  | 18 |  |
