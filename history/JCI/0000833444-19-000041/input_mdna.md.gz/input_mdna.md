# JCI MD&A — 0000833444-19-000041


## mdna

[0000833444-19-000041:mdna:1]
[same as prior period, unchanged from 0000833444-19-000022:mdna:1]

[0000833444-19-000041:mdna:2]
[same as prior period, unchanged from 0000833444-19-000022:mdna:2]

[0000833444-19-000041:mdna:3]
[same as prior period, unchanged from 0000833444-19-000022:mdna:3]

[0000833444-19-000041:mdna:4]
[same as prior period, unchanged from 0000833444-19-000022:mdna:4]

[0000833444-19-000041:mdna:5]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. The Company creates intelligent buildings, efficient energy solutions and integrated infrastructure that work seamlessly together to deliver on the promise of smart cities and communities. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-19-000041:mdna:6]
Johnson Controls was originally incorporated in the state of Wisconsin in 1885 as Johnson Electric Service Company to manufacture, install and service automatic temperature regulation systems for buildings. The Company was renamed to Johnson Controls, Inc. in 1974. In 2005, the Company acquired York International, a global supplier of heating, ventilating, air-conditioning and refrigeration equipment and services. In 2014, the Company acquired Air Distribution Technologies, Inc. ("ADTi"), one of the largest independent providers of air distribution and ventilation products in North America. On October 1, 2015, the Company formed a joint venture with Hitachi to expand its building product offerings.

[0000833444-19-000041:mdna:7]
[same as prior period, unchanged from 0000833444-19-000022:mdna:7]

[0000833444-19-000041:mdna:8]
[same as prior period, unchanged from 0000833444-19-000022:mdna:9]

[0000833444-19-000041:mdna:9]
The Company is a global market leader in engineering, developing, manufacturing and installing building products and systems around the world, including heating, ventilating, air-conditioning ("HVAC") equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Company further serves customers by providing technical services (in the HVAC, security and fire-protection space), energy-management consulting and data-driven solutions via its data-enabled business. Finally, the Company has a strong presence in the North American residential air conditioning and heating systems market and is a global market leader in industrial refrigeration products.

[0000833444-19-000041:mdna:10]
On November 13, 2018, the Company entered into a Stock and Asset Purchase Agreement (“Purchase Agreement”) with BCP Acquisitions LLC (“Purchaser”). The Purchaser is a newly-formed entity controlled by investment funds managed by Brookfield Capital Partners LLC. Pursuant to the Purchase Agreement, on the terms and subject to the conditions therein, the Company agreed to sell, and Purchaser agreed to acquire, the Company’s Power Solutions business for a purchase price of $13.2 billion. The transaction closed on April 30, 2019 with net cash proceeds of $11.6 billion after tax and transaction-related expenses.

[0000833444-19-000041:mdna:11]
[same as prior period, unchanged from 0000833444-19-000022:mdna:13]

[0000833444-19-000041:mdna:12]
The following information should be read in conjunction with the September 30, 2018 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2018 filed with the SEC on November 20, 2018. References in the following discussion and analysis to "Three Months"(or similar language) refer to the three months ended June 30, 2019 compared to the three months ended June 30, 2018, while "Year-to-Date" refers to the nine months ended June 30, 2019 compared to the nine months ended June 30, 2018.

[0000833444-19-000041:mdna:13]
[same as prior period, unchanged from 0000833444-19-000022:mdna:15]

[0000833444-19-000041:mdna:14]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Net sales | $ | 6,451 |  |  | $ | 6,282 |  |  | 3 | % |  | $ | 17,694 |  |  | $ | 17,217 |  |  | 3 | % |

[0000833444-19-000041:mdna:15]
The increase in consolidated net sales for the three months ended June 30, 2019 was due to higher organic sales ($349 million) and acquisitions ($5 million), partially offset by the unfavorable impact of foreign currency translation ($141 million) and lower sales due to business divestitures ($44 million). The increase in organic sales related to higher volumes across all segments. Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 6% as compared to the prior year. Refer to the "Segment Analysis" below within Item 2 for a discussion of net sales by segment.

[0000833444-19-000041:mdna:16]
The increase in consolidated net sales for the nine months ended June 30, 2019 was due to higher organic sales ($1,007 million) and acquisitions ($18 million), partially offset by the unfavorable impact of foreign currency translation ($406 million) and lower sales due to business divestitures ($142 million). The increase in organic sales related to higher volumes across all segments. Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 6% as compared to the prior year. Refer to the "Segment Analysis" below within Item 2 for a discussion of net sales by segment.

[0000833444-19-000041:mdna:17]
[same as prior period, unchanged from 0000833444-19-000022:mdna:19]

[0000833444-19-000041:mdna:18]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Cost of sales | $ | 4,307 |  |  | $ | 4,194 |  |  | 3 | % |  | $ | 11,981 |  |  | $ | 11,607 |  |  | 3 | % |
| Gross profit | 2,144 |  |  | 2,088 |  |  | 3 | % |  | 5,713 |  |  | 5,610 |  |  | 2 | % |
| % of sales | 33.2 | % |  | 33.2 | % |  |  |  | 32.3 | % |  | 32.6 | % |  |  |

[0000833444-19-000041:mdna:19]
Cost of sales for the three month period ended June 30, 2019 increased as compared to the three month period ended June 30, 2018, and gross profit as a percentage of sales was unchanged. Foreign currency translation had a favorable impact on cost of sales of approximately $93 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-19-000041:mdna:20]
Cost of sales for the nine month period ended June 30, 2019 increased as compared to the nine month period ended June 30, 2018, and gross profit as a percentage of sales decreased by 30 basis points. Gross profit increased due to higher volumes across all segments, partially offset by business divestitures and higher operating costs. Foreign currency translation had a favorable impact on cost of sales of approximately $270 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-19-000041:mdna:21]
[same as prior period, unchanged from 0000833444-19-000022:mdna:23]

[0000833444-19-000041:mdna:22]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Selling, general and administrative expenses | $ | 1,388 |  |  | $ | 1,441 |  |  | -4 | % |  | $ | 4,284 |  |  | $ | 4,250 |  |  | 1 | % |
| % of sales | 21.5 | % |  | 22.9 | % |  |  |  | 24.2 | % |  | 24.7 | % |  |  |

[0000833444-19-000041:mdna:23]
Selling, general and administrative expenses ("SG&A") for the three month period ended June 30, 2019 decreased 4% as compared to the three month period ended June 30, 2018. The decrease in SG&A was primarily due to productivity savings and costs synergies, net of incremental investments, and a current year tax indemnification reserve release, partially offset by a current year environmental charge. Foreign currency translation had a favorable impact on SG&A of $27 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-19-000041:mdna:24]
SG&A for the nine month period ended June 30, 2019 increased 1% as compared to the nine month period ended June 30, 2018. The increase in SG&A was primarily due to a $114 million gain on sale of the Scott Safety business in the Global Products segment in the prior year, and a current year environmental charge, partially offset by productivity savings and costs synergies, net of incremental investments, and a current year tax indemnification reserve release. Foreign currency translation had a favorable impact on SG&A of $82 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-19-000041:mdna:25]
[same as prior period, unchanged from 0000833444-19-000022:mdna:27]

[0000833444-19-000041:mdna:26]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Restructuring and impairment costs | $ | 235 |  |  | $ | — |  |  | * |  | $ | 235 |  |  | $ | 154 |  |  | 53 | % |

[0000833444-19-000041:mdna:27]
[same as prior period, unchanged from 0000833444-19-000022:mdna:29]

[0000833444-19-000041:mdna:28]
Refer to Note 8, "Significant Restructuring and Impairment Costs," and Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-19-000041:mdna:29]
[same as prior period, unchanged from 0000833444-19-000022:mdna:31]

[0000833444-19-000041:mdna:30]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Net financing charges | $ | 119 |  |  | $ | 95 |  |  | 25 | % |  | $ | 302 |  |  | $ | 304 |  |  | -1 | % |

[0000833444-19-000041:mdna:31]
[same as prior period, unchanged from 0000833444-19-000022:mdna:33]

[0000833444-19-000041:mdna:32]
[same as prior period, unchanged from 0000833444-19-000022:mdna:34]

[0000833444-19-000041:mdna:33]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Equity income | $ | 62 |  |  | $ | 55 |  |  | 13 | % |  | $ | 137 |  |  | $ | 129 |  |  | 6 | % |

[0000833444-19-000041:mdna:34]
The increase in equity income for the three months ended June 30, 2019 was primarily due to higher income at a certain partially-owned affiliate of the Johnson Controls - Hitachi joint venture. The increase in equity income for the nine months ended June 30, 2019 was primarily due to higher income at certain partially-owned affiliates within Building Solutions EMEA/LA segment and the Johnson Controls - Hitachi joint venture. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-19-000041:mdna:35]
[same as prior period, unchanged from 0000833444-19-000022:mdna:37]

[0000833444-19-000041:mdna:36]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Income tax provision | $ | 239 |  |  | $ | 61 |  |  | * |  | $ | 394 |  |  | $ | 314 |  |  | 25 | % |
| Effective tax rate | 52 | % |  | 10 | % |  |  |  | 38 | % |  | 30 | % |  |  |

[0000833444-19-000041:mdna:37]
* Measure not meaningful

[0000833444-19-000041:mdna:38]
[same as prior period, unchanged from 0000833444-19-000022:mdna:39]

[0000833444-19-000041:mdna:39]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended June 30, 2019, the Company's effective tax rate for continuing operations was 52% and was higher than the statutory tax rate of 12.5% primarily due to a discrete tax charge related to newly enacted regulations related to U.S. Tax Reform, non-U.S. tax audit reserve adjustments and tax rate differentials, partially offset by a tax indemnification reserve release, the tax benefits of an asset held for sale impairment charge and continuing global tax planning initiatives. For the nine months ended June 30, 2019, the Company's effective tax rate for continuing operations was 38% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments as a result of tax law changes, a discrete tax charge related to newly enacted regulations related to U.S. Tax Reform, non-U.S. tax audit reserve adjustments, and tax rate differentials, partially offset by a tax indemnification reserve release, the tax benefits of an asset held for sale impairment charge and continuing global tax planning initiatives. For the three months ended June 30, 2018, the Company's effective tax rate for continuing operations was 10% and was lower than the statutory tax rate of 12.5% primarily due to the benefits of continuing global tax planning initiatives. For the nine months ended June 30, 2018, the Company's effective tax rate for continuing operations was 30% and was higher than the statutory tax rate of 12.5% primarily due to the discrete net impacts of U.S. Tax Reform, the tax impact of the divestiture of the Scott Safety business and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives and tax audit closures. The effective tax rate for the nine months ended June 30, 2019 increased as compared to the nine months ended June 30, 2018 primarily

[0000833444-19-000041:mdna:40]
52

[0000833444-19-000041:mdna:41]
due to the discrete tax items described below and tax planning initiatives. The global tax planning initiatives related primarily to foreign tax credit planning, global financing structures and alignment of our global business functions in a tax efficient manner.

[0000833444-19-000041:mdna:42]
[same as prior period, unchanged from 0000833444-19-000022:mdna:41]

[0000833444-19-000041:mdna:43]
[same as prior period, unchanged from 0000833444-19-000022:mdna:42]

[0000833444-19-000041:mdna:44]
In the third quarter of fiscal 2019, the Company recorded a discrete charge of $199 million related to newly enacted regulations related to U.S. Tax Reform which impacted the Company's reserves for uncertain tax positions.

[0000833444-19-000041:mdna:45]
In the third quarter of fiscal 2019, the Company recorded a discrete charge of $27 million related to non-U.S. tax examinations.

[0000833444-19-000041:mdna:46]
In the third quarter of fiscal 2019, the Company recorded a $235 million impairment charge related to assets held for sale. Refer to Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for further information regarding the impairment charge.  The impairment charge generated a $53 million tax benefit.

[0000833444-19-000041:mdna:47]
In the third quarter of fiscal 2019, the Company released a $226 million tax indemnification reserve. Refer to Note 19, "Guarantees," of the notes to consolidated financial statements for further information regarding the reserve release. The reserve release generated no income tax expense.

[0000833444-19-000041:mdna:48]
[same as prior period, unchanged from 0000833444-19-000022:mdna:43]

[0000833444-19-000041:mdna:49]
In the first quarter of fiscal 2018, tax audit resolutions resulted in a $25 million net benefit to income tax expense.

[0000833444-19-000041:mdna:50]
[same as prior period, unchanged from 0000833444-19-000022:mdna:44]

[0000833444-19-000041:mdna:51]
[same as prior period, unchanged from 0000833444-19-000022:mdna:45]

[0000833444-19-000041:mdna:52]
[same as prior period, unchanged from 0000833444-19-000022:mdna:76]

[0000833444-19-000041:mdna:53]
[same as prior period, unchanged from 0000833444-19-000022:mdna:46]

[0000833444-19-000041:mdna:54]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Income from discontinued operations, net of tax | $ | 4,051 |  |  | $ | 258 |  |  | * |  | $ | 4,598 |  |  | $ | 841 |  |  | * |

[0000833444-19-000041:mdna:55]
* Measure not meaningful

[0000833444-19-000041:mdna:56]
[same as prior period, unchanged from 0000833444-19-000022:mdna:48]

[0000833444-19-000041:mdna:57]
[same as prior period, unchanged from 0000833444-19-000022:mdna:49]

[0000833444-19-000041:mdna:58]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 84 |  |  | $ | 72 |  |  | 17 | % |  | $ | 147 |  |  | $ | 134 |  |  | 10 | % |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | 9 |  |  | * |  |  | 24 |  |  | 33 |  |  | -27 | % |

[0000833444-19-000041:mdna:59]
* Measure not meaningful

[0000833444-19-000041:mdna:60]
The increase in income from continuing operations attributable to noncontrolling interests for the three and nine months ended June 30, 2019 was primarily due to higher net income at certain partially-owned affiliates within the Global Products segment.

[0000833444-19-000041:mdna:61]
[same as prior period, unchanged from 0000833444-19-000022:mdna:52]

[0000833444-19-000041:mdna:62]
[same as prior period, unchanged from 0000833444-19-000022:mdna:53]

[0000833444-19-000041:mdna:63]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Net income attributable to Johnson Controls | $ | 4,192 |  |  | $ | 723 |  |  | * |  | $ | 5,062 |  |  | $ | 1,391 |  |  | * |

[0000833444-19-000041:mdna:64]
* Measure not meaningful

[0000833444-19-000041:mdna:65]
The increase in net income attributable to Johnson Controls for the three and nine months ended June 30, 2019 was primarily due to the gain on sale of the Power Solutions business and higher gross profit, partially offset by a non-cash impairment charge, and a higher income tax provision.

[0000833444-19-000041:mdna:66]
Diluted earnings per share attributable to Johnson Controls for the three months ended June 30, 2019 was $4.79 compared to $0.78 for the three months ended June 30, 2018. Diluted earnings per share attributable to Johnson Controls for the nine months ended June 30, 2019 was $5.61 compared to $1.49 for the nine months ended June 30, 2018.

[0000833444-19-000041:mdna:67]
[same as prior period, unchanged from 0000833444-19-000022:mdna:57]

[0000833444-19-000041:mdna:68]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 4,097 |  |  | $ | 169 |  |  | * |  | $ | 4,969 |  |  | $ | 1,056 |  |  | * |

[0000833444-19-000041:mdna:69]
* Measure not meaningful

[0000833444-19-000041:mdna:70]
The increase in comprehensive income attributable to Johnson Controls for the three months ended June 30, 2019 was due to higher net income attributable to Johnson Controls ($3,469 million) and an increase in other comprehensive income attributable to Johnson Controls ($459 million) resulting primarily from favorable currency translation adjustments. The year-over-year favorable foreign currency translation adjustments were primarily driven by the weakening of the British pound and euro currencies against the U.S. dollar in the prior year.

[0000833444-19-000041:mdna:71]
The increase in comprehensive income attributable to Johnson Controls for the nine months ended June 30, 2019 was due to higher net income attributable to Johnson Controls ($3,671 million) and an increase in other comprehensive income attributable to Johnson Controls ($242 million) resulting primarily from favorable currency translation adjustments. The year-over-year favorable foreign currency translation adjustments were primarily driven by the weakening of the British pound and euro currencies against the U.S. dollar in the prior year.

[0000833444-19-000041:mdna:72]
[same as prior period, unchanged from 0000833444-19-000022:mdna:61]

[0000833444-19-000041:mdna:73]
On October 1, 2018, the Company adopted Accounting Standards Update ("ASU") No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." The new standard requires the mark-to-market of marketable securities investments previously recorded within accumulated other comprehensive income on the statement of financial position be recorded in the statement of income on a prospective basis beginning as of the adoption date. As these restricted investments do not relate to the underlying operating performance of its business, the Company’s definition of segment earnings excludes the mark-to-market adjustments beginning in the first quarter of fiscal 2019.

[0000833444-19-000041:mdna:74]
[same as prior period, unchanged from 0000833444-19-000022:mdna:63]

[0000833444-19-000041:mdna:75]
[same as prior period, unchanged from 0000833444-19-000022:mdna:64]

[0000833444-19-000041:mdna:76]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Building Solutions North America | $ | 2,327 |  |  | $ | 2,246 |  |  | 4 | % |  | $ | 6,630 |  |  | $ | 6,355 |  |  | 4 | % |
| Building Solutions EMEA/LA | 922 |  |  | 926 |  |  | - % |  |  | 2,707 |  |  | 2,748 |  |  | -1 | % |
| Building Solutions Asia Pacific | 691 |  |  | 681 |  |  | 1 | % |  | 1,932 |  |  | 1,864 |  |  | 4 | % |
| Global Products | 2,511 |  |  | 2,429 |  |  | 3 | % |  | 6,425 |  |  | 6,250 |  |  | 3 | % |
|  | $ | 6,451 |  |  | $ | 6,282 |  |  | 3 | % |  | $ | 17,694 |  |  | $ | 17,217 |  |  | 3 | % |

[0000833444-19-000041:mdna:77]
[same as prior period, unchanged from 0000833444-19-000022:mdna:66]

[0000833444-19-000041:mdna:78]
| • | The increase in Building Solutions North America was due to higher volumes ($88 million), partially offset by the unfavorable impact of foreign currency translation ($7 million). The increase in volumes was primarily attributable to higher installation / service sales. |

[0000833444-19-000041:mdna:79]
| • | The decrease in Building Solutions EMEA/LA was due to the unfavorable impact of foreign currency translation ($54 million) and lower volumes due to business divestitures ($3 million), partially offset by higher volumes ($51 million) |

[0000833444-19-000041:mdna:80]
[same as prior period, unchanged from 0000833444-19-000022:mdna:100]

[0000833444-19-000041:mdna:81]
and incremental sales related to a business acquisition ($2 million). The increase in volumes was primarily attributable to higher installation sales.

[0000833444-19-000041:mdna:82]
| • | The increase in Building Solutions Asia Pacific was due to higher volumes ($40 million) and incremental sales related to a business acquisition ($1 million), partially offset by the unfavorable impact of foreign currency translation ($31 million). The increase in volumes was primarily attributable to higher installation sales. |

[0000833444-19-000041:mdna:83]
| • | The increase in Global Products was due to higher volumes ($170 million) and incremental sales related to business acquisitions ($2 million), partially offset by the unfavorable impact of foreign currency translation ($49 million) and lower volumes related to business divestitures ($41 million). The increase in volumes was across HVAC and refrigeration equipment, building management and specialty products businesses. |

[0000833444-19-000041:mdna:84]
[same as prior period, unchanged from 0000833444-19-000022:mdna:71]

[0000833444-19-000041:mdna:85]
| • | The increase in Building Solutions North America was due to higher volumes ($300 million), partially offset by the unfavorable impact of foreign currency translation ($25 million). The increase in volumes was primarily attributable to higher installation / service sales. |

[0000833444-19-000041:mdna:86]
| • | The decrease in Building Solutions EMEA/LA was due to the unfavorable impact of foreign currency translation ($166 million) and lower volumes due to business divestitures ($3 million), partially offset by higher volumes ($124 million) and incremental sales related to a business acquisition ($4 million). The increase in volumes was primarily attributable to higher installation / service sales. |

[0000833444-19-000041:mdna:87]
| • | The increase in Building Solutions Asia Pacific was due to higher volumes ($142 million) and incremental sales related to a business acquisition ($1 million), partially offset by the unfavorable impact of foreign currency translation ($75 million). The increase in volumes was primarily attributable to higher installation / service sales. |

[0000833444-19-000041:mdna:88]
| • | The increase in Global Products was due to higher volumes ($441 million) and incremental sales related to business acquisitions ($13 million), partially offset by the unfavorable impact of foreign currency translation ($140 million) and lower volumes related to business divestitures ($139 million). The increase in volumes was primarily attributable to higher building management, HVAC and refrigeration equipment, and specialty products sales. |

[0000833444-19-000041:mdna:89]
[same as prior period, unchanged from 0000833444-19-000022:mdna:77]

[0000833444-19-000041:mdna:90]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Building Solutions North America | $ | 300 |  |  | $ | 314 |  |  | -4 | % |  | $ | 807 |  |  | $ | 780 |  |  | 3 | % |
| Building Solutions EMEA/LA | 101 |  |  | 96 |  |  | 5 | % |  | 258 |  |  | 242 |  |  | 7 | % |
| Building Solutions Asia Pacific | 98 |  |  | 97 |  |  | 1 | % |  | 240 |  |  | 242 |  |  | -1 | % |
| Global Products | 333 |  |  | 435 |  |  | -23 | % |  | 774 |  |  | 949 |  |  | -18 | % |
|  | $ | 832 |  |  | $ | 942 |  |  | -12 | % |  | $ | 2,079 |  |  | $ | 2,213 |  |  | -6 | % |

[0000833444-19-000041:mdna:91]
[same as prior period, unchanged from 0000833444-19-000022:mdna:79]

[0000833444-19-000041:mdna:92]
| • | The decrease in Building Solutions North America was due to higher SG&A, including incremental sales investments, and unfavorable mix ($31 million) and current year integration costs ($10 million), partially offset by favorable volumes ($23 million) and prior year integration costs ($4 million). |

[0000833444-19-000041:mdna:93]
| • | The increase in Building Solutions EMEA/LA was due to favorable volumes ($19 million), prior year integration costs ($2 million) and higher equity income ($1 million), partially offset by the unfavorable impact of foreign currency translation ($9 million), higher SG&A, including incremental sales investments ($6 million), and current year integration costs ($2 million). |

[0000833444-19-000041:mdna:94]
| • | The increase in Building Solutions Asia Pacific was due to higher volumes ($11 million), partially offset by higher SG&A, including incremental sales investments ($7 million), and the unfavorable impact of foreign currency translation ($3 million). |

[0000833444-19-000041:mdna:95]
56

[0000833444-19-000041:mdna:96]
| • | The decrease in Global Products was due to a current year environmental charge ($140 million), higher SG&A and operating expenses, including product investments, net of productivity savings ($10 million), the unfavorable impact of foreign currency translation ($9 million), current year integration costs ($8 million) and lower income due to business divestitures ($4 million). These items were partially offset by favorable volumes / mix ($57 million), prior year integration costs ($6 million) and higher equity income ($6 million). |

[0000833444-19-000041:mdna:97]
[same as prior period, unchanged from 0000833444-19-000022:mdna:84]

[0000833444-19-000041:mdna:98]
| • | The increase in Building Solutions North America was due to favorable volumes ($78 million) and prior year integration costs ($18 million), partially offset by higher SG&A, including incremental sales investments, and unfavorable mix ($52 million), current year integration costs ($15 million) and the unfavorable impact of foreign currency translation ($2 million). |

[0000833444-19-000041:mdna:99]
| • | The increase in Building Solutions EMEA/LA was due to favorable volumes / mix ($36 million), prior year integration costs ($5 million), higher equity income ($4 million) and incremental income related to a business acquisition ($1 million), partially offset by the unfavorable impact of foreign currency translation ($26 million), current year integration costs ($3 million) and higher SG&A, including incremental sales investments ($1 million). |

[0000833444-19-000041:mdna:100]
| • | The decrease in Building Solutions Asia Pacific was due to unfavorable mix / margin rates ($20 million), higher SG&A, including incremental investments ($11 million) and the unfavorable impact of foreign currency translation ($7 million), partially offset by higher volumes ($36 million). |

[0000833444-19-000041:mdna:101]
| • | The decrease in Global Products was due to a current year environmental charge ($140 million), a prior year gain on sale of Scott Safety ($114 million), higher SG&A and operating expenses, including product investments and a prior year insignificant gain on a business divestiture, net of productivity savings ($53 million), the unfavorable impact of foreign currency translation ($19 million), lower income due to business divestitures and acquisitions ($16 million) and current year integration costs ($16 million). These items were partially offset by favorable volumes / mix ($160 million), prior year integration costs ($21 million) and higher equity income ($2 million). |

[0000833444-19-000041:mdna:102]
[same as prior period, unchanged from 0000833444-19-000022:mdna:89]

[0000833444-19-000041:mdna:103]
The Company’s backlog relating to the Building Technologies & Solutions business is applicable to its sales of systems and services. At June 30, 2019, the backlog was $9.3 billion, of which $9.0 billion is attributable to the field business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-19-000041:mdna:104]
In the first quarter of fiscal 2019, the Company adopted ASC 606, “Revenue from Contracts with Customers,” and as a result is required to disclose remaining performance obligations. At June 30, 2019, remaining performance obligations were $14.2 billion, which is $4.9 billion higher than the Company's backlog of $9.3 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-19-000041:mdna:105]
[same as prior period, unchanged from 0000833444-19-000022:mdna:92]

[0000833444-19-000041:mdna:106]
[same as prior period, unchanged from 0000833444-19-000022:mdna:93]

[0000833444-19-000041:mdna:107]
[same as prior period, unchanged from 0000833444-19-000022:mdna:94]

[0000833444-19-000041:mdna:108]
[same as prior period, unchanged from 0000833444-19-000022:mdna:95]

[0000833444-19-000041:mdna:109]
[same as prior period, unchanged from 0000833444-19-000022:mdna:96]

[0000833444-19-000041:mdna:110]
[same as prior period, unchanged from 0000833444-19-000022:mdna:97]

[0000833444-19-000041:mdna:111]
|  | June 30, |  | September 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Current assets | $ | 13,042 |  |  | $ | 11,823 |  |  |  |
| Current liabilities | (9,242 | ) |  | (11,250 | ) |  |  |
|  | 3,800 |  |  | 573 |  |  | * |  |
| Less: Cash | (3,685 | ) |  | (185 | ) |  |  |
| Add: Short-term debt | 20 |  |  | 1,306 |  |  |  |
| Add: Current portion of long-term debt | 501 |  |  | 1 |  |  |  |
| Less: Assets held for sale | (95 | ) |  | (3,015 | ) |  |  |
| Add: Liabilities held for sale | 46 |  |  | 1,791 |  |  |  |
| Working capital (as defined) | $ | 587 |  |  | $ | 471 |  |  | 25 | % |
| Accounts receivable - net | $ | 6,033 |  |  | $ | 5,622 |  |  | 7 | % |
| Inventories | 2,050 |  |  | 1,819 |  |  | 13 | % |
| Accounts payable | 3,671 |  |  | 3,407 |  |  | 8 | % |
| * Measure not meaningful |  |  |  |  |  |

[0000833444-19-000041:mdna:112]
[same as prior period, unchanged from 0000833444-19-000022:mdna:99]

[0000833444-19-000041:mdna:113]
| • | The increase in working capital at June 30, 2019 as compared to September 30, 2018, was primarily due to an increase in accounts receivable due to organic sales growth, an increase in inventory to meet anticipated customer demand and timing of employee benefit payments, partially offset by an increase in accounts payable due to timing and mix of supplier payments, and an increase in other current liabilities. |

[0000833444-19-000041:mdna:114]
| • | The Company’s days sales in accounts receivable at June 30, 2019 and September 30, 2018 were 68 days. There has been no significant adverse changes in the level of overdue receivables or significant changes in revenue recognition methods. |

[0000833444-19-000041:mdna:115]
| • | The Company’s inventory turns for the three months ended June 30, 2019 were the same as the comparable period ended September 30, 2018. |

[0000833444-19-000041:mdna:116]
| • | Days in accounts payable at June 30, 2019 were 69 days, lower than 72 days at the comparable period ended September 30, 2018. |

[0000833444-19-000041:mdna:117]
58

[0000833444-19-000041:mdna:118]
[same as prior period, unchanged from 0000833444-19-000022:mdna:105]

[0000833444-19-000041:mdna:119]
|  |  | Nine Months Ended June 30, |
| (in millions) |  | 2019 |  | 2018 |
| Cash provided by operating activities |  | $ | 711 |  |  | $ | 697 |  |
| Cash provided (used) by investing activities |  | (363 | ) |  | 1,601 |  |
| Cash used by financing activities |  | (9,500 | ) |  | (2,525 | ) |
| Capital expenditures |  | (401 | ) |  | (481 | ) |

[0000833444-19-000041:mdna:120]
| • | The increase in cash provided by operating activities for the nine months ended June 30, 2019 was primarily due favorable changes in other assets and higher partially-owned affiliate dividends, partially offset by unfavorable changes in accounts payable and accrued liabilities, and inventory. |

[0000833444-19-000041:mdna:121]
| • | The increase in cash used by investing activities for the nine months ended June 30, 2019 was primarily due to net cash proceeds received from the Scott Safety business divestiture in the prior year, partially offset by lower capital expenditures. |

[0000833444-19-000041:mdna:122]
| • | The increase in cash used by financing activities for the nine months ended June 30, 2019 was primarily due to higher stock repurchases and higher repayments of debt. |

[0000833444-19-000041:mdna:123]
| • | The decrease in capital expenditures for the nine months ended June 30, 2019 primarily is due to timing of capital investment spend in the current year. |

[0000833444-19-000041:mdna:124]
[same as prior period, unchanged from 0000833444-19-000022:mdna:110]

[0000833444-19-000041:mdna:125]
|  | June 30, |  | September 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Short-term debt | $ | 20 |  |  | $ | 1,306 |  |  |  |
| Current portion of long-term debt | 501 |  |  | 1 |  |  |  |
| Long-term debt | 6,804 |  |  | 9,623 |  |  |  |
| Total debt | 7,325 |  |  | 10,930 |  |  | -33 | % |
| Less: cash and cash equivalents | 3,685 |  |  | 185 |  |  |  |
| Total net debt | 3,640 |  |  | 10,745 |  |  | -66 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 20,363 |  |  | 21,164 |  |  | -4 | % |
| Total capitalization | $ | 24,003 |  |  | $ | 31,909 |  |  | -25 | % |
| Total net debt as a % of total capitalization | 15.2 | % |  | 33.7 | % |  |  |

[0000833444-19-000041:mdna:126]
[same as prior period, unchanged from 0000833444-19-000022:mdna:112]

[0000833444-19-000041:mdna:127]
| • | In the third quarter of fiscal 2019, the Company began deploying the net cash proceeds from the Power Solution sale, which included a reduction in debt of approximately $3.4 billion and share repurchases. The debt reduction included short-term and long-term debt repayments, including a $1.5 billion debt tender as further described below. |

[0000833444-19-000041:mdna:128]
| • | The Company believes its capital resources and liquidity position at June 30, 2019 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in the remainder of fiscal 2019 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term |

[0000833444-19-000041:mdna:129]
59

[0000833444-19-000041:mdna:130]
debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company is unable to issue commercial paper, it would have the ability to draw on its $2.0 billion revolving credit facility. The facility matures in August 2020. There were no draws on the revolving credit facility as of June 30, 2019 and September 30, 2018. The Company also selectively makes use of short-term credit lines other than its revolving credit facility. The Company, as of June 30, 2019, could borrow up to $2.8 billion based on committed credit lines. In addition, the Company held cash and cash equivalents of $3.6 billion as of June 30, 2019. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-19-000041:mdna:131]
| • | In June 2019, the Company completed a "modified Dutch auction" tender offer to repurchase approximately $4.0 billion of its ordinary shares at a price of $39.25 per share. |

[0000833444-19-000041:mdna:132]
| • | In May 2019, the Company completed the debt tender offer to purchase up to $1.5 billion in aggregate principal amount of certain of its outstanding notes for $1.6 billion total consideration. The Company recognized a loss on the extinguishment of debt of $60 million, which was recorded within the net financing charges in the consolidated statements of income. |

[0000833444-19-000041:mdna:133]
| • | The Company’s debt financial covenant in its revolving credit facility requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of June 30, 2019, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures, governing its notes, and expect to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating. |

[0000833444-19-000041:mdna:134]
| • | The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2019, the Company believes the long-term rate of return will approximate 7.10%, 5.20% and 5.65% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first nine months of fiscal 2019, the Company made approximately $51 million in total pension and postretirement contributions for continuing operations. In total, the Company expects to contribute approximately $55 million in cash to its defined benefit pension plans in fiscal 2019 for continuing operations. The Company expects to contribute $15 million in cash to its postretirement plans in fiscal 2019 for continuing operations. |

[0000833444-19-000041:mdna:135]
| • | The Company earns a significant amount of its operating income outside of the parent company. Outside basis differences in consolidated subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in fiscal 2019, the Company provided income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain subsidiaries as a result of the planned divestiture of the Power Solutions business. Also, in fiscal 2018, due to U.S. Tax Reform, the Company provided income tax related to the change in the Company’s assertion over the outside basis difference of certain non-U.S. subsidiaries owned directly or indirectly by U.S. subsidiaries. Under U.S. Tax Reform, the U.S. has adopted a territorial tax system that provides an exemption for dividends received by U.S. corporations from 10% or more owned non-U.S. corporations. However, certain non-U.S, U.S. state and withholding taxes may still apply when closing an outside basis difference via distribution or other transactions. The Company currently does not intend nor foresee a need to repatriate undistributed earnings or reduce outside basis differences other than as noted above or in tax efficient manners. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in a tax efficient manner, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings. |

[0000833444-19-000041:mdna:136]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2018 and recorded $255 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2018 restructuring plan will reduce annual operating costs for continuing operations by approximately $300 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in 2020. For fiscal 2019, the savings, net of execution costs, are expected to be approximately 70% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in 2020. The restructuring plan reserve balance of $106 million at June 30, 2019 is expected to be paid in cash. |

[0000833444-19-000041:mdna:137]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2017 and recorded $347 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs for continuing operations by approximately $260 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2019. The restructuring action is expected to be substantially complete in fiscal 2019. The restructuring plan reserve balance of $69 million at June 30, 2019 is expected to be paid in cash. |

[0000833444-19-000041:mdna:138]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2016 and recorded $222 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2016 restructuring plan will reduce annual operating costs for continuing operations by approximately $127 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2019. The restructuring action is expected to be substantially complete in fiscal 2019. The restructuring plan reserve balance of $59 million at June 30, 2019 is expected to be paid in cash. |

[0000833444-19-000041:mdna:139]
| • | Refer to Note 11, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information on items impacting capitalization. |

[0000833444-19-000041:mdna:140]
[same as prior period, unchanged from 0000833444-19-000022:mdna:123]

[0000833444-19-000041:mdna:141]
[same as prior period, unchanged from 0000833444-19-000022:mdna:124]
