# JCI 8-K — 0000833444-19-000038 filed 2019-07-31

## item codes, every 8-K on or before 2019-08-01

- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2019-08-01

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-19-000038:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq3fy19.htm
EXHIBIT 99.1

[0000833444-19-000038:8k_2_02:2]
Exhibit

[0000833444-19-000038:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000833444-19-000038:8k_2_02:4]
| CONTACT: | Investors:Antonella Franzen(609) 720-4665Ryan Edelman(609) 720-4545Media:Fraser Engerman(414) 524-2733 | Exhibit 99.1 |

[0000833444-19-000038:8k_2_02:5]
Johnson Controls reports strong organic revenue and earnings growth in fiscal Q3;

[0000833444-19-000038:8k_2_02:6]
Tightens fiscal 2019 EPS guidance to high end of previous range

[0000833444-19-000038:8k_2_02:7]
________________________________________________________________________________

[0000833444-19-000038:8k_2_02:8]
| ▪ | GAAP EPS from continuing operations of $0.16 per share, including special items |

[0000833444-19-000038:8k_2_02:9]
| ▪ | Adjusted EPS from continuing operations of $0.65, up 20% versus prior year |

[0000833444-19-000038:8k_2_02:10]
| ▪ | Sales of $6.5 billion, up 3%, reflecting organic growth of 6%; Field up 2% with organic growth of 5%; Products up 3% with organic growth of 7% |

[0000833444-19-000038:8k_2_02:11]
| ▪ | Field orders up 6% organically versus prior year; Backlog up 7% organically versus prior year |

[0000833444-19-000038:8k_2_02:12]
| ▪ | Cash provided by operating activities from continuing operations of $0.6 billion; Adjusted free cash flow of $0.6 billion |

[0000833444-19-000038:8k_2_02:13]
| ▪ | Completed the sale of the Power Solutions business with net cash proceeds of $11.6 billion; equity tender approximated 102 million shares for $4.0 billion and repaid $3.4 billion of debt |

[0000833444-19-000038:8k_2_02:14]
| ▪ | Tightens fiscal 2019 adjusted EPS from continuing operations guidance range to $1.93 to $1.95, representing a year-over-year increase of 21% to 23% |

[0000833444-19-000038:8k_2_02:15]
________________________________________________________________________________

[0000833444-19-000038:8k_2_02:16]
CORK, Ireland, July 31, 2019 -- Johnson Controls International plc (NYSE: JCI) today reported fiscal third quarter 2019 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.16.  Excluding special items, adjusted EPS from continuing operations was $0.65, up 20% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-19-000038:8k_2_02:17]
Sales of $6.5 billion increased 3% compared to the prior year.  Excluding the impacts of M&A and foreign currency, sales grew 6% organically.

[0000833444-19-000038:8k_2_02:18]
GAAP earnings before interest and taxes (“EBIT”) was $583 million and EBIT margin was 9.0%. Adjusted EBIT was $809 million and adjusted EBIT margin was 12.5%, up 50 basis points over the prior year.  Excluding the

[0000833444-19-000038:8k_2_02:19]
Page 1 of 16

[0000833444-19-000038:8k_2_02:20]
impact of M&A and foreign currency, underlying adjusted EBIT grew 11% versus the prior year and margin increased 60 basis points.

[0000833444-19-000038:8k_2_02:21]
“We delivered another strong quarter of organic revenue, order and backlog growth as well as solid free cash flow.  These results reflect the continued emphasis on driving underlying fundamentals with a focus on new product development, talent management and enhanced commercial excellence across the organization,” said George Oliver, chairman and CEO.  “We are pleased with the execution of our capital deployment actions related to the proceeds from the Power Solutions sale, which has positioned us to tighten our EPS guidance to the high end of the previous range,” Oliver added.

[0000833444-19-000038:8k_2_02:22]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-19-000038:8k_2_02:23]
($ millions, except per-share amounts)

[0000833444-19-000038:8k_2_02:24]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal third quarter of 2018.  The results of Power Solutions are reported as discontinued operations in all periods presented.

[0000833444-19-000038:8k_2_02:25]
Organic sales growth, organic EBITA growth, adjusted segment EBITA, adjusted EBIT, adjusted EPS from continuing operations and adjusted free cash flow are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes.  A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-19-000038:8k_2_02:26]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2018 |  | Q3 2019 |  | Q3 2018 |  | Q3 2019 |  | Change |
| Sales |  | $6,282 |  | $6,451 |  | $6,282 |  | $6,451 |  | +3% |
| Segment EBITA |  | 942 |  | 832 |  | 954 |  | 992 |  | +4% |
| EBIT |  | 702 |  | 583 |  | 753 |  | 809 |  | +7% |
| Net income from continuing operations |  | 474 |  | 141 |  | 506 |  | 565 |  | +12% |
| Diluted EPS from continuing operations |  | $0.51 |  | $0.16 |  | $0.54 |  | $0.65 |  | +20% |

[0000833444-19-000038:8k_2_02:27]
Page 2 of 16

[0000833444-19-000038:8k_2_02:28]
BUSINESS RESULTS

[0000833444-19-000038:8k_2_02:29]
Building Solutions North America

[0000833444-19-000038:8k_2_02:30]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2018 |  | Q3 2019 |  | Q3 2018 |  | Q3 2019 |  | Change |
| Sales |  | $2,246 |  | $2,327 |  | $2,246 |  | $2,327 |  | 4% |
| Segment EBITA |  | $314 |  | $300 |  | $318 |  | $310 |  | (3%) |
| Segment EBITA margin % |  | 14.0% |  | 12.9% |  | 14.2% |  | 13.3% |  | (90bps) |

[0000833444-19-000038:8k_2_02:31]
Sales in the quarter of $2.3 billion increased 4% versus the prior year.  Excluding M&A and foreign currency, organic sales also increased 4% versus the prior year driven by strong growth in HVAC & Controls and, to a lesser extent, growth in Fire & Security. This was partially offset by a decline in Performance Solutions due to the timing of projects.

[0000833444-19-000038:8k_2_02:32]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 6% year-over-year.  Backlog at the end of the quarter of $5.7 billion increased 6% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-19-000038:8k_2_02:33]
Adjusted segment EBITA was $310 million, down 3% versus the prior year. Adjusted segment EBITA margin of 13.3% declined 90 basis points versus the prior year as favorable volume leverage as well as cost synergies and productivity savings, were more than offset by unfavorable mix and run-rate salesforce additions.

[0000833444-19-000038:8k_2_02:34]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-19-000038:8k_2_02:35]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2018 |  | Q3 2019 |  | Q3 2018 |  | Q3 2019 |  | Change |
| Sales |  | $926 |  | $922 |  | $926 |  | $922 |  | (0%) |
| Segment EBITA |  | $96 |  | $101 |  | $98 |  | $103 |  | 5% |
| Segment EBITA margin % |  | 10.4% |  | 11.0% |  | 10.6% |  | 11.2% |  | 60bps |

[0000833444-19-000038:8k_2_02:36]
Sales in the quarter of $922 million declined slightly versus the prior year.  Excluding M&A and foreign currency, organic sales grew 6% versus the prior year driven by strong growth in project installations. Growth was positive across most regions, led by strength in HVAC, Fire & Security and Industrial Refrigeration in Europe and Latin America.

[0000833444-19-000038:8k_2_02:37]
Page 3 of 16

[0000833444-19-000038:8k_2_02:38]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 8% year-over-year.  Backlog at the end of the quarter of $1.7 billion increased 11% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-19-000038:8k_2_02:39]
Adjusted segment EBITA was $103 million, up 5% versus the prior year. Adjusted segment EBITA margin of 11.2% expanded 60 basis points over the prior year, including a 30 basis point headwind related to foreign currency.  Adjusting for foreign currency, the underlying margin improved 90 basis points driven by favorable volume as well as the benefit from cost synergies and productivity savings, partially offset by run-rate salesforce additions.

[0000833444-19-000038:8k_2_02:40]
Building Solutions Asia Pacific

[0000833444-19-000038:8k_2_02:41]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2018 |  | Q3 2019 |  | Q3 2018 |  | Q3 2019 |  | Change |
| Sales |  | $681 |  | $691 |  | $681 |  | $691 |  | 1% |
| Segment EBITA |  | $97 |  | $98 |  | $97 |  | $98 |  | 1% |
| Segment EBITA margin % |  | 14.2% |  | 14.2% |  | 14.2% |  | 14.2% |  | Flat |

[0000833444-19-000038:8k_2_02:42]
Sales in the quarter of $691 million increased 1% versus the prior year.  Excluding M&A and foreign currency, organic sales increased 6% versus the prior year driven primarily by strong growth in project installations and solid growth in China.

[0000833444-19-000038:8k_2_02:43]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 1% year-over-year.  Backlog at the end of the quarter of $1.6 billion increased 7% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-19-000038:8k_2_02:44]
Adjusted segment EBITA was $98 million, up 1% versus the prior year. Adjusted segment EBITA margin of 14.2% was flat versus the prior year as favorable volume was offset by unfavorable mix, run-rate salesforce additions and expected underlying margin pressure.

[0000833444-19-000038:8k_2_02:45]
Global Products

[0000833444-19-000038:8k_2_02:46]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2018 |  | Q3 2019 |  | Q3 2018 |  | Q3 2019 |  | Change |
| Sales |  | $2,429 |  | $2,511 |  | $2,429 |  | $2,511 |  | 3% |
| Segment EBITA |  | $435 |  | $333 |  | $441 |  | $481 |  | 9% |
| Segment EBITA margin % |  | 17.9% |  | 13.3% |  | 18.2% |  | 19.2% |  | 100bps |

[0000833444-19-000038:8k_2_02:47]
Page 4 of 16

[0000833444-19-000038:8k_2_02:48]
Sales in the quarter of $2.5 billion increased 3% versus the prior year. Excluding M&A and foreign currency, organic sales increased 7% versus the prior year with solid growth across Building Management Systems, HVAC & Refrigeration Equipment, and Specialty Products.

[0000833444-19-000038:8k_2_02:49]
Adjusted segment EBITA was $481 million, up 9% versus the prior year. Adjusted segment EBITA margin of 19.2% expanded 100 basis points over the prior year. This increase was driven by favorable volume and mix, positive price/cost as well as the benefit of cost synergies and productivity savings, partially offset by ongoing product investments.

[0000833444-19-000038:8k_2_02:50]
Corporate

[0000833444-19-000038:8k_2_02:51]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2018 |  | Q3 2019 |  | Q3 2018 |  | Q3 2019 |  | Change |
| Corporate expense |  | ($142) |  | $70 |  | ($103) |  | ($90) |  | (13%) |

[0000833444-19-000038:8k_2_02:52]
Adjusted Corporate expense was $90 million in the quarter, a decrease of 13% compared to the prior year, driven primarily by continued cost synergies and productivity savings.

[0000833444-19-000038:8k_2_02:53]
OTHER ITEMS

[0000833444-19-000038:8k_2_02:54]
| • | For the quarter, cash provided by operating activities from continuing operations was $0.6 billion and capital expenditures were $0.1 billion, resulting in free cash flow from continuing operations of $0.5 billion. Adjusted free cash flow was $0.6 billion, which excludes net cash outflows of $0.1 billion primarily related to integration costs. |

[0000833444-19-000038:8k_2_02:55]
| • | Year-to-date, cash provided by operating activities from continuing operations was $0.7 billion and capital expenditures were $0.4 billion, resulting in a free cash flow from continuing operations of $0.3 billion. Adjusted free cash flow was $0.6 billion, which excludes net cash outflows of $0.3 billion primarily related to restructuring and integration costs. |

[0000833444-19-000038:8k_2_02:56]
| • | During the quarter, the Company repurchased approximately 105 million shares for $4.1 billion, including the completion of the share tender on June 5, 2019. Year-to-date, the Company repurchased approximately 135 million shares for $5.1 billion, representing ~14% of shares outstanding. |

[0000833444-19-000038:8k_2_02:57]
| • | During the quarter, the Company repaid $5.1 billion of short and long-term debt, including the completion of the $1.5 billion debt tender on May 30, 2019. As a result of the tender, the Company recorded a net pre-tax charge of $60 million as a loss on the early extinguishment of debt. During the quarter, the Company also repaid all outstanding financial obligations under the Tyco International Holding S.à.r.l (TSarl) term loan, revolving credit facility and TSarl other indebtedness. |

[0000833444-19-000038:8k_2_02:58]
| • | Due to favorable resolution in the quarter, the Company released an indemnification reserve of $226 million related to a post-sale tax contingency for a previously divested Tyco business. |

[0000833444-19-000038:8k_2_02:59]
Page 5 of 16

[0000833444-19-000038:8k_2_02:60]
| • | The Company recorded a $235 million non-cash asset impairment charge in the quarter related to the disposition of a non-core business now reported as held for sale. |

[0000833444-19-000038:8k_2_02:61]
| • | The Company recorded a charge in the amount of $140 million related to environmental remediation costs associated with its facilities in Marinette, Wisconsin. |

[0000833444-19-000038:8k_2_02:62]
| • | The Company recorded a discrete period tax charge of $226 million related primarily to newly enacted regulations related to U.S. Tax Reform in the quarter. |

[0000833444-19-000038:8k_2_02:63]
| • | In connection with the sale of Power Solutions, the Company recorded a pre-tax gain of $5.2 billion which is reported in discontinued operations. |

[0000833444-19-000038:8k_2_02:64]
###

[0000833444-19-000038:8k_2_02:65]
About Johnson Controls:

[0000833444-19-000038:8k_2_02:66]
Johnson Controls is a global leader creating a safe, comfortable and sustainable world. Our 105,000 employees create intelligent buildings, efficient energy solutions and integrated infrastructure that work seamlessly together to deliver on the promise of smart cities and communities in 150 countries. Our commitment to sustainability dates back to our roots in 1885, with the invention of the first electric room thermostat. We are committed to helping our customers win everywhere, every day and creating greater value for all of our stakeholders through our strategic focus on buildings. For additional information, please visit http://www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter.

[0000833444-19-000038:8k_2_02:67]
###

[0000833444-19-000038:8k_2_02:68]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-19-000038:8k_2_02:69]
Page 6 of 16

[0000833444-19-000038:8k_2_02:70]
to such transactions, the risk that disruptions from recent transactions will harm Johnson Controls’ business, the strength of the U.S. or other economies, changes to laws or policies governing foreign trade, including increased tariffs or trade restrictions, mix and schedules, energy and commodity prices, the availability of raw materials and component products, currency rates and cancellation of or changes to commercial arrangements, and with respect to the disposition of the Power Solutions business, whether the strategic benefits of the Power Solutions transaction can be achieved. A detailed discussion of risks related to Johnson Controls’ business is included in the section entitled “Risk Factors” in Johnson Controls’ Annual Report on Form 10-K for the 2018 fiscal year filed with the SEC on November 20, 2018, and its Quarterly Report on Form 10-Q for the quarterly period ended March 31, 2019 filed with the SEC on May 3, 2019, which are available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-19-000038:8k_2_02:71]
###

[0000833444-19-000038:8k_2_02:72]
Non-GAAP Financial Information

[0000833444-19-000038:8k_2_02:73]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include net mark-to-market adjustments, transaction/integration costs, restructuring and impairment costs, Scott Safety gain on sale, tax indemnification reserve release, environmental reserve, loss on extinguishment of debt, Power Solutions gain on sale (net of transaction and other costs), the impact of ceasing the depreciation/amortization expense for the Power Solutions business as the business is held for sale and discrete tax items. Financial information regarding organic sales, adjusted segment EBITA, adjusted organic segment EBITA, adjusted segment EBITA margin, adjusted free cash flow, adjusted free cash flow conversion and net debt are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as transaction/integration costs, environmental reserve and Scott Safety gain on sale because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.

[0000833444-19-000038:8k_2_02:74]
Page 7 of 16

[0000833444-19-000038:8k_2_02:75]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Three Months Ended June 30, |
|  |  | 2019 |  |  | 2018 |
| Net sales | $ | 6,451 |  |  |  | $ | 6,282 |  |
| Cost of sales | 4,307 |  |  |  | 4,194 |  |
|  | Gross profit | 2,144 |  |  |  | 2,088 |  |
| Selling, general and administrative expenses | (1,388 | ) |  |  | (1,441 | ) |
| Restructuring and impairment costs | (235 | ) |  |  | — |  |
| Net financing charges | (119 | ) |  |  | (95 | ) |
| Equity income | 62 |  |  |  | 55 |  |
| Income from continuing operations before income taxes | 464 |  |  |  | 607 |  |
| Income tax provision | 239 |  |  |  | 61 |  |
| Income from continuing operations | 225 |  |  |  | 546 |  |
| Income from discontinued operations, net of tax | 4,051 |  |  |  | 258 |  |
| Net income | 4,276 |  |  |  | 804 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 84 |  |  |  | 72 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 9 |  |
| Net income attributable to JCI | $ | 4,192 |  |  |  | $ | 723 |  |
| Income from continuing operations | $ | 141 |  |  |  | $ | 474 |  |
| Income from discontinued operations | 4,051 |  |  |  | 249 |  |
| Net income attributable to JCI | $ | 4,192 |  |  |  | $ | 723 |  |
| Diluted earnings per share from continuing operations | $ | 0.16 |  |  |  | $ | 0.51 |  |
| Diluted earnings per share from discontinued operations | 4.63 |  |  |  | 0.27 |  |
| Diluted earnings per share | $ | 4.79 |  |  |  | $ | 0.78 |  |
| Diluted weighted average shares | 875.2 |  |  |  | 930.7 |  |
| Shares outstanding at period end | 795.7 |  |  |  | 924.9 |  |

[0000833444-19-000038:8k_2_02:76]
Page 8 of 16

[0000833444-19-000038:8k_2_02:77]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Nine Months Ended June 30, |
|  |  | 2019 |  |  | 2018 |
| Net sales | $ | 17,694 |  |  |  | $ | 17,217 |  |
| Cost of sales | 11,981 |  |  |  | 11,607 |  |
|  | Gross profit | 5,713 |  |  |  | 5,610 |  |
| Selling, general and administrative expenses | (4,284 | ) |  |  | (4,250 | ) |
| Restructuring and impairment costs | (235 | ) |  |  | (154 | ) |
| Net financing charges | (302 | ) |  |  | (304 | ) |
| Equity income | 137 |  |  |  | 129 |  |
| Income from continuing operations before income taxes | 1,029 |  |  |  | 1,031 |  |
| Income tax provision | 394 |  |  |  | 314 |  |
| Income from continuing operations | 635 |  |  |  | 717 |  |
| Income from discontinued operations, net of tax | 4,598 |  |  |  | 841 |  |
| Net income | 5,233 |  |  |  | 1,558 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 147 |  |  |  | 134 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | 24 |  |  |  | 33 |  |
| Net income attributable to JCI | $ | 5,062 |  |  |  | $ | 1,391 |  |
| Income from continuing operations | $ | 488 |  |  |  | $ | 583 |  |
| Income from discontinued operations | 4,574 |  |  |  | 808 |  |
| Net income attributable to JCI | $ | 5,062 |  |  |  | $ | 1,391 |  |
| Diluted earnings per share from continuing operations | $ | 0.54 |  |  |  | $ | 0.63 |  |
| Diluted earnings per share from discontinued operations | 5.07 |  |  |  | 0.87 |  |
| Diluted earnings per share * | $ | 5.61 |  |  |  | $ | 1.49 |  |
| Diluted weighted average shares | 902.2 |  |  |  | 932.1 |  |
| Shares outstanding at period end | 795.7 |  |  |  | 924.9 |  |

[0000833444-19-000038:8k_2_02:78]
* May not sum due to rounding.

[0000833444-19-000038:8k_2_02:79]
Page 9 of 16

[0000833444-19-000038:8k_2_02:80]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | June 30,2019 |  | September 30,2018 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 3,685 |  |  | $ | 185 |  |
| Accounts receivable - net | 6,033 |  |  | 5,622 |  |
| Inventories | 2,050 |  |  | 1,819 |  |
| Assets held for sale | 95 |  |  | 3,015 |  |
| Other current assets | 1,179 |  |  | 1,182 |  |
|  | Current assets | 13,042 |  |  | 11,823 |  |
| Property, plant and equipment - net | 3,282 |  |  | 3,300 |  |
| Goodwill | 18,312 |  |  | 18,381 |  |
| Other intangible assets - net | 5,739 |  |  | 6,187 |  |
| Investments in partially-owned affiliates | 848 |  |  | 848 |  |
| Noncurrent assets held for sale | 59 |  |  | 5,188 |  |
| Other noncurrent assets | 1,787 |  |  | 3,070 |  |
|  | Total assets | $ | 43,069 |  |  | $ | 48,797 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 521 |  |  | $ | 1,307 |  |
| Accounts payable and accrued expenses | 4,452 |  |  | 4,428 |  |
| Liabilities held for sale | 46 |  |  | 1,791 |  |
| Other current liabilities | 4,223 |  |  | 3,724 |  |
|  | Current liabilities | 9,242 |  |  | 11,250 |  |
| Long-term debt | 6,804 |  |  | 9,623 |  |
| Other noncurrent liabilities | 5,614 |  |  | 5,259 |  |
| Noncurrent liabilities held for sale | — |  |  | 207 |  |
| Shareholders' equity attributable to JCI | 20,363 |  |  | 21,164 |  |
| Noncontrolling interests | 1,046 |  |  | 1,294 |  |
|  | Total liabilities and equity | $ | 43,069 |  |  | $ | 48,797 |  |

[0000833444-19-000038:8k_2_02:81]
Page 10 of 16

[0000833444-19-000038:8k_2_02:82]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended June 30, |
|  |  |  |  |  |  | 2019 |  |  | 2018 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI from continuing operations | $ | 141 |  |  |  | $ | 474 |  |
| Income from continuing operations attributable to noncontrolling interests | 84 |  |  |  | 72 |  |
| Net income from continuing operations | 225 |  |  |  | 546 |  |
| Adjustments to reconcile net income from continuing operations to |  |  |  |  |
| cash provided by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 203 |  |  |  | 227 |  |
|  |  | Pension and postretirement benefit income | (28 | ) |  |  | (36 | ) |
|  |  | Pension and postretirement contributions | (14 | ) |  |  | (17 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | 73 |  |  |  | (25 | ) |
|  |  | Deferred income taxes | (121 | ) |  |  | 1 |  |
|  |  | Non-cash restructuring and impairment costs | 235 |  |  |  | — |  |
|  |  | Other - net | 75 |  |  |  | 33 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (355 | ) |  |  | (347 | ) |
|  |  |  |  | Inventories | 32 |  |  |  | (2 | ) |
|  |  |  |  | Other assets | (33 | ) |  |  | (71 | ) |
|  |  |  |  | Restructuring reserves | (25 | ) |  |  | (49 | ) |
|  |  |  |  | Accounts payable and accrued liabilities | (19 | ) |  |  | 321 |  |
|  |  |  |  | Accrued income taxes | 360 |  |  |  | (24 | ) |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 608 |  |  |  | 557 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (123 | ) |  |  | (201 | ) |
| Acquisition of businesses, net of cash acquired | (3 | ) |  |  | (9 | ) |
| Business divestitures, net of cash divested | 6 |  |  |  | (13 | ) |
| Other - net | 16 |  |  |  | 13 |  |
|  |  |  |  |  | Cash used in investing activities from continuing operations | (104 | ) |  |  | (210 | ) |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | (5,163 | ) |  |  | 34 |  |
| Stock repurchases | (4,122 | ) |  |  | (56 | ) |
| Payment of cash dividends | (233 | ) |  |  | (241 | ) |
| Proceeds from the exercise of stock options | 60 |  |  |  | 3 |  |
| Employee equity-based compensation withholdings | (3 | ) |  |  | (2 | ) |
|  |  |  |  |  | Cash used in financing activities from continuing operations | (9,461 | ) |  |  | (262 | ) |
| Discontinued Operations |  |  |  |  |
| Net cash provided by (used in) operating activities | (385 | ) |  |  | 170 |  |
| Net cash provided by (used in) investing activities | 12,733 |  |  |  | (84 | ) |
| Net cash used by financing activities | (7 | ) |  |  | (12 | ) |
|  |  |  |  |  | Net cash flows provided by discontinued operations | 12,341 |  |  |  | 74 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 14 |  |  |  | (145 | ) |
| Changes in cash held for sale | 45 |  |  |  | 8 |  |
| Increase in cash, cash equivalents and restricted cash | $ | 3,443 |  |  |  | $ | 22 |  |

[0000833444-19-000038:8k_2_02:83]
Page 11 of 16

[0000833444-19-000038:8k_2_02:84]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Nine Months Ended June 30, |
|  |  |  |  |  |  | 2019 |  |  | 2018 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI from continuing operations | $ | 488 |  |  |  | $ | 583 |  |
| Income from continuing operations attributable to noncontrolling interests | 147 |  |  |  | 134 |  |
| Net income from continuing operations | 635 |  |  |  | 717 |  |
| Adjustments to reconcile net income from continuing operations to |  |  |  |  |
| cash provided by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 625 |  |  |  | 649 |  |
|  |  | Pension and postretirement benefit income | (85 | ) |  |  | (108 | ) |
|  |  | Pension and postretirement contributions | (51 | ) |  |  | (53 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | 6 |  |  |  | (84 | ) |
|  |  | Deferred income taxes | 382 |  |  |  | (78 | ) |
|  |  | Non-cash restructuring and impairment costs | 235 |  |  |  | 28 |  |
|  |  | Gain on Scott Safety business divestiture | — |  |  |  | (114 | ) |
|  |  | Other - net | 108 |  |  |  | 71 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (494 | ) |  |  | (454 | ) |
|  |  |  |  | Inventories | (289 | ) |  |  | (211 | ) |
|  |  |  |  | Other assets | (62 | ) |  |  | (245 | ) |
|  |  |  |  | Restructuring reserves | (84 | ) |  |  | (55 | ) |
|  |  |  |  | Accounts payable and accrued liabilities | (36 | ) |  |  | 268 |  |
|  |  |  |  | Accrued income taxes | (179 | ) |  |  | 366 |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 711 |  |  |  | 697 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (401 | ) |  |  | (481 | ) |
| Acquisition of businesses, net of cash acquired | (16 | ) |  |  | (24 | ) |
| Business divestitures, net of cash divested | 12 |  |  |  | 2,101 |  |
| Other - net | 42 |  |  |  | 5 |  |
|  |  |  |  |  | Cash provided by (used in) investing activities from continuing operations | (363 | ) |  |  | 1,601 |  |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | (3,619 | ) |  |  | (1,510 | ) |
| Debt financing costs | — |  |  |  | (4 | ) |
| Stock repurchases | (5,122 | ) |  |  | (255 | ) |
| Payment of cash dividends | (712 | ) |  |  | (714 | ) |
| Dividends paid to noncontrolling interests | (132 | ) |  |  | (43 | ) |
| Proceeds from the exercise of stock options | 111 |  |  |  | 39 |  |
| Employee equity-based compensation withholdings | (26 | ) |  |  | (38 | ) |
|  |  |  |  |  | Cash used in financing activities from continuing operations | (9,500 | ) |  |  | (2,525 | ) |
| Discontinued Operations |  |  |  |  |
| Net cash provided by operating activities | 117 |  |  |  | 567 |  |
| Net cash provided by (used in) investing activities | 12,580 |  |  |  | (312 | ) |
| Net cash (used in) financing activities | (35 | ) |  |  | (3 | ) |
|  |  |  |  |  | Net cash flows provided by discontinued operations | 12,662 |  |  |  | 252 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (24 | ) |  |  | (84 | ) |
| Changes in cash held for sale | 15 |  |  |  | 13 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | $ | 3,501 |  |  |  | $ | (46 | ) |

[0000833444-19-000038:8k_2_02:85]
Page 12 of 16

[0000833444-19-000038:8k_2_02:86]
FOOTNOTES

[0000833444-19-000038:8k_2_02:87]
1. Financial Summary

[0000833444-19-000038:8k_2_02:88]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans. In the first quarter of fiscal 2019, the Company began reporting the Power Solutions business as a discontinued operation, which required retrospective application to previously reported financial information. As a result, the financial results shown below are for continuing operations and exclude the Power Solutions business.

[0000833444-19-000038:8k_2_02:89]
|  | Three Months Ended June 30, |
| (in millions; unaudited) | 2019 |  | 2018 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,327 |  |  | $ | 2,327 |  |  | $ | 2,246 |  |  | $ | 2,246 |  |
| Building Solutions EMEA/LA | 922 |  |  | 922 |  |  | 926 |  |  | 926 |  |
| Building Solutions Asia Pacific | 691 |  |  | 691 |  |  | 681 |  |  | 681 |  |
| Global Products | 2,511 |  |  | 2,511 |  |  | 2,429 |  |  | 2,429 |  |
| Net sales | $ | 6,451 |  |  | $ | 6,451 |  |  | $ | 6,282 |  |  | $ | 6,282 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 300 |  |  | $ | 310 |  |  | $ | 314 |  |  | $ | 318 |  |
| Building Solutions EMEA/LA | 101 |  |  | 103 |  |  | 96 |  |  | 98 |  |
| Building Solutions Asia Pacific | 98 |  |  | 98 |  |  | 97 |  |  | 97 |  |
| Global Products | 333 |  |  | 481 |  |  | 435 |  |  | 441 |  |
| Segment EBITA | 832 |  |  | 992 |  |  | 942 |  |  | 954 |  |
| Corporate expenses (2) | 70 |  |  | (90 | ) |  | (142 | ) |  | (103 | ) |
| Amortization of intangible assets | (93 | ) |  | (93 | ) |  | (98 | ) |  | (98 | ) |
| Net mark-to-market adjustments (3) | 9 |  |  | — |  |  | — |  |  | — |  |
| Restructuring and impairment costs (4) | (235 | ) |  | — |  |  | — |  |  | — |  |
| EBIT (5) | 583 |  |  | 809 |  |  | 702 |  |  | 753 |  |
| EBIT margin | 9.0 | % |  | 12.5 | % |  | 11.2 | % |  | 12.0 | % |
| Net financing charges (6) | (119 | ) |  | (59 | ) |  | (95 | ) |  | (95 | ) |
| Income from continuing operations before income taxes | 464 |  |  | 750 |  |  | 607 |  |  | 658 |  |
| Income tax provision (7) | (239 | ) |  | (101 | ) |  | (61 | ) |  | (80 | ) |
| Income from continuing operations | 225 |  |  | 649 |  |  | 546 |  |  | 578 |  |
| Income from continuing operations attributable to noncontrolling interests | (84 | ) |  | (84 | ) |  | (72 | ) |  | (72 | ) |
| Net income from continuing operations attributable to JCI | $ | 141 |  |  | $ | 565 |  |  | $ | 474 |  |  | $ | 506 |  |

[0000833444-19-000038:8k_2_02:90]
|  | Nine Months Ended June 30, |
| (in millions; unaudited) | 2019 |  | 2018 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 6,630 |  |  | $ | 6,630 |  |  | $ | 6,355 |  |  | $ | 6,355 |  |
| Building Solutions EMEA/LA | 2,707 |  |  | 2,707 |  |  | 2,748 |  |  | 2,748 |  |
| Building Solutions Asia Pacific | 1,932 |  |  | 1,932 |  |  | 1,864 |  |  | 1,864 |  |
| Global Products | 6,425 |  |  | 6,425 |  |  | 6,250 |  |  | 6,250 |  |
| Net sales | $ | 17,694 |  |  | $ | 17,694 |  |  | $ | 17,217 |  |  | $ | 17,217 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 807 |  |  | $ | 822 |  |  | $ | 780 |  |  | $ | 798 |  |
| Building Solutions EMEA/LA | 258 |  |  | 261 |  |  | 242 |  |  | 247 |  |
| Building Solutions Asia Pacific | 240 |  |  | 240 |  |  | 242 |  |  | 242 |  |
| Global Products | 774 |  |  | 930 |  |  | 949 |  |  | 856 |  |
| Segment EBITA | 2,079 |  |  | 2,253 |  |  | 2,213 |  |  | 2,143 |  |
| Corporate expenses (2) | (233 | ) |  | (287 | ) |  | (442 | ) |  | (321 | ) |
| Amortization of intangible assets | (288 | ) |  | (288 | ) |  | (282 | ) |  | (282 | ) |
| Net mark-to-market adjustments (3) | 8 |  |  | — |  |  | — |  |  | — |  |
| Restructuring and impairment costs (4) | (235 | ) |  | — |  |  | (154 | ) |  | — |  |
| EBIT (5) | 1,331 |  |  | 1,678 |  |  | 1,335 |  |  | 1,540 |  |
| EBIT margin | 7.5 | % |  | 9.5 | % |  | 7.8 | % |  | 8.9 | % |
| Net financing charges (6) | (302 | ) |  | (242 | ) |  | (304 | ) |  | (304 | ) |
| Income from continuing operations before income taxes | 1,029 |  |  | 1,436 |  |  | 1,031 |  |  | 1,236 |  |
| Income tax provision (7) | (394 | ) |  | (194 | ) |  | (314 | ) |  | (150 | ) |
| Income from continuing operations | 635 |  |  | 1,242 |  |  | 717 |  |  | 1,086 |  |
| Income from continuing operations attributable to noncontrolling interests | (147 | ) |  | (147 | ) |  | (134 | ) |  | (134 | ) |
| Net income from continuing operations attributable to JCI | $ | 488 |  |  | $ | 1,095 |  |  | $ | 583 |  |  | $ | 952 |  |

[0000833444-19-000038:8k_2_02:91]
(1) The Company's press release contains financial information regarding adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-19-000038:8k_2_02:92]
The following is the three months ended June 30, 2019 and 2018 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-19-000038:8k_2_02:93]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment EBITA as reported | $ | 300 |  |  | $ | 314 |  |  | $ | 101 |  |  | $ | 96 |  |  | $ | 98 |  |  | $ | 97 |  |  | $ | 333 |  |  | $ | 435 |  |  | $ | 832 |  |  | $ | 942 |  |
| Segment EBITA margin as reported | 12.9 | % |  | 14.0 | % |  | 11.0 | % |  | 10.4 | % |  | 14.2 | % |  | 14.2 | % |  | 13.3 | % |  | 17.9 | % |  | 12.9 | % |  | 15.0 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | 10 |  |  | 4 |  |  | 2 |  |  | 2 |  |  | — |  |  | — |  |  | 8 |  |  | 6 |  |  | 20 |  |  | 12 |  |
| Environmental reserve (8) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 140 |  |  | — |  |  | 140 |  |  | — |  |
| Adjusted segment EBITA | $ | 310 |  |  | $ | 318 |  |  | $ | 103 |  |  | $ | 98 |  |  | $ | 98 |  |  | $ | 97 |  |  | $ | 481 |  |  | $ | 441 |  |  | $ | 992 |  |  | $ | 954 |  |
| Adjusted segment EBITA margin | 13.3 | % |  | 14.2 | % |  | 11.2 | % |  | 10.6 | % |  | 14.2 | % |  | 14.2 | % |  | 19.2 | % |  | 18.2 | % |  | 15.4 | % |  | 15.2 | % |

[0000833444-19-000038:8k_2_02:94]
The following is the nine months ended June 30, 2019 and 2018 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-19-000038:8k_2_02:95]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment EBITA as reported | $ | 807 |  |  | $ | 780 |  |  | $ | 258 |  |  | $ | 242 |  |  | $ | 240 |  |  | $ | 242 |  |  | $ | 774 |  |  | $ | 949 |  |  | $ | 2,079 |  |  | $ | 2,213 |  |
| Segment EBITA margin as reported | 12.2 | % |  | 12.3 | % |  | 9.5 | % |  | 8.8 | % |  | 12.4 | % |  | 13.0 | % |  | 12.0 | % |  | 15.2 | % |  | 11.7 | % |  | 12.9 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | 15 |  |  | 18 |  |  | 3 |  |  | 5 |  |  | — |  |  | — |  |  | 16 |  |  | 21 |  |  | 34 |  |  | 44 |  |
| Scott Safety gain on sale | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (114 | ) |  | — |  |  | (114 | ) |
| Environmental reserve (8) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 140 |  |  | — |  |  | 140 |  |  | — |  |
| Adjusted segment EBITA | $ | 822 |  |  | $ | 798 |  |  | $ | 261 |  |  | $ | 247 |  |  | $ | 240 |  |  | $ | 242 |  |  | $ | 930 |  |  | $ | 856 |  |  | $ | 2,253 |  |  | $ | 2,143 |  |
| Adjusted segment EBITA margin | 12.4 | % |  | 12.6 | % |  | 9.6 | % |  | 9.0 | % |  | 12.4 | % |  | 13.0 | % |  | 14.5 | % |  | 13.7 | % |  | 12.7 | % |  | 12.4 | % |

[0000833444-19-000038:8k_2_02:96]
Page 13 of 16

[0000833444-19-000038:8k_2_02:97]
(2) Adjusted Corporate expenses for the three months ended June 30, 2019 excludes $226 million of income as a result of a tax indemnification reserve release, partially offset by $63 million of integration costs and $3 million of transaction costs. Adjusted Corporate expenses for the nine months ended June 30, 2019 excludes $226 million of income as a result of a tax indemnification reserve release, $165 million of integration costs and $7 million of transaction costs. Adjusted Corporate expenses for the three months ended June 30, 2018 excludes $37 million of integration costs and $2 million of transaction costs.  Adjusted Corporate expenses for the nine months ended June 30, 2018 excludes $111 million of integration costs and $10 million of transaction costs.

[0000833444-19-000038:8k_2_02:98]
(3) On October 1, 2018, the Company adopted Accounting Standards Update (ASU) No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." ASU No. 2016-01 amends certain aspects of recognition, measurement, presentation and disclosure of financial instruments, including marketable securities. The new standard requires the mark-to-market of marketable securities investments previously recorded within accumulated other comprehensive income on the statement of financial position be recorded in the statement of income on a prospective basis beginning as of the adoption date. The three months ended June 30, 2019 exclude the net mark-to-market adjustments on restricted investments of $9 million. The nine months ended June 30, 2019 exclude the net mark-to-market adjustments on restricted investments of $8 million. As these restricted investments do not relate to the underlying operating performance of its businesses, the Company’s definition of adjusted segment EBITA and adjusted EBIT excludes the mark-to-market adjustments effective October 1, 2018.

[0000833444-19-000038:8k_2_02:99]
(4) Restructuring and impairment costs for the three and nine months ended June 30, 2019 of $235 million are excluded from the adjusted non-GAAP results. Restructuring and impairment costs for the nine months ended June 30, 2018 of $154 million are excluded from the adjusted non-GAAP results. The restructuring actions and impairment costs for the three and nine months ended June 30, 2019 result from the impairment of a Global Products business classified as held for sale.  The restructuring and impairment costs for the nine months ended June 30, 2018 are related primarily to related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions business and at Corporate.

[0000833444-19-000038:8k_2_02:100]
(5) Management defines earnings before interest and taxes (EBIT) as income from continuing operations before net financing charges, income taxes and noncontrolling interests.

[0000833444-19-000038:8k_2_02:101]
(6) Adjusted net financing charges for the three and nine months ended June 30, 2019 exclude a loss on debt extinguishment of $60 million.

[0000833444-19-000038:8k_2_02:102]
(7) Adjusted income tax provision for the three months ended June 30, 2019 excludes tax provisions primarily related to new U.S. tax regulations of $226 million and net mark-to-market adjustments of $2 million, partially offset by the tax benefits related to restructuring and impairment charges of $53 million, an environmental reserve of $28 million and integration costs of $9 million.  Adjusted income tax provision for the nine months ended June 30, 2019 excludes tax provisions primarily related to new U.S. tax regulations of $226 million, valuation allowance adjustments of $76 million as a result of changes in U.S. tax law and net mark-to-market adjustments of $2 million, partially offset by the tax benefits related to restructuring and impairment charges of $53 million, an environmental reserve of $28 million, integration costs of $22 million and transaction costs of $1 million.  Adjusted income tax provision for the three months ended June 30, 2018 excludes the tax benefits of the impact of the third quarter fiscal 2018 effective tax rate change of $13 million and integration costs of $6 million.  Adjusted income tax provision for the nine months ended June 30, 2018 excludes the net tax provision related to the U.S. Tax Reform legislation of $204 million and the Scott Safety gain on sale of $30 million, partially offset by the tax benefits for tax audit settlements of $25 million, restructuring and impairment costs of $23 million, integration costs of $21 million and transaction costs of $1 million.

[0000833444-19-000038:8k_2_02:103]
(8) An environmental charge for the three and nine months ended June 30, 2019 of $140 million is excluded from the adjusted non-GAAP results.  The $140 million is related to remediation efforts to be undertaken to address contamination at our facilities in Marinette, Wisconsin.  A substantial portion of the reserve relates to the remediation of fire-fighting foams containing PFAS compounds at or near our Fire Technology Center in Marinette.

[0000833444-19-000038:8k_2_02:104]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-19-000038:8k_2_02:105]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include transaction/integration costs, gain on sale of the Scott Safety business, net mark-to-market adjustments, restructuring and impairment costs, tax indemnification reserve release, environmental reserve, loss on extinguishment of debt, gain on sale of Power Solutions business, net of transaction and other costs, impact of ceasing the depreciation / amortization expense for the Power Solutions business as the business is held for sale and discrete tax items. The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-19-000038:8k_2_02:106]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-19-000038:8k_2_02:107]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Three Months Ended |  | Three Months Ended |
|  | June 30, |  | June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Earnings per share as reported for JCI plc | $ | 4.79 |  |  | $ | 0.78 |  |  | $ | 0.16 |  |  | $ | 0.51 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | — |  |  | — |  |  | — |  |
| Integration costs | 0.09 |  |  | 0.05 |  |  | 0.09 |  |  | 0.05 |  |
| Related tax impact | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |
| Scott Safety gain on sale | — |  |  | — |  |  | — |  |  | — |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |
| Net mark-to-market adjustments | (0.01 | ) |  | — |  |  | (0.01 | ) |  | — |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |
| Restructuring and impairment costs | 0.27 |  |  | — |  |  | 0.27 |  |  | — |  |
| Related tax impact | (0.06 | ) |  | — |  |  | (0.06 | ) |  | — |  |
| Tax indemnification reserve release | (0.26 | ) |  | — |  |  | (0.26 | ) |  | — |  |
| Environmental reserve | 0.16 |  |  | — |  |  | 0.16 |  |  | — |  |
| Related tax impact | (0.03 | ) |  | — |  |  | (0.03 | ) |  | — |  |
| Loss on extinguishment of debt | 0.07 |  |  | — |  |  | 0.07 |  |  | — |  |
| Power Solutions gain on sale, net of |  |  |  |  |  |  |  |
| transaction and other costs | (6.00 | ) |  | — |  |  | — |  |  | — |  |
| Related tax impact | 1.43 |  |  | — |  |  | — |  |  | — |  |
| Cease of Power Solutions |  |  |  |  |  |  |  |
| depreciation / amortization expense | (0.02 | ) |  | — |  |  | — |  |  | — |  |
| Related tax impact | 0.01 |  |  | — |  |  | — |  |  | — |  |
| Discrete tax items | 0.26 |  |  | (0.01 | ) |  | 0.26 |  |  | (0.01 | ) |
| Adjusted earnings per share for JCI plc * | $ | 0.69 |  |  | $ | 0.81 |  |  | $ | 0.65 |  |  | $ | 0.54 |  |

[0000833444-19-000038:8k_2_02:108]
* May not sum due to rounding.

[0000833444-19-000038:8k_2_02:109]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Nine Months Ended |  | Nine Months Ended |
|  | June 30, |  | June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Earnings per share as reported for JCI plc | $ | 5.61 |  |  | $ | 1.49 |  |  | $ | 0.54 |  |  | $ | 0.63 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | 0.01 |  |  | 0.01 |  |  | 0.01 |  |  | 0.01 |  |
| Integration costs | 0.22 |  |  | 0.17 |  |  | 0.22 |  |  | 0.17 |  |
| Related tax impact | (0.02 | ) |  | (0.02 | ) |  | (0.02 | ) |  | (0.02 | ) |
| Scott Safety gain on sale | — |  |  | (0.12 | ) |  | — |  |  | (0.12 | ) |
| Related tax impact | — |  |  | 0.03 |  |  | — |  |  | 0.03 |  |
| Net mark-to-market adjustments | (0.01 | ) |  | — |  |  | (0.01 | ) |  | — |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |
| Restructuring and impairment costs | 0.26 |  |  | 0.17 |  |  | 0.26 |  |  | 0.17 |  |
| Related tax impact | (0.06 | ) |  | (0.03 | ) |  | (0.06 | ) |  | (0.02 | ) |
| Tax indemnification reserve | (0.25 | ) |  | — |  |  | (0.25 | ) |  | — |  |
| Environmental reserve | 0.16 |  |  | — |  |  | 0.16 |  |  | — |  |
| Related tax impact | (0.03 | ) |  | — |  |  | (0.03 | ) |  | — |  |
| Loss on extinguishment of debt | 0.07 |  |  | — |  |  | 0.07 |  |  | — |  |
| Power Solutions gain on sale, net of |  |  |  |  |  |  |  |
| transaction and other costs | (5.77 | ) |  | — |  |  | — |  |  | — |  |
| Related tax impact | 1.39 |  |  | — |  |  | — |  |  | — |  |
| Cease of Power Solutions |  |  |  |  |  |  |  |
| depreciation / amortization expense | (0.13 | ) |  | — |  |  | — |  |  | — |  |
| Related tax impact | 0.03 |  |  | — |  |  | — |  |  | — |  |
| Discrete tax items | 0.42 |  |  | 0.19 |  |  | 0.33 |  |  | 0.19 |  |
| Adjusted earnings per share for JCI plc * | $ | 1.89 |  |  | $ | 1.89 |  |  | $ | 1.21 |  |  | $ | 1.02 |  |

[0000833444-19-000038:8k_2_02:110]
* May not sum due to rounding.

[0000833444-19-000038:8k_2_02:111]
Page 14 of 16

[0000833444-19-000038:8k_2_02:112]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-19-000038:8k_2_02:113]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, |  | June 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 870.9 |  |  | 925.6 |  |  | 898.4 |  |  | 926.0 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |
| and unvested performance share awards | 4.3 |  |  | 5.1 |  |  | 3.8 |  |  | 6.1 |  |
| Diluted weighted average shares outstanding | 875.2 |  |  | 930.7 |  |  | 902.2 |  |  | 932.1 |  |

[0000833444-19-000038:8k_2_02:114]
The Company has presented forward-looking statements regarding adjusted EPS from continuing operations, organic net sales growth, organic adjusted EBITA growth, organic adjusted EBIT growth, adjusted segment EBITA margin, adjusted EBIT margin and adjusted free cash flow conversion for the full fiscal year of 2019, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, income or cash flows from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments and the effect of foreign currency exchange fluctuations. Our fiscal 2019 outlook for organic net sales and adjusted EBITA and EBIT growth also excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s full year 2019 GAAP financial results.

[0000833444-19-000038:8k_2_02:115]
3. Organic Growth Reconciliation

[0000833444-19-000038:8k_2_02:116]
The components of the changes in net sales for the three months ended June 30, 2019 versus the three months ended June 30, 2018, including organic growth, is shown below (unaudited):

[0000833444-19-000038:8k_2_02:117]
| (in millions) | Net Sales for the Three Months Ended June 30, 2018 |  | Base Year Adjustments -Acquisitions and Divestitures |  | Adjusted Base Net Sales for the Three Months Ended June 30, 2018 |  | Foreign Currency |  | Organic Growth |  | Net Sales for the Three Months EndedJune 30, 2019 |
| Building Solutions North America | $ | 2,246 |  |  | $ | — |  |  | — |  |  | $ | 2,246 |  |  | $ | (7 | ) |  | — |  |  | $ | 88 |  |  | 4 | % |  | $ | 2,327 |  |  | 4 | % |
| Building Solutions EMEA/LA | 926 |  |  | (1 | ) |  | — |  |  | 925 |  |  | (54 | ) |  | -6 | % |  | 51 |  |  | 6 | % |  | 922 |  |  | 0 | % |
| Building Solutions Asia Pacific | 681 |  |  | 1 |  |  | — |  |  | 682 |  |  | (31 | ) |  | -5 | % |  | 40 |  |  | 6 | % |  | 691 |  |  | 1 | % |
| Total field | 3,853 |  |  | — |  |  | — |  |  | 3,853 |  |  | (92 | ) |  | -2 | % |  | 179 |  |  | 5 | % |  | 3,940 |  |  | 2 | % |
| Global Products | 2,429 |  |  | (39 | ) |  | -2 | % |  | 2,390 |  |  | (49 | ) |  | -2 | % |  | 170 |  |  | 7 | % |  | 2,511 |  |  | 5 | % |
| Total net sales | $ | 6,282 |  |  | $ | (39 | ) |  | -1 | % |  | $ | 6,243 |  |  | $ | (141 | ) |  | -2 | % |  | $ | 349 |  |  | 6 | % |  | $ | 6,451 |  |  | 3 | % |

[0000833444-19-000038:8k_2_02:118]
The components of the changes in net sales for the nine months ended June 30, 2019 versus the nine months ended June 30, 2018, including organic growth, is shown below (unaudited):

[0000833444-19-000038:8k_2_02:119]
| (in millions) | Net Sales for the Nine Months Ended June 30, 2018 |  | Base Year Adjustments -Acquisitions and Divestitures |  | Adjusted Base Net Sales for the Nine Months Ended June 30, 2018 |  | Foreign Currency |  | Organic Growth |  | Net Sales for the Nine Months EndedJune 30, 2019 |
| Building Solutions North America | $ | 6,355 |  |  | $ | — |  |  | — |  |  | $ | 6,355 |  |  | $ | (25 | ) |  | — |  |  | $ | 300 |  |  | 5 | % |  | $ | 6,630 |  |  | 4 | % |
| Building Solutions EMEA/LA | 2,748 |  |  | 1 |  |  | — |  |  | 2,749 |  |  | (166 | ) |  | -6 | % |  | 124 |  |  | 5 | % |  | 2,707 |  |  | -2 | % |
| Building Solutions Asia Pacific | 1,864 |  |  | 1 |  |  | — |  |  | 1,865 |  |  | (75 | ) |  | -4 | % |  | 142 |  |  | 8 | % |  | 1,932 |  |  | 4 | % |
| Total field | 10,967 |  |  | 2 |  |  | — |  |  | 10,969 |  |  | (266 | ) |  | -2 | % |  | 566 |  |  | 5 | % |  | 11,269 |  |  | 3 | % |
| Global Products | 6,250 |  |  | (126 | ) |  | -2 | % |  | 6,124 |  |  | (140 | ) |  | -2 | % |  | 441 |  |  | 7 | % |  | 6,425 |  |  | 5 | % |
| Total net sales | $ | 17,217 |  |  | $ | (124 | ) |  | -1 | % |  | $ | 17,093 |  |  | $ | (406 | ) |  | -2 | % |  | $ | 1,007 |  |  | 6 | % |  | $ | 17,694 |  |  | 4 | % |

[0000833444-19-000038:8k_2_02:120]
The components of the changes in segment EBITA and EBIT for the three months ended June 30, 2019 versus the three months ended June 30, 2018, including organic growth, is shown below (unaudited):

[0000833444-19-000038:8k_2_02:121]
| (in millions) | Adjusted Segment EBITA / EBIT for the Three Months Ended June 30, 2018 |  | Base Year Adjustments -Acquisitions and Divestitures |  | Adjusted Base Segment EBITA / EBIT for the Three Months Ended June 30, 2018 |  | Foreign Currency |  | Organic Growth |  | Adjusted SegmentEBITA / EBIT forthe ThreeMonths EndedJune 30, 2019 |
| Building Solutions North America | $ | 318 |  |  | $ | — |  |  | — |  |  | $ | 318 |  |  | $ | — |  |  | — |  |  | $ | (8 | ) |  | -3 | % |  | $ | 310 |  |  | -3 | % |
| Building Solutions EMEA/LA | 98 |  |  | — |  |  | — |  |  | 98 |  |  | (9 | ) |  | -9 | % |  | 14 |  |  | 14 | % |  | 103 |  |  | 5 | % |
| Building Solutions Asia Pacific | 97 |  |  | — |  |  | — |  |  | 97 |  |  | (3 | ) |  | -3 | % |  | 4 |  |  | 4 | % |  | 98 |  |  | 1 | % |
| Total field | 513 |  |  | — |  |  | — |  |  | 513 |  |  | (12 | ) |  | -2 | % |  | 10 |  |  | 2 | % |  | 511 |  |  | 0 | % |
| Global Products | 441 |  |  | (4 | ) |  | -1 | % |  | 437 |  |  | (9 | ) |  | -2 | % |  | 53 |  |  | 12 | % |  | 481 |  |  | 10 | % |
| Total adjusted segment EBITA | 954 |  |  | (4 | ) |  | — |  |  | 950 |  |  | $ | (21 | ) |  | -2 | % |  | $ | 63 |  |  | 7 | % |  | 992 |  |  | 4 | % |
| Corporate expenses | (103 | ) |  | — |  |  |  |  | (103 | ) |  |  |  |  |  |  |  |  |  | (90 | ) |  | 13 | % |
| Amortization of intangible assets | (98 | ) |  | — |  |  |  |  | (98 | ) |  |  |  |  |  |  |  |  |  | (93 | ) |  | 5 | % |
| Total adjusted EBIT | $ | 753 |  |  | $ | (4 | ) |  |  |  | $ | 749 |  |  |  |  |  |  |  |  |  |  | $ | 809 |  |  | 8 | % |

[0000833444-19-000038:8k_2_02:122]
Page 15 of 16

[0000833444-19-000038:8k_2_02:123]
The components of the changes in segment EBITA and EBIT for the nine months ended June 30, 2019 versus the nine months ended June 30, 2018, including organic growth, is shown below (unaudited):

[0000833444-19-000038:8k_2_02:124]
| (in millions) | Adjusted Segment EBITA / EBIT for the Nine Months Ended June 30, 2018 |  | Base Year Adjustments -Acquisitions and Divestitures |  | Adjusted Base Segment EBITA / EBIT for the Nine Months Ended June 30, 2018 |  | Foreign Currency |  | Organic Growth |  | Adjusted SegmentEBITA / EBIT forthe Nine Months EndedJune 30, 2019 |
| Building Solutions North America | $ | 798 |  |  | $ | — |  |  | — |  |  | $ | 798 |  |  | $ | (2 | ) |  | — |  |  | $ | 26 |  |  | 3 | % |  | $ | 822 |  |  | 3 | % |
| Building Solutions EMEA/LA | 247 |  |  | 1 |  |  | — |  |  | 248 |  |  | (26 | ) |  | -10 | % |  | 39 |  |  | 16 | % |  | 261 |  |  | 5 | % |
| Building Solutions Asia Pacific | 242 |  |  | — |  |  | — |  |  | 242 |  |  | (7 | ) |  | -3 | % |  | 5 |  |  | 2 | % |  | 240 |  |  | -1 | % |
| Total field | 1,287 |  |  | 1 |  |  | — |  |  | 1,288 |  |  | (35 | ) |  | -3 | % |  | 70 |  |  | 5 | % |  | 1,323 |  |  | 3 | % |
| Global Products | 856 |  |  | (16 | ) |  | -2 | % |  | 840 |  |  | (19 | ) |  | -2 | % |  | 109 |  |  | 13 | % |  | 930 |  |  | 11 | % |
| Total adjusted segment EBITA | 2,143 |  |  | (15 | ) |  | -1 | % |  | 2,128 |  |  | $ | (54 | ) |  | -3 | % |  | $ | 179 |  |  | 8 | % |  | 2,253 |  |  | 6 | % |
| Corporate expenses | (321 | ) |  | — |  |  |  |  | (321 | ) |  |  |  |  |  |  |  |  |  | (287 | ) |  | 11 | % |
| Amortization of intangible assets | (282 | ) |  | 2 |  |  |  |  | (280 | ) |  |  |  |  |  |  |  |  |  | (288 | ) |  | -3 | % |
| Total adjusted EBIT | $ | 1,540 |  |  | $ | (13 | ) |  |  |  | $ | 1,527 |  |  |  |  |  |  |  |  |  |  | $ | 1,678 |  |  | 10 | % |

[0000833444-19-000038:8k_2_02:125]
4.  Adjusted Free Cash Flow Reconciliation

[0000833444-19-000038:8k_2_02:126]
The Company's press release contains financial information regarding free cash flow, adjusted free cash flow and adjusted free cash flow conversion, which are non-GAAP performance measures. Free cash flow is defined as cash provided by operating activities less capital expenditures. Adjusted free cash flow excludes special items, as included in the table below, because these cash flows are not considered to be directly related to its underlying businesses. Adjusted free cash flow conversion is defined as adjusted free cash flow divided by adjusted net income. Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash.

[0000833444-19-000038:8k_2_02:127]
The following is the three months and nine months ended June 30, 2019 and 2018 reconciliation of free cash flow, adjusted free cash flow and adjusted free cash flow conversion for continuing operations (unaudited):

[0000833444-19-000038:8k_2_02:128]
| (in billions) | Three Months Ended June 30, 2019 |  | Three Months Ended June 30, 2018 |  | Nine Months Ended June 30, 2019 |  | Nine Months Ended June 30, 2018 |
| Cash provided by operating activities from continuing operations | $ | 0.6 |  |  | $ | 0.6 |  |  | $ | 0.7 |  |  | $ | 0.7 |  |
| Capital expenditures | (0.1 | ) |  | (0.2 | ) |  | (0.4 | ) |  | (0.5 | ) |
| Reported free cash flow | 0.5 |  |  | 0.4 |  |  | 0.3 |  |  | 0.2 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction/integration costs | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Restructuring payments | — |  |  | — |  |  | 0.1 |  |  | 0.2 |  |
| Nonrecurring tax payments, net of refunds | — |  |  | — |  |  | — |  |  | (0.1 | ) |
| Total adjusting items | 0.1 |  |  | 0.1 |  |  | 0.3 |  |  | 0.3 |  |
| Adjusted free cash flow | $ | 0.6 |  |  | $ | 0.5 |  |  | $ | 0.6 |  |  | $ | 0.5 |  |
| Adjusted net income from continuing operations |  |  |  |  |  |  |  |
| attributable to JCI | $ | 0.6 |  |  | $ | 0.5 |  |  | $ | 1.1 |  |  | $ | 1.0 |  |
| Adjusted free cash flow conversion | 100 | % |  | 100 | % |  | 55 | % |  | 50 | % |

[0000833444-19-000038:8k_2_02:129]
5.  Net Debt to Capitalization

[0000833444-19-000038:8k_2_02:130]
The Company provides financial information regarding net debt as a percentage of total capitalization, which is a non-GAAP performance measure. The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. The following is the June 30, 2019 and September 30, 2018 calculation of net debt as a percentage of total capitalization (unaudited):

[0000833444-19-000038:8k_2_02:131]
| (in millions) | June 30, 2019 |  | September 30, 2018 |
| Short-term debt and current portion of long-term debt | $ | 521 |  |  | $ | 1,307 |  |
| Long-term debt | 6,804 |  |  | 9,623 |  |
| Total debt | 7,325 |  |  | 10,930 |  |
| Less: cash and cash equivalents | 3,685 |  |  | 185 |  |
| Total net debt | 3,640 |  |  | 10,745 |  |
| Shareholders' equity attributable to JCI | 20,363 |  |  | 21,164 |  |
| Total capitalization | $ | 24,003 |  |  | $ | 31,909 |  |
| Total net debt as a % of total capitalization | 15.2 | % |  | 33.7 | % |

[0000833444-19-000038:8k_2_02:132]
6.  Divestitures

[0000833444-19-000038:8k_2_02:133]
On November 13, 2018, the Company entered into a definitive agreement to sell its Power Solutions business to BCP Acquisitions LLC for approximately $13.2 billion. BCP Acquisitions LLC is a newly-formed entity controlled by investment funds managed by Brookfield Capital Partners LLC. The transaction closed on April 30, 2019 with net cash proceeds of $11.6 billion after tax and transaction-related expenses, and the Company recorded a gain, net of transaction and other costs, of $5.2 billion ($4.0 billion after tax).

[0000833444-19-000038:8k_2_02:134]
On March 16, 2017, the Company announced that it signed a definitive agreement to sell its Scott Safety business to 3M for approximately $2.0 billion.  The transaction closed on October 4, 2017. Net cash proceeds from the transaction approximated $1.9 billion and the Company recorded a net gain of $114 million ($84 million after tax). Scott Safety is a leader in the design, manufacture and sale of high performance respiratory protection, gas and flame detection, thermal imaging and other critical products for fire services, law enforcement, industrial, oil and gas, chemical, armed forces, and homeland defense end markets.

[0000833444-19-000038:8k_2_02:135]
7.  Income Taxes

[0000833444-19-000038:8k_2_02:136]
The Company's effective tax rate from continuing operations before consideration of transaction/integration costs, gain on sale of the Scott Safety business, net mark-to-market adjustments, environmental reserve, tax indemnification reserve release, restructuring and impairment costs, loss on extinguishment of debt, and discrete tax items for the three and nine months ending June 30, 2019 is 13.5%, and for the three and nine months ending June 30, 2018 is approximately 12.2% and 12.1%, respectively.

[0000833444-19-000038:8k_2_02:137]
8.  Restructuring and Impairment Costs

[0000833444-19-000038:8k_2_02:138]
The three and nine months ended June 30,2019 include restructuring and impairment costs of $235 million related to the impairment of a Global Products business classified as held for sale. The nine months ended June 30, 2018 include restructuring and impairment costs of $154 million related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions business and at Corporate.

[0000833444-19-000038:8k_2_02:139]
Page 16 of 16
