# JCI note change history — 0000833444-19-000022 → 0000833444-19-000041


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-08-01):
[0000833444-19-000041:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of June 30, 2019, reserves for environmental liabilities for continuing operations totaled $163 million, of which $52 million was recorded within other current liabilities and $111 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $37 million at September 30, 2018, of which $10 million was recorded within other current liabilities and $27 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

- added (2019-08-01):
[0000833444-19-000041:note_history:2]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin.  In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working closely with WDNR to address these issues insofar as they related to this migration.

- added (2019-08-01):
[0000833444-19-000041:note_history:3]
The increase in reserves as of June 30, 2019 includes $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).  The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.

- added (2019-08-01):
[0000833444-19-000041:note_history:4]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure

- added (2019-08-01):
[0000833444-19-000041:note_history:5]
that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

- added (2019-08-01):
[0000833444-19-000041:note_history:6]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990.  Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River.  In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts.

- added (2019-08-01):
[0000833444-19-000041:note_history:7]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At June 30, 2019 and September 30, 2018, the Company recorded conditional asset retirement obligations for continuing operations of $30 million and $29 million, respectively.

- changed (2019-08-01):
[0000833444-19-000041:note_history:8]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.
  (was, 2019-05-03, similarity 0.7372):
[0000833444-19-000022:note_history:8]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability

- changed (2019-08-01):
[0000833444-19-000041:note_history:9]
As of June 30, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $167 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $538 million, of which $55 million was recorded in other current liabilities and $483 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $371 million, of which $49 million was recorded in other current assets, and $322 million was recorded in other noncurrent assets. Assets included $16 million of cash and $272 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at June 30, 2019 was $83 million. As of September 30, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $173 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $550 million, of which $55 million was recorded in other current liabilities and $495 million was recorded in other noncurrent liabilities. The
  (was, 2019-05-03, similarity 0.8315):
[0000833444-19-000022:note_history:9]
As of March 31, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $175 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $541 million, of which $55 million was recorded in other current liabilities and $486 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $366 million, of which $51 million was recorded in other current assets, and $315 million was recorded in other noncurrent assets. Assets included $19 million of cash and $263 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at March 31, 2019 was $84 million. As of September 30, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $173 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $550 million, of which $55 million was recorded in other current liabilities and $495 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $33 million was recorded in other current assets, and $344 million was recorded in other noncurrent assets. Assets included $6 million of cash and $281 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2018 was $90 million.

- added (2019-08-01):
[0000833444-19-000041:note_history:10]
Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $33 million was recorded in other current assets, and $344 million was recorded in other noncurrent assets. Assets included $6 million of cash and $281 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2018 was $90 million.

- changed (2019-08-01):
[0000833444-19-000041:note_history:11]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At June 30, 2019 and September 30, 2018, the insurable liabilities totaled $451 million and $417 million, respectively, of which $118 million and $95 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $311 million and $300 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at June 30, 2019 and September 30, 2018 were $26 million, of which $6 million was recorded within other current assets and $20 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.
  (was, 2019-05-03, similarity 0.9925):
[0000833444-19-000022:note_history:11]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At March 31, 2019 and September 30, 2018, the insurable liabilities totaled $423 million and $417 million, respectively, of which $95 million and $95 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $306 million and $300 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at March 31, 2019 and September 30, 2018 were $26 million, of which $6 million was recorded within other current assets and $20 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

- added (2019-08-01):
[0000833444-19-000041:note_history:12]
Two of our subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the

- added (2019-08-01):
[0000833444-19-000041:note_history:13]
firefighting foam products manufactured by defendants contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued regulatory limits, however; while those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

- changed (2019-08-01):
[0000833444-19-000041:note_history:14]
Chemguard and Tyco Fire Products are named in 23 putative class actions in federal and state courts in Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington New Hampshire, and Michigan. Each of these cases has been transferred to the MDL. The following putative class actions were filed in fiscal year 2019:
  (was, 2019-05-03, similarity 0.9477):
[0000833444-19-000022:note_history:14]
Chemguard and Tyco Fire Products are named in 21 putative class actions in federal and state courts in Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania and Washington. Each of these cases has been transferred to the MDL. The following putative class actions were filed in fiscal year 2019:

- added (2019-08-01):
[0000833444-19-000041:note_history:15]
| • | Smith et al. v. The 3M Company et al., filed May 24, 2019 in the United States District Court, District of New Hampshire. |

- added (2019-08-01):
[0000833444-19-000041:note_history:16]
| • | Cadrette et al. v. The 3M Company et al., filed May 24, 2019 in the United States District Court, Eastern District of Michigan. |

- changed (2019-08-01):
[0000833444-19-000041:note_history:17]
There are approximately 60 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases), Pennsylvania (11 cases), New Mexico (2 cases) and South Carolina (2 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania and two plaintiffs in New Mexico.  These matters have been transferred to or directly-filed in the MDL.  The Company is also on notice of approximately 660 other possible individual product liability claims and three possible municipal claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, but the Company anticipates that they soon will be.
  (was, 2019-05-03, similarity 0.9702):
[0000833444-19-000022:note_history:17]
There are approximately 58 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases), Pennsylvania (11 cases) and New Mexico (2 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania and two plaintiffs in New Mexico.  These matters have been transferred to the MDL.  The Company is also on notice of approximately 660 other possible individual product liability claims and three possible municipal claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, but the Company anticipates that they soon will be.

- changed (2019-08-01):
[0000833444-19-000041:note_history:18]
Chemguard and Tyco Fire Products are also defendants in 23 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio and South Carolina.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  All of these cases have been transferred to the MDL. The following municipal actions were filed in fiscal year 2019:
  (was, 2019-05-03, similarity 0.922):
[0000833444-19-000022:note_history:18]
Chemguard and Tyco Fire Products are also defendants in 17 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, Florida, Massachusetts, New Jersey, New York, Maryland and Ohio.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  All but one of these cases either have been transferred or identified for transfer to the MDL. The following municipal actions were filed in fiscal year 2019:

- added (2019-08-01):
[0000833444-19-000041:note_history:19]
| • | County of Westchester v. The 3M Company et al., filed May 24, 2019 in the United States District Court, Southern District of New York. |

- added (2019-08-01):
[0000833444-19-000041:note_history:20]
| • | Diane Hebrank et al. v. City of Newburgh v. The 3M Company et al., third-party complaint filed June 10, 2019, in the Supreme Court of New York, Orange County. |

- added (2019-08-01):
[0000833444-19-000041:note_history:21]
| • | California-American Water v. The 3M Company et al., direct-filed on June 21, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

- added (2019-08-01):
[0000833444-19-000041:note_history:22]
| • | City of Sioux Falls v. The 3M Company et al., direct-filed on June 26, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

- added (2019-08-01):
[0000833444-19-000041:note_history:23]
| • | Sioux Falls Regional Airport Authority v. The 3M Company et al., direct-filed on June 28, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

- changed (2019-08-01):
[0000833444-19-000041:note_history:24]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base. In addition, three water districts in Pennsylvania, Horsham Water and Sewer Authority, Warminster Municipal Authority, and Warrington Township have filed praecipes for summons against Chemguard and Tyco Fire Products and other AFFF manufacturers relating to alleged PFOS and PFOA contamination.  These praecipes are not active suits, but have the effect of tolling the statute of limitations.
  (was, 2019-05-03, similarity 0.7844):
[0000833444-19-000022:note_history:24]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base. In addition, three water districts in Pennsylvania, Horsham Water and Sewer Authority, Warminster Municipal Authority, and Warrington Township have filed praecipes for summons against Chemguard and Tyco Fire Products and other AFFF manufacturers relating to alleged PFOS and PFOA contamination.  These praecipes are not active suits, but have the effect of tolling the statute of limitations. In addition, in February 2019, the County of Westchester, New York sent a Notice of Intent to File Suit against Chemguard, Tyco Fire Products, other AFFF manufacturers, and various governmental entities including the United States and the State of New York in connection with PFOS and PFOA contamination allegedly resulting from the use of AFFF in and around the County of Westchester.

- added (2019-08-01):
[0000833444-19-000041:note_history:25]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and tagged for transfer to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York.  This third complaint has not been served.

- added (2019-08-01):
[0000833444-19-000041:note_history:26]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.).  The State of New Jersey action has been removed to the United State District Court for the District of New Jersey and tagged for transfer to the MDL.  The State of Vermont and State of New Hampshire actions were recently served.

- changed (2019-08-01):
[0000833444-19-000041:note_history:27]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFOA/PFOS contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.
  (was, 2019-05-03, similarity 0.9931):
[0000833444-19-000022:note_history:27]
Tyco Fire Products and its subsidiary Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFOA/PFOS contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.

- added (2019-08-01):
[0000833444-19-000041:note_history:28]
On March 15, 2019, a German subsidiary of the Company received a complaint from Robert Bosch GmbH (“Bosch”), filed in a German court. The complaint relates to an automotive starter batteries joint venture in which the Company and Bosch were 80/20 parties to this joint venture. At the time the complaint was filed, JCI’s ownership interest in the joint venture was to be transferred to entities controlled by the Purchaser upon consummation of the previously announced sale of the Company’s Power Solutions business.

- removed (2019-08-01):
[0000833444-19-000022:note_history:29]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of March 31, 2019, reserves for environmental liabilities for continuing operations totaled $30 million, of which $15 million was recorded within other current liabilities and $15 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $37 million at September 30, 2018, of which $10 million was recorded within other current liabilities and $27 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At March 31, 2019 and September 30, 2018, the Company recorded conditional asset retirement obligations for continuing operations of $29 million.

- removed (2019-08-01):
[0000833444-19-000022:note_history:30]
claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

- removed (2019-08-01):
[0000833444-19-000022:note_history:31]
Two of our subsidiaries, Chemguard, Inc. ("Chemguard") and Tyco Fire Products L.P. ("Tyco Fire Products"), have been named, along with other defendant manufacturers, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated ("PFAS") compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued regulatory limits, however; while those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

- removed (2019-08-01):
[0000833444-19-000022:note_history:32]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This second complaint has not been served.

- removed (2019-08-01):
[0000833444-19-000022:note_history:33]
Tyco Fire Products, in coordination with the Wisconsin Department of Natural Resources ("WDNR") and the Wisconsin Department of Health Services ("DHS"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin.  In connection with the assessment, PFOS and PFOA have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC.  Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working closely with WDNR and DHS to develop interim measures to remove these compounds from certain areas where they have been detected.

- removed (2019-08-01):
[0000833444-19-000022:note_history:34]
On March 15, 2019, a German subsidiary of the Company received a complaint from Robert Bosch GmbH (“Bosch”), filed in a German court. The complaint relates to a joint venture in which JCI’s ownership interest will be transferred to entities controlled by the Purchaser in connection with the previously announced sale of the Company’s Power Solutions business.

- removed (2019-08-01):
[0000833444-19-000022:note_history:35]
The Company and Bosch are 80/20 parties to this joint venture, which operates a business related to automotive starter batteries and is separate from the Company’s supply agreement with Bosch.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-08-01):
[0000833444-19-000041:note_history:36]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2018 filed with the SEC on November 20, 2018. The results of operations for the three and nine month periods ended June 30, 2019 are not necessarily indicative of results for the Company’s 2019 fiscal year because of seasonal and other factors.
  (was, 2019-05-03, similarity 0.9786):
[0000833444-19-000022:note_history:36]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2018 filed with the SEC on November 20, 2018. The results of operations for the three and six month periods ended March 31, 2019 are not necessarily indicative of results for the Company’s 2019 fiscal year because of seasonal and other factors.

- changed (2019-08-01):
[0000833444-19-000041:note_history:37]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. The Company creates intelligent buildings, efficient energy solutions and integrated infrastructure that work seamlessly together to deliver on the promise of smart cities and communities. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.
  (was, 2019-05-03, similarity 0.8422):
[0000833444-19-000022:note_history:37]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. The Company creates intelligent buildings, efficient energy solutions, integrated infrastructure and next generation transportation systems that work seamlessly together to deliver on the promise of smart cities and communities. The Company is committed to helping our customers win and creating greater value for all of its stakeholders through strategic focus on our buildings and energy growth platforms.

- changed (2019-08-01):
[0000833444-19-000041:note_history:38]
The Company is a global market leader in engineering, developing, manufacturing and installing building products and systems around the world, including heating, ventilating, air-conditioning ("HVAC") equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Company further serves customers by providing technical services (in the HVAC, security and fire-protection space), energy-management consulting and data-driven solutions via its data-enabled business. Finally, the Company has a strong presence in the North American residential air conditioning and heating systems market and is a global market leader in industrial refrigeration products.
  (was, 2019-05-03, similarity 0.6964):
[0000833444-19-000022:note_history:38]
The Building Technologies & Solutions ("Buildings") business is a global market leader in engineering, developing, manufacturing and installing building products and systems around the world, including heating, ventilating, air-conditioning ("HVAC") equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Buildings business further serves customers by providing technical services (in the HVAC, security and fire-protection space), energy-management consulting and data-driven solutions via its data-enabled business. Finally, the Company has a strong presence in the North American residential air conditioning and heating systems market and is a global market leader in industrial refrigeration products.

- changed (2019-08-01):
[0000833444-19-000041:note_history:39]
Under certain criteria as provided for in Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity ("VIE"). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting rights. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.
  (was, 2019-05-03, similarity 0.8188):
[0000833444-19-000022:note_history:39]
Under certain criteria as provided for in Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity ("VIE"). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting rights. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the

- added (2019-08-01):
[0000833444-19-000041:note_history:40]
At June 30, 2019, the Company held restricted cash of approximately $16 million, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities. At September 30, 2018, the Company held restricted cash of approximately $15 million, of which $6 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position.

- removed (2019-08-01):
[0000833444-19-000022:note_history:41]
The Power Solutions business is a leading global supplier of lead-acid automotive batteries for virtually every type of passenger car, light truck and utility vehicle. The Company serves both automotive original equipment manufacturers and the general vehicle battery aftermarket. The Company also supplies advanced battery technologies to power start-stop, hybrid and electric vehicles. During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation, which required retrospective application to financial information for all periods presented. Refer to Note 4, "Discontinued Operations" of the notes to consolidated financial statements for further information.

- removed (2019-08-01):
[0000833444-19-000022:note_history:42]
VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.

- removed (2019-08-01):
[0000833444-19-000022:note_history:43]
At March 31, 2019, the Company held restricted cash of approximately $19 million, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities. At September 30, 2018, the Company held restricted cash of approximately $15 million, of which $6 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-08-01):
[0000833444-19-000041:note_history:44]
In June 2019, TSarl, a subsidiary of the Company, terminated its $1.25 billion committed revolving credit facility scheduled to expire in August 2020. In connection with the termination, the Company repaid all of the outstanding obligations in respect of principal, interest and fees under the credit facility. In relation to the termination of the credit facility, TSarl completed all of its obligations under the Term Loan Credit Agreement, dated as of March 10, 2016 (the "Term Facility") by repaying all of the outstanding obligations under the term facility, which included $364 million term loan scheduled to mature in March 2020. Other debt held at TSarl as of March 31, 2019 was also repaid, including a 364-day $250 million floating rate term loan scheduled to mature in March 2020 and an 18-month 215 million euro floating rate euro term loan scheduled to mature in July 2019. No amounts remain outstanding on the $4.0 billion TSarl merger-related debt as of June 30, 2019.

- changed (2019-08-01):
[0000833444-19-000041:note_history:45]
In June 2019, the Company repurchased at par, $2.5 million of its 5.25% fixed rate notes, plus accrued interest, scheduled to mature in 2041.
  (was, 2019-05-03, similarity 0.9179):
[0000833444-19-000022:note_history:45]
In February 2019, the Company repurchased, at a discount, $12 million of its 3.9% fixed rate notes, plus accrued interest, scheduled to mature in 2026.

- added (2019-08-01):
[0000833444-19-000041:note_history:46]
In May 2019, the Company completed the debt tender offer to purchase up to $1.5 billion in aggregate principal amount of certain of its outstanding notes for $1.6 billion total consideration. The Company recognized a loss on the extinguishment of debt of $60 million, which was recorded within net financing charges in the consolidated statements of income.

- added (2019-08-01):
[0000833444-19-000041:note_history:47]
In May 2019, the Company repaid 10 billion yen of the 35 billion yen five-year syndicated floating rate term loan, plus accrued interest, scheduled to mature in September 2022.

- added (2019-08-01):
[0000833444-19-000041:note_history:48]
In April 2019, the Company repurchased at a discount, 4.7 million euro of its 1.375% fixed rate euro notes, plus accrued interest, scheduled to mature in 2025.

- changed (2019-08-01):
[0000833444-19-000041:note_history:49]
In March 2019, a 364-day $250 million committed revolving credit facility expired.  The Company entered into a new $250 million committed revolving credit facility scheduled to expire in March 2020.  As of June 30, 2019 there were no draws on the facility.
  (was, 2019-05-03, similarity 0.9809):
[0000833444-19-000022:note_history:49]
In March 2019, a 364-day $250 million committed revolving credit facility expired.  The Company entered into a new $250 million committed revolving credit facility scheduled to expire in March 2020.  As of March 31, 2019 there were no draws on the facility.

- added (2019-08-01):
[0000833444-19-000041:note_history:50]
In February 2019, the Company repurchased at a discount, $12 million of its 3.9% fixed rate notes, plus accrued interest, scheduled to mature in 2026.

- changed (2019-08-01):
[0000833444-19-000041:note_history:51]
In February 2019, a 364-day $150 million committed revolving credit facility expired.  The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2020.  As of June 30, 2019 there were no draws on the facility.
  (was, 2019-05-03, similarity 0.9814):
[0000833444-19-000022:note_history:51]
In February 2019, a 364-day $150 million committed revolving credit facility expired.  The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2020.  As of March 31, 2019 there were no draws on the facility.

- changed (2019-08-01):
[0000833444-19-000041:note_history:52]
In February 2019, a 364-day $150 million committed revolving credit facility expired.  The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2020.  As of June 30, 2019 there were no draws on the facility.
  (was, 2019-05-03, similarity 0.9814):
[0000833444-19-000022:note_history:52]
In February 2019, a 364-day $150 million committed revolving credit facility expired.  The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2020.  As of March 31, 2019 there were no draws on the facility.

- changed (2019-08-01):
[0000833444-19-000041:note_history:53]
In January 2019, the Company entered into a $750 million term loan due the earlier of January 2020 or five business days from the closing on the sale of the Power Solutions business.  Proceeds from the term loan were used for general corporate purposes. Following the sale of the Power Solutions business, the loan was repaid in May 2019.
  (was, 2019-05-03, similarity 0.8571):
[0000833444-19-000022:note_history:53]
In January 2019, the Company entered into a $750 million term loan due the earlier of January 2020 or five business days from the closing on the sale of the Power Solutions business.  Proceeds from the term loan were used for general corporate purposes.

- changed (2019-08-01):
[0000833444-19-000041:note_history:54]
In January 2019, a 364-day $200 million committed revolving credit facility expired.  The Company entered into a new $350 million committed revolving credit facility scheduled to expire in January 2020.  As of June 30, 2019 there were no draws on the facility.
  (was, 2019-05-03, similarity 0.9812):
[0000833444-19-000022:note_history:54]
In January 2019, a 364-day $200 million committed revolving credit facility expired.  The Company entered into a new $350 million committed revolving credit facility scheduled to expire in January 2020.  As of March 31, 2019 there were no draws on the facility.

- changed (2019-08-01):
[0000833444-19-000041:note_history:55]
The Company's net financing charges line item in the consolidated statements of income for the three and nine months ended June 30, 2019 and 2018 contained the following components (in millions):
  (was, 2019-05-03, similarity 0.9626):
[0000833444-19-000022:note_history:55]
The Company's net financing charges line item in the consolidated statements of income for the three and six months ended March 31, 2019 and 2018 contained the following components (in millions):

- changed (2019-08-01):
[0000833444-19-000041:note_history:56]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Interest expense, net of capitalized interest costs | $ | 81 |  |  | $ | 106 |  |  | $ | 269 |  |  | $ | 307 |  |
| Banking fees and bond cost amortization | 7 |  |  | 8 |  |  | 20 |  |  | 23 |  |
| Loss on debt extinguishment | 60 |  |  | — |  |  | 60 |  |  | — |  |
| Interest income | (28 | ) |  | (5 | ) |  | (41 | ) |  | (13 | ) |
| Net foreign exchange results for financing activities | (1 | ) |  | (14 | ) |  | (6 | ) |  | (13 | ) |
| Net financing charges | $ | 119 |  |  | $ | 95 |  |  | $ | 302 |  |  | $ | 304 |  |
  (was, 2019-05-03, similarity 0.691):
[0000833444-19-000022:note_history:56]
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Interest expense, net of capitalized interest costs | $ | 97 |  |  | $ | 99 |  |  | $ | 188 |  |  | $ | 201 |  |
| Banking fees and bond cost amortization | 7 |  |  | 8 |  |  | 13 |  |  | 15 |  |
| Interest income | (6 | ) |  | (1 | ) |  | (13 | ) |  | (8 | ) |
| Net foreign exchange results for financing activities | — |  |  | 1 |  |  | (5 | ) |  | 1 |  |
| Net financing charges | $ | 98 |  |  | $ | 107 |  |  | $ | 183 |  |  | $ | 209 |  |

- removed (2019-08-01):
[0000833444-19-000022:note_history:57]
On May 1, 2019, the Company announced that it has commenced a cash tender offer to purchase up to $1.5 billion in aggregate principal amount of certain of its outstanding notes.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2019-08-01):
[0000833444-19-000041:note_history:58]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $65 million and $27 million, respectively, for the three months ended June 30, 2019; and $65 million and $19 million, respectively, for the three months ended June 30, 2018. The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $162 million and $57 million, respectively, for the nine months ended June 30, 2019; and $169 million and $43 million, respectively, for the nine months ended June 30, 2018.

- changed (2019-08-01):
[0000833444-19-000041:note_history:59]
|  |  | June 30, 2019 |  | September 30, 2018 |  |
| Receivable from related parties |  | $ | 55 |  |  | $ | 36 |  |
| Payable to related parties |  | 8 |  |  | 18 |  |
  (was, 2019-05-03, similarity 0.9686):
[0000833444-19-000022:note_history:59]
|  |  | March 31, 2019 |  | September 30, 2018 |  |
| Receivable from related parties |  | $ | 48 |  |  | $ | 36 |  |
| Payable to related parties |  | 12 |  |  | 18 |  |

- removed (2019-08-01):
[0000833444-19-000022:note_history:60]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $54 million and $16 million, respectively, for the three months ended March 31, 2019; and $59 million and $15 million, respectively, for the three months ended March 31, 2018. The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $97 million and $30 million, respectively, for the six months ended March 31, 2019; and $104 million and $24 million, respectively, for the six months ended March 31, 2018.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2019-08-01):
[0000833444-19-000041:note_history:61]
|  |  | June 30, 2019 |  | September 30, 2018 |  |
| Receivable from related parties |  | $ | 55 |  |  | $ | 36 |  |
| Payable to related parties |  | 8 |  |  | 18 |  |
  (was, 2019-05-03, similarity 0.9686):
[0000833444-19-000022:note_history:61]
|  |  | March 31, 2019 |  | September 30, 2018 |  |
| Receivable from related parties |  | $ | 48 |  |  | $ | 36 |  |
| Payable to related parties |  | 12 |  |  | 18 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-08-01):
[0000833444-19-000041:note_history:62]
The following table presents the Company's revenues disaggregated by segment and by product versus services revenue for the three and nine months ended June 30, 2019 (in millions):
  (was, 2019-05-03, similarity 0.96):
[0000833444-19-000022:note_history:62]
The following table presents the Company's revenues disaggregated by segment and by product versus services revenue for the three and six months ended March 31, 2019 (in millions):

- changed (2019-08-01):
[0000833444-19-000041:note_history:63]
|  |  | Three Months EndedJune 30, 2019 |  | Nine Months EndedJune 30, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,494 |  |  | $ | 833 |  |  | $ | 2,327 |  |  | $ | 4,202 |  |  | $ | 2,428 |  |  | $ | 6,630 |  |
| Building Solutions EMEA/LA |  | 464 |  |  | 458 |  |  | 922 |  |  | 1,297 |  |  | 1,410 |  |  | 2,707 |  |
| Building Solutions Asia Pacific |  | 427 |  |  | 264 |  |  | 691 |  |  | 1,134 |  |  | 798 |  |  | 1,932 |  |
| Global Products |  | 2,511 |  |  | — |  |  | 2,511 |  |  | 6,425 |  |  | — |  |  | 6,425 |  |
| Total |  | $ | 4,896 |  |  | $ | 1,555 |  |  | $ | 6,451 |  |  | $ | 13,058 |  |  | $ | 4,636 |  |  | $ | 17,694 |  |
  (was, 2019-05-03, similarity 0.9425):
[0000833444-19-000022:note_history:63]
|  |  | Three Months EndedMarch 31, 2019 |  | Six Months EndedMarch 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,387 |  |  | $ | 800 |  |  | $ | 2,187 |  |  | $ | 2,708 |  |  | $ | 1,595 |  |  | $ | 4,303 |  |
| Building Solutions EMEA/LA |  | 416 |  |  | 462 |  |  | 878 |  |  | 833 |  |  | 952 |  |  | 1,785 |  |
| Building Solutions Asia Pacific |  | 351 |  |  | 277 |  |  | 628 |  |  | 707 |  |  | 534 |  |  | 1,241 |  |
| Global Products |  | 2,086 |  |  | — |  |  | 2,086 |  |  | 3,914 |  |  | — |  |  | 3,914 |  |
| Total |  | $ | 4,240 |  |  | $ | 1,539 |  |  | $ | 5,779 |  |  | $ | 8,162 |  |  | $ | 3,081 |  |  | $ | 11,243 |  |

- changed (2019-08-01):
[0000833444-19-000041:note_history:64]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and nine months ended June 30, 2019 (in millions):
  (was, 2019-05-03, similarity 0.9571):
[0000833444-19-000022:note_history:64]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and six months ended March 31, 2019 (in millions):

- changed (2019-08-01):
[0000833444-19-000041:note_history:65]
|  |  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  |  | 2019 |  | 2019 |
| Building Management |  | $ | 342 |  |  | $ | 943 |  |
| HVAC & Refrigeration Equipment |  | 1,869 |  |  | 4,628 |  |
| Specialty |  | 300 |  |  | 854 |  |
| Total Global Products |  | $ | 2,511 |  |  | $ | 6,425 |  |
  (was, 2019-05-03, similarity 0.8728):
[0000833444-19-000022:note_history:65]
|  |  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  |  | 2019 |  | 2019 |
| Building Management |  | $ | 320 |  |  | $ | 601 |  |
| HVAC & Refrigeration Equipment |  | 1,474 |  |  | 2,759 |  |
| Specialty |  | 292 |  |  | 554 |  |
| Total Global Products |  | $ | 2,086 |  |  | $ | 3,914 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-08-01):
[0000833444-19-000041:note_history:66]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion

- changed (2019-08-01):
[0000833444-19-000041:note_history:67]
measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company elected the practical expedient which permits the promised amount of consideration to not be adjusted for the effects of a significant financing component as at contract inception the Company expects to receive the payment within the twelve months of transfer of goods or services.
  (was, 2019-05-03, similarity 0.9092):
[0000833444-19-000022:note_history:67]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company elected the practical expedient which permits the promised amount of consideration to not be adjusted for the effects of a significant financing component as at contract inception the Company expects to receive the payment within the twelve months of transfer of goods or services.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-08-01):
[0000833444-19-000041:note_history:68]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion

- changed (2019-08-01):
[0000833444-19-000041:note_history:69]
measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company elected the practical expedient which permits the promised amount of consideration to not be adjusted for the effects of a significant financing component as at contract inception the Company expects to receive the payment within the twelve months of transfer of goods or services.
  (was, 2019-05-03, similarity 0.9092):
[0000833444-19-000022:note_history:69]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company elected the practical expedient which permits the promised amount of consideration to not be adjusted for the effects of a significant financing component as at contract inception the Company expects to receive the payment within the twelve months of transfer of goods or services.

- changed (2019-08-01):
[0000833444-19-000041:note_history:70]
The following table presents the Company's revenues disaggregated by segment and by product versus services revenue for the three and nine months ended June 30, 2019 (in millions):
  (was, 2019-05-03, similarity 0.96):
[0000833444-19-000022:note_history:70]
The following table presents the Company's revenues disaggregated by segment and by product versus services revenue for the three and six months ended March 31, 2019 (in millions):

- changed (2019-08-01):
[0000833444-19-000041:note_history:71]
|  |  | Three Months EndedJune 30, 2019 |  | Nine Months EndedJune 30, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,494 |  |  | $ | 833 |  |  | $ | 2,327 |  |  | $ | 4,202 |  |  | $ | 2,428 |  |  | $ | 6,630 |  |
| Building Solutions EMEA/LA |  | 464 |  |  | 458 |  |  | 922 |  |  | 1,297 |  |  | 1,410 |  |  | 2,707 |  |
| Building Solutions Asia Pacific |  | 427 |  |  | 264 |  |  | 691 |  |  | 1,134 |  |  | 798 |  |  | 1,932 |  |
| Global Products |  | 2,511 |  |  | — |  |  | 2,511 |  |  | 6,425 |  |  | — |  |  | 6,425 |  |
| Total |  | $ | 4,896 |  |  | $ | 1,555 |  |  | $ | 6,451 |  |  | $ | 13,058 |  |  | $ | 4,636 |  |  | $ | 17,694 |  |
  (was, 2019-05-03, similarity 0.9425):
[0000833444-19-000022:note_history:71]
|  |  | Three Months EndedMarch 31, 2019 |  | Six Months EndedMarch 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,387 |  |  | $ | 800 |  |  | $ | 2,187 |  |  | $ | 2,708 |  |  | $ | 1,595 |  |  | $ | 4,303 |  |
| Building Solutions EMEA/LA |  | 416 |  |  | 462 |  |  | 878 |  |  | 833 |  |  | 952 |  |  | 1,785 |  |
| Building Solutions Asia Pacific |  | 351 |  |  | 277 |  |  | 628 |  |  | 707 |  |  | 534 |  |  | 1,241 |  |
| Global Products |  | 2,086 |  |  | — |  |  | 2,086 |  |  | 3,914 |  |  | — |  |  | 3,914 |  |
| Total |  | $ | 4,240 |  |  | $ | 1,539 |  |  | $ | 5,779 |  |  | $ | 8,162 |  |  | $ | 3,081 |  |  | $ | 11,243 |  |

- changed (2019-08-01):
[0000833444-19-000041:note_history:72]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and nine months ended June 30, 2019 (in millions):
  (was, 2019-05-03, similarity 0.9571):
[0000833444-19-000022:note_history:72]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and six months ended March 31, 2019 (in millions):

- changed (2019-08-01):
[0000833444-19-000041:note_history:73]
|  |  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  |  | 2019 |  | 2019 |
| Building Management |  | $ | 342 |  |  | $ | 943 |  |
| HVAC & Refrigeration Equipment |  | 1,869 |  |  | 4,628 |  |
| Specialty |  | 300 |  |  | 854 |  |
| Total Global Products |  | $ | 2,511 |  |  | $ | 6,425 |  |
  (was, 2019-05-03, similarity 0.8728):
[0000833444-19-000022:note_history:73]
|  |  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  |  | 2019 |  | 2019 |
| Building Management |  | $ | 320 |  |  | $ | 601 |  |
| HVAC & Refrigeration Equipment |  | 1,474 |  |  | 2,759 |  |
| Specialty |  | 292 |  |  | 554 |  |
| Total Global Products |  | $ | 2,086 |  |  | $ | 3,914 |  |

- changed (2019-08-01):
[0000833444-19-000041:note_history:74]
|  |  | Location of contract balances |  | June 30, 2019 |  | October 1, 2018 |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,428 |  |  | $ | 1,261 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 85 |  |  | 85 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,389 | ) |  | (1,335 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (125 | ) |  | (113 | ) |
| Total |  |  |  | $ | (1 | ) |  | $ | (102 | ) |
  (was, 2019-05-03, similarity 0.9898):
[0000833444-19-000022:note_history:74]
|  |  | Location of contract balances |  | March 31, 2019 |  | October 1, 2018 |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,343 |  |  | $ | 1,261 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 85 |  |  | 85 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,521 | ) |  | (1,335 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (119 | ) |  | (113 | ) |
| Total |  |  |  | $ | (212 | ) |  | $ | (102 | ) |

- changed (2019-08-01):
[0000833444-19-000041:note_history:75]
For the three and nine months ended June 30, 2019, the Company recognized revenue of $130 million and $1,056 million, respectively, that was included in the beginning of period contract liability balance.
  (was, 2019-05-03, similarity 0.9635):
[0000833444-19-000022:note_history:75]
For the three and six months ended March 31, 2019, the Company recognized revenue of $214 million and $926 million, respectively, that was included in the beginning of period contract liability balance.

- changed (2019-08-01):
[0000833444-19-000041:note_history:76]
Performance obligations are satisfied as of a point in time or over time. Performance obligations are supported by contracts with customers, providing a framework for the nature of the distinct goods, services, or bundle of goods and services. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of June 30, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.2 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company has applied the practical expedient for certain revenue streams to exclude the value of remaining performance obligations for contracts with an original expected duration of one year or less.
  (was, 2019-05-03, similarity 0.9963):
[0000833444-19-000022:note_history:76]
Performance obligations are satisfied as of a point in time or over time. Performance obligations are supported by contracts with customers, providing a framework for the nature of the distinct goods, services, or bundle of goods and services. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of March 31, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $13.9 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company has applied the practical expedient for certain revenue streams to exclude the value of remaining performance obligations for contracts with an original expected duration of one year or less.

- added (2019-08-01):
[0000833444-19-000041:note_history:77]
As of June 30, 2019, the Company recorded the costs to obtain or fulfill a contract of $190 million, of which $100 million is recorded within other current assets and $90 million is recorded within other noncurrent assets in the consolidated statements of financial position.

- changed (2019-08-01):
[0000833444-19-000041:note_history:78]
During the three and nine months ended June 30, 2019, the Company recognized amortization expense of $50 million and $119 million, respectively related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and nine months ended June 30, 2019.
  (was, 2019-05-03, similarity 0.8229):
[0000833444-19-000022:note_history:78]
During the three and six months ended March 31, 2019, the Company recognized amortization expense of $34 million and $69 million, respectively related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and six months ended March 31, 2019.

- removed (2019-08-01):
[0000833444-19-000022:note_history:79]
As of March 31, 2019, the Company recorded the costs to obtain or fulfill a contract of $184 million, of which $98 million is recorded within other current assets and $86 million is recorded within other noncurrent assets in the consolidated statements of financial position.
