# JCI MD&A — 0000833444-22-000036


## mdna

[0000833444-22-000036:mdna:1]
[same as prior period, unchanged from 0000833444-22-000017:mdna:1]

[0000833444-22-000036:mdna:2]
[same as prior period, unchanged from 0000833444-22-000017:mdna:2]

[0000833444-22-000036:mdna:3]
[same as prior period, unchanged from 0000833444-22-000017:mdna:3]

[0000833444-22-000036:mdna:4]
[same as prior period, unchanged from 0000833444-22-000017:mdna:4]

[0000833444-22-000036:mdna:5]
[same as prior period, unchanged from 0000833444-22-000017:mdna:5]

[0000833444-22-000036:mdna:6]
The Company is a global leader in engineering, manufacturing and commissioning building products and systems, including residential and commercial HVAC equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its OpenBlue software platform and related digital capabilities. The Company partners with customers by leveraging its broad product portfolio and digital capabilities powered by OpenBlue, together with its direct channel service and solutions

[0000833444-22-000036:mdna:7]
capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency and reduce greenhouse gas emissions.

[0000833444-22-000036:mdna:8]
The following information should be read in conjunction with the September 30, 2021 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2021 filed with the SEC on November 15, 2021. References in the following discussion and analysis to "Three Months" (or similar language) refer to the three months ended June 30, 2022 compared to the three months ended June 30, 2021, while "Year-to-Date" refers to the nine months ended June 30, 2022 compared to the nine months ended June 30, 2021.

[0000833444-22-000036:mdna:9]
[same as prior period, unchanged from 0000833444-22-000017:mdna:9]

[0000833444-22-000036:mdna:10]
[same as prior period, unchanged from 0000833444-22-000017:mdna:10]

[0000833444-22-000036:mdna:11]
[same as prior period, unchanged from 0000833444-22-000017:mdna:11]

[0000833444-22-000036:mdna:12]
The Company continues to observe trends demonstrating increased interest and demand for safe, efficient and sustainable buildings, and seeks to capitalize on these trends to drive growth by developing and delivering technologies and solutions to create smart and healthy buildings. The Company launched its OpenBlue software platform, enabling enterprises to manage all aspects of their physical spaces delivering sustainability, new occupant experiences, and safety and security by combining the Company’s building expertise with cutting-edge technology, including AI-powered service solutions such as remote diagnostics, predictive maintenance, compliance monitoring and advanced risk assessments. The Company continues to leverage its install base, together with data-driven products and services to offer outcome-based solutions to customers with a focus on generating accelerated growth in services and recurring revenue for the Company. The Company has committed to investing in new product research and development in climate-related innovation to develop sustainable products and services.

[0000833444-22-000036:mdna:13]
The Company has experienced, and expects to continue to experience, increased input material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends, including increased global demand, the conflict between Russia and Ukraine, government-mandated actions in response to COVID-19, particularly in China, and labor shortages. Actions taken by the Company to mitigate supply chain disruptions and inflation, including expanding and redistributing its supplier network, supplier financing, price increases and productivity improvements, have generally been successful in offsetting some, but not all, of the impact of these trends. The collective impact of these trends has been to positively impact revenue due to increased demand and price increases to offset inflation, while negatively impacting margins due to supply chain disruptions and cost pressures. The Company has also experienced delays in converting its backlog due to continued supply chain disruptions, negatively impacting both revenues and margins. The Company expects that these trends will continue to impact the Company's results for the remainder of fiscal 2022 and possibly into fiscal 2023. Therefore, the Company could experience further disruptions, shortages and cost increases in the future, the effect of which will depend on the Company’s ability to successfully mitigate and offset the impact of these events.

[0000833444-22-000036:mdna:14]
During the second quarter of fiscal 2022, the Company suspended its operations in Russia in response to the conflict between Russia and Ukraine. Although this decision has not had and is not expected to have a material impact on the Company’s operating results, the broader consequences of this conflict, including heightened supply chain disruption, inflation, economic instability and other factors have and could continue to adversely impact the Company’s results of operations.

[0000833444-22-000036:mdna:15]
[same as prior period, unchanged from 0000833444-22-000017:mdna:16]

[0000833444-22-000036:mdna:16]
The COVID-19 pandemic continues to impact aspects of the Company's operations and results. The Company’s affiliates, employees, suppliers, customers and others have been and may continue to be restricted or prevented from conducting normal business activities, including as a result of shutdowns, travel restrictions and other actions that may be requested or mandated by governmental authorities. During the first nine months of fiscal 2022, the Company’s facilities generally operated at normal levels, however the Company has experienced some disruptions to its business in China due to government-mandated lockdowns in several major cities.

[0000833444-22-000036:mdna:17]
The Company continues to focus its efforts on preserving the health and safety of its employees and customers, as well as maintaining the continuity of its operations.

[0000833444-22-000036:mdna:18]
[same as prior period, unchanged from 0000833444-22-000017:mdna:20]

[0000833444-22-000036:mdna:19]
However, the Company continues to be influenced by COVID-19-related trends impacting site access and the labor force, which have and may continue to negatively impact the Company’s revenues and margins. Challenges in reaching sufficient vaccination levels and the introduction of new variants of COVID-19 have caused some governments to extend or reinstitute lockdowns and similar restrictive measures, which, in some cases, have limited the Company’s ability to access customer sites to install and maintain its products and deliver services. In addition, the Company has experienced and continues to experience labor shortages at certain facilities as the Company expands its production capacity to meet increased customer demand. Although the Company is mitigating these shortages through focused recruitment efforts and competitive compensation packages, the Company could continue to experience such shortages in the future.

[0000833444-22-000036:mdna:20]
The extent to which the COVID-19 pandemic continues to impact the Company’s results of operations and financial condition will depend on future developments that are highly uncertain and cannot be predicted, including the resurgence of COVID-19 and its variants in regions recovering from the impacts of the pandemic, the effectiveness of COVID-19 vaccines and the speed at which populations are vaccinated around the globe, the impact of COVID-19 on economic activity, and regulatory actions taken to contain its impact on public health and the global economy. See Item 1A of Part II of this Quarterly Report on Form 10-Q for additional discussion of risks related to COVID-19.

[0000833444-22-000036:mdna:21]
[same as prior period, unchanged from 0000833444-22-000017:mdna:23]

[0000833444-22-000036:mdna:22]
[same as prior period, unchanged from 0000833444-22-000017:mdna:24]

[0000833444-22-000036:mdna:23]
[same as prior period, unchanged from 0000833444-22-000017:mdna:26]

[0000833444-22-000036:mdna:24]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Net sales | $ | 6,614 |  |  | $ | 6,341 |  |  | 4 | % |  | $ | 18,574 |  |  | $ | 17,276 |  |  | 8 | % |

[0000833444-22-000036:mdna:25]
The increase in consolidated net sales for the three months ended June 30, 2022 was due to higher organic sales ($465 million) and incremental sales from acquisitions ($73 million), partially offset by the unfavorable impact of foreign currency translation ($258 million), and lower sales due to business divestitures ($7 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 7% as compared to the prior year, attributable to higher volumes and increased pricing in response to inflation pressures. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-22-000036:mdna:26]
The increase in consolidated net sales for the nine months ended June 30, 2022 was due to higher organic sales ($1,409 million) and incremental sales from acquisitions ($319 million), partially offset by the unfavorable impact of foreign currency translation ($413 million), and lower sales due to business divestitures ($17 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 8% as compared to the prior year, attributable to higher volumes and increased pricing in response to inflation pressures. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-22-000036:mdna:27]
[same as prior period, unchanged from 0000833444-22-000017:mdna:30]

[0000833444-22-000036:mdna:28]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Cost of sales | $ | 4,414 |  |  | $ | 4,144 |  |  | 7 | % |  | $ | 12,526 |  |  | $ | 11,408 |  |  | 10 | % |
| Gross profit | 2,200 |  |  | 2,197 |  |  | — | % |  | 6,048 |  |  | 5,868 |  |  | 3 | % |
| % of sales | 33.3 | % |  | 34.6 | % |  |  |  | 32.6 | % |  | 34.0 | % |  |  |

[0000833444-22-000036:mdna:29]
Cost of sales and gross profit increased for the three-month period ended June 30, 2022, and gross profit as a percentage of sales decreased by 130 basis points. Gross profit increased due to organic sales growth and business acquisitions, partially offset by unfavorable foreign currency translation ($84 million), supply chain inefficiencies, price/cost pressures and the unfavorable year-over-year impact of net mark-to-market adjustments on pension plans ($33 million). Gross profit as a percentage of sales decreased as the benefit of volume leverage was more than offset by supply chain inefficiencies and price/cost pressures.  Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-22-000036:mdna:30]
Cost of sales and gross profit increased for the nine-month period ended June 30, 2022, and gross profit as a percentage of sales decreased by 140 basis points. Gross profit increased due to organic sales growth and business acquisitions, partially offset by unfavorable foreign currency translation ($128 million), supply chain inefficiencies, price/cost pressures and the unfavorable year-over-year impact of net mark-to-market adjustments on pension plans ($90 million). Gross profit as a percentage of sales decreased as the benefit of volume leverage was more than offset by supply chain inefficiencies and price/cost pressures.  Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-22-000036:mdna:31]
[same as prior period, unchanged from 0000833444-22-000017:mdna:49]

[0000833444-22-000036:mdna:32]
[same as prior period, unchanged from 0000833444-22-000017:mdna:34]

[0000833444-22-000036:mdna:33]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Selling, general and administrative expenses | $ | 1,589 |  |  | $ | 1,367 |  |  | 16 | % |  | $ | 4,412 |  |  | $ | 3,914 |  |  | 13 | % |
| % of sales | 24.0 | % |  | 21.6 | % |  |  |  | 23.8 | % |  | 22.7 | % |  |  |

[0000833444-22-000036:mdna:34]
Selling, general and administrative expenses ("SG&A") for the three-month period ended June 30, 2022 increased $222 million, and SG&A as a percentage of sales increased by 240 basis points. The increase in SG&A was primarily due to the unfavorable year-over-year impact of net mark-to-market adjustments on pension plans ($105 million), the unfavorable year-over-year impact of net mark-to-market adjustments on restricted asbestos investments ($54 million) and current year business acquisitions, partially offset by favorable foreign currency translation ($48 million). Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-22-000036:mdna:35]
Selling, general and administrative expenses ("SG&A") for the nine-month period ended June 30, 2022 increased $498 million, and SG&A as a percentage of sales increased by 110 basis points. The increase in SG&A was primarily due to the unfavorable year-over-year impact of net mark-to-market adjustments on pension plans ($281 million), the absence of certain one-time cost mitigation actions, current year business acquisitions and the unfavorable year-over-year impact of net mark-to-market adjustments on restricted asbestos investments ($83 million), partially offset by a favorable earn-out liability adjustment ($43 million) and favorable foreign currency translation ($82 million). Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-22-000036:mdna:36]
[same as prior period, unchanged from 0000833444-22-000017:mdna:38]

[0000833444-22-000036:mdna:37]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Restructuring and impairment costs | $ | 121 |  |  | $ | 79 |  |  | 53 | % |  | $ | 554 |  |  | $ | 175 |  |  | * |

[0000833444-22-000036:mdna:38]
[same as prior period, unchanged from 0000833444-22-000017:mdna:40]

[0000833444-22-000036:mdna:39]
Refer to Note 8, "Goodwill and Other Intangible Assets," Note 17, "Significant Restructuring and Impairment Costs," and Note 18, "Impairment of Long-Lived Assets," of the notes to the consolidated financial statements and "Restructuring" below within this Item 2 for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-22-000036:mdna:40]
[same as prior period, unchanged from 0000833444-22-000017:mdna:42]

[0000833444-22-000036:mdna:41]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Net financing charges | $ | 49 |  |  | $ | 56 |  |  | -13 | % |  | $ | 153 |  |  | $ | 159 |  |  | -4 | % |

[0000833444-22-000036:mdna:42]
[same as prior period, unchanged from 0000833444-22-000017:mdna:44]

[0000833444-22-000036:mdna:43]
[same as prior period, unchanged from 0000833444-22-000017:mdna:45]

[0000833444-22-000036:mdna:44]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Equity income | $ | 63 |  |  | $ | 74 |  |  | -15 | % |  | $ | 175 |  |  | $ | 188 |  |  | -7 | % |

[0000833444-22-000036:mdna:45]
The decrease in equity income for the three months ended June 30, 2022 was primarily due to lower income at certain partially-owned affiliates of the Johnson Controls within Building Solutions North America segment and at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture. Foreign currency translation had an unfavorable impact on equity income of $1 million for the three months ended June 30, 2022. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-22-000036:mdna:46]
The decrease in equity income for the nine months ended June 30, 2022 was primarily due to lower income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture and at certain partially-owned affiliates of the Johnson Controls within Building Solutions North America segment. Foreign currency translation had an unfavorable impact on equity income of $1 million for the nine months ended June 30, 2022. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-22-000036:mdna:47]
[same as prior period, unchanged from 0000833444-22-000017:mdna:50]

[0000833444-22-000036:mdna:48]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Income tax provision | $ | 61 |  |  | $ | 108 |  |  | -44 | % |  | $ | 190 |  |  | $ | 378 |  |  | -50 | % |
| Effective tax rate | 12.1 | % |  | 14.0 | % |  |  |  | 17.2 | % |  | 20.9 | % |  |  |

[0000833444-22-000036:mdna:49]
[same as prior period, unchanged from 0000833444-22-000017:mdna:52]

[0000833444-22-000036:mdna:50]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended June 30, 2022, the Company's effective tax rate for continuing operations was 12.1% and was lower than the statutory tax rate of 12.5% primarily due to the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives, partially offset by the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestitures and tax rate differentials. For the nine months ended June 30, 2022, the Company's effective tax rate for continuing operations was 17.2% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of an impairment charge, the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestitures, and tax rate differentials, partially offset by the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives. For the three months ended June 30, 2021, the Company's effective tax rate for continuing operations was 14.0% and was higher than the statutory tax rate of 12.5% primarily due to the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the nine months ended June 30, 2021, the Company's effective tax rate for continuing operations was 20.9% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. The effective tax rate for the nine months ended June 30, 2022 decreased as compared to the nine months ended June 30, 2021 primarily due to the discrete tax items. Refer to Note 19, "Income Taxes," of the notes to the consolidated financial statements for further detail.

[0000833444-22-000036:mdna:51]
49

[0000833444-22-000036:mdna:52]
[same as prior period, unchanged from 0000833444-22-000017:mdna:54]

[0000833444-22-000036:mdna:53]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Income from discontinued operations, net of tax | $ | — |  |  | $ | — |  |  | * |  | $ | — |  |  | $ | 124 |  |  | * |

[0000833444-22-000036:mdna:54]
[same as prior period, unchanged from 0000833444-22-000017:mdna:56]

[0000833444-22-000036:mdna:55]
[same as prior period, unchanged from 0000833444-22-000017:mdna:57]

[0000833444-22-000036:mdna:56]
[same as prior period, unchanged from 0000833444-22-000017:mdna:58]

[0000833444-22-000036:mdna:57]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 64 |  |  | $ | 87 |  |  | -26 | % |  | $ | 143 |  |  | $ | 186 |  |  | -23 | % |

[0000833444-22-000036:mdna:58]
The decrease in income from continuing operations attributable to noncontrolling interests for the three and nine months ended June 30, 2022 was primarily due to lower net income at certain partially-owned affiliates within the Global Products segment.

[0000833444-22-000036:mdna:59]
[same as prior period, unchanged from 0000833444-22-000017:mdna:61]

[0000833444-22-000036:mdna:60]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Net income attributable to Johnson Controls | $ | 379 |  |  | $ | 574 |  |  | -34 | % |  | $ | 771 |  |  | $ | 1,368 |  |  | -44 | % |

[0000833444-22-000036:mdna:61]
The decrease in net income attributable to Johnson Controls for the three months ended June 30, 2022 was primarily due to higher SG&A and higher restructuring and impairment costs, partially offset by lower income tax provision. The decrease in net income attributable to Johnson Controls for the nine months ended June 30, 2022 was primarily due to higher SG&A, higher restructuring and impairment costs and non-recurrence of prior year income from discontinued operations, partially offset by higher gross profit and lower income tax provision.

[0000833444-22-000036:mdna:62]
Diluted earnings per share attributable to Johnson Controls for the three months ended June 30, 2022 was $0.55 compared to $0.80 for the three months ended June 30, 2021. Diluted earnings per share attributable to Johnson Controls for the nine months ended June 30, 2022 was $1.10 compared to $1.89 for the nine months ended June 30, 2021.

[0000833444-22-000036:mdna:63]
[same as prior period, unchanged from 0000833444-22-000017:mdna:65]

[0000833444-22-000036:mdna:64]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 62 |  |  | $ | 633 |  |  | -90 | % |  | $ | 543 |  |  | $ | 1,793 |  |  | -70 | % |

[0000833444-22-000036:mdna:65]
The decrease in comprehensive income attributable to Johnson Controls for the three months ended June 30, 2022 was due to a decrease in other comprehensive income attributable to Johnson Controls ($376 million) resulting primarily from currency translation adjustments and lower net income attributable to Johnson Controls ($195 million). The year-over-year unfavorable

[0000833444-22-000036:mdna:66]
foreign currency translation adjustments were primarily driven by the weakening of the Brazilian real, British pound and euro against the U.S. dollar in the current quarter.

[0000833444-22-000036:mdna:67]
The decrease in comprehensive income attributable to Johnson Controls for the nine months ended June 30, 2022 was due to a decrease in other comprehensive income attributable to Johnson Controls ($653 million) resulting primarily from currency translation adjustments and lower net income attributable to Johnson Controls ($597 million). The year-over-year unfavorable foreign currency translation adjustments were primarily driven by the weakening of the British pound and euro in the nine months ended June 30, 2022 compared to strengthening of the Brazilian real, British pound, Canadian dollar and Mexican peso against the U.S. dollar in the nine months ended June 30, 2021.

[0000833444-22-000036:mdna:68]
[same as prior period, unchanged from 0000833444-22-000017:mdna:69]

[0000833444-22-000036:mdna:69]
[same as prior period, unchanged from 0000833444-22-000017:mdna:70]

[0000833444-22-000036:mdna:70]
[same as prior period, unchanged from 0000833444-22-000017:mdna:71]

[0000833444-22-000036:mdna:71]
[same as prior period, unchanged from 0000833444-22-000017:mdna:72]

[0000833444-22-000036:mdna:72]
[same as prior period, unchanged from 0000833444-22-000017:mdna:73]

[0000833444-22-000036:mdna:73]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Building Solutions North America | $ | 2,426 |  |  | $ | 2,212 |  |  | 10 | % |  | $ | 6,805 |  |  | $ | 6,338 |  |  | 7 | % |
| Building Solutions EMEA/LA | 952 |  |  | 1,001 |  |  | -5 | % |  | 2,869 |  |  | 2,883 |  |  | — | % |
| Building Solutions Asia Pacific | 665 |  |  | 703 |  |  | -5 | % |  | 1,963 |  |  | 1,901 |  |  | 3 | % |
| Global Products | 2,571 |  |  | 2,425 |  |  | 6 | % |  | 6,937 |  |  | 6,154 |  |  | 13 | % |
|  | $ | 6,614 |  |  | $ | 6,341 |  |  | 4 | % |  | $ | 18,574 |  |  | $ | 17,276 |  |  | 8 | % |

[0000833444-22-000036:mdna:74]
[same as prior period, unchanged from 0000833444-22-000017:mdna:75]

[0000833444-22-000036:mdna:75]
•The increase in Building Solutions North America was due to higher prices ($217 million) and incremental sales related to business acquisitions ($6 million), partially offset by the unfavorable impact of foreign currency translation ($9 million). The sales increase was led by low double-digit growth in service and strong growth in the HVAC & Controls platform.

[0000833444-22-000036:mdna:76]
•The decrease in Building Solutions EMEA/LA was due to the unfavorable impact of foreign currency translation ($88 million) and business divestitures ($7 million), partially offset by the net impact of higher prices and lower volumes ($37 million) and incremental sales related to business acquisitions ($9 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales increased, driven by high single-digit growth in service and strong performance in the Fire & Security platforms. By region, strong growth in Europe was partially offset by a decline in Latin America.

[0000833444-22-000036:mdna:77]
•The decrease in Building Solutions Asia Pacific was due to the unfavorable impact of foreign currency translation ($39 million) and the net impact of lower volumes and higher prices ($7 million), partially offset by incremental sales related to business acquisitions ($8 million). The decrease in sales was due to the COVID-19 lockdowns in China. Strong demand for Industrial Refrigeration equipment continued in the third quarter of fiscal 2022.

[0000833444-22-000036:mdna:78]
•The increase in Global Products was due to the net impact of higher prices and lower volumes ($218 million) and incremental sales related to business acquisitions ($50 million), partially offset by the unfavorable impact of foreign currency translation ($122 million). Sales growth was driven by strong pricing and broad-based demand for Commercial and Residential HVAC and Fire Detection products, partially offset by lower volumes due to the supply chain constraints and the COVID-19 lockdowns in China.

[0000833444-22-000036:mdna:79]
[same as prior period, unchanged from 0000833444-22-000017:mdna:80]

[0000833444-22-000036:mdna:80]
•The increase in Building Solutions North America was due to higher volumes and prices ($455 million) and incremental sales related to business acquisitions ($15 million), partially offset by the unfavorable impact of foreign currency translation ($3 million). The sales increase was led by strong growth in service and the HVAC & Controls platform.

[0000833444-22-000036:mdna:81]
•The decrease in Building Solutions EMEA/LA was due to the unfavorable impact of foreign currency translation ($155 million) and business divestitures ($16 million), partially offset by higher volumes and prices ($133 million) and incremental sales related to business acquisitions ($24 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales increased, driven by growth in service and strong performance in the Fire & Security platforms. By region, strong growth in Europe and Latin America was partially offset by continued weakness in the Middle East.

[0000833444-22-000036:mdna:82]
•The increase in Building Solutions Asia Pacific was due to the net impact of higher prices and lower volumes ($99 million) and incremental sales related to business acquisitions ($26 million), partially offset by the unfavorable impact of foreign currency translation ($62 million) and business divestitures ($1 million). The increase in sales was led by strong demand for Commercial Applied HVAC & Controls, partially offset by the COVID-19 lockdowns in China during the third quarter of fiscal 2022.

[0000833444-22-000036:mdna:83]
•The increase in Global Products was due to higher volumes and prices ($722 million) and incremental sales related to business acquisitions ($254 million), partially offset by the unfavorable impact of foreign currency translation ($193 million). Sales growth was driven by broad-based demand for Commercial and Residential HVAC and Fire & Security products and strong pricing.

[0000833444-22-000036:mdna:84]
[same as prior period, unchanged from 0000833444-22-000017:mdna:85]

[0000833444-22-000036:mdna:85]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Building Solutions North America | $ | 260 |  |  | $ | 326 |  |  | -20 | % |  | $ | 745 |  |  | $ | 847 |  |  | -12 | % |
| Building Solutions EMEA/LA | 83 |  |  | 105 |  |  | -21 | % |  | 266 |  |  | 291 |  |  | -9 | % |
| Building Solutions Asia Pacific | 85 |  |  | 84 |  |  | 1 | % |  | 227 |  |  | 234 |  |  | -3 | % |
| Global Products | 570 |  |  | 505 |  |  | 13 | % |  | 1,283 |  |  | 1,001 |  |  | 28 | % |
|  | $ | 998 |  |  | $ | 1,020 |  |  | -2 | % |  | $ | 2,521 |  |  | $ | 2,373 |  |  | 6 | % |

[0000833444-22-000036:mdna:86]
[same as prior period, unchanged from 0000833444-22-000017:mdna:87]

[0000833444-22-000036:mdna:87]
•The decrease in Building Solutions North America was primarily due to lower absorption related to supply chain disruptions and labor constraints and the unfavorable impact of foreign currency translation ($2 million), partially offset by productivity savings.

[0000833444-22-000036:mdna:88]
•The decrease in Building Solutions EMEA/LA was primarily due to supply chain disruptions and the unfavorable impact of foreign currency translation ($9 million), partially offset by favorable price/cost and productivity savings.

[0000833444-22-000036:mdna:89]
•The increase in Building Solutions Asia Pacific was primarily due to favorable price/cost and productivity savings, partially offset by lower volume leverage resulting from the COVID-19 lockdowns in China and the unfavorable impact of foreign currency translation ($6 million).

[0000833444-22-000036:mdna:90]
•The increase in Global Products was primarily due to favorable price/cost, favorable mix and productivity savings, partially offset by supply chain disruptions and the unfavorable impact of foreign currency translation ($20 million).

[0000833444-22-000036:mdna:91]
[same as prior period, unchanged from 0000833444-22-000017:mdna:92]

[0000833444-22-000036:mdna:92]
•The decrease in Building Solutions North America was primarily due to lower absorption related to supply chain disruptions and labor constraints, partially offset by productivity savings.

[0000833444-22-000036:mdna:93]
•The decrease in Building Solutions EMEA/LA was primarily due to the suspension of operations in Russia ($11 million), supply chain disruptions and the unfavorable impact of foreign currency translation ($15 million), partially offset by favorable price/cost and productivity savings.

[0000833444-22-000036:mdna:94]
•The decrease in Building Solutions Asia Pacific was primarily due to supply chain disruptions and the unfavorable impact of foreign currency translation ($12 million), partially offset by favorable price/cost and productivity savings.

[0000833444-22-000036:mdna:95]
•The increase in Global Products was primarily due to favorable volumes and mix, productivity savings and a favorable earn-out liability adjustment ($43 million), partially offset by the unfavorable impact of foreign currency translation ($19 million) and lower equity income driven primarily by certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture ($9 million).

[0000833444-22-000036:mdna:96]
[same as prior period, unchanged from 0000833444-22-000017:mdna:98]

[0000833444-22-000036:mdna:97]
The Company’s backlog is applicable to its sales of systems and services. At June 30, 2022, the backlog was $11.7 billion, of which $11.1 billion was attributable to the field business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-22-000036:mdna:98]
At June 30, 2022, remaining performance obligations were $17.5 billion, which is $5.8 billion higher than the Company's backlog of $11.7 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-22-000036:mdna:99]
[same as prior period, unchanged from 0000833444-22-000017:mdna:101]

[0000833444-22-000036:mdna:100]
•The Company excludes from remaining performance obligations certain contracts with customers with a term of one year or less or contracts that are cancellable without substantial penalty while these contracts are included within backlog; and

[0000833444-22-000036:mdna:101]
[same as prior period, unchanged from 0000833444-22-000017:mdna:103]

[0000833444-22-000036:mdna:102]
[same as prior period, unchanged from 0000833444-22-000017:mdna:104]

[0000833444-22-000036:mdna:103]
53

[0000833444-22-000036:mdna:104]
[same as prior period, unchanged from 0000833444-22-000017:mdna:105]

[0000833444-22-000036:mdna:105]
[same as prior period, unchanged from 0000833444-22-000017:mdna:106]

[0000833444-22-000036:mdna:106]
|  | June 30, |  | September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Current assets | $ | 11,559 |  |  | $ | 9,998 |  |  |  |
| Current liabilities | (11,883) |  |  | (9,098) |  |  |  |
|  | (324) |  |  | 900 |  |  | * |
| Less: Cash and cash equivalents | (1,506) |  |  | (1,336) |  |  |  |
| Add: Short-term debt | 2,081 |  |  | 8 |  |  |  |
| Add: Current portion of long-term debt | 217 |  |  | 226 |  |  |  |
| Less: Current assets held for sale | (404) |  |  | — |  |  |  |
| Add: Current liabilities held for sale | 261 |  |  | — |  |  |  |
| Working capital (as defined) | $ | 325 |  |  | $ | (202) |  |  | * |
| Accounts receivable - net | $ | 5,850 |  |  | $ | 5,613 |  |  | 4 | % |
| Inventories | 2,574 |  |  | 2,057 |  |  | 25 | % |
| Accounts payable | 4,125 |  |  | 3,746 |  |  | 10 | % |

[0000833444-22-000036:mdna:107]
[same as prior period, unchanged from 0000833444-22-000017:mdna:108]

[0000833444-22-000036:mdna:108]
[same as prior period, unchanged from 0000833444-22-000017:mdna:109]

[0000833444-22-000036:mdna:109]
•The increase in working capital at June 30, 2022 as compared to September 30, 2021, was primarily due to an increase in inventory due to supply chain disruptions, an increase in accounts receivable and a decrease in accrued compensation and benefits liabilities, partially offset by an increase in accounts payable and deferred revenue.

[0000833444-22-000036:mdna:110]
•The Company’s days sales in accounts receivable at June 30, 2022 and September 30, 2021 were 57 days and 58 days, respectively. There has been no significant adverse changes in the level of overdue receivables or significant changes in revenue recognition methods.

[0000833444-22-000036:mdna:111]
•The Company’s inventory turns for the three months ended June 30, 2022 were lower than the comparable period ended September 30, 2021, primarily due to supply chain disruptions.

[0000833444-22-000036:mdna:112]
•Days in accounts payable at June 30, 2022 were 84 days, higher than 76 days at the comparable period ended September 30, 2021, primarily due to timing.

[0000833444-22-000036:mdna:113]
[same as prior period, unchanged from 0000833444-22-000017:mdna:114]

[0000833444-22-000036:mdna:114]
|  |  | Nine Months Ended June 30, |
| (in millions) |  | 2022 |  | 2021 |
| Cash provided by operating activities |  | $ | 811 |  |  | $ | 2,022 |  |
| Cash used by investing activities |  | (588) |  |  | (886) |  |
| Cash provided (used) by financing activities |  | 29 |  |  | (1,650) |  |

[0000833444-22-000036:mdna:115]
[same as prior period, unchanged from 0000833444-22-000017:mdna:116]

[0000833444-22-000036:mdna:116]
•The decrease in cash used by investing activities was primarily due to lower cash payments made for acquisitions, partially offset by higher capital expenditures.

[0000833444-22-000036:mdna:117]
[same as prior period, unchanged from 0000833444-22-000017:mdna:118]

[0000833444-22-000036:mdna:118]
[same as prior period, unchanged from 0000833444-22-000017:mdna:119]

[0000833444-22-000036:mdna:119]
|  | June 30, |  | September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Short-term debt | $ | 2,081 |  |  | $ | 8 |  |  |  |
| Current portion of long-term debt | 217 |  |  | 226 |  |  |  |
| Long-term debt | 7,194 |  |  | 7,506 |  |  |  |
| Total debt | 9,492 |  |  | 7,740 |  |  | 23 | % |
| Less: Cash and cash equivalents | 1,506 |  |  | 1,336 |  |  |  |
| Total net debt | 7,986 |  |  | 6,404 |  |  | 25 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 15,988 |  |  | 17,562 |  |  | -9 | % |
| Total capitalization | $ | 23,974 |  |  | $ | 23,966 |  |  | — | % |
| Total net debt as a % of total capitalization | 33.3 | % |  | 26.7 | % |  |  |

[0000833444-22-000036:mdna:120]
[same as prior period, unchanged from 0000833444-22-000017:mdna:121]

[0000833444-22-000036:mdna:121]
[same as prior period, unchanged from 0000833444-22-000017:mdna:122]

[0000833444-22-000036:mdna:122]
•As of June 30, 2022, approximately $3.6 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity, and the economic environment.

[0000833444-22-000036:mdna:123]
•The Company declared a dividend of $0.35 per common share in the quarter ended June 30, 2022. The Company has increased its dividend 30% since the fourth quarter of 2021 and intends to continue paying dividends throughout fiscal 2022.

[0000833444-22-000036:mdna:124]
•The Company believes its capital resources and liquidity position at June 30, 2022 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, minimum pension contributions,

[0000833444-22-000036:mdna:125]
debt maturities and any potential acquisitions or stock repurchases in the remainder of fiscal 2022 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the second quarter of fiscal 2022, the Company took advantage of low interest rates in euro commercial paper markets and borrowed $1.5 billion in commercial paper, which the Company intends to repay by the end of the fiscal year. In the event the Company is unable to issue commercial paper, it would have the ability to draw on its $2.5 billion revolving credit facility which expires in December 2024 or its $0.5 billion 364-day revolving credit facility which expires in December 2022. There were no draws on the revolving credit facilities as of June 30, 2022 and September 30, 2021. The Company estimates that, as of June 30, 2022, it could borrow up to $1.4 billion based on average borrowing levels during the third quarter of fiscal 2022 on committed credit lines. The Company maintains a shelf registration statement with the SEC under which it may issue additional debt securities, ordinary shares, preferred shares, depositary shares, warrants purchase contracts and units that may be offered in one or more offerings on terms to be determined at the time of the offering. The Company anticipates that the proceeds of any offering would be used for general corporate purposes, including repayment of indebtedness, acquisitions, additions to working capital, repurchases of ordinary shares, dividends, capital expenditures and investments in the Company's subsidiaries. In addition, the Company held cash and cash equivalents of $1.5 billion as of June 30, 2022. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-22-000036:mdna:126]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of June 30, 2022, the Company's credit ratings and outlook were as follows:

[0000833444-22-000036:mdna:127]
[same as prior period, unchanged from 0000833444-22-000017:mdna:127]

[0000833444-22-000036:mdna:128]
[same as prior period, unchanged from 0000833444-22-000017:mdna:128]

[0000833444-22-000036:mdna:129]
•Financial covenants in the Company's revolving credit facilities requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of June 30, 2022, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-22-000036:mdna:130]
•The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2022, the Company believes the long-term rate of return will approximate 7.00%, 3.70% and 5.30% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first nine months of fiscal 2022, the Company made approximately $83 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $100 million in cash to its defined benefit pension plans in fiscal 2022. The Company expects to contribute $3 million in cash to its postretirement plans in fiscal 2022.

[0000833444-22-000036:mdna:131]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in fiscal 2022, the Company recorded income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain subsidiaries as a result of the planned divestitures. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the

[0000833444-22-000036:mdna:132]
[same as prior period, unchanged from 0000833444-22-000017:mdna:146]

[0000833444-22-000036:mdna:133]
foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at its Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-22-000036:mdna:134]
[same as prior period, unchanged from 0000833444-22-000017:mdna:133]

[0000833444-22-000036:mdna:135]
[same as prior period, unchanged from 0000833444-22-000017:mdna:134]

[0000833444-22-000036:mdna:136]
[same as prior period, unchanged from 0000833444-22-000017:mdna:135]

[0000833444-22-000036:mdna:137]
[same as prior period, unchanged from 0000833444-22-000017:mdna:136]

[0000833444-22-000036:mdna:138]
In fiscal 2021, the Company announced plans to optimize its cost structure through broad-based SG&A actions focused on simplification, standardization and centralization, with the intent to deliver annualized savings of $300 million by fiscal 2023. Additionally, the Company announced cost of sales actions intended to drive $250 million in annual run rate savings by fiscal 2023. The one-time pre-tax costs associated with these actions were originally expected to be approximately $385 million across all segments and at Corporate through fiscal 2023. The Company expects it will incur these costs by the end of fiscal 2022 due to certain restructuring actions and expenses planned for fiscal 2023 being accelerated into fiscal 2022. During the three and nine months ended June 30, 2022, the Company recorded $59 million and $135 million, respectively, of costs resulting from the 2021 restructuring plan. The Company has outstanding restructuring reserves of $90 million at June 30, 2022, all of which is expected to be paid in cash.

[0000833444-22-000036:mdna:139]
[same as prior period, unchanged from 0000833444-22-000017:mdna:138]

[0000833444-22-000036:mdna:140]
The following information is provided in compliance with Rule 13-01 of Regulation S-X under the Securities Exchange Act of 1934 with respect to the (i) $625 million aggregate principal amount of 1.750% Senior Notes due 2030 (the “2030 Notes”), (ii) €500 million aggregate principal amount of 0.375% Senior Notes due 2027 (the “2027 Notes”), (iii) €500 million aggregate principal amount of 1.000% Senior Notes due 2032 (the “2032 Notes”) and (iv) $500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due 2031 (the “2031 Notes” and together with the 2032 Notes, the 2030 Notes and the 2027 Notes, the “Notes”), each issued by Johnson Controls International plc ("Parent Company") and Tyco Fire & Security Finance S.C.A. (“TFSCA”), a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”).

[0000833444-22-000036:mdna:141]
[same as prior period, unchanged from 0000833444-22-000017:mdna:140]

[0000833444-22-000036:mdna:142]
[same as prior period, unchanged from 0000833444-22-000017:mdna:141]

[0000833444-22-000036:mdna:143]
[same as prior period, unchanged from 0000833444-22-000017:mdna:142]

[0000833444-22-000036:mdna:144]
|  |  | Nine Months Ended June 30, 2022 |  | Year EndedSeptember 30, 2021 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Loss from continuing operations |  | (181) |  |  | (212) |  |  |
| Net loss |  | (181) |  |  | (212) |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net loss attributable to the entity |  | (181) |  |  | (212) |  |  |

[0000833444-22-000036:mdna:145]
[same as prior period, unchanged from 0000833444-22-000017:mdna:144]

[0000833444-22-000036:mdna:146]
|  |  | Nine Months Ended June 30, 2022 |  | Year EndedSeptember 30, 2021 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Income from continuing operations |  | 62 |  |  | 223 |  |  |
| Net income |  | 62 |  |  | 223 |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net income attributable to the entity |  | 62 |  |  | 223 |  |  |

[0000833444-22-000036:mdna:147]
58

[0000833444-22-000036:mdna:148]
The following table presents summarized balance sheet information as of June 30, 2022 and September 30, 2021 (in millions):

[0000833444-22-000036:mdna:149]
|  |  | June 30, 2022 |  | September 30, 2021 |  |
| Current assets |  | $ | 796 |  |  | $ | 1,036 |  |  |
| Noncurrent assets |  | 243 |  |  | 280 |  |  |
| Current liabilities |  | 4,432 |  |  | 1,825 |  |  |
| Noncurrent liabilities |  | 6,961 |  |  | 7,260 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-22-000036:mdna:150]
[same as prior period, unchanged from 0000833444-22-000017:mdna:149]

[0000833444-22-000036:mdna:151]
|  |  | June 30, 2022 |  | September 30, 2021 |  |
| Current assets |  | $ | 1,071 |  |  | $ | 465 |  |  |
| Noncurrent assets |  | 2,969 |  |  | 2,992 |  |  |
| Current liabilities |  | 2,273 |  |  | 1,660 |  |  |
| Noncurrent liabilities |  | 6,941 |  |  | 7,199 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-22-000036:mdna:152]
[same as prior period, unchanged from 0000833444-22-000017:mdna:151]

[0000833444-22-000036:mdna:153]
[same as prior period, unchanged from 0000833444-22-000017:mdna:152]

[0000833444-22-000036:mdna:154]
[same as prior period, unchanged from 0000833444-22-000017:mdna:153]

[0000833444-22-000036:mdna:155]
[same as prior period, unchanged from 0000833444-22-000017:mdna:154]

[0000833444-22-000036:mdna:156]
[same as prior period, unchanged from 0000833444-22-000017:mdna:155]
