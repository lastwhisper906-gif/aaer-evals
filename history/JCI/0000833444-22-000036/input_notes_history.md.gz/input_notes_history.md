# JCI note change history — 0000833444-22-000017 → 0000833444-22-000036


## jci:ScheduleOfAccrualForAsbestosLossContingenciesTableTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2022-08-04):
[0000833444-22-000036:note_history:1]
|  | June 30, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 385 |  |  | 400 |  |
| Total asbestos-related liabilities | 443 |  |  | 458 |  |
| Other current assets | 39 |  |  | 13 |  |
| Other noncurrent assets | 279 |  |  | 365 |  |
| Total asbestos-related assets | 318 |  |  | 378 |  |
| Net asbestos-related liabilities | $ | 125 |  |  | $ | 80 |  |

- added (2022-08-04):
[0000833444-22-000036:note_history:2]
|  | June 30, 2022 |  | September 30, 2021 |
| Restricted |  |  |  |
| Cash | $ | 8 |  |  | $ | 6 |  |
| Investments | 255 |  |  | 314 |  |
| Total restricted assets | 263 |  |  | 320 |  |
| Insurance recoveries for asbestos-related liabilities | 55 |  |  | 58 |  |
| Total asbestos-related assets | $ | 318 |  |  | $ | 378 |  |

- removed (2022-08-04):
[0000833444-22-000017:note_history:3]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 390 |  |  | 400 |  |
| Total asbestos-related liabilities | 448 |  |  | 458 |  |
| Other current assets | 36 |  |  | 13 |  |
| Other noncurrent assets | 326 |  |  | 365 |  |
| Total asbestos-related assets | 362 |  |  | 378 |  |
| Net asbestos-related liabilities | $ | 86 |  |  | $ | 80 |  |

- removed (2022-08-04):
[0000833444-22-000017:note_history:4]
|  | March 31, 2022 |  | September 30, 2021 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 299 |  |  | 314 |  |
| Total restricted assets | 305 |  |  | 320 |  |
| Insurance recoveries for asbestos-related liabilities | 57 |  |  | 58 |  |
| Total asbestos-related assets | $ | 362 |  |  | $ | 378 |  |


## jci:ScheduleOfAccrualForEnvironmentalLossContingenciesTableTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-08-04):
[0000833444-22-000036:note_history:5]
|  | June 30, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 57 |  |  | $ | 48 |  |
| Other noncurrent liabilities | 15 |  |  | 54 |  |
| Total reserves for environmental liabilities | $ | 72 |  |  | $ | 102 |  |
  (was, 2022-05-04, similarity 0.9778):
[0000833444-22-000017:note_history:5]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 50 |  |  | $ | 48 |  |
| Other noncurrent liabilities | 34 |  |  | 54 |  |
| Total reserves for environmental liabilities | $ | 84 |  |  | $ | 102 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-08-04):
[0000833444-22-000036:note_history:6]
|  | June 30, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 57 |  |  | $ | 48 |  |
| Other noncurrent liabilities | 15 |  |  | 54 |  |
| Total reserves for environmental liabilities | $ | 72 |  |  | $ | 102 |  |
  (was, 2022-05-04, similarity 0.9778):
[0000833444-22-000017:note_history:6]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 50 |  |  | $ | 48 |  |
| Other noncurrent liabilities | 34 |  |  | 54 |  |
| Total reserves for environmental liabilities | $ | 84 |  |  | $ | 102 |  |

- changed (2022-08-04):
[0000833444-22-000036:note_history:7]
A substantial portion of the Company’s environmental reserves relates to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The Company’s reserves for remediation efforts at or near the FTC are based on a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals at this time. The Company is currently conducting additional analyses and cost assessments associated with longer-term remediation actions at or near the FTC. The Company anticipates recording additional remediation reserves in the fourth quarter of fiscal 2022 when the associated liabilities become estimable following completion of these analyses and assessments.
  (was, 2022-05-04, similarity 0.8653):
[0000833444-22-000017:note_history:7]
A substantial portion of the Company’s environmental reserves relates to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The Company’s reserves for remediation efforts at or near the FTC are based on a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals at this time.

- added (2022-08-04):
[0000833444-22-000036:note_history:8]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation. On November 6, 2020, WDNR received further recommendations from WDHS regarding individual standards for 12 additional PFAS and a combined standard for four additional PFAS, PFOA, and PFOS.

- changed (2022-08-04):
[0000833444-22-000036:note_history:9]
In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, WDNR approved Tyco Fire Products’ proposed Groundwater Extraction and Treatment System (“GETS”), a permanent groundwater remediation system that will extract groundwater that contains PFAS, treat it using advanced filtration systems, and return the treated water to the environment. Tyco Fire Products is nearing completion of construction on the GETS. Tyco Fire Products is also nearly finished removing PFAS-affected soil from the FTC.
  (was, 2022-05-04, similarity 0.7483):
[0000833444-22-000017:note_history:9]
In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, WDNR approved Tyco Fire Products’ proposed Groundwater Extraction and Treatment System (“GETS”), a permanent groundwater remediation system that will extract groundwater that contains PFAS, treat it using advanced filtration systems, and return the treated water to the environment. Tyco Fire Products has commenced construction on the GETS. Tyco Fire Products also has started the process of removing PFAS-affected soil from the FTC.

- changed (2022-08-04):
[0000833444-22-000036:note_history:10]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility in the third quarter of 2019 was recorded following a further review of the Consent Order, which
  (was, 2022-05-04, similarity 0.8808):
[0000833444-22-000017:note_history:10]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility in the third quarter of 2019 was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation of PFAS in the Marinette region.

- added (2022-08-04):
[0000833444-22-000036:note_history:11]
resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation of PFAS in the Marinette region.

- changed (2022-08-04):
[0000833444-22-000036:note_history:12]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. The Company's conditional asset retirement obligations for continuing operations were $25 million and $29 million at June 30, 2022 and September 30, 2021, respectively.
  (was, 2022-05-04, similarity 0.8717):
[0000833444-22-000017:note_history:12]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. The Company's conditional asset retirement obligations for continuing operations were $29 million at both March 31, 2022 and September 30, 2021.

- added (2022-08-04):
[0000833444-22-000036:note_history:13]
|  | June 30, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 385 |  |  | 400 |  |
| Total asbestos-related liabilities | 443 |  |  | 458 |  |
| Other current assets | 39 |  |  | 13 |  |
| Other noncurrent assets | 279 |  |  | 365 |  |
| Total asbestos-related assets | 318 |  |  | 378 |  |
| Net asbestos-related liabilities | $ | 125 |  |  | $ | 80 |  |

- added (2022-08-04):
[0000833444-22-000036:note_history:14]
|  | June 30, 2022 |  | September 30, 2021 |
| Restricted |  |  |  |
| Cash | $ | 8 |  |  | $ | 6 |  |
| Investments | 255 |  |  | 314 |  |
| Total restricted assets | 263 |  |  | 320 |  |
| Insurance recoveries for asbestos-related liabilities | 55 |  |  | 58 |  |
| Total asbestos-related assets | $ | 318 |  |  | $ | 378 |  |

- changed (2022-08-04):
[0000833444-22-000036:note_history:15]
|  | June 30, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 91 |  |  | $ | 77 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 219 |  |  | 226 |  |
| Total insurable liabilities | $ | 332 |  |  | $ | 325 |  |
  (was, 2022-05-04, similarity 0.9811):
[0000833444-22-000017:note_history:15]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 82 |  |  | $ | 77 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 216 |  |  | 226 |  |
| Total insurable liabilities | $ | 320 |  |  | $ | 325 |  |

- changed (2022-08-04):
[0000833444-22-000036:note_history:16]
|  | June 30, 2022 |  | September 30, 2021 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 15 |  |  | 15 |  |
| Total insurable receivables | $ | 20 |  |  | $ | 20 |  |
  (was, 2022-05-04, similarity 0.9744):
[0000833444-22-000017:note_history:16]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 15 |  |  | 15 |  |
| Total insurable receivables | $ | 20 |  |  | $ | 20 |  |

- added (2022-08-04):
[0000833444-22-000036:note_history:17]
PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. In March 2021, the EPA published its final determination to regulate PFOS and PFOA in drinking water. While those studies continue, the EPA issued in June 2022 an updated set of interim health advisory levels for PFOA and PFOS in drinking water.

- changed (2022-08-04):
[0000833444-22-000036:note_history:18]
In October 2021, the EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which the EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.
  (was, 2022-05-04, similarity 0.7632):
[0000833444-22-000017:note_history:18]
PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. In March 2021, the EPA published its final determination to regulate PFOS and PFOA in drinking water. In October 2021, the EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which the EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

- changed (2022-08-04):
[0000833444-22-000036:note_history:19]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.
  (was, 2022-05-04, similarity 0.8):
[0000833444-22-000017:note_history:19]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation

- changed (2022-08-04):
[0000833444-22-000036:note_history:20]
There are more than 2,500 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 2,100 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona, Illinois, and Texas.
  (was, 2022-05-04, similarity 0.918):
[0000833444-22-000017:note_history:20]
There are more than 2,200 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 2,100 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and transferred. There are four matters that are proceeding in state courts — three in Arizona and one in Texas.

- changed (2022-08-04):
[0000833444-22-000036:note_history:21]
Chemguard and Tyco Fire Products have been named as defendants in more than 200 cases in federal and state courts involving municipal or water provider plaintiffs in various states including Alaska, Alabama, Arizona, California, Colorado, Connecticut, Florida, Idaho, Illinois, Kentucky, Louisiana, Maryland, Massachusetts, Michigan, New Jersey, New York, North Carolina, Ohio, Pennsylvania, Virginia, Washington, West Virginia, Wisconsin, the District of Columbia, and several municipalities or water providers from various states who direct-filed complaints in South Carolina. The vast majority of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.
  (was, 2022-05-04, similarity 0.9443):
[0000833444-22-000017:note_history:21]
Chemguard and Tyco Fire Products have been named as defendants in approximately 183 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Alabama, Arizona, California, Colorado, Connecticut, Florida, Idaho, Illinois, Kentucky, Louisiana, Maryland, Massachusetts, Michigan, New Jersey, New York, North Carolina, Ohio, Pennsylvania, Virginia, Washington, West Virginia, Wisconsin, the District of Columbia, and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but four of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.

- changed (2022-08-04):
[0000833444-22-000036:note_history:22]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of
  (was, 2022-05-04, similarity 0.7316):
[0000833444-22-000017:note_history:22]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from

- added (2022-08-04):
[0000833444-22-000036:note_history:23]
New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

- changed (2022-08-04):
[0000833444-22-000036:note_history:24]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the
  (was, 2022-05-04, similarity 0.6291):
[0000833444-22-000017:note_history:24]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL.

- added (2022-08-04):
[0000833444-22-000036:note_history:25]
Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL.

- added (2022-08-04):
[0000833444-22-000036:note_history:26]
In May 2022, the Attorney General of the Commonwealth of Massachusetts filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s natural resources, property, residents, and consumers allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

- added (2022-08-04):
[0000833444-22-000036:note_history:27]
In July 2022, the Attorney General of the State of Wisconsin filed a lawsuit in Wisconsin state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage to the State’s natural resources and public health allegedly resulting, in part, from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and tagged for transfer to the MDL.

- removed (2022-08-04):
[0000833444-22-000017:note_history:28]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22,

- removed (2022-08-04):
[0000833444-22-000017:note_history:29]
2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation. On November 6, 2020, WDNR received further recommendations from WDHS regarding individual standards for 12 additional PFAS and a combined standard for four additional PFAS, PFOA, and PFOS.

- removed (2022-08-04):
[0000833444-22-000017:note_history:30]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 390 |  |  | 400 |  |
| Total asbestos-related liabilities | 448 |  |  | 458 |  |
| Other current assets | 36 |  |  | 13 |  |
| Other noncurrent assets | 326 |  |  | 365 |  |
| Total asbestos-related assets | 362 |  |  | 378 |  |
| Net asbestos-related liabilities | $ | 86 |  |  | $ | 80 |  |

- removed (2022-08-04):
[0000833444-22-000017:note_history:31]
|  | March 31, 2022 |  | September 30, 2021 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 299 |  |  | 314 |  |
| Total restricted assets | 305 |  |  | 320 |  |
| Insurance recoveries for asbestos-related liabilities | 57 |  |  | 58 |  |
| Total asbestos-related assets | $ | 362 |  |  | $ | 378 |  |

- removed (2022-08-04):
[0000833444-22-000017:note_history:32]
(“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

- removed (2022-08-04):
[0000833444-22-000017:note_history:33]
firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-08-04):
[0000833444-22-000036:note_history:34]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2021 filed with the SEC on November 15, 2021. The results of operations for the three and nine month periods ended June 30, 2022 are not necessarily indicative of results for the Company’s 2022 fiscal year because of seasonal and other factors.
  (was, 2022-05-04, similarity 0.9791):
[0000833444-22-000017:note_history:34]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2021 filed with the SEC on November 15, 2021. The results of operations for the three and six month periods ended March 31, 2022 are not necessarily indicative of results for the Company’s 2022 fiscal year because of seasonal and other factors.

- changed (2022-08-04):
[0000833444-22-000036:note_history:35]
At June 30, 2022 and September 30, 2021, the Company held restricted cash of approximately $35 million and $6 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities and certain litigation and environmental matters.
  (was, 2022-05-04, similarity 0.9875):
[0000833444-22-000017:note_history:35]
At March 31, 2022 and September 30, 2021, the Company held restricted cash of approximately $33 million and $6 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities and certain litigation and environmental matters.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-04):
[0000833444-22-000036:note_history:36]
Debt and Financing Arrangements
As of June 30, 2022, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2022. As of June 30, 2022, there were no draws on the facilities.
  (was, 2022-05-04, similarity 0.9726):
[0000833444-22-000017:note_history:36]
Debt and Financing Arrangements
As of March 31, 2022, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2022. As of March 31, 2022, there were no draws on the facilities.

- changed (2022-08-04):
[0000833444-22-000036:note_history:37]
In March 2022, the Company entered into two bank term loans totaling €285 million ($297 million as of June 30, 2022) which are both due in March 2023. In November 2021, the Company entered into a €200 million ($208 million as of June 30, 2022) bank term loan which is due in October 2022.
  (was, 2022-05-04, similarity 0.7882):
[0000833444-22-000017:note_history:37]
In March 2022, the Company entered into two bank term loans totaling €285 million ($318 million as of March 31, 2022) which are both due in March 2023. In November 2021, the Company entered into a €200 million ($223 million as of March 31, 2022) bank term loan which is due in October 2022.

- changed (2022-08-04):
[0000833444-22-000036:note_history:38]
The Company had $1.6 billion of commercial paper outstanding as of June 30, 2022. No commercial paper was outstanding as of September 30, 2021.
  (was, 2022-05-04, similarity 0.9653):
[0000833444-22-000017:note_history:38]
The Company had $1.5 billion of commercial paper outstanding as of March 31, 2022. No commercial paper was outstanding as of September 30, 2021.

- changed (2022-08-04):
[0000833444-22-000036:note_history:39]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Interest expense, net of capitalized interest costs | $ | 54 |  |  | $ | 55 |  |  | $ | 165 |  |  | $ | 167 |  |
| Other financing charges | 6 |  |  | 7 |  |  | 16 |  |  | 19 |  |
| Interest income | (2) |  |  | (1) |  |  | (5) |  |  | (7) |  |
| Net foreign exchange results for financing activities | (9) |  |  | (5) |  |  | (23) |  |  | (20) |  |
| Net financing charges | $ | 49 |  |  | $ | 56 |  |  | $ | 153 |  |  | $ | 159 |  |
  (was, 2022-05-04, similarity 0.8658):
[0000833444-22-000017:note_history:39]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Interest expense, net of capitalized interest costs | $ | 56 |  |  | $ | 53 |  |  | $ | 111 |  |  | $ | 112 |  |
| Banking fees and bond cost amortization | 5 |  |  | 4 |  |  | 10 |  |  | 12 |  |
| Interest income | (1) |  |  | (3) |  |  | (3) |  |  | (6) |  |
| Net foreign exchange results for financing activities | (9) |  |  | (10) |  |  | (14) |  |  | (15) |  |
| Net financing charges | $ | 51 |  |  | $ | 44 |  |  | $ | 104 |  |  | $ | 103 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-08-04):
[0000833444-22-000036:note_history:40]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales to related parties |  | $ | 50 |  |  | $ | 46 |  |  | $ | 133 |  |  | $ | 143 |  |
| Purchases from related parties |  | 57 |  |  | 55 |  |  | 148 |  |  | 121 |  |
  (was, 2022-05-04, similarity 0.8637):
[0000833444-22-000017:note_history:40]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales to related parties |  | $ | 48 |  |  | $ | 53 |  |  | $ | 83 |  |  | $ | 97 |  |
| Purchases from related parties |  | 47 |  |  | 37 |  |  | 91 |  |  | 66 |  |

- changed (2022-08-04):
[0000833444-22-000036:note_history:41]
|  |  | June 30, 2022 |  | September 30, 2021 |
| Receivable from related parties |  | $ | 64 |  |  | $ | 73 |  |
| Payable to related parties |  | 34 |  |  | 45 |  |
  (was, 2022-05-04, similarity 0.9682):
[0000833444-22-000017:note_history:41]
|  |  | March 31, 2022 |  | September 30, 2021 |
| Receivable from related parties |  | $ | 63 |  |  | $ | 73 |  |
| Payable to related parties |  | 27 |  |  | 45 |  |

- added (2022-08-04):
[0000833444-22-000036:note_history:42]
Additionally, the Company leases certain facilities used in its operations from a related party. The following table presents right-of use assets and lease liabilities associated with these leases in the consolidated statements of financial position (in millions):

- added (2022-08-04):
[0000833444-22-000036:note_history:43]
|  |  | June 30, 2022 |  | September 30, 2021 |
| Right-of-use assets |  | $ | 10 |  |  | $ | 11 |  |
| Lease liabilities |  | 9 |  |  | 10 |  |

- added (2022-08-04):
[0000833444-22-000036:note_history:44]
Amounts paid for these leases were not material.

- removed (2022-08-04):
[0000833444-22-000017:note_history:45]
Additionally, the Company leases certain facilities used in its operations from a related party. As of March 31, 2022, the right-of-use asset and lease liability associated with these leases were $10 million. As of September 30, 2021, the right-of-use asset associated with these leases was $11 million and the lease liability was $10 million. Amounts paid for these leases were not material.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-08-04):
[0000833444-22-000036:note_history:46]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales to related parties |  | $ | 50 |  |  | $ | 46 |  |  | $ | 133 |  |  | $ | 143 |  |
| Purchases from related parties |  | 57 |  |  | 55 |  |  | 148 |  |  | 121 |  |
  (was, 2022-05-04, similarity 0.8637):
[0000833444-22-000017:note_history:46]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales to related parties |  | $ | 48 |  |  | $ | 53 |  |  | $ | 83 |  |  | $ | 97 |  |
| Purchases from related parties |  | 47 |  |  | 37 |  |  | 91 |  |  | 66 |  |

- changed (2022-08-04):
[0000833444-22-000036:note_history:47]
|  |  | June 30, 2022 |  | September 30, 2021 |
| Receivable from related parties |  | $ | 64 |  |  | $ | 73 |  |
| Payable to related parties |  | 34 |  |  | 45 |  |
  (was, 2022-05-04, similarity 0.9682):
[0000833444-22-000017:note_history:47]
|  |  | March 31, 2022 |  | September 30, 2021 |
| Receivable from related parties |  | $ | 63 |  |  | $ | 73 |  |
| Payable to related parties |  | 27 |  |  | 45 |  |

- added (2022-08-04):
[0000833444-22-000036:note_history:48]
Additionally, the Company leases certain facilities used in its operations from a related party. The following table presents right-of use assets and lease liabilities associated with these leases in the consolidated statements of financial position (in millions):

- added (2022-08-04):
[0000833444-22-000036:note_history:49]
|  |  | June 30, 2022 |  | September 30, 2021 |
| Right-of-use assets |  | $ | 10 |  |  | $ | 11 |  |
| Lease liabilities |  | 9 |  |  | 10 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-04):
[0000833444-22-000036:note_history:50]
|  |  | Three Months Ended June 30, |
|  |  | 2022 |  | 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,481 |  |  | $ | 945 |  |  | $ | 2,426 |  |  | $ | 1,355 |  |  | $ | 857 |  |  | $ | 2,212 |  |
| Building Solutions EMEA/LA |  | 537 |  |  | 415 |  |  | 952 |  |  | 507 |  |  | 494 |  |  | 1,001 |  |
| Building Solutions Asia Pacific |  | 493 |  |  | 172 |  |  | 665 |  |  | 413 |  |  | 290 |  |  | 703 |  |
| Global Products |  | 2,571 |  |  | — |  |  | 2,571 |  |  | 2,425 |  |  | — |  |  | 2,425 |  |
| Total |  | $ | 5,082 |  |  | $ | 1,532 |  |  | $ | 6,614 |  |  | $ | 4,700 |  |  | $ | 1,641 |  |  | $ | 6,341 |  |
  (was, 2022-05-04, similarity 0.948):
[0000833444-22-000017:note_history:50]
|  |  | Three Months Ended March 31, 2022 |  | Three Months Ended March 31, 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,343 |  |  | $ | 884 |  |  | $ | 2,227 |  |  | $ | 1,272 |  |  | $ | 820 |  |  | $ | 2,092 |  |
| Building Solutions EMEA/LA |  | 536 |  |  | 422 |  |  | 958 |  |  | 466 |  |  | 468 |  |  | 934 |  |
| Building Solutions Asia Pacific |  | 448 |  |  | 175 |  |  | 623 |  |  | 320 |  |  | 274 |  |  | 594 |  |
| Global Products |  | 2,290 |  |  | — |  |  | 2,290 |  |  | 1,974 |  |  | — |  |  | 1,974 |  |
| Total |  | $ | 4,617 |  |  | $ | 1,481 |  |  | $ | 6,098 |  |  | $ | 4,032 |  |  | $ | 1,562 |  |  | $ | 5,594 |  |

- changed (2022-08-04):
[0000833444-22-000036:note_history:51]
|  |  | Nine Months Ended June 30, |
|  |  | 2022 |  | 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 4,123 |  |  | $ | 2,682 |  |  | $ | 6,805 |  |  | $ | 3,869 |  |  | $ | 2,469 |  |  | $ | 6,338 |  |
| Building Solutions EMEA/LA |  | 1,617 |  |  | 1,252 |  |  | 2,869 |  |  | 1,441 |  |  | 1,442 |  |  | 2,883 |  |
| Building Solutions Asia Pacific |  | 1,442 |  |  | 521 |  |  | 1,963 |  |  | 1,067 |  |  | 834 |  |  | 1,901 |  |
| Global Products |  | 6,937 |  |  | — |  |  | 6,937 |  |  | 6,154 |  |  | — |  |  | 6,154 |  |
| Total |  | $ | 14,119 |  |  | $ | 4,455 |  |  | $ | 18,574 |  |  | $ | 12,531 |  |  | $ | 4,745 |  |  | $ | 17,276 |  |
  (was, 2022-05-04, similarity 0.9434):
[0000833444-22-000017:note_history:51]
|  |  | Six Months Ended March 31, 2022 |  | Six Months Ended March 31, 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 2,642 |  |  | $ | 1,737 |  |  | $ | 4,379 |  |  | $ | 2,514 |  |  | $ | 1,612 |  |  | $ | 4,126 |  |
| Building Solutions EMEA/LA |  | 1,080 |  |  | 837 |  |  | 1,917 |  |  | 934 |  |  | 948 |  |  | 1,882 |  |
| Building Solutions Asia Pacific |  | 949 |  |  | 349 |  |  | 1,298 |  |  | 654 |  |  | 544 |  |  | 1,198 |  |
| Global Products |  | 4,366 |  |  | — |  |  | 4,366 |  |  | 3,729 |  |  | — |  |  | 3,729 |  |
| Total |  | $ | 9,037 |  |  | $ | 2,923 |  |  | $ | 11,960 |  |  | $ | 7,831 |  |  | $ | 3,104 |  |  | $ | 10,935 |  |

- changed (2022-08-04):
[0000833444-22-000036:note_history:52]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 1,889 |  |  | $ | 1,781 |  |  | $ | 5,030 |  |  | $ | 4,373 |  |
| Fire & Security |  | 610 |  |  | 580 |  |  | 1,732 |  |  | 1,605 |  |
| Industrial Refrigeration |  | 72 |  |  | 64 |  |  | 175 |  |  | 176 |  |
| Total |  | $ | 2,571 |  |  | $ | 2,425 |  |  | $ | 6,937 |  |  | $ | 6,154 |  |
  (was, 2022-05-04, similarity 0.9388):
[0000833444-22-000017:note_history:52]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 1,658 |  |  | $ | 1,374 |  |  | $ | 3,141 |  |  | $ | 2,592 |  |
| Fire & Security |  | 578 |  |  | 537 |  |  | 1,122 |  |  | 1,025 |  |
| Industrial Refrigeration |  | 54 |  |  | 63 |  |  | 103 |  |  | 112 |  |
| Total |  | $ | 2,290 |  |  | $ | 1,974 |  |  | $ | 4,366 |  |  | $ | 3,729 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-08-04):
[0000833444-22-000036:note_history:53]
|  |  | Three Months Ended June 30, |
|  |  | 2022 |  | 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,481 |  |  | $ | 945 |  |  | $ | 2,426 |  |  | $ | 1,355 |  |  | $ | 857 |  |  | $ | 2,212 |  |
| Building Solutions EMEA/LA |  | 537 |  |  | 415 |  |  | 952 |  |  | 507 |  |  | 494 |  |  | 1,001 |  |
| Building Solutions Asia Pacific |  | 493 |  |  | 172 |  |  | 665 |  |  | 413 |  |  | 290 |  |  | 703 |  |
| Global Products |  | 2,571 |  |  | — |  |  | 2,571 |  |  | 2,425 |  |  | — |  |  | 2,425 |  |
| Total |  | $ | 5,082 |  |  | $ | 1,532 |  |  | $ | 6,614 |  |  | $ | 4,700 |  |  | $ | 1,641 |  |  | $ | 6,341 |  |
  (was, 2022-05-04, similarity 0.948):
[0000833444-22-000017:note_history:53]
|  |  | Three Months Ended March 31, 2022 |  | Three Months Ended March 31, 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,343 |  |  | $ | 884 |  |  | $ | 2,227 |  |  | $ | 1,272 |  |  | $ | 820 |  |  | $ | 2,092 |  |
| Building Solutions EMEA/LA |  | 536 |  |  | 422 |  |  | 958 |  |  | 466 |  |  | 468 |  |  | 934 |  |
| Building Solutions Asia Pacific |  | 448 |  |  | 175 |  |  | 623 |  |  | 320 |  |  | 274 |  |  | 594 |  |
| Global Products |  | 2,290 |  |  | — |  |  | 2,290 |  |  | 1,974 |  |  | — |  |  | 1,974 |  |
| Total |  | $ | 4,617 |  |  | $ | 1,481 |  |  | $ | 6,098 |  |  | $ | 4,032 |  |  | $ | 1,562 |  |  | $ | 5,594 |  |

- changed (2022-08-04):
[0000833444-22-000036:note_history:54]
|  |  | Nine Months Ended June 30, |
|  |  | 2022 |  | 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 4,123 |  |  | $ | 2,682 |  |  | $ | 6,805 |  |  | $ | 3,869 |  |  | $ | 2,469 |  |  | $ | 6,338 |  |
| Building Solutions EMEA/LA |  | 1,617 |  |  | 1,252 |  |  | 2,869 |  |  | 1,441 |  |  | 1,442 |  |  | 2,883 |  |
| Building Solutions Asia Pacific |  | 1,442 |  |  | 521 |  |  | 1,963 |  |  | 1,067 |  |  | 834 |  |  | 1,901 |  |
| Global Products |  | 6,937 |  |  | — |  |  | 6,937 |  |  | 6,154 |  |  | — |  |  | 6,154 |  |
| Total |  | $ | 14,119 |  |  | $ | 4,455 |  |  | $ | 18,574 |  |  | $ | 12,531 |  |  | $ | 4,745 |  |  | $ | 17,276 |  |
  (was, 2022-05-04, similarity 0.9434):
[0000833444-22-000017:note_history:54]
|  |  | Six Months Ended March 31, 2022 |  | Six Months Ended March 31, 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 2,642 |  |  | $ | 1,737 |  |  | $ | 4,379 |  |  | $ | 2,514 |  |  | $ | 1,612 |  |  | $ | 4,126 |  |
| Building Solutions EMEA/LA |  | 1,080 |  |  | 837 |  |  | 1,917 |  |  | 934 |  |  | 948 |  |  | 1,882 |  |
| Building Solutions Asia Pacific |  | 949 |  |  | 349 |  |  | 1,298 |  |  | 654 |  |  | 544 |  |  | 1,198 |  |
| Global Products |  | 4,366 |  |  | — |  |  | 4,366 |  |  | 3,729 |  |  | — |  |  | 3,729 |  |
| Total |  | $ | 9,037 |  |  | $ | 2,923 |  |  | $ | 11,960 |  |  | $ | 7,831 |  |  | $ | 3,104 |  |  | $ | 10,935 |  |

- changed (2022-08-04):
[0000833444-22-000036:note_history:55]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 1,889 |  |  | $ | 1,781 |  |  | $ | 5,030 |  |  | $ | 4,373 |  |
| Fire & Security |  | 610 |  |  | 580 |  |  | 1,732 |  |  | 1,605 |  |
| Industrial Refrigeration |  | 72 |  |  | 64 |  |  | 175 |  |  | 176 |  |
| Total |  | $ | 2,571 |  |  | $ | 2,425 |  |  | $ | 6,937 |  |  | $ | 6,154 |  |
  (was, 2022-05-04, similarity 0.9388):
[0000833444-22-000017:note_history:55]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 1,658 |  |  | $ | 1,374 |  |  | $ | 3,141 |  |  | $ | 2,592 |  |
| Fire & Security |  | 578 |  |  | 537 |  |  | 1,122 |  |  | 1,025 |  |
| Industrial Refrigeration |  | 54 |  |  | 63 |  |  | 103 |  |  | 112 |  |
| Total |  | $ | 2,290 |  |  | $ | 1,974 |  |  | $ | 4,366 |  |  | $ | 3,729 |  |

- changed (2022-08-04):
[0000833444-22-000036:note_history:56]
|  |  | Location of contract balances |  | June 30, 2022 |  | September 30, 2021 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,951 |  |  | $ | 1,718 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 104 |  |  | 99 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,846) |  |  | (1,637) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (278) |  |  | (269) |  |  |  |
  (was, 2022-05-04, similarity 0.9892):
[0000833444-22-000017:note_history:56]
|  |  | Location of contract balances |  | March 31, 2022 |  | September 30, 2021 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,851 |  |  | $ | 1,718 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 90 |  |  | 99 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,971) |  |  | (1,637) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (285) |  |  | (269) |  |  |  |

- added (2022-08-04):
[0000833444-22-000036:note_history:57]
For the three months ended June 30, 2022 and 2021, the Company recognized revenue of $193 million and $149 million, respectively, that was included in the beginning of period contract liability balance. For the nine months ended June 30, 2022 and 2021, the Company recognized revenue of $1,252 million and $1,084 million, respectively, that was included in the beginning of period contract liability balance.

- changed (2022-08-04):
[0000833444-22-000036:note_history:58]
A performance obligation is a distinct good, service, or a bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.
  (was, 2022-05-04, similarity 0.8508):
[0000833444-22-000017:note_history:58]
A performance obligation is a distinct good, service, or a bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is

- changed (2022-08-04):
[0000833444-22-000036:note_history:59]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of June 30, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $17.5 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.
  (was, 2022-05-04, similarity 0.9954):
[0000833444-22-000017:note_history:59]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of March 31, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $17.3 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

- changed (2022-08-04):
[0000833444-22-000036:note_history:60]
|  |  | June 30, 2022 |  | September 30, 2021 |  |  |
| Other current assets |  | $ | 169 |  |  | $ | 149 |  |  |  |
| Other noncurrent assets |  | 122 |  |  | 117 |  |  |  |
| Total |  | $ | 291 |  |  | $ | 266 |  |  |  |
  (was, 2022-05-04, similarity 0.9746):
[0000833444-22-000017:note_history:60]
|  |  | March 31, 2022 |  | September 30, 2021 |  |  |
| Other current assets |  | $ | 150 |  |  | $ | 149 |  |  |  |
| Other noncurrent assets |  | 116 |  |  | 117 |  |  |  |
| Total |  | $ | 266 |  |  | $ | 266 |  |  |  |

- added (2022-08-04):
[0000833444-22-000036:note_history:61]
During both the three months ended June 30, 2022 and 2021, the Company recognized amortization expense of $48 million, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2022 and 2021, the Company 
recognized amortization expense of $145 million and $136 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and nine months ended June 30, 2022 and 2021.

- removed (2022-08-04):
[0000833444-22-000017:note_history:62]
For the three months ended March 31, 2022 and March 31, 2021, the Company recognized revenue of $308 million and $221 million, respectively, that was included in the beginning of period contract liability balance. For the six months ended March 31, 2022 and March 31, 2021, the Company recognized revenue of $1,059 million and $935 million, respectively, that was included in the beginning of period contract liability balance.

- removed (2022-08-04):
[0000833444-22-000017:note_history:63]
allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

- removed (2022-08-04):
[0000833444-22-000017:note_history:64]
During both the three months ended March 31, 2022 and 2021, the Company recognized amortization expense of $47 million related to costs to obtain or fulfill a contract. During the six months ended March 31, 2022 and 2021, the Company recognized amortization expense of $97 million and $88 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and six months ended March 31, 2022 and 2021.
