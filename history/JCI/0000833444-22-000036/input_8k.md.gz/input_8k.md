# JCI 8-K — 0000833444-22-000034 filed 2022-08-04

## item codes, every 8-K on or before 2022-08-04

- 2022-08-04 0000833444-22-000034 — 2.02, 9.01
- 2022-07-06 0000833444-22-000029 — 5.02, 9.01
- 2022-06-30 0000833444-22-000027 — 5.02
- 2022-05-04 0000833444-22-000014 — 2.02, 9.01
- 2022-03-11 0001193125-22-073382 — 5.07
- 2022-02-15 0000833444-22-000010 — 5.02
- 2022-02-02 0000833444-22-000003 — 2.02, 9.01
- 2021-12-10 0000833444-21-000050 — 5.02
- 2021-11-05 0000833444-21-000043 — 2.02, 9.01
- 2021-09-16 0001193125-21-275152 — 1.01, 8.01, 9.01
- 2021-07-30 0000833444-21-000038 — 2.02, 9.01
- 2021-05-03 0000833444-21-000023 — 8.01
- 2021-04-30 0000833444-21-000017 — 2.02, 9.01
- 2021-03-11 0000833444-21-000013 — 5.02, 5.07, 9.01
- 2021-02-17 0001193125-21-045768 — 7.01, 9.01
- 2021-01-29 0000833444-21-000009 — 2.02, 9.01
- 2021-01-07 0000833444-21-000004 — 7.01
- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2022-08-04

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-22-000034:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq3fy22.htm
EX-99.1

[0000833444-22-000034:8k_2_02:2]
Document

[0000833444-22-000034:8k_2_02:3]
Exhibit 99.1

[0000833444-22-000034:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-22-000034:8k_2_02:5]
Johnson Controls Delivers Strong Q3 Orders and on Track to Achieve Solid Full Year Revenue and EPS Growth Performance

[0000833444-22-000034:8k_2_02:6]
________________________________________________________________________________

[0000833444-22-000034:8k_2_02:7]
▪GAAP EPS of $0.55; Adjusted EPS of $0.85, up 3% versus prior year

[0000833444-22-000034:8k_2_02:8]
▪Reported sales +4% versus prior year; +8% organically

[0000833444-22-000034:8k_2_02:9]
▪Strong Order momentum continues — Total Field Orders +8% year-over-year; +11% organically

[0000833444-22-000034:8k_2_02:10]
▪Record Field Backlog of $11.1 billion, increased 13% organically year-over-year

[0000833444-22-000034:8k_2_02:11]
▪Completed approximately $400 million in share repurchases in the quarter; $1.4 billion year-to-date

[0000833444-22-000034:8k_2_02:12]
▪Fiscal 2022 adjusted EPS guidance refined to $2.98 to $3.02, from $2.95 to $3.05 previously, absorbing 6 cents of FX headwinds versus our prior guide

[0000833444-22-000034:8k_2_02:13]
________________________________________________________________________________

[0000833444-22-000034:8k_2_02:14]
CORK, Ireland, August 4, 2022 -- Johnson Controls International plc (NYSE: JCI), a global leader for smart, healthy and sustainable buildings, today reported fiscal third quarter 2022 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.55. Excluding special items, adjusted EPS from continuing operations was $0.85, up 3% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-22-000034:8k_2_02:15]
Sales of $6.6 billion increased 4% compared to the prior year on an as reported basis and grew 8% organically. GAAP net income from continuing operations was $379 million. Adjusted net income from continuing operations of $594 million was flat versus the prior year. Earnings before interest and taxes (“EBIT”) was $553 million and EBIT margin was 8.4%. Adjusted EBIT was $809 million and adjusted EBIT margin was 12.2%, down 120 basis points versus the prior year.

[0000833444-22-000034:8k_2_02:16]
“During the fiscal third quarter, we continued to execute on our transformative strategy, delivering record order velocity and sequential margin improvement. Further, robust demand has persisted as our customers look to us for healthy, smart, and sustainable building solutions,” said George Oliver, Chairman and Chief Executive Officer. “Our teams remained resilient, as they diligently advanced our supply chain management efforts to mitigate disruptions.”

[0000833444-22-000034:8k_2_02:17]
“We are accelerating our digital transformation efforts and have made great progress in positioning the company to capitalize on key growth vectors across sustainable buildings and services led by connectivity with OpenBlue. We are confident that our innovative solutions will support long-term profitable growth and value creation for our customers and shareholders for years to come.”

[0000833444-22-000034:8k_2_02:18]
“We had another strong quarter in both order growth and revenue, despite a tough prior year compare,” said Olivier Leonetti, Chief Financial Officer. “We continue to make progress with our cost saving initiatives and investments in key technologies that support our growth both organically and inorganically. The combination of our quarterly performance and business outlook puts us in a great position to deliver our full-year targets and carry the momentum into 2023.”

[0000833444-22-000034:8k_2_02:19]
Page 1 of 20

[0000833444-22-000034:8k_2_02:20]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-22-000034:8k_2_02:21]
($ millions, except per-share amounts)

[0000833444-22-000034:8k_2_02:22]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal third quarter of 2021. Effective October 1, 2021, the Company’s Marine business, previously reported across the Building Solutions Asia Pacific, Global Products and Building Solutions EMEA/LA segments, is now managed and reported under the Building Solutions EMEA/LA segment. Historical information has been re-cast to present the comparative periods on a consistent basis.

[0000833444-22-000034:8k_2_02:23]
Organic sales growth, adjusted sales, organic segment EBITA growth, total segment EBITA, adjusted segment EBITA, adjusted corporate expense, EBIT, adjusted EBIT, adjusted net income from continuing operations, adjusted EPS from continuing operations, and free cash flow are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes. A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-22-000034:8k_2_02:24]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  |  |  |  |  |  |
| Sales |  | $6,341 |  | $6,614 |  | $6,344 |  | $6,614 |  |  |  |  |  |  |
| Segment EBITA |  | 1,020 |  | 998 |  | 1,027 |  | 998 |  |  |  |  |  |  |
| EBIT |  | 825 |  | 553 |  | 848 |  | 809 |  |  |  |  |  |  |
| Net income from continuing operations |  | 574 |  | 379 |  | 598 |  | 594 |  |  |  |  |  |  |
| Diluted EPS from continuing operations |  | $0.80 |  | $0.55 |  | $0.83 |  | $0.85 |  |  |  |  |  |  |

[0000833444-22-000034:8k_2_02:25]
Page 2 of 20

[0000833444-22-000034:8k_2_02:26]
SEGMENT RESULTS

[0000833444-22-000034:8k_2_02:27]
Building Solutions North America

[0000833444-22-000034:8k_2_02:28]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  |  |  |  |  |  |
| Sales |  | $2,212 |  | $2,426 |  | $2,212 |  | $2,426 |  |  |  |  |  |  |
| Segment EBITA |  | 326 |  | 260 |  | 326 |  | 260 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 14.7% |  | 10.7% |  | 14.7% |  | 10.7% |  |  |  |  |  |  |

[0000833444-22-000034:8k_2_02:29]
Sales in the quarter of $2.4 billion increased 10% versus the prior year. Organic sales also increased 10% over the prior year, led by low double-digit growth in Service and strong growth in our HVAC & Controls platform.

[0000833444-22-000034:8k_2_02:30]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 15% year-over-year. Backlog at the end of the quarter of $7.2 billion increased 17% compared to the prior year, excluding M&A and adjusted for foreign currency.

[0000833444-22-000034:8k_2_02:31]
Adjusted segment EBITA was $260 million, down 20% versus the prior year. Adjusted segment EBITA margin of 10.7% declined 400 basis points versus the prior year as the benefit of the SG&A/COGS actions were more than offset by lower absorption related to supply chain challenges and labor constraints.

[0000833444-22-000034:8k_2_02:32]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-22-000034:8k_2_02:33]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  |  |  |  |  |  |
| Sales |  | $1,001 |  | $952 |  | $1,001 |  | $952 |  |  |  |  |  |  |
| Segment EBITA |  | 105 |  | 83 |  | 105 |  | 83 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 10.5% |  | 8.7% |  | 10.5% |  | 8.7% |  |  |  |  |  |  |

[0000833444-22-000034:8k_2_02:34]
Sales in the quarter of $952 million declined 5% versus the prior year. Organic sales grew 4% versus the prior year with high single-digit growth in Service and strong performance in our Fire & Security platforms. By region, strong organic growth in Europe was offset by a decline in Latin America.

[0000833444-22-000034:8k_2_02:35]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 8% year-over-year. Backlog at the end of the quarter of $2.2 billion increased 10% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-22-000034:8k_2_02:36]
Page 3 of 20

[0000833444-22-000034:8k_2_02:37]
Adjusted segment EBITA was $83 million, down 21% versus the prior year. Adjusted segment EBITA margin of 8.7% declined 180 basis points versus the prior year, as the benefit of SG&A/COGS actions and positive price/cost were more than offset by supply chain disruptions and continued FX headwinds.

[0000833444-22-000034:8k_2_02:38]
Building Solutions Asia Pacific

[0000833444-22-000034:8k_2_02:39]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  |  |  |  |  |  |
| Sales |  | $703 |  | $665 |  | $703 |  | $665 |  |  |  |  |  |  |
| Segment EBITA |  | 84 |  | 85 |  | 84 |  | 85 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 11.9% |  | 12.8% |  | 11.9% |  | 12.8% |  |  |  |  |  |  |

[0000833444-22-000034:8k_2_02:40]
Sales in the quarter of $665 million declined 5% versus the prior year. Sales declined 1% organically versus the prior year, a direct result of the Covid-19 lockdowns in China. Strong demand for Industrial Refrigeration equipment continued in Q3.

[0000833444-22-000034:8k_2_02:41]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 2% year-over-year. Backlog at the end of the quarter of $1.7 billion increased 1% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-22-000034:8k_2_02:42]
Adjusted segment EBITA was $85 million, up 1% versus the prior year. Adjusted segment EBITA margin of 12.8% expanded 90 basis points versus the prior year as positive price/cost and the benefit of SG&A/COGS actions more than offset lower volume leverage resulting from the Covid-19 lockdowns in China and continued FX headwinds.

[0000833444-22-000034:8k_2_02:43]
Page 4 of 20

[0000833444-22-000034:8k_2_02:44]
Global Products

[0000833444-22-000034:8k_2_02:45]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  |  |  |  |  |  |
| Sales |  | $2,425 |  | $2,571 |  | $2,428 |  | $2,571 |  |  |  |  |  |  |
| Segment EBITA |  | 505 |  | 570 |  | 512 |  | 570 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 20.8% |  | 22.2% |  | 21.1% |  | 22.2% |  |  |  |  |  |  |

[0000833444-22-000034:8k_2_02:46]
Sales in the quarter of $2.6 billion increased 6% versus the prior year. Organic sales grew 9% versus the prior year driven by strong pricing and broad-based demand for Commercial and Residential HVAC and Fire Detection products, partially offset by the lower volumes due to the supply chain constraints and the Covid-19 lockdowns in China.

[0000833444-22-000034:8k_2_02:47]
Adjusted segment EBITA was $570 million, up 11% versus the prior year. Adjusted segment EBITA margin of 22.2% expanded 110 basis points versus the prior year as positive price/cost, positive mix, and the benefit of SG&A/COGS actions were partially offset by supply chain inefficiencies and continued FX headwinds.

[0000833444-22-000034:8k_2_02:48]
Corporate

[0000833444-22-000034:8k_2_02:49]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  |  |  |  |  |  |
| Corporate Expense |  | ($70) |  | ($96) |  | ($70) |  | ($87) |  |  |  |  |  |  |

[0000833444-22-000034:8k_2_02:50]
Adjusted Corporate expense was $87 million in the quarter, an increase of 24% compared to the prior year.

[0000833444-22-000034:8k_2_02:51]
OTHER ITEMS

[0000833444-22-000034:8k_2_02:52]
During the quarter...

[0000833444-22-000034:8k_2_02:53]
▪Cash provided by operating activities from continuing operations was $487 million and capital expenditures were ($170) million, resulting in a free cash flow from continuing operations of $317 million.

[0000833444-22-000034:8k_2_02:54]
▪The Company repurchased 6.9 million shares for approximately $400 million. Year to date through June, the Company repurchased 21.4 million shares for approximately $1.4 billion.

[0000833444-22-000034:8k_2_02:55]
Page 5 of 20

[0000833444-22-000034:8k_2_02:56]
▪The Company recorded net pre-tax mark-to-market losses of $126 million related primarily to the remeasurement of the Company’s pension and postretirement plan assets and restricted asbestos investments.

[0000833444-22-000034:8k_2_02:57]
▪The Company recorded pre-tax restructuring and impairment costs of $121 million, including the impairment of assets associated with a business classified as held for sale in the quarter.

[0000833444-22-000034:8k_2_02:58]
FOURTH QUARTER GUIDANCE

[0000833444-22-000034:8k_2_02:59]
The Company initiated fiscal 2022 fourth quarter guidance:

[0000833444-22-000034:8k_2_02:60]
▪Organic revenue growth of 9% to 10% year-over-year

[0000833444-22-000034:8k_2_02:61]
▪Adjusted segment EBITA margin improvement of 40 to 60 basis points, year-over-year

[0000833444-22-000034:8k_2_02:62]
▪Adjusted EPS before special items of $0.96 to $1.00

[0000833444-22-000034:8k_2_02:63]
FULL YEAR GUIDANCE

[0000833444-22-000034:8k_2_02:64]
The Company revised fiscal 2022 full year EPS guidance:

[0000833444-22-000034:8k_2_02:65]
▪Organic revenue growth of 8% to 9% year-over-year

[0000833444-22-000034:8k_2_02:66]
▪Adjusted segment EBITA margin down 10 to 20 basis points, year-over-year

[0000833444-22-000034:8k_2_02:67]
▪Adjusted EPS before special items of $2.98 to $3.02; representing 12% to 14% growth year-over-year

[0000833444-22-000034:8k_2_02:68]
CONFERENCE CALL & WEBCAST INFO

[0000833444-22-000034:8k_2_02:69]
Johnson Controls will host a conference call to discuss this quarter’s results at 8:30 a.m. ET today, which can be accessed by dialing 888-324-9610 (in the United States) or 630-395-0255 (outside the United States), or via webcast. The passcode is “Johnson Controls”. A slide presentation will accompany the prepared remarks and has been posted on the investor relations section of the Johnson Controls website at https://investors.johnsoncontrols.com/news-and-events/events-and-presentations. A replay will be made available approximately two hours following the conclusion of the conference call.

[0000833444-22-000034:8k_2_02:70]
About Johnson Controls:

[0000833444-22-000034:8k_2_02:71]
At Johnson Controls (NYSE:JCI), we transform the environments where people live, work, learn and play. As the global leader in smart, healthy and sustainable buildings, our mission is to reimagine the performance of buildings to serve people, places and the planet.

[0000833444-22-000034:8k_2_02:72]
Page 6 of 20

[0000833444-22-000034:8k_2_02:73]
Building on a proud history of more than 135 years of innovation, we deliver the blueprint of the future for industries such as healthcare, schools, data centers, airports, stadiums, manufacturing and beyond through OpenBlue, our comprehensive digital offering. Today, with a global team of 100,000 experts in more than 150 countries, Johnson Controls offers the world`s largest portfolio of building technology and software as well as service solutions from some of the most trusted names in the industry. Visit www.johnsoncontrols.com for more information and follow @Johnson Controls on social platforms.

[0000833444-22-000034:8k_2_02:74]
JOHNSON CONTROLS CONTACTS:

[0000833444-22-000034:8k_2_02:75]
| INVESTOR CONTACTS: | MEDIA CONTACTS: |  |  |  |
| Michael Gates | Danielle Canzanella |  |  |  |
| Direct: +1 414.524.5785 | Direct: +1 203.499.8297 |  |  |  |
| Email: michael.j.gates@jci.com | Email: danielle.canzanella@jci.com |  |  |  |

[0000833444-22-000034:8k_2_02:76]
###

[0000833444-22-000034:8k_2_02:77]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-22-000034:8k_2_02:78]
Page 7 of 20

[0000833444-22-000034:8k_2_02:79]
realize the expected benefits and synergies of recent portfolio transactions; the outcome of litigation and governmental proceedings; the ability to hire and retain senior management and other key personnel; the tax treatment of recent portfolio transactions; significant transaction costs and/or unknown liabilities associated with such transactions; fluctuations in currency exchange rates; labor shortages, work stoppages, union negotiations, labor disputes and other matters associated with the labor force; and the cancellation of or changes to commercial arrangements. A detailed discussion of risks related to Johnson Controls business is included in the section entitled “Risk Factors” in Johnson Controls Annual Report on Form 10-K for the 2021 fiscal year filed with the SEC on November 15, 2021, which is available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. The description of certain of these risks is supplemented in Item 1A of Part II of Johnson Controls subsequently filed Quarterly Reports on Form 10-Q. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-22-000034:8k_2_02:80]
###

[0000833444-22-000034:8k_2_02:81]
Non-GAAP Financial Information

[0000833444-22-000034:8k_2_02:82]
This press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include restructuring and impairment costs, net mark-to-market adjustments, Silent-Aire other nonrecurring items, Silent-Aire earn-out adjustment, charges associated with the suspension of operations in Russia, transaction / separation costs, Power Solutions divestiture reserve adjustment and discrete tax items. Financial information regarding organic sales growth, adjusted sales, EBIT, EBIT margin, adjusted EBIT, adjusted EBIT margin, organic segment EBITA growth, total segment EBITA, adjusted segment EBITA, adjusted segment EBITA margin, adjusted Corporate expense, free cash flow, free cash flow conversion and adjusted net income from continuing operations are also presented, which are non-GAAP performance measures. Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of Johnson Controls. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.  For further information on the calculation of the non-GAAP measures and a reconciliation of these non-GAAP measures, refer to the attached footnotes.

[0000833444-22-000034:8k_2_02:83]
###

[0000833444-22-000034:8k_2_02:84]
Page 8 of 20

[0000833444-22-000034:8k_2_02:85]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |  |
|  |  | Three Months Ended June 30, |  |
|  |  | 2022 |  |  | 2021 |  |
| Net sales | $ | 6,614 |  |  |  | $ | 6,341 |  |  |
| Cost of sales | 4,414 |  |  |  | 4,144 |  |  |
|  | Gross profit | 2,200 |  |  |  | 2,197 |  |  |
| Selling, general and administrative expenses | (1,589) |  |  |  | (1,367) |  |  |
| Restructuring and impairment costs | (121) |  |  |  | (79) |  |  |
| Net financing charges | (49) |  |  |  | (56) |  |  |
| Equity income | 63 |  |  |  | 74 |  |  |
| Income from continuing operations before income taxes | 504 |  |  |  | 769 |  |  |
| Income tax provision | 61 |  |  |  | 108 |  |  |
| Income from continuing operations | 443 |  |  |  | 661 |  |  |
| Income from discontinued operations, net of tax | — |  |  |  | — |  |  |
| Net income | 443 |  |  |  | 661 |  |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 64 |  |  |  | 87 |  |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |  |
| Net income attributable to JCI | $ | 379 |  |  |  | $ | 574 |  |  |
| Income from continuing operations | $ | 379 |  |  |  | $ | 574 |  |  |
| Income from discontinued operations | — |  |  |  | — |  |  |
| Net income attributable to JCI | $ | 379 |  |  |  | $ | 574 |  |  |
| Diluted earnings per share from continuing operations | $ | 0.55 |  |  |  | $ | 0.80 |  |  |
| Diluted earnings per share from discontinued operations | — |  |  |  | — |  |  |
| Diluted earnings per share | $ | 0.55 |  |  |  | $ | 0.80 |  |  |
| Diluted weighted average shares | 694.9 |  |  |  | 719.7 |  |  |
| Shares outstanding at period end | 688.8 |  |  |  | 712.2 |  |  |

[0000833444-22-000034:8k_2_02:86]
Page 9 of 20

[0000833444-22-000034:8k_2_02:87]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Nine Months Ended June 30, |
|  |  | 2022 |  |  | 2021 |
| Net sales | $ | 18,574 |  |  |  | $ | 17,276 |  |
| Cost of sales | 12,526 |  |  |  | 11,408 |  |
|  | Gross profit | 6,048 |  |  |  | 5,868 |  |
| Selling, general and administrative expenses | (4,412) |  |  |  | (3,914) |  |
| Restructuring and impairment costs | (554) |  |  |  | (175) |  |
| Net financing charges | (153) |  |  |  | (159) |  |
| Equity income | 175 |  |  |  | 188 |  |
| Income from continuing operations before income taxes | 1,104 |  |  |  | 1,808 |  |
| Income tax provision | 190 |  |  |  | 378 |  |
| Income from continuing operations | 914 |  |  |  | 1,430 |  |
| Income from discontinued operations, net of tax | — |  |  |  | 124 |  |
| Net income | 914 |  |  |  | 1,554 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 143 |  |  |  | 186 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |
| Net income attributable to JCI | $ | 771 |  |  |  | $ | 1,368 |  |
| Income from continuing operations | $ | 771 |  |  |  | $ | 1,244 |  |
| Income from discontinued operations | — |  |  |  | 124 |  |
| Net income attributable to JCI | $ | 771 |  |  |  | $ | 1,368 |  |
| Diluted earnings per share from continuing operations | $ | 1.10 |  |  |  | $ | 1.72 |  |
| Diluted earnings per share from discontinued operations | — |  |  |  | 0.17 |  |
| Diluted earnings per share | $ | 1.10 |  |  |  | $ | 1.89 |  |
| Diluted weighted average shares | 702.4 |  |  |  | 722.5 |  |
| Shares outstanding at period end | 688.8 |  |  |  | 712.2 |  |

[0000833444-22-000034:8k_2_02:88]
Page 10 of 20

[0000833444-22-000034:8k_2_02:89]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | June 30,2022 |  | September 30,2021 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 1,506 |  |  | $ | 1,336 |  |
| Accounts receivable - net | 5,850 |  |  | 5,613 |  |
| Inventories | 2,574 |  |  | 2,057 |  |
| Assets held for sale | 394 |  |  | — |  |
| Other current assets | 1,235 |  |  | 992 |  |
|  | Current assets | 11,559 |  |  | 9,998 |  |
| Property, plant and equipment - net | 2,962 |  |  | 3,228 |  |
| Goodwill | 17,725 |  |  | 18,335 |  |
| Other intangible assets - net | 4,764 |  |  | 5,549 |  |
| Investments in partially-owned affiliates | 1,070 |  |  | 1,066 |  |
| Noncurrent assets held for sale | 892 |  |  | 156 |  |
| Other noncurrent assets | 3,352 |  |  | 3,558 |  |
|  | Total assets | $ | 42,324 |  |  | $ | 41,890 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 2,298 |  |  | $ | 234 |  |
| Accounts payable and accrued expenses | 4,999 |  |  | 4,754 |  |
| Liabilities held for sale | 261 |  |  | — |  |
| Other current liabilities | 4,325 |  |  | 4,110 |  |
|  | Current liabilities | 11,883 |  |  | 9,098 |  |
| Long-term debt | 7,194 |  |  | 7,506 |  |
| Other noncurrent liabilities | 6,055 |  |  | 6,533 |  |
| Noncurrent liabilities held for sale | 49 |  |  | — |  |
| Shareholders' equity attributable to JCI | 15,988 |  |  | 17,562 |  |
| Noncontrolling interests | 1,155 |  |  | 1,191 |  |
|  | Total liabilities and equity | $ | 42,324 |  |  | $ | 41,890 |  |

[0000833444-22-000034:8k_2_02:90]
Page 11 of 20

[0000833444-22-000034:8k_2_02:91]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended June 30, |
|  |  |  |  |  |  | 2022 |  |  | 2021 |
| Operating Activities |  |  |  |  |
| Net income from continuing operations attributable to JCI | $ | 379 |  |  |  | $ | 574 |  |
| Income from continuing operations attributable to noncontrolling interests | 64 |  |  |  | 87 |  |
| Net income from continuing operations | 443 |  |  |  | 661 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 201 |  |  |  | 208 |  |
|  |  | Pension and postretirement benefit expense (income) | 59 |  |  |  | (94) |  |
|  |  | Pension and postretirement contributions | (7) |  |  |  | (15) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (45) |  |  |  | 41 |  |
|  |  | Deferred income taxes | (144) |  |  |  | (19) |  |
|  |  | Non-cash restructuring and impairment costs | 69 |  |  |  | 40 |  |
|  |  | Other - net | 39 |  |  |  | (6) |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (331) |  |  |  | (324) |  |
|  |  |  |  | Inventories | (142) |  |  |  | 7 |  |
|  |  |  |  | Other assets | (70) |  |  |  | 60 |  |
|  |  |  |  | Restructuring reserves | 17 |  |  |  | (3) |  |
|  |  |  |  | Accounts payable and accrued liabilities | 299 |  |  |  | 344 |  |
|  |  |  |  | Accrued income taxes | 99 |  |  |  | (38) |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 487 |  |  |  | 862 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (170) |  |  |  | (127) |  |
| Acquisition of businesses, net of cash acquired | (112) |  |  |  | (697) |  |
| Other - net | 26 |  |  |  | 57 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (256) |  |  |  | (767) |  |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | 175 |  |  |  | (31) |  |
| Stock repurchases and retirements | (392) |  |  |  | (340) |  |
| Payment of cash dividends | (244) |  |  |  | (193) |  |
| Proceeds from the exercise of stock options | 2 |  |  |  | 27 |  |
| Dividends paid to noncontrolling interests | (3) |  |  |  | (32) |  |
| Employee equity-based compensation withholding taxes | — |  |  |  | (1) |  |
| Other - net | 47 |  |  |  | (1) |  |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (415) |  |  |  | (571) |  |
| Discontinued Operations |  |  |  |  |
| Net cash used by operating activities | — |  |  |  | (19) |  |
| Net cash used by investing activities | — |  |  |  | — |  |
| Net cash used by financing activities | — |  |  |  | — |  |
|  |  |  |  |  | Net cash flows used by discontinued operations | — |  |  |  | (19) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (95) |  |  |  | 58 |  |
| Changes in cash held for sale | — |  |  |  | — |  |
| Decrease in cash, cash equivalents and restricted cash | $ | (279) |  |  |  | $ | (437) |  |

[0000833444-22-000034:8k_2_02:92]
Page 12 of 20

[0000833444-22-000034:8k_2_02:93]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Nine Months Ended June 30, |
|  |  |  |  |  |  | 2022 |  |  | 2021 |
| Operating Activities |  |  |  |  |
| Net income from continuing operations attributable to JCI | $ | 771 |  |  |  | $ | 1,244 |  |
| Income from continuing operations attributable to noncontrolling interests | 143 |  |  |  | 186 |  |
| Net income from continuing operations | 914 |  |  |  | 1,430 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 633 |  |  |  | 627 |  |
|  |  | Pension and postretirement benefit expense (income) | 8 |  |  |  | (393) |  |
|  |  | Pension and postretirement contributions | (83) |  |  |  | (40) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (25) |  |  |  | (66) |  |
|  |  | Deferred income taxes | (241) |  |  |  | 6 |  |
|  |  | Non-cash restructuring and impairment costs | 430 |  |  |  | 94 |  |
|  |  | Other - net | 32 |  |  |  | (38) |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (637) |  |  |  | (157) |  |
|  |  |  |  | Inventories | (761) |  |  |  | (204) |  |
|  |  |  |  | Other assets | (276) |  |  |  | (30) |  |
|  |  |  |  | Restructuring reserves | (2) |  |  |  | (27) |  |
|  |  |  |  | Accounts payable and accrued liabilities | 788 |  |  |  | 854 |  |
|  |  |  |  | Accrued income taxes | 31 |  |  |  | (34) |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 811 |  |  |  | 2,022 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (430) |  |  |  | (324) |  |
| Acquisition of businesses, net of cash acquired | (236) |  |  |  | (707) |  |
| Business divestitures, net of cash divested | 16 |  |  |  | 19 |  |
| Other - net | 62 |  |  |  | 126 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (588) |  |  |  | (886) |  |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | 2,234 |  |  |  | (64) |  |
| Stock repurchases and retirements | (1,427) |  |  |  | (1,001) |  |
| Payment of cash dividends | (674) |  |  |  | (570) |  |
| Proceeds from the exercise of stock options | 15 |  |  |  | 160 |  |
| Dividends paid to noncontrolling interests | (121) |  |  |  | (133) |  |
| Cash paid to acquire a noncontrolling interest | — |  |  |  | (14) |  |
| Employee equity-based compensation withholding taxes | (49) |  |  |  | (30) |  |
| Other - net | 51 |  |  |  | 2 |  |
|  |  |  |  |  | Cash provided (used) by financing activities from continuing operations | 29 |  |  |  | (1,650) |  |
| Discontinued Operations |  |  |  |  |
| Net cash used by operating activities | (4) |  |  |  | (56) |  |
| Net cash used by investing activities | — |  |  |  | — |  |
| Net cash used by financing activities | — |  |  |  | — |  |
|  |  |  |  |  | Net cash flows used by discontinued operations | (4) |  |  |  | (56) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (49) |  |  |  | 67 |  |
| Changes in cash held for sale | — |  |  |  | — |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | $ | 199 |  |  |  | $ | (503) |  |

[0000833444-22-000034:8k_2_02:94]
Page 13 of 20

[0000833444-22-000034:8k_2_02:95]
FOOTNOTES

[0000833444-22-000034:8k_2_02:96]
1. Financial Summary

[0000833444-22-000034:8k_2_02:97]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, charges attributable to the suspension of operations in Russia, Silent-Aire earn-out adjustment, certain transaction/separation costs, and the net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plan assets. The financial results shown below are for continuing operations and exclude the Power Solutions business. Historical information has been re-cast for changes in the composition of reportable segments effective October 1, 2021, to present the comparative periods on a consistent basis.

[0000833444-22-000034:8k_2_02:98]
| (in millions; unaudited) | Three Months Ended June 30, |
|  | 2022 |  | 2021 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,426 |  |  | $ | 2,426 |  |  | $ | 2,212 |  |  | $ | 2,212 |  |
| Building Solutions EMEA/LA | 952 |  |  | 952 |  |  | 1,001 |  |  | 1,001 |  |
| Building Solutions Asia Pacific | 665 |  |  | 665 |  |  | 703 |  |  | 703 |  |
| Global Products | 2,571 |  |  | 2,571 |  |  | 2,425 |  |  | 2,428 |  |
| Net sales | $ | 6,614 |  |  | $ | 6,614 |  |  | $ | 6,341 |  |  | $ | 6,344 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 260 |  |  | $ | 260 |  |  | $ | 326 |  |  | $ | 326 |  |
| Building Solutions EMEA/LA | 83 |  |  | 83 |  |  | 105 |  |  | 105 |  |
| Building Solutions Asia Pacific | 85 |  |  | 85 |  |  | 84 |  |  | 84 |  |
| Global Products | 570 |  |  | 570 |  |  | 505 |  |  | 512 |  |
| Segment EBITA | 998 |  |  | 998 |  |  | 1,020 |  |  | 1,027 |  |
| Corporate expenses (2) | (96) |  |  | (87) |  |  | (70) |  |  | (70) |  |
| Amortization of intangible assets (3) | (102) |  |  | (102) |  |  | (112) |  |  | (109) |  |
| Net mark-to-market adjustments (4) | (126) |  |  | — |  |  | 66 |  |  | — |  |
| Restructuring and impairment costs (5) | (121) |  |  | — |  |  | (79) |  |  | — |  |
| EBIT (6) | 553 |  |  | 809 |  |  | 825 |  |  | 848 |  |
| EBIT margin | 8.4 | % |  | 12.2 | % |  | 13.0 | % |  | 13.4 | % |
| Net financing charges | (49) |  |  | (49) |  |  | (56) |  |  | (56) |  |
| Income from continuing operations before income taxes | 504 |  |  | 760 |  |  | 769 |  |  | 792 |  |
| Income tax provision (7) | (61) |  |  | (102) |  |  | (108) |  |  | (107) |  |
| Income from continuing operations | 443 |  |  | 658 |  |  | 661 |  |  | 685 |  |
| Income from continuing operations attributable to noncontrolling interests (8) | (64) |  |  | (64) |  |  | (87) |  |  | (87) |  |
| Net income from continuing operations attributable to JCI | $ | 379 |  |  | $ | 594 |  |  | $ | 574 |  |  | $ | 598 |  |

[0000833444-22-000034:8k_2_02:99]
| (in millions; unaudited) | Nine Months Ended June 30, |
|  | 2022 |  | 2021 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 6,805 |  |  | $ | 6,805 |  |  | $ | 6,338 |  |  | $ | 6,338 |  |
| Building Solutions EMEA/LA | 2,869 |  |  | 2,869 |  |  | 2,883 |  |  | 2,883 |  |
| Building Solutions Asia Pacific | 1,963 |  |  | 1,963 |  |  | 1,901 |  |  | 1,901 |  |
| Global Products | 6,937 |  |  | 6,937 |  |  | 6,154 |  |  | 6,157 |  |
| Net sales | $ | 18,574 |  |  | $ | 18,574 |  |  | $ | 17,276 |  |  | $ | 17,279 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 745 |  |  | $ | 745 |  |  | $ | 847 |  |  | $ | 847 |  |
| Building Solutions EMEA/LA | 266 |  |  | 277 |  |  | 291 |  |  | 291 |  |
| Building Solutions Asia Pacific | 227 |  |  | 227 |  |  | 234 |  |  | 234 |  |
| Global Products | 1,283 |  |  | 1,240 |  |  | 1,001 |  |  | 1,008 |  |
| Segment EBITA | 2,521 |  |  | 2,489 |  |  | 2,373 |  |  | 2,380 |  |
| Corporate expenses (2) | (226) |  |  | (217) |  |  | (207) |  |  | (207) |  |
| Amortization of intangible assets (3) | (326) |  |  | (313) |  |  | (320) |  |  | (317) |  |
| Net mark-to-market adjustments (4) | (158) |  |  | — |  |  | 296 |  |  | — |  |
| Restructuring and impairment costs (5) | (554) |  |  | — |  |  | (175) |  |  | — |  |
| EBIT (6) | 1,257 |  |  | 1,959 |  |  | 1,967 |  |  | 1,856 |  |
| EBIT margin | 6.8 | % |  | 10.5 | % |  | 11.4 | % |  | 10.7 | % |
| Net financing charges | (153) |  |  | (153) |  |  | (159) |  |  | (159) |  |
| Income from continuing operations before income taxes | 1,104 |  |  | 1,806 |  |  | 1,808 |  |  | 1,697 |  |
| Income tax provision (7) | (190) |  |  | (243) |  |  | (378) |  |  | (229) |  |
| Income from continuing operations | 914 |  |  | 1,563 |  |  | 1,430 |  |  | 1,468 |  |
| Income from continuing operations attributable to noncontrolling interests (8) | (143) |  |  | (148) |  |  | (186) |  |  | (186) |  |
| Net income from continuing operations attributable to JCI | $ | 771 |  |  | $ | 1,415 |  |  | $ | 1,244 |  |  | $ | 1,282 |  |

[0000833444-22-000034:8k_2_02:100]
(1) The Company's press release contains financial information regarding adjusted net sales, total segment EBITA, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted net sales and adjusted segment EBITA excludes special items because these revenues and/or costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-22-000034:8k_2_02:101]
A reconciliation of total segment EBITA to income from continuing operations is shown earlier within this footnote. The following is the three months ended June 30, 2022 and 2021 reconciliation of net sales, total segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-22-000034:8k_2_02:102]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales as reported | $ | 2,426 |  |  | $ | 2,212 |  |  | $ | 952 |  |  | $ | 1,001 |  |  | $ | 665 |  |  | $ | 703 |  |  | $ | 2,571 |  |  | $ | 2,425 |  |  | $ | 6,614 |  |  | $ | 6,341 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring Silent-Aire purchase accounting impacts | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Adjusted net sales | $ | 2,426 |  |  | $ | 2,212 |  |  | $ | 952 |  |  | $ | 1,001 |  |  | $ | 665 |  |  | $ | 703 |  |  | $ | 2,571 |  |  | $ | 2,428 |  |  | $ | 6,614 |  |  | $ | 6,344 |  |
| Segment EBITA as reported | $ | 260 |  |  | $ | 326 |  |  | $ | 83 |  |  | $ | 105 |  |  | $ | 85 |  |  | $ | 84 |  |  | $ | 570 |  |  | $ | 505 |  |  | $ | 998 |  |  | $ | 1,020 |  |
| Segment EBITA margin as reported | 10.7 | % |  | 14.7 | % |  | 8.7 | % |  | 10.5 | % |  | 12.8 | % |  | 11.9 | % |  | 22.2 | % |  | 20.8 | % |  | 15.1 | % |  | 16.1 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring Silent-Aire purchase accounting impacts and other costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Adjusted segment EBITA | $ | 260 |  |  | $ | 326 |  |  | $ | 83 |  |  | $ | 105 |  |  | $ | 85 |  |  | $ | 84 |  |  | $ | 570 |  |  | $ | 512 |  |  | $ | 998 |  |  | $ | 1,027 |  |
| Adjusted segment EBITA margin | 10.7 | % |  | 14.7 | % |  | 8.7 | % |  | 10.5 | % |  | 12.8 | % |  | 11.9 | % |  | 22.2 | % |  | 21.1 | % |  | 15.1 | % |  | 16.2 | % |

[0000833444-22-000034:8k_2_02:103]
Page 14 of 20

[0000833444-22-000034:8k_2_02:104]
The following is the nine months ended June 30, 2022 and 2021 reconciliation of net sales, total segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-22-000034:8k_2_02:105]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales as reported | $ | 6,805 |  |  | $ | 6,338 |  |  | $ | 2,869 |  |  | $ | 2,883 |  |  | $ | 1,963 |  |  | $ | 1,901 |  |  | $ | 6,937 |  |  | $ | 6,154 |  |  | $ | 18,574 |  |  | $ | 17,276 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring Silent-Aire purchase accounting impacts | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Adjusted net sales | $ | 6,805 |  |  | $ | 6,338 |  |  | $ | 2,869 |  |  | $ | 2,883 |  |  | $ | 1,963 |  |  | $ | 1,901 |  |  | $ | 6,937 |  |  | $ | 6,157 |  |  | $ | 18,574 |  |  | $ | 17,279 |  |
| Segment EBITA as reported | $ | 745 |  |  | $ | 847 |  |  | $ | 266 |  |  | $ | 291 |  |  | $ | 227 |  |  | $ | 234 |  |  | $ | 1,283 |  |  | $ | 1,001 |  |  | $ | 2,521 |  |  | $ | 2,373 |  |
| Segment EBITA margin as reported | 10.9 | % |  | 13.4 | % |  | 9.3 | % |  | 10.1 | % |  | 11.6 | % |  | 12.3 | % |  | 18.5 | % |  | 16.3 | % |  | 13.6 | % |  | 13.7 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Silent-Aire earn-out adjustment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (43) |  |  | — |  |  | (43) |  |  | — |  |
| Charges attributable to the suspension of operations in Russia | — |  |  | — |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |
| Nonrecurring Silent-Aire purchase accounting impacts and other costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Adjusted segment EBITA | $ | 745 |  |  | $ | 847 |  |  | $ | 277 |  |  | $ | 291 |  |  | $ | 227 |  |  | $ | 234 |  |  | $ | 1,240 |  |  | $ | 1,008 |  |  | $ | 2,489 |  |  | $ | 2,380 |  |
| Adjusted segment EBITA margin | 10.9 | % |  | 13.4 | % |  | 9.7 | % |  | 10.1 | % |  | 11.6 | % |  | 12.3 | % |  | 17.9 | % |  | 16.4 | % |  | 13.4 | % |  | 13.8 | % |

[0000833444-22-000034:8k_2_02:106]
(2) Adjusted Corporate expenses for the three and nine months ended June 30, 2022 excludes $9 million of transaction/separation costs.

[0000833444-22-000034:8k_2_02:107]
(3) Adjusted amortization of intangible assets for the nine months ended June 30, 2022 excludes $13 million of nonrecurring intangible asset amortization related to Silent-Aire purchase accounting. Adjusted amortization of intangible assets for the three and nine months ended June 30, 2021 excludes $3 million of nonrecurring asset amortization related to Silent-Aire purchase accounting.

[0000833444-22-000034:8k_2_02:108]
(4) The three and nine months ended June 30, 2022 exclude the net mark-to-market losses on restricted asbestos investments and pension and postretirement plan assets of $126 million and $158 million, respectively. The three and nine months ended June 30, 2021 exclude the net mark-to-market gains on restricted asbestos investments and pension and postretirement plan assets of $66 million and $296 million, respectively.

[0000833444-22-000034:8k_2_02:109]
(5) Restructuring and impairment costs for the three and nine months ended June 30, 2022 of $121 million and $554 million, respectively, are excluded from the adjusted non-GAAP results. The restructuring actions and impairment costs for the three and nine months ended June 30, 2022 are related primarily to the impairment of assets associated with businesses classified as held for sale, workforce reductions and other asset impairments. Restructuring and impairment costs for the three and nine months ended June 30, 2021 of $79 million and $175 million, respectively, are excluded from the adjusted non-GAAP results. The restructuring actions and impairment costs for the three and nine months ended June 30, 2021 are related primarily to workforce reductions and asset impairments.

[0000833444-22-000034:8k_2_02:110]
(6) Management defines earnings before interest and taxes (EBIT) as income (loss) from continuing operations before net financing charges, income taxes and noncontrolling interests. EBIT is a non-GAAP performance measure. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company. A reconciliation of EBIT to income from continuing operations is shown earlier within this footnote.

[0000833444-22-000034:8k_2_02:111]
(7) Adjusted income tax provision for the three months ended June 30, 2022 excludes tax benefits related to net mark-to-market losses of $33 million, restructuring and impairment costs of $15 million and transaction/separation costs of $1 million, partially offset by tax provisions related to APB23 adjustments attributable to a business classified as held for sale of $8 million. Adjusted income tax provision for the nine months ended June 30, 2022 excludes tax benefits related to net mark-to-market losses of $40 million, restructuring and impairment costs of $29 million, Silent-Aire nonrecurring intangible asset amortization of $3 million, transaction/separation costs of $1 million and charges related to the suspension of operations in Russia of $1 million, partially offset by tax provisions related to APB23 adjustments attributable to businesses classified as held for sale of $21 million. Adjusted income tax provision for the three months ended June 30, 2021 excludes tax provisions from net mark-to-market gains of $17 million, partially offset by tax benefits related to restructuring and impairment costs of $15 million and tax benefits related to Silent-Aire nonrecurring purchase accounting of $1 million. Adjusted income tax provision for the nine months ended June 30, 2021 excludes tax provisions from a Mexico valuation allowance adjustment of $105 million and net mark-to-market gains of $75 million, partially offset by tax benefits related to restructuring and impairment costs of $30 million and tax benefits related to Silent-Aire nonrecurring purchase accounting of $1 million.

[0000833444-22-000034:8k_2_02:112]
(8) Adjusted income from continuing operations attributable to noncontrolling interests for the nine months ended June 30, 2022 excludes $5 million impact from restructuring and impairment costs.

[0000833444-22-000034:8k_2_02:113]
The Company has presented forward-looking statements regarding adjusted EPS, organic revenue growth, adjusted segment EBITA margin and free cash flow conversion, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, or income from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments and the effect of foreign currency exchange fluctuations. Our fiscal 2022 full year and fourth quarter guidance for organic revenue growth also excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s fourth quarter and full year fiscal 2022 GAAP financial results.

[0000833444-22-000034:8k_2_02:114]
Page 15 of 20

[0000833444-22-000034:8k_2_02:115]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-22-000034:8k_2_02:116]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include net mark-to-market adjustments, restructuring and impairment costs, Silent-Aire other nonrecurring costs, Silent-Aire earn-out adjustment, charges related to the suspension of operations in Russia, Power Solutions divestiture reserve adjustment, transaction/separation costs and discrete tax items. The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-22-000034:8k_2_02:117]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-22-000034:8k_2_02:118]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc from Continuing Operations |  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc from Continuing Operations |
|  | Three Months Ended |  | Three Months Ended |  | Nine Months Ended |  | Nine Months Ended |
|  | June 30, |  | June 30, |  | June 30, |  | June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Earnings per share as reported for JCI plc | $ | 0.55 |  |  | $ | 0.80 |  |  | $ | 0.55 |  |  | $ | 0.80 |  |  | $ | 1.10 |  |  | $ | 1.89 |  |  | $ | 1.10 |  |  | $ | 1.72 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | 0.18 |  |  | (0.09) |  |  | 0.18 |  |  | (0.09) |  |  | 0.22 |  |  | (0.41) |  |  | 0.22 |  |  | (0.41) |  |
| Related tax impact | (0.05) |  |  | 0.02 |  |  | (0.05) |  |  | 0.02 |  |  | (0.06) |  |  | 0.10 |  |  | (0.06) |  |  | 0.10 |  |
| Restructuring and impairment costs | 0.17 |  |  | 0.11 |  |  | 0.17 |  |  | 0.11 |  |  | 0.79 |  |  | 0.24 |  |  | 0.79 |  |  | 0.24 |  |
| Related tax impact | (0.02) |  |  | (0.02) |  |  | (0.02) |  |  | (0.02) |  |  | (0.04) |  |  | (0.04) |  |  | (0.04) |  |  | (0.04) |  |
| NCI impact of restructuring and impairment costs | — |  |  | — |  |  | — |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |
| Power Solutions divestiture reserve adjustment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (0.21) |  |  | — |  |  | — |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.04 |  |  | — |  |  | — |  |
| Silent-Aire other nonrecurring costs | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  | 0.02 |  |  | 0.01 |  |  | 0.02 |  |  | 0.01 |  |
| Silent-Aire earn-out adjustment | — |  |  | — |  |  | — |  |  | — |  |  | (0.06) |  |  | — |  |  | (0.06) |  |  | — |  |
| Charges attributable to the suspension of operations in Russia | — |  |  | — |  |  | — |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Transaction/separation costs | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Discrete tax items | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.03 |  |  | 0.15 |  |  | 0.03 |  |  | 0.15 |  |
| Adjusted earnings per share for JCI plc* | $ | 0.85 |  |  | $ | 0.83 |  |  | $ | 0.85 |  |  | $ | 0.83 |  |  | $ | 2.01 |  |  | $ | 1.77 |  |  | $ | 2.01 |  |  | $ | 1.77 |  |

[0000833444-22-000034:8k_2_02:119]
* May not sum due to rounding

[0000833444-22-000034:8k_2_02:120]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-22-000034:8k_2_02:121]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, |  | June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 692.2 |  |  | 714.5 |  |  | 698.6 |  |  | 718.2 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |
| and unvested performance share awards | 2.7 |  |  | 5.2 |  |  | 3.8 |  |  | 4.3 |  |
| Diluted weighted average shares outstanding | 694.9 |  |  | 719.7 |  |  | 702.4 |  |  | 722.5 |  |

[0000833444-22-000034:8k_2_02:122]
3. Organic Growth Reconciliation

[0000833444-22-000034:8k_2_02:123]
The components of the change in net sales for the three months ended June 30, 2022 versus the three months ended June 30, 2021, including organic growth, are shown below (unaudited):

[0000833444-22-000034:8k_2_02:124]
| (in millions) | Adjusted Net Sales for the Three Months Ended June 30, 2021 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the ThreeMonths EndedJune 30, 2021 |  | Acquisitions |  | Organic Growth |  | Net Sales for the Three Months EndedJune 30, 2022 |
| Building Solutions North America | $ | 2,212 |  |  | $ | — |  | — |  |  | $ | (9) |  | — |  |  | $ | 2,203 |  |  | $ | 6 |  | — |  |  | $ | 217 |  | 10 | % |  | $ | 2,426 |  | 10 | % |
| Building Solutions EMEA/LA | 1,001 |  |  | (7) |  | -1 | % |  | (88) |  | -9 | % |  | 906 |  |  | 9 |  | 1 | % |  | 37 |  | 4 | % |  | 952 |  | -5 | % |
| Building Solutions Asia Pacific | 703 |  |  | — |  | — |  |  | (39) |  | -6 | % |  | 664 |  |  | 8 |  | 1 | % |  | (7) |  | -1 | % |  | 665 |  | -5 | % |
| Total field | 3,916 |  |  | (7) |  | — |  |  | (136) |  | -3 | % |  | 3,773 |  |  | 23 |  | 1 | % |  | 247 |  | 7 | % |  | 4,043 |  | 3 | % |
| Global Products | 2,428 |  |  | — |  | — |  |  | (122) |  | -5 | % |  | 2,306 |  |  | 50 |  | 2 | % |  | 215 |  | 9 | % |  | 2,571 |  | 6 | % |
| Total net sales | $ | 6,344 |  |  | $ | (7) |  | — |  |  | $ | (258) |  | -4 | % |  | $ | 6,079 |  |  | $ | 73 |  | 1 | % |  | $ | 462 |  | 8 | % |  | $ | 6,614 |  | 4 | % |

[0000833444-22-000034:8k_2_02:125]
Page 16 of 20

[0000833444-22-000034:8k_2_02:126]
The components of the change in net sales for the nine months ended June 30, 2022 versus the nine months ended June 30, 2021, including organic growth, are shown below (unaudited):

[0000833444-22-000034:8k_2_02:127]
| (in millions) | Adjusted Net Sales for the Nine Months Ended June 30, 2021 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the NineMonths EndedJune 30, 2021 |  | Acquisitions |  | Organic Growth |  | Net Sales for the Nine Months EndedJune 30, 2022 |
| Building Solutions North America | $ | 6,338 |  |  | $ | — |  | — |  |  | $ | (3) |  | — |  |  | $ | 6,335 |  |  | $ | 15 |  | — |  |  | $ | 455 |  | 7 | % |  | $ | 6,805 |  | 7 | % |
| Building Solutions EMEA/LA | 2,883 |  |  | (16) |  | -1 | % |  | (155) |  | -5 | % |  | 2,712 |  |  | 24 |  | 1 | % |  | 133 |  | 5 | % |  | 2,869 |  | — |  |
| Building Solutions Asia Pacific | 1,901 |  |  | (1) |  | — |  |  | (62) |  | -3 | % |  | 1,838 |  |  | 26 |  | 1 | % |  | 99 |  | 5 | % |  | 1,963 |  | 3 | % |
| Total field | 11,122 |  |  | (17) |  | — |  |  | (220) |  | -2 | % |  | 10,885 |  |  | 65 |  | 1 | % |  | 687 |  | 6 | % |  | 11,637 |  | 5 | % |
| Global Products | 6,154 |  |  | — |  | — |  |  | (193) |  | -3 | % |  | 5,961 |  |  | 254 |  | 4 | % |  | 722 |  | 12 | % |  | 6,937 |  | 13 | % |
| Total net sales | $ | 17,276 |  |  | $ | (17) |  | — |  |  | $ | (413) |  | -2 | % |  | $ | 16,846 |  |  | $ | 319 |  | 2 | % |  | $ | 1,409 |  | 8 | % |  | $ | 18,574 |  | 8 | % |

[0000833444-22-000034:8k_2_02:128]
The components of the change in total segment EBITA for the three months ended June 30, 2022 versus the three months ended June 30, 2021, including organic growth, is shown below (unaudited):

[0000833444-22-000034:8k_2_02:129]
| (in millions) | Adjusted SegmentEBITA for the Three Months Ended June 30, 2021 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base SegmentEBITA for theThree Months EndedJune 30, 2021 |  | Acquisitions |  | Organic Growth |  | Adjusted SegmentEBITA for theThree Months EndedJune 30, 2022 |
| Total segment EBITA | $ | 1,027 |  |  | $ | (1) |  | — |  |  | $ | (37) |  | -4 | % |  | $ | 989 |  |  | $ | 1 |  | — |  |  | $ | 8 |  | 1 | % |  | $ | 998 |  | -3 | % |

[0000833444-22-000034:8k_2_02:130]
The Company's earnings presentation presents organic growth for each of the periods re-casted as a result of changes in the composition of reportable segments effective October 1, 2021. The components of the change in adjusted net sales, including organic growth, are shown below for the three months ended December 31, 2020 versus the three months ended December 31, 2019, the three months ended March 31, 2021 versus the three months ended March 31, 2020, the three months ended June 30, 2021 versus the three months ended June 30, 2020, the three months ended September 30, 2021 versus the three months ended September 30, 2020, and the twelve months ended September 30, 2021 versus the twelve months ended September 30, 2020 (unaudited).

[0000833444-22-000034:8k_2_02:131]
| (in millions) | Adjusted Net Sales for the Three Months Ended December 31, 2019 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the ThreeMonths EndedDecember 31, 2019 |  | Acquisitions |  | Organic Growth |  | Adjusted Net Sales for the Three Months EndedDecember 31, 2020 |
| Building Solutions North America | $ | 2,167 |  |  | $ | — |  | — |  |  | $ | 3 |  | — |  |  | $ | 2,170 |  |  | $ | — |  | — |  |  | $ | (136) |  | -6 | % |  | $ | 2,034 |  | -6 | % |
| Building Solutions EMEA/LA | 970 |  |  | — |  | — |  |  | 24 |  | 2 | % |  | 994 |  |  | 9 |  | 1 | % |  | (55) |  | -6 | % |  | 948 |  | -2 | % |
| Building Solutions Asia Pacific | 620 |  |  | (2) |  | — |  |  | 28 |  | 5 | % |  | 646 |  |  | — |  | — |  |  | (42) |  | -7 | % |  | 604 |  | -3 | % |
| Total field | 3,757 |  |  | (2) |  | — |  |  | 55 |  | 1 | % |  | 3,810 |  |  | 9 |  | — |  |  | (233) |  | -6 | % |  | 3,586 |  | -5 | % |
| Global Products | 1,819 |  |  | (71) |  | -4 | % |  | 35 |  | 2 | % |  | 1,783 |  |  | — |  | — |  |  | (28) |  | -2 | % |  | 1,755 |  | -4 | % |
| Total net sales | $ | 5,576 |  |  | $ | (73) |  | -1 | % |  | $ | 90 |  | 2 | % |  | $ | 5,593 |  |  | $ | 9 |  | — |  |  | $ | (261) |  | -5 | % |  | $ | 5,341 |  | -4 | % |

[0000833444-22-000034:8k_2_02:132]
| (in millions) | Adjusted Net Sales for the Three Months Ended March 31, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the ThreeMonths EndedMarch 31, 2020 |  | Acquisitions |  | Organic Growth |  | Adjusted Net Sales for the Three Months EndedMarch 31, 2021 |
| Building Solutions North America | $ | 2,175 |  |  | $ | — |  | — |  |  | $ | 13 |  | 1 | % |  | $ | 2,188 |  |  | $ | — |  | — |  |  | $ | (96) |  | -4 | % |  | $ | 2,092 |  | -4 | % |
| Building Solutions EMEA/LA | 891 |  |  | — |  | — |  |  | 44 |  | 5 | % |  | 935 |  |  | 4 |  | — |  |  | (5) |  | -1 | % |  | 934 |  | 5 | % |
| Building Solutions Asia Pacific | 518 |  |  | (2) |  | — |  |  | 29 |  | 6 | % |  | 545 |  |  | — |  | — |  |  | 49 |  | 9 | % |  | 594 |  | 15 | % |
| Total field | 3,584 |  |  | (2) |  | — |  |  | 86 |  | 2 | % |  | 3,668 |  |  | 4 |  | — |  |  | (52) |  | -1 | % |  | 3,620 |  | 1 | % |
| Global Products | 1,860 |  |  | (62) |  | -3 | % |  | 49 |  | 3 | % |  | 1,847 |  |  | — |  | — |  |  | 127 |  | 7 | % |  | 1,974 |  | 6 | % |
| Total net sales | $ | 5,444 |  |  | $ | (64) |  | -1 | % |  | $ | 135 |  | 2 | % |  | $ | 5,515 |  |  | $ | 4 |  | — |  |  | $ | 75 |  | 1 | % |  | $ | 5,594 |  | 3 | % |

[0000833444-22-000034:8k_2_02:133]
| (in millions) | Adjusted Net Sales for the Three Months Ended June 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the ThreeMonths EndedJune 30, 2020 |  | Acquisitions |  | Organic Growth |  | Adjusted Net Sales for the Three Months EndedJune 30, 2021 |
| Building Solutions North America | $ | 2,020 |  |  | $ | — |  | — |  |  | $ | 21 |  | 1 | % |  | $ | 2,041 |  |  | $ | — |  | — |  |  | $ | 171 |  | 8 | % |  | $ | 2,212 |  | 10 | % |
| Building Solutions EMEA/LA | 795 |  |  | — |  | — |  |  | 60 |  | 8 | % |  | 855 |  |  | 10 |  | 1 | % |  | 136 |  | 16 | % |  | 1,001 |  | 26 | % |
| Building Solutions Asia Pacific | 579 |  |  | (3) |  | -1 | % |  | 40 |  | 7 | % |  | 616 |  |  | — |  | — |  |  | 87 |  | 14 | % |  | 703 |  | 21 | % |
| Total field | 3,394 |  |  | (3) |  | — |  |  | 121 |  | 4 | % |  | 3,512 |  |  | 10 |  | — |  |  | 394 |  | 11 | % |  | 3,916 |  | 15 | % |
| Global Products | 1,949 |  |  | (54) |  | -3 | % |  | 44 |  | 2 | % |  | 1,939 |  |  | 80 |  | 4 | % |  | 409 |  | 21 | % |  | 2,428 |  | 25 | % |
| Total net sales | $ | 5,343 |  |  | $ | (57) |  | -1 | % |  | $ | 165 |  | 3 | % |  | $ | 5,451 |  |  | $ | 90 |  | 2 | % |  | $ | 803 |  | 15 | % |  | $ | 6,344 |  | 19 | % |

[0000833444-22-000034:8k_2_02:134]
| (in millions) | Adjusted Net Sales for the Three Months Ended September 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the ThreeMonths EndedSeptember 30, 2020 |  | Acquisitions |  | Organic Growth |  | Adjusted Net Sales for the Three Months EndedSeptember 30, 2021 |
| Building Solutions North America | $ | 2,243 |  |  | $ | — |  | — |  |  | $ | 12 |  | 1 | % |  | $ | 2,255 |  |  | $ | 4 |  | — |  |  | $ | 88 |  | 4 | % |  | $ | 2,347 |  | 5 | % |
| Building Solutions EMEA/LA | 957 |  |  | — |  | — |  |  | 17 |  | 2 | % |  | 974 |  |  | 14 |  | 1 | % |  | 13 |  | 1 | % |  | 1,001 |  | 5 | % |
| Building Solutions Asia Pacific | 651 |  |  | (2) |  | — |  |  | 18 |  | 3 | % |  | 667 |  |  | — |  | — |  |  | 48 |  | 7 | % |  | 715 |  | 10 | % |
| Total field | 3,851 |  |  | (2) |  | — |  |  | 47 |  | 1 | % |  | 3,896 |  |  | 18 |  | — |  |  | 149 |  | 4 | % |  | 4,063 |  | 6 | % |
| Global Products | 2,103 |  |  | (79) |  | -4 | % |  | 10 |  | — |  |  | 2,034 |  |  | 132 |  | 6 | % |  | 166 |  | 8 | % |  | 2,332 |  | 11 | % |
| Total net sales | $ | 5,954 |  |  | $ | (81) |  | -1 | % |  | $ | 57 |  | 1 | % |  | $ | 5,930 |  |  | $ | 150 |  | 3 | % |  | $ | 315 |  | 5 | % |  | $ | 6,395 |  | 7 | % |

[0000833444-22-000034:8k_2_02:135]
Page 17 of 20

[0000833444-22-000034:8k_2_02:136]
| (in millions) | Adjusted Net Sales for the Twelve Months Ended September 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the TwelveMonths EndedSeptember 30, 2020 |  | Acquisitions |  | Organic Growth |  | Adjusted Net Sales for the TwelveMonths EndedSeptember 30, 2021 |
| Building Solutions North America | $ | 8,605 |  |  | $ | — |  | — |  |  | $ | 49 |  | 1 | % |  | $ | 8,654 |  |  | $ | 4 |  | — |  |  | $ | 27 |  | — |  |  | $ | 8,685 |  | 1 | % |
| Building Solutions EMEA/LA | 3,613 |  |  | — |  | — |  |  | 145 |  | 4 | % |  | 3,758 |  |  | 37 |  | 1 | % |  | 89 |  | 2 | % |  | 3,884 |  | 8 | % |
| Building Solutions Asia Pacific | 2,368 |  |  | (9) |  | — |  |  | 115 |  | 5 | % |  | 2,474 |  |  | — |  | — |  |  | 142 |  | 6 | % |  | 2,616 |  | 10 | % |
| Total field | 14,586 |  |  | (9) |  | — |  |  | 309 |  | 2 | % |  | 14,886 |  |  | 41 |  | — |  |  | 258 |  | 2 | % |  | 15,185 |  | 4 | % |
| Global Products | 7,731 |  |  | (266) |  | -3 | % |  | 138 |  | 2 | % |  | 7,603 |  |  | 212 |  | 3 | % |  | 674 |  | 9 | % |  | 8,489 |  | 10 | % |
| Total net sales | $ | 22,317 |  |  | $ | (275) |  | -1 | % |  | $ | 447 |  | 2 | % |  | $ | 22,489 |  |  | $ | 253 |  | 1 | % |  | $ | 932 |  | 4 | % |  | $ | 23,674 |  | 6 | % |

[0000833444-22-000034:8k_2_02:137]
The organic growth reconciliations presented earlier within this footnote contain financial information regarding adjusted net sales. The following is the reconciliation of net sales as re-casted to adjusted net sales for the three months ended December 31, 2020 and 2019, the three months ended March 31, 2021 and 2020, the three months ended June 30, 2021 and 2020, the three months ended September 30, 2021 and 2020, and the twelve months ended September 30, 2021 and 2020 (unaudited):

[0000833444-22-000034:8k_2_02:138]
|  | Three Months Ended |  | Twelve Months Ended |
|  | December 31, |  | March 31, |  | June 30, |  | September 30, |  | September 30, |
| (in millions) | 2020 |  | 2019 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales as re-casted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,034 |  |  | $ | 2,167 |  |  | $ | 2,092 |  |  | $ | 2,175 |  |  | $ | 2,212 |  |  | $ | 2,020 |  |  | $ | 2,347 |  |  | $ | 2,243 |  |  | $ | 8,685 |  |  | $ | 8,605 |  |
| Building Solutions EMEA/LA | 948 |  |  | 970 |  |  | 934 |  |  | 891 |  |  | 1,001 |  |  | 795 |  |  | 1,001 |  |  | 957 |  |  | 3,884 |  |  | 3,613 |  |
| Building Solutions Asia Pacific | 604 |  |  | 620 |  |  | 594 |  |  | 518 |  |  | 703 |  |  | 579 |  |  | 715 |  |  | 651 |  |  | 2,616 |  |  | 2,368 |  |
| Global Products | 1,755 |  |  | 1,819 |  |  | 1,974 |  |  | 1,860 |  |  | 2,425 |  |  | 1,949 |  |  | 2,329 |  |  | 2,103 |  |  | 8,483 |  |  | 7,731 |  |
| Net sales as re-casted | 5,341 |  |  | 5,576 |  |  | 5,594 |  |  | 5,444 |  |  | 6,341 |  |  | 5,343 |  |  | 6,392 |  |  | 5,954 |  |  | 23,668 |  |  | 22,317 |  |
| Adjusting items (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Building Solutions EMEA/LA | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Building Solutions Asia Pacific | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Global Products | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |  | 6 |  |  | — |  |
| Adjusting items | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |  | 6 |  |  | — |  |
| Adjusted net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | 2,034 |  |  | 2,167 |  |  | 2,092 |  |  | 2,175 |  |  | 2,212 |  |  | 2,020 |  |  | 2,347 |  |  | 2,243 |  |  | 8,685 |  |  | 8,605 |  |
| Building Solutions EMEA/LA | 948 |  |  | 970 |  |  | 934 |  |  | 891 |  |  | 1,001 |  |  | 795 |  |  | 1,001 |  |  | 957 |  |  | 3,884 |  |  | 3,613 |  |
| Building Solutions Asia Pacific | 604 |  |  | 620 |  |  | 594 |  |  | 518 |  |  | 703 |  |  | 579 |  |  | 715 |  |  | 651 |  |  | 2,616 |  |  | 2,368 |  |
| Global Products | 1,755 |  |  | 1,819 |  |  | 1,974 |  |  | 1,860 |  |  | 2,428 |  |  | 1,949 |  |  | 2,332 |  |  | 2,103 |  |  | 8,489 |  |  | 7,731 |  |
| Adjusted net sales | $ | 5,341 |  |  | $ | 5,576 |  |  | $ | 5,594 |  |  | $ | 5,444 |  |  | $ | 6,344 |  |  | $ | 5,343 |  |  | $ | 6,395 |  |  | $ | 5,954 |  |  | $ | 23,674 |  |  | $ | 22,317 |  |

[0000833444-22-000034:8k_2_02:139]
(1) Adjusting items to net sales relate to nonrecurring Silent-Aire purchase accounting impacts.

[0000833444-22-000034:8k_2_02:140]
The Company's earnings presentation presents service revenue and organic growth for the three months ended June 30, 2022. The components of the change in service revenue, including organic growth, are shown below (unaudited):

[0000833444-22-000034:8k_2_02:141]
| (in millions) | Proforma ServiceRevenue for the Three Months EndedJune 30, 2021 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base ServiceRevenue for the ThreeMonths EndedJune 30, 2021 |  | Acquisitions |  | Organic Growth |  | Service Revenue for the Three Months EndedJune 30, 2022 |
| Building Solutions North America | $ | 857 |  |  | $ | — |  | — |  |  | $ | (2) |  | — |  |  | $ | 855 |  |  | $ | 5 |  | 1 | % |  | $ | 85 |  | 10 | % |  | $ | 945 |  | 10 | % |
| Building Solutions EMEA/LA | 427 |  |  | (7) |  | -2 | % |  | (38) |  | -9 | % |  | 382 |  |  | — |  | — |  |  | 33 |  | 9 | % |  | 415 |  | -3 | % |
| Building Solutions Asia Pacific | 183 |  |  | — |  | — |  |  | (12) |  | -7 | % |  | 171 |  |  | 1 |  | 1 | % |  | — |  | — |  |  | 172 |  | -6 | % |
| Total field | 1,467 |  |  | (7) |  | — |  |  | (52) |  | -4 | % |  | 1,408 |  |  | 6 |  | — |  |  | 118 |  | 8 | % |  | 1,532 |  | 4 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total net sales | $ | 1,467 |  |  | $ | (7) |  | — |  |  | $ | (52) |  | -4 | % |  | $ | 1,408 |  |  | $ | 6 |  | — |  |  | $ | 118 |  | 8 | % |  | $ | 1,532 |  | 4 | % |

[0000833444-22-000034:8k_2_02:142]
The Company's earnings presentation presents proforma service revenue and organic growth for the three months ended December 31, 2020, the three months ended March 31, 2021, the three months ended June 30, 2021, the three months ended September 30, 2021, and the twelve months ended September 30, 2021. The components of the change in proforma service revenue, including organic growth, for each period for which proforma financial information is presented are shown below (unaudited).

[0000833444-22-000034:8k_2_02:143]
| (in millions) | Proforma ServiceRevenue for the Three Months EndedDecember 31, 2019 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base ServiceRevenue for the ThreeMonths EndedDecember 31, 2019 |  | Acquisitions |  | Organic Growth |  | Proforma Service Revenue for theThree Months EndedDecember 31, 2020 |
| Building Solutions North America | $ | 811 |  |  | $ | — |  | — |  |  | $ | 1 |  | — |  |  | $ | 812 |  |  | $ | — |  | — |  |  | $ | (20) |  | -2 | % |  | $ | 792 |  | -2 | % |
| Building Solutions EMEA/LA | 414 |  |  | — |  | — |  |  | 5 |  | 1 | % |  | 419 |  |  | 3 |  | 1 | % |  | (5) |  | -1 | % |  | 417 |  | 1 | % |
| Building Solutions Asia Pacific | 165 |  |  | (2) |  | -1 | % |  | 7 |  | 4 | % |  | 170 |  |  | — |  | — |  |  | (2) |  | -1 | % |  | 168 |  | 2 | % |
| Total field | 1,390 |  |  | (2) |  | — |  |  | 13 |  | 1 | % |  | 1,401 |  |  | 3 |  | — |  |  | (27) |  | -2 | % |  | 1,377 |  | -1 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 1,390 |  |  | $ | (2) |  | — |  |  | $ | 13 |  | 1 | % |  | $ | 1,401 |  |  | $ | 3 |  | — |  |  | $ | (27) |  | -2 | % |  | $ | 1,377 |  | -1 | % |

[0000833444-22-000034:8k_2_02:144]
Page 18 of 20

[0000833444-22-000034:8k_2_02:145]
| (in millions) | Proforma ServiceRevenue for the Three Months EndedMarch 31, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base ServiceRevenue for the ThreeMonths EndedMarch 31, 2020 |  | Acquisitions |  | Organic Growth |  | Proforma Service Revenue for the Three Months EndedMarch 31, 2021 |
| Building Solutions North America | $ | 818 |  |  | $ | — |  | — |  |  | $ | 4 |  | — |  |  | $ | 822 |  |  | $ | — |  | — |  |  | $ | (2) |  | — |  |  | $ | 820 |  | — |  |
| Building Solutions EMEA/LA | 396 |  |  | — |  | — |  |  | 16 |  | 4 | % |  | 412 |  |  | 2 |  | — |  |  | (7) |  | -2 | % |  | 407 |  | 3 | % |
| Building Solutions Asia Pacific | 160 |  |  | (2) |  | -1 | % |  | 11 |  | 7 | % |  | 169 |  |  | — |  | — |  |  | 2 |  | 1 | % |  | 171 |  | 7 | % |
| Total field | 1,374 |  |  | (2) |  | — |  |  | 31 |  | 2 | % |  | 1,403 |  |  | 2 |  | — |  |  | (7) |  | — |  |  | 1,398 |  | 2 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 1,374 |  |  | $ | (2) |  | — |  |  | $ | 31 |  | 2 | % |  | $ | 1,403 |  |  | $ | 2 |  | — |  |  | $ | (7) |  | — |  |  | $ | 1,398 |  | 2 | % |

[0000833444-22-000034:8k_2_02:146]
| (in millions) | Proforma ServiceRevenue for theThree Months EndedJune 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base ServiceRevenue for the ThreeMonths EndedJune 30, 2020 |  | Acquisitions |  | Organic Growth |  | Proforma Service Revenue for theThree Months EndedJune 30, 2021 |
| Building Solutions North America | $ | 770 |  |  | $ | — |  | — |  |  | $ | 9 |  | 1 | % |  | $ | 779 |  |  | $ | — |  | — |  |  | $ | 78 |  | 10 | % |  | $ | 857 |  | 11 | % |
| Building Solutions EMEA/LA | 349 |  |  | — |  | — |  |  | 26 |  | 7 | % |  | 375 |  |  | 4 |  | 1 | % |  | 48 |  | 13 | % |  | 427 |  | 22 | % |
| Building Solutions Asia Pacific | 156 |  |  | (3) |  | -2 | % |  | 12 |  | 8 | % |  | 165 |  |  | — |  | — |  |  | 18 |  | 11 | % |  | 183 |  | 17 | % |
| Total field | 1,275 |  |  | (3) |  | — |  |  | 47 |  | 4 | % |  | 1,319 |  |  | 4 |  | — |  |  | 144 |  | 11 | % |  | 1,467 |  | 15 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 1,275 |  |  | $ | (3) |  | — |  |  | $ | 47 |  | 4 | % |  | $ | 1,319 |  |  | $ | 4 |  | — |  |  | $ | 144 |  | 11 | % |  | $ | 1,467 |  | 15 | % |

[0000833444-22-000034:8k_2_02:147]
| (in millions) | Proforma ServiceRevenue for theThree Months EndedSeptember 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base ServiceRevenue for the ThreeMonths EndedSeptember 30, 2020 |  | Acquisitions |  | Organic Growth |  | Proforma Service Revenue for theThree Months EndedSeptember 30, 2021 |
| Building Solutions North America | $ | 835 |  |  | $ | — |  | — |  |  | $ | 4 |  | — |  |  | $ | 839 |  |  | $ | 3 |  | — |  |  | $ | 62 |  | 7 | % |  | $ | 904 |  | 8 | % |
| Building Solutions EMEA/LA | 435 |  |  | — |  | — |  |  | 6 |  | 1 | % |  | 441 |  |  | 1 |  | — |  |  | (9) |  | -2 | % |  | 433 |  | — |  |
| Building Solutions Asia Pacific | 180 |  |  | (2) |  | -1 | % |  | 4 |  | 2 | % |  | 182 |  |  | — |  | — |  |  | 2 |  | 1 | % |  | 184 |  | 2 | % |
| Total field | 1,450 |  |  | (2) |  | — |  |  | 14 |  | 1 | % |  | 1,462 |  |  | 4 |  | — |  |  | 55 |  | 4 | % |  | 1,521 |  | 5 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 1,450 |  |  | $ | (2) |  | — |  |  | $ | 14 |  | 1 | % |  | $ | 1,462 |  |  | $ | 4 |  | — |  |  | $ | 55 |  | 4 | % |  | $ | 1,521 |  | 5 | % |

[0000833444-22-000034:8k_2_02:148]
| (in millions) | Proforma ServiceRevenue for theTwelve Months EndedSeptember 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base ServiceRevenue for the Twelve Months EndedSeptember 30, 2020 |  | Acquisitions |  | Organic Growth |  | Proforma Service Revenue for theTwelve Months EndedSeptember 30, 2021 |
| Building Solutions North America | $ | 3,234 |  |  | $ | — |  | — |  |  | $ | 18 |  | 1 | % |  | $ | 3,252 |  |  | $ | 3 |  | — |  |  | $ | 118 |  | 4 | % |  | $ | 3,373 |  | 4 | % |
| Building Solutions EMEA/LA | 1,594 |  |  | — |  | — |  |  | 53 |  | 3 | % |  | 1,647 |  |  | 10 |  | 1 | % |  | 27 |  | 2 | % |  | 1,684 |  | 6 | % |
| Building Solutions Asia Pacific | 661 |  |  | (9) |  | -1 | % |  | 34 |  | 5 | % |  | 686 |  |  | — |  | — |  |  | 20 |  | 3 | % |  | 706 |  | 7 | % |
| Total field | 5,489 |  |  | (9) |  | — |  |  | 105 |  | 2 | % |  | 5,585 |  |  | 13 |  | — |  |  | 165 |  | 3 | % |  | 5,763 |  | 5 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 5,489 |  |  | $ | (9) |  | — |  |  | $ | 105 |  | 2 | % |  | $ | 5,585 |  |  | $ | 13 |  | — |  |  | $ | 165 |  | 3 | % |  | $ | 5,763 |  | 5 | % |

[0000833444-22-000034:8k_2_02:149]
4.   Free Cash Flow Conversion

[0000833444-22-000034:8k_2_02:150]
The Company's press release contains financial information regarding free cash flow and free cash flow conversion, which are non-GAAP performance measures. Free cash flow is defined as cash provided by operating activities less capital expenditures. Free cash flow conversion is defined as free cash flow divided by adjusted net income attributable to JCI. Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash. These non-GAAP measures can also be used to evaluate our ability to generate cash flow from operations and the impact that this cash flow has on our liquidity.

[0000833444-22-000034:8k_2_02:151]
The following is the three months and nine months ended June 30, 2022 and 2021 reconciliation of free cash flow and free cash flow conversion for continuing operations (unaudited):

[0000833444-22-000034:8k_2_02:152]
|  | Three Months Ended |  | Nine Months Ended |  |
| (in millions) | June 30, 2022 |  | June 30, 2021 |  | June 30, 2022 |  | June 30, 2021 |  |
| Cash provided (used) by operating activities from continuing |  |  |  |  |  |  |  |  |
| operations | $ | 487 |  | $ | 862 |  | $ | 811 |  | $ | 2,022 |  |
| Capital expenditures | (170) |  | (127) |  | (430) |  | (324) |  |
| Reported free cash flow | $ | 317 |  | $ | 735 |  | $ | 381 |  | $ | 1,698 |  |
| Adjusted net income from continuing operations |  |  |  |  |  |  |  |  |
| attributable to JCI | $ | 594 |  | $ | 598 |  | $ | 1,415 |  | $ | 1,282 |  |
| Adjusted free cash flow conversion | 53 | % |  | 123 | % |  | 27 | % |  | 132 | % |  |

[0000833444-22-000034:8k_2_02:153]
Page 19 of 20

[0000833444-22-000034:8k_2_02:154]
5.  Net Debt to EBITDA

[0000833444-22-000034:8k_2_02:155]
The Company provides financial information regarding net debt to adjusted EBITDA, which is a non-GAAP performance measure. The Company believes the total net debt to adjusted EBITDA ratio is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. The following is the June 30, 2022 calculation of net debt to adjusted EBITDA (unaudited):

[0000833444-22-000034:8k_2_02:156]
| (in millions) | June 30, 2022 |  |  |
| Short-term debt and current portion of long-term debt | $ | 2,298 |  |  |  |
| Long-term debt | 7,194 |  |  |  |
| Total debt | 9,492 |  |  |  |
| Less: cash and cash equivalents | 1,506 |  |  |  |
| Total net debt | $ | 7,986 |  |  |  |
| Last twelve months adjusted EBITDA | $ | 3,617 |  |  |  |
| Total net debt to adjusted EBITDA | 2.2x |  |  |

[0000833444-22-000034:8k_2_02:157]
The following is the last twelve months ended June 30, 2022 reconciliation of income from continuing operations to adjusted EBIT and adjusted EBITDA, which are non-GAAP performance measures (unaudited):

[0000833444-22-000034:8k_2_02:158]
| (in millions) | Last Twelve MonthsEndedJune 30, 2022 |  |  |
| Income from continuing operations | $ | 1,230 |  |  |  |
| Income tax provision | 680 |  |  |  |
| Net financing charges | 200 |  |  |  |
| EBIT | 2,110 |  |  |  |
| Adjusting items: |  |  |  |
| Net mark-to-market adjustments | 52 |  |  |  |
| Restructuring and impairment costs | 621 |  |  |  |
| Silent-Aire other nonrecurring costs | 26 |  |  |  |
| Silent-Aire earn-out adjustment | (43) |  |  |  |
| Charges attributable to the suspension of operations in Russia | 11 |  |  |  |
| Transaction/separation costs | 9 |  |  |  |
| Adjusted EBIT (1) | 2,786 |  |  |  |
| Depreciation and amortization | 831 |  |  |  |
| Adjusted EBITDA (1) | $ | 3,617 |  |  |  |

[0000833444-22-000034:8k_2_02:159]
(1) The Company's definition of adjusted EBIT and adjusted EBITDA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-22-000034:8k_2_02:160]
6.  Trade Working Capital as a Percentage of Net Sales

[0000833444-22-000034:8k_2_02:161]
The Company provides financial information regarding trade working capital as a percentage of net sales, which is a non-GAAP performance measure. Trade working capital is defined as current assets less current liabilities, excluding cash, short-term debt, the current portion of long-term debt, the current portion of assets and liabilities held for sale, accrued compensation and benefits, and other current assets and liabilities.  Management believes this non-GAAP measure, which excludes financing-related items, non-trade related items and businesses to be divested, is a more useful measurement of the Company's operating performance. The following is the June 30, 2022 and June 30, 2021 calculation of trade working capital as a percentage of net sales (unaudited):

[0000833444-22-000034:8k_2_02:162]
| (in millions) | June 30, 2022 |  | June 30, 2021 |
| Current assets | $ | 11,559 |  |  | $ | 10,310 |  |
| Current liabilities | (11,883) |  |  | (9,285) |  |
| Total working capital | (324) |  |  | 1,025 |  |
| Less: cash and cash equivalents | (1,506) |  |  | (1,450) |  |
| Less: assets held for sale | (394) |  |  | — |  |
| Less: other current assets | (1,235) |  |  | (1,128) |  |
| Add: short-term debt | 2,081 |  |  | 265 |  |
| Add: current portion of long-term debt | 217 |  |  | 196 |  |
| Add: accrued compensation and benefits | 874 |  |  | 996 |  |
| Add: liabilities held for sale | 261 |  |  | — |  |
| Add: other current liabilities | 2,479 |  |  | 2,460 |  |
| Trade working capital | $ | 2,453 |  |  | $ | 2,364 |  |
| Last twelve months net sales | $ | 24,966 |  |  | $ | 23,320 |  |
| Trade working capital as a percentage of net sales | 9.8 | % |  | 10.2 | % |

[0000833444-22-000034:8k_2_02:163]
7.  Income Taxes

[0000833444-22-000034:8k_2_02:164]
The Company's effective tax rate from continuing operations before consideration of net mark-to-market adjustments, restructuring and impairment costs, Silent-Aire nonrecurring intangible asset amortization and purchase accounting, charges related to the suspension of operations in Russia, transaction/separation costs and discrete tax items for the three and nine months ending June 30, 2022 and June 30, 2021 is approximately 13.5%.

[0000833444-22-000034:8k_2_02:165]
8.  Restructuring and Impairment Costs

[0000833444-22-000034:8k_2_02:166]
The three months ended June 30, 2022 include restructuring and impairment costs of $121 million related primarily to the impairment of assets associated with a business classified as held for sale, workforce reductions and other asset impairments. The nine months ended June 30, 2022 include restructuring and impairment costs of $554 million related primarily to the impairment of assets associated with businesses classified as held for sale, workforce reductions and other asset impairments. The three months ended June 30, 2021 include restructuring and impairment costs of $79 million related primarily to workforce reductions, asset impairments and other related costs. The nine months ended June 30, 2021 include restructuring and impairment costs of $175 million related primarily to workforce reductions, asset impairments and other related costs.

[0000833444-22-000034:8k_2_02:167]
Page 20 of 20
