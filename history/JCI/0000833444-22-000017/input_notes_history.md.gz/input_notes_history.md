# JCI note change history — 0000833444-22-000005 → 0000833444-22-000017


## jci:ScheduleOfAccrualForAsbestosLossContingenciesTableTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2022-05-04):
[0000833444-22-000017:note_history:1]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 390 |  |  | 400 |  |
| Total asbestos-related liabilities | 448 |  |  | 458 |  |
| Other current assets | 36 |  |  | 13 |  |
| Other noncurrent assets | 326 |  |  | 365 |  |
| Total asbestos-related assets | 362 |  |  | 378 |  |
| Net asbestos-related liabilities | $ | 86 |  |  | $ | 80 |  |

- added (2022-05-04):
[0000833444-22-000017:note_history:2]
|  | March 31, 2022 |  | September 30, 2021 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 299 |  |  | 314 |  |
| Total restricted assets | 305 |  |  | 320 |  |
| Insurance recoveries for asbestos-related liabilities | 57 |  |  | 58 |  |
| Total asbestos-related assets | $ | 362 |  |  | $ | 378 |  |

- removed (2022-05-04):
[0000833444-22-000005:note_history:3]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 395 |  |  | 400 |  |
| Total asbestos-related liabilities | 453 |  |  | 458 |  |
| Other current assets | 15 |  |  | 13 |  |
| Other noncurrent assets | 373 |  |  | 365 |  |
| Total asbestos-related assets | 388 |  |  | 378 |  |
| Net asbestos-related liabilities | $ | 65 |  |  | $ | 80 |  |

- removed (2022-05-04):
[0000833444-22-000005:note_history:4]
|  | December 31, 2021 |  | September 30, 2021 |
| Restricted |  |  |  |
| Cash | $ | 7 |  |  | $ | 6 |  |
| Investments | 323 |  |  | 314 |  |
| Total restricted assets | 330 |  |  | 320 |  |
| Insurance recoveries for asbestos-related liabilities | 58 |  |  | 58 |  |
| Total asbestos-related assets | $ | 388 |  |  | $ | 378 |  |


## jci:ScheduleOfAccrualForEnvironmentalLossContingenciesTableTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000833444-22-000017:note_history:5]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 50 |  |  | $ | 48 |  |
| Other noncurrent liabilities | 34 |  |  | 54 |  |
| Total reserves for environmental liabilities | $ | 84 |  |  | $ | 102 |  |
  (was, 2022-02-02, similarity 0.9731):
[0000833444-22-000005:note_history:5]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current liabilities | $ | 64 |  |  | $ | 48 |  |
| Other noncurrent liabilities | 29 |  |  | 54 |  |
| Total reserves for environmental liabilities | $ | 93 |  |  | $ | 102 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000833444-22-000017:note_history:6]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 50 |  |  | $ | 48 |  |
| Other noncurrent liabilities | 34 |  |  | 54 |  |
| Total reserves for environmental liabilities | $ | 84 |  |  | $ | 102 |  |
  (was, 2022-02-02, similarity 0.9731):
[0000833444-22-000005:note_history:6]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current liabilities | $ | 64 |  |  | $ | 48 |  |
| Other noncurrent liabilities | 29 |  |  | 54 |  |
| Total reserves for environmental liabilities | $ | 93 |  |  | $ | 102 |  |

- changed (2022-05-04):
[0000833444-22-000017:note_history:7]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin. In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluoroalkyl substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.
  (was, 2022-02-02, similarity 0.843):
[0000833444-22-000005:note_history:7]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin. In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluoroalkyl substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the

- added (2022-05-04):
[0000833444-22-000017:note_history:8]
A substantial portion of the Company’s environmental reserves relates to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The Company’s reserves for remediation efforts at or near the FTC are based on a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals at this time.

- added (2022-05-04):
[0000833444-22-000017:note_history:9]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22,

- changed (2022-05-04):
[0000833444-22-000017:note_history:10]
2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation. On November 6, 2020, WDNR received further recommendations from WDHS regarding individual standards for 12 additional PFAS and a combined standard for four additional PFAS, PFOA, and PFOS.
  (was, 2022-02-02, similarity 0.7374):
[0000833444-22-000005:note_history:10]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation. On November 6, 2020, WDNR received further recommendations from WDHS regarding individual standards for 12 additional PFAS and a combined standard for four additional PFAS, PFOA, and PFOS.

- added (2022-05-04):
[0000833444-22-000017:note_history:11]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR’s requests. The lawsuit is presently at the beginning stages of litigation: Tyco Fire Products and Johnson Controls, Inc. each filed Answers to the Complaint on April 4, 2022. The Company is vigorously defending this civil enforcement action and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

- changed (2022-05-04):
[0000833444-22-000017:note_history:12]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.
  (was, 2022-02-02, similarity 0.8891):
[0000833444-22-000005:note_history:12]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. The Company recorded conditional asset retirement obligations for continuing operations of $29 million at both December 31, 2021 and September 30, 2021.

- added (2022-05-04):
[0000833444-22-000017:note_history:13]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. The Company's conditional asset retirement obligations for continuing operations were $29 million at both March 31, 2022 and September 30, 2021.

- added (2022-05-04):
[0000833444-22-000017:note_history:14]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 390 |  |  | 400 |  |
| Total asbestos-related liabilities | 448 |  |  | 458 |  |
| Other current assets | 36 |  |  | 13 |  |
| Other noncurrent assets | 326 |  |  | 365 |  |
| Total asbestos-related assets | 362 |  |  | 378 |  |
| Net asbestos-related liabilities | $ | 86 |  |  | $ | 80 |  |

- added (2022-05-04):
[0000833444-22-000017:note_history:15]
|  | March 31, 2022 |  | September 30, 2021 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 299 |  |  | 314 |  |
| Total restricted assets | 305 |  |  | 320 |  |
| Insurance recoveries for asbestos-related liabilities | 57 |  |  | 58 |  |
| Total asbestos-related assets | $ | 362 |  |  | $ | 378 |  |

- changed (2022-05-04):
[0000833444-22-000017:note_history:16]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 82 |  |  | $ | 77 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 216 |  |  | 226 |  |
| Total insurable liabilities | $ | 320 |  |  | $ | 325 |  |
  (was, 2022-02-02, similarity 0.977):
[0000833444-22-000005:note_history:16]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current liabilities | $ | 79 |  |  | $ | 77 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 218 |  |  | 226 |  |
| Total insurable liabilities | $ | 319 |  |  | $ | 325 |  |

- changed (2022-05-04):
[0000833444-22-000017:note_history:17]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 15 |  |  | 15 |  |
| Total insurable receivables | $ | 20 |  |  | $ | 20 |  |
  (was, 2022-02-02, similarity 0.9746):
[0000833444-22-000005:note_history:17]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 15 |  |  | 15 |  |
| Total insurable receivables | $ | 20 |  |  | $ | 20 |  |

- changed (2022-05-04):
[0000833444-22-000017:note_history:18]
PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. In March 2021, the EPA published its final determination to regulate PFOS and PFOA in drinking water. In October 2021, the EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which the EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.
  (was, 2022-02-02, similarity 0.8823):
[0000833444-22-000005:note_history:18]
PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. In March 2021, the EPA published its final determination to regulate PFOS and PFOA in drinking water. In October 2021, the EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which the EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater

- changed (2022-05-04):
[0000833444-22-000017:note_history:19]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation
  (was, 2022-02-02, similarity 0.8):
[0000833444-22-000005:note_history:19]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

- added (2022-05-04):
[0000833444-22-000017:note_history:20]
(“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

- changed (2022-05-04):
[0000833444-22-000017:note_history:21]
There are more than 2,200 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 2,100 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and transferred. There are four matters that are proceeding in state courts — three in Arizona and one in Texas.
  (was, 2022-02-02, similarity 0.7061):
[0000833444-22-000005:note_history:21]
There are more than 1,900 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 1,900 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and transferred. There are three matters that are proceeding in state court: One case, Young v. Chemguard et al., was filed in superior court in Maricopa County, Arizona, removed to the United States District Court, District of Arizona, and tagged to the MDL, but was remanded to state court prior to being transferred to the MDL. The decision to remand the case to state court is currently being appealed. The second case, Forbach et al. v. Chemguard et al., was filed in superior court in Coconino County, Arizona, and is proceeding with initial discovery. The third case, Ellison-Wood v. Chemguard, Inc., et al., was filed recently in district court in Tarrant County, Texas.

- changed (2022-05-04):
[0000833444-22-000017:note_history:22]
Chemguard and Tyco Fire Products have been named as defendants in approximately 183 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Alabama, Arizona, California, Colorado, Connecticut, Florida, Idaho, Illinois, Kentucky, Louisiana, Maryland, Massachusetts, Michigan, New Jersey, New York, North Carolina, Ohio, Pennsylvania, Virginia, Washington, West Virginia, Wisconsin, the District of Columbia, and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but four of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.
  (was, 2022-02-02, similarity 0.9971):
[0000833444-22-000005:note_history:22]
Chemguard and Tyco Fire Products have been named as defendants in approximately 168 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Alabama, Arizona, California, Colorado, Connecticut, Florida, Idaho, Illinois, Kentucky, Louisiana, Maryland, Massachusetts, Michigan, New Jersey, New York, North Carolina, Ohio, Pennsylvania, Virginia, Washington, West Virginia, Wisconsin, the District of Columbia, and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but five of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.

- changed (2022-05-04):
[0000833444-22-000017:note_history:23]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from
  (was, 2022-02-02, similarity 0.711):
[0000833444-22-000005:note_history:23]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

- added (2022-05-04):
[0000833444-22-000017:note_history:24]
firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

- changed (2022-05-04):
[0000833444-22-000017:note_history:25]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752-000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio. The lawsuit seeks to recover costs and natural resource damages associated with the contamination. This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.
  (was, 2022-02-02, similarity 0.9992):
[0000833444-22-000005:note_history:25]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752 -000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio. The lawsuit seeks to recover costs and natural resource damages associated with the contamination. This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

- added (2022-05-04):
[0000833444-22-000017:note_history:26]
In February 2022, the Attorney General of the State of Colorado filed a lawsuit in Colorado state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources, public health, and State property allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

- added (2022-05-04):
[0000833444-22-000017:note_history:27]
In April 2022, the Attorney General of the State of Florida filed a lawsuit in Florida state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage to the State’s natural resources and public health allegedly resulting from the use of firefighting foams at various locations throughout the State. It is anticipated that this complaint will be removed to federal court and transferred to the MDL.

- removed (2022-05-04):
[0000833444-22-000005:note_history:28]
boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.

- removed (2022-05-04):
[0000833444-22-000005:note_history:29]
During the third quarter of 2019, the Company increased its environmental reserves, which included $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.

- removed (2022-05-04):
[0000833444-22-000005:note_history:30]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

- removed (2022-05-04):
[0000833444-22-000005:note_history:31]
In December 2020, the Company received a notice from the Wisconsin Department of Justice (“WDOJ”) that the WDOJ was considering a potential civil enforcement action against the Company relating to environmental matters at the FTC including, but not limited to, the investigation and remediation of PFAS at or near the FTC as discussed above and the Company’s alleged failure to timely report the presence of PFAS chemicals at the FTC. Such enforcement action could seek civil monetary penalties and/or injunctive relief. The Company is presently unable to predict the duration, scope, or

- removed (2022-05-04):
[0000833444-22-000005:note_history:32]
results of any potential civil enforcement action that may result, the consequences of any such action, or the nature of any resolution of these potential claims with the WDOJ.

- removed (2022-05-04):
[0000833444-22-000005:note_history:33]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 395 |  |  | 400 |  |
| Total asbestos-related liabilities | 453 |  |  | 458 |  |
| Other current assets | 15 |  |  | 13 |  |
| Other noncurrent assets | 373 |  |  | 365 |  |
| Total asbestos-related assets | 388 |  |  | 378 |  |
| Net asbestos-related liabilities | $ | 65 |  |  | $ | 80 |  |

- removed (2022-05-04):
[0000833444-22-000005:note_history:34]
|  | December 31, 2021 |  | September 30, 2021 |
| Restricted |  |  |  |
| Cash | $ | 7 |  |  | $ | 6 |  |
| Investments | 323 |  |  | 314 |  |
| Total restricted assets | 330 |  |  | 320 |  |
| Insurance recoveries for asbestos-related liabilities | 58 |  |  | 58 |  |
| Total asbestos-related assets | $ | 388 |  |  | $ | 378 |  |

- removed (2022-05-04):
[0000833444-22-000005:note_history:35]
discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000833444-22-000017:note_history:36]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2021 filed with the SEC on November 15, 2021. The results of operations for the three and six month periods ended March 31, 2022 are not necessarily indicative of results for the Company’s 2022 fiscal year because of seasonal and other factors.
  (was, 2022-02-02, similarity 0.9776):
[0000833444-22-000005:note_history:36]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2021 filed with the SEC on November 15, 2021. The results of operations for the three-month period ended December 31, 2021 are not necessarily indicative of results for the Company’s 2022 fiscal year because of seasonal and other factors.

- changed (2022-05-04):
[0000833444-22-000017:note_history:37]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with U.S. GAAP. All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company’s interest exceeds 20% and the Company does not have a controlling interest.
  (was, 2022-02-02, similarity 0.9837):
[0000833444-22-000005:note_history:37]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with U.S. GAAP. All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the year are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company’s interest exceeds 20% and the Company does not have a controlling interest.

- changed (2022-05-04):
[0000833444-22-000017:note_history:38]
At March 31, 2022 and September 30, 2021, the Company held restricted cash of approximately $33 million and $6 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities and certain litigation and environmental matters.
  (was, 2022-02-02, similarity 0.9821):
[0000833444-22-000005:note_history:38]
At December 31, 2021 and September 30, 2021, the Company held restricted cash of approximately $15 million and $6 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities and certain litigation and environmental matters.

- changed (2022-05-04):
[0000833444-22-000017:note_history:39]
Effective October 1, 2021, the Company's marine businesses, which were previously included in the Building Solutions Asia Pacific and Global Products segments, became part of the Building Solutions EMEA/LA segment. Historical information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation. Refer to Note 8, "Goodwill and Other Intangible Assets," and Note 20, “Segment Information,” of the notes to the consolidated financial statements for further information.
  (was, 2022-02-02, similarity 0.8042):
[0000833444-22-000005:note_history:39]
Effective October 1, 2021, the Company's marine businesses previously included in the Building Solutions Asia Pacific and Global Products segments are now part of the Building Solutions EMEA/LA segment. Historical information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation. Refer to Note 8, "Goodwill and Other Intangible Assets," and Note 20, “Segment Information,” of the notes to consolidated financial statements for further information.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000833444-22-000017:note_history:40]
Debt and Financing Arrangements
As of March 31, 2022, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2022. As of March 31, 2022, there were no draws on the facilities.
  (was, 2022-02-02, similarity 0.7828):
[0000833444-22-000005:note_history:40]
Debt and Financing ArrangementsAs of December 31, 2021, the Company has a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which was renewed in December 2021 and is now scheduled to expire in December 2022. As of December 31, 2021, there were no draws on the facilities.
In November 2021, the Company entered into a €200 million bank term loan which is due in October 2022.

- added (2022-05-04):
[0000833444-22-000017:note_history:41]
In March 2022, the Company entered into two bank term loans totaling €285 million ($318 million as of March 31, 2022) which are both due in March 2023. In November 2021, the Company entered into a €200 million ($223 million as of March 31, 2022) bank term loan which is due in October 2022.

- changed (2022-05-04):
[0000833444-22-000017:note_history:42]
The Company had $1.5 billion of commercial paper outstanding as of March 31, 2022. No commercial paper was outstanding as of September 30, 2021.
  (was, 2022-02-02, similarity 0.9278):
[0000833444-22-000005:note_history:42]
The Company had $150 million of commercial paper outstanding as of December 31, 2021 and no commercial paper outstanding as of September 30, 2021.

- changed (2022-05-04):
[0000833444-22-000017:note_history:43]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Interest expense, net of capitalized interest costs | $ | 56 |  |  | $ | 53 |  |  | $ | 111 |  |  | $ | 112 |  |
| Banking fees and bond cost amortization | 5 |  |  | 4 |  |  | 10 |  |  | 12 |  |
| Interest income | (1) |  |  | (3) |  |  | (3) |  |  | (6) |  |
| Net foreign exchange results for financing activities | (9) |  |  | (10) |  |  | (14) |  |  | (15) |  |
| Net financing charges | $ | 51 |  |  | $ | 44 |  |  | $ | 104 |  |  | $ | 103 |  |
  (was, 2022-02-02, similarity 0.7995):
[0000833444-22-000005:note_history:43]
|  | Three Months Ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 55 |  |  | $ | 59 |  |  |  |  |  |
| Banking fees and bond cost amortization | 5 |  |  | 8 |  |  |  |  |  |
| Interest income | (2) |  |  | (3) |  |  |  |  |  |
| Net foreign exchange results for financing activities | (5) |  |  | (5) |  |  |  |  |  |
| Net financing charges | $ | 53 |  |  | $ | 59 |  |  |  |  |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000833444-22-000017:note_history:44]
The following table presents net sales to and purchases from related parties (in millions):
  (was, 2022-02-02, similarity 0.7982):
[0000833444-22-000005:note_history:44]
The following table presents net sales to and purchases from related parties for the three months ended December 31, 2021 and 2020 (in millions):

- changed (2022-05-04):
[0000833444-22-000017:note_history:45]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales to related parties |  | $ | 48 |  |  | $ | 53 |  |  | $ | 83 |  |  | $ | 97 |  |
| Purchases from related parties |  | 47 |  |  | 37 |  |  | 91 |  |  | 66 |  |
  (was, 2022-02-02, similarity 0.8551):
[0000833444-22-000005:note_history:45]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Net sales to related parties |  | $ | 35 |  |  | $ | 44 |  |  |  |  |  |
| Purchases from related parties |  | 44 |  |  | 29 |  |  |  |  |  |

- changed (2022-05-04):
[0000833444-22-000017:note_history:46]
|  |  | March 31, 2022 |  | September 30, 2021 |
| Receivable from related parties |  | $ | 63 |  |  | $ | 73 |  |
| Payable to related parties |  | 27 |  |  | 45 |  |
  (was, 2022-02-02, similarity 0.9686):
[0000833444-22-000005:note_history:46]
|  |  | December 31, 2021 |  | September 30, 2021 |
| Receivable from related parties |  | $ | 58 |  |  | $ | 73 |  |
| Payable to related parties |  | 15 |  |  | 45 |  |

- changed (2022-05-04):
[0000833444-22-000017:note_history:47]
Additionally, the Company leases certain facilities used in its operations from a related party. As of March 31, 2022, the right-of-use asset and lease liability associated with these leases were $10 million. As of September 30, 2021, the right-of-use asset associated with these leases was $11 million and the lease liability was $10 million. Amounts paid for these leases were not material.
  (was, 2022-02-02, similarity 0.9828):
[0000833444-22-000005:note_history:47]
Additionally, the Company leases certain facilities used in its operations from a related party. As of December 31, 2021, the right-of-use asset and lease liability associated with these leases were $10 million. As of September 30, 2021, the right-of-use asset associated with these leases was $11 million and the lease liability was $10 million. Amounts paid for these leases were not material.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000833444-22-000017:note_history:48]
The following table presents net sales to and purchases from related parties (in millions):
  (was, 2022-02-02, similarity 0.7982):
[0000833444-22-000005:note_history:48]
The following table presents net sales to and purchases from related parties for the three months ended December 31, 2021 and 2020 (in millions):

- changed (2022-05-04):
[0000833444-22-000017:note_history:49]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales to related parties |  | $ | 48 |  |  | $ | 53 |  |  | $ | 83 |  |  | $ | 97 |  |
| Purchases from related parties |  | 47 |  |  | 37 |  |  | 91 |  |  | 66 |  |
  (was, 2022-02-02, similarity 0.8551):
[0000833444-22-000005:note_history:49]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Net sales to related parties |  | $ | 35 |  |  | $ | 44 |  |  |  |  |  |
| Purchases from related parties |  | 44 |  |  | 29 |  |  |  |  |  |

- changed (2022-05-04):
[0000833444-22-000017:note_history:50]
|  |  | March 31, 2022 |  | September 30, 2021 |
| Receivable from related parties |  | $ | 63 |  |  | $ | 73 |  |
| Payable to related parties |  | 27 |  |  | 45 |  |
  (was, 2022-02-02, similarity 0.9686):
[0000833444-22-000005:note_history:50]
|  |  | December 31, 2021 |  | September 30, 2021 |
| Receivable from related parties |  | $ | 58 |  |  | $ | 73 |  |
| Payable to related parties |  | 15 |  |  | 45 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000833444-22-000017:note_history:51]
The following tables present the Company's revenues disaggregated by segment and by Products & Systems and Services revenue (in millions):
  (was, 2022-02-02, similarity 0.8196):
[0000833444-22-000005:note_history:51]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three months ended December 31, 2021 and 2020 (in millions):

- added (2022-05-04):
[0000833444-22-000017:note_history:52]
|  |  | Three Months Ended March 31, 2022 |  | Three Months Ended March 31, 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,343 |  |  | $ | 884 |  |  | $ | 2,227 |  |  | $ | 1,272 |  |  | $ | 820 |  |  | $ | 2,092 |  |
| Building Solutions EMEA/LA |  | 536 |  |  | 422 |  |  | 958 |  |  | 466 |  |  | 468 |  |  | 934 |  |
| Building Solutions Asia Pacific |  | 448 |  |  | 175 |  |  | 623 |  |  | 320 |  |  | 274 |  |  | 594 |  |
| Global Products |  | 2,290 |  |  | — |  |  | 2,290 |  |  | 1,974 |  |  | — |  |  | 1,974 |  |
| Total |  | $ | 4,617 |  |  | $ | 1,481 |  |  | $ | 6,098 |  |  | $ | 4,032 |  |  | $ | 1,562 |  |  | $ | 5,594 |  |

- changed (2022-05-04):
[0000833444-22-000017:note_history:53]
|  |  | Six Months Ended March 31, 2022 |  | Six Months Ended March 31, 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 2,642 |  |  | $ | 1,737 |  |  | $ | 4,379 |  |  | $ | 2,514 |  |  | $ | 1,612 |  |  | $ | 4,126 |  |
| Building Solutions EMEA/LA |  | 1,080 |  |  | 837 |  |  | 1,917 |  |  | 934 |  |  | 948 |  |  | 1,882 |  |
| Building Solutions Asia Pacific |  | 949 |  |  | 349 |  |  | 1,298 |  |  | 654 |  |  | 544 |  |  | 1,198 |  |
| Global Products |  | 4,366 |  |  | — |  |  | 4,366 |  |  | 3,729 |  |  | — |  |  | 3,729 |  |
| Total |  | $ | 9,037 |  |  | $ | 2,923 |  |  | $ | 11,960 |  |  | $ | 7,831 |  |  | $ | 3,104 |  |  | $ | 10,935 |  |
  (was, 2022-02-02, similarity 0.9116):
[0000833444-22-000005:note_history:53]
|  |  | Three Months Ended December 31, 2021 |  | Three Months Ended December 31, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,299 |  |  | $ | 853 |  |  | $ | 2,152 |  |  | $ | 1,242 |  |  | $ | 792 |  |  | $ | 2,034 |  |
| Building Solutions EMEA/LA |  | 544 |  |  | 415 |  |  | 959 |  |  | 468 |  |  | 480 |  |  | 948 |  |
| Building Solutions Asia Pacific |  | 501 |  |  | 174 |  |  | 675 |  |  | 334 |  |  | 270 |  |  | 604 |  |
| Global Products |  | 2,076 |  |  | — |  |  | 2,076 |  |  | 1,755 |  |  | — |  |  | 1,755 |  |
| Total |  | $ | 4,420 |  |  | $ | 1,442 |  |  | $ | 5,862 |  |  | $ | 3,799 |  |  | $ | 1,542 |  |  | $ | 5,341 |  |

- changed (2022-05-04):
[0000833444-22-000017:note_history:54]
The following table presents further disaggregation of Global Products segment revenues by product type (in millions):
  (was, 2022-02-02, similarity 0.8369):
[0000833444-22-000005:note_history:54]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2021 and 2020 (in millions):

- changed (2022-05-04):
[0000833444-22-000017:note_history:55]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 1,658 |  |  | $ | 1,374 |  |  | $ | 3,141 |  |  | $ | 2,592 |  |
| Fire & Security |  | 578 |  |  | 537 |  |  | 1,122 |  |  | 1,025 |  |
| Industrial Refrigeration |  | 54 |  |  | 63 |  |  | 103 |  |  | 112 |  |
| Total |  | $ | 2,290 |  |  | $ | 1,974 |  |  | $ | 4,366 |  |  | $ | 3,729 |  |
  (was, 2022-02-02, similarity 0.7092):
[0000833444-22-000005:note_history:55]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| HVAC |  | $ | 1,483 |  |  | $ | 1,218 |  |  |  |  |  |
| Fire & Security |  | 544 |  |  | 488 |  |  |  |  |  |
| Industrial Refrigeration |  | 49 |  |  | 49 |  |  |  |  |  |
| Total |  | $ | 2,076 |  |  | $ | 1,755 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0000833444-22-000017:note_history:56]
The following tables present the Company's revenues disaggregated by segment and by Products & Systems and Services revenue (in millions):
  (was, 2022-02-02, similarity 0.8196):
[0000833444-22-000005:note_history:56]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three months ended December 31, 2021 and 2020 (in millions):

- added (2022-05-04):
[0000833444-22-000017:note_history:57]
|  |  | Three Months Ended March 31, 2022 |  | Three Months Ended March 31, 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,343 |  |  | $ | 884 |  |  | $ | 2,227 |  |  | $ | 1,272 |  |  | $ | 820 |  |  | $ | 2,092 |  |
| Building Solutions EMEA/LA |  | 536 |  |  | 422 |  |  | 958 |  |  | 466 |  |  | 468 |  |  | 934 |  |
| Building Solutions Asia Pacific |  | 448 |  |  | 175 |  |  | 623 |  |  | 320 |  |  | 274 |  |  | 594 |  |
| Global Products |  | 2,290 |  |  | — |  |  | 2,290 |  |  | 1,974 |  |  | — |  |  | 1,974 |  |
| Total |  | $ | 4,617 |  |  | $ | 1,481 |  |  | $ | 6,098 |  |  | $ | 4,032 |  |  | $ | 1,562 |  |  | $ | 5,594 |  |

- changed (2022-05-04):
[0000833444-22-000017:note_history:58]
|  |  | Six Months Ended March 31, 2022 |  | Six Months Ended March 31, 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 2,642 |  |  | $ | 1,737 |  |  | $ | 4,379 |  |  | $ | 2,514 |  |  | $ | 1,612 |  |  | $ | 4,126 |  |
| Building Solutions EMEA/LA |  | 1,080 |  |  | 837 |  |  | 1,917 |  |  | 934 |  |  | 948 |  |  | 1,882 |  |
| Building Solutions Asia Pacific |  | 949 |  |  | 349 |  |  | 1,298 |  |  | 654 |  |  | 544 |  |  | 1,198 |  |
| Global Products |  | 4,366 |  |  | — |  |  | 4,366 |  |  | 3,729 |  |  | — |  |  | 3,729 |  |
| Total |  | $ | 9,037 |  |  | $ | 2,923 |  |  | $ | 11,960 |  |  | $ | 7,831 |  |  | $ | 3,104 |  |  | $ | 10,935 |  |
  (was, 2022-02-02, similarity 0.9116):
[0000833444-22-000005:note_history:58]
|  |  | Three Months Ended December 31, 2021 |  | Three Months Ended December 31, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,299 |  |  | $ | 853 |  |  | $ | 2,152 |  |  | $ | 1,242 |  |  | $ | 792 |  |  | $ | 2,034 |  |
| Building Solutions EMEA/LA |  | 544 |  |  | 415 |  |  | 959 |  |  | 468 |  |  | 480 |  |  | 948 |  |
| Building Solutions Asia Pacific |  | 501 |  |  | 174 |  |  | 675 |  |  | 334 |  |  | 270 |  |  | 604 |  |
| Global Products |  | 2,076 |  |  | — |  |  | 2,076 |  |  | 1,755 |  |  | — |  |  | 1,755 |  |
| Total |  | $ | 4,420 |  |  | $ | 1,442 |  |  | $ | 5,862 |  |  | $ | 3,799 |  |  | $ | 1,542 |  |  | $ | 5,341 |  |

- changed (2022-05-04):
[0000833444-22-000017:note_history:59]
The following table presents further disaggregation of Global Products segment revenues by product type (in millions):
  (was, 2022-02-02, similarity 0.8369):
[0000833444-22-000005:note_history:59]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2021 and 2020 (in millions):

- changed (2022-05-04):
[0000833444-22-000017:note_history:60]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 1,658 |  |  | $ | 1,374 |  |  | $ | 3,141 |  |  | $ | 2,592 |  |
| Fire & Security |  | 578 |  |  | 537 |  |  | 1,122 |  |  | 1,025 |  |
| Industrial Refrigeration |  | 54 |  |  | 63 |  |  | 103 |  |  | 112 |  |
| Total |  | $ | 2,290 |  |  | $ | 1,974 |  |  | $ | 4,366 |  |  | $ | 3,729 |  |
  (was, 2022-02-02, similarity 0.7092):
[0000833444-22-000005:note_history:60]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| HVAC |  | $ | 1,483 |  |  | $ | 1,218 |  |  |  |  |  |
| Fire & Security |  | 544 |  |  | 488 |  |  |  |  |  |
| Industrial Refrigeration |  | 49 |  |  | 49 |  |  |  |  |  |
| Total |  | $ | 2,076 |  |  | $ | 1,755 |  |  |  |  |  |

- added (2022-05-04):
[0000833444-22-000017:note_history:61]
|  |  | Location of contract balances |  | March 31, 2022 |  | September 30, 2021 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,851 |  |  | $ | 1,718 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 90 |  |  | 99 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,971) |  |  | (1,637) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (285) |  |  | (269) |  |  |  |

- added (2022-05-04):
[0000833444-22-000017:note_history:62]
For the three months ended March 31, 2022 and March 31, 2021, the Company recognized revenue of $308 million and $221 million, respectively, that was included in the beginning of period contract liability balance. For the six months ended March 31, 2022 and March 31, 2021, the Company recognized revenue of $1,059 million and $935 million, respectively, that was included in the beginning of period contract liability balance.

- changed (2022-05-04):
[0000833444-22-000017:note_history:63]
A performance obligation is a distinct good, service, or a bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is
  (was, 2022-02-02, similarity 0.8508):
[0000833444-22-000005:note_history:63]
A performance obligation is a distinct good, service, or a bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

- added (2022-05-04):
[0000833444-22-000017:note_history:64]
allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

- changed (2022-05-04):
[0000833444-22-000017:note_history:65]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of March 31, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $17.3 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.
  (was, 2022-02-02, similarity 0.9934):
[0000833444-22-000005:note_history:65]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of December 31, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $16.5 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

- changed (2022-05-04):
[0000833444-22-000017:note_history:66]
|  |  | March 31, 2022 |  | September 30, 2021 |  |  |
| Other current assets |  | $ | 150 |  |  | $ | 149 |  |  |  |
| Other noncurrent assets |  | 116 |  |  | 117 |  |  |  |
| Total |  | $ | 266 |  |  | $ | 266 |  |  |  |
  (was, 2022-02-02, similarity 0.9749):
[0000833444-22-000005:note_history:66]
|  |  | December 31, 2021 |  | September 30, 2021 |  |  |
| Other current assets |  | $ | 149 |  |  | $ | 149 |  |  |  |
| Other noncurrent assets |  | 120 |  |  | 117 |  |  |  |
| Total |  | $ | 269 |  |  | $ | 266 |  |  |  |

- added (2022-05-04):
[0000833444-22-000017:note_history:67]
During both the three months ended March 31, 2022 and 2021, the Company recognized amortization expense of $47 million related to costs to obtain or fulfill a contract. During the six months ended March 31, 2022 and 2021, the Company recognized amortization expense of $97 million and $88 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and six months ended March 31, 2022 and 2021.

- removed (2022-05-04):
[0000833444-22-000005:note_history:68]
|  |  | Location of contract balances |  | December 31, 2021 |  | September 30, 2021 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,806 |  |  | $ | 1,718 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 98 |  |  | 99 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,845) |  |  | (1,637) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (287) |  |  | (269) |  |  |  |

- removed (2022-05-04):
[0000833444-22-000005:note_history:69]
For the three months ended December 31, 2021 and December 31, 2020, the Company recognized revenue of $751 million and $714 million, respectively, that was included in the beginning of period contract liability balance.

- removed (2022-05-04):
[0000833444-22-000005:note_history:70]
During the three months ended December 31, 2021 and 2020, the Company recognized amortization expense of $50 million and $41 million, respectively, related to costs to obtain or fulfill a contract.  There were no impairment losses recognized in the three months ended December 31, 2021 and 2020.
