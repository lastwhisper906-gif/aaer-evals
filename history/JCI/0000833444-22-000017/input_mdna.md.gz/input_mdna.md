# JCI MD&A — 0000833444-22-000017


## mdna

[0000833444-22-000017:mdna:1]
[same as prior period, unchanged from 0000833444-22-000005:mdna:1]

[0000833444-22-000017:mdna:2]
[same as prior period, unchanged from 0000833444-22-000005:mdna:2]

[0000833444-22-000017:mdna:3]
[same as prior period, unchanged from 0000833444-22-000005:mdna:3]

[0000833444-22-000017:mdna:4]
[same as prior period, unchanged from 0000833444-22-000005:mdna:4]

[0000833444-22-000017:mdna:5]
[same as prior period, unchanged from 0000833444-22-000005:mdna:5]

[0000833444-22-000017:mdna:6]
The Company is a global leader in engineering, manufacturing and commissioning building products and systems, including residential and commercial HVAC equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its OpenBlue software platform and related digital capabilities. The Company partners with customers by leveraging its broad

[0000833444-22-000017:mdna:7]
product portfolio and digital capabilities powered by OpenBlue, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency and reduce greenhouse gas emissions.

[0000833444-22-000017:mdna:8]
The following information should be read in conjunction with the September 30, 2021 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2021 filed with the SEC on November 15, 2021. References in the following discussion and analysis to "Three Months" (or similar language) refer to the three months ended March 31, 2022 compared to the three months ended March 31, 2021, while "Year-to-Date" refers to the six months ended March 31, 2022 compared to the six months ended March 31, 2021.

[0000833444-22-000017:mdna:9]
[same as prior period, unchanged from 0000833444-22-000005:mdna:9]

[0000833444-22-000017:mdna:10]
[same as prior period, unchanged from 0000833444-22-000005:mdna:10]

[0000833444-22-000017:mdna:11]
[same as prior period, unchanged from 0000833444-22-000005:mdna:11]

[0000833444-22-000017:mdna:12]
[same as prior period, unchanged from 0000833444-22-000005:mdna:12]

[0000833444-22-000017:mdna:13]
The Company has experienced, and expects to continue to experience, increased input material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends, including increased global demand, the conflict between Russia and Ukraine, government-mandated actions in response to COVID-19 and labor shortages. Actions taken by the Company to mitigate supply chain disruptions and inflation, including expanding and redistributing its supplier network, supplier financing, price increases and productivity improvements, have generally been successful in offsetting some, but not all, of the impact of these trends. The collective impact of these trends has been to positively impact revenue due to increased demand and price increases in response to inflation and negatively impact margins due to supply chain disruptions and cost pressures. The Company has also experienced delays in converting its backlog due to continued supply chain disruptions, negatively impacting both revenues and margins. The Company expects that these trends will continue to impact the Company's results for the remainder of fiscal 2022. Therefore, the Company could experience further disruptions, shortages and cost increases in the future, the effect of which will depend on the Company’s ability to successfully mitigate and offset the impact of these events.

[0000833444-22-000017:mdna:14]
During the second quarter of fiscal 2022, the Company suspended its operations in Russia in response to the conflict between Russia and Ukraine. Although this decision has not had and is not expected to have a material impact on the Company’s operating results, the broader consequences of this conflict, including heightened supply chain disruption, inflation, economic instability and other factors have and could continue to adversely impact the Company’s results of operations. In addition, other potential consequences of the conflict could impact the Company’s results of operations in the future. See Item 1A of Part II of this Form 10-Q for more information on the potential adverse impacts of the Russia/Ukraine conflict.

[0000833444-22-000017:mdna:15]
44

[0000833444-22-000017:mdna:16]
[same as prior period, unchanged from 0000833444-22-000005:mdna:14]

[0000833444-22-000017:mdna:17]
[same as prior period, unchanged from 0000833444-22-000005:mdna:15]

[0000833444-22-000017:mdna:18]
The Company’s affiliates, employees, suppliers, customers and others have been and may continue to be restricted or prevented from conducting normal business activities, including as a result of shutdowns, travel restrictions and other actions that may be requested or mandated by governmental authorities. During the first six months of fiscal 2022, the Company’s facilities generally operated at normal levels, however the Company has experienced some disruptions to its business in China due to government-mandated lockdowns in several major cities. It is expected that the impact of these lockdowns will continue into the third quarter of fiscal 2022.

[0000833444-22-000017:mdna:19]
The Company continues to focus its efforts on preserving the health and safety of its employees and customers, as well as maintaining the continuity of its operations. The Company modified its business practices in response to the COVID-19 outbreak and instituted preventive measures at its facilities. The Company has adopted and implemented a multifaceted framework to guide its decision making as it reopens its offices and facilities to employees.

[0000833444-22-000017:mdna:20]
The Company has experienced increases in both demand and volumes as governments have distributed vaccines and lifted COVID-19-related restrictions, leading to increases in retrofit activity and commercial building construction. The global pandemic has also provided the Company with the opportunity to help its customers by delivering solutions and support that enhance the safety and increase the efficiency of their operations. As a result of the pandemic, the Company has seen an increase in demand for its products and solutions that promote building health and optimize customers’ infrastructure.

[0000833444-22-000017:mdna:21]
However, the Company continues to be influenced by COVID-19-related trends impacting site access and the labor force, which have and may continue to negatively impact the Company’s revenues and margins. Challenges in reaching sufficient vaccination levels and the introduction of new variants of COVID-19 have caused some governments to extend or reinstitute lockdowns and similar restrictive measures, which, in some cases, have limited the Company’s ability to access customer sites to install and maintain its products and deliver services. In addition, the Company has experienced and continues to experience labor shortages at certain facilities as the Company expands its production capacity to meet increased customer demand. Although the Company is mitigating these shortages through focused recruitment efforts and competitive compensation packages, the Company could continue to experience such shortages in the future. In addition, the Company’s efforts to comply with vaccination mandates instated by governments and customers, including requirements that some or all of the Company's employees and subcontractors be fully vaccinated against COVID-19, could result in increased labor attrition or disruption, and could adversely impact the Company’s ability to deliver services to its customers.

[0000833444-22-000017:mdna:22]
The extent to which the COVID-19 pandemic continues to impact the Company’s results of operations and financial condition will depend on future developments that are highly uncertain and cannot be predicted, including the resurgence of COVID-19 and its variants in regions recovering from the impacts of the pandemic, the effectiveness of COVID-19 vaccines and the speed at which populations are vaccinated around the globe, the impact of COVID-19 on economic activity, and regulatory actions taken to contain its impact on public health and the global economy. See Item 1A of Part II of the Company's Form 10-Q for the quarterly period ending December 31, 2021 for additional discussion of risks related to COVID-19.

[0000833444-22-000017:mdna:23]
[same as prior period, unchanged from 0000833444-22-000005:mdna:21]

[0000833444-22-000017:mdna:24]
[same as prior period, unchanged from 0000833444-22-000005:mdna:22]

[0000833444-22-000017:mdna:25]
[same as prior period, unchanged from 0000833444-22-000005:mdna:74]

[0000833444-22-000017:mdna:26]
[same as prior period, unchanged from 0000833444-22-000005:mdna:24]

[0000833444-22-000017:mdna:27]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Net sales | $ | 6,098 |  |  | $ | 5,594 |  |  | 9 | % |  | $ | 11,960 |  |  | $ | 10,935 |  |  | 9 | % |

[0000833444-22-000017:mdna:28]
The increase in consolidated net sales for the three months ended March 31, 2022 was due to higher organic sales ($503 million) and incremental sales from acquisitions ($119 million), partially offset by the unfavorable impact of foreign currency translation ($110 million), and lower sales due to business divestitures ($8 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 9% as compared to the prior year, attributable to higher volumes and increased pricing in response to inflation pressures. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-22-000017:mdna:29]
The increase in consolidated net sales for the six months ended March 31, 2022 was due to higher organic sales ($943 million) and incremental sales from acquisitions ($247 million), partially offset by the unfavorable impact of foreign currency translation ($155 million), and lower sales due to business divestitures ($10 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 9% as compared to the prior year, attributable to higher volumes and increased pricing in response to inflation pressures. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-22-000017:mdna:30]
[same as prior period, unchanged from 0000833444-22-000005:mdna:27]

[0000833444-22-000017:mdna:31]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Cost of sales | $ | 4,141 |  |  | $ | 3,651 |  |  | 13 | % |  | $ | 8,112 |  |  | $ | 7,264 |  |  | 12 | % |
| Gross profit | 1,957 |  |  | 1,943 |  |  | 1 | % |  | 3,848 |  |  | 3,671 |  |  | 5 | % |
| % of sales | 32.1 | % |  | 34.7 | % |  |  |  | 32.2 | % |  | 33.6 | % |  |  |

[0000833444-22-000017:mdna:32]
Cost of sales and gross profit increased for the three-month period ended March 31, 2022, and gross profit as a percentage of sales decreased by 260 basis points. Gross profit increased due to organic sales growth, business acquisitions, and favorable foreign currency translation ($77 million), partially offset by the unfavorable year-over-year impact of net mark-to-market adjustments on pension plans ($66 million). Gross profit as a percentage of sales decreased as the benefit of volume leverage was more than offset by supply chain inefficiencies and price/cost pressures.  Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-22-000017:mdna:33]
Cost of sales and gross profit increased for the six-month period ended March 31, 2022, and gross profit as a percentage of sales decreased by 140 basis points. Gross profit increased due to organic sales growth, business acquisitions, favorable foreign currency translation ($111 million), partially offset by the unfavorable year-over-year impact of net mark-to-market adjustments on pension plans ($57 million). Gross profit as a percentage of sales decreased as the benefit of volume leverage was more than offset by supply chain inefficiencies and price/cost pressures.  Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-22-000017:mdna:34]
[same as prior period, unchanged from 0000833444-22-000005:mdna:30]

[0000833444-22-000017:mdna:35]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Selling, general and administrative expenses | $ | 1,454 |  |  | $ | 1,253 |  |  | 16 | % |  | $ | 2,823 |  |  | $ | 2,547 |  |  | 11 | % |
| % of sales | 23.8 | % |  | 22.4 | % |  |  |  | 23.6 | % |  | 23.3 | % |  |  |

[0000833444-22-000017:mdna:36]
Selling, general and administrative expenses ("SG&A") for the three-month period ended March 31, 2022 increased $201 million, and SG&A as a percentage of sales increased by 140 basis points. The increase in SG&A was primarily due to the unfavorable year-over-year impact of net mark-to-market adjustments on pension plans ($210 million), absence of certain one-time cost mitigation actions, the unfavorable year-over-year impact of net mark-to-market adjustments on restricted asbestos investments and current year business acquisitions, partially offset by a favorable earn-out liability adjustment ($43 million) and favorable foreign currency translation ($24 million). Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-22-000017:mdna:37]
Selling, general and administrative expenses ("SG&A") for the six-month period ended March 31, 2022 increased $276 million, and SG&A as a percentage of sales increased by 30 basis points. The increase in SG&A was primarily due to the unfavorable year-over-year impact of net mark-to-market adjustments on pension plans ($176 million), the absence of certain one-time cost mitigation actions, incremental sales investments and current year business acquisitions and the unfavorable year-over-year impact of net mark-to-market adjustments on restricted asbestos investments, partially offset by a favorable earn-out liability adjustment ($43 million) and favorable foreign currency translation ($34 million). Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-22-000017:mdna:38]
[same as prior period, unchanged from 0000833444-22-000005:mdna:34]

[0000833444-22-000017:mdna:39]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Restructuring and impairment costs | $ | 384 |  |  | $ | 96 |  |  | * |  | $ | 433 |  |  | $ | 96 |  |  | * |

[0000833444-22-000017:mdna:40]
[same as prior period, unchanged from 0000833444-22-000005:mdna:36]

[0000833444-22-000017:mdna:41]
Refer to Note 17, "Significant Restructuring and Impairment Costs," and Note 18, "Impairment of Long-Lived Assets," of the notes to the consolidated financial statements and "Restructuring" below within this Item 2 for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-22-000017:mdna:42]
[same as prior period, unchanged from 0000833444-22-000005:mdna:38]

[0000833444-22-000017:mdna:43]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Net financing charges | $ | 51 |  |  | $ | 44 |  |  | 16 | % |  | $ | 104 |  |  | $ | 103 |  |  | 1 | % |

[0000833444-22-000017:mdna:44]
Refer to Note 10, "Debt and Financing Arrangements," of the notes to the consolidated financial statements for further disclosure related to the Company's net financing charges.

[0000833444-22-000017:mdna:45]
[same as prior period, unchanged from 0000833444-22-000005:mdna:41]

[0000833444-22-000017:mdna:46]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Equity income | $ | 42 |  |  | $ | 56 |  |  | -25 | % |  | $ | 112 |  |  | $ | 114 |  |  | -2 | % |

[0000833444-22-000017:mdna:47]
The decrease in equity income for the three months ended March 31, 2022 was primarily due to lower income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-22-000017:mdna:48]
The decrease in equity income for the six months ended March 31, 2022 was primarily due to lower income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture, partially offset by higher income at certain partially-owned affiliates within the Building Solutions EMEA/LA segment.  Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-22-000017:mdna:49]
47

[0000833444-22-000017:mdna:50]
[same as prior period, unchanged from 0000833444-22-000005:mdna:44]

[0000833444-22-000017:mdna:51]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Income tax provision | $ | 58 |  |  | $ | 209 |  |  | -72 | % |  | $ | 129 |  |  | $ | 270 |  |  | -52 | % |
| Effective tax rate | 52.7 | % |  | 34.5 | % |  |  |  | 21.5 | % |  | 26.0 | % |  |  |

[0000833444-22-000017:mdna:52]
[same as prior period, unchanged from 0000833444-22-000005:mdna:46]

[0000833444-22-000017:mdna:53]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended March 31, 2022, the Company's effective tax rate for continuing operations was 52.7% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of an impairment charge, the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestiture of its Global Retail business, and tax rate differentials, partially offset by the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives. For the six months ended March 31, 2022, the Company's effective tax rate for continuing operations was 21.5% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of an impairment charge, the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestiture of its Global Retail business, and tax rate differentials, partially offset by the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives. For the three months ended March 31, 2021, the Company's effective tax rate for continuing operations was 34.5% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the six months ended March 31, 2021, the Company's effective tax rate for continuing operations was 26.0% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. The effective tax rate for the six months ended March 31, 2022 decreased as compared to the six months ended March 31, 2021 primarily due to the discrete tax items. Refer to Note 19, "Income Taxes," of the notes to the consolidated financial statements for further detail.

[0000833444-22-000017:mdna:54]
[same as prior period, unchanged from 0000833444-22-000005:mdna:49]

[0000833444-22-000017:mdna:55]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Income from discontinued operations, net of tax | $ | — |  |  | $ | — |  |  | * |  | $ | — |  |  | $ | 124 |  |  | * |

[0000833444-22-000017:mdna:56]
[same as prior period, unchanged from 0000833444-22-000005:mdna:51]

[0000833444-22-000017:mdna:57]
Refer to Note 4, "Discontinued Operations & Assets and Liabilities Held for Sale," of the notes to the consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-22-000017:mdna:58]
[same as prior period, unchanged from 0000833444-22-000005:mdna:53]

[0000833444-22-000017:mdna:59]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 41 |  |  | $ | 54 |  |  | -24 | % |  | $ | 79 |  |  | $ | 99 |  |  | -20 | % |

[0000833444-22-000017:mdna:60]
The decrease in income from continuing operations attributable to noncontrolling interests for the three and six months ended March 31, 2022 was primarily due to lower net income at certain partially-owned affiliates within the Global Products segment.

[0000833444-22-000017:mdna:61]
[same as prior period, unchanged from 0000833444-22-000005:mdna:56]

[0000833444-22-000017:mdna:62]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Net income attributable to Johnson Controls | $ | 11 |  |  | $ | 343 |  |  | -97 | % |  | $ | 392 |  |  | $ | 794 |  |  | -51 | % |

[0000833444-22-000017:mdna:63]
The decrease in net income attributable to Johnson Controls for the three months ended March 31, 2022 was primarily due to higher restructuring and impairment costs and higher SG&A, partially offset by lower income tax provision. The decrease in net income attributable to Johnson Controls for the six months ended March 31, 2022 was primarily due to higher restructuring and impairment costs, higher SG&A and prior year income from discontinued operations, partially offset by higher gross profit and lower income tax provision.

[0000833444-22-000017:mdna:64]
Diluted earnings per share attributable to Johnson Controls for the three months ended March 31, 2022 was $0.02 compared to $0.48 for the three months ended March 31, 2021. Diluted earnings per share attributable to Johnson Controls for the six months ended March 31, 2022 was $0.56 compared to $1.10 for the six months ended March 31, 2021.

[0000833444-22-000017:mdna:65]
[same as prior period, unchanged from 0000833444-22-000005:mdna:60]

[0000833444-22-000017:mdna:66]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 13 |  |  | $ | 437 |  |  | -97 | % |  | $ | 481 |  |  | $ | 1,160 |  |  | -59 | % |

[0000833444-22-000017:mdna:67]
The decrease in comprehensive income attributable to Johnson Controls for the three months ended March 31, 2022 was due to lower net income attributable to Johnson Controls ($332 million) and a decrease in other comprehensive income attributable to Johnson Controls ($92 million) resulting primarily from currency translation adjustments. The year-over-year unfavorable foreign currency translation adjustments were primarily driven by the strengthening of the British pound against the U.S. dollar in the prior quarter.

[0000833444-22-000017:mdna:68]
The decrease in comprehensive income attributable to Johnson Controls for the six months ended March 31, 2022 was due to lower net income attributable to Johnson Controls ($402 million) and a decrease in other comprehensive income attributable to Johnson Controls ($277 million) resulting primarily from currency translation adjustments. The year-over-year unfavorable foreign currency translation adjustments were primarily driven by the strengthening of the British pound, euro and Mexican peso against the U.S. dollar in the prior year.

[0000833444-22-000017:mdna:69]
[same as prior period, unchanged from 0000833444-22-000005:mdna:64]

[0000833444-22-000017:mdna:70]
[same as prior period, unchanged from 0000833444-22-000005:mdna:65]

[0000833444-22-000017:mdna:71]
Effective October 1, 2021, the Company's marine businesses previously included in Building Solutions Asia Pacific and Global Products reportable segments are now part of Building Solutions EMEA/LA reportable segment. Historical information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation. Refer to Note 20, “Segment Information,” of the notes to the consolidated financial statements for further information.

[0000833444-22-000017:mdna:72]
[same as prior period, unchanged from 0000833444-22-000005:mdna:67]

[0000833444-22-000017:mdna:73]
[same as prior period, unchanged from 0000833444-22-000005:mdna:68]

[0000833444-22-000017:mdna:74]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Building Solutions North America | $ | 2,227 |  |  | $ | 2,092 |  |  | 6 | % |  | $ | 4,379 |  |  | $ | 4,126 |  |  | 6 | % |
| Building Solutions EMEA/LA | 958 |  |  | 934 |  |  | 3 | % |  | 1,917 |  |  | 1,882 |  |  | 2 | % |
| Building Solutions Asia Pacific | 623 |  |  | 594 |  |  | 5 | % |  | 1,298 |  |  | 1,198 |  |  | 8 | % |
| Global Products | 2,290 |  |  | 1,974 |  |  | 16 | % |  | 4,366 |  |  | 3,729 |  |  | 17 | % |
|  | $ | 6,098 |  |  | $ | 5,594 |  |  | 9 | % |  | $ | 11,960 |  |  | $ | 10,935 |  |  | 9 | % |

[0000833444-22-000017:mdna:75]
Three Months:

[0000833444-22-000017:mdna:76]
•The increase in Building Solutions North America was due to higher volumes and prices ($131 million) and incremental sales related to business acquisitions ($4 million). The sales increase was led by high-single digit growth in service and strong growth in the HVAC & Controls platform.

[0000833444-22-000017:mdna:77]
•The increase in Building Solutions EMEA/LA was due to higher volumes and prices ($70 million) and incremental sales related to business acquisitions ($7 million), partially offset by the unfavorable impact of foreign currency translation ($45 million) and business divestitures ($8 million). The increase in sales was driven by low double-digit growth in service and strong performance in Fire & Security platforms. By region, strong growth in Europe and Latin America was partially offset by continued weakness in the Middle East.

[0000833444-22-000017:mdna:78]
•The increase in Building Solutions Asia Pacific was due to higher volumes and prices ($36 million) and incremental sales related to business acquisitions ($10 million), partially offset by the unfavorable impact of foreign currency translation ($17 million). The increase in sales was led by strong demand for Commercial Applied HVAC & Controls and Industrial Refrigeration equipment. China remains the primary source of growth.

[0000833444-22-000017:mdna:79]
•The increase in Global Products was due to higher volumes and prices ($266 million) and incremental sales related to business acquisitions ($98 million), partially offset by the unfavorable impact of foreign currency translation ($48 million). Sales growth was driven by broad-based demand for Commercial and Residential HVAC and Fire & Security products.

[0000833444-22-000017:mdna:80]
Year-to-Date:

[0000833444-22-000017:mdna:81]
•The increase in Building Solutions North America was due to higher volumes and prices ($238 million), incremental sales related to business acquisitions ($9 million) and the favorable impact of foreign currency translation ($6 million). The sales increase was led by strong growth in service and the HVAC & Controls platform.

[0000833444-22-000017:mdna:82]
•The increase in Building Solutions EMEA/LA was due to higher volumes and prices ($96 million) and incremental sales related to business acquisitions ($15 million), partially offset by the unfavorable impact of foreign currency translation ($67 million) and business divestitures ($9 million). The increase in sales was driven by growth in service and strong performance in Fire & Security. By region, strong growth in Europe and Latin America was partially offset by continued weakness in the Middle East.

[0000833444-22-000017:mdna:83]
•The increase in Building Solutions Asia Pacific was due to higher volumes and prices ($105 million) and incremental sales related to business acquisitions ($19 million), partially offset by the unfavorable impact of foreign currency translation ($23 million) and business divestitures ($1 million). The increase in sales was led by strong demand for Commercial Applied HVAC & Controls. China remains the primary source of growth.

[0000833444-22-000017:mdna:84]
•The increase in Global Products was due to higher volumes and prices ($504 million) and incremental sales related to business acquisitions ($204 million), partially offset by the unfavorable impact of foreign currency translation ($71 million). Sales growth was driven by broad-based demand Commercial and Residential HVAC and Fire & Security products.

[0000833444-22-000017:mdna:85]
[same as prior period, unchanged from 0000833444-22-000005:mdna:75]

[0000833444-22-000017:mdna:86]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  | 2022 |  | 2021 |  | Change |
| Building Solutions North America | $ | 235 |  |  | $ | 266 |  |  | -12 | % |  | $ | 485 |  |  | $ | 521 |  |  | -7 | % |
| Building Solutions EMEA/LA | 79 |  |  | 88 |  |  | -10 | % |  | 183 |  |  | 186 |  |  | -2 | % |
| Building Solutions Asia Pacific | 74 |  |  | 73 |  |  | 1 | % |  | 142 |  |  | 150 |  |  | -5 | % |
| Global Products | 412 |  |  | 284 |  |  | 45 | % |  | 713 |  |  | 496 |  |  | 44 | % |
|  | $ | 800 |  |  | $ | 711 |  |  | 13 | % |  | $ | 1,523 |  |  | $ | 1,353 |  |  | 13 | % |

[0000833444-22-000017:mdna:87]
Three Months:

[0000833444-22-000017:mdna:88]
•The decrease in Building Solutions North America was primarily due to continued investment spending and lower absorption related to supply chain disruptions and labor constraints, partially offset by favorable volumes and productivity savings.

[0000833444-22-000017:mdna:89]
•The decrease in Building Solutions EMEA/LA was primarily due to the suspension of operations in Russia ($11 million), supply chain disruptions, unfavorable mix, lower equity income and the unfavorable impact of foreign currency translation ($4 million), partially offset by favorable price/cost and productivity savings.

[0000833444-22-000017:mdna:90]
•The increase in Building Solutions Asia Pacific was primarily due to productivity savings, partially offset by  unfavorable price/cost, supply chain disruptions, unfavorable mix and the unfavorable impact of foreign currency translation ($4 million).

[0000833444-22-000017:mdna:91]
•The increase in Global Products was primarily due to favorable volumes and mix, productivity savings and a favorable earn-out liability adjustment ($43 million), partially offset by unfavorable price/cost, continued investment spending, lower equity income driven primarily by certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture ($13 million) and the unfavorable impact of foreign currency translation ($1 million).

[0000833444-22-000017:mdna:92]
Year-to-Date:

[0000833444-22-000017:mdna:93]
•The decrease in Building Solutions North America was primarily due to continued investment spending and lower absorption related to supply chain disruptions and labor constraints, partially offset by favorable volumes, productivity savings and foreign currency translation ($2 million).

[0000833444-22-000017:mdna:94]
•The decrease in Building Solutions EMEA/LA was primarily due to the suspension of operations in Russia ($11 million) and the unfavorable impact of foreign currency translation ($6 million), partially offset by favorable price/cost and productivity savings.

[0000833444-22-000017:mdna:95]
•The decrease in Building Solutions Asia Pacific was primarily due to unfavorable mix, unfavorable price/cost and the unfavorable impact of foreign currency translation ($6 million), partially offset by favorable volume leverage and productivity savings.

[0000833444-22-000017:mdna:96]
•The increase in Global Products was primarily due to favorable volumes and mix, productivity savings, a favorable earn-out liability adjustment ($43 million) and the favorable impact of foreign currency translation ($1 million), partially offset by unfavorable price/cost and lower equity income driven primarily by certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture ($5 million).

[0000833444-22-000017:mdna:97]
[same as prior period, unchanged from 0000833444-22-000005:mdna:128]

[0000833444-22-000017:mdna:98]
[same as prior period, unchanged from 0000833444-22-000005:mdna:81]

[0000833444-22-000017:mdna:99]
The Company’s backlog is applicable to its sales of systems and services. At March 31, 2022, the backlog was $11.4 billion, of which $10.9 billion was attributable to the field business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-22-000017:mdna:100]
At March 31, 2022, remaining performance obligations were $17.3 billion, which is $5.9 billion higher than the Company's backlog of $11.4 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-22-000017:mdna:101]
[same as prior period, unchanged from 0000833444-22-000005:mdna:84]

[0000833444-22-000017:mdna:102]
•The Company excludes from remaining performance obligations certain contracts with customers with a term of one year or less or contracts that are cancelable without substantial penalty while these contracts are included within backlog; and

[0000833444-22-000017:mdna:103]
•Remaining performance obligations include the full remaining term of service contracts with substantial termination penalties versus backlog which includes only one year for all outstanding service contracts.

[0000833444-22-000017:mdna:104]
The Company reports backlog as it believes it is a useful measure of evaluating the Company's operational performance and relationship to total orders.

[0000833444-22-000017:mdna:105]
[same as prior period, unchanged from 0000833444-22-000005:mdna:88]

[0000833444-22-000017:mdna:106]
[same as prior period, unchanged from 0000833444-22-000005:mdna:89]

[0000833444-22-000017:mdna:107]
|  | March 31, |  | September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Current assets | $ | 11,612 |  |  | $ | 9,998 |  |  |  |
| Current liabilities | (11,654) |  |  | (9,098) |  |  |  |
|  | (42) |  |  | 900 |  |  | * |
| Less: Cash and cash equivalents | (1,787) |  |  | (1,336) |  |  |  |
| Add: Short-term debt | 2,044 |  |  | 8 |  |  |  |
| Add: Current portion of long-term debt | 240 |  |  | 226 |  |  |  |
| Less: Current assets held for sale | (386) |  |  | — |  |  |  |
| Add: Current liabilities held for sale | 326 |  |  | — |  |  |  |
| Working capital (as defined) | $ | 395 |  |  | $ | (202) |  |  | * |
| Accounts receivable - net | $ | 5,689 |  |  | $ | 5,613 |  |  | 1 | % |
| Inventories | 2,515 |  |  | 2,057 |  |  | 22 | % |
| Accounts payable | 4,101 |  |  | 3,746 |  |  | 9 | % |

[0000833444-22-000017:mdna:108]
* Measure not meaningful

[0000833444-22-000017:mdna:109]
•The Company defines working capital as current assets less current liabilities, excluding cash, short-term debt, the current portion of long-term debt, and current assets and liabilities held for sale. Management believes that this measure of working capital, which excludes financing-related items and businesses to be divested, provides a more useful measurement of the Company’s operating performance.

[0000833444-22-000017:mdna:110]
•The increase in working capital at March 31, 2022 as compared to September 30, 2021, was primarily due to an increase in inventory due to supply chain disruptions and a decrease in accrued compensation and benefits liabilities, partially offset by an increase in accounts payable and deferred revenue.

[0000833444-22-000017:mdna:111]
•The Company’s days sales in accounts receivable at March 31, 2022 and September 30, 2021 were 58 days for both periods. There has been no significant adverse changes in the level of overdue receivables or significant changes in revenue recognition methods.

[0000833444-22-000017:mdna:112]
•The Company’s inventory turns for the three months ended March 31, 2022 were lower than the comparable period ended September 30, 2021, primarily due to supply chain disruptions.

[0000833444-22-000017:mdna:113]
•Days in accounts payable at March 31, 2022 were 84 days, higher than 76 days at the comparable period ended September 30, 2021, primarily due to timing.

[0000833444-22-000017:mdna:114]
[same as prior period, unchanged from 0000833444-22-000005:mdna:96]

[0000833444-22-000017:mdna:115]
|  |  | Six Months Ended March 31, |
| (in millions) |  | 2022 |  | 2021 |
| Cash provided by operating activities |  | $ | 324 |  |  | $ | 1,160 |  |
| Cash used by investing activities |  | (332) |  |  | (119) |  |
| Cash provided (used) by financing activities |  | 444 |  |  | (1,079) |  |

[0000833444-22-000017:mdna:116]
•The decrease in cash provided by operating activities was primarily due to increases in accounts receivable and inventory.

[0000833444-22-000017:mdna:117]
•The increase in cash used by investing activities was primarily due to higher cash payments made for acquisitions and capital expenditures.

[0000833444-22-000017:mdna:118]
•The increase in cash provided by financing activities was primarily due to higher net short-term debt borrowings, partially offset by higher stock repurchases.

[0000833444-22-000017:mdna:119]
[same as prior period, unchanged from 0000833444-22-000005:mdna:101]

[0000833444-22-000017:mdna:120]
|  | March 31, |  | September 30, |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |
| Short-term debt | $ | 2,044 |  |  | $ | 8 |  |  |  |
| Current portion of long-term debt | 240 |  |  | 226 |  |  |  |
| Long-term debt | 7,366 |  |  | 7,506 |  |  |  |
| Total debt | 9,650 |  |  | 7,740 |  |  | 25 | % |
| Less: Cash and cash equivalents | 1,787 |  |  | 1,336 |  |  |  |
| Total net debt | 7,863 |  |  | 6,404 |  |  | 23 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 16,536 |  |  | 17,562 |  |  | -6 | % |
| Total capitalization | $ | 24,399 |  |  | $ | 23,966 |  |  | 2 | % |
| Total net debt as a % of total capitalization | 32.2 | % |  | 26.7 | % |  |  |

[0000833444-22-000017:mdna:121]
[same as prior period, unchanged from 0000833444-22-000005:mdna:103]

[0000833444-22-000017:mdna:122]
[same as prior period, unchanged from 0000833444-22-000005:mdna:104]

[0000833444-22-000017:mdna:123]
•As of March 31, 2022, approximately $4 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity, and the economic environment.

[0000833444-22-000017:mdna:124]
•The Company declared a dividend of $0.35 per common share in the quarter ended March 31, 2022. It has increased its dividend for two consecutive quarters and 30% since the fourth quarter of 2021. The Company intends to continue paying dividends throughout fiscal 2022.

[0000833444-22-000017:mdna:125]
•The Company believes its capital resources and liquidity position at March 31, 2022 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, minimum pension contributions, debt maturities and any potential acquisitions or stock repurchases in the remainder of fiscal 2022 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the second quarter of fiscal 2022, the Company took advantage of low interest rates in euro commercial paper markets and borrowed $1.5 billion in commercial paper, which the Company intends to repay by the end of the fiscal year. In the event the Company is unable to issue commercial paper, it would have the ability to draw on its $2.5 billion revolving credit facility which expires in December 2024 or its $0.5 billion 364-day revolving credit facility which expires in December 2022. There were no draws on the revolving credit facilities as of March 31, 2022 and September 30, 2021. The Company estimates that, as of March 31, 2022, it could borrow up to $1.5 billion based on average borrowing levels during the second quarter of fiscal 2022 on committed credit lines. The Company maintains a shelf registration statement with the SEC under which it may issue additional debt securities, ordinary shares, preferred shares, depositary shares, warrants purchase contracts and units that may be offered in one or more offerings on terms to be determined at the time of the offering. The Company anticipates that the proceeds of any offering would be used for general corporate purposes, including repayment of indebtedness, acquisitions, additions to working capital, repurchases of ordinary shares, dividends, capital expenditures and investments in the Company's subsidiaries. In addition, the Company held cash and cash equivalents of $1.8 billion as of March 31, 2022. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-22-000017:mdna:126]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of March 31, 2022, the Company's credit ratings and outlook were as follows:

[0000833444-22-000017:mdna:127]
[same as prior period, unchanged from 0000833444-22-000005:mdna:110]

[0000833444-22-000017:mdna:128]
[same as prior period, unchanged from 0000833444-22-000005:mdna:111]

[0000833444-22-000017:mdna:129]
•Financial covenants in the Company's revolving credit facilities requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of March 31, 2022, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-22-000017:mdna:130]
54

[0000833444-22-000017:mdna:131]
•The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2022, the Company believes the long-term rate of return will approximate 7.00%, 3.70% and 5.30% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first six months of fiscal 2022, the Company made approximately $76 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $100 million in cash to its defined benefit pension plans in fiscal 2022. The Company expects to contribute $3 million in cash to its postretirement plans in fiscal 2022.

[0000833444-22-000017:mdna:132]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in fiscal 2022, the Company provided income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain subsidiaries as the result of the planned divestiture of its Global Retail business. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-22-000017:mdna:133]
[same as prior period, unchanged from 0000833444-22-000005:mdna:117]

[0000833444-22-000017:mdna:134]
•Refer to Note 10, "Debt and Financing Arrangements," of the notes to the consolidated financial statements for additional information on items impacting capitalization.

[0000833444-22-000017:mdna:135]
[same as prior period, unchanged from 0000833444-22-000005:mdna:119]

[0000833444-22-000017:mdna:136]
[same as prior period, unchanged from 0000833444-22-000005:mdna:120]

[0000833444-22-000017:mdna:137]
•In fiscal 2021, the Company announced plans to optimize its cost structure through broad-based SG&A actions focused on simplification, standardization and centralization, with the intent to deliver annualized savings of $300 million by fiscal 2023. Additionally, the Company announced cost of sales actions intended to drive $250 million in annual run rate savings by fiscal 2023. The one-time pre-tax costs associated with these actions are estimated to be approximately $385 million across all segments and at Corporate. During the three and six months ended March 31, 2022, the Company recorded $27 million and $76 million, respectively, of costs resulting from the 2021 restructuring plan. The restructuring action is expected to be substantially complete in fiscal 2023. The Company has outstanding restructuring reserves of $71 million at March 31, 2022, all of which is expected to be paid in cash.

[0000833444-22-000017:mdna:138]
[same as prior period, unchanged from 0000833444-22-000005:mdna:122]

[0000833444-22-000017:mdna:139]
The following information is provided in compliance with Rule 13-01 of Regulation S-X under the Securities Exchange Act of 1934 with respect to the (i) $625 million aggregate principal amount of 1.750% Senior Notes due 2030 (the “2030 Notes”), (ii) €500 million aggregate principal amount of 0.375% Senior Notes due 2027 (the “2027 Notes”), (iii) €500 million aggregate principal amount of 1.000% Senior Notes due 2032 (the “2032 Notes”) and (iv) $500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due 2031 (the “2031 Notes” and together with the 2032 Notes, the 2030 Notes and the 2027 Notes, the “Notes”), each issued by Johnson Controls International plc ("Parent Company") and Tyco Fire & Security Finance S.C.A. (“TFSCA”), a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”).

[0000833444-22-000017:mdna:140]
[same as prior period, unchanged from 0000833444-22-000005:mdna:124]

[0000833444-22-000017:mdna:141]
[same as prior period, unchanged from 0000833444-22-000005:mdna:125]

[0000833444-22-000017:mdna:142]
[same as prior period, unchanged from 0000833444-22-000005:mdna:126]

[0000833444-22-000017:mdna:143]
|  |  | Six Months Ended March 31, 2022 |  | Year EndedSeptember 30, 2021 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Loss from continuing operations |  | (113) |  |  | (212) |  |  |
| Net loss |  | (113) |  |  | (212) |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net loss attributable to the entity |  | (113) |  |  | (212) |  |  |

[0000833444-22-000017:mdna:144]
Excluded from the table above are intercompany transactions between the Obligor Group and Non-Obligor Subsidiaries as follows (in millions):

[0000833444-22-000017:mdna:145]
|  |  | Six Months Ended March 31, 2022 |  | Year EndedSeptember 30, 2021 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Income from continuing operations |  | 47 |  |  | 223 |  |  |
| Net income |  | 47 |  |  | 223 |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net income attributable to the entity |  | 47 |  |  | 223 |  |  |

[0000833444-22-000017:mdna:146]
56

[0000833444-22-000017:mdna:147]
The following table presents summarized balance sheet information as of March 31, 2022 and September 30, 2021 (in millions):

[0000833444-22-000017:mdna:148]
|  |  | March 31, 2022 |  | September 30, 2021 |  |
| Current assets |  | $ | 361 |  |  | $ | 1,036 |  |  |
| Noncurrent assets |  | 265 |  |  | 280 |  |  |
| Current liabilities |  | 3,799 |  |  | 1,825 |  |  |
| Noncurrent liabilities |  | 7,129 |  |  | 7,260 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-22-000017:mdna:149]
Excluded from the table above are intercompany balances between the Obligor Group and Non-Obligor Subsidiaries as follows (in millions):

[0000833444-22-000017:mdna:150]
|  |  | March 31, 2022 |  | September 30, 2021 |  |
| Current assets |  | $ | 1,154 |  |  | $ | 465 |  |  |
| Noncurrent assets |  | 2,987 |  |  | 2,992 |  |  |
| Current liabilities |  | 1,892 |  |  | 1,660 |  |  |
| Noncurrent liabilities |  | 7,070 |  |  | 7,199 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-22-000017:mdna:151]
[same as prior period, unchanged from 0000833444-22-000005:mdna:135]

[0000833444-22-000017:mdna:152]
[same as prior period, unchanged from 0000833444-22-000005:mdna:136]

[0000833444-22-000017:mdna:153]
Refer to Note 2, "New Accounting Standards," of the notes to the consolidated financial statements.

[0000833444-22-000017:mdna:154]
Critical Accounting Estimates

[0000833444-22-000017:mdna:155]
The Company prepares its consolidated financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). This requires management to make estimates and assumptions that affect reported amounts and related disclosures. Actual results could differ from those estimates. The Company’s critical accounting estimates requiring significant judgement that could materially impact the Company's results of operations, financial position and cash flows are described in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in the Company’s Annual Report on Form 10-K for the year ended September 30, 2021. Since the date of the Company’s most recent Annual Report, there have been no material changes in the Company’s critical accounting estimates or assumptions.
