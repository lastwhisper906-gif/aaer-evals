# JCI notes — 0000833444-22-000017


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-22-000017:notes:1]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2021 filed with the SEC on November 15, 2021. The results of operations for the three and six month periods ended March 31, 2022 are not necessarily indicative of results for the Company’s 2022 fiscal year because of seasonal and other factors.

[0000833444-22-000017:notes:2]
[same as prior period, unchanged from 0000833444-22-000005:notes:2]

[0000833444-22-000017:notes:3]
[same as prior period, unchanged from 0000833444-22-000005:notes:3]

[0000833444-22-000017:notes:4]
[same as prior period, unchanged from 0000833444-22-000005:notes:4]

[0000833444-22-000017:notes:5]
[same as prior period, unchanged from 0000833444-22-000005:notes:5]

[0000833444-22-000017:notes:6]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with U.S. GAAP. All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company’s interest exceeds 20% and the Company does not have a controlling interest.

[0000833444-22-000017:notes:7]
[same as prior period, unchanged from 0000833444-22-000005:notes:7]

[0000833444-22-000017:notes:8]
[same as prior period, unchanged from 0000833444-22-000005:notes:8]

[0000833444-22-000017:notes:9]
At March 31, 2022 and September 30, 2021, the Company held restricted cash of approximately $33 million and $6 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities and certain litigation and environmental matters.

[0000833444-22-000017:notes:10]
[same as prior period, unchanged from 0000833444-22-000005:notes:10]

[0000833444-22-000017:notes:11]
Effective October 1, 2021, the Company's marine businesses, which were previously included in the Building Solutions Asia Pacific and Global Products segments, became part of the Building Solutions EMEA/LA segment. Historical information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation. Refer to Note 8, "Goodwill and Other Intangible Assets," and Note 20, “Segment Information,” of the notes to the consolidated financial statements for further information.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000833444-22-000017:notes:12]
New Accounting Standards
Recently Adopted Accounting Pronouncements

[0000833444-22-000017:notes:13]
In October 2021, the FASB issued ASU No. 2021-08, “Business Combinations (Topic 805), Accounting for Contract Assets and Contract Liabilities from Contracts with Customers,” which requires contract assets and contract liabilities (e.g. deferred revenue) acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, “Revenue from Contracts with Customers.” Generally, this new guidance will result in the acquirer recognizing contract assets and contract liabilities at the same amounts recorded by the acquiree. Historically, such amounts were recognized by the acquirer at fair value in acquisition accounting. The guidance is applied prospectively to acquisitions occurring on or after the effective date. During the quarter ended December 31, 2021, the Company early adopted ASU No. 2021-08. The adoption of the new standard did not have a material impact on the Company's consolidated financial statements.

[0000833444-22-000017:notes:14]
Recently Issued Accounting Pronouncements

[0000833444-22-000017:notes:15]
Recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-22-000017:notes:16]
Acquisitions and Divestitures
During the first six months of fiscal 2022, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $160 million, of which $124 million was paid as of March 31, 2022. In connection with the acquisitions, the Company recorded goodwill of $45 million within the Building Solutions Asia Pacific segment, $29 million within the Building Solutions EMEA/LA segment and $24 million within the Building Solutions North America segment.

[0000833444-22-000017:notes:17]
During the first six months of fiscal 2022, the Company completed a divestiture within the Buildings Solutions EMEA/LA segment. The selling price, net of cash divested, was $18 million, of which $16 million was received as of March 31, 2022. In connection with the divestiture, the Company reduced goodwill by $5 million.

[0000833444-22-000017:notes:18]
During the first six months of fiscal 2021, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $15 million, of which $10 million was paid as of March 31, 2021.  In connection with the acquisitions, the Company recorded goodwill of $13 million within the Building Solutions EMEA/LA segment.

[0000833444-22-000017:notes:19]
During the first six months of fiscal 2021, the Company completed certain divestitures within the Buildings Solutions Asia Pacific segment. The combined selling price was $23 million, of which $19 million was received as of March 31, 2021. In connection with the divestitures, the Company reduced goodwill by $6 million.

[0000833444-22-000017:notes:20]
Acquisitions and divestitures were not material to the Company's consolidated financial statements in the first six months of fiscal 2022 or 2021.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-22-000017:notes:21]
Discontinued Operations & Assets and Liabilities Held for Sale
On April 30, 2019, the Company completed the sale of its Power Solutions business. In December 2020, the favorable resolution of certain post-closing working capital and net debt adjustments resulted in income from discontinued operations, net of tax, of $124 million due to a reversal of a reserve established in connection with the sale.

[0000833444-22-000017:notes:22]
The following table summarizes the results of Power Solutions which are classified as discontinued operations (in millions):

[0000833444-22-000017:notes:23]
|  |  |  | Six Months Ended March 31, 2021 |
| Net sales |  |  | $ | — |  |
| Income from discontinued operations before income taxes |  |  | 150 |  |
| Provision for income taxes on discontinued operations |  |  | (26) |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax |  |  | — |  |
| Income from discontinued operations |  |  | $ | 124 |  |

[0000833444-22-000017:notes:24]
There is no Power Solutions related activity for the three and six months ended March 31, 2022 and the three months ended March 31, 2021.

[0000833444-22-000017:notes:25]
Assets and Liabilities Held for Sale

[0000833444-22-000017:notes:26]
During the second quarter of fiscal 2022, the Company determined that its Global Retail business within its Building Solutions North America, Building Solutions Asia Pacific and Building Solutions EMEA/LA segments met the criteria to be classified as held for sale. The assets and liabilities of this business are presented as held for sale in the consolidated statements of financial position as of March 31, 2022. Assets and liabilities held for sale are required to be recorded at the lower of carrying value or fair value, less costs to sell in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets". The carrying amount of any assets, including goodwill, that are part of the disposal group, but not in the scope of ASC 360-10, should be tested for impairment under the relevant guidance prior to measuring the disposal group at fair value, less cost to sell. Accordingly, the Company recorded a non-cash impairment charge of $235 million within restructuring and impairment costs in the consolidated statements of income to write down the goodwill related to its North America Retail reporting unit. Refer to Note 8, "Goodwill and Other Intangible Assets," of the notes to the consolidated financial statements for further information regarding the goodwill impairment charges. Additionally, the Company has recorded total impairment charges of $86 million within restructuring and impairment costs in the consolidated statements of income to write down the disposal group to its estimated fair value, less costs to sell. Refer to Note 18, "Impairment of Long-Lived Assets," of the notes to the consolidated financial statements for further information regarding the impairment charges. The divestiture of the business held for sale could result in a gain or loss on sale to the extent the ultimate selling price differs from the current carrying value of the net assets recorded, which could be material. The business did not meet the criteria to be classified as a discontinued operation as the divestiture of the business does not represent a strategic shift that will have a major effect on the Company's operations and financial results.

[0000833444-22-000017:notes:27]
The following table summarizes the carrying value of the Global Retail assets and liabilities held for sale (in millions):

[0000833444-22-000017:notes:28]
|  |  |  | March 31, 2022 |
| Accounts receivable - net |  |  | $ | 195 |  |
| Inventories |  |  | 142 |
| Other current assets |  |  | 49 |
| Current assets held for sale |  |  | $ | 386 |  |
| Property, plant and equipment - net |  |  | $ | 90 |  |
| Goodwill |  |  | 7 |  |
| Other intangible assets - net |  |  | 544 |  |
| Other noncurrent assets |  |  | 279 |  |
| Noncurrent assets held for sale |  |  | $ | 920 |  |
| Accounts payable |  |  | $ | 132 |  |
| Accrued compensation and benefits |  |  | 32 |
| Deferred revenue |  |  | 46 |
| Other current liabilities |  |  | 116 |
| Current liabilities held for sale |  |  | $ | 326 |  |
| Other noncurrent liabilities |  |  | $ | 228 |  |
| Noncurrent liabilities held for sale |  |  | $ | 228 |  |

[0000833444-22-000017:notes:29]
During the third quarter of fiscal 2020, the Company determined that certain noncurrent assets of the Building Solutions Asia Pacific segment met the criteria to be classified as held for sale. The estimated fair value, less costs to sell, of these assets was $159 million at March 31, 2022 and $156 million at September 30, 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-22-000017:notes:30]
[same as prior period, unchanged from 0000833444-22-000005:notes:24]

[0000833444-22-000017:notes:31]
The following tables present the Company's revenues disaggregated by segment and by Products & Systems and Services revenue (in millions):

[0000833444-22-000017:notes:32]
|  |  | Three Months Ended March 31, 2022 |  | Three Months Ended March 31, 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,343 |  |  | $ | 884 |  |  | $ | 2,227 |  |  | $ | 1,272 |  |  | $ | 820 |  |  | $ | 2,092 |  |
| Building Solutions EMEA/LA |  | 536 |  |  | 422 |  |  | 958 |  |  | 466 |  |  | 468 |  |  | 934 |  |
| Building Solutions Asia Pacific |  | 448 |  |  | 175 |  |  | 623 |  |  | 320 |  |  | 274 |  |  | 594 |  |
| Global Products |  | 2,290 |  |  | — |  |  | 2,290 |  |  | 1,974 |  |  | — |  |  | 1,974 |  |
| Total |  | $ | 4,617 |  |  | $ | 1,481 |  |  | $ | 6,098 |  |  | $ | 4,032 |  |  | $ | 1,562 |  |  | $ | 5,594 |  |

[0000833444-22-000017:notes:33]
|  |  | Six Months Ended March 31, 2022 |  | Six Months Ended March 31, 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 2,642 |  |  | $ | 1,737 |  |  | $ | 4,379 |  |  | $ | 2,514 |  |  | $ | 1,612 |  |  | $ | 4,126 |  |
| Building Solutions EMEA/LA |  | 1,080 |  |  | 837 |  |  | 1,917 |  |  | 934 |  |  | 948 |  |  | 1,882 |  |
| Building Solutions Asia Pacific |  | 949 |  |  | 349 |  |  | 1,298 |  |  | 654 |  |  | 544 |  |  | 1,198 |  |
| Global Products |  | 4,366 |  |  | — |  |  | 4,366 |  |  | 3,729 |  |  | — |  |  | 3,729 |  |
| Total |  | $ | 9,037 |  |  | $ | 2,923 |  |  | $ | 11,960 |  |  | $ | 7,831 |  |  | $ | 3,104 |  |  | $ | 10,935 |  |

[0000833444-22-000017:notes:34]
The following table presents further disaggregation of Global Products segment revenues by product type (in millions):

[0000833444-22-000017:notes:35]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 1,658 |  |  | $ | 1,374 |  |  | $ | 3,141 |  |  | $ | 2,592 |  |
| Fire & Security |  | 578 |  |  | 537 |  |  | 1,122 |  |  | 1,025 |  |
| Industrial Refrigeration |  | 54 |  |  | 63 |  |  | 103 |  |  | 112 |  |
| Total |  | $ | 2,290 |  |  | $ | 1,974 |  |  | $ | 4,366 |  |  | $ | 3,729 |  |

[0000833444-22-000017:notes:36]
[same as prior period, unchanged from 0000833444-22-000005:notes:29]

[0000833444-22-000017:notes:37]
[same as prior period, unchanged from 0000833444-22-000005:notes:30]

[0000833444-22-000017:notes:38]
[same as prior period, unchanged from 0000833444-22-000005:notes:31]

[0000833444-22-000017:notes:39]
|  |  | Location of contract balances |  | March 31, 2022 |  | September 30, 2021 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,851 |  |  | $ | 1,718 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 90 |  |  | 99 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,971) |  |  | (1,637) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (285) |  |  | (269) |  |  |  |

[0000833444-22-000017:notes:40]
For the three months ended March 31, 2022 and March 31, 2021, the Company recognized revenue of $308 million and $221 million, respectively, that was included in the beginning of period contract liability balance. For the six months ended March 31, 2022 and March 31, 2021, the Company recognized revenue of $1,059 million and $935 million, respectively, that was included in the beginning of period contract liability balance.

[0000833444-22-000017:notes:41]
[same as prior period, unchanged from 0000833444-22-000005:notes:34]

[0000833444-22-000017:notes:42]
A performance obligation is a distinct good, service, or a bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is

[0000833444-22-000017:notes:43]
allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

[0000833444-22-000017:notes:44]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of March 31, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $17.3 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-22-000017:notes:45]
[same as prior period, unchanged from 0000833444-22-000005:notes:37]

[0000833444-22-000017:notes:46]
[same as prior period, unchanged from 0000833444-22-000005:notes:38]

[0000833444-22-000017:notes:47]
[same as prior period, unchanged from 0000833444-22-000005:notes:39]

[0000833444-22-000017:notes:48]
|  |  | March 31, 2022 |  | September 30, 2021 |  |  |
| Other current assets |  | $ | 150 |  |  | $ | 149 |  |  |  |
| Other noncurrent assets |  | 116 |  |  | 117 |  |  |  |
| Total |  | $ | 266 |  |  | $ | 266 |  |  |  |

[0000833444-22-000017:notes:49]
During both the three months ended March 31, 2022 and 2021, the Company recognized amortization expense of $47 million related to costs to obtain or fulfill a contract. During the six months ended March 31, 2022 and 2021, the Company recognized amortization expense of $97 million and $88 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and six months ended March 31, 2022 and 2021.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0000833444-22-000017:notes:50]
[same as prior period, unchanged from 0000833444-22-000005:notes:42]

[0000833444-22-000017:notes:51]
The Company enters into various factoring agreements to sell certain accounts receivable to third-party financial institutions. For the majority of these agreements, for ease of administration, the Company collects customer payments related to the factored receivables on behalf of the financial institutions but otherwise maintains no continuing involvement with respect to the factored receivables. Sales of accounts receivable are reflected as a reduction of accounts receivable in the consolidated statements of financial position and the proceeds are included in cash flows from operating activities in the consolidated statements of cash flows. The Company sold $234 million and $368 million of accounts receivable under these factoring agreements  during the three and six months ended March 31, 2022, respectively. The cost of factoring such receivables was not material. As of March 31, 2022, $234 million of previously sold receivables were still outstanding. No receivables were factored during the six months ended March 31, 2021.

[0000833444-22-000017:notes:52]
[same as prior period, unchanged from 0000833444-22-000005:notes:44]

[0000833444-22-000017:notes:53]
|  |  | March 31, 2022 |  | September 30, 2021 |  |  |
| Accounts receivable |  | $ | 5,768 |  |  | $ | 5,723 |  |  |  |
| Less: Allowance for expected credit losses |  | (79) |  |  | (110) |  |  |  |
| Accounts receivable, net |  | $ | 5,689 |  |  | $ | 5,613 |  |  |  |

[0000833444-22-000017:notes:54]
The changes in the allowance for expected credit losses related to accounts receivable were as follows (in millions):

[0000833444-22-000017:notes:55]
|  | Six Months Ended March 31, |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Balance at beginning of period | $ | 110 |  |  | $ | 173 |  |  |  |  |  |
| Provision (benefit) for expected credit losses | (7) |  |  | 3 |  |  |  |  |  |
| Write-offs charged against the allowance for expected credit losses | (20) |  |  | (32) |  |  |  |  |  |
| Other | (4) |  |  | 4 |  |  |  |  |  |
| Balance at end of period | $ | 79 |  |  | $ | 148 |  |  |  |  |  |


## us-gaap:InventoryDisclosureTextBlock

[0000833444-22-000017:notes:56]
[same as prior period, unchanged from 0000833444-22-000005:notes:48]

[0000833444-22-000017:notes:57]
|  | March 31, 2022 |  | September 30, 2021 |
| Raw materials and supplies | $ | 998 |  |  | $ | 769 |  |
| Work-in-process | 212 |  |  | 166 |  |
| Finished goods | 1,305 |  |  | 1,122 |  |
| Inventories | $ | 2,515 |  |  | $ | 2,057 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-22-000017:notes:58]
Goodwill and Other Intangible Assets
Effective October 1, 2021, the Company's marine businesses previously included in the Building Solutions Asia Pacific and Global Products reportable segments became part of the Building Solutions EMEA/LA reportable segment. Historical information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation or the allocation of goodwill.

[0000833444-22-000017:notes:59]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the six-month period ended March 31, 2022 were as follows (in millions):

[0000833444-22-000017:notes:60]
|  |  |  | Business Acquisitions |  | Business Divestitures |  | Impairments |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  |  |  | March 31, |
|  | 2021 |  |  |  |  |  | 2022 |
| Building Solutions North America | $ | 9,215 |  |  | $ | 24 |  |  | $ | — |  |  | $ | (235) |  |  | $ | 12 |  |  | $ | 9,016 |  |
| Building Solutions EMEA/LA | 2,041 |  |  | 38 |  |  | (82) |  |  | — |  |  | (54) |  |  | 1,943 |  |
| Building Solutions Asia Pacific | 1,237 |  |  | 45 |  |  | (16) |  |  | — |  |  | 4 |  |  | 1,270 |  |
| Global Products | 5,842 |  |  | 16 |  |  | — |  |  | — |  |  | (58) |  |  | 5,800 |  |
| Total | $ | 18,335 |  |  | $ | 123 |  |  | $ | (98) |  |  | $ | (235) |  |  | $ | (96) |  |  | $ | 18,029 |  |

[0000833444-22-000017:notes:61]
Business divestitures include $77 million and $16 million of goodwill within the Building Solutions EMEA/LA and Building Solutions Asia Pacific reportable segments, respectively, transferred to noncurrent assets held for sale on the consolidated statements of financial position related to plans to dispose of the Global Retail business.

[0000833444-22-000017:notes:62]
The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. In the second quarter of fiscal 2022, the Company concluded it had a triggering event requiring assessment of goodwill impairment for its North America Retail reporting unit in conjunction with classifying its Global Retail business as held for sale. Refer to Note 4, "Discontinued Operations & Assets and Liabilities Held for Sale," of the notes to the consolidated financial statements for further disclosure related to the Global Retail assets held for sale. As a result, the Company recorded a non-cash impairment charge of $235 million within restructuring and impairment costs in the consolidated statements of income in the second quarter of fiscal 2022. The North America Retail reporting unit has no remaining goodwill balance as of March 31, 2022. The Company used the market approach to estimate the fair value of the reporting unit based on the relative estimated sales proceeds for the planned disposal of the Global Retail business attributable to the North America Retail reporting unit. The inputs utilized in the analysis are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-22-000017:notes:63]
There were no other triggering events requiring that an impairment assessment be conducted in the six months ended March 31, 2022. However, it is possible that future changes in circumstances would require the Company to record additional non-cash impairment charges.

[0000833444-22-000017:notes:64]
At March 31, 2022, accumulated goodwill impairment charges totaled $706 million, of which $659 million related to the North America Retail reporting unit and $47 million related to the Building Solutions EMEA/LA reporting unit. At September 30, 2021, accumulated goodwill impairment charges totaled $471 million, of which $424 million related to the North America Retail reporting unit and $47 million related to the Building Solutions EMEA/LA reporting unit.

[0000833444-22-000017:notes:65]
[same as prior period, unchanged from 0000833444-22-000005:notes:55]

[0000833444-22-000017:notes:66]
|  | March 31, 2022 |  | September 30, 2021 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,376 |  |  | $ | (621) |  |  | $ | 755 |  |  | $ | 1,464 |  |  | $ | (629) |  |  | $ | 835 |  |
| Customer relationships | 2,853 |  |  | (1,240) |  |  | 1,613 |  |  | 3,097 |  |  | (1,191) |  |  | 1,906 |  |
| Miscellaneous | 703 |  |  | (358) |  |  | 345 |  |  | 750 |  |  | (354) |  |  | 396 |  |
|  | 4,932 |  |  | (2,219) |  |  | 2,713 |  |  | 5,311 |  |  | (2,174) |  |  | 3,137 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,176 |  |  | — |  |  | 2,176 |  |  | 2,332 |  |  | — |  |  | 2,332 |  |
| Miscellaneous | — |  |  | — |  |  | — |  |  | 80 |  |  | — |  |  | 80 |  |
|  | 2,176 |  |  | — |  |  | 2,176 |  |  | 2,412 |  |  | — |  |  | 2,412 |  |
| Total intangible assets | $ | 7,108 |  |  | $ | (2,219) |  |  | $ | 4,889 |  |  | $ | 7,723 |  |  | $ | (2,174) |  |  | $ | 5,549 |  |

[0000833444-22-000017:notes:67]
Amortization of other intangible assets included within continuing operations for the three-month periods ended March 31, 2022 and 2021 was $106 million and $104 million, respectively. Amortization of other intangible assets included within continuing operations for the six month periods ended March 31, 2022 and 2021 was $224 million and $208 million, respectively.

[0000833444-22-000017:notes:68]
The Company reviews indefinite-lived intangible assets for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. There were no triggering events requiring that an impairment assessment be conducted in the six months ended March 31, 2022. However, it is possible that future changes in circumstances would require the Company to record additional non-cash impairment charges.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-22-000017:notes:69]
Leases
The following table presents supplemental consolidated statement of financial position information (in millions):

[0000833444-22-000017:notes:70]
|  | Location of lease balances |  | March 31, 2022 |  | September 30, 2021 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,072 |  |  | $ | 1,376 |  |
| Operating lease liabilities - current | Other current liabilities |  | 253 |  |  | 319 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 813 |  |  | 1,055 |  |

[0000833444-22-000017:notes:71]
The following table presents supplemental noncash operating lease activity, excluding leases acquired in business combinations (in millions):

[0000833444-22-000017:notes:72]
|  |  |  |  | Six Months Ended March 31, |  |  |
|  |  |  |  |  |  | 2022 |  | 2021 |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  |  |  |  |  | $ | 152 |  |  | $ | 303 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-22-000017:notes:73]
Debt and Financing Arrangements
As of March 31, 2022, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2022. As of March 31, 2022, there were no draws on the facilities.

[0000833444-22-000017:notes:74]
In March 2022, the Company entered into two bank term loans totaling €285 million ($318 million as of March 31, 2022) which are both due in March 2023. In November 2021, the Company entered into a €200 million ($223 million as of March 31, 2022) bank term loan which is due in October 2022.

[0000833444-22-000017:notes:75]
The Company had $1.5 billion of commercial paper outstanding as of March 31, 2022. No commercial paper was outstanding as of September 30, 2021.

[0000833444-22-000017:notes:76]
Net Financing Charges

[0000833444-22-000017:notes:77]
Net financing charges consisted of the following (in millions):

[0000833444-22-000017:notes:78]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Interest expense, net of capitalized interest costs | $ | 56 |  |  | $ | 53 |  |  | $ | 111 |  |  | $ | 112 |  |
| Banking fees and bond cost amortization | 5 |  |  | 4 |  |  | 10 |  |  | 12 |  |
| Interest income | (1) |  |  | (3) |  |  | (3) |  |  | (6) |  |
| Net foreign exchange results for financing activities | (9) |  |  | (10) |  |  | (14) |  |  | (15) |  |
| Net financing charges | $ | 51 |  |  | $ | 44 |  |  | $ | 104 |  |  | $ | 103 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-22-000017:notes:79]
Derivative Instruments and Hedging Activities
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, stock-based compensation liabilities and interest rates. Under Company policy, the use of derivatives is restricted to those intended for hedging purposes; the use of any derivative instrument for speculative purposes is strictly prohibited. A description of each type of derivative utilized by the Company to manage risk is included in the following paragraphs. In addition, refer to Note 12, "Fair Value Measurements," of the notes to the consolidated financial statements for information related to the fair value measurements and valuation methods utilized by the Company for each derivative type.

[0000833444-22-000017:notes:80]
[same as prior period, unchanged from 0000833444-22-000005:notes:69]

[0000833444-22-000017:notes:81]
[same as prior period, unchanged from 0000833444-22-000005:notes:70]

[0000833444-22-000017:notes:82]
[same as prior period, unchanged from 0000833444-22-000005:notes:71]

[0000833444-22-000017:notes:83]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of accumulated other comprehensive income (loss) ("AOCI") and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three and six months ended March 31, 2022 and 2021.

[0000833444-22-000017:notes:84]
[same as prior period, unchanged from 0000833444-22-000005:notes:73]

[0000833444-22-000017:notes:85]
|  |  | Volume Outstanding as of |
| Commodity |  | March 31, 2022 |  | September 30, 2021 |
| Copper |  | 3,496 |  |  | 2,656 |  |
| Aluminum |  | 7,310 |  |  | 5,159 |  |

[0000833444-22-000017:notes:86]
[same as prior period, unchanged from 0000833444-22-000005:notes:75]

[0000833444-22-000017:notes:87]
[same as prior period, unchanged from 0000833444-22-000005:notes:76]

[0000833444-22-000017:notes:88]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in AOCI attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company's net investments globally. The Company had 2.3 billion of euro-denominated bonds designated as net investment hedges of a portion of its net investment in European subsidiaries and 25 billion of yen-denominated debt designated as a net investment hedge of a portion of its net investment in Japanese subsidiaries as of March 31, 2022 and September 30, 2021.

[0000833444-22-000017:notes:89]
[same as prior period, unchanged from 0000833444-22-000005:notes:78]

[0000833444-22-000017:notes:90]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount. The Company hedged approximately 0.3 million of its ordinary shares, which have a cost basis of $23 million, as of March 31, 2022 and September 30, 2021.

[0000833444-22-000017:notes:91]
[same as prior period, unchanged from 0000833444-22-000005:notes:80]

[0000833444-22-000017:notes:92]
[same as prior period, unchanged from 0000833444-22-000005:notes:81]

[0000833444-22-000017:notes:93]
[same as prior period, unchanged from 0000833444-22-000005:notes:82]

[0000833444-22-000017:notes:94]
|  | Derivatives and Hedging Activities Designated as Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | March 31, |  | September 30, |  | March 31, |  | September 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 29 |  |  | $ | 15 |  |  | $ | 19 |  |  | $ | 17 |  |
| Commodity derivatives | 9 |  |  | 2 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 22 |  |  | 23 |  |
| Total assets | $ | 38 |  |  | $ | 17 |  |  | $ | 41 |  |  | $ | 40 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 9 |  |  | $ | 11 |  |  | $ | 25 |  |  | $ | 6 |  |
| Commodity derivatives | — |  |  | 1 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 2,795 |  |  | 2,918 |  |  | — |  |  | — |  |
| Total liabilities | $ | 2,804 |  |  | $ | 2,930 |  |  | $ | 25 |  |  | $ | 6 |  |

[0000833444-22-000017:notes:95]
[same as prior period, unchanged from 0000833444-22-000005:notes:84]

[0000833444-22-000017:notes:96]
[same as prior period, unchanged from 0000833444-22-000005:notes:85]

[0000833444-22-000017:notes:97]
[same as prior period, unchanged from 0000833444-22-000005:notes:86]

[0000833444-22-000017:notes:98]
[same as prior period, unchanged from 0000833444-22-000005:notes:87]

[0000833444-22-000017:notes:99]
|  |  | Fair Value of Assets |  |  |  | Fair Value of Liabilities |  |  |
|  |  | March 31, |  | September 30, |  |  |  | March 31, |  | September 30, |  |  |
|  |  | 2022 |  | 2021 |  |  |  | 2022 |  | 2021 |  |  |
| Gross amount recognized |  | $ | 79 |  |  | $ | 57 |  |  |  |  | $ | 2,829 |  |  | $ | 2,936 |  |  |  |
| Gross amount eligible for offsetting |  | (18) |  |  | (16) |  |  |  |  | (18) |  |  | (16) |  |  |  |
| Net amount |  | $ | 61 |  |  | $ | 41 |  |  |  |  | $ | 2,811 |  |  | $ | 2,920 |  |  |  |

[0000833444-22-000017:notes:100]
[same as prior period, unchanged from 0000833444-22-000005:notes:89]

[0000833444-22-000017:notes:101]
The following table presents the pre-tax gains recorded in other comprehensive income (loss) related to cash flow hedges (in millions):

[0000833444-22-000017:notes:102]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Foreign currency exchange derivatives |  | $ | 10 |  |  | $ | 10 |  |  | $ | 23 |  |  | $ | 13 |  |
| Commodity derivatives |  | 6 |  |  | — |  |  | 4 |  |  | 1 |  |
| Total |  | $ | 16 |  |  | $ | 10 |  |  | $ | 27 |  |  | $ | 14 |  |

[0000833444-22-000017:notes:103]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income (in millions):

[0000833444-22-000017:notes:104]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 6 |  |  | $ | 1 |  |  | $ | 11 |  |  | $ | 3 |  |
| Commodity derivatives |  | Cost of sales |  | (1) |  |  | (2) |  |  | (5) |  |  | (3) |  |
| Interest rate swaps |  | Net financing charges |  | — |  |  | — |  |  | (1) |  |  | — |  |
| Total |  |  |  | $ | 5 |  |  | $ | (1) |  |  | $ | 5 |  |  | $ | — |  |

[0000833444-22-000017:notes:105]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income (in millions):

[0000833444-22-000017:notes:106]
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (3) |  |  | $ | 2 |  |  | $ | 7 |  |  | $ | (4) |  |
| Foreign currency exchange derivatives |  | Selling, general and administrative |  | — |  |  | 3 |  |  | — |  |  | 1 |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 1 |  |  | 100 |  |  | 88 |  |  | 145 |  |
| Equity swap |  | Selling, general and administrative |  | (6) |  |  | 18 |  |  | (1) |  |  | 24 |  |
| Total |  |  |  | $ | (8) |  |  | $ | 123 |  |  | $ | 94 |  |  | $ | 166 |  |

[0000833444-22-000017:notes:107]
Pre-tax gains on net investment hedges recorded as foreign currency translation adjustments ("CTA") within other comprehensive income (loss) were $50 million and $144 million for the three months ended March 31, 2022 and 2021, 
respectively, and $123 million and $9 million for the six months ended March 31, 2022 and 2021, respectively.  No gains or losses were reclassified from CTA into income during the three and six months ended March 31, 2022 and 2021.


## us-gaap:DerivativesPolicyTextBlock

[0000833444-22-000017:notes:108]
[same as prior period, unchanged from 0000833444-22-000005:notes:97]


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-22-000017:notes:109]
[same as prior period, unchanged from 0000833444-22-000005:notes:98]

[0000833444-22-000017:notes:110]
[same as prior period, unchanged from 0000833444-22-000005:notes:99]

[0000833444-22-000017:notes:111]
[same as prior period, unchanged from 0000833444-22-000005:notes:100]

[0000833444-22-000017:notes:112]
[same as prior period, unchanged from 0000833444-22-000005:notes:101]

[0000833444-22-000017:notes:113]
[same as prior period, unchanged from 0000833444-22-000005:notes:102]

[0000833444-22-000017:notes:114]
[same as prior period, unchanged from 0000833444-22-000005:notes:103]

[0000833444-22-000017:notes:115]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value (in millions):

[0000833444-22-000017:notes:116]
|  | Fair Value Measurements Using: |
|  | Total as of March 31, 2022 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 48 |  |  | $ | — |  |  | $ | 48 |  |  | $ | — |  |
| Exchange traded funds (fixed income)1 | 23 |  |  | 23 |  |  | — |  |  | — |  |
| Commodity derivatives | 9 |  |  | — |  |  | 9 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 55 |  |  | 55 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 103 |  |  | 103 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 173 |  |  | 173 |  |  | — |  |  | — |  |
| Equity swap | 22 |  |  | — |  |  | 22 |  |  | — |  |
| Total assets | $ | 433 |  |  | $ | 354 |  |  | $ | 79 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 34 |  |  | $ | — |  |  | $ | 34 |  |  | $ | — |  |
| Contingent earn-out liabilities | 36 |  |  | — |  |  | — |  |  | 36 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 25 |  |  | — |  |  | — |  |  | 25 |  |
| Total liabilities | $ | 95 |  |  | $ | — |  |  | $ | 34 |  |  | $ | 61 |  |

[0000833444-22-000017:notes:117]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2021 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 32 |  |  | $ | — |  |  | $ | 32 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 63 |  |  | 63 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 146 |  |  | 146 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 168 |  |  | 168 |  |  | — |  |  | — |  |
| Equity swap | 23 |  |  | — |  |  | 23 |  |  | — |  |
| Total assets | $ | 434 |  |  | $ | 377 |  |  | $ | 57 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 17 |  |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Contingent earn-out liabilities | 32 |  |  | — |  |  | — |  |  | 32 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 50 |  |  | — |  |  | — |  |  | 50 |  |
| Total liabilities | $ | 100 |  |  | $ | — |  |  | $ | 18 |  |  | $ | 82 |  |

[0000833444-22-000017:notes:118]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 22, "Commitments and Contingencies," of the notes to the consolidated financial statements for further details.

[0000833444-22-000017:notes:119]
The following table summarizes the changes in contingent earn-out liabilities, which are valued using significant unobservable inputs (Level 3) (in millions):

[0000833444-22-000017:notes:120]
| Balance at September 30, 2021 | $ | 82 |  |  |
| Acquisitions | 21 |  |  |
| Reduction for change in estimates | (43) |  |  |
| Currency translation | 1 |  |  |
| Balance at March 31, 2022 | $ | 61 |  |  |

[0000833444-22-000017:notes:121]
[same as prior period, unchanged from 0000833444-22-000005:notes:109]

[0000833444-22-000017:notes:122]
[same as prior period, unchanged from 0000833444-22-000005:notes:110]

[0000833444-22-000017:notes:123]
[same as prior period, unchanged from 0000833444-22-000005:notes:111]

[0000833444-22-000017:notes:124]
[same as prior period, unchanged from 0000833444-22-000005:notes:112]

[0000833444-22-000017:notes:125]
[same as prior period, unchanged from 0000833444-22-000005:notes:113]

[0000833444-22-000017:notes:126]
Investments in exchange traded funds:  Investments in exchange traded funds are valued using a market approach based on  quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.  Refer to Note 22, "Commitments and Contingencies," of the notes to the consolidated financial statements for further information.

[0000833444-22-000017:notes:127]
[same as prior period, unchanged from 0000833444-22-000005:notes:115]

[0000833444-22-000017:notes:128]
The following table presents the portion of unrealized gains (losses) recognized in the consolidated statements of income that relate to equity securities still held at March 31, 2022 and 2021 (in millions):

[0000833444-22-000017:notes:129]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Deferred compensation plan assets |  | $ | (3) |  |  | $ | 2 |  |  | $ | — |  |  | $ | 7 |  |
| Investments in exchange traded funds |  | (20) |  |  | 2 |  |  | (6) |  |  | 23 |  |

[0000833444-22-000017:notes:130]
All of the gains (losses) on investments in exchange traded funds related to restricted investments. 
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. At March 31, 2022, the fair value of long-term debt was $7.7 billion, including public debt of $7.5 billion and other long-term debt of $0.2 billion. At September 30, 2021, the fair value of long-term debt was $8.5 billion, including public debt of $8.3 billion and other long-term debt of $0.2 billion. The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy.  The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000833444-22-000017:notes:131]
[same as prior period, unchanged from 0000833444-22-000005:notes:119]

[0000833444-22-000017:notes:132]
Investments in exchange traded funds:  Investments in exchange traded funds are valued using a market approach based on  quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.  Refer to Note 22, "Commitments and Contingencies," of the notes to the consolidated financial statements for further information.
Contingent earn-out liabilities:  The contingent earn-out liabilities, which are primarily related to the Silent-Aire acquisition, were established using a Monte Carlo simulation based on the forecasted operating results and the earn-out formula specified in the purchase agreement.The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy.  The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-22-000017:notes:133]
[same as prior period, unchanged from 0000833444-22-000005:notes:121]

[0000833444-22-000017:notes:134]
A summary of the stock-based awards granted is presented below:

[0000833444-22-000017:notes:135]
|  | Six Months Ended March 31, |  |  |
|  | 2022 |  |  |  | 2021 |  |  |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |
| Stock options | 548,398 |  |  | $ | 18.59 |  |  |  |  | 932,678 |  |  | $ | 9.36 |  |  |  |
| Stock appreciation rights | 19,768 |  |  | 18.59 |  |  |  |  | 35,254 |  |  | 9.36 |  |  |  |
| Restricted stock/units | 1,267,490 |  |  | 78.50 |  |  |  |  | 1,697,257 |  |  | 46.20 |  |  |  |
| Performance shares | 482,030 |  |  | 82.88 |  |  |  |  | 410,934 |  |  | 50.53 |  |  |  |

[0000833444-22-000017:notes:136]
[same as prior period, unchanged from 0000833444-22-000005:notes:124]

[0000833444-22-000017:notes:137]
[same as prior period, unchanged from 0000833444-22-000005:notes:125]

[0000833444-22-000017:notes:138]
[same as prior period, unchanged from 0000833444-22-000005:notes:126]

[0000833444-22-000017:notes:139]
|  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |
| Expected life of option (years) | 6.0 |  | 6.5 |
| Risk-free interest rate | 1.35% |  | 0.6% |
| Expected volatility of the Company’s stock | 27.8% |  | 27.6% |
| Expected dividend yield on the Company’s stock | 1.71% |  | 2.28% |

[0000833444-22-000017:notes:140]
[same as prior period, unchanged from 0000833444-22-000005:notes:128]

[0000833444-22-000017:notes:141]
SARs vest under the same terms and conditions as stock option awards; however, they are settled in cash for the difference between the market price on the date of the exercise and the exercise price. As a result, SARs are recorded in the Company's consolidated statements of financial position as a liability until the date of exercise. The fair value of each SAR award is estimated using a similar method and assumptions as described for stock options. The fair value of each SAR

[0000833444-22-000017:notes:142]
award is recalculated at the end of each reporting period and the liability and expense are adjusted based on the new fair value.

[0000833444-22-000017:notes:143]
[same as prior period, unchanged from 0000833444-22-000005:notes:130]

[0000833444-22-000017:notes:144]
[same as prior period, unchanged from 0000833444-22-000005:notes:131]

[0000833444-22-000017:notes:145]
[same as prior period, unchanged from 0000833444-22-000005:notes:132]

[0000833444-22-000017:notes:146]
[same as prior period, unchanged from 0000833444-22-000005:notes:133]

[0000833444-22-000017:notes:147]
[same as prior period, unchanged from 0000833444-22-000005:notes:134]

[0000833444-22-000017:notes:148]
[same as prior period, unchanged from 0000833444-22-000005:notes:135]

[0000833444-22-000017:notes:149]
|  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |
| Risk-free interest rate | 0.99% |  | 0.20% |
| Expected volatility of the Company’s stock | 30.0% |  | 30.9% |


## us-gaap:EarningsPerShareTextBlock

[0000833444-22-000017:notes:150]
Earnings Per ShareThe Company presents both basic and diluted earnings per share ("EPS") amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future and compensation cost for future service that the Company has not yet recognized. For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method include unamortized compensation cost.
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-22-000017:notes:151]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Income Available to Ordinary Shareholders |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 11 |  |  | $ | 343 |  |  | $ | 392 |  |  | $ | 670 |  |
| Income from discontinued operations | — |  |  | — |  |  | — |  |  | 124 |  |
| Basic and diluted income available to shareholders | $ | 11 |  |  | $ | 343 |  |  | $ | 392 |  |  | $ | 794 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 699.1 |  |  | 717.1 |  |  | 701.8 |  |  | 720.1 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 3.6 |  |  | 4.2 |  |  | 4.4 |  |  | 3.8 |  |
| Diluted weighted average shares outstanding | 702.7 |  |  | 721.3 |  |  | 706.2 |  |  | 723.9 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Stock options and unvested restricted stock | 0.3 |  |  | — |  |  | 0.2 |  |  | 0.1 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-22-000017:notes:152]
[same as prior period, unchanged from 0000833444-22-000005:notes:140]

[0000833444-22-000017:notes:153]
For the three and six months ended March 31, 2022, the Company repurchased and immediately retired $509 million and $1,035 million of its ordinary shares, respectively. For the three and six months ended March 31, 2021, the Company repurchased and immediately retired $315 million and $661 million of its ordinary shares, respectively. In March 2021, the Company's Board of Directors approved a $4 billion increase to the Company's share repurchase authorization, adding to the $2 billion remaining as of December 31, 2020 under the prior share repurchase authorization approved in 2019. As of March 31, 2022, approximately $4 billion remains available under the Company's share repurchase authorization.

[0000833444-22-000017:notes:154]
[same as prior period, unchanged from 0000833444-22-000005:notes:142]

[0000833444-22-000017:notes:155]
[same as prior period, unchanged from 0000833444-22-000005:notes:143]

[0000833444-22-000017:notes:156]
|  | Three Months Ended March 31, |
|  | 2022 |  | 2021 |
| Foreign currency translation adjustments |  |  |  |
| Balance at beginning of period | $ | (337) |  |  | $ | (506) |  |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | (6) |  |  | 88 |  |
| Balance at end of period | (343) |  |  | (418) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (13) |  |  | 3 |  |
| Current period changes in fair value (net of tax effect of $3 and $2) | 12 |  |  | 5 |  |
| Reclassification to income (net of tax effect of $(2) and $0) * | (3) |  |  | 1 |  |
| Balance at end of period | (4) |  |  | 9 |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | 3 |  |  | (1) |  |
| Reclassification to income (net of tax effect of $(1) and $0) | (1) |  |  | — |  |
| Balance at end of period | 2 |  |  | (1) |  |
| Accumulated other comprehensive loss, end of period | $ | (345) |  |  | $ | (410) |  |

[0000833444-22-000017:notes:157]
|  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |
| Foreign currency translation adjustments |  |  |  |
| Balance at beginning of period | $ | (421) |  |  | $ | (778) |  |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | 78 |  |  | 360 |  |
| Balance at end of period | (343) |  |  | (418) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (17) |  |  | 2 |  |
| Current period changes in fair value (net of tax effect of $6 and $4) | 16 |  |  | 7 |  |
| Reclassification to income (net of tax effect of $(2) and $0) * | (3) |  |  | — |  |
| Balance at end of period | (4) |  |  | 9 |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | 4 |  |  | — |  |
| Reclassification to income (net of tax effect of $(1) and $0) | (2) |  |  | (1) |  |
| Balance at end of period | 2 |  |  | (1) |  |
| Accumulated other comprehensive loss, end of period | $ | (345) |  |  | $ | (410) |  |

[0000833444-22-000017:notes:158]
* Refer to Note 11, "Derivative Instruments and Hedging Activities," of the notes to the consolidated financial statements for disclosure of the line items in the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-22-000017:notes:159]
[same as prior period, unchanged from 0000833444-22-000005:notes:148]

[0000833444-22-000017:notes:160]
|  | U.S. Pension Plans |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Interest cost | $ | 11 |  |  | $ | 11 |  |  | $ | 21 |  |  | $ | 22 |  |
| Expected return on plan assets | (41) |  |  | (42) |  |  | (82) |  |  | (84) |  |
| Net actuarial (gain) loss | 60 |  |  | (203) |  |  | 18 |  |  | (203) |  |
| Settlement (gain) loss | 2 |  |  | (4) |  |  | 1 |  |  | (4) |  |
| Net periodic benefit cost (credit) | $ | 32 |  |  | $ | (238) |  |  | $ | (42) |  |  | $ | (269) |  |

[0000833444-22-000017:notes:161]
|  | Non-U.S. Pension Plans |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Service cost | $ | 5 |  |  | $ | 6 |  |  | $ | 11 |  |  | $ | 13 |  |
| Interest cost | 10 |  |  | 8 |  |  | 20 |  |  | 16 |  |
| Expected return on plan assets | (21) |  |  | (27) |  |  | (42) |  |  | (55) |  |
| Net actuarial gain | (1) |  |  | — |  |  | (1) |  |  | — |  |
| Settlement loss | 8 |  |  | — |  |  | 8 |  |  | — |  |
| Net periodic benefit cost (credit) | $ | 1 |  |  | $ | (13) |  |  | $ | (4) |  |  | $ | (26) |  |

[0000833444-22-000017:notes:162]
|  | Postretirement Benefits |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Interest cost | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |
| Expected return on plan assets | (2) |  |  | (2) |  |  | (4) |  |  | (4) |  |
| Amortization of prior service credit | (1) |  |  | (1) |  |  | (2) |  |  | (2) |  |
| Net periodic benefit credit | $ | (2) |  |  | $ | (2) |  |  | $ | (5) |  |  | $ | (4) |  |

[0000833444-22-000017:notes:163]
Cumulative fiscal 2022 lump sum payouts triggered remeasurement events for certain pension plans in both the first and second quarters of fiscal 2022. During the three and six months ended March 31, 2022, the Company recognized net actuarial losses of $59 million and $17 million, respectively, primarily due to unfavorable plan asset performance, partially offset by increases in discount rates. 
During the second quarter of fiscal 2021, the amount of cumulative fiscal 2021 lump sum payouts triggered a remeasurement event for certain U.S. pension plans resulting in the recognition of net actuarial gains of $203 million, primarily due to increases in discount rates and favorable plan asset performance.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-22-000017:notes:164]
[same as prior period, unchanged from 0000833444-22-000005:notes:153]

[0000833444-22-000017:notes:165]
In fiscal 2021, the Company committed to a significant multi-year restructuring plan ("2021 Plan") which is expected to be completed during fiscal 2023. During the three and six months ended March 31, 2022, the Company recorded $27 million and $76 million of restructuring and impairment costs related to the 2021 Plan in the consolidated statements of income. The total amount expected to be incurred for this restructuring plan is $385 million across all segments and at Corporate.

[0000833444-22-000017:notes:166]
The following table summarizes restructuring and impairment costs related to the 2021 Plan (in millions):

[0000833444-22-000017:notes:167]
|  | Six Months Ended March 31, 2022 |  | Inception to March 31, 2022 |
| Building Solutions North America | $ | 13 |  |  | $ | 83 |  |
| Building Solutions EMEA/LA | 10 |  |  | 39 |  |
| Building Solutions Asia Pacific | 11 |  |  | 39 |  |
| Global Products | 39 |  |  | 130 |  |
| Corporate | 3 |  |  | 27 |  |
| Total | $ | 76 |  |  | $ | 318 |  |

[0000833444-22-000017:notes:168]
[same as prior period, unchanged from 0000833444-22-000005:notes:155]

[0000833444-22-000017:notes:169]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  | Total |
| Original reserve | $ | 68 |  |  | $ | 98 |  |  | $ | 76 |  |  |  |  | $ | 242 |  |
| Utilized—cash | (28) |  |  | — |  |  | (51) |  |  |  |  | (79) |  |
| Utilized—noncash | — |  |  | (98) |  |  | — |  |  |  |  | (98) |  |
| Balance at September 30, 2021 | 40 |  |  | — |  |  | 25 |  |  |  |  | 65 |  |
| Additional restructuring costs | 37 |  |  | 4 |  |  | 35 |  |  |  |  | 76 |  |
| Utilized—cash | (40) |  |  | — |  |  | (25) |  |  |  |  | (65) |  |
| Utilized—noncash | — |  |  | (4) |  |  | — |  |  |  |  | (4) |  |
| Currency translation | (1) |  |  | — |  |  | — |  |  |  |  | (1) |  |
| Balance at March 31, 2022 | $ | 36 |  |  | $ | — |  |  | $ | 35 |  |  |  |  | $ | 71 |  |

[0000833444-22-000017:notes:170]
The 2021 Plan included workforce reductions of approximately 4,500 employees. Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of March 31, 2022, approximately 2,800 of the employees have been separated from the Company pursuant to the 2021 Plan.
Company management closely monitors its overall cost structure and continually analyzes each of its businesses for opportunities to consolidate current operations, improve operating efficiencies and locate facilities in close proximity to customers. This ongoing analysis includes a review of its manufacturing, engineering and purchasing operations, as well as the overall global footprint for all its businesses.


## us-gaap:AssetImpairmentChargesTextBlock

[0000833444-22-000017:notes:171]
Impairment of Long-Lived Assets
The Company reviews long-lived assets, including right-of-use assets under operating leases, other tangible assets and intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of Software to be Sold, Leased, or Marketed."

[0000833444-22-000017:notes:172]
[same as prior period, unchanged from 0000833444-22-000005:notes:159]

[0000833444-22-000017:notes:173]
In the second quarter of fiscal 2022, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with classifying its Global Retail business as held for sale. As a result, the Company fully impaired $36 million of internal-use software projects that were no longer probable of being completed. Assets and liabilities held for sale are required to be recorded at the lower of carrying value or fair value, less costs to sell. Accordingly, the Company recorded an additional impairment charge of $86 million within restructuring and impairment costs in the consolidated statements of income to write down the carrying value of the assets held for sale to the fair value, based on estimated sale proceeds for the planned disposal, less costs to sell. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-22-000017:notes:174]
In the second quarter of fiscal 2021, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2021. As a result, the Company reviewed the long-lived assets for impairment and recorded $54 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $29 million related to the Building Solutions North America segment, $16 million related to the Global Products segment, $5 million related to Corporate assets and $4 million related to the Building Solutions Asia Pacific segment. Refer to Note 17, "Significant Restructuring and Impairment Costs," of the notes to the consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-22-000017:notes:175]
At March 31, 2022 and 2021, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-22-000017:notes:176]
[same as prior period, unchanged from 0000833444-22-000005:notes:161]

[0000833444-22-000017:notes:177]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended March 31, 2022, the Company's effective tax rate for continuing operations was 52.7% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of an impairment charge, the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestiture of its Global Retail business, and tax rate differentials, partially offset by the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives. For the six months ended March 31, 2022, the Company's effective tax rate for continuing operations was 21.5% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of an impairment charge, the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestiture of its Global Retail business, and tax rate differentials, partially offset by the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives. For the three months ended March 31, 2021, the Company's effective tax rate for continuing operations was 34.5% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the six months ended March 31, 2021, the Company's effective tax rate for continuing operations was 26.0% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives.

[0000833444-22-000017:notes:178]
[same as prior period, unchanged from 0000833444-22-000005:notes:163]

[0000833444-22-000017:notes:179]
[same as prior period, unchanged from 0000833444-22-000005:notes:164]

[0000833444-22-000017:notes:180]
In the second quarter of fiscal 2021, due to changes in forecasted taxable income, the Company recorded a discrete tax charge of $105 million related to valuation allowances on certain Mexico deferred tax assets now considered unrealizable.

[0000833444-22-000017:notes:181]
[same as prior period, unchanged from 0000833444-22-000005:notes:165]

[0000833444-22-000017:notes:182]
At September 30, 2021, the Company had gross tax-effected unrecognized tax benefits of $2,726 million, of which $2,268 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2021 was approximately $252 million (net of tax benefit). Total net accrued interest during the six months ended March 31, 2022 and 2021 was approximately $30 million (net of tax benefit) and approximately $24 million (net of tax benefit), respectively. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-22-000017:notes:183]
[same as prior period, unchanged from 0000833444-22-000005:notes:167]

[0000833444-22-000017:notes:184]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2021 |
| Germany |  | 2007 - 2018 |
| Luxembourg |  | 2017 - 2018 |
| Mexico |  | 2015 - 2020 |
| United Kingdom |  | 2014 - 2015, 2017 - 2018 |

[0000833444-22-000017:notes:185]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-22-000017:notes:186]
[same as prior period, unchanged from 0000833444-22-000005:notes:170]

[0000833444-22-000017:notes:187]
During the three months ended March 31, 2022, the Company recorded net mark-to-market losses of $89 million which generated a $21 million tax benefit, restructuring and impairment costs of $384 million which generated a $7 million tax benefit and a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries as a result of the planned divestiture of its Global Retail business which resulted in a tax charge of $13 million.

[0000833444-22-000017:notes:188]
During the six months ended March 31, 2022, the Company recorded net mark-to-market losses of $32 million which generated a $7 million tax benefit, restructuring and impairment costs of $433 million which generated a $14 million tax benefit and a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries which resulted in a tax charge of $13 million.

[0000833444-22-000017:notes:189]
During the three and six months ended March 31, 2021, the Company recorded pension mark-to-market gains of $207 million which generated tax expense of $53 million and $96 million of restructuring and impairment costs which generated a $15 million tax benefit.

[0000833444-22-000017:notes:190]
Tax expenses and benefits for the above transactions reflect the Company’s current tax positions in the impacted jurisdictions. Refer to Note 17, “Significant Restructuring and Impairment Costs,” and Note 18, “Impairment of Long-Lived Assets,” of the notes to the consolidated financial statements for additional information.

[0000833444-22-000017:notes:191]
Impacts of Tax Legislation
During the six months ended March 31, 2022, tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-22-000017:notes:192]
[same as prior period, unchanged from 0000833444-22-000005:notes:174]

[0000833444-22-000017:notes:193]
•Building Solutions North America: Building Solutions North America designs, sells, installs, and services HVAC, controls, building management, refrigeration, integrated electronic security, and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in the United States and Canada. Building Solutions North America also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems,

[0000833444-22-000017:notes:194]
as well as data-driven "smart building" solutions, to non-residential building and industrial applications in the United States and Canadian marketplace.

[0000833444-22-000017:notes:195]
[same as prior period, unchanged from 0000833444-22-000005:notes:176]

[0000833444-22-000017:notes:196]
[same as prior period, unchanged from 0000833444-22-000005:notes:177]

[0000833444-22-000017:notes:197]
[same as prior period, unchanged from 0000833444-22-000005:notes:178]

[0000833444-22-000017:notes:198]
Effective October 1, 2021, the Company's marine businesses previously included in Building Solutions Asia Pacific and Global Products reportable segments became part of Building Solutions EMEA/LA reportable segment. Historical information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation.

[0000833444-22-000017:notes:199]
[same as prior period, unchanged from 0000833444-22-000005:notes:180]

[0000833444-22-000017:notes:200]
[same as prior period, unchanged from 0000833444-22-000005:notes:181]

[0000833444-22-000017:notes:201]
|  | Net Sales |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Building Solutions North America | $ | 2,227 |  |  | $ | 2,092 |  |  | $ | 4,379 |  |  | $ | 4,126 |  |
| Building Solutions EMEA/LA | 958 |  |  | 934 |  |  | 1,917 |  |  | 1,882 |  |
| Building Solutions Asia Pacific | 623 |  |  | 594 |  |  | 1,298 |  |  | 1,198 |  |
| Global Products | 2,290 |  |  | 1,974 |  |  | 4,366 |  |  | 3,729 |  |
| Total net sales | $ | 6,098 |  |  | $ | 5,594 |  |  | $ | 11,960 |  |  | $ | 10,935 |  |

[0000833444-22-000017:notes:202]
|  | Segment EBITA |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Building Solutions North America | $ | 235 |  |  | $ | 266 |  |  | $ | 485 |  |  | $ | 521 |  |
| Building Solutions EMEA/LA | 79 |  |  | 88 |  |  | 183 |  |  | 186 |  |
| Building Solutions Asia Pacific | 74 |  |  | 73 |  |  | 142 |  |  | 150 |  |
| Global Products | 412 |  |  | 284 |  |  | 713 |  |  | 496 |  |
| Total segment EBITA | 800 |  |  | 711 |  |  | 1,523 |  |  | 1,353 |  |
| Corporate expenses | (60) |  |  | (70) |  |  | (130) |  |  | (137) |  |
| Amortization of intangible assets | (106) |  |  | (104) |  |  | (224) |  |  | (208) |  |
| Restructuring and impairment costs | (384) |  |  | (96) |  |  | (433) |  |  | (96) |  |
| Net mark-to-market adjustments | (89) |  |  | 209 |  |  | (32) |  |  | 230 |  |
| Net financing charges | (51) |  |  | (44) |  |  | (104) |  |  | (103) |  |
| Income from continuing operations before income taxes | $ | 110 |  |  | $ | 606 |  |  | $ | 600 |  |  | $ | 1,039 |  |


## us-gaap:GuaranteesTextBlock

[0000833444-22-000017:notes:203]
[same as prior period, unchanged from 0000833444-22-000005:notes:184]

[0000833444-22-000017:notes:204]
[same as prior period, unchanged from 0000833444-22-000005:notes:185]

[0000833444-22-000017:notes:205]
The Company’s product warranty liability for continuing operations is recorded in the consolidated statements of financial position in other current liabilities if the warranty is less than one year and in other non-current liabilities if the warranty extends longer than one year.

[0000833444-22-000017:notes:206]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations were as follows (in millions):

[0000833444-22-000017:notes:207]
|  | Six Months Ended March 31, |
|  | 2022 |  | 2021 |
| Balance at beginning of period | $ | 192 |  |  | $ | 167 |  |
| Accruals for warranties issued during the period | 44 |  |  | 39 |  |
| Accruals from acquisition and divestitures | (1) |  |  | (1) |  |
| Changes in estimates to pre-existing warranties | (8) |  |  | 14 |  |
| Settlements made (in cash or in kind) during the period | (39) |  |  | (33) |  |
| Currency translation | (2) |  |  | — |  |
| Balance at end of period | $ | 186 |  |  | $ | 186 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-22-000017:notes:208]
Commitments and Contingencies
Environmental Matters

[0000833444-22-000017:notes:209]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-22-000017:notes:210]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 50 |  |  | $ | 48 |  |
| Other noncurrent liabilities | 34 |  |  | 54 |  |
| Total reserves for environmental liabilities | $ | 84 |  |  | $ | 102 |  |

[0000833444-22-000017:notes:211]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin. In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluoroalkyl substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.

[0000833444-22-000017:notes:212]
A substantial portion of the Company’s environmental reserves relates to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The Company’s reserves for remediation efforts at or near the FTC are based on a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals at this time.

[0000833444-22-000017:notes:213]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22,

[0000833444-22-000017:notes:214]
2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation. On November 6, 2020, WDNR received further recommendations from WDHS regarding individual standards for 12 additional PFAS and a combined standard for four additional PFAS, PFOA, and PFOS.

[0000833444-22-000017:notes:215]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).” The WDNR issued a further letter regarding the issue on November 4, 2019.  In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to date. Tyco Fire Products responded to the WDNR’s September 2021 notice by the December 27, 2021 deadline set by WDNR. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

[0000833444-22-000017:notes:216]
In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, WDNR approved Tyco Fire Products’ proposed Groundwater Extraction and Treatment System (“GETS”), a permanent groundwater remediation system that will extract groundwater that contains PFAS, treat it using advanced filtration systems, and return the treated water to the environment. Tyco Fire Products has commenced construction on the GETS. Tyco Fire Products also has started the process of removing PFAS-affected soil from the FTC.

[0000833444-22-000017:notes:217]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR’s requests. The lawsuit is presently at the beginning stages of litigation: Tyco Fire Products and Johnson Controls, Inc. each filed Answers to the Complaint on April 4, 2022. The Company is vigorously defending this civil enforcement action and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

[0000833444-22-000017:notes:218]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility in the third quarter of 2019 was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation of PFAS in the Marinette region.

[0000833444-22-000017:notes:219]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-22-000017:notes:220]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. The Company's conditional asset retirement obligations for continuing operations were $29 million at both March 31, 2022 and September 30, 2021.

[0000833444-22-000017:notes:221]
Asbestos Matters

[0000833444-22-000017:notes:222]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-22-000017:notes:223]
The Company estimates the asbestos-related liability for pending and future claims and related defense costs on a discounted basis. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable.

[0000833444-22-000017:notes:224]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-22-000017:notes:225]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 390 |  |  | 400 |  |
| Total asbestos-related liabilities | 448 |  |  | 458 |  |
| Other current assets | 36 |  |  | 13 |  |
| Other noncurrent assets | 326 |  |  | 365 |  |
| Total asbestos-related assets | 362 |  |  | 378 |  |
| Net asbestos-related liabilities | $ | 86 |  |  | $ | 80 |  |

[0000833444-22-000017:notes:226]
The following table presents the components of asbestos-related assets (in millions):

[0000833444-22-000017:notes:227]
|  | March 31, 2022 |  | September 30, 2021 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 299 |  |  | 314 |  |
| Total restricted assets | 305 |  |  | 320 |  |
| Insurance recoveries for asbestos-related liabilities | 57 |  |  | 58 |  |
| Total asbestos-related assets | $ | 362 |  |  | $ | 378 |  |

[0000833444-22-000017:notes:228]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be paid by Company affiliates). Asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be paid through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-22-000017:notes:229]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-22-000017:notes:230]
Insurable Liabilities

[0000833444-22-000017:notes:231]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-22-000017:notes:232]
The following table presents the location and amount of insurable liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-22-000017:notes:233]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 82 |  |  | $ | 77 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 216 |  |  | 226 |  |
| Total insurable liabilities | $ | 320 |  |  | $ | 325 |  |

[0000833444-22-000017:notes:234]
The following table presents the location and amount of insurable receivables in the Company's consolidated statements of financial position (in millions):

[0000833444-22-000017:notes:235]
|  | March 31, 2022 |  | September 30, 2021 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 15 |  |  | 15 |  |
| Total insurable receivables | $ | 20 |  |  | $ | 20 |  |

[0000833444-22-000017:notes:236]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-22-000017:notes:237]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-22-000017:notes:238]
PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. In March 2021, the EPA published its final determination to regulate PFOS and PFOA in drinking water. In October 2021, the EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which the EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

[0000833444-22-000017:notes:239]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation

[0000833444-22-000017:notes:240]
(“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-22-000017:notes:241]
AFFF Putative Class Actions

[0000833444-22-000017:notes:242]
Chemguard and Tyco Fire Products are named in 33 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington, New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan, Texas and South Dakota. All of these cases except one have been direct-filed in or transferred to the MDL.

[0000833444-22-000017:notes:243]
AFFF Individual or Mass Actions

[0000833444-22-000017:notes:244]
There are more than 2,200 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 2,100 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and transferred. There are four matters that are proceeding in state courts — three in Arizona and one in Texas.

[0000833444-22-000017:notes:245]
AFFF Municipal Cases

[0000833444-22-000017:notes:246]
Chemguard and Tyco Fire Products have been named as defendants in approximately 183 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Alabama, Arizona, California, Colorado, Connecticut, Florida, Idaho, Illinois, Kentucky, Louisiana, Maryland, Massachusetts, Michigan, New Jersey, New York, North Carolina, Ohio, Pennsylvania, Virginia, Washington, West Virginia, Wisconsin, the District of Columbia, and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but four of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.

[0000833444-22-000017:notes:247]
The Company has periodically been notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-22-000017:notes:248]
State or U.S. Territory Attorneys General Litigation related to AFFF

[0000833444-22-000017:notes:249]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-22-000017:notes:250]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from

[0000833444-22-000017:notes:251]
firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-22-000017:notes:252]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752-000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio. The lawsuit seeks to recover costs and natural resource damages associated with the contamination. This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-22-000017:notes:253]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

[0000833444-22-000017:notes:254]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-22-000017:notes:255]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

[0000833444-22-000017:notes:256]
In August 2020, Attorney General of the State of Michigan filed two substantially similar lawsuits—one in federal court and one in state court—against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within the State. The federal action has been transferred to the MDL, and the state court action has been removed to federal court and transferred to the MDL.

[0000833444-22-000017:notes:257]
In December 2020, the State of Mississippi filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

[0000833444-22-000017:notes:258]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

[0000833444-22-000017:notes:259]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL.

[0000833444-22-000017:notes:260]
In February 2022, the Attorney General of the State of Colorado filed a lawsuit in Colorado state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources, public health, and State property allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-22-000017:notes:261]
In April 2022, the Attorney General of the State of Florida filed a lawsuit in Florida state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage to the State’s natural resources and public health allegedly resulting from the use of firefighting foams at various locations throughout the State. It is anticipated that this complaint will be removed to federal court and transferred to the MDL.

[0000833444-22-000017:notes:262]
Other AFFF Related Matters

[0000833444-22-000017:notes:263]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-22-000017:notes:264]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-22-000017:notes:265]
Other Matters

[0000833444-22-000017:notes:266]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-22-000017:notes:267]
Related Party Transactions
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-22-000017:notes:268]
The following table presents net sales to and purchases from related parties (in millions):

[0000833444-22-000017:notes:269]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales to related parties |  | $ | 48 |  |  | $ | 53 |  |  | $ | 83 |  |  | $ | 97 |  |
| Purchases from related parties |  | 47 |  |  | 37 |  |  | 91 |  |  | 66 |  |

[0000833444-22-000017:notes:270]
The following table presents receivables from and payables to related parties in the consolidated statements of financial position (in millions):

[0000833444-22-000017:notes:271]
|  |  | March 31, 2022 |  | September 30, 2021 |
| Receivable from related parties |  | $ | 63 |  |  | $ | 73 |  |
| Payable to related parties |  | 27 |  |  | 45 |  |

[0000833444-22-000017:notes:272]
Additionally, the Company leases certain facilities used in its operations from a related party. As of March 31, 2022, the right-of-use asset and lease liability associated with these leases were $10 million. As of September 30, 2021, the right-of-use asset associated with these leases was $11 million and the lease liability was $10 million. Amounts paid for these leases were not material.
