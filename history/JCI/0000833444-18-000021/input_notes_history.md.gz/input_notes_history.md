# JCI note change history — 0000833444-18-000008 → 0000833444-18-000021


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-03):
[0000833444-18-000021:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of March 31, 2018, reserves for environmental liabilities totaled $47 million, of which $12 million was recorded within other current liabilities and $35 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at September 30, 2017. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At March 31, 2018 and September 30, 2017, the Company recorded conditional asset retirement obligations of $65 million and $61 million, respectively.
  (was, 2018-02-02, similarity 0.9726):
[0000833444-18-000008:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of December 31, 2017, reserves for environmental liabilities totaled $48 million, of which $10 million was recorded within other current liabilities and $38 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at September 30, 2017. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities, primarily in the Power Solutions and Building Technologies & Solutions businesses. At December 31, 2017 and September 30, 2017, the Company recorded conditional asset retirement obligations of $62 million and $61 million, respectively.

- changed (2018-05-03):
[0000833444-18-000021:note_history:2]
As of March 31, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $174 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $555 million, of which $54 million was recorded in other current liabilities and $501 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $381 million, of which $57 million was recorded in other current assets, and $324 million was recorded in other noncurrent assets. Assets included $12 million of cash and $274 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at March 31, 2018 was $95 million. As of September 30, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $181 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $573 million, of which $48 million was recorded in other current liabilities and $525 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $392 million, of which $53 million was recorded in other current assets, and $339 million was recorded in other noncurrent assets. Assets included $22 million of cash and $269 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2017 was $101 million.
  (was, 2018-02-02, similarity 0.9942):
[0000833444-18-000008:note_history:2]
As of December 31, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $166 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $559 million, of which $54 million was recorded in other current liabilities and $505 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $393 million, of which $55 million was recorded in other current assets, and $338 million was recorded in other noncurrent assets. Assets included $10 million of cash and $283 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at December 31, 2017 was $100 million. As of September 30, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $181 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $573 million, of which $48 million was recorded in other current liabilities and $525 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $392 million, of which $53 million was recorded in other current assets, and $339 million was recorded in other noncurrent assets. Assets included $22 million of cash and $269 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2017 was $101 million.

- changed (2018-05-03):
[0000833444-18-000021:note_history:3]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At March 31, 2018 and September 30, 2017, the insurable liabilities totaled $439 million and $445 million, respectively, of which $81 million and $122 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $336 million and $301 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at March 31, 2018 was $21 million, of which $6 million was recorded within other current assets and $15 million was recorded within other noncurrent assets.  The amount of such receivables recorded at September 30, 2017 was $46 million, of which $31 million was recorded within other current assets and $15 million was recorded within other noncurrent assets. The Company maintains captive insurance companies to manage certain of its insurable liabilities.
  (was, 2018-02-02, similarity 0.9905):
[0000833444-18-000008:note_history:3]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At December 31, 2017 and September 30, 2017, the insurable liabilities totaled $434 million and $445 million, respectively, of which $92 million and $122 million was recorded within other current liabilities, $23 million and $22 million was recorded within accrued compensation and benefits, and $319 million and $301 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at December 31, 2017 was $21 million, of which $6 million was recorded within other current assets and $15 million was recorded within other noncurrent assets.  The amount of such receivables recorded at September 30, 2017 was $46 million, of which $31 million was recorded within other current assets and $15 million was recorded within other noncurrent assets. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

- changed (2018-05-03):
[0000833444-18-000021:note_history:4]
Two of our subsidiaries, Chemguard, Inc. ("Chemguard") and Tyco Fire Products L.P. ("Tyco Fire Products"), have been named, along with other defendant manufacturers, in a number of class action lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and that the use of these products by others at various airbases and airports resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports and airbases. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination. As of May 3, 2018, the Company is named in 15 putative class actions in federal courts in five states as set forth below:
  (was, 2018-02-02, similarity 0.9933):
[0000833444-18-000008:note_history:4]
Two of our subsidiaries, Chemguard, Inc. ("Chemguard") and Tyco Fire Products L.P. ("Tyco Fire Products"), have been named, along with other defendant manufacturers, in a number of class action lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and that the use of these products by others at various airbases and airports resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports and airbases. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination. As of February 2, 2018, the Company is named in 12 putative class actions in federal courts in three states as set forth below:

- changed (2018-05-03):
[0000833444-18-000021:note_history:5]
| • | District of Colorado - Bell et al. v. The 3M Company et al., filed on September 18, 2016. |
  (was, 2018-02-02, similarity 0.96):
[0000833444-18-000008:note_history:5]
•District of Colorado - Bell et al. v. The 3M Company et al., filed on September 18, 2016.

- changed (2018-05-03):
[0000833444-18-000021:note_history:6]
| • | District of Colorado - Bell et al. v. The 3M Company et al., filed on September 18, 2016. |
  (was, 2018-02-02, similarity 0.96):
[0000833444-18-000008:note_history:6]
•District of Colorado - Bell et al. v. The 3M Company et al., filed on September 18, 2016.

- changed (2018-05-03):
[0000833444-18-000021:note_history:7]
| • | District of Colorado - Davis et al. v. The 3M Company et al., filed on September 22, 2016. |
  (was, 2018-02-02, similarity 0.9605):
[0000833444-18-000008:note_history:7]
•District of Colorado - Davis et al. v. The 3M Company et al., filed on September 22, 2016.

- added (2018-05-03):
[0000833444-18-000021:note_history:8]
The above cases have been consolidated in the U.S. District Court for the District of Colorado, and a hearing on the plaintiffs’ motion for class certification is likely to be scheduled for July 2018 with a trial date schedule for April 2019. In addition to the putative class actions above, Chemguard and Tyco Fire Products are defendants in Adams, et al. v. The 3M Company et.al., filed on March 26, 2018, in the United States District Court for the District of Colorado. A group of approximately 90 plaintiffs allege that releases of PFOS and PFOA have contaminated the surrounding communities’ water supplies near the Peterson Air Force Base and the Colorado Municipal Springs Airport. The plaintiffs assert defective design, failure to warn, negligence, private nuisance and trespass and seek recovery for alleged diminished property values, personal injury, medical monitoring and punitive damages.

- added (2018-05-03):
[0000833444-18-000021:note_history:9]
Massachusetts

- added (2018-05-03):
[0000833444-18-000021:note_history:10]
| • | District of Massachusetts - Civitarese et al. v. The 3m Company et al., filed on April 18, 2018 in the United States District Court of Massachusetts. |

- added (2018-05-03):
[0000833444-18-000021:note_history:11]
Washington

- added (2018-05-03):
[0000833444-18-000021:note_history:12]
| • | Eastern District of Washington - Ackerman et al. v. The 3M Company et al. filed on April 5, 2018 in the United States District Court, Eastern District of Washington. |

- added (2018-05-03):
[0000833444-18-000021:note_history:13]
| • | Supreme Court of the State of New York, Suffolk County - Shipman et al. v. The 3M Company et al., filed March 21, 2018. |

- added (2018-05-03):
[0000833444-18-000021:note_history:14]
In addition to the putative class actions, Chemguard and Tyco Fire Products are also defendants in an action filed by two plaintiffs in the U.S. District Court for the Eastern District of Pennsylvania:  Menkes et al. v. The 3M Company et al., (filed February 7, 2017). The Menkes plaintiffs assert substantive claims and allegations similar to the putative class allegations, but also include personal injury claim. Further, the Company was recently served with an individual action in Pennsylvania state court, Court of Common Pleas Philadelphia: Gentles v. 3M Company et. al. (filed April 26, 2018). The Company is also on notice of approximately 540 other possible individual product liability claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, and, under Pennsylvania’s procedural rules, they may or may not result in lawsuits.

- added (2018-05-03):
[0000833444-18-000021:note_history:15]
Chemguard and Tyco Fire Products are also defendants in three cases pending in the U.S. District Court for the District of Massachusetts: Town of Barnstable v. the 3M. Co., et al, (filed Nov. 21, 2016), County of Barnstable v. the 3M. Co., et al, (filed January 9, 2017) and City of Westfield v. the 3M Co., et al., (filed on February 24, 2018). These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at a fire training academy and municipal airport released PFOS and PFOA into the town’s water supply wells, allegedly requiring remediation of the town and county property. The defendants have filed a motion to dismiss in County of Barnstable, which was granted without prejudice and the plaintiffs have subsequently filed an amended complaint.

- removed (2018-05-03):
[0000833444-18-000008:note_history:16]
The above cases have been consolidated in the U.S. District Court for the District of Colorado, and a hearing on the plaintiffs’ motion for class certification is scheduled for April 2018 with a trial date schedule for April 2019.

- removed (2018-05-03):
[0000833444-18-000008:note_history:17]
In addition to the putative class actions, Chemguard and Tyco Fire Products are also defendants in an action filed by two plaintiffs in the U.S. District Court for the Eastern District of Pennsylvania:  Menkes et al. v. The 3M Company et al., (filed February 7, 2017). The Menkes plaintiffs assert substantive claims and allegations similar to the putative class allegations, but also include personal injury claim. The Company is also on notice of approximately 540 other possible individual product liability claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, and, under Pennsylvania’s procedural rules, they may or may not result in lawsuits.

- removed (2018-05-03):
[0000833444-18-000008:note_history:18]
Chemguard and Tyco Fire Products are also defendants in two cases pending in the U.S. District Court for the District of Massachusetts: Town of Barnstable v. the 3M. Co., et al, (filed Nov. 21, 2016), and County of Barnstable v. the 3M. Co., et al, (filed January 9, 2017).  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at a fire training academy and municipal airport released PFOS and PFOA into the town’s water supply wells, allegedly requiring remediation of the town and county property. The defendants have filed a motion to dismiss in County of Barnstable, which was granted without prejudice and the plaintiffs have subsequently filed an amended complaint.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-05-03):
[0000833444-18-000021:note_history:19]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2017 filed with the SEC on November 21, 2017. The results of operations for the three and six month periods ended March 31, 2018 are not necessarily indicative of results for the Company’s 2018 fiscal year because of seasonal and other factors.
  (was, 2018-02-02, similarity 0.9778):
[0000833444-18-000008:note_history:19]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2017 filed with the SEC on November 21, 2017. The results of operations for the three month period ended December 31, 2017 are not necessarily indicative of results for the Company’s 2018 fiscal year because of seasonal and other factors.

- changed (2018-05-03):
[0000833444-18-000021:note_history:20]
Based upon the criteria set forth in ASC 810, the Company has determined that it was not the primary beneficiary in any VIEs for the reporting period ended March 31, 2018 and that it was the primary beneficiary in one VIE for the reporting period ended September 30, 2017, as the Company absorbed significant economics of the entity and had the power to direct the activities that are considered most significant to the entity.
  (was, 2018-02-02, similarity 0.9843):
[0000833444-18-000008:note_history:20]
Based upon the criteria set forth in ASC 810, the Company has determined that it was not the primary beneficiary in any VIEs for the reporting period ended December 31, 2017 and that it was the primary beneficiary in one VIE for the reporting period ended September 30, 2017, as the Company absorbed significant economics of the entity and had the power to direct the activities that are considered most significant to the entity.

- changed (2018-05-03):
[0000833444-18-000021:note_history:21]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company was considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE was consolidated within the Company’s consolidated statements of financial position as of September 30, 2017. During the quarter ended December 31, 2017, certain joint venture agreements were amended, and as a result, the Company can no longer make key operating decisions considered to be most significant to the VIE. As such, the Company is no longer considered the primary beneficiary of this entity, and the Company deconsolidated the entity during the quarter ended December 31, 2017. The impact of the entity on the Company’s consolidated statements of income for the six month periods ended March 31, 2018 and 2017 was not material.
  (was, 2018-02-02, similarity 0.6216):
[0000833444-18-000008:note_history:21]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company was considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE was consolidated within the Company’s consolidated statements of financial position as of September 30, 2017. The impact of the entity on the Company’s consolidated statements of income for the three month periods ended December 31, 2017 and 2016 were not material. During the quarter ended December 31, 2017, certain joint venture agreements were amended, and as a result, the Company can no longer make key operating decisions considered to be most significant to the VIE. As such, the Company is no longer considered the primary beneficiary of this entity, and the Company deconsolidated the entity during the quarter ended December 31, 2017.

- changed (2018-05-03):
[0000833444-18-000021:note_history:22]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The VIEs are named as co-obligors under a third party debt agreement in the amount of $159 million, maturing in fiscal 2020, under which a VIE could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business. The Company is not considered to be the primary beneficiary of three of the entities as of March 31, 2018 and two of the entities as of September 30, 2017, as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balances of $41 million and $65 million at March 31, 2018 and September 30, 2017, respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.
  (was, 2018-02-02, similarity 0.9947):
[0000833444-18-000008:note_history:22]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The VIEs are named as co-obligors under a third party debt agreement in the amount of $162 million, maturing in fiscal 2020, under which a VIE could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business. The Company is not considered to be the primary beneficiary of three of the entities as of December 31, 2017 and two of the entities as of September 30, 2017, as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balances of $38 million and $65 million at December 31, 2017 and September 30, 2017, respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.

- changed (2018-05-03):
[0000833444-18-000021:note_history:23]
At March 31, 2018, the Company held restricted cash of approximately $21 million, of which $12 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. At September 30, 2017, the Company held restricted cash of approximately $31 million, of which $22 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash restricted for payment of asbestos liabilities.
  (was, 2018-02-02, similarity 0.9907):
[0000833444-18-000008:note_history:23]
At December 31, 2017, the Company held restricted cash of approximately $19 million, of which $10 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. At September 30, 2017, the Company held restricted cash of approximately $31 million, of which $22 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash restricted for payment of asbestos liabilities.

- changed (2018-05-03):
[0000833444-18-000021:note_history:24]
In March 2016, the FASB issued Accounting Standards Update ("ASU") No. 2016-09, "Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." During the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09. As a result, employee withholding taxes paid to taxing authorities for equity-based compensation transactions, previously classified as cash flows from operating activities, were reclassified to financing activities in the consolidated statements of cash flows for the six months ended March 31, 2017. Refer to Note 2, "New Accounting Standards," of the notes to consolidated financial statements for further information.
  (was, 2018-02-02, similarity 0.963):
[0000833444-18-000008:note_history:24]
In March 2016, the FASB issued Accounting Standards Update ("ASU") No. 2016-09, "Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." During the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09. As a result, employee withholding taxes paid to taxing authorities for equity-based compensation transactions, previously classified as cash flows from operating activities, were reclassified to financing activities in the consolidated statements of cash flows for the three months ended December 31, 2016. Refer to Note 2, "New Accounting Standards," of the notes to consolidated financial statements for further information.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-03):
[0000833444-18-000021:note_history:25]
In October 2017, the Company completed the previously announced sale of its Scott Safety business to 3M. Net cash proceeds from the transaction of approximately $1.9 billion were used to repay a significant portion of the TSarl $4.0 billion of merger-related debt. In addition, in March 2018, the Company repaid $26 million in principal amount, plus accrued interest, of the TSarl merger-related debt. As of March 31, 2018, the outstanding balance of the TSarl term loan was approximately $1.7 billion.
  (was, 2018-02-02, similarity 0.6291):
[0000833444-18-000008:note_history:25]
In October 2017, the Company completed the previously announced sale of its Scott Safety business to 3M. Net cash proceeds from the transaction of approximately $1.9 billion were used to repay a significant portion of the TSarl $4.0 billion of merger-related debt. As of December 31, 2017, the outstanding balance of the TSarl term loan was approximately $1.8 billion.

- added (2018-05-03):
[0000833444-18-000021:note_history:26]
In March 2018, the Company increased the committed credit limit from $1.0 billion to $1.25 billion on TSarl's committed revolving credit facility scheduled to expire in August 2020. As of March 31, 2018, there were no draws on the facility.

- added (2018-05-03):
[0000833444-18-000021:note_history:27]
In March 2018, the Company entered into a 364-day $250 million committed revolving credit facility scheduled to expire in March 2019. As of March 31, 2018, there were no draws on the facility.

- added (2018-05-03):
[0000833444-18-000021:note_history:28]
In March 2018, a 364-day $150 million committed revolving credit facility expired. The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2019. As of March 31, 2018, there were no draws on the facility.

- added (2018-05-03):
[0000833444-18-000021:note_history:29]
In February 2018, a 364-day $150 million committed revolving credit facility expired. The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2019. As of March 31, 2018, there were no draws on the facility.

- added (2018-05-03):
[0000833444-18-000021:note_history:30]
In January 2018, a 364-day $250 million committed revolving credit facility expired. The Company entered into a new $200 million committed revolving credit facility scheduled to expire in January 2019. As of March 31, 2018, there were no draws on the facility.

- added (2018-05-03):
[0000833444-18-000021:note_history:31]
In January 2018, the Company retired $67 million in principal amount, plus accrued interest, of its 3.75% fixed rate notes  that expired in January 2018.

- changed (2018-05-03):
[0000833444-18-000021:note_history:32]
The Company's net financing charges line item in the consolidated statements of income for the three and six months ended March 31, 2018 and 2017 contained the following components (in millions):
  (was, 2018-02-02, similarity 0.9539):
[0000833444-18-000008:note_history:32]
The Company's net financing charges line item in the consolidated statements of income for the three months ended December 31, 2017 and 2016 contained the following components (in millions):

- changed (2018-05-03):
[0000833444-18-000021:note_history:33]
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Interest expense, net of capitalized interest costs | $ | 104 |  |  | $ | 118 |  |  | $ | 218 |  |  | $ | 228 |  |
| Banking fees and bond cost amortization | 14 |  |  | 11 |  |  | 27 |  |  | 41 |  |
| Interest income | (5 | ) |  | (5 | ) |  | (14 | ) |  | (12 | ) |
| Net foreign exchange results for financing activities | 2 |  |  | (8 | ) |  | — |  |  | (5 | ) |
| Net financing charges | $ | 115 |  |  | $ | 116 |  |  | $ | 231 |  |  | $ | 252 |  |
  (was, 2018-02-02, similarity 0.7967):
[0000833444-18-000008:note_history:33]
|  | Three Months EndedDecember 31, |
|  | 2017 |  | 2016 |
| Interest expense, net of capitalized interest costs | $ | 114 |  |  | $ | 110 |  |
| Banking fees and bond cost amortization | 13 |  |  | 30 |  |
| Interest income | (9 | ) |  | (7 | ) |
| Net foreign exchange results for financing activities | (2 | ) |  | 3 |  |
| Net financing charges | $ | 116 |  |  | $ | 136 |  |

- changed (2018-05-03):
[0000833444-18-000021:note_history:34]
Net financing charges for the six month period ended March 31, 2017, included $17 million of transaction costs related primarily to the prior year debt exchange offer fees.
  (was, 2018-02-02, similarity 0.924):
[0000833444-18-000008:note_history:34]
Net financing charges for the three months ended December 31, 2016, included $17 million of transaction costs related primarily to the prior year debt exchange offer fees.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2018-05-03):
[0000833444-18-000021:note_history:35]
The net sales to and purchases from related parties included in the consolidated statements of income were $222 million and $70 million, respectively, for the three months ended March 31, 2018; and $229 million and $52 million, respectively, for the three months ended March 31, 2017. The net sales to and purchases from related parties included in the consolidated statements of income were $464 million and $111 million, respectively, for the six months ended March 31, 2018; and $454 million and $101 million, respectively, for the six months ended March 31, 2017.
  (was, 2018-02-02, similarity 0.6294):
[0000833444-18-000008:note_history:35]
The net sales to and purchases from related parties included in the consolidated statements of income were $242 million and $41 million, respectively, for the three months ended December 31, 2017; and $225 million and $49 million, respectively, for the three months ended December 31, 2016.

- changed (2018-05-03):
[0000833444-18-000021:note_history:36]
|  |  | March 31, 2018 |  | September 30, 2017 |  |
| Receivable from related parties |  | $ | 107 |  |  | $ | 108 |  |
| Payable to related parties |  | 60 |  |  | 50 |  |
  (was, 2018-02-02, similarity 0.9691):
[0000833444-18-000008:note_history:36]
|  |  | December 31, 2017 |  | September 30, 2017 |  |
| Receivable from related parties |  | $ | 122 |  |  | $ | 108 |  |
| Payable to related parties |  | 34 |  |  | 50 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2018-05-03):
[0000833444-18-000021:note_history:37]
|  |  | March 31, 2018 |  | September 30, 2017 |  |
| Receivable from related parties |  | $ | 107 |  |  | $ | 108 |  |
| Payable to related parties |  | 60 |  |  | 50 |  |
  (was, 2018-02-02, similarity 0.9691):
[0000833444-18-000008:note_history:37]
|  |  | December 31, 2017 |  | September 30, 2017 |  |
| Receivable from related parties |  | $ | 122 |  |  | $ | 108 |  |
| Payable to related parties |  | 34 |  |  | 50 |  |
