# JCI 8-K — 0000833444-18-000018 filed 2018-05-01

## item codes, every 8-K on or before 2018-05-03

- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2018-05-03

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-18-000018:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq2fy18.htm
EXHIBIT 99.1

[0000833444-18-000018:8k_2_02:2]
Exhibit

[0000833444-18-000018:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000833444-18-000018:8k_2_02:4]
| CONTACT: | Investors:Antonella Franzen(609) 720-4665Ryan Edelman(609) 720-4545Media:Fraser Engerman(414) 524-2733 | Exhibit 99.1 |

[0000833444-18-000018:8k_2_02:5]
Johnson Controls reports solid fiscal Q2 earnings with stronger orders and free cash flow

[0000833444-18-000018:8k_2_02:6]
________________________________________________________________________________

[0000833444-18-000018:8k_2_02:7]
| ▪ | GAAP earnings of $0.47 per share including special items |

[0000833444-18-000018:8k_2_02:8]
| ▪ | Adjusted EPS from continuing operations of $0.53, up 6% versus prior year |

[0000833444-18-000018:8k_2_02:9]
| ▪ | Sales of $7.5 billion, up 3%, reflecting organic growth of 1% versus prior year |

[0000833444-18-000018:8k_2_02:10]
| ▪ | Buildings organic sales growth in service and products up 3% and 6%, respectively |

[0000833444-18-000018:8k_2_02:11]
| ▪ | Buildings field orders up 7% organically with continued strong quoting activity |

[0000833444-18-000018:8k_2_02:12]
| ▪ | Adjusted free cash flow of $0.6 billion in Q2; $0.3 billion year-to-date |

[0000833444-18-000018:8k_2_02:13]
| ▪ | Re-affirm full year fiscal 2018 guidance for adjusted EPS from continuing operations in the range of $2.75 to $2.85 |

[0000833444-18-000018:8k_2_02:14]
________________________________________________________________________________

[0000833444-18-000018:8k_2_02:15]
CORK, Ireland, May 1, 2018 -- Johnson Controls International plc (NYSE: JCI) today reported fiscal second quarter 2018 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.47.  Excluding these items, adjusted EPS from continuing operations was $0.53, up 6% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-18-000018:8k_2_02:16]
Sales of $7.5 billion increased 3% compared to the prior year.  Excluding the impacts of M&A, foreign currency and lead prices, total sales grew 1% organically.

[0000833444-18-000018:8k_2_02:17]
GAAP earnings before interest and taxes (“EBIT”) was $676 million and EBIT margin was 9.0%. Adjusted EBIT was $740 million and adjusted EBIT margin was 9.9%, up 10 basis points over the prior year.   Excluding the impact of the Scott Safety divestiture, foreign currency, and lead prices, the underlying adjusted EBIT margin increased 30 basis points.

[0000833444-18-000018:8k_2_02:18]
Page 1 of 17

[0000833444-18-000018:8k_2_02:19]
“Second quarter results represent an important step in the continued transformation of Johnson Controls,” said George Oliver, Johnson Controls chairman & chief executive officer. “We reported another quarter of solid operational performance and momentum continues to build. I am encouraged by the continued strength in orders across the Buildings platform driven by the significant efforts we have made to increase capacity and drive improved sales execution.  In addition, we are monetizing investments in sales and product and channel investments with 3% organic service growth and 6% organic product growth,” Oliver continued.

[0000833444-18-000018:8k_2_02:20]
“In Power Solutions, we are encouraged by our new business wins in both Original Equipment and Aftermarket, driven by improved service levels and shifts to new technologies.  We expect to see this momentum positively impact our top line growth as we move into the second half of the fiscal year.  In addition, we are making good progress on our Power Solutions strategic review.”

[0000833444-18-000018:8k_2_02:21]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-18-000018:8k_2_02:22]
($ millions, except per-share amounts)

[0000833444-18-000018:8k_2_02:23]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the second quarter of 2017.

[0000833444-18-000018:8k_2_02:24]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2017 |  | Q2 2018 |  | Q2 2017 |  | Q2 2018 |  | Change |
| Sales |  | $7,267 |  | $7,475 |  | $7,237 |  | $7,475 |  | +3% |
| Segment EBITA |  | 956 |  | 929 |  | 931 |  | 944 |  | +1% |
| EBIT |  | 509 |  | 676 |  | 711 |  | 740 |  | +4% |
| Net income (loss) from continuing operations |  | (148) |  | 438 |  | 473 |  | 493 |  | +4% |
| Diluted EPS from continuing operations |  | $(0.16) |  | $0.47 |  | $0.50 |  | $0.53 |  | +6% |

[0000833444-18-000018:8k_2_02:25]
Organic sales growth, adjusted segment EBITA, adjusted EBIT, adjusted EPS from continuing operations and adjusted free cash flow are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes.  A slide presentation reviewing second quarter results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-18-000018:8k_2_02:26]
Page 2 of 17

[0000833444-18-000018:8k_2_02:27]
BUSINESS RESULTS

[0000833444-18-000018:8k_2_02:28]
Building Solutions North America

[0000833444-18-000018:8k_2_02:29]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2017 |  | Q2 2018 |  | Q2 2017 |  | Q2 2018 |  | Change |
| Sales |  | $2,097 |  | $2,097 |  | $2,074 |  | $2,097 |  | +1% |
| Segment EBITA |  | $255 |  | $239 |  | $229 |  | $244 |  | +7% |
| Segment EBITA margin % |  | 12.2% |  | 11.4% |  | 11.0% |  | 11.6% |  | +60bps |

[0000833444-18-000018:8k_2_02:30]
Sales in the second quarter of 2018 were $2.1 billion, an increase of 1% versus the prior year quarter.  Excluding M&A and foreign currency, organic sales also increased 1% versus the prior year, driven primarily by solid growth in HVAC & Controls.

[0000833444-18-000018:8k_2_02:31]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 4% year-over-year.  Backlog at the end of the quarter of $5.3 billion increased 5% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-18-000018:8k_2_02:32]
Adjusted segment EBITA was $244 million, up 7% versus the prior year. Adjusted segment EBITA margin of 11.6% increased 60 basis points driven by cost synergies and productivity savings as well as favorable volume/mix, partially offset by expected low margin backlog conversion and salesforce additions.

[0000833444-18-000018:8k_2_02:33]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-18-000018:8k_2_02:34]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2017 |  | Q2 2018 |  | Q2 2017 |  | Q2 2018 |  | Change |
| Sales |  | $898 |  | $907 |  | $891 |  | $907 |  | +2% |
| Segment EBITA |  | $89 |  | $77 |  | $79 |  | $78 |  | (1%) |
| Segment EBITA margin % |  | 9.9% |  | 8.5% |  | 8.9% |  | 8.6% |  | (30bps) |

[0000833444-18-000018:8k_2_02:35]
Sales in the second quarter of 2018 were $907 million, an increase of 2% versus the prior year quarter.  Excluding M&A and foreign currency, organic sales declined 3% versus the prior year driven by lower volumes across Europe and the Middle East, partially offset by continued strength in Latin America.

[0000833444-18-000018:8k_2_02:36]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 10% year-over-year.  Backlog at the end of the quarter of $1.7 billion increased modestly year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-18-000018:8k_2_02:37]
Page 3 of 17

[0000833444-18-000018:8k_2_02:38]
Adjusted segment EBITA was $78 million, down 1% versus the prior year quarter. Adjusted segment EBITA margin of 8.6% declined 30 basis points over the prior year, as the benefit from cost synergies and productivity savings was more than offset by lower volume de-leverage.

[0000833444-18-000018:8k_2_02:39]
Building Solutions Asia Pacific

[0000833444-18-000018:8k_2_02:40]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2017 |  | Q2 2018 |  | Q2 2017 |  | Q2 2018 |  | Change |
| Sales |  | $562 |  | $586 |  | $562 |  | $586 |  | +4% |
| Segment EBITA |  | $67 |  | $71 |  | $67 |  | $71 |  | +6% |
| Segment EBITA margin % |  | 11.9% |  | 12.1% |  | 11.9% |  | 12.1% |  | +20bps |

[0000833444-18-000018:8k_2_02:41]
Sales in the second quarter of 2018 were $586 million, an increase of 4% versus the prior year quarter.  Excluding M&A and foreign currency, organic sales declined 2% versus the prior year, as strong growth in service was more than offset by declines in project installations related to the timing of large project flow-through.

[0000833444-18-000018:8k_2_02:42]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 10% year-over-year.  Backlog at the end of the quarter of $1.5 billion was 15% higher year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-18-000018:8k_2_02:43]
Adjusted segment EBITA was $71 million, up 6% versus the prior year. Adjusted segment EBITA margin of 12.1% expanded 20 basis points over the prior year, including a 40 basis point headwind related to foreign currency.  Adjusting for foreign currency, the underlying margin improved 60 basis points driven by favorable mix as well as the benefit of cost synergies and productivity savings, partially offset by salesforce additions.

[0000833444-18-000018:8k_2_02:44]
Global Products

[0000833444-18-000018:8k_2_02:45]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2017 |  | Q2 2018 |  | Q2 2017 |  | Q2 2018 |  | Change |
| Sales |  | $2,014 |  | $2,040 |  | $2,014 |  | $2,040 |  | +1% |
| Segment EBITA |  | $242 |  | $228 |  | $253 |  | $237 |  | (6%) |
| Segment EBITA margin % |  | 12.0% |  | 11.2% |  | 12.6% |  | 11.6% |  | (100bps) |

[0000833444-18-000018:8k_2_02:46]
Page 4 of 17

[0000833444-18-000018:8k_2_02:47]
Sales in the second quarter of 2018 were $2.0 billion, an increase of 1% versus the prior year quarter.  Excluding M&A and foreign currency, organic sales increased 6% versus the prior year driven by mid-single digit growth in Building Management and HVAC & Refrigeration Equipment, and low-teens growth in Specialty Products.

[0000833444-18-000018:8k_2_02:48]
Adjusted segment EBITA was $237 million, down 6% versus the prior year, primarily attributable to the impact of the Scott Safety divestiture.  Adjusted segment EBITA margin of 11.6% declined 100 basis points over the prior year including a 120 basis point headwind related to the divestiture of the Scott Safety business. The underlying margin expanded 20 basis points as the benefit of cost synergies and productivity savings as well as favorable volume leverage was partially offset by planned product and channel investments and expected price/cost pressure.

[0000833444-18-000018:8k_2_02:49]
Power Solutions

[0000833444-18-000018:8k_2_02:50]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2017 |  | Q2 2018 |  | Q2 2017 |  | Q2 2018 |  | Change |
| Sales |  | $1,696 |  | $1,845 |  | $1,696 |  | $1,845 |  | +9% |
| Segment EBITA |  | $303 |  | $314 |  | $303 |  | $314 |  | +4% |
| Segment EBITA margin % |  | 17.9% |  | 17.0% |  | 17.9% |  | 17.0% |  | (90bps) |

[0000833444-18-000018:8k_2_02:51]
Sales in the second quarter of 2018 were $1.8 billion, an increase of 9% versus the prior year quarter.  Excluding the impact of higher lead pass-through and foreign currency, organic sales declined 2% as favorable price and technology mix was more than offset by lower unit volumes. Global original equipment battery shipments declined 2% in-line with overall market demand and aftermarket shipments declined 6% driven primarily by weather impacts in the U.S. and Europe.  Start-stop battery shipments increased 14% year-over-year, led by growth in China and the Americas.

[0000833444-18-000018:8k_2_02:52]
Power Solutions adjusted segment EBITA was $314 million, a 4% increase compared to the prior year.  Adjusted segment EBITA margin of 17.0% decreased 90 basis points compared with the prior year, including a 60 basis point headwind related to the impact of foreign currency and lead prices. Power Solution’s underlying margin declined 30 basis points as favorable mix and productivity savings were more than offset by higher transportation costs and planned incremental investments.

[0000833444-18-000018:8k_2_02:53]
Page 5 of 17

[0000833444-18-000018:8k_2_02:54]
Corporate

[0000833444-18-000018:8k_2_02:55]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q2 2017 |  | Q2 2018 |  | Q2 2017 |  | Q2 2018 |  | Change |
| Corporate expense |  | $(240) |  | $(159) |  | $(128) |  | $(110) |  | (14%) |

[0000833444-18-000018:8k_2_02:56]
Adjusted Corporate expense was $110 million in the second quarter, a decrease of 14% compared to the prior year quarter driven primarily by cost synergies and productivity initiatives.

[0000833444-18-000018:8k_2_02:57]
OTHER ITEMS

[0000833444-18-000018:8k_2_02:58]
| • | Cash from operating activities less capex was $0.4 billion for the quarter and nil year-to-date. Adjusted free cash flow was $0.6 billion for the quarter and $0.3 billion year-to-date. Adjusted free cash flow excludes net cash outflows of $0.2 billion in the quarter and $0.3 billion year-to-date primarily related to restructuring and integration costs. |

[0000833444-18-000018:8k_2_02:59]
| • | During the quarter, the Company repurchased 1.3 million shares for approximately $50 million; year-to-date share repurchases totaled 4.9 million shares for approximately $200 million. |

[0000833444-18-000018:8k_2_02:60]
| • | In March, the Company announced the decision to review strategic alternatives for its Power Solutions business and the review is ongoing. |

[0000833444-18-000018:8k_2_02:61]
###

[0000833444-18-000018:8k_2_02:62]
About Johnson Controls

[0000833444-18-000018:8k_2_02:63]
Johnson Controls is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. Our 120,000 employees create intelligent buildings, efficient energy solutions, integrated infrastructure and next generation transportation systems that work seamlessly together to deliver on the promise of smart cities and communities. Our commitment to sustainability dates back to our roots in 1885, with the invention of the first electric room thermostat. We are committed to helping our customers win and creating greater value for all of our stakeholders through strategic focus on our buildings and energy growth platforms. For additional information, please visit http://www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter.

[0000833444-18-000018:8k_2_02:64]
###

[0000833444-18-000018:8k_2_02:65]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-18-000018:8k_2_02:66]
Page 6 of 17

[0000833444-18-000018:8k_2_02:67]
opportunities, capital expenditures and debt levels are forward-looking statements. Words such as “may,” “will,” “expect,” “intend,” “estimate,” “anticipate,” “believe,” “should,” “forecast,” “project” or “plan” and terms of similar meaning are also generally intended to identify forward-looking statements. However, the absence of these words does not mean that a statement is not forward-looking. Johnson Controls cautions that these statements are subject to numerous important risks, uncertainties, assumptions and other factors, some of which are beyond Johnson Controls’ control, that could cause Johnson Controls’ actual results to differ materially from those expressed or implied by such forward-looking statements, including, among others, risks related to: any delay or inability of Johnson Controls to realize the expected benefits and synergies of recent portfolio transactions such as the merger with Tyco and the spin-off of Adient, changes in tax laws (including but not limited to the recently enacted Tax Cuts and Jobs Act), regulations, rates, policies or interpretations, the loss of key senior management, the tax treatment of recent portfolio transactions, significant transaction costs and/or unknown liabilities associated with such transactions, the outcome of actual or potential litigation relating to such transactions, the risk that disruptions from recent transactions will harm Johnson Controls’ business, the strength of the U.S. or other economies, automotive vehicle production levels, mix and schedules, energy and commodity prices, the availability of raw materials and component products, currency rates, cancellation of or changes to commercial arrangements, and with respect to the recently announced review of strategic alternatives for the Power Solutions business, uncertainties as to the structure and timing of any transaction and whether it will be completed, the possibility that closing conditions for a transaction may not be satisfied or waived, the impact of the strategic review and any transaction on Johnson Controls and the Power Solutions business on a standalone basis if a transaction is completed, and whether the strategic benefits of any transaction can be achieved. A detailed discussion of risks related to Johnson Controls’ business is included in the section entitled “Risk Factors” in Johnson Controls’ Annual Report on Form 10-K for the 2017 fiscal year filed with the SEC on November 21, 2017, and its Quarterly Report on Form 10-Q for the quarterly period ended December 31, 2017 filed with the SEC on February 2, 2018, both of which are and available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-18-000018:8k_2_02:68]
###

[0000833444-18-000018:8k_2_02:69]
Non GAAP Financial Information

[0000833444-18-000018:8k_2_02:70]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include mark-to-market for pension and postretirement plans, transaction/integration/separation costs, restructuring and impairment costs, nonrecurring purchase accounting impacts related to the Tyco merger, Scott Safety gain on sale and discrete tax items. Financial information regarding adjusted sales, organic sales, adjusted segment EBITA, adjusted segment EBITA margin and adjusted free cash flow are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as transaction/integration/separation costs and nonrecurring purchase accounting impacts because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.

[0000833444-18-000018:8k_2_02:71]
###

[0000833444-18-000018:8k_2_02:72]
Page 7 of 17

[0000833444-18-000018:8k_2_02:73]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Three Months Ended March 31, |
|  |  | 2018 |  |  | 2017 |
| Net sales | $ | 7,475 |  |  |  | $ | 7,267 |  |
| Cost of sales | 5,255 |  |  |  | 4,986 |  |
|  | Gross profit | 2,220 |  |  |  | 2,281 |  |
| Selling, general and administrative expenses | (1,588 | ) |  |  | (1,726 | ) |
| Restructuring and impairment costs | — |  |  |  | (99 | ) |
| Net financing charges | (115 | ) |  |  | (116 | ) |
| Equity income | 44 |  |  |  | 53 |  |
| Income from continuing operations before income taxes | 561 |  |  |  | 393 |  |
| Income tax provision | 78 |  |  |  | 508 |  |
| Income (loss) from continuing operations | 483 |  |  |  | (115 | ) |
| Loss from discontinued operations, net of tax | — |  |  |  | — |  |
| Net income (loss) | 483 |  |  |  | (115 | ) |
| Less: Income from continuing operations attributable to noncontrolling interests | 45 |  |  |  | 33 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |
| Net income (loss) attributable to JCI | $ | 438 |  |  |  | $ | (148 | ) |
| Income (loss) from continuing operations | $ | 438 |  |  |  | $ | (148 | ) |
| Loss from discontinued operations | — |  |  |  | — |  |
| Net income (loss) attributable to JCI | $ | 438 |  |  |  | $ | (148 | ) |
| Diluted earnings (loss) per share from continuing operations | $ | 0.47 |  |  |  | $ | (0.16 | ) |
| Diluted loss per share from discontinued operations | — |  |  |  | — |  |
| Diluted earnings (loss) per share | $ | 0.47 |  |  |  | $ | (0.16 | ) |
| Diluted weighted average shares | 932.5 |  |  |  | 939.2 |  |
| Shares outstanding at period end | 926.2 |  |  |  | 938.1 |  |

[0000833444-18-000018:8k_2_02:74]
Page 8 of 17

[0000833444-18-000018:8k_2_02:75]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Six Months Ended March 31, |
|  |  | 2018 |  |  | 2017 |
| Net sales | $ | 14,910 |  |  |  | $ | 14,353 |  |
| Cost of sales | 10,521 |  |  |  | 9,958 |  |
|  | Gross profit | 4,389 |  |  |  | 4,395 |  |
| Selling, general and administrative expenses | (3,005 | ) |  |  | (3,296 | ) |
| Restructuring and impairment costs | (158 | ) |  |  | (177 | ) |
| Net financing charges | (231 | ) |  |  | (252 | ) |
| Equity income | 104 |  |  |  | 108 |  |
| Income from continuing operations before income taxes | 1,099 |  |  |  | 778 |  |
| Income tax provision | 345 |  |  |  | 481 |  |
| Income from continuing operations | 754 |  |  |  | 297 |  |
| Loss from discontinued operations, net of tax | — |  |  |  | (34 | ) |
| Net income | 754 |  |  |  | 263 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 86 |  |  |  | 73 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 9 |  |
| Net income attributable to JCI | $ | 668 |  |  |  | $ | 181 |  |
| Income from continuing operations | $ | 668 |  |  |  | $ | 224 |  |
| Loss from discontinued operations | — |  |  |  | (43 | ) |
| Net income attributable to JCI | $ | 668 |  |  |  | $ | 181 |  |
| Diluted earnings per share from continuing operations | $ | 0.72 |  |  |  | $ | 0.24 |  |
| Diluted loss per share from discontinued operations | — |  |  |  | (0.05 | ) |
| Diluted earnings per share | $ | 0.72 |  |  |  | $ | 0.19 |  |
| Diluted weighted average shares | 932.9 |  |  |  | 948.0 |  |
| Shares outstanding at period end | 926.2 |  |  |  | 938.1 |  |

[0000833444-18-000018:8k_2_02:76]
Page 9 of 17

[0000833444-18-000018:8k_2_02:77]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | March 31,2018 |  | September 30,2017 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 268 |  |  | $ | 321 |  |
| Accounts receivable - net | 6,679 |  |  | 6,666 |  |
| Inventories | 3,565 |  |  | 3,209 |  |
| Assets held for sale | 22 |  |  | 189 |  |
| Other current assets | 1,737 |  |  | 1,907 |  |
|  | Current assets | 12,271 |  |  | 12,292 |  |
| Property, plant and equipment - net | 6,235 |  |  | 6,121 |  |
| Goodwill | 19,806 |  |  | 19,688 |  |
| Other intangible assets - net | 6,625 |  |  | 6,741 |  |
| Investments in partially-owned affiliates | 1,294 |  |  | 1,191 |  |
| Noncurrent assets held for sale | — |  |  | 1,920 |  |
| Other noncurrent assets | 3,721 |  |  | 3,931 |  |
|  | Total assets | $ | 49,952 |  |  | $ | 51,884 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 1,136 |  |  | $ | 1,608 |  |
| Accounts payable and accrued expenses | 5,116 |  |  | 5,342 |  |
| Liabilities held for sale | — |  |  | 72 |  |
| Other current liabilities | 4,740 |  |  | 4,832 |  |
|  | Current liabilities | 10,992 |  |  | 11,854 |  |
| Long-term debt | 10,962 |  |  | 11,964 |  |
| Other noncurrent liabilities | 5,883 |  |  | 6,315 |  |
| Noncurrent liabilities held for sale | — |  |  | 173 |  |
| Redeemable noncontrolling interests | 235 |  |  | 211 |  |
| Shareholders' equity attributable to JCI | 20,874 |  |  | 20,447 |  |
| Noncontrolling interests | 1,006 |  |  | 920 |  |
|  | Total liabilities and equity | $ | 49,952 |  |  | $ | 51,884 |  |

[0000833444-18-000018:8k_2_02:78]
Page 10 of 17

[0000833444-18-000018:8k_2_02:79]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended March 31, |
|  |  |  |  |  |  | 2018 |  |  | 2017 |
| Operating Activities |  |  |  |  |
| Net income (loss) attributable to JCI | $ | 438 |  |  |  | $ | (148 | ) |
| Income from continuing operations attributable to noncontrolling interests | 45 |  |  |  | 33 |  |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |
| Net income (loss) | 483 |  |  |  | (115 | ) |
| Adjustments to reconcile net income (loss) to cash provided by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 280 |  |  |  | 292 |  |
|  |  | Pension and postretirement benefit income | (36 | ) |  |  | (47 | ) |
|  |  | Pension and postretirement contributions | (13 | ) |  |  | (11 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (43 | ) |  |  | (52 | ) |
|  |  | Deferred income taxes | 2 |  |  |  | 479 |  |
|  |  | Non-cash restructuring and impairment costs | — |  |  |  | 23 |  |
|  |  | Other - net | 15 |  |  |  | 45 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | 138 |  |  |  | (58 | ) |
|  |  |  |  | Inventories | (67 | ) |  |  | (228 | ) |
|  |  |  |  | Other assets | (49 | ) |  |  | (63 | ) |
|  |  |  |  | Restructuring reserves | (105 | ) |  |  | 27 |  |
|  |  |  |  | Accounts payable and accrued liabilities | 102 |  |  |  | 197 |  |
|  |  |  |  | Accrued income taxes | (45 | ) |  |  | (123 | ) |
|  |  |  |  |  | Cash provided by operating activities | 662 |  |  |  | 366 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (267 | ) |  |  | (263 | ) |
| Sale of property, plant and equipment | 5 |  |  |  | 16 |  |
| Acquisition of businesses, net of cash acquired | (15 | ) |  |  | (3 | ) |
| Business divestitures, net of cash divested | 103 |  |  |  | 133 |  |
| Other - net | (2 | ) |  |  | (24 | ) |
|  |  |  |  |  | Cash used by investing activities | (176 | ) |  |  | (141 | ) |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | (497 | ) |  |  | 220 |  |
| Debt financing costs | — |  |  |  | (11 | ) |
| Stock repurchases | (49 | ) |  |  | (119 | ) |
| Payment of cash dividends | (241 | ) |  |  | (235 | ) |
| Proceeds from the exercise of stock options | 20 |  |  |  | 59 |  |
| Dividends paid to noncontrolling interests | (46 | ) |  |  | (47 | ) |
| Cash transferred to Adient related to spin-off | — |  |  |  | (101 | ) |
| Cash paid related to prior acquisitions | — |  |  |  | 8 |  |
| Other - net | (1 | ) |  |  | 6 |  |
|  |  |  |  |  | Cash used by financing activities | (814 | ) |  |  | (220 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 44 |  |  |  | 30 |  |
| Increase (decrease) in cash and cash equivalents | $ | (284 | ) |  |  | $ | 35 |  |

[0000833444-18-000018:8k_2_02:80]
Page 11 of 17

[0000833444-18-000018:8k_2_02:81]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Six Months Ended March 31, |
|  |  |  |  |  |  | 2018 |  |  | 2017 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI | $ | 668 |  |  |  | $ | 181 |  |
| Income from continuing operations attributable to noncontrolling interests | 86 |  |  |  | 73 |  |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 9 |  |
| Net income | 754 |  |  |  | 263 |  |
| Adjustments to reconcile net income to cash provided (used) by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 552 |  |  |  | 638 |  |
|  |  | Pension and postretirement benefit income | (72 | ) |  |  | (202 | ) |
|  |  | Pension and postretirement contributions | (37 | ) |  |  | (258 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (79 | ) |  |  | (116 | ) |
|  |  | Deferred income taxes | (77 | ) |  |  | 1,059 |  |
|  |  | Non-cash restructuring and impairment costs | 30 |  |  |  | 39 |  |
|  |  | Gain on Scott Safety business divestiture | (114 | ) |  |  | — |  |
|  |  | Other - net | 32 |  |  |  | 82 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | 108 |  |  |  | (21 | ) |
|  |  |  |  | Inventories | (300 | ) |  |  | (370 | ) |
|  |  |  |  | Other assets | 15 |  |  |  | (150 | ) |
|  |  |  |  | Restructuring reserves | (12 | ) |  |  | 47 |  |
|  |  |  |  | Accounts payable and accrued liabilities | (521 | ) |  |  | (599 | ) |
|  |  |  |  | Accrued income taxes | 254 |  |  |  | (1,931 | ) |
|  |  |  |  |  | Cash provided (used) by operating activities | 533 |  |  |  | (1,519 | ) |
| Investing Activities |  |  |  |  |
| Capital expenditures | (497 | ) |  |  | (634 | ) |
| Sale of property, plant and equipment | 10 |  |  |  | 18 |  |
| Acquisition of businesses, net of cash acquired | (15 | ) |  |  | (6 | ) |
| Business divestitures, net of cash divested | 2,114 |  |  |  | 180 |  |
| Other - net | (14 | ) |  |  | (30 | ) |
|  |  |  |  |  | Cash provided (used) by investing activities | 1,598 |  |  |  | (472 | ) |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | (1,542 | ) |  |  | 776 |  |
| Debt financing costs | (4 | ) |  |  | (17 | ) |
| Stock repurchases | (199 | ) |  |  | (119 | ) |
| Payment of cash dividends | (473 | ) |  |  | (235 | ) |
| Proceeds from the exercise of stock options | 36 |  |  |  | 88 |  |
| Dividends paid to noncontrolling interests | (46 | ) |  |  | (78 | ) |
| Dividend from Adient spin-off | — |  |  |  | 2,050 |  |
| Cash transferred to Adient related to spin-off | — |  |  |  | (665 | ) |
| Cash paid related to prior acquisitions | — |  |  |  | (37 | ) |
| Other - net | (26 | ) |  |  | (19 | ) |
|  |  |  |  |  | Cash provided (used) by financing activities | (2,254 | ) |  |  | 1,744 |  |
| Effect of exchange rate changes on cash and cash equivalents | 61 |  |  |  | (25 | ) |
| Change in cash held for sale | 9 |  |  |  | 105 |  |
| Decrease in cash and cash equivalents | $ | (53 | ) |  |  | $ | (167 | ) |

[0000833444-18-000018:8k_2_02:82]
Page 12 of 17

[0000833444-18-000018:8k_2_02:83]
FOOTNOTES

[0000833444-18-000018:8k_2_02:84]
1. Financial Summary

[0000833444-18-000018:8k_2_02:85]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans.

[0000833444-18-000018:8k_2_02:86]
|  | Three Months Ended March 31, |
| (in millions; unaudited) | 2018 |  | 2017 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,097 |  |  | $ | 2,097 |  |  | $ | 2,097 |  |  | $ | 2,074 |  |
| Building Solutions EMEA/LA | 907 |  |  | 907 |  |  | 898 |  |  | 891 |  |
| Building Solutions Asia Pacific | 586 |  |  | 586 |  |  | 562 |  |  | 562 |  |
| Global Products | 2,040 |  |  | 2,040 |  |  | 2,014 |  |  | 2,014 |  |
| Total Building Technologies & Solutions | 5,630 |  |  | 5,630 |  |  | 5,571 |  |  | 5,541 |  |
| Power Solutions | 1,845 |  |  | 1,845 |  |  | 1,696 |  |  | 1,696 |  |
| Net sales | $ | 7,475 |  |  | $ | 7,475 |  |  | $ | 7,267 |  |  | $ | 7,237 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 239 |  |  | $ | 244 |  |  | $ | 255 |  |  | $ | 229 |  |
| Building Solutions EMEA/LA | 77 |  |  | 78 |  |  | 89 |  |  | 79 |  |
| Building Solutions Asia Pacific | 71 |  |  | 71 |  |  | 67 |  |  | 67 |  |
| Global Products | 228 |  |  | 237 |  |  | 242 |  |  | 253 |  |
| Total Building Technologies & Solutions | 615 |  |  | 630 |  |  | 653 |  |  | 628 |  |
| Power Solutions | 314 |  |  | 314 |  |  | 303 |  |  | 303 |  |
| Segment EBITA | 929 |  |  | 944 |  |  | 956 |  |  | 931 |  |
| Corporate expenses (2) | (159 | ) |  | (110 | ) |  | (240 | ) |  | (128 | ) |
| Amortization of intangible assets (3) | (94 | ) |  | (94 | ) |  | (126 | ) |  | (92 | ) |
| Mark-to-market gain for pension plans (4) | — |  |  | — |  |  | 18 |  |  | — |  |
| Restructuring and impairment costs (5) | — |  |  | — |  |  | (99 | ) |  | — |  |
| EBIT (6) | 676 |  |  | 740 |  |  | 509 |  |  | 711 |  |
| EBIT margin | 9.0 | % |  | 9.9 | % |  | 7.0 | % |  | 9.8 | % |
| Net financing charges (7) | (115 | ) |  | (115 | ) |  | (116 | ) |  | (116 | ) |
| Income from continuing operations before income taxes | 561 |  |  | 625 |  |  | 393 |  |  | 595 |  |
| Income tax provision (8) | (78 | ) |  | (87 | ) |  | (508 | ) |  | (89 | ) |
| Income (loss) from continuing operations | 483 |  |  | 538 |  |  | (115 | ) |  | 506 |  |
| Income from continuing operations attributable to noncontrolling interests | (45 | ) |  | (45 | ) |  | (33 | ) |  | (33 | ) |
| Net income (loss) from continuing operations attributable to JCI | $ | 438 |  |  | $ | 493 |  |  | $ | (148 | ) |  | $ | 473 |  |

[0000833444-18-000018:8k_2_02:87]
|  | Six Months Ended March 31, |
| (in millions; unaudited) | 2018 |  | 2017 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 4,109 |  |  | $ | 4,109 |  |  | $ | 4,039 |  |  | $ | 4,016 |  |
| Building Solutions EMEA/LA | 1,822 |  |  | 1,822 |  |  | 1,773 |  |  | 1,769 |  |
| Building Solutions Asia Pacific | 1,183 |  |  | 1,183 |  |  | 1,137 |  |  | 1,138 |  |
| Global Products | 3,821 |  |  | 3,821 |  |  | 3,808 |  |  | 3,814 |  |
| Total Building Technologies & Solutions | 10,935 |  |  | 10,935 |  |  | 10,757 |  |  | 10,737 |  |
| Power Solutions | 3,975 |  |  | 3,975 |  |  | 3,596 |  |  | 3,596 |  |
| Net sales | $ | 14,910 |  |  | $ | 14,910 |  |  | $ | 14,353 |  |  | $ | 14,333 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 466 |  |  | $ | 480 |  |  | $ | 451 |  |  | $ | 465 |  |
| Building Solutions EMEA/LA | 146 |  |  | 149 |  |  | 138 |  |  | 144 |  |
| Building Solutions Asia Pacific | 145 |  |  | 145 |  |  | 130 |  |  | 139 |  |
| Global Products | 514 |  |  | 415 |  |  | 369 |  |  | 458 |  |
| Total Building Technologies & Solutions | 1,271 |  |  | 1,189 |  |  | 1,088 |  |  | 1,206 |  |
| Power Solutions | 698 |  |  | 698 |  |  | 692 |  |  | 693 |  |
| Segment EBITA | 1,969 |  |  | 1,887 |  |  | 1,780 |  |  | 1,899 |  |
| Corporate expenses (2) | (293 | ) |  | (211 | ) |  | (433 | ) |  | (236 | ) |
| Amortization of intangible assets (3) | (188 | ) |  | (188 | ) |  | (275 | ) |  | (195 | ) |
| Mark-to-market gain for pension plans (4) | — |  |  | — |  |  | 135 |  |  | — |  |
| Restructuring and impairment costs (5) | (158 | ) |  | — |  |  | (177 | ) |  | — |  |
| EBIT (6) | 1,330 |  |  | 1,488 |  |  | 1,030 |  |  | 1,468 |  |
| EBIT margin | 8.9 | % |  | 10.0 | % |  | 7.2 | % |  | 10.2 | % |
| Net financing charges (7) | (231 | ) |  | (231 | ) |  | (252 | ) |  | (235 | ) |
| Income from continuing operations before income taxes | 1,099 |  |  | 1,257 |  |  | 778 |  |  | 1,233 |  |
| Income tax provision (8) | (345 | ) |  | (176 | ) |  | (481 | ) |  | (185 | ) |
| Income from continuing operations | 754 |  |  | 1,081 |  |  | 297 |  |  | 1,048 |  |
| Income from continuing operations attributable to noncontrolling interests | (86 | ) |  | (86 | ) |  | (73 | ) |  | (73 | ) |
| Net income from continuing operations attributable to JCI | $ | 668 |  |  | $ | 995 |  |  | $ | 224 |  |  | $ | 975 |  |

[0000833444-18-000018:8k_2_02:88]
Building Technologies & Solutions - Provides facility systems and services including comfort, energy and security management for the non-residential buildings market, and provides heating, ventilating, and air conditioning products and services, security products and services, and fire detection and suppression products and services.

[0000833444-18-000018:8k_2_02:89]
Power Solutions - Services both automotive original equipment manufacturers and the battery aftermarket by providing advanced battery technology, coupled with systems engineering, marketing and service expertise.

[0000833444-18-000018:8k_2_02:90]
Page 13 of 17

[0000833444-18-000018:8k_2_02:91]
(1) The Company's press release contains financial information regarding adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures.  The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-18-000018:8k_2_02:92]
The following is the three months ended March 31, 2018 and 2017 reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-18-000018:8k_2_02:93]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total Building Technologies & Solutions |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales as reported | $ | 2,097 |  |  | $ | 2,097 |  |  | $ | 907 |  |  | $ | 898 |  |  | $ | 586 |  |  | $ | 562 |  |  | $ | 2,040 |  |  | $ | 2,014 |  |  | $ | 5,630 |  |  | $ | 5,571 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | — |  |  | (23 | ) |  | — |  |  | (7 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (30 | ) |
| Adjusted net sales | $ | 2,097 |  |  | $ | 2,074 |  |  | $ | 907 |  |  | $ | 891 |  |  | $ | 586 |  |  | $ | 562 |  |  | $ | 2,040 |  |  | $ | 2,014 |  |  | $ | 5,630 |  |  | $ | 5,541 |  |
| Segment EBITA as reported | $ | 239 |  |  | $ | 255 |  |  | $ | 77 |  |  | $ | 89 |  |  | $ | 71 |  |  | $ | 67 |  |  | $ | 228 |  |  | $ | 242 |  |  | $ | 615 |  |  | $ | 653 |  |
| Segment EBITA margin as reported | 11.4 | % |  | 12.2 | % |  | 8.5 | % |  | 9.9 | % |  | 12.1 | % |  | 11.9 | % |  | 11.2 | % |  | 12.0 | % |  | 10.9 | % |  | 11.7 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 1 |  |  | — |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | 6 |  |  | — |  |  | 10 |  |
| Integration costs | 5 |  |  | 7 |  |  | 1 |  |  | 2 |  |  | — |  |  | 2 |  |  | 9 |  |  | 5 |  |  | 15 |  |  | 16 |  |
| Nonrecurring purchase accounting impacts | — |  |  | (34 | ) |  | — |  |  | (15 | ) |  | — |  |  | (2 | ) |  | — |  |  | — |  |  | — |  |  | (51 | ) |
| Adjusted segment EBITA | $ | 244 |  |  | $ | 229 |  |  | $ | 78 |  |  | $ | 79 |  |  | $ | 71 |  |  | $ | 67 |  |  | $ | 237 |  |  | $ | 253 |  |  | $ | 630 |  |  | $ | 628 |  |
| Adjusted segment EBITA margin | 11.6 | % |  | 11.0 | % |  | 8.6 | % |  | 8.9 | % |  | 12.1 | % |  | 11.9 | % |  | 11.6 | % |  | 12.6 | % |  | 11.2 | % |  | 11.3 | % |

[0000833444-18-000018:8k_2_02:94]
| (in millions) | Total Building Technologies & Solutions |  | Power Solutions |  | Consolidated JCI plc |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales as reported | $ | 5,630 |  |  | $ | 5,571 |  |  | $ | 1,845 |  |  | $ | 1,696 |  |  | $ | 7,475 |  |  | $ | 7,267 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | — |  |  | (30 | ) |  | — |  |  | — |  |  | — |  |  | (30 | ) |
| Adjusted net sales | $ | 5,630 |  |  | $ | 5,541 |  |  | $ | 1,845 |  |  | $ | 1,696 |  |  | $ | 7,475 |  |  | $ | 7,237 |  |
| Segment EBITA as reported | $ | 615 |  |  | $ | 653 |  |  | $ | 314 |  |  | $ | 303 |  |  | $ | 929 |  |  | $ | 956 |  |
| Segment EBITA margin as reported | 10.9 | % |  | 11.7 | % |  | 17.0 | % |  | 17.9 | % |  | 12.4 | % |  | 13.2 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |
| Integration costs | 15 |  |  | 16 |  |  | — |  |  | — |  |  | 15 |  |  | 16 |  |
| Nonrecurring purchase accounting impacts | — |  |  | (51 | ) |  | — |  |  | — |  |  | — |  |  | (51 | ) |
| Adjusted segment EBITA | $ | 630 |  |  | $ | 628 |  |  | $ | 314 |  |  | $ | 303 |  |  | $ | 944 |  |  | $ | 931 |  |
| Adjusted segment EBITA margin | 11.2 | % |  | 11.3 | % |  | 17.0 | % |  | 17.9 | % |  | 12.6 | % |  | 12.9 | % |

[0000833444-18-000018:8k_2_02:95]
The following is the six months ended March 31, 2018 and 2017 reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-18-000018:8k_2_02:96]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total Building Technologies & Solutions |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales as reported | $ | 4,109 |  |  | $ | 4,039 |  |  | $ | 1,822 |  |  | $ | 1,773 |  |  | $ | 1,183 |  |  | $ | 1,137 |  |  | $ | 3,821 |  |  | $ | 3,808 |  |  | $ | 10,935 |  |  | $ | 10,757 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | — |  |  | (23 | ) |  | — |  |  | (4 | ) |  | — |  |  | 1 |  |  | — |  |  | 6 |  |  | — |  |  | (20 | ) |
| Adjusted net sales | $ | 4,109 |  |  | $ | 4,016 |  |  | $ | 1,822 |  |  | $ | 1,769 |  |  | $ | 1,183 |  |  | $ | 1,138 |  |  | $ | 3,821 |  |  | $ | 3,814 |  |  | $ | 10,935 |  |  | $ | 10,737 |  |
| Segment EBITA as reported | $ | 466 |  |  | $ | 451 |  |  | $ | 146 |  |  | $ | 138 |  |  | $ | 145 |  |  | $ | 130 |  |  | $ | 514 |  |  | $ | 369 |  |  | $ | 1,271 |  |  | $ | 1,088 |  |
| Segment EBITA margin as reported | 11.3 | % |  | 11.2 | % |  | 8.0 | % |  | 7.8 | % |  | 12.3 | % |  | 11.4 | % |  | 13.5 | % |  | 9.7 | % |  | 11.6 | % |  | 10.1 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 11 |  |  | — |  |  | 5 |  |  | — |  |  | 2 |  |  | — |  |  | 9 |  |  | — |  |  | 27 |  |
| Integration costs | 14 |  |  | 14 |  |  | 3 |  |  | 4 |  |  | — |  |  | 3 |  |  | 15 |  |  | 9 |  |  | 32 |  |  | 30 |  |
| Scott Safety gain on sale | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (114 | ) |  | — |  |  | (114 | ) |  | — |  |
| Nonrecurring purchase accounting impacts | — |  |  | (11 | ) |  | — |  |  | (3 | ) |  | — |  |  | 4 |  |  | — |  |  | 71 |  |  | — |  |  | 61 |  |
| Adjusted segment EBITA | $ | 480 |  |  | $ | 465 |  |  | $ | 149 |  |  | $ | 144 |  |  | $ | 145 |  |  | $ | 139 |  |  | $ | 415 |  |  | $ | 458 |  |  | $ | 1,189 |  |  | $ | 1,206 |  |
| Adjusted segment EBITA margin | 11.7 | % |  | 11.6 | % |  | 8.2 | % |  | 8.1 | % |  | 12.3 | % |  | 12.2 | % |  | 10.9 | % |  | 12.0 | % |  | 10.9 | % |  | 11.2 | % |

[0000833444-18-000018:8k_2_02:97]
| (in millions) | Total Building Technologies & Solutions |  | Power Solutions |  | Consolidated JCI plc |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales as reported | $ | 10,935 |  |  | $ | 10,757 |  |  | $ | 3,975 |  |  | $ | 3,596 |  |  | $ | 14,910 |  |  | $ | 14,353 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | — |  |  | (20 | ) |  | — |  |  | — |  |  | — |  |  | (20 | ) |
| Adjusted net sales | $ | 10,935 |  |  | $ | 10,737 |  |  | $ | 3,975 |  |  | $ | 3,596 |  |  | $ | 14,910 |  |  | $ | 14,333 |  |
| Segment EBITA as reported | $ | 1,271 |  |  | $ | 1,088 |  |  | $ | 698 |  |  | $ | 692 |  |  | $ | 1,969 |  |  | $ | 1,780 |  |
| Segment EBITA margin as reported | 11.6 | % |  | 10.1 | % |  | 17.6 | % |  | 19.2 | % |  | 13.2 | % |  | 12.4 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 27 |  |  | — |  |  | 1 |  |  | — |  |  | 28 |  |
| Integration costs | 32 |  |  | 30 |  |  | — |  |  | — |  |  | 32 |  |  | 30 |  |
| Scott Safety gain on sale | (114 | ) |  | — |  |  | — |  |  | — |  |  | (114 | ) |  | — |  |
| Nonrecurring purchase accounting impacts | — |  |  | 61 |  |  | — |  |  | — |  |  | — |  |  | 61 |  |
| Adjusted segment EBITA | $ | 1,189 |  |  | $ | 1,206 |  |  | $ | 698 |  |  | $ | 693 |  |  | $ | 1,887 |  |  | $ | 1,899 |  |
| Adjusted segment EBITA margin | 10.9 | % |  | 11.2 | % |  | 17.6 | % |  | 19.3 | % |  | 12.7 | % |  | 13.2 | % |

[0000833444-18-000018:8k_2_02:98]
(2) Adjusted Corporate expenses for the three months ended March 31, 2018 excludes $46 million of integration costs and $3 million of transaction costs.  Adjusted Corporate expenses for the six months ended March 31, 2018 excludes $74 million of integration costs and $8 million of transaction costs.  Adjusted Corporate expenses for the three months ended March 31, 2017 excludes $95 million of integration costs and $17 million of transaction costs.  Adjusted Corporate expenses for the six months ended March 31, 2017 excludes $145 million of integration costs, $48 million of transaction costs and $4 million of separation costs.

[0000833444-18-000018:8k_2_02:99]
(3) Adjusted amortization of intangible assets for the three and six months ended March 31, 2017 excludes $34 million and $80 million, respectively, of nonrecurring asset amortization related to Tyco purchase accounting.

[0000833444-18-000018:8k_2_02:100]
(4) The three and six months ended March 31, 2017 pension mark-to-market gains of $18 million and $135 million, respectively, due to lump sum payouts for certain U.S. pension plans in the quarter are excluded from the adjusted non-GAAP results.

[0000833444-18-000018:8k_2_02:101]
(5) Restructuring and impairment costs for the six months ended March 31, 2018 of $158 million are excluded from the adjusted non-GAAP results.  Restructuring and impairment costs for the three and six months ended March 31, 2017 of $99 million and $177 million, respectively, are excluded from the adjusted non-GAAP results.

[0000833444-18-000018:8k_2_02:102]
(6) Management defines earnings before interest and taxes (EBIT) as income from continuing operations before net financing charges, income taxes and noncontrolling interests.

[0000833444-18-000018:8k_2_02:103]
(7) Adjusted net financing charges for the six months ended March 31, 2017 exclude $17 million of transaction costs related to the debt exchange offers.

[0000833444-18-000018:8k_2_02:104]
(8) Adjusted income tax provision for the three months ended March 31, 2018 excludes the tax benefit for integration costs of $9 million.  Adjusted income tax provision for the six months ended March 31, 2018 excludes the net tax provision related to the U.S. Tax Reform legislation of $204 million and the Scott Safety gain on sale of $30 million, partially offset by the tax benefits for tax audit settlements of $25 million, restructuring and impairment costs of $24 million, integration costs of $15 million and transaction costs of $1 million.  Adjusted income tax provision for the three months ended March 31, 2017 excludes the non-cash tax charge of $457 million related to establishment of a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries of the Scott Safety business and the tax provisions for the pension mark-to-market gain of $8 million and Tyco nonrecurring purchase accounting impacts of $5 million, partially offset by the tax benefits of integration costs of $25 million, restructuring and impairment costs of $20 million and transaction costs of $6 million.  Adjusted income tax provision for the six months ended March 31, 2017 excludes the non-cash tax charge of $457 million related to establishment of a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries of the Scott Safety business and the tax provision for the pension mark-to-market gains of $54 million, partially offset by the tax benefits of changes in entity tax status of $101 million, Tyco nonrecurring purchase accounting impacts of $38 million, restructuring and impairment costs of $34 million, integration costs of $32 million and transaction costs of $10 million.

[0000833444-18-000018:8k_2_02:105]
Page 14 of 17

[0000833444-18-000018:8k_2_02:106]
2. Diluted Earnings Per Share Reconciliation

[0000833444-18-000018:8k_2_02:107]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure.  The adjusting items include transaction/integration/separation costs, nonrecurring purchase accounting impacts related to the Tyco merger, mark-to-market gain or loss for pension and postretirement plans, Scott Safety gain on sale, restructuring and impairment costs and discrete tax items.  The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company.  Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-18-000018:8k_2_02:108]
A reconciliation of diluted earnings per share as reported to diluted adjusted earnings per share for the respective periods is shown below (unaudited):

[0000833444-18-000018:8k_2_02:109]
|  | Net Income Attributable to JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Three Months Ended |  | Three Months Ended |
|  | March 31, |  | March 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Earnings per share as reported for JCI plc | $ | 0.47 |  |  | $ | (0.16 | ) |  | $ | 0.47 |  |  | $ | (0.16 | ) |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 0.03 |  |  | — |  |  | 0.03 |  |
| Related tax impact | — |  |  | (0.01 | ) |  | — |  |  | (0.01 | ) |
| Integration costs | 0.07 |  |  | 0.12 |  |  | 0.07 |  |  | 0.12 |  |
| Related tax impact | (0.01 | ) |  | (0.03 | ) |  | (0.01 | ) |  | (0.03 | ) |
| Nonrecurring purchase accounting impacts | — |  |  | (0.02 | ) |  | — |  |  | (0.02 | ) |
| Related tax impact | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |
| Mark-to-market gain for pension plans | — |  |  | (0.02 | ) |  | — |  |  | (0.02 | ) |
| Related tax impact | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |
| Restructuring and impairment costs | — |  |  | 0.10 |  |  | — |  |  | 0.10 |  |
| Related tax impact | — |  |  | (0.02 | ) |  | — |  |  | (0.02 | ) |
| Discrete tax items | — |  |  | 0.48 |  |  | — |  |  | 0.48 |  |
| Adjusted earnings per share for JCI plc* | $ | 0.53 |  |  | $ | 0.50 |  |  | $ | 0.53 |  |  | $ | 0.50 |  |

[0000833444-18-000018:8k_2_02:110]
* May not sum due to rounding.

[0000833444-18-000018:8k_2_02:111]
|  | Net Income Attributable to JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Six Months Ended |  | Six Months Ended |
|  | March 31, |  | March 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Earnings per share as reported for JCI plc | $ | 0.72 |  |  | $ | 0.19 |  |  | $ | 0.72 |  |  | $ | 0.24 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | 0.01 |  |  | 0.10 |  |  | 0.01 |  |  | 0.10 |  |
| Related tax impact | — |  |  | (0.01 | ) |  | — |  |  | (0.01 | ) |
| Integration costs | 0.11 |  |  | 0.18 |  |  | 0.11 |  |  | 0.18 |  |
| Related tax impact | (0.02 | ) |  | (0.03 | ) |  | (0.02 | ) |  | (0.03 | ) |
| Separation costs | — |  |  | 0.09 |  |  | — |  |  | — |  |
| Nonrecurring purchase accounting impacts | — |  |  | 0.15 |  |  | — |  |  | 0.15 |  |
| Related tax impact | — |  |  | (0.04 | ) |  | — |  |  | (0.04 | ) |
| Mark-to-market gain for pension plans | — |  |  | (0.14 | ) |  | — |  |  | (0.14 | ) |
| Related tax impact | — |  |  | 0.06 |  |  | — |  |  | 0.06 |  |
| Scott Safety gain on sale | (0.12 | ) |  | — |  |  | (0.12 | ) |  | — |  |
| Related tax impact | 0.03 |  |  | — |  |  | 0.03 |  |  | — |  |
| Restructuring and impairment costs | 0.17 |  |  | 0.19 |  |  | 0.17 |  |  | 0.19 |  |
| Related tax impact | (0.03 | ) |  | (0.04 | ) |  | (0.03 | ) |  | (0.04 | ) |
| Discrete tax items | 0.19 |  |  | 0.40 |  |  | 0.19 |  |  | 0.38 |  |
| Adjusted earnings per share for JCI plc* | $ | 1.07 |  |  | $ | 1.09 |  |  | $ | 1.07 |  |  | $ | 1.03 |  |

[0000833444-18-000018:8k_2_02:112]
* May not sum due to rounding.

[0000833444-18-000018:8k_2_02:113]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-18-000018:8k_2_02:114]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, |  | March 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Weighted Average Shares Outstanding for JCI plc |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 926.2 |  |  | 939.2 |  |  | 926.2 |  |  | 938.2 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |
| and unvested performance share awards | 6.3 |  |  | — |  |  | 6.7 |  |  | 9.8 |  |
| Diluted weighted average shares outstanding | 932.5 |  |  | 939.2 |  |  | 932.9 |  |  | 948.0 |  |

[0000833444-18-000018:8k_2_02:115]
For the three months ended March 31, 2017, the total number of potential dilutive shares due to stock options, unvested restricted stock and unvested performance share awards was 9.4 million.  However, these items were not included in the computation of diluted loss per share for the three months ended March 31, 2017, since to do so would decrease the loss per share.  On an adjusted diluted outstanding share basis, inclusion of the effect of dilutive securities results in diluted weighted average shares outstanding of 948.6 million for the three months ended March 31, 2017.

[0000833444-18-000018:8k_2_02:116]
The Company has presented forward-looking statements regarding adjusted EPS from continuing operations, adjusted EBIT margin, organic adjusted net sales growth and adjusted free cash flow conversion (defined as adjusted free cash flow divided by adjusted net income from continuing operations attributable to JCI) for the full fiscal year of 2018, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, income or cash flows from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments related to pension and postretirement plans and the effect of foreign currency exchange fluctuations.  Our fiscal 2018 outlook for organic adjusted net sales growth also excludes the effect of acquisitions and divestitures, and for our Power Solutions business, the impacts of lead price fluctuations.  We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s full year 2018 GAAP financial results.

[0000833444-18-000018:8k_2_02:117]
Page 15 of 17

[0000833444-18-000018:8k_2_02:118]
3. Organic Adjusted Net Sales Growth Reconciliation

[0000833444-18-000018:8k_2_02:119]
The components of the changes in adjusted net sales for the three months ended March 31, 2018 versus the three months ended March 31, 2017, including organic net sales, is shown below (unaudited):

[0000833444-18-000018:8k_2_02:120]
| (in millions) | Adjusted Net Sales for the Three Months Ended March 31, 2017 |  | Base Year Adjustments -Divestitures |  | Adjusted Base Net Sales for the Three Months Ended March 31, 2017 |  | Foreign Currency |  | Lead Impact |  | Organic Net Sales |  | Adjusted Net Sales for the Three Months EndedMarch 31, 2018 |
| Building Solutions North America | $ | 2,074 |  |  | $ | — |  |  | 0.0 | % |  | $ | 2,074 |  |  | $ | 10 |  |  | 0.5 | % |  | $ | — |  |  | 0.0 | % |  | $ | 13 |  |  | 0.6 | % |  | $ | 2,097 |  |  | 1.1 | % |
| Building Solutions EMEA/LA | 891 |  |  | (37 | ) |  | -4.2 | % |  | 854 |  |  | 81 |  |  | 9.5 | % |  | — |  |  | 0.0 | % |  | (28 | ) |  | -3.3 | % |  | 907 |  |  | 6.2 | % |
| Building Solutions Asia Pacific | 562 |  |  | (2 | ) |  | -0.4 | % |  | 560 |  |  | 35 |  |  | 6.3 | % |  | — |  |  | 0.0 | % |  | (9 | ) |  | -1.6 | % |  | 586 |  |  | 4.6 | % |
| Global Products | 2,014 |  |  | (161 | ) |  | -8.0 | % |  | 1,853 |  |  | 72 |  |  | 3.9 | % |  | — |  |  | 0.0 | % |  | 115 |  |  | 6.2 | % |  | 2,040 |  |  | 10.1 | % |
| Total Building Technologies & Solutions | 5,541 |  |  | (200 | ) |  | -3.6 | % |  | 5,341 |  |  | 198 |  |  | 3.7 | % |  | — |  |  | 0.0 | % |  | 91 |  |  | 1.7 | % |  | 5,630 |  |  | 5.4 | % |
| Power Solutions | 1,696 |  |  | — |  |  | 0.0 | % |  | 1,696 |  |  | 113 |  |  | 6.7 | % |  | 68 |  |  | 4.0 | % |  | (32 | ) |  | -1.9 | % |  | 1,845 |  |  | 8.8 | % |
| Total net sales | $ | 7,237 |  |  | $ | (200 | ) |  | -2.8 | % |  | $ | 7,037 |  |  | $ | 311 |  |  | 4.4 | % |  | $ | 68 |  |  | 1.0 | % |  | $ | 59 |  |  | 0.8 | % |  | $ | 7,475 |  |  | 6.2 | % |

[0000833444-18-000018:8k_2_02:121]
The components of the changes in adjusted net sales for the six months ended March 31, 2018 versus the six months ended March 31, 2017, including organic net sales, is shown below (unaudited):

[0000833444-18-000018:8k_2_02:122]
| (in millions) | Adjusted Net Sales for the Six Months Ended March 31, 2017 |  | Base Year Adjustments -Divestitures |  | Adjusted Base Net Sales for the Six Months Ended March 31, 2017 |  | Foreign Currency |  | Lead Impact |  | Organic Net Sales |  | Adjusted Net Sales for the Six Months EndedMarch 31, 2018 |
| Building Solutions North America | $ | 4,016 |  |  | $ | — |  |  | 0.0 | % |  | $ | 4,016 |  |  | $ | 20 |  |  | 0.5 | % |  | $ | — |  |  | 0.0 | % |  | $ | 73 |  |  | 1.8 | % |  | $ | 4,109 |  |  | 2.3 | % |
| Building Solutions EMEA/LA | 1,769 |  |  | (80 | ) |  | -4.5 | % |  | 1,689 |  |  | 127 |  |  | 7.5 | % |  | — |  |  | 0.0 | % |  | 6 |  |  | 0.4 | % |  | 1,822 |  |  | 7.9 | % |
| Building Solutions Asia Pacific | 1,138 |  |  | (9 | ) |  | -0.8 | % |  | 1,129 |  |  | 49 |  |  | 4.3 | % |  | — |  |  | 0.0 | % |  | 5 |  |  | 0.4 | % |  | 1,183 |  |  | 4.8 | % |
| Global Products | 3,814 |  |  | (299 | ) |  | -7.8 | % |  | 3,515 |  |  | 92 |  |  | 2.6 | % |  | — |  |  | 0.0 | % |  | 214 |  |  | 6.1 | % |  | 3,821 |  |  | 8.7 | % |
| Total Building Technologies & Solutions | 10,737 |  |  | (388 | ) |  | -3.6 | % |  | 10,349 |  |  | 288 |  |  | 2.8 | % |  | — |  |  | 0.0 | % |  | 298 |  |  | 2.9 | % |  | 10,935 |  |  | 5.7 | % |
| Power Solutions | 3,596 |  |  | — |  |  | 0.0 | % |  | 3,596 |  |  | 191 |  |  | 5.3 | % |  | 199 |  |  | 5.5 | % |  | (11 | ) |  | -0.3 | % |  | 3,975 |  |  | 10.5 | % |
| Total net sales | $ | 14,333 |  |  | $ | (388 | ) |  | -2.7 | % |  | $ | 13,945 |  |  | $ | 479 |  |  | 3.4 | % |  | $ | 199 |  |  | 1.4 | % |  | $ | 287 |  |  | 2.1 | % |  | $ | 14,910 |  |  | 6.9 | % |

[0000833444-18-000018:8k_2_02:123]
4. Adjusted Free Cash Flow Reconciliation

[0000833444-18-000018:8k_2_02:124]
The Company's press release contains financial information regarding free cash flow and adjusted free cash flow, which are non-GAAP performance measures.  Free cash flow is defined as cash used by operating activities less capital expenditures.  Adjusted free cash flow excludes special items, as included in the table below, because these cash flows are not considered to be directly related to its underlying business.  Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash.

[0000833444-18-000018:8k_2_02:125]
The following is the three and six months ended March 31, 2018 and 2017 reconciliation of free cash flow and adjusted free cash flow (unaudited):

[0000833444-18-000018:8k_2_02:126]
| (in billions) | Three Months Ended March 31, 2018 |  | Three Months Ended March 31, 2017 |  | Six Months Ended March 31, 2018 |  | Six Months Ended March 31, 2017 |
| Cash provided (used) by operating activities | $ | 0.7 |  |  | $ | 0.4 |  |  | $ | 0.5 |  |  | $ | (1.5 | ) |
| Capital expenditures | (0.3 | ) |  | (0.3 | ) |  | (0.5 | ) |  | (0.6 | ) |
| Reported free cash flow* | $ | 0.4 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | (2.2 | ) |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction/integration/separation costs | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.3 |  |
| Transaction tax payments | — |  |  | 0.1 |  |  | — |  |  | 1.3 |  |
| Adient cash outflow | — |  |  | — |  |  | — |  |  | 0.3 |  |
| Change in control pension payment | — |  |  | — |  |  | — |  |  | 0.2 |  |
| Restructuring costs | 0.1 |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Total adjusting items | 0.2 |  |  | 0.2 |  |  | 0.3 |  |  | 2.2 |  |
| Adjusted free cash flow | $ | 0.6 |  |  | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | — |  |

[0000833444-18-000018:8k_2_02:127]
* May not sum due to rounding

[0000833444-18-000018:8k_2_02:128]
Page 16 of 17

[0000833444-18-000018:8k_2_02:129]
5. Net Debt to Capitalization

[0000833444-18-000018:8k_2_02:130]
The Company provides financial information regarding net debt as a percentage of total capitalization, which is a non-GAAP performance measure.  The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders.  The following is the March 31, 2018 and September 30, 2017 calculation of net debt as a percentage of total capitalization (unaudited):

[0000833444-18-000018:8k_2_02:131]
| (in millions) | March 31, 2018 |  | September 30, 2017 |
| Short-term debt and current portion of long-term debt | $ | 1,136 |  |  | $ | 1,608 |  |
| Long-term debt | 10,962 |  |  | 11,964 |  |
| Total debt | 12,098 |  |  | 13,572 |  |
| Less: cash and cash equivalents | 268 |  |  | 321 |  |
| Total net debt | 11,830 |  |  | 13,251 |  |
| Shareholders' equity attributable to JCI | 20,874 |  |  | 20,447 |  |
| Total capitalization | $ | 32,704 |  |  | $ | 33,698 |  |
| Total net debt as a % of total capitalization | 36.2 | % |  | 39.3 | % |

[0000833444-18-000018:8k_2_02:132]
6. Mark-to-Market of Pension and Postretirement Plans

[0000833444-18-000018:8k_2_02:133]
The pension and postretirement mark-to-market gain or loss for each period is excluded from adjusted diluted earnings per share.  There was no mark-to-market gain or loss for pension and postretirement plans for the three and six months ended March 31, 2018.  The three and six months ended March 31, 2017 includes a mark-to-market gain for pension plans of $18 million and $135 million, respectively, due to lump sum payouts for certain U.S. pension plans in the quarter.

[0000833444-18-000018:8k_2_02:134]
7. Divestitures

[0000833444-18-000018:8k_2_02:135]
On March 16, 2017, the Company announced that it signed a definitive agreement to sell its Scott Safety business to 3M for approximately $2.0 billion.  The transaction closed on October 4, 2017.  Net cash proceeds from the transaction approximated $1.9 billion and the Company recorded a net gain of $114 million ($84 million after tax).  Scott Safety is a leader in the design, manufacture and sale of high performance respiratory protection, gas and flame detection, thermal imaging and other critical products for fire services, law enforcement, industrial, oil and gas, chemical, armed forces, and homeland defense end markets.  The Scott Safety business is included within assets held for sale and liabilities held for sale in the accompanying condensed consolidated statement of financial position as of September 30, 2017.

[0000833444-18-000018:8k_2_02:136]
On October 31, 2017, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience business from JCI plc to Adient plc and the issuance of ordinary shares of Adient plc directly to holders of JCI plc ordinary shares on a pro rata basis.  Following the separation, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc.  Beginning in the first quarter of fiscal 2017, Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation.

[0000833444-18-000018:8k_2_02:137]
8. Income Taxes

[0000833444-18-000018:8k_2_02:138]
The Company's effective tax rate from continuing operations before consideration of the transaction/integration/separation costs, nonrecurring purchase accounting impacts related to the Tyco merger, mark-to-market gains or losses for pension and postretirement plans, Scott Safety gain on sale, restructuring and impairment costs and discrete tax items for the three and six months ending March 31, 2018 is approximately 14 percent and for the three and six months ending March 31, 2017 is approximately 15 percent.

[0000833444-18-000018:8k_2_02:139]
9. Restructuring

[0000833444-18-000018:8k_2_02:140]
The six months ended March 31, 2018 include restructuring and impairment costs of $158 million related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions and Power Solutions businesses, and at Corporate.  The three and six months ended March 31, 2017 restructuring and impairment costs of $99 million and $177 million, respectively, related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions business and at Corporate.

[0000833444-18-000018:8k_2_02:141]
Page 17 of 17
