# JCI MD&A — 0000833444-18-000021


## mdna

[0000833444-18-000021:mdna:1]
[same as prior period, unchanged from 0000833444-18-000008:mdna:1]

[0000833444-18-000021:mdna:2]
[same as prior period, unchanged from 0000833444-18-000008:mdna:2]

[0000833444-18-000021:mdna:3]
[same as prior period, unchanged from 0000833444-18-000008:mdna:3]

[0000833444-18-000021:mdna:4]
[same as prior period, unchanged from 0000833444-18-000008:mdna:4]

[0000833444-18-000021:mdna:5]
[same as prior period, unchanged from 0000833444-18-000008:mdna:5]

[0000833444-18-000021:mdna:6]
[same as prior period, unchanged from 0000833444-18-000008:mdna:6]

[0000833444-18-000021:mdna:7]
In the fourth quarter of fiscal 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco completed their combination, with JCI Inc. merging with a wholly owned, indirect subsidiary of Tyco (the "Merger"). Following the Merger, Tyco changed its name to “Johnson

[0000833444-18-000021:mdna:8]
Controls International plc” and JCI Inc. is a wholly-owned subsidiary of Johnson Controls International plc. The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes. Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company.

[0000833444-18-000021:mdna:9]
[same as prior period, unchanged from 0000833444-18-000008:mdna:8]

[0000833444-18-000021:mdna:10]
[same as prior period, unchanged from 0000833444-18-000008:mdna:9]

[0000833444-18-000021:mdna:11]
[same as prior period, unchanged from 0000833444-18-000008:mdna:10]

[0000833444-18-000021:mdna:12]
[same as prior period, unchanged from 0000833444-18-000008:mdna:11]

[0000833444-18-000021:mdna:13]
The following information should be read in conjunction with the September 30, 2017 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2017 filed with the SEC on November 21, 2017. References in the following discussion and analysis to "Three Months"(or similar language) refer to the three months ended March 31, 2018 compared to the three months ended March 31, 2017, while "Year-to-Date" refers to the six months ended March 31, 2018 compared to the six months ended March 31, 2017.

[0000833444-18-000021:mdna:14]
59

[0000833444-18-000021:mdna:15]
[same as prior period, unchanged from 0000833444-18-000008:mdna:13]

[0000833444-18-000021:mdna:16]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Net sales | $ | 7,475 |  |  | $ | 7,267 |  |  | 3 | % |  | $ | 14,910 |  |  | $ | 14,353 |  |  | 4 | % |

[0000833444-18-000021:mdna:17]
The increase in consolidated net sales for the three months ended March 31, 2018 was due to the favorable impact of foreign currency translation ($311 million) and higher sales in the Building Technologies & Solutions business ($61 million) and the Power Solutions business ($36 million), partially offset by lower sales due to business divestitures ($200 million). The increased sales in the Building Technologies & Solutions business, net of divestitures, related to higher volumes in the Global Products segment. Increased sales in the Power Solutions business resulted from the impact of higher lead costs on pricing, partially offset by lower volumes. Excluding the impact of foreign currency translation, impact of lead costs on pricing and business divestitures, consolidated net sales increased 1% as compared to the prior year. Refer to the "Segment Analysis" below within Item 2 for a discussion of net sales by segment.

[0000833444-18-000021:mdna:18]
The increase in consolidated net sales for the six months ended March 31, 2018 was due to the favorable impact of foreign currency translation ($483 million) and higher sales in the Building Technologies & Solutions business ($274 million) and the Power Solutions business ($188 million), partially offset by lower sales due to business divestitures ($388 million). The increased sales in the Building Technologies & Solutions business, net of divestitures, related to higher volumes  across all segments. Increased sales in the Power Solutions business resulted from the impact of higher lead costs on pricing, partially offset by lower volumes. Excluding the impact of foreign currency translation, impact of lead costs on pricing and business divestitures, consolidated net sales increased 2% as compared to the prior year. Refer to the "Segment Analysis" below within Item 2 for a discussion of net sales by segment.

[0000833444-18-000021:mdna:19]
[same as prior period, unchanged from 0000833444-18-000008:mdna:17]

[0000833444-18-000021:mdna:20]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Cost of sales | $ | 5,255 |  |  | $ | 4,986 |  |  | 5 | % |  | $ | 10,521 |  |  | $ | 9,958 |  |  | 6 | % |
| Gross profit | 2,220 |  |  | 2,281 |  |  | -3 | % |  | 4,389 |  |  | 4,395 |  |  | — | % |
| % of sales | 29.7 | % |  | 31.4 | % |  |  |  | 29.4 | % |  | 30.6 | % |  |  |

[0000833444-18-000021:mdna:21]
Cost of sales for the three month period ended March 31, 2018 increased as compared to the three month period ended March 31, 2017, and gross profit as a percentage of sales decreased by 170 basis points. Gross profit in the Building Technologies & Solutions business increased due to higher volumes and favorable mix in the Global Products and Building Solutions North America segments, partially offset by prior year nonrecurring purchase accounting adjustments ($30 million). Gross profit in the Power Solutions business was impacted by higher operating costs primarily driven by efforts to satisfy customer demand, partially offset by favorable pricing and product mix. Foreign currency translation had an unfavorable impact on cost of sales of approximately $229 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-18-000021:mdna:22]
Cost of sales for the six month period ended March 31, 2018 increased as compared to the six month period ended March 31, 2017, and gross profit as a percentage of sales decreased by 120 basis points. Gross profit in the Building Technologies & Solutions business increased due to prior year nonrecurring purchase accounting adjustments ($82 million), and higher volumes and favorable mix in the Global Products and Building Solutions North America segments, partially offset by higher operating costs. Gross profit in the Power Solutions business was impacted by higher operating costs primarily driven by efforts to satisfy customer demand, partially offset by favorable pricing and product mix. Foreign currency translation had an unfavorable impact on cost of sales of approximately $357 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-18-000021:mdna:23]
[same as prior period, unchanged from 0000833444-18-000008:mdna:20]

[0000833444-18-000021:mdna:24]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Selling, general and administrative expenses | $ | 1,588 |  |  | $ | 1,726 |  |  | -8 | % |  | $ | 3,005 |  |  | $ | 3,296 |  |  | -9 | % |
| % of sales | 21.2 | % |  | 23.8 | % |  |  |  | 20.2 | % |  | 23.0 | % |  |  |

[0000833444-18-000021:mdna:25]
Selling, general and administrative expenses ("SG&A") for the three month period ended March 31, 2018 decreased 8% as compared to the three month period ended March 31, 2017. The decrease in SG&A was primarily due to productivity savings and costs synergies, partially offset by net mark-to-market adjustments on pension plans which had a prior year favorable impact on SG&A of $13 million primarily due to favorable investment returns versus expectations. Foreign currency translation had an unfavorable impact on SG&A of $47 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-18-000021:mdna:26]
SG&A for the six month period ended March 31, 2018 decreased 9% as compared to the six month period ended March 31, 2017. The decrease in SG&A was primarily due to a gain on sale of Scott Safety in the Building Technologies & Solutions Global Products segment ($114 million), and productivity savings and costs synergies, partially offset by net mark-to-market adjustments on pension plans which had a prior year favorable impact on SG&A of $120 million primarily due to an increase in discount rates. Foreign currency translation had an unfavorable impact on SG&A of $71 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-18-000021:mdna:27]
[same as prior period, unchanged from 0000833444-18-000008:mdna:23]

[0000833444-18-000021:mdna:28]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Restructuring and impairment costs | $ | — |  |  | $ | 99 |  |  | * |  | $ | 158 |  |  | $ | 177 |  |  | -11 | % |

[0000833444-18-000021:mdna:29]
[same as prior period, unchanged from 0000833444-18-000008:mdna:25]

[0000833444-18-000021:mdna:30]
[same as prior period, unchanged from 0000833444-18-000008:mdna:26]

[0000833444-18-000021:mdna:31]
[same as prior period, unchanged from 0000833444-18-000008:mdna:28]

[0000833444-18-000021:mdna:32]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Net financing charges | $ | 115 |  |  | $ | 116 |  |  | -1 | % |  | $ | 231 |  |  | $ | 252 |  |  | -8 | % |

[0000833444-18-000021:mdna:33]
Net financing charges were lower for the six month period ended March 31, 2018 primarily due to prior year debt exchange offer fees.

[0000833444-18-000021:mdna:34]
[same as prior period, unchanged from 0000833444-18-000008:mdna:31]

[0000833444-18-000021:mdna:35]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Equity income | $ | 44 |  |  | $ | 53 |  |  | -17 | % |  | $ | 104 |  |  | $ | 108 |  |  | -4 | % |

[0000833444-18-000021:mdna:36]
The decrease in equity income for the three months ended March 31, 2018 was primarily due to lower income at partially-owned affiliates in the Power Solutions business. The decrease in equity income for the six months ended March 31, 2018 was primarily due to lower income at partially-owned affiliates in the Power Solutions business, partially offset by higher income at partially-owned affiliates in the Building Technologies & Solutions business. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-18-000021:mdna:37]
Income Tax Provision

[0000833444-18-000021:mdna:38]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Income tax provision | $ | 78 |  |  | $ | 508 |  |  | * |  | $ | 345 |  |  | $ | 481 |  |  | * |
| Effective tax rate | 14 | % |  | 129 | % |  |  |  | 31 | % |  | 62 | % |  |  |

[0000833444-18-000021:mdna:39]
[same as prior period, unchanged from 0000833444-18-000008:mdna:36]

[0000833444-18-000021:mdna:40]
[same as prior period, unchanged from 0000833444-18-000008:mdna:37]

[0000833444-18-000021:mdna:41]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended March 31, 2018, the Company's effective tax rate was 14% and was higher than the statutory tax rate of 12.5% primarily due to tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the six months ended March 31, 2018, the Company's effective tax rate was 31% and was higher than the statutory tax rate of 12.5% primarily due to the discrete net impacts of U.S. Tax Reform, final income tax effects of the completed divestiture of the Scott Safety business and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives and tax audit closures. For the three months ended March 31, 2017, the Company's effective tax rate was 129% and was higher than the statutory tax rate of 12.5% primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the divestiture of the Scott Safety business and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives, the jurisdictional mix of significant restructuring and impairment costs, and Tyco Merger transaction and integration costs. For the six months ended March 31, 2017, the Company's effective tax rate was 62% and was higher than the statutory tax rate of 12.5% primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the divestiture of the Scott Safety business, the income tax effects of pension mark-to-market gains, and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives, the jurisdictional mix of significant restructuring and impairment costs, Tyco Merger transaction and integration costs, purchase accounting impacts and a tax benefit due to changes in entity tax status. The effective tax rate for the six months ended March 31, 2018 decreased as compared to the six months ended March 31, 2017, primarily due to the discrete tax items described below and tax planning initiatives. The global tax planning initiatives related primarily to foreign tax credit planning, global financing structures and alignment of our global business functions in a tax efficient manner.

[0000833444-18-000021:mdna:42]
In the second quarter of fiscal 2018, the Company recorded $64 million of transaction and integration costs. These costs generated a $9 million tax benefit which was impacted by the Company’s current tax position in these jurisdictions.

[0000833444-18-000021:mdna:43]
On December 22, 2017, the “Tax Cuts and Jobs Act” (H.R. 1) was enacted which significantly revises U.S. corporate income tax by, among other things, lower corporate income tax rates, impose a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries, and implement a territorial tax system and various base erosion minimum tax provisions.

[0000833444-18-000021:mdna:44]
62

[0000833444-18-000021:mdna:45]
[same as prior period, unchanged from 0000833444-18-000008:mdna:41]

[0000833444-18-000021:mdna:46]
[same as prior period, unchanged from 0000833444-18-000008:mdna:42]

[0000833444-18-000021:mdna:47]
[same as prior period, unchanged from 0000833444-18-000008:mdna:43]

[0000833444-18-000021:mdna:48]
[same as prior period, unchanged from 0000833444-18-000008:mdna:44]

[0000833444-18-000021:mdna:49]
[same as prior period, unchanged from 0000833444-18-000008:mdna:45]

[0000833444-18-000021:mdna:50]
In the first quarter of fiscal 2018, the Company completed the sale of its Scott Safety business to 3M Company. Refer to Note 3, "Acquisitions and Divestitures," of the notes to consolidated financial statements for additional information. In connection with the sale, the Company recorded a pre-tax gain of $114 million and income tax expense of $30 million.

[0000833444-18-000021:mdna:51]
[same as prior period, unchanged from 0000833444-18-000008:mdna:46]

[0000833444-18-000021:mdna:52]
In the second quarter of fiscal 2017, the Company recorded a discrete non-cash tax charge of $457 million related to establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries of the Scott Safety business.

[0000833444-18-000021:mdna:53]
In the second quarter of fiscal 2017, the Company recorded $138 million of transaction and integration costs which generated a $31 million tax benefit.

[0000833444-18-000021:mdna:54]
In the second quarter of fiscal 2017, the Company recorded pension mark-to-market gains of $18 million, which resulted in tax expense of $8 million.

[0000833444-18-000021:mdna:55]
In the second quarter of fiscal 2017, the Company recorded $99 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $20 million tax benefit, which was impacted by the Company’s current tax position in these jurisdictions.

[0000833444-18-000021:mdna:56]
[same as prior period, unchanged from 0000833444-18-000008:mdna:47]

[0000833444-18-000021:mdna:57]
In the first quarter of fiscal 2017, the Company recorded pension mark-to-market gains of $117 million, which resulted in tax expense of $46 million.

[0000833444-18-000021:mdna:58]
[same as prior period, unchanged from 0000833444-18-000008:mdna:48]

[0000833444-18-000021:mdna:59]
[same as prior period, unchanged from 0000833444-18-000008:mdna:49]

[0000833444-18-000021:mdna:60]
[same as prior period, unchanged from 0000833444-18-000008:mdna:50]

[0000833444-18-000021:mdna:61]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Loss from discontinued operations, net of tax | $ | — |  |  | $ | — |  |  | * |  | $ | — |  |  | $ | (34 | ) |  | * |

[0000833444-18-000021:mdna:62]
[same as prior period, unchanged from 0000833444-18-000008:mdna:52]

[0000833444-18-000021:mdna:63]
[same as prior period, unchanged from 0000833444-18-000008:mdna:53]

[0000833444-18-000021:mdna:64]
[same as prior period, unchanged from 0000833444-18-000008:mdna:54]

[0000833444-18-000021:mdna:65]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 45 |  |  | $ | 33 |  |  | 36 | % |  | $ | 86 |  |  | $ | 73 |  |  | 18 | % |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | — |  |  | * |  |  | — |  |  | 9 |  |  | * |  |

[0000833444-18-000021:mdna:66]
[same as prior period, unchanged from 0000833444-18-000008:mdna:56]

[0000833444-18-000021:mdna:67]
The increase in income from continuing operations attributable to noncontrolling interests for the three and six months ended March 31, 2018 was primarily due to higher net income related to the Johnson Controls - Hitachi ("JCH") joint venture in the Building Technologies & Solutions business and higher net income at a Power Solutions partially-owned affiliate.

[0000833444-18-000021:mdna:68]
[same as prior period, unchanged from 0000833444-18-000008:mdna:58]

[0000833444-18-000021:mdna:69]
Net Income (Loss) Attributable to Johnson Controls

[0000833444-18-000021:mdna:70]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Net income (loss) attributable to Johnson Controls | $ | 438 |  |  | $ | (148 | ) |  | * |  | $ | 668 |  |  | $ | 181 |  |  | * |

[0000833444-18-000021:mdna:71]
[same as prior period, unchanged from 0000833444-18-000008:mdna:64]

[0000833444-18-000021:mdna:72]
The increase in net income attributable to Johnson Controls for the three and six months ended March 31, 2018 was primarily due to lower income tax provision due to higher discrete period net tax charges in the prior year and lower SG&A. Diluted earnings (loss) per share attributable to Johnson Controls for the three months ended March 31, 2018 was $0.47 compared to $(0.16) for the three months ended March 31, 2017. Diluted earnings per share attributable to Johnson Controls for the six months ended March 31, 2018 was $0.72 compared to $0.19 for the six months ended March 31, 2017.

[0000833444-18-000021:mdna:73]
Comprehensive Income (Loss) Attributable to Johnson Controls

[0000833444-18-000021:mdna:74]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Comprehensive income (loss) attributable to Johnson Controls | $ | 598 |  |  | $ | 98 |  |  | * |  | $ | 887 |  |  | $ | (234 | ) |  | * |

[0000833444-18-000021:mdna:75]
[same as prior period, unchanged from 0000833444-18-000008:mdna:76]

[0000833444-18-000021:mdna:76]
The increase in comprehensive income attributable to Johnson Controls for the three months ended March 31, 2018 was primarily due to higher net income attributable to Johnson Controls ($586 million), partially offset by a decrease in other comprehensive income attributable to Johnson Controls ($86 million) resulting primarily from unfavorable foreign currency translation adjustments. These year-over-year unfavorable foreign currency translation adjustments were primarily driven by the strengthening of the Brazilian real and Japanese yen currencies against the U.S. dollar in the prior year.

[0000833444-18-000021:mdna:77]
The increase in comprehensive income (loss) attributable to Johnson Controls for the six months ended March 31, 2018 was primarily due to an increase in other comprehensive income attributable to Johnson Controls ($634 million) resulting primarily from favorable foreign currency translation adjustments and higher net income attributable to Johnson Controls ($487 million). These year-over-year favorable foreign currency translation adjustments were primarily driven by the strengthening of the British pound and euro against the U.S. dollar.

[0000833444-18-000021:mdna:78]
[same as prior period, unchanged from 0000833444-18-000008:mdna:66]

[0000833444-18-000021:mdna:79]
[same as prior period, unchanged from 0000833444-18-000008:mdna:67]

[0000833444-18-000021:mdna:80]
[same as prior period, unchanged from 0000833444-18-000008:mdna:68]

[0000833444-18-000021:mdna:81]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Building Solutions North America | $ | 2,097 |  |  | $ | 2,097 |  |  | — | % |  | $ | 4,109 |  |  | $ | 4,039 |  |  | 2 | % |
| Building Solutions EMEA/LA | 907 |  |  | 898 |  |  | 1 | % |  | 1,822 |  |  | 1,773 |  |  | 3 | % |
| Building Solutions Asia Pacific | 586 |  |  | 562 |  |  | 4 | % |  | 1,183 |  |  | 1,137 |  |  | 4 | % |
| Global Products | 2,040 |  |  | 2,014 |  |  | 1 | % |  | 3,821 |  |  | 3,808 |  |  | — |  |
|  | $ | 5,630 |  |  | $ | 5,571 |  |  | 1 | % |  | $ | 10,935 |  |  | $ | 10,757 |  |  | 2 | % |

[0000833444-18-000021:mdna:82]
Three Months:

[0000833444-18-000021:mdna:83]
| • | Building Solutions North America was consistent with the prior year due to higher volumes ($13 million) and the favorable impact of foreign currency translation ($10 million), offset by the impact of prior year nonrecurring purchase accounting adjustments ($23 million). The increase in volumes was primarily attributable to higher HVAC and controls sales. |

[0000833444-18-000021:mdna:84]
| • | The increase in Building Solutions EMEA/LA was due to the favorable impact of foreign currency translation ($81 million), partially offset by lower volumes related to a business divestiture ($37 million), lower volumes in Europe ($17 million) and the Middle East ($11 million), and the impact of prior year nonrecurring purchase accounting adjustments ($7 million). |

[0000833444-18-000021:mdna:85]
| • | The increase in Building Solutions Asia Pacific was due to the favorable impact of foreign currency translation ($35 million), partially offset by lower volumes ($9 million) and lower volumes related to a business divestiture ($2 million). |

[0000833444-18-000021:mdna:86]
| • | The increase in Global Products was due to higher volumes ($115 million), and the favorable impact of foreign currency translation ($72 million), partially offset by lower volumes related to business divestitures ($161 million). The increase in volumes was primarily attributable to higher building management, HVAC and refrigeration equipment, and specialty products sales. |

[0000833444-18-000021:mdna:87]
Year-to-Date:

[0000833444-18-000021:mdna:88]
| • | The increase in Building Solutions North America was due to higher volumes ($73 million) and the favorable impact of foreign currency translation ($20 million), partially offset by the impact of prior year nonrecurring purchase accounting adjustments ($23 million). The increase in volumes was primarily attributable to higher HVAC and controls sales. |

[0000833444-18-000021:mdna:89]
| • | The increase in Building Solutions EMEA/LA was due to the favorable impact of foreign currency translation ($128 million), and higher volumes in Latin America ($11 million) and the Middle East ($9 million), partially offset by lower volumes related to a business divestiture ($80 million), lower volumes in Europe ($15 million) and the impact of prior year nonrecurring purchase accounting adjustments ($4 million). |

[0000833444-18-000021:mdna:90]
| • | The increase in Building Solutions Asia Pacific was due to the favorable impact of foreign currency translation ($49 million), higher volumes ($5 million) and the impact of prior year nonrecurring purchase accounting adjustments ($1 million), partially offset by lower volumes related to a business divestiture ($9 million). |

[0000833444-18-000021:mdna:91]
| • | The increase in Global Products was due to higher volumes ($211 million), the favorable impact of foreign currency translation ($95 million) and the impact of prior year nonrecurring purchase accounting adjustments ($6 million), partially offset by lower volumes related to business divestitures ($299 million). The increase in volumes was primarily attributable to higher building management, HVAC and refrigeration equipment, and specialty products sales. |

[0000833444-18-000021:mdna:92]
[same as prior period, unchanged from 0000833444-18-000008:mdna:74]

[0000833444-18-000021:mdna:93]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Building Solutions North America | $ | 239 |  |  | $ | 255 |  |  | -6 | % |  | $ | 466 |  |  | $ | 451 |  |  | 3 | % |
| Building Solutions EMEA/LA | 77 |  |  | 89 |  |  | -13 | % |  | 146 |  |  | 138 |  |  | 6 | % |
| Building Solutions Asia Pacific | 71 |  |  | 67 |  |  | 6 | % |  | 145 |  |  | 130 |  |  | 12 | % |
| Global Products | 228 |  |  | 242 |  |  | -6 | % |  | 514 |  |  | 369 |  |  | 39 | % |
|  | $ | 615 |  |  | $ | 653 |  |  | -6 | % |  | $ | 1,271 |  |  | $ | 1,088 |  |  | 17 | % |

[0000833444-18-000021:mdna:94]
Three Months:

[0000833444-18-000021:mdna:95]
| • | The decrease in Building Solutions North America was due to prior year nonrecurring purchase accounting adjustments ($34 million), current year integration costs ($5 million) and incremental investments ($5 million), partially offset by favorable volumes / mix ($11 million), lower operating costs ($8 million), prior year integration costs ($7 million), lower selling, general and administrative expenses ($1 million), and prior year transaction costs ($1 million). |

[0000833444-18-000021:mdna:96]
| • | The decrease in Building Solutions EMEA/LA was due to prior year nonrecurring purchase accounting adjustments ($15 million), lower volumes ($9 million), incremental investments ($3 million), lower equity income ($3 million) and current year integration costs ($1 million), partially offset by the favorable impact of foreign currency translation ($9 million), prior year transaction costs ($3 million), favorable mix ($3 million), prior year integration costs ($2 million), and lower selling, general and administrative expenses ($2 million). |

[0000833444-18-000021:mdna:97]
66

[0000833444-18-000021:mdna:98]
| • | The increase in Building Solutions Asia Pacific was due to favorable mix ($8 million), the favorable impact of foreign currency translation ($2 million), and prior year integration costs ($2 million), partially offset by lower volumes ($3 million), incremental investments ($2 million), prior year nonrecurring purchase accounting adjustments ($2 million), and higher selling, general and administrative expenses ($1 million), . |

[0000833444-18-000021:mdna:99]
| • | The decrease in Global Products was due to lower income due to business divestitures ($39 million), higher operating costs ($20 million), current year integration costs ($9 million), and higher selling, general and administrative expenses including planned incremental global product and channel investments, partially offset by productivity savings and an insignificant gain on a business divestiture ($8 million). These items were partially offset by favorable volumes / mix ($37 million), the favorable impact of foreign currency translation ($10 million), prior year transaction costs ($6 million), prior year integration costs ($5 million) and higher equity income ($4 million). |

[0000833444-18-000021:mdna:100]
Year-to-Date:

[0000833444-18-000021:mdna:101]
| • | The increase in Building Solutions North America was due to favorable volumes / mix ($16 million), prior year integration costs ($14 million), prior year transaction costs ($11 million), lower operating costs ($3 million), lower selling, general and administrative expenses ($3 million), and the favorable impact of foreign currency translation ($1 million), partially offset by current year integration costs ($14 million), prior year nonrecurring purchase accounting adjustments ($11 million) and incremental investments ($8 million). |

[0000833444-18-000021:mdna:102]
| • | The increase in Building Solutions EMEA/LA was due to the favorable impact of foreign currency translation ($13 million), prior year transaction costs ($5 million), prior year integration costs ($4 million), favorable mix ($3 million) and higher volumes ($1 million), partially offset by higher operating costs ($5 million), prior year nonrecurring purchase accounting adjustments ($3 million), current year integration costs ($3 million), incremental investments ($3 million), lower income due to a business divestiture ($2 million), and lower equity income ($2 million). |

[0000833444-18-000021:mdna:103]
| • | The increase in Building Solutions Asia Pacific was due to favorable mix ($8 million), prior year nonrecurring purchase accounting adjustments ($4 million), prior year integration costs ($3 million), lower selling, general and administrative expenses ($2 million), prior year transaction costs ($2 million) and the favorable impact of foreign currency translation ($2 million), partially offset by unfavorable pricing ($4 million) and incremental investments ($2 million). |

[0000833444-18-000021:mdna:104]
| • | The increase in Global Products was due to a gain on sale of Scott Safety ($114 million), prior year nonrecurring purchase accounting adjustments ($71 million), favorable volumes / mix ($67 million), the favorable impact of foreign currency translation ($15 million), higher equity income ($11 million), prior year integration costs ($9 million) and prior year transaction costs ($9 million). These items were partially offset by lower income due to business divestitures ($74 million), higher operating costs ($33 million), higher selling, general and administrative expenses including planned incremental global product and channel investments partially offset by productivity savings and an insignificant gain on a business divestiture ($29 million), and current year integration costs ($15 million). |

[0000833444-18-000021:mdna:105]
[same as prior period, unchanged from 0000833444-18-000008:mdna:83]

[0000833444-18-000021:mdna:106]
|  | Three Months Ended March 31, |  |  |  | Six Months EndedMarch 31, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Net sales | $ | 1,845 |  |  | $ | 1,696 |  |  | 9 | % |  | $ | 3,975 |  |  | $ | 3,596 |  |  | 11 | % |
| Segment EBITA | 314 |  |  | 303 |  |  | 4 | % |  | 698 |  |  | 692 |  |  | 1 | % |

[0000833444-18-000021:mdna:107]
Three Months:

[0000833444-18-000021:mdna:108]
| • | Net sales increased due to the favorable impact of foreign currency translation ($113 million), the impact of higher lead costs on pricing ($68 million), and favorable pricing and product mix ($31 million), partially offset by lower volumes ($63 million). The decrease in volumes was driven by changes in customer demand patterns in North America and Europe, partially offset by an increase in start-stop battery volumes. Additionally, higher start-stop volumes contributed to favorable product mix. |

[0000833444-18-000021:mdna:109]
| • | Segment EBITA increased due to favorable pricing and product mix ($29 million), lower selling, general and administrative expenses due to lower employee related expenses and cost reduction initiatives ($16 million), and the favorable impact |

[0000833444-18-000021:mdna:110]
67

[0000833444-18-000021:mdna:111]
of foreign currency translation ($14 million), partially offset by lower volumes ($22 million), lower equity income ($12 million), higher operating costs primarily driven by efforts to satisfy customer demand including higher transportation costs ($7 million) and incremental investments ($7 million).

[0000833444-18-000021:mdna:112]
Year-to-Date:

[0000833444-18-000021:mdna:113]
| • | Net sales increased due to the impact of higher lead costs on pricing ($199 million), the favorable impact of foreign currency translation ($191 million), and favorable pricing and product mix ($79 million), partially offset by lower volumes ($90 million). The decrease in volumes was driven by changes in customer demand patterns in North America and Europe, partially offset by an increase in start-stop battery volumes. Additionally, higher start-stop volumes contributed to favorable product mix. |

[0000833444-18-000021:mdna:114]
| • | Segment EBITA increased due to favorable pricing and product mix ($48 million), lower selling, general and administrative expenses from productivity savings and a gain on a business deconsolidation ($29 million), the favorable impact of foreign currency translation ($24 million) and prior year transaction costs ($1 million), partially offset by higher operating costs primarily driven by efforts to satisfy customer demand including higher transportation costs ($32 million), lower volumes ($30 million), incremental investments ($18 million) and lower equity income ($16 million). |

[0000833444-18-000021:mdna:115]
[same as prior period, unchanged from 0000833444-18-000008:mdna:87]

[0000833444-18-000021:mdna:116]
The Company's backlog relating to the Building Technologies & Solutions business is applicable to its sales of systems and services. At March 31, 2018, the backlog was $8.9 billion. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned during the fiscal year.

[0000833444-18-000021:mdna:117]
[same as prior period, unchanged from 0000833444-18-000008:mdna:90]

[0000833444-18-000021:mdna:118]
[same as prior period, unchanged from 0000833444-18-000008:mdna:91]

[0000833444-18-000021:mdna:119]
|  | March 31, |  | September 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Current assets | $ | 12,271 |  |  | $ | 12,292 |  |  |  |
| Current liabilities | (10,992 | ) |  | (11,854 | ) |  |  |
|  | 1,279 |  |  | 438 |  |  | * |  |
| Less: Cash | (268 | ) |  | (321 | ) |  |  |
| Add: Short-term debt | 1,111 |  |  | 1,214 |  |  |  |
| Add: Current portion of long-term debt | 25 |  |  | 394 |  |  |  |
| Less: Assets held for sale | (22 | ) |  | (189 | ) |  |  |
| Add: Liabilities held for sale | — |  |  | 72 |  |  |  |
| Working capital (as defined) | $ | 2,125 |  |  | $ | 1,608 |  |  | 32 | % |
| Accounts receivable - net | $ | 6,679 |  |  | $ | 6,666 |  |  | — | % |
| Inventories | 3,565 |  |  | 3,209 |  |  | 11 | % |
| Accounts payable | 4,250 |  |  | 4,271 |  |  | — | % |
| * Measure not meaningful |  |  |  |  |  |

[0000833444-18-000021:mdna:120]
[same as prior period, unchanged from 0000833444-18-000008:mdna:93]

[0000833444-18-000021:mdna:121]
68

[0000833444-18-000021:mdna:122]
| • | The increase in working capital at March 31, 2018 as compared to September 30, 2017, was primarily due to an increase in inventory to meet anticipated customer demand as well as the impact of foreign currency translation. |

[0000833444-18-000021:mdna:123]
| • | The Company’s days sales in accounts receivable at March 31, 2018 were 68 days, higher than 65 days at September 30, 2017. There has been no significant adverse changes in the level of overdue receivables or changes in revenue recognition methods. |

[0000833444-18-000021:mdna:124]
| • | The Company’s inventory turns for the three months ended March 31, 2018 were lower than the comparable period ended September 30, 2017, primarily due to changes in inventory production levels. |

[0000833444-18-000021:mdna:125]
| • | Days in accounts payable at March 31, 2018 were 72 days, slightly lower than 73 days at the comparable period ended September 30, 2017. |

[0000833444-18-000021:mdna:126]
[same as prior period, unchanged from 0000833444-18-000008:mdna:99]

[0000833444-18-000021:mdna:127]
|  |  | Six Months Ended March 31, |
| (in millions) |  | 2018 |  | 2017 |
| Cash provided (used) by operating activities |  | $ | 533 |  |  | $ | (1,519 | ) |
| Cash provided (used) by investing activities |  | 1,598 |  |  | (472 | ) |
| Cash provided (used) by financing activities |  | (2,254 | ) |  | 1,744 |  |
| Capital expenditures |  | (497 | ) |  | (634 | ) |

[0000833444-18-000021:mdna:128]
| • | The increase in cash provided by operating activities for the six months ended March 31, 2018 was primarily due to higher prior year income tax payments related to the Adient spin-off ($1.2 billion in the first quarter of fiscal 2017) and prior year operating cash outflows in the Automotive Experience business before the Adient spin-off, change in control pension payments and transaction/integration related payments. |

[0000833444-18-000021:mdna:129]
| • | The increase in cash provided by investing activities for the six months ended March 31, 2018 was primarily due to net cash proceeds received from the Scott Safety business divestiture in the current year and a decrease in capital expenditures. |

[0000833444-18-000021:mdna:130]
| • | The increase in cash used by financing activities for the six months ended March 31, 2018 was primarily due to the prior year net dividend proceeds from the Adient spin-off, higher current year repayments of long-term debt and a decrease in long-term debt borrowings, partially offset by cash transferred in the prior year to Adient related to the spin-off. |

[0000833444-18-000021:mdna:131]
| • | The decrease in capital expenditures for the six months ended March 31, 2018 primarily relates to lower capital investments in the current year in the Building Technologies & Solutions business and prior year capital investments in the Automotive Experience business before the Adient spin-off. |

[0000833444-18-000021:mdna:132]
[same as prior period, unchanged from 0000833444-18-000008:mdna:105]

[0000833444-18-000021:mdna:133]
|  | March 31, |  | September 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Short-term debt | $ | 1,111 |  |  | $ | 1,214 |  |  |  |
| Current portion of long-term debt | 25 |  |  | 394 |  |  |  |
| Long-term debt | 10,962 |  |  | 11,964 |  |  |  |
| Total debt | 12,098 |  |  | 13,572 |  |  | -11 | % |
| Less: cash and cash equivalents | 268 |  |  | 321 |  |  |  |
| Total net debt | 11,830 |  |  | 13,251 |  |  | -11 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 20,874 |  |  | 20,447 |  |  | 2 | % |
| Total capitalization | $ | 32,704 |  |  | $ | 33,698 |  |  | -3 | % |
| Total net debt as a % of total capitalization | 36.2 | % |  | 39.3 | % |  |  |

[0000833444-18-000021:mdna:134]
[same as prior period, unchanged from 0000833444-18-000008:mdna:107]

[0000833444-18-000021:mdna:135]
| • | The Company believes its capital resources and liquidity position at March 31, 2018 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in the remainder of fiscal 2018 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company and Tyco International Holding S.à.r.l ("TSarl") are unable to issue commercial paper, they would have the ability to draw on their $2.0 billion and $1.25 billion revolving credit facilities, respectively. Both facilities mature in August 2020. There were no draws on the revolving credit facility as of March 31, 2018 and September 30, 2017. The Company also selectively makes use of short-term credit lines other than its revolving credit facilities at the Company and TSarl. The Company estimates that, as of March 31, 2018, it could borrow up to $2.2 billion based on average borrowing levels during the quarter on committed credit lines. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future. |

[0000833444-18-000021:mdna:136]
| • | The Company’s debt financial covenant in its revolving credit facility require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. TSarl's revolving credit facility contains customary terms and conditions, and a financial covenant that limits the ratio of TSarl's debt to earnings before interest, taxes, depreciation, and amortization as adjusted for certain items set forth in the agreement to 3.5x. TSarl's revolving credit facility also limits its ability to incur subsidiary debt or grant liens on its and its subsidiaries' property. As of March 31, 2018, the Company and TSarl were in compliance with all covenants and other requirements set forth in their credit agreements and the indentures, governing their notes, and expect to remain in compliance for the foreseeable future. None of the Company’s or TSarl's debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the respective borrower's credit rating. |

[0000833444-18-000021:mdna:137]
| • | The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2018, the Company believes the long-term rate of return will approximate 7.50%, 5.35% and 5.65% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first six months of fiscal 2018, the Company made approximately $37 million in total pension and postretirement contributions. In total, the |

[0000833444-18-000021:mdna:138]
70

[0000833444-18-000021:mdna:139]
Company expects to contribute approximately $100 million in cash to its defined benefit pension plans in fiscal 2018. The Company expects to contribute $5 million in cash to its postretirement plans in fiscal 2018.

[0000833444-18-000021:mdna:140]
[same as prior period, unchanged from 0000833444-18-000008:mdna:113]

[0000833444-18-000021:mdna:141]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2018 and recorded $158 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2018 restructuring plan will reduce annual operating costs by approximately $150 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in 2020. For fiscal 2018, the savings, net of execution costs, are expected to be approximately 45% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in 2020. The restructuring plan reserve balance of $119 million at March 31, 2018 is expected to be paid in cash. |

[0000833444-18-000021:mdna:142]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2017 and recorded $367 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs by approximately $280 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2019. For fiscal 2018, the savings, net of execution costs, are expected to be approximately 85% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in 2018. The restructuring plan reserve balance of $128 million at March 31, 2018 is expected to be paid in cash. |

[0000833444-18-000021:mdna:143]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2016 and recorded $288 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2016 restructuring plan will reduce annual operating costs by approximately $135 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2019. For fiscal 2018, the savings, net of execution costs, are expected to be approximately 75% of the expected annual operating cost reduction. The |

[0000833444-18-000021:mdna:144]
71

[0000833444-18-000021:mdna:145]
restructuring action is expected to be substantially complete in 2018. The restructuring plan reserve balance of $76 million at March 31, 2018 is expected to be paid in cash.

[0000833444-18-000021:mdna:146]
[same as prior period, unchanged from 0000833444-18-000008:mdna:118]

[0000833444-18-000021:mdna:147]
[same as prior period, unchanged from 0000833444-18-000008:mdna:119]

[0000833444-18-000021:mdna:148]
[same as prior period, unchanged from 0000833444-18-000008:mdna:120]
