# JCI notes — 0000833444-18-000021


## jci:ComponentsOfNetFinancingChargesTableTextBlock

[0000833444-18-000021:notes:1]
The Company's net financing charges line item in the consolidated statements of income for the three and six months ended March 31, 2018 and 2017 contained the following components (in millions):

[0000833444-18-000021:notes:2]
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Interest expense, net of capitalized interest costs | $ | 104 |  |  | $ | 118 |  |  | $ | 218 |  |  | $ | 228 |  |
| Banking fees and bond cost amortization | 14 |  |  | 11 |  |  | 27 |  |  | 41 |  |
| Interest income | (5 | ) |  | (5 | ) |  | (14 | ) |  | (12 | ) |
| Net foreign exchange results for financing activities | 2 |  |  | (8 | ) |  | — |  |  | (5 | ) |
| Net financing charges | $ | 115 |  |  | $ | 116 |  |  | $ | 231 |  |  | $ | 252 |  |


## jci:DisposalGroupIncludingDiscontinuedOperationsIncomeStatementDisclosuresTableTextBlock

[0000833444-18-000021:notes:3]
The following table summarizes the results of Adient, reclassified as discontinued operations for the six month period ended March 31, 2017 (in millions). As the Adient spin-off occurred on October 31, 2016, there is only one month of Adient results included in the six month period ended March 31, 2017.

[0000833444-18-000021:notes:4]
|  | Six Months Ended March 31, |
|  | 2017 |
| Net sales | $ | 1,434 |  |
| Income from discontinued operations before income taxes | 1 |  |
| Provision for income taxes on discontinued operations | 35 |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax | 9 |  |
| Loss from discontinued operations | $ | (43 | ) |


## jci:EquityAttributableToParentAndNoncontrollingInterestsTableTextBlock

[0000833444-18-000021:notes:5]
[same as prior period, unchanged from 0000833444-18-000008:notes:5]

[0000833444-18-000021:notes:6]
|  | Three Months Ended March 31, 2018 |  | Three Months Ended March 31, 2017 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, December 31, | $ | 20,535 |  |  | $ | 965 |  |  | $ | 21,500 |  |  | $ | 19,577 |  |  | $ | 819 |  |  | $ | 20,396 |  |
| Total comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | 438 |  |  | 33 |  |  | 471 |  |  | (148 | ) |  | 25 |  |  | (123 | ) |
| Foreign currency translation adjustments | 168 |  |  | 31 |  |  | 199 |  |  | 241 |  |  | 10 |  |  | 251 |  |
| Realized and unrealized gains (losses) on derivatives | (6 | ) |  | 1 |  |  | (5 | ) |  | (6 | ) |  | (2 | ) |  | (8 | ) |
| Realized and unrealized gains (losses) on marketable securities | (2 | ) |  | — |  |  | (2 | ) |  | 11 |  |  | — |  |  | 11 |  |
| Other comprehensive income | 160 |  |  | 32 |  |  | 192 |  |  | 246 |  |  | 8 |  |  | 254 |  |
| Comprehensive income | 598 |  |  | 65 |  |  | 663 |  |  | 98 |  |  | 33 |  |  | 131 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (240 | ) |  | — |  |  | (240 | ) |  | (235 | ) |  | — |  |  | (235 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (43 | ) |  | (43 | ) |  | — |  |  | (47 | ) |  | (47 | ) |
| Repurchases of ordinary shares | (49 | ) |  | — |  |  | (49 | ) |  | (119 | ) |  | — |  |  | (119 | ) |
| Change in noncontrolling interest share | — |  |  | 19 |  |  | 19 |  |  | — |  |  | 8 |  |  | 8 |  |
| Spin-off of Adient | — |  |  | — |  |  | — |  |  | (18 | ) |  | — |  |  | (18 | ) |
| Other, including options exercised | 30 |  |  | — |  |  | 30 |  |  | 85 |  |  | — |  |  | 85 |  |
| Ending balance, March 31 | $ | 20,874 |  |  | $ | 1,006 |  |  | $ | 21,880 |  |  | $ | 19,388 |  |  | $ | 813 |  |  | $ | 20,201 |  |

[0000833444-18-000021:notes:7]
|  | Six Months Ended March 31, 2018 |  | Six Months Ended March 31, 2017 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, September 30, | $ | 20,447 |  |  | $ | 920 |  |  | $ | 21,367 |  |  | $ | 24,118 |  |  | $ | 972 |  |  | $ | 25,090 |  |
| Total comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 668 |  |  | 61 |  |  | 729 |  |  | 181 |  |  | 61 |  |  | 242 |  |
| Foreign currency translation adjustments | 226 |  |  | 47 |  |  | 273 |  |  | (418 | ) |  | (25 | ) |  | (443 | ) |
| Realized and unrealized gains (losses) on derivatives | (5 | ) |  | 2 |  |  | (3 | ) |  | (6 | ) |  | 2 |  |  | (4 | ) |
| Realized and unrealized gains (losses) on marketable securities | (2 | ) |  | — |  |  | (2 | ) |  | 9 |  |  | — |  |  | 9 |  |
| Other comprehensive income (loss) | 219 |  |  | 49 |  |  | 268 |  |  | (415 | ) |  | (23 | ) |  | (438 | ) |
| Comprehensive income (loss) | 887 |  |  | 110 |  |  | 997 |  |  | (234 | ) |  | 38 |  |  | (196 | ) |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (482 | ) |  | — |  |  | (482 | ) |  | (471 | ) |  | — |  |  | (471 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (43 | ) |  | (43 | ) |  | — |  |  | (47 | ) |  | (47 | ) |
| Repurchases of ordinary shares | (199 | ) |  | — |  |  | (199 | ) |  | (119 | ) |  | — |  |  | (119 | ) |
| Change in noncontrolling interest share | — |  |  | 19 |  |  | 19 |  |  | — |  |  | (12 | ) |  | (12 | ) |
| Adoption of ASU 2016-09 | 179 |  |  | — |  |  | 179 |  |  | — |  |  | — |  |  | — |  |
| Spin-off of Adient | — |  |  | — |  |  | — |  |  | (4,038 | ) |  | (138 | ) |  | (4,176 | ) |
| Other, including options exercised | 42 |  |  | — |  |  | 42 |  |  | 132 |  |  | — |  |  | 132 |  |
| Ending balance, March 31 | $ | 20,874 |  |  | $ | 1,006 |  |  | $ | 21,880 |  |  | $ | 19,388 |  |  | $ | 813 |  |  | $ | 20,201 |  |


## jci:OffsettingDerivativeAssetsandLiabilitiesTableTextBlock

[0000833444-18-000021:notes:8]
[same as prior period, unchanged from 0000833444-18-000008:notes:7]

[0000833444-18-000021:notes:9]
|  |  | Fair Value of Assets |  | Fair Value of Liabilities |
|  |  | March 31, |  | September 30, |  | March 31, |  | September 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Gross amount recognized |  | $ | 92 |  |  | $ | 91 |  |  | $ | 3,120 |  |  | $ | 2,105 |  |
| Gross amount eligible for offsetting |  | (20 | ) |  | (16 | ) |  | (20 | ) |  | (16 | ) |
| Net amount |  | $ | 72 |  |  | $ | 75 |  |  | $ | 3,100 |  |  | $ | 2,089 |  |


## jci:ScheduleOfIntangibleAssetsTableTextBlock

[0000833444-18-000021:notes:10]
[same as prior period, unchanged from 0000833444-18-000008:notes:9]

[0000833444-18-000021:notes:11]
|  | March 31, 2018 |  | September 30, 2017 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Amortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,344 |  |  | $ | (205 | ) |  | $ | 1,139 |  |  | $ | 1,328 |  |  | $ | (137 | ) |  | $ | 1,191 |  |
| Customer relationships | 3,163 |  |  | (561 | ) |  | 2,602 |  |  | 3,168 |  |  | (486 | ) |  | 2,682 |  |
| Miscellaneous | 443 |  |  | (176 | ) |  | 267 |  |  | 389 |  |  | (147 | ) |  | 242 |  |
| Total amortized intangible assets | 4,950 |  |  | (942 | ) |  | 4,008 |  |  | 4,885 |  |  | (770 | ) |  | 4,115 |  |
| Unamortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,494 |  |  | — |  |  | 2,494 |  |  | 2,483 |  |  | — |  |  | 2,483 |  |
| Miscellaneous | 123 |  |  | — |  |  | 123 |  |  | 143 |  |  | — |  |  | 143 |  |
|  | 2,617 |  |  | — |  |  | 2,617 |  |  | 2,626 |  |  | — |  |  | 2,626 |  |
| Total intangible assets | $ | 7,567 |  |  | $ | (942 | ) |  | $ | 6,625 |  |  | $ | 7,511 |  |  | $ | (770 | ) |  | $ | 6,741 |  |


## jci:ScheduleofsharebasedpaymentawardperformancesharevaluationassumptionsTableTextBlock

[0000833444-18-000021:notes:12]
|  | Six Months Ended March 31, |
|  | 2018 |  | 2017 |
| Risk-free interest rate | 1.92% |  | 1.40% |
| Expected volatility of the Company’s stock | 21.7% |  | 21.0% |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-18-000021:notes:13]
Commitments and Contingencies

[0000833444-18-000021:notes:14]
Environmental Matters

[0000833444-18-000021:notes:15]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of March 31, 2018, reserves for environmental liabilities totaled $47 million, of which $12 million was recorded within other current liabilities and $35 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at September 30, 2017. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At March 31, 2018 and September 30, 2017, the Company recorded conditional asset retirement obligations of $65 million and $61 million, respectively.

[0000833444-18-000021:notes:16]
Asbestos Matters

[0000833444-18-000021:notes:17]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-18-000021:notes:18]
As of March 31, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $174 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $555 million, of which $54 million was recorded in other current liabilities and $501 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $381 million, of which $57 million was recorded in other current assets, and $324 million was recorded in other noncurrent assets. Assets included $12 million of cash and $274 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at March 31, 2018 was $95 million. As of September 30, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $181 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $573 million, of which $48 million was recorded in other current liabilities and $525 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $392 million, of which $53 million was recorded in other current assets, and $339 million was recorded in other noncurrent assets. Assets included $22 million of cash and $269 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2017 was $101 million.

[0000833444-18-000021:notes:19]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-18-000021:notes:20]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-18-000021:notes:21]
Insurable Liabilities

[0000833444-18-000021:notes:22]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At March 31, 2018 and September 30, 2017, the insurable liabilities totaled $439 million and $445 million, respectively, of which $81 million and $122 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $336 million and $301 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at March 31, 2018 was $21 million, of which $6 million was recorded within other current assets and $15 million was recorded within other noncurrent assets.  The amount of such receivables recorded at September 30, 2017 was $46 million, of which $31 million was recorded within other current assets and $15 million was recorded within other noncurrent assets. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

[0000833444-18-000021:notes:23]
Arbitration Award

[0000833444-18-000021:notes:24]
In September 2017, the Company was subject to an unfavorable arbitration award of approximately $50 million relating to a contractual dispute with a subcontractor used by the Company at an airport construction project in Doha, Qatar. In connection with the unfavorable arbitration award, the Company recorded a charge of $50 million within selling, general and administrative expenses in the consolidated statements of income in the fourth quarter of fiscal 2017. The airport project is being managed by a steering committee. The Company and the subcontractor were working jointly to document claims for increased costs against the steering committee when the subcontractor initiated the arbitration proceeding against the Company. Pursuant to its arbitration proceeding against the Company, the subcontractor sought to recover costs it alleges it incurred due to project delays, additional work and related financing costs. The Company has filed annulment proceedings with respect to the arbitration award in the local court in Qatar. While the award remains outstanding, a portion of the balance will accrue interest at a statutory rate of 9.56%.

[0000833444-18-000021:notes:25]
In a related action, the Company has initiated an arbitration claim against the steering committee related to costs it incurred in connection with delays of the airport construction project, including costs related to the above award. The arbitrator is expected to issue a decision on the Company’s claims against the steering committee by the end of fiscal 2018.

[0000833444-18-000021:notes:26]
Aqueous Film-Forming Foam Litigation

[0000833444-18-000021:notes:27]
Two of our subsidiaries, Chemguard, Inc. ("Chemguard") and Tyco Fire Products L.P. ("Tyco Fire Products"), have been named, along with other defendant manufacturers, in a number of class action lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and that the use of these products by others at various airbases and airports resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports and airbases. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination. As of May 3, 2018, the Company is named in 15 putative class actions in federal courts in five states as set forth below:

[0000833444-18-000021:notes:28]
Colorado

[0000833444-18-000021:notes:29]
| • | District of Colorado - Bell et al. v. The 3M Company et al., filed on September 18, 2016. |

[0000833444-18-000021:notes:30]
| • | District of Colorado - Davis et al. v. The 3M Company et al., filed on September 22, 2016. |

[0000833444-18-000021:notes:31]
The above cases have been consolidated in the U.S. District Court for the District of Colorado, and a hearing on the plaintiffs’ motion for class certification is likely to be scheduled for July 2018 with a trial date schedule for April 2019. In addition to the putative class actions above, Chemguard and Tyco Fire Products are defendants in Adams, et al. v. The 3M Company et.al., filed on March 26, 2018, in the United States District Court for the District of Colorado. A group of approximately 90 plaintiffs allege that releases of PFOS and PFOA have contaminated the surrounding communities’ water supplies near the Peterson Air Force Base and the Colorado Municipal Springs Airport. The plaintiffs assert defective design, failure to warn, negligence, private nuisance and trespass and seek recovery for alleged diminished property values, personal injury, medical monitoring and punitive damages.

[0000833444-18-000021:notes:32]
Massachusetts

[0000833444-18-000021:notes:33]
| • | District of Massachusetts - Civitarese et al. v. The 3m Company et al., filed on April 18, 2018 in the United States District Court of Massachusetts. |

[0000833444-18-000021:notes:34]
Washington

[0000833444-18-000021:notes:35]
| • | Eastern District of Washington - Ackerman et al. v. The 3M Company et al. filed on April 5, 2018 in the United States District Court, Eastern District of Washington. |

[0000833444-18-000021:notes:36]
New York

[0000833444-18-000021:notes:37]
| • | Eastern District of New York - Green et al. v. The 3M Company et al., filed March 27, 2017 in Supreme Court of the State of New York, Suffolk County, prior to removal to federal court. |

[0000833444-18-000021:notes:38]
| • | Southern District of New York - Adamo et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

[0000833444-18-000021:notes:39]
| • | Southern District of New York - Fogarty et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

[0000833444-18-000021:notes:40]
| • | Southern District of New York - Miller et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

[0000833444-18-000021:notes:41]
| • | Supreme Court of the State of New York, Suffolk County - Singer et al. v. The 3M Company et al., filed October 10, 2017. |

[0000833444-18-000021:notes:42]
| • | Supreme Court of the State of New York, Suffolk County - Shipman et al. v. The 3M Company et al., filed March 21, 2018. |

[0000833444-18-000021:notes:43]
Chemguard and Tyco Fire Products are also defendants in Ayo, et al. v. The 3M Company, et al., filed on December 11, 2017 in the Suffolk County Supreme Court of New York. Approximately 32 plaintiffs allege that releases of PFOS and PFOA have contaminated surrounding communities’ water supplies near the Gabreski Air National Guard Base located on Long Island, New York.  The plaintiffs assert defective design, failure to warn, negligence, private nuisance, and trespass and seek recovery for alleged diminished property values, personal injury, medical monitoring and punitive damages.

[0000833444-18-000021:notes:44]
Responses to the complaints have not been filed yet in any of the New York actions.

[0000833444-18-000021:notes:45]
Pennsylvania

[0000833444-18-000021:notes:46]
| • | Eastern District of Pennsylvania - Bates et al. v. The 3M Company et al., filed September 15, 2016. |

[0000833444-18-000021:notes:47]
| • | Eastern District of Pennsylvania - Grande et al. v. The 3M Company et al., filed October 13, 2016. |

[0000833444-18-000021:notes:48]
| • | Eastern District of Pennsylvania - Yockey et al. v. The 3M Company et al., filed October 24, 2016. |

[0000833444-18-000021:notes:49]
| • | Eastern District of Pennsylvania - Fearnley et al. v. The 3M Company et al., filed December 9, 2016. |

[0000833444-18-000021:notes:50]
The above cases have been consolidated in the U.S. District Court for the Eastern District of Pennsylvania. The defendants' motion to dismiss the complaint in the consolidated proceeding was denied without prejudice and the cases are currently stayed pending the appeal of an action in which the Company is not a party.

[0000833444-18-000021:notes:51]
In addition to the putative class actions, Chemguard and Tyco Fire Products are also defendants in an action filed by two plaintiffs in the U.S. District Court for the Eastern District of Pennsylvania:  Menkes et al. v. The 3M Company et al., (filed February 7, 2017). The Menkes plaintiffs assert substantive claims and allegations similar to the putative class allegations, but also include personal injury claim. Further, the Company was recently served with an individual action in Pennsylvania state court, Court of Common Pleas Philadelphia: Gentles v. 3M Company et. al. (filed April 26, 2018). The Company is also on notice of approximately 540 other possible individual product liability claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, and, under Pennsylvania’s procedural rules, they may or may not result in lawsuits.

[0000833444-18-000021:notes:52]
Chemguard and Tyco Fire Products are also defendants in three cases pending in the U.S. District Court for the District of Massachusetts: Town of Barnstable v. the 3M. Co., et al, (filed Nov. 21, 2016), County of Barnstable v. the 3M. Co., et al, (filed January 9, 2017) and City of Westfield v. the 3M Co., et al., (filed on February 24, 2018). These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at a fire training academy and municipal airport released PFOS and PFOA into the town’s water supply wells, allegedly requiring remediation of the town and county property. The defendants have filed a motion to dismiss in County of Barnstable, which was granted without prejudice and the plaintiffs have subsequently filed an amended complaint.

[0000833444-18-000021:notes:53]
The Company is vigorously defending these cases and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

[0000833444-18-000021:notes:54]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-18-000021:notes:55]
[same as prior period, unchanged from 0000833444-18-000008:notes:49]

[0000833444-18-000021:notes:56]
[same as prior period, unchanged from 0000833444-18-000008:notes:50]

[0000833444-18-000021:notes:57]
CONDENSED CONSOLIDATING STATEMENT OF INCOME

[0000833444-18-000021:notes:58]
For the Three Months Ended March 31, 2018

[0000833444-18-000021:notes:59]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 7,475 |  |  | $ | — |  |  | $ | 7,475 |  |
| Cost of sales | — |  |  | — |  |  | — |  |  | 5,255 |  |  | — |  |  | 5,255 |  |
| Gross profit | — |  |  | — |  |  | — |  |  | 2,220 |  |  | — |  |  | 2,220 |  |
| Selling, general and administrative expenses | (7 | ) |  | — |  |  | 11 |  |  | (1,592 | ) |  | — |  |  | (1,588 | ) |
| Net financing charges | (86 | ) |  | 23 |  |  | (3 | ) |  | (49 | ) |  | — |  |  | (115 | ) |
| Equity income (loss) | 582 |  |  | 439 |  |  | (9 | ) |  | 44 |  |  | (1,012 | ) |  | 44 |  |
| Intercompany interest and fees | (51 | ) |  | 70 |  |  | (17 | ) |  | (2 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes | 438 |  |  | 532 |  |  | (18 | ) |  | 621 |  |  | (1,012 | ) |  | 561 |  |
| Income tax provision | — |  |  | — |  |  | — |  |  | 78 |  |  | — |  |  | 78 |  |
| Income (loss) from continuing operations | 438 |  |  | 532 |  |  | (18 | ) |  | 543 |  |  | (1,012 | ) |  | 483 |  |
| Loss from sale of intercompany investment, net of tax | — |  |  | — |  |  | — |  |  | (953 | ) |  | 953 |  |  | — |  |
| Net income (loss) | 438 |  |  | 532 |  |  | (18 | ) |  | (410 | ) |  | (59 | ) |  | 483 |  |
| Income from continuing operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 45 |  |  | — |  |  | 45 |  |
| Net income (loss) attributable to Johnson Controls | $ | 438 |  |  | $ | 532 |  |  | $ | (18 | ) |  | $ | (455 | ) |  | $ | (59 | ) |  | $ | 438 |  |

[0000833444-18-000021:notes:60]
[same as prior period, unchanged from 0000833444-18-000008:notes:54]

[0000833444-18-000021:notes:61]
| (in millions) | Johnson ControlsInternationalplc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net income (loss) | $ | 438 |  |  | $ | 532 |  |  | $ | (18 | ) |  | $ | (410 | ) |  | $ | (59 | ) |  | $ | 483 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments | 168 |  |  | (16 | ) |  | (2 | ) |  | 388 |  |  | (334 | ) |  | 204 |  |
| Realized and unrealized losses on derivatives | (6 | ) |  | — |  |  | — |  |  | (10 | ) |  | 6 |  |  | (10 | ) |
| Realized and unrealized losses on marketable securities | (2 | ) |  | — |  |  | — |  |  | (2 | ) |  | 2 |  |  | (2 | ) |
| Other comprehensive income (loss) | 160 |  |  | (16 | ) |  | (2 | ) |  | 376 |  |  | (326 | ) |  | 192 |  |
| Total comprehensive income (loss) | 598 |  |  | 516 |  |  | (20 | ) |  | (34 | ) |  | (385 | ) |  | 675 |  |
| Comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 77 |  |  | — |  |  | 77 |  |
| Comprehensive income (loss) attributable to Johnson Controls | $ | 598 |  |  | $ | 516 |  |  | $ | (20 | ) |  | $ | (111 | ) |  | $ | (385 | ) |  | $ | 598 |  |

[0000833444-18-000021:notes:62]
For the Six Months Ended March 31, 2018

[0000833444-18-000021:notes:63]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 14,910 |  |  | $ | — |  |  | $ | 14,910 |  |
| Cost of sales | — |  |  | — |  |  | — |  |  | 10,521 |  |  | — |  |  | 10,521 |  |
| Gross profit | — |  |  | — |  |  | — |  |  | 4,389 |  |  | — |  |  | 4,389 |  |
| Selling, general and administrative expenses | (10 | ) |  | — |  |  | 11 |  |  | (3,006 | ) |  | — |  |  | (3,005 | ) |
| Restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (158 | ) |  | — |  |  | (158 | ) |
| Net financing charges | (136 | ) |  | 24 |  |  | (5 | ) |  | (114 | ) |  | — |  |  | (231 | ) |
| Equity income | 867 |  |  | 627 |  |  | 133 |  |  | 104 |  |  | (1,627 | ) |  | 104 |  |
| Intercompany interest and fees | (53 | ) |  | 155 |  |  | (46 | ) |  | (56 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 668 |  |  | 806 |  |  | 93 |  |  | 1,159 |  |  | (1,627 | ) |  | 1,099 |  |
| Income tax provision | — |  |  | — |  |  | — |  |  | 345 |  |  | — |  |  | 345 |  |
| Income from continuing operations | 668 |  |  | 806 |  |  | 93 |  |  | 814 |  |  | (1,627 | ) |  | 754 |  |
| Loss from sale of intercompany investment, net of tax | — |  |  | — |  |  | — |  |  | (953 | ) |  | 953 |  |  | — |  |
| Net income (loss) | 668 |  |  | 806 |  |  | 93 |  |  | (139 | ) |  | (674 | ) |  | 754 |  |
| Income from continuing operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 86 |  |  | — |  |  | 86 |  |
| Net income (loss) attributable to Johnson Controls | $ | 668 |  |  | $ | 806 |  |  | $ | 93 |  |  | $ | (225 | ) |  | $ | (674 | ) |  | $ | 668 |  |

[0000833444-18-000021:notes:64]
| (in millions) | Johnson ControlsInternationalplc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net income (loss) | $ | 668 |  |  | $ | 806 |  |  | $ | 93 |  |  | $ | (139 | ) |  | $ | (674 | ) |  | $ | 754 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments | 226 |  |  | (23 | ) |  | (3 | ) |  | 441 |  |  | (358 | ) |  | 283 |  |
| Realized and unrealized losses on derivatives | (5 | ) |  | — |  |  | — |  |  | (11 | ) |  | 5 |  |  | (11 | ) |
| Realized and unrealized gains (losses) on marketable securities | (2 | ) |  | — |  |  | (4 | ) |  | 2 |  |  | 2 |  |  | (2 | ) |
| Other comprehensive income (loss) | 219 |  |  | (23 | ) |  | (7 | ) |  | 432 |  |  | (351 | ) |  | 270 |  |
| Total comprehensive income | 887 |  |  | 783 |  |  | 86 |  |  | 293 |  |  | (1,025 | ) |  | 1,024 |  |
| Comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 137 |  |  | — |  |  | 137 |  |
| Comprehensive income attributable to Johnson Controls | $ | 887 |  |  | $ | 783 |  |  | $ | 86 |  |  | $ | 156 |  |  | $ | (1,025 | ) |  | $ | 887 |  |

[0000833444-18-000021:notes:65]
For the Three Months Ended March 31, 2017

[0000833444-18-000021:notes:66]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 7,267 |  |  | $ | — |  |  | $ | 7,267 |  |
| Cost of sales | — |  |  | — |  |  | — |  |  | 4,986 |  |  | — |  |  | 4,986 |  |
| Gross profit | — |  |  | — |  |  | — |  |  | 2,281 |  |  | — |  |  | 2,281 |  |
| Selling, general and administrative expenses | (4 | ) |  | — |  |  | (1 | ) |  | (1,721 | ) |  | — |  |  | (1,726 | ) |
| Restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (99 | ) |  | — |  |  | (99 | ) |
| Net financing charges | (59 | ) |  | — |  |  | 5 |  |  | (62 | ) |  | — |  |  | (116 | ) |
| Equity income (loss) | (103 | ) |  | (187 | ) |  | (382 | ) |  | 53 |  |  | 672 |  |  | 53 |  |
| Intercompany interest and fees | 18 |  |  | 73 |  |  | 20 |  |  | (111 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes | (148 | ) |  | (114 | ) |  | (358 | ) |  | 341 |  |  | 672 |  |  | 393 |  |
| Income tax provision | — |  |  | — |  |  | — |  |  | 508 |  |  | — |  |  | 508 |  |
| Net loss | (148 | ) |  | (114 | ) |  | (358 | ) |  | (167 | ) |  | 672 |  |  | (115 | ) |
| Income from continuing operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 33 |  |  | — |  |  | 33 |  |
| Net loss attributable to Johnson Controls | $ | (148 | ) |  | $ | (114 | ) |  | $ | (358 | ) |  | $ | (200 | ) |  | $ | 672 |  |  | $ | (148 | ) |

[0000833444-18-000021:notes:67]
| (in millions) | Johnson ControlsInternationalplc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net loss | $ | (148 | ) |  | $ | (114 | ) |  | $ | (358 | ) |  | $ | (167 | ) |  | $ | 672 |  |  | $ | (115 | ) |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments | 241 |  |  | (7 | ) |  | (1 | ) |  | 260 |  |  | (241 | ) |  | 252 |  |
| Realized and unrealized losses on derivatives | (6 | ) |  | — |  |  | — |  |  | (8 | ) |  | 6 |  |  | (8 | ) |
| Realized and unrealized gains on marketable securities | 11 |  |  | — |  |  | 7 |  |  | 4 |  |  | (11 | ) |  | 11 |  |
| Other comprehensive income (loss) | 246 |  |  | (7 | ) |  | 6 |  |  | 256 |  |  | (246 | ) |  | 255 |  |
| Total comprehensive income (loss) | 98 |  |  | (121 | ) |  | (352 | ) |  | 89 |  |  | 426 |  |  | 140 |  |
| Comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 42 |  |  | — |  |  | 42 |  |
| Comprehensive income (loss) attributable to Johnson Controls | $ | 98 |  |  | $ | (121 | ) |  | $ | (352 | ) |  | $ | 47 |  |  | $ | 426 |  |  | $ | 98 |  |

[0000833444-18-000021:notes:68]
For the Six Months Ended March 31, 2017

[0000833444-18-000021:notes:69]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 14,353 |  |  | $ | — |  |  | $ | 14,353 |  |
| Cost of sales | — |  |  | — |  |  | — |  |  | 9,958 |  |  | — |  |  | 9,958 |  |
| Gross profit | — |  |  | — |  |  | — |  |  | 4,395 |  |  | — |  |  | 4,395 |  |
| Selling, general and administrative expenses | (6 | ) |  | — |  |  | — |  |  | (3,290 | ) |  | — |  |  | (3,296 | ) |
| Restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (177 | ) |  | — |  |  | (177 | ) |
| Net financing charges | (78 | ) |  | — |  |  | (14 | ) |  | (160 | ) |  | — |  |  | (252 | ) |
| Equity income (loss) | 215 |  |  | (473 | ) |  | (492 | ) |  | 108 |  |  | 750 |  |  | 108 |  |
| Intercompany interest and fees | 50 |  |  | 73 |  |  | 37 |  |  | (160 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes | 181 |  |  | (400 | ) |  | (469 | ) |  | 716 |  |  | 750 |  |  | 778 |  |
| Income tax provision | — |  |  | — |  |  | — |  |  | 481 |  |  | — |  |  | 481 |  |
| Income (loss) from continuing operations | 181 |  |  | (400 | ) |  | (469 | ) |  | 235 |  |  | 750 |  |  | 297 |  |
| Loss from sale of intercompany investment, net of tax | — |  |  | — |  |  | (935 | ) |  | — |  |  | 935 |  |  | — |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | — |  |  | (34 | ) |  | — |  |  | (34 | ) |
| Net income (loss) | 181 |  |  | (400 | ) |  | (1,404 | ) |  | 201 |  |  | 1,685 |  |  | 263 |  |
| Income from continuing operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 73 |  |  | — |  |  | 73 |  |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Net income (loss) attributable to Johnson Controls | $ | 181 |  |  | $ | (400 | ) |  | $ | (1,404 | ) |  | $ | 119 |  |  | $ | 1,685 |  |  | $ | 181 |  |

[0000833444-18-000021:notes:70]
| (in millions) | Johnson ControlsInternationalplc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net income (loss) | $ | 181 |  |  | $ | (400 | ) |  | $ | (1,404 | ) |  | $ | 201 |  |  | $ | 1,685 |  |  | $ | 263 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments | (418 | ) |  | (7 | ) |  | 26 |  |  | (470 | ) |  | 418 |  |  | (451 | ) |
| Realized and unrealized losses on derivatives | (6 | ) |  | — |  |  | — |  |  | (4 | ) |  | 6 |  |  | (4 | ) |
| Realized and unrealized gains on marketable securities | 9 |  |  | — |  |  | 7 |  |  | 2 |  |  | (9 | ) |  | 9 |  |
| Other comprehensive income (loss) | (415 | ) |  | (7 | ) |  | 33 |  |  | (472 | ) |  | 415 |  |  | (446 | ) |
| Total comprehensive loss | (234 | ) |  | (407 | ) |  | (1,371 | ) |  | (271 | ) |  | 2,100 |  |  | (183 | ) |
| Comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 51 |  |  | — |  |  | 51 |  |
| Comprehensive loss attributable to Johnson Controls | $ | (234 | ) |  | $ | (407 | ) |  | $ | (1,371 | ) |  | $ | (322 | ) |  | $ | 2,100 |  |  | $ | (234 | ) |

[0000833444-18-000021:notes:71]
[same as prior period, unchanged from 0000833444-18-000008:notes:59]

[0000833444-18-000021:notes:72]
As of March 31, 2018

[0000833444-18-000021:notes:73]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | 304 |  |  | $ | 161 |  |  | $ | 1,293 |  |  | $ | (1,490 | ) |  | $ | 268 |  |
| Accounts receivable - net | — |  |  | — |  |  | — |  |  | 6,679 |  |  | — |  |  | 6,679 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 3,565 |  |  | — |  |  | 3,565 |  |
| Intercompany receivables | 48 |  |  | 2,206 |  |  | 365 |  |  | 23,090 |  |  | (25,709 | ) |  | — |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 22 |  |  | — |  |  | 22 |  |
| Other current assets | 11 |  |  | 2 |  |  | 2 |  |  | 1,722 |  |  | — |  |  | 1,737 |  |
| Current assets | 59 |  |  | 2,512 |  |  | 528 |  |  | 36,371 |  |  | (27,199 | ) |  | 12,271 |  |
| Property, plant and equipment - net | — |  |  | — |  |  | — |  |  | 6,235 |  |  | — |  |  | 6,235 |  |
| Goodwill | 243 |  |  | — |  |  | 32 |  |  | 19,531 |  |  | — |  |  | 19,806 |  |
| Other intangible assets - net | — |  |  | — |  |  | — |  |  | 6,625 |  |  | — |  |  | 6,625 |  |
| Investments in partially-owned affiliates | — |  |  | — |  |  | — |  |  | 1,294 |  |  | — |  |  | 1,294 |  |
| Investments in affiliates | 39,838 |  |  | 33,681 |  |  | 21,456 |  |  | — |  |  | (94,975 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | 4,140 |  |  | 2,836 |  |  | 9,004 |  |  | (15,980 | ) |  | — |  |
| Other noncurrent assets | 63 |  |  | — |  |  | 3 |  |  | 3,655 |  |  | — |  |  | 3,721 |  |
| Total assets | $ | 40,203 |  |  | $ | 40,333 |  |  | $ | 24,855 |  |  | $ | 82,715 |  |  | $ | (138,154 | ) |  | $ | 49,952 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | 2,163 |  |  | $ | 9 |  |  | $ | — |  |  | $ | 429 |  |  | $ | (1,490 | ) |  | $ | 1,111 |  |
| Current portion of long-term debt | — |  |  | — |  |  | — |  |  | 25 |  |  | — |  |  | 25 |  |
| Accounts payable | 1 |  |  | — |  |  | — |  |  | 4,249 |  |  | — |  |  | 4,250 |  |
| Accrued compensation and benefits | 1 |  |  | — |  |  | — |  |  | 865 |  |  | — |  |  | 866 |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 1,543 |  |  | — |  |  | 1,543 |  |
| Intercompany payables | 3,361 |  |  | 19,459 |  |  | 2,031 |  |  | 858 |  |  | (25,709 | ) |  | — |  |
| Other current liabilities | 303 |  |  | 13 |  |  | 27 |  |  | 2,854 |  |  | — |  |  | 3,197 |  |
| Current liabilities | 5,829 |  |  | 19,481 |  |  | 2,058 |  |  | 10,823 |  |  | (27,199 | ) |  | 10,992 |  |
| Long-term debt | 8,812 |  |  | — |  |  | 155 |  |  | 1,995 |  |  | — |  |  | 10,962 |  |
| Pension and postretirement benefits | — |  |  | — |  |  | — |  |  | 864 |  |  | — |  |  | 864 |  |
| Intercompany loans payable | 4,688 |  |  | — |  |  | 4,316 |  |  | 6,976 |  |  | (15,980 | ) |  | — |  |
| Other noncurrent liabilities | — |  |  | — |  |  | 24 |  |  | 4,995 |  |  | — |  |  | 5,019 |  |
| Long-term liabilities | 13,500 |  |  | — |  |  | 4,495 |  |  | 14,830 |  |  | (15,980 | ) |  | 16,845 |  |
| Redeemable noncontrolling interests | — |  |  | — |  |  | — |  |  | 235 |  |  | — |  |  | 235 |  |
| Ordinary shares | 9 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Ordinary shares held in treasury | (946 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (946 | ) |
| Other shareholders' equity | 21,811 |  |  | 20,852 |  |  | 18,302 |  |  | 55,821 |  |  | (94,975 | ) |  | 21,811 |  |
| Shareholders’ equity attributable to Johnson Controls | 20,874 |  |  | 20,852 |  |  | 18,302 |  |  | 55,821 |  |  | (94,975 | ) |  | 20,874 |  |
| Noncontrolling interests | — |  |  | — |  |  | — |  |  | 1,006 |  |  | — |  |  | 1,006 |  |
| Total equity | 20,874 |  |  | 20,852 |  |  | 18,302 |  |  | 56,827 |  |  | (94,975 | ) |  | 21,880 |  |
| Total liabilities and equity | $ | 40,203 |  |  | $ | 40,333 |  |  | $ | 24,855 |  |  | $ | 82,715 |  |  | $ | (138,154 | ) |  | $ | 49,952 |  |

[0000833444-18-000021:notes:74]
[same as prior period, unchanged from 0000833444-18-000008:notes:62]

[0000833444-18-000021:notes:75]
[same as prior period, unchanged from 0000833444-18-000008:notes:63]

[0000833444-18-000021:notes:76]
[same as prior period, unchanged from 0000833444-18-000008:notes:64]

[0000833444-18-000021:notes:77]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Operating Activities |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided (used) by operating activities | $ | (342 | ) |  | $ | 188 |  |  | $ | 82 |  |  | $ | 605 |  |  | $ | — |  |  | $ | 533 |  |
| Investing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (497 | ) |  | — |  |  | (497 | ) |
| Sale of property, plant and equipment | — |  |  | — |  |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | — |  |  | (15 | ) |  | — |  |  | (15 | ) |
| Business divestitures | — |  |  | — |  |  | — |  |  | 2,114 |  |  | — |  |  | 2,114 |  |
| Changes in long-term investments | — |  |  | — |  |  | — |  |  | (14 | ) |  | — |  |  | (14 | ) |
| Net change in intercompany loans receivable | 300 |  |  | — |  |  | (285 | ) |  | 583 |  |  | (598 | ) |  | — |  |
| Net cash provided (used) by investing activities | 300 |  |  | — |  |  | (285 | ) |  | 2,181 |  |  | (598 | ) |  | 1,598 |  |
| Financing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Increase (decrease) in short-term debt - net | 687 |  |  | 9 |  |  | — |  |  | (192 | ) |  | (604 | ) |  | (100 | ) |
| Increase in long-term debt | 885 |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 886 |  |
| Repayment of long-term debt | (307 | ) |  | — |  |  | (18 | ) |  | (2,003 | ) |  | — |  |  | (2,328 | ) |
| Debt financing costs | (4 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (4 | ) |
| Stock repurchases | (199 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (199 | ) |
| Payment of cash dividends | (473 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (473 | ) |
| Proceeds from the exercise of stock options | 36 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 36 |  |
| Employee equity-based compensation withholding taxes | — |  |  | — |  |  | — |  |  | (37 | ) |  | — |  |  | (37 | ) |
| Net change in intercompany loans payable | (583 | ) |  | — |  |  | — |  |  | (15 | ) |  | 598 |  |  | — |  |
| Dividends paid to noncontrolling interests | — |  |  | — |  |  | — |  |  | (46 | ) |  | — |  |  | (46 | ) |
| Other | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Net cash provided (used) by financing activities | 42 |  |  | 9 |  |  | (18 | ) |  | (2,281 | ) |  | (6 | ) |  | (2,254 | ) |
| Effect of exchange rate changes on cash and cash equivalents | — |  |  | — |  |  | — |  |  | 61 |  |  | — |  |  | 61 |  |
| Change in cash held for sale | — |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Increase (decrease) in cash and cash equivalents | — |  |  | 197 |  |  | (221 | ) |  | 575 |  |  | (604 | ) |  | (53 | ) |
| Cash and cash equivalents at beginning of period | — |  |  | 107 |  |  | 382 |  |  | 718 |  |  | (886 | ) |  | 321 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | 304 |  |  | $ | 161 |  |  | $ | 1,293 |  |  | $ | (1,490 | ) |  | $ | 268 |  |

[0000833444-18-000021:notes:78]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Operating Activities |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided (used) by operating activities | $ | 62 |  |  | $ | — |  |  | $ | 67 |  |  | $ | (1,648 | ) |  | $ | — |  |  | $ | (1,519 | ) |
| Investing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (634 | ) |  | — |  |  | (634 | ) |
| Sale of property, plant and equipment | — |  |  | — |  |  | — |  |  | 18 |  |  | — |  |  | 18 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (6 | ) |  | — |  |  | — |  |  | (6 | ) |
| Business divestitures | — |  |  | — |  |  | — |  |  | 180 |  |  | — |  |  | 180 |  |
| Changes in long-term investments | — |  |  | — |  |  | (11 | ) |  | (19 | ) |  | — |  |  | (30 | ) |
| Net change in intercompany loans receivable | — |  |  | — |  |  | 10 |  |  | 165 |  |  | (175 | ) |  | — |  |
| Increase in intercompany investment in subsidiaries | (1,924 | ) |  | (1,716 | ) |  | (76 | ) |  | — |  |  | 3,716 |  |  | — |  |
| Net cash used by investing activities | (1,924 | ) |  | (1,716 | ) |  | (83 | ) |  | (290 | ) |  | 3,541 |  |  | (472 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Increase (decrease) in short-term debt - net | 885 |  |  | 76 |  |  | — |  |  | (545 | ) |  | (361 | ) |  | 55 |  |
| Increase in long-term debt | 1,544 |  |  | — |  |  | — |  |  | 8 |  |  | — |  |  | 1,552 |  |
| Repayment of long-term debt | (46 | ) |  | — |  |  | (16 | ) |  | (769 | ) |  | — |  |  | (831 | ) |
| Debt financing costs | (17 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (17 | ) |
| Stock repurchases | (119 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (119 | ) |
| Payment of cash dividends | (235 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (235 | ) |
| Proceeds from the exercise of stock options | 88 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 88 |  |
| Employee equity-based compensation withholding taxes | — |  |  | — |  |  | — |  |  | (33 | ) |  | — |  |  | (33 | ) |
| Net change in intercompany loans payable | (165 | ) |  | — |  |  | — |  |  | (10 | ) |  | 175 |  |  | — |  |
| Increase in equity from parent | — |  |  | 1,640 |  |  | 76 |  |  | 2,000 |  |  | (3,716 | ) |  | — |  |
| Dividends paid to noncontrolling interests | — |  |  | — |  |  | — |  |  | (78 | ) |  | — |  |  | (78 | ) |
| Dividend from Adient spin-off | — |  |  | — |  |  | — |  |  | 2,050 |  |  | — |  |  | 2,050 |  |
| Cash transferred to Adient related to spin-off | (87 | ) |  | — |  |  | — |  |  | (578 | ) |  | — |  |  | (665 | ) |
| Cash paid related to prior acquisitions | — |  |  | — |  |  | — |  |  | (37 | ) |  | — |  |  | (37 | ) |
| Other | 6 |  |  | — |  |  | — |  |  | 8 |  |  | — |  |  | 14 |  |
| Net cash provided by financing activities | 1,854 |  |  | 1,716 |  |  | 60 |  |  | 2,016 |  |  | (3,902 | ) |  | 1,744 |  |
| Effect of exchange rate changes on cash and cash equivalents | — |  |  | — |  |  | — |  |  | (25 | ) |  | — |  |  | (25 | ) |
| Change in cash held for sale | — |  |  | — |  |  | — |  |  | 105 |  |  | — |  |  | 105 |  |
| Increase (decrease) in cash and cash equivalents | (8 | ) |  | — |  |  | 44 |  |  | 158 |  |  | (361 | ) |  | (167 | ) |
| Cash and cash equivalents at beginning of period | 11 |  |  | — |  |  | 244 |  |  | 324 |  |  | — |  |  | 579 |  |
| Cash and cash equivalents at end of period | $ | 3 |  |  | $ | — |  |  | $ | 288 |  |  | $ | 482 |  |  | $ | (361 | ) |  | $ | 412 |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-18-000021:notes:79]
Debt and Financing Arrangements

[0000833444-18-000021:notes:80]
In October 2017, the Company completed the previously announced sale of its Scott Safety business to 3M. Net cash proceeds from the transaction of approximately $1.9 billion were used to repay a significant portion of the TSarl $4.0 billion of merger-related debt. In addition, in March 2018, the Company repaid $26 million in principal amount, plus accrued interest, of the TSarl merger-related debt. As of March 31, 2018, the outstanding balance of the TSarl term loan was approximately $1.7 billion.

[0000833444-18-000021:notes:81]
In March 2018, the Company increased the committed credit limit from $1.0 billion to $1.25 billion on TSarl's committed revolving credit facility scheduled to expire in August 2020. As of March 31, 2018, there were no draws on the facility.

[0000833444-18-000021:notes:82]
In March 2018, the Company entered into a 364-day $250 million committed revolving credit facility scheduled to expire in March 2019. As of March 31, 2018, there were no draws on the facility.

[0000833444-18-000021:notes:83]
In March 2018, a 364-day $150 million committed revolving credit facility expired. The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2019. As of March 31, 2018, there were no draws on the facility.

[0000833444-18-000021:notes:84]
In February 2018, a 364-day $150 million committed revolving credit facility expired. The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2019. As of March 31, 2018, there were no draws on the facility.

[0000833444-18-000021:notes:85]
In January 2018, a 364-day $250 million committed revolving credit facility expired. The Company entered into a new $200 million committed revolving credit facility scheduled to expire in January 2019. As of March 31, 2018, there were no draws on the facility.

[0000833444-18-000021:notes:86]
In January 2018, the Company retired $67 million in principal amount, plus accrued interest, of its 3.75% fixed rate notes  that expired in January 2018.

[0000833444-18-000021:notes:87]
In December 2017, the Company repaid a 364-day 150 million euro floating rate term loan, plus accrued interest, scheduled  to mature in September 2018.

[0000833444-18-000021:notes:88]
In November 2017, the Company issued 750 million euro in principal amount of 0.0% senior unsecured fixed rate notes due in December 2020. Proceeds from the issuance were used to repay existing debt and for other general corporate purposes.

[0000833444-18-000021:notes:89]
In November 2017, the Company retired $300 million in principal amount, plus accrued interest, of its 1.4% fixed rate notes that expired in November 2017.

[0000833444-18-000021:notes:90]
Net Financing Charges

[0000833444-18-000021:notes:91]
Net financing charges for the six month period ended March 31, 2017, included $17 million of transaction costs related primarily to the prior year debt exchange offer fees.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-18-000021:notes:92]
[same as prior period, unchanged from 0000833444-18-000008:notes:74]

[0000833444-18-000021:notes:93]
[same as prior period, unchanged from 0000833444-18-000008:notes:75]

[0000833444-18-000021:notes:94]
[same as prior period, unchanged from 0000833444-18-000008:notes:76]

[0000833444-18-000021:notes:95]
The Company has global operations and participates in the foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three and six months ended March 31, 2018 and 2017.

[0000833444-18-000021:notes:96]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of lead, copper, tin, aluminum and polypropylene in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As cash flow hedges, the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions, typically sales, occur and affect earnings. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in commodity prices during the three and six months ended March 31, 2018 and 2017.

[0000833444-18-000021:notes:97]
The Company had the following outstanding contracts to hedge forecasted commodity purchases (in metric tons):

[0000833444-18-000021:notes:98]
|  |  | Volume Outstanding as of |
| Commodity |  | March 31, 2018 |  | September 30, 2017 |
| Copper |  | 3,901 |  |  | 1,962 |  |
| Polypropylene |  | 16,561 |  |  | 19,563 |  |
| Lead |  | 6,500 |  |  | 24,705 |  |
| Aluminum |  | 4,525 |  |  | 2,169 |  |
| Tin |  | 2,015 |  |  | 1,715 |  |

[0000833444-18-000021:notes:99]
[same as prior period, unchanged from 0000833444-18-000008:notes:81]

[0000833444-18-000021:notes:100]
The Company selectively uses interest rate swaps to reduce market risk associated with changes in interest rates for its fixed-rate bonds. As fair value hedges, the interest rate swaps and related debt balances are valued under a market approach using publicized swap curves. Changes in the fair value of the swap and hedged portion of the debt are recorded in the consolidated statements of income. As of September 30, 2016, the Company had four fixed to floating interest rate swaps totaling $400 million to hedge the coupon of its 2.6% notes that matured in December 2016, three fixed to floating interest rate swaps totaling $300 million to hedge the coupon of its 1.4% notes maturing November 2017 and one fixed to floating interest rate swap totaling $150 million to hedge the coupon of its 7.125% notes maturing July 2017.  In December 2016, the four remaining outstanding interest rate swaps were terminated. The Company had no interest rate swaps outstanding at March 31, 2018 and September 30, 2017, respectively.

[0000833444-18-000021:notes:101]
[same as prior period, unchanged from 0000833444-18-000008:notes:83]

[0000833444-18-000021:notes:102]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company’s net investments globally. At March 31, 2018, the Company had one billion euro, 750 million euro, 423 million euro and 58 million euro bonds designated as net investment hedges in the Company's net investment in Europe and 35 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan. At September 30, 2017, the Company had one billion euro, 423 million euro and 58 million euro bonds designated as net investment hedges in the Company's net investment in Europe and 35 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan.

[0000833444-18-000021:notes:103]
[same as prior period, unchanged from 0000833444-18-000008:notes:85]

[0000833444-18-000021:notes:104]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount.  As of March 31, 2018, the Company hedged approximately 1.8 million shares of its ordinary shares, which have a cost basis of $73 million. As of September 30, 2017, the Company hedged approximately 1.4 million shares of its ordinary shares, which have a cost basis of $58 million.

[0000833444-18-000021:notes:105]
[same as prior period, unchanged from 0000833444-18-000008:notes:87]

[0000833444-18-000021:notes:106]
[same as prior period, unchanged from 0000833444-18-000008:notes:88]

[0000833444-18-000021:notes:107]
[same as prior period, unchanged from 0000833444-18-000008:notes:89]

[0000833444-18-000021:notes:108]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | March 31, |  | September 30, |  | March 31, |  | September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 26 |  |  | $ | 27 |  |  | $ | — |  |  | $ | — |  |
| Commodity derivatives | 3 |  |  | 9 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 63 |  |  | 55 |  |
| Total assets | $ | 29 |  |  | $ | 36 |  |  | $ | 63 |  |  | $ | 55 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 15 |  |  | $ | 21 |  |  | $ | 22 |  |  | $ | 25 |  |
| Commodity derivatives | 2 |  |  | 1 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,081 |  |  | 2,058 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,098 |  |  | $ | 2,080 |  |  | $ | 22 |  |  | $ | 25 |  |

[0000833444-18-000021:notes:109]
[same as prior period, unchanged from 0000833444-18-000008:notes:91]

[0000833444-18-000021:notes:110]
[same as prior period, unchanged from 0000833444-18-000008:notes:92]

[0000833444-18-000021:notes:111]
The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position. Collateral is generally not required of the Company or the counterparties under the master netting agreements. As of March 31, 2018 and September 30, 2017, no cash collateral was received or pledged under the master netting agreements.

[0000833444-18-000021:notes:112]
[same as prior period, unchanged from 0000833444-18-000008:notes:94]

[0000833444-18-000021:notes:113]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the three and six months ended March 31, 2018 and 2017 (in millions):

[0000833444-18-000021:notes:114]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Foreign currency exchange derivatives |  | $ | (5 | ) |  | $ | (2 | ) |  | $ | 1 |  |  | $ | 6 |  |
| Commodity derivatives |  | (1 | ) |  | 3 |  |  | 2 |  |  | 5 |  |
| Total |  | $ | (6 | ) |  | $ | 1 |  |  | $ | 3 |  |  | $ | 11 |  |

[0000833444-18-000021:notes:115]
The following tables present the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the three and six months ended March 31, 2018 and 2017 (in millions):

[0000833444-18-000021:notes:116]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (2 | ) |  | $ | 8 |  |  | $ | — |  |  | $ | 16 |  |
| Commodity derivatives |  | Cost of sales |  | 4 |  |  | 3 |  |  | 9 |  |  | 4 |  |
| Total |  |  |  | $ | 2 |  |  | $ | 11 |  |  | $ | 9 |  |  | $ | 20 |  |

[0000833444-18-000021:notes:117]
The following table presents the location and amount of pre-tax gains (losses) on fair value hedges recognized in the Company’s consolidated statements of income for the three and six months ended March 31, 2018 and 2017 (in millions):

[0000833444-18-000021:notes:118]
| Derivatives in ASC 815 Fair ValueHedging Relationships |  | Location of Gain (Loss) Recognized in Income on Derivative |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Interest rate swap |  | Net financing charges |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (1 | ) |
| Fixed rate debt swapped to floating |  | Net financing charges |  | — |  |  | — |  |  | — |  |  | 2 |  |
| Total |  |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |

[0000833444-18-000021:notes:119]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the three and six months ended March 31, 2018 and 2017 (in millions):

[0000833444-18-000021:notes:120]
|  |  |  |  | Amount of Gain (Loss) Recognized inIncome on Derivative |
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (4 | ) |  | $ | 2 |  |  | $ | (2 | ) |  | $ | 3 |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | (3 | ) |  | 5 |  |  | 1 |  |  | 9 |  |
| Foreign currency exchange derivatives |  | Income tax provision |  | — |  |  | — |  |  | 2 |  |  | (3 | ) |
| Foreign currency exchange derivatives |  | Income (loss) from discontinued operations |  | — |  |  | — |  |  | — |  |  | 5 |  |
| Equity swap |  | Selling, general and administrative |  | (5 | ) |  | — |  |  | (7 | ) |  | — |  |
| Total |  |  |  | $ | (12 | ) |  | $ | 7 |  |  | $ | (6 | ) |  | $ | 14 |  |

[0000833444-18-000021:notes:121]
The pre-tax gains (losses) recorded in CTA within other comprehensive income (loss) related to net investment hedges were $(100) million and $(19) million for the three months ended March 31, 2018 and 2017, respectively. The pre-tax gains (losses) recorded in CTA within other comprehensive income (loss) related to net investment hedges were $(136) million and $28 million for the six months ended March 31, 2018 and 2017, respectively. For the three and six months ended March 31, 2018 and 2017, no gains or losses were reclassified from CTA into income for the Company’s outstanding net investment hedges.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-18-000021:notes:122]
[same as prior period, unchanged from 0000833444-18-000008:notes:104]

[0000833444-18-000021:notes:123]
During September 2016, the Board of Directors of the Company approved amendments to the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based compensation awards. The Compensation Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter. A summary of the stock-based awards granted during the six month periods ended March 31, 2018 and 2017 is presented below:

[0000833444-18-000021:notes:124]
|  | Six Months Ended March 31, |
|  | 2018 |  | 2017 |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  | Number Granted |  | Weighted Average Grant Date Fair Value |
| Stock options | 1,355,595 |  |  | $ | 7.05 |  |  | 2,830,826 |  |  | $ | 7.81 |  |
| Stock appreciation rights | — |  |  | — |  |  | 15,693 |  |  | 8.28 |  |
| Restricted stock/units | 2,095,225 |  |  | 37.37 |  |  | 1,582,962 |  |  | 41.74 |  |
| Performance shares | 496,478 |  |  | 36.31 |  |  | 846,725 |  |  | 48.40 |  |

[0000833444-18-000021:notes:125]
[same as prior period, unchanged from 0000833444-18-000008:notes:107]

[0000833444-18-000021:notes:126]
[same as prior period, unchanged from 0000833444-18-000008:notes:108]

[0000833444-18-000021:notes:127]
[same as prior period, unchanged from 0000833444-18-000008:notes:109]

[0000833444-18-000021:notes:128]
|  | Six Months Ended March 31, |
|  | 2018 |  | 2017 |
| Expected life of option (years) | 6.5 |  | 4.75 & 6.5 |
| Risk-free interest rate | 2.28% |  | 1.23% - 1.48% |
| Expected volatility of the Company’s stock | 23.7% |  | 24.6% |
| Expected dividend yield on the Company’s stock | 2.78% |  | 2.21% |

[0000833444-18-000021:notes:129]
[same as prior period, unchanged from 0000833444-18-000008:notes:111]

[0000833444-18-000021:notes:130]
[same as prior period, unchanged from 0000833444-18-000008:notes:112]

[0000833444-18-000021:notes:131]
[same as prior period, unchanged from 0000833444-18-000008:notes:113]

[0000833444-18-000021:notes:132]
The Plan provides for the award of restricted stock or restricted stock units to certain employees. These awards are typically share settled unless the employee is a non-U.S. employee or elects to defer settlement until retirement at which point the award would be settled in cash. Restricted awards typically vest over a period of three years from the grant date. The Plan allows for different vesting terms on specific grants with approval by the Board of Directors. The fair value of each share-settled restricted award is based on the closing market value of the Company’s ordinary shares on the date of grant. The fair value of each cash-settled restricted award is recalculated at the end of each reporting period based on the closing market value of the Company's ordinary shares at the end of the reporting period, and the liability and expense are adjusted based on the new fair value.

[0000833444-18-000021:notes:133]
[same as prior period, unchanged from 0000833444-18-000008:notes:115]

[0000833444-18-000021:notes:134]
[same as prior period, unchanged from 0000833444-18-000008:notes:116]

[0000833444-18-000021:notes:135]
[same as prior period, unchanged from 0000833444-18-000008:notes:117]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-18-000021:notes:136]
[same as prior period, unchanged from 0000833444-18-000008:notes:118]

[0000833444-18-000021:notes:137]
[same as prior period, unchanged from 0000833444-18-000008:notes:119]

[0000833444-18-000021:notes:138]
For the six months ended March 31, 2017, the income from discontinued operations before income taxes included separation costs of $79 million.

[0000833444-18-000021:notes:139]
For the six months ended March 31, 2017, the effective tax rate was more than the U.S. federal statutory rate of 35% primarily due to the tax impacts of separation costs and Adient spin-off related tax expense, partially offset by non-U.S. tax rate differentials.

[0000833444-18-000021:notes:140]
The following table summarizes depreciation and amortization, capital expenditures, and significant operating and investing noncash items related to Adient for the six month period ended March 31, 2017 (in millions):

[0000833444-18-000021:notes:141]
|  | Six Months Ended March 31, |
|  | 2017 |
| Depreciation and amortization | $ | 29 |  |
| Equity in earnings of partially-owned affiliates | (31 | ) |
| Deferred income taxes | 562 |  |
| Equity-based compensation | 1 |  |
| Accrued income taxes | (808 | ) |
| Capital expenditures | (91 | ) |

[0000833444-18-000021:notes:142]
[same as prior period, unchanged from 0000833444-18-000008:notes:124]

[0000833444-18-000021:notes:143]
[same as prior period, unchanged from 0000833444-18-000008:notes:125]

[0000833444-18-000021:notes:144]
[same as prior period, unchanged from 0000833444-18-000008:notes:126]

[0000833444-18-000021:notes:145]
[same as prior period, unchanged from 0000833444-18-000008:notes:127]

[0000833444-18-000021:notes:146]
At March 31, 2018, $22 million of certain Corporate assets were classified as held for sale.


## us-gaap:EarningsPerShareTextBlock

[0000833444-18-000021:notes:147]
[same as prior period, unchanged from 0000833444-18-000008:notes:130]

[0000833444-18-000021:notes:148]
[same as prior period, unchanged from 0000833444-18-000008:notes:131]

[0000833444-18-000021:notes:149]
[same as prior period, unchanged from 0000833444-18-000008:notes:132]

[0000833444-18-000021:notes:150]
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Income (loss) Available to Ordinary Shareholders |  |  |  |  |  |  |  |
| Income (loss) from continuing operations | $ | 438 |  |  | $ | (148 | ) |  | $ | 668 |  |  | $ | 224 |  |
| Loss from discontinued operations | — |  |  | — |  |  | — |  |  | (43 | ) |
| Basic and diluted income (loss) available to shareholders | $ | 438 |  |  | $ | (148 | ) |  | $ | 668 |  |  | $ | 181 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 926.2 |  |  | 939.2 |  |  | 926.2 |  |  | 938.2 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 6.3 |  |  | — |  |  | 6.7 |  |  | 9.8 |  |
| Diluted weighted average shares outstanding | 932.5 |  |  | 939.2 |  |  | 932.9 |  |  | 948.0 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Options to purchase shares | 1.4 |  |  | — |  |  | 1.2 |  |  | 0.1 |  |

[0000833444-18-000021:notes:151]
For the three months ended March 31, 2017, the total number of potential dilutive shares due to stock options, unvested restricted stock and unvested performance share awards was 9.4 million. However, these items were not included in the computation of diluted loss per share for the three months ended March 31, 2017 since to do so would decrease the loss per share.

[0000833444-18-000021:notes:152]
During the three months ended March 31, 2018 and 2017, the Company declared a dividend of $0.26 and $0.25, respectively, per share. During the six months ended March 31, 2018 and 2017, the Company declared a dividend of $0.52 and $0.50, respectively, per share.The Company paid all dividends in the month subsequent to the end of each fiscal quarter.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-18-000021:notes:153]
[same as prior period, unchanged from 0000833444-18-000008:notes:135]

[0000833444-18-000021:notes:154]
[same as prior period, unchanged from 0000833444-18-000008:notes:136]

[0000833444-18-000021:notes:155]
[same as prior period, unchanged from 0000833444-18-000008:notes:137]

[0000833444-18-000021:notes:156]
[same as prior period, unchanged from 0000833444-18-000008:notes:138]

[0000833444-18-000021:notes:157]
[same as prior period, unchanged from 0000833444-18-000008:notes:139]

[0000833444-18-000021:notes:158]
[same as prior period, unchanged from 0000833444-18-000008:notes:140]

[0000833444-18-000021:notes:159]
[same as prior period, unchanged from 0000833444-18-000008:notes:141]

[0000833444-18-000021:notes:160]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of March 31, 2018 and September 30, 2017 (in millions):

[0000833444-18-000021:notes:161]
|  | Fair Value Measurements Using: |
|  | Total as of March 31, 2018 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |
| Commodity derivatives | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Exchange traded funds (fixed income)1 | 29 |  |  | 29 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Investments in marketable common stock | 7 |  |  | 7 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 95 |  |  | 95 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 137 |  |  | 137 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 108 |  |  | 108 |  |  | — |  |  | — |  |
| Equity swap | 63 |  |  | — |  |  | 63 |  |  | — |  |
| Total assets | $ | 468 |  |  | $ | 376 |  |  | $ | 92 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 37 |  |  | $ | — |  |  | $ | 37 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Total liabilities | $ | 39 |  |  | $ | — |  |  | $ | 39 |  |  | $ | — |  |

[0000833444-18-000021:notes:162]
[same as prior period, unchanged from 0000833444-18-000008:notes:144]

[0000833444-18-000021:notes:163]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements for further details.

[0000833444-18-000021:notes:164]
[same as prior period, unchanged from 0000833444-18-000008:notes:146]

[0000833444-18-000021:notes:165]
[same as prior period, unchanged from 0000833444-18-000008:notes:147]

[0000833444-18-000021:notes:166]
[same as prior period, unchanged from 0000833444-18-000008:notes:148]

[0000833444-18-000021:notes:167]
[same as prior period, unchanged from 0000833444-18-000008:notes:149]

[0000833444-18-000021:notes:168]
[same as prior period, unchanged from 0000833444-18-000008:notes:150]

[0000833444-18-000021:notes:169]
Investments in marketable common stock and exchange traded funds:  Investments in marketable common stock and exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. The Company recorded unrealized gains of $15 million and unrealized losses of $13 million on these investments as of March 31, 2018 within AOCI in the consolidated statements of financial position. The Company recorded unrealized gains of $10 million and unrealized losses of $6 million on these investments  as of September 30, 2017 within AOCI in the consolidated statements of financial position.

[0000833444-18-000021:notes:170]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The fair value of long-term debt was $11.2 billion and $12.7 billion at March 31, 2018 and September 30, 2017, respectively. The fair value of public debt was $9.1 billion and $8.6 billion, at March 31, 2018 and September 30, 2017, respectively, which was determined primarily using market quotes classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was $2.1 billion and $4.1 billion at March 31, 2018 and September 30, 2017, respectively, which was determined based on quoted market prices for similar instruments classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-18-000021:notes:171]
[same as prior period, unchanged from 0000833444-18-000008:notes:153]

[0000833444-18-000021:notes:172]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the six month period ended March 31, 2018 were as follows (in millions):

[0000833444-18-000021:notes:173]
|  |  |  | Business Acquisitions |  | Business Divestitures |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  |  | March 31, |
|  | 2017 |  |  |  |  | 2018 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 9,637 |  |  | $ | — |  |  | $ | — |  |  | $ | (22 | ) |  | $ | 9,615 |  |
| Building Solutions EMEA/LA | 2,012 |  |  | — |  |  | — |  |  | 77 |  |  | 2,089 |  |
| Building Solutions Asia Pacific | 1,255 |  |  | — |  |  | — |  |  | 54 |  |  | 1,309 |  |
| Global Products | 5,687 |  |  | 8 |  |  | (20 | ) |  | 2 |  |  | 5,677 |  |
| Power Solutions | 1,097 |  |  | — |  |  | — |  |  | 19 |  |  | 1,116 |  |
| Total | $ | 19,688 |  |  | $ | 8 |  |  | $ | (20 | ) |  | $ | 130 |  |  | $ | 19,806 |  |

[0000833444-18-000021:notes:174]
At September 30, 2017, accumulated goodwill impairment charges included $47 million related to the Building Solutions EMEA/LA  - Latin America reporting unit.

[0000833444-18-000021:notes:175]
Amortization of other intangible assets included within continuing operations for the three month periods ended March 31, 2018 and 2017 was $94 million and $126 million, respectively. Amortization of other intangible assets included within continuing operations for the six month periods ended March 31, 2018 and 2017 was $188 million and $275 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2019, 2020, 2021, 2022 and 2023 will be approximately $383 million, $379 million, $371 million, $361 million and $348 million per year, respectively.


## us-gaap:GuaranteesTextBlock

[0000833444-18-000021:notes:176]
[same as prior period, unchanged from 0000833444-18-000008:notes:158]

[0000833444-18-000021:notes:177]
[same as prior period, unchanged from 0000833444-18-000008:notes:159]

[0000833444-18-000021:notes:178]
[same as prior period, unchanged from 0000833444-18-000008:notes:160]

[0000833444-18-000021:notes:179]
[same as prior period, unchanged from 0000833444-18-000008:notes:161]

[0000833444-18-000021:notes:180]
The changes in the carrying amount of the Company’s total product warranty liability, including extended warranties, for the six months ended March 31, 2018 and 2017 were as follows (in millions):

[0000833444-18-000021:notes:181]
|  | Six Months EndedMarch 31, |
|  | 2018 |  | 2017 |
| Balance at beginning of period | $ | 409 |  |  | $ | 374 |  |
| Accruals for warranties issued during the period | 159 |  |  | 152 |  |
| Accruals from acquisition and divestitures | — |  |  | (5 | ) |
| Accruals related to pre-existing warranties | (8 | ) |  | (2 | ) |
| Settlements made (in cash or in kind) during the period | (165 | ) |  | (146 | ) |
| Currency translation | 5 |  |  | (2 | ) |
| Balance at end of period | $ | 400 |  |  | $ | 371 |  |

[0000833444-18-000021:notes:182]
As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded, as part of the acquired liabilities of Tyco, $290 million of post sale contingent tax indemnification liabilities which is generally recorded within other noncurrent liabilities in the consolidated statements of financial position. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. At March 31, 2018 and September 30, 2017, the Company recorded liabilities of $276 million and $290 million, respectively. Of the $276 million recorded as of March 31, 2018, $235 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0000833444-18-000021:notes:183]
[same as prior period, unchanged from 0000833444-18-000008:notes:165]

[0000833444-18-000021:notes:184]
The Company reviews long-lived assets, including tangible assets and other intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of software to be sold, leased, or marketed."  ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 350-30 requires intangible assets acquired in a business combination that are used in research and development activities to be considered indefinite lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they shall not be amortized but shall be tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired.  If the carrying amount of an intangible asset exceeds its fair value, an entity shall recognize an impairment loss in an amount equal to that excess. ASC 985-20 requires the unamortized capitalized costs of a computer software product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off.

[0000833444-18-000021:notes:185]
[same as prior period, unchanged from 0000833444-18-000008:notes:167]

[0000833444-18-000021:notes:186]
In the first and second quarters of fiscal 2017, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2017. As a result, the Company reviewed the long-lived assets for impairment and recorded $38 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income, of which $15 million was recorded in the first quarter and $23 million was recorded in the second quarter. Of the total impairment charges, $20 million related to the Global Products segment, $17 million related to Corporate assets and $1 million related to the Buildings North America segment. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-18-000021:notes:187]
At March 31, 2018 and 2017, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-18-000021:notes:188]
[same as prior period, unchanged from 0000833444-18-000008:notes:170]

[0000833444-18-000021:notes:189]
In calculating the provision for income taxes, the Company uses an estimate of the annual effective tax rate based upon the facts and circumstances known at each interim period. On a quarterly basis, the actual effective tax rate is adjusted, as appropriate, based upon changed facts and circumstances, if any, as compared to those forecasted at the beginning of the fiscal year and each interim period thereafter.

[0000833444-18-000021:notes:190]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended March 31, 2018, the Company's effective tax rate was 14% and was higher than the statutory tax rate of 12.5% primarily due to tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the six months ended March 31, 2018, the Company's effective tax rate was 31% and was higher than the statutory tax rate of 12.5% primarily due to the discrete net impacts of U.S. Tax Reform, final income tax effects of the completed divestiture of the Scott Safety business and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives and tax audit closures. For the three months ended March 31, 2017, the Company's effective tax rate was 129% and was higher than the statutory tax rate of 12.5% primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the divestiture of the Scott Safety business and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives, the jurisdictional mix of significant restructuring and impairment costs, and Tyco Merger transaction and integration costs. For the six months ended March 31, 2017, the Company's effective tax rate was 62% and was higher than the statutory tax rate of 12.5% primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the divestiture of the Scott Safety business, the income tax effects of pension mark-to-market gains, and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives, the jurisdictional mix of significant restructuring and impairment costs, Tyco Merger transaction and integration costs, purchase accounting impacts and a tax benefit due to changes in entity tax status.

[0000833444-18-000021:notes:191]
[same as prior period, unchanged from 0000833444-18-000008:notes:172]

[0000833444-18-000021:notes:192]
[same as prior period, unchanged from 0000833444-18-000008:notes:173]

[0000833444-18-000021:notes:193]
[same as prior period, unchanged from 0000833444-18-000008:notes:174]

[0000833444-18-000021:notes:194]
At September 30, 2017, the Company had gross tax effected unrecognized tax benefits of $2,173 million, of which $2,047 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2017 was approximately $99 million (net of tax benefit). The interest and penalties accrued during the six months ended March 31, 2018 and 2017 were not material. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-18-000021:notes:195]
[same as prior period, unchanged from 0000833444-18-000008:notes:176]

[0000833444-18-000021:notes:196]
In the U.S., fiscal years 2015 through 2016 are currently under exam by the Internal Revenue Service ("IRS"). Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions:

[0000833444-18-000021:notes:197]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2016 |
| Brazil |  | 2011 - 2012 |
| Canada |  | 2013 - 2014 |
| China |  | 2008 - 2016 |
| France |  | 2010 - 2016 |
| Germany |  | 2007 - 2015 |
| Spain |  | 2010 - 2014 |
| Switzerland |  | 2011 - 2014 |
| United Kingdom |  | 2011 - 2015 |

[0000833444-18-000021:notes:198]
[same as prior period, unchanged from 0000833444-18-000008:notes:179]

[0000833444-18-000021:notes:199]
On December 22, 2017, the “Tax Cuts and Jobs Act” (H.R. 1) was enacted which significantly revises U.S. corporate income tax by, among other things, lower corporate income tax rates, impose a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries, and implement a territorial tax system and various base erosion minimum tax provisions.

[0000833444-18-000021:notes:200]
[same as prior period, unchanged from 0000833444-18-000008:notes:181]

[0000833444-18-000021:notes:201]
In the first quarter of fiscal 2018, the Company also recorded a discrete tax charge of $305 million due to the one-time transition tax on deemed repatriated earnings of certain non-U.S. subsidiaries.  This charge is inclusive of relevant non-U.S. withholding taxes and U.S. state income tax on the portion of the earnings expected to be repatriated.  This one-time transition tax is based on the Company’s post-1986 earnings and profits (“E&P”) not previously subjected to U.S. taxation. This tax charge is provisional as the Company has not yet finally determined its post-1986 non-U.S. E&P.  Further, the transition tax is based in part on the amount of those earnings held in cash and other specified assets. Given the varying tax rates (15.5% on cash and 8% on other property), this amount may change when the Company completes the calculation of post-1986 non-U.S. E&P previously deferred from U.S. federal taxation and concludes on the amounts held in cash versus other specified assets.

[0000833444-18-000021:notes:202]
[same as prior period, unchanged from 0000833444-18-000008:notes:183]

[0000833444-18-000021:notes:203]
On October 13, 2016, the U.S. Treasury and the IRS released final and temporary Section 385 regulations. These regulations address whether certain instruments between related parties are treated as debt or equity. The Company does not expect that the regulations will have a material impact on its consolidated financial statements.

[0000833444-18-000021:notes:204]
During the six months ended March 31, 2018 and 2017, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-18-000021:notes:205]
[same as prior period, unchanged from 0000833444-18-000008:notes:186]

[0000833444-18-000021:notes:206]
In the second quarter of fiscal 2018, the Company recorded $64 million of transaction and integration costs. These costs generated a $9 million tax benefit which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000021:notes:207]
In the first quarter of fiscal 2018, the Company completed the sale of its Scott Safety business to 3M Company. Refer to Note 3, "Acquisitions and Divestitures," of the notes to consolidated financial statements for additional information. In connection with the sale, the Company recorded a pre-tax gain of $114 million and income tax expense of $30 million.

[0000833444-18-000021:notes:208]
[same as prior period, unchanged from 0000833444-18-000008:notes:187]

[0000833444-18-000021:notes:209]
[same as prior period, unchanged from 0000833444-18-000008:notes:188]

[0000833444-18-000021:notes:210]
In the second quarter of fiscal 2017, the Company recorded a discrete non-cash tax charge of $457 million related to establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries of the Scott Safety business.

[0000833444-18-000021:notes:211]
In the second quarter of fiscal 2017, the Company recorded $138 million of transaction and integration costs which generated a $31 million tax benefit.

[0000833444-18-000021:notes:212]
In the second quarter of fiscal 2017, the Company recorded pension mark-to-market gains of $18 million, which resulted in tax expense of $8 million.

[0000833444-18-000021:notes:213]
In the second quarter of fiscal 2017, the Company recorded $99 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $20 million tax benefit, which was impacted by the Company’s current tax position in these jurisdictions.

[0000833444-18-000021:notes:214]
[same as prior period, unchanged from 0000833444-18-000008:notes:189]

[0000833444-18-000021:notes:215]
In the first quarter of fiscal 2017, the Company recorded pension mark-to-market gains of $117 million, which resulted in tax expense of $46 million.

[0000833444-18-000021:notes:216]
[same as prior period, unchanged from 0000833444-18-000008:notes:190]

[0000833444-18-000021:notes:217]
[same as prior period, unchanged from 0000833444-18-000008:notes:191]


## us-gaap:InventoryDisclosureTextBlock

[0000833444-18-000021:notes:218]
[same as prior period, unchanged from 0000833444-18-000008:notes:192]

[0000833444-18-000021:notes:219]
[same as prior period, unchanged from 0000833444-18-000008:notes:193]

[0000833444-18-000021:notes:220]
|  | March 31, 2018 |  | September 30, 2017 |
| Raw materials and supplies | $ | 991 |  |  | $ | 919 |  |
| Work-in-process | 575 |  |  | 567 |  |
| Finished goods | 1,999 |  |  | 1,723 |  |
| Inventories | $ | 3,565 |  |  | $ | 3,209 |  |


## us-gaap:LongTermContractsOrProgramsDisclosureTextBlock

[0000833444-18-000021:notes:221]
[same as prior period, unchanged from 0000833444-18-000008:notes:195]

[0000833444-18-000021:notes:222]
The Building Technologies & Solutions business records certain long-term contracts under the percentage-of-completion method of accounting. Under this method, sales and gross profit are recognized as work is performed based on the relationship between actual costs incurred and total estimated costs at completion. The Company records costs and earnings in excess of billings on uncompleted contracts primarily within accounts receivable - net and billings in excess of costs and earnings on uncompleted contracts primarily within deferred revenue in the consolidated statements of financial position. Costs and earnings in excess of billings related to these contracts were $1,065 million and $908 million at March 31, 2018 and September 30, 2017, respectively. Billings in excess of costs and earnings related to these contracts were $565 million and $451 million at March 31, 2018 and September 30, 2017, respectively.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-18-000021:notes:223]
[same as prior period, unchanged from 0000833444-18-000008:notes:197]

[0000833444-18-000021:notes:224]
During the first six months of fiscal 2018, the Company completed certain acquisitions for a combined purchase price of $15 million, all of which was paid as of March 31, 2018. The acquisitions were not material to the Company’s consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $8 million within the Global Products segment.

[0000833444-18-000021:notes:225]
In the second quarter of fiscal 2018, the Company completed the sale of a certain Global Products business. The selling price  was $103 million, all of which was received in the three months ended March 31, 2018. In connection with the sale, the Company reduced goodwill by $20 million and realized an insignificant gain. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-18-000021:notes:226]
In the first quarter of fiscal 2018, the Company completed the sale of its Scott Safety business to 3M Company. The selling price, net of cash divested, was $2.0 billion, all of which was received as of December 31, 2017. In connection with the sale, the Company recorded a pre-tax gain of $114 million within selling, general and administrative expenses in the consolidated statements of income and reduced goodwill in assets held for sale by $1.2 billion. The gain, net of tax, recorded was $84 million. Net cash proceeds from the transaction of approximately $1.9 billion were used to repay a significant portion of the Tyco International Holding S.a.r.L.'s ("TSarl") $4.0 billion of merger-related debt. The Scott Safety business is included in the Global Products segment and was reported within assets and liabilities held for sale in the consolidated statements of financial position as of September 30, 2017. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further disclosure related to the Company's net assets held for sale.

[0000833444-18-000021:notes:227]
In the first six months of fiscal 2017, the Company completed three acquisitions for a combined purchase price, net of cash acquired, of $9 million, $6 million of which was paid in the six months ended March 31, 2017. The acquisitions in the aggregate were not material to the Company’s consolidated financial statements.

[0000833444-18-000021:notes:228]
In the second quarter of fiscal 2017, the Company completed the sale of its ADT security business in South Africa within the Building Solutions EMEA/LA segment. The selling price, net of cash divested, was $129 million, all of which was received in the six months ended March 31, 2017. In connection with the sale, the Company reduced goodwill in assets held for sale by $92 million. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-18-000021:notes:229]
In the first six months of fiscal 2017, the Company completed one divestiture for a sales price of $4 million, all of which was received in the six months ended March 31, 2017. The divestiture decreased the Company's ownership from a controlling to noncontrolling interest, and as a result, the Company deconsolidated cash of $5 million. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-18-000021:notes:230]
In the first six months of fiscal 2017, the Company received $52 million in net cash proceeds related to prior year business divestitures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-18-000021:notes:231]
[same as prior period, unchanged from 0000833444-18-000008:notes:202]

[0000833444-18-000021:notes:232]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2017 filed with the SEC on November 21, 2017. The results of operations for the three and six month periods ended March 31, 2018 are not necessarily indicative of results for the Company’s 2018 fiscal year because of seasonal and other factors.

[0000833444-18-000021:notes:233]
[same as prior period, unchanged from 0000833444-18-000008:notes:204]

[0000833444-18-000021:notes:234]
[same as prior period, unchanged from 0000833444-18-000008:notes:205]

[0000833444-18-000021:notes:235]
[same as prior period, unchanged from 0000833444-18-000008:notes:206]

[0000833444-18-000021:notes:236]
[same as prior period, unchanged from 0000833444-18-000008:notes:207]

[0000833444-18-000021:notes:237]
[same as prior period, unchanged from 0000833444-18-000008:notes:208]

[0000833444-18-000021:notes:238]
[same as prior period, unchanged from 0000833444-18-000008:notes:209]

[0000833444-18-000021:notes:239]
[same as prior period, unchanged from 0000833444-18-000008:notes:210]

[0000833444-18-000021:notes:240]
[same as prior period, unchanged from 0000833444-18-000008:notes:211]

[0000833444-18-000021:notes:241]
[same as prior period, unchanged from 0000833444-18-000008:notes:212]

[0000833444-18-000021:notes:242]
Based upon the criteria set forth in ASC 810, the Company has determined that it was not the primary beneficiary in any VIEs for the reporting period ended March 31, 2018 and that it was the primary beneficiary in one VIE for the reporting period ended September 30, 2017, as the Company absorbed significant economics of the entity and had the power to direct the activities that are considered most significant to the entity.

[0000833444-18-000021:notes:243]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company was considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE was consolidated within the Company’s consolidated statements of financial position as of September 30, 2017. During the quarter ended December 31, 2017, certain joint venture agreements were amended, and as a result, the Company can no longer make key operating decisions considered to be most significant to the VIE. As such, the Company is no longer considered the primary beneficiary of this entity, and the Company deconsolidated the entity during the quarter ended December 31, 2017. The impact of the entity on the Company’s consolidated statements of income for the six month periods ended March 31, 2018 and 2017 was not material.

[0000833444-18-000021:notes:244]
[same as prior period, unchanged from 0000833444-18-000008:notes:215]

[0000833444-18-000021:notes:245]
[same as prior period, unchanged from 0000833444-18-000008:notes:216]

[0000833444-18-000021:notes:246]
[same as prior period, unchanged from 0000833444-18-000008:notes:217]

[0000833444-18-000021:notes:247]
[same as prior period, unchanged from 0000833444-18-000008:notes:218]

[0000833444-18-000021:notes:248]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The VIEs are named as co-obligors under a third party debt agreement in the amount of $159 million, maturing in fiscal 2020, under which a VIE could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business. The Company is not considered to be the primary beneficiary of three of the entities as of March 31, 2018 and two of the entities as of September 30, 2017, as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balances of $41 million and $65 million at March 31, 2018 and September 30, 2017, respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.

[0000833444-18-000021:notes:249]
[same as prior period, unchanged from 0000833444-18-000008:notes:220]

[0000833444-18-000021:notes:250]
[same as prior period, unchanged from 0000833444-18-000008:notes:221]

[0000833444-18-000021:notes:251]
At March 31, 2018, the Company held restricted cash of approximately $21 million, of which $12 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. At September 30, 2017, the Company held restricted cash of approximately $31 million, of which $22 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash restricted for payment of asbestos liabilities.

[0000833444-18-000021:notes:252]
[same as prior period, unchanged from 0000833444-18-000008:notes:223]

[0000833444-18-000021:notes:253]
[same as prior period, unchanged from 0000833444-18-000008:notes:224]

[0000833444-18-000021:notes:254]
In March 2016, the FASB issued Accounting Standards Update ("ASU") No. 2016-09, "Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." During the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09. As a result, employee withholding taxes paid to taxing authorities for equity-based compensation transactions, previously classified as cash flows from operating activities, were reclassified to financing activities in the consolidated statements of cash flows for the six months ended March 31, 2017. Refer to Note 2, "New Accounting Standards," of the notes to consolidated financial statements for further information.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-18-000021:notes:255]
[same as prior period, unchanged from 0000833444-18-000008:notes:226]

[0000833444-18-000021:notes:256]
[same as prior period, unchanged from 0000833444-18-000008:notes:227]

[0000833444-18-000021:notes:257]
|  | U.S. Pension Plans |
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Service cost | $ | 3 |  |  | $ | 4 |  |  | $ | 7 |  |  | $ | 9 |  |
| Interest cost | 27 |  |  | 29 |  |  | 53 |  |  | 57 |  |
| Expected return on plan assets | (57 | ) |  | (58 | ) |  | (114 | ) |  | (117 | ) |
| Net actuarial gain | — |  |  | (18 | ) |  | — |  |  | (135 | ) |
| Settlement gain | — |  |  | (1 | ) |  | — |  |  | (9 | ) |
| Net periodic benefit credit | $ | (27 | ) |  | $ | (44 | ) |  | $ | (54 | ) |  | $ | (195 | ) |

[0000833444-18-000021:notes:258]
|  | Non-U.S. Pension Plans |
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Service cost | $ | 6 |  |  | $ | 8 |  |  | $ | 12 |  |  | $ | 16 |  |
| Interest cost | 15 |  |  | 11 |  |  | 29 |  |  | 23 |  |
| Expected return on plan assets | (29 | ) |  | (22 | ) |  | (58 | ) |  | (45 | ) |
| Net periodic benefit credit | $ | (8 | ) |  | $ | (3 | ) |  | $ | (17 | ) |  | $ | (6 | ) |

[0000833444-18-000021:notes:259]
|  | Postretirement Benefits |
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Service cost | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest cost | 1 |  |  | 2 |  |  | 3 |  |  | 3 |  |
| Expected return on plan assets | (3 | ) |  | (2 | ) |  | (5 | ) |  | (5 | ) |
| Net periodic benefit credit | $ | (1 | ) |  | $ | — |  |  | $ | (1 | ) |  | $ | (1 | ) |

[0000833444-18-000021:notes:260]
During the three and six months ended March 31, 2017, the amount of lump sum payouts triggered a remeasurement event for certain U.S. pension plans resulting in the recognition of net actuarial gains of $18 million and $135 million, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-18-000021:notes:261]
Related Party Transactions

[0000833444-18-000021:notes:262]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-18-000021:notes:263]
The net sales to and purchases from related parties included in the consolidated statements of income were $222 million and $70 million, respectively, for the three months ended March 31, 2018; and $229 million and $52 million, respectively, for the three months ended March 31, 2017. The net sales to and purchases from related parties included in the consolidated statements of income were $464 million and $111 million, respectively, for the six months ended March 31, 2018; and $454 million and $101 million, respectively, for the six months ended March 31, 2017.

[0000833444-18-000021:notes:264]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position (in millions):

[0000833444-18-000021:notes:265]
|  |  | March 31, 2018 |  | September 30, 2017 |  |
| Receivable from related parties |  | $ | 107 |  |  | $ | 108 |  |
| Payable to related parties |  | 60 |  |  | 50 |  |

[0000833444-18-000021:notes:266]
The Company has also provided financial support to certain of its VIE's; see Note 1, "Financial Statements," of the notes to consolidated financial statements for additional information.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-18-000021:notes:267]
[same as prior period, unchanged from 0000833444-18-000008:notes:238]

[0000833444-18-000021:notes:268]
[same as prior period, unchanged from 0000833444-18-000008:notes:239]

[0000833444-18-000021:notes:269]
[same as prior period, unchanged from 0000833444-18-000008:notes:240]

[0000833444-18-000021:notes:270]
[same as prior period, unchanged from 0000833444-18-000008:notes:241]

[0000833444-18-000021:notes:271]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 125 |  |  | $ | 30 |  |  | $ | 3 |  |  | $ | 158 |  |
| Utilized—noncash | — |  |  | (30 | ) |  | — |  |  | (30 | ) |
| Balance at December 31, 2017 | $ | 125 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 128 |  |
| Utilized—cash | (8 | ) |  | — |  |  | (1 | ) |  | (9 | ) |
| Balance at March 31, 2018 | $ | 117 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 119 |  |

[0000833444-18-000021:notes:272]
In fiscal 2017, the Company committed to a significant restructuring plan (2017 Plan) and recorded $367 million of restructuring and impairment costs in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $166 million related to Corporate, $74 million related to the Building Solutions EMEA/LA segment, $59 million related to the Building Solutions North America segment, $32 million related to the Global Products segment, $20 million related to the Power Solutions segment and $16 million related to the Building Solutions Asia Pacific segment. The restructuring actions are expected to be substantially complete in 2018.

[0000833444-18-000021:notes:273]
[same as prior period, unchanged from 0000833444-18-000008:notes:244]

[0000833444-18-000021:notes:274]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 276 |  |  | $ | 77 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 367 |  |
| Utilized—cash | (75 | ) |  | — |  |  | — |  |  | — |  |  | (75 | ) |
| Utilized—noncash | — |  |  | (77 | ) |  | (1 | ) |  | — |  |  | (78 | ) |
| Adjustment to restructuring reserves | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |
| Balance at September 30, 2017 | $ | 226 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 239 |  |
| Utilized—cash | (109 | ) |  | — |  |  | (3 | ) |  | — |  |  | (112 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Balance at March 31, 2018 | $ | 117 |  |  | $ | — |  |  | $ | 10 |  |  | $ | 1 |  |  | $ | 128 |  |

[0000833444-18-000021:notes:275]
In fiscal 2016, the Company committed to a significant restructuring plan (2016 Plan) and recorded $288 million of restructuring and impairment costs in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. Of the restructuring and impairment costs recorded, $161 million related to Corporate, $66 million related to the Power Solutions segment, $44 million related to the Global Products segment and $17 million related to the Building Solutions EMEA/LA segment. The restructuring actions are expected to be substantially complete in 2018. Included in the reserve is $56 million of committed restructuring actions taken by Tyco for liabilities assumed as part of the Tyco acquisition.

[0000833444-18-000021:notes:276]
[same as prior period, unchanged from 0000833444-18-000008:notes:247]

[0000833444-18-000021:notes:277]
[same as prior period, unchanged from 0000833444-18-000008:notes:248]

[0000833444-18-000021:notes:278]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 368 |  |  | $ | 190 |  |  | $ | 62 |  |  | $ | — |  |  | $ | 620 |  |
| Acquired Tyco restructuring reserves | 78 |  |  | — |  |  | — |  |  | — |  |  | 78 |  |
| Utilized—cash | (32 | ) |  | — |  |  | — |  |  | — |  |  | (32 | ) |
| Utilized—noncash | — |  |  | (190 | ) |  | (32 | ) |  | 1 |  |  | (221 | ) |
| Balance at September 30, 2016 | $ | 414 |  |  | $ | — |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 445 |  |
| Adient spin-off impact | (194 | ) |  | — |  |  | (22 | ) |  | — |  |  | (216 | ) |
| Utilized—cash | (86 | ) |  | — |  |  | (2 | ) |  | — |  |  | (88 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Adjustment to restructuring reserves | (25 | ) |  | — |  |  | — |  |  | — |  |  | (25 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Adjustment to acquired Tyco restructuring reserves | (22 | ) |  | — |  |  | — |  |  | — |  |  | (22 | ) |
| Balance at September 30, 2017 | $ | 84 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 2 |  |  | $ | 92 |  |
| Utilized—cash | (14 | ) |  | — |  |  | (2 | ) |  | — |  |  | (16 | ) |
| Balance at March 31, 2018 | $ | 70 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 2 |  |  | $ | 76 |  |

[0000833444-18-000021:notes:279]
The Company's fiscal 2018, 2017 and 2016 restructuring plans included workforce reductions of approximately 9,200 employees (7,300 for the Building Technologies & Solutions business, 1,700 for Corporate and 200 for Power Solutions). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of March 31, 2018, approximately 2,700 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included eleven plant closures in the Building Technologies & Solutions business. As of March 31, 2018, four of the eleven plants have been closed.

[0000833444-18-000021:notes:280]
[same as prior period, unchanged from 0000833444-18-000008:notes:251]


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-18-000021:notes:281]
[same as prior period, unchanged from 0000833444-18-000008:notes:252]

[0000833444-18-000021:notes:282]
|  | Three Months EndedMarch 31, |
|  | 2018 |  | 2017 |
| Foreign currency translation adjustments ("CTA") |  |  |  |
| Balance at beginning of period | $ | (423 | ) |  | $ | (1,248 | ) |
| Aggregate adjustment for the period (net of tax effect of $0) | 168 |  |  | 241 |  |
| Balance at end of period | (255 | ) |  | (1,007 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 7 |  |  | 20 |  |
| Current period changes in fair value (net of tax effect of $(2) and $0) | (4 | ) |  | 1 |  |
| Reclassification to income (net of tax effect of $0 and $(4)) ** | (2 | ) |  | (7 | ) |
| Balance at end of period | 1 |  |  | 14 |  |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | 4 |  |  | (3 | ) |
| Current period changes in fair value (net of tax effect of $0) | (2 | ) |  | 11 |  |
| Balance at end of period | 2 |  |  | 8 |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (2 | ) |  | (2 | ) |
| Other changes | — |  |  | — |  |
| Balance at end of period | (2 | ) |  | (2 | ) |
| Accumulated other comprehensive loss, end of period | $ | (254 | ) |  | $ | (987 | ) |

[0000833444-18-000021:notes:283]
|  | Six Months EndedMarch 31, |
|  | 2018 |  | 2017 |
| CTA |  |  |  |
| Balance at beginning of period | $ | (481 | ) |  | $ | (1,152 | ) |
| Aggregate adjustment for the period (net of tax effect of $1 and $5) * | 226 |  |  | (418 | ) |
| Adient spin-off impact (net of tax effect of $0) | — |  |  | 563 |  |
| Balance at end of period | (255 | ) |  | (1,007 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 6 |  |  | 4 |  |
| Current period changes in fair value (net of tax effect of $1 and $4) | 2 |  |  | 7 |  |
| Reclassification to income (net of tax effect of $(2) and $(7)) ** | (7 | ) |  | (13 | ) |
| Adient spin-off impact (net of tax effect of $0 and $6) | — |  |  | 16 |  |
| Balance at end of period | 1 |  |  | 14 |  |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | 4 |  |  | (1 | ) |
| Current period changes in fair value (net of tax effect of $0) | (2 | ) |  | 9 |  |
| Balance at end of period | 2 |  |  | 8 |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (2 | ) |  | (4 | ) |
| Adient spin-off impact (net of tax effect of $0) | — |  |  | 2 |  |
| Balance at end of period | (2 | ) |  | (2 | ) |
| Accumulated other comprehensive loss, end of period | $ | (254 | ) |  | $ | (987 | ) |

[0000833444-18-000021:notes:284]
* During the six months ended March 31, 2018, $12 million of cumulative CTA was recognized as part of the divestiture-related gain recognized as a result of the divestiture of Scott Safety.

[0000833444-18-000021:notes:285]
[same as prior period, unchanged from 0000833444-18-000008:notes:255]


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000833444-18-000021:notes:286]
[same as prior period, unchanged from 0000833444-18-000008:notes:256]

[0000833444-18-000021:notes:287]
|  | Net Sales |
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,097 |  |  | $ | 2,097 |  |  | $ | 4,109 |  |  | $ | 4,039 |  |
| Building Solutions EMEA/LA | 907 |  |  | 898 |  |  | 1,822 |  |  | 1,773 |  |
| Building Solutions Asia Pacific | 586 |  |  | 562 |  |  | 1,183 |  |  | 1,137 |  |
| Global Products | 2,040 |  |  | 2,014 |  |  | 3,821 |  |  | 3,808 |  |
|  | 5,630 |  |  | 5,571 |  |  | 10,935 |  |  | 10,757 |  |
| Power Solutions | 1,845 |  |  | 1,696 |  |  | 3,975 |  |  | 3,596 |  |
| Total net sales | $ | 7,475 |  |  | $ | 7,267 |  |  | $ | 14,910 |  |  | $ | 14,353 |  |

[0000833444-18-000021:notes:288]
|  | Segment EBITA |
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 239 |  |  | $ | 255 |  |  | $ | 466 |  |  | $ | 451 |  |
| Building Solutions EMEA/LA | 77 |  |  | 89 |  |  | 146 |  |  | 138 |  |
| Building Solutions Asia Pacific | 71 |  |  | 67 |  |  | 145 |  |  | 130 |  |
| Global Products | 228 |  |  | 242 |  |  | 514 |  |  | 369 |  |
|  | 615 |  |  | 653 |  |  | 1,271 |  |  | 1,088 |  |
| Power Solutions | 314 |  |  | 303 |  |  | 698 |  |  | 692 |  |
| Total segment EBITA | $ | 929 |  |  | $ | 956 |  |  | $ | 1,969 |  |  | $ | 1,780 |  |
| Corporate expenses | $ | (159 | ) |  | $ | (240 | ) |  | $ | (293 | ) |  | $ | (433 | ) |
| Amortization of intangible assets | (94 | ) |  | (126 | ) |  | (188 | ) |  | (275 | ) |
| Restructuring and impairment costs | — |  |  | (99 | ) |  | (158 | ) |  | (177 | ) |
| Net mark-to-market adjustments on pension plans | — |  |  | 18 |  |  | — |  |  | 135 |  |
| Net financing charges | (115 | ) |  | (116 | ) |  | (231 | ) |  | (252 | ) |
| Income from continuing operations before income taxes | $ | 561 |  |  | $ | 393 |  |  | $ | 1,099 |  |  | $ | 778 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-18-000021:notes:289]
[same as prior period, unchanged from 0000833444-18-000008:notes:259]

[0000833444-18-000021:notes:290]
[same as prior period, unchanged from 0000833444-18-000008:notes:260]

[0000833444-18-000021:notes:291]
[same as prior period, unchanged from 0000833444-18-000008:notes:261]

[0000833444-18-000021:notes:292]
[same as prior period, unchanged from 0000833444-18-000008:notes:262]

[0000833444-18-000021:notes:293]
[same as prior period, unchanged from 0000833444-18-000008:notes:263]

[0000833444-18-000021:notes:294]
[same as prior period, unchanged from 0000833444-18-000008:notes:264]

[0000833444-18-000021:notes:295]
[same as prior period, unchanged from 0000833444-18-000008:notes:265]

[0000833444-18-000021:notes:296]
[same as prior period, unchanged from 0000833444-18-000008:notes:266]

[0000833444-18-000021:notes:297]
[same as prior period, unchanged from 0000833444-18-000008:notes:267]

[0000833444-18-000021:notes:298]
[same as prior period, unchanged from 0000833444-18-000008:notes:268]

[0000833444-18-000021:notes:299]
[same as prior period, unchanged from 0000833444-18-000008:notes:269]

[0000833444-18-000021:notes:300]
[same as prior period, unchanged from 0000833444-18-000008:notes:270]

[0000833444-18-000021:notes:301]
[same as prior period, unchanged from 0000833444-18-000008:notes:271]

[0000833444-18-000021:notes:302]
[same as prior period, unchanged from 0000833444-18-000008:notes:272]

[0000833444-18-000021:notes:303]
[same as prior period, unchanged from 0000833444-18-000008:notes:273]

[0000833444-18-000021:notes:304]
[same as prior period, unchanged from 0000833444-18-000008:notes:274]

[0000833444-18-000021:notes:305]
[same as prior period, unchanged from 0000833444-18-000008:notes:275]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-18-000021:notes:306]
[same as prior period, unchanged from 0000833444-18-000008:notes:276]

[0000833444-18-000021:notes:307]
[same as prior period, unchanged from 0000833444-18-000008:notes:277]

[0000833444-18-000021:notes:308]
As previously disclosed, during the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09. As a result, the Company recognized deferred tax assets of $179 million related to certain operating loss carryforwards resulting from the exercise of employee stock options and restricted stock vestings on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2017.

[0000833444-18-000021:notes:309]
[same as prior period, unchanged from 0000833444-18-000008:notes:279]

[0000833444-18-000021:notes:310]
Following the Tyco Merger, the Company adopted, subject to the ongoing existence of sufficient distributable reserves, the existing Tyco International plc $1 billion share repurchase program in September 2016. In December 2017, the Company's Board of Directors approved an $1 billion increase to its share repurchase authorization. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. For the three and six month periods ended March 31, 2018, the Company repurchased $49 million and $199 million of its ordinary shares, respectively. For the three and six month periods ended March 31, 2017, the Company had $119 million repurchases of its ordinary shares. As of March 31, 2018, approximately $1.1 billion remains available under the share repurchase program.

[0000833444-18-000021:notes:311]
[same as prior period, unchanged from 0000833444-18-000008:notes:281]

[0000833444-18-000021:notes:312]
[same as prior period, unchanged from 0000833444-18-000008:notes:282]

[0000833444-18-000021:notes:313]
|  | Three Months EndedMarch 31, |
|  | 2018 |  | 2017 |
| Beginning balance, December 31 | $ | 226 |  |  | $ | 159 |  |
| Net income | 12 |  |  | 8 |  |
| Foreign currency translation adjustments | 5 |  |  | 1 |  |
| Realized and unrealized losses on derivatives | (5 | ) |  | — |  |
| Dividends | (3 | ) |  | — |  |
| Ending balance, March 31 | $ | 235 |  |  | $ | 168 |  |

[0000833444-18-000021:notes:314]
|  | Six Months EndedMarch 31, |
|  | 2018 |  | 2017 |
| Beginning balance, September 30 | $ | 211 |  |  | $ | 234 |  |
| Net income | 25 |  |  | 21 |  |
| Foreign currency translation adjustments | 10 |  |  | (8 | ) |
| Realized and unrealized losses on derivatives | (8 | ) |  | — |  |
| Dividends | (3 | ) |  | (43 | ) |
| Spin-off of Adient | — |  |  | (36 | ) |
| Ending balance, March 31 | $ | 235 |  |  | $ | 168 |  |
