# JCI 8-K — 0000833444-15-000060 filed 2015-07-31

## item codes, every 8-K on or before 2015-07-31

- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2015-07-31

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-15-000060:8k_2_02:1]
EX-99.1
2
exhibit991-q315.htm
EXHIBIT 99.1

[0000833444-15-000060:8k_2_02:2]
Exhibit 99.1 - Q315

[0000833444-15-000060:8k_2_02:3]
| Investor Contacts: |  | Media Contact: |  |
| Antonella Franzen |  | Stephen Wasdick |  |
| +1-609-720-4665 |  | +1-609-806-2262 |  |
| afranzen@tyco.com |  | swasdick@tyco.com |  |
| Leila Peters |  |  |  |
| +1-609-720-4545 |  |  |  |
| lpeters@tyco.com |  |  |  |

[0000833444-15-000060:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-15-000060:8k_2_02:5]
TYCO REPORTS THIRD QUARTER 2015 EARNINGS FROM CONTINUING OPERATIONS

[0000833444-15-000060:8k_2_02:6]
BEFORE SPECIAL ITEMS OF $0.59 PER SHARE AND GAAP EARNINGS OF $0.44 PER SHARE

[0000833444-15-000060:8k_2_02:7]
| • | Segment operating margin before special items of 14.8% expands 30 basis points year over year, or 90 basis points when adjusted for non-cash purchase accounting and increased Air-Pak shipments in prior-year quarter |

[0000833444-15-000060:8k_2_02:8]
| • | Diluted EPS from continuing operations before special items increases 9%, or 13% when adjusted for increased product shipments in prior-year quarter |

[0000833444-15-000060:8k_2_02:9]
| • | Provides guidance for fourth quarter 2015 EPS before special items of $0.60 - $0.62, a 7%-11% increase year over year |

[0000833444-15-000060:8k_2_02:10]
| • | Tightens full-year guidance to a range of $2.23 - $2.25 from $2.23 - $2.27, representing earnings growth of 12%-13% from the prior year |

[0000833444-15-000060:8k_2_02:11]
(Income and EPS amounts are attributable to Tyco ordinary shareholders)

[0000833444-15-000060:8k_2_02:12]
($ millions, except per-share amounts)

[0000833444-15-000060:8k_2_02:13]
(All prior periods have been recast to reflect certain businesses as discontinued operations)

[0000833444-15-000060:8k_2_02:14]
|  |  | Q3 2015 |  | Q3 2014 |  | % Change |  |
| Revenue |  | $ | 2,489 |  |  | $ | 2,660 |  |  | (6 | )% |  |
| Segment Operating Income |  | $ | 325 |  |  | $ | 355 |  |  | (8 | )% |  |
| Operating Income |  | $ | 253 |  |  | $ | 297 |  |  | (15 | )% |  |
| Income from Continuing Operations |  | $ | 188 |  |  | $ | 435 |  |  | (57 | )% |  |
| Diluted EPS from Continuing Operations |  | $ | 0.44 |  |  | $ | 0.93 |  |  | (53 | )% |  |
| Special Items |  | $ | (0.15 | ) |  | $ | 0.39 |  |  |  |  |
| Segment Operating Income Before Special Items |  | $ | 369 |  |  | $ | 387 |  |  | (5 | )% |  |
| Income from Continuing Ops Before Special Items |  | $ | 251 |  |  | $ | 254 |  |  | (1 | )% |  |
| Diluted EPS from Continuing Ops Before Special Items |  | $ | 0.59 |  |  | $ | 0.54 |  |  | 9 | % |  |

[0000833444-15-000060:8k_2_02:15]
CORK, Ireland, July 31, 2015 - Tyco (NYSE: TYC) today reported $0.44 in GAAP diluted earnings per share (EPS) from continuing operations for the fiscal third quarter of 2015 and diluted EPS from continuing operations before special items of $0.59.  Revenue of $2.5 billion in the quarter decreased 6% versus the prior year, primarily due to a 7% negative impact of the stronger U.S. dollar against foreign currencies.  Organic revenue declined 1% in the quarter.  Acquisitions contributed 2 percentage points of growth, which was partially offset by the impact of a divestiture.

[0000833444-15-000060:8k_2_02:16]
“While we were disappointed with our top-line growth, we once again demonstrated our ability to leverage and accelerate internal productivity and cost containment initiatives to deliver on our earnings commitment for the quarter,” said Tyco Chief Executive Officer George R. Oliver.  “We produced strong margin expansion of 90 basis points, driven by an improvement in fundamentals in our North America Installation & Services business.  That, combined with additional restructuring actions, position us well to achieve 12% to 13% EPS growth for the year," Mr. Oliver added.

[0000833444-15-000060:8k_2_02:17]
Organic revenue, free cash flow, adjusted free cash flow, operating income, segment operating income, and diluted EPS from continuing operations before special items are non-GAAP financial measures and are described below.  For a reconciliation of these non-GAAP measures, see the attached tables. Additional schedules as well as third quarter review slides can be found in the Investor Relations section of Tyco’s website at http://investors.tyco.com.

[0000833444-15-000060:8k_2_02:18]
SEGMENT RESULTS

[0000833444-15-000060:8k_2_02:19]
The financial results presented in the tables below are in accordance with GAAP unless otherwise indicated. All dollar amounts are pre-tax and stated in millions.  Certain businesses have been classified as discontinued operations.  The revenue and operating income results shown below have been adjusted to reflect these changes in all periods presented.  All comparisons are to the fiscal third quarter of 2014 unless otherwise indicated.

[0000833444-15-000060:8k_2_02:20]
North America Installation & Services

[0000833444-15-000060:8k_2_02:21]
|  |  | Q3 2015 |  | Q3 2014 |  | % Change |  |
| Revenue |  | $ | 972 |  |  | $ | 968 |  |  | — | % |  |
| Operating Income |  | $ | 160 |  |  | $ | 117 |  |  | 37 | % |  |
| Operating Margin |  | 16.5 | % |  | 12.1 | % |  |  |  |
| Special Items |  | $ | 3 |  |  | $ | (17 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 157 |  |  | $ | 134 |  |  | 17 | % |  |
| Operating Margin Before Special Items |  | 16.2 | % |  | 13.8 | % |  |  |  |

[0000833444-15-000060:8k_2_02:22]
Revenue of $972 million was relatively flat compared to the prior year, as organic growth was offset by the weakening of the Canadian dollar.  Organic revenue growth of 1% was driven by 3% growth in installation revenue, while service revenue was relatively flat.  Backlog of $2.5 billion increased 4% year over year and 2% on a quarter sequential basis, excluding the impact of foreign currency.

[0000833444-15-000060:8k_2_02:23]
Operating income for the quarter was $160 million and the operating margin was 16.5%. Special items were favorable by $3 million.  Before special items, operating income was $157 million and the operating margin improved 240 basis points to 16.2%.  Improved execution and the benefit of restructuring and productivity initiatives drove the operating margin expansion.

[0000833444-15-000060:8k_2_02:24]
Rest of World Installation & Services

[0000833444-15-000060:8k_2_02:25]
|  |  | Q3 2015 |  | Q3 2014 |  | % Change |  |
| Revenue |  | $ | 842 |  |  | $ | 999 |  |  | (16 | )% |  |
| Operating Income |  | $ | 57 |  |  | $ | 102 |  |  | (44 | )% |  |
| Operating Margin |  | 6.8 | % |  | 10.2 | % |  |  |  |
| Special Items |  | $ | (36 | ) |  | $ | (11 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 93 |  |  | $ | 113 |  |  | (18 | )% |  |
| Operating Margin Before Special Items |  | 11.0 | % |  | 11.3 | % |  |  |  |

[0000833444-15-000060:8k_2_02:26]
Revenue of $842 million decreased 16% compared to the prior year, driven by a 13% unfavorable impact from foreign currency exchange rates.  Organic revenue declined 2%, with a 1% decline in service and a 3% decline in installation revenue.  Acquisition growth of 1% was more than offset by a decline related to a divestiture.  Backlog of $1.9 billion decreased 1% year over year and increased 1% on a quarter sequential basis, excluding the impact of foreign currency and the divestiture.

[0000833444-15-000060:8k_2_02:27]
Operating income for the quarter was $57 million and the operating margin was 6.8%.  Special items of $36 million consisted primarily of restructuring and repositioning charges.  Before special items, operating income was $93 million and the operating margin was 11.0%.  The operating margin declined 30 basis points, as the benefit of restructuring and productivity initiatives was more than offset by the revenue decline and the contributing mix of geographies.

[0000833444-15-000060:8k_2_02:28]
Global Products

[0000833444-15-000060:8k_2_02:29]
|  |  | Q3 2015 |  | Q3 2014 |  | % Change |  |
| Revenue |  | $ | 675 |  |  | $ | 693 |  |  | (3 | )% |  |
| Operating Income |  | $ | 108 |  |  | $ | 136 |  |  | (21 | )% |  |
| Operating Margin |  | 16.0 | % |  | 19.6 | % |  |  |  |
| Special Items |  | $ | (11 | ) |  | $ | (4 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 119 |  |  | $ | 140 |  |  | (15 | )% |  |
| Operating Margin Before Special Items |  | 17.6 | % |  | 20.2 | % |  |  |  |

[0000833444-15-000060:8k_2_02:30]
Revenue of $675 million decreased 3% in the quarter.  Organic revenue declined 3%, including a 5 percentage point headwind related to increased shipments of Scott Safety Air-Pak X3s in the prior year.  Acquisitions contributed 7 percentage points of growth, which was offset by changes in foreign currency exchange rates.

[0000833444-15-000060:8k_2_02:31]
Operating income for the quarter was $108 million and the operating margin was 16.0%.  Special items of $11 million consisted of restructuring and repositioning charges as well as acquisition-related expenses.  Before special items, operating income was $119 million and the operating margin was 17.6%.  The 260 basis point decline in operating margin included the impact of the increased shipments of Air-Paks in the prior year, non-cash purchase accounting related to intangibles, and the timing of incremental investments in R&D, which together negatively impacted the operating margin by 330 basis points.  Underlying operations improved 70 basis points year over year.

[0000833444-15-000060:8k_2_02:32]
OTHER ITEMS

[0000833444-15-000060:8k_2_02:33]
| • | Cash from operating activities was $249 million and free cash flow was $186 million, which included a cash outflow of $44 million from special items primarily related to restructuring and repositioning activities. Adjusted free cash flow for the quarter was $230 million. The company completed the quarter with $531 million in cash and cash equivalents. |

[0000833444-15-000060:8k_2_02:34]
| • | Corporate expense for the quarter was $50 million before special items and $72 million on a GAAP basis, which includes restructuring and repositioning charges. |

[0000833444-15-000060:8k_2_02:35]
| • | The tax rate before special items was 17.2% for the quarter. |

[0000833444-15-000060:8k_2_02:36]
| • | In July, the company completed the acquisition of FootFall, a global retail intelligence leader, for approximately $60 million in cash. On an annualized basis, the addition of this business to Tyco’s operations is expected to generate approximately $40 million in revenue. |

[0000833444-15-000060:8k_2_02:37]
ABOUT TYCO

[0000833444-15-000060:8k_2_02:38]
Tyco (NYSE: TYC) is the world’s largest pure-play fire protection and security company. Tyco provides more than three million customers around the globe with the latest fire protection and security products and services. A company with $10+ billion in annual revenue, Tyco has over 57,000 employees in more than 900 locations across 50 countries serving various end markets, including commercial, institutional, governmental, retail, industrial, energy, residential and small business. For more information, visit www.tyco.com.

[0000833444-15-000060:8k_2_02:39]
CONFERENCE CALL AND WEBCAST

[0000833444-15-000060:8k_2_02:40]
Management will discuss the company’s third quarter results for 2015 during a conference call and webcast today beginning at 8:00 a.m. Eastern time (ET).  Today’s conference call for investors can be accessed in the following ways:

[0000833444-15-000060:8k_2_02:41]
| • | Live via webcast - through the Investor Relations section of Tyco’s website at http://investors.tyco.com, |

[0000833444-15-000060:8k_2_02:42]
| • | Live via telephone (for “listen-only” participants and those who would like to ask a question) - by dialing 800-857-9797 (in the United States) or 517-308-9029 (outside the United States), passcode “Tyco”, |

[0000833444-15-000060:8k_2_02:43]
| • | Replay via telephone - by dialing 866-353-3070 (in the United States) or 203-369-0090 (outside the United States), passcode 4999, from 10:00 a.m. (ET) on July 31, 2015, until 11:59 p.m. (ET) on August 7, 2015, and |

[0000833444-15-000060:8k_2_02:44]
| • | Replay via webcast - through the “Presentations & Webcasts” link on the Investor Relations section of Tyco’s website: http://investors.tyco.com. |

[0000833444-15-000060:8k_2_02:45]
NON-GAAP MEASURES

[0000833444-15-000060:8k_2_02:46]
Organic revenue, free cash flow (outflow) (FCF), and income from continuing operations, earnings per share (EPS) from continuing operations, operating income and segment operating income, in each case “before special items,” are non-GAAP measures and should not be considered replacements for GAAP results.

[0000833444-15-000060:8k_2_02:47]
Organic revenue is a useful measure used by the company to measure the underlying results and trends in the business. The difference between reported net revenue (the most comparable GAAP measure) and organic revenue (the non-GAAP measure) consists of the impact from foreign currency, acquisitions

[0000833444-15-000060:8k_2_02:48]
and divestitures, and other changes that either do not reflect the underlying results and trends of the Company’s businesses or are not completely under management’s control. There are limitations associated with organic revenue, such as the fact that, as presented herein, the metric may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using organic revenue in combination with the GAAP numbers. Organic revenue may be used as a component in the company’s incentive compensation plans.

[0000833444-15-000060:8k_2_02:49]
FCF is a useful measure of the company's cash that permits management and investors to gain insight into the number that management employs to measure cash that is free from any significant existing obligation and is available to service debt and make investments. The difference between Cash Flows from Operating Activities (the most comparable GAAP measure) and FCF (the non-GAAP measure) consists mainly of significant cash flows that the company believes are useful to identify. It, or a measure that is based on it, may be used as a component in the company's incentive compensation plans. The difference reflects the impact from:

[0000833444-15-000060:8k_2_02:50]
| • | net capital expenditures, |

[0000833444-15-000060:8k_2_02:51]
| • | dealer generated accounts and bulk accounts purchased, |

[0000833444-15-000060:8k_2_02:52]
| • | cash paid for purchase accounting and holdback liabilities, and |

[0000833444-15-000060:8k_2_02:53]
| • | voluntary pension contributions. |

[0000833444-15-000060:8k_2_02:54]
Capital expenditures and dealer generated and bulk accounts purchased are subtracted because they represent long-term investments that are required for normal business activities. Cash paid for purchase accounting and holdback liabilities is subtracted because these cash outflows are not available for general corporate uses. Voluntary pension contributions are added because this activity is driven by economic financing decisions rather than operating activity. In addition, the company presents adjusted free cash flow, which is free cash flow, adjusted to exclude the cash impact of the special items highlighted below. This number provides information to investors regarding the cash impact of certain items management believes are useful to identify, as described below.

[0000833444-15-000060:8k_2_02:55]
The limitation associated with using these cash flow metrics is that they adjust for cash items that are ultimately within management's and the Board of Directors' discretion to direct and therefore may imply that there is less or more cash that is available for the company's programs than the most comparable GAAP measure. Furthermore, these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using FCF in combination with the GAAP cash flow numbers.

[0000833444-15-000060:8k_2_02:56]
The company has presented its income and EPS from continuing operations, operating income and segment operating income before special items. Special items include charges and gains related to divestitures, acquisitions, restructurings, impairments, certain changes to accounting methodologies, legacy legal and tax charges and other income or charges that may mask the underlying operating results and/or business trends of the company or business segment, as applicable. The company utilizes these measures to assess overall operating performance and segment level core operating performance, as well as to provide insight to management in evaluating overall and segment operating plan execution and underlying market conditions. The Company also presents its effective tax rate as adjusted for special items for consistency, and presents corporate expense excluding special items. One or more of these measures may be used as components in the company's incentive compensation plans. These measures are useful for investors because they may permit more meaningful comparisons of the company's underlying operating results and business trends between periods. The difference between income and EPS from continuing operations before special items and income and EPS from continuing operations (the most comparable GAAP measures) consists of the impact of the special items noted above on the applicable GAAP measure. The limitation of these measures is that they exclude the impact (which may be material) of items that increase or decrease the company's reported GAAP metrics, and these non-GAAP metrics may not be comparable to similarly titled measures reported by other

[0000833444-15-000060:8k_2_02:57]
companies. These limitations are best addressed by using the non-GAAP measures in combination with the most comparable GAAP measures in order to better understand the amounts, character and impact of any increase or decrease on reported results.

[0000833444-15-000060:8k_2_02:58]
The company provides general corporate services to its segments and those costs are reported in the "Corporate and Other" segment. This segment's operating income (loss) is presented as "Corporate Expense." Segment Operating Income represents Tyco’s operating income excluding the Corporate and Other segment, and reflects the results of Tyco’s three operating segments. Segment Operating Income before special items reflects GAAP operating income adjusted for the special items noted in the paragraph above.

[0000833444-15-000060:8k_2_02:59]
FORWARD-LOOKING STATEMENTS

[0000833444-15-000060:8k_2_02:60]
# # #

[0000833444-15-000060:8k_2_02:61]
TYCO INTERNATIONAL PLC

[0000833444-15-000060:8k_2_02:62]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0000833444-15-000060:8k_2_02:63]
(in millions, except per share data)

[0000833444-15-000060:8k_2_02:64]
(Unaudited)

[0000833444-15-000060:8k_2_02:65]
|  | Quarters Ended |  | Nine Months Ended |
|  | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Revenue from product sales | $ | 1,511 |  |  | $ | 1,620 |  |  | $ | 4,457 |  |  | $ | 4,550 |  |
| Service revenue | 978 |  |  | 1,040 |  |  | 2,940 |  |  | 3,079 |  |
| Net revenue | 2,489 |  |  | 2,660 |  |  | 7,397 |  |  | 7,629 |  |
| Cost of product sales | 1,025 |  |  | 1,104 |  |  | 3,046 |  |  | 3,105 |  |
| Cost of services | 548 |  |  | 571 |  |  | 1,645 |  |  | 1,721 |  |
| Selling, general and administrative expenses | 625 |  |  | 671 |  |  | 1,925 |  |  | 1,876 |  |
| Separation costs | — |  |  | — |  |  | — |  |  | 1 |  |
| Restructuring and asset impairment charges, net | 38 |  |  | 17 |  |  | 108 |  |  | 27 |  |
| Operating income | 253 |  |  | 297 |  |  | 673 |  |  | 899 |  |
| Interest income | 4 |  |  | 4 |  |  | 11 |  |  | 10 |  |
| Interest expense | (26 | ) |  | (24 | ) |  | (75 | ) |  | (73 | ) |
| Other income (expense), net | 6 |  |  | — |  |  | 9 |  |  | (2 | ) |
| Income from continuing operations before income taxes | 237 |  |  | 277 |  |  | 618 |  |  | 834 |  |
| Income tax expense | (49 | ) |  | (55 | ) |  | (86 | ) |  | (164 | ) |
| Equity income in earnings of unconsolidated subsidiaries | — |  |  | 215 |  |  | — |  |  | 206 |  |
| Income from continuing operations | 188 |  |  | 437 |  |  | 532 |  |  | 876 |  |
| (Loss) income from discontinued operations, net of income taxes | (32 | ) |  | 1,015 |  |  | (50 | ) |  | 1,055 |  |
| Net income | 156 |  |  | 1,452 |  |  | 482 |  |  | 1,931 |  |
| Less: noncontrolling interest in subsidiaries net income (loss) | — |  |  | 2 |  |  | (3 | ) |  | 4 |  |
| Net income attributable to Tyco ordinary shareholders | $ | 156 |  |  | $ | 1,450 |  |  | $ | 485 |  |  | $ | 1,927 |  |
| Amounts attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 188 |  |  | $ | 435 |  |  | $ | 535 |  |  | $ | 872 |  |
| (Loss) income from discontinued operations | (32 | ) |  | 1,015 |  |  | (50 | ) |  | 1,055 |  |
| Net income attributable to Tyco ordinary shareholders | $ | 156 |  |  | $ | 1,450 |  |  | $ | 485 |  |  | $ | 1,927 |  |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 0.45 |  |  | $ | 0.95 |  |  | $ | 1.27 |  |  | $ | 1.89 |  |
| (Loss) income from discontinued operations | (0.08 | ) |  | 2.22 |  |  | (0.12 | ) |  | 2.29 |  |
| Net income attributable to Tyco ordinary shareholders | $ | 0.37 |  |  | $ | 3.17 |  |  | $ | 1.15 |  |  | $ | 4.18 |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 0.44 |  |  | $ | 0.93 |  |  | $ | 1.25 |  |  | $ | 1.86 |  |
| (Loss) income from discontinued operations | (0.07 | ) |  | 2.18 |  |  | (0.11 | ) |  | 2.25 |  |
| Net income attributable to Tyco ordinary shareholders | $ | 0.37 |  |  | $ | 3.11 |  |  | $ | 1.14 |  |  | $ | 4.11 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |  |  |
| Basic | 421 |  |  | 458 |  |  | 421 |  |  | 461 |  |
| Diluted | 427 |  |  | 466 |  |  | 427 |  |  | 469 |  |

[0000833444-15-000060:8k_2_02:66]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed on November 14, 2014 for the fiscal year ended September 26, 2014 and Quarterly Report on Form 10-Q filed on April 24, 2015 for the quarter ended March 27, 2015.

[0000833444-15-000060:8k_2_02:67]
TYCO INTERNATIONAL PLC

[0000833444-15-000060:8k_2_02:68]
RESULTS OF SEGMENTS

[0000833444-15-000060:8k_2_02:69]
(in millions)

[0000833444-15-000060:8k_2_02:70]
(Unaudited)

[0000833444-15-000060:8k_2_02:71]
|  |  | Quarters Ended |  |  |  | Nine Months Ended |  |  |
|  |  | June 26, 2015 |  |  |  | June 27, 2014 |  |  |  | June 26, 2015 |  |  |  | June 27, 2014 |  |  |
| Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Installation & Services |  | $ | 972 |  |  |  |  |  | $ | 968 |  |  |  |  |  | $ | 2,867 |  |  |  |  |  | $ | 2,864 |  |  |  |  |
| ROW Installation & Services |  | 842 |  |  |  |  |  | 999 |  |  |  |  |  | 2,605 |  |  |  |  |  | 2,902 |  |  |  |  |
| Global Products |  | 675 |  |  |  |  |  | 693 |  |  |  |  |  | 1,925 |  |  |  |  |  | 1,863 |  |  |  |  |
| Total Net Revenue |  | $ | 2,489 |  |  |  |  |  | $ | 2,660 |  |  |  |  |  | $ | 7,397 |  |  |  |  |  | $ | 7,629 |  |  |  |  |
| Operating Income and Margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Installation & Services |  | $ | 160 |  |  | 16.5 | % |  | $ | 117 |  |  | 12.1 | % |  | $ | 384 |  |  | 13.4 | % |  | $ | 333 |  |  | 11.6 | % |
| ROW Installation & Services |  | 57 |  |  | 6.8 | % |  | 102 |  |  | 10.2 | % |  | 187 |  |  | 7.2 | % |  | 310 |  |  | 10.7 | % |
| Global Products |  | 108 |  |  | 16.0 | % |  | 136 |  |  | 19.6 | % |  | 316 |  |  | 16.4 | % |  | 329 |  |  | 17.7 | % |
| Corporate and Other |  | (72 | ) |  | N/M |  |  | (58 | ) |  | N/M |  |  | (214 | ) |  | N/M |  |  | (73 | ) |  | N/M |  |
| Operating Income and Margin |  | $ | 253 |  |  | 10.2 | % |  | $ | 297 |  |  | 11.2 | % |  | $ | 673 |  |  | 9.1 | % |  | $ | 899 |  |  | 11.8 | % |

[0000833444-15-000060:8k_2_02:72]
TYCO INTERNATIONAL PLC

[0000833444-15-000060:8k_2_02:73]
CONSOLIDATED BALANCE SHEETS

[0000833444-15-000060:8k_2_02:74]
(in millions)

[0000833444-15-000060:8k_2_02:75]
(Unaudited)

[0000833444-15-000060:8k_2_02:76]
|  |  | June 26, 2015 |  | September 26, 2014 |
| Assets |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 531 |  |  | $ | 892 |  |
| Accounts receivable, net |  | 1,775 |  |  | 1,734 |  |
| Inventories |  | 690 |  |  | 625 |  |
| Prepaid expenses and other current assets |  | 820 |  |  | 1,051 |  |
| Deferred income taxes |  | 304 |  |  | 304 |  |
| Assets held for sale |  | 13 |  |  | 180 |  |
| Total Current Assets |  | 4,133 |  |  | 4,786 |  |
| Property, plant and equipment, net |  | 1,215 |  |  | 1,262 |  |
| Goodwill |  | 4,291 |  |  | 4,122 |  |
| Intangible assets, net |  | 890 |  |  | 712 |  |
| Other assets |  | 1,191 |  |  | 927 |  |
| Total Assets |  | $ | 11,720 |  |  | $ | 11,809 |  |
| Liabilities and Equity |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |
| Loans payable and current maturities of long-term debt |  | $ | 277 |  |  | $ | 20 |  |
| Accounts payable |  | 744 |  |  | 825 |  |
| Accrued and other current liabilities |  | 1,996 |  |  | 2,114 |  |
| Deferred revenue |  | 403 |  |  | 400 |  |
| Liabilities held for sale |  | 6 |  |  | 118 |  |
| Total Current Liabilities |  | 3,426 |  |  | 3,477 |  |
| Long-term debt |  | 1,744 |  |  | 1,443 |  |
| Deferred revenue |  | 313 |  |  | 335 |  |
| Other liabilities |  | 1,898 |  |  | 1,871 |  |
| Total Liabilities |  | 7,381 |  |  | 7,126 |  |
| Redeemable noncontrolling interest in businesses held for sale |  | — |  |  | 13 |  |
| Total Tyco shareholders' equity |  | 4,304 |  |  | 4,647 |  |
| Nonredeemable noncontrolling interest |  | 35 |  |  | 23 |  |
| Total Equity |  | 4,339 |  |  | 4,670 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity |  | $ | 11,720 |  |  | $ | 11,809 |  |

[0000833444-15-000060:8k_2_02:77]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed on November 14, 2014 for the fiscal year ended September 26, 2014 and Quarterly Report on Form 10-Q filed on April 24, 2015 for the quarter ended March 27, 2015.

[0000833444-15-000060:8k_2_02:78]
TYCO INTERNATIONAL PLC

[0000833444-15-000060:8k_2_02:79]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000833444-15-000060:8k_2_02:80]
(in millions)

[0000833444-15-000060:8k_2_02:81]
(Unaudited)

[0000833444-15-000060:8k_2_02:82]
|  |  | For the Quarters Ended |  | For the Nine Months Ended |
|  |  | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Tyco ordinary shareholders |  | $ | 156 |  |  | $ | 1,450 |  |  | $ | 485 |  |  | $ | 1,927 |  |
| Noncontrolling interest in subsidiaries net income (loss) |  | — |  |  | 2 |  |  | (3 | ) |  | 4 |  |
| Income (loss) from discontinued operations, net of income taxes |  | 32 |  |  | (1,015 | ) |  | 50 |  |  | (1,055 | ) |
| Income from continuing operations |  | 188 |  |  | 437 |  |  | 532 |  |  | 876 |  |
| Adjustments to reconcile net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  | 86 |  |  | 88 |  |  | 257 |  |  | 268 |  |
| Non-cash compensation expense |  | 13 |  |  | 17 |  |  | 44 |  |  | 48 |  |
| Deferred income taxes |  | 28 |  |  | 29 |  |  | (1 | ) |  | 85 |  |
| Provision for losses on accounts receivable and inventory |  | 4 |  |  | 9 |  |  | 37 |  |  | 32 |  |
| Legacy legal matters |  | — |  |  | — |  |  | — |  |  | (92 | ) |
| Gains on investments |  | (9 | ) |  | (219 | ) |  | (15 | ) |  | (214 | ) |
| Other non-cash items |  | 2 |  |  | 6 |  |  | 29 |  |  | 18 |  |
| Changes in assets and liabilities, net of the effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (126 | ) |  | (77 | ) |  | (104 | ) |  | (41 | ) |
| Contracts in progress |  | 38 |  |  | (45 | ) |  | 8 |  |  | (50 | ) |
| Inventories |  | (8 | ) |  | 10 |  |  | (72 | ) |  | (14 | ) |
| Prepaid expenses and other assets |  | 19 |  |  | 1 |  |  | (25 | ) |  | (39 | ) |
| Accounts payable |  | 8 |  |  | 64 |  |  | (78 | ) |  | 16 |  |
| Accrued and other liabilities |  | 14 |  |  | (141 | ) |  | (50 | ) |  | (361 | ) |
| Deferred revenue |  | (10 | ) |  | (23 | ) |  | (6 | ) |  | (12 | ) |
| Other |  | 2 |  |  | (4 | ) |  | (45 | ) |  | (2 | ) |
| Net cash provided by operating activities |  | 249 |  |  | 152 |  |  | 511 |  |  | 518 |  |
| Net cash (used in) provided by discontinued operating activities |  | (4 | ) |  | 25 |  |  | (1 | ) |  | 102 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures |  | (59 | ) |  | (75 | ) |  | (183 | ) |  | (210 | ) |
| Proceeds from disposal of assets |  | 1 |  |  | 1 |  |  | 4 |  |  | 7 |  |
| Acquisition of businesses, net of cash acquired |  | — |  |  | (9 | ) |  | (525 | ) |  | (63 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (5 | ) |  | (4 | ) |  | (13 | ) |  | (20 | ) |
| Divestiture of business, net of cash divested |  | (1 | ) |  | — |  |  | (1 | ) |  | — |  |
| Sales and maturities of investments |  | 4 |  |  | 142 |  |  | 283 |  |  | 283 |  |
| Purchases of investments |  | (2 | ) |  | (292 | ) |  | (290 | ) |  | (332 | ) |
| Sale of equity investment |  | — |  |  | 250 |  |  | — |  |  | 250 |  |
| Decrease (increase) in restricted cash |  | 12 |  |  | (5 | ) |  | (27 | ) |  | 1 |  |
| Other |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net cash (used in) provided by investing activities |  | (50 | ) |  | 9 |  |  | (752 | ) |  | (83 | ) |
| Net cash (used in) provided by discontinued investing activities |  | (22 | ) |  | 1,846 |  |  | (37 | ) |  | 1,789 |  |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt |  | — |  |  | 115 |  |  | 258 |  |  | 830 |  |
| Repayment of short-term debt |  | (1 | ) |  | (116 | ) |  | (259 | ) |  | (831 | ) |
| Proceeds from issuance of long-term debt |  | 3 |  |  | — |  |  | 570 |  |  | — |  |
| Proceeds from exercise of share options |  | 13 |  |  | 17 |  |  | 70 |  |  | 79 |  |
| Dividends paid |  | (86 | ) |  | (83 | ) |  | (237 | ) |  | (231 | ) |
| Repurchase of ordinary shares |  | — |  |  | (556 | ) |  | (417 | ) |  | (806 | ) |
| Transfer (to) from discontinued operations |  | (26 | ) |  | 1,871 |  |  | (38 | ) |  | 1,891 |  |
| Payment of contingent consideration |  | — |  |  | — |  |  | (23 | ) |  | — |  |
| Other |  | (1 | ) |  | — |  |  | (26 | ) |  | (10 | ) |
| Net cash (used in) provided by financing activities |  | (98 | ) |  | 1,248 |  |  | (102 | ) |  | 922 |  |
| Net cash provided by (used in) discontinued financing activities |  | 26 |  |  | (1,871 | ) |  | 38 |  |  | (1,891 | ) |
| Effect of currency translation on cash |  | (2 | ) |  | 8 |  |  | (18 | ) |  | (8 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 99 |  |  | 1,417 |  |  | (361 | ) |  | 1,349 |  |
| Cash and cash equivalents at beginning of period |  | 432 |  |  | 495 |  |  | 892 |  |  | 563 |  |
| Cash and cash equivalents at end of period |  | $ | 531 |  |  | $ | 1,912 |  |  | $ | 531 |  |  | $ | 1,912 |  |

[0000833444-15-000060:8k_2_02:83]
| Reconciliation to "Free Cash Flow": |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 249 |  |  | $ | 152 |  |  | $ | 511 |  |  | $ | 518 |  |
| Capital expenditures, net |  | (59 | ) |  | (74 | ) |  | (179 | ) |  | (203 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (5 | ) |  | (4 | ) |  | (13 | ) |  | (20 | ) |
| Payment of contingent consideration |  | 1 |  |  | — |  |  | (23 | ) |  | — |  |
| Free Cash Flow |  | $ | 186 |  |  | $ | 74 |  |  | $ | 296 |  |  | $ | 295 |  |
| Reconciliation to "Adjusted Free Cash Flow": |  |  |  |  |  |  |  |  |
| CIT settlement |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (17 | ) |
| IRS litigation costs |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Separation costs |  | — |  |  | 27 |  |  | 3 |  |  | 71 |  |
| Restructuring and repositioning costs |  | 48 |  |  | 23 |  |  | 119 |  |  | 79 |  |
| Environmental remediation payments |  | (1 | ) |  | 6 |  |  | 7 |  |  | 60 |  |
| Legal settlements |  | (4 | ) |  | 6 |  |  | (16 | ) |  | 6 |  |
| Net asbestos payments |  | — |  |  | 6 |  |  | 8 |  |  | 13 |  |
| Tax related separation costs and other tax matters |  | — |  |  | 147 |  |  | — |  |  | 149 |  |
| Cash payment from ADT Resi / Pentair |  | — |  |  | 19 |  |  | 1 |  |  | 30 |  |
| Acquisition / integration costs |  | 1 |  |  | — |  |  | 4 |  |  | — |  |
| Special Items |  | $ | 44 |  |  | $ | 234 |  |  | $ | 126 |  |  | $ | 392 |  |
| Adjusted Free Cash Flow |  | $ | 230 |  |  | $ | 308 |  |  | $ | 422 |  |  | $ | 687 |  |

[0000833444-15-000060:8k_2_02:84]
Note: Free cash flow is a non-GAAP measure.  See description of non-GAAP measures contained in this release.

[0000833444-15-000060:8k_2_02:85]
TYCO INTERNATIONAL PLC

[0000833444-15-000060:8k_2_02:86]
ORGANIC GROWTH RECONCILIATION - REVENUE

[0000833444-15-000060:8k_2_02:87]
(in millions)

[0000833444-15-000060:8k_2_02:88]
(Unaudited)

[0000833444-15-000060:8k_2_02:89]
|  |  |  |  | Quarter Ended June 26, 2015 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Quarter Ended June 27, 2014 |  | Adjustments |  | Adjusted Fiscal 2014 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Quarter Ended June 26, 2015 |
|  |  |  | Divestitures / Other |  |  | Foreign Currency |  | Acquisitions |  | Organic Revenue(1) |  |
| NA Installation & Services |  | $ | 968 |  |  | $ | — |  |  | — | % |  | $ | 968 |  |  | $ | (12 | ) |  | (1.2 | )% |  | $ | 3 |  |  | 0.3 | % |  | $ | 13 |  |  | 1.3 | % |  | $ | 972 |  |  | 0.4 | % |
| ROW Installation & Services |  | 999 |  |  | (21 | ) |  | (2.1 | )% |  | 978 |  |  | (126 | ) |  | (12.6 | )% |  | 11 |  |  | 1.1 | % |  | (21 | ) |  | (2.1 | )% |  | 842 |  |  | (15.7 | )% |
| Global Products |  | 693 |  |  | — |  |  | — | % |  | 693 |  |  | (45 | ) |  | (6.5 | )% |  | 49 |  |  | 7.1 | % |  | (22 | ) |  | (3.2 | )% |  | 675 |  |  | (2.6 | )% |
| Total Net Revenue |  | $ | 2,660 |  |  | $ | (21 | ) |  | (0.8 | )% |  | $ | 2,639 |  |  | $ | (183 | ) |  | (6.9 | )% |  | $ | 63 |  |  | 2.4 | % |  | $ | (30 | ) |  | (1.1 | )% |  | $ | 2,489 |  |  | (6.4 | )% |

[0000833444-15-000060:8k_2_02:90]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2014 base revenue. |

[0000833444-15-000060:8k_2_02:91]
|  |  |  |  | Nine Months Ended June 26, 2015 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Nine Months Ended June 27, 2014 |  | Adjustments |  | Adjusted Fiscal 2014 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Nine Months Ended June 26, 2015 |
|  |  |  | Divestitures / Other |  |  | Foreign Currency |  | Acquisitions |  |  | Organic Revenue (1) |  |
| NA Installation & Services |  | $ | 2,864 |  |  | $ | — |  |  | — | % |  | $ | 2,864 |  |  | $ | (33 | ) |  | (1.2 | )% |  | $ | 9 |  |  | 0.3 | % |  |  | $ | 27 |  |  | 0.9 | % |  | $ | 2,867 |  |  | 0.1 | % |
| ROW Installation & Services |  | 2,902 |  |  | (34 | ) |  | (1.2 | )% |  | 2,868 |  |  | (289 | ) |  | (10.0 | )% |  | 44 |  |  | 1.5 | % |  |  | (18 | ) |  | (0.6 | )% |  | 2,605 |  |  | (10.2 | )% |
| Global Products |  | 1,863 |  |  | — |  |  | — | % |  | 1,863 |  |  | (99 | ) |  | (5.3 | )% |  | 80 |  |  | 4.3 | % |  |  | 81 |  |  | 4.3 | % |  | 1,925 |  |  | 3.3 | % |
| Total Net Revenue |  | $ | 7,629 |  |  | $ | (34 | ) |  | (0.4 | )% |  | $ | 7,595 |  |  | $ | (421 | ) |  | (5.5 | )% |  | $ | 133 |  |  | 1.7 | % |  |  | $ | 90 |  |  | 1.2 | % |  | $ | 7,397 |  |  | (3.0 | )% |

[0000833444-15-000060:8k_2_02:92]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2014 base revenue. |

[0000833444-15-000060:8k_2_02:93]
Earnings Per Share Summary

[0000833444-15-000060:8k_2_02:94]
(Unaudited)

[0000833444-15-000060:8k_2_02:95]
|  |  | Quarter Ended |  | Quarter Ended |
|  |  | June 26, 2015 |  | June 27, 2014 |
| Diluted EPS from Continuing Operations Attributable to Tyco Shareholders (GAAP) |  | $ | 0.44 |  |  | $ | 0.93 |  |
| expense / (benefit) |  |  |  |  |
| Restructuring and repositioning activities |  | 0.14 |  |  | 0.05 |  |
| Separation costs included in SG&A |  | — |  |  | 0.02 |  |
| (Gains) / losses on divestitures, net included in SG&A |  | (0.01 | ) |  | — |  |
| Settlement with former management |  | — |  |  | (0.01 | ) |
| Asbestos |  | 0.02 |  |  | (0.01 | ) |
| Tax items |  | — |  |  | 0.02 |  |
| Gain on sale of Atkore divestiture |  | — |  |  | (0.46 | ) |
| Total Before Special Items |  | $ | 0.59 |  |  | $ | 0.54 |  |

[0000833444-15-000060:8k_2_02:96]
Tyco International plc

[0000833444-15-000060:8k_2_02:97]
For the Quarter Ended June 26, 2015

[0000833444-15-000060:8k_2_02:98]
(in millions, except per share data)

[0000833444-15-000060:8k_2_02:99]
(Unaudited)

[0000833444-15-000060:8k_2_02:100]
expense / (benefit)

[0000833444-15-000060:8k_2_02:101]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $972 |  |  |  |  |  | $842 |  |  |  |  |  | $675 |  |  |  |  |  | $2,489 |  |  |  |  |  | $— |  |  |  |  |  | $2,489 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other Income, net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $160 |  |  | 16.5 | % |  |  | $57 |  |  | 6.8 | % |  |  | $108 |  |  | 16.0 | % |  |  | $325 |  |  | 13.1 | % |  |  | ($72 | ) |  | N/M |  |  | $253 |  |  | 10.2 | % |  |  | ($22 | ) |  |  | $6 |  |  |  | ($49 | ) |  |  | $— |  |  |  | $— |  |  |  | $188 |  |  | $0.44 |  |
| Restructuring and repositioning activities |  | (3 | ) |  |  |  | 40 |  |  |  |  | 5 |  |  |  |  | 42 |  |  |  |  | 23 |  |  |  |  | 65 |  |  |  |  |  |  |  |  | (12 | ) |  |  |  |  |  | 53 |  | 0.14 |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  | (5 | ) |  |  |  | 1 |  |  |  |  | (4 | ) |  |  |  |  |  |  |  | (4 | ) |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  | (3 | ) | (0.01 | ) |
| Acquisition / integration costs |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | 1 |  | — |  |
| Settlement with former management |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (2 | ) |  |  |  | (2 | ) |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  | (1 | ) | — |  |
| Amortization of inventory step-up |  |  |  |  |  |  |  |  |  | 3 |  |  |  |  | 3 |  |  |  |  |  |  |  |  | 3 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | 2 |  | — |  |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 9 |  |  |  |  |  |  | 10 |  | 0.02 |  |
| Amortization of acquired backlog |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Total Before Special Items |  |  | $157 |  |  | 16.2 | % |  |  | $93 |  |  | 11.0 | % |  |  | $119 |  |  | 17.6 | % |  |  | $369 |  |  | 14.8 | % |  |  | ($50 | ) |  | N/M |  |  | $319 |  |  | 12.8 | % |  |  | ($22 | ) |  |  | $6 |  |  |  | ($52 | ) |  |  | $— |  |  |  | $— |  |  |  | $251 |  |  | $0.59 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 427 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 427 |  |

[0000833444-15-000060:8k_2_02:102]
Tyco International plc

[0000833444-15-000060:8k_2_02:103]
For the Quarter Ended June 27, 2014

[0000833444-15-000060:8k_2_02:104]
(in millions, except per share data)

[0000833444-15-000060:8k_2_02:105]
(Unaudited)

[0000833444-15-000060:8k_2_02:106]
expense / (benefit)

[0000833444-15-000060:8k_2_02:107]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $968 |  |  |  |  |  | $999 |  |  |  |  |  | $693 |  |  |  |  |  | $2,660 |  |  |  |  |  | $— |  |  |  |  |  | $2,660 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $117 |  |  | 12.1 | % |  |  | $102 |  |  | 10.2 | % |  |  | $136 |  |  | 19.6 | % |  |  | $355 |  |  | 13.3 | % |  |  | ($58 | ) |  | N/M |  |  | $297 |  |  | 11.2 | % |  |  | ($20 | ) |  |  | $— |  |  |  | ($55 | ) |  |  | $215 |  |  |  | ($2 | ) |  |  | $435 |  |  | $0.93 |  |
| Restructuring and repositioning activities |  | 6 |  |  |  |  | 11 |  |  |  |  | 3 |  |  |  |  | 20 |  |  |  |  | 10 |  |  |  |  | 30 |  |  |  |  |  |  |  |  | (9 | ) |  |  |  |  |  | 21 |  | 0.05 |  |
| Separation costs included in SG&A |  | 11 |  |  |  |  |  |  |  |  |  |  |  |  | 11 |  |  |  |  |  |  |  |  | 11 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | 10 |  | 0.02 |  |
| Acquisition / integration costs |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Settlement with former management |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (4 | ) |  |  |  | (4 | ) |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  | (3 | ) | (0.01 | ) |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (6 | ) |  |  |  | (6 | ) |  |  |  |  |  |  |  | 3 |  |  |  |  |  |  | (3 | ) | (0.01 | ) |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 9 |  |  |  |  |  |  | 9 |  | 0.02 |  |
| Gain on sale of Atkore divestiture |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (216 | ) |  |  |  | (216 | ) | (0.46 | ) |
| Total Before Special Items |  |  | $134 |  |  | 13.8 | % |  |  | $113 |  |  | 11.3 | % |  |  | $140 |  |  | 20.2 | % |  |  | $387 |  |  | 14.5 | % |  |  | ($58 | ) |  | N/M |  |  | $329 |  |  | 12.4 | % |  |  | ($20 | ) |  |  | $— |  |  |  | ($52 | ) |  |  | ($1 | ) |  |  | ($2 | ) |  |  | $254 |  |  | $0.54 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 466 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 466 |  |
