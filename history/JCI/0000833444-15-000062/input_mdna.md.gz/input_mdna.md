# JCI MD&A — 0000833444-15-000062


## mdna

[0000833444-15-000062:mdna:1]
[same as prior period, unchanged from 0000833444-15-000032:mdna:1]

[0000833444-15-000062:mdna:2]
[same as prior period, unchanged from 0000833444-15-000032:mdna:2]

[0000833444-15-000062:mdna:3]
[same as prior period, unchanged from 0000833444-15-000032:mdna:3]

[0000833444-15-000062:mdna:4]
[same as prior period, unchanged from 0000833444-15-000032:mdna:4]

[0000833444-15-000062:mdna:5]
References to 2015 and 2014 are to Tyco's fiscal quarters ending June 26, 2015 and June 27, 2014, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September. Fiscal years 2015 and 2014 are both 52-week years.

[0000833444-15-000062:mdna:6]
[same as prior period, unchanged from 0000833444-15-000032:mdna:6]

[0000833444-15-000062:mdna:7]
[same as prior period, unchanged from 0000833444-15-000032:mdna:7]

[0000833444-15-000062:mdna:8]
[same as prior period, unchanged from 0000833444-15-000032:mdna:8]

[0000833444-15-000062:mdna:9]
[same as prior period, unchanged from 0000833444-15-000032:mdna:9]

[0000833444-15-000062:mdna:10]
[same as prior period, unchanged from 0000833444-15-000032:mdna:10]

[0000833444-15-000062:mdna:11]
[same as prior period, unchanged from 0000833444-15-000032:mdna:11]

[0000833444-15-000062:mdna:12]
[same as prior period, unchanged from 0000833444-15-000032:mdna:12]

[0000833444-15-000062:mdna:13]
Certain prior period amounts have been reclassified to conform with current period presentation. During the quarter ended June 26, 2015, the Company sold three businesses in the Rest of World ("ROW") Installation & Services segment.  The assets and liabilities related to these businesses were classified as held for sale of as September 26, 2014, and the results of operations of two of these businesses are included in discontinued operations for all periods presented, as the criteria to be presented as a discontinued operation were not satisfied for the third business.  The Company expects to complete the sale of another of its ROW Installation & Services businesses during the first half of fiscal 2016.  The assets and liabilities of this business are classified as held for sale, and its results of operations are presented as discontinued operations for all periods presented.  See Note 3 to our unaudited Consolidated Financial Statements.

[0000833444-15-000062:mdna:14]
[same as prior period, unchanged from 0000833444-15-000032:mdna:15]

[0000833444-15-000062:mdna:15]
We are a leading global provider of security products and services, fire detection and suppression products and services and life safety products. We utilize our extensive global footprint of approximately 900 locations, including manufacturing facilities, service and distribution centers, monitoring centers and sales offices, to provide solutions and localized expertise to our global customer base. We provide an extensive range of product and service offerings to over 3 million customers in more than 100 countries through multiple channels. Our revenues are broadly diversified across the United States and Canada (collectively “North America”); Central America and South America (collectively “Latin America”); Europe, the Middle East, and Africa (collectively “EMEA”) and the Asia-Pacific geographic areas. The following chart reflects our net revenue by geographic area for the nine months ended June 26, 2015.

[0000833444-15-000062:mdna:16]
Nine Months Ended June 26, 2015

[0000833444-15-000062:mdna:17]
[same as prior period, unchanged from 0000833444-15-000032:mdna:18]

[0000833444-15-000062:mdna:18]
[same as prior period, unchanged from 0000833444-15-000032:mdna:19]

[0000833444-15-000062:mdna:19]
[same as prior period, unchanged from 0000833444-15-000032:mdna:20]

[0000833444-15-000062:mdna:20]
[same as prior period, unchanged from 0000833444-15-000032:mdna:21]

[0000833444-15-000062:mdna:21]
[same as prior period, unchanged from 0000833444-15-000032:mdna:22]

[0000833444-15-000062:mdna:22]
[same as prior period, unchanged from 0000833444-15-000032:mdna:23]

[0000833444-15-000062:mdna:23]
[same as prior period, unchanged from 0000833444-15-000032:mdna:24]

[0000833444-15-000062:mdna:24]
[same as prior period, unchanged from 0000833444-15-000032:mdna:26]

[0000833444-15-000062:mdna:25]
[same as prior period, unchanged from 0000833444-15-000032:mdna:25]

[0000833444-15-000062:mdna:26]
[same as prior period, unchanged from 0000833444-15-000032:mdna:27]

[0000833444-15-000062:mdna:27]
Because we are a global business, with approximately 50% of our revenue generated outside the United States, and because our financial statements are prepared in U.S. Dollars, our results of operations are impacted by changes in foreign currency exchange rates. In recent months, the U.S. Dollar has remained strong against the currencies of most of the significant non-U.S. jurisdictions where we operate. The most significant drop has been in the Euro, which decreased to a recent low of approximately EUR 1.05 per 1.00 U.S. Dollar from approximately EUR 1.26 at the beginning of our fiscal year. The significant strengthening of the U.S. Dollar has negatively impacted our revenue and operating income during the first nine months of fiscal 2015 and is expected to continue to do so during the remainder of fiscal 2015. In addition, the Company sells its products and services into the petrochemical, oil and gas market. Revenue from this market vertical is spread across each of the Company’s segments, with the most significant exposure in the United Kingdom in the ROW Installation & Services segment and in the Fire Protection Products business in the Global Products segment. As a result of recent declines in oil prices, this market vertical has seen significant changes in spending patterns, in particular with respect to capital expenditures. Based on activity in the second and third fiscal quarters, the Company expects the revenue tied to this market vertical to be negatively impacted during the fiscal year.

[0000833444-15-000062:mdna:28]
[same as prior period, unchanged from 0000833444-15-000032:mdna:29]

[0000833444-15-000062:mdna:29]
[same as prior period, unchanged from 0000833444-15-000032:mdna:30]

[0000833444-15-000062:mdna:30]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Net revenue | $ | 2,489 |  |  | $ | 2,660 |  |  | $ | 7,397 |  |  | $ | 7,629 |  |
| Net revenue decline | (6.4 | )% |  | N/A |  |  | (3.0 | )% |  | N/A |  |
| Organic revenue (decline) growth | (1.1 | )% |  | N/A |  |  | 1.2 | % |  | N/A |  |
| Operating income | $ | 253 |  |  | $ | 297 |  |  | $ | 673 |  |  | $ | 899 |  |
| Operating margin | 10.2 | % |  | 11.2 | % |  | 9.1 | % |  | 11.8 | % |
| Interest income | $ | 4 |  |  | $ | 4 |  |  | $ | 11 |  |  | $ | 10 |  |
| Interest expense | (26 | ) |  | (24 | ) |  | (75 | ) |  | (73 | ) |
| Other income (expense), net | 6 |  |  | — |  |  | 9 |  |  | (2 | ) |
| Income tax expense | (49 | ) |  | (55 | ) |  | (86 | ) |  | (164 | ) |
| Equity income in earnings of unconsolidated subsidiaries | — |  |  | 215 |  |  | — |  |  | 206 |  |
| Income from continuing operations attributable to Tyco ordinary shareholders | 188 |  |  | 435 |  |  | 535 |  |  | 872 |  |

[0000833444-15-000062:mdna:31]
[same as prior period, unchanged from 0000833444-15-000032:mdna:32]

[0000833444-15-000062:mdna:32]
Net revenue for the quarter ended June 26, 2015 decreased by $171 million, or 6.4%, to $2,489 million as compared to net revenue of $2,660 million for the quarter ended June 27, 2014.  Changes in foreign currency exchange rates had an unfavorable impact of $183 million, or 6.9%, on net revenue, primarily in our ROW Installation & Services segment, and to a lesser extent, in our Global Products segment.  On an organic basis, net revenue declined by $30 million, or 1.1%, year over year, primarily as a result of declines in our Global Products and ROW Installation & Services segments, partially offset by revenue growth in our NA Installation & Services segment.  Net revenue was favorably impacted by acquisitions that contributed $63 million, or 2.4%, primarily within our Global Products and ROW Installation & Services segment.

[0000833444-15-000062:mdna:33]
Net revenue for the nine months ended June 26, 2015 decreased by $232 million, or 3.0%, to $7,397 million as compared to net revenue of $7,629 million for the nine months ended June 27, 2014.  Changes in foreign currency exchange rates had an

[0000833444-15-000062:mdna:34]
unfavorable impact of $421 million, or 5.5%, on net revenue, primarily in our ROW Installation & Services segment, and to a lesser extent, in our Global Products and NA Installation & Services segments. Net revenue was also unfavorably impacted by divestitures of $34 million, or 0.4%, in our ROW Installation & Services segment, but was partially offset by the favorable impact of acquisitions, which contributed $133 million, or 1.7%, within our ROW Installation & Services and Global Products segments.  On an organic basis, net revenue grew by $90 million, or 1.2%, year over year, primarily as a result of revenue growth in our Global Products segment.

[0000833444-15-000062:mdna:35]
Cost of Revenue

[0000833444-15-000062:mdna:36]
The significant components of cost of product sales include material costs, labor and overhead costs, product shipping and warehousing costs. The significant components of cost of services include labor and employee related costs, depreciation expense, costs associated with our equipment and fleet of vehicles, telecommunication costs and material costs. The significant components of SG&A include compensation and compensation related costs, facility and maintenance expenses and professional fees.

[0000833444-15-000062:mdna:37]
[same as prior period, unchanged from 0000833444-15-000032:mdna:36]

[0000833444-15-000062:mdna:38]
Operating income for the quarter ended June 26, 2015 decreased by $44 million, or 14.8%, to $253 million, as compared to operating income of $297 million for the quarter ended June 27, 2014.  This decline is primarily due to a $35 million increase in restructuring and repositioning charges as compared to the prior year period.  In addition, changes in foreign currency exchange rates had an unfavorable impact on operating income of $10 million.  These items were offset by benefits from sourcing, productivity and restructuring activities as well as an $11 million decrease in separation costs.

[0000833444-15-000062:mdna:39]
Operating income for the nine months ended June 26, 2015 decreased by $226 million, or 25.1%, to $673 million, as compared to operating income of $899 million for the nine months ended June 27, 2014.  This decline is primarily due to a reversal of a compensation reserve of $92 million for the settlement of legacy litigation with former management, a non-recurring $21 million insurance recovery, and a gain of $16 million related to a legal settlement with CIT Group in the comparable period.  Operating income was also unfavorably impacted by a $114 million increase in restructuring and repositioning charges, as well as a $21 million increase in loss on divestitures.  In addition, changes in foreign currency exchange rates had an unfavorable impact on operating income of $34 million.  These items were offset by benefits from sourcing, productivity and cost-containment initiatives, and restructuring activities as well as a $40 million decrease in separation costs.

[0000833444-15-000062:mdna:40]
Key items impacting operating income for the quarters and nine months ended June 26, 2015 and June 27, 2014, respectively, are as follows:

[0000833444-15-000062:mdna:41]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Legacy legal gains | $ | (2 | ) |  | $ | (4 | ) |  | $ | (8 | ) |  | $ | (96 | ) |
| CIT settlement gain | — |  |  | — |  |  | — |  |  | (16 | ) |
| Separation costs | — |  |  | 11 |  |  | 2 |  |  | 42 |  |
| Loss on sale of investment | — |  |  | — |  |  | — |  |  | 7 |  |
| Restructuring and repositioning charges, net | 65 |  |  | 30 |  |  | 169 |  |  | 55 |  |
| (Gain) loss on divestitures | (4 | ) |  | — |  |  | 19 |  |  | (2 | ) |
| China insurance recovery | — |  |  | — |  |  | — |  |  | (21 | ) |
| Asbestos related charges (gains) | 1 |  |  | (6 | ) |  | 7 |  |  | (5 | ) |
| Impact of foreign currency | 10 |  |  | 2 |  |  | 34 |  |  | 11 |  |

[0000833444-15-000062:mdna:42]
We continue to identify and pursue opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across our businesses. Additionally, we initiated certain global actions designed to reduce our cost structure and improve future profitability by streamlining operations and better aligning functions, which we refer to as repositioning actions. The Company expects to incur approximately $225 million of restructuring and repositioning charges in fiscal 2015. See Note 4 to our unaudited Consolidated Financial Statements.

[0000833444-15-000062:mdna:43]
[same as prior period, unchanged from 0000833444-15-000032:mdna:42]

[0000833444-15-000062:mdna:44]
Interest income was $4 million for both quarters ended June 26, 2015 and June 27, 2014.  Interest income was $11 million and $10 million for the nine months ended June 26, 2015 and June 27, 2014, respectively.

[0000833444-15-000062:mdna:45]
Interest expense was $26 million and $24 million for the quarters ended June 26, 2015 and June 27, 2014, respectively.  Interest expense was $75 million and $73 million for the nine months ended June 26, 2015 and June 27, 2014, respectively.

[0000833444-15-000062:mdna:46]
Other Income (Expense), net

[0000833444-15-000062:mdna:47]
Other income of $6 million for the quarter ended June 26, 2015 was primarily comprised of a $5 million gain related to the sale of assets, as well as an unrealized gain on trading securities.  Other income was nil for the quarter ended June 27, 2014.

[0000833444-15-000062:mdna:48]
Other income of $9 million for the nine months ended June 26, 2015 was primarily comprised of a $5 million gain related to the sale of assets, as well as an unrealized gain on trading securities, partially offset by a net loss related to the 2012 Tax Sharing Agreement.  Other expense of $2 million for the nine months ended June 27, 2014 primarily related to a net loss on the 2012 Tax Sharing Agreement activity.

[0000833444-15-000062:mdna:49]
[same as prior period, unchanged from 0000833444-15-000032:mdna:48]

[0000833444-15-000062:mdna:50]
Our effective income tax rate was 20.7% and 19.9% during the quarters ended June 26, 2015 and June 27, 2014, respectively.  The current period rate represents the Company's geographic mix of income and non-recurring tax charges.

[0000833444-15-000062:mdna:51]
Our effective income tax rate was 13.9% and 19.7% during the nine months ended June 26, 2015 and June 27, 2014, respectively. The decrease in our effective tax rate in the current period was primarily due to a decrease in valuation allowances on the basis of management's reassessment of the amount of its deferred tax assets that are more likely than not to be realized resulting from the impact of restructuring actions and tax law changes in a non-U.S. jurisdiction.  In addition, income from a non-recurring reversal of a compensation reserve established in respect of legacy litigation with former management generated increased tax expense during the prior period.

[0000833444-15-000062:mdna:52]
[same as prior period, unchanged from 0000833444-15-000032:mdna:51]

[0000833444-15-000062:mdna:53]
Equity Gain in Earnings of Unconsolidated Subsidiaries

[0000833444-15-000062:mdna:54]
Equity gain in earnings of unconsolidated subsidiaries of $215 million and $206 million for the quarter and nine months ended June 27, 2014, respectively, reflects our share of Atkore International Group Inc.'s ("Atkore") net gain or loss, which was accounted for under the equity method of accounting.  On April 9, 2014, Atkore redeemed all of our common equity stake in Atkore.

[0000833444-15-000062:mdna:55]
49

[0000833444-15-000062:mdna:56]
[same as prior period, unchanged from 0000833444-15-000032:mdna:54]

[0000833444-15-000062:mdna:57]
The following chart reflects our net revenue by operating segment, as well as the percent of net revenue by operating segment, for the quarters and nine months ended June 26, 2015 and June 27, 2014, respectively.

[0000833444-15-000062:mdna:58]
[same as prior period, unchanged from 0000833444-15-000032:mdna:56]

[0000833444-15-000062:mdna:59]
[same as prior period, unchanged from 0000833444-15-000032:mdna:57]

[0000833444-15-000062:mdna:60]
Financial information for NA Installation & Services for the quarters and nine months ended June 26, 2015 and June 27, 2014 is as follows:

[0000833444-15-000062:mdna:61]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Net revenue | $ | 972 |  |  | $ | 968 |  |  | $ | 2,867 |  |  | $ | 2,864 |  |
| Net revenue growth | 0.4 | % |  | N/A |  |  | 0.1 | % |  | N/A |  |
| Organic revenue growth | 1.3 | % |  | N/A |  |  | 0.9 | % |  | N/A |  |
| Operating income | $ | 160 |  |  | $ | 117 |  |  | $ | 384 |  |  | $ | 333 |  |
| Operating margin | 16.5 | % |  | 12.1 | % |  | 13.4 | % |  | 11.6 | % |

[0000833444-15-000062:mdna:62]
[same as prior period, unchanged from 0000833444-15-000032:mdna:60]

[0000833444-15-000062:mdna:63]
[same as prior period, unchanged from 0000833444-15-000032:mdna:61]

[0000833444-15-000062:mdna:64]
[same as prior period, unchanged from 0000833444-15-000032:mdna:62]

[0000833444-15-000062:mdna:65]
| Factors Contributing to Year-Over-Year Change |  | Third QuarterFiscal 2015 Compared toThird QuarterFiscal 2014 |  | Year to Date Fiscal 2015 Compared to Year to Date Fiscal 2014 |
| Organic revenue growth |  | $ | 13 |  |  | $ | 27 |  |
| Acquisitions |  | 3 |  |  | 9 |  |
| Impact of foreign currency |  | (12 | ) |  | (33 | ) |
| Total change |  | $ | 4 |  |  | $ | 3 |  |

[0000833444-15-000062:mdna:66]
Net revenue increased $4 million, or 0.4%, to $972 million for the quarter ended June 26, 2015 as compared to $968 million for the quarter ended June 27, 2014. On an organic basis, net revenue grew by 1.3% from the comparable quarter, with growth in installation revenue, while service revenue remained unchanged.  Net revenue was also favorably impacted by $3 million, or 0.3%, due to several small acquisitions made during the first six months of fiscal 2015.  Changes in foreign currency exchange rates unfavorably impacted net revenue by $12 million, or 1.2%.

[0000833444-15-000062:mdna:67]
Net revenue increased $3 million, or 0.1%, to $2,867 million for the nine months ended June 26, 2015 as compared to $2,864 million for the nine months ended June 27, 2014.  Changes in foreign currency exchange rates unfavorably impacted net revenue by $33 million, or 1.2%.  On an organic basis, net revenue grew by 0.9% from the comparable period, as service revenue increased and installation revenue was flat.  Net revenue was favorably impacted by $9 million, or 0.3%, due to the acquisition of Westfire in the first quarter of fiscal 2014 and several small acquisitions made during the first six months of fiscal 2015.

[0000833444-15-000062:mdna:68]
[same as prior period, unchanged from 0000833444-15-000032:mdna:66]

[0000833444-15-000062:mdna:69]
Operating income for the quarter ended June 26, 2015 increased $43 million, or 36.8%, to $160 million, as compared to operating income of $117 million for the quarter ended June 27, 2014.  This increase was primarily due to an $11 million decline in separation costs, a decline of $9 million in restructuring and repositioning activities, and cost-containment initiatives during the quarter.  Operating income for the quarter also benefited from previous productivity and restructuring actions.

[0000833444-15-000062:mdna:70]
Operating income for the nine months ended June 26, 2015 increased $51 million, or 15.3%, to $384 million, as compared to operating income of $333 million for the nine months ended June 27, 2014.  The benefits of previous productivity and restructuring actions and a $38 million decline in separation costs was partially offset by an increase of $20 million in restructuring and repositioning activities.

[0000833444-15-000062:mdna:71]
Key items impacting operating income for the quarters and nine months ended June 26, 2015 and June 27, 2014, respectively, are as follows:

[0000833444-15-000062:mdna:72]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Separation costs | $ | — |  |  | $ | 11 |  |  | $ | 2 |  |  | $ | 40 |  |
| Restructuring and repositioning (gains) charges, net | (3 | ) |  | 6 |  |  | 27 |  |  | 7 |  |

[0000833444-15-000062:mdna:73]
[same as prior period, unchanged from 0000833444-15-000032:mdna:71]

[0000833444-15-000062:mdna:74]
Financial information for ROW Installation & Services for the quarters and nine months ended June 26, 2015 and June 27, 2014 is as follows:

[0000833444-15-000062:mdna:75]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Net revenue | $ | 842 |  |  | $ | 999 |  |  | $ | 2,605 |  |  | $ | 2,902 |  |
| Net revenue decline | (15.7 | )% |  | N/A |  |  | (10.2 | )% |  | N/A |  |
| Organic revenue decline | (2.1 | )% |  | N/A |  |  | (0.6 | )% |  | N/A |  |
| Operating income | $ | 57 |  |  | $ | 102 |  |  | $ | 187 |  |  | $ | 310 |  |
| Operating margin | 6.8 | % |  | 10.2 | % |  | 7.2 | % |  | 10.7 | % |

[0000833444-15-000062:mdna:76]
[same as prior period, unchanged from 0000833444-15-000032:mdna:74]

[0000833444-15-000062:mdna:77]
[same as prior period, unchanged from 0000833444-15-000032:mdna:75]

[0000833444-15-000062:mdna:78]
| Factors Contributing to Year-Over-Year Change |  | Third QuarterFiscal 2015Compared toThird QuarterFiscal 2014 |  | Year to Date Fiscal 2015 Compared to Year to Date Fiscal 2014 |
| Organic revenue decline |  | $ | (21 | ) |  | $ | (18 | ) |
| Acquisitions |  | 11 |  |  | 44 |  |
| Divestitures |  | (21 | ) |  | (34 | ) |
| Impact of foreign currency |  | (126 | ) |  | (289 | ) |
| Total change |  | $ | (157 | ) |  | $ | (297 | ) |

[0000833444-15-000062:mdna:79]
Net revenue decreased $157 million, or 15.7%, to $842 million for the quarter ended June 26, 2015 as compared to $999 million for the quarter ended June 27, 2014. Changes in foreign currency exchange rates unfavorably impacted net revenue by $126 million, or 12.6%.  On an organic basis, net revenue declined by $21 million, or 2.1%, primarily in the United Kingdom and the Pacific region as a result of pressure within the oil and gas and mining industries.  These declines were partially offset by growth in our growth markets and to a lesser extent, Continental Europe.  Net revenue was favorably impacted by $11 million, or 1.1%, due to acquisitions within growth markets, Continental Europe and the United Kingdom.

[0000833444-15-000062:mdna:80]
Net revenue decreased $297 million, or 10.2%, to $2,605 million for the nine months ended June 26, 2015 as compared to $2,902 million for the nine months ended June 27, 2014.  Changes in foreign currency exchange rates unfavorably impacted net revenue by $289 million, or 10.0%.  Net revenue was also unfavorably impacted by $34 million, or 1.2%, due to the divestiture of our Armourguard business in New Zealand and fire and security business in Fiji in the first quarter of fiscal 2014. On an organic basis, revenue decreased by $18 million, or 0.6%, as declines in the United Kingdom and our Pacific region, due to pressure within the oil and gas and mining industries, were partially offset by growth in growth markets and to a lesser extent, Continental Europe.  Net revenue was favorably impacted by $44 million, or 1.5%, primarily due to acquisitions within growth markets, Continental Europe, and the United Kingdom.

[0000833444-15-000062:mdna:81]
[same as prior period, unchanged from 0000833444-15-000032:mdna:79]

[0000833444-15-000062:mdna:82]
Operating income for the quarter ended June 26, 2015 decreased $45 million, or 44.1%, to $57 million as compared to operating income of $102 million for the quarter ended June 27, 2014.  Operating income was unfavorably impacted by a $29 million increase in restructuring and repositioning charges, and a slightly lower mix of high-margin service revenue offset by the benefits of cost-containment initiatives and previous productivity and restructuring actions.

[0000833444-15-000062:mdna:83]
Operating income for the nine months ended June 26, 2015 decreased $123 million, or 39.7%, to $187 million as compared to operating income of $310 million for the nine months ended June 27, 2014.  Operating income was unfavorably impacted by a $51 million increase in restructuring and repositioning charges during the nine months ended June 26, 2015, a $17 million increase in loss on divestitures, and a slightly lower mix of high-margin service revenue. Operating income for the nine months ended June 26, 2015 was also unfavorably impacted by $20 million related to changes in foreign currency exchange rates and a non-recurring $21 million insurance recovery recorded in the prior comparable period.  These unfavorable impacts were offset by the benefits of cost-containment initiatives and previous productivity and restructuring actions.

[0000833444-15-000062:mdna:84]
Key items impacting operating income for the quarters and nine months ended June 26, 2015 and June 27, 2014, respectively, are as follows:

[0000833444-15-000062:mdna:85]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Loss on sale of investment | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 7 |  |
| Restructuring and repositioning charges, net | 40 |  |  | 11 |  |  | 66 |  |  | 15 |  |
| (Gain) loss on divestitures | (5 | ) |  | — |  |  | 18 |  |  | 1 |  |
| China insurance recovery | — |  |  | — |  |  | — |  |  | (21 | ) |
| Impact of foreign currency | 5 |  |  | 2 |  |  | 20 |  |  | 9 |  |

[0000833444-15-000062:mdna:86]
[same as prior period, unchanged from 0000833444-15-000032:mdna:84]

[0000833444-15-000062:mdna:87]
Financial information for Global Products for the quarters and nine months ended June 26, 2015 and June 27, 2014 is as follows:

[0000833444-15-000062:mdna:88]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Net revenue | $ | 675 |  |  | $ | 693 |  |  | $ | 1,925 |  |  | $ | 1,863 |  |
| Net revenue (decline) growth | (2.6 | )% |  | N/A |  |  | 3.3 | % |  | N/A |  |
| Organic revenue (decline) growth | (3.2 | )% |  | N/A |  |  | 4.3 | % |  | N/A |  |
| Operating income | $ | 108 |  |  | $ | 136 |  |  | $ | 316 |  |  | $ | 329 |  |
| Operating margin | 16.0 | % |  | 19.6 | % |  | 16.4 | % |  | 17.7 | % |

[0000833444-15-000062:mdna:89]
[same as prior period, unchanged from 0000833444-15-000032:mdna:87]

[0000833444-15-000062:mdna:90]
[same as prior period, unchanged from 0000833444-15-000032:mdna:88]

[0000833444-15-000062:mdna:91]
| Factors Contributing to Year-Over-Year Change |  | Third QuarterFiscal 2015Compared toThird QuarterFiscal 2014 |  | Year to Date Fiscal 2015 Compared to Year to Date Fiscal 2014 |
| Organic revenue (decline) growth |  | $ | (22 | ) |  | $ | 81 |  |
| Acquisitions |  | 49 |  |  | 80 |  |
| Impact of foreign currency |  | (45 | ) |  | (99 | ) |
| Total change |  | $ | (18 | ) |  | $ | 62 |  |

[0000833444-15-000062:mdna:92]
Net revenue decreased $18 million, or 2.6%, to $675 million for the quarter ended June 26, 2015 as compared to $693 million for the quarter ended June 27, 2014.  On an organic basis, net revenue declined by $22 million, or 3.2%, primarily driven by our fire products and life safety businesses, partially offset by growth in our security products business.  Net revenue was favorably impacted by $49 million, or 7.1%, from acquisitions during the quarter ended June 26, 2015.  Net revenue was unfavorably impacted by changes in foreign currency exchange rates of $45 million, or 6.5% as well as increased Scott Air-Pak shipments during the comparable quarter in the prior year.

[0000833444-15-000062:mdna:93]
Net revenue increased $62 million, or 3.3%, to $1,925 million for the nine months ended June 26, 2015 as compared to $1,863 million for the nine months ended June 27, 2014.  On an organic basis, net revenue growth of $81 million, or 4.3%, was driven by growth in our security products and life safety businesses, while our fire products business was roughly flat.  Acquisitions favorably impacted net revenue by $80 million, or 4.3%.  Changes in foreign currency exchange rates unfavorably impacted net revenue by $99 million, or 5.3%.

[0000833444-15-000062:mdna:94]
[same as prior period, unchanged from 0000833444-15-000032:mdna:92]

[0000833444-15-000062:mdna:95]
Operating income for the quarter ended June 26, 2015 decreased by $28 million, or 20.6% to $108 million, as compared to operating income of $136 million for the quarter ended June 27, 2014.  Operating income was unfavorably impacted by the decline in net revenue and additional investments in research and development for the quarter ended June 26, 2015.  These impacts were partially offset by the benefit of cost-containment initiatives and prior productivity and restructuring actions.

[0000833444-15-000062:mdna:96]
Operating income for the nine months ended June 26, 2015 decreased by $13 million, or 4.0% to $316 million, as compared to operating income of $329 million for the nine months ended June 27, 2014.  The decrease was primarily due to an unfavorable impact of foreign currency exchange rates of $11 million, a $7 million increase in restructuring and repositioning charges, and additional investments in research and development.  These were partially offset by increases due to net revenue growth for the nine months ended June 26, 2015, as well as the benefit of cost-containment initiatives and prior productivity and restructuring actions.

[0000833444-15-000062:mdna:97]
Key items impacting operating income for the quarters and nine months ended June 26, 2015 and June 27, 2014, respectively, are as follows:

[0000833444-15-000062:mdna:98]
|  | For the Quarter Ended |  | For the Nine Months Ended |
| ($ in millions) | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Restructuring and repositioning charges, net | $ | 5 |  |  | $ | 3 |  |  | $ | 16 |  |  | $ | 9 |  |
| Impact of foreign currency | 4 |  |  | (1 | ) |  | 11 |  |  | (1 | ) |

[0000833444-15-000062:mdna:99]
[same as prior period, unchanged from 0000833444-15-000032:mdna:97]

[0000833444-15-000062:mdna:100]
Corporate expense was $72 million for the quarter ended June 26, 2015 compared to $58 million for the quarter ended June 27, 2014.  The increase in expense was primarily due to a $13 million increase in restructuring and repositioning charges compared to the quarter ended June 27, 2014 as well as a $7 million unfavorable change in asbestos related charges as a result of gains recorded in the prior comparable quarter for insurance recoveries.

[0000833444-15-000062:mdna:101]
Corporate expense was $214 million for the nine months ended June 26, 2015 compared to $73 million for the nine months ended June 27, 2014.  The increase in expense was primarily due to the reversal of a compensation reserve of $92 million for the settlement of legacy litigation with former management, and a gain of $16 million related to a legal settlement with CIT Group, for the nine months ended June 27, 2014.  In addition, restructuring and repositioning charges increased by $36 million compared to the nine months ended June 27, 2014 as well as a $12 million unfavorable change in asbestos related charges as a result of gains recorded in the prior comparable period for insurance recoveries.

[0000833444-15-000062:mdna:102]
Key items included in corporate expense for the quarters and nine months ended June 26, 2015 and June 27, 2014, respectively, are as follows:

[0000833444-15-000062:mdna:103]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Legacy legal gains | $ | (2 | ) |  | $ | (4 | ) |  | $ | (9 | ) |  | $ | (96 | ) |
| CIT settlement gain | — |  |  | — |  |  | — |  |  | (16 | ) |
| Restructuring and repositioning charges, net | 23 |  |  | 10 |  |  | 60 |  |  | 24 |  |
| Asbestos related charges (gains) | 1 |  |  | (6 | ) |  | 7 |  |  | (5 | ) |

[0000833444-15-000062:mdna:104]
[same as prior period, unchanged from 0000833444-15-000032:mdna:102]

[0000833444-15-000062:mdna:105]
The preparation of the unaudited Consolidated Financial Statements in conformity with US GAAP requires management to use judgment in making estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of contingent assets and liabilities and the reported amounts of revenue and expenses. We believe that our accounting policies for depreciation and amortization methods of security monitoring-related assets, revenue recognition, loss contingencies, income taxes, goodwill and indefinite-lived intangible assets, long-lived assets and pension and postretirement benefits are based on, among other things, judgments and assumptions made by management that include inherent risks and uncertainties. During fiscal 2015, there have been no significant changes to these policies or in the underlying accounting assumptions and estimates used in the above critical accounting policies from those disclosed in the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed with the SEC on November 14, 2014 for the fiscal year ended September 26, 2014.

[0000833444-15-000062:mdna:106]
[same as prior period, unchanged from 0000833444-15-000032:mdna:104]

[0000833444-15-000062:mdna:107]
A fundamental objective of the Company is to have sufficient liquidity, balance sheet strength, and financial flexibility to fund the operating and capital requirements of its core businesses around the world.

[0000833444-15-000062:mdna:108]
The primary source of funds to finance our operations and capital expenditures is cash generated by operations. In addition, we maintain a commercial paper program, have access to a $1 billion committed revolving credit facility, and have access to equity and debt capital from public and private sources. We continue to balance our operating, investing, and financing uses of cash through investments and acquisitions in our core businesses, dividends, and share repurchases. In addition, we believe our available cash, amounts available under our credit facility, commercial paper program and cash provided by operating activities will be adequate to cover our operational, capital and other business needs in the foreseeable future. To the extent it is necessary for us to finance our cash needs through the issuance of commercial paper, by accessing our committed revolving credit facility, or through other public or private sources, our cost of funding may increase depending on market conditions at the time of such borrowing.

[0000833444-15-000062:mdna:109]
As of June 26, 2015 and September 26, 2014, our cash and cash and cash equivalents, total debt, available amounts under committed credit facilities, and Tyco shareholders’ equity were as follows:

[0000833444-15-000062:mdna:110]
|  | As of |  | Credit Availability as of |
| ($ in millions) | June 26, 2015 |  | September 26, 2014 |  | June 26, 2015 |
| Cash and cash equivalents | $ | 531 |  |  | $ | 892 |  |  | $ | — |  |
| Total debt (excluding revolving credit facility) | 2,021 |  |  | 1,463 |  |  | — |  |
| Revolving credit facility | — |  |  | — |  |  | 1,000 |  |
| Total Tyco shareholders' equity | 4,304 |  |  | 4,647 |  |  | — |  |
| Total debt as a % of total capital (1) | 32.0 | % |  | 23.9 | % |  | NA |  |

[0000833444-15-000062:mdna:111]
(1) Total capital represents the aggregate amount of total debt and total Tyco Shareholders' equity which was $6,325 million and $6,110 million as of June 26, 2015 and September 26, 2014, respectively.

[0000833444-15-000062:mdna:112]
Significant uses of capital that are expected in the near- to mid-term include expenditures for (i) capital expenditures and dealer investments in annual amounts expected to approximate 3% to 3.5% of total revenues, (ii) the funding of a Yarway asbestos trust in the amount of approximately $325 million during the fourth quarter of fiscal 2015 (see Note 11 to our unaudited Consolidated Financial Statements), (iii) the funding of potential tax liabilities or settlements (see Notes 6 and 11 to our unaudited Consolidated Financial Statements), including with respect to the divestiture of our ADT South Korea business, with respect to which the amounts and timing are uncertain, (iv) repayment of $258 million in principal amount of 3.375% public notes due in October 2015, and (v) dividend payments in an annual amount of approximately $345 million as of March 27, 2015, $86 million of which had been paid as of June 26, 2015.  The Company intends to fund these capital uses through a combination of available cash, cash generated from operations, borrowing in the commercial paper market or under its revolving credit facility, and borrowing in public or private markets for debt securities. In addition, the Company intends, in its discretion, to pursue strategically important acquisitions, may repurchase its shares from time to time and may engage in other capital market activities (such as refinancing of outstanding debt), in each case depending on a number of factors, including the Company’s strategic priorities, its financial condition and results of operations, the capital requirements of the Company’s businesses, industry and capital markets factors and other relevant factors.

[0000833444-15-000062:mdna:113]
[same as prior period, unchanged from 0000833444-15-000032:mdna:109]

[0000833444-15-000062:mdna:114]
Our cash flows from operating, investing and financing from continuing operations for the nine months ended June 26, 2015 and June 27, 2014 are summarized below:

[0000833444-15-000062:mdna:115]
|  | For the Nine Months Ended |
| ($ in millions) | June 26, 2015 |  | June 27, 2014 |
| Net cash provided by operating activities | $ | 511 |  |  | $ | 518 |  |
| Net cash used in investing activities | (752 | ) |  | (83 | ) |
| Net cash (used in) provided by financing activities | (102 | ) |  | 922 |  |

[0000833444-15-000062:mdna:116]
55

[0000833444-15-000062:mdna:117]
On January 9, 2015, the Company completed a series of restructuring transactions related to the establishment and funding of a structure dedicated to resolving certain historic Grinnell asbestos liabilities. Pursuant to this transaction, a subsidiary of the Company acquired certain assets of Grinnell and transferred cash and other assets totaling approximately $278 million to the structure.  The cash and assets transferred to the structure have been designated as restricted by the Company. In addition, on the effective date of Yarway’s Chapter 11 plan of reorganization, which is anticipated to occur in the fourth fiscal quarter of 2015, the Company expects to contribute approximately $325 million to an asbestos settlement trust that conforms to the provisions of Section 524(g) of the U.S. Bankruptcy Code.  See Note 11 to our unaudited Consolidated Financial Statements.

[0000833444-15-000062:mdna:118]
[same as prior period, unchanged from 0000833444-15-000032:mdna:113]

[0000833444-15-000062:mdna:119]
[same as prior period, unchanged from 0000833444-15-000032:mdna:114]

[0000833444-15-000062:mdna:120]
The net change in working capital decreased operating cash flow by $372 million in the nine months ended June 26, 2015. The significant changes in working capital included a $104 million increase in accounts receivable, a $78 million decrease in accounts payable, a $72 million increase in inventories, a $50 million decrease in accrued and other liabilities, and a $25 million increase in prepaid expenses and other current assets.

[0000833444-15-000062:mdna:121]
The net change in working capital decreased operating cash flow by $503 million in the nine months ended June 27, 2014. The significant changes in working capital included a $361 million decrease in accrued and other liabilities, a $50 million increase in contracts in progress, $41 million increase in accounts receivable and a $39 million increase in prepaid expenses.

[0000833444-15-000062:mdna:122]
During the nine months ended June 26, 2015 and June 27, 2014, we paid approximately $78 million and $57 million, respectively, in cash related to restructuring activities.

[0000833444-15-000062:mdna:123]
In connection with the 2012 Separation, we paid $2 million and $48 million in separation costs during the nine months ended June 26, 2015 and June 27, 2014, respectively.

[0000833444-15-000062:mdna:124]
During the nine months ended June 26, 2015 and June 27, 2014, we made net payments related to asbestos liabilities of $8 million and $3 million, respectively.

[0000833444-15-000062:mdna:125]
During the nine months ended June 26, 2015 and June 27, 2014, we made net payments related to environmental remediation activities for a facility located in Marinette, Wisconsin, of $7 million and $60 million, respectively.

[0000833444-15-000062:mdna:126]
During the nine months ended June 27, 2014, Tyco made a net cash payment of $155 million to Medtronic under the terms of the 2007 Tax Sharing Agreement.  The cash exchanged was a reimbursement between the parties for various payments made to the IRS for federal income taxes related to the audit of fiscal years 2005 through 2007.  During the nine months ended June 26, 2015, we did not pay or receive cash under the terms of the Tax Sharing Agreements.

[0000833444-15-000062:mdna:127]
During the nine months ended June 27, 2014, Tyco settled a tax dispute with CIT Group, a former subsidiary.  Under the terms of the settlement agreement, Tyco received $60 million, of which $25 million and $19 million was subsequently paid during fiscal 2014 to Medtronic and TE Connectivity, respectively, under the terms of the 2007 Tax Sharing Agreement.

[0000833444-15-000062:mdna:128]
During the nine months ended June 26, 2015 and June 27, 2014, we made required contributions of $9 million and $17 million, respectively, to our U.S. pension plans and $13 million and $20 million, respectively, to our non-U.S. pension plans. We anticipate that we will contribute at least the minimum required to our pension plans in 2015 of $13 million for our U.S. plans and $23 million for our non-U.S. plans.

[0000833444-15-000062:mdna:129]
Income taxes paid, net of refunds, related to continuing operations were $84 million and $74 million during the nine months ended June 26, 2015 and June 27, 2014, respectively.

[0000833444-15-000062:mdna:130]
Net interest paid related to continuing operations was $52 million and $53 million for the nine months ended June 26, 2015 and June 27, 2014, respectively.

[0000833444-15-000062:mdna:131]
[same as prior period, unchanged from 0000833444-15-000032:mdna:126]

[0000833444-15-000062:mdna:132]
[same as prior period, unchanged from 0000833444-15-000032:mdna:127]

[0000833444-15-000062:mdna:133]
We made capital expenditures of $183 million and $210 million for the nine months ended June 26, 2015 and June 27, 2014, respectively.  The level of capital expenditures in fiscal 2015 is expected to be in line with the spending levels in fiscal 2014.

[0000833444-15-000062:mdna:134]
During the nine months ended June 26, 2015, we paid cash for acquisitions included in continuing operations totaling $525 million, net of cash acquired of $26 million, which primarily related to acquisitions in our ROW Installation & Services and Global Products segments.  During the nine months ended June 27, 2014, we paid cash for acquisitions included in continuing operations totaling $63 million, net of $1 million cash acquired, which related to acquisitions included in our NA Installation & Services and ROW Installation & Services segments.

[0000833444-15-000062:mdna:135]
We maintain captive insurance companies to manage certain of our insurable liabilities. The captive insurance companies held certain investment accounts for the purposes of providing collateral for our insurable liabilities.  During fiscal 2014, the portfolio of investments was liquidated and we now provide letters of credit as collateral.  During the nine months ended June 27, 2014, our captive insurance companies made net sales of approximately $283 million.  See Note 10 to our unaudited Consolidated Financial Statements.

[0000833444-15-000062:mdna:136]
During the nine months ended June 27, 2014, we purchased investments of $332 million, which was primarily comprised of time deposits of $277 million.  During the nine months ended June 26, 2015, our time deposits of $275 million matured, and we made purchases of $290 million of investments, primarily consisting of exchange traded equity and fixed income funds, which are classified as available-for-sale investments.  These investments are classified as restricted, as the Company plans to use them to fund the Yarway Trust during the fourth quarter of fiscal 2015.

[0000833444-15-000062:mdna:137]
During the nine months ended June 26, 2015, our restricted cash increased by $27 million.  This increase was primarily driven by an increase of $7 million related to the asbestos-related liabilities, $16 million of recoveries from Mr. Swartz and Mr. Kozlowski, and $4 million of restricted cash related to an acquisition.

[0000833444-15-000062:mdna:138]
During the nine months ended June 27, 2014, we generated $250 million in proceeds from the sale of our equity method investment in Atkore, as described in Note 3 to our unaudited Consolidated Financial Statements.

[0000833444-15-000062:mdna:139]
[same as prior period, unchanged from 0000833444-15-000032:mdna:133]

[0000833444-15-000062:mdna:140]
[same as prior period, unchanged from 0000833444-15-000032:mdna:134]

[0000833444-15-000062:mdna:141]
Proceeds from issuance of long-term debt primarily related to proceeds of $567 million from the issuance in February 2015 of €500 million aggregate principal amount of public notes due 2025.  See Note 9 to our unaudited Consolidated Financial Statements.

[0000833444-15-000062:mdna:142]
As of June 26, 2015 and September 26, 2014, TIFSA had no commercial paper outstanding.  The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1 billion as of June 26, 2015.

[0000833444-15-000062:mdna:143]
As of June 26, 2015 and September 26, 2014, there were no amounts drawn under the Company's revolving credit facility.

[0000833444-15-000062:mdna:144]
Pursuant to our share repurchase program, we may repurchase Tyco shares from time to time in open market purchases at prevailing market prices, in negotiated transactions off the market, or pursuant to an approved trading plan in accordance with applicable regulations.  During the nine months ended June 26, 2015, we repurchased approximately 10 million ordinary shares for approximately $417 million.  During the nine months ended June 27, 2014, we repurchased approximately 20 million ordinary shares for approximately $806 million.

[0000833444-15-000062:mdna:145]
On March 4, 2015, the Board of Directors approved a quarterly dividend of $0.205 per share payable on May 20, 2015 to shareholders of record on April 24, 2015.  On March 5, 2014, our shareholders approved a cash dividend of $0.72 per ordinary share payable to shareholders in four quarterly installments of $0.18 in May 2014, August 2014, November 2014 and February 2015.  During the nine months ended June 26, 2015 and June 27, 2014, we paid cash dividends of approximately $237 million and $231 million, respectively.

[0000833444-15-000062:mdna:146]
57

[0000833444-15-000062:mdna:147]
Included in cash flows from financing activities for the nine months ended June 26, 2015 is payment of contingent consideration of $23 million related to the acquisition of a business during fiscal year 2014.

[0000833444-15-000062:mdna:148]
[same as prior period, unchanged from 0000833444-15-000032:mdna:141]

[0000833444-15-000062:mdna:149]
Commitments and Contingencies

[0000833444-15-000062:mdna:150]
For a detailed discussion of contingencies related to tax and litigation matters, see Notes 6 and 11 to our unaudited Consolidated Financial Statements.

[0000833444-15-000062:mdna:151]
[same as prior period, unchanged from 0000833444-15-000032:mdna:144]

[0000833444-15-000062:mdna:152]
We had a backlog of unfilled orders of $4,709 million and $4,857 million as of June 26, 2015 and September 26, 2014, respectively.

[0000833444-15-000062:mdna:153]
[same as prior period, unchanged from 0000833444-15-000032:mdna:146]

[0000833444-15-000062:mdna:154]
|  | NA Installation& Services |  | ROWInstallation& Services |  | GlobalProducts |  | Total |
| As of September 26, 2014 |  |  |  |  |  |  |  |
| Backlog | $ | 992 |  |  | $ | 997 |  |  | $ | 181 |  |  | $ | 2,170 |  |
| Recurring revenue in force | 1,243 |  |  | 1,140 |  |  | — |  |  | 2,383 |  |
| Deferred revenue | 266 |  |  | 38 |  |  | — |  |  | 304 |  |
| Total Backlog | $ | 2,501 |  |  | $ | 2,175 |  |  | $ | 181 |  |  | $ | 4,857 |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |
| Backlog | $ | 1,075 |  |  | $ | 824 |  |  | $ | 215 |  |  | $ | 2,114 |  |
| Recurring revenue in force | 1,228 |  |  | 1,087 |  |  | — |  |  | 2,315 |  |
| Deferred revenue | 244 |  |  | 36 |  |  | — |  |  | 280 |  |
| Total Backlog | $ | 2,547 |  |  | $ | 1,947 |  |  | $ | 215 |  |  | $ | 4,709 |  |

[0000833444-15-000062:mdna:155]
Backlog decreased $148 million, or 3.0%, to $4,709 million as of June 26, 2015 compared to $4,857 million as of September 26, 2014.  Changes in foreign currency had an unfavorable impact of $210 million, or 4.3%, primarily in our ROW Installation & Services segment.  In addition, a divestiture of a business in our ROW Installation & Services segment had an unfavorable impact of $104 million, or 2.1%.  These impacts were partially offset by acquisitions primarily in our Global Products segment, which contributed $16 million, or 0.3%, to backlog.

[0000833444-15-000062:mdna:156]
[same as prior period, unchanged from 0000833444-15-000032:mdna:150]

[0000833444-15-000062:mdna:157]
[same as prior period, unchanged from 0000833444-15-000032:mdna:151]

[0000833444-15-000062:mdna:158]
[same as prior period, unchanged from 0000833444-15-000032:mdna:152]

[0000833444-15-000062:mdna:159]
In disposing of assets or businesses, we often provide representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities, and unidentified tax and other liabilities related to periods prior to disposition. We have no reason to believe that these uncertainties would have a material adverse effect on our financial position, results of operations or cash flows. We have recorded liabilities for known indemnifications included as part of environmental liabilities. See Note 11 to the unaudited Consolidated Financial Statements.

[0000833444-15-000062:mdna:160]
[same as prior period, unchanged from 0000833444-15-000032:mdna:154]

[0000833444-15-000062:mdna:161]
[same as prior period, unchanged from 0000833444-15-000032:mdna:155]

[0000833444-15-000062:mdna:162]
[same as prior period, unchanged from 0000833444-15-000032:mdna:156]

[0000833444-15-000062:mdna:163]
[same as prior period, unchanged from 0000833444-15-000032:mdna:157]

[0000833444-15-000062:mdna:164]
[same as prior period, unchanged from 0000833444-15-000032:mdna:159]

[0000833444-15-000062:mdna:165]
Quarter Ended June 26, 2015

[0000833444-15-000062:mdna:166]
|  | Net Revenue for the Quarter Ended June 27, 2014 |  | Base YearAdjustmentsDivestitures / Other |  | AdjustedFiscal 2014Base Revenue |  | ForeignCurrency |  | Acquisitions |  | OrganicRevenue(1) |  | OrganicGrowthPercentage |  | Net Revenue for the Quarter Ended June 26, 2015 |
|  | ($ in millions) |
| NA Installation & Services | $ | 968 |  |  | $ | — |  |  | $ | 968 |  |  | $ | (12 | ) |  | $ | 3 |  |  | $ | 13 |  |  | 1.3 | % |  | $ | 972 |  |
| ROW Installation & Services | 999 |  |  | (21 | ) |  | 978 |  |  | (126 | ) |  | 11 |  |  | (21 | ) |  | (2.1 | )% |  | 842 |  |
| Global Products | 693 |  |  | — |  |  | 693 |  |  | (45 | ) |  | 49 |  |  | (22 | ) |  | (3.2 | )% |  | 675 |  |
| Total Net Revenue | $ | 2,660 |  |  | $ | (21 | ) |  | $ | 2,639 |  |  | $ | (183 | ) |  | $ | 63 |  |  | $ | (30 | ) |  | (1.1 | )% |  | $ | 2,489 |  |

[0000833444-15-000062:mdna:167]
[same as prior period, unchanged from 0000833444-15-000032:mdna:163]

[0000833444-15-000062:mdna:168]
Nine Months Ended June 26, 2015

[0000833444-15-000062:mdna:169]
|  | Net Revenue for the Nine Months Ended June 27, 2014 |  | Base YearAdjustmentsDivestitures / Other |  | AdjustedFiscal 2014Base Revenue |  | ForeignCurrency |  | Acquisitions |  | OrganicRevenue(1) |  | OrganicGrowthPercentage |  | Net Revenue for the Nine Months Ended June 26, 2015 |
|  | ($ in millions) |
| NA Installation & Services | $ | 2,864 |  |  | $ | — |  |  | $ | 2,864 |  |  | $ | (33 | ) |  | $ | 9 |  |  | $ | 27 |  |  | 0.9 | % |  | $ | 2,867 |  |
| ROW Installation & Services | 2,902 |  |  | (34 | ) |  | 2,868 |  |  | (289 | ) |  | 44 |  |  | (18 | ) |  | (0.6 | )% |  | 2,605 |  |
| Global Products | 1,863 |  |  | — |  |  | 1,863 |  |  | (99 | ) |  | 80 |  |  | 81 |  |  | 4.3 | % |  | 1,925 |  |
| Total Net Revenue | $ | 7,629 |  |  | $ | (34 | ) |  | $ | 7,595 |  |  | $ | (421 | ) |  | $ | 133 |  |  | $ | 90 |  |  | 1.2 | % |  | $ | 7,397 |  |

[0000833444-15-000062:mdna:170]
[same as prior period, unchanged from 0000833444-15-000032:mdna:166]

[0000833444-15-000062:mdna:171]
[same as prior period, unchanged from 0000833444-15-000032:mdna:167]

[0000833444-15-000062:mdna:172]
[same as prior period, unchanged from 0000833444-15-000032:mdna:168]

[0000833444-15-000062:mdna:173]
[same as prior period, unchanged from 0000833444-15-000032:mdna:169]

[0000833444-15-000062:mdna:174]
[same as prior period, unchanged from 0000833444-15-000032:mdna:170]

[0000833444-15-000062:mdna:175]
[same as prior period, unchanged from 0000833444-15-000032:mdna:171]

[0000833444-15-000062:mdna:176]
| • | the outcome of litigation, arbitrations and governmental proceedings; |

[0000833444-15-000062:mdna:177]
| • | effect of income tax audits, litigation, settlements and appeals; |

[0000833444-15-000062:mdna:178]
[same as prior period, unchanged from 0000833444-15-000032:mdna:174]

[0000833444-15-000062:mdna:179]
[same as prior period, unchanged from 0000833444-15-000032:mdna:175]

[0000833444-15-000062:mdna:180]
[same as prior period, unchanged from 0000833444-15-000032:mdna:176]

[0000833444-15-000062:mdna:181]
[same as prior period, unchanged from 0000833444-15-000032:mdna:177]

[0000833444-15-000062:mdna:182]
[same as prior period, unchanged from 0000833444-15-000032:mdna:178]

[0000833444-15-000062:mdna:183]
[same as prior period, unchanged from 0000833444-15-000032:mdna:179]

[0000833444-15-000062:mdna:184]
[same as prior period, unchanged from 0000833444-15-000032:mdna:180]

[0000833444-15-000062:mdna:185]
[same as prior period, unchanged from 0000833444-15-000032:mdna:181]

[0000833444-15-000062:mdna:186]
[same as prior period, unchanged from 0000833444-15-000032:mdna:182]

[0000833444-15-000062:mdna:187]
| • | our ability to predict end-user demand for new or enhanced product or service offerings; |

[0000833444-15-000062:mdna:188]
[same as prior period, unchanged from 0000833444-15-000032:mdna:183]

[0000833444-15-000062:mdna:189]
[same as prior period, unchanged from 0000833444-15-000032:mdna:184]

[0000833444-15-000062:mdna:190]
[same as prior period, unchanged from 0000833444-15-000032:mdna:185]

[0000833444-15-000062:mdna:191]
[same as prior period, unchanged from 0000833444-15-000032:mdna:186]

[0000833444-15-000062:mdna:192]
60

[0000833444-15-000062:mdna:193]
[same as prior period, unchanged from 0000833444-15-000032:mdna:187]

[0000833444-15-000062:mdna:194]
[same as prior period, unchanged from 0000833444-15-000032:mdna:188]

[0000833444-15-000062:mdna:195]
[same as prior period, unchanged from 0000833444-15-000032:mdna:189]

[0000833444-15-000062:mdna:196]
[same as prior period, unchanged from 0000833444-15-000032:mdna:190]
