# JCI notes — 0000833444-15-000062


## tyc:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesAndNewAccountingPronouncementsTextBlock

[0000833444-15-000062:notes:1]
Basis of Presentation and Summary of Significant Accounting Policies

[0000833444-15-000062:notes:2]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year.  These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 26, 2014 (the "2014 Form 10-K").

[0000833444-15-000062:notes:3]
References to 2015 and 2014 are to Tyco's fiscal quarters ending June 26, 2015 and June 27, 2014, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September.  Fiscal years 2015 and 2014 are both 52-week years.

[0000833444-15-000062:notes:4]
Change of Jurisdiction - On November 17, 2014, Tyco International Ltd., an entity organized under the laws of Switzerland ("Tyco Switzerland"), completed its change of jurisdiction of incorporation from Switzerland to Ireland by merging with its subsidiary, Tyco International plc ("Tyco Ireland"), a public limited company incorporated under the laws of Ireland (the "Merger"). As a result of the Merger, Tyco Ireland is the successor issuer to Tyco Switzerland, has succeeded to the attributes of Tyco Switzerland as the registrant under SEC regulations, and has assumed all pre-Merger obligations of Tyco Switzerland.

[0000833444-15-000062:notes:5]
Reclassifications - Certain prior period amounts have been reclassified to conform with current period presentation. During the quarter ended June 26, 2015, the Company sold three businesses in the Rest of World ("ROW") Installation & Services segment.  The assets and liabilities related to these businesses were classified as held for sale of as September 26, 2014, and the results of operations of two of these businesses are included in discontinued operations for all periods presented, as the criteria to be presented as a discontinued operation were not satisfied for the third business.  The Company expects to complete the sale of another of its ROW Installation & Services businesses during the first half of fiscal 2016.  The assets and liabilities of this business are classified as held for sale, and its results of operations are presented as discontinued operations for all periods presented. See Note 3.

[0000833444-15-000062:notes:6]
Recently Adopted Accounting Pronouncements - In March 2013, the Financial Accounting Standards Board ("FASB") issued authoritative guidance to resolve diversity in practice on the accounting for the cumulative translation adjustment ("CTA") when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within a foreign entity. The guidance requires that the parent release any CTA into net income when the parent ceases to have a controlling financial interest in a subsidiary or group of assets within a foreign entity which results in a substantially complete liquidation of the foreign entity; when the sale of an investment in a foreign entity results in the loss of a controlling financial interest; or where an acquirer obtains control of an acquiree in which it had an equity interest immediately before the acquisition date. The guidance does not change the requirement to release a pro rata portion of the CTA into net income upon a partial sale of an equity method investment that is a foreign entity. The guidance became effective for Tyco in the first quarter of fiscal 2015. The adoption of this guidance, which was applied on a prospective basis, did not have a material impact on the Company's financial position, results of operations or cash flows.

[0000833444-15-000062:notes:7]
In July 2013, the FASB issued authoritative guidance for the presentation of an unrecognized tax benefit when a net operating loss (“NOL”) carryforward, a similar tax loss, or a tax credit carryforward exists. The guidance requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, in the financial statements as a reduction to a deferred tax asset for a NOL carryforward, a similar tax loss, or a tax credit carryforward. If the NOL carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the jurisdiction or the tax law of the jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit will be presented in the financial statements as a liability and will not be combined with deferred tax assets.  This guidance does not require any additional recurring disclosures and became effective for Tyco during the first fiscal quarter of fiscal 2015.  The adoption of this guidance, which was applied on a prospective basis, did not have a material impact on the Company's financial position, results of operations or cash flows.

[0000833444-15-000062:notes:8]
Recently Issued Accounting Pronouncements - In April 2014, the FASB issued authoritative guidance to change the criteria for reporting discontinued operations.  Under the new guidance, only disposals representing a strategic shift in a company's operations and financial results should be reported as discontinued operations, with expanded disclosures. In addition, disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify as a discontinued operation is required.  This guidance is effective for Tyco in the first quarter of fiscal 2016, with early adoption permitted only for disposals that have not been reported in financial statements previously issued or available for issuance.  The Company is currently assessing the impact, if any, the guidance will have upon adoption.

[0000833444-15-000062:notes:9]
In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires both quantitative and qualitative disclosures, which are more comprehensive than existing revenue standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. In July 2015, the FASB issued a deferral of the effective date of this guidance, which for Tyco will be the first quarter of fiscal 2019, with early adoption permitted beginning the first quarter of fiscal 2018.  The Company is currently assessing the impact the guidance will have upon adoption.

[0000833444-15-000062:notes:10]
In May 2015, the FASB issued authoritative guidance which is intended to improve the existing disclosure requirements for short-duration contracts for insurance entities that issue such contracts.  The guidance requires additional information to be disclosed about the liability for unpaid claims and claim adjustment expenses to increase the transparency of significant estimates made in measuring those liabilities.  This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance will have upon adoption.


## tyc:ScheduleOfIntangibleAssetsTextBlock

[0000833444-15-000062:notes:11]
The following table sets forth the gross carrying amount and accumulated amortization of the Company's intangible assets as of June 26, 2015 and September 26, 2014 ($ in millions):

[0000833444-15-000062:notes:12]
|  | As of |
|  | June 26, 2015 |  | September 26, 2014 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Amortizable: |  |  |  |  |  |  |  |
| Contracts and related customer relationships | $ | 1,361 |  |  | $ | 1,047 |  |  | $ | 1,400 |  |  | $ | 1,113 |  |
| Intellectual property | 770 |  |  | 505 |  |  | 608 |  |  | 487 |  |
| Other | 11 |  |  | 8 |  |  | 29 |  |  | 15 |  |
| Total | $ | 2,142 |  |  | $ | 1,560 |  |  | $ | 2,037 |  |  | $ | 1,615 |  |
| Non-Amortizable: |  |  |  |  |  |  |  |
| Intellectual property | $ | 212 |  |  |  |  |  | $ | 214 |  |  |  |
| Franchise rights | 76 |  |  |  |  |  | 76 |  |  |  |
| In-process research and development | 20 |  |  |  |  | — |  |  |  |
| Total | $ | 308 |  |  |  |  |  | $ | 290 |  |  |  |


## tyc:ScheduleOfNetReceivablesAndLiabilitiesRecordedUnderTaxSharingAgreementsTableTextBlock

[0000833444-15-000062:notes:13]
he receivables and liabilities related to the 2012 and 2007 Tax Sharing Agreements as of June 26, 2015 and September 26, 2014, are as follows ($ in millions):

[0000833444-15-000062:notes:14]
|  | 2012 Tax Sharing Agreement |  | 2007 Tax Sharing Agreement |
|  | As of |  | As of |
|  | June 26, 2015 |  | September 26, 2014 |  | June 26, 2015 |  | September 26, 2014 |
| Tax sharing agreement related receivables: |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 3 |  |
| Other assets | — |  |  | — |  |  | 24 |  |  | 23 |  |
|  | — |  |  | — |  |  | 26 |  |  | 26 |  |
| Tax sharing agreement related liabilities: |  |  |  |  |  |  |  |
| Accrued and other current liabilities | — |  |  | — |  |  | (21 | ) |  | (21 | ) |
| Other liabilities | (46 | ) |  | (46 | ) |  | (194 | ) |  | (194 | ) |
|  | (46 | ) |  | (46 | ) |  | (215 | ) |  | (215 | ) |
| Net liability | $ | (46 | ) |  | $ | (46 | ) |  | $ | (189 | ) |  | $ | (189 | ) |


## tyc:ScheduleOfRestructuringReserveByBalanceSheetLocationTextBlock

[0000833444-15-000062:notes:15]
As of June 26, 2015 and September 26, 2014, restructuring reserves related to all actions were included in the Company's Consolidated Balance Sheets as follows ($ in millions):

[0000833444-15-000062:notes:16]
|  | As of |
|  | June 26, 2015 |  | September 26, 2014 |
| Accrued and other current liabilities | $ | 106 |  |  | $ | 83 |  |
| Other liabilities | 14 |  |  | 16 |  |
| Total | $ | 120 |  |  | $ | 99 |  |


## tyc:ScheduleOfSegmentReportingInformationNetRevenueAndOperatingIncomeLossBySegmentTableTextBlock

[0000833444-15-000062:notes:17]
[same as prior period, unchanged from 0000833444-15-000032:notes:16]

[0000833444-15-000062:notes:18]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Net revenue(1): |  |  |  |  |  |  |  |
| NA Installation & Services | $ | 972 |  |  | $ | 968 |  |  | $ | 2,867 |  |  | $ | 2,864 |  |
| ROW Installation & Services | 842 |  |  | 999 |  |  | 2,605 |  |  | 2,902 |  |
| Global Products | 675 |  |  | 693 |  |  | 1,925 |  |  | 1,863 |  |
|  | $ | 2,489 |  |  | $ | 2,660 |  |  | $ | 7,397 |  |  | $ | 7,629 |  |

[0000833444-15-000062:notes:19]
[same as prior period, unchanged from 0000833444-15-000032:notes:18]

[0000833444-15-000062:notes:20]
[same as prior period, unchanged from 0000833444-15-000032:notes:19]

[0000833444-15-000062:notes:21]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Operating income (loss): |  |  |  |  |  |  |  |
| NA Installation & Services | $ | 160 |  |  | $ | 117 |  |  | $ | 384 |  |  | $ | 333 |  |
| ROW Installation & Services (1) | 57 |  |  | 102 |  |  | 187 |  |  | 310 |  |
| Global Products | 108 |  |  | 136 |  |  | 316 |  |  | 329 |  |
| Corporate and Other (2) | (72 | ) |  | (58 | ) |  | (214 | ) |  | (73 | ) |
|  | $ | 253 |  |  | $ | 297 |  |  | $ | 673 |  |  | $ | 899 |  |

[0000833444-15-000062:notes:22]
| (1) | Operating income for the nine months ended June 27, 2014 includes $21 million of an insurance recovery related to the improper recording of revenue in China that was previously disclosed in the fourth quarter of fiscal 2012. |

[0000833444-15-000062:notes:23]
| (2) | Operating loss for the nine months ended June 27, 2014 includes $96 million of income related to the settlement of a legacy legal matter with former management and $16 million of income related to the CIT settlement. |


## tyc:SeparationTransactionDisclosureTextBlock

[0000833444-15-000062:notes:24]
[same as prior period, unchanged from 0000833444-15-000032:notes:24]

[0000833444-15-000062:notes:25]
[same as prior period, unchanged from 0000833444-15-000032:notes:25]

[0000833444-15-000062:notes:26]
In connection with activities taken to complete the 2012 Separation and to create the revised organizational structure of the Company, the Company incurred pre-tax charges ("Separation Charges") within continuing operations of nil and $11 million during the quarters ended June 26, 2015 and June 27, 2014, respectively, and $2 million and $42 million during the nine months ended June 26, 2015 and June 27, 2014, respectively.  In addition, the Company incurred pre-tax charges within discontinued operations of nil and $1 million during the quarters ended June 26, 2015 and June 27, 2014, respectively, and nil and $2 million during the nine months ended June 26, 2015 and June 27, 2014, respectively.  The amounts presented within discontinued operations are costs directly related to the 2012 Separation that are not expected to provide a future benefit to the Company.  In addition to pre-tax charges, the Company incurred tax-related charges of nil and $9 million during the quarters ended June 26, 2015 and June 27, 2014, respectively, and nil and $9 million during the nine months ended June 26, 2015 and June 27, 2014, respectively.  The Company received associated tax benefits of nil during both quarters ended June 26, 2015 and June 27, 2014 and nil and $11 million during the nine months ended June 26, 2015 and June 27, 2014, respectively. The Company does not expect to incur material separation charges relating to activities taken to complete the 2012 Separation in future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000833444-15-000062:notes:27]
[same as prior period, unchanged from 0000833444-15-000032:notes:27]

[0000833444-15-000062:notes:28]
During the quarter ended June 26, 2015 the Company did not complete any acquisitions.  During the nine months ended June 26, 2015, total consideration paid, net of $26 million of cash acquired and $8 million of a holdback liability, for 11 acquisitions included in continuing operations was $525 million.  The largest of these was the acquisition of Industrial Safety Technologies International ("IST"), a global leader in gas and flame detection with operations in Europe, the Middle East, China, and the U.S., for total consideration paid, net of $5 million of cash acquired, of $327 million.  The purchase price for IST was allocated as follows: $68 million of assets, $136 million of goodwill, $143 million of intangible assets and the assumption of $15 million of liabilities.  IST is being integrated into the Global Products segment.  The remaining 10 acquisitions are being integrated into the ROW Installation & Services and Global Products segments.

[0000833444-15-000062:notes:29]
The determination of fair value for certain assets and liabilities relating to the acquisitions made during the quarters ended December 27, 2014 and March 27, 2015 has been finalized, with no material adjustment to the purchase price allocation.

[0000833444-15-000062:notes:30]
During the quarter ended June 27, 2014, cash paid for acquisitions included in continuing operations totaled $9 million, which was related to an acquisition within the Company's ROW Installation & Services segment.

[0000833444-15-000062:notes:31]
During the nine months ended June 27, 2014, total consideration paid was $67 million, which in addition to the acquisition within ROW Installation & Services segment described above, is comprised of $54 million, net of $1 million cash acquired, and $1 million of contingent consideration. This was entirely related to the acquisition of Westfire, Inc. ("Westfire") on November 8, 2013.  Westfire, a fire protection services company with operations in the United States, Chile and Peru, provides critical special-hazard suppression and detection applications in mining, telecommunications and other vertical markets and has been integrated into the NA Installation & Services and ROW Installation & Services segments.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-15-000062:notes:32]
Commitments and Contingencies

[0000833444-15-000062:notes:33]
Legacy Matters Related to Former Management

[0000833444-15-000062:notes:34]
In recent years, the Company has settled several lawsuits involving disputes with former management. With respect to Dennis Kozlowski, the Company's former chief executive officer, in the first quarter of fiscal 2014, the parties signed an agreement resolving all outstanding disputes, with Mr. Kozlowski agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements. As a result, in the first quarter of fiscal 2014, the Company reversed a non-cash net liability of approximately $92 million which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations for the amounts allegedly due to him.  Pursuant to the settlement agreement, Tyco will be entitled to a portion of the proceeds, if any, from the future sale of certain assets owned by Mr. Kozlowski, the timing and amount of which is uncertain.  During the quarter ended June 26, 2015, the Company received approximately $4 million in cash from the sale of property owned by Mr. Kozlowski, $2 million of which will be shared pursuant to the terms of a legacy class action lawsuit, resulting in a net recovery of $2 million for the Company, which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations.  The cash received has been classified as restricted.

[0000833444-15-000062:notes:35]
With respect to Mark Swartz, the Company's former chief financial officer, in November 2014, the parties reached a definitive agreement to resolve all outstanding disputes, with Mr. Swartz agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements alleged to have existed between him and the Company.  In the first quarter of fiscal 2015, the Company also received approximately $12 million in cash from Mr. Swartz, $5 million of which will be shared pursuant to the terms of a legacy class action lawsuit, resulting in a net recovery of $7 million for the Company, which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations. The cash received has been classified as restricted.

[0000833444-15-000062:notes:36]
Environmental Matters

[0000833444-15-000062:notes:37]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of June 26, 2015, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $29 million to $72 million. As of June 26, 2015, Tyco concluded that the best estimate within this range is approximately $33 million, of which $15 million is included in Accrued and other current liabilities and $18 million is included in Other liabilities in the Company's Consolidated Balance Sheet.

[0000833444-15-000062:notes:38]
The majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. Prior to Tyco's acquisition, Ansul manufactured arsenic-based agricultural herbicides at the Marinette facility, which resulted in significant arsenic contamination of soil and groundwater on the Marinette site and in parts of the adjoining Menominee River. Ansul has been engaged in ongoing remediation efforts at the Marinette site since 1990, and in February 2009 entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the Marinette site. Under this agreement, Ansul's principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. As of June 26, 2015, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $20 million to $47 million. The Company's best estimate within that range is approximately $23 million, of which $11 million is included in Accrued and other current liabilities and $12 million is included in Other liabilities in the Company's Consolidated Balance Sheet.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor the arsenic contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.

[0000833444-15-000062:notes:39]
Asbestos Matters

[0000833444-15-000062:notes:40]
The Company and certain of its subsidiaries, including Yarway Corporation (“Yarway”) and Grinnell LLC (“Grinnell”), along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. Over 90% of cases pending against affiliates of the Company have been filed against Yarway or Grinnell, and have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components. Claims filed against Yarway derive from Yarway’s purported use of asbestos-containing gaskets and packing in the sale or distribution of steam valves and traps and from its alleged manufacture of asbestos-containing expansion joint packing. Yarway’s alleged manufacture, distribution and/or sale of asbestos-containing materials ceased by 1988, and Yarway ceased substantially all of its manufacturing, distribution and sales operations in 2003. Claims filed against Grinnell typically allege that it manufactured, sold or distributed valves, gaskets, piping and sprinkler systems containing asbestos.

[0000833444-15-000062:notes:41]
As of June 26, 2015, the Company has determined that there were approximately 3,400 claims pending against it. This amount reflects the Company's current estimate of the number of viable claims made against it, excludes any claims against Yarway, and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties. As a result of the Yarway bankruptcy filing described below, claims against Yarway have been stayed since April 2013.

[0000833444-15-000062:notes:42]
As of June 26, 2015, the Company's estimated net liability, including Yarway, recorded within the Company's Consolidated Balance Sheet is $331 million.  The net liability is comprised of a liability for pending and future claims and related defense costs of $838 million, of which $344 million is recorded in Accrued and other current liabilities, and $494 million is recorded in Other liabilities.  The Company also maintains separate cash, investment and other assets of $507 million, of which $44 million is recorded in Prepaid expenses and other current assets, and $463 million is recorded in Other assets.  Assets include $16 million of cash and $275 million of investments, which have all been designated as restricted.  The Company believes that the asbestos related liabilities and insurance related assets as of June 26, 2015 are appropriate.  As of September 26, 2014, the Company's estimated net liability, including Yarway, of $608 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs of $853 million, and separately as an asset for insurance recoveries of $245 million.

[0000833444-15-000062:notes:43]
Yarway

[0000833444-15-000062:notes:44]
As previously disclosed, on April 22, 2013 Yarway filed a voluntary petition for relief under Chapter 11 of the U.S. Bankruptcy Code (“Chapter 11”) in the United States Bankruptcy Court for the District of Delaware (“Bankruptcy Court”). As a result of this filing, the continuation or commencement of asbestos-related litigation against Yarway has been enjoined by the automatic stay imposed by the U.S. Bankruptcy Code. Yarway's goal has been to negotiate, obtain approval of, and consummate a plan of reorganization that establishes a trust to fairly and equitably value and pay current and future Yarway asbestos claims, and that, in exchange for funding of the trust by the Company and/or its subsidiaries, provides permanent injunctive relief protecting the Company, each of its current and former affiliates and various other parties (the “Company Protected Parties”) from any further asbestos claims based on products manufactured, sold, and/or distributed by Yarway. On October 9, 2014, the Company reached an agreement in principle with Yarway, the Official Committee of Asbestos Claimants (“ACC”) appointed in the Yarway Chapter 11 case as the representative of current Yarway asbestos claimants, and the Future Claimants Representative (“FCR”) appointed in the Yarway Chapter 11 case as the representative of future Yarway asbestos claimants, to fund a section 524(g) trust for the resolution and payment of current and future Yarway asbestos claims. The agreement in principle will be implemented through a Chapter 11 plan of reorganization for Yarway, and is intended to resolve the potential liability of the Company Protected Parties for pending and future derivative personal injury claims related to exposure to asbestos-containing products that were allegedly manufactured, distributed, and/or sold by Yarway (“Yarway Asbestos Claims”). Under the Chapter 11 plan, an asbestos settlement trust (the “Yarway Trust”) that conforms to the provisions of Section 524(g) of the U.S. Bankruptcy Code will be established and, on the effective date of the Chapter 11 plan, the Company and Yarway will contribute to the Yarway Trust a total of approximately $325 million in cash (“Settlement Consideration”), which includes approximately $100 million relating to the settlement of intercompany amounts allegedly due to Yarway. In exchange for the Settlement Consideration, each of the Company Protected Parties will receive the benefit of a release from Yarway and an injunction under section 524(g) of the Bankruptcy Code permanently enjoining the assertion of Yarway Asbestos Claims against those Parties.  On April 8, 2015, following the approval of the Plan by the required number of Yarway's current asbestos claimants, the Bankruptcy Court issued an order confirming the Plan, and on July 14, 2015, the United States District Court for the District of Delaware affirmed the Plan.  Yarway expects to schedule an effective date for the Plan in August 2015.

[0000833444-15-000062:notes:45]
On the effective date of the Plan, the Company and Yarway will pay the Settlement Consideration and Yarway Asbestos Claims against the Company Protected Parties will be permanently enjoined. Yarway is anticipated to become a wholly-owned subsidiary of the Yarway Trust and, accordingly, would no longer be owned by or be part of a consolidated group with the Company.  As a result of the agreement in principle to settle, the Company recorded a charge of $225 million in Selling, general and administrative expenses in the Consolidated Statement of Operations during the fourth fiscal quarter of 2014.

[0000833444-15-000062:notes:46]
As a result of filing the voluntary bankruptcy petition during the third quarter of fiscal 2013, the Company recorded an expected loss upon deconsolidation of $10 million related to the Yarway Chapter 11 filing, which continues to represent the Company’s best estimate of its loss.

[0000833444-15-000062:notes:47]
Other Claims

[0000833444-15-000062:notes:48]
The Company continuously assesses the sufficiency of its estimated liability for pending and future asbestos claims and defense costs. On a quarterly basis, the Company evaluates actual experience regarding asbestos claims filed, settled and dismissed, amounts paid in settlements, and the recoverability of its insurance assets. If and when data from actual experience demonstrate an unfavorable discernible trend, the Company performs a valuation of its asbestos related liabilities and corresponding insurance assets including a comprehensive review of the underlying assumptions. In addition, the Company evaluates its ability to reasonably estimate claim activity beyond its current look-forward period in order to assess whether such period is appropriate. In addition to claims and litigation experience, the Company considers additional qualitative and quantitative factors such as changes in legislation, the legal environment, the Company’s strategy in managing claims and obtaining insurance, including its defense strategy, and health related trends in the overall population of individuals potentially exposed to asbestos. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance assets is warranted.

[0000833444-15-000062:notes:49]
During the fourth quarter of fiscal 2014, the Company concluded that an unfavorable trend had developed in actual claim filing activity compared to projected claim filing activity established during the Company’s most recent valuation. Accordingly, the Company, with the assistance of independent actuarial service providers, performed a revised valuation of its asbestos-related liabilities and corresponding insurance assets. As part of the revised valuation, the Company assessed whether a change in its look-forward period was appropriate, taking into consideration its more extensive history and experience with asbestos-related claims and litigation (including its experience with Yarway), and determined that it was possible to make a reasonable estimate of the actuarially determined ultimate risk of loss for pending and unasserted potential future asbestos-related claims through 2056. In connection with the revised valuation, the Company considered a recent settlement with one of its insurers calling for the establishment of a qualified settlement fund, and the results of a separate independent actuarial consulting firm report conducted in the fourth quarter to assist the Company in obtaining insurance to fully fund all estimable asbestos-related claims (excluding Yarway claims) incurred through 2056.

[0000833444-15-000062:notes:50]
The independent actuarial service firm calculated a total estimated liability for asbestos-related claims of the Company, which reflects the Company’s best estimate of its ultimate risk of loss to resolve all pending and future claims (excluding Yarway claims) through 2056, which is the Company’s reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates.

[0000833444-15-000062:notes:51]
In conjunction with determining the total estimated liability, the Company retained an independent third party to assist it in valuing its insurance assets responsive to asbestos-related claims, excluding Yarway claims. These insurance assets represent amounts due to the Company for previously settled claims and the probable reimbursements relating to its total liability for pending and unasserted potential future asbestos claims and defense costs. In calculating this amount, the Company used the estimated asbestos liability for pending and projected future claims and defense costs described above, and it also considered the amount of insurance available, the solvency risk with respect to the Company's insurance carriers, resolution of insurance coverage issues, gaps in coverage, allocation methodologies, and the terms of existing settlement agreements with insurance carriers.

[0000833444-15-000062:notes:52]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-15-000062:notes:53]
In connection with the foregoing, during the third quarter of fiscal 2014, the Company resolved disputes with certain of its historical insurers and agreed that certain insurance proceeds would be used to establish and fund a qualified settlement fund (“QSF”), within the meaning of the Internal Revenue Code, which would be used for the resolution primarily of Grinnell asbestos liabilities of the Company. It is intended that the QSF will receive future insurance payments and proceeds from third party insurers and, in addition, will fund and manage liabilities for certain historical operations of the Company. On January 9, 2015, the Company completed a series of restructuring transactions related to the establishment and funding of a dedicated structure pursuant to which a subsidiary of the Company acquired the assets of Grinnell and transferred cash and other assets totaling approximately $278 million (not including $22 million received by the QSF during the quarter ended December 26, 2014 from historic third-party insurers in settlement of coverage disputes) to the structure. As part of the restructuring, subsidiaries in the structure assumed certain liabilities related to historic Grinnell, Scott and Figgie operations, including all historical Grinnell asbestos liabilities, and such subsidiaries purchased additional insurance by, through or from a wholly-owned subsidiary in the structure in order to supplement and enhance existing insurance assets. The structure and the QSF fully fund all historic Grinnell asbestos liabilities and provide for the efficient and streamlined management of claims related thereto.

[0000833444-15-000062:notes:54]
The Company consolidates the qualified settlement fund and related entities that were established for the purpose of managing and resolving the liabilities described above. Although the entities in the dedicated structure serve the specific purpose of managing certain liabilities, each entity in the structure is a wholly-owned indirect subsidiary of the Company, and therefore is required to be consolidated under U.S. generally accepted accounting principles.

[0000833444-15-000062:notes:55]
Tax Matters

[0000833444-15-000062:notes:56]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation. The issues and proposed adjustments related to such years are generally subject to the sharing provisions of a tax sharing agreement entered in 2007 with Medtronic and TE Connectivity (the "2007 Tax Sharing Agreement") under which Tyco, Medtronic and TE Connectivity share 27%, 42% and 31%, respectively, of shared income tax liabilities that arise from adjustments made by tax authorities to Tyco's, Medtronic's and TE Connectivity's U.S. and certain non-U.S. income tax returns. The costs and expenses associated with the management of these shared tax liabilities are generally shared equally among the parties. Tyco has previously disclosed that in connection with U.S. federal tax audits, the IRS has raised a number of issues and proposed tax adjustments for periods beginning with the 1997 tax year. Although Tyco has been able to resolve substantially all of the issues and adjustments proposed by the IRS for tax years through 2007, it has not been able to resolve matters related to the treatment of certain intercompany debt transactions during the period. As a result, on June 20, 2013, Tyco received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owe additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million has been asserted. These amounts exclude interest and do not reflect the impact on subsequent periods if the IRS position described below is ultimately proved correct.

[0000833444-15-000062:notes:57]
The IRS asserted in the Notices of Deficiency that substantially all of Tyco's intercompany debt originated during the 1997 - 2000 period should not be treated as debt for U.S. federal income tax purposes, and has disallowed interest and related deductions recognized on U.S. income tax returns totaling approximately $2.9 billion. Tyco strongly disagrees with the IRS position and has filed petitions with the U.S. Tax Court contesting the IRS proposed adjustments. A trial date has been set for October 2016. Tyco believes that it has meritorious defenses for its tax filings, that the IRS positions with regard to these matters are inconsistent with the applicable tax laws and existing Treasury regulations, and that the previously reported taxes for the years in question are appropriate.

[0000833444-15-000062:notes:58]
No payments with respect to these matters would be required until the dispute is definitively resolved, which, based on the experience of other companies, could take several years. Tyco believes that its income tax reserves and the liabilities recorded in the Consolidated Balance Sheet for the tax sharing agreements continue to be appropriate. However, the ultimate resolution of these matters, and the impact of that resolution, are uncertain and could have a material impact on Tyco's financial condition, results of operations and cash flows. In particular, if the IRS is successful in asserting its claim, it would have an adverse impact on interest deductions related to the same intercompany debt in subsequent time periods, totaling approximately $6.6 billion, which is expected to be disallowed by the IRS.

[0000833444-15-000062:notes:59]
See Note 6 for additional information related to income tax matters.

[0000833444-15-000062:notes:60]
Other Matters

[0000833444-15-000062:notes:61]
As previously disclosed, SimplexGrinnell LP (“SG”), a subsidiary of the Company in the North America Installation & Services segment, has been named as a defendant in lawsuits in several jurisdictions seeking damages for SG’s alleged failure to pay prevailing wages and for other pay-related claims.  Through the first quarter of fiscal 2015, the Company had recorded a total of approximately $17 million in charges related to these lawsuits, which was recorded in the Cost of services within the Consolidated Statement of Operations.  During the quarter ended March 27, 2015, the Company agreed in principle to settle all outstanding lawsuits for a total of approximately $14 million.

[0000833444-15-000062:notes:62]
During the first quarter of fiscal 2015, the Company received and responded to inquiries from the U.S. Department of the Navy regarding the formulation of certain aqueous film forming foam ("AFFF") concentrates. The Company investigated such matters and ceased selling certain AFFF and other foam products pending the outcome of its investigation.  During the course of the investigation, three AFFF products were removed from the Navy’s Qualified Products List ("QPL"); one AFFF product remains on the QPL. The Company has shared the results of its investigation with appropriate governmental authorities and is also communicating with the government regarding the re-qualification of these products.  The government has confirmed that it considers the Company to be “presently responsible,” and that no suspension or debarment is warranted.  At this time, we cannot predict the outcome of these inquiries and whether this will result in further action by the Navy or other governmental authorities, but it is possible that the Company could be required to pay material fines, consent to injunctions on future conduct, or suffer other criminal or civil penalties or adverse impacts, including being subject to lawsuits brought by private litigants.

[0000833444-15-000062:notes:63]
In addition to the foregoing, the Company is subject to claims and suits, including from time to time, contractual disputes and product and general liability claims, incidental to present and former operations, acquisitions and dispositions. With respect to many of these claims, the Company either self-insures or maintains insurance through third-parties, with varying deductibles. While the ultimate outcome of these matters cannot be predicted with certainty, the Company believes that the resolution of any such proceedings, whether the underlying claims are covered by insurance or not, will not have a material adverse effect on the Company's financial condition, results of operations or cash flows beyond amounts recorded for such matters.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-15-000062:notes:64]
[same as prior period, unchanged from 0000833444-15-000032:notes:64]

[0000833444-15-000062:notes:65]
[same as prior period, unchanged from 0000833444-15-000032:notes:65]

[0000833444-15-000062:notes:66]
[same as prior period, unchanged from 0000833444-15-000032:notes:66]

[0000833444-15-000062:notes:67]
For the Quarter Ended June 26, 2015

[0000833444-15-000062:notes:68]
[same as prior period, unchanged from 0000833444-15-000032:notes:68]

[0000833444-15-000062:notes:69]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,489 |  |  | $ | — |  |  | $ | 2,489 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 1,025 |  |  | — |  |  | 1,025 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 548 |  |  | — |  |  | 548 |  |
| Selling, general and administrative expenses | 1 |  |  | — |  |  | — |  |  | 624 |  |  | — |  |  | 625 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 38 |  |  | — |  |  | 38 |  |
| Operating (loss) income | (1 | ) |  | — |  |  | — |  |  | 254 |  |  | — |  |  | 253 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Interest expense | — |  |  | — |  |  | (25 | ) |  | (1 | ) |  | — |  |  | (26 | ) |
| Other income, net | — |  |  | — |  |  | 1 |  |  | 5 |  |  | — |  |  | 6 |  |
| Equity in net income of subsidiaries | 145 |  |  | 165 |  |  | 166 |  |  | — |  |  | (476 | ) |  | — |  |
| Intercompany interest and fees | 12 |  |  | — |  |  | 23 |  |  | (35 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 156 |  |  | 165 |  |  | 165 |  |  | 227 |  |  | (476 | ) |  | 237 |  |
| Income tax expense | — |  |  | — |  |  | — |  |  | (49 | ) |  | — |  |  | (49 | ) |
| Income from continuing operations | 156 |  |  | 165 |  |  | 165 |  |  | 178 |  |  | (476 | ) |  | 188 |  |
| Loss from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | (32 | ) |  | — |  |  | (32 | ) |
| Net income | 156 |  |  | 165 |  |  | 165 |  |  | 146 |  |  | (476 | ) |  | 156 |  |
| Net income attributable to Tyco ordinary shareholders | $ | 156 |  |  | $ | 165 |  |  | $ | 165 |  |  | $ | 146 |  |  | $ | (476 | ) |  | $ | 156 |  |

[0000833444-15-000062:notes:70]
[same as prior period, unchanged from 0000833444-15-000032:notes:70]

[0000833444-15-000062:notes:71]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 156 |  |  | $ | 165 |  |  | $ | 165 |  |  | $ | 146 |  |  | $ | (476 | ) |  | $ | 156 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | 28 |  |  | — |  |  | (12 | ) |  | 40 |  |  | (28 | ) |  | 28 |  |
| Defined benefit and post retirement plans | 4 |  |  | — |  |  | — |  |  | 4 |  |  | (4 | ) |  | 4 |  |
| Unrealized gain on marketable securities and derivative instruments | (4 | ) |  | — |  |  | — |  |  | (4 | ) |  | 4 |  |  | (4 | ) |
| Total other comprehensive loss, net of tax | 28 |  |  | — |  |  | (12 | ) |  | 40 |  |  | (28 | ) |  | 28 |  |
| Comprehensive income | 184 |  |  | 165 |  |  | 153 |  |  | 186 |  |  | (504 | ) |  | 184 |  |
| Less: comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 184 |  |  | $ | 165 |  |  | $ | 153 |  |  | $ | 186 |  |  | $ | (504 | ) |  | $ | 184 |  |

[0000833444-15-000062:notes:72]
For the Quarter Ended June 27, 2014

[0000833444-15-000062:notes:73]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | 2,660 |  |  | $ | — |  |  | $ | 2,660 |  |
| Cost of product sales | — |  |  | — |  |  | 1,104 |  |  | — |  |  | 1,104 |  |
| Cost of services | — |  |  | — |  |  | 571 |  |  | — |  |  | 571 |  |
| Selling, general and administrative expenses | 5 |  |  | 1 |  |  | 665 |  |  | — |  |  | 671 |  |
| Separation costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | 17 |  |  | — |  |  | 17 |  |
| Operating (loss) income | (5 | ) |  | (1 | ) |  | 303 |  |  | — |  |  | 297 |  |
| Interest income | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Interest expense | — |  |  | (23 | ) |  | (1 | ) |  | — |  |  | (24 | ) |
| Other (expense) income, net | (1 | ) |  | — |  |  | 1 |  |  | — |  |  | — |  |
| Equity in net income of subsidiaries | 1,468 |  |  | 1,479 |  |  | — |  |  | (2,947 | ) |  | — |  |
| Intercompany interest and fees | (13 | ) |  | 14 |  |  | (1 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 1,449 |  |  | 1,469 |  |  | 306 |  |  | (2,947 | ) |  | 277 |  |
| Income tax benefit (expense) | 1 |  |  | (1 | ) |  | (55 | ) |  | — |  |  | (55 | ) |
| Equity income in earnings of unconsolidated subsidiaries | — |  |  | — |  |  | 215 |  |  | — |  |  | 215 |  |
| Income from continuing operations | 1,450 |  |  | 1,468 |  |  | 466 |  |  | (2,947 | ) |  | 437 |  |
| Income from discontinued operations, net of income taxes | — |  |  | — |  |  | 1,015 |  |  | — |  |  | 1,015 |  |
| Net income | 1,450 |  |  | 1,468 |  |  | 1,481 |  |  | (2,947 | ) |  | 1,452 |  |
| Less: noncontrolling interest in subsidiaries net income | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Net income attributable to Tyco ordinary shareholders | $ | 1,450 |  |  | $ | 1,468 |  |  | $ | 1,479 |  |  | $ | (2,947 | ) |  | $ | 1,450 |  |

[0000833444-15-000062:notes:74]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 1,450 |  |  | $ | 1,468 |  |  | $ | 1,481 |  |  | $ | (2,947 | ) |  | $ | 1,452 |  |
| Other comprehensive income, net of tax |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | 28 |  |  | — |  |  | 28 |  |  | (28 | ) |  | 28 |  |
| Defined benefit and post retirement plans | 9 |  |  | — |  |  | 9 |  |  | (9 | ) |  | 9 |  |
| Total other comprehensive income, net of tax | 37 |  |  | — |  |  | 37 |  |  | (37 | ) |  | 37 |  |
| Comprehensive income | 1,487 |  |  | 1,468 |  |  | 1,518 |  |  | (2,984 | ) |  | 1,489 |  |
| Less: comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 1,487 |  |  | $ | 1,468 |  |  | $ | 1,516 |  |  | $ | (2,984 | ) |  | $ | 1,487 |  |

[0000833444-15-000062:notes:75]
For the Nine Months Ended June 26, 2015

[0000833444-15-000062:notes:76]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 7,397 |  |  | $ | — |  |  | $ | 7,397 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 3,046 |  |  | — |  |  | 3,046 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 1,645 |  |  | — |  |  | 1,645 |  |
| Selling, general and administrative expenses | 6 |  |  | — |  |  | 1 |  |  | 1,918 |  |  | — |  |  | 1,925 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 108 |  |  | — |  |  | 108 |  |
| Operating (loss) income | (6 | ) |  | — |  |  | (1 | ) |  | 680 |  |  | — |  |  | 673 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |  | 11 |  |
| Interest expense | — |  |  | — |  |  | (73 | ) |  | (2 | ) |  | — |  |  | (75 | ) |
| Other income, net | — |  |  | — |  |  | 3 |  |  | 6 |  |  | — |  |  | 9 |  |
| Equity in net income of subsidiaries | 440 |  |  | 456 |  |  | 453 |  |  | — |  |  | (1,349 | ) |  | — |  |
| Intercompany interest and fees | 51 |  |  | — |  |  | 74 |  |  | (125 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 485 |  |  | 456 |  |  | 456 |  |  | 570 |  |  | (1,349 | ) |  | 618 |  |
| Income tax expense | — |  |  | — |  |  | — |  |  | (86 | ) |  | — |  |  | (86 | ) |
| Income from continuing operations | 485 |  |  | 456 |  |  | 456 |  |  | 484 |  |  | (1,349 | ) |  | 532 |  |
| Loss from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | (50 | ) |  | — |  |  | (50 | ) |
| Net income | 485 |  |  | 456 |  |  | 456 |  |  | 434 |  |  | (1,349 | ) |  | 482 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 485 |  |  | $ | 456 |  |  | $ | 456 |  |  | $ | 437 |  |  | $ | (1,349 | ) |  | $ | 485 |  |

[0000833444-15-000062:notes:77]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 485 |  |  | $ | 456 |  |  | $ | 456 |  |  | $ | 434 |  |  | $ | (1,349 | ) |  | $ | 482 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (346 | ) |  | — |  |  | 3 |  |  | (349 | ) |  | 346 |  |  | (346 | ) |
| Defined benefit and post retirement plans | 13 |  |  | — |  |  | — |  |  | 13 |  |  | (13 | ) |  | 13 |  |
| Unrealized gain on marketable securities and derivative instruments | (4 | ) |  | — |  |  | — |  |  | (4 | ) |  | 4 |  |  | (4 | ) |
| Total other comprehensive (loss) income, net of tax | (337 | ) |  | — |  |  | 3 |  |  | (340 | ) |  | 337 |  |  | (337 | ) |
| Comprehensive income | 148 |  |  | 456 |  |  | 459 |  |  | 94 |  |  | (1,012 | ) |  | 145 |  |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 148 |  |  | $ | 456 |  |  | $ | 459 |  |  | $ | 97 |  |  | $ | (1,012 | ) |  | $ | 148 |  |

[0000833444-15-000062:notes:78]
For the Nine Months Ended June 27, 2014

[0000833444-15-000062:notes:79]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | 7,629 |  |  | $ | — |  |  | $ | 7,629 |  |
| Cost of product sales | — |  |  | — |  |  | 3,105 |  |  | — |  |  | 3,105 |  |
| Cost of services | — |  |  | — |  |  | 1,721 |  |  | — |  |  | 1,721 |  |
| Selling, general and administrative expenses | (8 | ) |  | 3 |  |  | 1,881 |  |  | — |  |  | 1,876 |  |
| Separation costs | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | 27 |  |  | — |  |  | 27 |  |
| Operating income (loss) | 8 |  |  | (3 | ) |  | 894 |  |  | — |  |  | 899 |  |
| Interest income | — |  |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Interest expense | — |  |  | (71 | ) |  | (2 | ) |  | — |  |  | (73 | ) |
| Other (expense) income, net | (4 | ) |  | — |  |  | 2 |  |  | — |  |  | (2 | ) |
| Equity in net income of subsidiaries | 1,935 |  |  | 1,990 |  |  | — |  |  | (3,925 | ) |  | — |  |
| Intercompany interest and fees | (11 | ) |  | 31 |  |  | (20 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 1,928 |  |  | 1,947 |  |  | 884 |  |  | (3,925 | ) |  | 834 |  |
| Income tax benefit (expense) | 1 |  |  | (1 | ) |  | (164 | ) |  | — |  |  | (164 | ) |
| Equity income in earnings of unconsolidated subsidiaries | — |  |  | — |  |  | 206 |  |  | — |  |  | 206 |  |
| Income from continuing operations | 1,929 |  |  | 1,946 |  |  | 926 |  |  | (3,925 | ) |  | 876 |  |
| Income from discontinued operations, net of income taxes | (2 | ) |  | — |  |  | 1,057 |  |  | — |  |  | 1,055 |  |
| Net income | 1,927 |  |  | 1,946 |  |  | 1,983 |  |  | (3,925 | ) |  | 1,931 |  |
| Less: noncontrolling interest in subsidiaries net income | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Net income attributable to Tyco ordinary shareholders | $ | 1,927 |  |  | $ | 1,946 |  |  | $ | 1,979 |  |  | $ | (3,925 | ) |  | $ | 1,927 |  |

[0000833444-15-000062:notes:80]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 1,927 |  |  | $ | 1,946 |  |  | $ | 1,983 |  |  | $ | (3,925 | ) |  | $ | 1,931 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (24 | ) |  | — |  |  | (24 | ) |  | 24 |  |  | (24 | ) |
| Defined benefit and post retirement plans | 16 |  |  | — |  |  | 16 |  |  | (16 | ) |  | 16 |  |
| Total other comprehensive loss, net of tax | (8 | ) |  | — |  |  | (8 | ) |  | 8 |  |  | (8 | ) |
| Comprehensive income | 1,919 |  |  | 1,946 |  |  | 1,975 |  |  | (3,917 | ) |  | 1,923 |  |
| Less: comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 1,919 |  |  | $ | 1,946 |  |  | $ | 1,971 |  |  | $ | (3,917 | ) |  | $ | 1,919 |  |

[0000833444-15-000062:notes:81]
[same as prior period, unchanged from 0000833444-15-000032:notes:81]

[0000833444-15-000062:notes:82]
As of June 26, 2015

[0000833444-15-000062:notes:83]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 531 |  |  | $ | — |  |  | $ | 531 |  |
| Accounts receivable, net | — |  |  | — |  |  | — |  |  | 1,775 |  |  | — |  |  | 1,775 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 690 |  |  | — |  |  | 690 |  |
| Intercompany receivables | 17 |  |  | — |  |  | 348 |  |  | 7,430 |  |  | (7,795 | ) |  | — |  |
| Prepaid expenses and other current assets | 1 |  |  | — |  |  | 72 |  |  | 747 |  |  | — |  |  | 820 |  |
| Deferred income taxes | — |  |  | — |  |  | — |  |  | 304 |  |  | — |  |  | 304 |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Total current assets | 18 |  |  | — |  |  | 420 |  |  | 11,490 |  |  | (7,795 | ) |  | 4,133 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | — |  |  | 1,215 |  |  | — |  |  | 1,215 |  |
| Goodwill | — |  |  | — |  |  | — |  |  | 4,291 |  |  | — |  |  | 4,291 |  |
| Intangible assets, net | — |  |  | — |  |  | — |  |  | 890 |  |  | — |  |  | 890 |  |
| Investment in subsidiaries | 11,033 |  |  | 11,275 |  |  | 16,040 |  |  | — |  |  | (38,348 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | — |  |  | 2,947 |  |  | 5,062 |  |  | (8,009 | ) |  | — |  |
| Other assets | 1 |  |  | — |  |  | 32 |  |  | 1,158 |  |  | — |  |  | 1,191 |  |
| Total Assets | $ | 11,052 |  |  | $ | 11,275 |  |  | $ | 19,439 |  |  | $ | 24,106 |  |  | $ | (54,152 | ) |  | $ | 11,720 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 258 |  |  | $ | 19 |  |  | $ | — |  |  | $ | 277 |  |
| Accounts payable | 1 |  |  | — |  |  | — |  |  | 743 |  |  | — |  |  | 744 |  |
| Accrued and other current liabilities | 88 |  |  | — |  |  | 79 |  |  | 1,829 |  |  | — |  |  | 1,996 |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 403 |  |  | — |  |  | 403 |  |
| Intercompany payables | 3,508 |  |  | — |  |  | 3,928 |  |  | 359 |  |  | (7,795 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Total current liabilities | 3,597 |  |  | — |  |  | 4,265 |  |  | 3,359 |  |  | (7,795 | ) |  | 3,426 |  |
| Long-term debt | — |  |  | — |  |  | 1,742 |  |  | 2 |  |  | — |  |  | 1,744 |  |
| Intercompany loans payable | 3,151 |  |  | — |  |  | 1,911 |  |  | 2,947 |  |  | (8,009 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 313 |  |  | — |  |  | 313 |  |
| Other liabilities | — |  |  | — |  |  | 246 |  |  | 1,652 |  |  | — |  |  | 1,898 |  |
| Total Liabilities | 6,748 |  |  | — |  |  | 8,164 |  |  | 8,273 |  |  | (15,804 | ) |  | 7,381 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |  |  |
| Ordinary shares | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |
| Other shareholders' equity | 4,300 |  |  | 11,275 |  |  | 11,275 |  |  | 15,798 |  |  | (38,348 | ) |  | 4,300 |  |
| Total Tyco Shareholders' Equity | 4,304 |  |  | 11,275 |  |  | 11,275 |  |  | 15,798 |  |  | (38,348 | ) |  | 4,304 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 35 |  |  | — |  |  | 35 |  |
| Total Equity | 4,304 |  |  | 11,275 |  |  | 11,275 |  |  | 15,833 |  |  | (38,348 | ) |  | 4,339 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity | $ | 11,052 |  |  | $ | 11,275 |  |  | $ | 19,439 |  |  | $ | 24,106 |  |  | $ | (54,152 | ) |  | $ | 11,720 |  |

[0000833444-15-000062:notes:84]
[same as prior period, unchanged from 0000833444-15-000032:notes:84]

[0000833444-15-000062:notes:85]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | 892 |  |  | $ | — |  |  | $ | 892 |  |
| Accounts receivable, net | — |  |  | — |  |  | 1,734 |  |  | — |  |  | 1,734 |  |
| Inventories | — |  |  | — |  |  | 625 |  |  | — |  |  | 625 |  |
| Intercompany receivables | 18 |  |  | 245 |  |  | 8,102 |  |  | (8,365 | ) |  | — |  |
| Prepaid expenses and other current assets | 7 |  |  | 62 |  |  | 982 |  |  | — |  |  | 1,051 |  |
| Deferred income taxes | — |  |  | — |  |  | 304 |  |  | — |  |  | 304 |  |
| Assets held for sale | — |  |  | — |  |  | 180 |  |  | — |  |  | 180 |  |
| Total current assets | 25 |  |  | 307 |  |  | 12,819 |  |  | (8,365 | ) |  | 4,786 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | 1,262 |  |  | — |  |  | 1,262 |  |
| Goodwill | — |  |  | — |  |  | 4,122 |  |  | — |  |  | 4,122 |  |
| Intangible assets, net | — |  |  | — |  |  | 712 |  |  | — |  |  | 712 |  |
| Investment in subsidiaries | 12,738 |  |  | 16,207 |  |  | — |  |  | (28,945 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | 3,693 |  |  | 5,346 |  |  | (9,039 | ) |  | — |  |
| Other assets | 26 |  |  | 4 |  |  | 897 |  |  | — |  |  | 927 |  |
| Total Assets | $ | 12,789 |  |  | $ | 20,211 |  |  | $ | 25,158 |  |  | $ | (46,349 | ) |  | $ | 11,809 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |
| Accounts payable | 1 |  |  | — |  |  | 824 |  |  | — |  |  | 825 |  |
| Accrued and other current liabilities | 191 |  |  | 23 |  |  | 1,900 |  |  | — |  |  | 2,114 |  |
| Deferred revenue | — |  |  | — |  |  | 400 |  |  | — |  |  | 400 |  |
| Intercompany payables | 3,517 |  |  | 4,593 |  |  | 255 |  |  | (8,365 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | 118 |  |  | — |  |  | 118 |  |
| Total current liabilities | 3,709 |  |  | 4,616 |  |  | 3,517 |  |  | (8,365 | ) |  | 3,477 |  |
| Long-term debt | — |  |  | 1,441 |  |  | 2 |  |  | — |  |  | 1,443 |  |
| Intercompany loans payable | 4,180 |  |  | 1,888 |  |  | 2,971 |  |  | (9,039 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | 335 |  |  | — |  |  | 335 |  |
| Other liabilities | 253 |  |  | — |  |  | 1,618 |  |  | — |  |  | 1,871 |  |
| Total Liabilities | 8,142 |  |  | 7,945 |  |  | 8,443 |  |  | (17,404 | ) |  | 7,126 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |
| Ordinary shares | 208 |  |  | — |  |  | — |  |  | — |  |  | 208 |  |
| Ordinary shares held in treasury | — |  |  | — |  |  | (2,515 | ) |  | — |  |  | (2,515 | ) |
| Other shareholders' equity | 4,439 |  |  | 12,266 |  |  | 19,194 |  |  | (28,945 | ) |  | 6,954 |  |
| Total Tyco Shareholders' Equity | 4,647 |  |  | 12,266 |  |  | 16,679 |  |  | (28,945 | ) |  | 4,647 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Total Equity | 4,647 |  |  | 12,266 |  |  | 16,702 |  |  | (28,945 | ) |  | 4,670 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity | $ | 12,789 |  |  | $ | 20,211 |  |  | $ | 25,158 |  |  | $ | (46,349 | ) |  | $ | 11,809 |  |

[0000833444-15-000062:notes:86]
[same as prior period, unchanged from 0000833444-15-000032:notes:86]

[0000833444-15-000062:notes:87]
|  | TycoInternational plc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 94 |  |  | $ | — |  |  | $ | (525 | ) |  | $ | 942 |  |  | $ | — |  |  | $ | 511 |  |
| Net cash used in discontinued operating activities | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (183 | ) |  | — |  |  | (183 | ) |
| Proceeds from disposal of assets | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | — |  |  | (525 | ) |  | — |  |  | (525 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | — |  |  | (13 | ) |  | — |  |  | (13 | ) |
| Divestiture of businesses, net of cash divested | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net increase in intercompany loans | — |  |  | — |  |  | (41 | ) |  | — |  |  | 41 |  |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | 4 |  |  | 279 |  |  | — |  |  | 283 |  |
| Purchases of investments | — |  |  | — |  |  | (1 | ) |  | (289 | ) |  | — |  |  | (290 | ) |
| Increase in restricted cash | — |  |  | — |  |  | — |  |  | (27 | ) |  | — |  |  | (27 | ) |
| Net cash used in investing activities | — |  |  | — |  |  | (38 | ) |  | (755 | ) |  | 41 |  |  | (752 | ) |
| Net cash used in discontinued investing activities | — |  |  | — |  |  | — |  |  | (37 | ) |  | — |  |  | (37 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt | — |  |  | — |  |  | 258 |  |  | — |  |  | — |  |  | 258 |  |
| Repayment of short-term debt | — |  |  | — |  |  | (258 | ) |  | (1 | ) |  | — |  |  | (259 | ) |
| Proceeds from issuance of long-term debt | — |  |  | — |  |  | 567 |  |  | 3 |  |  | — |  |  | 570 |  |
| Proceeds from exercise of share options | 63 |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 70 |  |
| Dividends paid | (237 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (237 | ) |
| Repurchase of ordinary shares by treasury | — |  |  | — |  |  | — |  |  | (417 | ) |  | — |  |  | (417 | ) |
| Net intercompany loan borrowings | 83 |  |  | — |  |  | — |  |  | (42 | ) |  | (41 | ) |  | — |  |
| Transfer to discontinued operations | — |  |  | — |  |  | — |  |  | (38 | ) |  | — |  |  | (38 | ) |
| Payment of contingent consideration | — |  |  | — |  |  | — |  |  | (23 | ) |  | — |  |  | (23 | ) |
| Other | (3 | ) |  | — |  |  | (4 | ) |  | (19 | ) |  | — |  |  | (26 | ) |
| Net cash (used in) provided by financing activities | (94 | ) |  | — |  |  | 563 |  |  | (530 | ) |  | (41 | ) |  | (102 | ) |
| Net cash provided by discontinued financing activities | — |  |  | — |  |  | — |  |  | 38 |  |  | — |  |  | 38 |  |
| Effect of currency translation on cash | — |  |  | — |  |  | — |  |  | (18 | ) |  | — |  |  | (18 | ) |
| Net decrease in cash and cash equivalents | — |  |  | — |  |  | — |  |  | (361 | ) |  | — |  |  | (361 | ) |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | — |  |  | 892 |  |  | — |  |  | 892 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 531 |  |  | $ | — |  |  | $ | 531 |  |

[0000833444-15-000062:notes:88]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (184 | ) |  | $ | 455 |  |  | $ | 247 |  |  | $ | — |  |  | $ | 518 |  |
| Net cash provided by discontinued operating activities | — |  |  | — |  |  | 102 |  |  | — |  |  | 102 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | (210 | ) |  | — |  |  | (210 | ) |
| Proceeds from disposal of assets | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (63 | ) |  | — |  |  | (63 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | (20 | ) |  | — |  |  | (20 | ) |
| Net increase in intercompany loans | — |  |  | (446 | ) |  | — |  |  | 446 |  |  | — |  |
| Increase in investment in subsidiaries | (4 | ) |  | (9 | ) |  | 4 |  |  | 9 |  |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | 283 |  |  | — |  |  | 283 |  |
| Purchases of investments | — |  |  | — |  |  | (332 | ) |  | — |  |  | (332 | ) |
| Sale of equity investment | — |  |  | — |  |  | 250 |  |  | — |  |  | 250 |  |
| Decrease in restricted cash | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Other | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net cash used in investing activities | (4 | ) |  | (455 | ) |  | (79 | ) |  | 455 |  |  | (83 | ) |
| Net cash provided by discontinued investing activities | — |  |  | — |  |  | 1,789 |  |  | — |  |  | 1,789 |  |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt | — |  |  | 830 |  |  | — |  |  | — |  |  | 830 |  |
| Repayment of short-term debt | — |  |  | (830 | ) |  | (1 | ) |  | — |  |  | (831 | ) |
| Proceeds from exercise of share options | — |  |  | — |  |  | 79 |  |  | — |  |  | 79 |  |
| Dividends paid | (231 | ) |  | — |  |  | — |  |  | — |  |  | (231 | ) |
| Repurchase of ordinary shares by treasury | — |  |  | — |  |  | (806 | ) |  | — |  |  | (806 | ) |
| Net intercompany loan borrowings | 419 |  |  | — |  |  | 27 |  |  | (446 | ) |  | — |  |
| Increase in equity from parent | — |  |  | — |  |  | 9 |  |  | (9 | ) |  | — |  |
| Transfer from discontinued operations | — |  |  | — |  |  | 1,891 |  |  | — |  |  | 1,891 |  |
| Other | — |  |  | — |  |  | (10 | ) |  | — |  |  | (10 | ) |
| Net cash provided by financing activities | 188 |  |  | — |  |  | 1,189 |  |  | (455 | ) |  | 922 |  |
| Net cash used in discontinued financing activities | — |  |  | — |  |  | (1,891 | ) |  | — |  |  | (1,891 | ) |
| Effect of currency translation on cash | — |  |  | — |  |  | (8 | ) |  | — |  |  | (8 | ) |
| Net decrease in cash and cash equivalents | — |  |  | — |  |  | 1,349 |  |  | — |  |  | 1,349 |  |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | 563 |  |  | — |  |  | 563 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | 1,912 |  |  | $ | — |  |  | $ | 1,912 |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-15-000062:notes:89]
Debt

[0000833444-15-000062:notes:90]
Debt as of June 26, 2015 and September 26, 2014 is as follows ($ in millions):

[0000833444-15-000062:notes:91]
|  | As of |
|  | June 26, 2015 |  | September 26, 2014 |
| 3.375% public notes due 2015 (1) | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | 364 |  |  | 364 |  |
| 7.0% public notes due 2019 | 245 |  |  | 245 |  |
| 6.875% public notes due 2021 | 465 |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% public notes due 2025 | 559 |  |  | — |  |
| Other (2) | 21 |  |  | 22 |  |
| Total debt | 2,021 |  |  | 1,463 |  |
| Less current portion | 277 |  |  | 20 |  |
| Long-term debt | $ | 1,744 |  |  | $ | 1,443 |  |

[0000833444-15-000062:notes:92]
_______________________________________________________________________________

[0000833444-15-000062:notes:93]
(1) $258 million of 3.375% public notes due October 2015 is included in the current portion of debt as of June 26, 2015.

[0000833444-15-000062:notes:94]
(2)  $19 million and $20 million, respectively, of the amount shown as other is included in the current portion of the Company's total debt as of June 26, 2015 and September 26, 2014.

[0000833444-15-000062:notes:95]
Fair Value

[0000833444-15-000062:notes:96]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of June 26, 2015 and September 26, 2014 was $2,000 million and $1,441 million, respectively.  The Company has determined the fair value of such debt to be $2,177 million and $1,670 million as of June 26, 2015 and September 26, 2014, respectively.  The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets.  As of June 26, 2015 and September 26, 2014, $2,000 million and $1,441 million, respectively, of the Company's debt, which is actively traded and subject to the fair value disclosure requirements, is classified as Level 1 in the fair value hierarchy.

[0000833444-15-000062:notes:97]
Commercial Paper

[0000833444-15-000062:notes:98]
From time to time, the Company's wholly-owned subsidiary, Tyco International Finance S.A. ("TIFSA") may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued on a private placement basis under the commercial paper program is $1 billion as of June 26, 2015.  As of June 26, 2015 and September 26, 2014, TIFSA had no commercial paper outstanding.

[0000833444-15-000062:notes:99]
Credit Facilities

[0000833444-15-000062:notes:100]
The Company's committed revolving credit facility totaled $1 billion as of June 26, 2015. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of June 26, 2015 and September 26, 2014, there were no amounts drawn under the Company's revolving credit facility. Interest under the revolving credit facility is variable and is calculated by reference to LIBOR or an alternate base rate.

[0000833444-15-000062:notes:101]
Debt Issuance/Repayment

[0000833444-15-000062:notes:102]
On February 25, 2015, TIFSA issued €500 million aggregate principal amount of 1.375% Notes due February 25, 2025 (the "Notes"), which are fully and unconditionally guaranteed by each of the Company and Tyco Fire & Security Finance S.C.A.  TIFSA received total net proceeds of approximately $563 million after deducting debt issuance costs of approximately $5 million and a debt discount of approximately $1 million.  The net proceeds were made available for general corporate purposes.  The Notes are TIFSA’s senior unsecured obligations and rank equally in right of payment with all of its existing and future senior debt, and senior to any subordinated indebtedness that TIFSA may incur.  The Notes were designated as a net investment hedge.  See Note 10.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-15-000062:notes:103]
[same as prior period, unchanged from 0000833444-15-000032:notes:102]

[0000833444-15-000062:notes:104]
[same as prior period, unchanged from 0000833444-15-000032:notes:103]

[0000833444-15-000062:notes:105]
[same as prior period, unchanged from 0000833444-15-000032:notes:104]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-15-000062:notes:106]
[same as prior period, unchanged from 0000833444-15-000032:notes:105]

[0000833444-15-000062:notes:107]
[same as prior period, unchanged from 0000833444-15-000032:notes:106]

[0000833444-15-000062:notes:108]
During fiscal 2014, the Company announced that it intended to sell several businesses in the ROW Installation & Services segment. The Company completed the sale of these businesses during the quarter ended June 26, 2015, and recorded a loss on sale of $29 million and $28 million in (Loss) income from discontinued operations, net of taxes on the Consolidated Statements of Operations for the quarter and nine months ended June 26, 2015, respectively.  These businesses were accounted for as held for sale on the Consolidated Balance Sheets as of September 26, 2014 and their results of operations have been presented within discontinued operations on the Consolidated Statements of Operations during the quarters and nine months ended June 26, 2015 and June 27, 2014.

[0000833444-15-000062:notes:109]
In addition, during the quarter ended June 26, 2015, the Company completed the sale of a business in the ROW Installation & Services segment.  The Company recorded $22 million in Selling, general and administrative expenses on the Consolidated Statements of Operations for an anticipated loss on disposal during the quarter ended March 27, 2015.  This business was presented as held for sale as of September 26, 2014; however, it did not meet the criteria to be classified as a discontinued operation, and thus its results of operations were included in continuing operations in the Consolidated Financial Statements.

[0000833444-15-000062:notes:110]
During the quarter ended March 27, 2015, the Company concluded that a business in the ROW Installation & Services segment which it intends to sell met the criteria to be classified as held for sale. This business is accounted for as held for sale on the Consolidated Balance Sheets as of June 26, 2015 and September 26, 2014, and its results of operations have been presented as discontinued operations on the Consolidated Statements of Operations during the quarters and nine months ended June 26, 2015 and June 27, 2014. The Company expects to complete the sale of this business during the first half of fiscal 2016.

[0000833444-15-000062:notes:111]
[same as prior period, unchanged from 0000833444-15-000032:notes:109]

[0000833444-15-000062:notes:112]
[same as prior period, unchanged from 0000833444-15-000032:notes:110]

[0000833444-15-000062:notes:113]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Net revenue | $ | 5 |  |  | $ | 87 |  |  | $ | 15 |  |  | $ | 397 |  |
| Pre-tax (loss) income from discontinued operations | (3 | ) |  | 8 |  |  | (12 | ) |  | 59 |  |
| Pre-tax separation loss included within discontinued operations (See Note 2) | — |  |  | (1 | ) |  | — |  |  | (2 | ) |
| Pre-tax (loss) gain on sale of discontinued operations | (29 | ) |  | 1,179 |  |  | (28 | ) |  | 1,175 |  |
| Income tax expense | — |  |  | (171 | ) |  | (10 | ) |  | (177 | ) |
| (Loss) income from discontinued operations, net of income taxes | $ | (32 | ) |  | $ | 1,015 |  |  | $ | (50 | ) |  | $ | 1,055 |  |

[0000833444-15-000062:notes:114]
Balance sheet information for the assets and liabilities of businesses classified as held for sale as of June 26, 2015 and September 26, 2014 was as follows ($ in millions):

[0000833444-15-000062:notes:115]
|  | As of |
|  | June 26, 2015 |  | September 26, 2014 |
| Accounts receivable, net | $ | 1 |  |  | $ | 26 |  |
| Inventories | — |  |  | 7 |  |
| Prepaid expenses and other current assets | 1 |  |  | 107 |  |
| Deferred income taxes | 1 |  |  | 3 |  |
| Property, plant and equipment, net | 1 |  |  | 6 |  |
| Goodwill | 1 |  |  | 3 |  |
| Intangible assets, net | 8 |  |  | 25 |  |
| Other assets | — |  |  | 3 |  |
| Total assets | $ | 13 |  |  | $ | 180 |  |
| Accounts payable | 1 |  |  | 48 |  |
| Accrued and other current liabilities | 2 |  |  | 62 |  |
| Deferred revenue | — |  |  | 2 |  |
| Other liabilities | 3 |  |  | 6 |  |
| Total liabilities | $ | 6 |  |  | $ | 118 |  |

[0000833444-15-000062:notes:116]
[same as prior period, unchanged from 0000833444-15-000032:notes:114]


## us-gaap:EarningsPerShareTextBlock

[0000833444-15-000062:notes:117]
[same as prior period, unchanged from 0000833444-15-000032:notes:115]

[0000833444-15-000062:notes:118]
[same as prior period, unchanged from 0000833444-15-000032:notes:116]

[0000833444-15-000062:notes:119]
|  | For the Quarter Ended June 26, 2015 |  | For the Quarter Ended June 27, 2014 |
|  | Income |  | Shares |  | Per ShareAmount |  | Income |  | Shares |  | Per ShareAmount |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 188 |  |  | 421 |  |  | $ | 0.45 |  |  | $ | 435 |  |  | 458 |  |  | $ | 0.95 |  |
| Share options and restricted share awards | — |  |  | 6 |  |  |  |  | — |  |  | 8 |  |  |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations attributable to Tyco ordinary shareholders, giving effect to dilutive adjustments | $ | 188 |  |  | 427 |  |  | $ | 0.44 |  |  | $ | 435 |  |  | 466 |  |  | $ | 0.93 |  |

[0000833444-15-000062:notes:120]
|  | For the Nine Months Ended June 26, 2015 |  | For the Nine Months Ended June 27, 2014 |
|  | Income |  | Shares |  | Per ShareAmount |  | Income |  | Shares |  | Per ShareAmount |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 535 |  |  | 421 |  |  | $ | 1.27 |  |  | $ | 872 |  |  | 461 |  |  | $ | 1.89 |  |
| Share options and restricted share awards | — |  |  | 6 |  |  |  |  | — |  |  | 8 |  |  |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations attributable to Tyco ordinary shareholders, giving effect to dilutive adjustments | $ | 535 |  |  | 427 |  |  | $ | 1.25 |  |  | $ | 872 |  |  | 469 |  |  | $ | 1.86 |  |

[0000833444-15-000062:notes:121]
The computation of diluted earnings per share for the quarter and nine months ended June 26, 2015 excludes the effect of the potential exercise of share options to purchase approximately 3 million shares for both periods and excludes restricted stock units of approximately 1 million and 2 million shares, respectively, for the quarter and nine months ended June 26, 2015 because the effect would be anti-dilutive.

[0000833444-15-000062:notes:122]
The computation of diluted earnings per share for the quarter and nine months ended June 27, 2014 excludes the effect of the potential exercise of share options to purchase approximately 2 million shares for both periods and excludes restricted stock units of approximately 1 million and 2 million shares, respectively, for the quarter and nine months ended June 27, 2014 because the effect would be anti-dilutive.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000833444-15-000062:notes:123]
The following table presents the Company's hierarchy for its assets measured at fair value on a recurring basis as of June 26, 2015 and September 26, 2014 ($ in millions):

[0000833444-15-000062:notes:124]
|  |  |  |  |  |  |  | Consolidated Balance SheetClassification |
|  | As of June 26, 2015 |  | Cash and Cash Equivalents |  | Prepaids andOther CurrentAssets |  | Other Assets |
| Investment Assets: | Level 1 |  | Level 2 |  | Total |  |  |  |
| Cash equivalents | $ | 91 |  |  | $ | — |  |  | $ | 91 |  |  | $ | 91 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (fixed income) (1) | 190 |  |  | — |  |  | 190 |  |  | — |  |  | 15 |  |  | 175 |  |
| Exchange traded funds (equity) (1) | 85 |  |  | — |  |  | 85 |  |  | — |  |  | — |  |  | 85 |  |
| Trading securities: |  |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (equity) | 64 |  |  | — |  |  | 64 |  |  | — |  |  | 64 |  |  | — |  |
|  | $ | 430 |  |  | $ | — |  |  | $ | 430 |  |  | $ | 91 |  |  | $ | 79 |  |  | $ | 260 |  |

[0000833444-15-000062:notes:125]
[same as prior period, unchanged from 0000833444-15-000032:notes:123]

[0000833444-15-000062:notes:126]
|  |  |  |  |  |  |  | Consolidated Balance SheetClassification |
|  | As of September 26, 2014 |  | Cash and Cash Equivalents |  | Prepaids andOther CurrentAssets |
| Investment Assets: | Level 1 |  | Level 2 |  | Total |  |  |
| Cash equivalents | $ | 223 |  |  | $ | — |  |  | $ | 223 |  |  | $ | 223 |  |  | $ | — |  |
| Time deposits | 275 |  |  | — |  |  | 275 |  |  | — |  |  | 275 |  |
| Trading securities: |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (equity) | 62 |  |  | — |  |  | 62 |  |  | — |  |  | 62 |  |
|  | $ | 560 |  |  | $ | — |  |  | $ | 560 |  |  | $ | 223 |  |  | $ | 337 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000833444-15-000062:notes:127]
[same as prior period, unchanged from 0000833444-15-000032:notes:125]

[0000833444-15-000062:notes:128]
The Company's financial instruments consist primarily of cash and cash equivalents, time deposits, accounts receivable, investments, accounts payable, debt and derivative financial instruments. The fair value of cash and cash equivalents, time deposits, accounts receivable, and accounts payable approximated book value as of June 26, 2015 and September 26, 2014. The fair value of derivative financial instruments was not material to any of the periods presented. See below for the fair value of investments and Note 9 for the fair value of debt.

[0000833444-15-000062:notes:129]
[same as prior period, unchanged from 0000833444-15-000032:notes:127]

[0000833444-15-000062:notes:130]
In the normal course of business, Tyco is exposed to market risk arising from changes in currency exchange rates, interest rates and commodity prices. The Company may use derivative financial instruments to manage exposures to foreign currency, interest rate and commodity risks. The Company's objective for utilizing derivative financial instruments is to manage these risks using the most effective methods to eliminate or reduce the impacts of these exposures. The Company does not use derivative financial instruments for trading or speculative purposes.  As of and during the nine months ended June 26, 2015, the Company did not hold or enter into any commodity derivative instruments or interest rate swaps.

[0000833444-15-000062:notes:131]
For derivative instruments that are designated and qualified as hedging instruments for accounting purposes, the Company documents and links the relationships between the hedging instruments and hedged items.  The Company also assesses and documents at the hedge's inception whether the derivatives used in hedging transactions are effective in offsetting changes in fair values associated with the hedged items.  During the quarter ended March 27, 2015, the Company designated its €500 million of 1.375% public notes due February 2025 as a net investment hedge of the Company’s investments in certain of its international subsidiaries that use the Euro as their functional currency and intercompany permanent loans in order to reduce the volatility caused by changes in foreign currency exchange rates of the Euro with respect to the U.S. Dollar.  During the quarter and nine months ended June 26, 2015, the change in the carrying value due to remeasurement of the Euro denominated 2025 Notes resulted in a $12 million loss and an $8 million gain, respectively, reported in Accumulated other comprehensive loss on the Consolidated Balance Sheets. This hedge did not result in any hedge ineffectiveness for the quarter and nine months ended June 26, 2015.  During the quarter and nine months ended June 27, 2014, the Company did not have hedging instruments that were designated and qualified as hedging instruments for accounting purposes.

[0000833444-15-000062:notes:132]
As of June 26, 2015 and September 26, 2014, the total gross notional amount of the Company's foreign exchange contracts was $400 million and $258 million, respectively. The fair value of these derivative financial instruments and impact of such changes in the fair value was not material to the Consolidated Balance Sheets as of June 26, 2015 and September 26, 2014 or Consolidated Statements of Operations and Consolidated Statements of Cash Flows for the quarters and nine months ended June 26, 2015 and June 27, 2014.

[0000833444-15-000062:notes:133]
[same as prior period, unchanged from 0000833444-15-000032:notes:131]

[0000833444-15-000062:notes:134]
[same as prior period, unchanged from 0000833444-15-000032:notes:132]

[0000833444-15-000062:notes:135]
Cash Equivalents and Investments

[0000833444-15-000062:notes:136]
The fair value of cash equivalents approximates carrying value and are included in Level 1.

[0000833444-15-000062:notes:137]
Investments may include marketable securities such as U.S. government obligations, U.S. government agency and corporate debt securities, equity securities, exchange traded funds or time deposits with banks.

[0000833444-15-000062:notes:138]
[same as prior period, unchanged from 0000833444-15-000032:notes:135]

[0000833444-15-000062:notes:139]
[same as prior period, unchanged from 0000833444-15-000032:notes:136]

[0000833444-15-000062:notes:140]
During the quarter and nine months ended June 26, 2015, the Company did not have any significant transfers between levels within the fair value hierarchy.

[0000833444-15-000062:notes:141]
Unrealized gains and losses related to trading securities are recorded in Other (expense) income, net in the Consolidated Statements of Operations.  The Company recorded gains of $1 million and $5 million for the quarter and nine months ended June 26, 2015, respectively.  The Company did not hold these investments during the quarter and nine months ended June 27, 2014.  Unrealized gains and losses related to available for sale securities are recorded in Other comprehensive income.  The Company recorded losses of $6 million for both the quarter and nine months ended June 26, 2015, and losses of $1 million for both the quarter and nine months ended June 27, 2014.

[0000833444-15-000062:notes:142]
[same as prior period, unchanged from 0000833444-15-000032:notes:139]

[0000833444-15-000062:notes:143]
The Company had $1.4 billion and $1.5 billion of intercompany loans designated as permanent in nature as of June 26, 2015 and September 26, 2014, respectively.  Additionally, for the quarters ended June 26, 2015 and June 27, 2014, the Company recorded $40 million of a cumulative translation gain and $3 million of a cumulative translation loss, respectively, through Accumulated other comprehensive loss related to these loans.

[0000833444-15-000062:notes:144]
For the nine months ended June 26, 2015 and June 27, 2014, the Company recorded $105 million of a cumulative translation loss and $1 million of a cumulative translation gain, respectively, through Accumulated other comprehensive loss related to these loans.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-15-000062:notes:145]
[same as prior period, unchanged from 0000833444-15-000032:notes:142]

[0000833444-15-000062:notes:146]
[same as prior period, unchanged from 0000833444-15-000032:notes:143]

[0000833444-15-000062:notes:147]
|  | NA Installation &Services |  | ROWInstallation &Services |  | GlobalProducts |  | Total |
| Gross goodwill | $ | 2,104 |  |  | $ | 1,991 |  |  | $ | 1,824 |  |  | $ | 5,919 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 27, 2013 | 1,978 |  |  | 923 |  |  | 1,257 |  |  | 4,158 |  |
| 2014 activity: |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions/ purchase accounting adjustments | 10 |  |  | 15 |  |  | (4 | ) |  | 21 |  |
| Currency translation | (12 | ) |  | (34 | ) |  | (11 | ) |  | (57 | ) |
| Gross goodwill | $ | 2,102 |  |  | $ | 1,972 |  |  | $ | 1,809 |  |  | $ | 5,883 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 26, 2014 | 1,976 |  |  | 904 |  |  | 1,242 |  |  | 4,122 |  |
| 2015 activity: |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions / purchase accounting adjustments | 15 |  |  | 30 |  |  | 276 |  |  | 321 |  |
| Currency translation | (18 | ) |  | (110 | ) |  | (24 | ) |  | (152 | ) |
| Gross goodwill | $ | 2,099 |  |  | $ | 1,892 |  |  | $ | 2,061 |  |  | $ | 6,052 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of June 26, 2015 | $ | 1,973 |  |  | $ | 824 |  |  | $ | 1,494 |  |  | $ | 4,291 |  |

[0000833444-15-000062:notes:148]
Intangible asset amortization expense for the quarters ended June 26, 2015 and June 27, 2014 was $24 million and $22 million, respectively.  Intangible asset amortization expense for the nine months ended June 26, 2015 and June 27, 2014 was $65 million and $68 million, respectively.

[0000833444-15-000062:notes:149]
The estimated aggregate amortization expense on intangible assets is expected to be approximately $22 million for the remainder of 2015, $87 million for 2016, $78 million for 2017, $73 million for 2018, and $322 million for 2019 and thereafter.


## us-gaap:GuaranteesTextBlock

[0000833444-15-000062:notes:150]
[same as prior period, unchanged from 0000833444-15-000032:notes:147]

[0000833444-15-000062:notes:151]
[same as prior period, unchanged from 0000833444-15-000032:notes:148]

[0000833444-15-000062:notes:152]
[same as prior period, unchanged from 0000833444-15-000032:notes:149]

[0000833444-15-000062:notes:153]
In addition, Tyco historically provided support in the form of financial and/or performance guarantees to various Medtronic, TE Connectivity, ADT and Tyco Flow Control operating entities. In connection with both the 2012 and 2007 Separations, the Company worked with the guarantee counterparties to cancel or assign these guarantees to Medtronic, TE Connectivity, ADT or Pentair, as appropriate. To the extent these guarantees were not assigned prior to the Separation dates, Tyco remained as the guarantor, but was typically indemnified by the former subsidiary. The Company's obligations related to the 2012 Separation were $3 million, which were included in Other liabilities on the Company's Consolidated Balance Sheets as of both June 26, 2015 and September 26, 2014, with an offset to Tyco's shareholders' equity on the 2012 Separation date. The Company's obligations related to the 2007 Separation were $3 million, which were included in Other liabilities on the Company's Consolidated Balance Sheets as of both June 26, 2015 and September 26, 2014, with an offset to Tyco's shareholders' equity on the 2007 Separation date.

[0000833444-15-000062:notes:154]
In disposing of assets or businesses, the Company or its subsidiaries often provides representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities and unidentified tax liabilities and legal fees related to periods prior to disposition. The Company has no reason to believe that these contingencies, if realized, would have a material adverse effect on the Company's financial position, results of operations or cash flows. The Company has recorded liabilities for known indemnifications included as part of environmental liabilities. See Note 11.

[0000833444-15-000062:notes:155]
[same as prior period, unchanged from 0000833444-15-000032:notes:152]

[0000833444-15-000062:notes:156]
The changes in the carrying amount of the Company's warranty accrual from September 26, 2014 to June 26, 2015 were as follows ($ million):

[0000833444-15-000062:notes:157]
| Balance as of September 26, 2014 | $ | 28 |  |
| Warranties issued | 14 |  |
| Changes in estimates | 1 |  |
| Settlements | (11 | ) |
| Currency translation | (1 | ) |
| Balance as of June 26, 2015 | $ | 31 |  |

[0000833444-15-000062:notes:158]
[same as prior period, unchanged from 0000833444-15-000032:notes:155]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-15-000062:notes:159]
[same as prior period, unchanged from 0000833444-15-000032:notes:156]

[0000833444-15-000062:notes:160]
Tyco did not have a significant change to its unrecognized tax benefits during the quarter ended June 26, 2015.

[0000833444-15-000062:notes:161]
[same as prior period, unchanged from 0000833444-15-000032:notes:158]

[0000833444-15-000062:notes:162]
[same as prior period, unchanged from 0000833444-15-000032:notes:159]

[0000833444-15-000062:notes:163]
Based on the current status of its income tax audits, Tyco believes that it is reasonably possible that between nil and $2 million in unrecognized tax benefits may be resolved in the next twelve months.

[0000833444-15-000062:notes:164]
At each balance sheet date, the Company evaluates whether it is more likely than not that Tyco's deferred tax assets will be realized and if sufficient future taxable income will be available by assessing current period and projected operating results and other pertinent data. As of June 26, 2015, Tyco recorded deferred tax assets of approximately $329 million, which is comprised of $2.3 billion gross deferred tax assets net of $2.0 billion valuation allowances.

[0000833444-15-000062:notes:165]
[same as prior period, unchanged from 0000833444-15-000032:notes:162]

[0000833444-15-000062:notes:166]
[same as prior period, unchanged from 0000833444-15-000032:notes:163]

[0000833444-15-000062:notes:167]
[same as prior period, unchanged from 0000833444-15-000032:notes:164]

[0000833444-15-000062:notes:168]
[same as prior period, unchanged from 0000833444-15-000032:notes:165]

[0000833444-15-000062:notes:169]
[same as prior period, unchanged from 0000833444-15-000032:notes:166]

[0000833444-15-000062:notes:170]
[same as prior period, unchanged from 0000833444-15-000032:notes:167]

[0000833444-15-000062:notes:171]
The IRS asserted in the Notices of Deficiency that substantially all of Tyco's intercompany debt originated during the 1997 - 2000 period should not be treated as debt for U.S. federal income tax purposes, and has disallowed interest and related deductions recognized on U.S. income tax returns totaling approximately $2.9 billion. Tyco strongly disagrees with the IRS position and has filed petitions with the U.S. Tax Court contesting the IRS proposed adjustments.  A trial date has been set for October 2016.  Tyco believes that it has meritorious defenses for its tax filings, that the IRS positions with regard to these matters are inconsistent with the applicable tax laws and existing Treasury regulations, and that the previously reported taxes for the years in question are appropriate.

[0000833444-15-000062:notes:172]
[same as prior period, unchanged from 0000833444-15-000032:notes:169]

[0000833444-15-000062:notes:173]
[same as prior period, unchanged from 0000833444-15-000032:notes:170]

[0000833444-15-000062:notes:174]
In addition to dealing with tax liabilities for periods prior to the respective Separations, the 2012 and 2007 Tax Sharing Agreements contain sharing provisions to address the contingencies that the 2012 or 2007 Separations, or internal transactions related thereto, may be deemed taxable by U.S. or non U.S. taxing authorities. In the event the 2012 Separation is determined to be taxable and such determination was the result of actions taken after the 2012 Separations by Tyco, ADT or Pentair, the party responsible for such failure would be responsible for all taxes imposed on each company as a result thereof. If such determination is not the result of actions taken by Tyco, ADT or Pentair after the 2012 Separation, then Tyco, ADT and Pentair would be responsible for any taxes imposed on any of the companies as a result of such determination in the same manner and in the same proportions as described above. Similar provisions exist in the 2007 Tax Sharing Agreement. If either of the 2007 or 2012 Separation, or internal transactions taken in anticipation thereof, were deemed taxable, the associated liability could be significant. Tyco is responsible for all of its own taxes that are not shared pursuant to the 2012 and 2007 Tax Sharing Agreements' sharing formulas. In addition, Pentair and ADT, and Medtronic and TE Connectivity are responsible for their tax liabilities that are not subject to the 2012 or 2007 Tax Sharing Agreements' sharing formula.

[0000833444-15-000062:notes:175]
[same as prior period, unchanged from 0000833444-15-000032:notes:172]

[0000833444-15-000062:notes:176]
The receivables and liabilities related to the 2012 and 2007 Tax Sharing Agreements as of June 26, 2015 and September 26, 2014, are as follows ($ in millions):

[0000833444-15-000062:notes:177]
[same as prior period, unchanged from 0000833444-15-000032:notes:174]

[0000833444-15-000062:notes:178]
[same as prior period, unchanged from 0000833444-15-000032:notes:175]


## us-gaap:InventoryDisclosureTextBlock

[0000833444-15-000062:notes:179]
[same as prior period, unchanged from 0000833444-15-000032:notes:176]

[0000833444-15-000062:notes:180]
[same as prior period, unchanged from 0000833444-15-000032:notes:177]

[0000833444-15-000062:notes:181]
|  | As of |
|  | June 26, 2015 |  | September 26, 2014 |
| Purchased materials and manufactured parts | $ | 184 |  |  | $ | 159 |  |
| Work in process | 85 |  |  | 85 |  |
| Finished goods | 421 |  |  | 381 |  |
| Inventories | $ | 690 |  |  | $ | 625 |  |

[0000833444-15-000062:notes:182]
[same as prior period, unchanged from 0000833444-15-000032:notes:179]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-15-000062:notes:183]
[same as prior period, unchanged from 0000833444-15-000032:notes:180]

[0000833444-15-000062:notes:184]
[same as prior period, unchanged from 0000833444-15-000032:notes:181]

[0000833444-15-000062:notes:185]
|  | U.S. Plans |
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Service cost | $ | 2 |  |  | $ | 2 |  |  | $ | 6 |  |  | $ | 6 |  |
| Interest cost | 9 |  |  | 10 |  |  | 27 |  |  | 28 |  |
| Expected return on plan assets | (14 | ) |  | (14 | ) |  | (42 | ) |  | (38 | ) |
| Amortization of net actuarial loss | 3 |  |  | 3 |  |  | 7 |  |  | 7 |  |
| Net periodic benefit cost | $ | — |  |  | $ | 1 |  |  | $ | (2 | ) |  | $ | 3 |  |

[0000833444-15-000062:notes:186]
|  | Non-U.S. Plans |
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Service cost | $ | 2 |  |  | $ | 2 |  |  | $ | 7 |  |  | $ | 7 |  |
| Interest cost | 14 |  |  | 13 |  |  | 40 |  |  | 41 |  |
| Expected return on plan assets | (19 | ) |  | (17 | ) |  | (58 | ) |  | (55 | ) |
| Amortization of net actuarial loss | 3 |  |  | 3 |  |  | 10 |  |  | 9 |  |
| Net periodic benefit cost | $ | — |  |  | $ | 1 |  |  | $ | (1 | ) |  | $ | 2 |  |

[0000833444-15-000062:notes:187]
[same as prior period, unchanged from 0000833444-15-000032:notes:184]

[0000833444-15-000062:notes:188]
The Company's funding policy is to make contributions in accordance with the laws and customs of the various countries in which it operates and to make discretionary voluntary contributions from time to time. The Company anticipates that it will contribute at least the minimum required to its pension plans in fiscal year 2015 of $13 million for U.S. plans and $23 million for non-U.S. plans. During the quarter ended June 26, 2015, the Company made required contributions of $5 million to its U.S. pension plans and $4 million to its non-U.S. pension plans.  During the nine months ended June 26, 2015, the Company made required contributions of $9 million to its U.S. pension plans and $13 million to its non-U.S. pension plans.

[0000833444-15-000062:notes:189]
[same as prior period, unchanged from 0000833444-15-000032:notes:186]


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-15-000062:notes:190]
[same as prior period, unchanged from 0000833444-15-000032:notes:187]

[0000833444-15-000062:notes:191]
[same as prior period, unchanged from 0000833444-15-000032:notes:188]

[0000833444-15-000062:notes:192]
|  | As of |
|  | June 26, 2015 |  | September 26, 2014 |
| Land | $ | 33 |  |  | $ | 36 |  |
| Buildings | 416 |  |  | 411 |  |
| Subscriber systems | 2,008 |  |  | 2,210 |  |
| Machinery and equipment | 1,280 |  |  | 1,265 |  |
| Construction in progress | 94 |  |  | 90 |  |
| Accumulated depreciation | (2,616 | ) |  | (2,750 | ) |
| Property, plant and equipment, net | $ | 1,215 |  |  | $ | 1,262 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000833444-15-000062:notes:193]
[same as prior period, unchanged from 0000833444-15-000032:notes:190]

[0000833444-15-000062:notes:194]
During fiscal 2015, the Company identified and pursued additional opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across the Company's businesses. The Company expects to incur restructuring and restructuring related charges of approximately $125 million in fiscal 2015, which does not include repositioning charges as described below.

[0000833444-15-000062:notes:195]
[same as prior period, unchanged from 0000833444-15-000032:notes:192]

[0000833444-15-000062:notes:196]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| 2015 actions | $ | 39 |  |  | $ | — |  |  | $ | 97 |  |  | $ | — |  |
| 2014 actions | 1 |  |  | 19 |  |  | 11 |  |  | 28 |  |
| 2013 and prior actions | (2 | ) |  | (2 | ) |  | — |  |  | (1 | ) |
| Total | $ | 38 |  |  | $ | 17 |  |  | $ | 108 |  |  | $ | 27 |  |

[0000833444-15-000062:notes:197]
[same as prior period, unchanged from 0000833444-15-000032:notes:194]

[0000833444-15-000062:notes:198]
Restructuring and asset impairment charges, net, during the quarter and nine months ended June 26, 2015 related to the 2015 actions are as follows ($ in millions):

[0000833444-15-000062:notes:199]
|  | For the Quarter Ended June 26, 2015 |
|  | EmployeeSeverance andBenefits |  | Facility Exit and Other Charges |  | Total |
| NA Installation & Services | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| ROW Installation & Services | 34 |  |  | 1 |  |  | 35 |  |
| Global Products | 1 |  |  | — |  |  | 1 |  |
| Corporate and other | 2 |  |  | — |  |  | 2 |  |
| Total | $ | 38 |  |  | $ | 1 |  |  | $ | 39 |  |

[0000833444-15-000062:notes:200]
|  | For the Nine Months Ended June 26, 2015 |
|  | EmployeeSeverance andBenefits |  | Facility Exit and Other Charges |  | Total |
| NA Installation & Services | $ | 27 |  |  | $ | — |  |  | $ | 27 |  |
| ROW Installation & Services | 48 |  |  | 6 |  |  | 54 |  |
| Global Products | 4 |  |  | — |  |  | 4 |  |
| Corporate and Other | 12 |  |  | — |  |  | 12 |  |
| Total | $ | 91 |  |  | $ | 6 |  |  | $ | 97 |  |

[0000833444-15-000062:notes:201]
The rollforward of the reserves from September 26, 2014 to June 26, 2015 is as follows ($ in millions):

[0000833444-15-000062:notes:202]
| Balance as of September 26, 2014 | $ | — |  |
| Charges | 99 |  |
| Reversals | (2 | ) |
| Utilization | (40 | ) |
| Currency translation | (1 | ) |
| Balance as of June 26, 2015 | $ | 56 |  |

[0000833444-15-000062:notes:203]
Restructuring reserves for businesses that are included within Liabilities held for sale on the Consolidated Balance Sheets are excluded from the table above.  See Note 3.

[0000833444-15-000062:notes:204]
[same as prior period, unchanged from 0000833444-15-000032:notes:200]

[0000833444-15-000062:notes:205]
Restructuring and asset impairment charges, net, during the quarters and nine months ended June 26, 2015 and June 27, 2014 related to the 2014 actions are as follows ($ in millions):

[0000833444-15-000062:notes:206]
|  | For the Quarter Ended June 26, 2015 |  | For the Quarter Ended June 27, 2014 |
|  | EmployeeSeverance andBenefits |  | EmployeeSeverance andBenefits |  | Facility Exit and Other Charges |  | Total |
| NA Installation & Services | $ | (1 | ) |  | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |
| ROW Installation & Services | — |  |  | 7 |  |  | 3 |  |  | 10 |  |
| Global Products | 2 |  |  | 2 |  |  | — |  |  | 2 |  |
| Total | $ | 1 |  |  | $ | 16 |  |  | $ | 3 |  |  | $ | 19 |  |

[0000833444-15-000062:notes:207]
|  | For the Nine Months Ended June 26, 2015 |  | For the Nine Months Ended June 27, 2014 |
|  | EmployeeSeverance andBenefits |  | EmployeeSeverance andBenefits |  | Facility Exit and Other Charges |  | Total |
| NA Installation & Services | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| ROW Installation & Services | — |  |  | 12 |  |  | 3 |  |  | 15 |  |
| Global Products | 11 |  |  | 3 |  |  | — |  |  | 3 |  |
| Total | $ | 11 |  |  | $ | 25 |  |  | $ | 3 |  |  | $ | 28 |  |

[0000833444-15-000062:notes:208]
[same as prior period, unchanged from 0000833444-15-000032:notes:204]

[0000833444-15-000062:notes:209]
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Charges Reflected in SG&A |  | Total |
| NA Installation & Services | $ | 16 |  |  | $ | — |  |  | $ | — |  |  | $ | 16 |  |
| ROW Installation & Services | 18 |  |  | 5 |  |  | — |  |  | 23 |  |
| Global Products | 14 |  |  | — |  |  | 2 |  |  | 16 |  |
| Total | $ | 48 |  |  | $ | 5 |  |  | $ | 2 |  |  | $ | 55 |  |

[0000833444-15-000062:notes:210]
| Balance as of September 26, 2014 | $ | 29 |  |
| Charges | 13 |  |
| Reversals | (2 | ) |
| Utilization | (17 | ) |
| Currency translation | (3 | ) |
| Balance as of June 26, 2015 | $ | 20 |  |

[0000833444-15-000062:notes:211]
[same as prior period, unchanged from 0000833444-15-000032:notes:207]

[0000833444-15-000062:notes:212]
The Company continues to maintain restructuring reserves related to actions initiated prior to fiscal 2014. The total amount of these reserves was $44 million and $70 million as of June 26, 2015 and September 26, 2014, respectively. The Company incurred nil and $3 million of restructuring charges, $2 million and $5 million of reversals, and utilized $6 million and $10 million for the quarters ended June 26, 2015 and June 27, 2014, respectively, related to 2013 and prior actions.  The Company incurred $5 million and $17 million of restructuring charges, $5 million and $18 million of reversals, and utilized $21 million and $51 million for the nine months ended June 26, 2015 and June 27, 2014, respectively, related to 2013 and prior actions.  The remaining change in reserve during the quarters and nine months ended June 26, 2015 and June 27, 2014 relates to currency translation. The aggregate remaining reserves primarily relate to facility exit costs for long-term non-cancelable lease obligations primarily within the Company's ROW Installation & Services segment.

[0000833444-15-000062:notes:213]
[same as prior period, unchanged from 0000833444-15-000032:notes:209]

[0000833444-15-000062:notes:214]
[same as prior period, unchanged from 0000833444-15-000032:notes:210]

[0000833444-15-000062:notes:215]
The Company has initiated certain global actions designed to reduce its cost structure and improve future profitability by streamlining operations and better aligning functions, which the Company refers to as repositioning actions. These actions may or may not lead to a future restructuring action. During the quarters ended June 26, 2015 and June 27, 2014, the Company recorded repositioning charges of $27 million and $13 million, respectively, and $61 million and $28 million for the nine months ended June 26, 2015 and June 27, 2014, respectively, primarily related to professional fees which have been reflected in Selling, general and administrative expenses in the Consolidated Statements of Operations.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-15-000062:notes:216]
A summary of the changes in each component of Accumulated other comprehensive loss, net of tax, for the nine months ended June 26, 2015 and June 27, 2014 are as follows ($ in millions):

[0000833444-15-000062:notes:217]
|  | CurrencyTranslationAdjustments |  | Unrealized Gain(Loss) onMarketableSecurities andDerivativeInstruments |  | RetirementPlans |  | Accumulated OtherComprehensive Loss |
| Balance as of September 26, 2014 | $ | (693 | ) |  | $ | — |  |  | $ | (532 | ) |  | $ | (1,225 | ) |
| Other comprehensive loss before reclassifications | (349 | ) |  | — |  |  | — |  |  | (349 | ) |
| Amounts reclassified from accumulated other comprehensive income, net of tax | 3 |  |  | (4 | ) |  | 13 |  |  | 12 |  |
| Balance as of June 26, 2015 | $ | (1,039 | ) |  | $ | (4 | ) |  | $ | (519 | ) |  | $ | (1,562 | ) |

[0000833444-15-000062:notes:218]
|  | CurrencyTranslationAdjustments |  | Unrealized Gain(Loss) onMarketableSecurities andDerivativeInstruments |  | RetirementPlans |  | Accumulated OtherComprehensive Loss |
| Balance as of September 27, 2013 | $ | (519 | ) |  | $ | — |  |  | $ | (468 | ) |  | $ | (987 | ) |
| Other comprehensive income before reclassifications | 16 |  |  | — |  |  | — |  |  | 16 |  |
| Amounts reclassified from accumulated other comprehensive income, net of tax | (40 | ) |  | — |  |  | 16 |  |  | (24 | ) |
| Balance as of June 27, 2014 | $ | (543 | ) |  | $ | — |  |  | $ | (452 | ) |  | $ | (995 | ) |


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0000833444-15-000062:notes:219]
Comprehensive Income (Loss)

[0000833444-15-000062:notes:220]
Comprehensive income (loss) is comprised of the following ($ in millions):

[0000833444-15-000062:notes:221]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 26, 2015 |  | June 27, 2014 |  | June 26, 2015 |  | June 27, 2014 |
| Net income | $ | 156 |  |  | $ | 1,452 |  |  | $ | 482 |  |  | $ | 1,931 |  |
| Foreign currency translation (1) | 25 |  |  | 68 |  |  | (349 | ) |  | 16 |  |
| Liquidation of foreign entities (2) | 3 |  |  | (40 | ) |  | 3 |  |  | (40 | ) |
| Foreign currency translation | 28 |  |  | 28 |  |  | (346 | ) |  | (24 | ) |
| Amortization of net actuarial losses (3) | 6 |  |  | 11 |  |  | 17 |  |  | 21 |  |
| Income tax expense | (2 | ) |  | (2 | ) |  | (4 | ) |  | (5 | ) |
| Defined benefit and post retirement plans, net of tax | 4 |  |  | 9 |  |  | 13 |  |  | 16 |  |
| Unrealized loss on marketable securities and derivative instruments (4) | (6 | ) |  | (1 | ) |  | (6 | ) |  | (1 | ) |
| Income tax benefit | 2 |  |  | 1 |  |  | 2 |  |  | 1 |  |
| Unrealized loss on marketable securities and derivative instruments, net of tax | (4 | ) |  | — |  |  | (4 | ) |  | — |  |
| Total other comprehensive income (loss), net of tax | 28 |  |  | 37 |  |  | (337 | ) |  | (8 | ) |
| Comprehensive income | 184 |  |  | 1,489 |  |  | 145 |  |  | 1,923 |  |
| Less: comprehensive income (loss) attributable to noncontrolling interests | — |  |  | 2 |  |  | (3 | ) |  | 4 |  |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 184 |  |  | $ | 1,487 |  |  | $ | 148 |  |  | $ | 1,919 |  |

[0000833444-15-000062:notes:222]
(1) Includes a $12 million loss and $8 million gain related to the net investment hedge for the quarter and nine months ended June 26, 2015, respectively.  The Company did not hold this net investment hedge in fiscal year 2014.

[0000833444-15-000062:notes:223]
(2)


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-15-000062:notes:224]
[same as prior period, unchanged from 0000833444-15-000032:notes:220]

[0000833444-15-000062:notes:225]
[same as prior period, unchanged from 0000833444-15-000032:notes:221]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-15-000062:notes:226]
[same as prior period, unchanged from 0000833444-15-000032:notes:222]

[0000833444-15-000062:notes:227]
[same as prior period, unchanged from 0000833444-15-000032:notes:223]

[0000833444-15-000062:notes:228]
[same as prior period, unchanged from 0000833444-15-000032:notes:224]

[0000833444-15-000062:notes:229]
[same as prior period, unchanged from 0000833444-15-000032:notes:225]

[0000833444-15-000062:notes:230]
[same as prior period, unchanged from 0000833444-15-000032:notes:226]

[0000833444-15-000062:notes:231]
[same as prior period, unchanged from 0000833444-15-000032:notes:227]

[0000833444-15-000062:notes:232]
On June 4, 2015, the Company declared a quarterly dividend of $0.205 per share, payable on August 19, 2015 to shareholders of record on July 24, 2015.  On March 4, 2015, the Company declared a quarterly dividend of $0.205 per share payable on May 20, 2015 to shareholders of record on April 24, 2015.

[0000833444-15-000062:notes:233]
[same as prior period, unchanged from 0000833444-15-000032:notes:229]

[0000833444-15-000062:notes:234]
[same as prior period, unchanged from 0000833444-15-000032:notes:230]

[0000833444-15-000062:notes:235]
[same as prior period, unchanged from 0000833444-15-000032:notes:231]

[0000833444-15-000062:notes:236]
[same as prior period, unchanged from 0000833444-15-000032:notes:232]

[0000833444-15-000062:notes:237]
The Company's Board of Directors approved $1.75 billion and $1 billion share repurchase programs in March 2014 and September 2014, respectively.  During the nine months ended June 26, 2015, the Company repurchased a total of approximately 10 million shares for approximately $417 million which completed the $1.75 billion share repurchase program, all of which occurred during the quarter ended December 26, 2014.  As of June 26, 2015, a total of approximately $1 billion in share repurchase authority remained outstanding.

[0000833444-15-000062:notes:238]
During the quarter ended June 27, 2014, the Company repurchased a total of approximately 13 million shares for approximately $556 million.  During the nine months ended June 27, 2014, the Company repurchased a total of approximately 20 million shares for approximately $806 million.

[0000833444-15-000062:notes:239]
(2) During both the quarter and nine months ended June 26, 2015, $3 million of cumulative translation losses were transferred from foreign currency translation and included in (Loss) income from discontinued operations in the Consolidated Statements of Operations as a result of the sale of foreign entities.  During both the quarter and nine months ended June 27, 2014, $40 million of cumulative translation gains were transferred from foreign currency translation and included in (Loss)  income from discontinued operations in the Consolidated Statements of Operations as a result of the sale of foreign entities.

[0000833444-15-000062:notes:240]
(3) Reclassified to net periodic benefit cost.  See Note 12 Retirement Plans for additional information.  During the quarter ended June 27, 2014, $5 million of net actuarial losses were transferred from amortization of net actuarial losses and included in (Loss) income from discontinued operations in the Consolidated Statements of Operations as a result of the sale of foreign entities.  There was no transfer in fiscal 2015.

[0000833444-15-000062:notes:241]
(4) Reclassified realized gain (loss) on marketable securities and derivative instruments to Other income (expense), net.
