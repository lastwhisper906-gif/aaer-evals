# JCI note change history — 0000833444-15-000032 → 0000833444-15-000062


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-07-31):
[0000833444-15-000062:note_history:1]
In recent years, the Company has settled several lawsuits involving disputes with former management. With respect to Dennis Kozlowski, the Company's former chief executive officer, in the first quarter of fiscal 2014, the parties signed an agreement resolving all outstanding disputes, with Mr. Kozlowski agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements. As a result, in the first quarter of fiscal 2014, the Company reversed a non-cash net liability of approximately $92 million which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations for the amounts allegedly due to him.  Pursuant to the settlement agreement, Tyco will be entitled to a portion of the proceeds, if any, from the future sale of certain assets owned by Mr. Kozlowski, the timing and amount of which is uncertain.  During the quarter ended June 26, 2015, the Company received approximately $4 million in cash from the sale of property owned by Mr. Kozlowski, $2 million of which will be shared pursuant to the terms of a legacy class action lawsuit, resulting in a net recovery of $2 million for the Company, which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations.  The cash received has been classified as restricted.
  (was, 2015-04-24, similarity 0.7991):
[0000833444-15-000032:note_history:1]
In recent years, the Company has settled several lawsuits involving disputes with former management. With respect to Dennis Kozlowski, the Company's former chief executive officer, in the first quarter of fiscal 2014, the parties signed an agreement resolving all outstanding disputes, with Mr. Kozlowski agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements. As a result, in the first quarter of fiscal 2014, the Company reversed a non-cash net liability of approximately $92 million which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations for the amounts allegedly due to him.  Pursuant to the settlement agreement, Tyco will be entitled to a portion of the proceeds, if any, from the future sale of certain assets owned by Mr. Kozlowski, the timing and amount of which is uncertain.

- changed (2015-07-31):
[0000833444-15-000062:note_history:2]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of June 26, 2015, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $29 million to $72 million. As of June 26, 2015, Tyco concluded that the best estimate within this range is approximately $33 million, of which $15 million is included in Accrued and other current liabilities and $18 million is included in Other liabilities in the Company's Consolidated Balance Sheet.
  (was, 2015-04-24, similarity 0.9881):
[0000833444-15-000032:note_history:2]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of March 27, 2015, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $29 million to $72 million. As of March 27, 2015, Tyco concluded that the best estimate within this range is approximately $33 million, of which $15 million is included in Accrued and other current liabilities and $18 million is included in Other liabilities in the Company's Consolidated Balance Sheet.

- changed (2015-07-31):
[0000833444-15-000062:note_history:3]
The majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. Prior to Tyco's acquisition, Ansul manufactured arsenic-based agricultural herbicides at the Marinette facility, which resulted in significant arsenic contamination of soil and groundwater on the Marinette site and in parts of the adjoining Menominee River. Ansul has been engaged in ongoing remediation efforts at the Marinette site since 1990, and in February 2009 entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the Marinette site. Under this agreement, Ansul's principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. As of June 26, 2015, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $20 million to $47 million. The Company's best estimate within that range is approximately $23 million, of which $11 million is included in Accrued and other current liabilities and $12 million is included in Other liabilities in the Company's Consolidated Balance Sheet.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor the arsenic contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.
  (was, 2015-04-24, similarity 0.9981):
[0000833444-15-000032:note_history:3]
The majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. Prior to Tyco's acquisition, Ansul manufactured arsenic-based agricultural herbicides at the Marinette facility, which resulted in significant arsenic contamination of soil and groundwater on the Marinette site and in parts of the adjoining Menominee River. Ansul has been engaged in ongoing remediation efforts at the Marinette site since 1990, and in February 2009 entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the Marinette site. Under this agreement, Ansul's principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. As of March 27, 2015, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $19 million to $46 million. The Company's best estimate within that range is approximately $22 million, of which $10 million is included in Accrued and other current liabilities and $12 million is included in Other liabilities in the Company's Consolidated Balance Sheet.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor the arsenic contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.

- added (2015-07-31):
[0000833444-15-000062:note_history:4]
As of June 26, 2015, the Company has determined that there were approximately 3,400 claims pending against it. This amount reflects the Company's current estimate of the number of viable claims made against it, excludes any claims against Yarway, and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties. As a result of the Yarway bankruptcy filing described below, claims against Yarway have been stayed since April 2013.

- added (2015-07-31):
[0000833444-15-000062:note_history:5]
As of June 26, 2015, the Company's estimated net liability, including Yarway, recorded within the Company's Consolidated Balance Sheet is $331 million.  The net liability is comprised of a liability for pending and future claims and related defense costs of $838 million, of which $344 million is recorded in Accrued and other current liabilities, and $494 million is recorded in Other liabilities.  The Company also maintains separate cash, investment and other assets of $507 million, of which $44 million is recorded in Prepaid expenses and other current assets, and $463 million is recorded in Other assets.  Assets include $16 million of cash and $275 million of investments, which have all been designated as restricted.  The Company believes that the asbestos related liabilities and insurance related assets as of June 26, 2015 are appropriate.  As of September 26, 2014, the Company's estimated net liability, including Yarway, of $608 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs of $853 million, and separately as an asset for insurance recoveries of $245 million.

- changed (2015-07-31):
[0000833444-15-000062:note_history:6]
As previously disclosed, on April 22, 2013 Yarway filed a voluntary petition for relief under Chapter 11 of the U.S. Bankruptcy Code (“Chapter 11”) in the United States Bankruptcy Court for the District of Delaware (“Bankruptcy Court”). As a result of this filing, the continuation or commencement of asbestos-related litigation against Yarway has been enjoined by the automatic stay imposed by the U.S. Bankruptcy Code. Yarway's goal has been to negotiate, obtain approval of, and consummate a plan of reorganization that establishes a trust to fairly and equitably value and pay current and future Yarway asbestos claims, and that, in exchange for funding of the trust by the Company and/or its subsidiaries, provides permanent injunctive relief protecting the Company, each of its current and former affiliates and various other parties (the “Company Protected Parties”) from any further asbestos claims based on products manufactured, sold, and/or distributed by Yarway. On October 9, 2014, the Company reached an agreement in principle with Yarway, the Official Committee of Asbestos Claimants (“ACC”) appointed in the Yarway Chapter 11 case as the representative of current Yarway asbestos claimants, and the Future Claimants Representative (“FCR”) appointed in the Yarway Chapter 11 case as the representative of future Yarway asbestos claimants, to fund a section 524(g) trust for the resolution and payment of current and future Yarway asbestos claims. The agreement in principle will be implemented through a Chapter 11 plan of reorganization for Yarway, and is intended to resolve the potential liability of the Company Protected Parties for pending and future derivative personal injury claims related to exposure to asbestos-containing products that were allegedly manufactured, distributed, and/or sold by Yarway (“Yarway Asbestos Claims”). Under the Chapter 11 plan, an asbestos settlement trust (the “Yarway Trust”) that conforms to the provisions of Section 524(g) of the U.S. Bankruptcy Code will be established and, on the effective date of the Chapter 11 plan, the Company and Yarway will contribute to the Yarway Trust a total of approximately $325 million in cash (“Settlement Consideration”), which includes approximately $100 million relating to the settlement of intercompany amounts allegedly due to Yarway. In exchange for the Settlement Consideration, each of the Company Protected Parties will receive the benefit of a release from Yarway and an injunction under section 524(g) of the Bankruptcy Code permanently enjoining the assertion of Yarway Asbestos Claims against those Parties.  On April 8, 2015, following the approval of the Plan by the required number of Yarway's current asbestos claimants, the Bankruptcy Court issued an order confirming the Plan, and on July 14, 2015, the United States District Court for the District of Delaware affirmed the Plan.  Yarway expects to schedule an effective date for the Plan in August 2015.
  (was, 2015-04-24, similarity 0.9189):
[0000833444-15-000032:note_history:6]
As previously disclosed, on April 22, 2013 Yarway filed a voluntary petition for relief under Chapter 11 of the U.S. Bankruptcy Code (“Chapter 11”) in the United States Bankruptcy Court for the District of Delaware (“Bankruptcy Court”). As a result of this filing, the continuation or commencement of asbestos-related litigation against Yarway has been enjoined by the automatic stay imposed by the U.S. Bankruptcy Code. Yarway's goal has been to negotiate, obtain approval of, and consummate a plan of reorganization that establishes a trust to fairly and equitably value and pay current and future Yarway asbestos claims, and that, in exchange for funding of the trust by the Company and/or its subsidiaries, provides permanent injunctive relief protecting the Company, each of its current and former affiliates and various other parties (the “Company Protected Parties”) from any further asbestos claims based on products manufactured, sold, and/or distributed by Yarway. On October 9, 2014, the Company reached an agreement in principle with Yarway, the Official Committee of Asbestos Claimants (“ACC”) appointed in the Yarway Chapter 11 case as the representative of current Yarway asbestos claimants, and the Future Claimants Representative (“FCR”) appointed in the Yarway Chapter 11 case as the representative of future Yarway asbestos claimants, to fund a section 524(g) trust for the resolution and payment of current and future Yarway asbestos claims. The agreement in principle will be implemented through a Chapter 11 plan of reorganization for Yarway, and is intended to resolve the potential liability of the Company Protected Parties for pending and future derivative personal injury claims related to exposure to asbestos-containing products that were allegedly manufactured, distributed, and/or sold by Yarway (“Yarway Asbestos Claims”). Under the Chapter 11 plan, an asbestos settlement trust (the “Yarway Trust”) that conforms to the provisions of Section 524(g) of the U.S. Bankruptcy Code will be established and, on the effective date of the Chapter 11 plan, the Company and Yarway will contribute to the Yarway Trust a total of approximately $325 million in cash (“Settlement Consideration”), which includes approximately $100 million relating to the settlement of intercompany amounts allegedly due to Yarway. In exchange for the Settlement Consideration, each of the Company Protected Parties will receive the benefit of a release from Yarway and an injunction under section 524(g) of the Bankruptcy Code permanently enjoining the assertion of Yarway Asbestos Claims against those Parties.  On April 8, 2015, following the approval of the  Plan by the required number of Yarway's current asbestos claimants, the Bankruptcy Court issued an order confirming the Plan.  As a result, the Plan has been filed with the United States District Court for the District of Delaware ("District Court") and is awaiting affirmation by the District Court.  There have been no objections filed with respect to the Plan.  Upon the District Court's affirmation of the Plan, Yarway and the Plan proponents will schedule an effective date for the Plan, which is anticipated to occur during the Company's third fiscal quarter.

- changed (2015-07-31):
[0000833444-15-000062:note_history:7]
The IRS asserted in the Notices of Deficiency that substantially all of Tyco's intercompany debt originated during the 1997 - 2000 period should not be treated as debt for U.S. federal income tax purposes, and has disallowed interest and related deductions recognized on U.S. income tax returns totaling approximately $2.9 billion. Tyco strongly disagrees with the IRS position and has filed petitions with the U.S. Tax Court contesting the IRS proposed adjustments. A trial date has been set for October 2016. Tyco believes that it has meritorious defenses for its tax filings, that the IRS positions with regard to these matters are inconsistent with the applicable tax laws and existing Treasury regulations, and that the previously reported taxes for the years in question are appropriate.
  (was, 2015-04-24, similarity 0.9904):
[0000833444-15-000032:note_history:7]
The IRS asserted in the Notices of Deficiency that substantially all of Tyco's intercompany debt originated during the 1997 - 2000 period should not be treated as debt for U.S. federal income tax purposes, and has disallowed interest and related deductions recognized on U.S. income tax returns totaling approximately $2.9 billion. Tyco strongly disagrees with the IRS position and has filed petitions with the U.S. Tax Court contesting the IRS proposed adjustments. A trial date has been set for February 2016. Tyco believes that it has meritorious defenses for its tax filings, that the IRS positions with regard to these matters are inconsistent with the applicable tax laws and existing Treasury regulations, and that the previously reported taxes for the years in question are appropriate.

- changed (2015-07-31):
[0000833444-15-000062:note_history:8]
During the first quarter of fiscal 2015, the Company received and responded to inquiries from the U.S. Department of the Navy regarding the formulation of certain aqueous film forming foam ("AFFF") concentrates. The Company investigated such matters and ceased selling certain AFFF and other foam products pending the outcome of its investigation.  During the course of the investigation, three AFFF products were removed from the Navy’s Qualified Products List ("QPL"); one AFFF product remains on the QPL. The Company has shared the results of its investigation with appropriate governmental authorities and is also communicating with the government regarding the re-qualification of these products.  The government has confirmed that it considers the Company to be “presently responsible,” and that no suspension or debarment is warranted.  At this time, we cannot predict the outcome of these inquiries and whether this will result in further action by the Navy or other governmental authorities, but it is possible that the Company could be required to pay material fines, consent to injunctions on future conduct, or suffer other criminal or civil penalties or adverse impacts, including being subject to lawsuits brought by private litigants.
  (was, 2015-04-24, similarity 0.9528):
[0000833444-15-000032:note_history:8]
During the first quarter of fiscal 2015, the Company received and responded to inquiries from the U.S. Department of the Navy regarding the formulation of certain aqueous film forming foam ("AFFF") concentrates. The Company investigated such matters and ceased selling certain AFFF and other foam products pending the outcome of its investigation.  During the course of the investigation, three AFFF products were removed from the Navy’s Qualified Products List ("QPL"); one AFFF product remains on the QPL. The Company has shared the results of its investigation with appropriate governmental authorities and is also communicating with the government regarding the re-qualification of these products.  The government has confirmed that it considers the Company to be “presently responsible,” and that no suspension or debarment is warranted.  At this time, we cannot predict the outcome of these inquiries and whether this will result in further action by the Navy or other governmental authorities, but it is possible that the Company could be required to pay material fines, consent to injunctions on future conduct, or suffer other criminal or civil penalties or adverse impacts, including being subject to lawsuits brought by private litigants, each of which may have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- removed (2015-07-31):
[0000833444-15-000032:note_history:9]
As of March 27, 2015, the Company has determined that there were approximately 5,900 claims pending against it, which includes approximately 3,200 claims pending against Yarway. This amount reflects the Company's current estimate of the number of viable claims made against it and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties. Additionally, as a result of the Yarway bankruptcy filing described below, claims against Yarway have been stayed since April 2013.

- removed (2015-07-31):
[0000833444-15-000032:note_history:10]
As of March 27, 2015, the Company's estimated net liability, including Yarway, recorded within the Company's Consolidated Balance Sheet is $319 million.  The net liability is comprised of a liability for pending and future claims and related defense costs of $846 million, of which $349 million is recorded in Accrued and other current liabilities, and $497 million is recorded in Other liabilities.  The Company also maintains separate cash, investment and other assets of $527 million, of which $43 million is recorded in Prepaid expenses and other current assets, and $484 million is recorded in Other assets.  Assets include $22 million of cash and $282 million of investments, which have all been designated as restricted.  The Company believes that the asbestos related liabilities and insurance related assets as of March 27, 2015 are appropriate.  As of September 26, 2014, the Company's estimated net liability, including Yarway, of $608 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs of $853 million, and separately as an asset for insurance recoveries of $245 million.


## tyc:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesAndNewAccountingPronouncementsTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-07-31):
[0000833444-15-000062:note_history:11]
References to 2015 and 2014 are to Tyco's fiscal quarters ending June 26, 2015 and June 27, 2014, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September.  Fiscal years 2015 and 2014 are both 52-week years.
  (was, 2015-04-24, similarity 0.6772):
[0000833444-15-000032:note_history:11]
References to 2015 and 2014 are to Tyco's fiscal quarters ending March 27, 2015 and March 28, 2014, respectively, unless otherwise indicated.  The Company has a 52 or 53-week fiscal year that ends on the last Friday in September.  Fiscal years 2015 and 2014 are both 52-week years.

- added (2015-07-31):
[0000833444-15-000062:note_history:12]
Reclassifications - Certain prior period amounts have been reclassified to conform with current period presentation. During the quarter ended June 26, 2015, the Company sold three businesses in the Rest of World ("ROW") Installation & Services segment.  The assets and liabilities related to these businesses were classified as held for sale of as September 26, 2014, and the results of operations of two of these businesses are included in discontinued operations for all periods presented, as the criteria to be presented as a discontinued operation were not satisfied for the third business.  The Company expects to complete the sale of another of its ROW Installation & Services businesses during the first half of fiscal 2016.  The assets and liabilities of this business are classified as held for sale, and its results of operations are presented as discontinued operations for all periods presented. See Note 3.

- changed (2015-07-31):
[0000833444-15-000062:note_history:13]
In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires both quantitative and qualitative disclosures, which are more comprehensive than existing revenue standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. In July 2015, the FASB issued a deferral of the effective date of this guidance, which for Tyco will be the first quarter of fiscal 2019, with early adoption permitted beginning the first quarter of fiscal 2018.  The Company is currently assessing the impact the guidance will have upon adoption.
  (was, 2015-04-24, similarity 0.8819):
[0000833444-15-000032:note_history:13]
In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires both quantitative and qualitative disclosures, which are more comprehensive than existing revenue standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. This guidance will be effective for Tyco in the first quarter of fiscal 2018, with early adoption not permitted. The Company is currently assessing the impact the guidance will have upon adoption.

- added (2015-07-31):
[0000833444-15-000062:note_history:14]
In May 2015, the FASB issued authoritative guidance which is intended to improve the existing disclosure requirements for short-duration contracts for insurance entities that issue such contracts.  The guidance requires additional information to be disclosed about the liability for unpaid claims and claim adjustment expenses to increase the transparency of significant estimates made in measuring those liabilities.  This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance will have upon adoption.

- removed (2015-07-31):
[0000833444-15-000032:note_history:15]
Reclassifications - Certain prior period amounts have been reclassified to conform with current period presentation.  The Company has reclassified several businesses in the Rest of World ("ROW") Installation & Services segment to (Loss) income from discontinued operations in the Consolidated Statements of Operations and the assets and liabilities as held for sale within the Consolidated Balance Sheets for all periods presented as they satisfied the criteria to be presented as discontinued operations.  In addition, the Company has reclassified the assets and liabilities of several businesses in the ROW Installation & Services segment as held for sale during the quarter ended March 27, 2015.  One of these businesses satisfied the criteria to be presented as discontinued operations and has been reflected as such in the Consolidated Statements of Operations for all periods presented.  See Note 3.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-07-31):
[0000833444-15-000062:note_history:16]
Debt as of June 26, 2015 and September 26, 2014 is as follows ($ in millions):
  (was, 2015-04-24, similarity 0.9343):
[0000833444-15-000032:note_history:16]
Debt as of March 27, 2015 and September 26, 2014 is as follows ($ in millions):

- changed (2015-07-31):
[0000833444-15-000062:note_history:17]
|  | As of |
|  | June 26, 2015 |  | September 26, 2014 |
| 3.375% public notes due 2015 (1) | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | 364 |  |  | 364 |  |
| 7.0% public notes due 2019 | 245 |  |  | 245 |  |
| 6.875% public notes due 2021 | 465 |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% public notes due 2025 | 559 |  |  | — |  |
| Other (2) | 21 |  |  | 22 |  |
| Total debt | 2,021 |  |  | 1,463 |  |
| Less current portion | 277 |  |  | 20 |  |
| Long-term debt | $ | 1,744 |  |  | $ | 1,443 |  |
  (was, 2015-04-24, similarity 0.9905):
[0000833444-15-000032:note_history:17]
|  | As of |
|  | March 27, 2015 |  | September 26, 2014 |
| 3.375% public notes due 2015 (1) | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | 364 |  |  | 364 |  |
| 7.0% public notes due 2019 | 245 |  |  | 245 |  |
| 6.875% public notes due 2021 | 465 |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% public notes due 2025 | 548 |  |  | — |  |
| Other (2) | 21 |  |  | 22 |  |
| Total debt | 2,010 |  |  | 1,463 |  |
| Less current portion | 278 |  |  | 20 |  |
| Long-term debt | $ | 1,732 |  |  | $ | 1,443 |  |

- changed (2015-07-31):
[0000833444-15-000062:note_history:18]
(1) $258 million of 3.375% public notes due October 2015 is included in the current portion of debt as of June 26, 2015.
  (was, 2015-04-24, similarity 0.9573):
[0000833444-15-000032:note_history:18]
(1)  $258 million of 3.375% public notes due October 2015 is included in the current portion of debt as of March 27, 2015.

- changed (2015-07-31):
[0000833444-15-000062:note_history:19]
(2)  $19 million and $20 million, respectively, of the amount shown as other is included in the current portion of the Company's total debt as of June 26, 2015 and September 26, 2014.
  (was, 2015-04-24, similarity 0.8599):
[0000833444-15-000032:note_history:19]
(2)  $20 million of the amount shown as other is included in the current portion of the Company's total debt as of both March 27, 2015 and September 26, 2014.

- added (2015-07-31):
[0000833444-15-000062:note_history:20]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of June 26, 2015 and September 26, 2014 was $2,000 million and $1,441 million, respectively.  The Company has determined the fair value of such debt to be $2,177 million and $1,670 million as of June 26, 2015 and September 26, 2014, respectively.  The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets.  As of June 26, 2015 and September 26, 2014, $2,000 million and $1,441 million, respectively, of the Company's debt, which is actively traded and subject to the fair value disclosure requirements, is classified as Level 1 in the fair value hierarchy.

- changed (2015-07-31):
[0000833444-15-000062:note_history:21]
From time to time, the Company's wholly-owned subsidiary, Tyco International Finance S.A. ("TIFSA") may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued on a private placement basis under the commercial paper program is $1 billion as of June 26, 2015.  As of June 26, 2015 and September 26, 2014, TIFSA had no commercial paper outstanding.
  (was, 2015-04-24, similarity 0.9519):
[0000833444-15-000032:note_history:21]
From time to time, the Company's wholly-owned subsidiary, Tyco International Finance S.A. ("TIFSA") may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued on a private placement basis under the commercial paper program is $1 billion as of March 27, 2015.  As of March 27, 2015 and September 26, 2014, TIFSA had no commercial paper outstanding.

- changed (2015-07-31):
[0000833444-15-000062:note_history:22]
The Company's committed revolving credit facility totaled $1 billion as of June 26, 2015. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of June 26, 2015 and September 26, 2014, there were no amounts drawn under the Company's revolving credit facility. Interest under the revolving credit facility is variable and is calculated by reference to LIBOR or an alternate base rate.
  (was, 2015-04-24, similarity 0.9792):
[0000833444-15-000032:note_history:22]
The Company's committed revolving credit facility totaled $1 billion as of March 27, 2015. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of March 27, 2015 and September 26, 2014, there were no amounts drawn under the Company's revolving credit facility. Interest under the revolving credit facility is variable and is calculated by reference to LIBOR or an alternate base rate.

- changed (2015-07-31):
[0000833444-15-000062:note_history:23]
On February 25, 2015, TIFSA issued €500 million aggregate principal amount of 1.375% Notes due February 25, 2025 (the "Notes"), which are fully and unconditionally guaranteed by each of the Company and Tyco Fire & Security Finance S.C.A.  TIFSA received total net proceeds of approximately $563 million after deducting debt issuance costs of approximately $5 million and a debt discount of approximately $1 million.  The net proceeds were made available for general corporate purposes.  The Notes are TIFSA’s senior unsecured obligations and rank equally in right of payment with all of its existing and future senior debt, and senior to any subordinated indebtedness that TIFSA may incur.  The Notes were designated as a net investment hedge.  See Note 10.
  (was, 2015-04-24, similarity 0.9993):
[0000833444-15-000032:note_history:23]
On February 25, 2015, TIFSA issued €500 million aggregate principal amount of 1.375% Notes due February 25, 2025 (the "Notes"), which are fully and unconditionally guaranteed by each of the Company and Tyco Fire & Security Finance S.C.A.  TIFSA received total net proceeds of approximately $563 million after deducting debt issuance costs of approximately $5 million and a debt discount of approximately $1 million.  The net proceeds, were made available for general corporate purposes.  The Notes are TIFSA’s senior unsecured obligations and rank equally in right of payment with all of its existing and future senior debt, and senior to any subordinated indebtedness that TIFSA may incur.  The Notes were designated as a net investment hedge.  See Note 10.

- removed (2015-07-31):
[0000833444-15-000032:note_history:24]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of March 27, 2015 and September 26, 2014 was $1,989 million and $1,441 million, respectively.  The Company has determined the fair value of such debt to be $2,198 million and $1,670 million as of March 27, 2015 and September 26, 2014, respectively.  The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets.  As of March 27, 2015 and September 26, 2014, $1,989 million and $1,441 million, respectively, of the Company's debt, which is actively traded and subject to the fair value disclosure requirements, is classified as Level 1 in the fair value hierarchy.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-07-31):
[0000833444-15-000062:note_history:25]
Debt as of June 26, 2015 and September 26, 2014 is as follows ($ in millions):
  (was, 2015-04-24, similarity 0.9343):
[0000833444-15-000032:note_history:25]
Debt as of March 27, 2015 and September 26, 2014 is as follows ($ in millions):

- changed (2015-07-31):
[0000833444-15-000062:note_history:26]
|  | As of |
|  | June 26, 2015 |  | September 26, 2014 |
| 3.375% public notes due 2015 (1) | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | 364 |  |  | 364 |  |
| 7.0% public notes due 2019 | 245 |  |  | 245 |  |
| 6.875% public notes due 2021 | 465 |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% public notes due 2025 | 559 |  |  | — |  |
| Other (2) | 21 |  |  | 22 |  |
| Total debt | 2,021 |  |  | 1,463 |  |
| Less current portion | 277 |  |  | 20 |  |
| Long-term debt | $ | 1,744 |  |  | $ | 1,443 |  |
  (was, 2015-04-24, similarity 0.9905):
[0000833444-15-000032:note_history:26]
|  | As of |
|  | March 27, 2015 |  | September 26, 2014 |
| 3.375% public notes due 2015 (1) | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | 364 |  |  | 364 |  |
| 7.0% public notes due 2019 | 245 |  |  | 245 |  |
| 6.875% public notes due 2021 | 465 |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% public notes due 2025 | 548 |  |  | — |  |
| Other (2) | 21 |  |  | 22 |  |
| Total debt | 2,010 |  |  | 1,463 |  |
| Less current portion | 278 |  |  | 20 |  |
| Long-term debt | $ | 1,732 |  |  | $ | 1,443 |  |

- changed (2015-07-31):
[0000833444-15-000062:note_history:27]
(1) $258 million of 3.375% public notes due October 2015 is included in the current portion of debt as of June 26, 2015.
  (was, 2015-04-24, similarity 0.9573):
[0000833444-15-000032:note_history:27]
(1)  $258 million of 3.375% public notes due October 2015 is included in the current portion of debt as of March 27, 2015.

- changed (2015-07-31):
[0000833444-15-000062:note_history:28]
(2)  $19 million and $20 million, respectively, of the amount shown as other is included in the current portion of the Company's total debt as of June 26, 2015 and September 26, 2014.
  (was, 2015-04-24, similarity 0.8599):
[0000833444-15-000032:note_history:28]
(2)  $20 million of the amount shown as other is included in the current portion of the Company's total debt as of both March 27, 2015 and September 26, 2014.
