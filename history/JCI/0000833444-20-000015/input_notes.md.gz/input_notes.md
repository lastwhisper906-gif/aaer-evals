# JCI notes — 0000833444-20-000015


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-20-000015:notes:1]
[same as prior period, unchanged from 0000833444-20-000006:notes:1]

[0000833444-20-000015:notes:2]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2019 filed with the SEC on November 21, 2019. The results of operations for the three and six month periods ended March 31, 2020 are not necessarily indicative of results for the Company’s 2020 fiscal year because of seasonal and other factors.

[0000833444-20-000015:notes:3]
[same as prior period, unchanged from 0000833444-20-000006:notes:3]

[0000833444-20-000015:notes:4]
[same as prior period, unchanged from 0000833444-20-000006:notes:4]

[0000833444-20-000015:notes:5]
[same as prior period, unchanged from 0000833444-20-000006:notes:5]

[0000833444-20-000015:notes:6]
[same as prior period, unchanged from 0000833444-20-000006:notes:6]

[0000833444-20-000015:notes:7]
[same as prior period, unchanged from 0000833444-20-000006:notes:7]

[0000833444-20-000015:notes:8]
[same as prior period, unchanged from 0000833444-20-000006:notes:8]

[0000833444-20-000015:notes:9]
[same as prior period, unchanged from 0000833444-20-000006:notes:9]

[0000833444-20-000015:notes:10]
At March 31, 2020 and September 30, 2019, the Company held restricted cash of approximately $13 million and $16 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-20-000015:notes:11]
[same as prior period, unchanged from 0000833444-20-000006:notes:11]

[0000833444-20-000015:notes:12]
During the first six months of fiscal 2020, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $61 million, of which $58 million was paid as of March 31, 2020. In connection with the acquisitions, the Company recorded goodwill of $19 million within the Global Products segment and $20 million within the Building Solutions EMEA/LA segment.

[0000833444-20-000015:notes:13]
During the first six months of fiscal 2019, the Company completed certain divestitures within the Global Products and Building Solutions EMEA/LA businesses. The combined selling price was $18 million, $6 million of which was received as of March 31, 2019. In connection with the sale, the Company reduced goodwill by $1 million within the Building Solutions EMEA/LA segment. The divestitures were not material to the Company's consolidated financial statements.

[0000833444-20-000015:notes:14]
During the first quarter of fiscal 2019, the Company completed an acquisition for a purchase price of $13 million, all of which was paid as of March 31, 2019. In connection with the acquisition, the Company recorded goodwill of $9 million within the Global Products segment.

[0000833444-20-000015:notes:15]
Acquisitions and divestitures were not material to the Company's consolidated financial statements in the first six months of fiscal 2020 or 2019.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-20-000015:notes:16]
[same as prior period, unchanged from 0000833444-20-000006:notes:16]

[0000833444-20-000015:notes:17]
[same as prior period, unchanged from 0000833444-20-000006:notes:17]

[0000833444-20-000015:notes:18]
[same as prior period, unchanged from 0000833444-20-000006:notes:18]

[0000833444-20-000015:notes:19]
The following table summarizes the results of Power Solutions reclassified as discontinued operations for the three and six month periods ended March 31, 2019 (in millions).

[0000833444-20-000015:notes:20]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2019 |  | 2019 |
| Net sales | $ | 2,012 |  |  | $ | 4,439 |  |
| Income from discontinued operations before income taxes | 334 |  |  | 724 |  |
| Provision for income taxes on discontinued operations | (50 | ) |  | (177 | ) |
| Income from discontinued operations attributable to noncontrolling interests, net of tax | (9 | ) |  | (24 | ) |
| Income from discontinued operations | $ | 275 |  |  | $ | 523 |  |

[0000833444-20-000015:notes:21]
For the three months ended March 31, 2019, income from discontinued operations before income taxes included transaction costs of $18 million and a favorable impact of $64 million for ceasing depreciation and amortization expense as the business was held for sale. For the six months ended March 31, 2019, income from discontinued operations before income taxes included transaction costs of $46 million and a favorable impact of $96 million for ceasing depreciation and amortization expense as the business was held for sale.

[0000833444-20-000015:notes:22]
For the three months ended March 31, 2019, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to tax rate differentials. For the six months ended March 31, 2019, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the planned divestiture of the business and tax rate differentials.

[0000833444-20-000015:notes:23]
[same as prior period, unchanged from 0000833444-20-000006:notes:23]

[0000833444-20-000015:notes:24]
During the third quarter of fiscal 2019, the Company determined that a business within its Global Products segment met the criteria to be classified as held for sale. The assets and liabilities of this business are presented as held for sale in the consolidated statements of financial position as of March 31, 2020 and September 30, 2019. Assets and liabilities held for sale are required to be recorded at the lower of carrying value or fair value less any costs to sell. Accordingly, the Company has recorded total impairment charges of $250 million within restructuring and impairment costs in the consolidated statements of income to write down the carrying value of the assets held for sale to fair value less any costs to sell. Of the $250 million total impairment charges, $235 million was recorded during the third quarter of fiscal 2019, and $15 million was recorded during the first quarter of fiscal 2020. Refer to Note 18, "Impairment of Long-Lived Assets" of the notes to consolidated financial statements for further information regarding the impairment charges. The divestiture of the business held for sale could result in a gain or loss on sale to the extent the ultimate selling price differs from the current carrying value of the net assets recorded. The business did not meet the criteria to be classified as a discontinued operation as the divestiture of the business will not have a major effect on the Company's operations and financial results.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-20-000015:notes:25]
[same as prior period, unchanged from 0000833444-20-000006:notes:25]

[0000833444-20-000015:notes:26]
[same as prior period, unchanged from 0000833444-20-000006:notes:26]

[0000833444-20-000015:notes:27]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and six months ended March 31, 2020 and 2019 (in millions):

[0000833444-20-000015:notes:28]
|  |  | Three Months Ended March 31, 2020 |  | Three Months Ended March 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,357 |  |  | $ | 818 |  |  | $ | 2,175 |  |  | $ | 1,387 |  |  | $ | 800 |  |  | $ | 2,187 |  |
| Building Solutions EMEA/LA |  | 400 |  |  | 450 |  |  | 850 |  |  | 416 |  |  | 462 |  |  | 878 |  |
| Building Solutions Asia Pacific |  | 271 |  |  | 254 |  |  | 525 |  |  | 351 |  |  | 277 |  |  | 628 |  |
| Global Products |  | 1,894 |  |  | — |  |  | 1,894 |  |  | 2,086 |  |  | — |  |  | 2,086 |  |
| Total |  | $ | 3,922 |  |  | $ | 1,522 |  |  | $ | 5,444 |  |  | $ | 4,240 |  |  | $ | 1,539 |  |  | $ | 5,779 |  |

[0000833444-20-000015:notes:29]
|  |  | Six Months Ended March 31, 2020 |  | Six Months Ended March 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 2,713 |  |  | $ | 1,629 |  |  | $ | 4,342 |  |  | $ | 2,708 |  |  | $ | 1,595 |  |  | $ | 4,303 |  |
| Building Solutions EMEA/LA |  | 857 |  |  | 921 |  |  | 1,778 |  |  | 833 |  |  | 952 |  |  | 1,785 |  |
| Building Solutions Asia Pacific |  | 642 |  |  | 512 |  |  | 1,154 |  |  | 707 |  |  | 534 |  |  | 1,241 |  |
| Global Products |  | 3,746 |  |  | — |  |  | 3,746 |  |  | 3,914 |  |  | — |  |  | 3,914 |  |
| Total |  | $ | 7,958 |  |  | $ | 3,062 |  |  | $ | 11,020 |  |  | $ | 8,162 |  |  | $ | 3,081 |  |  | $ | 11,243 |  |

[0000833444-20-000015:notes:30]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and six months ended March 31, 2020 and 2019 (in millions):

[0000833444-20-000015:notes:31]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Building management systems |  | $ | 316 |  |  | $ | 320 |  |  | $ | 616 |  |  | $ | 601 |  |
| HVAC & refrigeration equipment |  | 1,307 |  |  | 1,474 |  |  | 2,592 |  |  | 2,759 |  |
| Specialty products |  | 271 |  |  | 292 |  |  | 538 |  |  | 554 |  |
| Total |  | $ | 1,894 |  |  | $ | 2,086 |  |  | $ | 3,746 |  |  | $ | 3,914 |  |

[0000833444-20-000015:notes:32]
[same as prior period, unchanged from 0000833444-20-000006:notes:31]

[0000833444-20-000015:notes:33]
[same as prior period, unchanged from 0000833444-20-000006:notes:32]

[0000833444-20-000015:notes:34]
[same as prior period, unchanged from 0000833444-20-000006:notes:33]

[0000833444-20-000015:notes:35]
|  |  | Location of contract balances |  | March 31, 2020 |  | September 30, 2019 |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,422 |  |  | $ | 1,389 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 95 |  |  | 90 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,600 | ) |  | (1,407 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (119 | ) |  | (117 | ) |
| Total |  |  |  | $ | (202 | ) |  | $ | (45 | ) |

[0000833444-20-000015:notes:36]
For the three months ended March 31, 2020 and March 31, 2019, the Company recognized revenue of $326 million and $214 million, respectively, that was included in the beginning of period contract liability balance. For the six months ended March 31, 2020 and March 31, 2019, the Company recognized revenue of $1,012 million and $926 million, respectively, that was included in the beginning of period contract liability balance.

[0000833444-20-000015:notes:37]
[same as prior period, unchanged from 0000833444-20-000006:notes:36]

[0000833444-20-000015:notes:38]
[same as prior period, unchanged from 0000833444-20-000006:notes:37]

[0000833444-20-000015:notes:39]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of March 31, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.4 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-20-000015:notes:40]
[same as prior period, unchanged from 0000833444-20-000006:notes:39]

[0000833444-20-000015:notes:41]
[same as prior period, unchanged from 0000833444-20-000006:notes:40]

[0000833444-20-000015:notes:42]
As of March 31, 2020, the Company recorded the costs to obtain or fulfill a contract of $228 million, of which $123 million is recorded within other current assets and $105 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2019, the Company recorded the costs to obtain or fulfill a contract of $212 million, of which $110 million is recorded within other current assets and $102 million is recorded within other noncurrent assets in the consolidated statements of financial position.

[0000833444-20-000015:notes:43]
During the three months ended March 31, 2020 and 2019, the Company recognized amortization expense of $43 million and $34 million, respectively, related to costs to obtain or fulfill a contract. During the six months ended March 31, 2020 and 2019, the Company recognized amortization expense of $69 million and $69 million, respectively, related to costs to obtain or fulfill a contract.  There were no impairment losses recognized in the three months ended March 31, 2020 and 2019.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-20-000015:notes:44]
[same as prior period, unchanged from 0000833444-20-000006:notes:43]

[0000833444-20-000015:notes:45]
[same as prior period, unchanged from 0000833444-20-000006:notes:44]

[0000833444-20-000015:notes:46]
[same as prior period, unchanged from 0000833444-20-000006:notes:45]

[0000833444-20-000015:notes:47]
Right-of-use assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent its obligation to make lease payments arising from the lease. Right-of-use assets and the corresponding lease liabilities are recognized at commencement date based on the present value of lease payments for all leases with terms longer than twelve months. As the majority of the Company's leases do not provide an implicit interest rate, to determine the present value of lease payments, the Company uses its incremental borrowing rate based on information available on the lease commencement date and uses the implicit rate when readily determinable.  The Company determines its incremental borrowing rate based on a comparable market yield curve consistent with the Company's credit rating, term of the lease and relative economic environment. The Company has elected to combine lease and non-lease components for its leases.

[0000833444-20-000015:notes:48]
[same as prior period, unchanged from 0000833444-20-000006:notes:48]

[0000833444-20-000015:notes:49]
[same as prior period, unchanged from 0000833444-20-000006:notes:49]

[0000833444-20-000015:notes:50]
The following table presents the Company’s lease costs for the three and six months ended March 31, 2020 (in millions):

[0000833444-20-000015:notes:51]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2020 |  | 2020 |
| Operating lease cost |  | $ | 98 |  |  | $ | 197 |  |
| Variable lease cost |  | 37 |  |  | 77 |  |
| Total lease costs |  | $ | 135 |  |  | $ | 274 |  |

[0000833444-20-000015:notes:52]
The following table presents supplemental consolidated statement of financial position information as of March 31, 2020 (in millions):

[0000833444-20-000015:notes:53]
|  | Location of lease balances |  | March 31, 2020 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,088 |  |
| Operating lease liabilities - current | Other current liabilities |  | 320 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 773 |  |
| Weighted-average remaining lease term |  |  | 6 years |  |
| Weighted-average discount rate |  |  | 2.3 | % |

[0000833444-20-000015:notes:54]
The following table presents supplemental cash flow information related to operating leases for the three and six months ended March 31, 2020 (in millions):

[0000833444-20-000015:notes:55]
|  |  | Three Months Ended March 31, 2020 |  | Six Months Ended March 31, 2020 |
| Cash paid for amounts included in the measurement of lease liability: |  |  |  |  |
| Operating cash outflows from operating leases |  | $ | 100 |  |  | $ | 197 |  |
| Noncash operating lease activity: |  |  |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  | 100 |  |  | 174 |  |

[0000833444-20-000015:notes:56]
The following table presents maturities of operating lease liabilities as of March 31, 2020 (in millions):

[0000833444-20-000015:notes:57]
|  |  | March 31, 2020 |
| 2020 (6 months) |  | $ | 173 |  |
| 2021 |  | 318 |  |
| 2022 |  | 233 |  |
| 2023 |  | 142 |  |
| 2024 |  | 101 |  |
| After 2024 |  | 200 |  |
| Total operating lease payments |  | 1,167 |  |
| Less interest |  | (74 | ) |
| Present value of lease payments |  | $ | 1,093 |  |

[0000833444-20-000015:notes:58]
[same as prior period, unchanged from 0000833444-20-000006:notes:58]

[0000833444-20-000015:notes:59]
[same as prior period, unchanged from 0000833444-20-000006:notes:59]

[0000833444-20-000015:notes:60]
[same as prior period, unchanged from 0000833444-20-000006:notes:60]

[0000833444-20-000015:notes:61]
The Company's monitoring services and maintenance agreements within its electronic security business that include subscriber system assets for which the Company retains ownership contain both lease and nonlease components. The Company has elected the practical expedient to combine lease and nonlease components for these arrangements where the timing and pattern of transfer of the lease and nonlease components are the same and the lease component would be classified as an operating lease if accounted for separately. The Company has concluded that in these arrangements the nonlease components are the predominant characteristic, and as a result, the combined component is accounted for under the revenue guidance.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-20-000015:notes:62]
[same as prior period, unchanged from 0000833444-20-000006:notes:62]

[0000833444-20-000015:notes:63]
[same as prior period, unchanged from 0000833444-20-000006:notes:63]

[0000833444-20-000015:notes:64]
|  | March 31, 2020 |  | September 30, 2019 |
| Raw materials and supplies | $ | 646 |  |  | $ | 588 |  |
| Work-in-process | 177 |  |  | 176 |  |
| Finished goods | 1,207 |  |  | 1,050 |  |
| Inventories | $ | 2,030 |  |  | $ | 1,814 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-20-000015:notes:65]
[same as prior period, unchanged from 0000833444-20-000006:notes:65]

[0000833444-20-000015:notes:66]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the six month period ended March 31, 2020 were as follows (in millions):

[0000833444-20-000015:notes:67]
|  |  |  | Business Acquisitions |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  | March 31, |
|  | 2019 |  |  |  | 2020 |
| Building Solutions North America | $ | 9,588 |  |  | $ | — |  |  | $ | (45 | ) |  | $ | 9,543 |  |
| Building Solutions EMEA/LA | 1,849 |  |  | 20 |  |  | (15 | ) |  | 1,854 |  |
| Building Solutions Asia Pacific | 1,194 |  |  | — |  |  | (23 | ) |  | 1,171 |  |
| Global Products | 5,547 |  |  | 19 |  |  | (62 | ) |  | 5,504 |  |
| Total | $ | 18,178 |  |  | $ | 39 |  |  | $ | (145 | ) |  | $ | 18,072 |  |

[0000833444-20-000015:notes:68]
[same as prior period, unchanged from 0000833444-20-000006:notes:68]

[0000833444-20-000015:notes:69]
The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company considered the deterioration in general economic and market conditions due to the COVID-19 pandemic and its impact on each of the Company’s reporting units’ performance. Based on the Company’s assessment of its market capitalization, forecasts and the amount of excess of fair value over the carrying value of the reporting units in the fiscal 2019 annual test, the Company concluded a triggering event did not occur during the quarter ended March 31, 2020. The Company continuously monitors for events and circumstances that could negatively impact the key assumptions in determining fair value, including long-term revenue growth projections, profitability, discount rates, recent market valuations from transactions by comparable companies, volatility in the Company's market capitalization, and general industry, market and macro-economic conditions. It is possible that future changes in such circumstances, including a more prolonged and/or severe COVID-19 pandemic, or future changes in the variables associated with the judgments, assumptions and estimates used in assessing the fair value of the reporting unit, would require the Company to record a non-cash impairment charge.

[0000833444-20-000015:notes:70]
[same as prior period, unchanged from 0000833444-20-000006:notes:69]

[0000833444-20-000015:notes:71]
|  | March 31, 2020 |  | September 30, 2019 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,306 |  |  | $ | (427 | ) |  | $ | 879 |  |  | $ | 1,307 |  |  | $ | (370 | ) |  | $ | 937 |  |
| Customer relationships | 2,704 |  |  | (854 | ) |  | 1,850 |  |  | 2,722 |  |  | (759 | ) |  | 1,963 |  |
| Miscellaneous | 618 |  |  | (240 | ) |  | 378 |  |  | 584 |  |  | (224 | ) |  | 360 |  |
| Total definite-lived intangible assets | 4,628 |  |  | (1,521 | ) |  | 3,107 |  |  | 4,613 |  |  | (1,353 | ) |  | 3,260 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,205 |  |  | — |  |  | 2,205 |  |  | 2,282 |  |  | — |  |  | 2,282 |  |
| Miscellaneous | 79 |  |  | — |  |  | 79 |  |  | 90 |  |  | — |  |  | 90 |  |
|  | 2,284 |  |  | — |  |  | 2,284 |  |  | 2,372 |  |  | — |  |  | 2,372 |  |
| Total intangible assets | $ | 6,912 |  |  | $ | (1,521 | ) |  | $ | 5,391 |  |  | $ | 6,985 |  |  | $ | (1,353 | ) |  | $ | 5,632 |  |

[0000833444-20-000015:notes:72]
The Company reviews indefinite-lived intangible assets for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. Indefinite-lived intangible assets primarily consist of trademarks and tradenames and are tested for impairment using a relief-from-royalty method. During the second quarter of fiscal 2020, the Company determined that it had a triggering event requiring assessment of impairment for certain of its indefinite-lived intangible assets due to declines in revenue directly attributable to the COVID-19 pandemic. As a result, the Company recorded an impairment charge of $62 million related primarily to the Company's retail business indefinite-lived intangible assets within restructuring and impairment costs in the consolidated statements of income in the second quarter of fiscal 2020. The Company continuously monitors for events and circumstances that could negatively impact the key assumptions in determining fair value, including long-term revenue growth projections, discount rates and general industry, market and macro-economic conditions. It is possible that future changes in such circumstances, including a more prolonged and/or severe COVID-19 pandemic, or future changes in the variables associated with the judgments, assumptions and estimates used in assessing the fair value of the indefinite-lived intangible assets, would require the Company to record an additional non-cash impairment charge.

[0000833444-20-000015:notes:73]
Amortization of other intangible assets included within continuing operations for the three month periods ended March 31, 2020 and 2019 was $97 million and $98 million, respectively. Amortization of other intangible assets included within continuing operations for the six month periods ended March 31, 2020 and 2019 was $193 million and $195 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2021, 2022, 2023, 2024 and 2025 will be approximately $392 million, $390 million, $382 million, $363 million and $346 million per year, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-20-000015:notes:74]
[same as prior period, unchanged from 0000833444-20-000006:notes:72]

[0000833444-20-000015:notes:75]
[same as prior period, unchanged from 0000833444-20-000006:notes:73]

[0000833444-20-000015:notes:76]
In the first quarter of fiscal 2020, the Company committed to a significant restructuring plan ("2020 Plan") and recorded $111 million of restructuring and impairment costs in the consolidated statements of income. This was the total amount incurred to date. The restructuring actions related primarily to cost reduction initiatives. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $87 million related to the Global Products segment, $10 million related to the Building Solutions Asia Pacific segment, $8 million related to the Building Solutions North America segment and $6 million related to the Building Solutions EMEA/LA segment. The restructuring actions are expected to be substantially complete in fiscal 2020.

[0000833444-20-000015:notes:77]
[same as prior period, unchanged from 0000833444-20-000006:notes:75]

[0000833444-20-000015:notes:78]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 54 |  |  | $ | 54 |  |  | $ | 3 |  |  | $ | 111 |  |
| Utilized—cash | (8 | ) |  | — |  |  | — |  |  | (8 | ) |
| Utilized—noncash | — |  |  | (54 | ) |  | — |  |  | (54 | ) |
| Balance at December 31, 2019 | $ | 46 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 49 |  |
| Utilized—cash | (24 | ) |  | — |  |  | (1 | ) |  | (25 | ) |
| Balance at March 31, 2020 | $ | 22 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 24 |  |

[0000833444-20-000015:notes:79]
In the second quarter of fiscal 2020, the Company recorded $62 million of restructuring and impairment costs in the consolidated statements of income for indefinite-lived intangible asset impairments. Refer to Note 8, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for further information regarding the indefinite-lived intangibles impairments.

[0000833444-20-000015:notes:80]
[same as prior period, unchanged from 0000833444-20-000006:notes:77]

[0000833444-20-000015:notes:81]
[same as prior period, unchanged from 0000833444-20-000006:notes:78]

[0000833444-20-000015:notes:82]
[same as prior period, unchanged from 0000833444-20-000006:notes:79]

[0000833444-20-000015:notes:83]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 209 |  |  | $ | 42 |  |  | $ | 12 |  |  | $ | — |  |  | $ | 263 |  |
| Utilized—cash | (45 | ) |  | — |  |  | (2 | ) |  | — |  |  | (47 | ) |
| Utilized—noncash | — |  |  | (42 | ) |  | — |  |  | — |  |  | (42 | ) |
| Balance at September 30, 2018 | $ | 164 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 174 |  |
| Utilized—cash | (61 | ) |  | — |  |  | (6 | ) |  | — |  |  | (67 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Transfer to liabilities held for sale | (4 | ) |  | — |  |  | — |  |  | — |  |  | (4 | ) |
| Balance at September 30, 2019 | $ | 99 |  |  | $ | — |  |  | $ | 4 |  |  | $ | (1 | ) |  | $ | 102 |  |
| Utilized—cash | (21 | ) |  | — |  |  | — |  |  | — |  |  | (21 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Adoption of ASC 8421 | — |  |  | — |  |  | (4 | ) |  | — |  |  | (4 | ) |
| Balance at March 31, 2020 | $ | 78 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 78 |  |

[0000833444-20-000015:notes:84]
[same as prior period, unchanged from 0000833444-20-000006:notes:81]

[0000833444-20-000015:notes:85]
[same as prior period, unchanged from 0000833444-20-000006:notes:82]

[0000833444-20-000015:notes:86]
[same as prior period, unchanged from 0000833444-20-000006:notes:83]

[0000833444-20-000015:notes:87]
[same as prior period, unchanged from 0000833444-20-000006:notes:84]

[0000833444-20-000015:notes:88]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 276 |  |  | $ | 77 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 367 |  |
| Utilized—cash | (75 | ) |  | — |  |  | — |  |  | — |  |  | (75 | ) |
| Utilized—noncash | — |  |  | (77 | ) |  | (1 | ) |  | — |  |  | (78 | ) |
| Adjustment to restructuring reserves | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |
| Balance at September 30, 2017 | $ | 226 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 239 |  |
| Utilized—cash | (152 | ) |  | — |  |  | (6 | ) |  | — |  |  | (158 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Balance at September 30, 2018 | $ | 74 |  |  | $ | — |  |  | $ | 7 |  |  | $ | (1 | ) |  | $ | 80 |  |
| Utilized—cash | (11 | ) |  | — |  |  | (2 | ) |  | — |  |  | (13 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (3 | ) |  | (3 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Balance at September 30, 2019 | $ | 60 |  |  | $ | — |  |  | $ | 5 |  |  | $ | (4 | ) |  | $ | 61 |  |
| Utilized—cash | (25 | ) |  | — |  |  | — |  |  | — |  |  | (25 | ) |
| Adoption of ASC 8421 | — |  |  | — |  |  | (5 | ) |  | — |  |  | (5 | ) |
| Balance at March 31, 2020 | $ | 35 |  |  | $ | — |  |  | $ | — |  |  | $ | (4 | ) |  | $ | 31 |  |

[0000833444-20-000015:notes:89]
The Company's fiscal 2020, 2018 and 2017 restructuring plans included workforce reductions of approximately 11,200 employees (9,000 for the Building Technologies & Solutions business and 2,200 for Corporate). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of March 31, 2020, approximately 9,600 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included nine plant closures in the Building Technologies & Solutions business. As of March 31, 2020, eight of the nine plants have been closed.

[0000833444-20-000015:notes:90]
[same as prior period, unchanged from 0000833444-20-000006:notes:87]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-20-000015:notes:91]
[same as prior period, unchanged from 0000833444-20-000006:notes:88]

[0000833444-20-000015:notes:92]
[same as prior period, unchanged from 0000833444-20-000006:notes:89]

[0000833444-20-000015:notes:93]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended March 31, 2020, the Company's effective tax rate for continuing operations was 5% and was lower than the statutory tax rate of 12.5% primarily due to tax audit reserve adjustments and the benefits of continuing global tax planning initiatives, partially offset by tax rate differentials. For the six months ended March 31, 2020, the Company's effective tax rate for continuing operations was 15% and was higher than the statutory tax rate of 12.5% primarily due to a discrete tax charge

[0000833444-20-000015:notes:94]
related to the remeasurement of deferred tax assets and liabilities as a result of Swiss tax reform and tax rate differentials, partially offset by tax audit reserve adjustments and the benefits of continuing global tax planning initiatives. For the three months ended March 31, 2019, the Company's effective tax rate for continuing operations was 15% and was higher than the statutory tax rate of 12.5% primarily due to tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the six months ended March 31, 2019, the Company's effective tax rate for continuing operations was 27% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments as a result of tax law changes and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives.

[0000833444-20-000015:notes:95]
[same as prior period, unchanged from 0000833444-20-000006:notes:91]

[0000833444-20-000015:notes:96]
[same as prior period, unchanged from 0000833444-20-000006:notes:92]

[0000833444-20-000015:notes:97]
[same as prior period, unchanged from 0000833444-20-000006:notes:93]

[0000833444-20-000015:notes:98]
[same as prior period, unchanged from 0000833444-20-000006:notes:94]

[0000833444-20-000015:notes:99]
At September 30, 2019, the Company had gross tax effected unrecognized tax benefits of $2,451 million, of which $2,121 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2019 was approximately $181 million (net of tax benefit). The interest and penalties accrued during the six months ended March 31, 2020 were approximately $35 million (net of tax benefit). Interest and penalties accrued during the six months ended March 31, 2019 were approximately $31 million (net of tax benefit). The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-20-000015:notes:100]
In the second quarter of fiscal 2020, tax audit resolutions resulted in a $22 million net benefit to income tax expense.

[0000833444-20-000015:notes:101]
In the U.S., fiscal years 2017 through 2018 are currently under exam by the Internal Revenue Service (“IRS”) for certain legal entities. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions for continuing operations:

[0000833444-20-000015:notes:102]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2018 |
| China |  | 2008 - 2016 |
| Germany |  | 2007 - 2016 |
| Taiwan |  | 2017 - 2018 |
| United Kingdom |  | 2014 - 2015, 2017 |

[0000833444-20-000015:notes:103]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense.

[0000833444-20-000015:notes:104]
[same as prior period, unchanged from 0000833444-20-000006:notes:99]

[0000833444-20-000015:notes:105]
On March 27, 2020, in response to the COVID-19 pandemic, the “Coronavirus Aid, Relief and Economic Security Act” (“CARES”) was signed into law by the President of the United States.  The CARES Act includes, among other things, U.S. corporate income tax provisions related to net operating loss carryback periods, alternative minimum tax credits, modifications to interest deduction limitations and technical corrections on tax depreciation methods for qualified improvement property.  A majority of non-U.S. countries have also introduced various COVID-19 related corporate income tax relief provisions.  The Company does not expect either the U.S. or non-U.S. corporate income tax provisions to have a material effect on its financial statements.

[0000833444-20-000015:notes:106]
In the first quarter of fiscal 2020, the Company recorded a noncash discrete tax charge of $30 million due to the remeasurement of deferred tax assets and liabilities related to Switzerland and the canton of Schaffhausen. On September 28, 2018, the Swiss Parliament approved the Federal Act on Tax Reform and AHV Financing (“TRAF”), which was subsequently approved by the Swiss electorate on May 19, 2019. During the fourth quarter of fiscal 2019, the Swiss Federal Council enacted TRAF which became effective for the Company on January 1, 2020. The impacts of the federal enactment did not have a material impact to the Company’s financial statements. TRAF also provides for parameters which enable the Swiss cantons to adjust tax rates and establish new regulations for companies. As of September 30, 2019, the canton of Schaffhausen had not concluded its public referendum; however, the enactment did occur during the first quarter of fiscal 2020.

[0000833444-20-000015:notes:107]
During the six months ended March 31, 2020 and 2019, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-20-000015:notes:108]
[same as prior period, unchanged from 0000833444-20-000006:notes:102]

[0000833444-20-000015:notes:109]
[same as prior period, unchanged from 0000833444-20-000006:notes:103]

[0000833444-20-000015:notes:110]
In the second quarter of fiscal 2020, the Company recorded $62 million of significant restructuring and impairment costs. Refer to Note 8, "Goodwill and Other Intangible Assets," and Note 9, “Significant Restructuring and Impairment Costs,” of the notes to consolidated financial statements for additional information. The restructuring costs generated a $4 million tax benefit, which reflects the Company’s current tax position in the impacted jurisdictions.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-20-000015:notes:111]
[same as prior period, unchanged from 0000833444-20-000006:notes:104]

[0000833444-20-000015:notes:112]
[same as prior period, unchanged from 0000833444-20-000006:notes:105]

[0000833444-20-000015:notes:113]
|  | U.S. Pension Plans |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Interest cost | $ | 19 |  |  | $ | 25 |  |  | 37 |  |  | 50 |  |
| Expected return on plan assets | (46 | ) |  | (46 | ) |  | (90 | ) |  | (92 | ) |
| Net periodic benefit credit | $ | (27 | ) |  | $ | (21 | ) |  | $ | (53 | ) |  | $ | (42 | ) |

[0000833444-20-000015:notes:114]
|  | Non-U.S. Pension Plans |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Service cost | $ | 7 |  |  | $ | 6 |  |  | $ | 13 |  |  | $ | 11 |  |
| Interest cost | 9 |  |  | 12 |  |  | 18 |  |  | 26 |  |
| Expected return on plan assets | (29 | ) |  | (25 | ) |  | (56 | ) |  | (52 | ) |
| Amortization of prior service cost | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Settlement loss | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net periodic benefit credit | $ | (12 | ) |  | $ | (6 | ) |  | $ | (24 | ) |  | $ | (14 | ) |

[0000833444-20-000015:notes:115]
|  | Postretirement Benefits |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Service cost | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Interest cost | 1 |  |  | 1 |  |  | 2 |  |  | 3 |  |
| Expected return on plan assets | (2 | ) |  | (3 | ) |  | (4 | ) |  | (5 | ) |
| Amortization of prior service credit | — |  |  | — |  |  | (1 | ) |  | — |  |
| Net periodic benefit credit | $ | (1 | ) |  | $ | (1 | ) |  | $ | (3 | ) |  | $ | (1 | ) |


## us-gaap:DebtDisclosureTextBlock

[0000833444-20-000015:notes:116]
Debt and Financing Arrangements

[0000833444-20-000015:notes:117]
Net Financing Charges

[0000833444-20-000015:notes:118]
The Company's net financing charges line item in the consolidated statements of income for the three and six months ended March 31, 2020 and 2019 contained the following components (in millions):

[0000833444-20-000015:notes:119]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Interest expense, net of capitalized interest costs | $ | 62 |  |  | $ | 97 |  |  | $ | 124 |  |  | $ | 188 |  |
| Banking fees and bond cost amortization | 5 |  |  | 7 |  |  | 10 |  |  | 13 |  |
| Interest income | (5 | ) |  | (6 | ) |  | (18 | ) |  | (13 | ) |
| Net foreign exchange results for financing activities | (3 | ) |  | — |  |  | (5 | ) |  | (5 | ) |
| Net financing charges | $ | 59 |  |  | $ | 98 |  |  | $ | 111 |  |  | $ | 183 |  |

[0000833444-20-000015:notes:120]
In April 2020, the Company entered into various European financing arrangements totaling $675 million which are due in September 2020 and $575 million of bank term loans which are due in April 2021.

[0000833444-20-000015:notes:121]
In March 2020, the Company retired $500 million in principal amount, plus accrued interest, of its 5.0% fixed rate notes that expired in March 2020.

[0000833444-20-000015:notes:122]
In December 2019, the Company entered into a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2020.  As of March 31, 2020, there were no draws on the facilities.

[0000833444-20-000015:notes:123]
In December 2019, the Company terminated its syndicated 5-year $2 billion committed revolving credit facility and four 364-day revolving credit facilities with total committed capacity of $750 million.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-20-000015:notes:124]
[same as prior period, unchanged from 0000833444-20-000006:notes:115]

[0000833444-20-000015:notes:125]
On September 2, 2016, the shareholders of the Company approved amendments to the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based compensation awards. The Compensation Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter. A summary of the stock-based awards granted during the six month periods ended March 31, 2020 and 2019 is presented below:

[0000833444-20-000015:notes:126]
|  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  | Number Granted |  | Weighted Average Grant Date Fair Value |
| Stock options | 1,347,310 |  |  | $ | 7.29 |  |  | 1,741,510 |  |  | $ | 5.56 |  |
| Restricted stock/units | 1,864,026 |  |  | 41.55 |  |  | 2,307,864 |  |  | 33.43 |  |
| Performance shares | 476,939 |  |  | 42.48 |  |  | 583,989 |  |  | 36.28 |  |

[0000833444-20-000015:notes:127]
[same as prior period, unchanged from 0000833444-20-000006:notes:118]

[0000833444-20-000015:notes:128]
[same as prior period, unchanged from 0000833444-20-000006:notes:119]

[0000833444-20-000015:notes:129]
[same as prior period, unchanged from 0000833444-20-000006:notes:120]

[0000833444-20-000015:notes:130]
|  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |
| Expected life of option (years) | 6.5 |  | 6.4 |
| Risk-free interest rate | 1.67% |  | 2.77% |
| Expected volatility of the Company’s stock | 22.4% |  | 21.8% |
| Expected dividend yield on the Company’s stock | 2.49% |  | 3.29% |

[0000833444-20-000015:notes:131]
[same as prior period, unchanged from 0000833444-20-000006:notes:122]

[0000833444-20-000015:notes:132]
[same as prior period, unchanged from 0000833444-20-000006:notes:123]

[0000833444-20-000015:notes:133]
[same as prior period, unchanged from 0000833444-20-000006:notes:124]

[0000833444-20-000015:notes:134]
[same as prior period, unchanged from 0000833444-20-000006:notes:125]

[0000833444-20-000015:notes:135]
[same as prior period, unchanged from 0000833444-20-000006:notes:126]

[0000833444-20-000015:notes:136]
|  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |
| Risk-free interest rate | 1.60% |  | 2.76% |
| Expected volatility of the Company’s stock | 21.8% |  | 22.9% |


## us-gaap:EarningsPerShareTextBlock

[0000833444-20-000015:notes:137]
[same as prior period, unchanged from 0000833444-20-000006:notes:128]

[0000833444-20-000015:notes:138]
[same as prior period, unchanged from 0000833444-20-000006:notes:129]

[0000833444-20-000015:notes:139]
[same as prior period, unchanged from 0000833444-20-000006:notes:130]

[0000833444-20-000015:notes:140]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Income Available to Ordinary Shareholders |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 213 |  |  | $ | 240 |  |  | $ | 372 |  |  | $ | 347 |  |
| Income from discontinued operations | — |  |  | 275 |  |  | — |  |  | 523 |  |
| Basic and diluted income available to shareholders | $ | 213 |  |  | $ | 515 |  |  | $ | 372 |  |  | $ | 870 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 754.8 |  |  | 902.5 |  |  | 762.4 |  |  | 912.1 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 2.3 |  |  | 3.4 |  |  | 3.2 |  |  | 3.5 |  |
| Diluted weighted average shares outstanding | 757.1 |  |  | 905.9 |  |  | 765.6 |  |  | 915.6 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Options to purchase shares | 1.4 |  |  | 2.2 |  |  | 0.8 |  |  | 2.4 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-20-000015:notes:141]
[same as prior period, unchanged from 0000833444-20-000006:notes:132]

[0000833444-20-000015:notes:142]
[same as prior period, unchanged from 0000833444-20-000006:notes:133]

[0000833444-20-000015:notes:143]
|  | Three Months Ended March 31, 2020 |  | Three Months Ended March 31, 2019 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, December 31, | $ | 19,329 |  |  | $ | 1,102 |  |  | $ | 20,431 |  |  | $ | 20,102 |  |  | $ | 1,305 |  |  | $ | 21,407 |  |
| Total comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 213 |  |  | 23 |  |  | 236 |  |  | 515 |  |  | 43 |  |  | 558 |  |
| Foreign currency translation adjustments | (471 | ) |  | (23 | ) |  | (494 | ) |  | 114 |  |  | 3 |  |  | 117 |  |
| Realized and unrealized gains (losses) on derivatives | (10 | ) |  | — |  |  | (10 | ) |  | 14 |  |  | 3 |  |  | 17 |  |
| Other comprehensive income (loss) | (481 | ) |  | (23 | ) |  | (504 | ) |  | 128 |  |  | 6 |  |  | 134 |  |
| Comprehensive income (loss) | (268 | ) |  | — |  |  | (268 | ) |  | 643 |  |  | 49 |  |  | 692 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (194 | ) |  | — |  |  | (194 | ) |  | (235 | ) |  | — |  |  | (235 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (98 | ) |  | (98 | ) |  | — |  |  | (89 | ) |  | (89 | ) |
| Repurchases and retirements of ordinary shares | (816 | ) |  | — |  |  | (816 | ) |  | (533 | ) |  | — |  |  | (533 | ) |
| Other, including options exercised | 33 |  |  | — |  |  | 33 |  |  | 59 |  |  | — |  |  | 59 |  |
| Ending balance, March 31, | $ | 18,084 |  |  | $ | 1,004 |  |  | $ | 19,088 |  |  | $ | 20,036 |  |  | $ | 1,265 |  |  | $ | 21,301 |  |

[0000833444-20-000015:notes:144]
|  | Six Months Ended March 31, 2020 |  | Six Months Ended March 31, 2019 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, September 30, | $ | 19,766 |  |  | $ | 1,063 |  |  | $ | 20,829 |  |  | $ | 21,164 |  |  | $ | 1,294 |  |  | $ | 22,458 |  |
| Total comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 372 |  |  | 55 |  |  | 427 |  |  | 870 |  |  | 87 |  |  | 957 |  |
| Foreign currency translation adjustments | (220 | ) |  | (13 | ) |  | (233 | ) |  | (13 | ) |  | 12 |  |  | (1 | ) |
| Realized and unrealized gains (losses) on derivatives | (5 | ) |  | 2 |  |  | (3 | ) |  | 15 |  |  | 4 |  |  | 19 |  |
| Pension and postretirement plans | (1 | ) |  | — |  |  | (1 | ) |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | (226 | ) |  | (11 | ) |  | (237 | ) |  | 2 |  |  | 16 |  |  | 18 |  |
| Comprehensive income | 146 |  |  | 44 |  |  | 190 |  |  | 872 |  |  | 103 |  |  | 975 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (395 | ) |  | — |  |  | (395 | ) |  | (475 | ) |  | — |  |  | (475 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (103 | ) |  | (103 | ) |  | — |  |  | (132 | ) |  | (132 | ) |
| Repurchases and retirements of ordinary shares | (1,467 | ) |  | — |  |  | (1,467 | ) |  | (1,000 | ) |  | — |  |  | (1,000 | ) |
| Adoption of ASC 606 | — |  |  | — |  |  | — |  |  | (45 | ) |  | — |  |  | (45 | ) |
| Adoption of ASU 2016-16 | — |  |  | — |  |  | — |  |  | (546 | ) |  | — |  |  | (546 | ) |
| Adoption of ASC 842 | (5 | ) |  | — |  |  | (5 | ) |  | — |  |  | — |  |  | — |  |
| Other, including options exercised | 39 |  |  | — |  |  | 39 |  |  | 66 |  |  | — |  |  | 66 |  |
| Ending balance, March 31, | $ | 18,084 |  |  | $ | 1,004 |  |  | $ | 19,088 |  |  | $ | 20,036 |  |  | $ | 1,265 |  |  | $ | 21,301 |  |

[0000833444-20-000015:notes:145]
[same as prior period, unchanged from 0000833444-20-000006:notes:135]

[0000833444-20-000015:notes:146]
During the quarter ended December 31, 2018, the Company adopted ASU 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory." As a result, the Company recognized deferred taxes of $546 million related to the tax effects of all intra-entity sales of assets other than inventory on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2018.

[0000833444-20-000015:notes:147]
For the three and six months ended March 31, 2020, the Company repurchased and retired $816 million and $1,467 million of its ordinary shares, respectively. For the three and six months ended March 31, 2019, the Company repurchased $533 million and $1 billion of its ordinary shares, respectively, which were retired in the fourth quarter of fiscal 2019. As of March 31, 2020, approximately $3.1 billion remains available under the share repurchase program. In order to enhance liquidity resources in response to business uncertainty related to the COVID-19 pandemic, in March 2020 the Company made the decision to suspend its share repurchase program.

[0000833444-20-000015:notes:148]
[same as prior period, unchanged from 0000833444-20-000006:notes:138]

[0000833444-20-000015:notes:149]
|  | Three Months Ended March 31, |
|  | 2020 |  | 2019 |
| Foreign currency translation adjustments ("CTA") |  |  |  |
| Balance at beginning of period | $ | (534 | ) |  | $ | (1,066 | ) |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | (471 | ) |  | 114 |  |
| Balance at end of period | (1,005 | ) |  | (952 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 3 |  |  | (12 | ) |
| Current period changes in fair value (net of tax effect of $(3) and $6) | (8 | ) |  | 12 |  |
| Reclassification to income (net of tax effect of $0 and $2) * | (2 | ) |  | 2 |  |
| Balance at end of period | (7 | ) |  | 2 |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (9 | ) |  | (2 | ) |
| Reclassification to income (net of tax effect of $0 and $0) | — |  |  | — |  |
| Balance at end of period | (9 | ) |  | (2 | ) |
| Accumulated other comprehensive loss, end of period | $ | (1,021 | ) |  | $ | (952 | ) |

[0000833444-20-000015:notes:150]
|  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |
| CTA |  |  |  |
| Balance at beginning of period | $ | (785 | ) |  | $ | (939 | ) |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | (220 | ) |  | (13 | ) |
| Balance at end of period | (1,005 | ) |  | (952 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (2 | ) |  | (13 | ) |
| Current period changes in fair value (net of tax effect of $(1) and $4) | (3 | ) |  | 8 |  |
| Reclassification to income (net of tax effect of $0 and $3) * | (2 | ) |  | 7 |  |
| Balance at end of period | (7 | ) |  | 2 |  |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | — |  |  | 8 |  |
| Adoption of ASU 2016-01 ** | — |  |  | (8 | ) |
| Balance at end of period | — |  |  | — |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (8 | ) |  | (2 | ) |
| Reclassification to income (net of tax effect of $0 and $0) | (1 | ) |  | — |  |
| Balance at end of period | (9 | ) |  | (2 | ) |
| Accumulated other comprehensive loss, end of period | $ | (1,021 | ) |  | $ | (952 | ) |

[0000833444-20-000015:notes:151]
[same as prior period, unchanged from 0000833444-20-000006:notes:140]

[0000833444-20-000015:notes:152]
[same as prior period, unchanged from 0000833444-20-000006:notes:141]

[0000833444-20-000015:notes:153]
[same as prior period, unchanged from 0000833444-20-000006:notes:142]

[0000833444-20-000015:notes:154]
** During the quarter ended December 31, 2018, the Company adopted ASU 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." As a result, the Company reclassified $8 million of unrealized gains on marketable securities to retained earnings as of October 1, 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-20-000015:notes:155]
[same as prior period, unchanged from 0000833444-20-000006:notes:144]

[0000833444-20-000015:notes:156]
[same as prior period, unchanged from 0000833444-20-000006:notes:145]

[0000833444-20-000015:notes:157]
[same as prior period, unchanged from 0000833444-20-000006:notes:146]

[0000833444-20-000015:notes:158]
The Company has global operations and participates in the foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the notional amount of each of its known foreign exchange transactional exposures.

[0000833444-20-000015:notes:159]
[same as prior period, unchanged from 0000833444-20-000006:notes:148]

[0000833444-20-000015:notes:160]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three and six months ended March 31, 2020 and 2019.

[0000833444-20-000015:notes:161]
[same as prior period, unchanged from 0000833444-20-000006:notes:150]

[0000833444-20-000015:notes:162]
|  |  | Volume Outstanding as of |
| Commodity |  | March 31, 2020 |  | September 30, 2019 |
| Copper |  | 3,719 |  |  | 3,561 |  |
| Aluminum |  | 2,921 |  |  | 2,967 |  |

[0000833444-20-000015:notes:163]
[same as prior period, unchanged from 0000833444-20-000006:notes:152]

[0000833444-20-000015:notes:164]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company’s net investments globally. At March 31, 2020 and September 30, 2019, the Company had 888 million euro, 750 million euro, 423 million euro and 54 million euro in bonds designated as net investment hedges in the Company's net investment in Europe and 25 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan.

[0000833444-20-000015:notes:165]
[same as prior period, unchanged from 0000833444-20-000006:notes:154]

[0000833444-20-000015:notes:166]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount.  As of March 31, 2020 and September 30, 2019, the Company hedged approximately 1.4 million shares of its ordinary shares, which have a cost basis of $60 million.

[0000833444-20-000015:notes:167]
[same as prior period, unchanged from 0000833444-20-000006:notes:156]

[0000833444-20-000015:notes:168]
[same as prior period, unchanged from 0000833444-20-000006:notes:157]

[0000833444-20-000015:notes:169]
[same as prior period, unchanged from 0000833444-20-000006:notes:158]

[0000833444-20-000015:notes:170]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | March 31, |  | September 30, |  | March 31, |  | September 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 14 |  |  | $ | 16 |  |  | $ | 13 |  |  | $ | 19 |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 38 |  |  | 62 |  |
| Total assets | $ | 14 |  |  | $ | 16 |  |  | $ | 51 |  |  | $ | 81 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 22 |  |  | $ | 23 |  |  | $ | 27 |  |  | $ | — |  |
| Commodity derivatives | 4 |  |  | 1 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 2,556 |  |  | 2,544 |  |  | — |  |  | — |  |
| Total liabilities | $ | 2,582 |  |  | $ | 2,568 |  |  | $ | 27 |  |  | $ | — |  |

[0000833444-20-000015:notes:171]
[same as prior period, unchanged from 0000833444-20-000006:notes:160]

[0000833444-20-000015:notes:172]
[same as prior period, unchanged from 0000833444-20-000006:notes:161]

[0000833444-20-000015:notes:173]
[same as prior period, unchanged from 0000833444-20-000006:notes:162]

[0000833444-20-000015:notes:174]
[same as prior period, unchanged from 0000833444-20-000006:notes:163]

[0000833444-20-000015:notes:175]
|  |  | Fair Value of Assets |  | Fair Value of Liabilities |
|  |  | March 31, |  | September 30, |  | March 31, |  | September 30, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Gross amount recognized |  | $ | 65 |  |  | $ | 97 |  |  | $ | 2,609 |  |  | $ | 2,568 |  |
| Gross amount eligible for offsetting |  | (15 | ) |  | (11 | ) |  | (15 | ) |  | (11 | ) |
| Net amount |  | $ | 50 |  |  | $ | 86 |  |  | $ | 2,594 |  |  | $ | 2,557 |  |

[0000833444-20-000015:notes:176]
[same as prior period, unchanged from 0000833444-20-000006:notes:165]

[0000833444-20-000015:notes:177]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the three and six months ended March 31, 2020 and 2019 (in millions):

[0000833444-20-000015:notes:178]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Foreign currency exchange derivatives |  | $ | (7 | ) |  | $ | 9 |  |  | $ | 2 |  |  | $ | 9 |  |
| Commodity derivatives |  | (4 | ) |  | 9 |  |  | (3 | ) |  | 3 |  |
| Total |  | $ | (11 | ) |  | $ | 18 |  |  | $ | (1 | ) |  | $ | 12 |  |

[0000833444-20-000015:notes:179]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the three and six months ended March 31, 2020 and 2019 (in millions):

[0000833444-20-000015:notes:180]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 2 |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | 2 |  |
| Foreign currency exchange derivatives |  | Income from discontinued operations |  | — |  |  | (1 | ) |  | — |  |  | — |  |
| Commodity derivatives |  | Cost of sales |  | — |  |  | (1 | ) |  | (1 | ) |  | (3 | ) |
| Commodity derivatives |  | Income from discontinued operations |  | — |  |  | (4 | ) |  | — |  |  | (9 | ) |
| Total |  |  |  | $ | 2 |  |  | $ | (4 | ) |  | $ | 2 |  |  | $ | (10 | ) |

[0000833444-20-000015:notes:181]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the three and six months ended March 31, 2020 and 2019 (in millions):

[0000833444-20-000015:notes:182]
|  |  |  |  | Amount of Gain (Loss) Recognized inIncome on Derivative |
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 4 |  |  | $ | (2 | ) |  | $ | 4 |  |  | $ | (6 | ) |
| Foreign currency exchange derivatives |  | Net financing charges |  | (10 | ) |  | (3 | ) |  | 49 |  |  | (24 | ) |
| Foreign currency exchange derivatives |  | Income from discontinued operations |  | — |  |  | 28 |  |  | — |  |  | 54 |  |
| Equity swap |  | Selling, general and administrative |  | (20 | ) |  | 12 |  |  | (24 | ) |  | 3 |  |
| Total |  |  |  | $ | (26 | ) |  | $ | 35 |  |  | $ | 29 |  |  | $ | 27 |  |

[0000833444-20-000015:notes:183]
The pre-tax gains on net investment hedges recorded in CTA within other comprehensive income (loss) were $46 million and $50 million for the three months ended March 31, 2020 and 2019, respectively. The pre-tax gains (losses) on net investment hedges recorded in CTA within other comprehensive income (loss) were $(12) million and $84 million for the six months ended March 31, 2020 and 2019, respectively. For the three and six months ended March 31, 2020 and 2019, no gains or losses were reclassified from CTA into income.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-20-000015:notes:184]
[same as prior period, unchanged from 0000833444-20-000006:notes:173]

[0000833444-20-000015:notes:185]
[same as prior period, unchanged from 0000833444-20-000006:notes:174]

[0000833444-20-000015:notes:186]
[same as prior period, unchanged from 0000833444-20-000006:notes:175]

[0000833444-20-000015:notes:187]
[same as prior period, unchanged from 0000833444-20-000006:notes:176]

[0000833444-20-000015:notes:188]
[same as prior period, unchanged from 0000833444-20-000006:notes:177]

[0000833444-20-000015:notes:189]
[same as prior period, unchanged from 0000833444-20-000006:notes:178]

[0000833444-20-000015:notes:190]
[same as prior period, unchanged from 0000833444-20-000006:notes:179]

[0000833444-20-000015:notes:191]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of March 31, 2020 and September 30, 2019 (in millions):

[0000833444-20-000015:notes:192]
|  | Fair Value Measurements Using: |
|  | Total as of March 31, 2020 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 27 |  |  | $ | — |  |  | $ | 27 |  |  | $ | — |  |
| Exchange traded funds (fixed income)1 | 38 |  |  | 38 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 54 |  |  | 54 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 114 |  |  | 114 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 99 |  |  | 99 |  |  | — |  |  | — |  |
| Equity swap | 38 |  |  | — |  |  | 38 |  |  | — |  |
| Total assets | $ | 370 |  |  | $ | 305 |  |  | $ | 65 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 49 |  |  | $ | — |  |  | $ | 49 |  |  | $ | — |  |
| Commodity derivatives | 4 |  |  | — |  |  | 4 |  |  | — |  |
| Total liabilities | $ | 53 |  |  | $ | — |  |  | $ | 53 |  |  | $ | — |  |

[0000833444-20-000015:notes:193]
[same as prior period, unchanged from 0000833444-20-000006:notes:182]

[0000833444-20-000015:notes:194]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements for further details.

[0000833444-20-000015:notes:195]
[same as prior period, unchanged from 0000833444-20-000006:notes:184]

[0000833444-20-000015:notes:196]
[same as prior period, unchanged from 0000833444-20-000006:notes:185]

[0000833444-20-000015:notes:197]
[same as prior period, unchanged from 0000833444-20-000006:notes:186]

[0000833444-20-000015:notes:198]
[same as prior period, unchanged from 0000833444-20-000006:notes:187]

[0000833444-20-000015:notes:199]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. During the three months ended March 31, 2020 and 2019, the Company recognized unrealized gains (losses) of $(10) million and $7 million, respectively, in the consolidated statements of income on these investments that were still held as of March 31, 2020 and 2019, where they offset unrealized gains and losses on the related deferred compensation plan liability. During the six months ended March 31, 2020 and 2019, the Company recognized unrealized gains (losses) of $(7) million and $(2) million, respectively, in the consolidated statements of income on these investments that were still held as of March 31, 2020 and 2019, where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-20-000015:notes:200]
Investments in marketable common stock and exchange traded funds:  Investments in marketable common stock and exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. During the three months ended March 31, 2020 and 2019, the Company recognized unrealized gains (losses) of $(32) million and $21 million, respectively, in the consolidated statements of income on these investments that were still held as of March 31, 2020 and 2019. Of these amounts, $(32) million and $20 million, respectively, of gains (losses) related to restricted investments. During the six months ended March 31, 2020 and 2019, the Company recognized unrealized gains (losses) of $(22) million and $(1) million, respectively, in the consolidated statements of income

[0000833444-20-000015:notes:201]
on these investments that were still held as of March 31, 2020 and 2019, all of which related to restricted investments. Refer to Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-20-000015:notes:202]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. At March 31, 2020, the fair value of long-term debt was $7.0 billion, including public debt of $6.8 billion, which was determined primarily using market quotes classified as Level 1 inputs within the ASC 820 fair value hierarchy and other long-term debt of $0.2 billion, which was determined based on quoted market prices for similar instruments classified as Level 2 inputs within the ASC 820 fair value hierarchy. At September 30, 2019, the fair value of long-term debt was $7.6 billion, including public debt of $7.4 billion, which was determined primarily using market quotes and other long-term debt of $0.2 billion, which was determined based on quoted market prices for similar instruments.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0000833444-20-000015:notes:203]
[same as prior period, unchanged from 0000833444-20-000006:notes:191]

[0000833444-20-000015:notes:204]
The Company reviews long-lived assets, including right-of-use assets under operating leases, other tangible assets and intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of software to be sold, leased, or marketed."  ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 350-30 requires intangible assets acquired in a business combination that are used in research and development activities to be considered indefinite lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they shall not be amortized but shall be tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired.  If the carrying amount of an intangible asset exceeds its fair value, an entity shall recognize an impairment loss in an amount equal to that excess. ASC 985-20 requires the unamortized capitalized costs of a computer software product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off.

[0000833444-20-000015:notes:205]
[same as prior period, unchanged from 0000833444-20-000006:notes:194]

[0000833444-20-000015:notes:206]
[same as prior period, unchanged from 0000833444-20-000006:notes:195]

[0000833444-20-000015:notes:207]
At March 31, 2020 and 2019, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets.

[0000833444-20-000015:notes:208]
Refer to Note 8, "Goodwill and Other Intangible Assets," and Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for further information regarding the indefinite-lived intangibles impairment charges recorded in the second quarter of fiscal 2020.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-20-000015:notes:209]
[same as prior period, unchanged from 0000833444-20-000006:notes:197]

[0000833444-20-000015:notes:210]
[same as prior period, unchanged from 0000833444-20-000006:notes:198]

[0000833444-20-000015:notes:211]
[same as prior period, unchanged from 0000833444-20-000006:notes:199]

[0000833444-20-000015:notes:212]
[same as prior period, unchanged from 0000833444-20-000006:notes:200]

[0000833444-20-000015:notes:213]
[same as prior period, unchanged from 0000833444-20-000006:notes:201]

[0000833444-20-000015:notes:214]
[same as prior period, unchanged from 0000833444-20-000006:notes:202]

[0000833444-20-000015:notes:215]
[same as prior period, unchanged from 0000833444-20-000006:notes:203]

[0000833444-20-000015:notes:216]
[same as prior period, unchanged from 0000833444-20-000006:notes:204]

[0000833444-20-000015:notes:217]
|  | Net Sales |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Building Solutions North America | $ | 2,175 |  |  | $ | 2,187 |  |  | $ | 4,342 |  |  | $ | 4,303 |  |
| Building Solutions EMEA/LA | 850 |  |  | 878 |  |  | 1,778 |  |  | 1,785 |  |
| Building Solutions Asia Pacific | 525 |  |  | 628 |  |  | 1,154 |  |  | 1,241 |  |
| Global Products | 1,894 |  |  | 2,086 |  |  | 3,746 |  |  | 3,914 |  |
| Total net sales | $ | 5,444 |  |  | $ | 5,779 |  |  | $ | 11,020 |  |  | $ | 11,243 |  |

[0000833444-20-000015:notes:218]
|  | Segment EBITA |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Building Solutions North America | $ | 251 |  |  | $ | 257 |  |  | $ | 509 |  |  | $ | 507 |  |
| Building Solutions EMEA/LA | 85 |  |  | 80 |  |  | 175 |  |  | 157 |  |
| Building Solutions Asia Pacific | 65 |  |  | 76 |  |  | 137 |  |  | 142 |  |
| Global Products | 216 |  |  | 251 |  |  | 419 |  |  | 441 |  |
| Total segment EBITA | $ | 617 |  |  | $ | 664 |  |  | $ | 1,240 |  |  | $ | 1,247 |  |
| Corporate expenses | $ | (118 | ) |  | $ | (167 | ) |  | $ | (236 | ) |  | $ | (303 | ) |
| Amortization of intangible assets | (97 | ) |  | (98 | ) |  | (193 | ) |  | (195 | ) |
| Restructuring and impairment costs | (62 | ) |  | — |  |  | (173 | ) |  | — |  |
| Net mark-to-market adjustments | (32 | ) |  | 20 |  |  | (22 | ) |  | (1 | ) |
| Net financing charges | (59 | ) |  | (98 | ) |  | (111 | ) |  | (183 | ) |
| Income from continuing operations before income taxes | $ | 249 |  |  | $ | 321 |  |  | $ | 505 |  |  | $ | 565 |  |


## us-gaap:GuaranteesTextBlock

[0000833444-20-000015:notes:219]
[same as prior period, unchanged from 0000833444-20-000006:notes:207]

[0000833444-20-000015:notes:220]
[same as prior period, unchanged from 0000833444-20-000006:notes:208]

[0000833444-20-000015:notes:221]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate for future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-20-000015:notes:222]
[same as prior period, unchanged from 0000833444-20-000006:notes:211]

[0000833444-20-000015:notes:223]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations, including extended warranties for which deferred revenue is recorded, for the six months ended March 31, 2020 and 2019 were as follows (in millions):

[0000833444-20-000015:notes:224]
|  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |
| Balance at beginning of period | $ | 285 |  |  | $ | 315 |  |
| Accruals for warranties issued during the period | 49 |  |  | 48 |  |
| Accruals related to pre-existing warranties | (3 | ) |  | (9 | ) |
| Settlements made (in cash or in kind) during the period | (41 | ) |  | (51 | ) |
| Currency translation | (1 | ) |  | 1 |  |
| Balance at end of period | $ | 289 |  |  | $ | 304 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-20-000015:notes:225]
Commitments and Contingencies

[0000833444-20-000015:notes:226]
Environmental Matters

[0000833444-20-000015:notes:227]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of March 31, 2020, reserves for environmental liabilities for continuing operations totaled $143 million, of which $52 million was recorded within other current liabilities and $91 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $159 million at September 30, 2019, of which $52 million was recorded within other current liabilities and $107 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

[0000833444-20-000015:notes:228]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin.  In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.

[0000833444-20-000015:notes:229]
During the third quarter of 2019, the Company increased its environmental reserves which included $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).  The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.

[0000833444-20-000015:notes:230]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

[0000833444-20-000015:notes:231]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS.  The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion.  On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation.

[0000833444-20-000015:notes:232]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers.  Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter.  The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).”  The WDNR issued a further letter regarding the issue on November 4, 2019.  In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area.  Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations.  The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

[0000833444-20-000015:notes:233]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990.  Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River.  In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts.

[0000833444-20-000015:notes:234]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At March 31, 2020 and September 30, 2019, the Company recorded conditional asset retirement obligations for continuing operations of $30 million.

[0000833444-20-000015:notes:235]
Asbestos Matters

[0000833444-20-000015:notes:236]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-20-000015:notes:237]
As of March 31, 2020, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $165 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $498 million, of

[0000833444-20-000015:notes:238]
which $50 million was recorded in other current liabilities and $448 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $333 million, of which $62 million was recorded in other current assets, and $271 million was recorded in other noncurrent assets. Assets included $13 million of cash and $251 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at March 31, 2020 was $69 million. As of September 30, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $141 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $507 million, of which $50 million was recorded in other current liabilities and $457 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $366 million, of which $46 million was recorded in other current assets, and $320 million was recorded in other noncurrent assets. Assets included $16 million of cash and $273 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2019 was $77 million.

[0000833444-20-000015:notes:239]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-20-000015:notes:240]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-20-000015:notes:241]
Insurable Liabilities

[0000833444-20-000015:notes:242]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At March 31, 2020 and September 30, 2019, the insurable liabilities totaled $363 million and $379 million, respectively, of which $85 million and $99 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $256 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at March 31, 2020 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2019 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-20-000015:notes:243]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-20-000015:notes:244]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but has stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

[0000833444-20-000015:notes:245]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-20-000015:notes:246]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-20-000015:notes:247]
AFFF Putative Class Actions

[0000833444-20-000015:notes:248]
Chemguard and Tyco Fire Products are named in 27 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, and Michigan. All but one of these cases has been transferred to the MDL, and it is anticipated that the newly filed Stengel case will be transferred. The following putative class actions were filed since the beginning of fiscal year 2020:

[0000833444-20-000015:notes:249]
| • | Aguon et al. v. The 3M Company et al., filed October 3, 2019, in the United States District Court, District of Guam. |

[0000833444-20-000015:notes:250]
| • | County of Rockland [New York] et al. v. 3M Company et al., filed February 4, 2020, in the United States District Court, District of South Carolina. |

[0000833444-20-000015:notes:251]
| • | City of Millington et al. v. 3M Company et al., filed February 25, 2020, in the United States District Court, District of Columbia. |

[0000833444-20-000015:notes:252]
| • | Stengel et al. v. 3M Company et al., filed April 29, 2020, in the United States District Court for the Northern District of West Virginia. |

[0000833444-20-000015:notes:253]
AFFF Individual or Mass Actions

[0000833444-20-000015:notes:254]
There are approximately 585 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases), Pennsylvania (11 cases), New Mexico (2 cases) and South Carolina (527 cases direct filed from various U.S. jurisdictions) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania, two plaintiffs in New Mexico, and more than 500 plaintiffs from various states who direct-filed complaints in South Carolina.  These matters have been transferred to or directly-filed in the MDL.  Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court.  The Company anticipates that the remainder of the possible individual product liability claims filed in Pennsylvania state court will either soon be filed in the MDL (and that all such claims in state court will be dismissed accordingly) or will be dismissed in Pennsylvania without a corresponding filing in South Carolina.

[0000833444-20-000015:notes:255]
AFFF Municipal Cases

[0000833444-20-000015:notes:256]
Chemguard and Tyco Fire Products are also defendants in 38 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, California, Colorado, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio, Pennsylvania and several municipalities or water providers from various states who direct-filed complaints in South Carolina.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  The following municipal actions were filed since the beginning of fiscal year 2020:

[0000833444-20-000015:notes:257]
| • | California Water Service Co. v. The 3M Company et al., direct-filed on October 14, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-20-000015:notes:258]
| • | Town of Ayer v. The 3M Company et al., direct-filed on November 4, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-20-000015:notes:259]
| • | Town of Maysville v. The 3M Company et al., direct-filed on December 10, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-20-000015:notes:260]
| • | Town of Grantsville v. The 3M Company et al., filed November 26, 2019, in the United States District Court, District of Maryland. |

[0000833444-20-000015:notes:261]
| • | Town of Mountain Lake Park v. The 3M Company et al., filed November 26, 2019, in the United States District Court, District of Maryland. |

[0000833444-20-000015:notes:262]
| • | Sanford Airport Authority v. The 3M Company et al., filed November 19, 2019, in circuit court in Seminole County, Florida, and removed to the United States District Court, Middle District of Florida. It has been tagged for transfer to the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-20-000015:notes:263]
| • | South Adams County Water & Sanitation District v. The 3M Company et al., filed December 20, 2019, in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-20-000015:notes:264]
| • | Town of Southampton v. The 3M Company et al., filed December 17, 2019, in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-20-000015:notes:265]
| • | Fairbanks North Star Borough v. 3M Company, et al., filed January 31, 2020, in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-20-000015:notes:266]
| • | England Economic and Industrial Development District v. 3M Company et al., filed February 20, 2020, in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-20-000015:notes:267]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base.

[0000833444-20-000015:notes:268]
State or U.S. Territory Attorneys General Litigation related to AFFF

[0000833444-20-000015:notes:269]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-20-000015:notes:270]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-20-000015:notes:271]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752 -000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio.  The lawsuit seeks to recover costs and natural resource damages associated with the contamination.  This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-20-000015:notes:272]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

[0000833444-20-000015:notes:273]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

[0000833444-20-000015:notes:274]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Group, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

[0000833444-20-000015:notes:275]
AFFF Matters Related to the Tyco Fire Products Fire Technology Center in Marinette, Wisconsin

[0000833444-20-000015:notes:276]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.

[0000833444-20-000015:notes:277]
Other AFFF Matters

[0000833444-20-000015:notes:278]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington.  This case has been transferred to the MDL.

[0000833444-20-000015:notes:279]
The Company is vigorously defending the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

[0000833444-20-000015:notes:280]
Bosch Litigation

[0000833444-20-000015:notes:281]
On March 15, 2019, a German subsidiary of the Company received a complaint from Robert Bosch GmbH (“Bosch”), filed in a German court. The complaint relates to an automotive starter batteries joint venture in which the Company and Bosch were 80/20 parties to this joint venture. At the time the complaint was filed, JCI’s ownership interest in the joint venture was to be transferred to entities controlled by the Purchaser upon consummation of the previously announced sale of the Company’s Power Solutions business.

[0000833444-20-000015:notes:282]
The complaint alleged that certain internal Company reorganization transactions were not in compliance with the arrangements relating to such joint venture. The complaint sought a declaration that such internal reorganization transactions are void or, in the alternative, a declaration of damages that represent an alleged difference between (i) the value ascribed to the joint venture interests in connection with the Power Solutions sale and (ii) the value that was assigned to those interests in connection with such internal reorganization transactions.

[0000833444-20-000015:notes:283]
On August 8, 2019, Bosch entered into an agreement with Purchaser pursuant to which Purchaser would purchase Bosch’s interest in the joint venture.  Simultaneously with this agreement, the Company and Bosch executed an agreement to dismiss the proceedings between the parties upon the completion of Purchaser’s acquisition of Bosch’s interest. In the first quarter of fiscal 2020, following the completion of Purchaser’s acquisition of Bosch’s interest in the joint venture, the Company and Bosch made filings with the German court terminating the litigation.

[0000833444-20-000015:notes:284]
Pursuant to the Company’s obligations to Purchaser in connection with the divestiture of the Company’s Power Solutions business, the Company reimbursed Purchaser a portion of its costs in connection with its acquisition of Bosch’s interests in the joint venture, which is reflected as a cash outflow for discontinued operations.

[0000833444-20-000015:notes:285]
Other Matters

[0000833444-20-000015:notes:286]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-20-000015:notes:287]
Related Party Transactions

[0000833444-20-000015:notes:288]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-20-000015:notes:289]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $38 million and $10 million, respectively, for the three months ended March 31, 2020; and $54 million and $16 million, respectively, for the three months ended March 31, 2019. The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $83 million and $22 million, respectively, for the six months ended March 31, 2020; and $97 million and $30 million, respectively, for the six months ended March 31, 2019.

[0000833444-20-000015:notes:290]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position for continuing operations (in millions):

[0000833444-20-000015:notes:291]
|  |  | March 31, 2020 |  | September 30, 2019 |
| Receivable from related parties |  | $ | 37 |  |  | $ | 34 |  |
| Payable to related parties |  | 4 |  |  | 6 |  |
