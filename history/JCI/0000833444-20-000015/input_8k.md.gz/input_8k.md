# JCI 8-K — 0000833444-20-000013 filed 2020-05-01

## item codes, every 8-K on or before 2020-05-01

- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2020-05-01

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-20-000013:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq2f.htm
EXHIBIT 99.1

[0000833444-20-000013:8k_2_02:2]
Exhibit

[0000833444-20-000013:8k_2_02:3]
Exhibit 99.1

[0000833444-20-000013:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-20-000013:8k_2_02:5]
May 1, 2020

[0000833444-20-000013:8k_2_02:6]
JOHNSON CONTROLS REPORTS FISCAL Q2 RESULTS AND PROVIDES UPDATES RELATED TO THE IMPACT OF COVID-19

[0000833444-20-000013:8k_2_02:7]
________________________________________________________________________________

[0000833444-20-000013:8k_2_02:8]
| ▪ | Strong liquidity position enhanced with incremental $1.3 billion in term debt |

[0000833444-20-000013:8k_2_02:9]
| ▪ | Existing share repurchase program suspended until further notice |

[0000833444-20-000013:8k_2_02:10]
| ▪ | Quarterly dividend maintained |

[0000833444-20-000013:8k_2_02:11]
| ▪ | Previous fiscal year 2020 full-year guidance withdrawn; second half framework provided |

[0000833444-20-000013:8k_2_02:12]
| ▪ | Q2 GAAP EPS from continuing operations of $0.28, including special items |

[0000833444-20-000013:8k_2_02:13]
| ▪ | Adjusted EPS from continuing operations of $0.42, up 31% versus prior year |

[0000833444-20-000013:8k_2_02:14]
________________________________________________________________________________

[0000833444-20-000013:8k_2_02:15]
CORK, Ireland -- Johnson Controls International plc (NYSE: JCI) announced its fiscal second quarter results, including a set of immediate actions in response to the evolving conditions and unprecedented uncertainty related to the novel coronavirus (COVID-19) pandemic.

[0000833444-20-000013:8k_2_02:16]
“The health and wellness of our employees and their families will continue to be our priority. In an effort to protect our employees, including those on the front lines supporting customers and in all facilities, we have taken extra precautions to ensure this priority is met. I would like to thank each of our 105,000 employees for their continuous efforts in the battle against COVID-19, and for going the extra mile for our customers and stakeholders,” said George Oliver, chairman and CEO.

[0000833444-20-000013:8k_2_02:17]
“We have also taken decisive actions to control operating costs and further enhance our liquidity position. Given our strong balance sheet and the improved fundamentals built over the past two years, I believe we are in an excellent position to weather the economic uncertainty and capitalize on the recovery,” Oliver said. “Since the start of this crisis, our goal as a company has been twofold - first and foremost, to protect the health and safety of all of our employees and their families. Second, to work diligently with our customers and partners to ensure the continued functionality of critical infrastructure and essential facilities around the world. I am proud to say that our teams have exceled on both fronts.”

[0000833444-20-000013:8k_2_02:18]
“Our position as the leader in intelligent and sustainable building solutions enables Johnson Controls to deliver the outcomes that matter most to our customers. The depth and breadth of our product portfolio, combined with proven expertise and expansive global footprint provides us with a unique advantage as the evolution of the built environment accelerates,” Oliver added.

[0000833444-20-000013:8k_2_02:19]
Page 1 of 18

[0000833444-20-000013:8k_2_02:20]
Johnson Controls financial position remains strong, with access to liquidity including two senior revolving credit facilities - a one-year $500 million facility and a five-year $2.5 billion facility. Given the increasingly uncertain environment, the Company has taken proactive measures to increase near-term financial flexibility, electing to opportunistically raise $675 million via European financing arrangements and $575 million in bank term loans.  In addition, as planned the Company repaid with existing cash a $500 million bond that matured in March 2020.

[0000833444-20-000013:8k_2_02:21]
The Company reported fiscal second quarter 2020 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.28. Excluding these items, adjusted EPS from continuing operations was $0.42, up 31% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-20-000013:8k_2_02:22]
Sales of $5.4 billion decreased 6% compared to the prior year and declined 5% organically. This includes a 6 to 7 percentage point headwind related to the estimated impact of COVID-19.

[0000833444-20-000013:8k_2_02:23]
GAAP earnings before interest and taxes (“EBIT”) was $308 million and EBIT margin was 5.7%. Adjusted EBIT was $440 million and adjusted EBIT margin was 8.1%, in-line with prior year results. Adjusted EBIT was negatively impacted by approximately $80 to $100 million attributable to the estimated net impact of COVID-19.

[0000833444-20-000013:8k_2_02:24]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-20-000013:8k_2_02:25]
($ millions, except per-share amounts)

[0000833444-20-000013:8k_2_02:26]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal second quarter of 2019. The results of Power Solutions are reported as discontinued operations in all periods presented.

[0000833444-20-000013:8k_2_02:27]
Organic sales growth, organic EBITA growth, segment EBITA, adjusted segment EBITA, EBIT, adjusted EBIT, adjusted EPS from continuing operations and adjusted free cash flow are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes.  A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-20-000013:8k_2_02:28]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q2 2019 | Q2 2020 |  | Q2 2019 | Q2 2020 | Change |
| Sales | $5,779 | $5,444 |  | $5,779 | $5,444 | (6%) |
| Segment EBITA | 664 | 617 |  | 671 | 619 | (8%) |
| EBIT | 419 | 308 |  | 469 | 440 | (6%) |
| Net income from continuing operations | 240 | 213 |  | 287 | 317 | +10% |
| Diluted EPS from continuing operations | $0.26 | $0.28 |  | $0.32 | $0.42 | +31% |

[0000833444-20-000013:8k_2_02:29]
Page 2 of 18

[0000833444-20-000013:8k_2_02:30]
The adjusted results include the estimated net impact attributable to COVID-19 which is summarized below.

[0000833444-20-000013:8k_2_02:31]
| Sales | ($350 - 390M) |
| Segment EBITA | ($90 - 110M) |
| EBIT | ($80 - 100M) |
| Net income from continuing operations | ($49 - 62M) |
| Diluted EPS from continuing operations | ($0.05 - 0.07) |

[0000833444-20-000013:8k_2_02:32]
BUSINESS RESULTS

[0000833444-20-000013:8k_2_02:33]
Building Solutions North America

[0000833444-20-000013:8k_2_02:34]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q2 2019 | Q2 2020 |  | Q2 2019 | Q2 2020 | Change |
| Sales | $2,187 | $2,175 |  | $2,187 | $2,175 | (1%) |
| Segment EBITA | $257 | $251 |  | $259 | $253 | (2%) |
| Segment EBITA margin % | 11.8% | 11.5% |  | 11.8% | 11.6% | (20bps) |

[0000833444-20-000013:8k_2_02:35]
Sales in the quarter of $2.2 billion, decreased approximately 1% versus the prior year. Organic sales were flat versus the prior year. Growth in Performance Solutions was offset by a decline in Fire & Security and HVAC & Controls was consistent with the prior year.

[0000833444-20-000013:8k_2_02:36]
Orders in the quarter, excluding M&A and adjusted for foreign currency, decreased 7% year-over-year.  Backlog at the end of the quarter of $5.8 billion increased 4% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-20-000013:8k_2_02:37]
Adjusted segment EBITA was $253 million, down 2% versus the prior year. Adjusted segment EBITA margin of 11.6% declined 20 basis points versus the prior year as productivity savings and cost synergies, were more than offset by the volume decline.

[0000833444-20-000013:8k_2_02:38]
Page 3 of 18

[0000833444-20-000013:8k_2_02:39]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-20-000013:8k_2_02:40]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q2 2019 | Q2 2020 |  | Q2 2019 | Q2 2020 | Change |
| Sales | $878 | $850 |  | $878 | $850 | (3%) |
| Segment EBITA | $80 | $85 |  | $81 | $85 | 5% |
| Segment EBITA margin % | 9.1% | 10.0% |  | 9.2% | 10.0% | 80bps |

[0000833444-20-000013:8k_2_02:41]
Sales in the quarter of $850 million decreased 3% versus the prior year. Organic sales declined nearly 1% versus the prior year as growth in service was more than offset by a decline in project installations.  Growth in Industrial Refrigeration was more than offset by a decline in HVAC & Controls and Fire & Security.

[0000833444-20-000013:8k_2_02:42]
Orders in the quarter, excluding M&A and adjusted for foreign currency, decreased 4% year-over-year.  Backlog at the end of the quarter of $1.7 billion increased 6% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-20-000013:8k_2_02:43]
Adjusted segment EBITA was $85 million, up 5% versus the prior year. Adjusted segment EBITA margin of 10.0% expanded 80 basis points over the prior year, including a 30 basis point headwind related to foreign currency.  Adjusting for foreign currency, the underlying margin improved 110 basis points driven by the benefit from productivity savings and cost synergies.

[0000833444-20-000013:8k_2_02:44]
Building Solutions Asia Pacific

[0000833444-20-000013:8k_2_02:45]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q2 2019 | Q2 2020 |  | Q2 2019 | Q2 2020 | Change |
| Sales | $628 | $525 |  | $628 | $525 | (16%) |
| Segment EBITA | $76 | $65 |  | $76 | $65 | (15%) |
| Segment EBITA margin % | 12.1% | 12.4% |  | 12.1% | 12.4% | 30bps |

[0000833444-20-000013:8k_2_02:46]
Sales in the quarter of $525 million decreased 16% versus the prior year. Organic sales declined 14% versus the prior year primarily driven by a decline in project installations and, to a lesser extent, service.   The sharp decline in China was predominately within HVAC & Controls.

[0000833444-20-000013:8k_2_02:47]
Orders in the quarter, excluding M&A and adjusted for foreign currency, decreased 11% year-over-year.  Backlog at the end of the quarter of $1.5 billion increased 3% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-20-000013:8k_2_02:48]
Adjusted segment EBITA was $65 million, down 15% versus the prior year. Adjusted segment EBITA margin of 12.4% expanded 30 basis points over the prior year as favorable mix and the benefit of productivity savings and cost synergies more than offset the volume decline.

[0000833444-20-000013:8k_2_02:49]
Page 4 of 18

[0000833444-20-000013:8k_2_02:50]
Global Products

[0000833444-20-000013:8k_2_02:51]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q2 2019 | Q2 2020 |  | Q2 2019 | Q2 2020 | Change |
| Sales | $2,086 | $1,894 |  | $2,086 | $1,894 | (9%) |
| Segment EBITA | $251 | $216 |  | $255 | $216 | (15%) |
| Segment EBITA margin % | 12.0% | 11.4% |  | 12.2% | 11.4% | (80bps) |

[0000833444-20-000013:8k_2_02:52]
Sales in the quarter of $1.9 billion decreased 9% versus the prior year. Organic sales declined 8% versus the prior year.  Sales within Building Management Systems were consistent with the prior year while sales within HVAC & Refrigeration Equipment and Specialty Products declined versus the prior year.

[0000833444-20-000013:8k_2_02:53]
Adjusted segment EBITA was $216 million, down 15% versus the prior year. Adjusted segment EBITA margin of 11.4% contracted 80 basis points over the prior year as positive price/cost as well as the benefit of productivity savings and cost synergies was more than offset by the volume decline.

[0000833444-20-000013:8k_2_02:54]
Corporate

[0000833444-20-000013:8k_2_02:55]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q2 2019 | Q2 2020 |  | Q2 2019 | Q2 2020 | Change |
| Corporate expense | ($167) | ($118) |  | ($104) | ($82) | (21%) |

[0000833444-20-000013:8k_2_02:56]
Adjusted Corporate expense was $82 million in the quarter, a decrease of 21% compared to the prior year, driven primarily by continued productivity savings and cost synergies, COVID-19 mitigating actions, and cost reductions related to the Power Solutions sale.

[0000833444-20-000013:8k_2_02:57]
OTHER ITEMS

[0000833444-20-000013:8k_2_02:58]
| ▪ | Cash provided by operating activities from continuing operations was $0.2 billion and capital expenditures were $0.1 billion in the quarter, resulting in free cash flow from continuing operations of less than $0.1 billion. Adjusted free cash flow was $0.2 billion, which excludes net cash outflows of $0.1 billion primarily related to restructuring and integration costs. |

[0000833444-20-000013:8k_2_02:59]
| ▪ | During the quarter, the Company repurchased approximately 21 million shares for $816 million. The Company suspended its share repurchase program in mid-March. |

[0000833444-20-000013:8k_2_02:60]
| ▪ | During the quarter, the Company recorded a pre-tax impairment charge of $62 million related to indefinite lived intangible assets. |

[0000833444-20-000013:8k_2_02:61]
| ▪ | During the quarter, the Company repaid a $500 million bond which matured in March 2020. |

[0000833444-20-000013:8k_2_02:62]
Page 5 of 18

[0000833444-20-000013:8k_2_02:63]
| ▪ | In April, the Company raised $675 million via European financing arrangements, with an average interest rate of 1.0% and a 6-month term. |

[0000833444-20-000013:8k_2_02:64]
| ▪ | In April, the Company raised $575 million in bank term loans, with an average interest rate of 2.7% and a 1-year term. |

[0000833444-20-000013:8k_2_02:65]
SECOND HALF FRAMEWORK

[0000833444-20-000013:8k_2_02:66]
As a result of the challenging and uncertain macro environment attributable to the impact of COVID-19, the Company is withdrawing its previously communicated fiscal year 2020 guidance and has provided the below framework related to the second half of the fiscal year.

[0000833444-20-000013:8k_2_02:67]
Organic Revenue Decline        (15 - 20%)

[0000833444-20-000013:8k_2_02:68]
Mitigating Cost Actions            $400 - 450M

[0000833444-20-000013:8k_2_02:69]
Net Decrementals on Revenue        Low 20s

[0000833444-20-000013:8k_2_02:70]
JOHNSON CONTROLS CONTACTS:

[0000833444-20-000013:8k_2_02:71]
| INVESTORS: | MEDIA: |
| Antonella Franzen | Phil Clement |
| Direct: 609.720.4665 | Direct: 414.208.5161 |
| Email: antonella.franzen@jci.com | Email: phil.clement@jci.com |
| Ryan Edelman | Fraser Engerman |
| Direct: 609.720.4545 | Direct: 414.308.8321 |
| Email: ryan.edelman@jci.com | Email: fraser.engerman@jci.com |

[0000833444-20-000013:8k_2_02:72]
###

[0000833444-20-000013:8k_2_02:73]
About Johnson Controls:

[0000833444-20-000013:8k_2_02:74]
At Johnson Controls, we transform the environments where people live, work, learn and play. From optimizing building performance to improving safety and enhancing comfort, we drive the outcomes that matter most. We deliver our promise in industries such as healthcare, education, data centers, and manufacturing. With a global team of 105,000 experts in more than 150 countries and over 130 years of innovation, we are the power behind our customers’ mission. Our leading portfolio of building technology and solutions includes some of the most trusted names in the industry, such as Tyco®, YORK®, Metasys®, Ruskin®, Titus®, Frick®, PENN®, Sabroe®, Simplex®, Ansul® and Grinnell®. For more information, visit www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter

[0000833444-20-000013:8k_2_02:75]
Page 6 of 18

[0000833444-20-000013:8k_2_02:76]
###

[0000833444-20-000013:8k_2_02:77]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-20-000013:8k_2_02:78]
###

[0000833444-20-000013:8k_2_02:79]
Page 7 of 18

[0000833444-20-000013:8k_2_02:80]
Non-GAAP Financial Information

[0000833444-20-000013:8k_2_02:81]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include restructuring and impairment costs, transaction costs, integration costs, net mark-to-market adjustments, and discrete tax items. Financial information regarding organic sales, EBIT, EBIT margin, segment EBITA, adjusted segment EBITA, adjusted organic segment EBITA, adjusted segment EBITA margin, free cash flow and adjusted free cash flow, are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as transaction costs and integration costs because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.  For further information on the calculation of thee non-GAAP measures and a reconciliation of these non-GAAP measures, refer to the attached footnotes.

[0000833444-20-000013:8k_2_02:82]
###

[0000833444-20-000013:8k_2_02:83]
Page 8 of 18

[0000833444-20-000013:8k_2_02:84]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Three Months Ended March 31, |
|  |  | 2020 |  |  | 2019 |
| Net sales | $ | 5,444 |  |  |  | $ | 5,779 |  |
| Cost of sales | 3,643 |  |  |  | 3,935 |  |
|  | Gross profit | 1,801 |  |  |  | 1,844 |  |
| Selling, general and administrative expenses | (1,451 | ) |  |  | (1,458 | ) |
| Restructuring and impairment costs | (62 | ) |  |  | — |  |
| Net financing charges | (59 | ) |  |  | (98 | ) |
| Equity income | 20 |  |  |  | 33 |  |
| Income from continuing operations before income taxes | 249 |  |  |  | 321 |  |
| Income tax provision | 13 |  |  |  | 47 |  |
| Income from continuing operations | 236 |  |  |  | 274 |  |
| Income from discontinued operations, net of tax | — |  |  |  | 284 |  |
| Net income | 236 |  |  |  | 558 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 23 |  |  |  | 34 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 9 |  |
| Net income attributable to JCI | $ | 213 |  |  |  | $ | 515 |  |
| Income from continuing operations | $ | 213 |  |  |  | $ | 240 |  |
| Income from discontinued operations | — |  |  |  | 275 |  |
| Net income attributable to JCI | $ | 213 |  |  |  | $ | 515 |  |
| Diluted earnings per share from continuing operations | $ | 0.28 |  |  |  | $ | 0.26 |  |
| Diluted earnings per share from discontinued operations | — |  |  |  | 0.30 |  |
| Diluted earnings per share * | $ | 0.28 |  |  |  | $ | 0.57 |  |
| Diluted weighted average shares | 757.1 |  |  |  | 905.9 |  |
| Shares outstanding at period end | 743.9 |  |  |  | 898.1 |  |

[0000833444-20-000013:8k_2_02:85]
* May not sum due to rounding.

[0000833444-20-000013:8k_2_02:86]
Page 9 of 18

[0000833444-20-000013:8k_2_02:87]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Six Months Ended March 31, |
|  |  | 2020 |  |  | 2019 |
| Net sales | $ | 11,020 |  |  |  | $ | 11,243 |  |
| Cost of sales | 7,416 |  |  |  | 7,674 |  |
|  | Gross profit | 3,604 |  |  |  | 3,569 |  |
| Selling, general and administrative expenses | (2,878 | ) |  |  | (2,896 | ) |
| Restructuring and impairment costs | (173 | ) |  |  | — |  |
| Net financing charges | (111 | ) |  |  | (183 | ) |
| Equity income | 63 |  |  |  | 75 |  |
| Income from continuing operations before income taxes | 505 |  |  |  | 565 |  |
| Income tax provision | 78 |  |  |  | 155 |  |
| Income from continuing operations | 427 |  |  |  | 410 |  |
| Income from discontinued operations, net of tax | — |  |  |  | 547 |  |
| Net income | 427 |  |  |  | 957 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 55 |  |  |  | 63 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 24 |  |
| Net income attributable to JCI | $ | 372 |  |  |  | $ | 870 |  |
| Income from continuing operations | $ | 372 |  |  |  | $ | 347 |  |
| Income from discontinued operations | — |  |  |  | 523 |  |
| Net income attributable to JCI | $ | 372 |  |  |  | $ | 870 |  |
| Diluted earnings per share from continuing operations | $ | 0.49 |  |  |  | $ | 0.38 |  |
| Diluted earnings per share from discontinued operations | — |  |  |  | 0.57 |  |
| Diluted earnings per share | $ | 0.49 |  |  |  | $ | 0.95 |  |
| Diluted weighted average shares | 765.6 |  |  |  | 915.6 |  |
| Shares outstanding at period end | 743.9 |  |  |  | 898.1 |  |

[0000833444-20-000013:8k_2_02:88]
Page 10 of 18

[0000833444-20-000013:8k_2_02:89]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | March 31,2020 |  | September 30,2019 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 1,006 |  |  | $ | 2,805 |  |
| Accounts receivable - net | 5,492 |  |  | 5,770 |  |
| Inventories | 2,030 |  |  | 1,814 |  |
| Assets held for sale | 91 |  |  | 98 |  |
| Other current assets | 1,336 |  |  | 1,906 |  |
|  | Current assets | 9,955 |  |  | 12,393 |  |
| Property, plant and equipment - net | 3,274 |  |  | 3,348 |  |
| Goodwill | 18,072 |  |  | 18,178 |  |
| Other intangible assets - net | 5,391 |  |  | 5,632 |  |
| Investments in partially-owned affiliates | 869 |  |  | 853 |  |
| Noncurrent assets held for sale | 46 |  |  | 60 |  |
| Other noncurrent assets | 2,795 |  |  | 1,823 |  |
|  | Total assets | $ | 40,402 |  |  | $ | 42,287 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 1,430 |  |  | $ | 511 |  |
| Accounts payable and accrued expenses | 3,813 |  |  | 4,535 |  |
| Liabilities held for sale | 39 |  |  | 44 |  |
| Other current liabilities | 4,227 |  |  | 3,980 |  |
|  | Current liabilities | 9,509 |  |  | 9,070 |  |
| Long-term debt | 5,640 |  |  | 6,708 |  |
| Other noncurrent liabilities | 6,165 |  |  | 5,680 |  |
| Shareholders' equity attributable to JCI | 18,084 |  |  | 19,766 |  |
| Noncontrolling interests | 1,004 |  |  | 1,063 |  |
|  | Total liabilities and equity | $ | 40,402 |  |  | $ | 42,287 |  |

[0000833444-20-000013:8k_2_02:90]
Page 11 of 18

[0000833444-20-000013:8k_2_02:91]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended March 31, |
|  |  |  |  |  |  | 2020 |  |  | 2019 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI from continuing operations | $ | 213 |  |  |  | $ | 240 |  |
| Income from continuing operations attributable to noncontrolling interests | 23 |  |  |  | 34 |  |
| Net income from continuing operations | 236 |  |  |  | 274 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 207 |  |  |  | 211 |  |
|  |  | Pension and postretirement benefit income | (40 | ) |  |  | (28 | ) |
|  |  | Pension and postretirement contributions | (15 | ) |  |  | (16 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (19 | ) |  |  | (31 | ) |
|  |  | Deferred income taxes | (58 | ) |  |  | 460 |  |
|  |  | Non-cash restructuring and impairment costs | 62 |  |  |  | — |  |
|  |  | Other - net | 40 |  |  |  | 5 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | 7 |  |  |  | (285 | ) |
|  |  |  |  | Inventories | (147 | ) |  |  | (99 | ) |
|  |  |  |  | Other assets | (58 | ) |  |  | 34 |  |
|  |  |  |  | Restructuring reserves | (71 | ) |  |  | (34 | ) |
|  |  |  |  | Accounts payable and accrued liabilities | (107 | ) |  |  | 209 |  |
|  |  |  |  | Accrued income taxes | 118 |  |  |  | (518 | ) |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 155 |  |  |  | 182 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (124 | ) |  |  | (125 | ) |
| Acquisition of businesses, net of cash acquired | (10 | ) |  |  | — |  |
| Other - net | 19 |  |  |  | 2 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (115 | ) |  |  | (123 | ) |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | (177 | ) |  |  | 530 |  |
| Stock repurchases | (816 | ) |  |  | (533 | ) |
| Payment of cash dividends | (199 | ) |  |  | (239 | ) |
| Dividends paid to noncontrolling interests | — |  |  |  | (89 | ) |
| Proceeds from the exercise of stock options | 18 |  |  |  | 38 |  |
| Employee equity-based compensation withholding | (12 | ) |  |  | (2 | ) |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (1,186 | ) |  |  | (295 | ) |
| Discontinued Operations |  |  |  |  |
| Net cash provided (used) by operating activities | (14 | ) |  |  | 309 |  |
| Net cash used by investing activities | — |  |  |  | (87 | ) |
| Net cash used by financing activities | — |  |  |  | (17 | ) |
|  |  |  |  |  | Net cash flows provided (used) by discontinued operations | (14 | ) |  |  | 205 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 7 |  |  |  | 5 |  |
| Changes in cash held for sale | — |  |  |  | (28 | ) |
| Decrease in cash, cash equivalents and restricted cash | $ | (1,153 | ) |  |  | $ | (54 | ) |

[0000833444-20-000013:8k_2_02:92]
Page 12 of 18

[0000833444-20-000013:8k_2_02:93]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Six Months Ended March 31, |
|  |  |  |  |  |  | 2020 |  |  | 2019 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI from continuing operations | $ | 372 |  |  |  | $ | 347 |  |
| Income from continuing operations attributable to noncontrolling interests | 55 |  |  |  | 63 |  |
| Net income from continuing operations | 427 |  |  |  | 410 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 414 |  |  |  | 422 |  |
|  |  | Pension and postretirement benefit income | (80 | ) |  |  | (57 | ) |
|  |  | Pension and postretirement contributions | (27 | ) |  |  | (37 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (11 | ) |  |  | (67 | ) |
|  |  | Deferred income taxes | (61 | ) |  |  | 503 |  |
|  |  | Non-cash restructuring and impairment costs | 116 |  |  |  | — |  |
|  |  | Other - net | 56 |  |  |  | 33 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | 244 |  |  |  | (139 | ) |
|  |  |  |  | Inventories | (261 | ) |  |  | (321 | ) |
|  |  |  |  | Other assets | (150 | ) |  |  | (29 | ) |
|  |  |  |  | Restructuring reserves | (38 | ) |  |  | (59 | ) |
|  |  |  |  | Accounts payable and accrued liabilities | (605 | ) |  |  | (17 | ) |
|  |  |  |  | Accrued income taxes | 642 |  |  |  | (539 | ) |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 666 |  |  |  | 103 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (250 | ) |  |  | (278 | ) |
| Acquisition of businesses, net of cash acquired | (58 | ) |  |  | (13 | ) |
| Business divestitures, net of cash divested | — |  |  |  | 6 |  |
| Other - net | 20 |  |  |  | 26 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (288 | ) |  |  | (259 | ) |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | (167 | ) |  |  | 1,544 |  |
| Stock repurchases | (1,467 | ) |  |  | (1,000 | ) |
| Payment of cash dividends | (402 | ) |  |  | (479 | ) |
| Proceeds from the exercise of stock options | 39 |  |  |  | 51 |  |
| Dividends paid to noncontrolling interests | (5 | ) |  |  | (132 | ) |
| Employee equity-based compensation withholding | (32 | ) |  |  | (23 | ) |
| Other - net | (2 | ) |  |  | — |  |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (2,036 | ) |  |  | (39 | ) |
| Discontinued Operations |  |  |  |  |
| Net cash provided (used) by operating activities | (208 | ) |  |  | 502 |  |
| Net cash used by investing activities | — |  |  |  | (153 | ) |
| Net cash used by financing activities | — |  |  |  | (28 | ) |
|  |  |  |  |  | Net cash flows provided (used) by discontinued operations | (208 | ) |  |  | 321 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 64 |  |  |  | (38 | ) |
| Changes in cash held for sale | — |  |  |  | (30 | ) |
| Increase (decrease) in cash, cash equivalents and restricted cash | $ | (1,802 | ) |  |  | $ | 58 |  |

[0000833444-20-000013:8k_2_02:94]
Page 13 of 18

[0000833444-20-000013:8k_2_02:95]
FOOTNOTES

[0000833444-20-000013:8k_2_02:96]
1. Financial Summary

[0000833444-20-000013:8k_2_02:97]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans. The financial results shown below are for continuing operations and exclude the Power Solutions business.

[0000833444-20-000013:8k_2_02:98]
| (in millions; unaudited) | Three Months Ended March 31, |
|  | 2020 |  | 2019 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,175 |  |  | $ | 2,175 |  |  | $ | 2,187 |  |  | $ | 2,187 |  |
| Building Solutions EMEA/LA | 850 |  |  | 850 |  |  | 878 |  |  | 878 |  |
| Building Solutions Asia Pacific | 525 |  |  | 525 |  |  | 628 |  |  | 628 |  |
| Global Products | 1,894 |  |  | 1,894 |  |  | 2,086 |  |  | 2,086 |  |
| Net sales | $ | 5,444 |  |  | $ | 5,444 |  |  | $ | 5,779 |  |  | $ | 5,779 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 251 |  |  | $ | 253 |  |  | $ | 257 |  |  | $ | 259 |  |
| Building Solutions EMEA/LA | 85 |  |  | 85 |  |  | 80 |  |  | 81 |  |
| Building Solutions Asia Pacific | 65 |  |  | 65 |  |  | 76 |  |  | 76 |  |
| Global Products | 216 |  |  | 216 |  |  | 251 |  |  | 255 |  |
| Segment EBITA | 617 |  |  | 619 |  |  | 664 |  |  | 671 |  |
| Corporate expenses (2) | (118 | ) |  | (82 | ) |  | (167 | ) |  | (104 | ) |
| Amortization of intangible assets | (97 | ) |  | (97 | ) |  | (98 | ) |  | (98 | ) |
| Net mark-to-market adjustments (3) | (32 | ) |  | — |  |  | 20 |  |  | — |  |
| Restructuring and impairment costs (4) | (62 | ) |  | — |  |  | — |  |  | — |  |
| EBIT (5) | 308 |  |  | 440 |  |  | 419 |  |  | 469 |  |
| EBIT margin | 5.7 | % |  | 8.1 | % |  | 7.3 | % |  | 8.1 | % |
| Net financing charges | (59 | ) |  | (59 | ) |  | (98 | ) |  | (98 | ) |
| Income from continuing operations before income taxes | 249 |  |  | 381 |  |  | 321 |  |  | 371 |  |
| Income tax provision (6) | (13 | ) |  | (52 | ) |  | (47 | ) |  | (50 | ) |
| Income from continuing operations | 236 |  |  | 329 |  |  | 274 |  |  | 321 |  |
| Income from continuing operations attributable to noncontrolling interests | (23 | ) |  | (12 | ) |  | (34 | ) |  | (34 | ) |
| Net income from continuing operations attributable to JCI | $ | 213 |  |  | $ | 317 |  |  | $ | 240 |  |  | $ | 287 |  |

[0000833444-20-000013:8k_2_02:99]
| (in millions; unaudited) | Six Months Ended March 31, |
|  | 2020 |  | 2019 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 4,342 |  |  | $ | 4,342 |  |  | $ | 4,303 |  |  | $ | 4,303 |  |
| Building Solutions EMEA/LA | 1,778 |  |  | 1,778 |  |  | 1,785 |  |  | 1,785 |  |
| Building Solutions Asia Pacific | 1,154 |  |  | 1,154 |  |  | 1,241 |  |  | 1,241 |  |
| Global Products | 3,746 |  |  | 3,746 |  |  | 3,914 |  |  | 3,914 |  |
| Net sales | $ | 11,020 |  |  | $ | 11,020 |  |  | $ | 11,243 |  |  | $ | 11,243 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 509 |  |  | $ | 512 |  |  | $ | 507 |  |  | $ | 512 |  |
| Building Solutions EMEA/LA | 175 |  |  | 175 |  |  | 157 |  |  | 158 |  |
| Building Solutions Asia Pacific | 137 |  |  | 137 |  |  | 142 |  |  | 142 |  |
| Global Products | 419 |  |  | 420 |  |  | 441 |  |  | 449 |  |
| Segment EBITA | 1,240 |  |  | 1,244 |  |  | 1,247 |  |  | 1,261 |  |
| Corporate expenses (2) | (236 | ) |  | (163 | ) |  | (303 | ) |  | (197 | ) |
| Amortization of intangible assets | (193 | ) |  | (193 | ) |  | (195 | ) |  | (195 | ) |
| Net mark-to-market adjustments (3) | (22 | ) |  | — |  |  | (1 | ) |  | — |  |
| Restructuring and impairment costs (4) | (173 | ) |  | — |  |  | — |  |  | — |  |
| EBIT (5) | 616 |  |  | 888 |  |  | 748 |  |  | 869 |  |
| EBIT margin | 5.6 | % |  | 8.1 | % |  | 6.7 | % |  | 7.7 | % |
| Net financing charges | (111 | ) |  | (111 | ) |  | (183 | ) |  | (183 | ) |
| Income from continuing operations before income taxes | 505 |  |  | 777 |  |  | 565 |  |  | 686 |  |
| Income tax provision (6) | (78 | ) |  | (105 | ) |  | (155 | ) |  | (93 | ) |
| Income from continuing operations | 427 |  |  | 672 |  |  | 410 |  |  | 593 |  |
| Income from continuing operations attributable to noncontrolling interests | (55 | ) |  | (49 | ) |  | (63 | ) |  | (63 | ) |
| Net income from continuing operations attributable to JCI | $ | 372 |  |  | $ | 623 |  |  | $ | 347 |  |  | $ | 530 |  |

[0000833444-20-000013:8k_2_02:100]
(1) The Company's press release contains financial information regarding segment EBITA, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-20-000013:8k_2_02:101]
A reconciliation of segment EBITA to income from continuing operations is shown earler within this footnote. The following is the three months ended March 31, 2020 and 2019 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-20-000013:8k_2_02:102]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Segment EBITA as reported | $ | 251 |  |  | $ | 257 |  |  | $ | 85 |  |  | $ | 80 |  |  | $ | 65 |  |  | $ | 76 |  |  | $ | 216 |  |  | $ | 251 |  |  | $ | 617 |  |  | $ | 664 |  |
| Segment EBITA margin as reported | 11.5 | % |  | 11.8 | % |  | 10.0 | % |  | 9.1 | % |  | 12.4 | % |  | 12.1 | % |  | 11.4 | % |  | 12.0 | % |  | 11.3 | % |  | 11.5 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | 2 |  |  | 2 |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | 2 |  |  | 7 |  |
| Adjusted segment EBITA | $ | 253 |  |  | $ | 259 |  |  | $ | 85 |  |  | $ | 81 |  |  | $ | 65 |  |  | $ | 76 |  |  | $ | 216 |  |  | $ | 255 |  |  | $ | 619 |  |  | $ | 671 |  |
| Adjusted segment EBITA margin | 11.6 | % |  | 11.8 | % |  | 10.0 | % |  | 9.2 | % |  | 12.4 | % |  | 12.1 | % |  | 11.4 | % |  | 12.2 | % |  | 11.4 | % |  | 11.6 | % |

[0000833444-20-000013:8k_2_02:103]
Page 14 of 18

[0000833444-20-000013:8k_2_02:104]
The following is the six months ended March 31, 2020 and 2019 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-20-000013:8k_2_02:105]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Segment EBITA as reported | $ | 509 |  |  | $ | 507 |  |  | $ | 175 |  |  | $ | 157 |  |  | $ | 137 |  |  | $ | 142 |  |  | $ | 419 |  |  | $ | 441 |  |  | $ | 1,240 |  |  | $ | 1,247 |  |
| Segment EBITA margin as reported | 11.7 | % |  | 11.8 | % |  | 9.8 | % |  | 8.8 | % |  | 11.9 | % |  | 11.4 | % |  | 11.2 | % |  | 11.3 | % |  | 11.3 | % |  | 11.1 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | 3 |  |  | 5 |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |  | 8 |  |  | 4 |  |  | 14 |  |
| Adjusted segment EBITA | $ | 512 |  |  | $ | 512 |  |  | $ | 175 |  |  | $ | 158 |  |  | $ | 137 |  |  | $ | 142 |  |  | $ | 420 |  |  | $ | 449 |  |  | $ | 1,244 |  |  | $ | 1,261 |  |
| Adjusted segment EBITA margin | 11.8 | % |  | 11.9 | % |  | 9.8 | % |  | 8.9 | % |  | 11.9 | % |  | 11.4 | % |  | 11.2 | % |  | 11.5 | % |  | 11.3 | % |  | 11.2 | % |

[0000833444-20-000013:8k_2_02:106]
(2) Adjusted Corporate expenses excludes special items because these costs are not considered to be directly related to the underlying operating performance of the Company's business. Adjusted Corporate expenses for the three months ended March 31, 2020 excludes $36 million of integration costs. Adjusted Corporate expenses for the six months ended March 31, 2020 excludes $73 million of integration costs. Adjusted Corporate expenses for the three months ended March 31, 2019 excludes $61 million of integration costs and $2 million of transaction costs. Adjusted Corporate expenses for the six months ended March 31, 2019 excludes $102 million of integration costs and $4 million of transaction costs.

[0000833444-20-000013:8k_2_02:107]
(3) The three months ended March 31, 2020 exclude the net mark-to-market adjustments on restricted investments of $32 million. The six months ended March 31, 2020 exclude the net mark-to-market adjustments on restricted investments of $22 million. The three months ended March 31, 2019 exclude the net mark-to-market adjustments on restricted investments of $20 million. The six months ended March 31, 2019 exclude the net mark-to-market adjustments on restricted investments of $1 million.

[0000833444-20-000013:8k_2_02:108]
(4) Restructuring and impairment costs for the three months ended March 31, 2020 of $62 million are excluded from the adjusted non-GAAP results. Restructuring and impairment costs for the six months ended March 31, 2020 of $173 million are excluded from the adjusted non-GAAP results. The restructuring actions and impairment costs related primarily to workforce reductions, plant closures and asset impairments.

[0000833444-20-000013:8k_2_02:109]
(5) Management defines earnings before interest and taxes (EBIT) as income from continuing operations before net financing charges, income taxes and noncontrolling interests. EBIT is a non-GAAP performance measure. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company. A reconciliation of EBIT to income from continuing operations is shown earlier within this footnote.

[0000833444-20-000013:8k_2_02:110]
(6) Adjusted income tax provision for the three months ended March 31, 2020 excludes tax benefits from tax audit reserve adjustments of $22 million, net mark-to-market adjustments of $7 million, integration costs of $6 million, and restructuring and impairment costs of $4 million. Adjusted income tax provision for the six months ended March 31, 2020 excludes tax benefits from tax audit reserve adjustments of $22 million, restructuring and impairment costs of $20 million, integration costs of $11 million and net mark-to-market adjustments of $4 million, partially offset by tax provisions related to Switzerland tax reform of $30 million. Adjusted income tax provision for the three months ended March 31, 2019 excludes the tax benefits of integration costs of $7 million and transaction costs of $1 million, partially offset by the tax provision for net mark-to-market adjustments of $5 million. Adjusted income tax provision for the six months ended March 31, 2019 excludes the tax provision for valuation allowance adjustments of $76 million as a result of changes in U.S. tax law, partially offset by the tax benefits for integration costs of $13 million and transaction costs of $1 million.

[0000833444-20-000013:8k_2_02:111]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-20-000013:8k_2_02:112]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include transaction/integration costs, net mark-to-market adjustments, restructuring and impairment costs, impact of ceasing the depreciation and amortization expense for the Power Solutions business as the business is held for sale, and discrete tax items. The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-20-000013:8k_2_02:113]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-20-000013:8k_2_02:114]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc from Continuing Operations |  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc from Continuing Operations |
|  | Three Months Ended |  | Three Months Ended |  | Six Months Ended |  | Six Months Ended |
|  | March 31, |  | March 31, |  | March 31, |  | March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Earnings per share as reported for JCI plc | $ | 0.28 |  |  | $ | 0.57 |  |  | $ | 0.28 |  |  | $ | 0.26 |  |  | $ | 0.49 |  |  | $ | 0.95 |  |  | $ | 0.49 |  |  | $ | 0.38 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 0.02 |  |  | — |  |  | — |  |  | — |  |  | 0.05 |  |  | — |  |  | — |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (0.01 | ) |  | — |  |  | — |  |
| Integration costs | 0.05 |  |  | 0.08 |  |  | 0.05 |  |  | 0.08 |  |  | 0.10 |  |  | 0.13 |  |  | 0.10 |  |  | 0.13 |  |
| Related tax impact | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |
| Net mark-to-market adjustments | 0.04 |  |  | (0.02 | ) |  | 0.04 |  |  | (0.02 | ) |  | 0.03 |  |  | — |  |  | 0.03 |  |  | — |  |
| Related tax impact | (0.01 | ) |  | 0.01 |  |  | (0.01 | ) |  | 0.01 |  |  | (0.01 | ) |  | — |  |  | (0.01 | ) |  | — |  |
| Restructuring and impairment costs | 0.08 |  |  | — |  |  | 0.08 |  |  | — |  |  | 0.23 |  |  | — |  |  | 0.23 |  |  | — |  |
| Related tax impact | (0.01 | ) |  | — |  |  | (0.01 | ) |  | — |  |  | (0.03 | ) |  | — |  |  | (0.03 | ) |  | — |  |
| NCI impact of restructuring and impairment | — |  |  | — |  |  | — |  |  | — |  |  | (0.01 | ) |  | — |  |  | (0.01 | ) |  | — |  |
| Cease of Power Solutions |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| depreciation / amortization expense | — |  |  | (0.07 | ) |  | — |  |  | — |  |  | — |  |  | (0.10 | ) |  | — |  |  | — |  |
| Related tax impact | — |  |  | 0.02 |  |  | — |  |  | — |  |  | — |  |  | 0.03 |  |  | — |  |  | — |  |
| Discrete tax items | (0.03 | ) |  | — |  |  | (0.03 | ) |  | — |  |  | 0.01 |  |  | 0.16 |  |  | 0.01 |  |  | 0.08 |  |
| NCI impact of discrete tax items | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Adjusted earnings per share for JCI plc* | $ | 0.42 |  |  | $ | 0.59 |  |  | $ | 0.42 |  |  | $ | 0.32 |  |  | $ | 0.81 |  |  | $ | 1.20 |  |  | $ | 0.81 |  |  | $ | 0.58 |  |

[0000833444-20-000013:8k_2_02:115]
* May not sum due to rounding.

[0000833444-20-000013:8k_2_02:116]
Page 15 of 18

[0000833444-20-000013:8k_2_02:117]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-20-000013:8k_2_02:118]
|  | Three Months Ended |  | Six Months Ended |
|  | March 31, |  | March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 754.8 |  |  | 902.5 |  |  | 762.4 |  |  | 912.1 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |
| and unvested performance share awards | 2.3 |  |  | 3.4 |  |  | 3.2 |  |  | 3.5 |  |
| Diluted weighted average shares outstanding | 757.1 |  |  | 905.9 |  |  | 765.6 |  |  | 915.6 |  |

[0000833444-20-000013:8k_2_02:119]
The Company has presented forward-looking statements regarding organic net sales, net decrementals and adjusted free cash flow conversion, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, income or cash flows from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments and the effect of foreign currency exchange fluctuations. Our fiscal 2020 framework for organic net sales also excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s full year 2020 GAAP financial results.

[0000833444-20-000013:8k_2_02:120]
3. Organic Growth Reconciliation

[0000833444-20-000013:8k_2_02:121]
The components of the changes in net sales for the three months ended March 31, 2020 versus the three months ended March 31, 2019, including organic growth, is shown below (unaudited):

[0000833444-20-000013:8k_2_02:122]
| (in millions) | Net Sales for the Three Months Ended March 31, 2019 |  | Base Year Adjustments - Divestitures and Other |  | Adjusted Base Net Sales for the Three Months Ended March 31, 2019 |  | Acquisitions |  | Foreign Currency |  | Organic Growth |  | Net Sales for the Three Months EndedMarch 31, 2020 |
| Building Solutions North America | $ | 2,187 |  |  | $ | — |  |  | — |  |  | $ | 2,187 |  |  | $ | — |  |  | — |  |  | $ | (2 | ) |  | — |  |  | $ | (10 | ) |  | — |  |  | $ | 2,175 |  |  | -1 | % |
| Building Solutions EMEA/LA | 878 |  |  | 2 |  |  | — |  |  | 880 |  |  | 10 |  |  | 1 | % |  | (33 | ) |  | -4 | % |  | (7 | ) |  | -1 | % |  | 850 |  |  | -3 | % |
| Building Solutions Asia Pacific | 628 |  |  | — |  |  | — |  |  | 628 |  |  | 2 |  |  | — |  |  | (15 | ) |  | -2 | % |  | (90 | ) |  | -14 | % |  | 525 |  |  | -16 | % |
| Total field | 3,693 |  |  | 2 |  |  | — |  |  | 3,695 |  |  | 12 |  |  | — |  |  | (50 | ) |  | -1 | % |  | (107 | ) |  | -3 | % |  | 3,550 |  |  | -4 | % |
| Global Products | 2,086 |  |  | (7 | ) |  | — |  |  | 2,079 |  |  | 2 |  |  | — |  |  | (13 | ) |  | -1 | % |  | (174 | ) |  | -8 | % |  | 1,894 |  |  | -9 | % |
| Total net sales | $ | 5,779 |  |  | $ | (5 | ) |  | — |  |  | $ | 5,774 |  |  | $ | 14 |  |  | — |  |  | $ | (63 | ) |  | -1 | % |  | $ | (281 | ) |  | -5 | % |  | $ | 5,444 |  |  | -6 | % |

[0000833444-20-000013:8k_2_02:123]
The components of the changes in net sales for the six months ended March 31, 2020 versus the six months ended March 31, 2019, including organic growth, is shown below (unaudited):

[0000833444-20-000013:8k_2_02:124]
| (in millions) | Net Sales for the Six Months Ended March 31, 2019 |  | Base Year Adjustments - Divestitures and Other |  | Adjusted Base Net Sales for the Six Months Ended March 31, 2019 |  | Acquisitions |  | Foreign Currency |  | Organic Growth |  | Net Sales for the Six Months EndedMarch 31, 2020 |
| Building Solutions North America | $ | 4,303 |  |  | $ | (2 | ) |  | — |  |  | $ | 4,301 |  |  | $ | — |  |  | — |  |  | $ | (2 | ) |  | — |  |  | $ | 43 |  |  | 1 | % |  | $ | 4,342 |  |  | 1 | % |
| Building Solutions EMEA/LA | 1,785 |  |  | (23 | ) |  | -1 | % |  | 1,762 |  |  | 15 |  |  | 1 | % |  | (58 | ) |  | -3 | % |  | 59 |  |  | 3 | % |  | 1,778 |  |  | — |  |
| Building Solutions Asia Pacific | 1,241 |  |  | — |  |  | — |  |  | 1,241 |  |  | 4 |  |  | — |  |  | (20 | ) |  | -2 | % |  | (71 | ) |  | -6 | % |  | 1,154 |  |  | -7 | % |
| Total field | 7,329 |  |  | (25 | ) |  | — |  |  | 7,304 |  |  | 19 |  |  | — |  |  | (80 | ) |  | -1 | % |  | 31 |  |  | — |  |  | 7,274 |  |  | — |  |
| Global Products | 3,914 |  |  | (15 | ) |  | — |  |  | 3,899 |  |  | 3 |  |  | — |  |  | (10 | ) |  | — |  |  | (146 | ) |  | -4 | % |  | 3,746 |  |  | -4 | % |
| Total net sales | $ | 11,243 |  |  | $ | (40 | ) |  | — |  |  | $ | 11,203 |  |  | $ | 22 |  |  | — |  |  | $ | (90 | ) |  | -1 | % |  | $ | (115 | ) |  | -1 | % |  | $ | 11,020 |  |  | -2 | % |

[0000833444-20-000013:8k_2_02:125]
Page 16 of 18

[0000833444-20-000013:8k_2_02:126]
The components of the changes in segment EBITA and EBIT for the three months ended March 31, 2020 versus the three months ended March 31, 2019, including organic growth, is shown below (unaudited):

[0000833444-20-000013:8k_2_02:127]
| (in millions) | Adjusted Segment EBITA / EBIT for the Three Months Ended March 31, 2019 |  | Base Year Adjustments - Divestitures and Other |  | Adjusted Base Segment EBITA / EBIT for the Three Months Ended March 31, 2019 |  | Acquisitions |  | Foreign Currency |  | Organic Growth |  | Adjusted SegmentEBITA / EBIT forthe ThreeMonths EndedMarch 31, 2020 |
| Building Solutions North America | $ | 259 |  |  | $ | — |  |  | — |  |  | $ | 259 |  |  | $ | — |  |  | — |  |  | $ | — |  |  | — |  |  | $ | (6 | ) |  | -2 | % |  | $ | 253 |  |  | -2 | % |
| Building Solutions EMEA/LA | 81 |  |  | — |  |  | — |  |  | 81 |  |  | 2 |  |  | 2 | % |  | (6 | ) |  | -7 | % |  | 8 |  |  | 10 | % |  | 85 |  |  | 5 | % |
| Building Solutions Asia Pacific | 76 |  |  | — |  |  | — |  |  | 76 |  |  | — |  |  | — |  |  | (1 | ) |  | -1 | % |  | (10 | ) |  | -13 | % |  | 65 |  |  | -14 | % |
| Total field | 416 |  |  | — |  |  | — |  |  | 416 |  |  | 2 |  |  | — |  |  | (7 | ) |  | -2 | % |  | (8 | ) |  | -2 | % |  | 403 |  |  | -3 | % |
| Global Products | 255 |  |  | (1 | ) |  | — |  |  | 254 |  |  | — |  |  | — |  |  | (2 | ) |  | -1 | % |  | (36 | ) |  | -14 | % |  | 216 |  |  | -15 | % |
| Total adjusted segment EBITA | 671 |  |  | $ | (1 | ) |  | — |  |  | 670 |  |  | $ | 2 |  |  | — |  |  | $ | (9 | ) |  | -1 | % |  | $ | (44 | ) |  | -7 | % |  | 619 |  |  | -8 | % |
| Corporate expenses | (104 | ) |  | — |  |  |  |  | (104 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (82 | ) |  | 21 | % |
| Amortization of intangible assets | (98 | ) |  | — |  |  |  |  | (98 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (97 | ) |  | 1 | % |
| Total adjusted EBIT | $ | 469 |  |  | $ | (1 | ) |  |  |  | $ | 468 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 440 |  |  | -6 | % |

[0000833444-20-000013:8k_2_02:128]
The components of the changes in segment EBITA and EBIT for the six months ended March 31, 2020 versus the six months ended March 31, 2019, including organic growth, is shown below (unaudited):

[0000833444-20-000013:8k_2_02:129]
| (in millions) | Adjusted Segment EBITA / EBIT for the Six Months Ended March 31, 2019 |  | Base Year Adjustments - Divestitures and Other |  | Adjusted Base Segment EBITA / EBIT for the Six Months Ended March 31, 2019 |  | Acquisitions |  | Foreign Currency |  | Organic Growth |  | Adjusted SegmentEBITA / EBIT forthe Six Months EndedMarch 31, 2020 |
| Building Solutions North America | $ | 512 |  |  | $ | — |  |  | — |  |  | $ | 512 |  |  | $ | — |  |  | — |  |  | $ | — |  |  | — |  |  | $ | — |  |  | — |  |  | $ | 512 |  |  | — |  |
| Building Solutions EMEA/LA | 158 |  |  | (1 | ) |  | -1 | % |  | 157 |  |  | 3 |  |  | 2 | % |  | (9 | ) |  | -6 | % |  | 24 |  |  | 15 | % |  | 175 |  |  | 11 | % |
| Building Solutions Asia Pacific | 142 |  |  | — |  |  | — |  |  | 142 |  |  | 1 |  |  | 1 | % |  | (1 | ) |  | -1 | % |  | (5 | ) |  | -4 | % |  | 137 |  |  | -4 | % |
| Total field | 812 |  |  | (1 | ) |  | — |  |  | 811 |  |  | 4 |  |  | — |  |  | (10 | ) |  | -1 | % |  | 19 |  |  | 2 | % |  | 824 |  |  | 2 | % |
| Global Products | 449 |  |  | (1 | ) |  | — |  |  | 448 |  |  | (1 | ) |  | — |  |  | (3 | ) |  | -1 | % |  | (24 | ) |  | -5 | % |  | 420 |  |  | -6 | % |
| Total adjusted segment EBITA | 1,261 |  |  | $ | (2 | ) |  | — |  |  | 1,259 |  |  | $ | 3 |  |  | — |  |  | $ | (13 | ) |  | -1 | % |  | $ | (5 | ) |  | — |  |  | 1,244 |  |  | -1 | % |
| Corporate expenses | (197 | ) |  | — |  |  |  |  | (197 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (163 | ) |  | 17 | % |
| Amortization of intangible assets | (195 | ) |  | — |  |  |  |  | (195 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (193 | ) |  | 1 | % |
| Total adjusted EBIT | $ | 869 |  |  | $ | (2 | ) |  |  |  | $ | 867 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 888 |  |  | 2 | % |

[0000833444-20-000013:8k_2_02:130]
4.  Adjusted Free Cash Flow Reconciliation

[0000833444-20-000013:8k_2_02:131]
The Company's press release contains financial information regarding free cash flow, adjusted free cash flow and adjusted free cash flow conversion, which are non-GAAP performance measures. Free cash flow is defined as cash provided by operating activities less capital expenditures. Adjusted free cash flow excludes special items, as included in the table below, because these cash flows are not considered to be directly related to its underlying businesses. Adjusted free cash flow conversion is defined as adjusted free cash flow divided by adjusted net income. Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash.

[0000833444-20-000013:8k_2_02:132]
The following is the three months and six months ended March 31, 2020 and 2019 reconciliation of free cash flow, adjusted free cash flow and adjusted free cash flow conversion for continuing operations (unaudited):

[0000833444-20-000013:8k_2_02:133]
| (in billions) | Three Months Ended March 31, 2020 |  | Three Months Ended March 31, 2019 |  | Six Months Ended March 31, 2020 |  | Six Months Ended March 31, 2019 |
| Cash provided by operating activities from continuing operations | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | 0.7 |  |  | $ | 0.1 |  |
| Capital expenditures | (0.1 | ) |  | (0.1 | ) |  | (0.3 | ) |  | (0.3 | ) |
| Reported free cash flow* | — |  |  | 0.1 |  |  | 0.4 |  |  | (0.2 | ) |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction/integration costs | — |  |  | 0.1 |  |  | 0.2 |  |  | 0.1 |  |
| Restructuring payments | 0.1 |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Nonrecurring tax refunds | — |  |  | — |  |  | (0.6 | ) |  | — |  |
| Total adjusting items | 0.1 |  |  | 0.1 |  |  | (0.3 | ) |  | 0.2 |  |
| Adjusted free cash flow* | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | 0.1 |  |  | $ | — |  |
| Adjusted net income from continuing operations |  |  |  |  |  |  |  |
| attributable to JCI | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.6 |  |  | $ | 0.5 |  |
| Adjusted free cash flow conversion | 67 | % |  | 67 | % |  | 17 | % |  | 0 | % |

[0000833444-20-000013:8k_2_02:134]
* May not sum due to rounding

[0000833444-20-000013:8k_2_02:135]
Page 17 of 18

[0000833444-20-000013:8k_2_02:136]
5.  Net Debt to EBITDA

[0000833444-20-000013:8k_2_02:137]
The Company provides financial information regarding net debt to adjusted EBITDA, which is a non-GAAP performance measure. The Company believes the total net debt to adjusted EBITDA ratio is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. The following is the March 31, 2020 and December 31, 2019 calculation of net debt to adjusted EBITDA (unaudited):

[0000833444-20-000013:8k_2_02:138]
| (in millions) | March 31, 2020 |  | December 31, 2019 |
| Short-term debt and current portion of long-term debt | $ | 1,430 |  |  | $ | 1,362 |  |
| Long-term debt | 5,640 |  |  | 5,920 |  |
| Total debt | 7,070 |  |  | 7,282 |  |
| Less: cash and cash equivalents | 1,006 |  |  | 2,160 |  |
| Total net debt | $ | 6,064 |  |  | $ | 5,122 |  |
| Last twelve months adjusted EBITDA | $ | 3,326 |  |  | $ | 3,359 |  |
| Total net debt to adjusted EBITDA | 1.8x |  |  | 1.5x |  |

[0000833444-20-000013:8k_2_02:139]
The following is the last twelve months ended March 31, 2020  and December 31, 2019 reconciliation of income from continuing operations to adjusted EBIT and adjusted EBITDA, which are non-GAAP performance measures (unaudited):

[0000833444-20-000013:8k_2_02:140]
| (in millions) | Last Twelve MonthsEndedMarch 31, 2020 |  | Last Twelve Months EndedDecember 31, 2019 |
| Income from continuing operations | $ | 1,306 |  |  | $ | 1,344 |  |
| Income tax benefit | (310 | ) |  | (276 | ) |
| Net financing charges | 278 |  |  | 317 |  |
| EBIT | 1,274 |  |  | 1,385 |  |
| Adjusting items: |  |  |  |
| Transaction costs | 7 |  |  | 9 |  |
| Integration costs | 267 |  |  | 297 |  |
| Net mark-to-market adjustments | 639 |  |  | 587 |  |
| Restructuring and impairment costs | 408 |  |  | 346 |  |
| Tax indemnification reserve release | (226 | ) |  | (226 | ) |
| Environmental reserve | 140 |  |  | 140 |  |
| Adjusted EBIT (1) | 2,509 |  |  | 2,538 |  |
| Depreciation and amortization | 817 |  |  | 821 |  |
| Adjusted EBITDA (1) | $ | 3,326 |  |  | $ | 3,359 |  |

[0000833444-20-000013:8k_2_02:141]
(1) The Company's definition of adjusted EBIT and adjusted EBITDA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-20-000013:8k_2_02:142]
6.  Income Taxes

[0000833444-20-000013:8k_2_02:143]
The Company's effective tax rate from continuing operations before consideration of transaction/integration costs, net mark-to-market adjustments, restructuring and impairment costs, and discrete tax items for the three and six months ending March 31, 2020 and March 31, 2019 is approximately 13.5%.

[0000833444-20-000013:8k_2_02:144]
7.  Restructuring and Impairment Costs

[0000833444-20-000013:8k_2_02:145]
The three months ended March 31, 2020 include restructuring and impairment costs of $62 million related to indefinite-lived intangible asset impairments primarily related to the Company's retail business. The six months ended March 31, 2020 include restructuring and impairment costs of $173 million related primarily to workforce reductions, plant closures and asset impairments.

[0000833444-20-000013:8k_2_02:146]
8.  Leases

[0000833444-20-000013:8k_2_02:147]
On October 1, 2019, the Company adopted ASU 2016-02, "Leases (Topic 842)," which requires recognition of operating leases as a lease asset and liabilities on the balance sheet. The adoption of the new guidance resulted in recognition of a right-of-use asset and related lease liabilities of $1.1 billion.

[0000833444-20-000013:8k_2_02:148]
Page 18 of 18
