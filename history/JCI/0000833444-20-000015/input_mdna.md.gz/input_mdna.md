# JCI MD&A — 0000833444-20-000015


## mdna

[0000833444-20-000015:mdna:1]
[same as prior period, unchanged from 0000833444-20-000006:mdna:1]

[0000833444-20-000015:mdna:2]
[same as prior period, unchanged from 0000833444-20-000006:mdna:2]

[0000833444-20-000015:mdna:3]
[same as prior period, unchanged from 0000833444-20-000006:mdna:3]

[0000833444-20-000015:mdna:4]
[same as prior period, unchanged from 0000833444-20-000006:mdna:4]

[0000833444-20-000015:mdna:5]
[same as prior period, unchanged from 0000833444-20-000006:mdna:5]

[0000833444-20-000015:mdna:6]
[same as prior period, unchanged from 0000833444-20-000006:mdna:6]

[0000833444-20-000015:mdna:7]
On November 13, 2018, the Company entered into a Stock and Asset Purchase Agreement (“Purchase Agreement”) with BCP Acquisitions LLC (“Purchaser”). The Purchaser is a newly-formed entity controlled by investment funds managed by Brookfield Capital Partners LLC. Pursuant to the Purchase Agreement, on the terms and subject to the conditions therein, the Company agreed

[0000833444-20-000015:mdna:8]
to sell, and Purchaser agreed to acquire, the Company’s Power Solutions business for a purchase price of $13.2 billion. The transaction closed on April 30, 2019 with net cash proceeds of $11.6 billion after tax and transaction-related expenses.

[0000833444-20-000015:mdna:9]
[same as prior period, unchanged from 0000833444-20-000006:mdna:8]

[0000833444-20-000015:mdna:10]
[same as prior period, unchanged from 0000833444-20-000006:mdna:9]

[0000833444-20-000015:mdna:11]
The following information should be read in conjunction with the September 30, 2019 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2019 filed with the SEC on November 21, 2019. References in the following discussion and analysis to "Three Months" (or similar language) refer to the three months ended March 31, 2020 compared to the three months ended March 31, 2019, while "Year-to-Date" refers to the six months ended March 31, 2020 compared to the six months ended March 31, 2019.

[0000833444-20-000015:mdna:12]
Impact of COVID-19 pandemic

[0000833444-20-000015:mdna:13]
The global outbreak of COVID-19 has severely restricted the level of economic activity around the world. In response to this outbreak, the governments of many countries, states, cities and other geographic regions have taken preventative or protective actions, such as imposing restrictions on travel and business operations. The Company’s affiliates, employees, suppliers, customers and others have been and may continue to be restricted or prevented from conducting normal business activities, including as a result of shutdowns, travel restrictions and other actions that may be requested or mandated by governmental authorities. Such actions have, and may in the future prevent the Company from accessing the facilities of its customers to deliver and install products, provide services and complete maintenance. While a substantial portion of the Company businesses have been classified as an essential business in jurisdictions in which facility closures have been mandated, some of its facilities have nevertheless been ordered to close in certain jurisdictions.

[0000833444-20-000015:mdna:14]
In the second quarter of fiscal 2020, the Company experienced a temporary reduction of its manufacturing and operating capacity in China as a result of government-mandated actions to control the spread of COVID-19. Further, the Company has experienced, and may continue to experience, disruptions or delays in its supply chain as a result of such actions, which has resulted in higher supply chain costs to the Company in order to maintain the supply of materials and components for its products. In addition, the Company has modified its business practices (including employee travel, employee work locations, and cancellation of physical participation in meetings, events and conferences).

[0000833444-20-000015:mdna:15]
The Company has experienced a recent decline in demand and volumes in its global businesses as a result of the impact of efforts to contain the spread of COVID-19.  In addition, the Company’s customers may choose to delay or abandon projects on which the Company provides products and/or services.

[0000833444-20-000015:mdna:16]
While the Company has a strong liquidity position as of March 31, 2020, with $1.0 billion of cash and $3.0 billion of revolving credit facilities, given the increasingly uncertain economic environment, the Company took proactive measures in April 2020 to increase near-term financial flexibility, electing to opportunistically raise $675 million via European financing arrangements and $575 million in bank term loans. To further enhance liquidity resources, in March 2020 the Company made the decision to suspend its share repurchase program. Additionally, the Company is executing cost mitigation actions in response to the COVID-19 pandemic, such as short-term furloughing of salaried employees and limiting discretionary spending including Corporate expense.

[0000833444-20-000015:mdna:17]
The extent to which the COVID-19 outbreak impacts the Company’s results of operations and financial condition will depend on future developments that are highly uncertain and cannot be predicted, including new information that may emerge concerning the severity of COVID-19, the longevity of COVID-19, the impact of COVID-19 on economic activity, and the actions to contain its impacts on public health and the global economy. See Part II, Item 1A, Risk Factors, for an additional discussion of risks related to COVD-19.

[0000833444-20-000015:mdna:18]
[same as prior period, unchanged from 0000833444-20-000006:mdna:11]

[0000833444-20-000015:mdna:19]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Net sales | $ | 5,444 |  |  | $ | 5,779 |  |  | -6 | % |  | $ | 11,020 |  |  | $ | 11,243 |  |  | -2 | % |

[0000833444-20-000015:mdna:20]
The decrease in consolidated net sales for the three months ended March 31, 2020 was due to lower organic sales ($281 million), the unfavorable impact of foreign currency translation ($63 million) and lower sales due to business divestitures ($5 million), partially offset by acquisitions ($14 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales decreased 5% as compared to the prior year due to the unfavorable impact of the COVID-19 pandemic. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-20-000015:mdna:21]
The decrease in consolidated net sales for the six months ended March 31, 2020 was due to lower organic sales ($143 million), the unfavorable impact of foreign currency translation ($90 million) and lower sales due to business divestitures ($12 million), partially offset by acquisitions ($22 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales decreased 1% as compared to the prior year due to the unfavorable impact of the COVID-19 pandemic. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-20-000015:mdna:22]
[same as prior period, unchanged from 0000833444-20-000006:mdna:14]

[0000833444-20-000015:mdna:23]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Cost of sales | $ | 3,643 |  |  | $ | 3,935 |  |  | -7 | % |  | $ | 7,416 |  |  | $ | 7,674 |  |  | -3 | % |
| Gross profit | 1,801 |  |  | 1,844 |  |  | -2 | % |  | 3,604 |  |  | 3,569 |  |  | 1 | % |
| % of sales | 33.1 | % |  | 31.9 | % |  |  |  | 32.7 | % |  | 31.7 | % |  |  |

[0000833444-20-000015:mdna:24]
Cost of sales and gross profit decreased for the three month period ended March 31, 2020, and gross profit as a percentage of sales increased by 120 basis points. Gross profit decreased due to organic sales declines due to the unfavorable impact of the COVID-19 pandemic. Foreign currency translation had a favorable impact on cost of sales of approximately $43 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-20-000015:mdna:25]
Cost of sales decreased and gross profit increased for the six month period ended March 31, 2020, and gross profit as a percentage of sales increased by 100 basis points. Foreign currency translation had a favorable impact on cost of sales of approximately $60 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-20-000015:mdna:26]
[same as prior period, unchanged from 0000833444-20-000006:mdna:17]

[0000833444-20-000015:mdna:27]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Selling, general and administrative expenses | $ | 1,451 |  |  | $ | 1,458 |  |  | — | % |  | $ | 2,878 |  |  | $ | 2,896 |  |  | -1 | % |
| % of sales | 26.7 | % |  | 25.2 | % |  |  |  | 26.1 | % |  | 25.8 | % |  |  |

[0000833444-20-000015:mdna:28]
Selling, general and administrative expenses ("SG&A") for the three month period ended March 31, 2020 decreased $7 million, and SG&A as a percentage of sales increased by 150 basis points. The decrease in SG&A was primarily due to a reduction in discretionary spend in the current quarter and a favorable impact of foreign currency translation, partially offset by unfavorable year-over-year impact of net mark-to-market adjustments on restricted asbestos investments. The Company is executing cost

[0000833444-20-000015:mdna:29]
[same as prior period, unchanged from 0000833444-20-000006:mdna:93]

[0000833444-20-000015:mdna:30]
mitigation actions in response to the COVID-19 pandemic. Foreign currency translation had a favorable impact on SG&A of $12 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-20-000015:mdna:31]
SG&A for the six month period ended March 31, 2020 decreased $18 million, and SG&A as a percentage of sales increased by 30 basis points. The decrease in SG&A was primarily due to a reduction in discretionary spend in the current year and a favorable impact of foreign currency translation, partially offset by unfavorable year-over-year impact of net mark-to-market adjustments on restricted asbestos investments. The Company is executing cost mitigation actions in response to the COVID-19 pandemic. Foreign currency translation had a favorable impact on SG&A of $19 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-20-000015:mdna:32]
[same as prior period, unchanged from 0000833444-20-000006:mdna:20]

[0000833444-20-000015:mdna:33]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Restructuring and impairment costs | $ | 62 |  |  | $ | — |  |  | * |  | $ | 173 |  |  | $ | — |  |  | * |

[0000833444-20-000015:mdna:34]
[same as prior period, unchanged from 0000833444-20-000006:mdna:22]

[0000833444-20-000015:mdna:35]
Refer to Note 9, "Significant Restructuring and Impairment Costs," Note 8, "Goodwill and Other Intangible Assets," and Note 18, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-20-000015:mdna:36]
[same as prior period, unchanged from 0000833444-20-000006:mdna:24]

[0000833444-20-000015:mdna:37]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Net financing charges | $ | 59 |  |  | $ | 98 |  |  | -40 | % |  | $ | 111 |  |  | $ | 183 |  |  | -39 | % |

[0000833444-20-000015:mdna:38]
[same as prior period, unchanged from 0000833444-20-000006:mdna:26]

[0000833444-20-000015:mdna:39]
[same as prior period, unchanged from 0000833444-20-000006:mdna:27]

[0000833444-20-000015:mdna:40]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Equity income | $ | 20 |  |  | $ | 33 |  |  | -39 | % |  | $ | 63 |  |  | $ | 75 |  |  | -16 | % |

[0000833444-20-000015:mdna:41]
The decrease in equity income for the three months ended March 31, 2020 was primarily due to lower income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture primarily due to unfavorable impact of the COVID-19 pandemic. Foreign currency translation had an unfavorable impact on equity income of $1 million for the three months ended March 31, 2020. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-20-000015:mdna:42]
The decrease in equity income for the six months ended March 31, 2020 was primarily due to lower income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture primarily due to unfavorable impact of the COVID-19 pandemic. Foreign currency translation had an unfavorable impact on equity income of $2 million for the six months ended March 31, 2020. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-20-000015:mdna:43]
[same as prior period, unchanged from 0000833444-20-000006:mdna:30]

[0000833444-20-000015:mdna:44]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Income tax provision | $ | 13 |  |  | $ | 47 |  |  | -72 | % |  | $ | 78 |  |  | $ | 155 |  |  | -50 | % |
| Effective tax rate | 5 | % |  | 15 | % |  |  |  | 15 | % |  | 27 | % |  |  |

[0000833444-20-000015:mdna:45]
[same as prior period, unchanged from 0000833444-20-000006:mdna:32]

[0000833444-20-000015:mdna:46]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended March 31, 2020, the Company's effective tax rate for continuing operations was 5% and was lower than the statutory tax rate of 12.5% primarily due to tax audit reserve adjustments and the benefits of continuing global tax planning initiatives, partially offset by tax rate differentials. For the six months ended March 31, 2020, the Company's effective tax rate for continuing operations was 15% and was higher than the statutory tax rate of 12.5% primarily due to a discrete tax charge related to the remeasurement of deferred tax assets and liabilities as a result of Swiss tax reform and tax rate differentials, partially offset by tax audit reserve adjustments and the benefits of continuing global tax planning initiatives. For the three months ended March 31, 2019, the Company's effective tax rate for continuing operations was 15% and was higher than the statutory tax rate of 12.5% primarily due to tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the six months ended March 31, 2019, the Company's effective tax rate for continuing operations was 27% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments as a result of tax law changes and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. The effective tax rate for the six months ended March 31, 2020 decreased as compared to the six months ended March 31, 2019 primarily due to the discrete tax items. Refer to Note 10, "Income Taxes," of the notes to consolidated financial statements for further details.

[0000833444-20-000015:mdna:47]
[same as prior period, unchanged from 0000833444-20-000006:mdna:35]

[0000833444-20-000015:mdna:48]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Income from discontinued operations, net of tax | $ | — |  |  | $ | 284 |  |  | * |  | $ | — |  |  | $ | 547 |  |  | * |

[0000833444-20-000015:mdna:49]
[same as prior period, unchanged from 0000833444-20-000006:mdna:37]

[0000833444-20-000015:mdna:50]
[same as prior period, unchanged from 0000833444-20-000006:mdna:38]

[0000833444-20-000015:mdna:51]
[same as prior period, unchanged from 0000833444-20-000006:mdna:39]

[0000833444-20-000015:mdna:52]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 23 |  |  | $ | 34 |  |  | -32 | % |  | $ | 55 |  |  | $ | 63 |  |  | -13 | % |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | 9 |  |  | * |  |  | — |  |  | 24 |  |  | * |  |

[0000833444-20-000015:mdna:53]
[same as prior period, unchanged from 0000833444-20-000006:mdna:41]

[0000833444-20-000015:mdna:54]
The decrease in income from continuing operations attributable to noncontrolling interests for the three and six months ended March 31, 2020 was primarily due to lower net income as a result of the COVID-19 pandemic at certain partially-owned affiliates within the Global Products segment.

[0000833444-20-000015:mdna:55]
[same as prior period, unchanged from 0000833444-20-000006:mdna:43]

[0000833444-20-000015:mdna:56]
[same as prior period, unchanged from 0000833444-20-000006:mdna:44]

[0000833444-20-000015:mdna:57]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Net income attributable to Johnson Controls | $ | 213 |  |  | $ | 515 |  |  | -59 | % |  | $ | 372 |  |  | $ | 870 |  |  | -57 | % |

[0000833444-20-000015:mdna:58]
The decrease in net income attributable to Johnson Controls for the three months ended March 31, 2020 was primarily due to the prior year income from discontinued operations, current year impairment charges and the unfavorable impact of the COVID-19 pandemic. The decrease in net income attributable to Johnson Controls for the six months ended March 31, 2020 was primarily due to the prior year income from discontinued operations, current year restructuring and impairment charges, and the unfavorable impact of the COVID-19 pandemic, partially offset by lower income tax provision and lower net financing charges.

[0000833444-20-000015:mdna:59]
Diluted earnings per share attributable to Johnson Controls for the three months ended March 31, 2020 was $0.28 compared to $0.57 for the three months ended March 31, 2019. Diluted earnings per share attributable to Johnson Controls for the six months ended March 31, 2020 was $0.49 compared to $0.95 for the six months ended March 31, 2019.

[0000833444-20-000015:mdna:60]
Comprehensive Income (Loss) Attributable to Johnson Controls

[0000833444-20-000015:mdna:61]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Comprehensive income (loss) attributable to Johnson Controls | $ | (268 | ) |  | $ | 643 |  |  | * |  | $ | 146 |  |  | $ | 872 |  |  | -83 | % |

[0000833444-20-000015:mdna:62]
* Measure not meaningful

[0000833444-20-000015:mdna:63]
The increase in comprehensive loss attributable to Johnson Controls for the three months ended March 31, 2020 was due to an increase in other comprehensive loss attributable to Johnson Controls ($609 million) resulting primarily from unfavorable currency translation adjustments and by lower net income attributable to Johnson Controls ($302 million). The year-over-year unfavorable foreign currency translation adjustments were primarily driven by the weakening of the British pound, Canadian dollar, euro, Mexican peso and Brazilian real currencies against the U.S. dollar in the current quarter.

[0000833444-20-000015:mdna:64]
The decrease in comprehensive income attributable to Johnson Controls for the six months ended March 31, 2020 was due to lower net income attributable to Johnson Controls ($498 million) and an increase in other comprehensive loss attributable to Johnson Controls ($228 million) resulting primarily from unfavorable currency translation adjustments. The year-over-year unfavorable foreign currency translation adjustments were primarily driven by the weakening of the Canadian dollar, Mexican peso and Brazilian real currencies against the U.S. dollar in the current year.

[0000833444-20-000015:mdna:65]
[same as prior period, unchanged from 0000833444-20-000006:mdna:52]

[0000833444-20-000015:mdna:66]
[same as prior period, unchanged from 0000833444-20-000006:mdna:53]

[0000833444-20-000015:mdna:67]
[same as prior period, unchanged from 0000833444-20-000006:mdna:54]

[0000833444-20-000015:mdna:68]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Building Solutions North America | $ | 2,175 |  |  | $ | 2,187 |  |  | -1 | % |  | $ | 4,342 |  |  | $ | 4,303 |  |  | 1 | % |
| Building Solutions EMEA/LA | 850 |  |  | 878 |  |  | -3 | % |  | 1,778 |  |  | 1,785 |  |  | — | % |
| Building Solutions Asia Pacific | 525 |  |  | 628 |  |  | -16 | % |  | 1,154 |  |  | 1,241 |  |  | -7 | % |
| Global Products | 1,894 |  |  | 2,086 |  |  | -9 | % |  | 3,746 |  |  | 3,914 |  |  | -4 | % |
|  | $ | 5,444 |  |  | $ | 5,779 |  |  | -6 | % |  | $ | 11,020 |  |  | $ | 11,243 |  |  | -2 | % |

[0000833444-20-000015:mdna:69]
Three Months:

[0000833444-20-000015:mdna:70]
| • | The decrease in Building Solutions North America was due to lower volumes ($10 million) and the unfavorable impact of foreign currency translation ($2 million). The decrease in volumes was primarily attributed to an increase in installation / services sales being more than offset by the unfavorable impact of the COVID-19 pandemic. |

[0000833444-20-000015:mdna:71]
| • | The decrease in Building Solutions EMEA/LA was primarily attributable to the unfavorable impact of foreign currency translation ($33 million), lower volumes due to business divestitures ($3 million) and lower volumes ($2 million), partially offset by incremental sales related to business acquisitions ($10 million). The decrease in volumes was primarily attributed to an increase in services sales being more than offset by the unfavorable impact of the COVID-19 pandemic. |

[0000833444-20-000015:mdna:72]
| • | The decrease in Building Solutions Asia Pacific was due to lower volumes ($90 million) and the unfavorable impact of foreign currency translation ($15 million), partially offset by incremental sales related to business acquisitions ($2 million). The decrease in volumes was primarily attributed to an increase in installation / services sales being more than offset by the unfavorable impact of the COVID-19 pandemic. |

[0000833444-20-000015:mdna:73]
| • | The decrease in Global Products was due to lower volumes ($179 million), the unfavorable impact of foreign currency translation ($13 million) and lower volumes due to business divestitures ($2 million), partially offset by incremental sales related to business acquisitions ($2 million). The decrease in volumes was primarily attributed to the unfavorable impact of the COVID-19 pandemic. |

[0000833444-20-000015:mdna:74]
Year-to-Date:

[0000833444-20-000015:mdna:75]
| • | The increase in Building Solutions North America was due to higher volumes ($41 million), partially offset by the unfavorable impact of foreign currency translation ($2 million). The increase in volumes was primarily attributed to an increase in installation / services, partially offset by the unfavorable impact of the COVID-19 pandemic. |

[0000833444-20-000015:mdna:76]
| • | The decrease in Building Solutions EMEA/LA was primarily attributable to the unfavorable impact of foreign currency translation ($58 million) and lower volumes due to business divestitures ($7 million), partially offset by higher volumes ($43 million) and incremental sales related to business acquisitions ($15 million). The increase in volumes was primarily attributed to an increase in installation / services sales, partially offset by the unfavorable impact of the COVID-19 pandemic. |

[0000833444-20-000015:mdna:77]
| • | The decrease in Building Solutions Asia Pacific was due to lower volumes ($71 million) and the unfavorable impact of foreign currency translation ($20 million), partially offset by incremental sales related to business acquisitions ($4 million). The decrease in volumes was primarily attributed to an increase in installation / services sales being more than offset by the unfavorable impact of the COVID-19 pandemic. |

[0000833444-20-000015:mdna:78]
| • | The decrease in Global Products was due to lower volumes ($156 million), the unfavorable impact of foreign currency translation ($10 million) and lower volumes due to business divestitures ($5 million), partially offset by incremental sales related to business acquisitions ($3 million). The decrease in volumes was primarily attributed to an increase in building management and specialty product sales being more than offset by the unfavorable impact of the COVID-19 pandemic. |

[0000833444-20-000015:mdna:79]
51

[0000833444-20-000015:mdna:80]
[same as prior period, unchanged from 0000833444-20-000006:mdna:61]

[0000833444-20-000015:mdna:81]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Building Solutions North America | $ | 251 |  |  | $ | 257 |  |  | -2 | % |  | $ | 509 |  |  | $ | 507 |  |  | — | % |
| Building Solutions EMEA/LA | 85 |  |  | 80 |  |  | 6 | % |  | 175 |  |  | 157 |  |  | 11 | % |
| Building Solutions Asia Pacific | 65 |  |  | 76 |  |  | -14 | % |  | 137 |  |  | 142 |  |  | -4 | % |
| Global Products | 216 |  |  | 251 |  |  | -14 | % |  | 419 |  |  | 441 |  |  | -5 | % |
|  | $ | 617 |  |  | $ | 664 |  |  | -7 | % |  | $ | 1,240 |  |  | $ | 1,247 |  |  | -1 | % |

[0000833444-20-000015:mdna:82]
Three Months:

[0000833444-20-000015:mdna:83]
| • | The decrease in Building Solutions North America was due to unfavorable volumes, net of productivity savings and cost mitigation actions ($6 million) and current year integration costs ($2 million), partially offset by prior year integration costs ($2 million). The decrease in volumes was primarily attributed to an increase in installation / services sales being more than offset by the unfavorable impact of the COVID-19 pandemic. |

[0000833444-20-000015:mdna:84]
| • | The increase in Building Solutions EMEA/LA was due to productivity savings and cost mitigation actions, net of unfavorable volumes ($6 million), higher income due to business acquisitions ($2 million), higher equity income ($2 million) and prior year integration costs ($1 million), partially offset by the unfavorable impact of foreign currency translation ($6 million). The decrease in volumes was primarily attributed to an increase in services sales being more than offset by the unfavorable impact of the COVID-19 pandemic. |

[0000833444-20-000015:mdna:85]
| • | The decrease in Building Solutions Asia Pacific was due to unfavorable volumes, net of productivity savings and cost mitigation actions ($10 million) and the unfavorable impact of foreign currency translation ($1 million). The decrease in volumes was primarily attributed to an increase in installation / services sales being more than offset by the unfavorable impact of the COVID-19 pandemic. |

[0000833444-20-000015:mdna:86]
| • | The decrease in Global Products was due to unfavorable volumes, net of favorable price / cost, productivity savings and cost mitigation actions ($22 million), lower equity income driven primarily by the unfavorable impact of COVID-19 ($14 million) the unfavorable impact of foreign currency translation ($2 million) and lower income due to business divestitures ($1 million), partially offset by prior year integration costs ($4 million). The decrease in volumes was primarily attributed to the unfavorable impact of the COVID-19 pandemic. |

[0000833444-20-000015:mdna:87]
Year-to-Date:

[0000833444-20-000015:mdna:88]
| • | The increase in Building Solutions North America was due to prior year integration costs ($5 million), partially offset by current year integration costs ($3 million). Favorable volume, productivity savings and cost mitigation actions were offset by unfavorable mix. The increase in volumes was primarily attributed to an increase in installation / services, partially offset by the unfavorable impact of the COVID-19 pandemic. |

[0000833444-20-000015:mdna:89]
| • | The increase in Building Solutions EMEA/LA was due to favorable volume, productivity savings and cost mitigation actions ($22 million), higher income due to business acquisitions ($3 million), higher equity income ($2 million) and prior year integration costs ($1 million), partially offset by the unfavorable impact of foreign currency translation ($9 million) and lower income due to business divestitures ($1 million). The increase in volumes was primarily attributed to an increase in installation / services sales, partially offset by the unfavorable impact of the COVID-19 pandemic. |

[0000833444-20-000015:mdna:90]
| • | The decrease in Building Solutions Asia Pacific was due to unfavorable volumes / mix, net of productivity savings and cost mitigation actions ($5 million) and the unfavorable impact of foreign currency translation ($1 million), partially offset by higher income due to business acquisitions ($1 million). The decrease in volumes was primarily attributed to an increase in installation / services sales being more than offset by the unfavorable impact of the COVID-19 pandemic. |

[0000833444-20-000015:mdna:91]
| • | The decrease in Global Products was due to unfavorable volumes , net of favorable price / cost, productivity savings and cost mitigation actions ($12 million), lower equity income driven by the unfavorable impact of COVID-19 ($12 million), the unfavorable impact of foreign currency translation ($3 million), lower income due to business acquisitions ($1 million), lower income due to business divestitures ($1 million) and current year integration costs ($1 million), partially offset by |

[0000833444-20-000015:mdna:92]
prior year integration costs ($8 million). The decrease in volumes was primarily attributed to an increase in building management and specialty product sales being more than offset by the unfavorable impact of the COVID-19 pandemic.

[0000833444-20-000015:mdna:93]
[same as prior period, unchanged from 0000833444-20-000006:mdna:67]

[0000833444-20-000015:mdna:94]
The Company’s backlog relating to the Building Technologies & Solutions business is applicable to its sales of systems and services. At March 31, 2020, the backlog was $9.3 billion, of which $9.0 billion was attributable to the field business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-20-000015:mdna:95]
In the first quarter of fiscal 2019, the Company adopted ASC 606, “Revenue from Contracts with Customers,” and as a result is required to disclose remaining performance obligations. At March 31, 2020, remaining performance obligations were $14.4 billion, which is $5.1 billion higher than the Company's backlog of $9.3 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-20-000015:mdna:96]
[same as prior period, unchanged from 0000833444-20-000006:mdna:70]

[0000833444-20-000015:mdna:97]
[same as prior period, unchanged from 0000833444-20-000006:mdna:71]

[0000833444-20-000015:mdna:98]
[same as prior period, unchanged from 0000833444-20-000006:mdna:72]

[0000833444-20-000015:mdna:99]
[same as prior period, unchanged from 0000833444-20-000006:mdna:73]

[0000833444-20-000015:mdna:100]
[same as prior period, unchanged from 0000833444-20-000006:mdna:74]

[0000833444-20-000015:mdna:101]
[same as prior period, unchanged from 0000833444-20-000006:mdna:75]

[0000833444-20-000015:mdna:102]
|  | March 31, |  | September 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |
| Current assets | $ | 9,955 |  |  | $ | 12,393 |  |  |  |
| Current liabilities | (9,509 | ) |  | (9,070 | ) |  |  |
|  | 446 |  |  | 3,323 |  |  | -87 | % |
| Less: Cash | (1,006 | ) |  | (2,805 | ) |  |  |
| Add: Short-term debt | 344 |  |  | 10 |  |  |  |
| Add: Current portion of long-term debt | 1,086 |  |  | 501 |  |  |  |
| Less: Assets held for sale | (91 | ) |  | (98 | ) |  |  |
| Add: Liabilities held for sale | 39 |  |  | 44 |  |  |  |
| Working capital (as defined) | $ | 818 |  |  | $ | 975 |  |  | -16 | % |
| Accounts receivable - net | $ | 5,492 |  |  | $ | 5,770 |  |  | -5 | % |
| Inventories | 2,030 |  |  | 1,814 |  |  | 12 | % |
| Accounts payable | 3,119 |  |  | 3,582 |  |  | -13 | % |

[0000833444-20-000015:mdna:103]
[same as prior period, unchanged from 0000833444-20-000006:mdna:77]

[0000833444-20-000015:mdna:104]
| • | The decrease in working capital at March 31, 2020 as compared to September 30, 2019, was primarily due to lower income tax assets, the establishment of an operating lease liability on the balance sheet in the first quarter of fiscal 2020 as a result of the adoption of ASC 842 and a decrease in accounts receivable, partially offset by a decrease in accounts payable due to lower spending, a decrease in accrued compensation and benefits liabilities and an increase in inventory. |

[0000833444-20-000015:mdna:105]
| • | The Company’s days sales in accounts receivable at March 31, 2020 and September 30, 2019 were 71 days and 67 days, respectively. There has been no significant adverse changes in the level of overdue receivables or significant changes in revenue recognition methods. |

[0000833444-20-000015:mdna:106]
| • | The Company’s inventory turns for the three months ended March 31, 2020 were lower than the comparable period ended September 30, 2019, primarily due to changes in inventory production levels. |

[0000833444-20-000015:mdna:107]
| • | Days in accounts payable at March 31, 2020 were 73 days, higher than 72 days at the comparable period ended September 30, 2019. |

[0000833444-20-000015:mdna:108]
[same as prior period, unchanged from 0000833444-20-000006:mdna:83]

[0000833444-20-000015:mdna:109]
|  |  | Six Months Ended March 31, |
| (in millions) |  | 2020 |  | 2019 |
| Cash provided by operating activities |  | $ | 666 |  |  | $ | 103 |  |
| Cash used by investing activities |  | (288 | ) |  | (259 | ) |
| Cash used by financing activities |  | (2,036 | ) |  | (39 | ) |

[0000833444-20-000015:mdna:110]
| • | The increase in cash provided by operating activities was primarily due to the timing of income tax payments / refunds and favorable changes in accounts receivable, partially offset by unfavorable changes in accounts payable and accrued liabilities. |

[0000833444-20-000015:mdna:111]
[same as prior period, unchanged from 0000833444-20-000006:mdna:86]

[0000833444-20-000015:mdna:112]
[same as prior period, unchanged from 0000833444-20-000006:mdna:87]

[0000833444-20-000015:mdna:113]
[same as prior period, unchanged from 0000833444-20-000006:mdna:88]

[0000833444-20-000015:mdna:114]
|  | March 31, |  | September 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |
| Short-term debt | $ | 344 |  |  | $ | 10 |  |  |  |
| Current portion of long-term debt | 1,086 |  |  | 501 |  |  |  |
| Long-term debt | 5,640 |  |  | 6,708 |  |  |  |
| Total debt | 7,070 |  |  | 7,219 |  |  | -2 | % |
| Less: cash and cash equivalents | 1,006 |  |  | 2,805 |  |  |  |
| Total net debt | 6,064 |  |  | 4,414 |  |  | 37 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 18,084 |  |  | 19,766 |  |  | -9 | % |
| Total capitalization | $ | 24,148 |  |  | $ | 24,180 |  |  | — | % |
| Total net debt as a % of total capitalization | 25.1 | % |  | 18.3 | % |  |  |

[0000833444-20-000015:mdna:115]
[same as prior period, unchanged from 0000833444-20-000006:mdna:90]

[0000833444-20-000015:mdna:116]
54

[0000833444-20-000015:mdna:117]
| • | The Company believes its capital resources and liquidity position at March 31, 2020 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, minimum pension contributions, debt maturities and any potential acquisitions or stock repurchases in the remainder of fiscal 2020 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company is unable to issue commercial paper, it would have the ability to draw on its $2.5 billion and $0.5 billion revolving credit facilities. The facilities mature in December 2024 and December 2020, respectively. There were no draws on the revolving credit facilities as of March 31, 2020 and September 30, 2019. In addition, the Company held cash and cash equivalents of $1.0 billion as of March 31, 2020. Given the increasingly uncertain economic environment caused by the COVID-19 pandemic, the Company has taken proactive measures in April 2020 to increase near-term financial flexibility, electing to opportunistically raise $675 million via European financing arrangements and $575 million in bank term loans. This new debt partially replaces a recently matured $500 million bond, which was repaid in March 2020. To further enhance liquidity resources, in March 2020 the Company made the decision to suspend its share repurchase program. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future. |

[0000833444-20-000015:mdna:118]
| • | The Company’s debt financial covenant in its revolving credit facility requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of March 31, 2020, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures, governing its notes, and expect to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating. |

[0000833444-20-000015:mdna:119]
| • | The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2020, the Company believes the long-term rate of return will approximate 6.90%, 5.20% and 5.70% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first six months of fiscal 2020, the Company made approximately $27 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $50 million in cash to its defined benefit pension plans in fiscal 2020. The Company expects to contribute $4 million in cash to its postretirement plans in fiscal 2020. |

[0000833444-20-000015:mdna:120]
[same as prior period, unchanged from 0000833444-20-000006:mdna:96]

[0000833444-20-000015:mdna:121]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2020 and recorded $111 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring |

[0000833444-20-000015:mdna:122]
55

[0000833444-20-000015:mdna:123]
action, the fiscal 2020 restructuring plan will reduce annual operating costs for continuing operations by approximately $80 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in 2021. For fiscal 2020, the savings, net of execution costs, are expected to be approximately 60% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in 2020. The restructuring plan reserve balance of $24 million at March 31, 2020 is expected to be paid in cash.

[0000833444-20-000015:mdna:124]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2018 and recorded $255 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2018 restructuring plan will reduce annual operating costs for continuing operations by approximately $300 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in 2020. The restructuring action is expected to be substantially complete in 2020. The restructuring plan reserve balance of $78 million at March 31, 2020 is expected to be paid in cash. |

[0000833444-20-000015:mdna:125]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2017 and recorded $347 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs for continuing operations by approximately $260 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company substantially realized the annual benefit of these actions in fiscal 2019. The restructuring actions are expected to be substantially complete in fiscal 2020. The restructuring plan reserve balance of $31 million at March 31, 2020 is expected to be paid in cash. |

[0000833444-20-000015:mdna:126]
[same as prior period, unchanged from 0000833444-20-000006:mdna:100]

[0000833444-20-000015:mdna:127]
[same as prior period, unchanged from 0000833444-20-000006:mdna:101]

[0000833444-20-000015:mdna:128]
[same as prior period, unchanged from 0000833444-20-000006:mdna:102]
