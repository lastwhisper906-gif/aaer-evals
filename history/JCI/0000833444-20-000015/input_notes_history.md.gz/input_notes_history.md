# JCI note change history — 0000833444-20-000006 → 0000833444-20-000015


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-01):
[0000833444-20-000015:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of March 31, 2020, reserves for environmental liabilities for continuing operations totaled $143 million, of which $52 million was recorded within other current liabilities and $91 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $159 million at September 30, 2019, of which $52 million was recorded within other current liabilities and $107 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.
  (was, 2020-01-31, similarity 0.9912):
[0000833444-20-000006:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of December 31, 2019, reserves for environmental liabilities for continuing operations totaled $151 million, of which $51 million was recorded within other current liabilities and $100 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $159 million at September 30, 2019, of which $52 million was recorded within other current liabilities and $107 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

- changed (2020-05-01):
[0000833444-20-000015:note_history:2]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.
  (was, 2020-01-31, similarity 0.8324):
[0000833444-20-000006:note_history:2]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in

- changed (2020-05-01):
[0000833444-20-000015:note_history:3]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers.  Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter.  The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).”  The WDNR issued a further letter regarding the issue on November 4, 2019.  In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area.  Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations.  The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.
  (was, 2020-01-31, similarity 0.7239):
[0000833444-20-000006:note_history:3]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers.  Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter.  The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).”  The WDNR issued a further letter regarding the issue on November 4, 2019.  Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations.  The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

- changed (2020-05-01):
[0000833444-20-000015:note_history:4]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At March 31, 2020 and September 30, 2019, the Company recorded conditional asset retirement obligations for continuing operations of $30 million.
  (was, 2020-01-31, similarity 0.9881):
[0000833444-20-000006:note_history:4]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At December 31, 2019 and September 30, 2019, the Company recorded conditional asset retirement obligations for continuing operations of $31 million and $30 million, respectively.

- added (2020-05-01):
[0000833444-20-000015:note_history:5]
As of March 31, 2020, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $165 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $498 million, of

- added (2020-05-01):
[0000833444-20-000015:note_history:6]
which $50 million was recorded in other current liabilities and $448 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $333 million, of which $62 million was recorded in other current assets, and $271 million was recorded in other noncurrent assets. Assets included $13 million of cash and $251 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at March 31, 2020 was $69 million. As of September 30, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $141 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $507 million, of which $50 million was recorded in other current liabilities and $457 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $366 million, of which $46 million was recorded in other current assets, and $320 million was recorded in other noncurrent assets. Assets included $16 million of cash and $273 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2019 was $77 million.

- changed (2020-05-01):
[0000833444-20-000015:note_history:7]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.
  (was, 2020-01-31, similarity 0.9517):
[0000833444-20-000006:note_history:7]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be

- changed (2020-05-01):
[0000833444-20-000015:note_history:8]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At March 31, 2020 and September 30, 2019, the insurable liabilities totaled $363 million and $379 million, respectively, of which $85 million and $99 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $256 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at March 31, 2020 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2019 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.
  (was, 2020-01-31, similarity 0.9906):
[0000833444-20-000006:note_history:8]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At December 31, 2019 and September 30, 2019, the insurable liabilities totaled $378 million and $379 million, respectively, of which $101 million and $99 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $255 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at December 31, 2019 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2019 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

- changed (2020-05-01):
[0000833444-20-000015:note_history:9]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but has stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.
  (was, 2020-01-31, similarity 0.9955):
[0000833444-20-000006:note_history:9]
Two of our subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but has stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

- changed (2020-05-01):
[0000833444-20-000015:note_history:10]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.
  (was, 2020-01-31, similarity 0.9701):
[0000833444-20-000006:note_history:10]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to the MDL.

- changed (2020-05-01):
[0000833444-20-000015:note_history:11]
Chemguard and Tyco Fire Products are named in 27 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, and Michigan. All but one of these cases has been transferred to the MDL, and it is anticipated that the newly filed Stengel case will be transferred. The following putative class actions were filed since the beginning of fiscal year 2020:
  (was, 2020-01-31, similarity 0.6213):
[0000833444-20-000006:note_history:11]
Chemguard and Tyco Fire Products are named in 24 putative class actions in federal and state courts in Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington New Hampshire, Guam, and Michigan. Each of these cases has been transferred to the MDL. The following putative class actions were filed since the beginning of fiscal year 2020:

- added (2020-05-01):
[0000833444-20-000015:note_history:12]
| • | County of Rockland [New York] et al. v. 3M Company et al., filed February 4, 2020, in the United States District Court, District of South Carolina. |

- added (2020-05-01):
[0000833444-20-000015:note_history:13]
| • | City of Millington et al. v. 3M Company et al., filed February 25, 2020, in the United States District Court, District of Columbia. |

- added (2020-05-01):
[0000833444-20-000015:note_history:14]
| • | Stengel et al. v. 3M Company et al., filed April 29, 2020, in the United States District Court for the Northern District of West Virginia. |

- added (2020-05-01):
[0000833444-20-000015:note_history:15]
There are approximately 585 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases), Pennsylvania (11 cases), New Mexico (2 cases) and South Carolina (527 cases direct filed from various U.S. jurisdictions) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania, two plaintiffs in New Mexico, and more than 500 plaintiffs from various states who direct-filed complaints in South Carolina.  These matters have been transferred to or directly-filed in the MDL.  Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court.  The Company anticipates that the remainder of the possible individual product liability claims filed in Pennsylvania state court will either soon be filed in the MDL (and that all such claims in state court will be dismissed accordingly) or will be dismissed in Pennsylvania without a corresponding filing in South Carolina.

- added (2020-05-01):
[0000833444-20-000015:note_history:16]
Chemguard and Tyco Fire Products are also defendants in 38 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, California, Colorado, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio, Pennsylvania and several municipalities or water providers from various states who direct-filed complaints in South Carolina.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  The following municipal actions were filed since the beginning of fiscal year 2020:

- added (2020-05-01):
[0000833444-20-000015:note_history:17]
| • | Fairbanks North Star Borough v. 3M Company, et al., filed January 31, 2020, in the MDL pending in the United States District Court, District of South Carolina. |

- added (2020-05-01):
[0000833444-20-000015:note_history:18]
| • | England Economic and Industrial Development District v. 3M Company et al., filed February 20, 2020, in the MDL pending in the United States District Court, District of South Carolina. |

- changed (2020-05-01):
[0000833444-20-000015:note_history:19]
State or U.S. Territory Attorneys General Litigation related to AFFF
  (was, 2020-01-31, similarity 0.8475):
[0000833444-20-000006:note_history:19]
State Attorneys General Litigation related to AFFF

- changed (2020-05-01):
[0000833444-20-000015:note_history:20]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.
  (was, 2020-01-31, similarity 0.9988):
[0000833444-20-000006:note_history:20]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al., No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

- changed (2020-05-01):
[0000833444-20-000015:note_history:21]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.
  (was, 2020-01-31, similarity 0.998):
[0000833444-20-000006:note_history:21]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

- changed (2020-05-01):
[0000833444-20-000015:note_history:22]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Group, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.
  (was, 2020-01-31, similarity 0.9686):
[0000833444-20-000006:note_history:22]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Group, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and tagged for transfer to the MDL.

- added (2020-05-01):
[0000833444-20-000015:note_history:23]
Other AFFF Matters

- added (2020-05-01):
[0000833444-20-000015:note_history:24]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington.  This case has been transferred to the MDL.

- changed (2020-05-01):
[0000833444-20-000015:note_history:25]
The Company is vigorously defending the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.
  (was, 2020-01-31, similarity 0.8463):
[0000833444-20-000006:note_history:25]
The Company is vigorously defending the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but

- removed (2020-05-01):
[0000833444-20-000006:note_history:26]
the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

- removed (2020-05-01):
[0000833444-20-000006:note_history:27]
As of December 31, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $132 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $502 million, of which $50 million was recorded in other current liabilities and $452 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $370 million, of which $42 million was recorded in other current assets, and $328 million was recorded in other noncurrent assets. Assets included $12 million of cash and $282 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at December 31, 2019 was $76 million. As of September 30, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $141 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $507 million, of which $50 million was recorded in other current liabilities and $457 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $366 million, of which $46 million was recorded in other current assets, and $320 million was recorded in other noncurrent assets. Assets included $16 million of cash and $273 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2019 was $77 million.

- removed (2020-05-01):
[0000833444-20-000006:note_history:28]
significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

- removed (2020-05-01):
[0000833444-20-000006:note_history:29]
There are approximately 152 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases), Pennsylvania (11 cases), New Mexico (2 cases) and South Carolina (94 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania, two plaintiffs in New Mexico, and approximately 100 plaintiffs from various states who direct-filed complaints in South Carolina.  These matters have been transferred to or directly-filed in the MDL.  The Company is also on notice of approximately 660 other possible individual product liability claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters in Pennsylvania.  Some of the individuals who filed claims in Pennsylvania state court filed individual complaints in the MDL in South Carolina (and dismissed their claims in Pennsylvania state court), and the Company anticipates that the rest will soon be filed in the MDL.

- removed (2020-05-01):
[0000833444-20-000006:note_history:30]
Chemguard and Tyco Fire Products are also defendants in 37 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, California, Colorado, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio, Pennsylvania, and South Carolina.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  All of these cases but one have been transferred to the MDL. The following municipal actions were filed since the beginning of fiscal year 2020:

- removed (2020-05-01):
[0000833444-20-000006:note_history:31]
there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-01):
[0000833444-20-000015:note_history:32]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2019 filed with the SEC on November 21, 2019. The results of operations for the three and six month periods ended March 31, 2020 are not necessarily indicative of results for the Company’s 2020 fiscal year because of seasonal and other factors.
  (was, 2020-01-31, similarity 0.9778):
[0000833444-20-000006:note_history:32]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2019 filed with the SEC on November 21, 2019. The results of operations for the three month period ended December 31, 2019 are not necessarily indicative of results for the Company’s 2020 fiscal year because of seasonal and other factors.

- changed (2020-05-01):
[0000833444-20-000015:note_history:33]
At March 31, 2020 and September 30, 2019, the Company held restricted cash of approximately $13 million and $16 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.
  (was, 2020-01-31, similarity 0.9793):
[0000833444-20-000006:note_history:33]
At December 31, 2019 and September 30, 2019, the Company held restricted cash of approximately $12 million and $16 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-01):
[0000833444-20-000015:note_history:34]
The Company's net financing charges line item in the consolidated statements of income for the three and six months ended March 31, 2020 and 2019 contained the following components (in millions):
  (was, 2020-01-31, similarity 0.9539):
[0000833444-20-000006:note_history:34]
The Company's net financing charges line item in the consolidated statements of income for the three months ended December 31, 2019 and 2018 contained the following components (in millions):

- changed (2020-05-01):
[0000833444-20-000015:note_history:35]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Interest expense, net of capitalized interest costs | $ | 62 |  |  | $ | 97 |  |  | $ | 124 |  |  | $ | 188 |  |
| Banking fees and bond cost amortization | 5 |  |  | 7 |  |  | 10 |  |  | 13 |  |
| Interest income | (5 | ) |  | (6 | ) |  | (18 | ) |  | (13 | ) |
| Net foreign exchange results for financing activities | (3 | ) |  | — |  |  | (5 | ) |  | (5 | ) |
| Net financing charges | $ | 59 |  |  | $ | 98 |  |  | $ | 111 |  |  | $ | 183 |  |
  (was, 2020-01-31, similarity 0.8047):
[0000833444-20-000006:note_history:35]
|  | Three Months Ended December 31, |
|  | 2019 |  | 2018 |
| Interest expense, net of capitalized interest costs | $ | 62 |  |  | $ | 91 |  |
| Banking fees and bond cost amortization | 5 |  |  | 6 |  |
| Interest income | (13 | ) |  | (7 | ) |
| Net foreign exchange results for financing activities | (2 | ) |  | (5 | ) |
| Net financing charges | $ | 52 |  |  | $ | 85 |  |

- added (2020-05-01):
[0000833444-20-000015:note_history:36]
In April 2020, the Company entered into various European financing arrangements totaling $675 million which are due in September 2020 and $575 million of bank term loans which are due in April 2021.

- added (2020-05-01):
[0000833444-20-000015:note_history:37]
In March 2020, the Company retired $500 million in principal amount, plus accrued interest, of its 5.0% fixed rate notes that expired in March 2020.

- changed (2020-05-01):
[0000833444-20-000015:note_history:38]
In December 2019, the Company entered into a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2020.  As of March 31, 2020, there were no draws on the facilities.
  (was, 2020-01-31, similarity 0.9788):
[0000833444-20-000006:note_history:38]
In December 2019, the Company entered into a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2020.  As of December 31, 2019, there were no draws on the facilities.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-05-01):
[0000833444-20-000015:note_history:39]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $38 million and $10 million, respectively, for the three months ended March 31, 2020; and $54 million and $16 million, respectively, for the three months ended March 31, 2019. The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $83 million and $22 million, respectively, for the six months ended March 31, 2020; and $97 million and $30 million, respectively, for the six months ended March 31, 2019.
  (was, 2020-01-31, similarity 0.6327):
[0000833444-20-000006:note_history:39]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $45 million and $12 million, respectively, for the three months ended December 31, 2019; and $43 million and $14 million, respectively, for the three months ended December 31, 2018.

- changed (2020-05-01):
[0000833444-20-000015:note_history:40]
|  |  | March 31, 2020 |  | September 30, 2019 |
| Receivable from related parties |  | $ | 37 |  |  | $ | 34 |  |
| Payable to related parties |  | 4 |  |  | 6 |  |
  (was, 2020-01-31, similarity 0.9619):
[0000833444-20-000006:note_history:40]
|  |  | December 31, 2019 |  | September 30, 2019 |  |
| Receivable from related parties |  | $ | 29 |  |  | $ | 34 |  |
| Payable to related parties |  | 6 |  |  | 6 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-05-01):
[0000833444-20-000015:note_history:41]
|  |  | March 31, 2020 |  | September 30, 2019 |
| Receivable from related parties |  | $ | 37 |  |  | $ | 34 |  |
| Payable to related parties |  | 4 |  |  | 6 |  |
  (was, 2020-01-31, similarity 0.9619):
[0000833444-20-000006:note_history:41]
|  |  | December 31, 2019 |  | September 30, 2019 |  |
| Receivable from related parties |  | $ | 29 |  |  | $ | 34 |  |
| Payable to related parties |  | 6 |  |  | 6 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-01):
[0000833444-20-000015:note_history:42]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and six months ended March 31, 2020 and 2019 (in millions):
  (was, 2020-01-31, similarity 0.9504):
[0000833444-20-000006:note_history:42]
The following table presents the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three months ended December 31, 2019 and 2018 (in millions):

- added (2020-05-01):
[0000833444-20-000015:note_history:43]
|  |  | Three Months Ended March 31, 2020 |  | Three Months Ended March 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,357 |  |  | $ | 818 |  |  | $ | 2,175 |  |  | $ | 1,387 |  |  | $ | 800 |  |  | $ | 2,187 |  |
| Building Solutions EMEA/LA |  | 400 |  |  | 450 |  |  | 850 |  |  | 416 |  |  | 462 |  |  | 878 |  |
| Building Solutions Asia Pacific |  | 271 |  |  | 254 |  |  | 525 |  |  | 351 |  |  | 277 |  |  | 628 |  |
| Global Products |  | 1,894 |  |  | — |  |  | 1,894 |  |  | 2,086 |  |  | — |  |  | 2,086 |  |
| Total |  | $ | 3,922 |  |  | $ | 1,522 |  |  | $ | 5,444 |  |  | $ | 4,240 |  |  | $ | 1,539 |  |  | $ | 5,779 |  |

- changed (2020-05-01):
[0000833444-20-000015:note_history:44]
|  |  | Six Months Ended March 31, 2020 |  | Six Months Ended March 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 2,713 |  |  | $ | 1,629 |  |  | $ | 4,342 |  |  | $ | 2,708 |  |  | $ | 1,595 |  |  | $ | 4,303 |  |
| Building Solutions EMEA/LA |  | 857 |  |  | 921 |  |  | 1,778 |  |  | 833 |  |  | 952 |  |  | 1,785 |  |
| Building Solutions Asia Pacific |  | 642 |  |  | 512 |  |  | 1,154 |  |  | 707 |  |  | 534 |  |  | 1,241 |  |
| Global Products |  | 3,746 |  |  | — |  |  | 3,746 |  |  | 3,914 |  |  | — |  |  | 3,914 |  |
| Total |  | $ | 7,958 |  |  | $ | 3,062 |  |  | $ | 11,020 |  |  | $ | 8,162 |  |  | $ | 3,081 |  |  | $ | 11,243 |  |
  (was, 2020-01-31, similarity 0.9116):
[0000833444-20-000006:note_history:44]
|  |  | Three Months Ended December 31, 2019 |  | Three Months Ended December 31, 2018 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,356 |  |  | $ | 811 |  |  | $ | 2,167 |  |  | $ | 1,321 |  |  | $ | 795 |  |  | $ | 2,116 |  |
| Building Solutions EMEA/LA |  | 457 |  |  | 471 |  |  | 928 |  |  | 417 |  |  | 490 |  |  | 907 |  |
| Building Solutions Asia Pacific |  | 371 |  |  | 258 |  |  | 629 |  |  | 356 |  |  | 257 |  |  | 613 |  |
| Global Products |  | 1,852 |  |  | — |  |  | 1,852 |  |  | 1,828 |  |  | — |  |  | 1,828 |  |
| Total |  | $ | 4,036 |  |  | $ | 1,540 |  |  | $ | 5,576 |  |  | $ | 3,922 |  |  | $ | 1,542 |  |  | $ | 5,464 |  |

- changed (2020-05-01):
[0000833444-20-000015:note_history:45]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and six months ended March 31, 2020 and 2019 (in millions):
  (was, 2020-01-31, similarity 0.9489):
[0000833444-20-000006:note_history:45]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2019 and 2018 (in millions):

- changed (2020-05-01):
[0000833444-20-000015:note_history:46]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Building management systems |  | $ | 316 |  |  | $ | 320 |  |  | $ | 616 |  |  | $ | 601 |  |
| HVAC & refrigeration equipment |  | 1,307 |  |  | 1,474 |  |  | 2,592 |  |  | 2,759 |  |
| Specialty products |  | 271 |  |  | 292 |  |  | 538 |  |  | 554 |  |
| Total |  | $ | 1,894 |  |  | $ | 2,086 |  |  | $ | 3,746 |  |  | $ | 3,914 |  |
  (was, 2020-01-31, similarity 0.75):
[0000833444-20-000006:note_history:46]
|  |  | Three Months Ended December 31, |
|  |  | 2019 |  | 2018 |
| Building management systems |  | $ | 300 |  |  | $ | 281 |  |
| HVAC & refrigeration equipment |  | 1,285 |  |  | 1,285 |  |
| Specialty products |  | 267 |  |  | 262 |  |
| Total |  | $ | 1,852 |  |  | $ | 1,828 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-01):
[0000833444-20-000015:note_history:47]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and six months ended March 31, 2020 and 2019 (in millions):
  (was, 2020-01-31, similarity 0.9504):
[0000833444-20-000006:note_history:47]
The following table presents the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three months ended December 31, 2019 and 2018 (in millions):

- added (2020-05-01):
[0000833444-20-000015:note_history:48]
|  |  | Three Months Ended March 31, 2020 |  | Three Months Ended March 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,357 |  |  | $ | 818 |  |  | $ | 2,175 |  |  | $ | 1,387 |  |  | $ | 800 |  |  | $ | 2,187 |  |
| Building Solutions EMEA/LA |  | 400 |  |  | 450 |  |  | 850 |  |  | 416 |  |  | 462 |  |  | 878 |  |
| Building Solutions Asia Pacific |  | 271 |  |  | 254 |  |  | 525 |  |  | 351 |  |  | 277 |  |  | 628 |  |
| Global Products |  | 1,894 |  |  | — |  |  | 1,894 |  |  | 2,086 |  |  | — |  |  | 2,086 |  |
| Total |  | $ | 3,922 |  |  | $ | 1,522 |  |  | $ | 5,444 |  |  | $ | 4,240 |  |  | $ | 1,539 |  |  | $ | 5,779 |  |

- changed (2020-05-01):
[0000833444-20-000015:note_history:49]
|  |  | Six Months Ended March 31, 2020 |  | Six Months Ended March 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 2,713 |  |  | $ | 1,629 |  |  | $ | 4,342 |  |  | $ | 2,708 |  |  | $ | 1,595 |  |  | $ | 4,303 |  |
| Building Solutions EMEA/LA |  | 857 |  |  | 921 |  |  | 1,778 |  |  | 833 |  |  | 952 |  |  | 1,785 |  |
| Building Solutions Asia Pacific |  | 642 |  |  | 512 |  |  | 1,154 |  |  | 707 |  |  | 534 |  |  | 1,241 |  |
| Global Products |  | 3,746 |  |  | — |  |  | 3,746 |  |  | 3,914 |  |  | — |  |  | 3,914 |  |
| Total |  | $ | 7,958 |  |  | $ | 3,062 |  |  | $ | 11,020 |  |  | $ | 8,162 |  |  | $ | 3,081 |  |  | $ | 11,243 |  |
  (was, 2020-01-31, similarity 0.9116):
[0000833444-20-000006:note_history:49]
|  |  | Three Months Ended December 31, 2019 |  | Three Months Ended December 31, 2018 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,356 |  |  | $ | 811 |  |  | $ | 2,167 |  |  | $ | 1,321 |  |  | $ | 795 |  |  | $ | 2,116 |  |
| Building Solutions EMEA/LA |  | 457 |  |  | 471 |  |  | 928 |  |  | 417 |  |  | 490 |  |  | 907 |  |
| Building Solutions Asia Pacific |  | 371 |  |  | 258 |  |  | 629 |  |  | 356 |  |  | 257 |  |  | 613 |  |
| Global Products |  | 1,852 |  |  | — |  |  | 1,852 |  |  | 1,828 |  |  | — |  |  | 1,828 |  |
| Total |  | $ | 4,036 |  |  | $ | 1,540 |  |  | $ | 5,576 |  |  | $ | 3,922 |  |  | $ | 1,542 |  |  | $ | 5,464 |  |

- changed (2020-05-01):
[0000833444-20-000015:note_history:50]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and six months ended March 31, 2020 and 2019 (in millions):
  (was, 2020-01-31, similarity 0.9489):
[0000833444-20-000006:note_history:50]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2019 and 2018 (in millions):

- changed (2020-05-01):
[0000833444-20-000015:note_history:51]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Building management systems |  | $ | 316 |  |  | $ | 320 |  |  | $ | 616 |  |  | $ | 601 |  |
| HVAC & refrigeration equipment |  | 1,307 |  |  | 1,474 |  |  | 2,592 |  |  | 2,759 |  |
| Specialty products |  | 271 |  |  | 292 |  |  | 538 |  |  | 554 |  |
| Total |  | $ | 1,894 |  |  | $ | 2,086 |  |  | $ | 3,746 |  |  | $ | 3,914 |  |
  (was, 2020-01-31, similarity 0.75):
[0000833444-20-000006:note_history:51]
|  |  | Three Months Ended December 31, |
|  |  | 2019 |  | 2018 |
| Building management systems |  | $ | 300 |  |  | $ | 281 |  |
| HVAC & refrigeration equipment |  | 1,285 |  |  | 1,285 |  |
| Specialty products |  | 267 |  |  | 262 |  |
| Total |  | $ | 1,852 |  |  | $ | 1,828 |  |

- added (2020-05-01):
[0000833444-20-000015:note_history:52]
|  |  | Location of contract balances |  | March 31, 2020 |  | September 30, 2019 |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,422 |  |  | $ | 1,389 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 95 |  |  | 90 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,600 | ) |  | (1,407 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (119 | ) |  | (117 | ) |
| Total |  |  |  | $ | (202 | ) |  | $ | (45 | ) |

- added (2020-05-01):
[0000833444-20-000015:note_history:53]
For the three months ended March 31, 2020 and March 31, 2019, the Company recognized revenue of $326 million and $214 million, respectively, that was included in the beginning of period contract liability balance. For the six months ended March 31, 2020 and March 31, 2019, the Company recognized revenue of $1,012 million and $926 million, respectively, that was included in the beginning of period contract liability balance.

- changed (2020-05-01):
[0000833444-20-000015:note_history:54]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of March 31, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.4 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.
  (was, 2020-01-31, similarity 0.9934):
[0000833444-20-000006:note_history:54]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of December 31, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.7 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

- changed (2020-05-01):
[0000833444-20-000015:note_history:55]
As of March 31, 2020, the Company recorded the costs to obtain or fulfill a contract of $228 million, of which $123 million is recorded within other current assets and $105 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2019, the Company recorded the costs to obtain or fulfill a contract of $212 million, of which $110 million is recorded within other current assets and $102 million is recorded within other noncurrent assets in the consolidated statements of financial position.
  (was, 2020-01-31, similarity 0.9879):
[0000833444-20-000006:note_history:55]
As of December 31, 2019, the Company recorded the costs to obtain or fulfill a contract of $236 million, of which $127 million is recorded within other current assets and $109 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2019, the Company recorded the costs to obtain or fulfill a contract of $212 million, of which $110 million is recorded within other current assets and $102 million is recorded within other noncurrent assets in the consolidated statements of financial position.

- added (2020-05-01):
[0000833444-20-000015:note_history:56]
During the three months ended March 31, 2020 and 2019, the Company recognized amortization expense of $43 million and $34 million, respectively, related to costs to obtain or fulfill a contract. During the six months ended March 31, 2020 and 2019, the Company recognized amortization expense of $69 million and $69 million, respectively, related to costs to obtain or fulfill a contract.  There were no impairment losses recognized in the three months ended March 31, 2020 and 2019.

- removed (2020-05-01):
[0000833444-20-000006:note_history:57]
|  |  | Location of contract balances |  | December 31, 2019 |  | September 30, 2019 |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,465 |  |  | $ | 1,389 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 99 |  |  | 90 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,495 | ) |  | (1,407 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (119 | ) |  | (117 | ) |
| Total |  |  |  | $ | (50 | ) |  | $ | (45 | ) |

- removed (2020-05-01):
[0000833444-20-000006:note_history:58]
For the three months ended December 31, 2019 and December 31, 2018, the Company recognized revenue of $686 million and $712 million, respectively, that was included in the beginning of period contract liability balance.

- removed (2020-05-01):
[0000833444-20-000006:note_history:59]
During the three months ended December 31, 2019 and 2018, the Company recognized amortization expense of $26 million and $35 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three months ended December 31, 2019 and 2018.
