# JCI 8-K — 0000833444-24-000049 filed 2024-07-31

## item codes, every 8-K on or before 2024-07-31

- 2024-07-31 0000833444-24-000049 — 2.02, 9.01
- 2024-07-26 0001193125-24-186281 — 1.01, 9.01
- 2024-07-23 0000833444-24-000044 — 2.02, 7.01, 9.01
- 2024-06-04 0001193125-24-154244 — 8.01, 9.01
- 2024-05-20 0000833444-24-000032 — 8.01, 9.01
- 2024-05-01 0000833444-24-000026 — 2.02, 9.01
- 2024-04-19 0001193125-24-102867 — 8.01, 9.01
- 2024-04-12 0000833444-24-000023 — 1.01, 8.01, 9.01
- 2024-03-18 0000833444-24-000020 — 5.07
- 2024-01-30 0000833444-24-000007 — 2.02, 9.01
- 2024-01-16 0000833444-24-000004 — 5.02, 9.01
- 2023-12-12 0000833444-23-000044 — 2.02, 9.01
- 2023-12-08 0000833444-23-000042 — 5.02
- 2023-11-13 0000833444-23-000038 — 8.01
- 2023-09-27 0000833444-23-000036 — 8.01
- 2023-09-08 0000833444-23-000033 — 5.02
- 2023-08-21 0001193125-23-217018 — 8.01, 9.01
- 2023-08-07 0001193125-23-205014 — 8.01, 9.01
- 2023-08-02 0000833444-23-000028 — 2.02, 9.01
- 2023-05-23 0001193125-23-151889 — 8.01, 9.01
- 2023-05-05 0000833444-23-000011 — 2.02, 9.01
- 2023-03-14 0000833444-23-000007 — 5.07
- 2023-02-01 0000833444-23-000003 — 2.02, 9.01
- 2022-12-22 0000833444-22-000047 — 5.02
- 2022-12-09 0000833444-22-000045 — 5.02
- 2022-11-03 0000833444-22-000038 — 2.02, 9.01
- 2022-09-14 0001193125-22-244741 — 8.01, 9.01
- 2022-09-07 0001193125-22-240030 — 8.01, 9.01
- 2022-08-04 0000833444-22-000034 — 2.02, 9.01
- 2022-07-06 0000833444-22-000029 — 5.02, 9.01
- 2022-06-30 0000833444-22-000027 — 5.02
- 2022-05-04 0000833444-22-000014 — 2.02, 9.01
- 2022-03-11 0001193125-22-073382 — 5.07
- 2022-02-15 0000833444-22-000010 — 5.02
- 2022-02-02 0000833444-22-000003 — 2.02, 9.01
- 2021-12-10 0000833444-21-000050 — 5.02
- 2021-11-05 0000833444-21-000043 — 2.02, 9.01
- 2021-09-16 0001193125-21-275152 — 1.01, 8.01, 9.01
- 2021-07-30 0000833444-21-000038 — 2.02, 9.01
- 2021-05-03 0000833444-21-000023 — 8.01
- 2021-04-30 0000833444-21-000017 — 2.02, 9.01
- 2021-03-11 0000833444-21-000013 — 5.02, 5.07, 9.01
- 2021-02-17 0001193125-21-045768 — 7.01, 9.01
- 2021-01-29 0000833444-21-000009 — 2.02, 9.01
- 2021-01-07 0000833444-21-000004 — 7.01
- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2024-07-31

- 2023-11-29 0000833444-23-000040 — NT 10-K, for the period ended 2023-09-30
- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-24-000049:8k_2_02:1]
EX-99.1
2
q3exh991xq3fy24earningsrel.htm
EX-99.1

[0000833444-24-000049:8k_2_02:2]
Document

[0000833444-24-000049:8k_2_02:3]
Exhibit 99.1

[0000833444-24-000049:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-24-000049:8k_2_02:5]
Johnson Controls Reports Solid Q3 Results; Tightens FY24 Guidance

[0000833444-24-000049:8k_2_02:6]
______________________________________________________________________________________

[0000833444-24-000049:8k_2_02:7]
▪Q3 reported sales increased 1% and 3% organically*

[0000833444-24-000049:8k_2_02:8]
▪Q3 GAAP EPS of $1.45; Q3 Adjusted EPS* of $1.14

[0000833444-24-000049:8k_2_02:9]
▪Q3 Orders +5% organically year-over-year

[0000833444-24-000049:8k_2_02:10]
▪Building Solutions backlog of $12.9 billion increased 10% organically year-over-year

[0000833444-24-000049:8k_2_02:11]
▪Initiates fiscal Q4 and updates full year fiscal 2024 guidance*

[0000833444-24-000049:8k_2_02:12]
*  This news release contains non-GAAP financial measures. Definitions and reconciliations of the non-GAAP financial measures can be found in the attached footnotes. Non-GAAP measures should be considered in addition to, and not as replacements for, the most comparable GAAP measures.

[0000833444-24-000049:8k_2_02:13]
_____________________________________________________________________________________

[0000833444-24-000049:8k_2_02:14]
CORK, Ireland — July 31, 2024 — Johnson Controls International plc (NYSE: JCI), a global leader for smart, healthy and sustainable buildings, today reported fiscal third quarter 2024 GAAP earnings per share (“EPS”) of $1.45. Excluding special items, adjusted EPS was $1.14.

[0000833444-24-000049:8k_2_02:15]
Sales in the quarter of $7.2 billion increased 1% over the prior year on an as reported basis and 3% organically. GAAP net income was $975 million. Adjusted net income was $769 million.

[0000833444-24-000049:8k_2_02:16]
“Our third quarter results exceeded expectations with robust margin expansion, strong free cash flow generation, and continued Service demand,” said George Oliver, Chairman and CEO. “We have increased our backlog to record levels, building on our strong momentum driving profitable growth. We have also tightened our full year adjusted EPS guidance to reflect our progress and confidence in Johnson Controls' prospects for continued growth and value creation. The announced divestitures of our R&LC HVAC and Air Distribution Technologies businesses, representing roughly 20% of sales, marked a pivotal milestone in our transformation into a pure-play provider of comprehensive solutions for commercial buildings and is a significant step to unlock value for our shareholders.”

[0000833444-24-000049:8k_2_02:17]
FISCAL Q3 SEGMENT RESULTS

[0000833444-24-000049:8k_2_02:18]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal third quarter of 2023.

[0000833444-24-000049:8k_2_02:19]
A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-24-000049:8k_2_02:20]
1

[0000833444-24-000049:8k_2_02:21]
Building Solutions North America

[0000833444-24-000049:8k_2_02:22]
|  |  | Fiscal Q3 |  |  |  |  |  |
| (in millions) |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |
| Sales |  | $ | 2,899 |  |  | $ | 2,665 |  |  | 9 | % |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 521 |  |  | 385 |  |  | 35 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 460 |  |  | 385 |  |  | 19 | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 18.0 | % |  | 14.4 | % |  | 360 | bp |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 15.9 | % |  | 14.4 | % |  | 150 | bp |  |  |  |  |  |

[0000833444-24-000049:8k_2_02:23]
Sales in the quarter of $2.9 billion increased 9% over the prior year. Organic sales increased 8% over the prior year led by growth greater than 20% in Applied HVAC & Controls.

[0000833444-24-000049:8k_2_02:24]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 5% year-over-year. Backlog at the end of the quarter of $9.0 billion increased 14% compared to the prior year, excluding M&A and adjusted for foreign currency.

[0000833444-24-000049:8k_2_02:25]
Segment EBITA margin of 18.0% expanded 360 basis points versus the prior year led by higher margin backlog conversion, improved productivity and a favorable earn-out liability adjustment. Adjusted segment EBITA in Q3 2024 excludes the favorable earn-out liability adjustment.

[0000833444-24-000049:8k_2_02:26]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-24-000049:8k_2_02:27]
|  |  | Fiscal Q3 |  |  |  |  |  |
| (in millions) |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |
| Sales |  | $ | 1,081 |  |  | $ | 1,045 |  |  | 3 | % |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 111 |  |  | 90 |  |  | 23 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 111 |  |  | 90 |  |  | 23 | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 10.3 | % |  | 8.6 | % |  | 170 | bp |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 10.3 | % |  | 8.6 | % |  | 170 | bp |  |  |  |  |  |

[0000833444-24-000049:8k_2_02:28]
Sales in the quarter of $1.1 billion increased 3% over the prior year. Organic sales grew 8% versus the prior year led by strong mid-teen growth in Service.

[0000833444-24-000049:8k_2_02:29]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 11% year-over-year. Backlog at the end of the quarter of $2.5 billion increased 12% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-24-000049:8k_2_02:30]
Segment EBITA margin of 10.3% expanded 170 basis points versus the prior year driven by the positive mix from the growth in Service and by the conversion of higher margin Systems backlog.

[0000833444-24-000049:8k_2_02:31]
2

[0000833444-24-000049:8k_2_02:32]
Building Solutions Asia Pacific

[0000833444-24-000049:8k_2_02:33]
|  |  | Fiscal Q3 |  |  |  |  |  |
| (in millions) |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |
| Sales |  | $ | 575 |  |  | $ | 736 |  |  | (22 | %) |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 67 |  |  | 102 |  |  | (34 | %) |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 67 |  |  | 102 |  |  | (34 | %) |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 11.7 | % |  | 13.9 | % |  | (220 | bp) |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 11.7 | % |  | 13.9 | % |  | (220 | bp) |  |  |  |  |  |

[0000833444-24-000049:8k_2_02:34]
Sales in the quarter of $575 million declined 22% versus the prior year. Organic sales declined 19% versus the prior year as high single-digit Service growth was more than offset by continued weakness in the Systems business in China.

[0000833444-24-000049:8k_2_02:35]
Orders in the quarter, excluding M&A and adjusted for foreign currency, declined 2% year-over-year. Backlog at the end of the quarter of $1.4 billion decreased 12% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-24-000049:8k_2_02:36]
Segment EBITA margin of 11.7% declined 220 basis points versus the prior year as weakness in China more than offset positive mix from the Service business.

[0000833444-24-000049:8k_2_02:37]
Global Products

[0000833444-24-000049:8k_2_02:38]
|  |  | Fiscal Q3 |  |  |  |  |  |
| (in millions) |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |
| Sales |  | $ | 2,676 |  |  | $ | 2,687 |  |  | — | % |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 655 |  |  | 593 |  |  | 10 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 655 |  |  | 593 |  |  | 10 | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 24.5 | % |  | 22.1 | % |  | 240 | bp |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 24.5 | % |  | 22.1 | % |  | 240 | bp |  |  |  |  |  |

[0000833444-24-000049:8k_2_02:39]
Sales in the quarter of $2.7 billion were flat versus the prior year. Organic sales grew 3% versus the prior year as growth in Commercial and Residential HVAC was offset by declines in Fire & Security.

[0000833444-24-000049:8k_2_02:40]
Segment EBITA margin of 24.5% expanded 240 basis points versus the prior year as positive price/cost and improved productivity more than offset mix headwinds from ongoing weakness in China.

[0000833444-24-000049:8k_2_02:41]
3

[0000833444-24-000049:8k_2_02:42]
Corporate

[0000833444-24-000049:8k_2_02:43]
|  |  | Fiscal Q3 |  |  |  |  |  |
| (in millions) |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |
| Corporate Expense |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 135 |  |  | $ | 122 |  |  | 11 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 119 |  |  | 78 |  |  | 53 | % |  |  |  |  |  |

[0000833444-24-000049:8k_2_02:44]
Adjusted Corporate expense in Q3 2024 and Q3 2023 exclude certain transaction/separation costs.

[0000833444-24-000049:8k_2_02:45]
OTHER Q3 ITEMS

[0000833444-24-000049:8k_2_02:46]
▪Cash provided by operating activities was $1.0 billion. Free cash flow was $922 million and adjusted free cash flow was $1.3 billion.

[0000833444-24-000049:8k_2_02:47]
▪The Company paid dividends of approximately $249 million.

[0000833444-24-000049:8k_2_02:48]
▪The Company repurchased 6.0 million shares of common stock for approximately $402 million.

[0000833444-24-000049:8k_2_02:49]
▪The Company recorded pre-tax restructuring and impairment costs of $106 million, comprised of impairments primarily associated with assets classified as held for sale ($66 million) and severance and other charges related to ongoing restructuring actions ($40 million).

[0000833444-24-000049:8k_2_02:50]
▪The Company recorded a pre-tax gain of $351 million related to insurance recoveries associated with the water provider Aqueous Film Forming Foam ("AFFF") settlement disclosed in Q2 2024.

[0000833444-24-000049:8k_2_02:51]
GUIDANCE

[0000833444-24-000049:8k_2_02:52]
The following forward-looking statements regarding organic sales growth, adjusted segment EBITA margin, adjusted segment EBITA margin improvement and adjusted EPS are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as mark-to-market adjustments. Organic revenue growth excludes the effect of acquisitions, divestitures and foreign currency. The Company is unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to its most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s fiscal 2024 fourth quarter and full year GAAP financial results.

[0000833444-24-000049:8k_2_02:53]
4

[0000833444-24-000049:8k_2_02:54]
The Company initiated fiscal 2024 fourth quarter guidance:

[0000833444-24-000049:8k_2_02:55]
▪Organic sales up ~7% year-over-year

[0000833444-24-000049:8k_2_02:56]
▪Adjusted segment EBITA margin of ~19.0%

[0000833444-24-000049:8k_2_02:57]
▪Adjusted EPS before special items of ~$1.23 to $1.26

[0000833444-24-000049:8k_2_02:58]
The Company tightened fiscal 2024 full year EPS guidance:

[0000833444-24-000049:8k_2_02:59]
▪Organic sales growth up ~3% year-over-year (previously Up ~MSD)

[0000833444-24-000049:8k_2_02:60]
▪Adjusted segment EBITA margin improvement of ~110 basis points, year-over-year (previously Up ~50 to 75 bps)

[0000833444-24-000049:8k_2_02:61]
▪Adjusted EPS before special items of ~$3.66 to $3.69 (previously ~$3.60 to $3.75)

[0000833444-24-000049:8k_2_02:62]
CONFERENCE CALL & WEBCAST INFO

[0000833444-24-000049:8k_2_02:63]
Johnson Controls will host a conference call to discuss this quarter’s results at 8:30 a.m. ET today, which can be accessed by dialing 844-763-8274 (in the United States) or +1-412-717-9224 (outside the United States), or via webcast. A slide presentation will accompany the prepared remarks and has been posted on the investor relations section of the Johnson Controls website at https://investors.johnsoncontrols.com/news-and-events/events-and-presentations. A replay will be made available approximately two hours following the conclusion of the conference call.

[0000833444-24-000049:8k_2_02:64]
ABOUT JOHNSON CONTROLS

[0000833444-24-000049:8k_2_02:65]
At Johnson Controls (NYSE:JCI), we transform the environments where people live, work, learn and play. As the global leader in smart, healthy and sustainable buildings, our mission is to reimagine the performance of buildings to serve people, places and the planet.

[0000833444-24-000049:8k_2_02:66]
Building on a proud history of nearly 140 years of innovation, we deliver the blueprint of the future for industries such as healthcare, schools, data centers, airports, stadiums, manufacturing and beyond through OpenBlue, our comprehensive digital offering.

[0000833444-24-000049:8k_2_02:67]
Today, with a global team of 100,000 experts in more than 150 countries, Johnson Controls offers the world`s largest portfolio of building technology and software as well as service solutions from some of the most trusted names in the industry.

[0000833444-24-000049:8k_2_02:68]
Visit www.johnsoncontrols.com for more information and follow @Johnson Controls on social platforms.

[0000833444-24-000049:8k_2_02:69]
5

[0000833444-24-000049:8k_2_02:70]
JOHNSON CONTROLS CONTACTS:

[0000833444-24-000049:8k_2_02:71]
| INVESTOR CONTACTS: | MEDIA CONTACT: |  |  |  |
| Jim Lucas | Danielle Canzanella |  |  |  |
| Direct: +1 414.340.1752 | Direct: +1 203.499.8297 |  |  |  |
| Email: jim.lucas@jci.com | Email: danielle.canzanella@jci.com |  |  |  |
| Michael Gates |  |  |  |  |
| Direct: +1 414.524.5785 |  |  |  |  |
| Email: michael.j.gates@jci.com |  |  |  |  |

[0000833444-24-000049:8k_2_02:72]
###

[0000833444-24-000049:8k_2_02:73]
JOHNSON CONTROLS INTERNATIONAL PLC CAUTIONARY STATEMENT REGARDING FORWARD-LOOKING STATEMENTS

[0000833444-24-000049:8k_2_02:74]
6

[0000833444-24-000049:8k_2_02:75]
successfully meet Johnson Controls public sustainability commitments; risks and uncertainties related to the settlement with a nationwide class of public water systems concerning the use of AFFF; the outcome of litigation and governmental proceedings; the risk of infringement or expiration of intellectual property rights; Johnson Controls ability to manage disruptions caused by catastrophic or geopolitical events, such as natural disasters, armed conflict, political change, climate change, pandemics and outbreaks of contagious diseases and other adverse public health developments; the ability of Johnson Controls to drive organizational improvement;  any delay or inability of Johnson Controls to realize the expected benefits and synergies of recent portfolio transactions; the ability to hire and retain senior management and other key personnel; the tax treatment of recent portfolio transactions; significant transaction costs and/or unknown liabilities associated with such transactions; labor shortages, work stoppages, union negotiations, labor disputes and other matters associated with the labor force; and the cancellation of or changes to commercial arrangements. A detailed discussion of risks related to Johnson Controls business is included in the section entitled “Risk Factors” in Johnson Controls Annual Report on Form 10-K for the fiscal year filed with the SEC, which is available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. The description of certain of these risks is supplemented in Item 1A of Part II of Johnson Controls subsequently filed Quarterly Reports on Form 10-Q. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-24-000049:8k_2_02:76]
###

[0000833444-24-000049:8k_2_02:77]
7

[0000833444-24-000049:8k_2_02:78]
FINANCIAL STATEMENTS

[0000833444-24-000049:8k_2_02:79]
Johnson Controls International plc

[0000833444-24-000049:8k_2_02:80]
Consolidated Statements of Income

[0000833444-24-000049:8k_2_02:81]
(in millions, except per share data; unaudited)

[0000833444-24-000049:8k_2_02:82]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales |  |  |  |  |  |  |  |
| Products and systems | $ | 5,422 |  |  | $ | 5,431 |  |  | $ | 14,896 |  |  | $ | 15,070 |  |
| Services | 1,809 |  |  | 1,702 |  |  | 5,128 |  |  | 4,817 |  |
|  | 7,231 |  |  | 7,133 |  |  | 20,024 |  |  | 19,887 |  |
| Cost of sales |  |  |  |  |  |  |  |
| Products and systems | 3,652 |  |  | 3,708 |  |  | 10,273 |  |  | 10,337 |  |
| Services | 1,091 |  |  | 994 |  |  | 3,090 |  |  | 2,787 |  |
|  | 4,743 |  |  | 4,702 |  |  | 13,363 |  |  | 13,124 |  |
| Gross profit | 2,488 |  |  | 2,431 |  |  | 6,661 |  |  | 6,763 |  |
| Selling, general and administrative expenses | 1,090 |  |  | 1,555 |  |  | 4,854 |  |  | 4,705 |  |
| Restructuring and impairment costs | 106 |  |  | 81 |  |  | 399 |  |  | 844 |  |
| Net financing charges | 71 |  |  | 80 |  |  | 263 |  |  | 218 |  |
| Equity income | 58 |  |  | 78 |  |  | 176 |  |  | 190 |  |
| Income before income taxes | 1,279 |  |  | 793 |  |  | 1,321 |  |  | 1,186 |  |
| Income tax provision (benefit) | 227 |  |  | (329) |  |  | 99 |  |  | (266) |  |
| Net income | 1,052 |  |  | 1,122 |  |  | 1,222 |  |  | 1,452 |  |
| Less: Income attributable to noncontrolling interests | 77 |  |  | 73 |  |  | 150 |  |  | 152 |  |
| Net income attributable to Johnson Controls | $ | 975 |  |  | $ | 1,049 |  |  | $ | 1,072 |  |  | $ | 1,300 |  |
| Earnings per share attributable to Johnson Controls |  |  |  |  |  |  |  |
| Basic | $ | 1.45 |  |  | $ | 1.54 |  |  | $ | 1.58 |  |  | $ | 1.90 |  |
| Diluted | 1.45 |  |  | 1.53 |  |  | 1.58 |  |  | 1.89 |  |

[0000833444-24-000049:8k_2_02:83]
8

[0000833444-24-000049:8k_2_02:84]
Johnson Controls International plc

[0000833444-24-000049:8k_2_02:85]
Condensed Consolidated Statements of Financial Position

[0000833444-24-000049:8k_2_02:86]
(in millions; unaudited)

[0000833444-24-000049:8k_2_02:87]
|  | June 30, 2024 |  | September 30, 2023 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 862 |  |  | $ | 835 |  |
| Accounts receivable - net | 6,667 |  |  | 6,006 |  |
| Inventories | 2,863 |  |  | 2,776 |  |
| Current assets held for sale | 205 |  |  | — |  |
| Other current assets | 1,556 |  |  | 1,120 |  |
| Current assets | 12,153 |  |  | 10,737 |  |
| Property, plant and equipment - net | 3,011 |  |  | 3,136 |  |
| Goodwill | 17,676 |  |  | 17,936 |  |
| Other intangible assets - net | 4,315 |  |  | 4,888 |  |
| Investments in partially-owned affiliates | 1,054 |  |  | 1,056 |  |
| Noncurrent assets held for sale | 487 |  |  | — |  |
| Other noncurrent assets | 4,629 |  |  | 4,489 |  |
| Total assets | $ | 43,325 |  |  | $ | 42,242 |  |
| Liabilities and Equity |  |  |  |
| Short-term debt | $ | 1,523 |  |  | $ | 385 |  |
| Current portion of long-term debt | 998 |  |  | 645 |  |
| Accounts payable | 4,128 |  |  | 4,268 |  |
| Accrued compensation and benefits | 1,012 |  |  | 958 |  |
| Deferred revenue | 2,143 |  |  | 1,996 |  |
| Current liabilities held for sale | 149 |  |  | — |  |
| Other current liabilities | 2,771 |  |  | 2,832 |  |
| Current liabilities | 12,724 |  |  | 11,084 |  |
| Long-term debt | 7,867 |  |  | 7,818 |  |
| Pension and postretirement benefits | 225 |  |  | 278 |  |
| Noncurrent liabilities held for sale | 203 |  |  | — |  |
| Other noncurrent liabilities | 5,163 |  |  | 5,368 |  |
| Long-term liabilities | 13,458 |  |  | 13,464 |  |
| Shareholders’ equity attributable to Johnson Controls | 15,968 |  |  | 16,545 |  |
| Noncontrolling interests | 1,175 |  |  | 1,149 |  |
| Total equity | 17,143 |  |  | 17,694 |  |
| Total liabilities and equity | $ | 43,325 |  |  | $ | 42,242 |  |

[0000833444-24-000049:8k_2_02:88]
9

[0000833444-24-000049:8k_2_02:89]
Johnson Controls International plc

[0000833444-24-000049:8k_2_02:90]
Consolidated Statements of Cash Flows

[0000833444-24-000049:8k_2_02:91]
(in millions; unaudited)

[0000833444-24-000049:8k_2_02:92]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income attributable to Johnson Controls | $ | 975 |  |  | $ | 1,049 |  |  | $ | 1,072 |  |  | $ | 1,300 |  |
| Income attributable to noncontrolling interests | 77 |  |  | 73 |  |  | 150 |  |  | 152 |  |
| Net income | 1,052 |  |  | 1,122 |  |  | 1,222 |  |  | 1,452 |  |
| Adjustments to reconcile net income to cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization | 220 |  |  | 212 |  |  | 687 |  |  | 621 |  |
| Pension and postretirement benefit income | (10) |  |  | (20) |  |  | (30) |  |  | (23) |  |
| Pension and postretirement contributions | (8) |  |  | (12) |  |  | (21) |  |  | (38) |  |
| Equity in (earnings) losses of partially-owned affiliates, net of dividends received | 104 |  |  | 28 |  |  | 2 |  |  | (27) |  |
| Deferred income taxes | 11 |  |  | (102) |  |  | (389) |  |  | (270) |  |
| Noncash restructuring and impairment charges | 80 |  |  | 10 |  |  | 333 |  |  | 701 |  |
| Equity-based compensation | 28 |  |  | — |  |  | 84 |  |  | 92 |  |
| Other - net | (87) |  |  | 14 |  |  | (125) |  |  | (104) |  |
| Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |  |  |  |
| Accounts receivable | (104) |  |  | (307) |  |  | (763) |  |  | (667) |  |
| Inventories | 13 |  |  | 110 |  |  | (215) |  |  | (383) |  |
| Other assets | (349) |  |  | (45) |  |  | (553) |  |  | (214) |  |
| Restructuring reserves | (19) |  |  | 50 |  |  | (79) |  |  | 33 |  |
| Accounts payable and accrued liabilities | 47 |  |  | 28 |  |  | 405 |  |  | (127) |  |
| Accrued income taxes | 43 |  |  | (275) |  |  | 14 |  |  | (215) |  |
| Cash provided by operating activities | 1,021 |  |  | 813 |  |  | 572 |  |  | 831 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Capital expenditures | (99) |  |  | (111) |  |  | (324) |  |  | (366) |  |
| Acquisition of businesses, net of cash acquired | — |  |  | (171) |  |  | 1 |  |  | (260) |  |
| Other - net | — |  |  | 20 |  |  | 13 |  |  | 50 |  |
| Cash used by investing activities | (99) |  |  | (262) |  |  | (310) |  |  | (576) |  |
| Financing Activities |  |  |  |  |  |  |  |
| Net proceeds (payments) from borrowings with maturities less than three months | (840) |  |  | (1,536) |  |  | 679 |  |  | (248) |  |
| Proceeds from debt | 859 |  |  | 855 |  |  | 1,281 |  |  | 1,171 |  |
| Repayments of debt | (275) |  |  | — |  |  | (438) |  |  | (536) |  |
| Stock repurchases and retirements | (402) |  |  | (366) |  |  | (876) |  |  | (613) |  |
| Payment of cash dividends | (249) |  |  | (248) |  |  | (753) |  |  | (729) |  |
| Employee equity-based compensation withholding taxes | (2) |  |  | (2) |  |  | (26) |  |  | (34) |  |
| Dividends paid to noncontrolling interests | (70) |  |  | (77) |  |  | (121) |  |  | (149) |  |
| Other - net | (20) |  |  | 1 |  |  | (68) |  |  | 27 |  |
| Cash used by financing activities | (999) |  |  | (1,373) |  |  | (322) |  |  | (1,111) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 10 |  |  | (75) |  |  | 29 |  |  | (67) |  |
| Decrease in cash, cash equivalents and restricted cash | (67) |  |  | (897) |  |  | (31) |  |  | (923) |  |
| Cash, cash equivalents and restricted cash at beginning of period | 960 |  |  | 2,040 |  |  | 924 |  |  | 2,066 |  |
| Cash, cash equivalents and restricted cash at end of period | 893 |  |  | 1,143 |  |  | 893 |  |  | 1,143 |  |
| Less: Restricted cash | 31 |  |  | 86 |  |  | 31 |  |  | 86 |  |
| Cash and cash equivalents at end of period | $ | 862 |  |  | $ | 1,057 |  |  | $ | 862 |  |  | $ | 1,057 |  |

[0000833444-24-000049:8k_2_02:93]
10

[0000833444-24-000049:8k_2_02:94]
FOOTNOTES

[0000833444-24-000049:8k_2_02:95]
1.Non-GAAP Measures

[0000833444-24-000049:8k_2_02:96]
The Company reports various non-GAAP measures in this earnings release and the related earnings presentation.  Non-GAAP measures should be considered in addition to, and not as replacements for, the most comparable GAAP measures. Refer to footnotes two through seven for further information on the calculations of the non-GAAP measures and reconciliations of the non-GAAP measures to the most comparable GAAP measures.

[0000833444-24-000049:8k_2_02:97]
Organic sales

[0000833444-24-000049:8k_2_02:98]
Organic sales growth excludes the impact of acquisitions, divestitures and foreign currency. Management believes organic sales growth is useful to investors in understanding period-over-period sales results and trends.

[0000833444-24-000049:8k_2_02:99]
Cash flow

[0000833444-24-000049:8k_2_02:100]
Adjusted free cash flow and adjusted free cash flow conversion are non-GAAP measures which exclude the impacts of the following:

[0000833444-24-000049:8k_2_02:101]
•JC Capital cash flows primarily include activity associated with finance/notes receivables and inventory and/or capital expenditures related to lease arrangements. JC Capital net income is primarily related to interest income on the finance/notes receivable and profit recognized on arrangements with sales-type lease components.

[0000833444-24-000049:8k_2_02:102]
•Effective January 1, 2024, the Company has excluded the impact of discontinuing its accounts receivables factoring programs from adjusted free cash flow and adjusted free cash flow conversion. The Company has also re-baselined the prior year adjusted free cash flow measures to present a more comparative measure without the impact of factoring.

[0000833444-24-000049:8k_2_02:103]
•Cash impacts of the water systems AFFF settlement and related insurance recoveries.

[0000833444-24-000049:8k_2_02:104]
Management believes free cash flow and adjusted free cash flow measures are useful to investors in understanding the strength of the Company and its ability to generate cash. These non-GAAP measures can also be used to evaluate the Company’s ability to generate cash flow from operations and the impact that this cash flow has on its liquidity. Management also believes adjusted free cash flows are useful to investors in understanding period-over-period cash flows, cash trends and ongoing cash flows of the Company.

[0000833444-24-000049:8k_2_02:105]
Adjusted financial measures

[0000833444-24-000049:8k_2_02:106]
Adjusted financial measures include adjusted segment EBITA, adjusted net income, adjusted earnings per share, adjusted EBIT, adjusted EBITDA and adjusted corporate expenses. These non-GAAP measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the excluded amounts is a matter of management judgment and depends upon the nature and variability of the underlying expense or income amounts and other factors.

[0000833444-24-000049:8k_2_02:107]
As detailed in the tables included in footnotes four through seven, the following items were excluded from certain financial measures:

[0000833444-24-000049:8k_2_02:108]
•Net mark-to-market adjustments are the result of adjusting restricted asbestos investments and pension and postretirement plan assets to their current market value. These adjustments may have a favorable or unfavorable impact on results.

[0000833444-24-000049:8k_2_02:109]
•Restructuring and impairment costs - Restructuring costs include costs associated with exit plans or other restructuring plans that will have a more significant impact on the underlying cost structure of the organization. Impairment costs primarily relate to write-downs of goodwill, intangible assets and assets held for sale to their fair value.

[0000833444-24-000049:8k_2_02:110]
•NCI impact of restructuring and impairment costs represent the portion of restructuring and impairment costs attributable to Noncontrolling Interests.

[0000833444-24-000049:8k_2_02:111]
11

[0000833444-24-000049:8k_2_02:112]
•Water systems AFFF settlement and insurance recoveries include amounts related to a settlement with a nationwide class of public water systems concerning the use of AFFF manufactured and sold by a subsidiary of the Company.

[0000833444-24-000049:8k_2_02:113]
•Transaction/separation costs include costs associated with significant mergers and acquisitions.

[0000833444-24-000049:8k_2_02:114]
•Earn-out adjustments relate to earn-out liabilities associated with certain significant acquisitions and may have a favorable or unfavorable impact on results.

[0000833444-24-000049:8k_2_02:115]
•Warehouse fire loss relates to an uninsured loss attributable to a fire at a warehouse in Menominee, Michigan.

[0000833444-24-000049:8k_2_02:116]
•Cyber incident costs primarily represent expenses, net of insurance recoveries, associated with the response to, and remediation of, a cybersecurity incident which occurred in September 2023.

[0000833444-24-000049:8k_2_02:117]
•Global products product quality issue are costs related to a product quality issue within the Global Products segment that is unusual due to the magnitude of the expected cost to remediate in comparison to typical product quality issues experienced by the Company.

[0000833444-24-000049:8k_2_02:118]
•Related tax impact includes the tax impact of the various excluded items.

[0000833444-24-000049:8k_2_02:119]
Management believes the exclusion of these items is useful to investors due to the unusual nature and/or magnitude of the amounts. When considered together with unadjusted amounts, adjusted financial measures are useful to investors in understanding period-over-period operating results, business trends and ongoing operations of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes.

[0000833444-24-000049:8k_2_02:120]
Debt ratios

[0000833444-24-000049:8k_2_02:121]
Management believes that net debt to adjusted EBITDA, a non-GAAP measure, is useful to understanding the Company's financial condition as the ratio provides an overview of the extent to which the Company relies on external debt financing for its funding and also is a measure of risk to its shareholders.

[0000833444-24-000049:8k_2_02:122]
12

[0000833444-24-000049:8k_2_02:123]
2. Sales

[0000833444-24-000049:8k_2_02:124]
The following tables detail the changes in sales attributable to organic growth, foreign currency, acquisitions, divestitures and other (unaudited):

[0000833444-24-000049:8k_2_02:125]
|  | Three Months Ended June 30 |
| Net sales | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Net sales - 2023 | $ | 2,665 |  |  | $ | 1,045 |  |  | $ | 736 |  |  | $ | 4,446 |  |  | $ | 2,687 |  |  | $ | 7,133 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | (1) |  |  | (17) |  |  | (18) |  |  | (7) |  |  | (25) |  |
| Foreign currency | 2 |  |  | (46) |  |  | (25) |  |  | (69) |  |  | (80) |  |  | (149) |  |
| Adjusted base net sales | 2,667 |  |  | 998 |  |  | 694 |  |  | 4,359 |  |  | 2,600 |  |  | 6,959 |  |
| Acquisitions | 16 |  |  | 1 |  |  | 15 |  |  | 32 |  |  | — |  |  | 32 |  |
| Organic growth | 216 |  |  | 82 |  |  | (134) |  |  | 164 |  |  | 76 |  |  | 240 |  |
| Net sales - 2024 | $ | 2,899 |  |  | $ | 1,081 |  |  | $ | 575 |  |  | $ | 4,555 |  |  | $ | 2,676 |  |  | $ | 7,231 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | 9 | % |  | 3 | % |  | (22 | %) |  | 2 | % |  | — | % |  | 1 | % |
| Organic growth | 8 | % |  | 8 | % |  | (19 | %) |  | 4 | % |  | 3 | % |  | 3 | % |

[0000833444-24-000049:8k_2_02:126]
|  | Nine Months Ended June 30 |
| Net sales | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Net sales - 2023 | $ | 7,552 |  |  | $ | 3,051 |  |  | $ | 2,049 |  |  | $ | 12,652 |  |  | $ | 7,235 |  |  | $ | 19,887 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | (3) |  |  | (51) |  |  | (54) |  |  | (12) |  |  | (66) |  |
| Foreign currency | 15 |  |  | (8) |  |  | (68) |  |  | (61) |  |  | (144) |  |  | (205) |  |
| Adjusted base net sales | 7,567 |  |  | 3,040 |  |  | 1,930 |  |  | 12,537 |  |  | 7,079 |  |  | 19,616 |  |
| Acquisitions | 48 |  |  | 7 |  |  | 51 |  |  | 106 |  |  | 29 |  |  | 135 |  |
| Organic growth | 510 |  |  | 136 |  |  | (408) |  |  | 238 |  |  | 35 |  |  | 273 |  |
| Net sales - 2024 | $ | 8,125 |  |  | $ | 3,183 |  |  | $ | 1,573 |  |  | $ | 12,881 |  |  | $ | 7,143 |  |  | $ | 20,024 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | 8 | % |  | 4 | % |  | (23 | %) |  | 2 | % |  | (1 | %) |  | 1 | % |
| Organic growth | 7 | % |  | 4 | % |  | (21 | %) |  | 2 | % |  | — | % |  | 1 | % |

[0000833444-24-000049:8k_2_02:127]
13

[0000833444-24-000049:8k_2_02:128]
|  | Three Months Ended June 30 |
| Products and systems revenue | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Products and systems revenue - 2023 | $ | 1,636 |  |  | $ | 571 |  |  | $ | 537 |  |  | $ | 2,744 |  |  | $ | 2,687 |  |  | $ | 5,431 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | — |  |  | — |  |  | — |  |  | (7) |  |  | (7) |  |
| Foreign currency | 2 |  |  | (12) |  |  | (18) |  |  | (28) |  |  | (80) |  |  | (108) |  |
| Adjusted products and systems revenue | 1,638 |  |  | 559 |  |  | 519 |  |  | 2,716 |  |  | 2,600 |  |  | 5,316 |  |
| Acquisitions | 2 |  |  | 1 |  |  | 10 |  |  | 13 |  |  | — |  |  | 13 |  |
| Organic growth | 150 |  |  | 15 |  |  | (148) |  |  | 17 |  |  | 76 |  |  | 93 |  |
| Products and systems revenue - 2024 | $ | 1,790 |  |  | $ | 575 |  |  | $ | 381 |  |  | $ | 2,746 |  |  | $ | 2,676 |  |  | $ | 5,422 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Products and systems revenue | 9 | % |  | 1 | % |  | (29 | %) |  | — | % |  | — | % |  | — | % |
| Organic growth | 9 | % |  | 3 | % |  | (29 | %) |  | 1 | % |  | 3 | % |  | 2 | % |

[0000833444-24-000049:8k_2_02:129]
|  | Nine Months Ended June 30 |
| Products and systems revenue | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Products and systems revenue - 2023 | $ | 4,641 |  |  | $ | 1,705 |  |  | $ | 1,489 |  |  | $ | 7,835 |  |  | $ | 7,235 |  |  | $15,070 |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | (1) |  |  | — |  |  | (1) |  |  | (12) |  |  | (13) |  |
| Foreign currency | 14 |  |  | 35 |  |  | (51) |  |  | (2) |  |  | (144) |  |  | (146) |  |
| Adjusted products and systems revenue | 4,655 |  |  | 1,739 |  |  | 1,438 |  |  | 7,832 |  |  | 7,079 |  |  | 14,911 |  |
| Acquisitions | 5 |  |  | 4 |  |  | 30 |  |  | 39 |  |  | 29 |  |  | 68 |  |
| Organic growth | 349 |  |  | (25) |  |  | (442) |  |  | (118) |  |  | 35 |  |  | (83) |  |
| Products and systems revenue - 2024 | $ | 5,009 |  |  | $ | 1,718 |  |  | $ | 1,026 |  |  | $ | 7,753 |  |  | $ | 7,143 |  |  | $ | 14,896 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Products and systems revenue | 8 | % |  | 1 | % |  | (31 | %) |  | (1 | %) |  | (1 | %) |  | (1 | %) |
| Organic growth | 7 | % |  | (1 | %) |  | (31 | %) |  | (2 | %) |  | — | % |  | (1 | %) |

[0000833444-24-000049:8k_2_02:130]
14

[0000833444-24-000049:8k_2_02:131]
|  | Three Months Ended June 30 |
| Service revenue | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Service revenue - 2023 | $ | 1,029 |  |  | $ | 474 |  |  | $ | 199 |  |  | $ | 1,702 |  |  | $ | — |  |  | $ | 1,702 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | (1) |  |  | (17) |  |  | (18) |  |  | — |  |  | (18) |  |
| Foreign currency | — |  |  | (34) |  |  | (7) |  |  | (41) |  |  | — |  |  | (41) |  |
| Adjusted base service revenue | 1,029 |  |  | 439 |  |  | 175 |  |  | 1,643 |  |  | — |  |  | 1,643 |  |
| Acquisitions | 14 |  |  | — |  |  | 5 |  |  | 19 |  |  | — |  |  | 19 |  |
| Organic growth | 66 |  |  | 67 |  |  | 14 |  |  | 147 |  |  | — |  |  | 147 |  |
| Service revenue - 2024 | $ | 1,109 |  |  | $ | 506 |  |  | $ | 194 |  |  | $ | 1,809 |  |  | $ | — |  |  | $ | 1,809 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Service revenue | 8 | % |  | 7 | % |  | (3 | %) |  | 6 | % |  | — | % |  | 6 | % |
| Organic growth | 6 | % |  | 15 | % |  | 8 | % |  | 9 | % |  | — | % |  | 9 | % |

[0000833444-24-000049:8k_2_02:132]
|  | Nine Months Ended June 30 |
| Service revenue | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Service revenue - 2023 | $ | 2,911 |  |  | $ | 1,346 |  |  | $ | 560 |  |  | $ | 4,817 |  |  | $ | — |  |  | $ | 4,817 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | (2) |  |  | (51) |  |  | (53) |  |  | — |  |  | (53) |  |
| Foreign currency | 1 |  |  | (43) |  |  | (17) |  |  | (59) |  |  | — |  |  | (59) |  |
| Adjusted base service revenue | 2,912 |  |  | 1,301 |  |  | 492 |  |  | 4,705 |  |  | — |  |  | 4,705 |  |
| Acquisitions | 43 |  |  | 3 |  |  | 21 |  |  | 67 |  |  | — |  |  | 67 |  |
| Organic growth | 161 |  |  | 161 |  |  | 34 |  |  | 356 |  |  | — |  |  | 356 |  |
| Service revenue - 2024 | $ | 3,116 |  |  | $ | 1,465 |  |  | $ | 547 |  |  | $ | 5,128 |  |  | $ | — |  |  | $ | 5,128 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Service revenue | 7 | % |  | 9 | % |  | (2 | %) |  | 6 | % |  | — | % |  | 6 | % |
| Organic growth | 6 | % |  | 12 | % |  | 7 | % |  | 8 | % |  | — | % |  | 8 | % |

[0000833444-24-000049:8k_2_02:133]
15

[0000833444-24-000049:8k_2_02:134]
3.   Cash Flow, Free Cash Flow and Free Cash Flow Conversion

[0000833444-24-000049:8k_2_02:135]
The following table includes free cash flow and free cash flow conversion (unaudited):

[0000833444-24-000049:8k_2_02:136]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cash provided by operating activities | $ | 1,021 |  | $ | 813 |  | $ | 572 |  | $ | 831 |  |
| Capital expenditures | (99) |  | (111) |  | (324) |  | (366) |  |
| Free cash flow (non-GAAP) | $ | 922 |  | $ | 702 |  | $ | 248 |  | $ | 465 |  |
| Net income attributable to JCI | $ | 975 |  | $ | 1,049 |  | $ | 1,072 |  | $ | 1,300 |  |
| Free cash flow conversion from net income (non-GAAP) | 95% |  | 67% |  | 23 | % |  | 36 | % |  |

[0000833444-24-000049:8k_2_02:137]
The following table includes adjusted free cash flow and adjusted free cash flow conversion (unaudited):

[0000833444-24-000049:8k_2_02:138]
|  | Three Months Ended June 30, |  | Nine Months EndedJune 30, |
| (in millions) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Free cash flow (non-GAAP) | $ | 922 |  | $ | 702 |  | $ | 248 |  | $ | 465 |
| Adjustments: |  |  |  |  |  |  |  |
| JC Capital cash used by operating activities | 49 |  | 39 |  | 170 |  | 81 |
| Water systems AFFF settlement cash payments and insurance recoveries | 243 |  | — |  | 243 |  | — |
| Impact from discontinuation of factoring programs | 49 |  | — |  | 648 |  | — |
| Adjusted free cash flow (non-GAAP) | 1,263 |  | 741 |  | 1,309 |  | 546 |
| Prior year impact from factoring programs | — |  | 5 |  | — |  | 79 |
| Re-baselined adjusted free cash flow (non-GAAP) | $ | 1,263 |  | $ | 746 |  | $ | 1,309 |  | $ | 625 |
| Adjusted net income attributable to JCI (non-GAAP) | $ | 769 |  | $ | 706 |  | $ | 1,652 |  | $ | 1,686 |
| JC Capital net income | (3) |  | (4) |  | (8) |  | (12) |
| Adjusted net income attributable to JCI, excluding JC Capital (non-GAAP) | $ | 766 |  | $ | 702 |  | $ | 1,644 |  | $ | 1,674 |
| Adjusted free cash flow conversion (non-GAAP) | 165% |  | 106% |  | 80% |  | 37 | % |

[0000833444-24-000049:8k_2_02:139]
16

[0000833444-24-000049:8k_2_02:140]
4. EBITA, EBIT and Corporate Expense

[0000833444-24-000049:8k_2_02:141]
The Company evaluates the performance of its business units primarily on segment EBITA.

[0000833444-24-000049:8k_2_02:142]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | Actual |  | Adjusted(Non-GAAP) |  | Actual |  | Adjusted(Non-GAAP) |
| (in millions; unaudited) | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 521 |  |  | $ | 385 |  |  | $ | 460 |  |  | $ | 385 |  |  | $ | 1,179 |  |  | $ | 967 |  |  | $ | 1,118 |  |  | $ | 967 |  |
| Building Solutions EMEA/LA | 111 |  |  | 90 |  | 111 |  |  | 90 |  |  | 280 |  |  | 234 |  |  | 280 |  |  | 234 |  |
| Building Solutions Asia Pacific | 67 |  |  | 102 |  | 67 |  |  | 102 |  |  | 167 |  |  | 249 |  |  | 167 |  |  | 249 |  |
| Global Products | 655 |  |  | 593 |  |  | 655 |  |  | 593 |  |  | 1,453 |  |  | 1,463 |  |  | 1,479 |  |  | 1,473 |  |
| EBIT (non-GAAP) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to JCI | $ | 975 |  |  | $ | 1,049 |  |  | $ | 769 |  |  | $ | 706 |  |  | $ | 1,072 |  |  | $ | 1,300 |  |  | $ | 1,652 |  |  | $ | 1,686 |  |
| Income attributable to noncontrolling interests (1) | 77 |  |  | 73 |  |  | 79 |  |  | 73 |  |  | 150 |  |  | 152 |  |  | 156 |  |  | 152 |  |
| Net income | 1,052 |  |  | 1,122 |  |  | 848 |  |  | 779 |  |  | 1,222 |  |  | 1,452 |  |  | 1,808 |  |  | 1,838 |  |
| Less: Income tax benefit (provision) (2) | 227 |  |  | (329) |  |  | 136 |  |  | 122 |  |  | 99 |  |  | (266) |  |  | 289 |  |  | 287 |  |
| Income before income taxes | 1,279 |  |  | 793 |  |  | 984 |  |  | 901 |  |  | 1,321 |  |  | 1,186 |  |  | 2,097 |  |  | 2,125 |  |
| Net financing charges | 71 |  |  | 80 |  |  | 71 |  |  | 80 |  |  | 263 |  |  | 218 |  |  | 263 |  |  | 218 |  |
| EBIT (non-GAAP) | $ | 1,350 |  |  | $ | 873 |  |  | $ | 1,055 |  |  | $ | 981 |  |  | $ | 1,584 |  |  | $ | 1,404 |  |  | $ | 2,360 |  |  | $ | 2,343 |  |

[0000833444-24-000049:8k_2_02:143]
(1) Adjusted income attributable to noncontrolling interests excludes the impact of restructuring and impairment costs.

[0000833444-24-000049:8k_2_02:144]
(2) Adjusted income tax benefit (provision) excludes the related tax impacts of pre-tax adjusting items.

[0000833444-24-000049:8k_2_02:145]
The following tables reconcile segment EBITA to adjusted segment EBITA (unaudited):

[0000833444-24-000049:8k_2_02:146]
|  | Three Months Ended June 30, |
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building SolutionsAsia Pacific |  | Global Products |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Segment EBITA | $ | 521 |  |  | $ | 385 |  |  | $ | 111 |  |  | $ | 90 |  |  | $ | 67 |  |  | $ | 102 |  |  | $ | 655 |  |  | $ | 593 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Earn-out adjustments | (61) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted segment EBITA(non-GAAP) | $ | 460 |  |  | $ | 385 |  |  | $ | 111 |  |  | $ | 90 |  |  | $ | 67 |  |  | $ | 102 |  |  | $ | 655 |  |  | $ | 593 |  |

[0000833444-24-000049:8k_2_02:147]
17

[0000833444-24-000049:8k_2_02:148]
|  | Nine Months Ended June 30, |
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building SolutionsAsia Pacific |  | Global Products |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Segment EBITA | $ | 1,179 |  |  | $ | 967 |  |  | $ | 280 |  |  | $ | 234 |  |  | $ | 167 |  |  | $ | 249 |  |  | $ | 1,453 |  |  | $ | 1,463 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Earn-out adjustments | (61) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (7) |  |  | (30) |  |
| Uninsured warehouse fire loss | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 40 |  |
| Global Products product quality issue | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 33 |  |  | — |  |
| Adjusted segment EBITA(non-GAAP) | $ | 1,118 |  |  | $ | 967 |  |  | $ | 280 |  |  | $ | 234 |  |  | $ | 167 |  |  | $ | 249 |  |  | $ | 1,479 |  |  | $ | 1,473 |  |

[0000833444-24-000049:8k_2_02:149]
The following table reconciles Corporate expense as reported to the comparable adjusted amounts (unaudited):

[0000833444-24-000049:8k_2_02:150]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Corporate expense (GAAP) | $ | 135 |  |  | $ | 122 |  |  | $ | 373 |  |  | $ | 362 |  |
|  |  |  |  |  | . |  |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction/separation costs | (16) |  |  | (44) |  |  | (28) |  |  | (101) |  |
| Cyber incident costs | — |  |  | — |  |  | (27) |  |  | — |  |
| Adjusted corporate expense (non-GAAP) | $ | 119 |  |  | $ | 78 |  |  | $ | 318 |  |  | $ | 261 |  |

[0000833444-24-000049:8k_2_02:151]
18

[0000833444-24-000049:8k_2_02:152]
5.  Net Income and Diluted Earnings Per Share

[0000833444-24-000049:8k_2_02:153]
The following tables reconcile net income attributable to JCI and diluted earnings per share as reported to the comparable adjusted amounts (unaudited):

[0000833444-24-000049:8k_2_02:154]
|  | Three Months Ended June 30, |
|  | Net income attributable to JCI |  | Diluted earnings per share |
| (in millions, except per share) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| As reported (GAAP) | $ | 975 |  |  | $ | 1,049 |  |  | $ | 1.45 |  |  | $ | 1.53 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (5) |  |  | (17) |  |  | (0.01) |  |  | (0.02) |  |
| Restructuring and impairment costs | 106 |  |  | 81 |  |  | 0.16 |  |  | 0.12 |  |
| NCI impact of restructuring and impairment costs | (2) |  |  | — |  |  | — |  |  | — |  |
| Water systems AFFF insurance recoveries | (351) |  |  | — |  |  | (0.52) |  |  | — |  |
| Transaction/separation costs | 16 |  |  | 44 |  |  | 0.02 |  |  | 0.06 |  |
| Earn-out adjustments | (61) |  |  | — |  |  | (0.09) |  |  | — |  |
| Discrete tax items | — |  |  | (438) |  |  | — |  |  | (0.64) |  |
| Related tax impact | 91 |  |  | (13) |  |  | 0.14 |  |  | (0.02) |  |
| Adjusted (non-GAAP)* | $ | 769 |  |  | $ | 706 |  |  | $ | 1.14 |  |  | $ | 1.03 |  |

[0000833444-24-000049:8k_2_02:155]
* May not sum due to rounding

[0000833444-24-000049:8k_2_02:156]
|  | Nine Months Ended June 30, |
|  | Net income attributable to JCI |  | Diluted earningsper share |
| (in millions, except per share) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| As reported (GAAP) | $ | 1,072 |  |  | $ | 1,300 |  |  | $ | 1.58 |  |  | $ | 1.89 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (42) |  |  | (16) |  |  | (0.06) |  |  | (0.02) |  |
| Restructuring and impairment costs | 399 |  |  | 844 |  |  | 0.59 |  |  | 1.23 |  |
| NCI impact of restructuring and impairment costs | (6) |  |  | — |  |  | (0.01) |  |  | — |  |
| Water systems AFFF settlement | 750 |  |  | — |  |  | 1.11 |  |  | — |  |
| Water systems AFFF insurance recoveries | (351) |  |  | — |  |  | (0.52) |  |  | — |  |
| Transaction/separation costs | 28 |  |  | 101 |  |  | 0.04 |  |  | 0.15 |  |
| Earn-out adjustments | (68) |  |  | (30) |  |  | (0.10) |  |  | (0.04) |  |
| Warehouse fire loss | — |  |  | 40 |  |  | — |  |  | 0.06 |  |
| Cyber incident costs | 27 |  |  | — |  |  | 0.04 |  |  | — |  |
| Global Products product quality issue | 33 |  |  | — |  |  | 0.05 |  |  | — |  |
| Discrete tax items | — |  |  | (438) |  |  | — |  |  | (0.64) |  |
| Related tax impact | (190) |  |  | (115) |  |  | (0.28) |  |  | (0.17) |  |
| Adjusted (non-GAAP)* | $ | 1,652 |  |  | $ | 1,686 |  |  | $ | 2.43 |  |  | $ | 2.45 |  |

[0000833444-24-000049:8k_2_02:157]
* May not sum due to rounding

[0000833444-24-000049:8k_2_02:158]
19

[0000833444-24-000049:8k_2_02:159]
The following table reconciles the denominators used to calculate basic and diluted earnings per share (in millions; unaudited):

[0000833444-24-000049:8k_2_02:160]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Weighted average shares outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 670.3 |  |  | 683.3 |  | 676.7 |  | 685.7 |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 2.5 |  |  | 2.9 |  |  | 1.9 |  |  | 3.1 |  |
| Diluted weighted average shares outstanding | 672.8 |  |  | 686.2 |  |  | 678.6 |  |  | 688.8 |  |

[0000833444-24-000049:8k_2_02:161]
6.  Debt Ratios

[0000833444-24-000049:8k_2_02:162]
The following table includes net debt to income before income taxes and net debt to adjusted EBITDA (unaudited):

[0000833444-24-000049:8k_2_02:163]
| (in millions) | June 30, 2024 |  | March 31, 2024 |  | June 30, 2023 |  |  |
| Short-term debt | $ | 1,523 |  |  | $ | 2,210 |  |  | $ | 186 |  |  |  |
| Current portion of long-term debt | 998 |  |  | 1,165 |  |  | 1,081 |  |  |  |
| Long-term debt | 7,867 |  |  | 7,348 |  |  | 8,497 |  |  |  |
| Total debt | 10,388 |  |  | 10,723 |  |  | 9,764 |  |  |  |
| Less: cash and cash equivalents | 862 |  |  | 843 |  |  | 1,057 |  |  |  |
| Net debt | $ | 9,526 |  |  | $ | 9,880 |  |  | $ | 8,707 |  |  |  |
| Last twelve months income before income taxes | $ | 1,845 |  |  | $ | 1,359 |  |  | $ | 1,792 |  |  |  |
| Net debt to income before income taxes | 5.2 | x |  | 7.3 | x |  | 4.9 | x |  |  |
| Last twelve months adjusted EBITDA (non-GAAP) | $ | 4,210 |  |  | $ | 4,128 |  |  | $ | 4,078 |  |  |  |
| Net debt to adjusted EBITDA (non-GAAP) | 2.3x |  | 2.4x |  | 2.1x |  |  |

[0000833444-24-000049:8k_2_02:164]
20

[0000833444-24-000049:8k_2_02:165]
The following table reconciles net income to adjusted EBIT and adjusted EBITDA (unaudited):

[0000833444-24-000049:8k_2_02:166]
|  | Twelve Months Ended |  |  |
| (in millions) | June 30, 2024 |  | March 31, 2024 |  | June 30, 2023 |  |  |
| Net income | $ | 1,803 |  |  | $ | 1,873 |  |  | $ | 2,261 |  |  |  |
| Income tax provision (benefit) | 42 |  |  | (514) |  |  | (469) |  |  |  |
| Net financing charges | 326 |  |  | 335 |  |  | 278 |  |  |  |
| EBIT | 2,171 |  |  | 1,694 |  |  | 2,070 |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | 66 |  |  | 54 |  |  | (208) |  |  |  |
| Restructuring and impairment costs | 619 |  |  | 594 |  |  | 1,011 |  |  |  |
| Environmental remediation and related reserves adjustment | — |  |  | — |  |  | 255 |  |  |  |
| Water systems AFFF settlement | 750 |  |  | 750 |  |  | — |  |  |  |
| Water systems AFFF insurance recoveries | (351) |  |  | — |  |  | — |  |  |  |
| Earn-out adjustments | (68) |  |  | (7) |  |  | (30) |  |  |  |
| Global Products product quality issue | 33 |  |  | 33 |  |  | — |  |  |  |
| Warehouse fire loss | — |  |  | — |  |  | 40 |  |  |  |
| Cyber incident costs | 27 |  |  | 27 |  |  | — |  |  |  |
| Transaction/separation costs | 49 |  |  | 77 |  |  | 122 |  |  |  |
| Adjusted EBIT (non-GAAP) | 3,296 |  |  | 3,222 |  |  | 3,260 |  |  |  |
| Depreciation and amortization | 914 |  |  | 906 |  |  | 818 |  |  |  |
| Adjusted EBITDA (non-GAAP) | $ | 4,210 |  |  | $ | 4,128 |  |  | $ | 4,078 |  |  |  |

[0000833444-24-000049:8k_2_02:167]
7.  Income Taxes

[0000833444-24-000049:8k_2_02:168]
The Company's effective tax rate before consideration of certain excluded items was approximately 13.75% for the three and nine months ending June 30, 2024 and approximately 13.5% for the three and nine months ending June 30, 2023.

[0000833444-24-000049:8k_2_02:169]
21
