# JCI notes — 0000833444-24-000052


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-24-000052:notes:1]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2023 filed with the SEC on December 14, 2023. The results of operations for the three and nine month periods ended June 30, 2024 are not necessarily indicative of results for the Company’s 2024 fiscal year because of seasonal and other factors.

[0000833444-24-000052:notes:2]
[same as prior period, unchanged from 0000833444-24-000029:notes:2]

[0000833444-24-000052:notes:3]
[same as prior period, unchanged from 0000833444-24-000029:notes:3]

[0000833444-24-000052:notes:4]
[same as prior period, unchanged from 0000833444-24-000029:notes:4]

[0000833444-24-000052:notes:5]
[same as prior period, unchanged from 0000833444-24-000029:notes:5]

[0000833444-24-000052:notes:6]
[same as prior period, unchanged from 0000833444-24-000029:notes:6]

[0000833444-24-000052:notes:7]
[same as prior period, unchanged from 0000833444-24-000029:notes:7]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000833444-24-000052:notes:8]
NEW ACCOUNTING STANDARDS
Recently Adopted Accounting Pronouncements

[0000833444-24-000052:notes:9]
In September 2022, the FASB issued ASU 2022-04, "Disclosure of Supplier Finance Program Obligations," which is intended to enhance the transparency surrounding the use of supplier finance programs. Supplier finance programs may

[0000833444-24-000052:notes:10]
also be referred to as reverse factoring, payables finance, or structured payables arrangements. The amendments require a buyer that uses supplier finance programs to make annual disclosures about the program’s key terms, the balance sheet presentation of related amounts, the confirmed amount outstanding at the end of the period, and associated rollforward information. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company adopted the new disclosures, other than the rollforward disclosure, as required at the beginning of fiscal 2024. The rollforward disclosure will be adopted as required at the beginning of fiscal 2025.

[0000833444-24-000052:notes:11]
The Company maintains agreements with third-party financial institutions who offer voluntary supply chain financing ("SCF") programs to its suppliers. The SCF programs enable suppliers to sell their receivables to third-party financial institutions and receive payments earlier than the negotiated commercial terms between the suppliers and the Company, which generally range from 90 to 120 days. Suppliers sell receivables to third-party financial institutions on terms negotiated between the supplier and the respective third-party financial institution. The Company remains obligated to make payments under the terms of the original commercial arrangement regardless of whether the supplier receivable is sold, and does not pledge any assets as security or provide other forms of guarantees for the committed payment to the third-party financial institutions.

[0000833444-24-000052:notes:12]
Amounts outstanding related to SCF programs are included in accounts payable in the consolidated statements of financial position. Accounts payable included in the SCF programs were approximately $669 million and $566 million as of June 30, 2024, and September 30, 2023, respectively.

[0000833444-24-000052:notes:13]
Recently Issued Accounting Pronouncements

[0000833444-24-000052:notes:14]
In December 2023, the FASB issued ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures," which is intended to enhance the transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. The amendments require that on an annual basis, entities disclose specific categories in the rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. In addition, the amendments require that entities disclose additional information about income taxes paid as well as additional disclosures of pretax income and income tax expense, and remove the requirement to disclose certain items that are no longer considered cost beneficial or relevant. The Company expects to adopt the new annual disclosures as required for fiscal 2026.

[0000833444-24-000052:notes:15]
In November 2023, the FASB issued ASU 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures," which is intended to improve reportable segment disclosures, primarily through enhanced disclosures about significant segment expenses. In addition, the amendments enhance interim disclosure requirements, clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provide new segment disclosure requirements for entities with a single reportable segment and contain other disclosure requirements. The Company expects to adopt the new annual disclosures as required for fiscal 2025 and the interim disclosures as required beginning with the first quarter of fiscal 2026.

[0000833444-24-000052:notes:16]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-24-000052:notes:17]
ACQUISITIONS AND DIVESTITURES
During the nine months ended June 30, 2023, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $306 million, of which $260 million was paid as of June 30, 2023. In connection with the acquisitions, the Company recorded goodwill of $121 million within the Global Products segment, $51 million within the Building Solutions Asia Pacific segment and $12 million within the Building Solutions EMEA/LA segment.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-24-000052:notes:18]
ASSETS AND LIABILITIES HELD FOR SALE
During the third quarter of fiscal 2024, the Company entered into a definitive agreement to sell its Air Distribution Technologies ("ADTi") business included within the Global Products segment. As of June 30, 2024, ADTi met the criteria

[0000833444-24-000052:notes:19]
to be classified as held for sale and the assets and liabilities of this business are separately presented in the consolidated statements of financial position.

[0000833444-24-000052:notes:20]
The following table summarizes the asset and liabilities associated with ADTi classified as held for sale (in millions):

[0000833444-24-000052:notes:21]
|  |  |  | June 30, 2024 |
| Assets Held for Sale |  |  |  |
| Accounts receivable - net |  |  | $ | 91 |  |
| Inventories |  |  | 93 |  |
| Other current assets |  |  | 21 |  |
| Current assets held for sale |  |  | 205 |  |
| Property, plant and equipment - net |  |  | 83 |  |
| Other intangible assets - net |  |  | 308 |  |
| Other noncurrent assets |  |  | 131 |  |
| Impairment on assets held for sale |  |  | (35) |  |
| Noncurrent assets held for sale |  |  | 487 |  |
| Total Assets |  |  | $ | 692 |  |
| Liabilities Held for Sale |  |  |  |
| Accounts payable |  |  | $ | 113 |  |
| Accrued compensation and benefits |  |  | 13 |  |
| Other current liabilities |  |  | 23 |  |
| Current liabilities held for sale |  |  | 149 |  |
| Pension and postretirement benefits |  |  | 5 |  |
| Other noncurrent liabilities |  |  | 198 |  |
| Noncurrent liabilities held for sale |  |  | 203 |  |
| Total Liabilities |  |  | $ | 352 |  |

[0000833444-24-000052:notes:22]
Based on the total consideration expected from the sale, net of costs to sell, the Company recorded non-cash impairment charges on the allocated goodwill of $21 million and the held for sale disposal group of $35 million within restructuring and impairment costs in the consolidated statements of income during the three months ended June 30, 2024.

[0000833444-24-000052:notes:23]
The business did not meet the criteria to be classified as a discontinued operation as the divestiture does not represent a strategic shift that will have a major effect on the Company's operations and financial results. The transaction is expected to close in the fourth quarter of fiscal 2024.

[0000833444-24-000052:notes:24]
No impairment charges were recorded during the three months ended June 30, 2023. During the nine months ended June 30, 2023, the Company recorded impairment charges for the Global Retail business of $438 million and the Building Solutions Asia Pacific segment of $60 million. The impairment charges were primarily due to reductions in the estimated fair values of the businesses to be disposed as a result of negotiations with potential buyers and were recorded within restructuring and impairment costs in the consolidated statements of income. During the third quarter of fiscal 2023, the Company concluded that its Global Retail business no longer met the criteria to be classified as held for sale, as it was no longer probable that it would be sold in the next 12 months. The net assets were reclassified to held and used at the lower of fair value or adjusted carrying value, and due to prior period impairment charges recorded, there was no impact to the consolidated statements of income as a result of this reclassification.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-24-000052:notes:25]
[same as prior period, unchanged from 0000833444-24-000029:notes:20]

[0000833444-24-000052:notes:26]
[same as prior period, unchanged from 0000833444-24-000029:notes:21]

[0000833444-24-000052:notes:27]
|  |  | Three Months Ended June 30, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,791 |  |  | $ | 1,108 |  |  | $ | 2,899 |  |  | $ | 1,636 |  |  | $ | 1,029 |  |  | $ | 2,665 |  |
| Building Solutions EMEA/LA |  | 574 |  |  | 507 |  |  | 1,081 |  |  | 571 |  |  | 474 |  |  | 1,045 |  |
| Building Solutions Asia Pacific |  | 381 |  |  | 194 |  |  | 575 |  |  | 537 |  |  | 199 |  |  | 736 |  |
| Global Products |  | 2,676 |  |  | — |  |  | 2,676 |  |  | 2,687 |  |  | — |  |  | 2,687 |  |
| Total |  | $ | 5,422 |  |  | $ | 1,809 |  |  | $ | 7,231 |  |  | $ | 5,431 |  |  | $ | 1,702 |  |  | $ | 7,133 |  |

[0000833444-24-000052:notes:28]
|  |  | Nine Months Ended June 30, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 5,009 |  |  | $ | 3,116 |  |  | $ | 8,125 |  |  | $ | 4,641 |  |  | $ | 2,911 |  |  | $ | 7,552 |  |
| Building Solutions EMEA/LA |  | 1,718 |  |  | 1,465 |  |  | 3,183 |  |  | 1,705 |  |  | 1,346 |  |  | 3,051 |  |
| Building Solutions Asia Pacific |  | 1,026 |  |  | 547 |  |  | 1,573 |  |  | 1,489 |  |  | 560 |  |  | 2,049 |  |
| Global Products |  | 7,143 |  |  | — |  |  | 7,143 |  |  | 7,235 |  |  | — |  |  | 7,235 |  |
| Total |  | $ | 14,896 |  |  | $ | 5,128 |  |  | $ | 20,024 |  |  | $ | 15,070 |  |  | $ | 4,817 |  |  | $ | 19,887 |  |

[0000833444-24-000052:notes:29]
[same as prior period, unchanged from 0000833444-24-000029:notes:24]

[0000833444-24-000052:notes:30]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 1,971 |  |  | $ | 1,973 |  |  | $ | 5,072 |  |  | $ | 5,170 |  |
| Fire & Security |  | 601 |  |  | 626 |  |  | 1,755 |  |  | 1,819 |  |
| Industrial Refrigeration |  | 104 |  |  | 88 |  |  | 316 |  |  | 246 |  |
| Total |  | $ | 2,676 |  |  | $ | 2,687 |  |  | $ | 7,143 |  |  | $ | 7,235 |  |

[0000833444-24-000052:notes:31]
[same as prior period, unchanged from 0000833444-24-000029:notes:26]

[0000833444-24-000052:notes:32]
[same as prior period, unchanged from 0000833444-24-000029:notes:27]

[0000833444-24-000052:notes:33]
[same as prior period, unchanged from 0000833444-24-000029:notes:28]

[0000833444-24-000052:notes:34]
|  |  | Location of contract balances |  | June 30, 2024 |  | September 30, 2023 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,961 |  |  | $ | 2,370 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 9 |  |  | 12 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,143 |  |  | 1,996 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 314 |  |  | 297 |  |  |  |

[0000833444-24-000052:notes:35]
For the three months ended June 30, 2024 and 2023, the Company recognized revenue of $269 million and $222 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year. For the nine months ended June 30, 2024 and 2023, the Company recognized revenue of $1,530 million and $1,387 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.

[0000833444-24-000052:notes:36]
[same as prior period, unchanged from 0000833444-24-000029:notes:31]

[0000833444-24-000052:notes:37]
[same as prior period, unchanged from 0000833444-24-000029:notes:32]

[0000833444-24-000052:notes:38]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of June 30, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $21.4 billion, of which approximately 67% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.

[0000833444-24-000052:notes:39]
[same as prior period, unchanged from 0000833444-24-000029:notes:34]

[0000833444-24-000052:notes:40]
[same as prior period, unchanged from 0000833444-24-000029:notes:35]

[0000833444-24-000052:notes:41]
[same as prior period, unchanged from 0000833444-24-000029:notes:36]

[0000833444-24-000052:notes:42]
|  |  | June 30, 2024 |  | September 30, 2023 |  |  |
| Other current assets |  | $ | 247 |  |  | $ | 156 |  |  |  |
| Other noncurrent assets |  | 278 |  |  | 224 |  |  |  |
| Total |  | $ | 525 |  |  | $ | 380 |  |  |  |

[0000833444-24-000052:notes:43]
During the three months ended June 30, 2024 and 2023, the Company recognized amortization expense of $84 million and $66 million, respectively, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2024 and 2023, the Company recognized amortization expense of $218 million and $188 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and nine months ended June 30, 2024 and 2023.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0000833444-24-000052:notes:44]
ACCOUNTS RECEIVABLE
The Company discontinued its receivable factoring program in March 2024. Accounts receivable sold totaled $702 million during the nine months ended June 30, 2024, $425 million during the three months ended June 30, 2023 and $1.3 billion during the nine months ended June 30, 2023. Previously sold receivables still outstanding were $31 million and $681 million as of June 30, 2024 and September 30, 2023, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-24-000052:notes:45]
[same as prior period, unchanged from 0000833444-24-000029:notes:40]

[0000833444-24-000052:notes:46]
|  | June 30, 2024 |  | September 30, 2023 |
| Raw materials and supplies | $ | 1,107 |  |  | $ | 1,203 |  |
| Work-in-process | 267 |  |  | 226 |  |
| Finished goods | 1,489 |  |  | 1,347 |  |
| Inventories | $ | 2,863 |  |  | $ | 2,776 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-24-000052:notes:47]
[same as prior period, unchanged from 0000833444-24-000029:notes:42]

[0000833444-24-000052:notes:48]
|  |  | Building Solutions North America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total |
| Goodwill |  | $ | 10,040 |  |  | $ | 1,932 |  |  | $ | 1,179 |  |  | $ | 5,750 |  |  | 18,901 |  |
| Accumulated impairment loss |  | (659) |  |  | (47) |  |  | — |  |  | (259) |  |  | (965) |  |
| Balance at September 30, 2023 |  | 9,381 |  |  | 1,885 |  |  | 1,179 |  |  | 5,491 |  |  | 17,936 |  |
| Impairments |  | — |  |  | (230) |  |  | — |  |  | — |  |  | (230) |  |
| Foreign currency translation and other (1) |  | 6 |  |  | 31 |  |  | (2) |  |  | (65) |  |  | (30) |  |
| Balance at June 30, 2024 |  | $ | 9,387 |  |  | $ | 1,686 |  |  | $ | 1,177 |  |  | $ | 5,426 |  |  | $ | 17,676 |  |

[0000833444-24-000052:notes:49]
(1)  Includes measurement period adjustments and the allocation of $21 million of goodwill from Global Products to the ADTi disposal group classified as held for sale. Refer to Note 4, "Assets and Liabilities Held for Sale" of the notes to the consolidated financial statements for further information.

[0000833444-24-000052:notes:50]
The Company tests goodwill for impairment annually as of July 31 or more frequently if events or changes in circumstances indicate the asset might be impaired.

[0000833444-24-000052:notes:51]
During the second quarter of fiscal 2024, the Company determined a triggering event had occurred for one of its reporting units due to year-to-date results and projections for the remainder of fiscal 2024 being lower than the forecast used in the previous annual goodwill impairment test, and a quantitative test of goodwill for possible impairment was necessary. As a result of the goodwill impairment test, the Company recorded a non-cash impairment charge of $230 million within restructuring and impairment costs in the consolidated statements of income, which was determined by comparing the carrying amount of the reporting unit to its fair value. The Company used a discounted cash flow model to estimate the fair value of the reporting unit. The primary assumptions used in the model were management's internal projections of future

[0000833444-24-000052:notes:52]
cash flows, the weighted-average cost of capital and the long-term growth rate, which are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The reporting unit whose goodwill was impaired was previously disclosed as being at risk of impairment in the Company’s Annual Report on Form 10-K for the year-ended September 30, 2023. It is possible that future changes in circumstances, including an increase in the discount rate or a decrease in the revenue growth rates, could result in an additional non-cash impairment charge of the remaining $212 million of goodwill for this reporting unit.

[0000833444-24-000052:notes:53]
There were no other triggering events requiring an impairment assessment be conducted in the nine months ended June 30, 2024.

[0000833444-24-000052:notes:54]
[same as prior period, unchanged from 0000833444-24-000029:notes:47]

[0000833444-24-000052:notes:55]
|  | June 30, 2024 |  | September 30, 2023 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,590 |  |  | $ | (919) |  |  | $ | 671 |  |  | $ | 1,575 |  |  | $ | (806) |  |  | $ | 769 |  |
| Customer relationships | 2,790 |  |  | (1,562) |  |  | 1,228 |  |  | 3,047 |  |  | (1,496) |  |  | 1,551 |  |
| Miscellaneous | 968 |  |  | (509) |  |  | 459 |  |  | 889 |  |  | (435) |  |  | 454 |  |
|  | 5,348 |  |  | (2,990) |  |  | 2,358 |  |  | 5,511 |  |  | (2,737) |  |  | 2,774 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 1,957 |  |  | — |  |  | 1,957 |  |  | 2,114 |  |  | — |  |  | 2,114 |  |
| Total intangible assets | $ | 7,305 |  |  | $ | (2,990) |  |  | $ | 4,315 |  |  | $ | 7,625 |  |  | $ | (2,737) |  |  | $ | 4,888 |  |

[0000833444-24-000052:notes:56]
Amortization of other intangible assets for the three months ended June 30, 2024 and 2023 was $119 million and $111 million, respectively. Amortization of other intangible assets for the nine months ended June 30, 2024 and 2023 was $366 million and $319 million, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-24-000052:notes:57]
[same as prior period, unchanged from 0000833444-24-000029:notes:50]

[0000833444-24-000052:notes:58]
|  | Location of lease balances |  | June 30, 2024 |  | September 30, 2023 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,226 |  | $ | 1,389 |  |
| Operating lease liabilities - current | Other current liabilities |  | 303 |  | 318 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 935 |  | 1,086 |  |

[0000833444-24-000052:notes:59]
[same as prior period, unchanged from 0000833444-24-000029:notes:52]

[0000833444-24-000052:notes:60]
|  |  |  |  | Nine Months Ended June 30, |  |  |
|  |  |  |  |  |  | 2024 |  | 2023 |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  |  |  |  |  | $ | 248 |  |  | $ | 347 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-24-000052:notes:61]
DEBT AND FINANCING ARRANGEMENTS
Short-term debt consisted of the following (in millions):

[0000833444-24-000052:notes:62]
|  | June 30, |  | September 30, |
|  | 2024 |  | 2023 |
| Commercial paper | $ | 941 |  |  | $ | 200 |  |
| Term loans | 581 |  |  | 159 |  |
| Bank borrowings | 1 |  |  | 26 |  |
|  | $ | 1,523 |  |  | $ | 385 |  |
| Weighted average interest rate on short-term debt outstanding | 4.5 | % |  | 5.1 | % |

[0000833444-24-000052:notes:63]
As of June 30, 2024, the Company had syndicated committed revolving credit facilities of $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2024. There were no draws on the facilities as of June 30, 2024.

[0000833444-24-000052:notes:64]
In June 2024, the Company completed the debt tender offer to purchase $119 million of its 5.125% Notes due 2045.
In April 2024, the Company and its wholly-owned subsidiary, Tyco Fire & Security Finance S.C.A, co-issued $700 million unsecured, unsubordinated senior notes with an interest rate of 5.50% which is due April 2029.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-24-000052:notes:65]
[same as prior period, unchanged from 0000833444-24-000029:notes:58]

[0000833444-24-000052:notes:66]
[same as prior period, unchanged from 0000833444-24-000029:notes:59]

[0000833444-24-000052:notes:67]
[same as prior period, unchanged from 0000833444-24-000029:notes:60]

[0000833444-24-000052:notes:68]
[same as prior period, unchanged from 0000833444-24-000029:notes:61]

[0000833444-24-000052:notes:69]
During the second quarter of fiscal 2024, the Company terminated $600 million of forward-starting interest-rate swaps related to an anticipated note issuance that was no longer highly likely to occur. Accumulated amounts previously recorded in AOCI were not material and were recognized as net financing charges in the consolidated statements of income when the swaps were terminated.

[0000833444-24-000052:notes:70]
[same as prior period, unchanged from 0000833444-24-000029:notes:63]

[0000833444-24-000052:notes:71]
[same as prior period, unchanged from 0000833444-24-000029:notes:64]

[0000833444-24-000052:notes:72]
|  |  | Volume Outstanding as of |
| Commodity |  | June 30, 2024 |  | September 30, 2023 |
| Copper |  | 2,790 |  |  | 2,812 |  |
| Aluminum |  | 5,606 |  |  | 5,976 |  |

[0000833444-24-000052:notes:73]
Cash flow hedges under ASC 815, "Derivatives and Hedging," that hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates and commodity prices during the three and nine months ended June 30, 2024 and 2023.

[0000833444-24-000052:notes:74]
[same as prior period, unchanged from 0000833444-24-000029:notes:67]

[0000833444-24-000052:notes:75]
[same as prior period, unchanged from 0000833444-24-000029:notes:68]

[0000833444-24-000052:notes:76]
[same as prior period, unchanged from 0000833444-24-000029:notes:69]

[0000833444-24-000052:notes:77]
|  |  | June 30, |  | September 30, |
|  | 2024 |  | 2023 |
| Euro-denominated bonds designated as net investment hedges in Europe |  | € | 2.9 |  |  | € | 2.9 |  |
| Yen-denominated debt designated as a net investment hedge in Japan |  | ¥ | 30 |  |  | ¥ | 30 |  |
| US dollar vs. Yen cross-currency interest rate swap designated as a net investment hedge in Japan |  | ¥ | 14 |  |  | ¥ | 14 |  |

[0000833444-24-000052:notes:78]
[same as prior period, unchanged from 0000833444-24-000029:notes:71]

[0000833444-24-000052:notes:79]
[same as prior period, unchanged from 0000833444-24-000029:notes:72]

[0000833444-24-000052:notes:80]
[same as prior period, unchanged from 0000833444-24-000029:notes:73]

[0000833444-24-000052:notes:81]
[same as prior period, unchanged from 0000833444-24-000029:notes:74]

[0000833444-24-000052:notes:82]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments |  | Derivatives and Hedging ActivitiesNot Designatedas Hedging Instruments |
|  | June 30, |  | September 30, |  | June 30, |  | September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 11 |  |  | $ | 16 |  |  | $ | 2 |  |  | $ | 13 |  |
| Interest rate swaps | — |  |  | 22 |  |  | — |  |  | — |  |
| Commodity derivatives | 3 |  |  | — |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Cross-currency interest rate swap | 13 |  |  | 5 |  |  | — |  |  | — |  |
| Total assets | $ | 27 |  |  | $ | 43 |  |  | $ | 2 |  |  | $ | 13 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 10 |  |  | $ | 20 |  |  | $ | — |  |  | $ | 5 |  |
| Commodity derivatives | 1 |  |  | 2 |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,264 |  |  | 3,253 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,275 |  |  | $ | 3,275 |  |  | $ | — |  |  | $ | 5 |  |

[0000833444-24-000052:notes:83]
[same as prior period, unchanged from 0000833444-24-000029:notes:76]

[0000833444-24-000052:notes:84]
[same as prior period, unchanged from 0000833444-24-000029:notes:77]

[0000833444-24-000052:notes:85]
[same as prior period, unchanged from 0000833444-24-000029:notes:78]

[0000833444-24-000052:notes:86]
[same as prior period, unchanged from 0000833444-24-000029:notes:79]

[0000833444-24-000052:notes:87]
|  |  | Fair Value of Assets |  |  |  | Fair Value of Liabilities |  |  |
|  |  | June 30, |  | September 30, |  |  |  | June 30, |  | September 30, |  |  |
|  |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |  |  |
| Gross amount recognized |  | $ | 29 |  |  | $ | 56 |  |  |  |  | $ | 3,275 |  |  | $ | 3,280 |  |  |  |
| Gross amount eligible for offsetting |  | (9) |  |  | (19) |  |  |  |  | (9) |  |  | (19) |  |  |  |
| Net amount |  | $ | 20 |  |  | $ | 37 |  |  |  |  | $ | 3,266 |  |  | $ | 3,261 |  |  |  |

[0000833444-24-000052:notes:88]
[same as prior period, unchanged from 0000833444-24-000029:notes:81]

[0000833444-24-000052:notes:89]
[same as prior period, unchanged from 0000833444-24-000029:notes:82]

[0000833444-24-000052:notes:90]
| Derivatives in Cash Flow Hedging Relationships |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Foreign currency exchange derivatives |  | $ | 2 |  |  | $ | 3 |  |  | $ | 4 |  |  | $ | (9) |  |
| Commodity derivatives |  | 4 |  |  | (6) |  |  | 5 |  |  | 1 |  |
| Interest rate swaps |  | — |  |  | 1 |  |  | (21) |  |  | 6 |  |
| Total |  | $ | 6 |  |  | $ | (2) |  |  | $ | (12) |  |  | $ | (2) |  |

[0000833444-24-000052:notes:91]
[same as prior period, unchanged from 0000833444-24-000029:notes:84]

[0000833444-24-000052:notes:92]
| Derivatives in Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 4 |  |  | $ | (6) |  |  | $ | 1 |  |  | $ | (2) |  |
| Commodity derivatives |  | Cost of sales |  | — |  |  | 1 |  |  | (4) |  |  | (7) |  |
| Total |  |  |  | $ | 4 |  |  | $ | (5) |  |  | $ | (3) |  |  | $ | (9) |  |

[0000833444-24-000052:notes:93]
[same as prior period, unchanged from 0000833444-24-000029:notes:86]

[0000833444-24-000052:notes:94]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (4) |  |  | $ | (9) |  |  | $ | (7) |  |  | $ | (17) |  |
| Foreign currency exchange derivatives |  | SG&A |  | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 20 |  |  | (54) |  |  | 36 |  |  | (118) |  |
| Total |  |  |  | $ | 18 |  |  | $ | (63) |  |  | $ | 31 |  |  | $ | (135) |  |

[0000833444-24-000052:notes:95]
[same as prior period, unchanged from 0000833444-24-000029:notes:88]

[0000833444-24-000052:notes:96]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net investment hedges | $ | 44 |  |  | $ | 30 |  |  | $ | (3) |  |  | $ | (299) |  |

[0000833444-24-000052:notes:97]
No gains or losses were reclassified from CTA into income during the three and nine months ended June 30, 2024 and 2023.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-24-000052:notes:98]
[same as prior period, unchanged from 0000833444-24-000029:notes:91]

[0000833444-24-000052:notes:99]
[same as prior period, unchanged from 0000833444-24-000029:notes:92]

[0000833444-24-000052:notes:100]
[same as prior period, unchanged from 0000833444-24-000029:notes:93]

[0000833444-24-000052:notes:101]
[same as prior period, unchanged from 0000833444-24-000029:notes:94]

[0000833444-24-000052:notes:102]
[same as prior period, unchanged from 0000833444-24-000029:notes:95]

[0000833444-24-000052:notes:103]
[same as prior period, unchanged from 0000833444-24-000029:notes:96]

[0000833444-24-000052:notes:104]
[same as prior period, unchanged from 0000833444-24-000029:notes:97]

[0000833444-24-000052:notes:105]
|  | Fair Value Measurements Using: |
|  | Total as of June 30, 2024 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |
| Commodity derivatives | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Cross-currency interest rate swap | 13 |  |  | — |  |  | 13 |  |  | — |  |
| Deferred compensation plan assets | 53 |  |  | 53 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)(1) | 80 |  |  | 80 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)(1) | 191 |  |  | 191 |  |  | — |  |  | — |  |
| Total assets | $ | 353 |  |  | $ | 324 |  |  | $ | 29 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Contingent earn-out liabilities | 15 |  |  | — |  |  | — |  |  | 15 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 20 |  |  | — |  |  | — |  |  | 20 |  |
| Total liabilities | $ | 46 |  |  | $ | — |  |  | $ | 11 |  |  | $ | 35 |  |

[0000833444-24-000052:notes:106]
(1)  Classified as restricted investments for payment of asbestos liabilities. See Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further details.

[0000833444-24-000052:notes:107]
[same as prior period, unchanged from 0000833444-24-000029:notes:99]

[0000833444-24-000052:notes:108]
[same as prior period, unchanged from 0000833444-24-000029:notes:101]

[0000833444-24-000052:notes:109]
| Balance at September 30, 2023 | $ | 124 |  |  |
| Payments | (20) |  |  |
| Reduction for change in estimates | (69) |  |  |
| Balance at June 30, 2024 | $ | 35 |  |  |

[0000833444-24-000052:notes:110]
[same as prior period, unchanged from 0000833444-24-000029:notes:103]

[0000833444-24-000052:notes:111]
[same as prior period, unchanged from 0000833444-24-000029:notes:104]

[0000833444-24-000052:notes:112]
[same as prior period, unchanged from 0000833444-24-000029:notes:105]

[0000833444-24-000052:notes:113]
[same as prior period, unchanged from 0000833444-24-000029:notes:106]

[0000833444-24-000052:notes:114]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices.

[0000833444-24-000052:notes:115]
Unrealized gains (losses) on the deferred compensation plan assets are recognized in the consolidated statements of income where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-24-000052:notes:116]
Exchange traded funds: Investments in exchange traded funds are valued using a market approach based on quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further information.

[0000833444-24-000052:notes:117]
[same as prior period, unchanged from 0000833444-24-000029:notes:109]

[0000833444-24-000052:notes:118]
[same as prior period, unchanged from 0000833444-24-000029:notes:110]

[0000833444-24-000052:notes:119]
The following table presents the portion of unrealized gains recognized in the consolidated statements of income that relate to equity securities still held at June 30, 2024 and 2023 (in millions):

[0000833444-24-000052:notes:120]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Deferred compensation plan assets |  | $ | — |  |  | $ | 1 |  |  | $ | 7 |  |  | $ | 6 |  |
| Investments in exchange traded funds |  | 4 |  |  | 11 |  |  | 43 |  |  | 34 |  |

[0000833444-24-000052:notes:121]
[same as prior period, unchanged from 0000833444-24-000029:notes:113]

[0000833444-24-000052:notes:122]
The fair value of long-term debt at June 30, 2024 and September 30, 2023 was as follows (in billions):

[0000833444-24-000052:notes:123]
|  |  | June 30, |  | September 30, |  |
|  | 2024 |  | 2023 |  |
| Public debt |  | $ | 8.1 |  |  | $ | 7.1 |  |  |
| Other long-term debt |  | 0.2 |  |  | 0.4 |  |  |
| Total fair value of long-term debt |  | $ | 8.3 |  |  | $ | 7.5 |  |  |

[0000833444-24-000052:notes:124]
[same as prior period, unchanged from 0000833444-24-000029:notes:116]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000833444-24-000052:notes:125]
[same as prior period, unchanged from 0000833444-24-000029:notes:117]

[0000833444-24-000052:notes:126]
[same as prior period, unchanged from 0000833444-24-000029:notes:118]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-24-000052:notes:127]
[same as prior period, unchanged from 0000833444-24-000029:notes:119]

[0000833444-24-000052:notes:128]
[same as prior period, unchanged from 0000833444-24-000029:notes:120]

[0000833444-24-000052:notes:129]
|  | Nine Months Ended June 30, |  |  |
|  | 2024 |  |  |  | 2023 |  |  |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |
| Restricted stock/units | 1,874,606 |  |  | $ | 53.86 |  |  |  |  | 1,799,240 |  |  | $ | 66.28 |  |  |  |
| Performance shares | 370,307 |  |  | 54.13 |  |  |  |  | 339,191 |  |  | 79.54 |  |  |  |
| Stock options | 652,702 |  |  | 13.74 |  |  |  |  | 570,140 |  |  | 18.21 |  |  |  |

[0000833444-24-000052:notes:130]
[same as prior period, unchanged from 0000833444-24-000029:notes:122]

[0000833444-24-000052:notes:131]
[same as prior period, unchanged from 0000833444-24-000029:notes:123]

[0000833444-24-000052:notes:132]
|  | Nine Months Ended June 30, |
|  | 2024 |  | 2023 |
| Risk-free interest rate | 4.21% |  | 4.04% |
| Expected volatility of the Company’s stock | 27.2% |  | 33.5% |

[0000833444-24-000052:notes:133]
[same as prior period, unchanged from 0000833444-24-000029:notes:125]

[0000833444-24-000052:notes:134]
[same as prior period, unchanged from 0000833444-24-000029:notes:126]

[0000833444-24-000052:notes:135]
|  | Nine Months Ended June 30, |
|  | 2024 |  | 2023 |
| Expected life of option (years) | 5.7 |  | 5.8 |
| Risk-free interest rate | 3.86% |  | 3.59% |
| Expected volatility of the Company’s stock | 29.8% |  | 29.4% |
| Expected dividend yield on the Company’s stock | 2.77% |  | 2.10% |


## us-gaap:EarningsPerShareTextBlock

[0000833444-24-000052:notes:136]
[same as prior period, unchanged from 0000833444-24-000029:notes:128]

[0000833444-24-000052:notes:137]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net income attributable to Johnson Controls | $ | 975 |  |  | $ | 1,049 |  |  | $ | 1,072 |  |  | $ | 1,300 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 670.3 |  |  | 683.3 |  |  | 676.7 |  |  | 685.7 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 2.5 |  |  | 2.9 |  |  | 1.9 |  |  | 3.1 |  |
| Diluted weighted average shares outstanding | 672.8 |  |  | 686.2 |  |  | 678.6 |  |  | 688.8 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Stock options and unvested restricted stock | 0.1 |  |  | 0.2 |  |  | 0.4 |  |  | 0.3 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-24-000052:notes:138]
[same as prior period, unchanged from 0000833444-24-000029:notes:131]

[0000833444-24-000052:notes:139]
During the three and nine months ended June 30, 2024, the Company repurchased and immediately retired $402 million and $876 million of its ordinary shares, respectively, on an open market. During the three and nine months ended June 30, 2023, the Company repurchased and immediately retired $366 million and $613 million of its ordinary shares, respectively, on an open market.

[0000833444-24-000052:notes:140]
As of June 30, 2024, approximately $2.1 billion remains available under the Company's share repurchase program, which was approved by the Company's Board of Directors in March 2021. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice.

[0000833444-24-000052:notes:141]
[same as prior period, unchanged from 0000833444-24-000029:notes:134]

[0000833444-24-000052:notes:142]
[same as prior period, unchanged from 0000833444-24-000029:notes:135]

[0000833444-24-000052:notes:143]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Foreign currency translation adjustments |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (1,001) |  |  | $ | (843) |  |  | $ | (970) |  |  | $ | (901) |  |
| Aggregate adjustment for the period | (51) |  |  | (25) |  |  | (82) |  |  | 33 |  |
| Balance at end of period | (1,052) |  |  | (868) |  |  | (1,052) |  |  | (868) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |  |  |  |  |
| Balance at beginning of period | — |  |  | (3) |  |  | 15 |  |  | (11) |  |
| Current period changes in fair value | 6 |  |  | (1) |  |  | (14) |  |  | 4 |  |
| Reclassification to income (1) | (3) |  |  | 4 |  |  | 4 |  |  | 8 |  |
| Net tax impact | 1 |  |  | (1) |  |  | (1) |  |  | (2) |  |
| Balance at end of period | 4 |  |  | (1) |  |  | 4 |  |  | (1) |  |
| Pension and postretirement plans |  |  |  |  |  |  |  |
| Balance at beginning of period | (2) |  |  | — |  |  | — |  |  | 1 |  |
| Reclassification to income | (1) |  |  | (1) |  |  | (4) |  |  | (3) |  |
| Net tax impact | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Balance at end of period | (3) |  |  | (1) |  |  | (3) |  |  | (1) |  |
| Accumulated other comprehensive loss, end of period | $ | (1,051) |  |  | $ | (870) |  |  | $ | (1,051) |  |  | $ | (870) |  |

[0000833444-24-000052:notes:144]
[same as prior period, unchanged from 0000833444-24-000029:notes:137]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-24-000052:notes:145]
[same as prior period, unchanged from 0000833444-24-000029:notes:138]

[0000833444-24-000052:notes:146]
|  | U.S. Pension Plans |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Interest cost | $ | 20 |  |  | $ | 21 |  |  | $ | 59 |  |  | $ | 62 |  |
| Expected return on plan assets | (30) |  |  | (34) |  |  | (90) |  |  | (101) |  |
| Net actuarial loss (gain) | — |  |  | (6) |  |  | — |  |  | 17 |  |
| Settlement loss | — |  |  | — |  |  | — |  |  | 1 |  |
| Net periodic benefit credit | $ | (10) |  |  | $ | (19) |  |  | $ | (31) |  |  | $ | (21) |  |

[0000833444-24-000052:notes:147]
|  | Non-U.S. Pension Plans |
|  | Three Months Ended June 30, |  | Nine Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Service cost | $ | 4 |  |  | $ | 4 |  |  | $ | 12 |  |  | $ | 11 |  |
| Interest cost | 17 |  |  | 18 |  |  | 51 |  |  | 51 |  |
| Expected return on plan assets | (18) |  |  | (20) |  |  | (54) |  |  | (57) |  |
| Net periodic benefit cost | $ | 3 |  |  | $ | 2 |  |  | $ | 9 |  |  | $ | 5 |  |

[0000833444-24-000052:notes:148]
|  | Postretirement Benefits |
|  | Three Months Ended June 30, |  | Nine Months EndedJune 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Interest cost | $ | 1 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | 3 |  |
| Expected return on plan assets | (3) |  |  | (3) |  |  | (7) |  |  | (7) |  |
| Amortization of prior service credit | (1) |  |  | (1) |  |  | (4) |  |  | (3) |  |
| Net periodic benefit credit | $ | (3) |  |  | $ | (3) |  |  | $ | (8) |  |  | $ | (7) |  |

[0000833444-24-000052:notes:149]
Cumulative fiscal 2023 lump sum payouts triggered remeasurement events for certain pension plans in each quarter of fiscal 2023. During the three months ended June 30, 2023, the Company recognized net actuarial gains of $6 million, primarily due to increases in discount rates, partially offset by unfavorable asset performance. During the nine months ended June 30, 2023, the Company recognized net actuarial losses of $17 million, primarily due to net decreases in discount rates, partially offset by net favorable plan asset performance.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-24-000052:notes:150]
[same as prior period, unchanged from 0000833444-24-000029:notes:143]

[0000833444-24-000052:notes:151]
In the third and fourth quarters of fiscal 2023, the Company developed a restructuring plan which included workforce reductions and other actions focused on continued scaling of SG&A expenses to its planned growth. Additional restructuring charges related to this plan were recorded in the three and nine months ended June 30, 2024 and are expected in subsequent quarters.

[0000833444-24-000052:notes:152]
[same as prior period, unchanged from 0000833444-24-000029:notes:145]

[0000833444-24-000052:notes:153]
|  | Three Months Ended June 30, 2024 |  | Nine Months Ended June 30, 2024 |  |  |
| Building Solutions North America | $ | — |  |  | $ | 4 |  |  |  |
| Building Solutions EMEA/LA | 9 |  |  | 22 |  |  |  |
| Building Solutions Asia Pacific | 4 |  |  | 7 |  |  |  |
| Global Products | 20 |  |  | 56 |  |  |  |
| Corporate | 7 |  |  | 14 |  |  |  |
| Total | $ | 40 |  |  | $ | 103 |  |  |  |

[0000833444-24-000052:notes:154]
[same as prior period, unchanged from 0000833444-24-000029:notes:147]

[0000833444-24-000052:notes:155]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  | Total |
| Restructuring and related costs | $ | 204 |  |  | $ | 38 |  |  | $ | 34 |  |  |  |  | $ | 276 |  |
| Utilized—cash | (111) |  |  | — |  |  | (19) |  |  |  |  | (130) |  |
| Utilized—noncash | — |  |  | (38) |  |  | (3) |  |  |  |  | (41) |  |
| Balance at September 30, 2023 | 93 |  |  | — |  |  | 12 |  |  |  |  | 105 |  |
| Additional restructuring and related costs | 50 |  |  | 36 |  |  | 17 |  |  |  |  | 103 |  |
| Utilized—cash | (121) |  |  | — |  |  | (12) |  |  |  |  | (133) |  |
| Utilized—noncash | — |  |  | (36) |  |  | (1) |  |  |  |  | (37) |  |
| Other | 32 |  |  |  |  | — |  |  |  |  | 32 |  |
| Balance at June 30, 2024 | $ | 54 |  |  | $ | — |  |  | $ | 16 |  |  |  |  | $ | 70 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-24-000052:notes:156]
[same as prior period, unchanged from 0000833444-24-000029:notes:149]

[0000833444-24-000052:notes:157]
[same as prior period, unchanged from 0000833444-24-000029:notes:150]

[0000833444-24-000052:notes:158]
For the three months ended June 30, 2024, the Company's effective tax rate was 17.7% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of the water systems Aqueous Film Forming Foam ("AFFF") insurance proceeds and tax rate differentials, partially offset by the benefits of continuing global tax planning.

[0000833444-24-000052:notes:159]
For the nine months ended June 30, 2024, the Company's effective tax rate was 7.5% and was lower than the statutory tax rate of 12.5% primarily due to the net tax impact of the water systems AFFF settlement costs and insurance proceeds, Swiss tax reform, and the benefits of continuing global tax planning, partially offset by the tax impact of an impairment charge, the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain consolidated subsidiaries and tax rate differentials.

[0000833444-24-000052:notes:160]
For the three months ended June 30, 2023, the Company's effective tax rate was (41.5)% and was lower than the statutory tax rate of 12.5% primarily due to reserve adjustments resulting from tax audit developments and the benefits of continuing global tax planning, partially offset by tax rate differentials.

[0000833444-24-000052:notes:161]
For the nine months ended June 30, 2023, the Company's effective tax rate was (22.4)% and was lower than the statutory tax rate of 12.5% primarily due to reserve adjustments resulting from tax audit developments and the benefits of continuing global tax planning, partially offset by the tax impact of an impairment charge and tax rate differentials.

[0000833444-24-000052:notes:162]
Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement.

[0000833444-24-000052:notes:163]
[same as prior period, unchanged from 0000833444-24-000029:notes:156]

[0000833444-24-000052:notes:164]
At September 30, 2023, the Company had gross tax-effected unrecognized tax benefits of $2.2 billion, of which $1.6 billion, if recognized, would impact the effective tax rate. Accrued interest, net at September 30, 2023 was approximately $335 million (net of tax benefit). Interest accrued during the nine months ended June 30, 2024 and 2023 was approximately $92 million and $33 million (both net of tax benefit), respectively. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-24-000052:notes:165]
[same as prior period, unchanged from 0000833444-24-000029:notes:159]

[0000833444-24-000052:notes:166]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2022 |
| Germany |  | 2007 - 2021 |
| Mexico |  | 2016 - 2019 |
| United Kingdom |  | 2014 - 2015; 2018; 2020 - 2021 |

[0000833444-24-000052:notes:167]
It is reasonably possible that tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-24-000052:notes:168]
[same as prior period, unchanged from 0000833444-24-000029:notes:162]

[0000833444-24-000052:notes:169]
On September 11, 2023, the Schaffhausen parliament approved a partial revision of the cantonal act on direct taxation: Immediate Minimum Taxation Measure (“IMTM”). On November 19, 2023, IMTM was approved in a public referendum in the canton of Schaffhausen, was published in the cantonal official gazette on December 8, 2023, and is effective starting January 1, 2024. The IMTM increased Switzerland's combined statutory income tax rate to approximately 15%. As a result, in the nine months ended June 30, 2024, the Company recorded a noncash discrete net tax benefit of $80 million due to the remeasurement of deferred tax assets and liabilities related to Switzerland and the canton of Schaffhausen.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-24-000052:notes:170]
[same as prior period, unchanged from 0000833444-24-000029:notes:164]

[0000833444-24-000052:notes:171]
[same as prior period, unchanged from 0000833444-24-000029:notes:165]

[0000833444-24-000052:notes:172]
[same as prior period, unchanged from 0000833444-24-000029:notes:166]

[0000833444-24-000052:notes:173]
[same as prior period, unchanged from 0000833444-24-000029:notes:167]

[0000833444-24-000052:notes:174]
[same as prior period, unchanged from 0000833444-24-000029:notes:168]

[0000833444-24-000052:notes:175]
[same as prior period, unchanged from 0000833444-24-000029:notes:169]

[0000833444-24-000052:notes:176]
[same as prior period, unchanged from 0000833444-24-000029:notes:170]

[0000833444-24-000052:notes:177]
[same as prior period, unchanged from 0000833444-24-000029:notes:171]

[0000833444-24-000052:notes:178]
[same as prior period, unchanged from 0000833444-24-000029:notes:172]

[0000833444-24-000052:notes:179]
[same as prior period, unchanged from 0000833444-24-000029:notes:173]

[0000833444-24-000052:notes:180]
[same as prior period, unchanged from 0000833444-24-000029:notes:174]

[0000833444-24-000052:notes:181]
[same as prior period, unchanged from 0000833444-24-000029:notes:175]

[0000833444-24-000052:notes:182]
[same as prior period, unchanged from 0000833444-24-000029:notes:176]

[0000833444-24-000052:notes:183]
[same as prior period, unchanged from 0000833444-24-000029:notes:177]

[0000833444-24-000052:notes:184]
[same as prior period, unchanged from 0000833444-24-000029:notes:178]

[0000833444-24-000052:notes:185]
Management evaluates the performance of its segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income before income taxes and noncontrolling interests, excluding corporate expenses, amortization of intangible assets, restructuring and impairment costs, the water systems AFFF settlement costs and insurance recoveries, net mark-to-market gains and losses related to pension and postretirement plans and restricted asbestos investments, and net financing charges.

[0000833444-24-000052:notes:186]
[same as prior period, unchanged from 0000833444-24-000029:notes:180]

[0000833444-24-000052:notes:187]
|  | Net Sales |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Building Solutions North America | $ | 2,899 |  |  | $ | 2,665 |  |  | $ | 8,125 |  |  | $ | 7,552 |  |
| Building Solutions EMEA/LA | 1,081 |  |  | 1,045 |  |  | 3,183 |  |  | 3,051 |  |
| Building Solutions Asia Pacific | 575 |  |  | 736 |  |  | 1,573 |  |  | 2,049 |  |
| Global Products | 2,676 |  |  | 2,687 |  |  | 7,143 |  |  | 7,235 |  |
| Total net sales | $ | 7,231 |  |  | $ | 7,133 |  |  | $ | 20,024 |  |  | $ | 19,887 |  |

[0000833444-24-000052:notes:188]
|  | Segment EBITA |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Building Solutions North America | $ | 521 |  |  | $ | 385 |  |  | $ | 1,179 |  |  | $ | 967 |  |
| Building Solutions EMEA/LA | 111 |  |  | 90 |  |  | 280 |  |  | 234 |  |
| Building Solutions Asia Pacific | 67 |  |  | 102 |  |  | 167 |  |  | 249 |  |
| Global Products | 655 |  |  | 593 |  |  | 1,453 |  |  | 1,463 |  |
| Total segment EBITA | 1,354 |  |  | 1,170 |  |  | 3,079 |  |  | 2,913 |  |
| Corporate expenses | 135 |  |  | 122 |  |  | 373 |  |  | 362 |  |
| Amortization of intangible assets | 119 |  |  | 111 |  |  | 366 |  |  | 319 |  |
| Restructuring and impairment costs | 106 |  |  | 81 |  |  | 399 |  |  | 844 |  |
| Water systems AFFF settlement (1) | — |  |  | — |  |  | 750 |  |  | — |  |
| Water systems AFFF insurance recoveries (1) | (351) |  |  | — |  |  | (351) |  |  | — |  |
| Net mark-to-market gains | (5) |  |  | (17) |  |  | (42) |  |  | (16) |  |
| Net financing charges | 71 |  |  | 80 |  |  | 263 |  |  | 218 |  |
| Income before income taxes | $ | 1,279 |  |  | $ | 793 |  |  | $ | 1,321 |  |  | $ | 1,186 |  |

[0000833444-24-000052:notes:189]
(1) Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement.


## us-gaap:GuaranteesTextBlock

[0000833444-24-000052:notes:190]
[same as prior period, unchanged from 0000833444-24-000029:notes:184]

[0000833444-24-000052:notes:191]
[same as prior period, unchanged from 0000833444-24-000029:notes:185]

[0000833444-24-000052:notes:192]
[same as prior period, unchanged from 0000833444-24-000029:notes:186]

[0000833444-24-000052:notes:193]
[same as prior period, unchanged from 0000833444-24-000029:notes:187]

[0000833444-24-000052:notes:194]
| Balance at September 30, 2023 | $ | 203 |  |  |
| Accruals for warranties issued during the period | 107 |  |  |
| Settlements made (in cash or in kind) during the period | (101) |  |  |
| Changes in estimates to pre-existing warranties | 26 |  |  |
| Currency translation | (2) |  |  |
| Balance at June 30, 2024 | $ | 233 |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-24-000052:notes:195]
COMMITMENTS AND CONTINGENCIES
Environmental Matters

[0000833444-24-000052:notes:196]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000052:notes:197]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 37 |  |  | $ | 31 |  |
| Other noncurrent liabilities | 180 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 217 |  |  | $ | 242 |  |

[0000833444-24-000052:notes:198]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

[0000833444-24-000052:notes:199]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).

[0000833444-24-000052:notes:200]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA")  and other environmental and health agencies and researchers. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. On April 10, 2024, EPA announced the final National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBA. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meet the statutory definition of hazardous waste.

[0000833444-24-000052:notes:201]
In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In April 2023, EPA issued an Advanced Notice of Proposed Rulemaking ("ANPR") seeking input on whether it should expand the proposed rule to designate as "hazardous substances" under CERCLA: (1) seven additional PFAS; (2) the precursors to PFOA, PFOS, and the seven additional PFAS; or (3) entire categories of PFAS. On April 17, 2024, the EPA Administrator signed the final rule designating PFOA and PFOS, along with their salts and structural isomers, as “hazardous substances.”

[0000833444-24-000052:notes:202]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the

[0000833444-24-000052:notes:203]
various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-24-000052:notes:204]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $8 million and $13 million at June 30, 2024 and September 30, 2023, respectively.

[0000833444-24-000052:notes:205]
FTC-Related Matters

[0000833444-24-000052:notes:206]
FTC Remediation

[0000833444-24-000052:notes:207]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. During the three months ended June 30, 2024, Tyco Fire Products completed its previously announced plan to discontinue the production and sale of fluorinated firefighting foams, including AFFF products, and has transitioned to non-fluorinated foam alternatives.

[0000833444-24-000052:notes:208]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with  EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

[0000833444-24-000052:notes:209]
Tyco Fire Products is operating and monitoring at the FTC a Groundwater Extraction and Treatment System ("GETS"), a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. The Company's reserves for continued remediation of the FTC, the Stanton Street Facility and surrounding areas in Marinette and Peshtigo are based on estimates of costs associated with the long-term remediation actions, including the continued operation of the GETS, the implementation of long-term drinking water solutions for the area impacted by groundwater migrating from the FTC, continued monitoring and testing of groundwater monitoring wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

[0000833444-24-000052:notes:210]
FTC-Related Litigation

[0000833444-24-000052:notes:211]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. The WDNR initiated a rulemaking proceeding that would establish groundwater quality standards for PFOA, PFOS,

[0000833444-24-000052:notes:212]
perfluorobutane sulfonic acid and its potassium salt (“PFBS”) and hexafluoropropylene oxide dimer acid and its ammonium salt (“HFPO-DA”). Pursuant to state law, the WDNR has stopped work on the proposed rule and notified the state legislature that, following economic analysis, the proposed costs would exceed statutory thresholds. As a result, the state legislature is required to authorize the WDNR to allow the rulemaking to continue.

[0000833444-24-000052:notes:213]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions, including the potential assessment of penalties.

[0000833444-24-000052:notes:214]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties are engaged in summary judgment and pretrial motions and the court has set a trial date of December 3, 2024.

[0000833444-24-000052:notes:215]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina.

[0000833444-24-000052:notes:216]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. Subsequently, several additional plaintiffs have direct-filed in the MDL complaints with similar allegations.

[0000833444-24-000052:notes:217]
The Company is vigorously defending each of these cases and believes that it has meritorious defenses, but it is presently unable to predict the duration, scope, or outcome of these actions.

[0000833444-24-000052:notes:218]
Aqueous Film-Forming Foam ("AFFF") Matters

[0000833444-24-000052:notes:219]
AFFF Litigation

[0000833444-24-000052:notes:220]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with

[0000833444-24-000052:notes:221]
Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-24-000052:notes:222]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to the MDL. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-24-000052:notes:223]
AFFF Municipal and Water Provider Cases

[0000833444-24-000052:notes:224]
Chemguard and Tyco Fire Products have been named as defendants in more than 950 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 35 states and territories. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation.

[0000833444-24-000052:notes:225]
Tyco Fire Products and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-24-000052:notes:226]
Water Systems AFFF Settlement Agreement

[0000833444-24-000052:notes:227]
On April 12, 2024, Tyco Fire Products agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. The settlement releases these claims against Tyco Fire Products, Chemguard, and other related corporate entities. In connection with the settlement, a charge for $750 million was recorded in selling, general and administrative expenses in the consolidated statements of income in the three months ended March 31, 2024.

[0000833444-24-000052:notes:228]
Tyco Fire Products contributed an initial payment of $250 million in June 2024, with the remaining $500 million due by the first quarter of fiscal 2025. Prior to the date of the final contribution, Tyco Fire Products has agreed to contribute any applicable insurance recoveries in excess of the initial $250 million payment, up to the remaining $500 million due, within a specified period following the receipt of such recovery. During the three months ended June 30, 2024, the Company recorded expected insurance recoveries of $351 million in selling, general and administrative expenses in the consolidated statements of income, substantially all of the proceeds of which are expected to be received in the fourth quarter of fiscal 2024. In accordance with its agreement and recent insurance recovery, Tyco Fire Products will make an additional payment during the fourth quarter of fiscal 2024 of approximately $90 million, reducing its final payment to approximately $410 million. The amounts and timing of any additional insurance recoveries are uncertain.

[0000833444-24-000052:notes:229]
There are still several procedural and legal steps that must occur before the settlement is final and the remaining payment is made. The settlement is subject to final approval by the MDL court and other contingencies, and that process is expected to take several months.

[0000833444-24-000052:notes:230]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems

[0000833444-24-000052:notes:231]
that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of damages alleged to be related to the historic use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.

[0000833444-24-000052:notes:232]
The settlement does not constitute an admission of liability or wrongdoing by Tyco Fire Products or Chemguard. If the MDL court does not approve the agreement or certain terms are not fulfilled, Tyco Fire Products and Chemguard will continue to defend themselves in the litigation.

[0000833444-24-000052:notes:233]
AFFF Putative Class Actions

[0000833444-24-000052:notes:234]
Chemguard and Tyco Fire Products are named in 46 pending putative class actions in federal courts originating from 18 states and territories. All of these cases have been direct-filed in or transferred to the MDL. It is anticipated that the remaining state-court action will be similarly tagged and transferred. Tyco Fire Products was also recently named in class actions in British Columbia and Quebec, Canada.

[0000833444-24-000052:notes:235]
AFFF Individual or Mass Actions

[0000833444-24-000052:notes:236]
There are more than 7,800 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 7,800 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona, Illinois and Virginia.

[0000833444-24-000052:notes:237]
Tyco and Chemguard are also periodically notified by other individuals that they may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-24-000052:notes:238]
AFFF State or U.S. Territory Attorneys General Litigation

[0000833444-24-000052:notes:239]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-24-000052:notes:240]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including

[0000833444-24-000052:notes:241]
affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-24-000052:notes:242]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

[0000833444-24-000052:notes:243]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. These two cases have also been removed to federal court and transferred to the MDL.

[0000833444-24-000052:notes:244]
In addition, 33 other states and territories have filed 35 lawsuits against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of each of those State's environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within each respective State. The states and territories are: Arkansas, Arizona, California, Colorado, Connecticut, Delaware, the District of Columbia, Florida, Hawaii, Illinois, Indiana, Kentucky, Massachusetts, Maryland, Maine, Michigan, Mississippi, New Hampshire, New Jersey, New Mexico, Ohio, Oklahoma, Oregon, Rhode Island, South Carolina, Tennessee, Texas, Vermont, Washington, Wisconsin, Guam, the Northern Mariana Islands, and Puerto Rico. All of these complaints, if not filed directly in the MDL, have been removed to federal court and transferred to the MDL.

[0000833444-24-000052:notes:245]
Other AFFF Related Matters

[0000833444-24-000052:notes:246]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-24-000052:notes:247]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This complaint has been transferred to the MDL.

[0000833444-24-000052:notes:248]
In July 2023, the Fond du Lac Band of Lake Superior Chippewa (a federally recognized tribe) direct-filed a lawsuit in the MDL against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota.

[0000833444-24-000052:notes:249]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin and a federal district court in South Carolina. The insurance litigation

[0000833444-24-000052:notes:250]
involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-24-000052:notes:251]
Asbestos Matters

[0000833444-24-000052:notes:252]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-24-000052:notes:253]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000052:notes:254]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 353 |  |  | 364 |  |
| Total asbestos-related liabilities | 411 |  |  | 422 |  |
| Other current assets | 18 |  |  | 28 |  |
| Other noncurrent assets | 310 |  |  | 273 |  |
| Total asbestos-related assets | 328 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 83 |  |  | $ | 121 |  |

[0000833444-24-000052:notes:255]
The following table presents the components of asbestos-related assets (in millions):

[0000833444-24-000052:notes:256]
|  | June 30, 2024 |  | September 30, 2023 |
| Restricted |  |  |  |
| Cash | $ | 10 |  |  | $ | 20 |  |
| Investments | 271 |  |  | 231 |  |
| Total restricted assets | 281 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 47 |  |  | 50 |  |
| Total asbestos-related assets | $ | 328 |  |  | $ | 301 |  |

[0000833444-24-000052:notes:257]
The amounts recorded for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-24-000052:notes:258]
Self-Insured Liabilities

[0000833444-24-000052:notes:259]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage a portion of its insurable liabilities.

[0000833444-24-000052:notes:260]
The following table presents the location and amount of self-insured liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000052:notes:261]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 98 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 23 |  |  | 21 |  |
| Other noncurrent liabilities | 232 |  |  | 226 |  |
| Total self-insured liabilities | $ | 353 |  |  | $ | 333 |  |

[0000833444-24-000052:notes:262]
The following table presents the location and amount of insurance receivables in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000052:notes:263]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current assets | $ | 6 |  |  | $ | 6 |  |
| Other noncurrent assets | 14 |  |  | 14 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 20 |  |

[0000833444-24-000052:notes:264]
Other Matters

[0000833444-24-000052:notes:265]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to the Company, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock

[0000833444-24-000052:notes:266]
The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):


## us-gaap:SubsequentEventsTextBlock

[0000833444-24-000052:notes:267]
SUBSEQUENT EVENT
On July 23, 2024, the Company entered into a Stock and Asset Purchase Agreement (“Purchase Agreement”) with Bosch GmbH, a Gesellschaft mit beschränkter Haftung (“Purchaser”). Pursuant to the Purchase Agreement, on the terms and subject to the conditions therein, the Company has agreed to sell, and Purchaser has agreed to acquire, the Company’s Residential and Light Commercial HVAC business (the “R&LC Business”), including the Company’s North America Ducted business and Johnson Controls-Hitachi Air Conditioning Holding (UK) Ltd., the Company’s global Residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which the Company owns 60% and Hitachi owns 40%. The total consideration payable by Purchaser to the Company and Hitachi is approximately  $8.1 billion in cash, and the Company’s portion of the aggregate consideration is approximately $6.7 billion in cash, in each case, subject to adjustment, plus the assumption by Purchaser or its affiliates of certain liabilities of the R&LC Business specified in the Purchase Agreement. Net cash proceeds to the Company are expected to be approximately $5.0 billion after tax and transaction-related expenses. The transaction is expected to close in the fourth quarter of fiscal 2025, subject to required regulatory approvals and other customary closing conditions. The Company expects to report the operating results of the R&LC HVAC business, which is currently reported in the Global Products segment, in discontinued operations beginning in the fourth quarter of fiscal 2024.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000833444-24-000052:notes:268]
On June 5, 2024, George Oliver, Chairman and Chief Executive Officer of the Company, entered into a Rule 10b5–1 trading arrangement with respect to 331,846 ordinary shares of Company stock issuable upon the exercise of option awards scheduled to expire in 2024 (the “Oliver 10b5-1 Plan”). The Oliver 10b5-1 Plan was executed during the Company’s most recent open trading window and is expected to become effective on or about September 15, 2024. Under the Oliver 10b5-1 Plan, the options are expected to be exercised in regular intervals between the plan’s start date and termination date, provided that the market price of the Company’s ordinary shares exceeds the exercise price of the options at the time of exercise. With respect to the options to be exercised, a portion of the ordinary shares are expected to be sold in the market to cover the exercise price and taxes associated with the exercise of the options. The remaining ordinary shares underlying the options will be sold in the open market at the times and prices specified in the plan. All transactions under the Oliver 10b5-1 Plan, if they occur, are expected to be completed by or before November 25, 2024. The Oliver 10b5-1 Plan will automatically terminate upon the earlier of the completion of all transactions contemplated under the plan or November 25, 2024.
