# JCI MD&A — 0000833444-24-000052


## mdna

[0000833444-24-000052:mdna:1]
[same as prior period, unchanged from 0000833444-24-000029:mdna:1]

[0000833444-24-000052:mdna:2]
[same as prior period, unchanged from 0000833444-24-000029:mdna:2]

[0000833444-24-000052:mdna:3]
[same as prior period, unchanged from 0000833444-24-000029:mdna:3]

[0000833444-24-000052:mdna:4]
[same as prior period, unchanged from 0000833444-24-000029:mdna:4]

[0000833444-24-000052:mdna:5]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers in more than 150 countries. The Company’s products, services, systems and

[0000833444-24-000052:mdna:6]
solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-24-000052:mdna:7]
[same as prior period, unchanged from 0000833444-24-000029:mdna:6]

[0000833444-24-000052:mdna:8]
The following information should be read in conjunction with the September 30, 2023 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in the Company's Annual Report on Form 10-K for the year ended September 30, 2023 filed with the SEC on December 14, 2023. References in the following discussion and analysis to "Three Months," "Third Quarter" or similar language refer to the three months ended June 30, 2024 compared to the three months ended June 30, 2023, while "Year-to-Date" refers to nine months ended June 30, 2024 compared to the nine months ended June 30, 2023.

[0000833444-24-000052:mdna:9]
[same as prior period, unchanged from 0000833444-24-000029:mdna:8]

[0000833444-24-000052:mdna:10]
Much of the demand for the Company’s products and solutions is driven by construction, facility expansion, retrofit and maintenance projects within the commercial, institutional, industrial, data center, governmental and residential sectors. Construction projects are heavily dependent on general economic conditions, localized demand for real estate and the availability of credit, public funding or other financing sources. Positive or negative fluctuations in construction, industrial facility expansion, retrofit activity, maintenance projects and other capital investments in buildings within the sectors that the Company serves, as well as availability of credit, financing or funding for such projects, could have a corresponding impact on the Company’s financial condition, results of operations and cash flows. During the nine months ended June 30, 2024, the Company observed continued softening of economic conditions in China, negatively impacting the performance of the Building Solutions Asia Pacific segment. The Company expects economic conditions in China to remain soft throughout the remainder of fiscal 2024, which could impact the performance of the Building Solutions Asia Pacific segment.

[0000833444-24-000052:mdna:11]
As a result of the Company’s global presence, a significant portion of its revenues and expenses is denominated in currencies other than the U.S. dollar. The Company is therefore subject to non-U.S. currency risks and non-U.S. exchange exposure. While the Company employs financial instruments to hedge some of its transactional foreign exchange exposure, these activities do not insulate it completely from those exposures. In addition, the currency exposure from the translation of non-U.S. dollar functional currency subsidiaries are not able to be hedged. Exchange rates can be volatile and a substantial weakening or strengthening of foreign currencies against the U.S. dollar could increase or reduce the Company’s profit margin, respectively, and impact the comparability of results from period to period. Revenue and profits were negatively impacted by movements in foreign exchange rates against the U.S. dollar during the three and nine months ended June 30, 2024.

[0000833444-24-000052:mdna:12]
The Company continues to observe trends demonstrating increased interest and demand for its products and services that enable smart, safe, efficient and sustainable buildings. This demand is driven in part by government tax incentives, building performance standards and other regulations designed to limit emissions and combat climate change. In particular, legislative and regulatory initiatives such as the U.S. Climate Smart Buildings Initiative, U.S. Inflation Reduction Act and EU Energy Performance of Buildings Directive include provisions designed to fund and encourage investment in decarbonization and digital technologies for buildings. This demand is supplemented by an increase in commitments in both the public and private sectors to reduce emissions and/or achieve net zero emissions. The Company seeks to capitalize on these trends to drive growth by developing and delivering technologies and solutions to create smart, sustainable and healthy buildings. The Company is investing in new digital and product capabilities, including its OpenBlue platform, to enable it to deliver sustainable, high-efficiency products and tailored services to enable customers to achieve their sustainability goals. The Company is leveraging its install base, together with data-driven products and services, to offer outcome-based solutions to customers with a focus on generating accelerated growth in services and recurring revenue.

[0000833444-24-000052:mdna:13]
40

[0000833444-24-000052:mdna:14]
[same as prior period, unchanged from 0000833444-24-000029:mdna:14]

[0000833444-24-000052:mdna:15]
[same as prior period, unchanged from 0000833444-24-000029:mdna:15]

[0000833444-24-000052:mdna:16]
Portfolio Simplification Transactions

[0000833444-24-000052:mdna:17]
The Company has been engaged in an ongoing evaluation of its non-core product lines in connection with its objective to be a pure-play provider of comprehensive solutions for commercial buildings. During the third quarter of fiscal 2024, the Company entered into a definitive agreement to sell its Air Distribution Technologies business included within the Global Products segment. During the fourth quarter of fiscal 2024, the Company entered into a definitive agreement to sell its Residential and Light Commercial ("R&LC") HVAC business to Robert Bosch GmbH (“Bosch”). The RL&C business includes the Company's North America Ducted business and Johnson Controls-Hitachi Air Conditioning Holding (UK) Ltd., the Company’s global Residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which the Company owns 60% and Hitachi owns 40%. The Company expects to report the operating results of the R&LC HVAC business in discontinued operations beginning in the fourth quarter of fiscal 2024. The Company expects that the sale of the Air Distribution Technologies business will close in the fourth quarter of fiscal 2024 and the sale of the RL&C business will close in the fourth quarter of fiscal 2025.

[0000833444-24-000052:mdna:18]
[same as prior period, unchanged from 0000833444-24-000029:mdna:16]

[0000833444-24-000052:mdna:19]
[same as prior period, unchanged from 0000833444-24-000029:mdna:17]

[0000833444-24-000052:mdna:20]
[same as prior period, unchanged from 0000833444-24-000029:mdna:18]

[0000833444-24-000052:mdna:21]
The overall impact of the cybersecurity incident did not have a material impact on net income, net of insurance recoveries, or cash flows from operations in the third quarter of fiscal 2024, nor is the impact expected to be material for the full year fiscal 2024.

[0000833444-24-000052:mdna:22]
The Company maintains insurance covering certain losses associated with cybersecurity incidents. The Company currently expects that a substantial portion of its direct costs incurred related to containing, investigating and remediating the incident, as well as business interruption losses, will be reimbursed through insurance recoveries. The timing of recognizing insurance recoveries may differ from the timing of recognizing the associated expenses.

[0000833444-24-000052:mdna:23]
[same as prior period, unchanged from 0000833444-24-000029:mdna:22]

[0000833444-24-000052:mdna:24]
In the third and fourth quarters of fiscal 2023, the Company developed a restructuring plan which included workforce reductions and other actions focused on continued scaling of selling, general and administrative expenses ("SG&A") to its planned growth. The costs of the plan were recorded to restructuring and impairment costs in the consolidated statements of income. In the three and nine months ended June 30, 2024, an additional $40 million and $103 million, respectively, of

[0000833444-24-000052:mdna:25]
restructuring charges related to this plan were incurred. Additional restructuring charges are expected in subsequent quarters. The Company expects savings from the restructuring initiatives to be substantially offset by incremental ongoing operating costs and investments to grow the business.

[0000833444-24-000052:mdna:26]
[same as prior period, unchanged from 0000833444-24-000029:mdna:24]

[0000833444-24-000052:mdna:27]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Net sales | $ | 7,231 |  |  | $ | 7,133 |  |  | 1 | % |  | $ | 20,024 |  |  | $ | 19,887 |  |  | 1 | % |

[0000833444-24-000052:mdna:28]
The increase in net sales for the three months ended June 30, 2024 was due to higher organic sales ($240 million) and the net impact of acquisitions and divestitures ($7 million), partially offset by the unfavorable impact of foreign currency translation ($149 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, net sales increased 3% over the prior year, as strong high single-digit Service growth more than offset continued weakness in China’s Systems/Install business.

[0000833444-24-000052:mdna:29]
The increase in net sales for the nine months ended June 30, 2024 was due to higher organic sales ($273 million) and the net impact of acquisitions and divestitures ($69 million), partially offset by the unfavorable impact of foreign currency translation ($205 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, net sales increased 1% over the prior year, as growth in Services was offset primarily by weakness in China's Systems/Install business and declines in global residential HVAC.

[0000833444-24-000052:mdna:30]
[same as prior period, unchanged from 0000833444-24-000029:mdna:28]

[0000833444-24-000052:mdna:31]
[same as prior period, unchanged from 0000833444-24-000029:mdna:29]

[0000833444-24-000052:mdna:32]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Cost of sales | $ | 4,743 |  |  | $ | 4,702 |  |  | 1 | % |  | $ | 13,363 |  |  | $ | 13,124 |  |  | 2 | % |
| Gross profit | 2,488 |  |  | 2,431 |  |  | 2 |  |  | 6,661 |  |  | 6,763 |  |  | (2) |  |
| % of sales | 34.4 | % |  | 34.1 | % |  | 30 | bp |  | 33.3 | % |  | 34.0 | % |  | (70) | bp |

[0000833444-24-000052:mdna:33]
Gross profit increased for the three months ended June 30, 2024, primarily due to higher gross profit in the Systems/Install business of the Building Solutions segments.

[0000833444-24-000052:mdna:34]
Gross profit decreased for the nine months ended June 30, 2024, primarily due to unfavorable mix and lower volumes in the Global Products segment, partially offset by higher gross profit in the Systems/Install business of the Building Solutions segments and the Services business.

[0000833444-24-000052:mdna:35]
[same as prior period, unchanged from 0000833444-24-000029:mdna:32]

[0000833444-24-000052:mdna:36]
[same as prior period, unchanged from 0000833444-24-000029:mdna:33]

[0000833444-24-000052:mdna:37]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| SG&A | $ | 1,090 |  |  | $ | 1,555 |  |  | (30) | % |  | $ | 4,854 |  |  | $ | 4,705 |  |  | 3 | % |
| % of sales | 15.1 | % |  | 21.8 | % |  | (670) | bp |  | 24.2 | % |  | 23.7 | % |  | 50 | bp |

[0000833444-24-000052:mdna:38]
For the three months ended June 30, 2024, decreases in SG&A were due to lower costs due to operating efficiencies ($36 million), water systems AFFF insurance recoveries ($351 million), favorable earn-out adjustments ($61 million) and reductions in miscellaneous other expenses including transaction and separation costs ($17 million).

[0000833444-24-000052:mdna:39]
For the nine months ended June 30, 2024, increases in SG&A were due to the net unfavorable impact of the water systems AFFF settlement agreement costs and insurance recoveries ($399 million), partially offset by lower costs due to operating efficiencies ($104 million), favorable earn-out adjustments ($38 million), the favorable impact of a prior year loss associated with a fire at a leased warehouse facility ($40 million), and reductions in miscellaneous other expenses including transaction and separation costs ($68 million).

[0000833444-24-000052:mdna:40]
Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA. Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement and related insurance recoveries.

[0000833444-24-000052:mdna:41]
[same as prior period, unchanged from 0000833444-24-000029:mdna:39]

[0000833444-24-000052:mdna:42]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |  |
| Goodwill impairments | $ | 21 |  |  | $ | — |  |  |  |  | $ | 251 |  |  | $ | 184 |  |  |
| Held for sale impairments | 35 |  |  | — |  |  |  |  | 35 |  |  | 498 |  |  |
| Other impairments | 10 |  |  | — |  |  |  |  | 10 |  |  | — |  |  |
| Restructuring and related costs | 40 |  |  | 81 |  |  |  |  | 103 |  |  | 162 |  |  |
| Restructuring and impairment costs | $ | 106 |  |  | $ | 81 |  |  |  |  | $ | 399 |  |  | $ | 844 |  |  |

[0000833444-24-000052:mdna:43]
[same as prior period, unchanged from 0000833444-24-000029:mdna:41]

[0000833444-24-000052:mdna:44]
[same as prior period, unchanged from 0000833444-24-000029:mdna:42]

[0000833444-24-000052:mdna:45]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Interest expense, net of capitalized interest costs | $ | 105 |  |  | $ | 79 |  |  | 33 | % |  | $ | 296 |  |  | $ | 219 |  |  | 35 | % |
| Other financing charges | 6 |  |  | 13 |  |  | (54) |  |  | 34 |  |  | 34 |  |  | — |  |
| Gain on debt extinguishment | (25) |  |  | — |  |  | * |  | (25) |  |  | — |  |  | * |
| Interest income | (5) |  |  | (10) |  |  | (50) |  |  | (15) |  |  | (17) |  |  | (12) |  |
| Net foreign exchange results for financing activities | (10) |  |  | (2) |  |  | * |  | (27) |  |  | (18) |  |  | 50 |  |
| Net financing charges | $ | 71 |  |  | $ | 80 |  |  | (11) | % |  | $ | 263 |  |  | $ | 218 |  |  | 21 | % |

[0000833444-24-000052:mdna:46]
[same as prior period, unchanged from 0000833444-24-000029:mdna:47]

[0000833444-24-000052:mdna:47]
[same as prior period, unchanged from 0000833444-24-000029:mdna:44]

[0000833444-24-000052:mdna:48]
[same as prior period, unchanged from 0000833444-24-000029:mdna:45]

[0000833444-24-000052:mdna:49]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Income tax (benefit) provision | $ | 227 |  |  | $ | (329) |  |  | * |  | $ | 99 |  |  | $ | (266) |  |  | * |
| Effective tax rate | 17.7 | % |  | (41.5) | % |  | * |  | 7.5 | % |  | (22.4) | % |  | * |

[0000833444-24-000052:mdna:50]
[same as prior period, unchanged from 0000833444-24-000029:mdna:89]

[0000833444-24-000052:mdna:51]
[same as prior period, unchanged from 0000833444-24-000029:mdna:48]

[0000833444-24-000052:mdna:52]
[same as prior period, unchanged from 0000833444-24-000029:mdna:49]

[0000833444-24-000052:mdna:53]
Management evaluates the performance of its segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income before income taxes and noncontrolling interests, excluding corporate expenses, amortization of intangible assets, restructuring and impairment costs, the water systems AFFF settlement costs and insurance recoveries, net mark-to-market gains and losses related to pension and postretirement plans and restricted asbestos investments, and net financing charges.

[0000833444-24-000052:mdna:54]
[same as prior period, unchanged from 0000833444-24-000029:mdna:51]

[0000833444-24-000052:mdna:55]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Building Solutions North America | $ | 2,899 |  |  | $ | 2,665 |  |  | 9 | % |  | $ | 8,125 |  |  | $ | 7,552 |  |  | 8 | % |
| Building Solutions EMEA/LA | 1,081 |  |  | 1,045 |  |  | 3 |  |  | 3,183 |  |  | 3,051 |  |  | 4 |  |
| Building Solutions Asia Pacific | 575 |  |  | 736 |  |  | (22) |  |  | 1,573 |  |  | 2,049 |  |  | (23) |  |
| Global Products | 2,676 |  |  | 2,687 |  |  | — |  |  | 7,143 |  |  | 7,235 |  |  | (1) |  |
|  | $ | 7,231 |  |  | $ | 7,133 |  |  | 1 | % |  | $ | 20,024 |  |  | $ | 19,887 |  |  | 1 | % |

[0000833444-24-000052:mdna:56]
[same as prior period, unchanged from 0000833444-24-000029:mdna:53]

[0000833444-24-000052:mdna:57]
•The increase in Building Solutions North America was primarily due to organic growth ($216 million) and incremental sales related to business acquisitions ($16 million). Excluding the impact of business acquisitions, sales growth was led by growth greater than 20% in Applied HVAC & Controls. System sales increased 9% and Services increased 6%.

[0000833444-24-000052:mdna:58]
•The increase in Building Solutions EMEA/LA was primarily due to organic growth across the portfolio ($82 million), partially offset by the unfavorable impact of foreign currency translation ($46 million). Excluding the impact of foreign currency translation, sales growth was led by mid-teen growth in Services and low single-digit growth in Systems.

[0000833444-24-000052:mdna:59]
•The decrease in Building Solutions Asia Pacific was primarily due to organic sales declines ($134 million) and the unfavorable impact of foreign currency translation ($25 million). Excluding the impact of foreign currency translation, sales decreased as high single-digit Services growth was more than offset by continued weakness in  System sales in China.

[0000833444-24-000052:mdna:60]
•Global Products net sales were flat as organic growth ($76 million) was offset by the unfavorable impact of foreign currency translation ($80 million). Excluding the impact of foreign currency translation, sales increased as growth in Commercial and Residential HVAC was offset by declines in Fire & Security.

[0000833444-24-000052:mdna:61]
[same as prior period, unchanged from 0000833444-24-000029:mdna:58]

[0000833444-24-000052:mdna:62]
•The increase in Building Solutions North America was primarily due to organic growth ($510 million), incremental sales related to business acquisitions ($48 million) and the favorable impact of foreign currency translation ($15

[0000833444-24-000052:mdna:63]
million). Excluding the impacts of foreign currency translation and business acquisitions, sales growth was led by growth in Applied HVAC & Controls.

[0000833444-24-000052:mdna:64]
•The increase in Building Solutions EMEA/LA was primarily due to organic growth ($136 million), partially offset by the unfavorable impact of foreign currency translation ($8 million). Excluding the impact of foreign currency translation, sales growth was led by growth in Services.

[0000833444-24-000052:mdna:65]
•The decrease in Building Solutions Asia Pacific was primarily due to organic sales declines ($408 million) and the unfavorable impact of foreign currency translation ($68 million). Excluding the impact of foreign currency translation, sales decreased as Services growth was more than offset by weakness in the China Systems business.

[0000833444-24-000052:mdna:66]
•The decrease in Global Products was due to the unfavorable impact of foreign currency translation ($144 million), partially offset by organic growth ($35 million) and the net impact of business acquisitions and divestitures ($17 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales increased as growth in Commercial HVAC was partially offset by declines in Residential HVAC.

[0000833444-24-000052:mdna:67]
[same as prior period, unchanged from 0000833444-24-000029:mdna:64]

[0000833444-24-000052:mdna:68]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Building Solutions North America | $ | 521 |  |  | $ | 385 |  |  | 35 | % |  | $ | 1,179 |  |  | $ | 967 |  |  | 22 | % |
| Building Solutions EMEA/LA | 111 |  |  | 90 |  |  | 23 |  |  | 280 |  |  | 234 |  |  | 20 |  |
| Building Solutions Asia Pacific | 67 |  |  | 102 |  |  | (34) |  |  | 167 |  |  | 249 |  |  | (33) |  |
| Global Products | 655 |  |  | 593 |  |  | 10 |  |  | 1,453 |  |  | 1,463 |  |  | (1) |  |

[0000833444-24-000052:mdna:69]
[same as prior period, unchanged from 0000833444-24-000029:mdna:66]

[0000833444-24-000052:mdna:70]
•The increase in Building Solutions North America was primarily due to higher margin backlog conversion, improved productivity and a favorable earn-out liability adjustment in the current quarter.

[0000833444-24-000052:mdna:71]
•The increase in Building Solutions EMEA/LA was primarily driven by positive mix from the growth in Services and the conversion of higher margin Systems backlog.

[0000833444-24-000052:mdna:72]
•The decrease in Building Solutions Asia Pacific was primarily driven by weakness in China, partially offset by positive mix from the Service business.

[0000833444-24-000052:mdna:73]
•The increase in Global Products was primarily due to positive price/cost and improved productivity, partially offset by unfavorable mix primarily from ongoing weakness in China.

[0000833444-24-000052:mdna:74]
[same as prior period, unchanged from 0000833444-24-000029:mdna:71]

[0000833444-24-000052:mdna:75]
•The increase in Building Solutions North America was primarily due to higher margin backlog conversion and continued growth in Services. A favorable earn-out liability adjustment also contributed to the increase.

[0000833444-24-000052:mdna:76]
•The increase in Building Solutions EMEA/LA was primarily due to growth in higher margin Services.

[0000833444-24-000052:mdna:77]
•The decrease in Building Solutions Asia Pacific was primarily due to continued weakness in the Systems business in China.

[0000833444-24-000052:mdna:78]
•The decrease in Global Products was primarily the result of unfavorable mix, the negative impact of a product quality issue and less favorable earn-out liability adjustments in the current year, partially offset by productivity improvements and the absence of the prior year loss associated with a fire at a leased warehouse facility.

[0000833444-24-000052:mdna:79]
[same as prior period, unchanged from 0000833444-24-000029:mdna:76]

[0000833444-24-000052:mdna:80]
Backlog and orders are additional metrics that are meant to provide management with a deeper level of insight into the progress of specific strategic and growth initiatives. Backlog is applicable to sales of systems and services and totaled $15.5 billion at June 30, 2024, including both Building Solutions and Global Products. Orders provide management with a signal of customer demand for the Company's products and services, as well as an indication of future revenues and performance. However, the timing and conversion of backlog and orders are subject to numerous uncertainties and risks and are not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-24-000052:mdna:81]
[same as prior period, unchanged from 0000833444-24-000029:mdna:78]

[0000833444-24-000052:mdna:82]
|  | Backlog |  | Orders |
| (in billions) | June 30, 2024 |  |  |  | Year-over-Year Change (1) |  | Three months ended June 30, 2024 |  |  |  | Year-over-Year Change (1) |
| Building Solutions North America | $ | 9.0 |  |  |  |  | 14 | % |  | $ | 3.1 |  |  |  |  | 5 | % |
| Building Solutions EMEA/LA | 2.5 |  |  |  |  | 12 | % |  | 1.1 |  |  |  |  | 11 | % |
| Building Solutions Asia Pacific | 1.4 |  |  |  |  | (12) | % |  | 0.8 |  |  |  |  | (2) | % |
| Total Building Solutions | $ | 12.9 |  |  |  |  | 10 | % |  | $ | 5.0 |  |  |  |  | 5 | % |

[0000833444-24-000052:mdna:83]
(1) Change is compared to June 30, 2023 (backlog) and the three months ended June 30, 2023 (orders) and excludes the impact of mergers, acquisitions, dispositions and foreign currency.

[0000833444-24-000052:mdna:84]
Remaining performance obligations were $21.4 billion at June 30, 2024. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-24-000052:mdna:85]
[same as prior period, unchanged from 0000833444-24-000029:mdna:82]

[0000833444-24-000052:mdna:86]
[same as prior period, unchanged from 0000833444-24-000029:mdna:83]

[0000833444-24-000052:mdna:87]
[same as prior period, unchanged from 0000833444-24-000029:mdna:84]

[0000833444-24-000052:mdna:88]
[same as prior period, unchanged from 0000833444-24-000029:mdna:85]

[0000833444-24-000052:mdna:89]
[same as prior period, unchanged from 0000833444-24-000029:mdna:86]

[0000833444-24-000052:mdna:90]
[same as prior period, unchanged from 0000833444-24-000029:mdna:87]

[0000833444-24-000052:mdna:91]
| (in millions) | June 30, 2024 |  | September 30, 2023 |  | Change |
| Current assets | $ | 12,153 |  |  | $ | 10,737 |  |  |  |
| Current liabilities | 12,724 |  |  | 11,084 |  |  |  |
| Working capital | $ | (571) |  |  | $ | (347) |  |  | (65) | % |
| Accounts receivable - net | $ | 6,667 |  |  | $ | 6,006 |  |  | 11 | % |
| Inventories | 2,863 |  |  | 2,776 |  |  | 3 | % |
| Accounts payable | 4,128 |  |  | 4,268 |  |  | (3) | % |

[0000833444-24-000052:mdna:92]
•The decrease in working capital was primarily due to higher current and short-term borrowings and the water systems AFFF settlement accrual, partially offset by increases in accounts receivable, AFFF insurance recovery receivables and the net impact of various other current assets and liabilities.

[0000833444-24-000052:mdna:93]
•In March 2024, the Company discontinued its receivables factoring programs. The Company did not factor any receivables during the three months ended June 30, 2024, and does not expect to engage in any receivables factoring during the remainder of fiscal year 2024, resulting in an unfavorable impact of approximately $700 million on operating cash flows in fiscal 2024.

[0000833444-24-000052:mdna:94]
•Material cash requirements primarily consist of working capital, capital expenditures, dividends, minimum pension contributions, debt maturities and interest, operating leases, payments related to the water systems AFFF settlement, and any potential acquisitions or stock repurchases. The Company expects cash requirements for the remainder of fiscal 2024 will be funded from operations, supplemented by other sources of short- and long-term borrowings, including term loans, commercial paper and the issuance of debt securities. The Company also expects to fund a portion of the payments related to the water systems AFFF settlement through insurance recoveries.

[0000833444-24-000052:mdna:95]
[same as prior period, unchanged from 0000833444-24-000029:mdna:93]

[0000833444-24-000052:mdna:96]
|  |  | Nine Months Ended June 30, |
| (in millions) |  | 2024 |  | 2023 |
| Cash provided by operating activities |  | $ | 572 |  |  | $ | 831 |  |
| Cash used by investing activities |  | (310) |  |  | (576) |  |
| Cash used by financing activities |  | (322) |  |  | (1,111) |  |

[0000833444-24-000052:mdna:97]
•The decrease in cash provided by operating activities was primarily due to increases in accounts receivable due to the discontinuation of factoring programs and to other assets due to AFFF insurance recovery receivables, partially offset by decreases in accounts payable and other accrued liabilities and reduced inventory growth.

[0000833444-24-000052:mdna:98]
•The decrease in cash used by investing activities was primarily due to lower capital expenditures and lower cash usage for acquisitions.

[0000833444-24-000052:mdna:99]
•The decrease in cash used by financing activities was primarily due to changes in net debt activity, primarily commercial paper, partially offset by higher share repurchases in the nine months ended June 30, 2024.

[0000833444-24-000052:mdna:100]
[same as prior period, unchanged from 0000833444-24-000029:mdna:98]

[0000833444-24-000052:mdna:101]
| (in millions) | June 30, 2024 |  | September 30, 2023 |  |  |
| Short-term debt | $ | 1,523 |  |  | $ | 385 |  |  |  |
| Current portion of long-term debt | 998 |  |  | 645 |  |  |  |
| Long-term debt | 7,867 |  |  | 7,818 |  |  |  |
| Total debt | 10,388 |  |  | 8,848 |  |  |  |
| Less: Cash and cash equivalents | 862 |  |  | 835 |  |  |  |
| Net debt | $ | 9,526 |  |  | $ | 8,013 |  |  |  |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders ("Equity") | $ | 15,968 |  |  | $ | 16,545 |  |  |  |
| Total capitalization (Total debt plus Equity) | 26,356 |  |  | 25,393 |  |  |  |
| Net capitalization (Net debt plus Equity) | 25,494 |  |  | 24,558 |  |  |  |
| Total debt as a % of Total capitalization | 39.4 | % |  | 34.8 | % |  |  |
| Net debt as a % of Net capitalization | 37.4 | % |  | 32.6 | % |  |  |

[0000833444-24-000052:mdna:102]
[same as prior period, unchanged from 0000833444-24-000029:mdna:100]

[0000833444-24-000052:mdna:103]
•As of June 30, 2024, approximately $2.1 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity, and the economic environment.

[0000833444-24-000052:mdna:104]
•The Company declared a dividend of $0.37 per common share in the quarter ended June 30, 2024 and intends to continue paying dividends throughout fiscal 2024.

[0000833444-24-000052:mdna:105]
•On April 12, 2024, Tyco Fire Products, a subsidiary of the Company, agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. Tyco Fire Products contributed an initial payment of $250 million in June 2024, with the remaining $500 million due by the first quarter of fiscal 2025. Prior to the date of the final contribution, Tyco Fire Products has agreed to contribute any applicable insurance recoveries in excess of the initial $250 million payment, up to the remaining $500 million due, within a specified period following the receipt of such recovery. During the three months ended June 30, 2024, the Company recorded expected insurance recoveries of $351 million in selling, general and administrative expenses in the consolidated statements of income, substantially all of the proceeds of which are expected to be received in the fourth quarter of fiscal 2024. In accordance with its agreement and recent insurance recovery, Tyco Fire Products will make an additional payment during the fourth quarter of fiscal 2024 of approximately $90 million, reducing its final payment to approximately $410 million. The amounts and timing of any additional insurance recoveries are uncertain. Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for additional discussion of the water systems settlement.

[0000833444-24-000052:mdna:106]
•The Company believes its capital resources and liquidity position, including cash and cash equivalents of $862 million at June 30, 2024, are adequate to fund operations and meet its cash obligations for the foreseeable future.

[0000833444-24-000052:mdna:107]
–The Company manages its short-term debt position in the U.S. and euro commercial paper and bank loan markets. Commercial paper outstanding totaled $941 million as of June 30, 2024 and $200 million as of September 30, 2023.

[0000833444-24-000052:mdna:108]
[same as prior period, unchanged from 0000833444-24-000029:mdna:106]

[0000833444-24-000052:mdna:109]
–The Company also has the ability to draw on its $2.5 billion revolving credit facility which is scheduled to expire in December 2028 or its $0.5 billion revolving credit facility which is scheduled to expire in December 2024. There were no draws on the revolving credit facilities as of June 30, 2024 and September 30, 2023.

[0000833444-24-000052:mdna:110]
–In April 2024, the Company and its wholly-owned subsidiary, Tyco Fire & Security Finance S.C.A, co-issued $700 million unsecured, unsubordinated senior notes with an interest rate of 5.50% which is due April 2029. In June 2024, the Company completed a debt tender offer to purchase $119 million of its 5.125% Notes due 2045.

[0000833444-24-000052:mdna:111]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of June 30, 2024, the Company's credit ratings and outlook were as follows:

[0000833444-24-000052:mdna:112]
[same as prior period, unchanged from 0000833444-24-000029:mdna:110]

[0000833444-24-000052:mdna:113]
[same as prior period, unchanged from 0000833444-24-000029:mdna:111]

[0000833444-24-000052:mdna:114]
•Financial covenants in the Company's revolving credit facilities require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of June 30, 2024, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-24-000052:mdna:115]
[same as prior period, unchanged from 0000833444-24-000029:mdna:114]

[0000833444-24-000052:mdna:116]
[same as prior period, unchanged from 0000833444-24-000029:mdna:115]

[0000833444-24-000052:mdna:117]
•Refer to Note 10, "Debt and Financing Arrangements," and Note 21, "Commitments and Contingencies" of the notes to the consolidated financial statements for additional information on debt balances, the water systems AFFF settlement agreement and items impacting capitalization.

[0000833444-24-000052:mdna:118]
[same as prior period, unchanged from 0000833444-24-000029:mdna:117]

[0000833444-24-000052:mdna:119]
[same as prior period, unchanged from 0000833444-24-000029:mdna:118]

[0000833444-24-000052:mdna:120]
•€500 million aggregate principal amount of 0.375% Senior Notes due 2027

[0000833444-24-000052:mdna:121]
•€600 million aggregate principal amount of 3.000% Senior Notes due 2028

[0000833444-24-000052:mdna:122]
•$700 million aggregate principal amount of 5.500% Senior Notes due 2029

[0000833444-24-000052:mdna:123]
•$625 million aggregate principal amount of 1.750% Senior Notes due 2030

[0000833444-24-000052:mdna:124]
•$500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due 2031

[0000833444-24-000052:mdna:125]
•€500 million aggregate principal amount of 1.000% Senior Notes due 2032

[0000833444-24-000052:mdna:126]
•$400 million aggregate principal amount of 4.900% Senior Notes due 2032

[0000833444-24-000052:mdna:127]
•€800 million aggregate principal amount of 4.25% Senior Notes due 2035

[0000833444-24-000052:mdna:128]
TFSCA is a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”) and is a wholly-owned consolidated subsidiary of the Company that is 99.924% owned directly by the Parent Company and 0.076% owned by TFSCA’s sole general partner and manager, Tyco Fire & Security S.à r.l., which is itself wholly-owned by the Company. The Parent Company is incorporated and organized

[0000833444-24-000052:mdna:129]
under the laws of Ireland. TFSCA is incorporated and organized under the laws of Luxembourg. The bankruptcy, insolvency, administrative, debtor relief and other laws of Luxembourg or Ireland, as applicable, may be materially different from, or in conflict with, those of the United States, including in the areas of rights of creditors, priority of governmental and other creditors, ability to obtain post-petition interest and duration of the proceeding. The application of these laws, or any conflict among them, could adversely affect noteholders’ ability to enforce their rights under the Notes in those jurisdictions or limit any amounts that they may receive.

[0000833444-24-000052:mdna:130]
[same as prior period, unchanged from 0000833444-24-000029:mdna:128]

[0000833444-24-000052:mdna:131]
|  |  | Nine Months Ended June 30, 2024 |  | Year Ended September 30, 2023 |  |
| Net loss attributable to the Obligor Group |  | $ | 404 |  |  | $ | 458 |  |  |
| Net income (loss) attributable to intercompany transactions |  | 422 |  |  | (139) |  |  |

[0000833444-24-000052:mdna:132]
[same as prior period, unchanged from 0000833444-24-000029:mdna:130]

[0000833444-24-000052:mdna:133]
[same as prior period, unchanged from 0000833444-24-000029:mdna:131]

[0000833444-24-000052:mdna:134]
|  |  | Obligor Group |  | Intercompany Balances |
|  |  | June 30, 2024 |  | September 30, 2023 |  | June 30, 2024 |  | September 30, 2023 |
| Current assets |  | $ | 927 |  |  | $ | 26 |  |  | $ | 785 |  |  | $ | 5,608 |  |
| Noncurrent assets |  | 256 |  |  | 270 |  |  | 7,031 |  |  | 1,882 |  |
| Current liabilities |  | 5,912 |  |  | 3,652 |  |  | 4,457 |  |  | 9,289 |  |
| Noncurrent liabilities |  | 7,713 |  |  | 7,585 |  |  | 7,062 |  |  | 3,462 |  |

[0000833444-24-000052:mdna:135]
[same as prior period, unchanged from 0000833444-24-000029:mdna:133]

[0000833444-24-000052:mdna:136]
[same as prior period, unchanged from 0000833444-24-000029:mdna:134]

[0000833444-24-000052:mdna:137]
[same as prior period, unchanged from 0000833444-24-000029:mdna:135]

[0000833444-24-000052:mdna:138]
[same as prior period, unchanged from 0000833444-24-000029:mdna:136]

[0000833444-24-000052:mdna:139]
[same as prior period, unchanged from 0000833444-24-000029:mdna:137]
