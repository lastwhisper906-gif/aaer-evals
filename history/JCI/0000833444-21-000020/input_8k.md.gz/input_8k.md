# JCI 8-K — 0000833444-21-000017 filed 2021-04-30

## item codes, every 8-K on or before 2021-04-30

- 2021-04-30 0000833444-21-000017 — 2.02, 9.01
- 2021-03-11 0000833444-21-000013 — 5.02, 5.07, 9.01
- 2021-02-17 0001193125-21-045768 — 7.01, 9.01
- 2021-01-29 0000833444-21-000009 — 2.02, 9.01
- 2021-01-07 0000833444-21-000004 — 7.01
- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2021-04-30

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-21-000017:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq2fy21.htm
EX-99.1

[0000833444-21-000017:8k_2_02:2]
Document

[0000833444-21-000017:8k_2_02:3]
Exhibit 99.1

[0000833444-21-000017:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-21-000017:8k_2_02:5]
Johnson Controls reports solid second quarter results and once again raises full-year guidance;

[0000833444-21-000017:8k_2_02:6]
Announces $250 million in new annual run rate COGS savings by fiscal 2023

[0000833444-21-000017:8k_2_02:7]
________________________________________________________________________________

[0000833444-21-000017:8k_2_02:8]
▪GAAP EPS of $0.48; Adjusted EPS of $0.52, up 24% versus prior year

[0000833444-21-000017:8k_2_02:9]
▪Sales and order growth inflected positive on both a nominal and organic basis; Backlog of $9.6 billion increases 4% organically year-over-year

[0000833444-21-000017:8k_2_02:10]
▪Cash provided by operating activities was $0.6 billion; Free cash flow of $0.5 billion

[0000833444-21-000017:8k_2_02:11]
▪Announces COGS cost actions to drive $250 million in annual run rate savings by fiscal 2023

[0000833444-21-000017:8k_2_02:12]
▪Provides fiscal 2021 third quarter adjusted earnings per share guidance range of $0.80 to $0.82

[0000833444-21-000017:8k_2_02:13]
▪Raises fiscal 2021 adjusted EPS guidance to $2.58 to $2.65, an increase of 15% to 18% year-over-year

[0000833444-21-000017:8k_2_02:14]
________________________________________________________________________________

[0000833444-21-000017:8k_2_02:15]
CORK, Ireland, April 30, 2021 -- Johnson Controls International plc (NYSE: JCI), the global leader for smart, healthy and sustainable buildings, today reported fiscal second quarter 2021 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.48. Excluding these items, adjusted EPS from continuing operations was $0.52, up 24% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-21-000017:8k_2_02:16]
Sales of $5.6 billion increased 3% compared to the prior year on a reported basis, and up 1% organically. GAAP net income from continuing operations was $343 million. Adjusted net income from continuing operations of $373 million, increased 18% versus the prior year. Earnings before interest and taxes (“EBIT”) was $650 million and EBIT margin was 11.6%. Adjusted EBIT was $537 million and adjusted EBIT margin was 9.6%, an increase of 150 basis points versus prior year results.

[0000833444-21-000017:8k_2_02:17]
“Our performance continues to strengthen as we emerge from the global pandemic with a sharpened focus on our future,” said chairman and CEO, George Oliver. “I am incredibly proud of our employees’ leadership and commitment through this time. The strategic actions we have taken to address future profitability, expand into key growth markets through disciplined capital allocation, deliver on sustainability, and expand our digital and service offerings, are all evidence of how we are executing our strategy,” Oliver continued.

[0000833444-21-000017:8k_2_02:18]
“Momentum in many of our end markets continues to build. Volumes in our Global Products business are recovering nicely, led by continued strength in Residential, while order activity in our non-residential businesses is accelerating and the pipeline is expanding further as we enter the second half of our year. Based on our year-to-date performance, the strength and resilience of our backlog, and the outlook for the remainder of the year, I am confident we are positioned to deliver on all of our commitments.”

[0000833444-21-000017:8k_2_02:19]
Page 1 of 18

[0000833444-21-000017:8k_2_02:20]
Cost Savings Program

[0000833444-21-000017:8k_2_02:21]
In addition to the multi-year SG&A actions designed to further optimize the overall cost structure and enhance operational efficiency that was announced in February, the company announced this morning the details of its multi-year Cost of Goods Sold (COGS) actions which are expected to deliver annualized net savings of $250 million. Together, these cost savings programs are expected to deliver a net $550 million in annualized net savings by fiscal year-end 2023. Additional details related to the COGS actions are included in the slide presentation.

[0000833444-21-000017:8k_2_02:22]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-21-000017:8k_2_02:23]
($ millions, except per-share amounts)

[0000833444-21-000017:8k_2_02:24]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the second fiscal quarter of 2020.

[0000833444-21-000017:8k_2_02:25]
Organic sales, total segment EBITA, adjusted segment EBITA, adjusted corporate expense, EBIT, adjusted EBIT, adjusted net income from continuing operations, adjusted EPS from continuing operations and free cash flow are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes. A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at

[0000833444-21-000017:8k_2_02:26]
http://investors.johnsoncontrols.com.

[0000833444-21-000017:8k_2_02:27]
|  |  | Fiscal Q2 |  |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |  |
| Sales |  | $5,444 |  |  | $5,594 |  |  | $5,444 |  |  | $5,594 |  |  |  |  |  |  |  |  |
| Segment EBITA |  | 617 |  | 711 |  | 619 |  | 711 |  |  |  |  |  |  |  |
| EBIT |  | 308 |  | 650 |  | 440 |  | 537 |  |  |  |  |  |  |  |
| Net income from continuing operations |  | 213 |  | 343 |  | 317 |  | 373 |  |  |  |  |  |  |  |
| Diluted EPS from continuing operations |  | $0.28 |  |  | $0.48 |  |  | $0.42 |  |  | $0.52 |  |  |  |  |  |  |  |  |

[0000833444-21-000017:8k_2_02:28]
Page 2 of 18

[0000833444-21-000017:8k_2_02:29]
SEGMENT RESULTS

[0000833444-21-000017:8k_2_02:30]
Building Solutions North America

[0000833444-21-000017:8k_2_02:31]
|  |  | Fiscal Q2 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |
| Sales |  | $2,175 |  |  | $2,092 |  |  | $2,175 |  |  | $2,092 |  |  |  |  |  |  |  |
| Segment EBITA |  | 251 |  | 266 |  | 253 |  | 266 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 11.5% |  | 12.7% |  | 11.6% |  | 12.7% |  |  |  |  |  |  |

[0000833444-21-000017:8k_2_02:32]
Sales in the quarter of $2.1 billion decreased 4% versus the prior year. Organic sales also declined 4% versus the prior year, driven by continued weakness in project installations due primarily to the slower order intake experienced throughout much of the pandemic. Strong growth in Performance Solutions resulting from increased demand for our energy savings performance contract business, was more than offset by a decline in Fire & Security and Applied HVAC & Controls.

[0000833444-21-000017:8k_2_02:33]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 5% year-over-year. Backlog at the end of the quarter of $6.0 billion increased 3% compared to the prior year, excluding M&A and adjusted for foreign currency.

[0000833444-21-000017:8k_2_02:34]
Adjusted segment EBITA was $266 million, up 5% versus the prior year. Adjusted segment EBITA margin of 12.7% expanded 110 basis points versus the prior year driven by significant cost mitigation actions and restructuring benefits as well as positive mix, which more than offset the impact of the volume decline.

[0000833444-21-000017:8k_2_02:35]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-21-000017:8k_2_02:36]
|  |  | Fiscal Q2 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |
| Sales |  | $850 |  |  | $897 |  |  | $850 |  |  | $897 |  |  |  |  |  |  |  |
| Segment EBITA |  | 85 |  | 86 |  | 85 |  | 86 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 10.0% |  | 9.6% |  | 10.0% |  | 9.6% |  |  |  |  |  |  |

[0000833444-21-000017:8k_2_02:37]
Sales in the quarter of $897 million increased 6% versus the prior year. Organic sales were flat with the prior year as a modest increase in project installations was offset by a modest decline in service.  Strength in our Industrial Refrigeration and Applied HVAC & Controls businesses was offset by a low-single digit

[0000833444-21-000017:8k_2_02:38]
Page 3 of 18

[0000833444-21-000017:8k_2_02:39]
decline in Fire & Security. Modest growth in Europe, despite continued headwinds related to the pandemic, was offset by declines in the Middle East and Latin America.

[0000833444-21-000017:8k_2_02:40]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 5% year-over-year. Backlog at the end of the quarter of $1.9 billion increased 7% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-21-000017:8k_2_02:41]
Adjusted segment EBITA was $86 million, up 1% versus the prior year. Adjusted segment EBITA margin of 9.6% declined 40 basis points over the prior year, including a 40 basis point headwind related to foreign currency. Adjusting for foreign currency, EMEALA’s underlying EBITA margin was flat with the prior year, as the benefit of mitigating cost actions was offset by lower equity income.

[0000833444-21-000017:8k_2_02:42]
Building Solutions Asia Pacific

[0000833444-21-000017:8k_2_02:43]
|  |  | Fiscal Q2 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |
| Sales |  | $525 |  |  | $603 |  |  | $525 |  |  | $603 |  |  |  |  |  |  |  |
| Segment EBITA |  | 65 |  | 74 |  | 65 |  | 74 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 12.4% |  | 12.3% |  | 12.4% |  | 12.3% |  |  |  |  |  |  |

[0000833444-21-000017:8k_2_02:44]
Sales in the quarter of $603 million increased 15% versus the prior year. Organic sales grew 9% versus the prior year with growth in both service and project installations, driven by strong growth in Applied HVAC & Controls. China continues to recover sharply, with the rest of Asia still mixed.

[0000833444-21-000017:8k_2_02:45]
Orders in the quarter, excluding M&A and adjusted for foreign currency, declined 1% year-over-year.  Significantly improved demand in China was offset by further declines in countries such as Japan, Korea and South East Asia. Backlog at the end of the quarter of $1.7 billion increased 4% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-21-000017:8k_2_02:46]
Adjusted segment EBITA was $74 million, up 14% versus the prior year. Adjusted segment EBITA margin of 12.3% declined 10 basis points versus the prior year including a 20 basis point headwind related to foreign currency and a divestiture.  Adjusting for this, Asia Pacific’s underlying EBITA margin increased 10 basis points as the benefit of volume leverage was mostly offset by geographic mix.

[0000833444-21-000017:8k_2_02:47]
Page 4 of 18

[0000833444-21-000017:8k_2_02:48]
Global Products

[0000833444-21-000017:8k_2_02:49]
|  |  | Fiscal Q2 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |
| Sales |  | $1,894 |  |  | $2,002 |  |  | $1,894 |  |  | $2,002 |  |  |  |  |  |  |  |
| Segment EBITA |  | 216 |  | 285 |  | 216 |  | 285 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 11.4% |  | 14.2% |  | 11.4% |  | 14.2% |  |  |  |  |  |  |

[0000833444-21-000017:8k_2_02:50]
Sales in the quarter of $2.0 billion increased 6% versus the prior year. Organic sales also grew 6% versus the prior year driven by growth in Residential HVAC and to a lesser extent Fire & Security. This growth was partially offset by a moderating decline in Commercial HVAC and Industrial Refrigeration.

[0000833444-21-000017:8k_2_02:51]
Adjusted segment EBITA was $285 million, up 32% versus the prior year. Adjusted segment EBITA margin of 14.2% expanded 280 basis points versus the prior year driven by volume leverage, increased equity income, the benefit of mitigating cost actions, and positive price/cost partially offset by negative mix.

[0000833444-21-000017:8k_2_02:52]
Corporate

[0000833444-21-000017:8k_2_02:53]
|  |  | Fiscal Q2 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |
| Corporate Expense |  | ($118) |  | ($70) |  | ($82) |  | ($70) |  |  |  |  |  |  |

[0000833444-21-000017:8k_2_02:54]
Adjusted Corporate expense was $70 million in the quarter, a decrease of 15% compared to the prior year, driven primarily by mitigating cost actions and continuous structural cost reductions.

[0000833444-21-000017:8k_2_02:55]
OTHER ITEMS

[0000833444-21-000017:8k_2_02:56]
▪For the quarter, cash provided by operating activities from continuing operations was $0.6 billion and capital expenditures were $0.1 billion, resulting in free cash flow from continuing operations of $0.5 billion.

[0000833444-21-000017:8k_2_02:57]
▪During the quarter, the company repurchased approximately 6 million shares for $315 million.

[0000833444-21-000017:8k_2_02:58]
▪During the quarter, the company increased its regular annual cash dividend to $1.08 per share, and its share repurchase authorization by $4 billion.

[0000833444-21-000017:8k_2_02:59]
Page 5 of 18

[0000833444-21-000017:8k_2_02:60]
▪During the quarter, the company repaid $257 million, in 4.25% senior notes that matured in March. This was replaced with a zero coupon €200M one-year bank loan.

[0000833444-21-000017:8k_2_02:61]
▪In early April, Johnson Controls announced an agreement to acquire Silent-Aire for up to $870 million, including an upfront payment of approximately $630 million and additional payments to be made subject to the achievement of post-closing earnout milestones.

[0000833444-21-000017:8k_2_02:62]
FY21 THIRD QUARTER AND FULL YEAR GUIDANCE

[0000833444-21-000017:8k_2_02:63]
Johnson Controls initiated fiscal 2021 third quarter guidance:

[0000833444-21-000017:8k_2_02:64]
▪Organic revenue growth up mid-teens year-over-year

[0000833444-21-000017:8k_2_02:65]
▪Adjusted segment EBITA margin up slightly, year-over-year

[0000833444-21-000017:8k_2_02:66]
▪Adjusted EPS before special items of $0.80 to $0.82; represents 19 to 22% growth year-over-year

[0000833444-21-000017:8k_2_02:67]
The company raised fiscal 2021 full year guidance:

[0000833444-21-000017:8k_2_02:68]
▪Organic revenue growth up mid-single digits year-over-year

[0000833444-21-000017:8k_2_02:69]
▪Adjusted segment EBITA margin expansion of 70 to 90 basis points, year-over-year

[0000833444-21-000017:8k_2_02:70]
▪Adjusted EPS before special items of $2.58 to $2.65; represents 15 to 18% growth year-over-year

[0000833444-21-000017:8k_2_02:71]
CONFERENCE CALL & WEBCAST INFO

[0000833444-21-000017:8k_2_02:72]
Johnson Controls will host a conference call to discuss this quarter’s results at 8:30 a.m. ET today, which can be accessed by dialing 888-324-9610 (in the United States) or 630-395-0255 (outside the United States), or via webcast. The passcode is “Johnson Controls”. A slide presentation will accompany the prepared remarks and has been posted on the investor relations section of the Johnson Controls website at https://investors.johnsoncontrols.com/news-and-events/events-and-presentations. A replay will be made available approximately two hours following the conclusion of the conference call.

[0000833444-21-000017:8k_2_02:73]
Page 6 of 18

[0000833444-21-000017:8k_2_02:74]
About Johnson Controls:

[0000833444-21-000017:8k_2_02:75]
At Johnson Controls (NYSE:JCI) we transform the environments where people live, work, learn and play. As the global leader in smart, healthy and sustainable buildings, our mission is to reimagine the performance of buildings to serve people, places and the planet.

[0000833444-21-000017:8k_2_02:76]
With a history of more than 135 years of innovation, Johnson Controls delivers the blueprint of the future for industries such as healthcare, schools, data centers, airports, stadiums, manufacturing and beyond through its comprehensive digital offering OpenBlue. With a global team of 100,000 experts in more than 150 countries, Johnson Controls offers the world`s largest portfolio of building technology, software as well as service solutions with some of the most trusted names in the industry. For more information, visit www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter.

[0000833444-21-000017:8k_2_02:77]
JOHNSON CONTROLS CONTACTS:

[0000833444-21-000017:8k_2_02:78]
| INVESTOR CONTACTS: | MEDIA CONTACTS: |  |  |  |
| Antonella Franzen | Chaz Bickers |  |  |  |
| Direct: 609.720.4665 | Direct: 224.307.0655 |  |  |  |
| Email: antonella.franzen@jci.com | Email: charles.norman.bickers@jci.com |  |  |  |
| Ryan Edelman | Michael Isaac |  |  |  |
| Direct: 609.720.4545 | Direct: +41 52 6330374 |  |  |  |
| Email: ryan.edelman@jci.com | Email: michael.isaac@jci.com |  |  |  |

[0000833444-21-000017:8k_2_02:79]
###

[0000833444-21-000017:8k_2_02:80]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-21-000017:8k_2_02:81]
Page 7 of 18

[0000833444-21-000017:8k_2_02:82]
achieve market acceptance; changes to laws or policies governing foreign trade, including increased tariffs or trade restrictions; maintaining the capacity, reliability and security of our enterprise and product information technology infrastructure; the risk of infringement or expiration of intellectual property rights; any delay or inability of Johnson Controls to realize the expected benefits and synergies of recent portfolio transactions such as its merger with Tyco and the disposition of the Power Solutions business;  the outcome of litigation and governmental proceedings; the ability to hire and retain key senior   management; the tax treatment of recent portfolio transactions; significant transaction costs and/or unknown liabilities associated with such transactions; the availability of raw materials and component products; fluctuations in currency exchange rates; work stoppages, union negotiations, labor disputes and other matters associated with the labor force; the cancellation of or changes to commercial arrangements.  A detailed discussion of risks related to Johnson Controls’ business is included in the section entitled “Risk Factors” in Johnson Controls’ Annual Report on Form 10-K for the 2020 fiscal year filed with the SEC on November 16, 2020, which is available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-21-000017:8k_2_02:83]
###

[0000833444-21-000017:8k_2_02:84]
Non-GAAP Financial Information

[0000833444-21-000017:8k_2_02:85]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include restructuring and impairment costs, transaction costs, integration costs, net mark-to-market adjustments, Power Solutions divestiture reserve adjustment and discrete tax items. Financial information regarding organic sales, EBIT, EBIT margin, adjusted EBIT, adjusted EBIT margin, total segment EBITA, adjusted segment EBITA, adjusted segment EBITA margin, adjusted corporate expense, free cash flow, and adjusted net income (loss) from continuing operations are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as integration costs because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.  For further information on the calculation of thee non-GAAP measures and a reconciliation of these non-GAAP measures, refer to the attached footnotes.

[0000833444-21-000017:8k_2_02:86]
###

[0000833444-21-000017:8k_2_02:87]
Page 8 of 18

[0000833444-21-000017:8k_2_02:88]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |  |
|  |  | Three Months Ended March 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Net sales | $ | 5,594 |  |  |  | $ | 5,444 |  |  |
| Cost of sales | 3,651 |  |  |  | 3,643 |  |  |
|  | Gross profit | 1,943 |  |  |  | 1,801 |  |  |
| Selling, general and administrative expenses | (1,253) |  |  |  | (1,451) |  |  |
| Restructuring and impairment costs | (96) |  |  |  | (62) |  |  |
| Net financing charges | (44) |  |  |  | (59) |  |  |
| Equity income | 56 |  |  |  | 20 |  |  |
| Income from continuing operations before income taxes | 606 |  |  |  | 249 |  |  |
| Income tax provision | 209 |  |  |  | 13 |  |  |
| Income from continuing operations | 397 |  |  |  | 236 |  |  |
| Income from discontinued operations, net of tax | — |  |  |  | — |  |  |
| Net income | 397 |  |  |  | 236 |  |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 54 |  |  |  | 23 |  |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |  |
| Net income attributable to JCI | $ | 343 |  |  |  | $ | 213 |  |  |
| Income from continuing operations | $ | 343 |  |  |  | $ | 213 |  |  |
| Income from discontinued operations | — |  |  |  | — |  |  |
| Net income attributable to JCI | $ | 343 |  |  |  | $ | 213 |  |  |
| Diluted earnings per share from continuing operations | $ | 0.48 |  |  |  | $ | 0.28 |  |  |
| Diluted earnings per share from discontinued operations | — |  |  |  | — |  |  |
| Diluted earnings per share | $ | 0.48 |  |  |  | $ | 0.28 |  |  |
| Diluted weighted average shares | 721.3 |  |  |  | 757.1 |  |  |
| Shares outstanding at period end | 716.7 |  |  |  | 743.9 |  |  |

[0000833444-21-000017:8k_2_02:89]
Page 9 of 18

[0000833444-21-000017:8k_2_02:90]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Six Months Ended March 31, |
|  |  | 2021 |  |  | 2020 |
| Net sales | $ | 10,935 |  |  |  | $ | 11,020 |  |
| Cost of sales | 7,264 |  |  |  | 7,416 |  |
|  | Gross profit | 3,671 |  |  |  | 3,604 |  |
| Selling, general and administrative expenses | (2,547) |  |  |  | (2,878) |  |
| Restructuring and impairment costs | (96) |  |  |  | (173) |  |
| Net financing charges | (103) |  |  |  | (111) |  |
| Equity income | 114 |  |  |  | 63 |  |
| Income from continuing operations before income taxes | 1,039 |  |  |  | 505 |  |
| Income tax provision | 270 |  |  |  | 78 |  |
| Income from continuing operations | 769 |  |  |  | 427 |  |
| Income from discontinued operations, net of tax | 124 |  |  |  | — |  |
| Net income | 893 |  |  |  | 427 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 99 |  |  |  | 55 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |
| Net income attributable to JCI | $ | 794 |  |  |  | $ | 372 |  |
| Income from continuing operations | $ | 670 |  |  |  | $ | 372 |  |
| Income from discontinued operations | 124 |  |  |  | — |  |
| Net income attributable to JCI | $ | 794 |  |  |  | $ | 372 |  |
| Diluted earnings per share from continuing operations | $ | 0.93 |  |  |  | $ | 0.49 |  |
| Diluted earnings per share from discontinued operations | 0.17 |  |  |  | — |  |
| Diluted earnings per share | $ | 1.10 |  |  |  | $ | 0.49 |  |
| Diluted weighted average shares | 723.9 |  |  |  | 765.6 |  |
| Shares outstanding at period end | 716.7 |  |  |  | 743.9 |  |

[0000833444-21-000017:8k_2_02:91]
Page 10 of 18

[0000833444-21-000017:8k_2_02:92]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | March 31,2021 |  | September 30,2020 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 1,883 |  |  | $ | 1,951 |  |
| Accounts receivable - net | 5,167 |  |  | 5,294 |  |
| Inventories | 1,994 |  |  | 1,773 |  |
| Other current assets | 1,160 |  |  | 1,035 |  |
|  | Current assets | 10,204 |  |  | 10,053 |  |
| Property, plant and equipment - net | 3,015 |  |  | 3,059 |  |
| Goodwill | 18,124 |  |  | 17,932 |  |
| Other intangible assets - net | 5,259 |  |  | 5,356 |  |
| Investments in partially-owned affiliates | 1,045 |  |  | 914 |  |
| Noncurrent assets held for sale | 179 |  |  | 147 |  |
| Other noncurrent assets | 3,354 |  |  | 3,354 |  |
|  | Total assets | $ | 41,180 |  |  | $ | 40,815 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 444 |  |  | $ | 293 |  |
| Accounts payable and accrued expenses | 4,234 |  |  | 3,958 |  |
| Other current liabilities | 4,062 |  |  | 3,997 |  |
|  | Current liabilities | 8,740 |  |  | 8,248 |  |
| Long-term debt | 7,323 |  |  | 7,526 |  |
| Other noncurrent liabilities | 6,360 |  |  | 6,508 |  |
| Shareholders' equity attributable to JCI | 17,698 |  |  | 17,447 |  |
| Noncontrolling interests | 1,059 |  |  | 1,086 |  |
|  | Total liabilities and equity | $ | 41,180 |  |  | $ | 40,815 |  |

[0000833444-21-000017:8k_2_02:93]
Page 11 of 18

[0000833444-21-000017:8k_2_02:94]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended March 31, |
|  |  |  |  |  |  | 2021 |  |  | 2020 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI from continuing operations | $ | 343 |  |  |  | $ | 213 |  |
| Income from continuing operations attributable to noncontrolling interests | 54 |  |  |  | 23 |  |
| Net income from continuing operations | 397 |  |  |  | 236 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 212 |  |  |  | 207 |  |
|  |  | Pension and postretirement benefit income | (253) |  |  |  | (40) |  |
|  |  | Pension and postretirement contributions | (8) |  |  |  | (15) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (55) |  |  |  | (19) |  |
|  |  | Deferred income taxes | 84 |  |  |  | (58) |  |
|  |  | Non-cash restructuring and impairment costs | 54 |  |  |  | 62 |  |
|  |  | Other - net | (7) |  |  |  | 40 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (57) |  |  |  | 7 |  |
|  |  |  |  | Inventories | (113) |  |  |  | (147) |  |
|  |  |  |  | Other assets | (20) |  |  |  | (58) |  |
|  |  |  |  | Restructuring reserves | 10 |  |  |  | (71) |  |
|  |  |  |  | Accounts payable and accrued liabilities | 419 |  |  |  | (107) |  |
|  |  |  |  | Accrued income taxes | (18) |  |  |  | 118 |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 645 |  |  |  | 155 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (106) |  |  |  | (124) |  |
| Acquisition of businesses, net of cash acquired | (10) |  |  |  | (10) |  |
| Business divestitures, net of cash divested | 8 |  |  |  | — |  |
| Other - net | 26 |  |  |  | 19 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (82) |  |  |  | (115) |  |
| Financing Activities |  |  |  |  |
| Decrease in short and long-term debt - net | (13) |  |  |  | (177) |  |
| Stock repurchases | (315) |  |  |  | (816) |  |
| Payment of cash dividends | (187) |  |  |  | (199) |  |
| Dividends paid to noncontrolling interests | (101) |  |  |  | — |  |
| Proceeds from the exercise of stock options | 102 |  |  |  | 18 |  |
| Cash paid to acquire a noncontrolling interest | (14) |  |  |  | — |  |
| Employee equity-based compensation withholding | (8) |  |  |  | (12) |  |
| Other - net | 4 |  |  |  | — |  |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (532) |  |  |  | (1,186) |  |
| Discontinued Operations |  |  |  |  |
| Net cash used by operating activities | (1) |  |  |  | (14) |  |
| Net cash used by investing activities | — |  |  |  | — |  |
| Net cash used by financing activities | — |  |  |  | — |  |
|  |  |  |  |  | Net cash flows used by discontinued operations | (1) |  |  |  | (14) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 20 |  |  |  | 7 |  |
| Changes in cash held for sale | — |  |  |  | — |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | $ | 50 |  |  |  | $ | (1,153) |  |

[0000833444-21-000017:8k_2_02:95]
Page 12 of 18

[0000833444-21-000017:8k_2_02:96]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Six Months Ended March 31, |
|  |  |  |  |  |  | 2021 |  |  | 2020 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI from continuing operations | $ | 670 |  |  |  | $ | 372 |  |
| Income from continuing operations attributable to noncontrolling interests | 99 |  |  |  | 55 |  |
| Net income from continuing operations | 769 |  |  |  | 427 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 419 |  |  |  | 414 |  |
|  |  | Pension and postretirement benefit income | (299) |  |  |  | (80) |  |
|  |  | Pension and postretirement contributions | (25) |  |  |  | (27) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (107) |  |  |  | (11) |  |
|  |  | Deferred income taxes | 25 |  |  |  | (61) |  |
|  |  | Non-cash restructuring and impairment costs | 54 |  |  |  | 116 |  |
|  |  | Other - net | (32) |  |  |  | 56 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | 167 |  |  |  | 244 |  |
|  |  |  |  | Inventories | (211) |  |  |  | (261) |  |
|  |  |  |  | Other assets | (90) |  |  |  | (150) |  |
|  |  |  |  | Restructuring reserves | (24) |  |  |  | (38) |  |
|  |  |  |  | Accounts payable and accrued liabilities | 510 |  |  |  | (605) |  |
|  |  |  |  | Accrued income taxes | 4 |  |  |  | 642 |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 1,160 |  |  |  | 666 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (197) |  |  |  | (250) |  |
| Acquisition of businesses, net of cash acquired | (10) |  |  |  | (58) |  |
| Business divestitures, net of cash divested | 19 |  |  |  | — |  |
| Other - net | 69 |  |  |  | 20 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (119) |  |  |  | (288) |  |
| Financing Activities |  |  |  |  |
| Decrease in short and long-term debt - net | (33) |  |  |  | (167) |  |
| Stock repurchases | (661) |  |  |  | (1,467) |  |
| Payment of cash dividends | (377) |  |  |  | (402) |  |
| Proceeds from the exercise of stock options | 133 |  |  |  | 39 |  |
| Dividends paid to noncontrolling interests | (101) |  |  |  | (5) |  |
| Cash paid to acquire a noncontrolling interest | (14) |  |  |  | — |  |
| Employee equity-based compensation withholding | (29) |  |  |  | (32) |  |
| Other - net | 3 |  |  |  | (2) |  |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (1,079) |  |  |  | (2,036) |  |
| Discontinued Operations |  |  |  |  |
| Net cash used by operating activities | (37) |  |  |  | (208) |  |
| Net cash used by investing activities | — |  |  |  | — |  |
| Net cash used by financing activities | — |  |  |  | — |  |
|  |  |  |  |  | Net cash flows used by discontinued operations | (37) |  |  |  | (208) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 9 |  |  |  | 64 |  |
| Changes in cash held for sale | — |  |  |  | — |  |
| Decrease in cash, cash equivalents and restricted cash | $ | (66) |  |  |  | $ | (1,802) |  |

[0000833444-21-000017:8k_2_02:97]
Page 13 of 18

[0000833444-21-000017:8k_2_02:98]
FOOTNOTES

[0000833444-21-000017:8k_2_02:99]
1. Financial Summary

[0000833444-21-000017:8k_2_02:100]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans. The financial results shown below are for continuing operations and exclude the Power Solutions business.

[0000833444-21-000017:8k_2_02:101]
| (in millions; unaudited) | Three Months Ended March 31, |
|  | 2021 |  | 2020 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Net sales |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,092 |  |  | $ | 2,092 |  |  | $ | 2,175 |  |  | $ | 2,175 |  |
| Building Solutions EMEA/LA | 897 |  |  | 897 |  |  | 850 |  |  | 850 |  |
| Building Solutions Asia Pacific | 603 |  |  | 603 |  |  | 525 |  |  | 525 |  |
| Global Products | 2,002 |  |  | 2,002 |  |  | 1,894 |  |  | 1,894 |  |
| Net sales | $ | 5,594 |  |  | $ | 5,594 |  |  | $ | 5,444 |  |  | $ | 5,444 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 266 |  |  | $ | 266 |  |  | $ | 251 |  |  | $ | 253 |  |
| Building Solutions EMEA/LA | 86 |  |  | 86 |  |  | 85 |  |  | 85 |  |
| Building Solutions Asia Pacific | 74 |  |  | 74 |  |  | 65 |  |  | 65 |  |
| Global Products | 285 |  |  | 285 |  |  | 216 |  |  | 216 |  |
| Segment EBITA | 711 |  |  | 711 |  |  | 617 |  |  | 619 |  |
| Corporate expenses (2) | (70) |  |  | (70) |  |  | (118) |  |  | (82) |  |
| Amortization of intangible assets | (104) |  |  | (104) |  |  | (97) |  |  | (97) |  |
| Net mark-to-market adjustments (3) | 209 |  |  | — |  |  | (32) |  |  | — |  |
| Restructuring and impairment costs (4) | (96) |  |  | — |  |  | (62) |  |  | — |  |
| EBIT (5) | 650 |  |  | 537 |  |  | 308 |  |  | 440 |  |
| EBIT margin | 11.6 | % |  | 9.6 | % |  | 5.7 | % |  | 8.1 | % |
| Net financing charges | (44) |  |  | (44) |  |  | (59) |  |  | (59) |  |
| Income from continuing operations before income taxes | 606 |  |  | 493 |  |  | 249 |  |  | 381 |  |
| Income tax provision (6) | (209) |  |  | (66) |  |  | (13) |  |  | (52) |  |
| Income from continuing operations | 397 |  |  | 427 |  |  | 236 |  |  | 329 |  |
| Income from continuing operations attributable to noncontrolling interests | (54) |  |  | (54) |  |  | (23) |  |  | (12) |  |
| Net income from continuing operations attributable to JCI | $ | 343 |  |  | $ | 373 |  |  | $ | 213 |  |  | $ | 317 |  |

[0000833444-21-000017:8k_2_02:102]
| (in millions; unaudited) | Six Months Ended March 31, |
|  | 2021 |  | 2020 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Net sales |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 4,126 |  |  | $ | 4,126 |  |  | $ | 4,342 |  |  | $ | 4,342 |  |
| Building Solutions EMEA/LA | 1,803 |  |  | 1,803 |  |  | 1,778 |  |  | 1,778 |  |
| Building Solutions Asia Pacific | 1,218 |  |  | 1,218 |  |  | 1,154 |  |  | 1,154 |  |
| Global Products | 3,788 |  |  | 3,788 |  |  | 3,746 |  |  | 3,746 |  |
| Net sales | $ | 10,935 |  |  | $ | 10,935 |  |  | $ | 11,020 |  |  | $ | 11,020 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 521 |  |  | $ | 521 |  |  | $ | 509 |  |  | $ | 512 |  |
| Building Solutions EMEA/LA | 181 |  |  | 181 |  |  | 175 |  |  | 175 |  |
| Building Solutions Asia Pacific | 153 |  |  | 153 |  |  | 137 |  |  | 137 |  |
| Global Products | 498 |  |  | 498 |  |  | 419 |  |  | 420 |  |
| Segment EBITA | 1,353 |  |  | 1,353 |  |  | 1,240 |  |  | 1,244 |  |
| Corporate expenses (2) | (137) |  |  | (137) |  |  | (236) |  |  | (163) |  |
| Amortization of intangible assets | (208) |  |  | (208) |  |  | (193) |  |  | (193) |  |
| Net mark-to-market adjustments (3) | 230 |  |  | — |  |  | (22) |  |  | — |  |
| Restructuring and impairment costs (4) | (96) |  |  | — |  |  | (173) |  |  | — |  |
| EBIT (5) | 1,142 |  |  | 1,008 |  |  | 616 |  |  | 888 |  |
| EBIT margin | 10.4 | % |  | 9.2 | % |  | 5.6 | % |  | 8.1 | % |
| Net financing charges | (103) |  |  | (103) |  |  | (111) |  |  | (111) |  |
| Income from continuing operations before income taxes | 1,039 |  |  | 905 |  |  | 505 |  |  | 777 |  |
| Income tax provision (6) | (270) |  |  | (122) |  |  | (78) |  |  | (105) |  |
| Income from continuing operations | 769 |  |  | 783 |  |  | 427 |  |  | 672 |  |
| Income from continuing operations attributable to noncontrolling interests | (99) |  |  | (99) |  |  | (55) |  |  | (49) |  |
| Net income from continuing operations attributable to JCI | $ | 670 |  |  | $ | 684 |  |  | $ | 372 |  |  | $ | 623 |  |

[0000833444-21-000017:8k_2_02:103]
(1) The Company's press release contains financial information regarding segment EBITA, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-21-000017:8k_2_02:104]
A reconciliation of segment EBITA to income from continuing operations is shown earlier within this footnote. The following is the three months ended March 31, 2021 and 2020 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-21-000017:8k_2_02:105]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Segment EBITA as reported | $ | 266 |  |  | $ | 251 |  |  | $ | 86 |  |  | $ | 85 |  |  | $ | 74 |  |  | $ | 65 |  |  | $ | 285 |  |  | $ | 216 |  |  | $ | 711 |  |  | $ | 617 |  |
| Segment EBITA margin as reported | 12.7 | % |  | 11.5 | % |  | 9.6 | % |  | 10.0 | % |  | 12.3 | % |  | 12.4 | % |  | 14.2 | % |  | 11.4 | % |  | 12.7 | % |  | 11.3 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | — |  |  | 2 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2 |  |
| Adjusted segment EBITA | $ | 266 |  |  | $ | 253 |  |  | $ | 86 |  |  | $ | 85 |  |  | $ | 74 |  |  | $ | 65 |  |  | $ | 285 |  |  | $ | 216 |  |  | $ | 711 |  |  | $ | 619 |  |
| Adjusted segment EBITA margin | 12.7 | % |  | 11.6 | % |  | 9.6 | % |  | 10.0 | % |  | 12.3 | % |  | 12.4 | % |  | 14.2 | % |  | 11.4 | % |  | 12.7 | % |  | 11.4 | % |

[0000833444-21-000017:8k_2_02:106]
Page 14 of 18

[0000833444-21-000017:8k_2_02:107]
The following is the six months ended March 31, 2021 and 2020 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-21-000017:8k_2_02:108]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Segment EBITA as reported | $ | 521 |  |  | $ | 509 |  |  | $ | 181 |  |  | $ | 175 |  |  | $ | 153 |  |  | $ | 137 |  |  | $ | 498 |  |  | $ | 419 |  |  | $ | 1,353 |  |  | $ | 1,240 |  |
| Segment EBITA margin as reported | 12.6 | % |  | 11.7 | % |  | 10.0 | % |  | 9.8 | % |  | 12.6 | % |  | 11.9 | % |  | 13.1 | % |  | 11.2 | % |  | 12.4 | % |  | 11.3 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | — |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 4 |  |
| Adjusted segment EBITA | $ | 521 |  |  | $ | 512 |  |  | $ | 181 |  |  | $ | 175 |  |  | $ | 153 |  |  | $ | 137 |  |  | $ | 498 |  |  | $ | 420 |  |  | $ | 1,353 |  |  | $ | 1,244 |  |
| Adjusted segment EBITA margin | 12.6 | % |  | 11.8 | % |  | 10.0 | % |  | 9.8 | % |  | 12.6 | % |  | 11.9 | % |  | 13.1 | % |  | 11.2 | % |  | 12.4 | % |  | 11.3 | % |

[0000833444-21-000017:8k_2_02:109]
(2)  Adjusted Corporate expenses excludes special items because these costs are not considered to be directly related to the underlying operating performance of the Company's business. Adjusted Corporate expenses for the three months ended March 31, 2020 excludes $36 million of integration costs. Adjusted Corporate expenses for the six months ended March 31, 2020 excludes $73 million of integration costs.

[0000833444-21-000017:8k_2_02:110]
(3) The three months ended March 31, 2021 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $209 million. The six months ended March 31, 2021 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $230 million. The three months ended March 31, 2020 exclude the net mark-to-market adjustments on restricted investments of $32 million. The six months ended March 31, 2020 exclude the net mark-to-market adjustments on restricted investments of $22 million.

[0000833444-21-000017:8k_2_02:111]
(4) Restructuring and impairment costs for the three and six months ended March 31, 2021 of $96 million are excluded from the adjusted non-GAAP results. Restructuring and impairment costs for the three months ended March 31, 2020 of $62 million are excluded from the adjusted non-GAAP results. Restructuring and impairment costs for the six months ended March 31, 2020 of $173 million are excluded from the adjusted non-GAAP results. The restructuring actions and impairment costs related primarily to workforce reductions, plant closures and asset impairments.

[0000833444-21-000017:8k_2_02:112]
(5) Management defines earnings before interest and taxes (EBIT) as income (loss) from continuing operations before net financing charges, income taxes and noncontrolling interests. EBIT is a non-GAAP performance measure. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company. A reconciliation of EBIT to income from continuing operations is shown earlier within this footnote.

[0000833444-21-000017:8k_2_02:113]
(6) Adjusted income tax provision for the three months ended March 31, 2021 excludes tax provisions from a Mexico valuation allowance adjustment of $105 million and net mark-to-market adjustments of $53 million, partially offset by tax benefits related to restructuring and impairment costs of $15 million. Adjusted income tax provision for the six months ended March 31, 2021 excludes tax provisions from a Mexico valuation allowance adjustment of $105 million and net mark-to-market adjustments of $58 million, partially offset by tax benefits related to restructuring and impairment costs of $15 million. Adjusted income tax provision for the three months ended March 31, 2020 excludes tax benefits from tax audit reserve adjustments of $22 million, net mark-to-market adjustments of $7 million, integration costs of $6 million, and restructuring and impairment costs of $4 million. Adjusted income tax provision for the six months ended March 31, 2020 excludes tax benefits from tax audit reserve adjustments of $22 million, restructuring and impairment costs of $20 million, integration costs of $11 million and net mark-to-market adjustments of $4 million, partially offset by tax provisions related to Switzerland tax reform of $30 million.

[0000833444-21-000017:8k_2_02:114]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-21-000017:8k_2_02:115]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include transaction/integration costs, net mark-to-market adjustments, restructuring and impairment costs, Power Solutions divestiture reserve adjustment and discrete tax items. The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-21-000017:8k_2_02:116]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-21-000017:8k_2_02:117]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Three Months Ended |  | Three Months Ended |  | Six Months Ended |  | Six Months Ended |
|  | March 31, |  | March 31, |  | March 31, |  | March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Earnings per share as reported for JCI plc | $ | 0.48 |  |  | $ | 0.28 |  |  | $ | 0.48 |  |  | $ | 0.28 |  |  | $ | 1.10 |  |  | $ | 0.49 |  |  | $ | 0.93 |  |  | $ | 0.49 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | — |  |  | 0.05 |  |  | — |  |  | 0.05 |  |  | — |  |  | 0.10 |  |  | — |  |  | 0.10 |  |
| Related tax impact | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |
| Net mark-to-market adjustments | (0.29) |  |  | 0.04 |  |  | (0.29) |  |  | 0.04 |  |  | (0.32) |  |  | 0.03 |  |  | (0.32) |  |  | 0.03 |  |
| Related tax impact | 0.07 |  |  | (0.01) |  |  | 0.07 |  |  | (0.01) |  |  | 0.08 |  |  | (0.01) |  |  | 0.08 |  |  | (0.01) |  |
| Restructuring and impairment costs | 0.13 |  |  | 0.08 |  |  | 0.13 |  |  | 0.08 |  |  | 0.13 |  |  | 0.23 |  |  | 0.13 |  |  | 0.23 |  |
| Related tax impact | (0.02) |  |  | (0.01) |  |  | (0.02) |  |  | (0.01) |  |  | (0.02) |  |  | (0.03) |  |  | (0.02) |  |  | (0.03) |  |
| NCI impact of restructuring and impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |
| Power Solutions divestiture reserve adjustment | — |  |  | — |  |  | — |  |  | — |  |  | (0.21) |  |  | — |  |  | — |  |  | — |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |  | 0.04 |  |  | — |  |  | — |  |  | — |  |
| Discrete tax items | 0.15 |  |  | (0.03) |  |  | 0.15 |  |  | (0.03) |  |  | 0.15 |  |  | 0.01 |  |  | 0.15 |  |  | 0.01 |  |
| NCI impact of discrete tax items | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |
| Adjusted earnings per share for JCI plc* | $ | 0.52 |  |  | $ | 0.42 |  |  | $ | 0.52 |  |  | $ | 0.42 |  |  | $ | 0.94 |  |  | $ | 0.81 |  |  | $ | 0.94 |  |  | $ | 0.81 |  |

[0000833444-21-000017:8k_2_02:118]
* May not sum due to rounding

[0000833444-21-000017:8k_2_02:119]
Page 15 of 18

[0000833444-21-000017:8k_2_02:120]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-21-000017:8k_2_02:121]
|  | Three Months Ended |  | Six Months Ended |  |  |  |  |
|  | March 31, |  | March 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 717.1 |  |  | 754.8 |  |  | 720.1 |  |  | 762.4 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |  |  |  |  |
| and unvested performance share awards | 4.2 |  |  | 2.3 |  |  | 3.8 |  |  | 3.2 |  |  |  |  |  |
| Diluted weighted average shares outstanding | 721.3 |  |  | 757.1 |  |  | 723.9 |  |  | 765.6 |  |  |  |  |  |

[0000833444-21-000017:8k_2_02:122]
The Company has presented forward-looking statements regarding adjusted corporate expense, adjusted EPS, organic revenue, adjusted segment EBITA margin and free cash flow conversion, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, or income from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments and the effect of foreign currency exchange fluctuations. Our fiscal 2021 full year and third quarter guidance for organic revenue also excludes the effect of acquisitions, divestitures and foreign currency. Our fiscal 2021 full year and third quarter guidance for adjusted segment EBITA margin, adjusted EPS and amortization expense also excludes the effect of the announced acquisition of Silent-Aire. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s third quarter and full year 2021 GAAP financial results.

[0000833444-21-000017:8k_2_02:123]
3. Organic Growth Reconciliation

[0000833444-21-000017:8k_2_02:124]
The components of the changes in net sales for the three months ended March 31, 2021 versus the three months ended March 31, 2020, including organic growth, is shown below (unaudited):

[0000833444-21-000017:8k_2_02:125]
| (in millions) | Net Sales for theThree Months EndedMarch 31, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the ThreeMonths EndedMarch 31, 2020 |  | Acquisitions |  | Organic Growth |  | Net Sales for theThree Months EndedMarch 31, 2021 |
| Building Solutions North America | $ | 2,175 |  |  | $ | — |  |  | — |  |  | $ | 13 |  |  | 1 | % |  | $ | 2,188 |  |  | $ | — |  |  | — |  |  | $ | (96) |  |  | -4 | % |  | $ | 2,092 |  |  | -4 | % |
| Building Solutions EMEA/LA | 850 |  |  | — |  |  | — |  |  | 42 |  |  | 5 | % |  | 892 |  |  | 4 |  |  | — |  |  | 1 |  |  | — |  |  | 897 |  |  | 6 | % |
| Building Solutions Asia Pacific | 525 |  |  | (2) |  |  | — |  |  | 30 |  |  | 6 | % |  | 553 |  |  | — |  |  | — |  |  | 50 |  |  | 9 | % |  | 603 |  |  | 15 | % |
| Total field | 3,550 |  |  | (2) |  |  | — |  |  | 85 |  |  | 2 | % |  | 3,633 |  |  | 4 |  |  | — |  |  | (45) |  |  | -1 | % |  | 3,592 |  |  | 1 | % |
| Global Products | 1,894 |  |  | (62) |  |  | -3 | % |  | 51 |  |  | 3 | % |  | 1,883 |  |  | — |  |  | — |  |  | 119 |  |  | 6 | % |  | 2,002 |  |  | 6 | % |
| Total net sales | $ | 5,444 |  |  | $ | (64) |  |  | -1 | % |  | $ | 136 |  |  | 2 | % |  | $ | 5,516 |  |  | $ | 4 |  |  | — |  |  | $ | 74 |  |  | 1 | % |  | $ | 5,594 |  |  | 3 | % |

[0000833444-21-000017:8k_2_02:126]
The components of the changes in net sales for the six months ended March 31, 2021 versus the six months ended March 31, 2020, including organic growth, is shown below (unaudited):

[0000833444-21-000017:8k_2_02:127]
| (in millions) | Net Sales for theSix Months Ended March 31, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the SixMonths EndedMarch 31, 2020 |  | Acquisitions |  | Organic Growth |  | Net Sales for theSix Months EndedMarch 31, 2021 |
| Building Solutions North America | $ | 4,342 |  |  | $ | — |  |  | — |  |  | $ | 16 |  |  | — |  |  | $ | 4,358 |  |  | $ | — |  |  | — |  |  | $ | (232) |  |  | -5 | % |  | $ | 4,126 |  |  | -5 | % |
| Building Solutions EMEA/LA | 1,778 |  | — |  |  | — |  |  | 63 |  | 4 | % |  | 1,841 |  |  | 13 |  |  | 1 | % |  | (51) |  |  | -3 | % |  | 1,803 |  |  | 1 | % |
| Building Solutions Asia Pacific | 1,154 |  | (4) |  |  | — |  |  | 58 |  | 5 | % |  | 1,208 |  |  | — |  |  | — |  |  | 10 |  |  | 1 | % |  | 1,218 |  |  | 6 | % |
| Total field | 7,274 |  | (4) |  |  | — |  |  | 137 |  | 2 | % |  | 7,407 |  |  | 13 |  |  | — |  |  | (273) |  |  | -4 | % |  | 7,147 |  |  | -2 | % |
| Global Products | 3,746 |  | (133) |  |  | -4 | % |  | 88 |  | 2 | % |  | 3,701 |  |  | — |  |  | — |  |  | 87 |  |  | 2 | % |  | 3,788 |  |  | 1 | % |
| Total net sales | $ | 11,020 |  |  | $ | (137) |  |  | -1 | % |  | $ | 225 |  |  | 2 | % |  | $ | 11,108 |  |  | $ | 13 |  |  | — |  |  | $ | (186) |  |  | -2 | % |  | $ | 10,935 |  |  | -1 | % |

[0000833444-21-000017:8k_2_02:128]
Page 16 of 18

[0000833444-21-000017:8k_2_02:129]
4.  Free Cash Flow Reconciliation

[0000833444-21-000017:8k_2_02:130]
The Company's press release contains financial information regarding free cash flow which is a non-GAAP performance measure. Free cash flow is defined as cash provided by operating activities less capital expenditures. Management believes this non-GAAP measure is useful to investors in understanding the strength of the Company and its ability to generate cash.

[0000833444-21-000017:8k_2_02:131]
The following is the three months and six months ended March 31, 2021 and 2020 reconciliation of free cash flow for continuing operations (unaudited):

[0000833444-21-000017:8k_2_02:132]
| (in millions) | Three Months EndedMarch 31, 2021 |  | Three Months EndedMarch 31, 2020 |  | Six Months EndedMarch 31, 2021 |  | Six Months EndedMarch 31, 2020 |  |  |
| Cash provided by operating activities from continuing operations | $ | 645 |  |  | $ | 155 |  |  | $ | 1,160 |  |  | $ | 666 |  |  |  |
| Capital expenditures | (106) |  |  | (124) |  |  | (197) |  |  | (250) |  |  |  |
| Adjusted free cash flow | $ | 539 |  |  | $ | 31 |  |  | $ | 963 |  |  | $ | 416 |  |  |  |

[0000833444-21-000017:8k_2_02:133]
5.  Net Debt to EBITDA

[0000833444-21-000017:8k_2_02:134]
The Company provides financial information regarding net debt to adjusted EBITDA, which is a non-GAAP performance measure. The Company believes the total net debt to adjusted EBITDA ratio is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. The following is the March 31, 2021 calculation of net debt to adjusted EBITDA (unaudited):

[0000833444-21-000017:8k_2_02:135]
| (in millions) | March 31, 2021 |  |  |
| Short-term debt and current portion of long-term debt | $ | 444 |  |  |  |
| Long-term debt | 7,323 |  |  |  |
| Total debt | 7,767 |  |  |  |
| Less: cash and cash equivalents | 1,883 |  |  |  |
| Total net debt | $ | 5,884 |  |  |  |
| Last twelve months adjusted EBITDA | $ | 3,312 |  |  |  |
| Total net debt to adjusted EBITDA | 1.8x |  |  |

[0000833444-21-000017:8k_2_02:136]
The following is the last twelve months ended March 31, 2021 reconciliation of income from continuing operations to adjusted EBIT and adjusted EBITDA, which are non-GAAP performance measures (unaudited):

[0000833444-21-000017:8k_2_02:137]
| (in millions) | Last Twelve MonthsEndedMarch 31, 2021 |  |  |
| Income from continuing operations | $ | 1,137 |  |  |  |
| Income tax provision | 300 |  |  |  |
| Net financing charges | 223 |  |  |  |
| EBIT | 1,660 |  |  |  |
| Adjusting items: |  |  |  |
| Integration costs | 58 |  |  |  |
| Net mark-to-market adjustments | 22 |  |  |  |
| Restructuring and impairment costs | 706 |  |  |  |
| Acquisition related compensation charge | 39 |  |  |  |
| Adjusted EBIT (1) | 2,485 |  |  |  |
| Depreciation and amortization | 827 |  |  |  |
| Adjusted EBITDA (1) | $ | 3,312 |  |  |  |

[0000833444-21-000017:8k_2_02:138]
(1) The Company's definition of adjusted EBIT and adjusted EBITDA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-21-000017:8k_2_02:139]
Page 17 of 18

[0000833444-21-000017:8k_2_02:140]
6.  Trade Working Capital as a Percentage of Net Sales

[0000833444-21-000017:8k_2_02:141]
The Company provides financial information regarding trade working capital as a percentage of net sales, which is a non-GAAP performance measure. Trade working capital is defined as current assets less current liabilities, excluding cash, short-term debt, the current portion of long-term debt, the current portion of assets and liabilities held for sale, accrued compensation and benefits, and other current assets and liabilities.  Management believes this non-GAAP measure, which excludes financing-related items, non-trade related items and businesses to be divested, is a more useful measurement of the Company's operating performance. The following is the March 31, 2021 and March 31, 2020 calculation of trade working capital as a percentage of net sales (unaudited):

[0000833444-21-000017:8k_2_02:142]
| (in millions) | March 31, 2021 |  | March 31, 2020 |
| Current assets | $ | 10,204 |  |  | $ | 9,955 |  |
| Current liabilities | (8,740) |  |  | (9,509) |  |
| Total working capital | 1,464 |  |  | 446 |  |
| Less: cash and cash equivalents | (1,883) |  |  | (1,006) |  |
| Less: assets held for sale | — |  |  | (91) |  |
| Less: other current assets | (1,160) |  |  | (1,336) |  |
| Add: short-term debt | 248 |  |  | 344 |  |
| Add: current portion of long-term debt | 196 |  |  | 1,086 |  |
| Add: accrued compensation and benefits | 817 |  |  | 694 |  |
| Add: liabilities held for sale | — |  |  | 39 |  |
| Add: other current liabilities | 2,352 |  |  | 2,627 |  |
| Trade working capital | $ | 2,034 |  |  | $ | 2,803 |  |
| Last twelve months net sales | $ | 22,232 |  |  | $ | 23,745 |  |
| Trade working capital as a percentage of net sales | 9.1 | % |  | 11.8 | % |

[0000833444-21-000017:8k_2_02:143]
7.  Income Taxes

[0000833444-21-000017:8k_2_02:144]
The Company's effective tax rate from continuing operations before consideration of transaction/integration costs, net mark-to-market adjustments, restructuring and impairment costs and discrete tax items for the three and six months ending March 31, 2021 and March 31, 2020 is approximately 13.5%.

[0000833444-21-000017:8k_2_02:145]
8.  Restructuring and Impairment Costs

[0000833444-21-000017:8k_2_02:146]
The three and six months ended March 31, 2021 include restructuring and impairment costs of $96 million related primarily to workforce reductions and asset impairments. The three months ended March 31, 2020 include restructuring and impairment costs of $62 million related to indefinite-lived intangible asset impairments primarily related to the Company's retail business. The six months ended March 31, 2020 include restructuring and impairment costs of $173 million related primarily to workforce reductions, plant closures and asset impairments.

[0000833444-21-000017:8k_2_02:147]
Page 18 of 18
