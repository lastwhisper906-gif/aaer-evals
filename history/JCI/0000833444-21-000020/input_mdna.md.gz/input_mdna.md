# JCI MD&A — 0000833444-21-000020


## mdna

[0000833444-21-000020:mdna:1]
[same as prior period, unchanged from 0000833444-21-000011:mdna:1]

[0000833444-21-000020:mdna:2]
[same as prior period, unchanged from 0000833444-21-000011:mdna:2]

[0000833444-21-000020:mdna:3]
[same as prior period, unchanged from 0000833444-21-000011:mdna:3]

[0000833444-21-000020:mdna:4]
[same as prior period, unchanged from 0000833444-21-000011:mdna:4]

[0000833444-21-000020:mdna:5]
[same as prior period, unchanged from 0000833444-21-000011:mdna:5]

[0000833444-21-000020:mdna:6]
[same as prior period, unchanged from 0000833444-21-000011:mdna:6]

[0000833444-21-000020:mdna:7]
[same as prior period, unchanged from 0000833444-21-000011:mdna:7]

[0000833444-21-000020:mdna:8]
[same as prior period, unchanged from 0000833444-21-000011:mdna:8]

[0000833444-21-000020:mdna:9]
The Company continues to observe trends demonstrating increased interest and demand for safe, efficient and sustainable buildings, and seeks to capitalize on these trends to drive growth by developing and delivering technologies and solutions to create healthy buildings. In 2020, the Company launched OpenBlue, a digitally driven suite of connected solutions that delivers impactful sustainability, new occupant experiences, and respectful safety and security by combining the Company’s building expertise with cutting-edge technology, including AI-powered service solutions such as remote diagnostics, predictive maintenance, compliance monitoring and advanced risk assessments. In January 2021, the Company committed to invest 75 percent of its new product research and development in climate-related innovation to develop sustainable products and services.

[0000833444-21-000020:mdna:10]
The following information should be read in conjunction with the September 30, 2020 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2020 filed with the SEC on November 16, 2020. References in the following discussion and analysis to "Three Months" (or similar language) refer to the three months ended March 31, 2021 compared to the three months ended March 31, 2020, while "Year-to-Date" refers to the six months ended March 31, 2021 compared to the six months ended March 31, 2020.

[0000833444-21-000020:mdna:11]
[same as prior period, unchanged from 0000833444-21-000011:mdna:11]

[0000833444-21-000020:mdna:12]
The global outbreak of COVID-19 severely restricted the level of economic activity around the world and caused a significant contraction in the global economy. The Company’s affiliates, employees, suppliers, customers and others have been and may continue to be restricted or prevented from conducting normal business activities, including as a result of shutdowns, travel restrictions and other actions that may be requested or mandated by governmental authorities. Although shutdown orders and similar restrictions have been lifted in some jurisdictions, resurgences in the spread of COVID-19 have caused the reinstitution of such measures in impacted areas. While a substantial portion of the Company's businesses have been classified as an essential business in jurisdictions in which facility closures have been mandated, some of its facilities have at times nevertheless been ordered to close, and we can give no assurance that there will not be additional closures in the future or that the Company's businesses will be classified as essential in each of the jurisdictions in which it operates.

[0000833444-21-000020:mdna:13]
[same as prior period, unchanged from 0000833444-21-000011:mdna:14]

[0000833444-21-000020:mdna:14]
During portions of fiscal 2020, the Company experienced temporary reductions of its manufacturing and operating capacity in China, India and Mexico. Currently, the Company’s facilities have been operating at normal levels. The Company has experienced, and may continue to experience, disruptions or delays in its supply chain as a result of government-mandated actions. While actions taken by the Company to mitigate manufacturing and supply chain disruptions, including redistributing manufacturing capacity, expanding supplier diversity, government outreach and supplier financing, have generally been successful, resurgences in the spread of COVID-19 could lead to further disruptions.

[0000833444-21-000020:mdna:15]
The Company experienced a decline in demand and volumes in its global businesses as a result of the impact of efforts to contain the spread of COVID-19. Specifically, the Company experienced lower demand due to restricted access to customer

[0000833444-21-000020:mdna:16]
sites to perform service and installation work as well as reduced discretionary capital spending by the Company's customers. In fiscal 2021, the Company has experienced increases in demand and volumes as governments have begun to distribute vaccines and lift COVID-19-related restrictions. However, delays in vaccine distribution and a resurgence in the spread of COVID-19 could result in the reinstitution of lockdowns or other restrictive measures, which could cause a decrease in economic activity and demand for the Company’s products and services.

[0000833444-21-000020:mdna:17]
The global pandemic has provided the Company with the opportunity to help its customers prepare to re-open by delivering solutions and support that enhance the safety and increase the efficiency of their operations. The Company has seen an increase in demand for its products and solutions that promote building health and optimize customers’ infrastructure, including thermal cameras, indoor air quality, location-based services for contact tracing and touchless access control.

[0000833444-21-000020:mdna:18]
In fiscal 2020, the Company executed temporary and permanent cost mitigation actions to offset a portion of the impact of COVID-19 on the demand for its products and services. As a result of these and other permanent cost mitigation actions, including the Company's 2020 restructuring plan, the Company experienced a positive impact on its results of operations for the three and six months ended March 31, 2021. Although the Company has largely ceased temporary cost mitigation actions initiated in fiscal 2020, the necessity of future cost mitigation actions will depend on the continued impact of COVID-19, which is highly uncertain.

[0000833444-21-000020:mdna:19]
During fiscal 2020, the Company determined that it had triggering events requiring assessment of impairment for certain of its indefinite-lived intangible assets due to declines in revenue directly attributable to the COVID-19 pandemic and for certain of its indefinite-lived intangible assets, long-lived assets and goodwill due to declines in revenue and further declines in forecasted cash flows in its North America Retail reporting unit. As a result, the Company recorded an impairment charge of $62 million related primarily to the Company's retail business indefinite-lived intangible assets and an impairment charge of $424 million related to the Company's North America Retail reporting unit's goodwill. There were no triggering events requiring that an impairment assessment be conducted for indefinite-lived intangible assets or goodwill in the six months ended March 31, 2021. However, it is possible that future changes in circumstances, including a more prolonged and/or severe COVID-19 pandemic, would require the Company to record additional non-cash impairment charges.

[0000833444-21-000020:mdna:20]
[same as prior period, unchanged from 0000833444-21-000011:mdna:21]

[0000833444-21-000020:mdna:21]
The extent to which the COVID-19 pandemic continues to impact the Company’s results of operations and financial condition will depend on future developments that are highly uncertain and cannot be predicted, including the resurgence of COVID-19 in regions recovering from the impacts of the pandemic, the effectiveness of COVID-19 vaccines and the speed at which populations are vaccinated around the globe, the impact of COVID-19 on economic activity, and regulatory actions taken to contain its impact on public health and the global economy. See Part I, Item 1A, of the Company’s Annual Report on Form 10-K for the year ended September 30, 2020 for an additional discussion of risks related to COVID-19.

[0000833444-21-000020:mdna:22]
Restructuring and Cost Optimization Initiatives

[0000833444-21-000020:mdna:23]
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company has committed to various restructuring plans. In fiscal 2021, the Company announced its plans to optimize its cost structure through broad-based SG&A actions focused on simplification, standardization and centralization, with the intent to deliver annualized savings of $300 million by fiscal 2023. Additionally, the Company announced cost of sales actions to drive $250 million in annual run rate savings by fiscal 2023. For more information on the Company’s restructuring plans, see “Liquidity and Capital Resources—Restructuring”.

[0000833444-21-000020:mdna:24]
44

[0000833444-21-000020:mdna:25]
[same as prior period, unchanged from 0000833444-21-000011:mdna:24]

[0000833444-21-000020:mdna:26]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Net sales | $ | 5,594 |  |  | $ | 5,444 |  |  | 3 | % |  | $ | 10,935 |  |  | $ | 11,020 |  |  | -1 | % |

[0000833444-21-000020:mdna:27]
The increase in consolidated net sales for the three months ended March 31, 2021 was due to the favorable impact of foreign currency translation ($136 million), higher organic sales ($74 million) and incremental sales from acquisitions ($4 million), partially offset by lower sales due to business divestitures ($64 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 1% as compared to the prior year. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-21-000020:mdna:28]
The decrease in consolidated net sales for the six months ended March 31, 2021 was due to lower organic sales ($186 million) and lower sales due to business divestitures ($137 million), partially offset by the favorable impact of foreign currency translation ($225 million) and incremental sales from acquisitions ($13 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales decreased 2% as compared to the prior year primarily due to the unfavorable impact of the COVID-19 pandemic on demand and volumes. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-21-000020:mdna:29]
[same as prior period, unchanged from 0000833444-21-000011:mdna:27]

[0000833444-21-000020:mdna:30]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Cost of sales | $ | 3,651 |  |  | $ | 3,643 |  |  | — | % |  | $ | 7,264 |  |  | $ | 7,416 |  |  | -2 | % |
| Gross profit | 1,943 |  |  | 1,801 |  |  | 8 | % |  | 3,671 |  |  | 3,604 |  |  | 2 | % |
| % of sales | 34.7 | % |  | 33.1 | % |  |  |  | 33.6 | % |  | 32.7 | % |  |  |

[0000833444-21-000020:mdna:31]
Cost of sales and gross profit increased for the three month period ended March 31, 2021, and gross profit as a percentage of sales increased by 160 basis points. Gross profit increased due to organic sales growth and favorable current year pension mark-to-market adjustments ($49 million), partially offset by business divestitures. Foreign currency translation had an unfavorable impact on cost of sales of approximately $95 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-21-000020:mdna:32]
Cost of sales decreased and gross profit increased for the six month period ended March 31, 2021, and gross profit as a percentage of sales increased by 90 basis points. Gross profit increased due to favorable current year pension mark-to-market adjustments ($49 million), partially offset by organic sales declines from the unfavorable impact of the COVID-19 pandemic and business divestitures. Foreign currency translation had an unfavorable impact on cost of sales of approximately $158 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-21-000020:mdna:33]
[same as prior period, unchanged from 0000833444-21-000011:mdna:30]

[0000833444-21-000020:mdna:34]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Selling, general and administrative expenses | $ | 1,253 |  |  | $ | 1,451 |  |  | -14 | % |  | $ | 2,547 |  |  | $ | 2,878 |  |  | -12 | % |
| % of sales | 22.4 | % |  | 26.7 | % |  |  |  | 23.3 | % |  | 26.1 | % |  |  |

[0000833444-21-000020:mdna:35]
Selling, general and administrative expenses ("SG&A") for the three month period ended March 31, 2021 decreased $198 million, and SG&A as a percentage of sales decreased by 430 basis points. The decrease in SG&A was primarily due to

[0000833444-21-000020:mdna:36]
favorable current year mark-to-market adjustments on pension plans ($158 million), favorable impacts of cost mitigation actions and reductions in discretionary spend in the current quarter, and the favorable year-over-year impact of net mark-to-market adjustments on restricted asbestos investments, partially offset by an unfavorable impact of foreign currency translation. Foreign currency translation had an unfavorable impact on SG&A of $32 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-21-000020:mdna:37]
SG&A for the six month period ended March 31, 2021 decreased $331 million, and SG&A as a percentage of sales decreased by 280 basis points. The decrease in SG&A was primarily due to favorable current year mark-to-market adjustments on pension plans ($158 million), favorable impacts of cost mitigation actions and reductions in discretionary spend in the current year, and the favorable year-over-year impact of net mark-to-market adjustments on restricted asbestos investments, partially offset by an unfavorable impact of foreign currency translation. Foreign currency translation had an unfavorable impact on SG&A of $52 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-21-000020:mdna:38]
[same as prior period, unchanged from 0000833444-21-000011:mdna:34]

[0000833444-21-000020:mdna:39]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Restructuring and impairment costs | $ | 96 |  |  | $ | 62 |  |  | 55 | % |  | $ | 96 |  |  | $ | 173 |  |  | -45 | % |

[0000833444-21-000020:mdna:40]
[same as prior period, unchanged from 0000833444-21-000011:mdna:37]

[0000833444-21-000020:mdna:41]
[same as prior period, unchanged from 0000833444-21-000011:mdna:38]

[0000833444-21-000020:mdna:42]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Net financing charges | $ | 44 |  |  | $ | 59 |  |  | -25 | % |  | $ | 103 |  |  | $ | 111 |  |  | -7 | % |

[0000833444-21-000020:mdna:43]
[same as prior period, unchanged from 0000833444-21-000011:mdna:40]

[0000833444-21-000020:mdna:44]
[same as prior period, unchanged from 0000833444-21-000011:mdna:41]

[0000833444-21-000020:mdna:45]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Equity income | $ | 56 |  |  | $ | 20 |  |  | * |  | $ | 114 |  |  | $ | 63 |  |  | 81 | % |

[0000833444-21-000020:mdna:46]
[same as prior period, unchanged from 0000833444-21-000011:mdna:36]

[0000833444-21-000020:mdna:47]
The increase in equity income for the three months ended March 31, 2021 was primarily due to higher income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture. Foreign currency translation had a favorable impact on equity income of $1 million for the three months ended March 31, 2021. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-21-000020:mdna:48]
The increase in equity income for the six months ended March 31, 2021 was primarily due to higher income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture. Foreign currency translation had a favorable impact on equity income of $4 million for the six months ended March 31, 2021. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-21-000020:mdna:49]
[same as prior period, unchanged from 0000833444-21-000011:mdna:44]

[0000833444-21-000020:mdna:50]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Income tax provision | $ | 209 |  |  | $ | 13 |  |  | * |  | $ | 270 |  |  | $ | 78 |  |  | * |
| Effective tax rate | 34 | % |  | 5 | % |  |  |  | 26 | % |  | 15 | % |  |  |

[0000833444-21-000020:mdna:51]
[same as prior period, unchanged from 0000833444-21-000011:mdna:52]

[0000833444-21-000020:mdna:52]
[same as prior period, unchanged from 0000833444-21-000011:mdna:46]

[0000833444-21-000020:mdna:53]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended March 31, 2021, the Company's effective tax rate for continuing operations was 34% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the six months ended March 31, 2021, the Company's effective tax rate for continuing operations was 26% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the three months ended March 31, 2020, the Company's effective tax rate for continuing operations was 5% and was lower than the statutory tax rate of 12.5% primarily due to tax audit reserve adjustments and the benefits of continuing global tax planning initiatives, partially offset by tax rate differentials. For the six months ended March 31, 2020, the Company's effective tax rate for continuing operations was 15% and was higher than the statutory tax rate of 12.5% primarily due to a discrete tax charge related to the remeasurement of deferred tax assets and liabilities as a result of Swiss tax reform and tax rate differentials, partially offset by tax audit reserve adjustments and the benefits of continuing global tax planning initiatives. The effective tax rate for the six months ended March 31, 2021 increased as compared to the six months ended March 31, 2020 primarily due to the discrete tax items. Refer to Note 11, "Income Taxes," of the notes to consolidated financial statements for further detail.

[0000833444-21-000020:mdna:54]
[same as prior period, unchanged from 0000833444-21-000011:mdna:50]

[0000833444-21-000020:mdna:55]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Income from discontinued operations, net of tax | $ | — |  |  | $ | — |  |  | * |  | $ | 124 |  |  | $ | — |  |  | * |

[0000833444-21-000020:mdna:56]
[same as prior period, unchanged from 0000833444-21-000011:mdna:59]

[0000833444-21-000020:mdna:57]
[same as prior period, unchanged from 0000833444-21-000011:mdna:53]

[0000833444-21-000020:mdna:58]
[same as prior period, unchanged from 0000833444-21-000011:mdna:54]

[0000833444-21-000020:mdna:59]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 54 |  |  | $ | 23 |  |  | * |  | $ | 99 |  |  | $ | 55 |  |  | 80 | % |

[0000833444-21-000020:mdna:60]
* Measure not meaningful

[0000833444-21-000020:mdna:61]
The increase in income from continuing operations attributable to noncontrolling interests for the three and six months ended March 31, 2021 was primarily due to higher net income at certain partially-owned affiliates within the Global Products segment.

[0000833444-21-000020:mdna:62]
[same as prior period, unchanged from 0000833444-21-000011:mdna:57]

[0000833444-21-000020:mdna:63]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Net income attributable to Johnson Controls | $ | 343 |  |  | $ | 213 |  |  | 61 | % |  | $ | 794 |  |  | $ | 372 |  |  | * |

[0000833444-21-000020:mdna:64]
* Measure not meaningful

[0000833444-21-000020:mdna:65]
The increase in net income attributable to Johnson Controls for the three months ended March 31, 2021 was primarily due to lower SG&A and higher gross profit, partially offset by higher income tax provision. The increase in net income attributable to Johnson Controls for the six months ended March 31, 2021 was primarily due to lower SG&A, the current year income from discontinued operations, higher gross profit, and lower restructuring and impairment costs, partially offset by higher income tax provision.

[0000833444-21-000020:mdna:66]
Diluted earnings per share attributable to Johnson Controls for the three months ended March 31, 2021 was $0.48 compared to $0.28 for the three months ended March 31, 2020. Diluted earnings per share attributable to Johnson Controls for the six months ended March 31, 2021 was $1.10 compared to $0.49 for the six months ended March 31, 2020.

[0000833444-21-000020:mdna:67]
[same as prior period, unchanged from 0000833444-21-000011:mdna:62]

[0000833444-21-000020:mdna:68]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Comprehensive income (loss) attributable to Johnson Controls | $ | 437 |  |  | $ | (268) |  |  | * |  | $ | 1,160 |  |  | $ | 146 |  |  | * |

[0000833444-21-000020:mdna:69]
* Measure not meaningful

[0000833444-21-000020:mdna:70]
The increase in comprehensive income attributable to Johnson Controls for the three months ended March 31, 2021 was due to higher net income attributable to Johnson Controls ($130 million) and an increase in other comprehensive income attributable to Johnson Controls ($575 million) resulting primarily from favorable currency translation adjustments. The year-over-year favorable foreign currency translation adjustments were primarily driven by the weakening of the British pound, Mexican peso, Canadian dollar and Brazilian real against the U.S. dollar in the prior quarter.

[0000833444-21-000020:mdna:71]
The increase in comprehensive income attributable to Johnson Controls for the six months ended March 31, 2021 was due to higher net income attributable to Johnson Controls ($422 million) and an increase in other comprehensive income attributable to Johnson Controls ($592 million) resulting primarily from favorable currency translation adjustments. The year-over-year favorable foreign currency translation adjustments were primarily driven by the strengthening of the British pound, Mexican peso and Canadian dollar against the U.S. dollar in the current year.

[0000833444-21-000020:mdna:72]
[same as prior period, unchanged from 0000833444-21-000011:mdna:65]

[0000833444-21-000020:mdna:73]
[same as prior period, unchanged from 0000833444-21-000011:mdna:66]

[0000833444-21-000020:mdna:74]
[same as prior period, unchanged from 0000833444-21-000011:mdna:67]

[0000833444-21-000020:mdna:75]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Building Solutions North America | $ | 2,092 |  |  | $ | 2,175 |  |  | -4 | % |  | $ | 4,126 |  |  | $ | 4,342 |  |  | -5 | % |
| Building Solutions EMEA/LA | 897 |  |  | 850 |  |  | 6 | % |  | 1,803 |  |  | 1,778 |  |  | 1 | % |
| Building Solutions Asia Pacific | 603 |  |  | 525 |  |  | 15 | % |  | 1,218 |  |  | 1,154 |  |  | 6 | % |
| Global Products | 2,002 |  |  | 1,894 |  |  | 6 | % |  | 3,788 |  |  | 3,746 |  |  | 1 | % |
|  | $ | 5,594 |  |  | $ | 5,444 |  |  | 3 | % |  | $ | 10,935 |  |  | $ | 11,020 |  |  | -1 | % |

[0000833444-21-000020:mdna:76]
Three Months:

[0000833444-21-000020:mdna:77]
•The decrease in Building Solutions North America was due to lower volumes ($96 million), partially offset by the favorable impact of foreign currency translation ($13 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic.

[0000833444-21-000020:mdna:78]
•The increase in Building Solutions EMEA/LA was due to the favorable impact of foreign currency translation ($42 million), incremental sales related to business acquisitions ($4 million) and favorable volumes ($1 million).

[0000833444-21-000020:mdna:79]
•The increase in Building Solutions Asia Pacific was due to favorable volumes ($50 million) and the favorable impact of foreign currency translation ($30 million), partially offset by business divestitures ($2 million). The increase in volumes was primarily attributable to the COVID-19 pandemic recovery in China.

[0000833444-21-000020:mdna:80]
•The increase in Global Products was due to favorable volumes ($119 million) and the favorable impact of foreign currency translation ($51 million), partially offset by business divestitures ($62 million). The increase in volumes was primarily attributable to strong residential end markets as well as an inflection to growth in Commercial HVAC and Fire & Security.

[0000833444-21-000020:mdna:81]
Year-to-Date:

[0000833444-21-000020:mdna:82]
•The decrease in Building Solutions North America was due to lower volumes ($232 million), partially offset by the favorable impact of foreign currency translation ($16 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic.

[0000833444-21-000020:mdna:83]
•The increase in Building Solutions EMEA/LA was due to the favorable impact of foreign currency translation ($63 million) and incremental sales related to business acquisitions ($13 million), partially offset by lower volumes ($51 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic.

[0000833444-21-000020:mdna:84]
•The increase in Building Solutions Asia Pacific was due to the favorable impact of foreign currency translation ($58 million) and favorable volumes ($10 million), partially offset by business divestitures ($4 million)

[0000833444-21-000020:mdna:85]
•The increase in Global Products was due to the favorable impact of foreign currency translation ($88 million) and favorable volumes ($87 million), partially offset by business divestitures ($133 million). The increase in volumes was primarily attributable to strong residential end markets and the COVID-19 pandemic recovery in the Asia Pacific region.

[0000833444-21-000020:mdna:86]
[same as prior period, unchanged from 0000833444-21-000011:mdna:74]

[0000833444-21-000020:mdna:87]
|  | Three Months Ended March 31, |  |  |  | Six Months Ended March 31, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Building Solutions North America | $ | 266 |  |  | $ | 251 |  |  | 6 | % |  | $ | 521 |  |  | $ | 509 |  |  | 2 | % |
| Building Solutions EMEA/LA | 86 |  |  | 85 |  |  | 1 | % |  | 181 |  |  | 175 |  |  | 3 | % |
| Building Solutions Asia Pacific | 74 |  |  | 65 |  |  | 14 | % |  | 153 |  |  | 137 |  |  | 12 | % |
| Global Products | 285 |  |  | 216 |  |  | 32 | % |  | 498 |  |  | 419 |  |  | 19 | % |
|  | $ | 711 |  |  | $ | 617 |  |  | 15 | % |  | $ | 1,353 |  |  | $ | 1,240 |  |  | 9 | % |

[0000833444-21-000020:mdna:88]
Three Months:

[0000833444-21-000020:mdna:89]
•The increase in Building Solutions North America was due to productivity savings and cost mitigation actions, net of unfavorable volumes ($14 million) and the favorable impact of foreign currency translation ($1 million).

[0000833444-21-000020:mdna:90]
•The increase in Building Solutions EMEA/LA was due to productivity savings and favorable volumes ($2 million), the favorable impact of foreign currency translation ($1 million) and higher income due to business acquisitions ($1 million), partially offset by lower equity income ($3 million).

[0000833444-21-000020:mdna:91]
•The increase in Building Solutions Asia Pacific was due to favorable volumes ($7 million) and the favorable impact of foreign currency translation ($3 million), partially offset by lower income due to business divestitures ($1 million).

[0000833444-21-000020:mdna:92]
•The increase in Global Products was due to higher equity income ($35 million) driven primarily by certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture, favorable volumes, productivity savings and cost mitigation actions ($35 million) and the favorable impact of foreign currency translation ($5 million), partially offset by lower income due to business divestitures ($6 million).

[0000833444-21-000020:mdna:93]
Year-to-Date:

[0000833444-21-000020:mdna:94]
•The increase in Building Solutions North America was due to productivity savings and cost mitigation actions, net of unfavorable volumes ($10 million), prior year integration costs ($1 million) and the favorable impact of foreign currency translation ($1 million).

[0000833444-21-000020:mdna:95]
•The increase in Building Solutions EMEA/LA was due to productivity savings and cost mitigation actions, net of unfavorable volumes ($6 million), higher income due to business acquisitions ($2 million) and the favorable impact of foreign currency translation ($1 million), partially offset by lower equity income ($3 million).

[0000833444-21-000020:mdna:96]
•The increase in Building Solutions Asia Pacific was due to productivity savings, cost mitigation actions and favorable volumes ($11 million) and the favorable impact of foreign currency translation ($6 million), partially offset by lower income due to business divestitures ($1 million).

[0000833444-21-000020:mdna:97]
•The increase in Global Products was due to higher equity income ($45 million) driven primarily by certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture, favorable volumes, productivity savings and cost mitigation actions ($34 million), the favorable impact of foreign currency translation ($11 million) and prior year integration costs ($1 million), partially offset by lower income due to business divestitures ($12 million).

[0000833444-21-000020:mdna:98]
[same as prior period, unchanged from 0000833444-21-000011:mdna:80]

[0000833444-21-000020:mdna:99]
The Company’s backlog is applicable to its sales of systems and services. At March 31, 2021, the backlog was $10.0 billion, of which $9.6 billion was attributable to the field business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-21-000020:mdna:100]
At March 31, 2021, remaining performance obligations were $15.0 billion, which is $5.0 billion higher than the Company's backlog of $10.0 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-21-000020:mdna:101]
[same as prior period, unchanged from 0000833444-21-000011:mdna:83]

[0000833444-21-000020:mdna:102]
[same as prior period, unchanged from 0000833444-21-000011:mdna:84]

[0000833444-21-000020:mdna:103]
[same as prior period, unchanged from 0000833444-21-000011:mdna:85]

[0000833444-21-000020:mdna:104]
[same as prior period, unchanged from 0000833444-21-000011:mdna:86]

[0000833444-21-000020:mdna:105]
[same as prior period, unchanged from 0000833444-21-000011:mdna:87]

[0000833444-21-000020:mdna:106]
[same as prior period, unchanged from 0000833444-21-000011:mdna:88]

[0000833444-21-000020:mdna:107]
|  | March 31, |  | September 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |
| Current assets | $ | 10,204 |  |  | $ | 10,053 |  |  |  |
| Current liabilities | (8,740) |  |  | (8,248) |  |  |  |
|  | 1,464 |  |  | 1,805 |  |  | -19 | % |
| Less: Cash | (1,883) |  |  | (1,951) |  |  |  |
| Add: Short-term debt | 248 |  |  | 31 |  |  |  |
| Add: Current portion of long-term debt | 196 |  |  | 262 |  |  |  |
| Working capital (as defined) | $ | 25 |  |  | $ | 147 |  |  | -83 | % |
| Accounts receivable - net | $ | 5,167 |  |  | $ | 5,294 |  |  | -2 | % |
| Inventories | 1,994 |  |  | 1,773 |  |  | 12 | % |
| Accounts payable | 3,417 |  |  | 3,120 |  |  | 10 | % |

[0000833444-21-000020:mdna:108]
[same as prior period, unchanged from 0000833444-21-000011:mdna:90]

[0000833444-21-000020:mdna:109]
•The decrease in working capital at March 31, 2021 as compared to September 30, 2020, was primarily due to an increase in accounts payable and decrease in accounts receivable, partially offset by an increase in inventory to meet anticipated customer demand and the favorable resolution of certain post-closing working capital and net debt adjustments related to the Power Solutions sale.

[0000833444-21-000020:mdna:110]
•The Company’s days sales in accounts receivable at March 31, 2021 and September 30, 2020 were 64 days and 63 days, respectively. There has been no significant adverse changes in the level of overdue receivables or significant changes in revenue recognition methods.

[0000833444-21-000020:mdna:111]
•The Company’s inventory turns for the three months ended March 31, 2021 were lower than the comparable period ended September 30, 2020, primarily due to changes in inventory production levels.

[0000833444-21-000020:mdna:112]
•Days in accounts payable at March 31, 2021 were 78 days, higher than 69 days at the comparable period ended September 30, 2020, primarily due to timing.

[0000833444-21-000020:mdna:113]
[same as prior period, unchanged from 0000833444-21-000011:mdna:95]

[0000833444-21-000020:mdna:114]
|  |  | Six Months Ended March 31, |
| (in millions) |  | 2021 |  | 2020 |
| Cash provided by operating activities |  | $ | 1,160 |  |  | $ | 666 |  |
| Cash used by investing activities |  | (119) |  |  | (288) |  |
| Cash used by financing activities |  | (1,079) |  |  | (2,036) |  |

[0000833444-21-000020:mdna:115]
[same as prior period, unchanged from 0000833444-21-000011:mdna:97]

[0000833444-21-000020:mdna:116]
•The decrease in cash used by investing activities was primarily due to lower capital expenditures, lower payments for acquisitions, higher proceeds from the sale of property, plant and equipment, and current year cash proceeds from business divestitures.

[0000833444-21-000020:mdna:117]
[same as prior period, unchanged from 0000833444-21-000011:mdna:99]

[0000833444-21-000020:mdna:118]
[same as prior period, unchanged from 0000833444-21-000011:mdna:100]

[0000833444-21-000020:mdna:119]
|  | March 31, |  | September 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |
| Short-term debt | $ | 248 |  |  | $ | 31 |  |  |  |
| Current portion of long-term debt | 196 |  |  | 262 |  |  |  |
| Long-term debt | 7,323 |  |  | 7,526 |  |  |  |
| Total debt | 7,767 |  |  | 7,819 |  |  | -1 | % |
| Less: cash and cash equivalents | 1,883 |  |  | 1,951 |  |  |  |
| Total net debt | 5,884 |  |  | 5,868 |  |  | — | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 17,698 |  |  | 17,447 |  |  | 1 | % |
| Total capitalization | $ | 23,582 |  |  | $ | 23,315 |  |  | 1 | % |
| Total net debt as a % of total capitalization | 25.0 | % |  | 25.2 | % |  |  |

[0000833444-21-000020:mdna:120]
[same as prior period, unchanged from 0000833444-21-000011:mdna:102]

[0000833444-21-000020:mdna:121]
•The Company believes its capital resources and liquidity position at March 31, 2021 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, minimum pension contributions, debt maturities and any potential acquisitions or stock repurchases in the remainder of fiscal 2021 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company is unable to issue commercial paper, it would have the ability to draw on its $2.5 billion revolving credit facility which expires in December 2024 or its $0.5 billion 364-day revolving credit facility which expires in December 2021. There were no draws on the revolving credit facilities as of March 31, 2021 and September 30, 2020. In addition, the Company held cash and cash equivalents of $1.9 billion as of March 31, 2021. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-21-000020:mdna:122]
•Financial covenants in the Company's revolving credit facilities requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of March 31, 2021, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-21-000020:mdna:123]
•The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2021, the Company believes the long-term rate of return will approximate 6.50%, 4.90% and 5.30% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first six months of fiscal 2021, the Company made approximately $25 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $46 million in cash to its defined benefit pension plans in fiscal 2021. The Company expects to contribute $3 million in cash to its postretirement plans in fiscal 2021.

[0000833444-21-000020:mdna:124]
[same as prior period, unchanged from 0000833444-21-000011:mdna:107]

[0000833444-21-000020:mdna:125]
•We may from time to time purchase our outstanding debt through open market purchases, privately negotiated transactions or otherwise. Purchases or retirement of debt, if any, will depend on prevailing market conditions, liquidity requirements, contractual restrictions and other factors. The amounts involved may be material.

[0000833444-21-000020:mdna:126]
[same as prior period, unchanged from 0000833444-21-000011:mdna:109]

[0000833444-21-000020:mdna:127]
Restructuring

[0000833444-21-000020:mdna:128]
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company has committed to various restructuring plans. Restructuring plans generally result in charges for workforce reductions, plant closures, asset impairments and other related costs which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The Company expects the restructuring actions to reduce cost of sales and SG&A, including reduced employee-related costs, depreciation and amortization expense.

[0000833444-21-000020:mdna:129]
•In fiscal 2021, the Company announced its plans to optimize its cost structure through broad-based SG&A actions focused on simplification, standardization and centralization, with the intent to deliver annualized savings of $300 million by fiscal 2023. Additionally, the Company announced cost of sales actions to drive $250 million in annual run rate savings by fiscal 2023. The one-time pre-tax costs associated with these actions are estimated to be approximately $385 million across all segments and at Corporate. During the three months ended March 31, 2021, the Company recorded $96 million of costs resulting from the 2021 restructuring plan. The Company has outstanding restructuring reserves of $37 million at March 31, 2021, all of which is expected to be paid in cash.

[0000833444-21-000020:mdna:130]
•In fiscal 2020, the Company recorded $297 million of costs resulting from the 2020 restructuring plan. The Company currently estimates that upon completion of the restructuring action, the fiscal 2020 restructuring plans will reduce annual operating costs for continuing operations by approximately $430 million. The Company expects the annual benefit of these actions will be substantially realized in 2021. The restructuring action is expected to be substantially complete in fiscal 2021. The Company has outstanding restructuring reserves of $60 million at March 31, 2021, all of which is expected to be paid in cash.

[0000833444-21-000020:mdna:131]
[same as prior period, unchanged from 0000833444-21-000011:mdna:111]

[0000833444-21-000020:mdna:132]
The following information is provided in compliance with Rule 13-01 of Regulation S-X under the Securities Exchange Act of 1934 with respect to the (i) $625 million aggregate principal amount of 1.750% Senior Notes due 2030 (the “2030 Notes”), (ii) €500 million aggregate principal amount of 0.375% Senior Notes due 2027 (the “2027 Notes”) and (iii) €500 million aggregate principal amount of 1.000% Senior Notes due 2032 (the “2032 Notes” and together with the 2030 Notes and the 2027 Notes, the “Notes”), each issued by Johnson Controls International plc ("Parent Company") and Tyco Fire & Security Finance S.C.A. (“TFSCA”), a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”).

[0000833444-21-000020:mdna:133]
[same as prior period, unchanged from 0000833444-21-000011:mdna:113]

[0000833444-21-000020:mdna:134]
[same as prior period, unchanged from 0000833444-21-000011:mdna:114]

[0000833444-21-000020:mdna:135]
[same as prior period, unchanged from 0000833444-21-000011:mdna:115]

[0000833444-21-000020:mdna:136]
|  |  | Six Months Ended March 31, 2021 |  | Year EndedSeptember 30, 2020 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Loss from continuing operations |  | (100) |  |  | (450) |  |  |
| Net loss |  | (100) |  |  | (450) |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net loss attributable to the entity |  | (100) |  |  | (450) |  |  |

[0000833444-21-000020:mdna:137]
54

[0000833444-21-000020:mdna:138]
[same as prior period, unchanged from 0000833444-21-000011:mdna:117]

[0000833444-21-000020:mdna:139]
|  |  | Six Months Ended March 31, 2021 |  | Year EndedSeptember 30, 2020 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Income from continuing operations |  | 193 |  |  | 702 |  |  |
| Net income |  | 193 |  |  | 702 |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net income attributable to the entity |  | 193 |  |  | 702 |  |  |

[0000833444-21-000020:mdna:140]
The following table presents summarized balance sheet information as of March 31, 2021 and September 30, 2020 (in millions):

[0000833444-21-000020:mdna:141]
|  |  | March 31, 2021 |  | September 30, 2020 |  |
| Current assets |  | $ | 535 |  |  | $ | 522 |  |  |
| Noncurrent assets |  | 338 |  |  | 318 |  |  |
| Current liabilities |  | 2,734 |  |  | 7,612 |  |  |
| Noncurrent liabilities |  | 7,075 |  |  | 7,258 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-21-000020:mdna:142]
[same as prior period, unchanged from 0000833444-21-000011:mdna:121]

[0000833444-21-000020:mdna:143]
|  |  | March 31, 2021 |  | September 30, 2020 |  |
| Current assets |  | $ | 545 |  |  | $ | 838 |  |  |
| Noncurrent assets |  | 2,795 |  |  | 7,338 |  |  |
| Current liabilities |  | 1,384 |  |  | 2,724 |  |  |
| Noncurrent liabilities |  | 7,019 |  |  | 3,406 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-21-000020:mdna:144]
[same as prior period, unchanged from 0000833444-21-000011:mdna:123]

[0000833444-21-000020:mdna:145]
[same as prior period, unchanged from 0000833444-21-000011:mdna:124]

[0000833444-21-000020:mdna:146]
[same as prior period, unchanged from 0000833444-21-000011:mdna:125]
