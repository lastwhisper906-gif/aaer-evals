# JCI notes — 0000833444-21-000020


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-21-000020:notes:1]
Financial Statements
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2020 filed with the SEC on November 16, 2020. The results of operations for the three and six month periods ended March 31, 2021 are not necessarily indicative of results for the Company’s 2021 fiscal year because of seasonal and other factors.

[0000833444-21-000020:notes:2]
[same as prior period, unchanged from 0000833444-21-000011:notes:2]

[0000833444-21-000020:notes:3]
[same as prior period, unchanged from 0000833444-21-000011:notes:3]

[0000833444-21-000020:notes:4]
[same as prior period, unchanged from 0000833444-21-000011:notes:4]

[0000833444-21-000020:notes:5]
[same as prior period, unchanged from 0000833444-21-000011:notes:5]

[0000833444-21-000020:notes:6]
[same as prior period, unchanged from 0000833444-21-000011:notes:6]

[0000833444-21-000020:notes:7]
[same as prior period, unchanged from 0000833444-21-000011:notes:7]

[0000833444-21-000020:notes:8]
[same as prior period, unchanged from 0000833444-21-000011:notes:8]

[0000833444-21-000020:notes:9]
At March 31, 2021 and September 30, 2020, the Company held restricted cash of approximately $11 million and $9 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-21-000020:notes:10]
Acquisitions and Divestitures
In April 2021, the Company announced it had entered into a definitive agreement to acquire Silent-Aire, a global leader in hyperscale data center cooling and modular critical infrastructure solutions. The all-cash transaction is valued at up to $870 million, which will include an upfront payment of approximately $630 million at closing and additional payments to be made subject to the achievement of post-closing earnout milestones. The Silent-Aire business will be reported within the Global Products segment. The transaction is expected to close in the third quarter of fiscal 2021, subject to the receipt of regulatory approval and customary closing conditions.

[0000833444-21-000020:notes:11]
During the first six months of fiscal 2021, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $15 million, of which $10 million was paid as of March 31, 2021.  In connection with the acquisitions, the Company recorded goodwill of $13 million within the Building Solutions EMEA/LA segment.

[0000833444-21-000020:notes:12]
During the first six months of fiscal 2021, the Company completed certain divestitures within the Buildings Solutions Asia Pacific segment. The combined selling price was $23 million, of which $19 million was received as of March 31, 2021. In connection with the divestitures, the Company reduced goodwill by $6 million.

[0000833444-21-000020:notes:13]
During the first six months of fiscal 2020, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $61 million, of which $58 million was paid as of March 31, 2020. In connection with the acquisitions, the Company recorded goodwill of $19 million within the Global Products segment and $20 million within the Building Solutions EMEA/LA segment.

[0000833444-21-000020:notes:14]
Acquisitions and divestitures were not material to the Company's consolidated financial statements in the first six months of fiscal 2021 or 2020.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-21-000020:notes:15]
Discontinued OperationsOn April 30, 2019, the Company completed the sale of its Power Solutions business, which met the criteria to be classified as a discontinued operation, to BCP Acquisitions LLC for a purchase price of $13.2 billion. The net cash proceeds after tax and transaction-related expenses were $11.6 billion. In connection with the sale, the Company recorded a gain, net of transaction and other costs, of $5.2 billion ($4.0 billion after tax), subject to post-closing working capital and net debt adjustments, within income from discontinued operations, net of tax, in the consolidated statements of income. In December 2020, the favorable resolution of certain post-closing working capital and net debt adjustments resulted in income from discontinued operations, net of tax, of $124 million due to a reversal of a reserve established in connection with the sale of Power Solutions.
The following table summarizes the results of Power Solutions which are classified as discontinued operations for the six months ended March 31, 2021 (in millions). There is no Power Solutions related activity for the three months ended March 31, 2021 and the three and six months ended March 31, 2020.

[0000833444-21-000020:notes:16]
|  |  |  | Six Months Ended March 31, 2021 |
| Net sales |  |  | $ | — |  |
| Income from discontinued operations before income taxes |  |  | 150 |  |
| Provision for income taxes on discontinued operations |  |  | (26) |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax |  |  | — |  |
| Income from discontinued operations |  |  | $ | 124 |  |

[0000833444-21-000020:notes:17]
Assets and Liabilities Held for Sale

[0000833444-21-000020:notes:18]
During the second quarter of fiscal 2021, the Company determined that certain corporate assets met the criteria to be classified as held for sale. The carrying value of these assets was $26 million at March 31, 2021.
During the third quarter of fiscal 2020, the Company determined that certain assets of the Building Solutions Asia Pacific segment met the criteria to be classified as held for sale. The estimated fair value, less costs to sell, of these assets was $153 million at March 31, 2021 and $147 million at September 30, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-21-000020:notes:19]
[same as prior period, unchanged from 0000833444-21-000011:notes:16]

[0000833444-21-000020:notes:20]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and six months ended March 31, 2021 and 2020 (in millions):

[0000833444-21-000020:notes:21]
|  |  | Three Months Ended March 31, 2021 |  | Three Months Ended March 31, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,272 |  |  | $ | 820 |  |  | $ | 2,092 |  |  | $ | 1,357 |  |  | $ | 818 |  |  | $ | 2,175 |  |
| Building Solutions EMEA/LA |  | 429 |  |  | 468 |  |  | 897 |  |  | 400 |  |  | 450 |  |  | 850 |  |
| Building Solutions Asia Pacific |  | 329 |  |  | 274 |  |  | 603 |  |  | 271 |  |  | 254 |  |  | 525 |  |
| Global Products |  | 2,002 |  |  | — |  |  | 2,002 |  |  | 1,894 |  |  | — |  |  | 1,894 |  |
| Total |  | $ | 4,032 |  |  | $ | 1,562 |  |  | $ | 5,594 |  |  | $ | 3,922 |  |  | $ | 1,522 |  |  | $ | 5,444 |  |

[0000833444-21-000020:notes:22]
|  |  | Six Months Ended March 31, 2021 |  | Six Months Ended March 31, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 2,514 |  |  | $ | 1,612 |  |  | $ | 4,126 |  |  | $ | 2,713 |  |  | $ | 1,629 |  |  | $ | 4,342 |  |
| Building Solutions EMEA/LA |  | 855 |  |  | 948 |  |  | 1,803 |  |  | 857 |  |  | 921 |  |  | 1,778 |  |
| Building Solutions Asia Pacific |  | 674 |  |  | 544 |  |  | 1,218 |  |  | 642 |  |  | 512 |  |  | 1,154 |  |
| Global Products |  | 3,788 |  |  | — |  |  | 3,788 |  |  | 3,746 |  |  | — |  |  | 3,746 |  |
| Total |  | $ | 7,831 |  |  | $ | 3,104 |  |  | $ | 10,935 |  |  | $ | 7,958 |  |  | $ | 3,062 |  |  | $ | 11,020 |  |

[0000833444-21-000020:notes:23]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and six months ended March 31, 2021 and 2020 (in millions):

[0000833444-21-000020:notes:24]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 1,402 |  |  | $ | 1,324 |  |  | $ | 2,651 |  |  | $ | 2,624 |  |
| Fire & Security |  | 537 |  |  | 511 |  |  | 1,025 |  |  | 1,003 |  |
| Industrial Refrigeration |  | 63 |  |  | 59 |  |  | 112 |  |  | 119 |  |
| Total |  | $ | 2,002 |  |  | $ | 1,894 |  |  | $ | 3,788 |  |  | $ | 3,746 |  |

[0000833444-21-000020:notes:25]
[same as prior period, unchanged from 0000833444-21-000011:notes:21]

[0000833444-21-000020:notes:26]
[same as prior period, unchanged from 0000833444-21-000011:notes:22]

[0000833444-21-000020:notes:27]
[same as prior period, unchanged from 0000833444-21-000011:notes:23]

[0000833444-21-000020:notes:28]
|  |  | Location of contract balances |  | March 31, 2021 |  | September 30, 2020 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,387 |  |  | $ | 1,395 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 102 |  |  | 104 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,710) |  |  | (1,435) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (258) |  |  | (245) |  |  |  |
| Total |  |  |  | $ | (479) |  |  | $ | (181) |  |  |  |

[0000833444-21-000020:notes:29]
For the three months ended March 31, 2021 and March 31, 2020, the Company recognized revenue of $221 million and $326 million, respectively, that was included in the beginning of period contract liability balance. For the six months ended March 31, 2021 and March 31, 2020, the Company recognized revenue of $935 million and $1,012 million, respectively, that was included in the beginning of period contract liability balance.

[0000833444-21-000020:notes:30]
[same as prior period, unchanged from 0000833444-21-000011:notes:26]

[0000833444-21-000020:notes:31]
[same as prior period, unchanged from 0000833444-21-000011:notes:27]

[0000833444-21-000020:notes:32]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of March 31, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $15.0 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-21-000020:notes:33]
[same as prior period, unchanged from 0000833444-21-000011:notes:29]

[0000833444-21-000020:notes:34]
[same as prior period, unchanged from 0000833444-21-000011:notes:30]

[0000833444-21-000020:notes:35]
As of March 31, 2021, the Company recorded the costs to obtain or fulfill a contract of $241 million, of which $130 million is recorded within other current assets and $111 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2020, the Company recorded the costs to obtain or fulfill a contract of $223 million, of which $119 million is recorded within other current assets and $104 million is recorded within other noncurrent assets in the consolidated statements of financial position.

[0000833444-21-000020:notes:36]
During the three months ended March 31, 2021 and 2020, the Company recognized amortization expense of $47 million and $43 million, respectively, related to costs to obtain or fulfill a contract. During the six months ended March 31, 2021 and 2020, the Company recognized amortization expense of $88 million and $69 million, respectively, related to costs to 
obtain or fulfill a contract. There were no impairment losses recognized in the three and six months ended March 31, 2021 and 2020.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0000833444-21-000020:notes:37]
[same as prior period, unchanged from 0000833444-21-000011:notes:32]

[0000833444-21-000020:notes:38]
[same as prior period, unchanged from 0000833444-21-000011:notes:33]

[0000833444-21-000020:notes:39]
|  |  | March 31, 2021 |  | September 30, 2020 |  |  |
| Accounts receivable |  | $ | 5,315 |  |  | $ | 5,467 |  |  |  |
| Less: Allowance for expected credit losses (1) |  | (148) |  |  | (173) |  |  |  |
| Accounts receivable, net |  | $ | 5,167 |  |  | $ | 5,294 |  |  |  |

[0000833444-21-000020:notes:40]
(1) Allowance for doubtful accounts as of September 30, 2020, prior to the adoption of ASU 2016-13.

[0000833444-21-000020:notes:41]
The changes in the allowance for expected credit losses related to accounts receivable for the six month period ended March 31, 2021 were as follows (in millions):

[0000833444-21-000020:notes:42]
|  |  | Six Months Ended March 31, 2021 |
| Balance as of September 30, 2020 |  | $ | 173 |  |  |  |
| Provision for expected credit losses |  | 3 |  |  |  |
| Write-offs charged against the allowance for expected credit losses |  | (32) |  |  |  |
| Other (including impact of adoption of ASU 2016-13) |  | 4 |  |  |  |
| Balance as of March 31, 2021 |  | $ | 148 |  |  |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-21-000020:notes:43]
Leases
The Company's lease portfolio is described in Note 8, "Leases," of the notes to consolidated financial statements in its Annual Report on Form 10-K for the year ended September 30, 2020.

[0000833444-21-000020:notes:44]
The following table presents supplemental consolidated statement of financial position information as of March 31, 2021 and September 30, 2020 (in millions):

[0000833444-21-000020:notes:45]
|  | Location of lease balances |  | March 31, 2021 |  | September 30, 2020 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,284 |  |  | $ | 1,190 |  |
| Operating lease liabilities - current | Other current liabilities |  | 296 |  |  | 332 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 992 |  |  | 875 |  |

[0000833444-21-000020:notes:46]
The following table presents supplemental noncash operating lease activity for the six months ended March 31, 2021 and 2020 (in millions):

[0000833444-21-000020:notes:47]
|  |  |  |  | Six Months Ended March 31, |  |  |
|  |  |  |  |  |  | 2021 |  | 2020 |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  |  |  |  |  | $ | 303 |  |  | $ | 174 |  |  |  |


## us-gaap:InventoryDisclosureTextBlock

[0000833444-21-000020:notes:48]
[same as prior period, unchanged from 0000833444-21-000011:notes:43]

[0000833444-21-000020:notes:49]
|  | March 31, 2021 |  | September 30, 2020 |
| Raw materials and supplies | $ | 676 |  |  | $ | 629 |  |
| Work-in-process | 175 |  |  | 142 |  |
| Finished goods | 1,143 |  |  | 1,002 |  |
| Inventories | $ | 1,994 |  |  | $ | 1,773 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-21-000020:notes:50]
Goodwill and Other Intangible Assets
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the six month period ended March 31, 2021 were as follows (in millions):

[0000833444-21-000020:notes:51]
|  |  |  | Business Acquisitions |  |  |  | Business Divestitures |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  |  |  | March 31, |
|  | 2020 |  |  |  |  |  | 2021 |
| Building Solutions North America | $ | 9,160 |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | 42 |  |  | $ | 9,202 |  |
| Building Solutions EMEA/LA | 1,967 |  |  | 13 |  |  |  |  | — |  |  | 51 |  |  | 2,031 |  |
| Building Solutions Asia Pacific | 1,226 |  |  | — |  |  |  |  | (6) |  |  | 40 |  |  | 1,260 |  |
| Global Products | 5,579 |  |  | — |  |  |  |  | — |  |  | 52 |  |  | 5,631 |  |
| Total | $ | 17,932 |  |  | $ | 13 |  |  |  |  | $ | (6) |  |  | $ | 185 |  |  | $ | 18,124 |  |

[0000833444-21-000020:notes:52]
[same as prior period, unchanged from 0000833444-21-000011:notes:47]

[0000833444-21-000020:notes:53]
The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. There were no triggering events requiring that an impairment assessment be conducted in the six months ended March 31, 2021. However, it is possible that future changes in circumstances, including a more prolonged and/or severe COVID-19 pandemic, would require the Company to record additional non-cash impairment charges.

[0000833444-21-000020:notes:54]
[same as prior period, unchanged from 0000833444-21-000011:notes:50]

[0000833444-21-000020:notes:55]
|  | March 31, 2021 |  | September 30, 2020 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,351 |  |  | $ | (566) |  |  | $ | 785 |  |  | $ | 1,332 |  |  | $ | (497) |  |  | $ | 835 |  |
| Customer relationships | 2,805 |  |  | (1,086) |  |  | 1,719 |  |  | 2,773 |  |  | (969) |  |  | 1,804 |  |
| Miscellaneous | 710 |  |  | (312) |  |  | 398 |  |  | 657 |  |  | (268) |  |  | 389 |  |
|  | 4,866 |  |  | (1,964) |  |  | 2,902 |  |  | 4,762 |  |  | (1,734) |  |  | 3,028 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,277 |  |  | — |  |  | 2,277 |  |  | 2,248 |  |  | — |  |  | 2,248 |  |
| Miscellaneous | 80 |  |  | — |  |  | 80 |  |  | 80 |  |  | — |  |  | 80 |  |
|  | 2,357 |  |  | — |  |  | 2,357 |  |  | 2,328 |  |  | — |  |  | 2,328 |  |
| Total intangible assets | $ | 7,223 |  |  | $ | (1,964) |  |  | $ | 5,259 |  |  | $ | 7,090 |  |  | $ | (1,734) |  |  | $ | 5,356 |  |

[0000833444-21-000020:notes:56]
Amortization of other intangible assets included within continuing operations for the three month periods ended March 31, 2021 and 2020 was $104 million and $97 million, respectively. Amortization of other intangible assets included within continuing operations for the six month periods ended March 31, 2021 and 2020 was $208 million and $193 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2022, 2023, 2024, 2025 and 2026 will be approximately $417 million, $411 million, $395 million, $374 million and $301 million per year, respectively.

[0000833444-21-000020:notes:57]
The Company reviews indefinite-lived intangible assets for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. There were no triggering events requiring that an impairment assessment be conducted in the six months ended March 31, 2021. However, it is possible that future changes in circumstances, including a more prolonged and/or severe COVID-19 pandemic, would require the Company to record additional non-cash impairment charges.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-21-000020:notes:58]
Significant Restructuring and Impairment Costs
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to various restructuring plans as necessary. Restructuring plans generally result in charges for workforce reductions, plant closures, asset impairments and other related costs which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The Company expects the restructuring actions to reduce cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-21-000020:notes:59]
In fiscal 2021, the Company committed to a significant restructuring plan ("2021 Plan"). During the three months ended March 31, 2021, the Company recorded $96 million of restructuring and impairment costs in the consolidated statements of income. The total amount expected to be incurred for this restructuring plan is $385 million across all segments and at Corporate. Of the restructuring and impairment costs recorded, $38 million related to the Building Solutions North America segment, $34 million related to the Global Products segment, $10 million related to the Building Solutions EMEA/LA segment, $7 million related to the Building Solutions Asia Pacific segment and $7 million related to Corporate.

[0000833444-21-000020:notes:60]
The following table summarizes the changes in the Company’s 2021 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-21-000020:notes:61]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  | Total |
| Original reserve | $ | 32 |  |  | $ | 54 |  |  | $ | 10 |  |  |  |  | $ | 96 |  |
| Utilized—cash | (2) |  |  | — |  |  | (3) |  |  |  |  | (5) |  |
| Utilized—noncash | — |  |  | (54) |  |  | — |  |  |  |  | (54) |  |
| Balance at March 31, 2021 | $ | 30 |  |  | $ | — |  |  | $ | 7 |  |  |  |  | $ | 37 |  |

[0000833444-21-000020:notes:62]
[same as prior period, unchanged from 0000833444-21-000011:notes:55]

[0000833444-21-000020:notes:63]
[same as prior period, unchanged from 0000833444-21-000011:notes:56]

[0000833444-21-000020:notes:64]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  | Total |
| Original reserve | $ | 196 |  |  | $ | 96 |  |  | $ | 5 |  |  |  |  | $ | 297 |  |
| Utilized—cash | (92) |  |  | — |  |  | (3) |  |  |  |  | (95) |  |
| Utilized—noncash | — |  |  | (96) |  |  | — |  |  |  |  | (96) |  |
| Currency translation | 2 |  |  | — |  |  | — |  |  |  |  | 2 |  |
| Balance at September 30, 2020 | $ | 106 |  |  | $ | — |  |  | $ | 2 |  |  |  |  | $ | 108 |  |
| Utilized—cash | (46) |  |  | — |  |  | (2) |  |  |  |  | (48) |  |
| Balance at March 31, 2021 | $ | 60 |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | 60 |  |

[0000833444-21-000020:notes:65]
[same as prior period, unchanged from 0000833444-21-000011:notes:58]

[0000833444-21-000020:notes:66]
The Company's fiscal 2021 and 2020 restructuring plans included workforce reductions of approximately 8,100 employees. Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of March 31, 2021, approximately 5,300 of the employees have been separated from the Company pursuant to the restructuring plans.
Company management closely monitors its overall cost structure and continually analyzes each of its businesses for opportunities to consolidate current operations, improve operating efficiencies and locate facilities in close proximity to customers. This ongoing analysis includes a review of its manufacturing, engineering and purchasing operations, as well as the overall global footprint for all its businesses.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-21-000020:notes:67]
[same as prior period, unchanged from 0000833444-21-000011:notes:60]

[0000833444-21-000020:notes:68]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended March 31, 2021, the Company's effective tax rate for continuing operations was 34% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the six months ended March 31, 2021, the Company's effective tax rate for continuing operations was 26% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the three months ended March 31, 2020, the Company's effective tax rate for continuing operations was 5% and was lower than the statutory tax rate of 12.5% primarily due to tax audit reserve adjustments and the benefits of continuing global tax planning initiatives, partially offset by tax rate differentials. For the six months ended March 31, 2020, the Company's effective tax rate for continuing operations was 15% and was higher than the statutory tax rate of 12.5% primarily due to a discrete tax charge related to the remeasurement of deferred tax assets and liabilities as a result of Swiss tax reform and tax rate differentials, partially offset by tax audit reserve adjustments and the benefits of continuing global tax planning initiatives.

[0000833444-21-000020:notes:69]
[same as prior period, unchanged from 0000833444-21-000011:notes:62]

[0000833444-21-000020:notes:70]
The Company reviews the realizability of its deferred tax assets on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-21-000020:notes:71]
In the second quarter of fiscal 2021, due to changes in forecasted taxable income, the Company recorded a discrete tax charge of $105 million related to valuation allowances on certain Mexico deferred tax assets now considered unrealizable.

[0000833444-21-000020:notes:72]
[same as prior period, unchanged from 0000833444-21-000011:notes:65]

[0000833444-21-000020:notes:73]
At September 30, 2020, the Company had gross tax effected unrecognized tax benefits of $2,528 million, of which $2,132 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2020 was approximately $205 million (net of tax benefit). Total net accrued interest during the six months ended March 31, 2021 and 2020 was approximately $24 million (net of tax benefit) and approximately $35 million (net of tax benefit), respectively. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-21-000020:notes:74]
In the second quarter of fiscal 2020, tax audit resolutions resulted in a $22 million net benefit to income tax expense.

[0000833444-21-000020:notes:75]
[same as prior period, unchanged from 0000833444-21-000011:notes:67]

[0000833444-21-000020:notes:76]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2020 |
| China |  | 2017 - 2019 |
| Germany |  | 2007 - 2018 |
| Luxembourg |  | 2017 - 2018 |
| Mexico |  | 2015 - 2020 |
| Taiwan |  | 2019 |
| United Kingdom |  | 2014 - 2015, 2018 |

[0000833444-21-000020:notes:77]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-21-000020:notes:78]
[same as prior period, unchanged from 0000833444-21-000011:notes:70]

[0000833444-21-000020:notes:79]
In the second quarter of fiscal 2021, the Company recorded pension mark-to-market gains of $207 million. The gain generated tax expense of $53 million, which reflects the Company’s current tax position in the impacted jurisdictions.

[0000833444-21-000020:notes:80]
In the second quarter of fiscal 2021, the Company recorded $96 million of restructuring and impairment costs. Refer to Note 10, “Significant Restructuring and Impairment Costs,” of the notes to consolidated financial statements for additional information. The restructuring costs generated a $15 million tax benefit, which reflects the Company’s current tax position in the impacted jurisdictions.

[0000833444-21-000020:notes:81]
In the second quarter of fiscal 2020, the Company recorded $62 million of restructuring and impairment costs. Refer to Note 10, “Significant Restructuring and Impairment Costs,” of the notes to consolidated financial statements for additional information. The restructuring costs generated a $4 million tax benefit, which reflects the Company’s current tax position in the impacted jurisdictions.

[0000833444-21-000020:notes:82]
[same as prior period, unchanged from 0000833444-21-000011:notes:71]

[0000833444-21-000020:notes:83]
[same as prior period, unchanged from 0000833444-21-000011:notes:72]

[0000833444-21-000020:notes:84]
[same as prior period, unchanged from 0000833444-21-000011:notes:73]

[0000833444-21-000020:notes:85]
In the first quarter of fiscal 2020, the Company recorded a noncash discrete tax charge of $30 million due to the remeasurement of deferred tax assets and liabilities related to Switzerland and the canton of Schaffhausen. On September 28, 2018, the Swiss Parliament approved the Federal Act on Tax Reform and AHV Financing (“TRAF”), which was subsequently approved by the Swiss electorate on May 19, 2019. During the fourth quarter of fiscal 2019, the Swiss Federal Council enacted TRAF which became effective for the Company on January 1, 2020. The impacts of the federal 
enactment did not have a material impact to the Company’s financial statements. TRAF also provides for parameters which enable the Swiss cantons to adjust tax rates and establish new regulations for companies. As of September 30, 2019, the canton of Schaffhausen had not concluded its public referendum; however, the enactment did occur during the first quarter of fiscal 2020.During the six months ended March 31, 2021 and 2020, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-21-000020:notes:86]
[same as prior period, unchanged from 0000833444-21-000011:notes:75]

[0000833444-21-000020:notes:87]
|  | U.S. Pension Plans |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Interest cost | $ | 11 |  |  | $ | 19 |  |  | $ | 22 |  |  | $ | 37 |  |
| Expected return on plan assets | (42) |  |  | (46) |  |  | (84) |  |  | (90) |  |
| Net actuarial gain | (203) |  |  | — |  |  | (203) |  |  | — |  |
| Settlement gain | (4) |  |  | — |  |  | (4) |  |  | — |  |
| Net periodic benefit credit | $ | (238) |  |  | $ | (27) |  |  | $ | (269) |  |  | $ | (53) |  |

[0000833444-21-000020:notes:88]
|  | Non-U.S. Pension Plans |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Service cost | $ | 6 |  |  | $ | 7 |  |  | $ | 13 |  |  | $ | 13 |  |
| Interest cost | 8 |  |  | 9 |  |  | 16 |  |  | 18 |  |
| Expected return on plan assets | (27) |  |  | (29) |  |  | (55) |  |  | (56) |  |
| Amortization of prior service cost | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net periodic benefit credit | $ | (13) |  |  | $ | (12) |  |  | $ | (26) |  |  | $ | (24) |  |

[0000833444-21-000020:notes:89]
|  | Postretirement Benefits |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Service cost | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |
| Interest cost | — |  |  | 1 |  |  | 1 |  |  | 2 |  |
| Expected return on plan assets | (2) |  |  | (2) |  |  | (4) |  |  | (4) |  |
| Amortization of prior service credit | (1) |  |  | — |  |  | (2) |  |  | (1) |  |
| Net periodic benefit credit | $ | (2) |  |  | $ | (1) |  |  | $ | (4) |  |  | $ | (3) |  |

[0000833444-21-000020:notes:90]
During the three months ended March 31, 2021, the amount of cumulative fiscal 2021 lump sum payouts triggered a remeasurement event for certain U.S. pension plans resulting in the recognition of net actuarial gains of $203 million, primarily due to an increase in discount rates and favorable plan asset performance.


## us-gaap:DebtDisclosureTextBlock

[0000833444-21-000020:notes:91]
Debt and Financing Arrangements
Net Financing Charges

[0000833444-21-000020:notes:92]
Net financing charges consisted of the following (in millions):

[0000833444-21-000020:notes:93]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Interest expense, net of capitalized interest costs | $ | 53 |  |  | $ | 62 |  |  | $ | 112 |  |  | $ | 124 |  |
| Banking fees and bond cost amortization | 4 |  |  | 5 |  |  | 12 |  |  | 10 |  |
| Interest income | (3) |  |  | (5) |  |  | (6) |  |  | (18) |  |
| Net foreign exchange results for financing activities | (10) |  |  | (3) |  |  | (15) |  |  | (5) |  |
| Net financing charges | $ | 44 |  |  | $ | 59 |  |  | $ | 103 |  |  | $ | 111 |  |

[0000833444-21-000020:notes:94]
In March 2021, the Company entered into a bank term loan arrangement totaling $235 million due in March 2022 and retired $257 million in principal amount, plus accrued interest, of its 4.25% fixed rate notes that expired in March 2021.

[0000833444-21-000020:notes:95]
As of March 31, 2021, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which was renewed in December 2020 and is now scheduled to expire in December 2021. As of March 31, 2021, there were no draws on the facilities.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-21-000020:notes:96]
Stock-Based Compensation
On March 10, 2021, the shareholders of the Company approved the Johnson Controls International plc 2021 Equity and Incentive Plan and terminated the 2012 Share and Incentive Plan, as amended in September 2016 (collectively, the "Plans"). Both plans authorize stock options, stock appreciation rights, restricted (non-vested) stock/units, performance shares, performance units and other stock-based awards. The Compensation and Talent Development Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter.

[0000833444-21-000020:notes:97]
A summary of the stock-based awards granted during the six month periods ended March 31, 2021 and 2020 is presented below:

[0000833444-21-000020:notes:98]
|  | Six Months Ended March 31, |  |  |
|  | 2021 |  |  |  | 2020 |  |  |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |
| Stock options | 932,678 |  |  | $ | 9.36 |  |  |  |  | 1,347,310 |  |  | $ | 7.29 |  |  |  |
| Stock appreciation rights | 35,254 |  |  | 9.36 |  |  |  |  | — |  |  | — |  |  |  |
| Restricted stock/units | 1,697,257 |  |  | 46.20 |  |  |  |  | 1,864,026 |  |  | 41.55 |  |  |  |
| Performance shares | 410,934 |  |  | 50.53 |  |  |  |  | 476,939 |  |  | 42.48 |  |  |  |

[0000833444-21-000020:notes:99]
[same as prior period, unchanged from 0000833444-21-000011:notes:85]

[0000833444-21-000020:notes:100]
[same as prior period, unchanged from 0000833444-21-000011:notes:86]

[0000833444-21-000020:notes:101]
[same as prior period, unchanged from 0000833444-21-000011:notes:87]

[0000833444-21-000020:notes:102]
|  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |
| Expected life of option (years) | 6.5 |  | 6.5 |
| Risk-free interest rate | 0.6% |  | 1.67% |
| Expected volatility of the Company’s stock | 27.6% |  | 22.4% |
| Expected dividend yield on the Company’s stock | 2.28% |  | 2.49% |

[0000833444-21-000020:notes:103]
Stock Appreciation Rights (SARs)

[0000833444-21-000020:notes:104]
SARs vest under the same terms and conditions as stock option awards; however, they are settled in cash for the difference between the market price on the date of the exercise and the exercise price. As a result, SARs are recorded in the Company's consolidated financial statements of financial position as a liability until the date of exercise. The fair value of each SAR award is estimated using a similar method described for stock options. The fair value of each SAR award is recalculated at the end of each reporting period and the liability and expense are adjusted based on the new fair value.

[0000833444-21-000020:notes:105]
[same as prior period, unchanged from 0000833444-21-000011:notes:89]

[0000833444-21-000020:notes:106]
Restricted stock or restricted stock units are typically share settled unless the employee is a non-U.S. employee or elects to defer settlement until retirement at which point the award would be settled in cash. Restricted awards typically vest over a period of three years from the grant date. The Plans allow for different vesting terms on specific grants with approval by the Board of Directors. The fair value of each share-settled restricted award is based on the closing market value of the Company’s ordinary shares on the date of grant. The fair value of each cash-settled restricted award is recalculated at the end of each reporting period based on the closing market value of the Company's ordinary shares at the end of the reporting period, and the liability and expense are adjusted based on the new fair value.

[0000833444-21-000020:notes:107]
[same as prior period, unchanged from 0000833444-21-000011:notes:91]

[0000833444-21-000020:notes:108]
[same as prior period, unchanged from 0000833444-21-000011:notes:92]

[0000833444-21-000020:notes:109]
The fair value of each PSU is estimated on the date of grant using of a Monte Carlo simulation that uses the assumptions noted in the following table. The risk-free interest rate for periods during the contractual life of the PSU is based on the

[0000833444-21-000020:notes:110]
U.S. Treasury yield curve in effect at the time of grant. The expected volatility is based on the historical volatility of the Company's stock over the most recent three-year period as of the grant date.

[0000833444-21-000020:notes:111]
|  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |
| Risk-free interest rate | 0.20% |  | 1.60% |
| Expected volatility of the Company’s stock | 30.9% |  | 21.8% |


## us-gaap:EarningsPerShareTextBlock

[0000833444-21-000020:notes:112]
[same as prior period, unchanged from 0000833444-21-000011:notes:95]

[0000833444-21-000020:notes:113]
[same as prior period, unchanged from 0000833444-21-000011:notes:96]

[0000833444-21-000020:notes:114]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Income Available to Ordinary Shareholders |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 343 |  |  | $ | 213 |  |  | $ | 670 |  |  | $ | 372 |  |
| Income from discontinued operations | — |  |  | — |  |  | 124 |  |  | — |  |
| Basic and diluted income available to shareholders | $ | 343 |  |  | $ | 213 |  |  | $ | 794 |  |  | $ | 372 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 717.1 |  |  | 754.8 |  |  | 720.1 |  |  | 762.4 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 4.2 |  |  | 2.3 |  |  | 3.8 |  |  | 3.2 |  |
| Diluted weighted average shares outstanding | 721.3 |  |  | 757.1 |  |  | 723.9 |  |  | 765.6 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Options to purchase shares | — |  |  | 1.4 |  |  | 0.1 |  |  | 0.8 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-21-000020:notes:115]
Equity and Noncontrolling InterestsOther comprehensive income includes activity relating to discontinued operations. The following schedules present changes in consolidated equity attributable to Johnson Controls and noncontrolling interests (in millions, net of tax):

[0000833444-21-000020:notes:116]
|  | Three Months Ended March 31, 2021 |  | Three Months Ended March 31, 2020 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, December 31 | $ | 17,656 |  |  | $ | 1,167 |  |  | $ | 18,823 |  |  | $ | 19,329 |  |  | $ | 1,102 |  |  | $ | 20,431 |  |
| Total comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 343 |  |  | 54 |  |  | 397 |  |  | 213 |  |  | 23 |  |  | 236 |  |
| Foreign currency translation adjustments | 88 |  |  | (25) |  |  | 63 |  |  | (471) |  |  | (23) |  |  | (494) |  |
| Realized and unrealized gains (losses) on derivatives | 6 |  |  | 2 |  |  | 8 |  |  | (10) |  |  | — |  |  | (10) |  |
| Other comprehensive income (loss) | 94 |  |  | (23) |  |  | 71 |  |  | (481) |  |  | (23) |  |  | (504) |  |
| Comprehensive income (loss) | 437 |  |  | 31 |  |  | 468 |  |  | (268) |  |  | — |  |  | (268) |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (195) |  |  | — |  |  | (195) |  |  | (194) |  |  | — |  |  | (194) |  |
| Dividends attributable to noncontrolling interests | — |  |  | (133) |  |  | (133) |  |  | — |  |  | (98) |  |  | (98) |  |
| Repurchases and retirements of ordinary shares | (315) |  |  | — |  |  | (315) |  |  | (816) |  |  | — |  |  | (816) |  |
| Change in noncontrolling interest share | (8) |  |  | (6) |  |  | (14) |  |  | — |  |  | — |  |  | — |  |
| Other, including options exercised | 123 |  |  | — |  |  | 123 |  |  | 33 |  |  | — |  |  | 33 |  |
| Ending balance, March 31 | $ | 17,698 |  |  | $ | 1,059 |  |  | $ | 18,757 |  |  | $ | 18,084 |  |  | $ | 1,004 |  |  | $ | 19,088 |  |

[0000833444-21-000020:notes:117]
|  | Six Months Ended March 31, 2021 |  | Six Months Ended March 31, 2020 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, September 30 | $ | 17,447 |  |  | $ | 1,086 |  |  | $ | 18,533 |  |  | $ | 19,766 |  |  | $ | 1,063 |  |  | $ | 20,829 |  |
| Total comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 794 |  |  | 99 |  |  | 893 |  |  | 372 |  |  | 55 |  |  | 427 |  |
| Foreign currency translation adjustments | 360 |  |  | 11 |  |  | 371 |  |  | (220) |  |  | (13) |  |  | (233) |  |
| Realized and unrealized gains (losses) on derivatives | 7 |  |  | 2 |  |  | 9 |  |  | (5) |  |  | 2 |  |  | (3) |  |
| Pension and postretirement plans | (1) |  |  | — |  |  | (1) |  |  | (1) |  |  | — |  |  | (1) |  |
| Other comprehensive income (loss) | 366 |  |  | 13 |  |  | 379 |  |  | (226) |  |  | (11) |  |  | (237) |  |
| Comprehensive income | 1,160 |  |  | 112 |  |  | 1,272 |  |  | 146 |  |  | 44 |  |  | 190 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (384) |  |  | — |  |  | (384) |  |  | (395) |  |  | — |  |  | (395) |  |
| Dividends attributable to noncontrolling interests | — |  |  | (133) |  |  | (133) |  |  | — |  |  | (103) |  |  | (103) |  |
| Repurchases and retirements of ordinary shares | (661) |  |  | — |  |  | (661) |  |  | (1,467) |  |  | — |  |  | (1,467) |  |
| Change in noncontrolling interest share | (8) |  |  | (6) |  |  | (14) |  |  | — |  |  | — |  |  | — |  |
| Adoption of ASC 842 | — |  |  | — |  |  | — |  |  | (5) |  |  | — |  |  | (5) |  |
| Adoption of ASU 2016-13 | (4) |  |  | — |  |  | (4) |  |  | — |  |  | — |  |  | — |  |
| Other, including options exercised | 148 |  |  | — |  |  | 148 |  |  | 39 |  |  | — |  |  | 39 |  |
| Ending balance, March 31 | $ | 17,698 |  |  | $ | 1,059 |  |  | $ | 18,757 |  |  | $ | 18,084 |  |  | $ | 1,004 |  |  | $ | 19,088 |  |

[0000833444-21-000020:notes:118]
During the quarter ended December 31, 2020, the Company recorded $4 million to beginning retained earnings for the cumulative effect of adopting ASU 2016-13, "Financial Instruments - Credit Losses."

[0000833444-21-000020:notes:119]
[same as prior period, unchanged from 0000833444-21-000011:notes:101]

[0000833444-21-000020:notes:120]
For the three and six months ended March 31, 2021, the Company repurchased and immediately retired $315 million and $661 million of its ordinary shares, respectively. For the three and six months ended March 31, 2020, the Company repurchased and immediately retired $816 million and $1,467 million of its ordinary shares, respectively. In March 2021, the Company's Board of Directors approved a $4.0 billion increase to the Company's share repurchase authorization, adding to the $2.0 billion remaining as of December 31, 2020 under the prior share repurchase authorization approved in 2019. As of March 31, 2021, approximately $5.7 billion remains available under the Company's share repurchase authorization.

[0000833444-21-000020:notes:121]
[same as prior period, unchanged from 0000833444-21-000011:notes:103]

[0000833444-21-000020:notes:122]
|  | Three Months Ended March 31, |
|  | 2021 |  | 2020 |
| Foreign currency translation adjustments ("CTA") |  |  |  |
| Balance at beginning of period | $ | (506) |  |  | $ | (534) |  |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | 88 |  |  | (471) |  |
| Balance at end of period | (418) |  |  | (1,005) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 3 |  |  | 3 |  |
| Current period changes in fair value (net of tax effect of $2 and $(3)) | 5 |  |  | (8) |  |
| Reclassification to income (net of tax effect of $0 and $0) * | 1 |  |  | (2) |  |
| Balance at end of period | 9 |  |  | (7) |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (1) |  |  | (9) |  |
| Reclassification to income (net of tax effect of $0 and $0) | — |  |  | — |  |
| Balance at end of period | (1) |  |  | (9) |  |
| Accumulated other comprehensive loss, end of period | $ | (410) |  |  | $ | (1,021) |  |

[0000833444-21-000020:notes:123]
|  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |
| CTA |  |  |  |
| Balance at beginning of period | $ | (778) |  |  | $ | (785) |  |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | 360 |  |  | (220) |  |
| Balance at end of period | (418) |  |  | (1,005) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 2 |  |  | (2) |  |
| Current period changes in fair value (net of tax effect of $4 and $(1)) | 7 |  |  | (3) |  |
| Reclassification to income (net of tax effect of $0 and $0) * | — |  |  | (2) |  |
| Balance at end of period | 9 |  |  | (7) |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | — |  |  | (8) |  |
| Reclassification to income (net of tax effect of $0 and $0) | (1) |  |  | (1) |  |
| Balance at end of period | (1) |  |  | (9) |  |
| Accumulated other comprehensive loss, end of period | $ | (410) |  |  | $ | (1,021) |  |

[0000833444-21-000020:notes:124]
[same as prior period, unchanged from 0000833444-21-000011:notes:105]

[0000833444-21-000020:notes:125]
[same as prior period, unchanged from 0000833444-21-000011:notes:106]

[0000833444-21-000020:notes:126]
[same as prior period, unchanged from 0000833444-21-000011:notes:107]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-21-000020:notes:127]
[same as prior period, unchanged from 0000833444-21-000011:notes:108]

[0000833444-21-000020:notes:128]
[same as prior period, unchanged from 0000833444-21-000011:notes:109]

[0000833444-21-000020:notes:129]
[same as prior period, unchanged from 0000833444-21-000011:notes:110]

[0000833444-21-000020:notes:130]
[same as prior period, unchanged from 0000833444-21-000011:notes:111]

[0000833444-21-000020:notes:131]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three and six months ended March 31, 2021 and 2020.

[0000833444-21-000020:notes:132]
[same as prior period, unchanged from 0000833444-21-000011:notes:113]

[0000833444-21-000020:notes:133]
|  |  | Volume Outstanding as of |
| Commodity |  | March 31, 2021 |  | September 30, 2020 |
| Copper |  | 2,783 |  |  | 2,497 |  |
| Aluminum |  | 3,133 |  |  | 3,036 |  |

[0000833444-21-000020:notes:134]
[same as prior period, unchanged from 0000833444-21-000011:notes:115]

[0000833444-21-000020:notes:135]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company’s net investments globally. At March 31, 2021 and September 30, 2020, the Company had 888 million euro, 500 million euro, 500 million euro, 423 million euro and 54 million euro in bonds designated as net investment hedges of a portion of the Company's net investment in European subsidiaries and 25 billion yen of foreign denominated debt designated as net investment hedge of a portion of the Company's net investment in Japanese subsidiaries.

[0000833444-21-000020:notes:136]
[same as prior period, unchanged from 0000833444-21-000011:notes:117]

[0000833444-21-000020:notes:137]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount. The Company hedged approximately 1.4 million shares of its ordinary shares, which have a cost basis of $58 million, as of March 31, 2021 and 1.4 million shares, which have a cost basis of $60 million, as of September 30, 2020.

[0000833444-21-000020:notes:138]
The Company also holds certain foreign currency forward and option contracts not designated as hedging instruments under ASC 815. The change in fair value of these foreign currency exchange derivatives are recorded in the consolidated statements of income in the period in which they occur.

[0000833444-21-000020:notes:139]
[same as prior period, unchanged from 0000833444-21-000011:notes:120]

[0000833444-21-000020:notes:140]
[same as prior period, unchanged from 0000833444-21-000011:notes:121]

[0000833444-21-000020:notes:141]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | March 31, |  | September 30, |  | March 31, |  | September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 20 |  |  | $ | 10 |  |  | $ | 57 |  |  | $ | 17 |  |
| Commodity derivatives | 3 |  |  | 2 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 82 |  |  | 58 |  |
| Total assets | $ | 23 |  |  | $ | 12 |  |  | $ | 139 |  |  | $ | 75 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 7 |  |  | $ | 10 |  |  | $ | 3 |  |  | $ | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,002 |  |  | 3,010 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,009 |  |  | $ | 3,020 |  |  | $ | 3 |  |  | $ | — |  |

[0000833444-21-000020:notes:142]
[same as prior period, unchanged from 0000833444-21-000011:notes:123]

[0000833444-21-000020:notes:143]
[same as prior period, unchanged from 0000833444-21-000011:notes:124]

[0000833444-21-000020:notes:144]
[same as prior period, unchanged from 0000833444-21-000011:notes:125]

[0000833444-21-000020:notes:145]
[same as prior period, unchanged from 0000833444-21-000011:notes:126]

[0000833444-21-000020:notes:146]
|  |  | Fair Value of Assets |  |  |  | Fair Value of Liabilities |  |  |
|  |  | March 31, |  | September 30, |  |  |  | March 31, |  | September 30, |  |  |
|  |  | 2021 |  | 2020 |  |  |  | 2021 |  | 2020 |  |  |
| Gross amount recognized |  | $ | 162 |  |  | $ | 87 |  |  |  |  | $ | 3,012 |  |  | $ | 3,020 |  |  |  |
| Gross amount eligible for offsetting |  | (10) |  |  | (10) |  |  |  |  | (10) |  |  | (10) |  |  |  |
| Net amount |  | $ | 152 |  |  | $ | 77 |  |  |  |  | $ | 3,002 |  |  | $ | 3,010 |  |  |  |

[0000833444-21-000020:notes:147]
[same as prior period, unchanged from 0000833444-21-000011:notes:128]

[0000833444-21-000020:notes:148]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the three and six months ended March 31, 2021 and 2020 (in millions):

[0000833444-21-000020:notes:149]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Foreign currency exchange derivatives |  | $ | 10 |  |  | $ | (7) |  |  | $ | 13 |  |  | $ | 2 |  |
| Commodity derivatives |  | — |  |  | (4) |  |  | 1 |  |  | (3) |  |
| Total |  | $ | 10 |  |  | $ | (11) |  |  | $ | 14 |  |  | $ | (1) |  |

[0000833444-21-000020:notes:150]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the three and six months ended March 31, 2021 and 2020 (in millions):

[0000833444-21-000020:notes:151]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 1 |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | 3 |  |
| Commodity derivatives |  | Cost of sales |  | (2) |  |  | — |  |  | (3) |  |  | (1) |  |
| Total |  |  |  | $ | (1) |  |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |

[0000833444-21-000020:notes:152]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the three and six months ended March 31, 2021 and 2020 (in millions):

[0000833444-21-000020:notes:153]
|  |  |  |  | Amount of Gain (Loss) Recognized inIncome on Derivative |
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 2 |  |  | $ | 4 |  |  | $ | (4) |  |  | $ | 4 |  |
| Foreign currency exchange derivatives |  | Selling, general and administrative |  | 3 |  |  | — |  |  | 1 |  |  | — |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 100 |  |  | (10) |  |  | 145 |  |  | 49 |  |
| Equity swap |  | Selling, general and administrative |  | 18 |  |  | (20) |  |  | 24 |  |  | (24) |  |
| Total |  |  |  | $ | 123 |  |  | $ | (26) |  |  | $ | 166 |  |  | $ | 29 |  |

[0000833444-21-000020:notes:154]
Pre-tax gains on net investment hedges recorded in CTA within other comprehensive income (loss) were $144 million and $46 million for the three months ended March 31, 2021 and 2020, respectively. Pre-tax gains (losses) on net investment hedges recorded in CTA within other comprehensive income (loss) were $9 million and $(12) million for the six months ended March 31, 2021 and 2020, respectively. For the three and six months ended March 31, 2021 and 2020, no gains or losses were reclassified from CTA into income.


## us-gaap:DerivativesPolicyTextBlock

[0000833444-21-000020:notes:155]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings.The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company’s net investments globally.The Company also holds certain foreign currency forward and option contracts not designated as hedging instruments under ASC 815. The change in fair value of these foreign currency exchange derivatives are recorded in the consolidated statements of income in the period in which they occur.The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-21-000020:notes:156]
[same as prior period, unchanged from 0000833444-21-000011:notes:136]

[0000833444-21-000020:notes:157]
[same as prior period, unchanged from 0000833444-21-000011:notes:137]

[0000833444-21-000020:notes:158]
[same as prior period, unchanged from 0000833444-21-000011:notes:138]

[0000833444-21-000020:notes:159]
[same as prior period, unchanged from 0000833444-21-000011:notes:139]

[0000833444-21-000020:notes:160]
[same as prior period, unchanged from 0000833444-21-000011:notes:140]

[0000833444-21-000020:notes:161]
[same as prior period, unchanged from 0000833444-21-000011:notes:141]

[0000833444-21-000020:notes:162]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of March 31, 2021 and September 30, 2020 (in millions):

[0000833444-21-000020:notes:163]
|  | Fair Value Measurements Using: |
|  | Total as of March 31, 2021 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 77 |  |  | $ | — |  |  | $ | 77 |  |  | $ | — |  |
| Commodity derivatives | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 72 |  |  | 72 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 147 |  |  | 147 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 157 |  |  | 157 |  |  | — |  |  | — |  |
| Equity swap | 82 |  |  | — |  |  | 82 |  |  | — |  |
| Total assets | $ | 538 |  |  | $ | 376 |  |  | $ | 162 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |
| Total liabilities | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |

[0000833444-21-000020:notes:164]
[same as prior period, unchanged from 0000833444-21-000011:notes:144]

[0000833444-21-000020:notes:165]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for further details.

[0000833444-21-000020:notes:166]
[same as prior period, unchanged from 0000833444-21-000011:notes:146]

[0000833444-21-000020:notes:167]
[same as prior period, unchanged from 0000833444-21-000011:notes:147]

[0000833444-21-000020:notes:168]
[same as prior period, unchanged from 0000833444-21-000011:notes:148]

[0000833444-21-000020:notes:169]
[same as prior period, unchanged from 0000833444-21-000011:notes:149]

[0000833444-21-000020:notes:170]
[same as prior period, unchanged from 0000833444-21-000011:notes:150]

[0000833444-21-000020:notes:171]
Investments in exchange traded funds:  Investments in exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.  Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-21-000020:notes:172]
The following table presents the portion of unrealized gains (losses) recognized in the consolidated statements of income for the three and six months ended March 31, 2021 and 2020 that relate to equity securities still held at March 31, 2021 and 2020 (in millions):

[0000833444-21-000020:notes:173]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Deferred compensation plan assets |  | $ | 2 |  |  | $ | (10) |  |  | $ | 7 |  |  | $ | (7) |  |
| Investments in exchange traded funds |  | 2 |  |  | (32) |  |  | 23 |  |  | (22) |  |

[0000833444-21-000020:notes:174]
All of the gains and losses on investments in exchange traded funds related to restricted investments. 
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. At March 31, 2021, the fair value of long-term debt was $8.1 billion, including public debt of $7.9 billion and other long-term debt of $0.2 billion. At September 30, 2020, the fair value of long-term debt was $8.6 billion, including public debt of $8.4 billion and other long-term debt of $0.2 billion. The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy.  The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000833444-21-000020:notes:175]
ASC 820, "Fair Value Measurement," defines fair value as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0000833444-21-000020:notes:176]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. Unrealized gains (losses) on the deferred compensation plan assets are recognized in the consolidated statements of income where they offset unrealized gains and losses on the related deferred compensation plan liability. 
Investments in exchange traded funds:  Investments in exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy.  The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:AssetImpairmentChargesTextBlock

[0000833444-21-000020:notes:177]
Impairment of Long-Lived Assets
The Company reviews long-lived assets, including right-of-use assets under operating leases, other tangible assets and intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of Software to be Sold, Leased, or Marketed."

[0000833444-21-000020:notes:178]
The Company groups assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluates the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. Intangible assets acquired in a business combination that are used in research and development activities are considered indefinite-lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they are not amortized but are tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired.  If the carrying amount of an intangible asset exceeds its fair value, the Company recognizes an impairment loss in an amount equal to that excess. Unamortized capitalized costs of a computer software product are compared to the net realizable value of the product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset is written off.

[0000833444-21-000020:notes:179]
In the second quarter of fiscal 2021, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2021. As a result, the Company reviewed the long-lived assets for impairment and recorded $54 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $29 million related to the Building Solutions North America segment, $16 million related to the Global Products segment, $5 million related to Corporate assets and $4 million related to the Building Solutions Asia Pacific segment. Refer to Note 10, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-21-000020:notes:180]
[same as prior period, unchanged from 0000833444-21-000011:notes:156]

[0000833444-21-000020:notes:181]
[same as prior period, unchanged from 0000833444-21-000011:notes:157]

[0000833444-21-000020:notes:182]
[same as prior period, unchanged from 0000833444-21-000011:notes:158]

[0000833444-21-000020:notes:183]
At March 31, 2021 and 2020, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets.

[0000833444-21-000020:notes:184]
[same as prior period, unchanged from 0000833444-21-000011:notes:160]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-21-000020:notes:185]
[same as prior period, unchanged from 0000833444-21-000011:notes:161]

[0000833444-21-000020:notes:186]
[same as prior period, unchanged from 0000833444-21-000011:notes:162]

[0000833444-21-000020:notes:187]
[same as prior period, unchanged from 0000833444-21-000011:notes:163]

[0000833444-21-000020:notes:188]
[same as prior period, unchanged from 0000833444-21-000011:notes:164]

[0000833444-21-000020:notes:189]
•Global Products: Global Products designs and produces heating and air conditioning for residential and commercial applications, and markets products and refrigeration systems to replacement and new construction market customers globally. The Global Products business also designs, manufactures and sells fire protection and security products, including intrusion security, anti-theft devices, and access control and video management systems, for commercial,

[0000833444-21-000020:notes:190]
industrial, retail, residential, small business, institutional and governmental customers worldwide.  Global Products also includes the Johnson Controls-Hitachi joint venture.

[0000833444-21-000020:notes:191]
[same as prior period, unchanged from 0000833444-21-000011:notes:166]

[0000833444-21-000020:notes:192]
[same as prior period, unchanged from 0000833444-21-000011:notes:167]

[0000833444-21-000020:notes:193]
|  | Net Sales |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Building Solutions North America | $ | 2,092 |  |  | $ | 2,175 |  |  | $ | 4,126 |  |  | $ | 4,342 |  |
| Building Solutions EMEA/LA | 897 |  |  | 850 |  |  | 1,803 |  |  | 1,778 |  |
| Building Solutions Asia Pacific | 603 |  |  | 525 |  |  | 1,218 |  |  | 1,154 |  |
| Global Products | 2,002 |  |  | 1,894 |  |  | 3,788 |  |  | 3,746 |  |
| Total net sales | $ | 5,594 |  |  | $ | 5,444 |  |  | $ | 10,935 |  |  | $ | 11,020 |  |

[0000833444-21-000020:notes:194]
|  | Segment EBITA |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Building Solutions North America | $ | 266 |  |  | $ | 251 |  |  | $ | 521 |  |  | $ | 509 |  |
| Building Solutions EMEA/LA | 86 |  |  | 85 |  |  | 181 |  |  | 175 |  |
| Building Solutions Asia Pacific | 74 |  |  | 65 |  |  | 153 |  |  | 137 |  |
| Global Products | 285 |  |  | 216 |  |  | 498 |  |  | 419 |  |
| Total segment EBITA | $ | 711 |  |  | $ | 617 |  |  | $ | 1,353 |  |  | $ | 1,240 |  |
| Corporate expenses | $ | (70) |  |  | $ | (118) |  |  | $ | (137) |  |  | $ | (236) |  |
| Amortization of intangible assets | (104) |  |  | (97) |  |  | (208) |  |  | (193) |  |
| Restructuring and impairment costs | (96) |  |  | (62) |  |  | (96) |  |  | (173) |  |
| Net mark-to-market adjustments | 209 |  |  | (32) |  |  | 230 |  |  | (22) |  |
| Net financing charges | (44) |  |  | (59) |  |  | (103) |  |  | (111) |  |
| Income from continuing operations before income taxes | $ | 606 |  |  | $ | 249 |  |  | $ | 1,039 |  |  | $ | 505 |  |


## us-gaap:GuaranteesTextBlock

[0000833444-21-000020:notes:195]
[same as prior period, unchanged from 0000833444-21-000011:notes:170]

[0000833444-21-000020:notes:196]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate for future warranty-related costs based on actual historical

[0000833444-21-000020:notes:197]
return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-21-000020:notes:198]
[same as prior period, unchanged from 0000833444-21-000011:notes:172]

[0000833444-21-000020:notes:199]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations, for the six months ended March 31, 2021 and 2020 were as follows (in millions). Extended warranty for which deferred revenue is recorded is not included in the table below, but rather included within the contract balances table in the Note 5, "Revenue Recognition," of the notes to consolidated financial statements for all periods presented.

[0000833444-21-000020:notes:200]
|  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |
| Balance at beginning of period | $ | 167 |  |  | $ | 156 |  |
| Accruals for warranties issued during the period | 39 |  |  | 32 |  |
| Accruals from acquisition and divestitures | (1) |  |  | — |  |
| Accruals related to pre-existing warranties | 14 |  |  | (3) |  |
| Settlements made (in cash or in kind) during the period | (33) |  |  | (30) |  |
| Currency translation | — |  |  | (1) |  |
| Balance at end of period | $ | 186 |  |  | $ | 154 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-21-000020:notes:201]
Commitments and Contingencies
Environmental Matters

[0000833444-21-000020:notes:202]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of March 31, 2021, reserves for environmental liabilities for continuing operations totaled $112 million, of which $46 million was recorded within other current liabilities and $66 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $130 million at September 30, 2020, of which $61 million was recorded within other current liabilities and $69 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

[0000833444-21-000020:notes:203]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin. In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.

[0000833444-21-000020:notes:204]
During the third quarter of 2019, the Company increased its environmental reserves, which included $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.

[0000833444-21-000020:notes:205]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in

[0000833444-21-000020:notes:206]
order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

[0000833444-21-000020:notes:207]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation.

[0000833444-21-000020:notes:208]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter.  The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).” The WDNR issued a further letter regarding the issue on November 4, 2019.  In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

[0000833444-21-000020:notes:209]
In December 2020, the Company received a notice from the Wisconsin Department of Justice (“WDOJ”) that the WDOJ was considering a potential civil enforcement action against the Company relating to environmental matters at the FTC including, but not limited to, the investigation and remediation of PFAS at or near the FTC as discussed in the prior paragraphs and the Company’s alleged failure to timely report the presence of PFAS chemicals at the FTC. Such enforcement action could seek civil monetary penalties and/or injunctive relief. The Company is presently unable to predict the duration, scope, or results of any potential civil enforcement action that may result, the consequences of any such action, or the nature of any resolution of these potential claims with the WDOJ.

[0000833444-21-000020:notes:210]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility in the third quarter of 2019 was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation of PFAS in the Marinette region.

[0000833444-21-000020:notes:211]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to

[0000833444-21-000020:notes:212]
the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At March 31, 2021 and September 30, 2020, the Company recorded conditional asset retirement obligations for continuing operations of $29 million and $29 million, respectively.

[0000833444-21-000020:notes:213]
Asbestos Matters

[0000833444-21-000020:notes:214]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-21-000020:notes:215]
As of March 31, 2021, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $93 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $470 million, of which $49 million was recorded in other current liabilities and $421 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $22 million was recorded in other current assets, and $355 million was recorded in other noncurrent assets. Assets included $11 million of cash and $304 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at March 31, 2021 was $62 million. As of September 30, 2020, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $115 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $483 million, of which $49 million was recorded in other current liabilities and $434 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $368 million, of which $39 million was recorded in other current assets, and $329 million was recorded in other noncurrent assets. Assets included $9 million of cash and $291 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2020 was $68 million.

[0000833444-21-000020:notes:216]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-21-000020:notes:217]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-21-000020:notes:218]
Insurable Liabilities

[0000833444-21-000020:notes:219]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At March 31, 2021 and September 30, 2020, the insurable liabilities totaled $366 million and $363 million, respectively, of which $90 million and $83 million was recorded within other current liabilities, $23 million and $22 million was recorded within accrued compensation and benefits, and $253 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at March 31, 2021 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2020 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-21-000020:notes:220]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-21-000020:notes:221]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but had stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. The EPA also announced in January 2021 that it will issue an advance notice of proposed rulemaking to solicit public comment on whether the agency should take additional regulatory steps to address PFAS contamination, including designating PFOA and PFOS and other PFAS as hazardous substances under the Comprehensive Environmental Response, Compensation, and Liability Act and seeking comment on whether PFOA and PFOS and other PFAS should be subject to regulation as hazardous waste under the Resource Conservation and Recovery Act. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

[0000833444-21-000020:notes:222]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-21-000020:notes:223]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-21-000020:notes:224]
AFFF Putative Class Actions

[0000833444-21-000020:notes:225]
Chemguard and Tyco Fire Products are named in 31 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington, New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan, Texas and South Dakota. All of these cases have been direct-filed in or transferred to the MDL. Since the beginning of fiscal year 2021, two putative class actions (Jackson v. 3M Company, et al., direct filed on January 15, 2021 in the MDL pending in the United States District Court, District of South Carolina; Ogden v. Intercontinental Terminals Company LLC, et al., filed in the United States District Court, Southern District of Texas on January 27, 2021, and tagged to the MDL) have been filed against the Company.

[0000833444-21-000020:notes:226]
AFFF Individual or Mass Actions

[0000833444-21-000020:notes:227]
There are approximately 1,000 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, and approximately 1,000 other plaintiffs. All but five of these matters have been transferred to or directly-filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL.  Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court.  The Company anticipates that the remainder of the possible individual product liability claims filed in Pennsylvania state court will either soon be filed in the MDL (and that all such claims in state court will be dismissed accordingly) or will be dismissed in Pennsylvania without a corresponding filing in South Carolina.

[0000833444-21-000020:notes:228]
AFFF Municipal Cases

[0000833444-21-000020:notes:229]
Chemguard and Tyco Fire Products have been named as defendants in 87 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Alabama, Arizona, California, Colorado, Florida, Idaho, Kentucky, Louisiana, Massachusetts, New Jersey, New York, Maryland, North Carolina, Ohio, Pennsylvania, Virginia, Washington, the District of Columbia and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but five of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.

[0000833444-21-000020:notes:230]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base. In May 2020, the Company was also notified by the Lakewood Water District in Pierce County, Washington that it may assert claims regarding remediation in connection with PFOA, PFOS, and other PFAS contamination allegedly resulting from the use of those products at Joint Base Lewis-McChord.

[0000833444-21-000020:notes:231]
In April 2020, the Weirton Area Water Board in West Virginia filed a lawsuit in the Circuit Court of Brooke County, West Virginia against a number of PFAS chemical manufacturers, including Chemguard, with respect to PFAS contamination. This case has been removed to the United States District Court for the Northern District of West Virginia and transferred to the MDL in the District of South Carolina.

[0000833444-21-000020:notes:232]
State or U.S. Territory Attorneys General Litigation related to AFFF

[0000833444-21-000020:notes:233]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-21-000020:notes:234]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-21-000020:notes:235]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752 -000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio. The lawsuit seeks to recover costs and natural resource damages associated with the contamination. This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-21-000020:notes:236]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

[0000833444-21-000020:notes:237]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-21-000020:notes:238]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

[0000833444-21-000020:notes:239]
In August 2020, Attorney General of the State of Michigan filed two substantially similar lawsuits—one in federal court and one in state court—against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within the State.  The federal action has been transferred to the MDL, and the state court action has been removed to federal court and tagged for transfer to the MDL.

[0000833444-21-000020:notes:240]
In December 2020, the State of Mississippi filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

[0000833444-21-000020:notes:241]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint has not yet been served.

[0000833444-21-000020:notes:242]
AFFF Matters Related to the Tyco Fire Products Fire Technology Center in Marinette, Wisconsin

[0000833444-21-000020:notes:243]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. On January 7, 2021, the parties agreed to settle the lawsuit. The settlement provides that Tyco will pay up to $17.5 million to compensate Town of Peshtigo residents who live in the area affected by PFAS from the FTC for claims related to loss of real property value, exposure and/or personal injury. The settlement does not constitute an admission of wrongdoing by Tyco or Chemguard and is subject to approval by the federal court presiding over the lawsuit and other contingencies. The court is scheduled to conduct a hearing regarding the proposed settlement in May 2021. The Company does not expect the settlement to have a significant impact on its fiscal year 2021 results of operations or cash flows.

[0000833444-21-000020:notes:244]
A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.

[0000833444-21-000020:notes:245]
Other AFFF Related Matters

[0000833444-21-000020:notes:246]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-21-000020:notes:247]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-21-000020:notes:248]
Other Matters

[0000833444-21-000020:notes:249]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-21-000020:notes:250]
Related Party Transactions
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-21-000020:notes:251]
The following table presents net sales to and purchases from related parties for the three and six months ended March 31, 2021 and 2020 (in millions):

[0000833444-21-000020:notes:252]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales to related parties |  | $ | 53 |  |  | $ | 38 |  |  | $ | 97 |  |  | $ | 83 |  |
| Purchases from related parties |  | 37 |  |  | 10 |  |  | 66 |  |  | 22 |  |

[0000833444-21-000020:notes:253]
The following table presents receivables from and payables to related parties in the consolidated statements of financial position (in millions):

[0000833444-21-000020:notes:254]
|  |  | March 31, 2021 |  | September 30, 2020 |
| Receivable from related parties |  | $ | 62 |  |  | $ | 48 |  |
| Payable to related parties |  | 19 |  |  | 11 |  |
