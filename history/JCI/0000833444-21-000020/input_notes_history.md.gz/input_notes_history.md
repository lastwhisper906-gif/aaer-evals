# JCI note change history — 0000833444-21-000011 → 0000833444-21-000020


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-04-30):
[0000833444-21-000020:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of March 31, 2021, reserves for environmental liabilities for continuing operations totaled $112 million, of which $46 million was recorded within other current liabilities and $66 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $130 million at September 30, 2020, of which $61 million was recorded within other current liabilities and $69 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.
  (was, 2021-01-29, similarity 0.9912):
[0000833444-21-000011:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of December 31, 2020, reserves for environmental liabilities for continuing operations totaled $122 million, of which $61 million was recorded within other current liabilities and $61 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $130 million at September 30, 2020, of which $61 million was recorded within other current liabilities and $69 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

- added (2021-04-30):
[0000833444-21-000020:note_history:2]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in

- changed (2021-04-30):
[0000833444-21-000020:note_history:3]
order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.
  (was, 2021-01-29, similarity 0.7976):
[0000833444-21-000011:note_history:3]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

- changed (2021-04-30):
[0000833444-21-000020:note_history:4]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation.
  (was, 2021-01-29, similarity 0.6885):
[0000833444-21-000011:note_history:4]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22,

- added (2021-04-30):
[0000833444-21-000020:note_history:5]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to

- changed (2021-04-30):
[0000833444-21-000020:note_history:6]
the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At March 31, 2021 and September 30, 2020, the Company recorded conditional asset retirement obligations for continuing operations of $29 million and $29 million, respectively.
  (was, 2021-01-29, similarity 0.714):
[0000833444-21-000011:note_history:6]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or

- changed (2021-04-30):
[0000833444-21-000020:note_history:7]
As of March 31, 2021, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $93 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $470 million, of which $49 million was recorded in other current liabilities and $421 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $22 million was recorded in other current assets, and $355 million was recorded in other noncurrent assets. Assets included $11 million of cash and $304 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at March 31, 2021 was $62 million. As of September 30, 2020, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $115 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $483 million, of which $49 million was recorded in other current liabilities and $434 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $368 million, of which $39 million was recorded in other current assets, and $329 million was recorded in other noncurrent assets. Assets included $9 million of cash and $291 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2020 was $68 million.
  (was, 2021-01-29, similarity 0.9942):
[0000833444-21-000011:note_history:7]
As of December 31, 2020, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $93 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $474 million, of which $49 million was recorded in other current liabilities and $425 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $381 million, of which $17 million was recorded in other current assets, and $364 million was recorded in other noncurrent assets. Assets included $5 million of cash and $308 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at December 31, 2020 was $68 million. As of September 30, 2020, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $115 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $483 million, of which $49 million was recorded in other current liabilities and $434 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $368 million, of which $39 million was recorded in other current assets, and $329 million was recorded in other noncurrent assets. Assets included $9 million of cash and $291 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2020 was $68 million.

- changed (2021-04-30):
[0000833444-21-000020:note_history:8]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.
  (was, 2021-01-29, similarity 0.8294):
[0000833444-21-000011:note_history:8]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-

- changed (2021-04-30):
[0000833444-21-000020:note_history:9]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At March 31, 2021 and September 30, 2020, the insurable liabilities totaled $366 million and $363 million, respectively, of which $90 million and $83 million was recorded within other current liabilities, $23 million and $22 million was recorded within accrued compensation and benefits, and $253 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at March 31, 2021 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2020 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.
  (was, 2021-01-29, similarity 0.9906):
[0000833444-21-000011:note_history:9]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At December 31, 2020 and September 30, 2020, the insurable liabilities totaled $362 million and $363 million, respectively, of which $88 million and $83 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $252 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at December 31, 2020 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2020 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

- changed (2021-04-30):
[0000833444-21-000020:note_history:10]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but had stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. The EPA also announced in January 2021 that it will issue an advance notice of proposed rulemaking to solicit public comment on whether the agency should take additional regulatory steps to address PFAS contamination, including designating PFOA and PFOS and other PFAS as hazardous substances under the Comprehensive Environmental Response, Compensation, and Liability Act and seeking comment on whether PFOA and PFOS and other PFAS should be subject to regulation as hazardous waste under the Resource Conservation and Recovery Act. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.
  (was, 2021-01-29, similarity 0.8566):
[0000833444-21-000011:note_history:10]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but has stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

- changed (2021-04-30):
[0000833444-21-000020:note_history:11]
Chemguard and Tyco Fire Products are named in 31 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington, New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan, Texas and South Dakota. All of these cases have been direct-filed in or transferred to the MDL. Since the beginning of fiscal year 2021, two putative class actions (Jackson v. 3M Company, et al., direct filed on January 15, 2021 in the MDL pending in the United States District Court, District of South Carolina; Ogden v. Intercontinental Terminals Company LLC, et al., filed in the United States District Court, Southern District of Texas on January 27, 2021, and tagged to the MDL) have been filed against the Company.
  (was, 2021-01-29, similarity 0.8685):
[0000833444-21-000011:note_history:11]
Chemguard and Tyco Fire Products are named in 31 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington, New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan and South Dakota. All of these cases have been direct-filed in or transferred to the MDL. Since the beginning of fiscal year 2021, one putative class action (Jackson v. 3M Company, et al., direct filed on January 15, 2021 in the MDL pending in the United States District Court, District of South Carolina) has been filed against the Company.

- added (2021-04-30):
[0000833444-21-000020:note_history:12]
There are approximately 1,000 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, and approximately 1,000 other plaintiffs. All but five of these matters have been transferred to or directly-filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL.  Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court.  The Company anticipates that the remainder of the possible individual product liability claims filed in Pennsylvania state court will either soon be filed in the MDL (and that all such claims in state court will be dismissed accordingly) or will be dismissed in Pennsylvania without a corresponding filing in South Carolina.

- added (2021-04-30):
[0000833444-21-000020:note_history:13]
Chemguard and Tyco Fire Products have been named as defendants in 87 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Alabama, Arizona, California, Colorado, Florida, Idaho, Kentucky, Louisiana, Massachusetts, New Jersey, New York, Maryland, North Carolina, Ohio, Pennsylvania, Virginia, Washington, the District of Columbia and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but five of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.

- changed (2021-04-30):
[0000833444-21-000020:note_history:14]
In April 2020, the Weirton Area Water Board in West Virginia filed a lawsuit in the Circuit Court of Brooke County, West Virginia against a number of PFAS chemical manufacturers, including Chemguard, with respect to PFAS contamination. This case has been removed to the United States District Court for the Northern District of West Virginia and transferred to the MDL in the District of South Carolina.
  (was, 2021-01-29, similarity 0.9172):
[0000833444-21-000011:note_history:14]
In April 2020, the Weirton Area Water Board in West Virginia filed a lawsuit in the Circuit Court of Brooke County, West Virginia against a number of PFAS chemical manufacturers, including Chemguard, with respect to PFAS contamination. This case has been removed to the United States District Court for the Northern District of West Virginia.

- changed (2021-04-30):
[0000833444-21-000020:note_history:15]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.
  (was, 2021-01-29, similarity 0.6922):
[0000833444-21-000011:note_history:15]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect

- added (2021-04-30):
[0000833444-21-000020:note_history:16]
In December 2020, the State of Mississippi filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

- added (2021-04-30):
[0000833444-21-000020:note_history:17]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint has not yet been served.

- changed (2021-04-30):
[0000833444-21-000020:note_history:18]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. On January 7, 2021, the parties agreed to settle the lawsuit. The settlement provides that Tyco will pay up to $17.5 million to compensate Town of Peshtigo residents who live in the area affected by PFAS from the FTC for claims related to loss of real property value, exposure and/or personal injury. The settlement does not constitute an admission of wrongdoing by Tyco or Chemguard and is subject to approval by the federal court presiding over the lawsuit and other contingencies. The court is scheduled to conduct a hearing regarding the proposed settlement in May 2021. The Company does not expect the settlement to have a significant impact on its fiscal year 2021 results of operations or cash flows.
  (was, 2021-01-29, similarity 0.9103):
[0000833444-21-000011:note_history:18]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. On January 7, 2021, the parties agreed to settle the lawsuit. The settlement provides that Tyco will pay up to $17.5 million to compensate Town of Peshtigo residents who live in the area affected by PFAS from the FTC for claims related to loss of real property value, exposure and/or personal injury. The settlement does not constitute an admission of wrongdoing by Tyco or Chemguard and is subject to approval by the federal court presiding over the lawsuit and other contingencies. The Company does not expect the settlement to have a significant impact on its fiscal year 2021 results of operations or cash flows.

- changed (2021-04-30):
[0000833444-21-000020:note_history:19]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.
  (was, 2021-01-29, similarity 0.8699):
[0000833444-21-000011:note_history:19]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with

- removed (2021-04-30):
[0000833444-21-000011:note_history:20]
2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation.

- removed (2021-04-30):
[0000833444-21-000011:note_history:21]
abandonment of existing owned facilities. At December 31, 2020 and September 30, 2020, the Company recorded conditional asset retirement obligations for continuing operations of $30 million and $29 million, respectively.

- removed (2021-04-30):
[0000833444-21-000011:note_history:22]
related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

- removed (2021-04-30):
[0000833444-21-000011:note_history:23]
There are approximately 876 individual or “mass” actions pending that were filed in state or federal court in California (5 cases), Colorado (41 cases), New York (4 cases), Pennsylvania (15 cases), New Mexico (2 cases), Missouri (1 case), Arizona (1 case) and South Carolina (807 cases direct filed from various U.S. jurisdictions) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve five plaintiffs in California, approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania, two plaintiffs in New Mexico, one plaintiff in Missouri, two plaintiffs in Arizona, and more than 800 plaintiffs from various states who direct-filed complaints in South Carolina. All but six of these matters have been transferred to or directly-filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL.  Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court.  The Company anticipates that the remainder of the possible individual product liability claims filed in Pennsylvania state court will either soon be filed in the MDL (and that all such claims in state court will be dismissed accordingly) or will be dismissed in Pennsylvania without a corresponding filing in South Carolina.

- removed (2021-04-30):
[0000833444-21-000011:note_history:24]
Chemguard and Tyco Fire Products are also defendants in 63 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, California, Colorado, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio, Pennsylvania, Washington, the District of Columbia and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but three of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property. Since the beginning of fiscal year 2021, the following municipal actions have been filed against the Company:

- removed (2021-04-30):
[0000833444-21-000011:note_history:25]
•Hicksville Water District v. 3M Company, et al., filed on October 16, 2020 in New York State Court; now pending in the Eastern District of New York (tagged for transfer to the MDL pending in the United States District Court, District of South Carolina).

- removed (2021-04-30):
[0000833444-21-000011:note_history:26]
•Pennsylvania-American Water Co. v. 3M Company, et al., complaint filed on October 21, 2020 in the Court of Common Pleas of Cumberland County, Pennsylvania.

- removed (2021-04-30):
[0000833444-21-000011:note_history:27]
•Santa Clarita Valley Water Agency v. 3M Company, et al., direct-filed on October 27, 2020 in the MDL pending in the United States District Court, District of South Carolina.

- removed (2021-04-30):
[0000833444-21-000011:note_history:28]
•Barnstable Fire District v. 3M Company, et al., direct-filed on December 3, 2020 in the MDL pending in the United States District Court, District of South Carolina.

- removed (2021-04-30):
[0000833444-21-000011:note_history:29]
•Miami-Dade County, Florida v. 3M Company, et al., direct-filed on December 3, 2020 in the MDL pending in the United States District Court, District of South Carolina.

- removed (2021-04-30):
[0000833444-21-000011:note_history:30]
•Town of Cairo v. 3M Company, et al., direct-filed on December 7, 2020 in the MDL pending in the United States District Court, District of South Carolina.

- removed (2021-04-30):
[0000833444-21-000011:note_history:31]
•Paducah Water of the City of Paducah, Kentucky v. 3M Company, et al., direct-filed on December 16, 2020 in the MDL pending in the United States District Court, District of South Carolina.

- removed (2021-04-30):
[0000833444-21-000011:note_history:32]
to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

- removed (2021-04-30):
[0000833444-21-000011:note_history:33]
In December 2020, the State of Mississippi filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Group, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

- removed (2021-04-30):
[0000833444-21-000011:note_history:34]
Other PFAS Related Matters

- removed (2021-04-30):
[0000833444-21-000011:note_history:35]
these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-04-30):
[0000833444-21-000020:note_history:36]
Financial Statements
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2020 filed with the SEC on November 16, 2020. The results of operations for the three and six month periods ended March 31, 2021 are not necessarily indicative of results for the Company’s 2021 fiscal year because of seasonal and other factors.
  (was, 2021-01-29, similarity 0.9663):
[0000833444-21-000011:note_history:36]
Financial Statements
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2020 filed with the SEC on November 16, 2020. The results of operations for the three month period ended December 31, 2020 are not necessarily indicative of results for the Company’s 2021 fiscal year because of seasonal and other factors.

- changed (2021-04-30):
[0000833444-21-000020:note_history:37]
At March 31, 2021 and September 30, 2020, the Company held restricted cash of approximately $11 million and $9 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.
  (was, 2021-01-29, similarity 0.9793):
[0000833444-21-000011:note_history:37]
At December 31, 2020 and September 30, 2020, the Company held restricted cash of approximately $5 million and $9 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-04-30):
[0000833444-21-000020:note_history:38]
Net financing charges consisted of the following (in millions):

- changed (2021-04-30):
[0000833444-21-000020:note_history:39]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Interest expense, net of capitalized interest costs | $ | 53 |  |  | $ | 62 |  |  | $ | 112 |  |  | $ | 124 |  |
| Banking fees and bond cost amortization | 4 |  |  | 5 |  |  | 12 |  |  | 10 |  |
| Interest income | (3) |  |  | (5) |  |  | (6) |  |  | (18) |  |
| Net foreign exchange results for financing activities | (10) |  |  | (3) |  |  | (15) |  |  | (5) |  |
| Net financing charges | $ | 44 |  |  | $ | 59 |  |  | $ | 103 |  |  | $ | 111 |  |
  (was, 2021-01-29, similarity 0.7995):
[0000833444-21-000011:note_history:39]
|  | Three Months Ended December 31, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 59 |  |  | $ | 62 |  |  |  |  |  |
| Banking fees and bond cost amortization | 8 |  |  | 5 |  |  |  |  |  |
| Interest income | (3) |  |  | (13) |  |  |  |  |  |
| Net foreign exchange results for financing activities | (5) |  |  | (2) |  |  |  |  |  |
| Net financing charges | $ | 59 |  |  | $ | 52 |  |  |  |  |  |

- added (2021-04-30):
[0000833444-21-000020:note_history:40]
In March 2021, the Company entered into a bank term loan arrangement totaling $235 million due in March 2022 and retired $257 million in principal amount, plus accrued interest, of its 4.25% fixed rate notes that expired in March 2021.

- changed (2021-04-30):
[0000833444-21-000020:note_history:41]
As of March 31, 2021, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which was renewed in December 2020 and is now scheduled to expire in December 2021. As of March 31, 2021, there were no draws on the facilities.
  (was, 2021-01-29, similarity 0.9612):
[0000833444-21-000011:note_history:41]
As of December 31, 2020, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which was renewed in December 2020 and is now scheduled to expire in December 2021. As of December 31, 2020, there were no draws on the facilities.

- removed (2021-04-30):
[0000833444-21-000011:note_history:42]
The Company's net financing charges line item in the consolidated statements of income for the three months ended December 31, 2020 and 2019 contained the following components (in millions):


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-04-30):
[0000833444-21-000020:note_history:43]
The following table presents net sales to and purchases from related parties for the three and six months ended March 31, 2021 and 2020 (in millions):
  (was, 2021-01-29, similarity 0.9391):
[0000833444-21-000011:note_history:43]
The following table presents net sales to and purchases from related parties for the three months ended December 31, 2020 and 2019 (in millions):

- changed (2021-04-30):
[0000833444-21-000020:note_history:44]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales to related parties |  | $ | 53 |  |  | $ | 38 |  |  | $ | 97 |  |  | $ | 83 |  |
| Purchases from related parties |  | 37 |  |  | 10 |  |  | 66 |  |  | 22 |  |
  (was, 2021-01-29, similarity 0.775):
[0000833444-21-000011:note_history:44]
|  |  | Three Months Ended December 31, |
|  |  | 2020 |  | 2019 |
| Net sales to related parties |  | $ | 44 |  |  | $ | 42 |  |
| Purchases from related parties |  | 29 |  |  | 12 |  |

- changed (2021-04-30):
[0000833444-21-000020:note_history:45]
|  |  | March 31, 2021 |  | September 30, 2020 |
| Receivable from related parties |  | $ | 62 |  |  | $ | 48 |  |
| Payable to related parties |  | 19 |  |  | 11 |  |
  (was, 2021-01-29, similarity 0.9686):
[0000833444-21-000011:note_history:45]
|  |  | December 31, 2020 |  | September 30, 2020 |
| Receivable from related parties |  | $ | 51 |  |  | $ | 48 |  |
| Payable to related parties |  | 14 |  |  | 11 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-04-30):
[0000833444-21-000020:note_history:46]
The following table presents net sales to and purchases from related parties for the three and six months ended March 31, 2021 and 2020 (in millions):
  (was, 2021-01-29, similarity 0.9391):
[0000833444-21-000011:note_history:46]
The following table presents net sales to and purchases from related parties for the three months ended December 31, 2020 and 2019 (in millions):

- changed (2021-04-30):
[0000833444-21-000020:note_history:47]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales to related parties |  | $ | 53 |  |  | $ | 38 |  |  | $ | 97 |  |  | $ | 83 |  |
| Purchases from related parties |  | 37 |  |  | 10 |  |  | 66 |  |  | 22 |  |
  (was, 2021-01-29, similarity 0.775):
[0000833444-21-000011:note_history:47]
|  |  | Three Months Ended December 31, |
|  |  | 2020 |  | 2019 |
| Net sales to related parties |  | $ | 44 |  |  | $ | 42 |  |
| Purchases from related parties |  | 29 |  |  | 12 |  |

- changed (2021-04-30):
[0000833444-21-000020:note_history:48]
|  |  | March 31, 2021 |  | September 30, 2020 |
| Receivable from related parties |  | $ | 62 |  |  | $ | 48 |  |
| Payable to related parties |  | 19 |  |  | 11 |  |
  (was, 2021-01-29, similarity 0.9686):
[0000833444-21-000011:note_history:48]
|  |  | December 31, 2020 |  | September 30, 2020 |
| Receivable from related parties |  | $ | 51 |  |  | $ | 48 |  |
| Payable to related parties |  | 14 |  |  | 11 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-04-30):
[0000833444-21-000020:note_history:49]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and six months ended March 31, 2021 and 2020 (in millions):
  (was, 2021-01-29, similarity 0.9556):
[0000833444-21-000011:note_history:49]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three months ended December 31, 2020 and 2019 (in millions):

- added (2021-04-30):
[0000833444-21-000020:note_history:50]
|  |  | Three Months Ended March 31, 2021 |  | Three Months Ended March 31, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,272 |  |  | $ | 820 |  |  | $ | 2,092 |  |  | $ | 1,357 |  |  | $ | 818 |  |  | $ | 2,175 |  |
| Building Solutions EMEA/LA |  | 429 |  |  | 468 |  |  | 897 |  |  | 400 |  |  | 450 |  |  | 850 |  |
| Building Solutions Asia Pacific |  | 329 |  |  | 274 |  |  | 603 |  |  | 271 |  |  | 254 |  |  | 525 |  |
| Global Products |  | 2,002 |  |  | — |  |  | 2,002 |  |  | 1,894 |  |  | — |  |  | 1,894 |  |
| Total |  | $ | 4,032 |  |  | $ | 1,562 |  |  | $ | 5,594 |  |  | $ | 3,922 |  |  | $ | 1,522 |  |  | $ | 5,444 |  |

- changed (2021-04-30):
[0000833444-21-000020:note_history:51]
|  |  | Six Months Ended March 31, 2021 |  | Six Months Ended March 31, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 2,514 |  |  | $ | 1,612 |  |  | $ | 4,126 |  |  | $ | 2,713 |  |  | $ | 1,629 |  |  | $ | 4,342 |  |
| Building Solutions EMEA/LA |  | 855 |  |  | 948 |  |  | 1,803 |  |  | 857 |  |  | 921 |  |  | 1,778 |  |
| Building Solutions Asia Pacific |  | 674 |  |  | 544 |  |  | 1,218 |  |  | 642 |  |  | 512 |  |  | 1,154 |  |
| Global Products |  | 3,788 |  |  | — |  |  | 3,788 |  |  | 3,746 |  |  | — |  |  | 3,746 |  |
| Total |  | $ | 7,831 |  |  | $ | 3,104 |  |  | $ | 10,935 |  |  | $ | 7,958 |  |  | $ | 3,062 |  |  | $ | 11,020 |  |
  (was, 2021-01-29, similarity 0.9116):
[0000833444-21-000011:note_history:51]
|  |  | Three Months Ended December 31, 2020 |  | Three Months Ended December 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,242 |  |  | $ | 792 |  |  | $ | 2,034 |  |  | $ | 1,356 |  |  | $ | 811 |  |  | $ | 2,167 |  |
| Building Solutions EMEA/LA |  | 426 |  |  | 480 |  |  | 906 |  |  | 457 |  |  | 471 |  |  | 928 |  |
| Building Solutions Asia Pacific |  | 345 |  |  | 270 |  |  | 615 |  |  | 371 |  |  | 258 |  |  | 629 |  |
| Global Products |  | 1,786 |  |  | — |  |  | 1,786 |  |  | 1,852 |  |  | — |  |  | 1,852 |  |
| Total |  | $ | 3,799 |  |  | $ | 1,542 |  |  | $ | 5,341 |  |  | $ | 4,036 |  |  | $ | 1,540 |  |  | $ | 5,576 |  |

- changed (2021-04-30):
[0000833444-21-000020:note_history:52]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and six months ended March 31, 2021 and 2020 (in millions):
  (was, 2021-01-29, similarity 0.9489):
[0000833444-21-000011:note_history:52]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2020 and 2019 (in millions):

- changed (2021-04-30):
[0000833444-21-000020:note_history:53]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 1,402 |  |  | $ | 1,324 |  |  | $ | 2,651 |  |  | $ | 2,624 |  |
| Fire & Security |  | 537 |  |  | 511 |  |  | 1,025 |  |  | 1,003 |  |
| Industrial Refrigeration |  | 63 |  |  | 59 |  |  | 112 |  |  | 119 |  |
| Total |  | $ | 2,002 |  |  | $ | 1,894 |  |  | $ | 3,788 |  |  | $ | 3,746 |  |
  (was, 2021-01-29, similarity 0.7092):
[0000833444-21-000011:note_history:53]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2020 |  | 2019 |  |  |  |  |
| HVAC |  | $ | 1,249 |  |  | $ | 1,300 |  |  |  |  |  |
| Fire & Security |  | 488 |  |  | 492 |  |  |  |  |  |
| Industrial Refrigeration |  | 49 |  |  | 60 |  |  |  |  |  |
| Total |  | $ | 1,786 |  |  | $ | 1,852 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-04-30):
[0000833444-21-000020:note_history:54]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and six months ended March 31, 2021 and 2020 (in millions):
  (was, 2021-01-29, similarity 0.9556):
[0000833444-21-000011:note_history:54]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three months ended December 31, 2020 and 2019 (in millions):

- added (2021-04-30):
[0000833444-21-000020:note_history:55]
|  |  | Three Months Ended March 31, 2021 |  | Three Months Ended March 31, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,272 |  |  | $ | 820 |  |  | $ | 2,092 |  |  | $ | 1,357 |  |  | $ | 818 |  |  | $ | 2,175 |  |
| Building Solutions EMEA/LA |  | 429 |  |  | 468 |  |  | 897 |  |  | 400 |  |  | 450 |  |  | 850 |  |
| Building Solutions Asia Pacific |  | 329 |  |  | 274 |  |  | 603 |  |  | 271 |  |  | 254 |  |  | 525 |  |
| Global Products |  | 2,002 |  |  | — |  |  | 2,002 |  |  | 1,894 |  |  | — |  |  | 1,894 |  |
| Total |  | $ | 4,032 |  |  | $ | 1,562 |  |  | $ | 5,594 |  |  | $ | 3,922 |  |  | $ | 1,522 |  |  | $ | 5,444 |  |

- changed (2021-04-30):
[0000833444-21-000020:note_history:56]
|  |  | Six Months Ended March 31, 2021 |  | Six Months Ended March 31, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 2,514 |  |  | $ | 1,612 |  |  | $ | 4,126 |  |  | $ | 2,713 |  |  | $ | 1,629 |  |  | $ | 4,342 |  |
| Building Solutions EMEA/LA |  | 855 |  |  | 948 |  |  | 1,803 |  |  | 857 |  |  | 921 |  |  | 1,778 |  |
| Building Solutions Asia Pacific |  | 674 |  |  | 544 |  |  | 1,218 |  |  | 642 |  |  | 512 |  |  | 1,154 |  |
| Global Products |  | 3,788 |  |  | — |  |  | 3,788 |  |  | 3,746 |  |  | — |  |  | 3,746 |  |
| Total |  | $ | 7,831 |  |  | $ | 3,104 |  |  | $ | 10,935 |  |  | $ | 7,958 |  |  | $ | 3,062 |  |  | $ | 11,020 |  |
  (was, 2021-01-29, similarity 0.9116):
[0000833444-21-000011:note_history:56]
|  |  | Three Months Ended December 31, 2020 |  | Three Months Ended December 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,242 |  |  | $ | 792 |  |  | $ | 2,034 |  |  | $ | 1,356 |  |  | $ | 811 |  |  | $ | 2,167 |  |
| Building Solutions EMEA/LA |  | 426 |  |  | 480 |  |  | 906 |  |  | 457 |  |  | 471 |  |  | 928 |  |
| Building Solutions Asia Pacific |  | 345 |  |  | 270 |  |  | 615 |  |  | 371 |  |  | 258 |  |  | 629 |  |
| Global Products |  | 1,786 |  |  | — |  |  | 1,786 |  |  | 1,852 |  |  | — |  |  | 1,852 |  |
| Total |  | $ | 3,799 |  |  | $ | 1,542 |  |  | $ | 5,341 |  |  | $ | 4,036 |  |  | $ | 1,540 |  |  | $ | 5,576 |  |

- changed (2021-04-30):
[0000833444-21-000020:note_history:57]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and six months ended March 31, 2021 and 2020 (in millions):
  (was, 2021-01-29, similarity 0.9489):
[0000833444-21-000011:note_history:57]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2020 and 2019 (in millions):

- changed (2021-04-30):
[0000833444-21-000020:note_history:58]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 1,402 |  |  | $ | 1,324 |  |  | $ | 2,651 |  |  | $ | 2,624 |  |
| Fire & Security |  | 537 |  |  | 511 |  |  | 1,025 |  |  | 1,003 |  |
| Industrial Refrigeration |  | 63 |  |  | 59 |  |  | 112 |  |  | 119 |  |
| Total |  | $ | 2,002 |  |  | $ | 1,894 |  |  | $ | 3,788 |  |  | $ | 3,746 |  |
  (was, 2021-01-29, similarity 0.7092):
[0000833444-21-000011:note_history:58]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2020 |  | 2019 |  |  |  |  |
| HVAC |  | $ | 1,249 |  |  | $ | 1,300 |  |  |  |  |  |
| Fire & Security |  | 488 |  |  | 492 |  |  |  |  |  |
| Industrial Refrigeration |  | 49 |  |  | 60 |  |  |  |  |  |
| Total |  | $ | 1,786 |  |  | $ | 1,852 |  |  |  |  |  |

- added (2021-04-30):
[0000833444-21-000020:note_history:59]
|  |  | Location of contract balances |  | March 31, 2021 |  | September 30, 2020 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,387 |  |  | $ | 1,395 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 102 |  |  | 104 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,710) |  |  | (1,435) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (258) |  |  | (245) |  |  |  |
| Total |  |  |  | $ | (479) |  |  | $ | (181) |  |  |  |

- added (2021-04-30):
[0000833444-21-000020:note_history:60]
For the three months ended March 31, 2021 and March 31, 2020, the Company recognized revenue of $221 million and $326 million, respectively, that was included in the beginning of period contract liability balance. For the six months ended March 31, 2021 and March 31, 2020, the Company recognized revenue of $935 million and $1,012 million, respectively, that was included in the beginning of period contract liability balance.

- changed (2021-04-30):
[0000833444-21-000020:note_history:61]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of March 31, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $15.0 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.
  (was, 2021-01-29, similarity 0.9934):
[0000833444-21-000011:note_history:61]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of December 31, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.9 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

- changed (2021-04-30):
[0000833444-21-000020:note_history:62]
As of March 31, 2021, the Company recorded the costs to obtain or fulfill a contract of $241 million, of which $130 million is recorded within other current assets and $111 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2020, the Company recorded the costs to obtain or fulfill a contract of $223 million, of which $119 million is recorded within other current assets and $104 million is recorded within other noncurrent assets in the consolidated statements of financial position.
  (was, 2021-01-29, similarity 0.7864):
[0000833444-21-000011:note_history:62]
As of December 31, 2020, the Company recorded the costs to obtain or fulfill a contract of $236 million, of which $135 million is recorded within other current assets and $101 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2020, the Company recorded the costs to obtain or fulfill a contract of $223 million, of which $119 million is recorded within other current assets and $104 million is recorded within other noncurrent assets in the consolidated statements of financial position.
During the three months ended December 31, 2020 and 2019, the Company recognized amortization expense of $41 million and $26 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three months ended December 31, 2020 and 2019.

- added (2021-04-30):
[0000833444-21-000020:note_history:63]
During the three months ended March 31, 2021 and 2020, the Company recognized amortization expense of $47 million and $43 million, respectively, related to costs to obtain or fulfill a contract. During the six months ended March 31, 2021 and 2020, the Company recognized amortization expense of $88 million and $69 million, respectively, related to costs to 
obtain or fulfill a contract. There were no impairment losses recognized in the three and six months ended March 31, 2021 and 2020.

- removed (2021-04-30):
[0000833444-21-000011:note_history:64]
|  |  | Location of contract balances |  | December 31, 2020 |  | September 30, 2020 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,404 |  |  | $ | 1,395 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 104 |  |  | 104 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,583) |  |  | (1,435) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (257) |  |  | (245) |  |  |  |
| Total |  |  |  | $ | (332) |  |  | $ | (181) |  |  |  |

- removed (2021-04-30):
[0000833444-21-000011:note_history:65]
For the three months ended December 31, 2020 and December 31, 2019, the Company recognized revenue of $714 million and $686 million, respectively, that was included in the beginning of period contract liability balance.
