# JCI note change history — 0000833444-23-000014 → 0000833444-23-000030


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000833444-23-000030:note_history:1]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 38 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 214 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 252 |  |  | $ | 286 |  |
  (was, 2023-05-05, similarity 0.9778):
[0000833444-23-000014:note_history:1]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 42 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 223 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 265 |  |  | $ | 286 |  |

- changed (2023-08-02):
[0000833444-23-000030:note_history:2]
A substantial portion of the increase to the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to fire-fighting foams containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The increase in reserves was recorded as a result of several events that occurred in the three months ended September 30, 2022, including the completion and testing of the Groundwater Extraction and Treatment System (“GETS”) at the FTC (as further discussed below), the completion of resident surveys in Peshtigo regarding long-term drinking water solutions, correspondence with regulators on planned remediation activities, finalization of cost estimates for system upgrades and related long-term run rate costs in response to new permit requirements at the Stanton Street Facility, and the development of additional information through ongoing investigation and analysis. These events allowed the Company to develop estimates of costs associated with the long-term remediation actions expected to be performed over an estimated period of up to 20 years, including the continued operation of the GETS, the implementation of long-term drinking water solutions, continued monitoring and testing of the wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.
  (was, 2023-05-05, similarity 0.8188):
[0000833444-23-000014:note_history:2]
A substantial portion of the increase to the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to fire-fighting foams containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The increase in reserves was recorded as a result of several events that occurred in the three months ended September 30, 2022, including the completion and testing of the Groundwater Extraction and Treatment System (“GETS”) at the FTC (as further discussed below), the completion of resident surveys in Peshtigo regarding long-term drinking water solutions, correspondence with regulators on planned remediation activities, finalization of cost estimates for system upgrades and related long-term run rate costs in response to new permit requirements at the Stanton

- changed (2023-08-02):
[0000833444-23-000030:note_history:3]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports, or elsewhere. In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, the WDNR approved Tyco Fire Products’ proposed GETS, a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has completed construction of the GETS, which is now in operation. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. Tyco Fire Products is also in the process of implementing a long-term drinking water solution in the form of deep aquifer private drinking wells for certain Peshtigo residents. On July 18, 2023, Tyco Fire Products announced that it plans to
  (was, 2023-05-05, similarity 0.8402):
[0000833444-23-000014:note_history:3]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports, or elsewhere. In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, the WDNR approved Tyco Fire Products’ proposed GETS, a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has completed construction of the GETS, which is now in operation. Tyco Fire Products is also in the process of completing the removal and disposal of PFAS-affected soil from the FTC. In December 2022, Tyco Fire Products also began implementation of a long-term drinking water solution for some Peshtigo residents with the installation of the first deep aquifer private drinking wells.

- added (2023-08-02):
[0000833444-23-000030:note_history:4]
discontinue the production and sale of fluorinated firefighting foams by June 2024, including AFFF products, and will transition to non-fluorinated foam alternatives.

- changed (2023-08-02):
[0000833444-23-000030:note_history:5]
PFOA, PFOS, and other PFAS compounds are being studied by EPA and other environmental and health agencies and researchers. EPA initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water and in June 2022 an updated set of interim health advisory levels for PFOA and PFOS in drinking water, as well as final health advisory levels for two other types of PFAS (PFBS and GenX chemicals). In November 2022, EPA added a class definition of PFAS to the final version of EPA's fifth Contaminant Candidate List ("CCL 5"), which is a list of substances not currently subject to national drinking water regulation, but which EPA believes may require future regulation. In March 2023, EPA announced a proposed National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR proposes establishing legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion for each of PFOA and PFOS. EPA indicated that it anticipates finalizing the regulation by the end of 2023.
  (was, 2023-05-05, similarity 0.9992):
[0000833444-23-000014:note_history:5]
PFOA, PFOS, and other PFAS compounds are being studied by EPA and other environmental and health agencies and researchers. EPA initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water and in June 2022 an updated set of interim health advisory levels for PFOA and PFOS in drinking water, as well as final health advisory levels for two other types of PFAS (PFBS and GenX chemicals). In November 2022, EPA added a class definition of PFAS to the final version of EPA's fifth Contaminant Candidate List (CCL 5), which is a list of substances not currently subject to national drinking water regulation, but which EPA believes may require future regulation. In March 2023, EPA announced a proposed National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR proposes establishing legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion for each of PFOA and PFOS. EPA indicated that it anticipates finalizing the regulation by the end of 2023.

- changed (2023-08-02):
[0000833444-23-000030:note_history:6]
In October 2021, EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act (“CERCLA”) hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains. In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under CERCLA. In April 2023, EPA issued an Advanced Notice of Proposed Rulemaking ("ANPR") seeking input on whether it should expand the proposed rule to designate as "hazardous substances" under CERCLA: (1) seven additional PFAS; (2) the precursors to PFOA, PFOS, and the seven additional PFAS; or (3) entire categories of PFAS.
  (was, 2023-05-05, similarity 0.8903):
[0000833444-23-000014:note_history:6]
In October 2021, EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act (“CERCLA”) hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains. In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under CERCLA.

- changed (2023-08-02):
[0000833444-23-000030:note_history:7]
It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial
  (was, 2023-05-05, similarity 0.9046):
[0000833444-23-000014:note_history:7]
It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- added (2023-08-02):
[0000833444-23-000030:note_history:8]
condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- changed (2023-08-02):
[0000833444-23-000030:note_history:9]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $13 million and $17 million at June 30, 2023 and September 30, 2022, respectively.
  (was, 2023-05-05, similarity 0.9253):
[0000833444-23-000014:note_history:9]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $17 million at both March 31, 2023 and September 30, 2022.

- added (2023-08-02):
[0000833444-23-000030:note_history:10]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. In December 2022, the Governor of Wisconsin and WDNR approved a scope statement setting out parameters for the WDNR to draft a final rule regarding groundwater quality standards for PFOA and PFOS. The WDNR is now in the process of drafting the rule.

- changed (2023-08-02):
[0000833444-23-000030:note_history:11]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR’s requests. The parties are proceeding with fact discovery and the court has set a trial date of December 3, 2024. The Company is vigorously defending this civil enforcement action and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.
  (was, 2023-05-05, similarity 0.8719):
[0000833444-23-000014:note_history:11]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR’s requests. The parties are proceeding with fact discovery and the court has

- changed (2023-08-02):
[0000833444-23-000030:note_history:12]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. Subsequently, several additional plaintiffs have direct-filed in the MDL complaints with similar allegations. These lawsuits are presently at the beginning stages of litigation. The Company is vigorously defending these cases and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.
  (was, 2023-05-05, similarity 0.6825):
[0000833444-23-000014:note_history:12]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. These lawsuits are presently at the beginning stages of litigation. The Company is vigorously defending these cases and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

- changed (2023-08-02):
[0000833444-23-000030:note_history:13]
Chemguard and Tyco Fire Products are named in 41 pending putative class actions in federal courts originating from 16 states and territories. All but one of these cases have been direct-filed in or transferred to the MDL and it is anticipated that the remaining case will be transferred to the MDL.
  (was, 2023-05-05, similarity 0.9882):
[0000833444-23-000014:note_history:13]
Chemguard and Tyco Fire Products are named in 39 pending putative class actions in federal courts originating from 15 states and territories. All but two of these cases have been direct-filed in or transferred to the MDL and it is anticipated that the remaining cases will be transferred to the MDL.

- changed (2023-08-02):
[0000833444-23-000030:note_history:14]
There are more than 4,700 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 4,700 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona and Illinois.
  (was, 2023-05-05, similarity 0.9238):
[0000833444-23-000014:note_history:14]
There are more than 3,900 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 3,900 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and

- added (2023-08-02):
[0000833444-23-000030:note_history:15]
Chemguard and Tyco Fire Products have been named as defendants in more than 600 cases involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 33 states. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the

- added (2023-08-02):
[0000833444-23-000030:note_history:16]
MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation. The MDL court set the first case for trial on June 5, 2023 (City of Stuart (Florida) v. 3M Co. et al.). On April 26, 2023, the parties entered a stipulation dismissing Chemguard with prejudice from the City of Stuart case, and on May 4, 2023 the parties entered into a stipulation dismissing Tyco with prejudice from the City of Stuart case. On June 5, 2023, the MDL court continued the trial date for the City of Stuart case, and the parties remaining in that case later reached settlement. The parties in the MDL are working to identify potential water provider and personal injury cases for additional bellwether phases.

- changed (2023-08-02):
[0000833444-23-000030:note_history:17]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al. No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.
  (was, 2023-05-05, similarity 0.9994):
[0000833444-23-000014:note_history:17]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

- changed (2023-08-02):
[0000833444-23-000030:note_history:18]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al. (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al. (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al. (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.
  (was, 2023-05-05, similarity 0.999):
[0000833444-23-000014:note_history:18]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

- added (2023-08-02):
[0000833444-23-000030:note_history:19]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

- changed (2023-08-02):
[0000833444-23-000030:note_history:20]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting
  (was, 2023-05-05, similarity 0.7349):
[0000833444-23-000014:note_history:20]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

- added (2023-08-02):
[0000833444-23-000030:note_history:21]
from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

- changed (2023-08-02):
[0000833444-23-000030:note_history:22]
In May 2022, the Attorney General of the Commonwealth of Massachusetts filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s natural resources, property, residents, and consumers allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.
  (was, 2023-05-05, similarity 0.6636):
[0000833444-23-000014:note_history:22]
In May 2022, the Attorney General of the Commonwealth of Massachusetts filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the

- changed (2023-08-02):
[0000833444-23-000030:note_history:23]
In March 2023, the Attorney General of the State of Maine filed a lawsuit in Maine state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of the State’s natural resources allegedly resulting from the manufacture, distribution, release, promotion, sale, and use of PFAS-containing AFFF within the state. This complaint has been removed to federal court and transferred to the MDL.
  (was, 2023-05-05, similarity 0.9332):
[0000833444-23-000014:note_history:23]
In March 2023, the Attorney General of the State of Maine filed a lawsuit in Maine state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of the State’s natural resources allegedly resulting from the manufacture, distribution, release, promotion, sale, and use of PFAS-containing AFFF within the state. It is anticipated that this complaint will be removed to federal court and transferred to the MDL.

- changed (2023-08-02):
[0000833444-23-000030:note_history:24]
In March 2023, the Attorney General of the State of Illinois filed a lawsuit in Illinois state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of the State’s environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within the State. This complaint has been removed to federal court, and the JPML is considering Illinois's opposition to transfer to the MDL.
  (was, 2023-05-05, similarity 0.8622):
[0000833444-23-000014:note_history:24]
In March 2023, the Attorney General of the State of Illinois filed a lawsuit in Illinois state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of the State’s environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within the State. It is anticipated that this complaint will be removed to federal court and transferred to the MDL.

- added (2023-08-02):
[0000833444-23-000030:note_history:25]
In May and June 2023, eleven other states and territories filed lawsuits, ten in their respective state courts, and one direct-filed in the MDL, against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of Arizona v. The 3M Company et al.; State of Arkansas v. The 3M Company et al.; Commonwealth of Kentucky v. The 3M Company et al.; State of Maryland v. The 3M Company et al.; State of New Mexico v. The 3M Company et al.; State of Oregon v. The 3M Company et al.; Commonwealth of Puerto Rico v. The 3M Company et al.; State of Rhode Island v. The 3M Company et al.; State of Tennessee v. The 3M Company et al.; State of Texas v. The 3M Company et al.; State of Washington v. The 3M Company et al.). It is anticipated the ten state court-filed complaints will be removed to federal court and transferred to the MDL.

- added (2023-08-02):
[0000833444-23-000030:note_history:26]
In July 2023, the Attorney General of the District of Columbia filed a lawsuit in superior court in the District, against a number of manufacturers, including affiliates of the Company, with respect to PFAS damage of the District’s natural resources and public health allegedly resulting from the manufacture, distribution, release, and use of PFAS-containing AFFF within and adjacent to it (District of Columbia v. The 3M Company et al.). It is anticipated that this complaint will be removed to federal court and transferred to the MDL.

- added (2023-08-02):
[0000833444-23-000030:note_history:27]
In July 2023, the Fond du Lac Band of Lake Superior Chippewa (a federally recognized tribe) direct-filed a lawsuit in the MDL against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota.

- added (2023-08-02):
[0000833444-23-000030:note_history:28]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity

- changed (2023-08-02):
[0000833444-23-000030:note_history:29]
available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters in the event the Company is required to pay claims. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.
  (was, 2023-05-05, similarity 0.7851):
[0000833444-23-000014:note_history:29]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

- added (2023-08-02):
[0000833444-23-000030:note_history:30]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 363 |  |  | 380 |  |
| Total asbestos-related liabilities | 421 |  |  | 438 |  |
| Other current assets | 34 |  |  | 37 |  |
| Other noncurrent assets | 283 |  |  | 263 |  |
| Total asbestos-related assets | 317 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 104 |  |  | $ | 138 |  |

- added (2023-08-02):
[0000833444-23-000030:note_history:31]
|  | June 30, 2023 |  | September 30, 2022 |
| Restricted |  |  |  |
| Cash | $ | 26 |  |  | $ | 6 |  |
| Investments | 240 |  |  | 239 |  |
| Total restricted assets | 266 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 51 |  |  | 55 |  |
| Total asbestos-related assets | $ | 317 |  |  | $ | 300 |  |

- changed (2023-08-02):
[0000833444-23-000030:note_history:32]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be paid by Company affiliates). Estimated asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be paid through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and
  (was, 2023-05-05, similarity 0.7985):
[0000833444-23-000014:note_history:32]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be paid by Company affiliates). Estimated asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be paid through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

- added (2023-08-02):
[0000833444-23-000030:note_history:33]
dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

- added (2023-08-02):
[0000833444-23-000030:note_history:34]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

- changed (2023-08-02):
[0000833444-23-000030:note_history:35]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 77 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 232 |  |  | 230 |  |
| Total self-insured liabilities | $ | 331 |  |  | $ | 341 |  |
  (was, 2023-05-05, similarity 0.9813):
[0000833444-23-000014:note_history:35]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 92 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 233 |  |  | 230 |  |
| Total self-insured liabilities | $ | 347 |  |  | $ | 341 |  |

- changed (2023-08-02):
[0000833444-23-000030:note_history:36]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current assets | $ | 10 |  |  | $ | 10 |  |
| Other noncurrent assets | 20 |  |  | 20 |  |
| Total insurance receivables | $ | 30 |  |  | $ | 30 |  |
  (was, 2023-05-05, similarity 0.9744):
[0000833444-23-000014:note_history:36]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current assets | $ | 10 |  |  | $ | 10 |  |
| Other noncurrent assets | 20 |  |  | 20 |  |
| Total insurance receivables | $ | 30 |  |  | $ | 30 |  |

- removed (2023-08-02):
[0000833444-23-000014:note_history:37]
Street Facility, and the development of additional information through ongoing investigation and analysis. These events allowed the Company to develop estimates of costs associated with the long-term remediation actions expected to be performed over an estimated period of up to 20 years, including the continued operation of the GETS, the implementation of long-term drinking water solutions, continued monitoring and testing of the wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

- removed (2023-08-02):
[0000833444-23-000014:note_history:38]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. In September 2022, the Governor of Wisconsin signed a scope statement setting out parameters for the WDNR to draft a final rule regarding groundwater quality standards for PFOA and PFOS, among other compounds. The WDNR is now in the process of drafting the rule.

- removed (2023-08-02):
[0000833444-23-000014:note_history:39]
set a trial date of December 3, 2024. The Company is vigorously defending this civil enforcement action and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

- removed (2023-08-02):
[0000833444-23-000014:note_history:40]
transferred. There are several matters that are proceeding in state courts, including actions in Arizona and Illinois.

- removed (2023-08-02):
[0000833444-23-000014:note_history:41]
Chemguard and Tyco Fire Products have been named as defendants in more than 350 cases involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 30 states. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation. The MDL court has set the first case for trial on June 5, 2023, (City of Stuart (Florida) v. 3M Co. et al.). On April 26, 2023, the parties entered a stipulation dismissing Chemguard with prejudice from the City of Stuart case, and it is expected that the parties will enter into a stipulation dismissing Tyco with prejudice from the City of Stuart case. The MDL Court has ordered the parties to conduct mediation of the water provider cases pending in the MDL.

- removed (2023-08-02):
[0000833444-23-000014:note_history:42]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting

- removed (2023-08-02):
[0000833444-23-000014:note_history:43]
from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

- removed (2023-08-02):
[0000833444-23-000014:note_history:44]
State’s natural resources, property, residents, and consumers allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

- removed (2023-08-02):
[0000833444-23-000014:note_history:45]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 370 |  |  | 380 |  |
| Total asbestos-related liabilities | 428 |  |  | 438 |  |
| Other current assets | 37 |  |  | 37 |  |
| Other noncurrent assets | 275 |  |  | 263 |  |
| Total asbestos-related assets | 312 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 116 |  |  | $ | 138 |  |

- removed (2023-08-02):
[0000833444-23-000014:note_history:46]
|  | March 31, 2023 |  | September 30, 2022 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 253 |  |  | 239 |  |
| Total restricted assets | 259 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 53 |  |  | 55 |  |
| Total asbestos-related assets | $ | 312 |  |  | $ | 300 |  |

- removed (2023-08-02):
[0000833444-23-000014:note_history:47]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and

- removed (2023-08-02):
[0000833444-23-000014:note_history:48]
assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000833444-23-000030:note_history:49]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 38 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 214 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 252 |  |  | $ | 286 |  |
  (was, 2023-05-05, similarity 0.9778):
[0000833444-23-000014:note_history:49]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 42 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 223 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 265 |  |  | $ | 286 |  |

- added (2023-08-02):
[0000833444-23-000030:note_history:50]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 363 |  |  | 380 |  |
| Total asbestos-related liabilities | 421 |  |  | 438 |  |
| Other current assets | 34 |  |  | 37 |  |
| Other noncurrent assets | 283 |  |  | 263 |  |
| Total asbestos-related assets | 317 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 104 |  |  | $ | 138 |  |

- added (2023-08-02):
[0000833444-23-000030:note_history:51]
|  | June 30, 2023 |  | September 30, 2022 |
| Restricted |  |  |  |
| Cash | $ | 26 |  |  | $ | 6 |  |
| Investments | 240 |  |  | 239 |  |
| Total restricted assets | 266 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 51 |  |  | 55 |  |
| Total asbestos-related assets | $ | 317 |  |  | $ | 300 |  |

- changed (2023-08-02):
[0000833444-23-000030:note_history:52]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 77 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 232 |  |  | 230 |  |
| Total self-insured liabilities | $ | 331 |  |  | $ | 341 |  |
  (was, 2023-05-05, similarity 0.9813):
[0000833444-23-000014:note_history:52]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 92 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 233 |  |  | 230 |  |
| Total self-insured liabilities | $ | 347 |  |  | $ | 341 |  |

- changed (2023-08-02):
[0000833444-23-000030:note_history:53]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current assets | $ | 10 |  |  | $ | 10 |  |
| Other noncurrent assets | 20 |  |  | 20 |  |
| Total insurance receivables | $ | 30 |  |  | $ | 30 |  |
  (was, 2023-05-05, similarity 0.9744):
[0000833444-23-000014:note_history:53]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current assets | $ | 10 |  |  | $ | 10 |  |
| Other noncurrent assets | 20 |  |  | 20 |  |
| Total insurance receivables | $ | 30 |  |  | $ | 30 |  |

- removed (2023-08-02):
[0000833444-23-000014:note_history:54]
|  | March 31, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 370 |  |  | 380 |  |
| Total asbestos-related liabilities | 428 |  |  | 438 |  |
| Other current assets | 37 |  |  | 37 |  |
| Other noncurrent assets | 275 |  |  | 263 |  |
| Total asbestos-related assets | 312 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 116 |  |  | $ | 138 |  |

- removed (2023-08-02):
[0000833444-23-000014:note_history:55]
|  | March 31, 2023 |  | September 30, 2022 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 253 |  |  | 239 |  |
| Total restricted assets | 259 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 53 |  |  | 55 |  |
| Total asbestos-related assets | $ | 312 |  |  | $ | 300 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000833444-23-000030:note_history:56]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2022 filed with the SEC on November 15, 2022. The results of operations for the three and nine month periods ended June 30, 2023 are not necessarily indicative of results for the Company’s 2023 fiscal year because of seasonal and other factors.
  (was, 2023-05-05, similarity 0.9791):
[0000833444-23-000014:note_history:56]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2022 filed with the SEC on November 15, 2022. The results of operations for the three and six month periods ended March 31, 2023 are not necessarily indicative of results for the Company’s 2023 fiscal year because of seasonal and other factors.

- added (2023-08-02):
[0000833444-23-000030:note_history:57]
Assets and liabilities of the Global Retail business which were classified as held for sale in prior periods have been reclassified to conform with the current period presentation. Refer to Note 4, "Assets and Liabilities Held for Sale," of the notes to the consolidated financial statements for further details.

- added (2023-08-02):
[0000833444-23-000030:note_history:58]
Restricted cash relates to amounts restricted for payment of asbestos liabilities and certain litigation and environmental matters. Restricted cash is recorded primarily within other current assets in the consolidated statements of financial position and totaled $86 million and $35 million at June 30, 2023 and September 30, 2022, respectively.

- changed (2023-08-02):
[0000833444-23-000030:note_history:59]
Prior Period Revision – Statement of Cash Flows
The Company revised the amounts previously reported as net proceeds from borrowings with maturities less than three months and proceeds from debt for certain short-term debt transactions that were incorrectly presented on a net basis within the financing activities section of the consolidated statements of cash flows for the nine months ended June 30, 2022. Interim and annual amounts for the year ended September 30, 2022 and annual amounts for the years ended September 30, 2021 and 2020 were similarly impacted. Prior period amounts will be revised with future Quarterly Reports on Form 10-Q and Annual Report on Form 10-K filings. Cash provided by financing activities and the total increase (decrease) in cash, cash equivalents and restricted cash were unchanged for all affected periods. The Company does not believe the impact of incorrect presentation is material to any periods.
  (was, 2023-05-05, similarity 0.8111):
[0000833444-23-000014:note_history:59]
Restricted cash relates to amounts restricted for payment of asbestos liabilities and certain litigation and environmental matters. Restricted cash is recorded primarily within other current assets in the consolidated statements of financial position and totaled $65 million and $35 million at March 31, 2023 and September 30, 2022, respectively. 
Prior Period Revision – Statement of Cash FlowsThe Company revised the amounts previously reported as net proceeds from borrowings with maturities less than three months and proceeds from debt for certain short-term debt transactions that were incorrectly presented on a net basis within the financing activities section of the consolidated statements of cash flows for the six months ended March 31, 2022. Interim and annual amounts for the year ended September 30, 2022 and annual amounts for the years ended September 30, 2021 and 2020 were similarly impacted. Prior period amounts will be revised with future Quarterly Reports on Form 10-Q and Annual Report on Form 10-K filings. Cash provided by financing activities and the total increase (decrease) in cash, cash equivalents and restricted cash were unchanged for all affected periods. The Company does not believe the impact of incorrect presentation is material to any periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-08-02):
[0000833444-23-000030:note_history:60]
|  | June 30, |  | September 30, |
|  | 2023 |  | 2022 |
| Bank borrowings | $ | 23 |  |  | $ | 10 |  |
| Commercial paper | — |  |  | 172 |  |
| Term loans | 163 |  |  | 487 |  |
|  | $ | 186 |  |  | $ | 669 |  |
| Weighted average interest rate on short-term debt outstanding | 3.8 | % |  | 0.5 | % |

- changed (2023-08-02):
[0000833444-23-000030:note_history:61]
As of June 30, 2023, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in November 2023. As of June 30, 2023, there were no draws on the facilities.
  (was, 2023-05-05, similarity 0.9697):
[0000833444-23-000014:note_history:61]
As of March 31, 2023, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in November 2023. As of March 31, 2023, there were no draws on the facilities.

- added (2023-08-02):
[0000833444-23-000030:note_history:62]
The Company entered into the following financing activities during the current fiscal year:

- added (2023-08-02):
[0000833444-23-000030:note_history:63]
•October 2022

- added (2023-08-02):
[0000833444-23-000030:note_history:64]
–Repaid a €200 million ($196 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5%

- added (2023-08-02):
[0000833444-23-000030:note_history:65]
–Issued a €150 million ($163 million as of March 31, 2023) term loan with an interest rate of EURIBOR plus 0.7% which is due in April 2024

- changed (2023-08-02):
[0000833444-23-000030:note_history:66]
•January 2023 - Repaid $32 million of outstanding 4.625% Notes due 2023
  (was, 2023-05-05, similarity 0.8788):
[0000833444-23-000014:note_history:66]
In January 2023, the Company repaid $32 million of outstanding 4.625% Notes due 2023.

- added (2023-08-02):
[0000833444-23-000030:note_history:67]
•March 2023

- added (2023-08-02):
[0000833444-23-000030:note_history:68]
–Repaid a €150 million ($147 million as of September 30, 2022) term loan with an interest rate of 0.0%

- added (2023-08-02):
[0000833444-23-000030:note_history:69]
–Repaid a €135 million ($133 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5%

- added (2023-08-02):
[0000833444-23-000030:note_history:70]
–Issued a €150 million ($163 million as of March 31, 2023) term loan with an interest rate of EURIBOR plus 0.4% which is due March 2024

- added (2023-08-02):
[0000833444-23-000030:note_history:71]
•May 2023 - Together with its wholly owned subsidiary, Tyco Fire & Security Finance S.C.A., co-issued an €800 million ($868 million as of June 30, 2023) bond with an interest rate of 4.25% which is due May 2035.

- changed (2023-08-02):
[0000833444-23-000030:note_history:72]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest expense, net of capitalized interest costs | $ | 79 |  |  | $ | 54 |  |  | $ | 219 |  |  | $ | 165 |  |
| Other financing charges | 13 |  |  | 6 |  |  | 34 |  |  | 16 |  |
| Interest income | (10) |  |  | (2) |  |  | (17) |  |  | (5) |  |
| Net foreign exchange results for financing activities | (2) |  |  | (9) |  |  | (18) |  |  | (23) |  |
| Net financing charges | $ | 80 |  |  | $ | 49 |  |  | $ | 218 |  |  | $ | 153 |  |
  (was, 2023-05-05, similarity 0.9566):
[0000833444-23-000014:note_history:72]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest expense, net of capitalized interest costs | $ | 71 |  |  | $ | 56 |  |  | $ | 140 |  |  | $ | 111 |  |
| Other financing charges | 11 |  |  | 5 |  |  | 21 |  |  | 10 |  |
| Interest income | (3) |  |  | (1) |  |  | (7) |  |  | (3) |  |
| Net foreign exchange results for financing activities | (8) |  |  | (9) |  |  | (16) |  |  | (14) |  |
| Net financing charges | $ | 71 |  |  | $ | 51 |  |  | $ | 138 |  |  | $ | 104 |  |

- removed (2023-08-02):
[0000833444-23-000014:note_history:73]
|  | March 31, |  | September 30, |
|  | 2023 |  | 2022 |
| Bank borrowings | $ | 20 |  |  | $ | 10 |  |
| Commercial paper | 1,554 |  |  | 172 |  |
| Term loans | 163 |  |  | 487 |  |
|  | $ | 1,737 |  |  | $ | 669 |  |
| Weighted average interest rate on short-term debt outstanding | 2.9 | % |  | 0.5 | % |

- removed (2023-08-02):
[0000833444-23-000014:note_history:74]
In October 2022, the Company repaid a €200 million ($196 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5% and entered into a €150 million ($163 million as of March 31, 2023) term loan with an interest rate of EURIBOR plus 0.7% which is due in April 2024.

- removed (2023-08-02):
[0000833444-23-000014:note_history:75]
In March 2023, the Company repaid a €150 million ($147 million as of September 30, 2022) term loan with an interest rate of 0.0%, repaid a €135 million ($133 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5% and entered into a €150 million ($163 million as of March 31, 2023) term loan with an interest rate of EURIBOR plus 0.4% which is due March 2024.


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-08-02):
[0000833444-23-000030:note_history:76]
|  | June 30, |  | September 30, |
|  | 2023 |  | 2022 |
| Bank borrowings | $ | 23 |  |  | $ | 10 |  |
| Commercial paper | — |  |  | 172 |  |
| Term loans | 163 |  |  | 487 |  |
|  | $ | 186 |  |  | $ | 669 |  |
| Weighted average interest rate on short-term debt outstanding | 3.8 | % |  | 0.5 | % |

- removed (2023-08-02):
[0000833444-23-000014:note_history:77]
|  | March 31, |  | September 30, |
|  | 2023 |  | 2022 |
| Bank borrowings | $ | 20 |  |  | $ | 10 |  |
| Commercial paper | 1,554 |  |  | 172 |  |
| Term loans | 163 |  |  | 487 |  |
|  | $ | 1,737 |  |  | $ | 669 |  |
| Weighted average interest rate on short-term debt outstanding | 2.9 | % |  | 0.5 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000833444-23-000030:note_history:78]
|  |  | Three Months Ended June 30, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,636 |  |  | $ | 1,029 |  |  | $ | 2,665 |  |  | $ | 1,481 |  |  | $ | 945 |  |  | $ | 2,426 |  |
| Building Solutions EMEA/LA |  | 571 |  |  | 474 |  |  | 1,045 |  |  | 537 |  |  | 415 |  |  | 952 |  |
| Building Solutions Asia Pacific |  | 537 |  |  | 199 |  |  | 736 |  |  | 493 |  |  | 172 |  |  | 665 |  |
| Global Products |  | 2,687 |  |  | — |  |  | 2,687 |  |  | 2,571 |  |  | — |  |  | 2,571 |  |
| Total |  | $ | 5,431 |  |  | $ | 1,702 |  |  | $ | 7,133 |  |  | $ | 5,082 |  |  | $ | 1,532 |  |  | $ | 6,614 |  |
  (was, 2023-05-05, similarity 0.9921):
[0000833444-23-000014:note_history:78]
|  |  | Three Months Ended March 31, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,554 |  |  | $ | 966 |  |  | $ | 2,520 |  |  | $ | 1,343 |  |  | $ | 884 |  |  | $ | 2,227 |  |
| Building Solutions EMEA/LA |  | 582 |  |  | 449 |  |  | 1,031 |  |  | 536 |  |  | 422 |  |  | 958 |  |
| Building Solutions Asia Pacific |  | 479 |  |  | 188 |  |  | 667 |  |  | 448 |  |  | 175 |  |  | 623 |  |
| Global Products |  | 2,468 |  |  | — |  |  | 2,468 |  |  | 2,290 |  |  | — |  |  | 2,290 |  |
| Total |  | $ | 5,083 |  |  | $ | 1,603 |  |  | $ | 6,686 |  |  | $ | 4,617 |  |  | $ | 1,481 |  |  | $ | 6,098 |  |

- changed (2023-08-02):
[0000833444-23-000030:note_history:79]
|  |  | Nine Months Ended June 30, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 4,641 |  |  | $ | 2,911 |  |  | $ | 7,552 |  |  | $ | 4,123 |  |  | $ | 2,682 |  |  | $ | 6,805 |  |
| Building Solutions EMEA/LA |  | 1,705 |  |  | 1,346 |  |  | 3,051 |  |  | 1,617 |  |  | 1,252 |  |  | 2,869 |  |
| Building Solutions Asia Pacific |  | 1,489 |  |  | 560 |  |  | 2,049 |  |  | 1,442 |  |  | 521 |  |  | 1,963 |  |
| Global Products |  | 7,235 |  |  | — |  |  | 7,235 |  |  | 6,937 |  |  | — |  |  | 6,937 |  |
| Total |  | $ | 15,070 |  |  | $ | 4,817 |  |  | $ | 19,887 |  |  | $ | 14,119 |  |  | $ | 4,455 |  |  | $ | 18,574 |  |
  (was, 2023-05-05, similarity 0.9859):
[0000833444-23-000014:note_history:79]
|  |  | Six Months Ended March 31, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,005 |  |  | $ | 1,882 |  |  | $ | 4,887 |  |  | $ | 2,642 |  |  | $ | 1,737 |  |  | $ | 4,379 |  |
| Building Solutions EMEA/LA |  | 1,134 |  |  | 872 |  |  | 2,006 |  |  | 1,080 |  |  | 837 |  |  | 1,917 |  |
| Building Solutions Asia Pacific |  | 952 |  |  | 361 |  |  | 1,313 |  |  | 949 |  |  | 349 |  |  | 1,298 |  |
| Global Products |  | 4,548 |  |  | — |  |  | 4,548 |  |  | 4,366 |  |  | — |  |  | 4,366 |  |
| Total |  | $ | 9,639 |  |  | $ | 3,115 |  |  | $ | 12,754 |  |  | $ | 9,037 |  |  | $ | 2,923 |  |  | $ | 11,960 |  |

- changed (2023-08-02):
[0000833444-23-000030:note_history:80]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 1,973 |  |  | $ | 1,889 |  |  | $ | 5,170 |  |  | $ | 5,030 |  |
| Fire & Security |  | 626 |  |  | 610 |  |  | 1,819 |  |  | 1,732 |  |
| Industrial Refrigeration |  | 88 |  |  | 72 |  |  | 246 |  |  | 175 |  |
| Total |  | $ | 2,687 |  |  | $ | 2,571 |  |  | $ | 7,235 |  |  | $ | 6,937 |  |
  (was, 2023-05-05, similarity 0.9388):
[0000833444-23-000014:note_history:80]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 1,757 |  |  | $ | 1,658 |  |  | $ | 3,197 |  |  | $ | 3,141 |  |
| Fire & Security |  | 623 |  |  | 578 |  |  | 1,193 |  |  | 1,122 |  |
| Industrial Refrigeration |  | 88 |  |  | 54 |  |  | 158 |  |  | 103 |  |
| Total |  | $ | 2,468 |  |  | $ | 2,290 |  |  | $ | 4,548 |  |  | $ | 4,366 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000833444-23-000030:note_history:81]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of June 30, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $19.2 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.
  (was, 2023-05-05, similarity 0.9955):
[0000833444-23-000014:note_history:81]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $18.8 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-02):
[0000833444-23-000030:note_history:82]
|  |  | Three Months Ended June 30, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,636 |  |  | $ | 1,029 |  |  | $ | 2,665 |  |  | $ | 1,481 |  |  | $ | 945 |  |  | $ | 2,426 |  |
| Building Solutions EMEA/LA |  | 571 |  |  | 474 |  |  | 1,045 |  |  | 537 |  |  | 415 |  |  | 952 |  |
| Building Solutions Asia Pacific |  | 537 |  |  | 199 |  |  | 736 |  |  | 493 |  |  | 172 |  |  | 665 |  |
| Global Products |  | 2,687 |  |  | — |  |  | 2,687 |  |  | 2,571 |  |  | — |  |  | 2,571 |  |
| Total |  | $ | 5,431 |  |  | $ | 1,702 |  |  | $ | 7,133 |  |  | $ | 5,082 |  |  | $ | 1,532 |  |  | $ | 6,614 |  |
  (was, 2023-05-05, similarity 0.9921):
[0000833444-23-000014:note_history:82]
|  |  | Three Months Ended March 31, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,554 |  |  | $ | 966 |  |  | $ | 2,520 |  |  | $ | 1,343 |  |  | $ | 884 |  |  | $ | 2,227 |  |
| Building Solutions EMEA/LA |  | 582 |  |  | 449 |  |  | 1,031 |  |  | 536 |  |  | 422 |  |  | 958 |  |
| Building Solutions Asia Pacific |  | 479 |  |  | 188 |  |  | 667 |  |  | 448 |  |  | 175 |  |  | 623 |  |
| Global Products |  | 2,468 |  |  | — |  |  | 2,468 |  |  | 2,290 |  |  | — |  |  | 2,290 |  |
| Total |  | $ | 5,083 |  |  | $ | 1,603 |  |  | $ | 6,686 |  |  | $ | 4,617 |  |  | $ | 1,481 |  |  | $ | 6,098 |  |

- changed (2023-08-02):
[0000833444-23-000030:note_history:83]
|  |  | Nine Months Ended June 30, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 4,641 |  |  | $ | 2,911 |  |  | $ | 7,552 |  |  | $ | 4,123 |  |  | $ | 2,682 |  |  | $ | 6,805 |  |
| Building Solutions EMEA/LA |  | 1,705 |  |  | 1,346 |  |  | 3,051 |  |  | 1,617 |  |  | 1,252 |  |  | 2,869 |  |
| Building Solutions Asia Pacific |  | 1,489 |  |  | 560 |  |  | 2,049 |  |  | 1,442 |  |  | 521 |  |  | 1,963 |  |
| Global Products |  | 7,235 |  |  | — |  |  | 7,235 |  |  | 6,937 |  |  | — |  |  | 6,937 |  |
| Total |  | $ | 15,070 |  |  | $ | 4,817 |  |  | $ | 19,887 |  |  | $ | 14,119 |  |  | $ | 4,455 |  |  | $ | 18,574 |  |
  (was, 2023-05-05, similarity 0.9859):
[0000833444-23-000014:note_history:83]
|  |  | Six Months Ended March 31, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,005 |  |  | $ | 1,882 |  |  | $ | 4,887 |  |  | $ | 2,642 |  |  | $ | 1,737 |  |  | $ | 4,379 |  |
| Building Solutions EMEA/LA |  | 1,134 |  |  | 872 |  |  | 2,006 |  |  | 1,080 |  |  | 837 |  |  | 1,917 |  |
| Building Solutions Asia Pacific |  | 952 |  |  | 361 |  |  | 1,313 |  |  | 949 |  |  | 349 |  |  | 1,298 |  |
| Global Products |  | 4,548 |  |  | — |  |  | 4,548 |  |  | 4,366 |  |  | — |  |  | 4,366 |  |
| Total |  | $ | 9,639 |  |  | $ | 3,115 |  |  | $ | 12,754 |  |  | $ | 9,037 |  |  | $ | 2,923 |  |  | $ | 11,960 |  |

- changed (2023-08-02):
[0000833444-23-000030:note_history:84]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 1,973 |  |  | $ | 1,889 |  |  | $ | 5,170 |  |  | $ | 5,030 |  |
| Fire & Security |  | 626 |  |  | 610 |  |  | 1,819 |  |  | 1,732 |  |
| Industrial Refrigeration |  | 88 |  |  | 72 |  |  | 246 |  |  | 175 |  |
| Total |  | $ | 2,687 |  |  | $ | 2,571 |  |  | $ | 7,235 |  |  | $ | 6,937 |  |
  (was, 2023-05-05, similarity 0.9388):
[0000833444-23-000014:note_history:84]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 1,757 |  |  | $ | 1,658 |  |  | $ | 3,197 |  |  | $ | 3,141 |  |
| Fire & Security |  | 623 |  |  | 578 |  |  | 1,193 |  |  | 1,122 |  |
| Industrial Refrigeration |  | 88 |  |  | 54 |  |  | 158 |  |  | 103 |  |
| Total |  | $ | 2,468 |  |  | $ | 2,290 |  |  | $ | 4,548 |  |  | $ | 4,366 |  |

- changed (2023-08-02):
[0000833444-23-000030:note_history:85]
|  |  | Location of contract balances |  | June 30, 2023 |  | September 30, 2022 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,080 |  |  | $ | 2,067 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 79 |  |  | 79 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 1,918 |  |  | 1,804 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 292 |  |  | 282 |  |  |  |
  (was, 2023-05-05, similarity 0.989):
[0000833444-23-000014:note_history:85]
|  |  | Location of contract balances |  | March 31, 2023 |  | September 30, 2022 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,026 |  |  | $ | 2,020 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 81 |  |  | 79 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 1,939 |  |  | 1,768 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 292 |  |  | 282 |  |  |  |

- added (2023-08-02):
[0000833444-23-000030:note_history:86]
For the three months ended June 30, 2023 and 2022, the Company recognized revenue of $222 million and $193 million, respectively, that was included in the beginning of period contract liability balance. For the nine months ended June 30, 2023 and 2022, the Company recognized revenue of $1,387 million and $1,252 million, respectively, that was included in the beginning of period contract liability balance

- changed (2023-08-02):
[0000833444-23-000030:note_history:87]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of June 30, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $19.2 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.
  (was, 2023-05-05, similarity 0.9955):
[0000833444-23-000014:note_history:87]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $18.8 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.

- changed (2023-08-02):
[0000833444-23-000030:note_history:88]
|  |  | June 30, 2023 |  | September 30, 2022 |  |  |
| Other current assets |  | $ | 159 |  |  | $ | 139 |  |  |  |
| Other noncurrent assets |  | 212 |  |  | 174 |  |  |  |
| Total |  | $ | 371 |  |  | $ | 313 |  |  |  |
  (was, 2023-05-05, similarity 0.9746):
[0000833444-23-000014:note_history:88]
|  |  | March 31, 2023 |  | September 30, 2022 |  |  |
| Other current assets |  | $ | 154 |  |  | $ | 139 |  |  |  |
| Other noncurrent assets |  | 200 |  |  | 174 |  |  |  |
| Total |  | $ | 354 |  |  | $ | 313 |  |  |  |

- changed (2023-08-02):
[0000833444-23-000030:note_history:89]
During the three months ended June 30, 2023 and 2022, the Company recognized amortization expense of $66 million and $48 million, respectively, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2023 and 2022, the Company recognized amortization expense of $188 million and $145 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and nine months ended June 30, 2023 and 2022.
  (was, 2023-05-05, similarity 0.8721):
[0000833444-23-000014:note_history:89]
During the three months ended March 31, 2023 and 2022, the Company recognized amortization expense of $61 million and $47 million, respectively, related to costs to obtain or fulfill a contract. During the six months ended March 31, 2023 and 2022, the Company recognized amortization expense of $122 million and $97 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and six months ended March 31, 2023 and 2022.

- removed (2023-08-02):
[0000833444-23-000014:note_history:90]
For the three months ended March 31, 2023 and 2022, the Company recognized revenue of $319 million and $308 million, respectively, that was included in the beginning of period contract liability balance. For the six months ended March 31, 2023 and 2022, the Company recognized revenue of $1,165 million and $1,059 million, respectively, that was included in the beginning of period contract liability balance
