# JCI MD&A — 0000833444-23-000030


## mdna

[0000833444-23-000030:mdna:1]
[same as prior period, unchanged from 0000833444-23-000014:mdna:1]

[0000833444-23-000030:mdna:2]
[same as prior period, unchanged from 0000833444-23-000014:mdna:2]

[0000833444-23-000030:mdna:3]
[same as prior period, unchanged from 0000833444-23-000014:mdna:3]

[0000833444-23-000030:mdna:4]
[same as prior period, unchanged from 0000833444-23-000014:mdna:4]

[0000833444-23-000030:mdna:5]
[same as prior period, unchanged from 0000833444-23-000014:mdna:5]

[0000833444-23-000030:mdna:6]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its OpenBlue software platform and capabilities. The Company

[0000833444-23-000030:mdna:7]
partners with customers by leveraging its broad product portfolio and digital capabilities powered by OpenBlue, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

[0000833444-23-000030:mdna:8]
The following information should be read in conjunction with the September 30, 2022 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2022 filed with the SEC on November 15, 2022. References in the following discussion and analysis to "Three Months" (or similar language) refer to the three months ended June 30, 2023 compared to the three months ended June 30, 2022, while "Year-to-Date" refers to the nine months ended June 30, 2023 compared to the nine months ended June 30, 2022.

[0000833444-23-000030:mdna:9]
[same as prior period, unchanged from 0000833444-23-000014:mdna:9]

[0000833444-23-000030:mdna:10]
[same as prior period, unchanged from 0000833444-23-000014:mdna:10]

[0000833444-23-000030:mdna:11]
As a result of the Company’s global presence, a significant portion of its revenues and expenses is denominated in currencies other than the U.S. dollar. The Company is therefore subject to non-U.S. currency risks and non-U.S. exchange exposure. While the Company employs financial instruments to hedge some of its transactional foreign exchange exposure, these activities do not insulate it completely from those exposures. In addition, the currency exposure from the translation of non-U.S. dollar functional currency subsidiaries are not able to be hedged. Exchange rates can be volatile and a substantial weakening or strengthening of foreign currencies against the U.S. dollar could increase or reduce the Company’s profit margin, respectively, and impact the comparability of results from period to period. During the three and nine months ended June 30, 2023, revenue and profits were adversely impacted due to the strengthening of the U.S. dollar against foreign currencies.

[0000833444-23-000030:mdna:12]
[same as prior period, unchanged from 0000833444-23-000014:mdna:12]

[0000833444-23-000030:mdna:13]
The Company has experienced, and could continue to experience, increased material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends, including increased global demand, geopolitical and economic tensions, including the conflict between Russia and Ukraine, and labor shortages. Actions taken by the Company to mitigate supply chain disruptions and inflation, including expanding and redistributing its supplier network, supplier financing, price increases and productivity improvements, have generally been successful in offsetting some, but not all, of the impact of these trends. The collective impact of these trends has been favorable to revenue due to increased demand and price increases to offset inflation, while negatively impacting margins due to supply chain disruptions and cost pressures. However, the Company continues to observe improved margins as supply chain disruptions ease and higher priced backlog is converted to sales. Although the Company has experienced recent improvement in its supply chain, the Company could experience further disruptions, shortages and cost increases in the future, the effect of which will depend on the Company’s ability to successfully mitigate and offset the impact of these events.

[0000833444-23-000030:mdna:14]
[same as prior period, unchanged from 0000833444-23-000014:mdna:26]

[0000833444-23-000030:mdna:15]
During the second quarter of fiscal 2022, the Company suspended its operations in Russia in response to the conflict between Russia and Ukraine, with existing contractual obligations being fulfilled in a manner that fully complies with all sanctions and trade controls. The Company has subsequently reduced its business presence and operations in Russia. Although these actions have not had and are not expected to have a material impact on the Company’s operating results, the broader consequences of the ongoing conflict, including heightened supply chain disruption, inflation, economic instability and other factors have and could continue to adversely impact the Company’s results of operations.

[0000833444-23-000030:mdna:16]
The extent to which the Company’s results of operations and financial condition are impacted by these and other factors in the future will depend on developments that are highly uncertain and cannot be predicted. See the section entitled "Risk Factors" in Johnson Controls' Annual Report on Form 10-K for the year ended September 30, 2022 filed with the United States Securities and Exchange Commission ("SEC") on November 15, 2022.

[0000833444-23-000030:mdna:17]
Restructuring Activities

[0000833444-23-000030:mdna:18]
To better align its resources with its growth strategies and reduce the cost structure of its global operations, the Company commits to restructuring plans as necessary. In the third quarter of fiscal 2023, the Company began developing a restructuring plan with certain actions focused on continued scaling of selling, general and administrative expenses ("SG&A") to its planned growth. Early actions of this plan were committed to during the third quarter and charges, primarily related to workforce reductions, were recorded to restructuring and impairment costs in the consolidated statements of income, and additional restructuring charges are expected in subsequent quarters. Anticipated savings from the restructuring plan are not yet estimable, as the scope of the plan is expected to be finalized during the fourth quarter of fiscal 2023.

[0000833444-23-000030:mdna:19]
[same as prior period, unchanged from 0000833444-23-000014:mdna:19]

[0000833444-23-000030:mdna:20]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Net sales | $ | 7,133 |  |  | $ | 6,614 |  |  | 8 | % |  | $ | 19,887 |  |  | $ | 18,574 |  |  | 7 | % |

[0000833444-23-000030:mdna:21]
The increase in consolidated net sales for the three months ended June 30, 2023 was due to higher organic sales ($595 million) and the net impact of acquisitions and divestitures ($24 million), partially offset by the unfavorable impact of foreign currency translation ($100 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 9% as compared to the prior year, primarily attributable to increased pricing in response to inflation pressures and higher volumes. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-23-000030:mdna:22]
The increase in consolidated net sales for the nine months ended June 30, 2023 was due to higher organic sales ($1,854 million) and the net impact of acquisitions and divestitures ($57 million), partially offset by the unfavorable impact of foreign currency translation ($598 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 10% as compared to the prior year, attributable to increased pricing in response to inflation pressures and higher volumes. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-23-000030:mdna:23]
[same as prior period, unchanged from 0000833444-23-000014:mdna:23]

[0000833444-23-000030:mdna:24]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Cost of sales | $ | 4,702 |  |  | $ | 4,414 |  |  | 7 | % |  | $ | 13,124 |  |  | $ | 12,526 |  |  | 5 | % |
| Gross profit | 2,431 |  |  | 2,200 |  |  | 11 | % |  | 6,763 |  |  | 6,048 |  |  | 12 | % |
| % of sales | 34.1 | % |  | 33.3 | % |  |  |  | 34.0 | % |  | 32.6 | % |  |  |

[0000833444-23-000030:mdna:25]
Cost of sales and gross profit increased for the three-month period ended June 30, 2023, and gross profit as a percentage of sales increased by 80 basis points. Gross profit increased due to sales growth and favorable price/cost, partially offset by

[0000833444-23-000030:mdna:26]
unfavorable foreign currency translation ($33 million). Gross profit as a percentage of sales increased primarily due to favorable price/cost. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-23-000030:mdna:27]
Cost of sales and gross profit increased for the nine-month period ended June 30, 2023, and gross profit as a percentage of sales increased by 140 basis points. Gross profit increased due to sales growth and favorable price/cost, partially offset by unfavorable foreign currency translation ($189 million). Gross profit as a percentage of sales increased primarily due to favorable price/cost. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-23-000030:mdna:28]
[same as prior period, unchanged from 0000833444-23-000014:mdna:28]

[0000833444-23-000030:mdna:29]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Selling, general and administrative expenses | $ | 1,555 |  |  | $ | 1,589 |  |  | -2 | % |  | $ | 4,705 |  |  | $ | 4,412 |  |  | 7 | % |
| % of sales | 21.8 | % |  | 24.0 | % |  |  |  | 23.7 | % |  | 23.8 | % |  |  |

[0000833444-23-000030:mdna:30]
SG&A for the three-month period ended June 30, 2023 decreased $34 million, and SG&A as a percentage of sales decreased by 220 basis points. The decrease in SG&A was primarily due to the favorable year-over-year impact of net mark-to-market adjustments and favorable foreign currency translation ($17 million), partially offset by certain investments to support growth and one-time transaction and separation costs. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-23-000030:mdna:31]
SG&A for the nine-month period ended June 30, 2023 increased $293 million, and SG&A as a percentage of sales decreased by 10 basis points. The increase in SG&A was primarily due to certain investments to support growth, one-time transaction and separation costs and a loss associated with a fire at a leased warehouse facility, partially offset by the favorable year-over-year impact of net mark-to-market adjustments and favorable foreign currency translation ($122 million). Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-23-000030:mdna:32]
[same as prior period, unchanged from 0000833444-23-000014:mdna:32]

[0000833444-23-000030:mdna:33]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Restructuring and impairment costs | $ | 81 |  |  | $ | 121 |  |  | -33 | % |  | $ | 844 |  |  | $ | 554 |  |  | 52 | % |

[0000833444-23-000030:mdna:34]
Restructuring and impairment costs for the three-month period ended June 30, 2023 included $67 million in severance charges and $14 million in other long-lived asset impairments and other restructuring costs.

[0000833444-23-000030:mdna:35]
Restructuring and impairment costs for the nine-month period ended June 30, 2023 included $498 million of impairment costs related to businesses classified or previously classified as held-for-sale, $184 million of goodwill impairment costs related to the Silent-Aire reporting unit, $114 million in severance charges and $48 million in other long-lived asset impairments and other restructuring costs.

[0000833444-23-000030:mdna:36]
Restructuring and impairment costs for the three-month period ended June 30, 2022 included $60 million of impairment costs related to businesses classified as held-for-sale, $52 million of severance charges, $7 million of other long-lived asset impairments and other restructuring costs and $2 million of impairment related to internal-use software projects that were no longer probable of being completed.

[0000833444-23-000030:mdna:37]
Restructuring and impairment costs for the nine-month period ended June 30, 2022 included $235 million of goodwill impairment costs related to the North America Retail reporting unit, $146 million of impairment costs related to businesses classified or previously classified as held-for-sale, $89 million of severance charges, $46 million of other long-lived asset

[0000833444-23-000030:mdna:38]
impairments and other restructuring costs, and $38 million of impairment related to internal-use software projects that were no longer probable of being completed.

[0000833444-23-000030:mdna:39]
Refer to Note 4, "Assets and Liabilities Held for Sale," Note 8, "Goodwill and Other Intangible Assets," and Note 17, "Restructuring and Related Costs," of the notes to the consolidated financial statements for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-23-000030:mdna:40]
[same as prior period, unchanged from 0000833444-23-000014:mdna:38]

[0000833444-23-000030:mdna:41]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Net financing charges | $ | 80 |  |  | $ | 49 |  |  | 63 | % |  | $ | 218 |  |  | $ | 153 |  |  | 42 | % |

[0000833444-23-000030:mdna:42]
[same as prior period, unchanged from 0000833444-23-000014:mdna:40]

[0000833444-23-000030:mdna:43]
[same as prior period, unchanged from 0000833444-23-000014:mdna:41]

[0000833444-23-000030:mdna:44]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Equity income | $ | 78 |  |  | $ | 63 |  |  | 24 | % |  | $ | 190 |  |  | $ | 175 |  |  | 9 | % |

[0000833444-23-000030:mdna:45]
The increase in equity income for the three and nine months ended June 30, 2023 was primarily due to higher income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-23-000030:mdna:46]
Income Tax (Benefit) Provision

[0000833444-23-000030:mdna:47]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Income tax (benefit) provision | $ | (329) |  |  | $ | 61 |  |  | * |  | $ | (266) |  |  | $ | 190 |  |  | * |
| Effective tax rate | (41.5 | %) |  | 12.1 | % |  |  |  | (22.4 | %) |  | 17.2 | % |  |  |

[0000833444-23-000030:mdna:48]
[same as prior period, unchanged from 0000833444-23-000014:mdna:51]

[0000833444-23-000030:mdna:49]
The decrease in the effective tax rate for the three and nine months ended June 30, 2023 was primarily due to reserve adjustments for uncertain tax positions resulting from tax audit developments and statute expirations, higher prior year tax impacts of impairment charges and the prior year establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestiture of its Global Retail business. Refer to Note 18, "Income Taxes," of the notes to the consolidated financial statements for further detail.

[0000833444-23-000030:mdna:50]
[same as prior period, unchanged from 0000833444-23-000014:mdna:47]

[0000833444-23-000030:mdna:51]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Income attributable to noncontrolling interests | $ | 73 |  |  | $ | 64 |  |  | 14 | % |  | $ | 152 |  |  | $ | 143 |  |  | 6 | % |

[0000833444-23-000030:mdna:52]
The increase in income attributable to noncontrolling interests for the three and nine months ended June 30, 2023 was primarily due to higher net income at certain partially-owned affiliates within the Global Products segment.

[0000833444-23-000030:mdna:53]
[same as prior period, unchanged from 0000833444-23-000014:mdna:49]

[0000833444-23-000030:mdna:54]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Net income attributable to Johnson Controls | $ | 1,049 |  |  | $ | 379 |  |  | * |  | $ | 1,300 |  |  | $ | 771 |  |  | 69 | % |

[0000833444-23-000030:mdna:55]
[same as prior period, unchanged from 0000833444-23-000014:mdna:56]

[0000833444-23-000030:mdna:56]
The increase in net income attributable to Johnson Controls for the three months ended June 30, 2023 was primarily due to lower income tax provision and higher gross profit, both of which are discussed above. The increase in net income attributable to Johnson Controls for the nine months ended June 30, 2023 was primarily due to higher gross profit and lower income tax provision, partially offset by higher SG&A and restructuring and impairment costs, all of which are discussed above.

[0000833444-23-000030:mdna:57]
Diluted earnings per share attributable to Johnson Controls for the three months ended June 30, 2023 was $1.53 compared to $0.55 for the three months ended June 30, 2022. Diluted earnings per share attributable to Johnson Controls for the nine months ended June 30, 2023 was $1.89 compared to $1.10 for the nine months ended June 30, 2022.

[0000833444-23-000030:mdna:58]
[same as prior period, unchanged from 0000833444-23-000014:mdna:54]

[0000833444-23-000030:mdna:59]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 1,025 |  |  | $ | 62 |  |  | * |  | $ | 1,341 |  |  | $ | 543 |  |  | * |

[0000833444-23-000030:mdna:60]
[same as prior period, unchanged from 0000833444-23-000014:mdna:96]

[0000833444-23-000030:mdna:61]
The increase in comprehensive income attributable to Johnson Controls for the three months ended June 30, 2023 was due to higher net income attributable to Johnson Controls ($670 million) and an increase in other comprehensive income attributable to Johnson Controls ($293 million) primarily resulting from currency translation adjustments.

[0000833444-23-000030:mdna:62]
The increase in comprehensive income attributable to Johnson Controls for the nine months ended June 30, 2023 was due to higher net income attributable to Johnson Controls ($529 million) and an increase in other comprehensive income attributable to Johnson Controls ($269 million) primarily resulting from currency translation adjustments.

[0000833444-23-000030:mdna:63]
[same as prior period, unchanged from 0000833444-23-000014:mdna:59]

[0000833444-23-000030:mdna:64]
Management evaluates the performance of its business units based primarily on segment EBITA, which represents income before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-23-000030:mdna:65]
[same as prior period, unchanged from 0000833444-23-000014:mdna:61]

[0000833444-23-000030:mdna:66]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Building Solutions North America | $ | 2,665 |  |  | $ | 2,426 |  |  | 10 | % |  | $ | 7,552 |  |  | $ | 6,805 |  |  | 11 | % |
| Building Solutions EMEA/LA | 1,045 |  |  | 952 |  |  | 10 | % |  | 3,051 |  |  | 2,869 |  |  | 6 | % |
| Building Solutions Asia Pacific | 736 |  |  | 665 |  |  | 11 | % |  | 2,049 |  |  | 1,963 |  |  | 4 | % |
| Global Products | 2,687 |  |  | 2,571 |  |  | 5 | % |  | 7,235 |  |  | 6,937 |  |  | 4 | % |
|  | $ | 7,133 |  |  | $ | 6,614 |  |  | 8 | % |  | $ | 19,887 |  |  | $ | 18,574 |  |  | 7 | % |

[0000833444-23-000030:mdna:67]
[same as prior period, unchanged from 0000833444-23-000014:mdna:63]

[0000833444-23-000030:mdna:68]
•The increase in Building Solutions North America was due to higher prices and volumes ($246 million) and incremental sales related to business acquisitions ($5 million), partially offset by the unfavorable impact of foreign currency translation ($12 million). Excluding the impacts of business acquisitions and foreign currency translation, sales growth was led by low-teens growth in HVAC & Controls and high single-digit growth in Fire & Security.

[0000833444-23-000030:mdna:69]
•The increase in Building Solutions EMEA/LA was due to higher prices ($89 million) and the net impact of business acquisitions and divestitures ($6 million), partially offset by the unfavorable impact of foreign currency translation ($2 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales growth was led by mid-teens growth in service and high single-digit growth in HVAC & Controls and Fire & Security. By region, there was strong organic growth in Europe and Latin America, with more modest growth in the Middle East.

[0000833444-23-000030:mdna:70]
•The increase in Building Solutions Asia Pacific was due to higher prices and volumes ($98 million) and incremental sales related to business acquisitions ($8 million), partially offset by the unfavorable impact of foreign currency translation ($35 million). Excluding the impacts of foreign currency translation and business acquisitions, sales growth was led by high-teen growth in service and continued momentum for HVAC & Controls. By region, sales in China grew over 25%, with strong double-digit growth in the service and install businesses as China rebounded from COVID-19 shutdowns in the prior year.

[0000833444-23-000030:mdna:71]
•The increase in Global Products was due to higher prices ($162 million) and incremental sales related to business acquisitions ($5 million), partially offset by the unfavorable impact of foreign currency translation ($51 million). Excluding the impacts of foreign currency translation and business acquisitions, sales growth was driven by growth in Applied, Fire Detection, Industrial Refrigeration and Commercial Ducted HVAC products.

[0000833444-23-000030:mdna:72]
[same as prior period, unchanged from 0000833444-23-000014:mdna:68]

[0000833444-23-000030:mdna:73]
•The increase in Building Solutions North America was due to higher prices and volumes ($771 million) and incremental sales related to business acquisitions ($17 million), partially offset by the unfavorable impact of foreign currency translation ($41 million). Excluding the impacts of business acquisitions and foreign currency translation, sales growth was led by growth in HVAC & Controls and Fire & Security.

[0000833444-23-000030:mdna:74]
•The increase in Building Solutions EMEA/LA was due to higher prices ($296 million) and the net impact of business acquisitions and divestitures ($27 million), partially offset by the unfavorable impact of foreign currency translation ($141 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales growth was led by growth in Fire & Security and HVAC & Controls. By region, there was strong organic growth in Europe and Latin America, with more modest growth in the Middle East.

[0000833444-23-000030:mdna:75]
•The increase in Building Solutions Asia Pacific was due to higher prices and volumes ($225 million) and incremental sales related to business acquisitions ($8 million), partially offset by the unfavorable impact of foreign currency translation ($147 million). Excluding the impacts of foreign currency translation and business acquisitions, sales growth was led by continued demand for HVAC & Controls. By region, sales in China grew, with strong growth in the service and install businesses.

[0000833444-23-000030:mdna:76]
•The increase in Global Products was due to the net impact of higher prices and lower volumes ($562 million) and incremental sales related to business acquisitions ($5 million), partially offset by the unfavorable impact of foreign currency translation ($269 million). Excluding the impacts of foreign currency translation and business acquisitions, sales growth was driven by strong price realization and growth in Applied, Fire Detection, Industrial Refrigeration and Commercial HVAC products.

[0000833444-23-000030:mdna:77]
[same as prior period, unchanged from 0000833444-23-000014:mdna:74]

[0000833444-23-000030:mdna:78]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Building Solutions North America | $ | 385 |  |  | $ | 260 |  |  | 48 | % |  | $ | 967 |  |  | $ | 745 |  |  | 30 | % |
| Building Solutions EMEA/LA | 90 |  |  | 83 |  |  | 8 | % |  | 234 |  |  | 266 |  |  | -12 | % |
| Building Solutions Asia Pacific | 102 |  |  | 85 |  |  | 20 | % |  | 249 |  |  | 227 |  |  | 10 | % |
| Global Products | 593 |  |  | 570 |  |  | 4 | % |  | 1,463 |  |  | 1,283 |  |  | 14 | % |
|  | $ | 1,170 |  |  | $ | 998 |  |  | 17 | % |  | $ | 2,913 |  |  | $ | 2,521 |  |  | 16 | % |

[0000833444-23-000030:mdna:79]
[same as prior period, unchanged from 0000833444-23-000014:mdna:76]

[0000833444-23-000030:mdna:80]
•The increase in Building Solutions North America was primarily due to favorable price/cost, ongoing productivity savings and growth in service.

[0000833444-23-000030:mdna:81]
•The increase in Building Solutions EMEA/LA was primarily due to favorable price/cost and productivity improvements.

[0000833444-23-000030:mdna:82]
•The increase in Building Solutions Asia Pacific was primarily due to service performance, favorable price/cost and productivity savings.

[0000833444-23-000030:mdna:83]
•The increase in Global Products was primarily due to favorable price/cost and productivity savings, partially offset by the unfavorable impact of continued weakness in the residential North America market and foreign currency translation ($11 million).

[0000833444-23-000030:mdna:84]
[same as prior period, unchanged from 0000833444-23-000014:mdna:81]

[0000833444-23-000030:mdna:85]
[same as prior period, unchanged from 0000833444-23-000014:mdna:82]

[0000833444-23-000030:mdna:86]
•The decrease in Building Solutions EMEA/LA was primarily due to the unfavorable impact of foreign currency translation ($16 million) and unfavorable project mix, partially offset by favorable price/cost and productivity savings.

[0000833444-23-000030:mdna:87]
•The increase in Building Solutions Asia Pacific was primarily due to favorable price/cost and productivity savings, partially offset by the unfavorable impact of foreign currency translation ($21 million).

[0000833444-23-000030:mdna:88]
•The increase in Global Products was primarily due to favorable price/cost and productivity savings, partially offset by unfavorable mix, an uninsured loss associated with a fire at a leased warehouse facility and the unfavorable impact of foreign currency translation ($36 million).

[0000833444-23-000030:mdna:89]
[same as prior period, unchanged from 0000833444-23-000014:mdna:86]

[0000833444-23-000030:mdna:90]
The Company’s backlog is applicable to its sales of systems and services. At June 30, 2023, the backlog was $13.3 billion, of which $12.0 billion was attributable to the building solutions (field) business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-23-000030:mdna:91]
48

[0000833444-23-000030:mdna:92]
At June 30, 2023, remaining performance obligations were $19.2 billion, which is $5.9 billion higher than the Company's backlog of $13.3 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-23-000030:mdna:93]
[same as prior period, unchanged from 0000833444-23-000014:mdna:89]

[0000833444-23-000030:mdna:94]
[same as prior period, unchanged from 0000833444-23-000014:mdna:90]

[0000833444-23-000030:mdna:95]
[same as prior period, unchanged from 0000833444-23-000014:mdna:91]

[0000833444-23-000030:mdna:96]
[same as prior period, unchanged from 0000833444-23-000014:mdna:92]

[0000833444-23-000030:mdna:97]
[same as prior period, unchanged from 0000833444-23-000014:mdna:93]

[0000833444-23-000030:mdna:98]
[same as prior period, unchanged from 0000833444-23-000014:mdna:94]

[0000833444-23-000030:mdna:99]
|  | June 30, |  | September 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |
| Current assets | $ | 12,006 |  |  | $ | 11,685 |  |  |  |
| Current liabilities | (11,128) |  |  | (11,239) |  |  |  |
|  | 878 |  |  | 446 |  |  | 97 | % |
| Less: Cash and cash equivalents | (1,057) |  |  | (2,031) |  |  |  |
| Add: Short-term debt | 186 |  |  | 669 |  |  |  |
| Add: Current portion of long-term debt | 1,081 |  |  | 865 |  |  |  |
| Working capital (as defined) | $ | 1,088 |  |  | $ | (51) |  |  | * |
| Accounts receivable - net | $ | 6,540 |  |  | $ | 5,727 |  |  | 14 | % |
| Inventories | 3,092 |  |  | 2,665 |  |  | 16 | % |
| Accounts payable | 4,296 |  |  | 4,368 |  |  | (2 | %) |

[0000833444-23-000030:mdna:100]
* Measure not meaningful

[0000833444-23-000030:mdna:101]
[same as prior period, unchanged from 0000833444-23-000014:mdna:97]

[0000833444-23-000030:mdna:102]
•The increase in working capital at June 30, 2023 as compared to September 30, 2022, was primarily due to increases in accounts receivable due to increased sales and timing of collections and increases in inventory due to seasonality factors and softer demand in the residential end market.

[0000833444-23-000030:mdna:103]
•The Company’s days sales in accounts receivable at June 30, 2023 and September 30, 2022 were 58 days and 51 days, respectively. There have been no significant adverse changes in the level of overdue receivables or significant changes in revenue recognition methods.

[0000833444-23-000030:mdna:104]
•The Company’s inventory turns for the three months ended June 30, 2023 were lower than the comparable period ended September 30, 2022 primarily due to softer demand in the residential end market and certain other project delays.

[0000833444-23-000030:mdna:105]
•Days in accounts payable were 83 days at June 30, 2023 and 88 days at September 30, 2022.

[0000833444-23-000030:mdna:106]
[same as prior period, unchanged from 0000833444-23-000014:mdna:113]

[0000833444-23-000030:mdna:107]
[same as prior period, unchanged from 0000833444-23-000014:mdna:102]

[0000833444-23-000030:mdna:108]
|  |  | Nine Months Ended June 30, |
| (in millions) |  | 2023 |  | 2022 |
| Cash provided by operating activities |  | $ | 831 |  |  | $ | 811 |  |
| Cash used by investing activities |  | (576) |  |  | (588) |  |
| Cash provided (used) by financing activities |  | (1,111) |  |  | 29 |  |

[0000833444-23-000030:mdna:109]
•The increase in cash provided by operating activities reflects higher net income and lower cash payments for inventory, partially offset by the timing of accounts payable and accrued liabilities payments.

[0000833444-23-000030:mdna:110]
•The decrease in cash used by investing activities was primarily due to lower capital expenditures, partially offset by higher cash paid for acquisitions.

[0000833444-23-000030:mdna:111]
•The decrease in cash provided by financing activities was primarily due to lower net cash inflows from debt and borrowings, partially offset by lower cash outflows for stock repurchases.

[0000833444-23-000030:mdna:112]
[same as prior period, unchanged from 0000833444-23-000014:mdna:107]

[0000833444-23-000030:mdna:113]
|  | June 30, |  | September 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |
| Short-term debt | $ | 186 |  |  | $ | 669 |  |  |  |
| Current portion of long-term debt | 1,081 |  |  | 865 |  |  |  |
| Long-term debt | 8,497 |  |  | 7,426 |  |  |  |
| Total debt | 9,764 |  |  | 8,960 |  |  | 9 | % |
| Less: Cash and cash equivalents | 1,057 |  |  | 2,031 |  |  |  |
| Total net debt | 8,707 |  |  | 6,929 |  |  | 26 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 16,324 |  |  | 16,268 |  |  | — | % |
| Total capitalization | $ | 25,031 |  |  | $ | 23,197 |  |  | 8 | % |
| Total net debt as a % of total capitalization | 34.8 | % |  | 29.9 | % |  |  |

[0000833444-23-000030:mdna:114]
[same as prior period, unchanged from 0000833444-23-000014:mdna:109]

[0000833444-23-000030:mdna:115]
[same as prior period, unchanged from 0000833444-23-000014:mdna:110]

[0000833444-23-000030:mdna:116]
•As of June 30, 2023, approximately $3.0 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity, and the economic environment.

[0000833444-23-000030:mdna:117]
•The Company declared a dividend of $0.37 per common share in the quarter ended June 30, 2023 and intends to continue paying dividends throughout fiscal 2023.

[0000833444-23-000030:mdna:118]
•The Company believes its capital resources and liquidity position, including cash and cash equivalents of $1.1 billion at June 30, 2023, are adequate to fund operations and meet its obligations for the foreseeable future. The Company expects

[0000833444-23-000030:mdna:119]
requirements for working capital, capital expenditures, dividends, minimum pension contributions, debt maturities and any potential acquisitions or stock repurchases in the remainder of fiscal 2023 will be funded from operations, supplemented by short- and long-term borrowings, if required.

[0000833444-23-000030:mdna:120]
–The Company manages its short-term debt position in the U.S. and euro commercial paper and bank loan markets. No commercial paper was outstanding as of June 30, 2023.  Commercial paper outstanding totaled $172 million as of September 30, 2022.

[0000833444-23-000030:mdna:121]
[same as prior period, unchanged from 0000833444-23-000014:mdna:116]

[0000833444-23-000030:mdna:122]
–The Company also has the ability to draw on its $2.5 billion revolving credit facility which expires in December 2024 or its $0.5 billion 364-day revolving credit facility which expires in November 2023. There were no draws on the revolving credit facilities as of June 30, 2023 and September 30, 2022.

[0000833444-23-000030:mdna:123]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of June 30, 2023, the Company's credit ratings and outlook were as follows:

[0000833444-23-000030:mdna:124]
[same as prior period, unchanged from 0000833444-23-000014:mdna:119]

[0000833444-23-000030:mdna:125]
[same as prior period, unchanged from 0000833444-23-000014:mdna:120]

[0000833444-23-000030:mdna:126]
•Financial covenants in the Company's revolving credit facilities requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of June 30, 2023, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-23-000030:mdna:127]
•The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2023, the Company believes the long-term rate of return will approximate 8.25%, 3.70% and 6.65% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first nine months of fiscal 2023, the Company made approximately $38 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $38 million in cash to its defined benefit pension plans and $3 million in cash to its postretirement plans in fiscal 2023.

[0000833444-23-000030:mdna:128]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company

[0000833444-23-000030:mdna:129]
could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at its Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-23-000030:mdna:130]
[same as prior period, unchanged from 0000833444-23-000014:mdna:126]

[0000833444-23-000030:mdna:131]
•Refer to Note 10, "Debt and Financing Arrangements," of the notes to the consolidated financial statements for additional information on debt activity and items impacting capitalization.

[0000833444-23-000030:mdna:132]
[same as prior period, unchanged from 0000833444-23-000014:mdna:128]

[0000833444-23-000030:mdna:133]
[same as prior period, unchanged from 0000833444-23-000014:mdna:129]

[0000833444-23-000030:mdna:134]
•€500 million aggregate principal amount of 0.375% Senior Notes due 2027

[0000833444-23-000030:mdna:135]
•€600 million aggregate principal amount of 3.000% Senior Notes due 2028

[0000833444-23-000030:mdna:136]
•$625 million aggregate principal amount of 1.750% Senior Notes due 2030

[0000833444-23-000030:mdna:137]
•$500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due 2031

[0000833444-23-000030:mdna:138]
•$400 million aggregate principal amount of 4.900% Senior Notes due 2032

[0000833444-23-000030:mdna:139]
•€500 million aggregate principal amount of 1.000% Senior Notes due 2032

[0000833444-23-000030:mdna:140]
•€800 million aggregate principal amount of 4.25% Senior Notes due 2035

[0000833444-23-000030:mdna:141]
[same as prior period, unchanged from 0000833444-23-000014:mdna:136]

[0000833444-23-000030:mdna:142]
[same as prior period, unchanged from 0000833444-23-000014:mdna:137]

[0000833444-23-000030:mdna:143]
52

[0000833444-23-000030:mdna:144]
[same as prior period, unchanged from 0000833444-23-000014:mdna:139]

[0000833444-23-000030:mdna:145]
|  |  | Nine Months Ended June 30, 2023 |  | Year EndedSeptember 30, 2022 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Net loss |  | (390) |  |  | (268) |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net loss attributable to the entity |  | (390) |  |  | (268) |  |  |

[0000833444-23-000030:mdna:146]
[same as prior period, unchanged from 0000833444-23-000014:mdna:141]

[0000833444-23-000030:mdna:147]
|  |  | Nine Months Ended June 30, 2023 |  | Year EndedSeptember 30, 2022 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Net income (loss) |  | (81) |  |  | 92 |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net income (loss) attributable to the entity |  | (81) |  |  | 92 |  |  |

[0000833444-23-000030:mdna:148]
The following table presents summarized balance sheet information as of June 30, 2023 and September 30, 2022 (in millions):

[0000833444-23-000030:mdna:149]
|  |  | June 30, 2023 |  | September 30, 2022 |  |
| Current assets |  | $ | 207 |  |  | $ | 1,231 |  |  |
| Noncurrent assets |  | 243 |  |  | 243 |  |  |
| Current liabilities |  | 2,314 |  |  | 5,463 |  |  |
| Noncurrent liabilities |  | 8,232 |  |  | 7,176 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-23-000030:mdna:150]
[same as prior period, unchanged from 0000833444-23-000014:mdna:145]

[0000833444-23-000030:mdna:151]
|  |  | June 30, 2023 |  | September 30, 2022 |  |
| Current assets |  | $ | 1,812 |  |  | $ | 455 |  |  |
| Noncurrent assets |  | 1,951 |  |  | 2,952 |  |  |
| Current liabilities |  | 6,921 |  |  | 2,538 |  |  |
| Noncurrent liabilities |  | 6,346 |  |  | 6,228 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-23-000030:mdna:152]
[same as prior period, unchanged from 0000833444-23-000014:mdna:147]

[0000833444-23-000030:mdna:153]
[same as prior period, unchanged from 0000833444-23-000014:mdna:148]

[0000833444-23-000030:mdna:154]
[same as prior period, unchanged from 0000833444-23-000014:mdna:149]

[0000833444-23-000030:mdna:155]
[same as prior period, unchanged from 0000833444-23-000014:mdna:150]

[0000833444-23-000030:mdna:156]
[same as prior period, unchanged from 0000833444-23-000014:mdna:151]
