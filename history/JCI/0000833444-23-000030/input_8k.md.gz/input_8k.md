# JCI 8-K — 0000833444-23-000028 filed 2023-08-02

## item codes, every 8-K on or before 2023-08-02

- 2023-08-02 0000833444-23-000028 — 2.02, 9.01
- 2023-05-23 0001193125-23-151889 — 8.01, 9.01
- 2023-05-05 0000833444-23-000011 — 2.02, 9.01
- 2023-03-14 0000833444-23-000007 — 5.07
- 2023-02-01 0000833444-23-000003 — 2.02, 9.01
- 2022-12-22 0000833444-22-000047 — 5.02
- 2022-12-09 0000833444-22-000045 — 5.02
- 2022-11-03 0000833444-22-000038 — 2.02, 9.01
- 2022-09-14 0001193125-22-244741 — 8.01, 9.01
- 2022-09-07 0001193125-22-240030 — 8.01, 9.01
- 2022-08-04 0000833444-22-000034 — 2.02, 9.01
- 2022-07-06 0000833444-22-000029 — 5.02, 9.01
- 2022-06-30 0000833444-22-000027 — 5.02
- 2022-05-04 0000833444-22-000014 — 2.02, 9.01
- 2022-03-11 0001193125-22-073382 — 5.07
- 2022-02-15 0000833444-22-000010 — 5.02
- 2022-02-02 0000833444-22-000003 — 2.02, 9.01
- 2021-12-10 0000833444-21-000050 — 5.02
- 2021-11-05 0000833444-21-000043 — 2.02, 9.01
- 2021-09-16 0001193125-21-275152 — 1.01, 8.01, 9.01
- 2021-07-30 0000833444-21-000038 — 2.02, 9.01
- 2021-05-03 0000833444-21-000023 — 8.01
- 2021-04-30 0000833444-21-000017 — 2.02, 9.01
- 2021-03-11 0000833444-21-000013 — 5.02, 5.07, 9.01
- 2021-02-17 0001193125-21-045768 — 7.01, 9.01
- 2021-01-29 0000833444-21-000009 — 2.02, 9.01
- 2021-01-07 0000833444-21-000004 — 7.01
- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2023-08-02

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-23-000028:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq3fy23.htm
EX-99.1

[0000833444-23-000028:8k_2_02:2]
Document

[0000833444-23-000028:8k_2_02:3]
Exhibit 99.1

[0000833444-23-000028:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-23-000028:8k_2_02:5]
Johnson Controls Reports Strong Revenue and EPS Growth in Q3; Updates FY23 Guidance

[0000833444-23-000028:8k_2_02:6]
________________________________________________________________________________

[0000833444-23-000028:8k_2_02:7]
▪Q3 reported sales +8% versus prior year; +9% organically

[0000833444-23-000028:8k_2_02:8]
▪Q3 GAAP EPS of $1.53; Adjusted EPS of $1.03, up 21% versus prior year

[0000833444-23-000028:8k_2_02:9]
▪Q3 Orders +8% organically year-over year

[0000833444-23-000028:8k_2_02:10]
▪Record backlog of $12.0 billion, increased 8% organically year-over year

[0000833444-23-000028:8k_2_02:11]
▪Initiates fiscal Q4 and updates fiscal 2023 full year guidance

[0000833444-23-000028:8k_2_02:12]
______________________________________________________________________________

[0000833444-23-000028:8k_2_02:13]
CORK, Ireland, August 2, 2023 -- Johnson Controls International plc (NYSE: JCI), a global leader for smart, healthy and sustainable buildings, today reported fiscal third quarter 2023 GAAP earnings per share (“EPS”) from continuing operations of $1.53. Excluding special items, adjusted EPS from continuing operations was $1.03, up 21% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-23-000028:8k_2_02:14]
Sales in the quarter of $7.1 billion increased 8% compared to the prior year on an as reported basis and grew 9% organically. GAAP net income from continuing operations was $1.05 billion. Adjusted net income from continuing operations of $706 million was up 19% versus the prior year. Earnings before interest and taxes (“EBIT”) was $873 million and EBIT margin was 12.2%. Adjusted EBIT was $981 million and adjusted EBIT margin was 13.8%, improving 160 basis points versus the prior year.

[0000833444-23-000028:8k_2_02:15]
“Johnson Controls delivered strong third quarter results led by double digit growth in sales and orders for our Service business,” said George Oliver, Chairman and CEO. “We remain confident in our longer cycle Building Solutions segments supported by our healthy order pipeline and resilient backlog. Our leading technologies position us well in making buildings smarter, healthier, and more sustainable.”

[0000833444-23-000028:8k_2_02:16]
“Our third quarter results met the high end of our guidance as we delivered robust margin expansion and strong adjusted EPS growth,” said Olivier Leonetti, Chief Financial Officer. “We have made great progress in improving our margins this fiscal year and we believe there remains runway for further margin expansion in fiscal 2024 and beyond.”

[0000833444-23-000028:8k_2_02:17]
Page 1 of 18

[0000833444-23-000028:8k_2_02:18]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-23-000028:8k_2_02:19]
($ millions, except per-share amounts)

[0000833444-23-000028:8k_2_02:20]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal third quarter of 2022.

[0000833444-23-000028:8k_2_02:21]
Organic sales growth, adjusted sales, total segment EBITA, adjusted segment EBITA, adjusted corporate expense, EBIT, adjusted EBIT, adjusted net income from continuing operations, adjusted EPS from continuing operations, cash provided by operating activities from continuing operations, excluding JC Capital, and free cash flow are non-GAAP financial measures. For a reconciliation of non-GAAP measures and detail of the special items, refer to the attached footnotes.

[0000833444-23-000028:8k_2_02:22]
This press release includes forward-looking statements regarding organic revenue growth, adjusted segment EBITA margin improvement and adjusted EPS, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as mark-to-market adjustments. Organic revenue growth excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company's fiscal 2023 fourth quarter and full year GAAP financial results.

[0000833444-23-000028:8k_2_02:23]
A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-23-000028:8k_2_02:24]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Sales |  | $6,614 |  | $7,133 |  | $6,614 |  | $7,133 |  |  |  |  |  |  |
| Segment EBITA |  | 998 |  | 1,170 |  | 998 |  | 1,170 |  |  |  |  |  |  |
| EBIT |  | 553 |  | 873 |  | 809 |  | 981 |  |  |  |  |  |  |
| Net income from continuing operations |  | 379 |  | 1,049 |  | 594 |  | 706 |  |  |  |  |  |  |
| Diluted EPS from continuing operations |  | $0.55 |  | $1.53 |  | $0.85 |  | $1.03 |  |  |  |  |  |  |

[0000833444-23-000028:8k_2_02:25]
Page 2 of 18

[0000833444-23-000028:8k_2_02:26]
SEGMENT RESULTS

[0000833444-23-000028:8k_2_02:27]
Building Solutions North America

[0000833444-23-000028:8k_2_02:28]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Sales |  | $2,426 |  | $2,665 |  | $2,426 |  | $2,665 |  |  |  |  |  |  |
| Segment EBITA |  | 260 |  | 385 |  | 260 |  | 385 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 10.7% |  | 14.4% |  | 10.7% |  | 14.4% |  |  |  |  |  |  |

[0000833444-23-000028:8k_2_02:29]
Sales in the quarter of $2.7 billion increased 10% versus the prior year. Organic sales increased 10% over the prior year with strong growth in both Service and Install, led by low-teens digit growth in HVAC & Controls and high single-digit growth in Fire & Security.

[0000833444-23-000028:8k_2_02:30]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 5% year-over-year. Backlog at the end of the quarter of $8.0 billion increased 11% compared to the prior year, excluding M&A and adjusted for foreign currency.

[0000833444-23-000028:8k_2_02:31]
Segment EBITA was $385 million, up 48% versus the prior year. Segment EBITA margin of 14.4% expanded 370 basis points versus the prior year led by higher margin backlog conversion, ongoing productivity benefits and strong growth in Services.

[0000833444-23-000028:8k_2_02:32]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-23-000028:8k_2_02:33]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Sales |  | $952 |  | $1,045 |  | $952 |  | $1,045 |  |  |  |  |  |  |
| Segment EBITA |  | 83 |  | 90 |  | 83 |  | 90 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 8.7% |  | 8.6% |  | 8.7% |  | 8.6% |  |  |  |  |  |  |

[0000833444-23-000028:8k_2_02:34]
Sales in the quarter of $1.0 billion increased 10% versus the prior year. Organic sales grew 9% versus the prior year, with mid-teens growth in Service and high single-digit growth in HVAC & Controls and Fire & Security. By region, Europe and Latin America experienced strong organic growth, while growth in the Middle East was more modest.

[0000833444-23-000028:8k_2_02:35]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 10% year-over-year. Backlog at the end of the quarter of $2.3 billion increased 6% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-23-000028:8k_2_02:36]
Page 3 of 18

[0000833444-23-000028:8k_2_02:37]
Segment EBITA was $90 million, an increase of 8% versus the prior year. Segment EBITA margin of 8.6% declined 10 basis points versus the prior year and showed strong sequential improvement as higher margin backlog conversion and productivity improved.

[0000833444-23-000028:8k_2_02:38]
Building Solutions Asia Pacific

[0000833444-23-000028:8k_2_02:39]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Sales |  | $665 |  | $736 |  | $665 |  | $736 |  |  |  |  |  |  |
| Segment EBITA |  | 85 |  | 102 |  | 85 |  | 102 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 12.8% |  | 13.9% |  | 12.8% |  | 13.9% |  |  |  |  |  |  |

[0000833444-23-000028:8k_2_02:40]
Sales in the quarter of $736 million increased 11% versus the prior year. Sales increased 16% organically versus the prior year, with high-teen growth in Service and continued momentum in HVAC & Controls. Organic Sales in China grew greater than 25%, with strong double-digit growth in the Service and Install businesses, as China rebounded from Covid-19 shutdowns in the prior year.

[0000833444-23-000028:8k_2_02:41]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 14% year-over-year. Backlog at the end of the quarter of $1.7 billion increased 2% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-23-000028:8k_2_02:42]
Segment EBITA was $102 million, up 20% versus the prior year. Segment EBITA margin of 13.9% expanded 110 basis points versus the prior year led by strong Service performance, higher margin backlog conversion, and productivity.

[0000833444-23-000028:8k_2_02:43]
Page 4 of 18

[0000833444-23-000028:8k_2_02:44]
Global Products

[0000833444-23-000028:8k_2_02:45]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Sales |  | $2,571 |  | $2,687 |  | $2,571 |  | $2,687 |  |  |  |  |  |  |
| Segment EBITA |  | 570 |  | 593 |  | 570 |  | 593 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 22.2% |  | 22.1% |  | 22.2% |  | 22.1% |  |  |  |  |  |  |

[0000833444-23-000028:8k_2_02:46]
Sales in the quarter of $2.7 billion increased 5% versus the prior year. Organic sales grew 6% versus the prior year driven by growth in Applied, Fire Detection, Industrial Refrigeration, and Commercial Ducted HVAC products.

[0000833444-23-000028:8k_2_02:47]
Segment EBITA was $593 million, up 4% versus the prior year. Segment EBITA margin of 22.1% declined 10 basis points versus the prior year against a tough comparison and further Residential weakness.

[0000833444-23-000028:8k_2_02:48]
Corporate

[0000833444-23-000028:8k_2_02:49]
|  |  | Fiscal Q3 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Corporate Expense |  | ($96) |  | ($122) |  | ($87) |  | ($78) |  |  |  |  |  |  |

[0000833444-23-000028:8k_2_02:50]
Corporate expense was $122 million in the quarter, an increase of 27% compared to the prior year. Adjusted Corporate expense excludes transaction/separation costs in both Q3 2022 and Q3 2023.

[0000833444-23-000028:8k_2_02:51]
OTHER Q3 ITEMS

[0000833444-23-000028:8k_2_02:52]
▪Cash provided by operating activities from continuing operations was $813 million, while cash provided by operating activities from continuing operations, excluding JC Capital, was $852 million. Capital expenditures were $111 million, resulting in a free cash flow from continuing operations of $741 million.

[0000833444-23-000028:8k_2_02:53]
▪The Company repurchased 6.0 million shares for approximately $366 million. Year-to-date through June the Company repurchased 10.3 million shares for approximately $613 million.

[0000833444-23-000028:8k_2_02:54]
▪The Company recorded net pre-tax mark-to-market gains of $17 million related primarily to the remeasurement of the Company’s pension and postretirement benefit plans and restricted asbestos investments.

[0000833444-23-000028:8k_2_02:55]
Page 5 of 18

[0000833444-23-000028:8k_2_02:56]
▪The Company recorded pre-tax restructuring and impairment costs of $81 million.

[0000833444-23-000028:8k_2_02:57]
▪The Company recorded a discrete period net tax benefit of $438 million resulting from tax audit resolutions, statute expirations and remeasurement of certain tax-related matters.

[0000833444-23-000028:8k_2_02:58]
▪The Company issued €800 million senior notes due 2035.

[0000833444-23-000028:8k_2_02:59]
FOURTH QUARTER GUIDANCE

[0000833444-23-000028:8k_2_02:60]
The Company initiated fiscal 2023 fourth quarter guidance:

[0000833444-23-000028:8k_2_02:61]
▪Organic revenue growth of ~+4% year-over-year

[0000833444-23-000028:8k_2_02:62]
▪Adjusted segment EBITA margin improvement of ~+60 basis points year-over-year

[0000833444-23-000028:8k_2_02:63]
▪Adjusted EPS before special items of ~$1.10; representing ~11% growth year-over-year

[0000833444-23-000028:8k_2_02:64]
FULL YEAR GUIDANCE

[0000833444-23-000028:8k_2_02:65]
The Company updated its fiscal 2023 full year EPS guidance:

[0000833444-23-000028:8k_2_02:66]
▪Organic revenue growth ~+HSD year-over year (previously guided at ~+10% growth)

[0000833444-23-000028:8k_2_02:67]
▪Adjusted segment EBITA margin improvement of ~+110 basis points, year-over-year (previously guided to 100 to 120 basis point improvement)

[0000833444-23-000028:8k_2_02:68]
▪Adjusted EPS before special items of ~$3.55; representing ~18% growth year-over-year (previously guided to $3.50 to $3.60)

[0000833444-23-000028:8k_2_02:69]
CONFERENCE CALL & WEBCAST INFO

[0000833444-23-000028:8k_2_02:70]
Johnson Controls will host a conference call to discuss this quarter’s results at 8:30 a.m. ET today, which can be accessed by dialing 844-763-8274 (in the United States) or +1-412-717-9224 (outside the United States), or via webcast. A slide presentation will accompany the prepared remarks and has been posted on the investor relations section of the Johnson Controls website at https://investors.johnsoncontrols.com/news-and-events/events-and-presentations. A replay will be made available approximately two hours following the conclusion of the conference call.

[0000833444-23-000028:8k_2_02:71]
About Johnson Controls:

[0000833444-23-000028:8k_2_02:72]
At Johnson Controls (NYSE:JCI), we transform the environments where people live, work, learn and play. As the global leader in smart, healthy and sustainable buildings, our mission is to reimagine the performance of buildings to serve people, places and the planet.

[0000833444-23-000028:8k_2_02:73]
Building on a proud history of nearly 140 years of innovation, we deliver the blueprint of the future for industries such as healthcare, schools, data centers, airports, stadiums, manufacturing and beyond through OpenBlue, our comprehensive digital offering.

[0000833444-23-000028:8k_2_02:74]
Page 6 of 18

[0000833444-23-000028:8k_2_02:75]
Today, with a global team of 100,000 experts in more than 150 countries, Johnson Controls offers the world`s largest portfolio of building technology and software as well as service solutions from some of the most trusted names in the industry.

[0000833444-23-000028:8k_2_02:76]
Visit www.johnsoncontrols.com for more information and follow @Johnson Controls on social platforms.

[0000833444-23-000028:8k_2_02:77]
JOHNSON CONTROLS CONTACTS:

[0000833444-23-000028:8k_2_02:78]
| INVESTOR CONTACTS: | MEDIA CONTACT: |  |  |  |
| Jim Lucas | Danielle Canzanella |  |  |  |
| Direct: +1 651.391.3182 | Direct: +1 203.499.8297 |  |  |  |
| Email: jim.lucas@jci.com | Email: danielle.canzanella@jci.com |  |  |  |
| Michael Gates |  |  |  |  |
| Direct: +1 414.524.5785 |  |  |  |  |
| Email: michael.j.gates@jci.com |  |  |  |  |

[0000833444-23-000028:8k_2_02:79]
###

[0000833444-23-000028:8k_2_02:80]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-23-000028:8k_2_02:81]
Page 7 of 18

[0000833444-23-000028:8k_2_02:82]
lifecycle cybersecurity risk in the development, deployment and operation of Johnson Controls digital platforms and services; the outcome of litigation and governmental proceedings; the risk of infringement or expiration of intellectual property rights; Johnson Controls ability to manage the impacts of natural disasters, climate change, pandemics and outbreaks of contagious diseases and other adverse public health developments, such as the COVID-19 pandemic; the ability of Johnson Controls to drive organizational improvement; any delay or inability of Johnson Controls to realize the expected benefits and synergies of recent portfolio transactions; the ability to hire and retain senior management and other key personnel; the tax treatment of recent portfolio transactions; significant transaction costs and/or unknown liabilities associated with such transactions; labor shortages, work stoppages, union negotiations, labor disputes and other matters associated with the labor force; and the cancellation of or changes to commercial arrangements. A detailed discussion of risks related to Johnson Controls business is included in the section entitled "Risk Factors" in Johnson Controls Annual Report on Form 10-K for the 2022 fiscal year filed with the SEC on November 15, 2022, which is available at www.sec.gov and www.johnsoncontrols.com under the "Investors" tab. The description of certain of these risks is supplemented in Item 1A of Part II of Johnson Controls subsequently filed Quarterly Reports on Form 10-Q. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-23-000028:8k_2_02:83]
###

[0000833444-23-000028:8k_2_02:84]
Non-GAAP Financial Information

[0000833444-23-000028:8k_2_02:85]
This press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include restructuring and impairment costs, net mark-to-market adjustments, Silent-Aire other nonrecurring items, certain transaction/separation costs, Silent-Aire earn-out adjustment, charges attributable to the suspension of operations in Russia, warehouse fire loss, and discrete tax items. Financial information regarding organic sales growth, adjusted sales, EBIT, EBIT margin, adjusted EBIT, adjusted EBIT margin, total segment EBITA, adjusted segment EBITA, adjusted segment EBITA margin, adjusted Corporate expense, cash provided by operating activities from continuing operations, excluding JC Capital, free cash flow, free cash flow conversion and adjusted net income from continuing operations are also presented, which are non-GAAP performance measures. Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of Johnson Controls. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.  For further information on the calculation of the non-GAAP measures and a reconciliation of these non-GAAP measures, refer to the attached footnotes.

[0000833444-23-000028:8k_2_02:86]
###

[0000833444-23-000028:8k_2_02:87]
Page 8 of 18

[0000833444-23-000028:8k_2_02:88]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |  |
|  |  | Three Months Ended June 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Net sales | $ | 7,133 |  |  |  | $ | 6,614 |  |  |
| Cost of sales | 4,702 |  |  |  | 4,414 |  |  |
|  | Gross profit | 2,431 |  |  |  | 2,200 |  |  |
| Selling, general and administrative expenses | (1,555) |  |  |  | (1,589) |  |  |
| Restructuring and impairment costs | (81) |  |  |  | (121) |  |  |
| Net financing charges | (80) |  |  |  | (49) |  |  |
| Equity income | 78 |  |  |  | 63 |  |  |
| Income before income taxes | 793 |  |  |  | 504 |  |  |
| Income tax provision (benefit) | (329) |  |  |  | 61 |  |  |
| Net income | 1,122 |  |  |  | 443 |  |  |
| Income attributable to noncontrolling interests | 73 |  |  |  | 64 |  |  |
| Net income attributable to JCI | $ | 1,049 |  |  |  | $ | 379 |  |  |
| Diluted earnings per share | $ | 1.53 |  |  |  | $ | 0.55 |  |  |
| Diluted weighted average shares | 686.2 |  |  |  | 694.9 |  |  |
| Shares outstanding at period end | 680.3 |  |  |  | 688.8 |  |  |

[0000833444-23-000028:8k_2_02:89]
Page 9 of 18

[0000833444-23-000028:8k_2_02:90]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Nine Months Ended June 30, |
|  |  | 2023 |  |  | 2022 |
| Net sales | $ | 19,887 |  |  |  | $ | 18,574 |  |
| Cost of sales | 13,124 |  |  |  | 12,526 |  |
|  | Gross profit | 6,763 |  |  |  | 6,048 |  |
| Selling, general and administrative expenses | (4,705) |  |  |  | (4,412) |  |
| Restructuring and impairment costs | (844) |  |  |  | (554) |  |
| Net financing charges | (218) |  |  |  | (153) |  |
| Equity income | 190 |  |  |  | 175 |  |
| Income before income taxes | 1,186 |  |  |  | 1,104 |  |
| Income tax provision (benefit) | (266) |  |  |  | 190 |  |
| Net income | 1,452 |  |  |  | 914 |  |
| Income attributable to noncontrolling interests | 152 |  |  |  | 143 |  |
| Net income attributable to JCI | $ | 1,300 |  |  |  | $ | 771 |  |
| Diluted earnings per share | $ | 1.89 |  |  |  | $ | 1.10 |  |
| Diluted weighted average shares | 688.8 |  |  |  | 702.4 |  |
| Shares outstanding at period end | 680.3 |  |  |  | 688.8 |  |

[0000833444-23-000028:8k_2_02:91]
Page 10 of 18

[0000833444-23-000028:8k_2_02:92]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | June 30,2023 |  | September 30,2022 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 1,057 |  |  | $ | 2,031 |  |
| Accounts receivable - net | 6,540 |  |  | 5,727 |  |
| Inventories | 3,092 |  |  | 2,665 |  |
| Other current assets | 1,317 |  |  | 1,262 |  |
|  | Current assets | 12,006 |  |  | 11,685 |  |
| Property, plant and equipment - net | 3,187 |  |  | 3,131 |  |
| Goodwill | 17,644 |  |  | 17,350 |  |
| Other intangible assets - net | 4,831 |  |  | 5,155 |  |
| Investments in partially-owned affiliates | 988 |  |  | 963 |  |
| Other noncurrent assets | 4,124 |  |  | 3,874 |  |
|  | Total assets | $ | 42,780 |  |  | $ | 42,158 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 1,267 |  |  | $ | 1,534 |  |
| Accounts payable and accrued expenses | 5,250 |  |  | 5,371 |  |
| Other current liabilities | 4,611 |  |  | 4,334 |  |
|  | Current liabilities | 11,128 |  |  | 11,239 |  |
| Long-term debt | 8,497 |  |  | 7,426 |  |
| Other noncurrent liabilities | 5,692 |  |  | 6,091 |  |
| Shareholders' equity attributable to JCI | 16,324 |  |  | 16,268 |  |
| Noncontrolling interests | 1,139 |  |  | 1,134 |  |
|  | Total liabilities and equity | $ | 42,780 |  |  | $ | 42,158 |  |

[0000833444-23-000028:8k_2_02:93]
Page 11 of 18

[0000833444-23-000028:8k_2_02:94]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |  |  |
|  |  |  |  |  |  | Three Months Ended June 30, |  |  |
|  |  |  |  |  |  | 2023 |  |  | 2022 |  |  |
| Operating Activities |  |  |  |  |  |  |
| Net income attributable to JCI | $ | 1,049 |  |  |  | $ | 379 |  |  |  |
| Income attributable to noncontrolling interests | 73 |  |  |  | 64 |  |  |  |
| Net income | 1,122 |  |  |  | 443 |  |  |  |
| Adjustments to reconcile net income to cash provided (used) by operating activities: |  |  |  |  |  |  |
|  |  | Depreciation and amortization | 212 |  |  |  | 201 |  |  |  |
|  |  | Pension and postretirement benefit expense (income) | (20) |  |  |  | 59 |  |  |  |
|  |  | Pension and postretirement contributions | (12) |  |  |  | (7) |  |  |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | 28 |  |  |  | (45) |  |  |  |
|  |  | Deferred income taxes | (102) |  |  |  | (144) |  |  |  |
|  |  | Non-cash restructuring and impairment costs | 10 |  |  |  | 69 |  |  |  |
|  |  | Other - net | 14 |  |  |  | 39 |  |  |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |  |  |
|  |  |  |  | Accounts receivable | (307) |  |  |  | (331) |  |  |  |
|  |  |  |  | Inventories | 110 |  |  |  | (142) |  |  |  |
|  |  |  |  | Other assets | (45) |  |  |  | (70) |  |  |  |
|  |  |  |  | Restructuring reserves | 50 |  |  |  | 17 |  |  |  |
|  |  |  |  | Accounts payable and accrued liabilities | 28 |  |  |  | 299 |  |  |  |
|  |  |  |  | Accrued income taxes | (275) |  |  |  | 99 |  |  |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 813 |  |  |  | 487 |  |  |  |
| Investing Activities |  |  |  |  |  |  |
| Capital expenditures | (111) |  |  |  | (170) |  |  |  |
| Acquisition of businesses, net of cash acquired | (171) |  |  |  | (112) |  |  |  |
| Other - net | 20 |  |  |  | 26 |  |  |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (262) |  |  |  | (256) |  |  |  |
| Financing Activities |  |  |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | (681) |  |  |  | 175 |  |  |  |
| Stock repurchases and retirements | (366) |  |  |  | (392) |  |  |  |
| Payment of cash dividends | (248) |  |  |  | (244) |  |  |  |
| Dividends paid to noncontrolling interests | (77) |  |  |  | (3) |  |  |  |
| Other - net | (1) |  |  |  | 49 |  |  |  |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (1,373) |  |  |  | (415) |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (75) |  |  |  | (95) |  |  |  |
| Decrease in cash, cash equivalents and restricted cash | $ | (897) |  |  |  | $ | (279) |  |  |  |

[0000833444-23-000028:8k_2_02:95]
Page 12 of 18

[0000833444-23-000028:8k_2_02:96]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Nine Months Ended June 30, |
|  |  |  |  |  |  | 2023 |  |  | 2022 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI | $ | 1,300 |  |  |  | $ | 771 |  |
| Income attributable to noncontrolling interests | 152 |  |  |  | 143 |  |
| Net income | 1,452 |  |  |  | 914 |  |
| Adjustments to reconcile net income to cash provided (used) by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 621 |  |  |  | 633 |  |
|  |  | Pension and postretirement benefit expense (income) | (23) |  |  |  | 8 |  |
|  |  | Pension and postretirement contributions | (38) |  |  |  | (83) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (27) |  |  |  | (25) |  |
|  |  | Deferred income taxes | (270) |  |  |  | (241) |  |
|  |  | Non-cash restructuring and impairment costs | 701 |  |  |  | 430 |  |
|  |  | Other - net | (12) |  |  |  | 32 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (667) |  |  |  | (637) |  |
|  |  |  |  | Inventories | (383) |  |  |  | (761) |  |
|  |  |  |  | Other assets | (214) |  |  |  | (276) |  |
|  |  |  |  | Restructuring reserves | 33 |  |  |  | (2) |  |
|  |  |  |  | Accounts payable and accrued liabilities | (127) |  |  |  | 788 |  |
|  |  |  |  | Accrued income taxes | (215) |  |  |  | 31 |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 831 |  |  |  | 811 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (366) |  |  |  | (430) |  |
| Acquisition of businesses, net of cash acquired | (260) |  |  |  | (236) |  |
| Other - net | 50 |  |  |  | 78 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (576) |  |  |  | (588) |  |
| Financing Activities |  |  |  |  |
| Increase in short and long-term debt - net | 387 |  |  |  | 2,234 |  |
| Stock repurchases and retirements | (613) |  |  |  | (1,427) |  |
| Payment of cash dividends | (729) |  |  |  | (674) |  |
| Dividends paid to noncontrolling interests | (149) |  |  |  | (121) |  |
| Other - net | (7) |  |  |  | 17 |  |
|  |  |  |  |  | Cash provided (used) by financing activities from continuing operations | (1,111) |  |  |  | 29 |  |
| Discontinued Operations - Cash used by operating activities | — |  |  |  | (4) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (67) |  |  |  | (49) |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | $ | (923) |  |  |  | $ | 199 |  |

[0000833444-23-000028:8k_2_02:97]
Page 13 of 18

[0000833444-23-000028:8k_2_02:98]
FOOTNOTES

[0000833444-23-000028:8k_2_02:99]
1. Financial Summary

[0000833444-23-000028:8k_2_02:100]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans, restructuring and impairment costs and net financing charges.

[0000833444-23-000028:8k_2_02:101]
| (in millions; unaudited) | Three Months Ended June 30, |
|  | 2023 |  | 2022 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 385 |  |  | $ | 385 |  |  | $ | 260 |  |  | $ | 260 |  |
| Building Solutions EMEA/LA | 90 |  |  | 90 |  |  | 83 |  |  | 83 |  |
| Building Solutions Asia Pacific | 102 |  |  | 102 |  |  | 85 |  |  | 85 |  |
| Global Products | 593 |  |  | 593 |  |  | 570 |  |  | 570 |  |
| Segment EBITA | 1,170 |  |  | 1,170 |  |  | 998 |  |  | 998 |  |
| Corporate expenses (2) | (122) |  |  | (78) |  |  | (96) |  |  | (87) |  |
| Amortization of intangible assets (3) | (111) |  |  | (111) |  |  | (102) |  |  | (102) |  |
| Net mark-to-market gains (losses) (4) | 17 |  |  | — |  |  | (126) |  |  | — |  |
| Restructuring and impairment costs (5) | (81) |  |  | — |  |  | (121) |  |  | — |  |
| EBIT (6) | 873 |  |  | 981 |  |  | 553 |  |  | 809 |  |
| EBIT margin (6) | 12.2 | % |  | 13.8 | % |  | 8.4 | % |  | 12.2 | % |
| Net financing charges | (80) |  |  | (80) |  |  | (49) |  |  | (49) |  |
| Income before income taxes | 793 |  |  | 901 |  |  | 504 |  |  | 760 |  |
| Income tax benefit (provision) (7) | 329 |  |  | (122) |  |  | (61) |  |  | (102) |  |
| Net income | 1,122 |  |  | 779 |  |  | 443 |  |  | 658 |  |
| Income attributable to noncontrolling interests (8) | (73) |  |  | (73) |  |  | (64) |  |  | (64) |  |
| Net income attributable to JCI | $ | 1,049 |  |  | $ | 706 |  |  | $ | 379 |  |  | $ | 594 |  |

[0000833444-23-000028:8k_2_02:102]
| (in millions; unaudited) | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 967 |  |  | $ | 967 |  |  | $ | 745 |  |  | $ | 745 |  |
| Building Solutions EMEA/LA | 234 |  |  | 234 |  |  | 266 |  |  | 277 |  |
| Building Solutions Asia Pacific | 249 |  |  | 249 |  |  | 227 |  |  | 227 |  |
| Global Products | 1,463 |  |  | 1,473 |  |  | 1,283 |  |  | 1,240 |  |
| Segment EBITA | 2,913 |  |  | 2,923 |  |  | 2,521 |  |  | 2,489 |  |
| Corporate expenses (2) | (362) |  |  | (261) |  |  | (226) |  |  | (217) |  |
| Amortization of intangible assets (3) | (319) |  |  | (319) |  |  | (326) |  |  | (313) |  |
| Net mark-to-market gains (losses) (4) | 16 |  |  | — |  |  | (158) |  |  | — |  |
| Restructuring and impairment costs (5) | (844) |  |  | — |  |  | (554) |  |  | — |  |
| EBIT (6) | 1,404 |  |  | 2,343 |  |  | 1,257 |  |  | 1,959 |  |
| EBIT margin (6) | 7.1 | % |  | 11.8 | % |  | 6.8 | % |  | 10.5 | % |
| Net financing charges | (218) |  |  | (218) |  |  | (153) |  |  | (153) |  |
| Income before income taxes | 1,186 |  |  | 2,125 |  |  | 1,104 |  |  | 1,806 |  |
| Income tax benefit (provision) (7) | 266 |  |  | (287) |  |  | (190) |  |  | (243) |  |
| Net income | 1,452 |  |  | 1,838 |  |  | 914 |  |  | 1,563 |  |
| Income attributable to noncontrolling interests (8) | (152) |  |  | (152) |  |  | (143) |  |  | (148) |  |
| Net income attributable to JCI | $ | 1,300 |  |  | $ | 1,686 |  |  | $ | 771 |  |  | $ | 1,415 |  |

[0000833444-23-000028:8k_2_02:103]
(1) The Company's press release contains financial information regarding total segment EBITA, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted segment EBITA excludes other non-recurring items that are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-23-000028:8k_2_02:104]
Page 14 of 18

[0000833444-23-000028:8k_2_02:105]
A reconciliation of segment EBITA to net income is shown earlier within this footnote. For the three months ended June 30, 2023 and 2022, there were no items excluded from the calculation of adjusted segment EBITA. The following is the nine months ended June 30, 2023 and 2022 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-23-000028:8k_2_02:106]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building Solutions Asia Pacific |  | Total Building Solutions |  | Global Products |  | ConsolidatedJCI plc |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Segment EBITA as reported | $967 |  | $745 |  | $234 |  | $266 |  | $249 |  | $227 |  | $1,450 |  | $1,238 |  | $1,463 |  | $1,283 |  | $2,913 |  | $2,521 |
| Segment EBITA margin as reported (9) | 12.8 | % |  | 10.9 | % |  | 7.7 | % |  | 9.3 | % |  | 12.2 | % |  | 11.6 | % |  | 11.5 | % |  | 10.6 | % |  | 20.2 | % |  | 18.5 | % |  | 14.6 | % |  | 13.6 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Silent-Aire earn-out adjustment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (30) |  |  | (43) |  |  | (30) |  |  | (43) |  |
| Warehouse fire loss | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 40 |  |  | — |  |  | 40 |  |  | — |  |
| Charges attributable to the suspension of operations in Russia | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Adjusted segment EBITA | $967 |  | $745 |  | $234 |  | $277 |  | $249 |  | $227 |  | $1,450 |  | $1,249 |  | $1,473 |  | $1,240 |  | $2,923 |  | $2,489 |
| Adjusted segment EBITA margin (9) | 12.8 | % |  | 10.9 | % |  | 7.7 | % |  | 9.7 | % |  | 12.2 | % |  | 11.6 | % |  | 11.5 | % |  | 10.7 | % |  | 20.4 | % |  | 17.9 | % |  | 14.7 | % |  | 13.4 | % |

[0000833444-23-000028:8k_2_02:107]
(2) Adjusted Corporate expenses for the three and nine months ended June 30, 2023 excludes certain transaction/separation costs of $44 million and $101 million, respectively. Adjusted Corporate expenses for the three and nine months ended June 30, 2022 excludes $9 million of transaction/separation costs.

[0000833444-23-000028:8k_2_02:108]
(3) Adjusted amortization of intangible assets for the nine months ended June 30, 2022 excludes nonrecurring intangible asset amortization related to Silent-Aire purchase accounting of $13 million.

[0000833444-23-000028:8k_2_02:109]
(4) Adjusted results for the three and nine months ended June 30, 2023 exclude net mark-to-market gains on restricted asbestos investments and pension and postretirement plans of $17 million and $16 million, respectively. The three and nine months ended June 30, 2022 exclude net mark-to-market losses on restricted asbestos investments and pension and postretirement plans of $126 million and $158 million, respectively.

[0000833444-23-000028:8k_2_02:110]
(5) Adjusted results for the three and nine months ended June 30, 2023 exclude restructuring and impairment costs of $81 million and $844 million, respectively. The restructuring actions and impairment costs for the three and nine months ended June 30, 2023 are related primarily to workforce reductions, impairment of goodwill attributable to the Company's Silent-Aire reporting unit, impairment of assets associated with businesses previously classified as held for sale and other asset impairments. Adjusted results for the three and nine months ended June 30, 2022 exclude restructuring and impairment costs of $121 million and $554 million, respectively. The restructuring actions and impairment costs for the three and nine months ended June 30, 2022 are related primarily to the impairment of assets associated with a business classified or previously classified as held for sale, workforce reductions and other asset impairments.

[0000833444-23-000028:8k_2_02:111]
(6) Management defines earnings before interest and taxes (EBIT) as income before net financing charges, income taxes and noncontrolling interests. EBIT margin is defined as EBIT divided by net sales. EBIT and EBIT margin are non-GAAP performance measures. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company. A reconciliation of EBIT to net income is shown earlier within this footnote.

[0000833444-23-000028:8k_2_02:112]
(7) Adjusted income tax provision for the three months ended June 30, 2023 excludes net tax benefits related to adjustments to reserves for uncertain tax positions of $438 million and the net tax effect of other pre-tax adjusting items of $13 million. Adjusted income tax provision for the nine months ended June 30, 2023 excludes net tax benefits related to adjustments to reserves for uncertain tax positions of $438 million and the net tax effect of other pre-tax adjusting items of $115 million. Adjusted income tax provision for the three and nine months ended June 30, 2022 excludes the net tax benefit of pre-tax adjusting items of $41 million and $53 million, respectively.

[0000833444-23-000028:8k_2_02:113]
(8) Adjusted income from continuing operations attributable to noncontrolling interests for the nine months ended June 30, 2022 excludes $5 million impact from restructuring and impairment costs.

[0000833444-23-000028:8k_2_02:114]
(9) Segment EBITA margin is defined as segment EBITA divided by segment net sales, as disclosed in the Company's press release.

[0000833444-23-000028:8k_2_02:115]
The Company's press release and earnings presentation include forward-looking statements regarding organic revenue growth, adjusted segment EBITA margin improvement, free cash flow and adjusted EPS, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as mark-to-market adjustments. Organic revenue growth excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s fiscal 2023 fourth quarter and full year GAAP financial results.

[0000833444-23-000028:8k_2_02:116]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-23-000028:8k_2_02:117]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items shown in the table below are excluded because these items are not considered to be directly related to the underlying operating performance of the Company. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-23-000028:8k_2_02:118]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-23-000028:8k_2_02:119]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc |  |
|  | Three Months Ended |  | Nine Months Ended |  |
|  | June 30, |  | June 30, |  |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |
| Earnings per share as reported for JCI plc | $ | 1.53 |  |  | $ | 0.55 |  |  | $ | 1.89 |  |  | $ | 1.10 |  |  |
| Adjusting items: |  |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (0.02) |  |  | 0.18 |  |  | (0.02) |  |  | 0.22 |  |  |
| Related tax impact | 0.01 |  |  | (0.05) |  |  | — |  |  | (0.06) |  |  |
| Restructuring and impairment costs | 0.12 |  |  | 0.17 |  |  | 1.23 |  |  | 0.79 |  |  |
| Related tax impact | (0.02) |  |  | (0.02) |  |  | (0.14) |  |  | (0.04) |  |  |
| NCI impact of restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (0.01) |  |  |
| Silent-Aire other nonrecurring costs | — |  |  | — |  |  | — |  |  | 0.02 |  |  |
| Transaction/separation costs | 0.06 |  |  | 0.01 |  |  | 0.15 |  |  | 0.01 |  |  |
| Related tax impact | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |  |
| Silent-Aire earn-out adjustment | — |  |  | — |  |  | (0.04) |  |  | (0.06) |  |  |
| Warehouse fire loss | — |  |  | — |  |  | 0.06 |  |  | — |  |  |
| Related tax impact | — |  |  | — |  |  | (0.01) |  |  | — |  |  |
| Charges attributable to the suspension of operations in Russia | — |  |  | — |  |  | — |  |  | 0.01 |  |  |
| Discrete tax items | (0.64) |  |  | 0.01 |  |  | (0.64) |  |  | 0.03 |  |  |
| Adjusted earnings per share for JCI plc* | $ | 1.03 |  |  | $ | 0.85 |  |  | $ | 2.45 |  |  | $ | 2.01 |  |  |

[0000833444-23-000028:8k_2_02:120]
* May not sum due to rounding

[0000833444-23-000028:8k_2_02:121]
Page 15 of 18

[0000833444-23-000028:8k_2_02:122]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-23-000028:8k_2_02:123]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, |  | June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 683.3 |  |  | 692.2 |  |  | 685.7 |  |  | 698.6 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |
| and unvested performance share awards | 2.9 |  |  | 2.7 |  |  | 3.1 |  |  | 3.8 |  |
| Diluted weighted average shares outstanding | 686.2 |  |  | 694.9 |  |  | 688.8 |  |  | 702.4 |  |

[0000833444-23-000028:8k_2_02:124]
3. Organic Growth Reconciliation

[0000833444-23-000028:8k_2_02:125]
The components of the change in net sales for the three months ended June 30, 2023 versus the three months ended June 30, 2022, including organic growth, are shown below (unaudited):

[0000833444-23-000028:8k_2_02:126]
| (in millions) | Net Sales for the Three Months Ended June 30, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the Three Months EndedJune 30, 2022 |  | Acquisitions |  | Organic Growth |  | Net Sales for the Three Months EndedJune 30, 2023 |
| Building Solutions North America | $ | 2,426 |  |  | $ | — |  | — |  |  | $ | (12) |  | — |  |  | $ | 2,414 |  |  | $ | 5 |  | — |  |  | $ | 246 |  | 10 | % |  | $ | 2,665 |  | 10 | % |
| Building Solutions EMEA/LA | 952 |  |  | (4) |  | — |  |  | (2) |  | — |  |  | 946 |  |  | 10 |  | 1 | % |  | 89 |  | 9 | % |  | 1,045 |  | 10 | % |
| Building Solutions Asia Pacific | 665 |  |  | — |  | — |  |  | (35) |  | -5 | % |  | 630 |  |  | 8 |  | 1 | % |  | 98 |  | 16 | % |  | 736 |  | 11 | % |
| Total Building Solutions | 4,043 |  |  | (4) |  | — |  |  | (49) |  | -1 | % |  | 3,990 |  |  | 23 |  | 1 | % |  | 433 |  | 11 | % |  | 4,446 |  | 10 | % |
| Global Products | 2,571 |  |  | — |  | — |  |  | (51) |  | -2 | % |  | 2,520 |  |  | 5 |  | — |  |  | 162 |  | 6 | % |  | 2,687 |  | 5 | % |
| Total net sales | $ | 6,614 |  |  | $ | (4) |  | — |  |  | $ | (100) |  | -2 | % |  | $ | 6,510 |  |  | $ | 28 |  | — |  |  | $ | 595 |  | 9 | % |  | $ | 7,133 |  | 8 | % |

[0000833444-23-000028:8k_2_02:127]
The components of the change in net sales for the nine months ended June 30, 2023 versus the nine months ended June 30, 2022, including organic growth, are shown below (unaudited):

[0000833444-23-000028:8k_2_02:128]
| (in millions) | Net Sales for the Nine Months Ended June 30, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for theNine Months Ended June 30, 2022 |  | Acquisitions |  | Organic Growth |  | Net Sales for the Nine Months EndedJune 30, 2023 |
| Building Solutions North America | $ | 6,805 |  |  | $ | — |  | — |  |  | $ | (41) |  | -1 | % |  | $ | 6,764 |  |  | $ | 17 |  | — |  |  | $ | 771 |  | 11 | % |  | $ | 7,552 |  | 11 | % |
| Building Solutions EMEA/LA | 2,869 |  |  | (27) |  | -1 | % |  | (141) |  | -5 | % |  | 2,701 |  |  | 54 |  | 2 | % |  | 296 |  | 11 | % |  | 3,051 |  | 6 | % |
| Building Solutions Asia Pacific | 1,963 |  |  | — |  | — |  |  | (147) |  | -7 | % |  | 1,816 |  |  | 8 |  | — |  |  | 225 |  | 12 | % |  | 2,049 |  | 4 | % |
| Total Building Solutions | 11,637 |  |  | (27) |  | — |  |  | (329) |  | -3 | % |  | 11,281 |  |  | 79 |  | 1 | % |  | 1,292 |  | 11 | % |  | 12,652 |  | 9 | % |
| Global Products | 6,937 |  |  | — |  | — |  |  | (269) |  | -4 | % |  | 6,668 |  |  | 5 |  | — |  |  | 562 |  | 8 | % |  | 7,235 |  | 4 | % |
| Total net sales | $ | 18,574 |  |  | $ | (27) |  | — |  |  | $ | (598) |  | -3 | % |  | $ | 17,949 |  |  | $ | 84 |  | — |  |  | $ | 1,854 |  | 10 | % |  | $ | 19,887 |  | 7 | % |

[0000833444-23-000028:8k_2_02:129]
The components of the change in total service revenue for the three months ended June 30, 2023 versus the three months ended June 30, 2022, including organic growth, are shown below (unaudited):

[0000833444-23-000028:8k_2_02:130]
| (in millions) | Service Revenuefor the Three Months Ended June 30, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base Service Revenue for the Three Months Ended June 30, 2022 |  | Acquisitions |  | Organic Growth |  | Service Revenuefor the Three Months EndedJune 30, 2023 |
| Building Solutions North America | $ | 945 |  |  | $ | — |  | — |  |  | $ | (4) |  | — |  |  | $ | 941 |  |  | $ | 5 |  | 1 | % |  | $ | 83 |  | 9 | % |  | $ | 1,029 |  | 9 | % |
| Building Solutions EMEA/LA | 415 |  |  | — |  | — |  |  | (7) |  | -2 | % |  | 408 |  |  | 3 |  | 1 | % |  | 63 |  | 15 | % |  | 474 |  | 14 | % |
| Building Solutions Asia Pacific | 172 |  |  | — |  | — |  |  | (7) |  | -4 | % |  | 165 |  |  | 3 |  | 2 | % |  | 31 |  | 19 | % |  | 199 |  | 16 | % |
| Total Building Solutions | 1,532 |  |  | — |  | — |  |  | (18) |  | -1 | % |  | 1,514 |  |  | 11 |  | 1 | % |  | 177 |  | 12 | % |  | 1,702 |  | 11 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 1,532 |  |  | $ | — |  | — |  |  | $ | (18) |  | -1 | % |  | $ | 1,514 |  |  | $ | 11 |  | 1 | % |  | $ | 177 |  | 12 | % |  | $ | 1,702 |  | 11 | % |

[0000833444-23-000028:8k_2_02:131]
The components of the change in total service revenue for the nine months ended June 30, 2023 versus the nine months ended June 30, 2022, including organic growth, are shown below (unaudited):

[0000833444-23-000028:8k_2_02:132]
| (in millions) | Service Revenue for the Nine Months EndedJune 30, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base Service Revenue for the Nine Months Ended June 30, 2022 |  | Acquisitions |  | Organic Growth |  | Service Revenuefor the Nine Months EndedJune 30, 2023 |
| Building Solutions North America | $ | 2,682 |  |  | $ | — |  | — |  |  | $ | (15) |  | -1 | % |  | $ | 2,667 |  |  | $ | 17 |  | 1 | % |  | $ | 227 |  | 9 | % |  | $ | 2,911 |  | 9 | % |
| Building Solutions EMEA/LA | 1,252 |  |  | (12) |  | -1 | % |  | (72) |  | -6 | % |  | 1,168 |  |  | 10 |  | 1 | % |  | 168 |  | 14 | % |  | 1,346 |  | 8 | % |
| Building Solutions Asia Pacific | 521 |  |  | — |  | — |  |  | (36) |  | -7 | % |  | 485 |  |  | 3 |  | 1 | % |  | 72 |  | 15 | % |  | 560 |  | 7 | % |
| Total Building Solutions | 4,455 |  |  | (12) |  | — |  |  | (123) |  | -3 | % |  | 4,320 |  |  | 30 |  | 1 | % |  | 467 |  | 11 | % |  | 4,817 |  | 8 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 4,455 |  |  | $ | (12) |  | — |  |  | $ | (123) |  | -3 | % |  | $ | 4,320 |  |  | $ | 30 |  | 1 | % |  | $ | 467 |  | 11 | % |  | $ | 4,817 |  | 8 | % |

[0000833444-23-000028:8k_2_02:133]
Page 16 of 18

[0000833444-23-000028:8k_2_02:134]
The components of the change in total install revenue for the three months ended June 30, 2023 versus the three months ended June 30, 2022, including organic growth, are shown below (unaudited):

[0000833444-23-000028:8k_2_02:135]
| (in millions) | Install Revenue for the Three Months EndedJune 30, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base Install Revenue for the Three Months Ended June 30, 2022 |  | Acquisitions |  | Organic Growth |  | Install Revenuefor the Three Months EndedJune 30, 2023 |
| Building Solutions North America | $ | 1,481 |  |  | $ | — |  | — |  |  | $ | (8) |  | -1 | % |  | $ | 1,473 |  |  | $ | — |  | — |  |  | $ | 163 |  | 11 | % |  | $ | 1,636 |  | 10 | % |
| Building Solutions EMEA/LA | 537 |  |  | (3) |  | -1 | % |  | 5 |  | 1 | % |  | 539 |  |  | 7 |  | 1 | % |  | 25 |  | 5 | % |  | 571 |  | 6 | % |
| Building Solutions Asia Pacific | 493 |  |  | — |  | — |  |  | (28) |  | -6 | % |  | 465 |  |  | 5 |  | 1 | % |  | 67 |  | 14 | % |  | 537 |  | 9 | % |
| Total Building Solutions | 2,511 |  |  | (3) |  | — |  |  | (31) |  | -1 | % |  | 2,477 |  |  | 12 |  | — |  |  | 255 |  | 10 | % |  | 2,744 |  | 9 | % |
| Global Products | 2,571 |  |  | — |  | — |  |  | (51) |  | -2 | % |  | 2,520 |  |  | 5 |  | — |  |  | 162 |  | 6 | % |  | 2,687 |  | 5 | % |
| Total install revenue | $ | 5,082 |  |  | $ | (3) |  | — |  |  | $ | (82) |  | -2 | % |  | $ | 4,997 |  |  | $ | 17 |  | — |  |  | $ | 417 |  | 8 | % |  | $ | 5,431 |  | 7 | % |

[0000833444-23-000028:8k_2_02:136]
4.   Free Cash Flow Conversion

[0000833444-23-000028:8k_2_02:137]
The Company's press release contains financial information regarding free cash flow and free cash flow conversion, which are non-GAAP performance measures. We also present below free cash flow conversion from the GAAP measure of net income attributable to JCI. Effective January 1, 2023, the Company has excluded the impact of its financing entity, JC Capital, from the calculation of free cash flow. Management believes this provides a more true representation of the Company’s operational ability to convert cash, without the contrary impact from financing activities. The impact on interim and annual periods prior to January 1, 2023 was not material. JC Capital cash flows that are excluded from the calculation of free cash flow primarily include activity associated with finance/notes receivables and inventory and/or capital expenditures related to lease arrangements. JC Capital net income that is excluded is primarily related to interest income on the finance/notes receivable and profit recognized on arrangements with sales-type lease components.

[0000833444-23-000028:8k_2_02:138]
Free cash flow is defined as cash provided (used) by operating activities, excluding JC Capital, less capital expenditures, excluding JC Capital. Free cash flow conversion from net income is defined as free cash flow divided by net income attributable to JCI. Free cash flow conversion is defined as free cash flow divided by adjusted net income attributable to JCI, excluding JC Capital. Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash. These non-GAAP measures can also be used to evaluate our ability to generate cash flow from operations and the impact that this cash flow has on our liquidity.

[0000833444-23-000028:8k_2_02:139]
The following is the three and nine months ended June 30, 2023 and 2022 calculation of free cash flow (unaudited):

[0000833444-23-000028:8k_2_02:140]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions) | June 30, 2023 |  | June 30, 2022 |  | June 30, 2023 |  | June 30, 2022 |
| Cash provided by operating activities from continuing operations | $ | 813 |  | $ | 487 |  | $ | 831 |  | $ | 811 |
| Less: JC Capital cash used by operating activities from continuing operations | (39) |  | — |  | (81) |  | — |
| Cash provided by operating activities from continuing operations, excluding JC Capital | $ | 852 |  | $ | 487 |  | $ | 912 |  | $ | 811 |
| Capital expenditures | $ | (111) |  | $ | (170) |  | $ | (366) |  | $ | (430) |
| Less: JC Capital capital expenditures | — |  | — |  | — |  | — |
| Capital expenditures, excluding JC Capital | $ | (111) |  | $ | (170) |  | $ | (366) |  | $ | (430) |
| Free cash flow | $ | 741 |  | $ | 317 |  | $ | 546 |  | $ | 381 |

[0000833444-23-000028:8k_2_02:141]
The following is the nine months ended June 30, 2023 and 2022 calculation of free cash flow conversion from net income and free cash flow conversion (unaudited):

[0000833444-23-000028:8k_2_02:142]
|  | Nine Months Ended |  |
| (in millions) | June 30, 2023 |  | June 30, 2022 |  |
| Net income attributable to JCI | $ | 1,300 |  | $ | 771 |  |
| Free cash flow conversion from net income | 42 | % |  | 49 | % |  |
| Adjusted net income attributable to JCI | $ | 1,686 |  | $ | 1,415 |  |
| Less: JC Capital net income | 12 |  | — |  |
| Adjusted net income attributable to JCI, excluding JC Capital | $ | 1,674 |  | $ | 1,415 |  |
| Free cash flow conversion | 33 | % |  | 27 | % |  |

[0000833444-23-000028:8k_2_02:143]
Page 17 of 18

[0000833444-23-000028:8k_2_02:144]
5.  Debt Ratios

[0000833444-23-000028:8k_2_02:145]
The Company's earnings presentation provides financial information regarding net debt to adjusted EBITDA, which is a non-GAAP performance measure. We also present below net debt to income before income taxes. The Company believes these ratios are useful to understanding the Company's financial condition as they provide an overview of the extent to which the Company relies on external debt financing for its funding and are a measure of risk to its shareholders. The following is the June 30, 2023, March 31, 2023, and June 30, 2022 calculation of net debt to income before income taxes and net debt to adjusted EBITDA (unaudited):

[0000833444-23-000028:8k_2_02:146]
| (in millions) | June 30, 2023 |  | March 31, 2023 |  | June 30, 2022 |  |  |
| Short-term debt and current portion of long-term debt | $ | 1,267 |  |  | $ | 2,659 |  |  | $ | 2,298 |  |  |  |
| Long-term debt | 8,497 |  |  | 7,832 |  |  | 7,194 |  |  |  |
| Total debt | 9,764 |  |  | 10,491 |  |  | 9,492 |  |  |  |
| Less: cash and cash equivalents | 1,057 |  |  | 1,975 |  |  | 1,506 |  |  |  |
| Total net debt | $ | 8,707 |  |  | $ | 8,516 |  |  | $ | 7,986 |  |  |  |
| Last twelve months income before income taxes | $ | 1,792 |  |  | $ | 1,503 |  |  | $ | 1,910 |  |  |  |
| Total net debt to income before income taxes | 4.9x |  | 5.7x |  | 4.2x |  |  |
| Last twelve months adjusted EBITDA | $ | 4,078 |  |  | $ | 3,895 |  |  | $ | 3,617 |  |  |  |
| Total net debt to adjusted EBITDA | 2.1x |  | 2.2x |  | 2.2x |  |  |

[0000833444-23-000028:8k_2_02:147]
The following is the last twelve months ended June 30, 2023, March 31, 2023, and June 30, 2022 reconciliation of income from continuing operations to adjusted EBIT and adjusted EBITDA, which are non-GAAP performance measures (unaudited):

[0000833444-23-000028:8k_2_02:148]
| (in millions) | Last Twelve MonthsEndedJune 30, 2023 |  | Last Twelve MonthsEndedMarch 31, 2023 |  | Last Twelve MonthsEndedJune 30, 2022 |  |  |
| Income from continuing operations | $ | 2,261 |  |  | $ | 1,582 |  |  | $ | 1,230 |  |  |  |
| Income tax provision (benefit) | (469) |  |  | (79) |  |  | 680 |  |  |  |
| Net financing charges | 278 |  |  | 247 |  |  | 200 |  |  |  |
| EBIT | 2,070 |  |  | 1,750 |  |  | 2,110 |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (208) |  |  | (65) |  |  | 52 |  |  |  |
| Restructuring and impairment costs | 1,011 |  |  | 1,051 |  |  | 621 |  |  |  |
| Environmental remediation and related reserves adjustment | 255 |  |  | 255 |  |  | — |  |  |  |
| Silent-Aire other nonrecurring costs | — |  |  | — |  |  | 26 |  |  |  |
| Silent-Aire earn-out adjustment | (30) |  |  | (30) |  |  | (43) |  |  |  |
| Charges attributable to the suspension of operations in Russia | — |  |  | — |  |  | 11 |  |  |  |
| Warehouse fire loss | 40 |  |  | 40 |  |  | — |  |  |  |
| Transaction/separation costs | 122 |  |  | 87 |  |  | 9 |  |  |  |
| Adjusted EBIT (1) | 3,260 |  |  | 3,088 |  |  | 2,786 |  |  |  |
| Depreciation and amortization | 818 |  |  | 807 |  |  | 831 |  |  |  |
| Adjusted EBITDA (1) | $ | 4,078 |  |  | $ | 3,895 |  |  | $ | 3,617 |  |  |  |

[0000833444-23-000028:8k_2_02:149]
(1) The Company's definition of adjusted EBIT and adjusted EBITDA excludes special items that are not considered to be directly related to the underlying operating performance of its businesses. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-23-000028:8k_2_02:150]
6.  Income Taxes

[0000833444-23-000028:8k_2_02:151]
The Company's effective tax rate from continuing operations before consideration of net mark-to-market adjustments, restructuring and impairment costs, Silent-Aire nonrecurring intangible asset amortization and purchase accounting, charges attributable to the suspension of operations in Russia, discrete tax items, certain transaction/separation costs and warehouse fire loss for the three and nine months ending June 30, 2023 and June 30, 2022 is approximately 13.5%.

[0000833444-23-000028:8k_2_02:152]
Page 18 of 18
