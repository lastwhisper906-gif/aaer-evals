# JCI notes — 0000833444-23-000030


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-23-000030:notes:1]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2022 filed with the SEC on November 15, 2022. The results of operations for the three and nine month periods ended June 30, 2023 are not necessarily indicative of results for the Company’s 2023 fiscal year because of seasonal and other factors.

[0000833444-23-000030:notes:2]
Assets and liabilities of the Global Retail business which were classified as held for sale in prior periods have been reclassified to conform with the current period presentation. Refer to Note 4, "Assets and Liabilities Held for Sale," of the notes to the consolidated financial statements for further details.

[0000833444-23-000030:notes:3]
[same as prior period, unchanged from 0000833444-23-000014:notes:2]

[0000833444-23-000030:notes:4]
[same as prior period, unchanged from 0000833444-23-000014:notes:3]

[0000833444-23-000030:notes:5]
[same as prior period, unchanged from 0000833444-23-000014:notes:4]

[0000833444-23-000030:notes:6]
[same as prior period, unchanged from 0000833444-23-000014:notes:5]

[0000833444-23-000030:notes:7]
[same as prior period, unchanged from 0000833444-23-000014:notes:6]

[0000833444-23-000030:notes:8]
[same as prior period, unchanged from 0000833444-23-000014:notes:7]

[0000833444-23-000030:notes:9]
[same as prior period, unchanged from 0000833444-23-000014:notes:8]

[0000833444-23-000030:notes:10]
Restricted cash relates to amounts restricted for payment of asbestos liabilities and certain litigation and environmental matters. Restricted cash is recorded primarily within other current assets in the consolidated statements of financial position and totaled $86 million and $35 million at June 30, 2023 and September 30, 2022, respectively.

[0000833444-23-000030:notes:11]
Prior Period Revision – Statement of Cash Flows
The Company revised the amounts previously reported as net proceeds from borrowings with maturities less than three months and proceeds from debt for certain short-term debt transactions that were incorrectly presented on a net basis within the financing activities section of the consolidated statements of cash flows for the nine months ended June 30, 2022. Interim and annual amounts for the year ended September 30, 2022 and annual amounts for the years ended September 30, 2021 and 2020 were similarly impacted. Prior period amounts will be revised with future Quarterly Reports on Form 10-Q and Annual Report on Form 10-K filings. Cash provided by financing activities and the total increase (decrease) in cash, cash equivalents and restricted cash were unchanged for all affected periods. The Company does not believe the impact of incorrect presentation is material to any periods.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000833444-23-000030:notes:12]
New Accounting Standards
Recently Issued Accounting Pronouncements

[0000833444-23-000030:notes:13]
In September 2022, the FASB issued ASU 2022-04, "Disclosure of Supplier Finance Program Obligations," which is intended to enhance the transparency surrounding the use of supplier finance programs. Supplier finance programs may also be referred to as reverse factoring, payables finance, or structured payables arrangements. The amendments require a buyer that uses supplier finance programs to make annual disclosures about the program’s key terms, the balance sheet presentation of related amounts, the confirmed amount outstanding at the end of the period, and associated rollforward information. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company expects to adopt the new disclosures, other than the rollforward disclosure, as required at the beginning of fiscal 2024. The rollforward disclosures will be adopted as required at the beginning of fiscal 2025.

[0000833444-23-000030:notes:14]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-23-000030:notes:15]
Acquisitions and Divestitures
During the first nine months of fiscal 2023, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $306 million, of which $260 million was paid as of June 30, 2023. In connection with the acquisitions, the Company recorded goodwill of $51 million within the Building Solutions Asia Pacific segment, $12 million within the Building Solutions EMEA/LA segment and $121 million within the Global Products segment. These amounts are based on the preliminary purchase price allocations and are subject to change as the purchase price allocations are completed.

[0000833444-23-000030:notes:16]
The Company completed no divestitures during the first nine months of fiscal 2023.

[0000833444-23-000030:notes:17]
During the first nine months of fiscal 2022, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $287 million, of which $236 million was paid as of June 30, 2022. In connection with the acquisitions, the Company recorded goodwill of $45 million within the Building Solutions Asia Pacific segment, $68 million within the Building Solutions EMEA/LA segment, $24 million within the Building Solutions North America segment and $45 million with the Global Products segment.

[0000833444-23-000030:notes:18]
During the first nine months of fiscal 2022, the Company completed a divestiture within the Buildings Solutions EMEA/LA segment. The selling price, net of cash divested, was $18 million, of which $16 million was received as of June 30, 2022. In connection with the divestiture, the Company reduced goodwill by $5 million.

[0000833444-23-000030:notes:19]
Acquisitions and divestitures were not material individually or in the aggregate during the first nine months of fiscal 2023 or 2022.

[0000833444-23-000030:notes:20]
Subsequent Event

[0000833444-23-000030:notes:21]
On July 13, 2023, the Company acquired FM:Systems, a leading digital workplace management and Internet of Things (IoT) solutions provider for facilities and real estate professionals. The base purchase price for the transaction was $455 million, plus up to $155 million in payments to be made subject to the achievement of post-closing earn-out milestones over the next two years. Preliminary purchase accounting is not yet available due to the timing of close of the transaction.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-23-000030:notes:22]
Assets and Liabilities Held for Sale
During fiscal 2022, the Company determined that its Global Retail business within its Building Solutions North America, Building Solutions Asia Pacific and Building Solutions EMEA/LA segments and a business within the Building Solutions Asia Pacific segment both met the criteria to be classified as held for sale. The assets and liabilities of both businesses were presented as held for sale in the Company's consolidated statements of financial position as of September 30, 2022 and in previously filed quarterly financial statements. Assets and liabilities held for sale are recorded at the lower of carrying value or fair value, less costs to sell in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets." The carrying amount of any assets, including goodwill, that are part of the disposal group, but not in the scope of ASC 360-10, are tested for impairment under the relevant guidance prior to measuring the disposal group at fair value, less cost to sell. The businesses did not meet the criteria to be classified as discontinued operations as neither planned divestiture represented a strategic shift that would have a major effect on the Company's operations and financial results.

[0000833444-23-000030:notes:23]
During the third quarter of fiscal 2023, the Company concluded that its Global Retail business no longer met the criteria to be classified as held for sale, as it is no longer probable that it will be sold in the next 12 months. As a result, the assets and liabilities were reclassified to held and used on the consolidated statements of financial position as of both June 30, 2023 and September 30, 2022. The net assets were reclassified to held and used at the lower of fair value or adjusted carrying value in the current period, and due to prior period impairment charges recorded, there was no impact to the consolidated statements of income as a result of this reclassification.

[0000833444-23-000030:notes:24]
No impairment charges were recorded during the three months ended June 30, 2023. During the nine months ended June 30, 2023, the Company recorded impairment charges for the Global Retail business of $438 million and the Building Solutions Asia Pacific segment of $60 million. The impairment charges were primarily due to reductions in the estimated fair values of the businesses to be disposed as a result of negotiations with potential buyers and were recorded within restructuring and impairment costs in the consolidated statements of income. 
The business in the Building Solutions Asia Pacific segment was sold on August 1, 2023. The net assets were not significant to the consolidated statements of financial position. The Company is finalizing its accounting for the transaction and any gain or loss on sale is not expected to be significant.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-23-000030:notes:25]
[same as prior period, unchanged from 0000833444-23-000014:notes:23]

[0000833444-23-000030:notes:26]
[same as prior period, unchanged from 0000833444-23-000014:notes:24]

[0000833444-23-000030:notes:27]
|  |  | Three Months Ended June 30, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,636 |  |  | $ | 1,029 |  |  | $ | 2,665 |  |  | $ | 1,481 |  |  | $ | 945 |  |  | $ | 2,426 |  |
| Building Solutions EMEA/LA |  | 571 |  |  | 474 |  |  | 1,045 |  |  | 537 |  |  | 415 |  |  | 952 |  |
| Building Solutions Asia Pacific |  | 537 |  |  | 199 |  |  | 736 |  |  | 493 |  |  | 172 |  |  | 665 |  |
| Global Products |  | 2,687 |  |  | — |  |  | 2,687 |  |  | 2,571 |  |  | — |  |  | 2,571 |  |
| Total |  | $ | 5,431 |  |  | $ | 1,702 |  |  | $ | 7,133 |  |  | $ | 5,082 |  |  | $ | 1,532 |  |  | $ | 6,614 |  |

[0000833444-23-000030:notes:28]
|  |  | Nine Months Ended June 30, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 4,641 |  |  | $ | 2,911 |  |  | $ | 7,552 |  |  | $ | 4,123 |  |  | $ | 2,682 |  |  | $ | 6,805 |  |
| Building Solutions EMEA/LA |  | 1,705 |  |  | 1,346 |  |  | 3,051 |  |  | 1,617 |  |  | 1,252 |  |  | 2,869 |  |
| Building Solutions Asia Pacific |  | 1,489 |  |  | 560 |  |  | 2,049 |  |  | 1,442 |  |  | 521 |  |  | 1,963 |  |
| Global Products |  | 7,235 |  |  | — |  |  | 7,235 |  |  | 6,937 |  |  | — |  |  | 6,937 |  |
| Total |  | $ | 15,070 |  |  | $ | 4,817 |  |  | $ | 19,887 |  |  | $ | 14,119 |  |  | $ | 4,455 |  |  | $ | 18,574 |  |

[0000833444-23-000030:notes:29]
[same as prior period, unchanged from 0000833444-23-000014:notes:27]

[0000833444-23-000030:notes:30]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 1,973 |  |  | $ | 1,889 |  |  | $ | 5,170 |  |  | $ | 5,030 |  |
| Fire & Security |  | 626 |  |  | 610 |  |  | 1,819 |  |  | 1,732 |  |
| Industrial Refrigeration |  | 88 |  |  | 72 |  |  | 246 |  |  | 175 |  |
| Total |  | $ | 2,687 |  |  | $ | 2,571 |  |  | $ | 7,235 |  |  | $ | 6,937 |  |

[0000833444-23-000030:notes:31]
[same as prior period, unchanged from 0000833444-23-000014:notes:29]

[0000833444-23-000030:notes:32]
[same as prior period, unchanged from 0000833444-23-000014:notes:30]

[0000833444-23-000030:notes:33]
[same as prior period, unchanged from 0000833444-23-000014:notes:31]

[0000833444-23-000030:notes:34]
|  |  | Location of contract balances |  | June 30, 2023 |  | September 30, 2022 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,080 |  |  | $ | 2,067 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 79 |  |  | 79 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 1,918 |  |  | 1,804 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 292 |  |  | 282 |  |  |  |

[0000833444-23-000030:notes:35]
For the three months ended June 30, 2023 and 2022, the Company recognized revenue of $222 million and $193 million, respectively, that was included in the beginning of period contract liability balance. For the nine months ended June 30, 2023 and 2022, the Company recognized revenue of $1,387 million and $1,252 million, respectively, that was included in the beginning of period contract liability balance

[0000833444-23-000030:notes:36]
[same as prior period, unchanged from 0000833444-23-000014:notes:34]

[0000833444-23-000030:notes:37]
[same as prior period, unchanged from 0000833444-23-000014:notes:35]

[0000833444-23-000030:notes:38]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of June 30, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $19.2 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.

[0000833444-23-000030:notes:39]
[same as prior period, unchanged from 0000833444-23-000014:notes:37]

[0000833444-23-000030:notes:40]
[same as prior period, unchanged from 0000833444-23-000014:notes:38]

[0000833444-23-000030:notes:41]
[same as prior period, unchanged from 0000833444-23-000014:notes:39]

[0000833444-23-000030:notes:42]
|  |  | June 30, 2023 |  | September 30, 2022 |  |  |
| Other current assets |  | $ | 159 |  |  | $ | 139 |  |  |  |
| Other noncurrent assets |  | 212 |  |  | 174 |  |  |  |
| Total |  | $ | 371 |  |  | $ | 313 |  |  |  |

[0000833444-23-000030:notes:43]
During the three months ended June 30, 2023 and 2022, the Company recognized amortization expense of $66 million and $48 million, respectively, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2023 and 2022, the Company recognized amortization expense of $188 million and $145 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and nine months ended June 30, 2023 and 2022.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0000833444-23-000030:notes:44]
Accounts ReceivableThe Company enters into various factoring agreements to sell certain accounts receivable to third-party financial institutions. For the majority of these agreements, for ease of administration, the Company collects customer payments related to the factored receivables on behalf of the financial institutions but otherwise maintains no continuing involvement with respect to the factored receivables. Sales of accounts receivable are reflected as a reduction of accounts receivable in the consolidated statements of financial position and the proceeds are included in cash flows from operating activities in the consolidated statements of cash flows. The Company sold $425 million and $1,261 million of accounts receivable under these factoring agreements during the three and nine months ended June 30, 2023, respectively. The Company sold $244 million and $612 million of accounts receivable under these factoring agreements during the three and nine months ended June 30, 2022, respectively. The cost of factoring such receivables was not material. Previously sold receivables still outstanding were $397 million and $476 million as of June 30, 2023 and  September 30, 2022, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-23-000030:notes:45]
[same as prior period, unchanged from 0000833444-23-000014:notes:43]

[0000833444-23-000030:notes:46]
|  | June 30, 2023 |  | September 30, 2022 |
| Raw materials and supplies | $ | 1,261 |  |  | $ | 1,040 |  |
| Work-in-process | 259 |  |  | 203 |  |
| Finished goods | 1,572 |  |  | 1,422 |  |
| Inventories | $ | 3,092 |  |  | $ | 2,665 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-23-000030:notes:47]
[same as prior period, unchanged from 0000833444-23-000014:notes:45]

[0000833444-23-000030:notes:48]
|  |  | Nine Months Ended June 30, 2023 |
|  |  | Building Solutions North America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total |
| Goodwill |  | $ | 9,630 |  |  | $ | 1,794 |  |  | $ | 1,116 |  |  | $ | 5,591 |  |  | 18,131 |  |
| Accumulated impairment loss |  | (659) |  |  | (47) |  |  | — |  |  | (75) |  |  | (781) |  |
| Balance at beginning of period |  | 8,971 |  |  | 1,747 |  |  | 1,116 |  |  | 5,516 |  |  | 17,350 |  |
| Acquisitions (1) |  | — |  |  | 12 |  |  | 51 |  |  | 121 |  |  | 184 |  |
| Impairments |  | — |  |  | — |  |  | — |  |  | (184) |  |  | (184) |  |
| Foreign currency translation and other |  | 17 |  |  | 174 |  |  | 21 |  |  | 82 |  |  | 294 |  |
| Balance at end of period |  | $ | 8,988 |  |  | $ | 1,933 |  |  | $ | 1,188 |  |  | $ | 5,535 |  |  | $ | 17,644 |  |

[0000833444-23-000030:notes:49]
[same as prior period, unchanged from 0000833444-23-000014:notes:47]

[0000833444-23-000030:notes:50]
[same as prior period, unchanged from 0000833444-23-000014:notes:48]

[0000833444-23-000030:notes:51]
forecast. Due to actual results being lower than its business plan, and the nearer term forecast being revised to reflect lower margins and earnings, the Company determined a triggering event had occurred and a quantitative test of goodwill for possible impairment was necessary. As a result of the goodwill impairment test, the Company recorded a non-cash impairment charge of $184 million within restructuring and impairment costs in the consolidated statements of income in the second quarter of fiscal 2023, which was determined by comparing the carrying amount of the reporting unit to its fair value. The Silent-Aire reporting unit has no remaining goodwill balance as of June 30, 2023. The Company used a discounted cash flow model to estimate the fair value of the reporting unit. The primary assumptions used in the model were management's internal projections of future cash flows, the weighted-average cost of capital and the long-term growth rate, which are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." There were no other triggering events requiring that an impairment assessment be conducted in the nine months ended June 30, 2023. However, it is possible that future changes in circumstances would require the Company to record additional non-cash impairment charges.

[0000833444-23-000030:notes:52]
[same as prior period, unchanged from 0000833444-23-000014:notes:50]

[0000833444-23-000030:notes:53]
|  | June 30, 2023 |  | September 30, 2022 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,479 |  |  | $ | (771) |  |  | $ | 708 |  |  | $ | 1,481 |  |  | $ | (728) |  |  | $ | 753 |  |
| Customer relationships | 2,975 |  |  | (1,451) |  |  | 1,524 |  |  | 3,011 |  |  | (1,340) |  |  | 1,671 |  |
| Miscellaneous | 878 |  |  | (422) |  |  | 456 |  |  | 949 |  |  | (425) |  |  | 524 |  |
|  | 5,332 |  |  | (2,644) |  |  | 2,688 |  |  | 5,441 |  |  | (2,493) |  |  | 2,948 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,143 |  |  | — |  |  | 2,143 |  |  | 2,207 |  |  | — |  |  | 2,207 |  |
|  | 2,143 |  |  | — |  |  | 2,143 |  |  | 2,207 |  |  | — |  |  | 2,207 |  |
| Total intangible assets | $ | 7,475 |  |  | $ | (2,644) |  |  | $ | 4,831 |  |  | $ | 7,648 |  |  | $ | (2,493) |  |  | $ | 5,155 |  |

[0000833444-23-000030:notes:54]
Amortization of other intangible assets for the three-month periods ended June 30, 2023 and 2022 was $111 million and $102 million, respectively. Amortization of other intangible assets for the nine month periods ended June 30, 2023 and 2022 was $319 million and $326 million, respectively.

[0000833444-23-000030:notes:55]
The Company tests indefinite-lived intangible assets for impairment annually as of July 31 or more frequently if events or changes in circumstances indicate the asset might be impaired. There were no triggering events requiring that an impairment assessment be conducted in the nine months ended June 30, 2023. However, it is possible that future changes in circumstances would require the Company to record additional non-cash impairment charges.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-23-000030:notes:56]
[same as prior period, unchanged from 0000833444-23-000014:notes:54]

[0000833444-23-000030:notes:57]
|  | Location of lease balances |  | June 30, 2023 |  | September 30, 2022 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,423 |  |  | $ | 1,332 |  |
| Operating lease liabilities - current | Other current liabilities |  | 321 |  |  | 288 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 1,111 |  |  | 1,040 |  |

[0000833444-23-000030:notes:58]
[same as prior period, unchanged from 0000833444-23-000014:notes:56]

[0000833444-23-000030:notes:59]
|  |  |  |  | Nine Months Ended June 30, |  |  |
|  |  |  |  |  |  | 2023 |  | 2022 |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  |  |  |  |  | $ | 347 |  |  | $ | 263 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-23-000030:notes:60]
Debt and Financing Arrangements
Short-term debt consisted of the following (in millions):

[0000833444-23-000030:notes:61]
|  | June 30, |  | September 30, |
|  | 2023 |  | 2022 |
| Bank borrowings | $ | 23 |  |  | $ | 10 |  |
| Commercial paper | — |  |  | 172 |  |
| Term loans | 163 |  |  | 487 |  |
|  | $ | 186 |  |  | $ | 669 |  |
| Weighted average interest rate on short-term debt outstanding | 3.8 | % |  | 0.5 | % |

[0000833444-23-000030:notes:62]
As of June 30, 2023, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in November 2023. As of June 30, 2023, there were no draws on the facilities.

[0000833444-23-000030:notes:63]
Financing Activity

[0000833444-23-000030:notes:64]
The Company entered into the following financing activities during the current fiscal year:

[0000833444-23-000030:notes:65]
•October 2022

[0000833444-23-000030:notes:66]
–Repaid a €200 million ($196 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5%

[0000833444-23-000030:notes:67]
–Issued a €150 million ($163 million as of March 31, 2023) term loan with an interest rate of EURIBOR plus 0.7% which is due in April 2024

[0000833444-23-000030:notes:68]
•January 2023 - Repaid $32 million of outstanding 4.625% Notes due 2023

[0000833444-23-000030:notes:69]
•March 2023

[0000833444-23-000030:notes:70]
–Repaid a €150 million ($147 million as of September 30, 2022) term loan with an interest rate of 0.0%

[0000833444-23-000030:notes:71]
–Repaid a €135 million ($133 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5%

[0000833444-23-000030:notes:72]
–Issued a €150 million ($163 million as of March 31, 2023) term loan with an interest rate of EURIBOR plus 0.4% which is due March 2024

[0000833444-23-000030:notes:73]
•May 2023 - Together with its wholly owned subsidiary, Tyco Fire & Security Finance S.C.A., co-issued an €800 million ($868 million as of June 30, 2023) bond with an interest rate of 4.25% which is due May 2035.

[0000833444-23-000030:notes:74]
Net Financing Charges

[0000833444-23-000030:notes:75]
Net financing charges consisted of the following (in millions):

[0000833444-23-000030:notes:76]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest expense, net of capitalized interest costs | $ | 79 |  |  | $ | 54 |  |  | $ | 219 |  |  | $ | 165 |  |
| Other financing charges | 13 |  |  | 6 |  |  | 34 |  |  | 16 |  |
| Interest income | (10) |  |  | (2) |  |  | (17) |  |  | (5) |  |
| Net foreign exchange results for financing activities | (2) |  |  | (9) |  |  | (18) |  |  | (23) |  |
| Net financing charges | $ | 80 |  |  | $ | 49 |  |  | $ | 218 |  |  | $ | 153 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-23-000030:notes:77]
[same as prior period, unchanged from 0000833444-23-000014:notes:68]

[0000833444-23-000030:notes:78]
[same as prior period, unchanged from 0000833444-23-000014:notes:69]

[0000833444-23-000030:notes:79]
[same as prior period, unchanged from 0000833444-23-000014:notes:70]

[0000833444-23-000030:notes:80]
[same as prior period, unchanged from 0000833444-23-000014:notes:71]

[0000833444-23-000030:notes:81]
As cash flow hedges under ASC 815, "Derivatives and Hedging," hedge gains or losses due to changes in fair value are initially recorded as a component of accumulated other comprehensive income (loss) ("AOCI") and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three and nine months ended June 30, 2023 and 2022.

[0000833444-23-000030:notes:82]
[same as prior period, unchanged from 0000833444-23-000014:notes:73]

[0000833444-23-000030:notes:83]
|  |  | Volume Outstanding as of |
| Commodity |  | June 30, 2023 |  | September 30, 2022 |
| Copper |  | 3,493 |  |  | 3,629 |  |
| Aluminum |  | 7,860 |  |  | 6,758 |  |

[0000833444-23-000030:notes:84]
In March, April and May 2023, the Company entered into forward-starting interest rate swaps with a combined notional amount of €400 million to reduce the market risk associated with changes in interest rates on future potential debt

[0000833444-23-000030:notes:85]
issuances. The swaps were terminated in May 2023 when the anticipated debt was issued. Accumulated amounts recorded in AOCI as of the date of the debt issuance are amortized to interest expense over the life of the respective debt.

[0000833444-23-000030:notes:86]
[same as prior period, unchanged from 0000833444-23-000014:notes:76]

[0000833444-23-000030:notes:87]
[same as prior period, unchanged from 0000833444-23-000014:notes:77]

[0000833444-23-000030:notes:88]
[same as prior period, unchanged from 0000833444-23-000014:notes:78]

[0000833444-23-000030:notes:89]
|  |  | June 30, |  | September 30, |
|  | 2023 |  | 2022 |
| Euro-denominated bonds designated as net investment hedges in Europe |  | € | 2.9 |  |  | € | 2.9 |  |
| Yen-denominated debt designated as a net investment hedge in Japan |  | ¥ | 30 |  |  | ¥ | 30 |  |

[0000833444-23-000030:notes:90]
[same as prior period, unchanged from 0000833444-23-000014:notes:80]

[0000833444-23-000030:notes:91]
[same as prior period, unchanged from 0000833444-23-000014:notes:81]

[0000833444-23-000030:notes:92]
[same as prior period, unchanged from 0000833444-23-000014:notes:82]

[0000833444-23-000030:notes:93]
[same as prior period, unchanged from 0000833444-23-000014:notes:83]

[0000833444-23-000030:notes:94]
|  | Derivatives and Hedging Activities Designated as Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | June 30, |  | September 30, |  | June 30, |  | September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 14 |  |  | $ | 30 |  |  | $ | 34 |  |  | $ | 24 |  |
| Total assets | $ | 14 |  |  | $ | 30 |  |  | $ | 34 |  |  | $ | 24 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 18 |  |  | $ | 24 |  |  | $ | 21 |  |  | $ | 27 |  |
| Commodity derivatives | 4 |  |  | 10 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,376 |  |  | 3,077 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,398 |  |  | $ | 3,111 |  |  | $ | 21 |  |  | $ | 27 |  |

[0000833444-23-000030:notes:95]
[same as prior period, unchanged from 0000833444-23-000014:notes:85]

[0000833444-23-000030:notes:96]
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with

[0000833444-23-000030:notes:97]
substantially all of its counterparties. The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position.

[0000833444-23-000030:notes:98]
[same as prior period, unchanged from 0000833444-23-000014:notes:87]

[0000833444-23-000030:notes:99]
[same as prior period, unchanged from 0000833444-23-000014:notes:88]

[0000833444-23-000030:notes:100]
|  |  | Fair Value of Assets |  |  |  | Fair Value of Liabilities |  |  |
|  |  | June 30, |  | September 30, |  |  |  | June 30, |  | September 30, |  |  |
|  |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |  |  |
| Gross amount recognized |  | $ | 48 |  |  | $ | 54 |  |  |  |  | $ | 3,419 |  |  | $ | 3,138 |  |  |  |
| Gross amount eligible for offsetting |  | (16) |  |  | (42) |  |  |  |  | (16) |  |  | (42) |  |  |  |
| Net amount |  | $ | 32 |  |  | $ | 12 |  |  |  |  | $ | 3,403 |  |  | $ | 3,096 |  |  |  |

[0000833444-23-000030:notes:101]
[same as prior period, unchanged from 0000833444-23-000014:notes:90]

[0000833444-23-000030:notes:102]
[same as prior period, unchanged from 0000833444-23-000014:notes:91]

[0000833444-23-000030:notes:103]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Foreign currency exchange derivatives |  | $ | 3 |  |  | $ | 3 |  |  | $ | (9) |  |  | $ | 26 |  |
| Commodity derivatives |  | (6) |  |  | (24) |  |  | 1 |  |  | (20) |  |
| Interest rate swaps |  | 1 |  |  | — |  |  | 6 |  |  | — |  |
| Total |  | $ | (2) |  |  | $ | (21) |  |  | $ | (2) |  |  | $ | 6 |  |

[0000833444-23-000030:notes:104]
[same as prior period, unchanged from 0000833444-23-000014:notes:93]

[0000833444-23-000030:notes:105]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (6) |  |  | $ | 14 |  |  | $ | (2) |  |  | $ | 25 |  |
| Commodity derivatives |  | Cost of sales |  | 1 |  |  | (4) |  |  | (7) |  |  | (9) |  |
| Interest rate swaps |  | Net financing charges |  | — |  |  | (1) |  |  | — |  |  | (2) |  |
| Total |  |  |  | $ | (5) |  |  | $ | 9 |  |  | $ | (9) |  |  | $ | 14 |  |

[0000833444-23-000030:notes:106]
[same as prior period, unchanged from 0000833444-23-000014:notes:95]

[0000833444-23-000030:notes:107]
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of GainRecognized in Income on Derivative |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (9) |  |  | $ | 1 |  |  | $ | (17) |  |  | $ | 8 |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | (54) |  |  | (16) |  |  | (118) |  |  | 72 |  |
| Equity swap |  | Selling, general and administrative |  | — |  |  | (4) |  |  | — |  |  | (5) |  |
| Total |  |  |  | $ | (63) |  |  | $ | (19) |  |  | $ | (135) |  |  | $ | 75 |  |

[0000833444-23-000030:notes:108]
Pre-tax gains (losses) on net investment hedges recorded as foreign currency translation adjustments ("CTA") within other comprehensive income (loss) were $30 million and $192 million for the three months ended June 30, 2023 and 2022, respectively. Pre-tax gains (losses) on net investment hedges recorded as CTA within other comprehensive income (loss) were $(299) million and $315 million for the nine months ended June 30, 2023 and 2022, respectively. No gains or losses were reclassified from CTA into income during the three and nine months ended June 30, 2023 and 2022.


## us-gaap:DerivativesPolicyTextBlock

[0000833444-23-000030:notes:109]
As cash flow hedges under ASC 815, "Derivatives and Hedging," hedge gains or losses due to changes in fair value are initially recorded as a component of accumulated other comprehensive income (loss) ("AOCI") and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings.The currency effects of the debt obligations are reflected in AOCI attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company's net investments globally.The Company holds certain foreign currency forward contracts not designated as hedging instruments under ASC 815 to hedge foreign currency exposure resulting from monetary assets and liabilities denominated in nonfunctional currencies.  The changes in fair value of these foreign currency forward exchange derivatives are recorded in the consolidated statements of income where they offset foreign currency transactional gains and losses on the nonfunctional currency denominated assets and liabilities being hedged.The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with 
substantially all of its counterparties. The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-23-000030:notes:110]
[same as prior period, unchanged from 0000833444-23-000014:notes:99]

[0000833444-23-000030:notes:111]
[same as prior period, unchanged from 0000833444-23-000014:notes:100]

[0000833444-23-000030:notes:112]
[same as prior period, unchanged from 0000833444-23-000014:notes:101]

[0000833444-23-000030:notes:113]
[same as prior period, unchanged from 0000833444-23-000014:notes:102]

[0000833444-23-000030:notes:114]
[same as prior period, unchanged from 0000833444-23-000014:notes:103]

[0000833444-23-000030:notes:115]
[same as prior period, unchanged from 0000833444-23-000014:notes:104]

[0000833444-23-000030:notes:116]
[same as prior period, unchanged from 0000833444-23-000014:notes:105]

[0000833444-23-000030:notes:117]
|  | Fair Value Measurements Using: |
|  | Total as of June 30, 2023 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 48 |  |  | $ | — |  |  | $ | 48 |  |  | $ | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 46 |  |  | 46 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)(1) | 80 |  |  | 80 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)(1) | 160 |  |  | 160 |  |  | — |  |  | — |  |
| Total assets | $ | 334 |  |  | $ | 286 |  |  | $ | 48 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 39 |  |  | $ | — |  |  | $ | 39 |  |  | $ | — |  |
| Commodity derivatives | 4 |  |  | — |  |  | 4 |  |  | — |  |
| Contingent earn-out liabilities | 35 |  |  | — |  |  | — |  |  | 35 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 22 |  |  | — |  |  | — |  |  | 22 |  |
| Total liabilities | $ | 100 |  |  | $ | — |  |  | $ | 43 |  |  | $ | 57 |  |

[0000833444-23-000030:notes:118]
[same as prior period, unchanged from 0000833444-23-000014:notes:107]

[0000833444-23-000030:notes:119]
(1)  Classified as restricted investments for payment of asbestos liabilities. See Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further details.

[0000833444-23-000030:notes:120]
[same as prior period, unchanged from 0000833444-23-000014:notes:109]

[0000833444-23-000030:notes:121]
| Balance at September 30, 2022 | $ | 60 |  |  |
| Acquisitions | 36 |  |  |
| Payments | (4) |  |  |
| Reduction for change in estimates | (36) |  |  |
| Currency translation | 1 |  |  |
| Balance at June 30, 2023 | $ | 57 |  |  |

[0000833444-23-000030:notes:122]
[same as prior period, unchanged from 0000833444-23-000014:notes:111]

[0000833444-23-000030:notes:123]
[same as prior period, unchanged from 0000833444-23-000014:notes:112]

[0000833444-23-000030:notes:124]
[same as prior period, unchanged from 0000833444-23-000014:notes:113]

[0000833444-23-000030:notes:125]
[same as prior period, unchanged from 0000833444-23-000014:notes:114]

[0000833444-23-000030:notes:126]
[same as prior period, unchanged from 0000833444-23-000014:notes:115]

[0000833444-23-000030:notes:127]
Investments in exchange traded funds:  Investments in exchange traded funds are valued using a market approach based on  quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.  Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further information.

[0000833444-23-000030:notes:128]
[same as prior period, unchanged from 0000833444-23-000014:notes:117]

[0000833444-23-000030:notes:129]
The following table presents the portion of unrealized gains (losses) recognized in the consolidated statements of income that relate to equity securities still held at June 30, 2023 and 2022 (in millions):

[0000833444-23-000030:notes:130]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Deferred compensation plan assets |  | $ | 1 |  |  | $ | (7) |  |  | $ | 6 |  |  | $ | (7) |  |
| Investments in exchange traded funds |  | 11 |  |  | (61) |  |  | 34 |  |  | (67) |  |

[0000833444-23-000030:notes:131]
All of the gains (losses) on investments in exchange traded funds related to restricted investments. 
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. At June 30, 2023, the fair value of long-term debt was $8.7 billion, including public debt of $8.5 billion and other long-term debt of $0.2 billion. At September 30, 2022, the fair value of long-term debt was $7.3 billion, including public debt of $7.1 billion and other long-term debt of $0.2 billion. The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000833444-23-000030:notes:132]
[same as prior period, unchanged from 0000833444-23-000014:notes:121]

[0000833444-23-000030:notes:133]
Investments in exchange traded funds:  Investments in exchange traded funds are valued using a market approach based on  quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.  Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further information.
Contingent earn-out liabilities:  The contingent earn-out liabilities were established using a Monte Carlo simulation based on the forecasted operating results and the earn-out formula specified in the purchase agreements.The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-23-000030:notes:134]
[same as prior period, unchanged from 0000833444-23-000014:notes:123]

[0000833444-23-000030:notes:135]
[same as prior period, unchanged from 0000833444-23-000014:notes:124]

[0000833444-23-000030:notes:136]
|  | Nine Months Ended June 30, |  |  |
|  | 2023 |  |  |  | 2022 |  |  |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |
| Restricted stock/units | 1,799,240 |  |  | $ | 66.28 |  |  |  |  | 1,431,550 |  |  | $ | 75.62 |  |  |  |
| Performance shares | 339,191 |  |  | 79.54 |  |  |  |  | 482,030 |  |  | 82.88 |  |  |  |
| Stock options | 570,140 |  |  | 18.21 |  |  |  |  | 548,398 |  |  | 18.59 |  |  |  |

[0000833444-23-000030:notes:137]
[same as prior period, unchanged from 0000833444-23-000014:notes:126]

[0000833444-23-000030:notes:138]
[same as prior period, unchanged from 0000833444-23-000014:notes:127]

[0000833444-23-000030:notes:139]
|  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |
| Risk-free interest rate | 4.04% |  | 0.99% |
| Expected volatility of the Company’s stock | 33.5% |  | 30.0% |

[0000833444-23-000030:notes:140]
[same as prior period, unchanged from 0000833444-23-000014:notes:129]

[0000833444-23-000030:notes:141]
[same as prior period, unchanged from 0000833444-23-000014:notes:130]

[0000833444-23-000030:notes:142]
|  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |
| Expected life of option (years) | 5.8 |  | 6.0 |
| Risk-free interest rate | 3.59% |  | 1.35% |
| Expected volatility of the Company’s stock | 29.4% |  | 27.8% |
| Expected dividend yield on the Company’s stock | 2.10% |  | 1.71% |


## us-gaap:EarningsPerShareTextBlock

[0000833444-23-000030:notes:143]
[same as prior period, unchanged from 0000833444-23-000014:notes:132]

[0000833444-23-000030:notes:144]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net income attributable to Johnson Controls | $ | 1,049 |  |  | $ | 379 |  |  | $ | 1,300 |  |  | $ | 771 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 683.3 |  |  | 692.2 |  |  | 685.7 |  |  | 698.6 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 2.9 |  |  | 2.7 |  |  | 3.1 |  |  | 3.8 |  |
| Diluted weighted average shares outstanding | 686.2 |  |  | 694.9 |  |  | 688.8 |  |  | 702.4 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Stock options and unvested restricted stock | 0.2 |  |  | 0.6 |  |  | 0.3 |  |  | 0.3 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-23-000030:notes:145]
[same as prior period, unchanged from 0000833444-23-000014:notes:134]

[0000833444-23-000030:notes:146]
During  the three and nine months ended June 30, 2023, the Company repurchased and immediately retired $366 million and $613 million of its ordinary shares, respectively. For the three and nine months ended June 30, 2022, the Company repurchased and immediately retired $392 million and $1,427 million of its ordinary shares, respectively. As of June 30, 2023, approximately $3.0 billion remains available under the Company's share repurchase program, which was approved by the Company's Board of Directors in March 2021. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice.

[0000833444-23-000030:notes:147]
[same as prior period, unchanged from 0000833444-23-000014:notes:136]

[0000833444-23-000030:notes:148]
[same as prior period, unchanged from 0000833444-23-000014:notes:137]

[0000833444-23-000030:notes:149]
|  | Three Months Ended June 30, |
|  | 2023 |  | 2022 |
| Foreign currency translation adjustments |  |  |  |
| Balance at beginning of period | $ | (843) |  |  | $ | (343) |  |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | (25) |  |  | (298) |  |
| Balance at end of period | (868) |  |  | (641) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (3) |  |  | (4) |  |
| Current period changes in fair value (net of tax effect of $0 and $(4)) | (1) |  |  | (13) |  |
| Reclassification to income (net of tax effect of $1 and $(3))(1) | 3 |  |  | (6) |  |
| Balance at end of period | (1) |  |  | (23) |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | — |  |  | 2 |  |
| Reclassification to income (net of tax effect of $0 and $0) | (1) |  |  | — |  |
| Balance at end of period | (1) |  |  | 2 |  |
| Accumulated other comprehensive loss, end of period | $ | (870) |  |  | $ | (662) |  |

[0000833444-23-000030:notes:150]
|  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |
| Foreign currency translation adjustments |  |  |  |
| Balance at beginning of period | $ | (901) |  |  | $ | (421) |  |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | 33 |  |  | (220) |  |
| Balance at end of period | (868) |  |  | (641) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (11) |  |  | (17) |  |
| Current period changes in fair value (net of tax effect of $1 and $2) | 3 |  |  | 3 |  |
| Reclassification to income (net of tax effect of $1 and $(5))(1) | 7 |  |  | (9) |  |
| Balance at end of period | (1) |  |  | (23) |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | 1 |  |  | 4 |  |
| Reclassification to income (net of tax effect of $(1) and $(1)) | (2) |  |  | (2) |  |
| Balance at end of period | (1) |  |  | 2 |  |
| Accumulated other comprehensive loss, end of period | $ | (870) |  |  | $ | (662) |  |

[0000833444-23-000030:notes:151]
[same as prior period, unchanged from 0000833444-23-000014:notes:140]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-23-000030:notes:152]
[same as prior period, unchanged from 0000833444-23-000014:notes:141]

[0000833444-23-000030:notes:153]
|  | U.S. Pension Plans |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest cost | $ | 21 |  |  | $ | 17 |  |  | $ | 62 |  |  | $ | 38 |  |
| Expected return on plan assets | (34) |  |  | (37) |  |  | (101) |  |  | (119) |  |
| Net actuarial loss (gain) | (6) |  |  | 106 |  |  | 17 |  |  | 124 |  |
| Settlement loss | — |  |  | 2 |  |  | 1 |  |  | 3 |  |
| Net periodic benefit cost (credit) | $ | (19) |  |  | $ | 88 |  |  | $ | (21) |  |  | $ | 46 |  |

[0000833444-23-000030:notes:154]
|  | Non-U.S. Pension Plans |
|  | Three Months Ended June 30, |  | Nine Months EndedJune 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Service cost | $ | 4 |  |  | $ | 5 |  |  | $ | 11 |  |  | $ | 16 |  |
| Interest cost | 18 |  |  | 10 |  |  | 51 |  |  | 30 |  |
| Expected return on plan assets | (20) |  |  | (20) |  |  | (57) |  |  | (62) |  |
| Net actuarial gain | — |  |  | (19) |  |  | — |  |  | (20) |  |
| Settlement loss (gain) | — |  |  | (1) |  |  | — |  |  | 7 |  |
| Net periodic benefit cost (credit) | $ | 2 |  |  | $ | (25) |  |  | $ | 5 |  |  | $ | (29) |  |

[0000833444-23-000030:notes:155]
|  | Postretirement Benefits |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest cost | $ | 1 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 1 |  |
| Expected return on plan assets | (3) |  |  | (3) |  |  | (7) |  |  | (7) |  |
| Amortization of prior service credit | (1) |  |  | (1) |  |  | (3) |  |  | (3) |  |
| Net periodic benefit credit | $ | (3) |  |  | $ | (4) |  |  | $ | (7) |  |  | $ | (9) |  |

[0000833444-23-000030:notes:156]
Cumulative fiscal 2023 lump sum payouts triggered remeasurement events for certain pension plans in each quarter of fiscal 2023. During the three months ended June 30, 2023, the Company recognized net actuarial gains of $6 million, primarily due to increases in discount rates, partially offset by unfavorable asset performance. During the nine months ended June 30, 2023, the Company recognized net actuarial losses of $17 million, primarily due to net decreases in discount rates, partially offset by net favorable plan asset performance.

[0000833444-23-000030:notes:157]
Cumulative fiscal 2022 lump sum payouts triggered remeasurement events for certain pension plans in each quarter of fiscal 2022. During the three and nine months ended June 30, 2022, the Company recognized net actuarial losses of $87 million and $104 million, respectively, primarily due to unfavorable plan asset performance, partially offset by increases in discount rates.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-23-000030:notes:158]
Restructuring Costs
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to various restructuring activities as necessary. Restructuring activities generally result in charges for workforce reductions, plant closures, asset impairments and other related costs which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The Company expects the restructuring activities to reduce cost of sales and selling, general and administrative expenses ("SG&A") due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-23-000030:notes:159]
In the third quarter of fiscal 2023, the Company began developing a restructuring plan with certain actions focused on continued scaling of SG&A expenses to its planned growth. Early actions of this plan were committed to during the third quarter and charges, primarily related to workforce reductions, were recorded to restructuring and impairment costs in the consolidated statements of income, and additional restructuring charges are expected in subsequent quarters. The scope of the plan is expected to be finalized during the fourth quarter of fiscal 2023. Restructuring charges incurred during the first and second quarters of fiscal 2023 were the result of other segment and Corporate-level restructuring plans.

[0000833444-23-000030:notes:160]
Refer to Note 4, "Assets and Liabilities Held for Sale," and Note 8, "Goodwill and Other Intangible Assets," of the notes to the consolidated financial statements for disclosure of other impairment costs.

[0000833444-23-000030:notes:161]
The following table summarizes restructuring costs (in millions):

[0000833444-23-000030:notes:162]
|  | Three Months Ended June 30, 2023 |  | Nine Months Ended June 30, 2023 |  |  |
| Building Solutions North America | $ | 10 |  |  | $ | 16 |  |  |  |
| Building Solutions EMEA/LA | 40 |  |  | 61 |  |  |  |
| Building Solutions Asia Pacific | 6 |  |  | 12 |  |  |  |
| Global Products | 15 |  |  | 42 |  |  |  |
| Corporate | 10 |  |  | 31 |  |  |  |
| Total | $ | 81 |  |  | $ | 162 |  |  |  |

[0000833444-23-000030:notes:163]
The following table summarizes changes in the restructuring reserve, which is included within other current liabilities in the consolidated statements of financial position, for new restructuring actions taken in the nine months ended June 30, 2023 (in millions):

[0000833444-23-000030:notes:164]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  | Total |
| Restructuring costs | $ | 114 |  |  | $ | 20 |  |  | $ | 28 |  |  |  |  | $ | 162 |  |
| Utilized—cash | (51) |  |  | — |  |  | (15) |  |  |  |  | (66) |  |
| Utilized—noncash | — |  |  | (20) |  |  | (2) |  |  |  |  | (22) |  |
| Balance at June 30, 2023 | $ | 63 |  |  | $ | — |  |  | $ | 11 |  |  |  |  | $ | 74 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-23-000030:notes:165]
[same as prior period, unchanged from 0000833444-23-000014:notes:153]

[0000833444-23-000030:notes:166]
[same as prior period, unchanged from 0000833444-23-000014:notes:154]

[0000833444-23-000030:notes:167]
For the three months ended June 30, 2023, the Company's effective tax rate was (41.5%) and was lower than the statutory tax rate of 12.5% primarily due to reserve adjustments resulting from tax audit developments and the benefits of continuing global tax planning, partially offset by tax rate differentials.

[0000833444-23-000030:notes:168]
For the nine months ended June 30, 2023, the Company's effective tax rate was (22.4%) and was lower than the statutory tax rate of 12.5% primarily due to reserve adjustments resulting from tax audit developments and the benefits of continuing global tax planning, partially offset by the tax impact of an impairment charge and tax rate differentials.

[0000833444-23-000030:notes:169]
For the three months ended June 30, 2022, the Company's effective tax rate was 12.1% and was lower than the statutory tax rate of 12.5% primarily due to the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives, partially offset by the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestitures and tax rate differentials.

[0000833444-23-000030:notes:170]
For the nine months ended June 30, 2022, the Company's effective tax rate was 17.2% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of an impairment charge, the establishment of a deferred tax liability on the

[0000833444-23-000030:notes:171]
outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestitures and tax rate differentials, partially offset by the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives.

[0000833444-23-000030:notes:172]
[same as prior period, unchanged from 0000833444-23-000014:notes:159]

[0000833444-23-000030:notes:173]
[same as prior period, unchanged from 0000833444-23-000014:notes:160]

[0000833444-23-000030:notes:174]
[same as prior period, unchanged from 0000833444-23-000014:notes:161]

[0000833444-23-000030:notes:175]
At September 30, 2022, the Company had gross tax-effected unrecognized tax benefits of $2,537 million, of which $1,973 million, if recognized, would impact the effective tax rate. Accrued interest, net at September 30, 2022 was approximately $284 million (net of tax benefit). Interest accrued during the nine months ended June 30, 2023 and 2022 was approximately $33 million (net of tax benefit) and approximately $40 million (net of tax benefit), respectively. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-23-000030:notes:176]
During the three months ended June 30, 2023, as the result of tax audit resolutions, statute expirations, and remeasurements of ongoing controversy matters in various jurisdictions, the Company adjusted its reserve for uncertain tax positions which resulted in a $438 million net benefit to income tax expense.

[0000833444-23-000030:notes:177]
In the U.S., fiscal years 2017 through 2018 are currently under exam by the Internal Revenue Service (“IRS”) for certain legal entities and the Company intends to take any unagreed issues that may result through the administrative appeals process. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions:

[0000833444-23-000030:notes:178]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2021 |
| Germany |  | 2007 - 2021 |
| Luxembourg |  | 2017 - 2018 |
| Mexico |  | 2015 - 2017 |
| United Kingdom |  | 2014 - 2015; 2018; 2020 - 2021 |

[0000833444-23-000030:notes:179]
It is reasonably possible that tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-23-000030:notes:180]
[same as prior period, unchanged from 0000833444-23-000014:notes:166]

[0000833444-23-000030:notes:181]
The Company recorded restructuring and impairment costs of $81 million, which generated an $11 million tax benefit, during the three months ended June 30, 2023 and $121 million, which generated a $15 million tax benefit, during the three months ended June 30, 2022.

[0000833444-23-000030:notes:182]
The Company recorded restructuring and impairment costs of $844 million, which generated a $98 million tax benefit, during the nine months ended June 30, 2023 and $554 million, which generated a $29 million tax benefit, during the nine months ended June 30, 2022.

[0000833444-23-000030:notes:183]
Tax expenses and benefits for the above transactions reflect the Company’s current tax positions in the impacted jurisdictions. Refer to Note 17, “Restructuring and Related Costs,” of the notes to the consolidated financial statements for additional information.
Impacts of Tax LegislationDuring the nine months ended June 30, 2023 and 2022, tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-23-000030:notes:184]
[same as prior period, unchanged from 0000833444-23-000014:notes:172]

[0000833444-23-000030:notes:185]
[same as prior period, unchanged from 0000833444-23-000014:notes:173]

[0000833444-23-000030:notes:186]
[same as prior period, unchanged from 0000833444-23-000014:notes:174]

[0000833444-23-000030:notes:187]
[same as prior period, unchanged from 0000833444-23-000014:notes:175]

[0000833444-23-000030:notes:188]
[same as prior period, unchanged from 0000833444-23-000014:notes:176]

[0000833444-23-000030:notes:189]
[same as prior period, unchanged from 0000833444-23-000014:notes:177]

[0000833444-23-000030:notes:190]
[same as prior period, unchanged from 0000833444-23-000014:notes:178]

[0000833444-23-000030:notes:191]
|  | Net Sales |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Building Solutions North America | $ | 2,665 |  |  | $ | 2,426 |  |  | $ | 7,552 |  |  | $ | 6,805 |  |
| Building Solutions EMEA/LA | 1,045 |  |  | 952 |  |  | 3,051 |  |  | 2,869 |  |
| Building Solutions Asia Pacific | 736 |  |  | 665 |  |  | 2,049 |  |  | 1,963 |  |
| Global Products | 2,687 |  |  | 2,571 |  |  | 7,235 |  |  | 6,937 |  |
| Total net sales | $ | 7,133 |  |  | $ | 6,614 |  |  | $ | 19,887 |  |  | $ | 18,574 |  |

[0000833444-23-000030:notes:192]
|  | Segment EBITA |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Building Solutions North America | $ | 385 |  |  | $ | 260 |  |  | $ | 967 |  |  | $ | 745 |  |
| Building Solutions EMEA/LA | 90 |  |  | 83 |  |  | 234 |  |  | 266 |  |
| Building Solutions Asia Pacific | 102 |  |  | 85 |  |  | 249 |  |  | 227 |  |
| Global Products | 593 |  |  | 570 |  |  | 1,463 |  |  | 1,283 |  |
| Total segment EBITA | 1,170 |  |  | 998 |  |  | 2,913 |  |  | 2,521 |  |
| Corporate expenses | (122) |  |  | (96) |  |  | (362) |  |  | (226) |  |
| Amortization of intangible assets | (111) |  |  | (102) |  |  | (319) |  |  | (326) |  |
| Restructuring and impairment costs | (81) |  |  | (121) |  |  | (844) |  |  | (554) |  |
| Net mark-to-market adjustments | 17 |  |  | (126) |  |  | 16 |  |  | (158) |  |
| Net financing charges | (80) |  |  | (49) |  |  | (218) |  |  | (153) |  |
| Income before income taxes | $ | 793 |  |  | $ | 504 |  |  | $ | 1,186 |  |  | $ | 1,104 |  |


## us-gaap:GuaranteesTextBlock

[0000833444-23-000030:notes:193]
[same as prior period, unchanged from 0000833444-23-000014:notes:181]

[0000833444-23-000030:notes:194]
[same as prior period, unchanged from 0000833444-23-000014:notes:182]

[0000833444-23-000030:notes:195]
[same as prior period, unchanged from 0000833444-23-000014:notes:183]

[0000833444-23-000030:notes:196]
[same as prior period, unchanged from 0000833444-23-000014:notes:184]

[0000833444-23-000030:notes:197]
|  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |
| Balance at beginning of period | $ | 180 |  |  | $ | 192 |  |
| Accruals for warranties issued during the period | 99 |  |  | 82 |  |
| Settlements made (in cash or in kind) during the period | (79) |  |  | (79) |  |
| Changes in estimates to pre-existing warranties | 12 |  |  | (9) |  |
| Currency translation | 1 |  |  | (7) |  |
| Balance at end of period | $ | 213 |  |  | $ | 179 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-23-000030:notes:198]
Commitments and Contingencies
Environmental Matters

[0000833444-23-000030:notes:199]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000030:notes:200]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 38 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 214 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 252 |  |  | $ | 286 |  |

[0000833444-23-000030:notes:201]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. During the three months ended September 30, 2022, with the assistance of independent environmental consultants and taking into consideration investigation and remediation actions previously completed, new information available to the Company during the fourth quarter of fiscal 2022 and ongoing discussions with the Wisconsin Department of Natural Resources ("WDNR"), the Company completed a comprehensive long-term analysis and cost assessment related to the Company’s ongoing environmental remediation obligations. As a result of this analysis, the Company increased its accrual for environmental liabilities by $228 million in the fourth quarter of fiscal 2022, which are recorded on an undiscounted basis. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

[0000833444-23-000030:notes:202]
A substantial portion of the increase to the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to fire-fighting foams containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The increase in reserves was recorded as a result of several events that occurred in the three months ended September 30, 2022, including the completion and testing of the Groundwater Extraction and Treatment System (“GETS”) at the FTC (as further discussed below), the completion of resident surveys in Peshtigo regarding long-term drinking water solutions, correspondence with regulators on planned remediation activities, finalization of cost estimates for system upgrades and related long-term run rate costs in response to new permit requirements at the Stanton Street Facility, and the development of additional information through ongoing investigation and analysis. These events allowed the Company to develop estimates of costs associated with the long-term remediation actions expected to be performed over an estimated period of up to 20 years, including the continued operation of the GETS, the implementation of long-term drinking water solutions, continued monitoring and testing of the wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

[0000833444-23-000030:notes:203]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports, or elsewhere. In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, the WDNR approved Tyco Fire Products’ proposed GETS, a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has completed construction of the GETS, which is now in operation. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. Tyco Fire Products is also in the process of implementing a long-term drinking water solution in the form of deep aquifer private drinking wells for certain Peshtigo residents. On July 18, 2023, Tyco Fire Products announced that it plans to

[0000833444-23-000030:notes:204]
discontinue the production and sale of fluorinated firefighting foams by June 2024, including AFFF products, and will transition to non-fluorinated foam alternatives.

[0000833444-23-000030:notes:205]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency (“EPA”) to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

[0000833444-23-000030:notes:206]
PFOA, PFOS, and other PFAS compounds are being studied by EPA and other environmental and health agencies and researchers. EPA initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water and in June 2022 an updated set of interim health advisory levels for PFOA and PFOS in drinking water, as well as final health advisory levels for two other types of PFAS (PFBS and GenX chemicals). In November 2022, EPA added a class definition of PFAS to the final version of EPA's fifth Contaminant Candidate List ("CCL 5"), which is a list of substances not currently subject to national drinking water regulation, but which EPA believes may require future regulation. In March 2023, EPA announced a proposed National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR proposes establishing legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion for each of PFOA and PFOS. EPA indicated that it anticipates finalizing the regulation by the end of 2023.

[0000833444-23-000030:notes:207]
In October 2021, EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act (“CERCLA”) hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains. In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under CERCLA. In April 2023, EPA issued an Advanced Notice of Proposed Rulemaking ("ANPR") seeking input on whether it should expand the proposed rule to designate as "hazardous substances" under CERCLA: (1) seven additional PFAS; (2) the precursors to PFOA, PFOS, and the seven additional PFAS; or (3) entire categories of PFAS.

[0000833444-23-000030:notes:208]
It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial

[0000833444-23-000030:notes:209]
condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-23-000030:notes:210]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $13 million and $17 million at June 30, 2023 and September 30, 2022, respectively.

[0000833444-23-000030:notes:211]
FTC-Related Remediation and Litigation

[0000833444-23-000030:notes:212]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. In December 2022, the Governor of Wisconsin and WDNR approved a scope statement setting out parameters for the WDNR to draft a final rule regarding groundwater quality standards for PFOA and PFOS. The WDNR is now in the process of drafting the rule.

[0000833444-23-000030:notes:213]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products responded to the WDNR’s letter by requesting additional necessary information. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. Tyco Fire Products responded to the WDNR’s September 2021 notice by the December 27, 2021 deadline set by WDNR and submitted additional updates to WDNR on October 25, 2022 and February 16, 2023. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

[0000833444-23-000030:notes:214]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR’s requests. The parties are proceeding with fact discovery and the court has set a trial date of December 3, 2024. The Company is vigorously defending this civil enforcement action and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

[0000833444-23-000030:notes:215]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina. The Company plans to vigorously defend against this case and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

[0000833444-23-000030:notes:216]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. Subsequently, several additional plaintiffs have direct-filed in the MDL complaints with similar allegations. These lawsuits are presently at the beginning stages of litigation. The Company is vigorously defending these cases and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

[0000833444-23-000030:notes:217]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-23-000030:notes:218]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-23-000030:notes:219]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to the MDL. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-23-000030:notes:220]
AFFF Putative Class Actions

[0000833444-23-000030:notes:221]
Chemguard and Tyco Fire Products are named in 41 pending putative class actions in federal courts originating from 16 states and territories. All but one of these cases have been direct-filed in or transferred to the MDL and it is anticipated that the remaining case will be transferred to the MDL.

[0000833444-23-000030:notes:222]
AFFF Individual or Mass Actions

[0000833444-23-000030:notes:223]
There are more than 4,700 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 4,700 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona and Illinois.

[0000833444-23-000030:notes:224]
Tyco and Chemguard are also periodically notified by other individuals that they may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-23-000030:notes:225]
AFFF Municipal and Water Provider Cases

[0000833444-23-000030:notes:226]
Chemguard and Tyco Fire Products have been named as defendants in more than 600 cases involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 33 states. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the

[0000833444-23-000030:notes:227]
MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation. The MDL court set the first case for trial on June 5, 2023 (City of Stuart (Florida) v. 3M Co. et al.). On April 26, 2023, the parties entered a stipulation dismissing Chemguard with prejudice from the City of Stuart case, and on May 4, 2023 the parties entered into a stipulation dismissing Tyco with prejudice from the City of Stuart case. On June 5, 2023, the MDL court continued the trial date for the City of Stuart case, and the parties remaining in that case later reached settlement. The parties in the MDL are working to identify potential water provider and personal injury cases for additional bellwether phases.

[0000833444-23-000030:notes:228]
Tyco and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-23-000030:notes:229]
State or U.S. Territory Attorneys General Litigation related to AFFF

[0000833444-23-000030:notes:230]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al. No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-23-000030:notes:231]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al. (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al. (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al. (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-23-000030:notes:232]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752-000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio. The lawsuit seeks to recover costs and natural resource damages associated with the contamination. This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-23-000030:notes:233]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

[0000833444-23-000030:notes:234]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting

[0000833444-23-000030:notes:235]
from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000030:notes:236]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000030:notes:237]
In August 2020, Attorney General of the State of Michigan filed two substantially similar lawsuits—one in federal court and one in state court—against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within the State. The federal action has been transferred to the MDL, and the state court action has been removed to federal court and transferred to the MDL.

[0000833444-23-000030:notes:238]
In December 2020, the State of Mississippi filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

[0000833444-23-000030:notes:239]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

[0000833444-23-000030:notes:240]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. It is anticipated that these two cases will be removed to federal court and transferred to the MDL.

[0000833444-23-000030:notes:241]
In February 2022, the Attorney General of the State of Colorado filed a lawsuit in Colorado state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources, public health, and State property allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000030:notes:242]
In April 2022, the Attorney General of the State of Florida filed a lawsuit in Florida state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage to the State’s natural resources and public health allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000030:notes:243]
In May 2022, the Attorney General of the Commonwealth of Massachusetts filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s natural resources, property, residents, and consumers allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

[0000833444-23-000030:notes:244]
In July 2022, the Attorney General of the State of Wisconsin filed a lawsuit in Wisconsin state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage to the State’s natural resources and public health allegedly resulting, in part, from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000030:notes:245]
In November 2022, the Attorney General of the State of California filed a lawsuit in California state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the manufacture, use, marketing, or sale of PFAS-containing products, including firefighting foams, at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000030:notes:246]
In March 2023, the Attorney General of the State of Maine filed a lawsuit in Maine state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of the State’s natural resources allegedly resulting from the manufacture, distribution, release, promotion, sale, and use of PFAS-containing AFFF within the state. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000030:notes:247]
In March 2023, the Attorney General of the State of Illinois filed a lawsuit in Illinois state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of the State’s environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within the State. This complaint has been removed to federal court, and the JPML is considering Illinois's opposition to transfer to the MDL.

[0000833444-23-000030:notes:248]
In May and June 2023, eleven other states and territories filed lawsuits, ten in their respective state courts, and one direct-filed in the MDL, against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of Arizona v. The 3M Company et al.; State of Arkansas v. The 3M Company et al.; Commonwealth of Kentucky v. The 3M Company et al.; State of Maryland v. The 3M Company et al.; State of New Mexico v. The 3M Company et al.; State of Oregon v. The 3M Company et al.; Commonwealth of Puerto Rico v. The 3M Company et al.; State of Rhode Island v. The 3M Company et al.; State of Tennessee v. The 3M Company et al.; State of Texas v. The 3M Company et al.; State of Washington v. The 3M Company et al.). It is anticipated the ten state court-filed complaints will be removed to federal court and transferred to the MDL.

[0000833444-23-000030:notes:249]
In July 2023, the Attorney General of the District of Columbia filed a lawsuit in superior court in the District, against a number of manufacturers, including affiliates of the Company, with respect to PFAS damage of the District’s natural resources and public health allegedly resulting from the manufacture, distribution, release, and use of PFAS-containing AFFF within and adjacent to it (District of Columbia v. The 3M Company et al.). It is anticipated that this complaint will be removed to federal court and transferred to the MDL.

[0000833444-23-000030:notes:250]
Other AFFF Related Matters

[0000833444-23-000030:notes:251]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-23-000030:notes:252]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This complaint has been transferred to the MDL.

[0000833444-23-000030:notes:253]
In July 2023, the Fond du Lac Band of Lake Superior Chippewa (a federally recognized tribe) direct-filed a lawsuit in the MDL against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota.

[0000833444-23-000030:notes:254]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity

[0000833444-23-000030:notes:255]
available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters in the event the Company is required to pay claims. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-23-000030:notes:256]
Asbestos Matters

[0000833444-23-000030:notes:257]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-23-000030:notes:258]
The Company estimates the asbestos-related liability for pending and future claims and related defense costs on a discounted basis. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable.

[0000833444-23-000030:notes:259]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000030:notes:260]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 363 |  |  | 380 |  |
| Total asbestos-related liabilities | 421 |  |  | 438 |  |
| Other current assets | 34 |  |  | 37 |  |
| Other noncurrent assets | 283 |  |  | 263 |  |
| Total asbestos-related assets | 317 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 104 |  |  | $ | 138 |  |

[0000833444-23-000030:notes:261]
The following table presents the components of asbestos-related assets (in millions):

[0000833444-23-000030:notes:262]
|  | June 30, 2023 |  | September 30, 2022 |
| Restricted |  |  |  |
| Cash | $ | 26 |  |  | $ | 6 |  |
| Investments | 240 |  |  | 239 |  |
| Total restricted assets | 266 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 51 |  |  | 55 |  |
| Total asbestos-related assets | $ | 317 |  |  | $ | 300 |  |

[0000833444-23-000030:notes:263]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be paid by Company affiliates). Estimated asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be paid through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and

[0000833444-23-000030:notes:264]
dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-23-000030:notes:265]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-23-000030:notes:266]
Self-Insured Liabilities

[0000833444-23-000030:notes:267]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage its self-insured liabilities.

[0000833444-23-000030:notes:268]
The following table presents the location and amount of self-insured liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000030:notes:269]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 77 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 232 |  |  | 230 |  |
| Total self-insured liabilities | $ | 331 |  |  | $ | 341 |  |

[0000833444-23-000030:notes:270]
The following table presents the location and amount of insurance receivables in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000030:notes:271]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current assets | $ | 10 |  |  | $ | 10 |  |
| Other noncurrent assets | 20 |  |  | 20 |  |
| Total insurance receivables | $ | 30 |  |  | $ | 30 |  |

[0000833444-23-000030:notes:272]
Other Matters

[0000833444-23-000030:notes:273]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock

[0000833444-23-000030:notes:274]
The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):


## ecd:MtrlTermsOfTrdArrTextBlock

[0000833444-23-000030:notes:275]
On May 8, 2023, John Donofrio, the Company’s Executive Vice President and General Counsel, terminated a pre-existing Rule 10b5–1 trading arrangement (the “Donofrio 10b5-1 Plan”). The Donofrio 10b5-1 Plan was originally entered into on December 7, 2022 during the Company’s first quarter open trading window and contemplated the sale of up to 14,253 ordinary shares of Company stock issued upon the vesting of restricted stock units and performance stock units, provided that the price of Company’s ordinary shares exceeded the limit price set forth in the Donofrio 10b5-1 Plan. Prior to its termination, the Donofrio 10b5-1 Plan was scheduled to terminate upon the earlier of the sale of all shares contemplated under the Donofrio 10b5-1 Plan or December 1, 2023. No Company shares were sold under the Donofrio 10b5-1 Plan prior to its termination.

[0000833444-23-000030:notes:276]
On May 24, 2023, George Oliver, Chairman and Chief Executive Officer of the Company, entered into a Rule 10b5–1 trading arrangement with respect to 309,996 ordinary shares of Company stock issuable upon the exercise of option awards scheduled to expire in 2023 (the “Oliver 10b5-1 Plan”). The Oliver 10b5-1 Plan was executed during the Company’s most recent open trading window and is expected to become effective on or about August 23, 2023. Under the Oliver 10b5-1 Plan, the options are expected to be exercised in regular intervals between the plan’s start date and termination date, provided that the market price of the Company’s ordinary shares exceeds the exercise price of the option at the time of exercise. With respect to the options to be exercised, a portion of the ordinary shares are expected to be sold in the market to cover the exercise price and taxes associated with the exercise of the options. The remaining ordinary shares underlying the options will be sold in the open market at the times and prices specified in the plan. All transactions under the Oliver 10b5-1 Plan, if they occur, are expected to be completed by or before November 20, 2023. The Oliver 10b5-1 Plan will automatically terminate upon the earlier of the completion of all transactions contemplated under the plan or November 20, 2023.
