# JCI 8-K — 0000833444-15-000010 filed 2015-01-30

## item codes, every 8-K on or before 2015-01-30

- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2015-01-30

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-15-000010:8k_2_02:1]
EX-99.1
2
exhibit991-q115.htm
EXHIBIT 99.1 - EARNINGS RELEASE

[0000833444-15-000010:8k_2_02:2]
Exhibit 99.1 - Q115

[0000833444-15-000010:8k_2_02:3]
| Investor Contacts: |  | Media Contact: |  |
| Antonella Franzen |  | Stephen Wasdick |  |
| +1-609-720-4665 |  | +1-609-806-2262 |  |
| afranzen@tyco.com |  | swasdick@tyco.com |  |
| Leila Peters |  |  |  |
| +1-609-720-4545 |  |  |  |
| lpeters@tyco.com |  |  |  |

[0000833444-15-000010:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-15-000010:8k_2_02:5]
TYCO REPORTS FIRST QUARTER 2015 EARNINGS FROM CONTINUING OPERATIONS

[0000833444-15-000010:8k_2_02:6]
BEFORE SPECIAL ITEMS OF $0.49 PER SHARE AND GAAP EARNINGS OF $0.38 PER SHARE

[0000833444-15-000010:8k_2_02:7]
| • | Revenue of $2.5 billion increases 2% on an organic basis, led by the Global Products segment with organic growth of 10% |

[0000833444-15-000010:8k_2_02:8]
| • | Diluted EPS from continuing operations before special items increases 17% |

[0000833444-15-000010:8k_2_02:9]
| • | Announces five acquisitions during the quarter that are expected to generate a total of $240 million in revenue on an annualized basis |

[0000833444-15-000010:8k_2_02:10]
| • | Repurchases 10 million shares for $417 million during the quarter |

[0000833444-15-000010:8k_2_02:11]
| • | Provides guidance for second quarter 2015 EPS before special items of $0.48 - $0.50 |

[0000833444-15-000010:8k_2_02:12]
| • | Revises guidance for full year 2015 EPS before special items to a range of $2.30 - $2.40, adjusting for incremental $0.09 headwind from foreign currency exchange rates, offset by $0.04 benefit from recent acquisitions and additional productivity |

[0000833444-15-000010:8k_2_02:13]
(Income and EPS amounts are attributable to Tyco ordinary shareholders)

[0000833444-15-000010:8k_2_02:14]
($ millions, except per-share amounts)

[0000833444-15-000010:8k_2_02:15]
(All prior periods have been recast to reflect certain businesses as discontinued operations)

[0000833444-15-000010:8k_2_02:16]
|  |  | Q1 2015 |  | Q1 2014 |  | % Change |  |
| Revenue |  | $ | 2,479 |  |  | $ | 2,493 |  |  | (1 | )% |  |
| Segment Operating Income |  | $ | 272 |  |  | $ | 298 |  |  | (9 | )% |  |
| Operating Income |  | $ | 198 |  |  | $ | 344 |  |  | (42 | )% |  |
| Income from Continuing Operations |  | $ | 163 |  |  | $ | 246 |  |  | (34 | )% |  |
| Diluted EPS from Continuing Operations |  | $ | 0.38 |  |  | $ | 0.52 |  |  | (27 | )% |  |
| Special Items |  | $ | (0.11 | ) |  | $ | 0.10 |  |  |  |  |
| Segment Operating Income Before Special Items |  | $ | 326 |  |  | $ | 322 |  |  | 1 | % |  |
| Income from Continuing Ops Before Special Items |  | $ | 209 |  |  | $ | 198 |  |  | 6 | % |  |
| Diluted EPS from Continuing Ops Before Special Items |  | $ | 0.49 |  |  | $ | 0.42 |  |  | 17 | % |  |

[0000833444-15-000010:8k_2_02:17]
CORK, Ireland, January 30, 2015 - Tyco (NYSE: TYC) today reported $0.38 in GAAP diluted earnings per share (EPS) from continuing operations for the fiscal first quarter of 2015 and diluted EPS from continuing operations before special items of $0.49. Revenue of $2.5 billion in the quarter decreased 1% versus the prior year due to the impact of the stronger U.S. dollar against foreign currencies. Organic revenue grew 2% in the quarter, led by Global Products with a 10% increase. Service revenue grew 1% organically and installation revenue was relatively flat. Acquisitions contributed one percentage point of growth, which was partially offset by the impact of divestitures.

[0000833444-15-000010:8k_2_02:18]
“We are off to a solid start in 2015 with our sixth consecutive quarter of double digit earnings growth,” said Tyco Chief Executive Officer George R. Oliver.  “Our teams continue to execute well, with exceptional organic growth of 10% from our products businesses, which drove overall organic revenue growth of 2% and contributed to the 17% increase in earnings per share, year over year.  In addition, we committed nearly $1 billion of capital to acquisitions and share repurchases.”

[0000833444-15-000010:8k_2_02:19]
“We are making good progress in transforming our direct channel into a technology solutions provider by expanding our capabilities through organic investments and strategic acquisitions. During the quarter, we appointed Daryll Fogal as our Chief Technology Officer, we launched our new ‘Tyco On’ software solutions platform and completed or signed five acquisitions focused on key areas of growth for Tyco, including gas and flame detection, growth markets, and expanding our services platform.  These acquisitions accelerate our strategic priorities, with a focus on technology that enables innovative solutions to uniquely address customer problems utilizing our direct channel,” continued Mr. Oliver.

[0000833444-15-000010:8k_2_02:20]
"While we continue to deliver strong operating performance, the sustained strengthening of the U.S. dollar is putting additional pressure on our results. Based on current exchange rates, we have an incremental $0.09 of foreign currency headwinds on top of the $0.07 we had expected when we gave 2015 guidance in November. We are able to partially offset this incremental headwind with the benefit of recent acquisitions and additional productivity. As a result, we are updating our full year EPS guidance to a range of $2.30 to $2.40 before special items, which at the midpoint would represent an 18% year-over-year improvement," Mr. Oliver added.

[0000833444-15-000010:8k_2_02:21]
Organic revenue, free cash flow, operating income, segment operating income, and diluted EPS from continuing operations before special items are non-GAAP financial measures and are described below. For a reconciliation of these non-GAAP measures, see the attached tables. Additional schedules as well as first quarter review slides can be found in the Investor Relations section of Tyco’s website at http://investors.tyco.com.

[0000833444-15-000010:8k_2_02:22]
SEGMENT RESULTS

[0000833444-15-000010:8k_2_02:23]
The financial results presented in the tables below are in accordance with GAAP unless otherwise indicated. All dollar amounts are pre-tax and stated in millions. In fiscal year 2014, certain businesses were classified as discontinued operations. The revenue and operating income results shown below have been adjusted to reflect these changes in all periods presented. All comparisons are to the fiscal first quarter of 2014 unless otherwise indicated.

[0000833444-15-000010:8k_2_02:24]
North America Installation & Services

[0000833444-15-000010:8k_2_02:25]
|  |  | Q1 2015 |  | Q1 2014 |  | % Change |  |
| Revenue |  | $ | 951 |  |  | $ | 957 |  |  | (1 | )% |  |
| Operating Income |  | $ | 105 |  |  | $ | 117 |  |  | (10 | )% |  |
| Operating Margin |  | 11.0 | % |  | 12.2 | % |  |  |  |
| Special Items |  | $ | (26 | ) |  | $ | (12 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 131 |  |  | $ | 129 |  |  | 2 | % |  |
| Operating Margin Before Special Items |  | 13.8 | % |  | 13.5 | % |  |  |  |

[0000833444-15-000010:8k_2_02:26]
Revenue of $951 million decreased 1% due to the weakening of the Canadian dollar. Organic growth in service revenue of 1% was offset by a decline in installation revenue of 1%. Backlog of $2.5 billion increased 5% year over year and 1% on a quarter sequential basis, excluding the impact of foreign currency.

[0000833444-15-000010:8k_2_02:27]
Operating income for the quarter was $105 million and the operating margin was 11.0%. Special items of $26 million consisted primarily of restructuring charges. Before special items, operating income was $131 million and the operating margin was 13.8%. Improved execution and the benefit of restructuring and productivity initiatives were partially offset by a legal charge, which negatively impacted the operating margin by 60 basis points.

[0000833444-15-000010:8k_2_02:28]
Rest of World Installation & Services

[0000833444-15-000010:8k_2_02:29]
|  |  | Q1 2015 |  | Q1 2014 |  | % Change |  |
| Revenue |  | $ | 917 |  |  | $ | 971 |  |  | (6 | )% |  |
| Operating Income |  | $ | 69 |  |  | $ | 95 |  |  | (27 | )% |  |
| Operating Margin |  | 7.5 | % |  | 9.8 | % |  |  |  |
| Special Items |  | $ | (21 | ) |  | $ | (8 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 90 |  |  | $ | 103 |  |  | (13 | )% |  |
| Operating Margin Before Special Items |  | 9.8 | % |  | 10.6 | % |  |  |  |

[0000833444-15-000010:8k_2_02:30]
Revenue of $917 million decreased 6% compared to the prior year, driven by a 7% unfavorable impact related to changes in foreign currency exchange rates.  Organic revenue growth was relatively flat with a modest increase in both service and installation revenue.  Acquisitions contributed 2% to revenue growth, which was partially offset by the impact of divestitures.  Backlog of $2.1 billion increased 2% on a year over year and quarter sequential basis, excluding the impact of foreign currency.

[0000833444-15-000010:8k_2_02:31]
Operating income for the quarter was $69 million and the operating margin was 7.5%. Special items of $21 million consisted primarily of restructuring charges. Before special items, operating income was $90 million, and the operating margin declined 80 basis points to 9.8%, primarily due to the mix of businesses contributing to growth and a lower percentage of higher-margin service revenue.

[0000833444-15-000010:8k_2_02:32]
Global Products

[0000833444-15-000010:8k_2_02:33]
|  |  | Q1 2015 |  | Q1 2014 |  | % Change |  |
| Revenue |  | $ | 611 |  |  | $ | 565 |  |  | 8 | % |  |
| Operating Income |  | $ | 98 |  |  | $ | 86 |  |  | 14 | % |  |
| Operating Margin |  | 16.0 | % |  | 15.2 | % |  |  |  |
| Special Items |  | $ | (7 | ) |  | $ | (4 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 105 |  |  | $ | 90 |  |  | 17 | % |  |
| Operating Margin Before Special Items |  | 17.2 | % |  | 15.9 | % |  |  |  |

[0000833444-15-000010:8k_2_02:34]
Revenue of $611 million increased 8% in the quarter. Organic revenue growth of 10% was driven by strong growth across all three platforms, led by Security Products and Life Safety Products. Organic growth included a 2 percentage point benefit from increased shipments of Scott Safety Air-Pak X3s compared to the prior year. Acquisitions contributed an additional point of growth, which was more than offset by a 3% decrease related to changes in foreign currency exchange rates.

[0000833444-15-000010:8k_2_02:35]
Operating income for the quarter was $98 million and the operating margin was 16.0%. Special items of $7 million consisted primarily of restructuring charges. Before special items, operating income was $105 million and the operating margin increased 130 basis points to 17.2%. Operating leverage on increased revenue, favorable product mix and productivity benefits drove the operating margin improvement.

[0000833444-15-000010:8k_2_02:36]
OTHER ITEMS

[0000833444-15-000010:8k_2_02:37]
| • | Cash from operating activities was $96 million and free cash flow was $4 million, which included a cash outflow of $38 million, primarily related to restructuring and repositioning activities. Adjusted free cash flow for the quarter was $42 million. The company completed the quarter with $473 million in cash and cash equivalents. |

[0000833444-15-000010:8k_2_02:38]
| • | Corporate expense for the quarter was $55 million before special items and $74 million on a GAAP basis, primarily due to restructuring and repositioning charges. |

[0000833444-15-000010:8k_2_02:39]
| • | The tax rate before special items was 17.5% for the quarter. |

[0000833444-15-000010:8k_2_02:40]
| • | During the quarter, the company repurchased 10 million shares for $417 million. The remaining share repurchase authorization is $1.0 billion. |

[0000833444-15-000010:8k_2_02:41]
| • | The company completed the change in its jurisdiction of incorporation to Ireland on November 17, 2014. |

[0000833444-15-000010:8k_2_02:42]
| • | As previously disclosed, during the quarter the company signed a definitive agreement to acquire Industrial Safety Technologies (IST), a global leader in gas and flame detection, for $329.5 million in cash. On an annualized basis, the addition of IST to Tyco's Global Products segment is expected to generate approximately $140 million in revenue. This transaction is expected to close toward the end of the fiscal second quarter. |

[0000833444-15-000010:8k_2_02:43]
| • | During the quarter, the company completed four additional acquisitions for a total of $140 million in cash. These included the acquisitions of a thermal imaging business, a fire suppression products business in China, a fire and security service business in the U.K, and a majority investment in an interactive intrusion platform that expands the company's Internet of Things capabilities. On an annualized basis these businesses are expected to generate revenue of approximately $100 million. |

[0000833444-15-000010:8k_2_02:44]
ABOUT TYCO

[0000833444-15-000010:8k_2_02:45]
Tyco (NYSE: TYC) is the world’s largest pure-play fire protection and security company. Tyco provides more than three million customers around the globe with the latest fire protection and security products and services. A company with $10+ billion in annual revenue, Tyco has over 57,000 employees in more than 900 locations across 50 countries serving various end markets, including commercial, institutional, governmental, retail, industrial, energy, residential and small business. For more information, visit www.tyco.com.

[0000833444-15-000010:8k_2_02:46]
CONFERENCE CALL AND WEBCAST

[0000833444-15-000010:8k_2_02:47]
Management will discuss the company’s first quarter results for 2015 during a conference call and webcast today beginning at 8:00 a.m. Eastern time (ET).  Today’s conference call for investors can be accessed in the following ways:

[0000833444-15-000010:8k_2_02:48]
| • | Live via webcast - through the Investor Relations section of Tyco’s website at http://investors.tyco.com, |

[0000833444-15-000010:8k_2_02:49]
| • | Live via telephone (for “listen-only” participants and those who would like to ask a question) - by dialing 800-857-9797 (in the United States) or 517-308-9262 (outside the United States), passcode “Tyco”, |

[0000833444-15-000010:8k_2_02:50]
| • | Replay via telephone - by dialing 800-324-4696 (in the United States) or 402-220-3856 (outside the United States), passcode 9851, from 10:00 a.m. (ET) on January 30, 2015, until 11:59 p.m. (ET) on February 6, 2015, and |

[0000833444-15-000010:8k_2_02:51]
| • | Replay via webcast - through the “Presentations & Webcasts” link on the Investor Relations section of Tyco’s website: http://investors.tyco.com. |

[0000833444-15-000010:8k_2_02:52]
NON-GAAP MEASURES

[0000833444-15-000010:8k_2_02:53]
Organic revenue, free cash flow (outflow) (FCF), and income from continuing operations, earnings per share (EPS) from continuing operations, operating income and segment operating income, in each case “before special items,” are non-GAAP measures and should not be considered replacements for GAAP results.

[0000833444-15-000010:8k_2_02:54]
Organic revenue is a useful measure used by the company to measure the underlying results and trends in the business. The difference between reported net revenue (the most comparable GAAP measure) and organic revenue (the non-GAAP measure) consists of the impact from foreign currency, acquisitions and divestitures, and other changes that either do not reflect the underlying results and trends of the Company’s businesses or are not completely under management’s control. There are limitations associated with organic revenue, such as the fact that, as presented herein, the metric may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using organic revenue in combination with the GAAP numbers. Organic revenue may be used as a component in the company’s incentive compensation plans.

[0000833444-15-000010:8k_2_02:55]
FCF is a useful measure of the company's cash that permits management and investors to gain insight into the number that management employs to measure cash that is free from any significant existing obligation and is available to service debt and make investments. The difference between Cash Flows from Operating Activities (the most comparable GAAP measure) and FCF (the non-GAAP measure) consists mainly of significant cash flows that the company believes are useful to identify. It, or a measure that is based on it, may be used as a component in the company's incentive compensation plans. The difference reflects the impact from:

[0000833444-15-000010:8k_2_02:56]
| • | net capital expenditures, |

[0000833444-15-000010:8k_2_02:57]
| • | dealer generated accounts and bulk accounts purchased, |

[0000833444-15-000010:8k_2_02:58]
| • | cash paid for purchase accounting and holdback liabilities, and |

[0000833444-15-000010:8k_2_02:59]
| • | voluntary pension contributions. |

[0000833444-15-000010:8k_2_02:60]
Capital expenditures and dealer generated and bulk accounts purchased are subtracted because they represent long-term investments that are required for normal business activities. Cash paid for purchase accounting and holdback liabilities is subtracted because these cash outflows are not available for general corporate uses. Voluntary pension contributions are added because this activity is driven by economic financing decisions rather than operating activity. In addition, the company presents adjusted free cash flow, which is free cash flow, adjusted to exclude the cash impact of the special items highlighted below. This number provides information to investors regarding the cash impact of certain items management believes are useful to identify, as described below.

[0000833444-15-000010:8k_2_02:61]
The limitation associated with using these cash flow metrics is that they adjust for cash items that are ultimately within management's and the Board of Directors' discretion to direct and therefore may imply that there is less or more cash that is available for the company's programs than the most comparable GAAP measure. Furthermore, these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using FCF in combination with the GAAP cash flow numbers.

[0000833444-15-000010:8k_2_02:62]
The company has presented its income and EPS from continuing operations, operating income and segment operating income before special items. Special items include charges and gains related to divestitures, acquisitions, restructurings, impairments, certain changes to accounting methodologies, legacy legal and tax charges and other income or charges that may mask the underlying operating results and/or business trends of the company or business segment, as applicable. The company utilizes these measures to assess overall operating performance and segment level core operating performance, as well as to provide insight to management in evaluating overall and segment operating plan execution and underlying market conditions. The Company also presents its effective tax rate as adjusted for special items for consistency, and presents corporate expense excluding special items. One or more of these measures may be used as components in the company's incentive compensation plans. These measures are useful for investors because they may permit more meaningful comparisons of the company's underlying operating results and business trends between periods. The difference between income and EPS from continuing operations before special items and income and EPS from continuing operations (the most comparable GAAP measures) consists of the impact of the special items noted above on the applicable GAAP measure. The limitation of these measures is that they exclude the impact (which may be material) of items that increase or decrease the company's reported GAAP metrics, and these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using the non-GAAP measures in combination with the most comparable GAAP measures in order to better understand the amounts, character and impact of any increase or decrease on reported results.

[0000833444-15-000010:8k_2_02:63]
The company provides general corporate services to its segments and those costs are reported in the "Corporate and Other" segment. This segment's operating income (loss) is presented as "Corporate Expense." Segment Operating Income represents Tyco’s operating income excluding the Corporate and Other segment, and reflects the results of Tyco’s three operating segments. Segment Operating Income before special items reflects GAAP operating income adjusted for the special items noted in the paragraph above.

[0000833444-15-000010:8k_2_02:64]
FORWARD-LOOKING STATEMENTS

[0000833444-15-000010:8k_2_02:65]
# # #

[0000833444-15-000010:8k_2_02:66]
TYCO INTERNATIONAL PLC

[0000833444-15-000010:8k_2_02:67]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0000833444-15-000010:8k_2_02:68]
(in millions, except per share data)

[0000833444-15-000010:8k_2_02:69]
(Unaudited)

[0000833444-15-000010:8k_2_02:70]
|  |  | Quarters Ended |
|  |  | December 26, 2014 |  | December 27, 2013 |
| Revenue from product sales |  | $ | 1,488 |  |  | $ | 1,468 |  |
| Service revenue |  | 991 |  |  | 1,025 |  |
| Net revenue |  | 2,479 |  |  | 2,493 |  |
| Cost of product sales |  | 1,022 |  |  | 999 |  |
| Cost of services |  | 548 |  |  | 576 |  |
| Selling, general and administrative expenses |  | 653 |  |  | 571 |  |
| Restructuring and asset impairment charges, net |  | 58 |  |  | 3 |  |
| Operating income |  | 198 |  |  | 344 |  |
| Interest income |  | 3 |  |  | 3 |  |
| Interest expense |  | (24 | ) |  | (24 | ) |
| Other income (expense), net |  | 4 |  |  | (1 | ) |
| Income from continuing operations before income taxes |  | 181 |  |  | 322 |  |
| Income tax expense |  | (19 | ) |  | (70 | ) |
| Equity loss in earnings of unconsolidated subsidiaries |  | — |  |  | (4 | ) |
| Income from continuing operations |  | 162 |  |  | 248 |  |
| (Loss) income from discontinued operations, net of income taxes |  | (1 | ) |  | 24 |  |
| Net income |  | 161 |  |  | 272 |  |
| Less: noncontrolling interest in subsidiaries net (loss) income |  | (1 | ) |  | 2 |  |
| Net income attributable to Tyco ordinary shareholders |  | $ | 162 |  |  | $ | 270 |  |
| Amounts attributable to Tyco ordinary shareholders: |  |  |  |  |  |
| Income from continuing operations |  | $ | 163 |  |  | $ | 246 |  |
| (Loss) income from discontinued operations |  | (1 | ) |  | 24 |  |
| Net income attributable to Tyco ordinary shareholders |  | $ | 162 |  |  | $ | 270 |  |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.39 |  |  | $ | 0.53 |  |
| Income from discontinued operations |  | — |  |  | 0.05 |  |
| Net income attributable to Tyco ordinary shareholders |  | $ | 0.39 |  |  | $ | 0.58 |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.38 |  |  | $ | 0.52 |  |
| Income from discontinued operations |  | — |  |  | 0.05 |  |
| Net income attributable to Tyco ordinary shareholders |  | $ | 0.38 |  |  | $ | 0.57 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |
| Basic |  | 420 |  |  | 464 |  |
| Diluted |  | 427 |  |  | 471 |  |

[0000833444-15-000010:8k_2_02:71]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed on November 14, 2014 for the fiscal year ended September 26, 2014.

[0000833444-15-000010:8k_2_02:72]
TYCO INTERNATIONAL PLC

[0000833444-15-000010:8k_2_02:73]
RESULTS OF SEGMENTS

[0000833444-15-000010:8k_2_02:74]
(in millions)

[0000833444-15-000010:8k_2_02:75]
(Unaudited)

[0000833444-15-000010:8k_2_02:76]
|  |  | Quarters Ended |  |  |
|  |  | December 26, 2014 |  |  |  | December 27, 2013 |  |  |
| Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Installation & Services |  | $ | 951 |  |  |  |  |  | $ | 957 |  |  |  |  |
| ROW Installation & Services |  | 917 |  |  |  |  |  | 971 |  |  |  |  |
| Global Products |  | 611 |  |  |  |  |  | 565 |  |  |  |  |
| Total Net Revenue |  | $ | 2,479 |  |  |  |  |  | $ | 2,493 |  |  |  |  |
| Operating Income and Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Installation & Services |  | $ | 105 |  |  | 11.0 | % |  | $ | 117 |  |  | 12.2 | % |
| ROW Installation & Services |  | 69 |  |  | 7.5 | % |  | 95 |  |  | 9.8 | % |
| Global Products |  | 98 |  |  | 16.0 | % |  | 86 |  |  | 15.2 | % |
| Corporate and Other |  | (74 | ) |  | N/M |  |  | 46 |  |  | N/M |  |
| Operating Income and Margin |  | $ | 198 |  |  | 8.0 | % |  | $ | 344 |  |  | 13.8 | % |

[0000833444-15-000010:8k_2_02:77]
TYCO INTERNATIONAL PLC

[0000833444-15-000010:8k_2_02:78]
CONSOLIDATED BALANCE SHEETS

[0000833444-15-000010:8k_2_02:79]
(in millions)

[0000833444-15-000010:8k_2_02:80]
(Unaudited)

[0000833444-15-000010:8k_2_02:81]
|  |  | December 26, 2014 |  | September 26, 2014 |
| Assets |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 473 |  |  | $ | 892 |  |
| Accounts receivable, net |  | 1,718 |  |  | 1,750 |  |
| Inventories |  | 658 |  |  | 628 |  |
| Prepaid expenses and other current assets |  | 890 |  |  | 1,153 |  |
| Deferred income taxes |  | 307 |  |  | 307 |  |
| Assets held for sale |  | 20 |  |  | 21 |  |
| Total Current Assets |  | 4,066 |  |  | 4,751 |  |
| Property, plant and equipment, net |  | 1,242 |  |  | 1,269 |  |
| Goodwill |  | 4,148 |  |  | 4,126 |  |
| Intangible assets, net |  | 796 |  |  | 737 |  |
| Other assets |  | 946 |  |  | 926 |  |
| Total Assets |  | $ | 11,198 |  |  | $ | 11,809 |  |
| Liabilities and Equity |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |
| Loans payable and current maturities of long-term debt |  | $ | 278 |  |  | $ | 20 |  |
| Accounts payable |  | 825 |  |  | 871 |  |
| Accrued and other current liabilities |  | 1,993 |  |  | 2,167 |  |
| Deferred revenue |  | 365 |  |  | 400 |  |
| Liabilities held for sale |  | 14 |  |  | 13 |  |
| Total Current Liabilities |  | 3,475 |  |  | 3,471 |  |
| Long-term debt |  | 1,184 |  |  | 1,443 |  |
| Deferred revenue |  | 324 |  |  | 335 |  |
| Other liabilities |  | 1,918 |  |  | 1,877 |  |
| Total Liabilities |  | 6,901 |  |  | 7,126 |  |
| Redeemable noncontrolling interest |  | 13 |  |  | 13 |  |
| Total Tyco shareholders' equity |  | 4,234 |  |  | 4,647 |  |
| Nonredeemable noncontrolling interest |  | 50 |  |  | 23 |  |
| Total Equity |  | 4,284 |  |  | 4,670 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity |  | $ | 11,198 |  |  | $ | 11,809 |  |

[0000833444-15-000010:8k_2_02:82]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed on November 14, 2014 for the fiscal year ended September 26, 2014.

[0000833444-15-000010:8k_2_02:83]
TYCO INTERNATIONAL PLC

[0000833444-15-000010:8k_2_02:84]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000833444-15-000010:8k_2_02:85]
(in millions)

[0000833444-15-000010:8k_2_02:86]
(Unaudited)

[0000833444-15-000010:8k_2_02:87]
|  |  | For the Quarters Ended |
|  |  | December 26, 2014 |  | December 27, 2013 |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |
| Net income attributable to Tyco ordinary shareholders |  | $ | 162 |  |  | $ | 270 |  |
| Noncontrolling interest in subsidiaries net (loss) income |  | (1 | ) |  | 2 |  |
| Loss (income) from discontinued operations, net of income taxes |  | 1 |  |  | (24 | ) |
| Income from continuing operations |  | 162 |  |  | 248 |  |
| Adjustments to reconcile net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  | 91 |  |  | 94 |  |
| Non-cash compensation expense |  | 15 |  |  | 15 |  |
| Deferred income taxes |  | (6 | ) |  | 51 |  |
| Provision for losses on accounts receivable and inventory |  | 16 |  |  | 10 |  |
| Legacy legal matters |  | — |  |  | (92 | ) |
| Other non-cash items |  | (2 | ) |  | 7 |  |
| Changes in assets and liabilities, net of the effects of acquisitions and divestitures: |  |  |  |  |  |  |
| Accounts receivable, net |  | (7 | ) |  | 25 |  |
| Contracts in progress |  | 8 |  |  | 13 |  |
| Inventories |  | (43 | ) |  | (30 | ) |
| Prepaid expenses and other assets |  | (3 | ) |  | (54 | ) |
| Accounts payable |  | (41 | ) |  | (41 | ) |
| Accrued and other liabilities |  | (33 | ) |  | (105 | ) |
| Deferred revenue |  | (37 | ) |  | (40 | ) |
| Other |  | (24 | ) |  | (1 | ) |
| Net cash provided by operating activities |  | 96 |  |  | 100 |  |
| Net cash provided by discontinued operating activities |  | — |  |  | 23 |  |
| Cash Flows From Investing Activities: |  |  |  |  |
| Capital expenditures |  | (66 | ) |  | (63 | ) |
| Proceeds from disposal of assets |  | 1 |  |  | 4 |  |
| Acquisition of businesses, net of cash acquired |  | (152 | ) |  | (54 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (4 | ) |  | (11 | ) |
| Sales and maturities of investments |  | 275 |  |  | 112 |  |
| Purchases of investments |  | (1 | ) |  | (32 | ) |
| (Increase) decrease in restricted cash |  | (45 | ) |  | 4 |  |
| Other |  | (1 | ) |  | 2 |  |
| Net cash provided by (used in) investing activities |  | 7 |  |  | (38 | ) |
| Net cash used in discontinued investing activities |  | (15 | ) |  | (29 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt |  | — |  |  | 310 |  |
| Repayment of short-term debt |  | — |  |  | (150 | ) |
| Proceeds from exercise of share options |  | 33 |  |  | 40 |  |
| Dividends paid |  | (75 | ) |  | (74 | ) |
| Repurchase of ordinary shares by treasury |  | (417 | ) |  | (250 | ) |
| Transfer to discontinued operations |  | (15 | ) |  | (6 | ) |
| Payment of contingent consideration |  | (23 | ) |  | — |  |
| Other |  | (15 | ) |  | (9 | ) |
| Net cash used in financing activities |  | (512 | ) |  | (139 | ) |
| Net cash provided by discontinued financing activities |  | 15 |  |  | 6 |  |
| Effect of currency translation on cash |  | (10 | ) |  | (7 | ) |
| Net decrease in cash and cash equivalents |  | (419 | ) |  | (84 | ) |
| Less: net decrease in cash and cash equivalents related to discontinued operations |  | — |  |  | — |  |
| Cash and cash equivalents at beginning of period |  | 892 |  |  | 563 |  |
| Cash and cash equivalents at end of period |  | $ | 473 |  |  | $ | 479 |  |

[0000833444-15-000010:8k_2_02:88]
| Reconciliation to "Free Cash Flow": |  |  |  |  |
| Net cash provided by operating activities |  | $ | 96 |  |  | $ | 100 |  |
| Capital expenditures, net |  | (65 | ) |  | (59 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (4 | ) |  | (11 | ) |
| Payment of contingent consideration |  | (23 | ) |  | — |  |
| Free Cash Flow |  | $ | 4 |  |  | $ | 30 |  |
| Reconciliation to "Adjusted Free Cash Flow": |  |  |  |  |
| CIT settlement |  | $ | — |  |  | $ | (60 | ) |
| IRS litigation costs |  | — |  |  | 1 |  |
| Separation costs |  | 3 |  |  | 22 |  |
| Restructuring and repositioning costs |  | 34 |  |  | 29 |  |
| Environmental remediation payments |  | 7 |  |  | 31 |  |
| Legal settlements |  | (12 | ) |  | — |  |
| Net asbestos payments (recoveries) |  | 5 |  |  | 3 |  |
| Cash payment from Covidien / TE Connectivity |  | — |  |  | (1 | ) |
| Acquisition / integration costs |  | 1 |  |  | — |  |
| Special Items |  | $ | 38 |  |  | $ | 25 |  |
| Adjusted Free Cash Flow |  | $ | 42 |  |  | $ | 55 |  |

[0000833444-15-000010:8k_2_02:89]
NOTE: Free cash flow is a non-GAAP measure.  See description of non-GAAP measures contained in this release.

[0000833444-15-000010:8k_2_02:90]
TYCO INTERNATIONAL PLC

[0000833444-15-000010:8k_2_02:91]
ORGANIC GROWTH RECONCILIATION - REVENUE

[0000833444-15-000010:8k_2_02:92]
(in millions)

[0000833444-15-000010:8k_2_02:93]
(Unaudited)

[0000833444-15-000010:8k_2_02:94]
|  |  |  |  | Quarter Ended December 26, 2014 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Quarter Ended December 27, 2013 |  | Adjustments |  | Adjusted Fiscal 2014 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Quarter Ended December 26, 2014 |
|  |  |  | Divestitures / Other |  |  | Foreign Currency |  | Acquisitions |  | Organic Revenue(1) |  |
| NA Installation & Services |  | $ | 957 |  |  | $ | — |  |  | — | % |  | $ | 957 |  |  | $ | (9 | ) |  | (0.9 | )% |  | $ | 4 |  |  | 0.4 | % |  | $ | (1 | ) |  | (0.1 | )% |  | $ | 951 |  |  | (0.6 | )% |
| ROW Installation & Services |  | 971 |  |  | (13 | ) |  | (1.3 | )% |  | 958 |  |  | (63 | ) |  | (6.5 | )% |  | 20 |  |  | 2.1 | % |  | 2 |  |  | 0.2 | % |  | 917 |  |  | (5.6 | )% |
| Global Products |  | 565 |  |  | — |  |  | — | % |  | 565 |  |  | (17 | ) |  | (3.0 | )% |  | 5 |  |  | 0.9 | % |  | 58 |  |  | 10.3 | % |  | 611 |  |  | 8.1 | % |
| Total Net Revenue |  | $ | 2,493 |  |  | $ | (13 | ) |  | (0.5 | )% |  | $ | 2,480 |  |  | $ | (89 | ) |  | (3.6 | )% |  | $ | 29 |  |  | 1.2 | % |  | $ | 59 |  |  | 2.4 | % |  | $ | 2,479 |  |  | (0.6 | )% |

[0000833444-15-000010:8k_2_02:95]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2014 base revenue. |

[0000833444-15-000010:8k_2_02:96]
Earnings Per Share Summary

[0000833444-15-000010:8k_2_02:97]
(Unaudited)

[0000833444-15-000010:8k_2_02:98]
|  |  | Quarter Ended |  | Quarter Ended |
|  |  | Dec. 26, 2014 |  | Dec. 27, 2013 |
| Diluted EPS from Continuing Operations Attributable to Tyco Shareholders (GAAP) |  | $ | 0.38 |  |  | $ | 0.52 |  |
| expense / (benefit) |  |  |  |  |
| Restructuring and repositioning activities |  | 0.12 |  |  | 0.01 |  |
| Separation costs included in SG&A |  | — |  |  | 0.02 |  |
| Loss on sale of investment |  | — |  |  | 0.01 |  |
| CIT settlement |  | — |  |  | (0.03 | ) |
| Settlement with former management |  | (0.01 | ) |  | (0.11 | ) |
| Total Before Special Items |  | $ | 0.49 |  |  | $ | 0.42 |  |

[0000833444-15-000010:8k_2_02:99]
Tyco International plc

[0000833444-15-000010:8k_2_02:100]
For the Quarter Ended December 26, 2014

[0000833444-15-000010:8k_2_02:101]
(in millions, except per share data)

[0000833444-15-000010:8k_2_02:102]
(Unaudited)

[0000833444-15-000010:8k_2_02:103]
expense / (benefit)

[0000833444-15-000010:8k_2_02:104]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $951 |  |  |  |  |  | $917 |  |  |  |  |  | $611 |  |  |  |  |  | $2,479 |  |  |  |  |  | $— |  |  |  |  |  | $2,479 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other Income, net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $105 |  |  | 11.0 | % |  |  | $69 |  |  | 7.5 | % |  |  | $98 |  |  | 16.0 | % |  |  | $272 |  |  | 11.0 | % |  |  | ($74 | ) |  | N/M |  |  | $198 |  |  | 8.0 | % |  |  | ($21 | ) |  |  | $4 |  |  |  | ($19 | ) |  |  | $— |  |  |  | $1 |  |  |  | $163 |  |  | $0.38 |  |
| Restructuring and repositioning activities |  | 24 |  |  |  |  | 19 |  |  |  |  | 7 |  |  |  |  | 50 |  |  |  |  | 25 |  |  |  |  | 75 |  |  |  |  |  |  |  |  | (27 | ) |  |  |  |  |  | 48 |  | 0.12 |  |
| Separation costs included in SG&A |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | 1 |  | — |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Acquisition / integration costs |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Settlement with former management |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (7 | ) |  |  |  | (7 | ) |  |  |  |  |  |  |  | 3 |  |  |  |  |  |  | (4 | ) | (0.01 | ) |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 3 |  |  |  |  | 3 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | 2 |  | — |  |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (2 | ) |  |  |  | (2 | ) |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  | (1 | ) | — |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  |  |  | (2 | ) | — |  |
| Total Before Special Items |  |  | $131 |  |  | 13.8 | % |  |  | $90 |  |  | 9.8 | % |  |  | $105 |  |  | 17.2 | % |  |  | $326 |  |  | 13.2 | % |  |  | ($55 | ) |  | N/M |  |  | $271 |  |  | 10.9 | % |  |  | ($21 | ) |  |  | $2 |  |  |  | ($44 | ) |  |  | $— |  |  |  | $1 |  |  |  | $209 |  |  | $0.49 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 427 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 427 |  |

[0000833444-15-000010:8k_2_02:105]
Tyco International plc

[0000833444-15-000010:8k_2_02:106]
For the Quarter Ended December 27, 2013

[0000833444-15-000010:8k_2_02:107]
(in millions, except per share data)

[0000833444-15-000010:8k_2_02:108]
(Unaudited)

[0000833444-15-000010:8k_2_02:109]
expense / (benefit)

[0000833444-15-000010:8k_2_02:110]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $957 |  |  |  |  |  | $971 |  |  |  |  |  | $565 |  |  |  |  |  | $2,493 |  |  |  |  |  | $— |  |  |  |  |  | $2,493 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $117 |  |  | 12.2 | % |  |  | $95 |  |  | 9.8 | % |  |  | $86 |  |  | 15.2 | % |  |  | $298 |  |  | 12.0 | % |  |  | $46 |  |  | N/M |  |  | $344 |  |  | 13.8 | % |  |  | ($21 | ) |  |  | ($1 | ) |  |  | ($70 | ) |  |  | ($4 | ) |  |  | ($2 | ) |  |  | $246 |  |  | $0.52 |  |
| Restructuring and repositioning activities |  | (2 | ) |  |  |  |  |  |  |  | 4 |  |  |  |  | 2 |  |  |  |  | 7 |  |  |  |  | 9 |  |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  | 7 |  | 0.01 |  |
| Separation costs included in SG&A |  | 14 |  |  |  |  |  |  |  |  |  |  |  |  | 14 |  |  |  |  | 1 |  |  |  |  | 15 |  |  |  |  |  |  |  |  | (6 | ) |  |  |  |  |  | 9 |  | 0.02 |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (3 | ) |  |  |  | (3 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (3 | ) | — |  |
| Acquisition / integration costs |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Settlement with former management |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (92 | ) |  |  |  | (92 | ) |  |  |  |  |  |  |  | 36 |  |  |  |  |  |  | (56 | ) | (0.11 | ) |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | — |  | — |  |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| CIT settlement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (16 | ) |  |  |  | (16 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (16 | ) | (0.03 | ) |
| Loss on sale of investment |  |  |  |  |  | 7 |  |  |  |  |  |  |  |  | 7 |  |  |  |  |  |  |  |  | 7 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 7 |  | 0.01 |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  | — |  |
| Total Before Special Items |  |  | $129 |  |  | 13.5 | % |  |  | $103 |  |  | 10.6 | % |  |  | $90 |  |  | 15.9 | % |  |  | $322 |  |  | 12.9 | % |  |  | ($55 | ) |  | N/M |  |  | $267 |  |  | 10.7 | % |  |  | ($21 | ) |  |  | $1 |  |  |  | ($43 | ) |  |  | ($4 | ) |  |  | ($2 | ) |  |  | $198 |  |  | $0.42 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 471 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 471 |  |
