# JCI MD&A — 0000833444-15-000013


## mdna

[0000833444-15-000013:mdna:1]
[same as prior period, unchanged from 0000833444-14-000099:mdna:1]

[0000833444-15-000013:mdna:2]
[same as prior period, unchanged from 0000833444-14-000099:mdna:2]

[0000833444-15-000013:mdna:3]
[same as prior period, unchanged from 0000833444-14-000099:mdna:3]

[0000833444-15-000013:mdna:4]
The unaudited Consolidated Financial Statements include the consolidated results of Tyco International plc and its subsidiaries (hereinafter collectively referred to as "we", the "Company", "Tyco Ireland" or "Tyco"). The financial statements have been prepared in United States dollars ("USD"), in accordance with accounting principles generally accepted in the United States ("GAAP").

[0000833444-15-000013:mdna:5]
References to 2015 and 2014 are to Tyco's fiscal quarters ending December 26, 2014 and December 27, 2013, respectively, unless otherwise indicated.  The Company has a 52 or 53-week fiscal year that ends on the last Friday in September. Fiscal years 2015 and 2014 are both 52-week years.

[0000833444-15-000013:mdna:6]
Tyco Ireland was formed as an Irish public limited company and a wholly-owned subsidiary of Tyco International Ltd., a Swiss entity ("Tyco Switzerland") on May 9, 2014. On November 17, 2014, Tyco Switzerland merged with Tyco Ireland, with Tyco Ireland being the surviving company ("the Merger").  This Merger resulted in Tyco Ireland succeeding Tyco Switzerland as the publicly-traded parent company of the Tyco group.  Tyco Switzerland's shareholders received one ordinary share of Tyco Ireland for each ordinary share of Tyco Switzerland held immediately prior to the Merger.  Tyco Ireland now conducts, through its subsidiaries, the same businesses as conducted by Tyco Switzerland before the Merger.

[0000833444-15-000013:mdna:7]
Upon the effectiveness of the Merger, the ordinary shares of Tyco Ireland were listed on the New York Stock Exchange (“NYSE”) under the symbol “TYC,” the same symbol under which the ordinary shares in Tyco Switzerland were previously listed and traded.

[0000833444-15-000013:mdna:8]
[same as prior period, unchanged from 0000833444-14-000099:mdna:6]

[0000833444-15-000013:mdna:9]
[same as prior period, unchanged from 0000833444-14-000099:mdna:7]

[0000833444-15-000013:mdna:10]
[same as prior period, unchanged from 0000833444-14-000099:mdna:8]

[0000833444-15-000013:mdna:11]
[same as prior period, unchanged from 0000833444-14-000099:mdna:9]

[0000833444-15-000013:mdna:12]
[same as prior period, unchanged from 0000833444-14-000099:mdna:10]

[0000833444-15-000013:mdna:13]
Certain prior period amounts have been reclassified to conform with current period presentation.  Specifically, the Company has reclassified its ADT Korea business and several other ROW Installation & Services businesses to income from discontinued operations in the Consolidated Statements of Operations and to assets and liabilities held for sale within the Consolidated Balance Sheets as they each satisfied the criteria to be presented as discontinued operations.  We completed the sale of ADT Korea on May 22, 2014, and we expect to complete the sale of the other identified ROW Installation & Services businesses by the end of the third quarter of fiscal 2015. See Note 3 to our unaudited Consolidated Financial Statements.

[0000833444-15-000013:mdna:14]
[same as prior period, unchanged from 0000833444-14-000099:mdna:12]

[0000833444-15-000013:mdna:15]
We are a leading global provider of security products and services, fire detection and suppression products and services and life safety products. We utilize our extensive global footprint of approximately 900 locations, including manufacturing facilities, service and distribution centers, monitoring centers and sales offices, to provide solutions and localized expertise to our global customer base. We provide an extensive range of product and service offerings to over 3 million customers in more

[0000833444-15-000013:mdna:16]
than 100 countries through multiple channels. Our revenues are broadly diversified across the United States and Canada (collectively “North America”); Central America and South America (collectively “Latin America”); Europe, the Middle East, and Africa (collectively “EMEA”) and the Asia-Pacific geographic areas. The following chart reflects our net revenue by geographic area for the three months ended December 26, 2014.

[0000833444-15-000013:mdna:17]
Three Months Ended December 26, 2014

[0000833444-15-000013:mdna:18]
[same as prior period, unchanged from 0000833444-14-000099:mdna:15]

[0000833444-15-000013:mdna:19]
[same as prior period, unchanged from 0000833444-14-000099:mdna:16]

[0000833444-15-000013:mdna:20]
[same as prior period, unchanged from 0000833444-14-000099:mdna:17]

[0000833444-15-000013:mdna:21]
[same as prior period, unchanged from 0000833444-14-000099:mdna:18]

[0000833444-15-000013:mdna:22]
[same as prior period, unchanged from 0000833444-14-000099:mdna:19]

[0000833444-15-000013:mdna:23]
[same as prior period, unchanged from 0000833444-14-000099:mdna:20]

[0000833444-15-000013:mdna:24]
[same as prior period, unchanged from 0000833444-14-000099:mdna:21]

[0000833444-15-000013:mdna:25]
[same as prior period, unchanged from 0000833444-14-000099:mdna:22]

[0000833444-15-000013:mdna:26]
As a global business with a varied customer base and an extensive range of products and services, our operations and results are impacted by global, regional and industry specific factors, and by political factors. Our geographic diversity and the diversity in our customer base and our products and services has helped mitigate the impact of any one industry or the economy of any single country on our consolidated operating results, financial condition and cash flows. Due to the global nature of our

[0000833444-15-000013:mdna:27]
40

[0000833444-15-000013:mdna:28]
business and the variety of our customers, products and services, no single factor is predominantly used to forecast Company results. Rather, management monitors a number of factors to develop expectations regarding future results, including the activity of key competitors and customers, order rates for longer lead time projects, and capital expenditure budgets and spending patterns of our customers. We also monitor trends throughout the commercial and residential fire and security markets, including building codes and fire-safety standards. Our commercial installation businesses are impacted by trends in commercial construction starts, while our residential business, which is located outside of the United States, is impacted by new housing starts.

[0000833444-15-000013:mdna:29]
[same as prior period, unchanged from 0000833444-14-000099:mdna:26]

[0000833444-15-000013:mdna:30]
[same as prior period, unchanged from 0000833444-14-000099:mdna:27]

[0000833444-15-000013:mdna:31]
|  | For the Quarters Ended |
| ($ in millions) | December 26, 2014 |  | December 27, 2013 |
| Net revenue | $ | 2,479 |  |  | $ | 2,493 |  |
| Net revenue decline | (0.6 | )% |  | N/A |  |
| Organic revenue growth | 2.4 | % |  | N/A |  |
| Operating income | $ | 198 |  |  | $ | 344 |  |
| Operating margin | 8.0 | % |  | 13.8 | % |
| Interest income | $ | 3 |  |  | $ | 3 |  |
| Interest expense | (24 | ) |  | (24 | ) |
| Other income (expense), net | 4 |  |  | (1 | ) |
| Income tax expense | (19 | ) |  | (70 | ) |
| Equity loss in earnings of unconsolidated subsidiaries | — |  |  | (4 | ) |
| Income from continuing operations attributable to Tyco ordinary shareholders | 163 |  |  | 246 |  |

[0000833444-15-000013:mdna:32]
[same as prior period, unchanged from 0000833444-14-000099:mdna:29]

[0000833444-15-000013:mdna:33]
Net revenue for the quarter ended December 26, 2014 decreased by $14 million, or 0.6%, to $2,479 million as compared to net revenue of $2,493 million for the quarter ended December 27, 2013. On an organic basis, net revenue grew by $59 million, or 2.4%, year over year, primarily as a result of revenue growth in our Global Products segment.  Organic revenue for NA and ROW Installation & Services segments were virtually unchanged.  Net revenue was favorably impacted by acquisitions that contributed $29 million, or 1.2%, within our ROW Installation & Services segment primarily in high growth regions.  Changes in foreign currency exchange rates had an unfavorable impact of $89 million, or 3.6%, on net revenue, primarily in our ROW Installation & Services segment, and to a lesser extent, in our Global Products segment. Net revenue growth was also unfavorably impacted by divestitures of $13 million, or 0.5%, in our ROW Installation & Services segment.

[0000833444-15-000013:mdna:34]
[same as prior period, unchanged from 0000833444-14-000099:mdna:32]

[0000833444-15-000013:mdna:35]
Operating income for the quarter ended December 26, 2014 decreased by $146 million, or 42.4%, to $198 million, as compared to operating income of $344 million for the quarter ended December 27, 2013.  Most of this decline is due to a reversal of a compensation reserve of $92 million for the settlement of legacy litigation with former management, and a gain of $16 million related to a legal settlement with CIT Group, both during the quarter ended December 27, 2013.  Operating income was also unfavorably impacted by a $66 million increase in restructuring and repositioning charges as compared to the prior comparable period. These items were offset by benefits from sourcing, productivity and restructuring activities, and a $13 million decline in separation costs.

[0000833444-15-000013:mdna:36]
Key items impacting operating income for the quarters ended December 26, 2014 and December 27, 2013, respectively, are as follows:

[0000833444-15-000013:mdna:37]
|  | For the Quarters Ended |
| ($ in millions) | December 26, 2014 |  | December 27, 2013 |
| Legacy legal gains | $ | (7 | ) |  | $ | (92 | ) |
| CIT settlement gain | — |  |  | (16 | ) |
| Separation costs | 2 |  |  | 15 |  |
| Loss on sale of investment | — |  |  | 7 |  |
| Restructuring, repositioning and asset impairment charges, net | 75 |  |  | 9 |  |

[0000833444-15-000013:mdna:38]
We continue to identify and pursue opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across our businesses. Additionally, we initiated certain global actions designed to reduce our cost structure and improve future profitability by streamlining operations and better aligning functions, which we refer to as repositioning actions. The Company expects to incur approximately $100 million to $150 million of restructuring and repositioning charges in fiscal 2015. See Note 4 to our unaudited Consolidated Financial Statements.

[0000833444-15-000013:mdna:39]
[same as prior period, unchanged from 0000833444-14-000099:mdna:39]

[0000833444-15-000013:mdna:40]
Interest income was $3 million for both quarters ended December 26, 2014 and December 27, 2013. Interest expense was $24 million for both quarters ended December 26, 2014 and December 27, 2013.

[0000833444-15-000013:mdna:41]
Other Income (Expense), net

[0000833444-15-000013:mdna:42]
Other income of $4 million for the quarter ended December 26, 2014 primarily related to an unrealized gain on trading securities and a net gain on TSA activity under both the 2012 and 2007 agreements.  Other expense of $1 million for the quarter ended December 27, 2013 primarily related to a net loss on 2012 TSA activity.

[0000833444-15-000013:mdna:43]
[same as prior period, unchanged from 0000833444-14-000099:mdna:45]

[0000833444-15-000013:mdna:44]
Our effective income tax rate was 10.5% and 21.7% during the quarters ended December 26, 2014 and December 27, 2013, respectively. The decrease in our effective tax rate in the current period was primarily due to non-recurring charges in a high tax jurisdiction, partially offset by income from a non-recurring reversal of a compensation reserve established in respect of legacy litigation with former management that generated increased tax expense during the prior period.

[0000833444-15-000013:mdna:45]
[same as prior period, unchanged from 0000833444-14-000099:mdna:48]

[0000833444-15-000013:mdna:46]
Equity Income (Loss) in Earnings of Unconsolidated Subsidiaries

[0000833444-15-000013:mdna:47]
Equity income (loss) in earnings of unconsolidated subsidiaries for the quarter ended December 27, 2013 reflects our share of Atkore International Group Inc.'s  ("Atkore") net gain or loss, which is accounted for under the equity method of accounting. Equity income (loss) in earnings of unconsolidated subsidiaries during the quarter ended December 27, 2013 was a loss of $4 million.  On April 9, 2014, Atkore redeemed all of our common equity stake in Atkore.

[0000833444-15-000013:mdna:48]
[same as prior period, unchanged from 0000833444-14-000099:mdna:52]

[0000833444-15-000013:mdna:49]
The following chart reflects our net revenue by operating segment, as well as the percent of net revenue by operating segment, for the quarters ended December 26, 2014 and December 27, 2013, respectively.

[0000833444-15-000013:mdna:50]
[same as prior period, unchanged from 0000833444-14-000099:mdna:54]

[0000833444-15-000013:mdna:51]
[same as prior period, unchanged from 0000833444-14-000099:mdna:55]

[0000833444-15-000013:mdna:52]
Financial information for NA Installation & Services for the quarters ended December 26, 2014 and December 27, 2013 is as follows:

[0000833444-15-000013:mdna:53]
|  | For the Quarters Ended |
| ($ in millions) | December 26, 2014 |  | December 27, 2013 |
| Net revenue | $ | 951 |  |  | $ | 957 |  |
| Net revenue decline | (0.6 | )% |  | N/A |  |
| Organic revenue decline | (0.1 | )% |  | N/A |  |
| Operating income | $ | 105 |  |  | $ | 117 |  |
| Operating margin | 11.0 | % |  | 12.2 | % |

[0000833444-15-000013:mdna:54]
[same as prior period, unchanged from 0000833444-14-000099:mdna:58]

[0000833444-15-000013:mdna:55]
[same as prior period, unchanged from 0000833444-14-000099:mdna:59]

[0000833444-15-000013:mdna:56]
| Factors Contributing to Year-Over-Year Change |  | First QuarterFiscal 2015 Compared toFirst QuarterFiscal 2014 |
| Organic revenue decline |  | $ | (1 | ) |
| Acquisitions |  | 4 |  |
| Impact of foreign currency |  | (9 | ) |
| Total change |  | $ | (6 | ) |

[0000833444-15-000013:mdna:57]
Net revenue decreased $6 million, or 0.6%, to $951 million for the quarter ended December 26, 2014 as compared to $957 million for the quarter ended December 27, 2013. Organic revenue remained relatively unchanged from the prior comparable quarter, as increased service revenue was offset by a decline in installation revenue.  Net revenue was favorably impacted by $4 million, or 0.4%, due to the acquisition of Westfire in the first quarter of fiscal 2014.  Changes in foreign currency exchange rates unfavorably impacted net revenue by $9 million, or 0.9%.

[0000833444-15-000013:mdna:58]
[same as prior period, unchanged from 0000833444-14-000099:mdna:63]

[0000833444-15-000013:mdna:59]
Operating income for the quarter ended December 26, 2014 decreased $12 million, or 10.3%, to $105 million, as compared to operating income of $117 million for the quarter ended December 27, 2013.  Operating income was unfavorably impacted by a $26 million increase in restructuring and repositioning activities.  This was partially offset by productivity and restructuring benefits and a $12 million decline in separation costs.

[0000833444-15-000013:mdna:60]
Key items impacting operating income for the quarters ended December 26, 2014 and December 27, 2013, respectively, are as follows:

[0000833444-15-000013:mdna:61]
|  | For the Quarters Ended |
| ($ in millions) | December 26, 2014 |  | December 27, 2013 |
| Separation costs | $ | 2 |  |  | $ | 14 |  |
| Restructuring, repositioning and asset impairment charges (reversals), net | 24 |  |  | (2 | ) |

[0000833444-15-000013:mdna:62]
[same as prior period, unchanged from 0000833444-14-000099:mdna:68]

[0000833444-15-000013:mdna:63]
Financial information for ROW Installation & Services for the quarters ended December 26, 2014 and December 27, 2013 is as follows:

[0000833444-15-000013:mdna:64]
|  | For the Quarters Ended |
| ($ in millions) | December 26, 2014 |  | December 27, 2013 |
| Net revenue | $ | 917 |  |  | $ | 971 |  |
| Net revenue decline | (5.6 | )% |  | N/A |  |
| Organic revenue growth | 0.2 | % |  | N/A |  |
| Operating income | $ | 69 |  |  | $ | 95 |  |
| Operating margin | 7.5 | % |  | 9.8 | % |

[0000833444-15-000013:mdna:65]
[same as prior period, unchanged from 0000833444-14-000099:mdna:71]

[0000833444-15-000013:mdna:66]
[same as prior period, unchanged from 0000833444-14-000099:mdna:72]

[0000833444-15-000013:mdna:67]
| Factors Contributing to Year-Over-Year Change |  | First QuarterFiscal 2015Compared toFirst QuarterFiscal 2014 |
| Organic revenue growth |  | $ | 2 |  |
| Acquisitions |  | 20 |  |
| Divestitures |  | (13 | ) |
| Impact of foreign currency |  | (63 | ) |
| Total change |  | $ | (54 | ) |

[0000833444-15-000013:mdna:68]
Net revenue decreased $54 million, or 5.6%, to $917 million for the quarter ended December 26, 2014 as compared to $971 million for the quarter ended December 27, 2013. Changes in foreign currency exchange rates unfavorably impacted net revenue by $63 million, or 6.5%. Net revenue was also unfavorably impacted by $13 million, or 1.3%, primarily due to the divestiture of our Armourguard business in New Zealand and fire and security business in Fiji in the first quarter of fiscal 2014. Organic revenue was relatively unchanged, as growth in high growth markets and continental Europe were almost entirely offset by declines in our Pacific region, Asia and the United Kingdom. Net revenue was favorably impacted by $20 million, or 2.1%, primarily due to acquisitions within high growth markets during fiscal 2014, and to a lesser extent, in continental Europe.

[0000833444-15-000013:mdna:69]
[same as prior period, unchanged from 0000833444-14-000099:mdna:77]

[0000833444-15-000013:mdna:70]
Operating income for the quarter ended December 26, 2014 decreased $26 million, or 27.4%, to $69 million as compared to operating income of $95 million for the quarter ended December 27, 2013. Operating income was unfavorably impacted by a $19 million increase in restructuring and repositioning charges during the quarter ended December 26, 2014, and a slightly lower percentage of high-margin service revenue. This was partially offset by an increase in operating income due to the $7 million loss on the sale of an investment during the quarter ended December 27, 2013.

[0000833444-15-000013:mdna:71]
Key items impacting operating income for the quarters ended December 26, 2014 and December 27, 2013, respectively, are as follows:

[0000833444-15-000013:mdna:72]
|  | For the Quarters Ended |
| ($ in millions) | December 26, 2014 |  | December 27, 2013 |
| Loss on sale of investment | $ | — |  |  | $ | 7 |  |
| Restructuring, repositioning and asset impairment charges, net | 19 |  |  | — |  |

[0000833444-15-000013:mdna:73]
[same as prior period, unchanged from 0000833444-14-000099:mdna:82]

[0000833444-15-000013:mdna:74]
Financial information for Global Products for the quarters ended December 26, 2014 and December 27, 2013 is as follows:

[0000833444-15-000013:mdna:75]
|  | For the Quarters Ended |
| ($ in millions) | December 26, 2014 |  | December 27, 2013 |
| Net revenue | $ | 611 |  |  | $ | 565 |  |
| Net revenue growth | 8.1 | % |  | N/A |  |
| Organic revenue growth | 10.3 | % |  | N/A |  |
| Operating income | $ | 98 |  |  | $ | 86 |  |
| Operating margin | 16.0 | % |  | 15.2 | % |

[0000833444-15-000013:mdna:76]
[same as prior period, unchanged from 0000833444-14-000099:mdna:85]

[0000833444-15-000013:mdna:77]
[same as prior period, unchanged from 0000833444-14-000099:mdna:86]

[0000833444-15-000013:mdna:78]
| Factors Contributing to Year-Over-Year Change |  | First QuarterFiscal 2015Compared toFirst QuarterFiscal 2014 |
| Organic revenue growth |  | $ | 58 |  |
| Acquisitions |  | 5 |  |
| Impact of foreign currency |  | (17 | ) |
| Total change |  | $ | 46 |  |

[0000833444-15-000013:mdna:79]
Net revenue increased $46 million, or 8.1%, to $611 million for the quarter ended December 26, 2014 as compared to $565 million for the quarter ended December 27, 2013.  Organic revenue growth was driven by growth across all three businesses, predominantly in our life safety business due to lower revenue during the first quarter of fiscal 2014 as a result of industry-wide approval delays of new standards related to self-contained breathing apparatuses.  Organic growth was also driven by increases in our security products business and to a lesser extent, our fire products business. Net revenue was favorably impacted by $5 million, or 0.9%, from acquisitions during the first quarter of fiscal 2015.  Changes in foreign currency exchange rates unfavorably impacted net revenue by $17 million, or 3.0%.

[0000833444-15-000013:mdna:80]
[same as prior period, unchanged from 0000833444-14-000099:mdna:91]

[0000833444-15-000013:mdna:81]
Operating income for the quarter ended December 26, 2014 increased by $12 million, or 14.0% to $98 million, as compared to operating income of $86 million for the quarter ended December 27, 2013.  Operating income increased due to net revenue growth for the quarter ended December 26, 2014, as well as the benefit of productivity and restructuring initiatives. These were partially offset by additional investments in research and development and sales and marketing costs, and a $3 million increase in restructuring and repositioning charges.

[0000833444-15-000013:mdna:82]
Key items impacting operating income for the quarters ended December 26, 2014 and December 27, 2013, respectively, are as follows:

[0000833444-15-000013:mdna:83]
|  | For the Quarter Ended |
| ($ in millions) | December 26, 2014 |  | December 27, 2013 |
| Restructuring, repositioning and asset impairment charges, net | $ | 7 |  |  | $ | 4 |  |

[0000833444-15-000013:mdna:84]
[same as prior period, unchanged from 0000833444-14-000099:mdna:96]

[0000833444-15-000013:mdna:85]
Corporate expense was $74 million for the quarter ended December 26, 2014 while Corporate generated income of $46 million for the quarter ended December 27, 2013.  The decrease was primarily due to the reversal of a compensation reserve of $92 million for the settlement of legacy litigation with former management, and a gain of $16 million related to a legal settlement with CIT Group for the quarter ended December 27, 2013.  In addition, restructuring and repositioning charges increased by $18 million compared to the quarter ended December 27, 2013.

[0000833444-15-000013:mdna:86]
Key items included in corporate expense for the quarters ended December 26, 2014 and December 27, 2013, respectively, are as follows:

[0000833444-15-000013:mdna:87]
|  | For the Quarters Ended |
| ($ in millions) | December 26, 2014 |  | December 27, 2013 |
| Legacy legal gains | $ | (7 | ) |  | $ | (92 | ) |
| CIT settlement gain | — |  |  | (16 | ) |
| Restructuring, repositioning and asset impairment charges, net | 25 |  |  | 7 |  |

[0000833444-15-000013:mdna:88]
[same as prior period, unchanged from 0000833444-14-000099:mdna:102]

[0000833444-15-000013:mdna:89]
The preparation of the unaudited Consolidated Financial Statements in conformity with US GAAP requires management to use judgment in making estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of contingent assets and liabilities and the reported amounts of revenue and expenses. We believe that our accounting policies for depreciation and amortization methods of security monitoring-related assets, revenue recognition, loss contingencies, income taxes, goodwill and indefinite-lived intangible assets, long-lived assets and pension and postretirement benefits are based on, among other things, judgments and assumptions made by management that include inherent risks and uncertainties. During fiscal 2015, there have been no significant changes to these policies or in the underlying accounting assumptions and estimates used in the above critical accounting policies from those disclosed in the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed with the SEC on November 13, 2014 for the fiscal year ended September 26, 2014.

[0000833444-15-000013:mdna:90]
[same as prior period, unchanged from 0000833444-14-000099:mdna:104]

[0000833444-15-000013:mdna:91]
A fundamental objective of the Company is to have sufficient liquidity, balance sheet strength, and financial flexibility to fund the operating and capital requirements of its core businesses around the world. The primary source of funds to finance our operations and capital expenditures is cash generated by operations. In addition, we maintain a commercial paper program, have access to a committed revolving credit facility and have access to equity and debt capital from public and private sources. We continue to balance our operating, investing and financing uses of cash through investments and acquisitions in our core businesses, dividends and share repurchases. In addition, we believe our cash position, amounts available under our credit facility, commercial paper program and cash provided by operating activities will be adequate to cover our operational and business needs in the foreseeable future.

[0000833444-15-000013:mdna:92]
As of December 26, 2014 and September 26, 2014, our cash and cash equivalents, total debt and Tyco shareholders' equity are as follows:

[0000833444-15-000013:mdna:93]
|  | As of |
| ($ in millions) | December 26, 2014 |  | September 26, 2014 |
| Cash and cash equivalents (1) | $ | 473 |  |  | $ | 892 |  |
| Total debt | 1,462 |  |  | 1,463 |  |
| Total Tyco shareholders' equity | 4,234 |  |  | 4,647 |  |
| Total debt as a % of total capital (2) | 25.7 | % |  | 23.9 | % |

[0000833444-15-000013:mdna:94]
(1) The Company anticipates making cash payments of approximately $600 million during the remainder of fiscal 2015 to resolve liabilities relating to the Company's asbestos related matters.

[0000833444-15-000013:mdna:95]
(2) Total capital represents the aggregate amount of total debt and total Tyco Shareholders' equity which was $5,696 million and $6,110 million as of December 26, 2014 and September 26, 2014, respectively.

[0000833444-15-000013:mdna:96]
[same as prior period, unchanged from 0000833444-14-000099:mdna:24]

[0000833444-15-000013:mdna:97]
[same as prior period, unchanged from 0000833444-14-000099:mdna:109]

[0000833444-15-000013:mdna:98]
Our cash flows from operating, investing and financing from continuing operations for the three months ended December 26, 2014 and December 27, 2013 are summarized below:

[0000833444-15-000013:mdna:99]
|  | For the Three Months Ended |
| ($ in millions) | December 26, 2014 |  | December 27, 2013 |
| Net cash provided by operating activities | $ | 96 |  |  | $ | 100 |  |
| Net cash provided by (used in) investing activities | 7 |  |  | (38 | ) |
| Net cash used in financing activities | (512 | ) |  | (139 | ) |

[0000833444-15-000013:mdna:100]
[same as prior period, unchanged from 0000833444-14-000099:mdna:112]

[0000833444-15-000013:mdna:101]
Cash flow from operating activities can fluctuate significantly from period to period as working capital needs and the timing of payments for items such as restructuring activities, asbestos activities, pension funding, income taxes and other items impact reported cash flow.

[0000833444-15-000013:mdna:102]
The net change in working capital decreased operating cash flow by $180 million in the three months ended December 26, 2014. The significant changes in working capital included a $43 million increase in inventories, a $41 million decrease in accounts payable, a $37 million decrease in deferred revenue and a $33 million decrease in accrued and other liabilities.

[0000833444-15-000013:mdna:103]
The net change in working capital decreased operating cash flow by $233 million in the three months ended December 27, 2013. The significant changes in working capital included a $105 million decrease in accrued and other liabilities, a $54 million increase in prepaid expenses and other assets, a $41 million decrease in accounts payable, a $40 million decrease in deferred revenue, and a $30 million increase in inventories.

[0000833444-15-000013:mdna:104]
During the three months ended December 26, 2014, we received $12 million in cash from Mr. Swartz, $5 million of which will be shared pursuant to the terms of the class action lawsuit, resulting in a net recovery of $7 million.

[0000833444-15-000013:mdna:105]
During the three months ended December 26, 2014 and December 27, 2013, we paid approximately $27 million and $24 million, respectively, in cash related to restructuring activities.

[0000833444-15-000013:mdna:106]
In connection with the 2012 Separation, we paid $2 million and $15 million in separation costs during the three months ended December 26, 2014 and December 27, 2013, respectively.

[0000833444-15-000013:mdna:107]
During the three months ended December 26, 2014 and December 27, 2013, we made net payments related to asbestos liabilities of $5 million and $3 million, respectively.

[0000833444-15-000013:mdna:108]
During the three months ended December 26, 2014 and December 27, 2013, we made payments related to environmental remediation activities for a facility located in Marinette, Wisconsin, of $7 million and $31 million respectively.

[0000833444-15-000013:mdna:109]
During the three months ended December 27, 2013, Tyco settled a tax dispute with CIT Group, a former subsidiary.  Under the terms of the settlement agreement, Tyco received $60 million of which $25 million and $19 million was subsequently paid during fiscal 2014 to Covidien and TE Connectivity, respectively, under the terms of the 2007 Tax Sharing Agreement.

[0000833444-15-000013:mdna:110]
During the three months ended December 26, 2014 and December 27, 2013, we made required contributions of $1 million and $3 million, respectively, to our U.S. pension plans and $5 million and $8 million, respectively, to our non-U.S. pension plans. We anticipate that we will contribute at least the minimum required to our pension plans in 2015 of $13 million for our U.S. plans and $23 million for our non-U.S. plans.

[0000833444-15-000013:mdna:111]
Income taxes paid, net of refunds, related to continuing operations were $26 million and $17 million during the three months ended December 26, 2014 and December 27, 2013, respectively.

[0000833444-15-000013:mdna:112]
Net interest paid related to continuing operations was $10 million for both the three months ended December 26, 2014 and December 27, 2013.

[0000833444-15-000013:mdna:113]
[same as prior period, unchanged from 0000833444-14-000099:mdna:125]

[0000833444-15-000013:mdna:114]
[same as prior period, unchanged from 0000833444-14-000099:mdna:126]

[0000833444-15-000013:mdna:115]
We made capital expenditures of $66 million and $63 million for the three months ended December 26, 2014 and December 27, 2013, respectively. The level of capital expenditures in fiscal 2015 is expected to exceed the spending levels in fiscal 2014 and is also expected to exceed depreciation expense.

[0000833444-15-000013:mdna:116]
During the three months ended December 26, 2014, we paid cash for acquisitions included in continuing operations totaling $152 million, net of cash acquired of $23 million, which related to acquisitions in our ROW Installation & Services and Global Products segments.  During the three months ended December 27, 2013, we paid cash for acquisitions included in continuing operations totaling $54 million, net of $1 million cash acquired, which related to an acquisition included in our NA Installation & Services segment and ROW Installation & Services segments.

[0000833444-15-000013:mdna:117]
We maintain captive insurance companies to manage certain of our insurable liabilities. The captive insurance companies held certain investment accounts for the purposes of providing collateral for our insurable liabilities.  During fiscal 2014, the portfolio of investments was liquidated and we now provide letters of credit as collateral.  During the three months ended December 27, 2013, our captive insurance companies made net sales of approximately $80 million.  See Notes 10 and 18 to our unaudited Consolidated Financial Statements.

[0000833444-15-000013:mdna:118]
During the three months ended December 26, 2014, our time deposits of $275 million matured.

[0000833444-15-000013:mdna:119]
During the three months ended December 26, 2014, our restricted cash increased by $45 million.  This increase was primarily driven by $22 million related to the asbestos-related qualified settlement fund and $12 million of cash received from Mr. Swartz.

[0000833444-15-000013:mdna:120]
[same as prior period, unchanged from 0000833444-14-000099:mdna:133]

[0000833444-15-000013:mdna:121]
Cash flows from financing activities relate primarily to proceeds received from incurring debt and issuing stock, and cash used to repay debt, repurchase stock and make dividend payments to shareholders.

[0000833444-15-000013:mdna:122]
As of December 26, 2014 and September 26, 2014, TIFSA had no commercial paper outstanding.  The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1 billion as of December 26, 2014.  As of December 27, 2013, TIFSA had $160 million of commercial paper outstanding, which bore interest at a weighted-average rate of 0.31%.

[0000833444-15-000013:mdna:123]
As of December 26, 2014 and December 27, 2013, there were no amounts drawn under the Company's revolving credit facility.

[0000833444-15-000013:mdna:124]
Pursuant to our share repurchase program, we may repurchase Tyco shares from time to time in open market purchases at prevailing market prices, in negotiated transactions off the market, or pursuant to an approved trading plan in accordance with applicable regulations.  During the three months ended December 26, 2014, we repurchased approximately 10 million ordinary  shares for approximately $417 million.  During the three months ended December 27, 2013, we repurchased approximately 7 million ordinary shares for approximately $250 million.

[0000833444-15-000013:mdna:125]
On March 5, 2014, our shareholders approved a cash dividend of $0.72 per ordinary share payable to shareholders in four quarterly installments of $0.18 in May 2014, August 2014, November 2014 and February 2015. During the three months ended December 26, 2014 and December 27, 2013, we paid cash dividends of approximately $75 million and $74 million, respectively.

[0000833444-15-000013:mdna:126]
Included in cash flows from financing activities for the three months ended December 26, 2014 is payment of contingent consideration of $23 million related to the acquisition of a business during fiscal year 2014.

[0000833444-15-000013:mdna:127]
Management believes that cash generated by or available to us should be sufficient to fund our capital and operational business needs for the foreseeable future, including capital expenditures, quarterly dividend payments, share repurchases, separation-related, asbestos-related and other expenses.

[0000833444-15-000013:mdna:128]
Commitments and Contingencies

[0000833444-15-000013:mdna:129]
For a detailed discussion of contingencies related to tax and litigation matters, see Notes 6 and 11 to our unaudited Consolidated Financial Statements.

[0000833444-15-000013:mdna:130]
[same as prior period, unchanged from 0000833444-14-000099:mdna:142]

[0000833444-15-000013:mdna:131]
We had a backlog of unfilled orders of $4,824 million and $4,862 million as of December 26, 2014 and September 26, 2014, respectively.

[0000833444-15-000013:mdna:132]
[same as prior period, unchanged from 0000833444-14-000099:mdna:144]

[0000833444-15-000013:mdna:133]
|  | NA Installation& Services |  | ROWInstallation& Services |  | GlobalProducts |  | Total |
| As of September 26, 2014 |  |  |  |  |  |  |  |
| Backlog | $ | 992 |  |  | $ | 999 |  |  | $ | 181 |  |  | $ | 2,172 |  |
| Recurring revenue in force | 1,243 |  |  | 1,143 |  |  | — |  |  | 2,386 |  |
| Deferred revenue | 266 |  |  | 38 |  |  | — |  |  | 304 |  |
| Total Backlog | $ | 2,501 |  |  | $ | 2,180 |  |  | $ | 181 |  |  | $ | 4,862 |  |
| As of December 26, 2014 |  |  |  |  |  |  |  |  |  |  |  |
| Backlog | $ | 1,016 |  |  | $ | 954 |  |  | $ | 201 |  |  | $ | 2,171 |  |
| Recurring revenue in force | 1,236 |  |  | 1,122 |  |  | — |  |  | 2,358 |  |
| Deferred revenue | 258 |  |  | 37 |  |  | — |  |  | 295 |  |
| Total Backlog | $ | 2,510 |  |  | $ | 2,113 |  |  | $ | 201 |  |  | $ | 4,824 |  |

[0000833444-15-000013:mdna:134]
Backlog decreased $38 million, or 0.8%, to $4,824 million as of December 26, 2014 compared to $4,862 million as of September 26, 2014.  Changes in foreign currency unfavorably impacted backlog by $122 million, or 2.5%, primarily in our ROW Installation & Services segment.  This was partially offset by $84 million of increases across all of our segments, particularly by a 13.7% increase in Global Products led by the Security Products business, a 1.7% increase in ROW Installation & Services led by growth markets, and a 0.9% increase in NA Installation & Services led by our fire business.  Included in the aforementioned increase was backlog of $20 million related to the acquisitions made during the quarter, which primarily benefited our ROW Installation & Services segment.

[0000833444-15-000013:mdna:135]
[same as prior period, unchanged from 0000833444-14-000099:mdna:148]

[0000833444-15-000013:mdna:136]
The Company and certain of its subsidiaries have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions. The guarantees would typically be triggered in the event of nonperformance and we believe that performance under the guarantees, if required, would not have a material effect on our financial position, results of operations or cash flows.

[0000833444-15-000013:mdna:137]
There are certain guarantees or indemnifications extended among Tyco, Covidien, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 Separation and Distribution Agreements and the Tax Sharing Agreements. The guarantees primarily relate to certain contingent tax liabilities included in the Tax Sharing Agreements. At the time of the 2007 and 2012 Separations, we recorded liabilities necessary to recognize the fair value of such guarantees and indemnifications. See Note 6 to the unaudited Consolidated Financial Statements. In addition, prior to the 2007 and 2012 Separations we provided support in the form of financial and/or performance guarantees to various Covidien, TE Connectivity, ADT and Tyco Flow Control operating entities. To the extent these guarantees were not assigned in connection with the 2007 and 2012 Separations, we remained as the guarantor, but were typically indemnified by the former subsidiary. See Note 18 to the unaudited Consolidated Financial Statements.

[0000833444-15-000013:mdna:138]
In disposing of assets or businesses, we often provide representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities, and unidentified tax liabilities and legal fees related to periods prior to disposition. We have no reason to believe that these uncertainties would have a material adverse effect on our financial position, results of operations or cash flows. We have recorded liabilities for known indemnifications included as part of environmental liabilities. See Note 11 to the unaudited Consolidated Financial Statements.

[0000833444-15-000013:mdna:139]
[same as prior period, unchanged from 0000833444-14-000099:mdna:152]

[0000833444-15-000013:mdna:140]
[same as prior period, unchanged from 0000833444-14-000099:mdna:154]

[0000833444-15-000013:mdna:141]
[same as prior period, unchanged from 0000833444-14-000099:mdna:155]

[0000833444-15-000013:mdna:142]
[same as prior period, unchanged from 0000833444-14-000099:mdna:156]

[0000833444-15-000013:mdna:143]
[same as prior period, unchanged from 0000833444-14-000099:mdna:157]

[0000833444-15-000013:mdna:144]
Quarter Ended December 26, 2014

[0000833444-15-000013:mdna:145]
|  | Net Revenue for the Quarter Ended December 27, 2013 |  | Base YearAdjustmentsDivestitures / Other |  | AdjustedFiscal 2014Base Revenue |  | ForeignCurrency |  | Acquisitions |  | OrganicRevenue(1) |  | OrganicGrowthPercentage |  | Net Revenue for the Quarter Ended December 26, 2014 |
|  | ($ in millions) |
| NA Installation & Services | $ | 957 |  |  | $ | — |  |  | $ | 957 |  |  | $ | (9 | ) |  | $ | 4 |  |  | $ | (1 | ) |  | (0.1 | )% |  | $ | 951 |  |
| ROW Installation & Services | 971 |  |  | (13 | ) |  | 958 |  |  | (63 | ) |  | 20 |  |  | 2 |  |  | 0.2 | % |  | 917 |  |
| Global Products | 565 |  |  | — |  |  | 565 |  |  | (17 | ) |  | 5 |  |  | 58 |  |  | 10.3 | % |  | 611 |  |
| Total Net Revenue | $ | 2,493 |  |  | $ | (13 | ) |  | $ | 2,480 |  |  | $ | (89 | ) |  | $ | 29 |  |  | $ | 59 |  |  | 2.4 | % |  | $ | 2,479 |  |

[0000833444-15-000013:mdna:146]
[same as prior period, unchanged from 0000833444-14-000099:mdna:160]

[0000833444-15-000013:mdna:147]
| (1) | Organic revenue growth percentage based on adjusted fiscal 2014 base revenue. |

[0000833444-15-000013:mdna:148]
[same as prior period, unchanged from 0000833444-14-000099:mdna:167]

[0000833444-15-000013:mdna:149]
[same as prior period, unchanged from 0000833444-14-000099:mdna:168]

[0000833444-15-000013:mdna:150]
[same as prior period, unchanged from 0000833444-14-000099:mdna:169]

[0000833444-15-000013:mdna:151]
[same as prior period, unchanged from 0000833444-14-000099:mdna:170]

[0000833444-15-000013:mdna:152]
[same as prior period, unchanged from 0000833444-14-000099:mdna:171]

[0000833444-15-000013:mdna:153]
| • | the outcome of litigation, arbitrations and governmental proceedings; |

[0000833444-15-000013:mdna:154]
| • | effect of income tax audits, litigation, settlements and appeals; |

[0000833444-15-000013:mdna:155]
[same as prior period, unchanged from 0000833444-14-000099:mdna:175]

[0000833444-15-000013:mdna:156]
[same as prior period, unchanged from 0000833444-14-000099:mdna:176]

[0000833444-15-000013:mdna:157]
[same as prior period, unchanged from 0000833444-14-000099:mdna:177]

[0000833444-15-000013:mdna:158]
[same as prior period, unchanged from 0000833444-14-000099:mdna:178]

[0000833444-15-000013:mdna:159]
[same as prior period, unchanged from 0000833444-14-000099:mdna:179]

[0000833444-15-000013:mdna:160]
[same as prior period, unchanged from 0000833444-14-000099:mdna:180]

[0000833444-15-000013:mdna:161]
[same as prior period, unchanged from 0000833444-14-000099:mdna:181]

[0000833444-15-000013:mdna:162]
[same as prior period, unchanged from 0000833444-14-000099:mdna:182]

[0000833444-15-000013:mdna:163]
[same as prior period, unchanged from 0000833444-14-000099:mdna:183]

[0000833444-15-000013:mdna:164]
[same as prior period, unchanged from 0000833444-14-000099:mdna:184]

[0000833444-15-000013:mdna:165]
[same as prior period, unchanged from 0000833444-14-000099:mdna:185]

[0000833444-15-000013:mdna:166]
[same as prior period, unchanged from 0000833444-14-000099:mdna:186]

[0000833444-15-000013:mdna:167]
[same as prior period, unchanged from 0000833444-14-000099:mdna:187]

[0000833444-15-000013:mdna:168]
[same as prior period, unchanged from 0000833444-14-000099:mdna:188]

[0000833444-15-000013:mdna:169]
| • | natural events such as severe weather, fires, floods and earthquakes; and |

[0000833444-15-000013:mdna:170]
| • | acts of terrorism, cyber-attacks or our inability to maintain adequate security related information networks and data. |
