# JCI notes — 0000833444-15-000013


## tyc:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesAndNewAccountingPronouncementsTextBlock

[0000833444-15-000013:notes:1]
Basis of Presentation and Summary of Significant Accounting Policies

[0000833444-15-000013:notes:2]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year.  These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 26, 2014 (the "2014 Form 10-K").

[0000833444-15-000013:notes:3]
References to 2015 and 2014 are to Tyco's fiscal quarters ending December 26, 2014 and December 27, 2013, respectively, unless otherwise indicated. The Company has a 52 or 53-week fiscal year that ends on the last Friday in September. Fiscal years 2015 and 2014 are both 52-week years.

[0000833444-15-000013:notes:4]
Change of Jurisdiction - On November 17, 2014, Tyco International Ltd., an entity organized under the laws of Switzerland ("Tyco Switzerland"), completed its change of jurisdiction of incorporation from Switzerland to Ireland by merging with its subsidiary, Tyco International plc ("Tyco Ireland"), a public limited company incorporated under the laws of Ireland (the "Merger"). As a result of the Merger, Tyco Ireland is the successor issuer to Tyco Switzerland, has succeeded to the attributes of Tyco Switzerland as the registrant under SEC regulations, and has assumed all pre-Merger obligations of Tyco Switzerland.

[0000833444-15-000013:notes:5]
Reclassifications - Certain prior period amounts have been reclassified to conform with current period presentation as discussed below.

[0000833444-15-000013:notes:6]
During the third quarter of fiscal 2014, the Company completed the sale of its South Korean security business (“ADT Korea”) to an affiliate of The Carlyle Group. The Company has reclassified the operations of its South Korean security business to Income from discontinued operations in the Consolidated Statements of Operations for all periods presented and assets and liabilities have been reclassified as held for sale for periods prior to the third quarter of fiscal 2014 as it satisfied the criteria to be presented as discontinued operations for those periods.  See Note 3.

[0000833444-15-000013:notes:7]
In addition, the Company has reclassified several businesses in the Rest of World ("ROW") Installation & Services segment to Income from discontinued operations in the Consolidated Statements of Operations and the assets and liabilities as held for sale within the Consolidated Balance Sheets for all periods presented as they satisfied the criteria to be presented as discontinued operations.  The Company expects to complete the sale of these businesses by the end of the third quarter of fiscal 2015. See Note 3.

[0000833444-15-000013:notes:8]
Recently Adopted Accounting Pronouncements - In March 2013, the FASB issued authoritative guidance to resolve diversity in practice on the accounting for the cumulative translation adjustment ("CTA") when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within a foreign entity. The guidance requires that the parent release any CTA into net income when the parent ceases to have a controlling financial interest in a subsidiary or group of assets within a foreign entity which results in a substantially complete liquidation of the foreign entity; when the sale of an investment in a foreign entity results in the loss of a controlling financial interest; or where an acquirer obtains control of an acquiree in which it had an equity interest immediately before the acquisition date. The guidance does not change the requirement to release a pro rata portion of the CTA into net income upon a partial sale of an equity method investment that is a foreign entity. The guidance became effective for Tyco in the first quarter of fiscal 2015. The adoption of this guidance did not have a material impact on the Company's financial position, results of operations or cash flows.

[0000833444-15-000013:notes:9]
In July 2013, the FASB issued authoritative guidance for the presentation of an unrecognized tax benefit when a net operating loss (“NOL”) carryforward, a similar tax loss, or a tax credit carryforward exists. The guidance requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, in the financial statements as a reduction to a deferred tax asset for a NOL carryforward, a similar tax loss, or a tax credit carryforward. If the NOL carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the jurisdiction or the tax law of the jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit will be presented in the financial statements as a liability and will not be combined with deferred tax assets.  This guidance does not require any additional recurring disclosures and became effective for Tyco during the first fiscal quarter of fiscal 2015. The adoption of this guidance did not have a material impact on the Company's financial position, results of operations or cash flows.

[0000833444-15-000013:notes:10]
Recently Issued Accounting Pronouncements - In April 2014, the FASB issued authoritative guidance to change the criteria for reporting discontinued operations.  Under the new guidance, only disposals representing a strategic shift in a company's operations and financial results should be reported as discontinued operations, with expanded disclosures. In addition, disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify as a discontinued operation is required.  This guidance is effective for Tyco in the first quarter of fiscal 2016, with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance will have upon adoption.

[0000833444-15-000013:notes:11]
In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires both quantitative and qualitative disclosures, which are more comprehensive than existing revenue standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. This guidance will be effective for Tyco in the first fiscal quarter of 2018, with early adoption not permitted. The Company is currently assessing the impact the guidance will have upon adoption.


## tyc:ScheduleOfIntangibleAssetsTextBlock

[0000833444-15-000013:notes:12]
The following table sets forth the gross carrying amount and accumulated amortization of the Company's intangible assets as of December 26, 2014 and September 26, 2014 ($ in millions):

[0000833444-15-000013:notes:13]
|  | As of |
|  | December 26, 2014 |  | September 26, 2014 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Amortizable: |  |  |  |  |  |  |  |
| Contracts and related customer relationships | $ | 1,370 |  |  | $ | 1,067 |  |  | $ | 1,405 |  |  | $ | 1,117 |  |
| Intellectual property | 664 |  |  | 494 |  |  | 622 |  |  | 492 |  |
| Other | 38 |  |  | 18 |  |  | 38 |  |  | 16 |  |
| Total | $ | 2,072 |  |  | $ | 1,579 |  |  | $ | 2,065 |  |  | $ | 1,625 |  |
| Non-Amortizable: |  |  |  |  |  |  |  |
| Intellectual property | $ | 220 |  |  |  |  |  | $ | 221 |  |  |  |
| Franchise rights | 76 |  |  |  |  |  | 76 |  |  |  |
| Other | 7 |  |  |  |  | — |  |  |  |
| Total | $ | 303 |  |  |  |  |  | $ | 297 |  |  |  |


## tyc:ScheduleOfNetReceivablesAndLiabilitiesRecordedUnderTaxSharingAgreementsTableTextBlock

[0000833444-15-000013:notes:14]
he receivables and liabilities related to the 2012 and 2007 Tax Sharing Agreements as of December 26, 2014 and September 26, 2014, are as follows ($ in millions):

[0000833444-15-000013:notes:15]
|  | 2012 Tax Sharing Agreement |  | 2007 Tax Sharing Agreement |
|  | As of |  | As of |
|  | December 26, 2014 |  | September 26, 2014 |  | December 26, 2014 |  | September 26, 2014 |
| Tax sharing agreement related receivables: |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | 3 |  |
| Other assets | — |  |  | — |  |  | 23 |  |  | 23 |  |
|  | — |  |  | — |  |  | 26 |  |  | 26 |  |
| Tax sharing agreement related liabilities: |  |  |  |  |  |  |  |
| Accrued and other current liabilities | — |  |  | — |  |  | (21 | ) |  | (21 | ) |
| Other liabilities | (46 | ) |  | (46 | ) |  | (194 | ) |  | (194 | ) |
|  | (46 | ) |  | (46 | ) |  | (215 | ) |  | (215 | ) |
| Net liability | $ | (46 | ) |  | $ | (46 | ) |  | $ | (189 | ) |  | $ | (189 | ) |


## tyc:ScheduleOfRestructuringReserveByBalanceSheetLocationTextBlock

[0000833444-15-000013:notes:16]
As of December 26, 2014 and September 26, 2014, restructuring reserves related to all actions were included in the Company's Consolidated Balance Sheets as follows ($ in millions):

[0000833444-15-000013:notes:17]
|  | As of |
|  | December 26, 2014 |  | September 26, 2014 |
| Accrued and other current liabilities | $ | 110 |  |  | $ | 83 |  |
| Other liabilities | 16 |  |  | 16 |  |
| Total | $ | 126 |  |  | $ | 99 |  |


## tyc:ScheduleOfSegmentReportingInformationNetRevenueAndOperatingIncomeLossBySegmentTableTextBlock

[0000833444-15-000013:notes:18]
Selected information by segment is presented in the following tables ($ in millions):

[0000833444-15-000013:notes:19]
|  | For the Quarters Ended |
|  | December 26, 2014 |  | December 27, 2013 |
| Net revenue(1): |  |  |  |
| NA Installation & Services | $ | 951 |  |  | $ | 957 |  |
| ROW Installation & Services | 917 |  |  | 971 |  |
| Global Products | 611 |  |  | 565 |  |
|  | $ | 2,479 |  |  | $ | 2,493 |  |

[0000833444-15-000013:notes:20]
_____________________________________________________________________________

[0000833444-15-000013:notes:21]
| (1) | Net revenue by operating segment excludes intercompany transactions. |

[0000833444-15-000013:notes:22]
|  | For the Quarters Ended |
|  | December 26, 2014 |  | December 27, 2013 |
| Operating income (loss): |  |  |  |
| NA Installation & Services | $ | 105 |  |  | $ | 117 |  |
| ROW Installation & Services | 69 |  |  | 95 |  |
| Global Products | 98 |  |  | 86 |  |
| Corporate and Other (1) | (74 | ) |  | 46 |  |
|  | $ | 198 |  |  | $ | 344 |  |

[0000833444-15-000013:notes:23]
_______________________________________________________________________________

[0000833444-15-000013:notes:24]
| (1) | Operating income for the quarter ended December 27, 2013 includes $92 million of income related to the settlement of a legacy legal matter with former management and $16 million of income related to the CIT settlement. See Note 11. |


## tyc:SeparationTransactionDisclosureTextBlock

[0000833444-15-000013:notes:25]
[same as prior period, unchanged from 0000833444-14-000099:notes:240]

[0000833444-15-000013:notes:26]
On September 28, 2012, the Company completed the spin-offs of The ADT Corporation ("ADT") and Pentair Ltd. (formerly known as Tyco Flow Control International Ltd. ("Tyco Flow Control")), formerly the North American residential security and flow control businesses of Tyco, respectively, into separate, publicly traded companies in the form of a distribution to Tyco shareholders ("2012 Separation").

[0000833444-15-000013:notes:27]
In connection with activities taken to complete the 2012 Separation and to create the revised organizational structure of the Company, the Company incurred pre-tax charges ("Separation Charges") within Selling, general and administrative expenses of $2 million and $15 million during the quarters ended December 26, 2014 and December 27, 2013, respectively.  The Company received associated tax benefits of $1 million and $6 million during the quarters ended December 26, 2014 and December 27, 2013, respectively. The Company does not expect to incur material separation charges relating to activities taken to complete the 2012 Separation in future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000833444-15-000013:notes:28]
[same as prior period, unchanged from 0000833444-14-000099:notes:4]

[0000833444-15-000013:notes:29]
During the quarter ended December 26, 2014, total consideration for acquisitions included in continuing operations totaled $152 million, which was comprised of $175 million cash paid, net of $23 million cash acquired, for five acquisitions which were not material. The acquisitions will be integrated into the ROW Installation & Services and Global Products segments. In connection with one of the acquisitions, the Company acquired a majority interest and recorded a nonredeemable noncontrolling interest of $29 million as of December 26, 2014.  The final determination of fair value for certain assets and liabilities relating to four of the acquisitions made during the quarter ended December 26, 2014 remain subject to change based on final valuations of the assets acquired and liabilities assumed.  The Company does not expect the finalization of these matters to have a material effect on the allocation, which is expected to be completed within fiscal 2015.

[0000833444-15-000013:notes:30]
In addition, during the quarter ended December 26, 2014, the Company announced that it had reached an agreement to acquire Industrial Safety Technologies ("IST"), a global leader in gas and flame detection, with operations in Europe, the Middle East, China and the U.S. Gulf Coast region from Battery Ventures, for approximately $330 million in cash. IST will be integrated into the Global Products segment. The sale is expected to close during the second quarter of fiscal 2015.

[0000833444-15-000013:notes:31]
During the quarter ended December 27, 2013, total consideration included in continuing operations was $54 million which was primarily related to the acquisition of Westfire, Inc. ("Westfire") on November 8, 2013.  Westfire, a fire protection services company with operations in the United States, Chile and Peru, provides critical special-hazard suppression and detection applications in mining, telecommunications and other vertical markets and will be integrated with the NA Installation & Services and ROW Installation & Services segments.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-15-000013:notes:32]
Commitments and Contingencies

[0000833444-15-000013:notes:33]
Legacy Matters Related to Former Management

[0000833444-15-000013:notes:34]
In recent years, the Company has settled several lawsuits involving disputes with former management. With respect to Mr. Kozlowski, the Company's former chief executive officer, in the first quarter of fiscal 2014, the parties signed an agreement resolving all outstanding disputes, with Mr. Kozlowski agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements. As a result, in the first quarter of fiscal 2014, the Company reversed a non-cash net liability of approximately $92 million which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations for the amounts allegedly due to him.  Pursuant to the settlement agreement, Tyco will be entitled to a portion of the proceeds, if any, from the future sale of certain assets owned by Mr. Kozlowski, the timing and amount of which is uncertain at this time.

[0000833444-15-000013:notes:35]
With respect to Mr. Swartz, the Company's former chief financial officer, in November 2014, the parties reached a definitive agreement to resolve all outstanding disputes, with Mr. Swartz agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements alleged to have existed between him and the Company.  In the first quarter of fiscal 2015, the Company also received approximately $12 million in cash from Mr. Swartz, $5 million of which will be shared pursuant to the terms of the class action lawsuit, resulting in a net recovery of $7 million which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations. The cash received has been classified as restricted.

[0000833444-15-000013:notes:36]
Environmental Matters

[0000833444-15-000013:notes:37]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of December 26, 2014, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $30 million to $73 million. As of December 26, 2014, Tyco concluded that the best estimate within this range is approximately $34 million, of which $15 million is included in Accrued and other current liabilities and $19 million is included in Other liabilities in the Company's Consolidated Balance Sheet.

[0000833444-15-000013:notes:38]
The majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. Prior to Tyco's acquisition, Ansul manufactured arsenic-based agricultural herbicides at the Marinette facility, which resulted in significant arsenic contamination of soil and groundwater on the Marinette site and in parts of the adjoining Menominee River. Ansul has been engaged in ongoing remediation efforts at the Marinette site since 1990, and in February 2009 entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the Marinette site. Under this agreement, Ansul's principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. As of December 26, 2014, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $20 million to $47 million. The Company's best estimate within that range is approximately $23 million, of which $11 million is included in Accrued and other current liabilities and $12 million is included in Other liabilities in the Company's Consolidated Balance Sheet.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor the arsenic contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.

[0000833444-15-000013:notes:39]
Asbestos Matters

[0000833444-15-000013:notes:40]
The Company and certain of its subsidiaries, including Yarway Corporation (“Yarway”) and Grinnell LLC (“Grinnell”), along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. Over 90% of cases pending against affiliates of the Company have been filed against Yarway or Grinnell, and have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components. Claims filed against Yarway derive from Yarway’s purported use of asbestos-containing gaskets and packing in the sale or distribution of steam valves and traps and from its alleged manufacture of asbestos-containing expansion joint packing. Yarway’s alleged manufacture, distribution and/or sale of asbestos-containing materials ceased by 1988, and Yarway ceased substantially all of its manufacturing, distribution and sales operations in 2003. Claims filed against Grinnell typically allege that it manufactured, sold or distributed valves, gaskets, piping and sprinkler systems containing asbestos.

[0000833444-15-000013:notes:41]
As of December 26, 2014, the Company has determined that there were approximately 5,700 claims pending against it, which includes approximately 3,200 claims pending against Yarway. This amount reflects the Company's current estimate of the number of viable claims made against it and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties. Additionally, as a result of the Yarway bankruptcy filing described below, claims against Yarway have been stayed since April 2013.

[0000833444-15-000013:notes:42]
As of December 26, 2014, the Company's estimated net liability, including Yarway, recorded within the Company's Consolidated Balance Sheet is $605 million.  The net liability is comprised of a liability for pending and future claims and related defense costs of $850 million, of which $353 million is recorded in Accrued and other current liabilities, and $497 million is recorded in Other liabilities.  The Company also maintains separate insurance recovery related assets of $245 million, of which $22 million is recorded in Prepaid expenses and other current assets, and $223 million is recorded in Other assets.  Insurance recovery related assets include $22 million of cash which has been designated as restricted.  The Company believes that its asbestos related liabilities and insurance related assets as of December 26, 2014 are appropriate. Similarly, as of September 26, 2014, the Company's estimated net liability, including Yarway, of $608 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs of $853 million, and separately as an asset for insurance recoveries of $245 million.

[0000833444-15-000013:notes:43]
Yarway

[0000833444-15-000013:notes:44]
As previously disclosed, on April 22, 2013 Yarway filed a voluntary petition for relief under Chapter 11 of the U.S. Bankruptcy Code (“Chapter 11”) in the United States Bankruptcy Court for the District of Delaware (“Bankruptcy Court”). As a result of this filing, the continuation or commencement of asbestos-related litigation against Yarway has been enjoined by the automatic stay imposed by the U.S. Bankruptcy Code. Yarway's goal has been to negotiate, obtain approval of, and consummate a plan of reorganization that establishes a trust to fairly and equitably value and pay current and future Yarway asbestos claims, and that, in exchange for funding of the trust by the Company and/or its subsidiaries, provides permanent injunctive relief protecting the Company, each of its current and former affiliates and various other parties (the “Company Protected Parties”) from any further asbestos claims based on products manufactured, sold, and/or distributed by Yarway. On October 9, 2014, the Company reached an agreement in principle with Yarway, the Official Committee of Asbestos Claimants (“ACC”) appointed in the Yarway Chapter 11 case as the representative of current Yarway asbestos claimants, and the Future Claimants Representative (“FCR”) appointed in the Yarway Chapter 11 case as the representative of future Yarway asbestos claimants, to fund a section 524(g) trust for the resolution and payment of current and future Yarway asbestos claims. The agreement in principle, which will be implemented through a Chapter 11 plan for Yarway, will resolve the potential liability of the Company Protected Parties for pending and future derivative personal injury claims related to exposure to asbestos-containing products that were allegedly manufactured, distributed, and/or sold by Yarway (“Yarway Asbestos Claims”). Under the Chapter 11 plan, an asbestos settlement trust (the “Yarway Trust”) that conforms to the provisions of Section 524(g) of the U.S. Bankruptcy Code will be established and, on the effective date of the Chapter 11 plan, the Company and Yarway will contribute to the Yarway Trust a total of $325 million in cash (“Settlement Consideration”), which includes approximately $100 million relating to the settlement of intercompany amounts allegedly due to Yarway. In exchange for the Settlement Consideration, each of the Company Protected Parties will receive the benefit of a release from Yarway and an injunction under section 524(g) of the Bankruptcy Code permanently enjoining the assertion of Yarway Asbestos Claims against those Parties. The agreement in principle is subject, among other things, to the negotiation and filing of a Chapter 11 plan of reorganization for Yarway incorporating the terms of such agreement (the “Plan”), acceptance of the Plan by at least 75% of Yarway’s current asbestos claimants voting on such Plan, confirmation of the Plan by the Bankruptcy Court and approval of the injunction in favor of the Company Protected Parties by the United States District Court for the District of Delaware (“District Court”). On the effective date of the Plan, which is anticipated to occur in the second half of fiscal 2015, the Company and Yarway will pay the Settlement Consideration and Yarway Asbestos Claims against the Company Protected Parties will be permanently enjoined. Yarway is anticipated to become a wholly-owned subsidiary of the Yarway Trust and, accordingly, would no longer be owned by or be part of a consolidated group with the Company. Unless extended by a further agreement, the agreement in principle will expire if the order confirming the Plan and implementing the injunction has not been entered or affirmed by the District Court by June 30, 2015, or if the effective date of the Plan has not occurred by September 15, 2016. As a result of the agreement in principle to settle, the Company recorded a charge of $225 million in Selling, general and administrative expenses in the Consolidated Statement of Operations during the fourth fiscal quarter of 2014.

[0000833444-15-000013:notes:45]
As a result of filing the voluntary bankruptcy petition during the third quarter of fiscal 2013, the Company recorded an expected loss upon deconsolidation of $10 million related to the Yarway Chapter 11 filing, which continues to represent the Company’s best estimate of its loss.

[0000833444-15-000013:notes:46]
Other Claims

[0000833444-15-000013:notes:47]
The Company continuously assesses the sufficiency of its estimated liability for pending and future asbestos claims and defense costs. On a quarterly basis, the Company evaluates actual experience regarding asbestos claims filed, settled and dismissed, amounts paid in settlements, and the recoverability of its insurance assets. If and when data from actual experience demonstrate an unfavorable discernible trend, the Company performs a valuation of its asbestos related liabilities and corresponding insurance assets including a comprehensive review of the underlying assumptions. In addition, the Company evaluates its ability to reasonably estimate claim activity beyond its current look-forward period in order to assess whether such period is appropriate. In addition to claims and litigation experience, the Company considers additional qualitative and quantitative factors such as changes in legislation, the legal environment, the Company’s strategy in managing claims and obtaining insurance, including its defense strategy, and health related trends in the overall population of individuals potentially exposed to asbestos. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance assets is warranted.

[0000833444-15-000013:notes:48]
During the fourth quarter of fiscal 2014, the Company concluded that an unfavorable trend had developed in actual claim filing activity compared to projected claim filing activity established during the Company’s most recent valuation. Accordingly, the Company, with the assistance of independent actuarial service providers, performed a revised valuation of its asbestos-related liabilities and corresponding insurance assets. As part of the revised valuation, the Company assessed whether a change in its look-forward period was appropriate, taking into consideration its more extensive history and experience with asbestos-related claims and litigation (including its experience with Yarway), and determined that it was now possible to make a reasonable estimate of the actuarially determined ultimate risk of loss for pending and unasserted potential future asbestos-related claims through 2056. In connection with the revised valuation, the Company considered a recent settlement with one of its insurers calling for the establishment of a qualified settlement fund, and the results of a separate independent actuarial consulting firm report conducted in the fourth quarter to assist the Company in obtaining insurance to fully fund all estimable asbestos-related claims (excluding Yarway claims) incurred through 2056.

[0000833444-15-000013:notes:49]
The independent actuarial service firm calculated a total estimated liability for asbestos-related claims of the Company, which reflects the Company’s best estimate of its ultimate risk of loss to resolve all pending and future claims (excluding Yarway claims) through 2056, which is the Company’s reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates.

[0000833444-15-000013:notes:50]
In conjunction with determining the total estimated liability, the Company retained an independent third party to assist it in valuing its insurance assets responsive to asbestos-related claims, excluding Yarway claims. These insurance assets represent amounts due to the Company for previously settled claims and the probable reimbursements relating to its total liability for pending and unasserted potential future asbestos claims and defense costs. In calculating this amount, the Company used the estimated asbestos liability for pending and projected future claims and defense costs described above, and it also considered the amount of insurance available, the solvency risk with respect to the Company's insurance carriers, resolution of insurance coverage issues, gaps in coverage, allocation methodologies, and the terms of existing settlement agreements with insurance carriers.

[0000833444-15-000013:notes:51]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-15-000013:notes:52]
In connection with the foregoing, during the third quarter of fiscal 2014, the Company resolved disputes with certain of its historical insurers and agreed that certain insurance proceeds would be used to establish and fund a qualified settlement fund (“QSF”), within the meaning of the Internal Revenue Code, which would be used for the resolution primarily of Grinnell asbestos liabilities of the Company. It is intended that the QSF will receive future insurance payments and proceeds from third party insurers and, in addition, will fund and manage liabilities for certain historical operations  of the Company. On January 9, 2015, the Company completed a series of restructuring transactions related to the establishment and funding of a dedicated structure pursuant to which the Company acquired the assets of Grinnell and transferred cash and other assets totaling approximately $278 million (not including $22 million received by the QSF from historic third-party insurers in settlement of coverage disputes) to the structure. As part of the restructuring, subsidiaries in the structure assumed certain liabilities related to historic Grinnell, Scott and Figgie operations, including all historical Grinnell asbestos liabilities, and such subsidiaries purchased additional insurance by, through or from a wholly-owned subsidiary in the structure in order to supplement and enhance existing insurance assets. The structure and the QSF fully fund all historic Grinnell asbestos liabilities and provide for the efficient and streamlined management of claims related thereto.

[0000833444-15-000013:notes:53]
Tax Matters

[0000833444-15-000013:notes:54]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation. The issues and proposed adjustments related to such years are generally subject to the sharing provisions of a tax sharing agreement entered in 2007 with Covidien and TE Connectivity (the "2007 Tax Sharing Agreement") under which Tyco, Covidien and TE Connectivity share 27%, 42% and 31%, respectively, of shared income tax liabilities that arise from adjustments made by tax authorities to Tyco's, Covidien's and TE Connectivity's U.S. and certain non-U.S. income tax returns. The costs and expenses associated with the management of these shared tax liabilities are generally shared equally among the parties. Tyco has previously disclosed that in connection with U.S. federal tax audits, the IRS has raised a number of issues and proposed tax adjustments for periods beginning with the 1997 tax year. Although Tyco has been able to resolve substantially all of the issues and adjustments proposed by the IRS for tax years through 2007, it has not been able to resolve matters related to the treatment of certain intercompany debt transactions during the period. As a result, on June 20, 2013, Tyco received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owe additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million is expected to be asserted. These amounts exclude interest and do not reflect the impact on subsequent periods if the IRS position described below is ultimately proved correct.

[0000833444-15-000013:notes:55]
The IRS asserted in the Notices of Deficiency that substantially all of Tyco's intercompany debt originated during the 1997 - 2000 period should not be treated as debt for U.S. federal income tax purposes, and has disallowed interest and related deductions recognized on U.S. income tax returns totaling approximately $2.9 billion. Tyco strongly disagrees with the IRS position and has filed petitions with the U.S. Tax Court contesting the IRS proposed adjustments. A trial date has been set for February 2016. Tyco believes that it has meritorious defenses for its tax filings, that the IRS positions with regard to these matters are inconsistent with the applicable tax laws and existing Treasury regulations, and that the previously reported taxes for the years in question are appropriate.

[0000833444-15-000013:notes:56]
No payments with respect to these matters would be required until the dispute is definitively resolved, which, based on the experience of other companies, could take several years. Tyco believes that its income tax reserves and the liabilities recorded in the Consolidated Balance Sheet for the tax sharing agreements continue to be appropriate. However, the ultimate resolution of these matters, and the impact of that resolution, are uncertain and could have a material impact on Tyco's financial condition, results of operations and cash flows. In particular, if the IRS is successful in asserting its claim, it would have an adverse impact on interest deductions related to the same intercompany debt in subsequent time periods, totaling approximately $6.6 billion, which is expected to be disallowed by the IRS.

[0000833444-15-000013:notes:57]
See Note 6 for additional information related to income tax matters.

[0000833444-15-000013:notes:58]
Other Matters

[0000833444-15-000013:notes:59]
During the first quarter of fiscal 2014, Tyco settled a tax dispute with its former subsidiary, CIT Group, Inc. ("CIT").  Under the terms of the settlement agreement, Tyco received $60 million during the first quarter of 2014, which was subject to the sharing provisions of the 2007 Tax Sharing Agreement. As a result, the Company recorded a $16 million gain in Selling, general and administrative expenses in the Consolidated Statement of Operations and established payables of $25 million and $19 million due to Covidien and TE Connectivity, respectively, as of December 27, 2013. The Company paid these amounts to Covidien and TE Connectivity during the second fiscal quarter of 2014.

[0000833444-15-000013:notes:60]
SimplexGrinnell LP (“SG”), a subsidiary of the Company in the North America Installation & Services segment, has been named as a defendant in several lawsuits seeking damages for SG’s alleged failure to pay prevailing wages in connection with work performed on state and local municipal projects.  In New York, the U.S. District Court had granted SG’s motion for summary judgment dismissing plaintiffs’ claims for prevailing wages on testing and inspection work, which was based primarily on a 2009 opinion of the New York Department of Labor (“DOL”) that testing and inspection work would be considered covered by the prevailing wage law only on a prospective basis.  Plaintiffs appealed this decision to the U.S. Court of Appeals for the Second Circuit, which in turn asked the NY Court of Appeals whether the lower court should have given deference to the DOL’s prospective-only application of law.  In October 2014, the NY Court of Appeals ruled that the lower court did not have to give deference to the DOL based on an amicus brief submitted by the DOL in which it stated the Court need not have given it deference.  As a result, the Company recorded a $10 million charge in Cost of services in the Consolidated Statement of Operations during the fourth quarter of fiscal 2014.  During the quarter ended December 26, 2014, the Company recorded an additional charge in Cost of services within the Consolidated Statement of Operations based on a refinement of the underlying data used by the plaintiffs’ experts.  Such amount, which reflects the Company’s best estimate of its probable loss related to this matter, is not material to the financial statements.  SG also is a defendant in two other lawsuits related to prevailing wages in New Jersey and California. SG has agreed in principle to settle the California lawsuit for approximately $5 million subject to Court approval, which the Company had previously reserved.

[0000833444-15-000013:notes:61]
During the first quarter of fiscal 2015, the Company received and responded to inquiries from the U.S. Department of the Navy regarding the formulation of certain aqueous film forming foam ("AFFF") concentrates. The Company investigated such matters and ceased selling certain AFFF and other foam products pending the outcome of its investigation.  During the course of the investigation, three AFFF products were removed from the Navy’s Qualified Products List ("QPL"); one AFFF product remains on the QPL. The Company has shared the results of its investigation with appropriate governmental authorities and is also communicating with the government regarding the re-qualification of these products.  The government has confirmed that it considers the Company to be “presently responsible,” and that no suspension or debarment is warranted.  At this time, we cannot predict the outcome of these inquiries and whether this will result in further action by the Navy or other governmental authorities, but it is possible that the Company could be required to pay material fines, consent to injunctions on future conduct, or suffer other criminal or civil penalties or adverse impacts, including being subject to lawsuits brought by private litigants, each of which may have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-15-000013:notes:62]
In addition to the foregoing, the Company is subject to claims and suits, including from time to time, contractual disputes and product and general liability claims, incidental to present and former operations, acquisitions and dispositions. With respect to many of these claims, the Company either self-insures or maintains insurance through third-parties, with varying deductibles. While the ultimate outcome of these matters cannot be predicted with certainty, the Company believes that the resolution of any such proceedings, whether the underlying claims are covered by insurance or not, will not have a material adverse effect on the Company's financial condition, results of operations or cash flows beyond amounts recorded for such matters.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-15-000013:notes:63]
TIFSA, a 100% owned subsidiary of the Company, has public debt securities outstanding which are fully and unconditionally guaranteed by Tyco and by Tyco Fire & Security Finance SCA, a wholly owned subsidiary of Tyco and parent company of TIFSA.  The following tables present condensed consolidating financial information for Tyco, TIFSA and all other subsidiaries. Condensed financial information for Tyco and TIFSA on a stand-alone basis is presented using the equity method of accounting for subsidiaries.

[0000833444-15-000013:notes:64]
[same as prior period, unchanged from 0000833444-14-000099:notes:37]

[0000833444-15-000013:notes:65]
For the Quarter Ended December 26, 2014

[0000833444-15-000013:notes:66]
[same as prior period, unchanged from 0000833444-14-000099:notes:39]

[0000833444-15-000013:notes:67]
|  | TycoInternationalPublic Limited Company |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,479 |  |  | $ | — |  |  | $ | 2,479 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 1,022 |  |  | — |  |  | 1,022 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 548 |  |  | — |  |  | 548 |  |
| Selling, general and administrative expenses | 3 |  |  | — |  |  | 1 |  |  | 649 |  |  | — |  |  | 653 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 58 |  |  | — |  |  | 58 |  |
| Operating (loss) income | (3 | ) |  | — |  |  | (1 | ) |  | 202 |  |  | — |  |  | 198 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Interest expense | — |  |  | — |  |  | (24 | ) |  | — |  |  | — |  |  | (24 | ) |
| Other income, net | — |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Equity in net income of subsidiaries | 143 |  |  | 133 |  |  | 127 |  |  | — |  |  | (403 | ) |  | — |  |
| Intercompany interest and fees | 22 |  |  | — |  |  | 27 |  |  | (49 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 162 |  |  | 133 |  |  | 133 |  |  | 156 |  |  | (403 | ) |  | 181 |  |
| Income tax expense | — |  |  | — |  |  | — |  |  | (19 | ) |  | — |  |  | (19 | ) |
| Income from continuing operations | 162 |  |  | 133 |  |  | 133 |  |  | 137 |  |  | (403 | ) |  | 162 |  |
| Loss from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net income | 162 |  |  | 133 |  |  | 133 |  |  | 136 |  |  | (403 | ) |  | 161 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 162 |  |  | $ | 133 |  |  | $ | 133 |  |  | $ | 137 |  |  | $ | (403 | ) |  | $ | 162 |  |

[0000833444-15-000013:notes:68]
[same as prior period, unchanged from 0000833444-14-000099:notes:41]

[0000833444-15-000013:notes:69]
|  | TycoInternationalPublic Limited Company |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 162 |  |  | $ | 133 |  |  | $ | 133 |  |  | $ | 136 |  |  | $ | (403 | ) |  | $ | 161 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (198 | ) |  | — |  |  | (1 | ) |  | (197 | ) |  | 198 |  |  | (198 | ) |
| Defined benefit and post retirement plans | 5 |  |  | — |  |  | — |  |  | 5 |  |  | (5 | ) |  | 5 |  |
| Total other comprehensive loss, net of tax | (193 | ) |  | — |  |  | (1 | ) |  | (192 | ) |  | 193 |  |  | (193 | ) |
| Comprehensive (loss) income | (31 | ) |  | 133 |  |  | 132 |  |  | (56 | ) |  | (210 | ) |  | (32 | ) |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Comprehensive (loss) income attributable to Tyco ordinary shareholders | $ | (31 | ) |  | $ | 133 |  |  | $ | 132 |  |  | $ | (55 | ) |  | $ | (210 | ) |  | $ | (31 | ) |

[0000833444-15-000013:notes:70]
For the Quarter Ended December 27, 2013

[0000833444-15-000013:notes:71]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | 2,493 |  |  | $ | — |  |  | $ | 2,493 |  |
| Cost of product sales | — |  |  | — |  |  | 999 |  |  | — |  |  | 999 |  |
| Cost of services | — |  |  | — |  |  | 576 |  |  | — |  |  | 576 |  |
| Selling, general and administrative expenses | (13 | ) |  | 1 |  |  | 583 |  |  | — |  |  | 571 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Operating income (loss) | 13 |  |  | (1 | ) |  | 332 |  |  | — |  |  | 344 |  |
| Interest income | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Interest expense | — |  |  | (24 | ) |  | — |  |  | — |  |  | (24 | ) |
| Other expense, net | (1 | ) |  | — |  |  | — |  |  | — |  |  | (1 | ) |
| Equity in net income of subsidiaries | 268 |  |  | 284 |  |  | — |  |  | (552 | ) |  | — |  |
| Intercompany interest and fees | (10 | ) |  | 9 |  |  | 1 |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 270 |  |  | 268 |  |  | 336 |  |  | (552 | ) |  | 322 |  |
| Income tax expense | — |  |  | — |  |  | (70 | ) |  | — |  |  | (70 | ) |
| Equity loss in earnings of unconsolidated subsidiaries | — |  |  | — |  |  | (4 | ) |  | — |  |  | (4 | ) |
| Income from continuing operations | 270 |  |  | 268 |  |  | 262 |  |  | (552 | ) |  | 248 |  |
| Income from discontinued operations, net of income taxes | — |  |  | — |  |  | 24 |  |  | — |  |  | 24 |  |
| Net income | 270 |  |  | 268 |  |  | 286 |  |  | (552 | ) |  | 272 |  |
| Less: noncontrolling interest in subsidiaries net income | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Net income attributable to Tyco ordinary shareholders | $ | 270 |  |  | $ | 268 |  |  | $ | 284 |  |  | $ | (552 | ) |  | $ | 270 |  |

[0000833444-15-000013:notes:72]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 270 |  |  | $ | 268 |  |  | $ | 286 |  |  | $ | (552 | ) |  | $ | 272 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (37 | ) |  | — |  |  | (37 | ) |  | 37 |  |  | (37 | ) |
| Defined benefit and post retirement plans | 3 |  |  | — |  |  | 3 |  |  | (3 | ) |  | 3 |  |
| Total other comprehensive loss, net of tax | (34 | ) |  | — |  |  | (34 | ) |  | 34 |  |  | (34 | ) |
| Comprehensive income | 236 |  |  | 268 |  |  | 252 |  |  | (518 | ) |  | 238 |  |
| Less: comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 236 |  |  | $ | 268 |  |  | $ | 250 |  |  | $ | (518 | ) |  | $ | 236 |  |

[0000833444-15-000013:notes:73]
[same as prior period, unchanged from 0000833444-14-000099:notes:52]

[0000833444-15-000013:notes:74]
As of December 26, 2014

[0000833444-15-000013:notes:75]
|  | TycoInternationalPublic Limited Company |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 473 |  |  | $ | — |  |  | $ | 473 |  |
| Accounts receivable, net | — |  |  | — |  |  | — |  |  | 1,718 |  |  | — |  |  | 1,718 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 658 |  |  | — |  |  | 658 |  |
| Intercompany receivables | 66 |  |  | — |  |  | 275 |  |  | 8,145 |  |  | (8,486 | ) |  | — |  |
| Prepaid expenses and other current assets | 1 |  |  | — |  |  | 72 |  |  | 817 |  |  | — |  |  | 890 |  |
| Deferred income taxes | — |  |  | — |  |  | — |  |  | 307 |  |  | — |  |  | 307 |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 20 |  |  | — |  |  | 20 |  |
| Total current assets | 67 |  |  | — |  |  | 347 |  |  | 12,138 |  |  | (8,486 | ) |  | 4,066 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | — |  |  | 1,242 |  |  | — |  |  | 1,242 |  |
| Goodwill | — |  |  | — |  |  | — |  |  | 4,148 |  |  | — |  |  | 4,148 |  |
| Intangible assets, net | — |  |  | — |  |  | — |  |  | 796 |  |  | — |  |  | 796 |  |
| Investment in subsidiaries | 10,851 |  |  | 11,040 |  |  | 16,041 |  |  | — |  |  | (37,932 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | — |  |  | 2,964 |  |  | 5,037 |  |  | (8,001 | ) |  | — |  |
| Other assets | 1 |  |  | — |  |  | 29 |  |  | 916 |  |  | — |  |  | 946 |  |
| Total Assets | $ | 10,919 |  |  | $ | 11,040 |  |  | $ | 19,381 |  |  | $ | 24,277 |  |  | $ | (54,419 | ) |  | $ | 11,198 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 258 |  |  | $ | 20 |  |  | $ | — |  |  | $ | 278 |  |
| Accounts payable | 1 |  |  | — |  |  | — |  |  | 824 |  |  | — |  |  | 825 |  |
| Accrued and other current liabilities | 79 |  |  | — |  |  | 70 |  |  | 1,844 |  |  | — |  |  | 1,993 |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 365 |  |  | — |  |  | 365 |  |
| Intercompany payables | 3,463 |  |  | — |  |  | 4,684 |  |  | 339 |  |  | (8,486 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Total current liabilities | 3,543 |  |  | — |  |  | 5,012 |  |  | 3,406 |  |  | (8,486 | ) |  | 3,475 |  |
| Long-term debt | — |  |  | — |  |  | 1,183 |  |  | 1 |  |  | — |  |  | 1,184 |  |
| Intercompany loans payable | 3,142 |  |  | — |  |  | 1,895 |  |  | 2,964 |  |  | (8,001 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 324 |  |  | — |  |  | 324 |  |
| Other liabilities | — |  |  | — |  |  | 252 |  |  | 1,666 |  |  | — |  |  | 1,918 |  |
| Total Liabilities | 6,685 |  |  | — |  |  | 8,342 |  |  | 8,361 |  |  | (16,487 | ) |  | 6,901 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |  |  |
| Ordinary shares | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |
| Other shareholders' equity | 4,230 |  |  | 11,040 |  |  | 11,039 |  |  | 15,853 |  |  | (37,932 | ) |  | 4,230 |  |
| Total Tyco Shareholders' Equity | 4,234 |  |  | 11,040 |  |  | 11,039 |  |  | 15,853 |  |  | (37,932 | ) |  | 4,234 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 50 |  |  | — |  |  | 50 |  |
| Total Equity | 4,234 |  |  | 11,040 |  |  | 11,039 |  |  | 15,903 |  |  | (37,932 | ) |  | 4,284 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity | $ | 10,919 |  |  | $ | 11,040 |  |  | $ | 19,381 |  |  | $ | 24,277 |  |  | $ | (54,419 | ) |  | $ | 11,198 |  |

[0000833444-15-000013:notes:76]
As of September 26, 2014

[0000833444-15-000013:notes:77]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | 892 |  |  | $ | — |  |  | $ | 892 |  |
| Accounts receivable, net | — |  |  | — |  |  | 1,750 |  |  | — |  |  | 1,750 |  |
| Inventories | — |  |  | — |  |  | 628 |  |  | — |  |  | 628 |  |
| Intercompany receivables | 18 |  |  | 245 |  |  | 8,102 |  |  | (8,365 | ) |  | — |  |
| Prepaid expenses and other current assets | 7 |  |  | 62 |  |  | 1,084 |  |  | — |  |  | 1,153 |  |
| Deferred income taxes | — |  |  | — |  |  | 307 |  |  | — |  |  | 307 |  |
| Assets held for sale | — |  |  | — |  |  | 21 |  |  | — |  |  | 21 |  |
| Total current assets | 25 |  |  | 307 |  |  | 12,784 |  |  | (8,365 | ) |  | 4,751 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | 1,269 |  |  | — |  |  | 1,269 |  |
| Goodwill | — |  |  | — |  |  | 4,126 |  |  | — |  |  | 4,126 |  |
| Intangible assets, net | — |  |  | — |  |  | 737 |  |  | — |  |  | 737 |  |
| Investment in subsidiaries | 12,738 |  |  | 16,209 |  |  | — |  |  | (28,947 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | 3,693 |  |  | 5,346 |  |  | (9,039 | ) |  | — |  |
| Other assets | 26 |  |  | 4 |  |  | 896 |  |  | — |  |  | 926 |  |
| Total Assets | $ | 12,789 |  |  | $ | 20,213 |  |  | $ | 25,158 |  |  | $ | (46,351 | ) |  | $ | 11,809 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |
| Accounts payable | 1 |  |  | — |  |  | 870 |  |  | — |  |  | 871 |  |
| Accrued and other current liabilities | 191 |  |  | 23 |  |  | 1,953 |  |  | — |  |  | 2,167 |  |
| Deferred revenue | — |  |  | — |  |  | 400 |  |  | — |  |  | 400 |  |
| Intercompany payables | 3,517 |  |  | 4,593 |  |  | 255 |  |  | (8,365 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Total current liabilities | 3,709 |  |  | 4,616 |  |  | 3,511 |  |  | (8,365 | ) |  | 3,471 |  |
| Long-term debt | — |  |  | 1,441 |  |  | 2 |  |  | — |  |  | 1,443 |  |
| Intercompany loans payable | 4,180 |  |  | 1,888 |  |  | 2,971 |  |  | (9,039 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | 335 |  |  | — |  |  | 335 |  |
| Other liabilities | 253 |  |  | — |  |  | 1,624 |  |  | — |  |  | 1,877 |  |
| Total Liabilities | 8,142 |  |  | 7,945 |  |  | 8,443 |  |  | (17,404 | ) |  | 7,126 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |
| Ordinary shares | 208 |  |  | — |  |  | — |  |  | — |  |  | 208 |  |
| Ordinary shares held in treasury | — |  |  | — |  |  | (2,515 | ) |  | — |  |  | (2,515 | ) |
| Other shareholders' equity | 4,439 |  |  | 12,268 |  |  | 19,194 |  |  | (28,947 | ) |  | 6,954 |  |
| Total Tyco Shareholders' Equity | 4,647 |  |  | 12,268 |  |  | 16,679 |  |  | (28,947 | ) |  | 4,647 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Total Equity | 4,647 |  |  | 12,268 |  |  | 16,702 |  |  | (28,947 | ) |  | 4,670 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity | $ | 12,789 |  |  | $ | 20,213 |  |  | $ | 25,158 |  |  | $ | (46,351 | ) |  | $ | 11,809 |  |

[0000833444-15-000013:notes:78]
[same as prior period, unchanged from 0000833444-14-000099:notes:57]

[0000833444-15-000013:notes:79]
|  | TycoInternationalPublic Limited Company |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (34 | ) |  | $ | 72 |  |  | $ | 58 |  |  | $ | — |  |  | $ | 96 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | (66 | ) |  | — |  |  | (66 | ) |
| Proceeds from disposal of assets | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (152 | ) |  | — |  |  | (152 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | (4 | ) |  | — |  |  | (4 | ) |
| Net increase in intercompany loans | — |  |  | (72 | ) |  | — |  |  | 72 |  |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | 275 |  |  | — |  |  | 275 |  |
| Purchases of investments | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Increase in restricted cash | — |  |  | — |  |  | (45 | ) |  | — |  |  | (45 | ) |
| Other | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net cash used in (provided by) investing activities | — |  |  | (72 | ) |  | 7 |  |  | 72 |  |  | 7 |  |
| Net cash used in discontinued investing activities | — |  |  | — |  |  | (15 | ) |  | — |  |  | (15 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from exercise of share options | 27 |  |  | — |  |  | 6 |  |  | — |  |  | 33 |  |
| Dividends paid | (75 | ) |  | — |  |  | — |  |  | — |  |  | (75 | ) |
| Repurchase of ordinary shares by treasury | — |  |  | — |  |  | (417 | ) |  | — |  |  | (417 | ) |
| Net intercompany loan borrowings | 84 |  |  | — |  |  | (12 | ) |  | (72 | ) |  | — |  |
| Transfer from discontinued operations | — |  |  | — |  |  | (15 | ) |  | — |  |  | (15 | ) |
| Payment of contingent consideration | — |  |  | — |  |  | (23 | ) |  | — |  |  | (23 | ) |
| Other | (2 | ) |  | — |  |  | (13 | ) |  | — |  |  | (15 | ) |
| Net cash provided by (used in) financing activities | 34 |  |  | — |  |  | (474 | ) |  | (72 | ) |  | (512 | ) |
| Net cash provided by discontinued financing activities | — |  |  | — |  |  | 15 |  |  | — |  |  | 15 |  |
| Effect of currency translation on cash | — |  |  | — |  |  | (10 | ) |  | — |  |  | (10 | ) |
| Net decrease in cash and cash equivalents | — |  |  | — |  |  | (419 | ) |  | — |  |  | (419 | ) |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | 892 |  |  | — |  |  | 892 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | 473 |  |  | $ | — |  |  | $ | 473 |  |

[0000833444-15-000013:notes:80]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 46 |  |  | $ | (136 | ) |  | $ | 190 |  |  | $ | — |  |  | $ | 100 |  |
| Net cash provided by discontinued operating activities | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | (63 | ) |  | — |  |  | (63 | ) |
| Proceeds from disposal of assets | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (54 | ) |  | — |  |  | (54 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | (11 | ) |  | — |  |  | (11 | ) |
| Net increase in intercompany loans | — |  |  | (15 | ) |  | — |  |  | 15 |  |  | — |  |
| Increase in investment in subsidiaries | — |  |  | (9 | ) |  | — |  |  | 9 |  |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | 112 |  |  | — |  |  | 112 |  |
| Purchases of investments | — |  |  | — |  |  | (32 | ) |  | — |  |  | (32 | ) |
| Decrease in restricted cash | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Other | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Net cash used in investing activities | — |  |  | (24 | ) |  | (38 | ) |  | 24 |  |  | (38 | ) |
| Net cash used in discontinued investing activities | — |  |  | — |  |  | (29 | ) |  | — |  |  | (29 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt | — |  |  | 310 |  |  | — |  |  | — |  |  | 310 |  |
| Repayment of short-term debt | — |  |  | (150 | ) |  | — |  |  | — |  |  | (150 | ) |
| Proceeds from exercise of share options | — |  |  | — |  |  | 40 |  |  | — |  |  | 40 |  |
| Dividends paid | (74 | ) |  | — |  |  | — |  |  | — |  |  | (74 | ) |
| Repurchase of ordinary shares by treasury | — |  |  | — |  |  | (250 | ) |  | — |  |  | (250 | ) |
| Net intercompany loan borrowings | 28 |  |  | — |  |  | (13 | ) |  | (15 | ) |  | — |  |
| Increase in equity from parent | — |  |  | — |  |  | 9 |  |  | (9 | ) |  | — |  |
| Transfer to discontinued operations | — |  |  | — |  |  | (6 | ) |  | — |  |  | (6 | ) |
| Other | — |  |  | — |  |  | (9 | ) |  | — |  |  | (9 | ) |
| Net cash (used in) provided by financing activities | (46 | ) |  | 160 |  |  | (229 | ) |  | (24 | ) |  | (139 | ) |
| Net cash provided by discontinued financing activities | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Effect of currency translation on cash | — |  |  | — |  |  | (7 | ) |  | — |  |  | (7 | ) |
| Net decrease in cash and cash equivalents | — |  |  | — |  |  | (84 | ) |  | — |  |  | (84 | ) |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | 563 |  |  | — |  |  | 563 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | 479 |  |  | $ | — |  |  | $ | 479 |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-15-000013:notes:81]
Debt

[0000833444-15-000013:notes:82]
Debt as of December 26, 2014 and September 26, 2014 is as follows ($ in millions):

[0000833444-15-000013:notes:83]
|  | As of |
|  | December 26, 2014 |  | September 26, 2014 |
| 3.375% public notes due 2015 (1) | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | 364 |  |  | 364 |  |
| 7.0% public notes due 2019 | 245 |  |  | 245 |  |
| 6.875% public notes due 2021 | 465 |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| Other (2) | 21 |  |  | 22 |  |
| Total debt | 1,462 |  |  | 1,463 |  |
| Less current portion | 278 |  |  | 20 |  |
| Long-term debt | $ | 1,184 |  |  | $ | 1,443 |  |

[0000833444-15-000013:notes:84]
(1)  $258 million of 3.375% public notes due October 2015 is included in the current portion of debt as of December 26, 2014.

[0000833444-15-000013:notes:85]
(2) $20 million of the amount shown as other is included in the current portion of the Company's total debt as of both December 26, 2014 and September 26, 2014.

[0000833444-15-000013:notes:86]
Fair Value

[0000833444-15-000013:notes:87]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of both December 26, 2014 and September 26, 2014 was $1,441 million.  The Company has determined the fair value of such debt to be $1,659 million and $1,670 million as of December 26, 2014 and September 26, 2014, respectively.  The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets.  As of December 26, 2014 and September 26, 2014, $1,441 million of the Company's debt, which is actively traded and subject to the fair value disclosure requirements, is classified as Level 1 in the fair value hierarchy.

[0000833444-15-000013:notes:88]
Commercial Paper

[0000833444-15-000013:notes:89]
From time to time Tyco International Finance S.A. ("TIFSA") may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued on a private placement basis under the commercial paper program is $1 billion as of December 26, 2014.  As of December 26, 2014 and September 26, 2014, TIFSA had no commercial paper outstanding.

[0000833444-15-000013:notes:90]
Credit Facilities

[0000833444-15-000013:notes:91]
The Company's committed revolving credit facility totaled $1 billion as of December 26, 2014. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of December 26, 2014 and September 26, 2014, there were no amounts drawn under the Company's revolving credit facility. Interest under the revolving credit facility is variable and is calculated by reference to LIBOR or an alternate base rate.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-15-000013:notes:92]
[same as prior period, unchanged from 0000833444-14-000099:notes:71]

[0000833444-15-000013:notes:93]
During the quarter ended December 26, 2014, the Company issued its annual share-based compensation grants. The total number of awards issued was approximately 2.4 million, of which 1.5 million were stock options, 0.4 million were restricted unit awards and 0.5 million were performance share unit awards. The options and restricted stock units vest in equal annual installments over a period of 4 years, and the performance share unit awards vest after a period of 3 years based on the level of attainment of the applicable performance metrics, which are determined by the Compensation and Human Resources Committee of the Board. The weighted-average grant-date fair value of the stock options, restricted unit awards and performance share unit awards was $11.77, $43.38 and $42.95, respectively. The weighted-average assumptions used in the Black-Scholes option pricing model included an expected stock price volatility of 32%, a risk free interest rate of 1.83%, an expected annual dividend per share of $0.72 and an expected option life of 5.57 years.

[0000833444-15-000013:notes:94]
[same as prior period, unchanged from 0000833444-14-000099:notes:72]

[0000833444-15-000013:notes:95]
[same as prior period, unchanged from 0000833444-14-000099:notes:73]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-15-000013:notes:96]
[same as prior period, unchanged from 0000833444-14-000099:notes:74]

[0000833444-15-000013:notes:97]
[same as prior period, unchanged from 0000833444-14-000099:notes:75]

[0000833444-15-000013:notes:98]
During fiscal 2014, the Company concluded that several businesses in the ROW Installation & Services segment it intends to sell met the criteria to be classified as held for sale.  The businesses are accounted for as held for sale on the Consolidated Balance Sheets as of December 26, 2014 and September 26, 2014, and their results of operations have been presented as discontinued operations on the Consolidated Statements of Operations during the quarters ended December 26, 2014 and December 27, 2013.  The Company expects to complete the sale of these businesses by the end of the third quarter of fiscal 2015.

[0000833444-15-000013:notes:99]
On May 22, 2014, the Company, together with its wholly-owned subsidiary Tyco Far East Holdings Ltd. completed the sale of Tyco Fire & Security Services Korea Co. Ltd. and its subsidiaries that form and operate the Company’s ADT Korea business to an affiliate of The Carlyle Group pursuant to a stock purchase agreement for an aggregate purchase price of $1.93 billion.  The Company recognized a gain of $1.0 billion, net of a $212 million charge related to the indemnification at fair value for certain tax related matters borne by the buyer that are probable of being paid, which was recorded in Income from discontinued operations, net of income taxes, on the Consolidated Statements of Operations during fiscal 2014.  Its results of operations have been presented within discontinued operations on the Consolidated Statements of Operations during the quarter ended December 27, 2013.

[0000833444-15-000013:notes:100]
During the quarter ended December 27, 2013, the Company completed the sale of its Armourguard business in New Zealand and its fire and security business in Fiji, both of which were in its ROW Installation & Services segment, for an immaterial amount.  The assets and liabilities have not been presented separately as held-for-sale in the Consolidated Balance Sheets as the amounts were not material to the presentation of all periods. This business has not been presented in discontinued operations as the amounts were not material to the Consolidated Financial Statements.

[0000833444-15-000013:notes:101]
Discontinued Operations

[0000833444-15-000013:notes:102]
[same as prior period, unchanged from 0000833444-14-000099:notes:83]

[0000833444-15-000013:notes:103]
|  | For the Quarters Ended |
|  | December 26, 2014 |  | December 27, 2013 |
| Net revenue | $ | 4 |  |  | $ | 154 |  |
| Pre-tax (loss) income from discontinued operations | (2 | ) |  | 30 |  |
| Pre-tax gain on sale of discontinued operations | 1 |  |  | — |  |
| Income tax expense | — |  |  | (6 | ) |
| (Loss) income from discontinued operations, net of income taxes | $ | (1 | ) |  | $ | 24 |  |

[0000833444-15-000013:notes:104]
Balance sheet information for the discontinued operations as of December 26, 2014 and September 26, 2014 was as follows ($ in millions):

[0000833444-15-000013:notes:105]
|  | As of |
|  | December 26, 2014 |  | September 26, 2014 |
| Accounts receivable, net | $ | 11 |  |  | $ | 11 |  |
| Inventories | 2 |  |  | 3 |  |
| Prepaid expenses and other current assets | 5 |  |  | 5 |  |
| Other assets | 2 |  |  | 2 |  |
| Total assets | $ | 20 |  |  | $ | 21 |  |
| Accounts payable | 2 |  |  | 2 |  |
| Accrued and other current liabilities | 11 |  |  | 9 |  |
| Other liabilities | 1 |  |  | 2 |  |
| Total liabilities | $ | 14 |  |  | $ | 13 |  |


## us-gaap:EarningsPerShareTextBlock

[0000833444-15-000013:notes:106]
[same as prior period, unchanged from 0000833444-14-000099:notes:90]

[0000833444-15-000013:notes:107]
The reconciliations between basic and diluted earnings per share attributable to Tyco ordinary shareholders are as follows (in millions, except per share data):

[0000833444-15-000013:notes:108]
|  | For the Quarter Ended December 26, 2014 |  | For the Quarter Ended December 27, 2013 |
|  | Income |  | Shares |  | Per ShareAmount |  | Income |  | Shares |  | Per ShareAmount |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 163 |  |  | 420 |  |  | $ | 0.39 |  |  | $ | 246 |  |  | 464 |  |  | $ | 0.53 |  |
| Share options and restricted share awards | — |  |  | 7 |  |  |  |  | — |  |  | 7 |  |  |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations attributable to Tyco ordinary shareholders, giving effect to dilutive adjustments | $ | 163 |  |  | 427 |  |  | $ | 0.38 |  |  | $ | 246 |  |  | 471 |  |  | $ | 0.52 |  |

[0000833444-15-000013:notes:109]
The computation of diluted earnings per share for the quarter ended December 26, 2014 excludes the effect of the potential exercise of share options to purchase approximately 3 million shares and excludes restricted stock units of approximately 2 million shares because the effect would be anti-dilutive.

[0000833444-15-000013:notes:110]
The computation of diluted earnings per share for the quarter ended December 27, 2013 excludes the effect of the potential exercise of share options to purchase approximately 2 million shares and excludes restricted stock units of approximately 1 million shares because the effect would be anti-dilutive.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000833444-15-000013:notes:111]
The following table presents the Company's hierarchy for its assets measured at fair value on a recurring basis as of December 26, 2014 and September 26, 2014 ($ in millions):

[0000833444-15-000013:notes:112]
|  |  |  |  |  |  |  | Consolidated Balance SheetClassification |
|  | As of December 26, 2014 |  | Prepaids andOther CurrentAssets |
| Investment Assets: | Level 1 |  | Level 2 |  | Total |  |  |
| Exchange traded equity funds | $ | 65 |  |  | $ | — |  |  | $ | 65 |  |  | $ | 65 |  |
|  | $ | 65 |  |  | $ | — |  |  | $ | 65 |  |  | $ | 65 |  |

[0000833444-15-000013:notes:113]
|  |  |  |  |  |  |  | Consolidated Balance SheetClassification |
|  | As of September 26, 2014 |  | Prepaids andOther CurrentAssets |
| Investment Assets: | Level 1 |  | Level 2 |  | Total |  |
| Time deposits | $ | 275 |  |  | $ | — |  |  | $ | 275 |  |  | $ | 275 |  |
| Exchange traded equity funds | 62 |  |  | — |  |  | 62 |  |  | 62 |  |
|  | $ | 337 |  |  | $ | — |  |  | $ | 337 |  |  | $ | 337 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000833444-15-000013:notes:114]
[same as prior period, unchanged from 0000833444-14-000099:notes:99]

[0000833444-15-000013:notes:115]
The Company's financial instruments consist primarily of cash and cash equivalents, time deposits, accounts receivable, investments, accounts payable, and debt and derivative financial instruments. The fair value of cash and cash equivalents, time deposits, accounts receivable, and accounts payable approximated book value as of December 26, 2014 and September 26, 2014. The fair value of derivative financial instruments was not material to any of the periods presented. See below for the fair value of investments and Note 9 for the fair value of debt.

[0000833444-15-000013:notes:116]
[same as prior period, unchanged from 0000833444-14-000099:notes:101]

[0000833444-15-000013:notes:117]
In the normal course of business, Tyco is exposed to market risk arising from changes in currency exchange rates, interest rates and commodity prices. The Company may use derivative financial instruments to manage exposures to foreign currency, interest rate and commodity risks. The Company's objective for utilizing derivative financial instruments is to manage these risks using the most effective methods to eliminate or reduce the impacts of these exposures. The Company does not use derivative financial instruments for trading or speculative purposes. As of and during the three months ended December 26, 2014, the Company did not hold or enter into any commodity derivative instruments or interest rate swaps.

[0000833444-15-000013:notes:118]
As of December 26, 2014 and September 26, 2014, the total gross notional amount of the Company's foreign exchange contracts was $282 million and $258 million, respectively. The fair value of these derivative financial instruments and impact of such changes in the fair value was not material to the Consolidated Balance Sheets as of December 26, 2014 and September 26, 2014 or Consolidated Statements of Operations and Consolidated Statements of Cash Flows for the quarters ended December 26, 2014 and December 27, 2013.

[0000833444-15-000013:notes:119]
[same as prior period, unchanged from 0000833444-14-000099:notes:106]

[0000833444-15-000013:notes:120]
[same as prior period, unchanged from 0000833444-14-000099:notes:107]

[0000833444-15-000013:notes:121]
[same as prior period, unchanged from 0000833444-14-000099:notes:108]

[0000833444-15-000013:notes:122]
Investments may primarily include marketable securities such as U.S. government obligations, U.S. government agency and corporate debt securities, equity securities, or time deposits with banks.

[0000833444-15-000013:notes:123]
[same as prior period, unchanged from 0000833444-14-000099:notes:110]

[0000833444-15-000013:notes:124]
[same as prior period, unchanged from 0000833444-14-000099:notes:112]

[0000833444-15-000013:notes:125]
During the quarters ended December 26, 2014 and December 27, 2013, the Company did not have any significant transfers between levels within the fair value hierarchy.

[0000833444-15-000013:notes:126]
[same as prior period, unchanged from 0000833444-14-000099:notes:114]

[0000833444-15-000013:notes:127]
The Company had $1.5 billion of intercompany loans designated as permanent in nature as of both December 26, 2014 and September 26, 2014.  Additionally, for the quarters ended December 26, 2014 and December 27, 2013, the Company recorded $70 million and $12 million of a cumulative translation loss, respectively, through Accumulated other comprehensive loss related to these loans.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-15-000013:notes:128]
[same as prior period, unchanged from 0000833444-14-000099:notes:118]

[0000833444-15-000013:notes:129]
[same as prior period, unchanged from 0000833444-14-000099:notes:119]

[0000833444-15-000013:notes:130]
|  | NA Installation &Services |  | ROWInstallation &Services |  | GlobalProducts |  | Total |
| Gross goodwill | $ | 2,104 |  |  | $ | 1,995 |  |  | $ | 1,824 |  |  | $ | 5,923 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 27, 2013 | 1,978 |  |  | 927 |  |  | 1,257 |  |  | 4,162 |  |
| 2014 activity: |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions/ purchase accounting adjustments | 10 |  |  | 15 |  |  | (4 | ) |  | 21 |  |
| Currency translation | (12 | ) |  | (34 | ) |  | (11 | ) |  | (57 | ) |
| Gross goodwill | $ | 2,102 |  |  | $ | 1,976 |  |  | $ | 1,809 |  |  | $ | 5,887 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 26, 2014 | 1,976 |  |  | 908 |  |  | 1,242 |  |  | 4,126 |  |
| 2015 activity: |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions / purchase accounting adjustments | — |  |  | 32 |  |  | 80 |  |  | 112 |  |
| Currency translation | (8 | ) |  | (69 | ) |  | (13 | ) |  | (90 | ) |
| Gross goodwill | $ | 2,094 |  |  | $ | 1,939 |  |  | $ | 1,876 |  |  | $ | 5,909 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of December 26, 2014 | $ | 1,968 |  |  | $ | 871 |  |  | $ | 1,309 |  |  | $ | 4,148 |  |

[0000833444-15-000013:notes:131]
Intangible asset amortization expense for the quarters ended December 26, 2014 and December 27, 2013 was $21 million and $24 million, respectively.

[0000833444-15-000013:notes:132]
The estimated aggregate amortization expense on intangible assets is expected to be approximately $55 million for the remainder of 2015, $73 million for 2016, $64 million for 2017, $60 million for 2018, and $241 million for 2019 and thereafter.


## us-gaap:GuaranteesTextBlock

[0000833444-15-000013:notes:133]
[same as prior period, unchanged from 0000833444-14-000099:notes:125]

[0000833444-15-000013:notes:134]
Certain of the Company's business segments have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance.  The Company's performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-15-000013:notes:135]
[same as prior period, unchanged from 0000833444-14-000099:notes:127]

[0000833444-15-000013:notes:136]
In addition, Tyco historically provided support in the form of financial and/or performance guarantees to various Covidien, TE Connectivity, ADT and Tyco Flow Control operating entities. In connection with both the 2012 and 2007 Separations, the Company worked with the guarantee counterparties to cancel or assign these guarantees to Covidien, TE Connectivity, ADT or Pentair, as appropriate. To the extent these guarantees were not assigned prior to the Separation dates, Tyco remained as the guarantor, but was typically indemnified by the former subsidiary. The Company's obligations related to the 2012 Separation were $3 million, which were included in Other liabilities on the Company's Consolidated Balance Sheets as of both December 26, 2014 and September 26, 2014, with an offset to Tyco's shareholders' equity on the 2012 Separation date. The Company's obligations related to the 2007 Separation were $3 million, which were included in Other liabilities on the Company's Consolidated Balance Sheets as of both December 26, 2014 and September 26, 2014, with an offset to Tyco's shareholders' equity on the 2007 Separation date.

[0000833444-15-000013:notes:137]
In disposing of assets or businesses, the Company often provides representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities and unidentified tax liabilities and legal fees related to periods prior to disposition. The Company has no reason to believe that these contingencies, if realized, would have a material adverse effect on the Company's financial position, results of operations or cash flows. The Company has recorded liabilities for known indemnifications included as part of environmental liabilities. See Note 11.

[0000833444-15-000013:notes:138]
[same as prior period, unchanged from 0000833444-14-000099:notes:131]

[0000833444-15-000013:notes:139]
The changes in the carrying amount of the Company's warranty accrual from September 26, 2014 to December 26, 2014 were as follows ($ million):

[0000833444-15-000013:notes:140]
| Balance as of September 26, 2014 | $ | 28 |  |
| Warranties issued | 2 |  |
| Changes in estimates | (1 | ) |
| Settlements | (2 | ) |
| Balance as of December 26, 2014 | $ | 27 |  |

[0000833444-15-000013:notes:141]
[same as prior period, unchanged from 0000833444-14-000099:notes:133]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-15-000013:notes:142]
[same as prior period, unchanged from 0000833444-14-000099:notes:134]

[0000833444-15-000013:notes:143]
Tyco did not have a significant change to its unrecognized tax benefits during the quarter ended December 26, 2014.

[0000833444-15-000013:notes:144]
[same as prior period, unchanged from 0000833444-14-000099:notes:136]

[0000833444-15-000013:notes:145]
| Jurisdiction | Years OpenTo Audit |
| Australia | 2004-2014 |
| Canada | 2006-2014 |
| Germany | 2005-2014 |
| Ireland | 2010-2014 |
| Switzerland | 2005-2014 |
| United Kingdom | 2012-2014 |
| United States | 1997-2014 |

[0000833444-15-000013:notes:146]
Based on the current status of its income tax audits, Tyco believes that it is reasonably possible that between nil and $20 million in unrecognized tax benefits may be resolved in the next twelve months.

[0000833444-15-000013:notes:147]
At each balance sheet date, the Company evaluates whether it is more likely than not that Tyco's deferred tax assets will be realized and if sufficient future taxable income will be available by assessing current period and projected operating results and other pertinent data. As of December 26, 2014, Tyco recorded deferred tax assets of approximately $382 million, which is comprised of $2.4 billion gross deferred tax assets net of $2.0 billion valuation allowances.

[0000833444-15-000013:notes:148]
[same as prior period, unchanged from 0000833444-14-000099:notes:140]

[0000833444-15-000013:notes:149]
In connection with the 2012 and 2007 Separations, Tyco entered into the 2012 and 2007 Tax Sharing Agreements, respectively, that govern the respective rights, responsibilities, and obligations of (i) Tyco, Pentair and ADT after the 2012 Separation and (ii) Tyco, Covidien plc (which merged into Medtronic plc on January 26, 2015, and referred to herein as "Covidien") and TE Connectivity after the 2007 Separation, with respect to taxes. Specifically, this includes taxes in the ordinary course of business and taxes, if any, incurred as a result of any failure of the respective distributions to qualify tax-free for U.S. federal income tax purposes within the meaning of Section 355 of the Internal Revenue Code ("the Code") or certain internal transactions undertaken in anticipation of the spin-offs to qualify for tax-favored treatment under the Code.

[0000833444-15-000013:notes:150]
Under the 2012 Tax Sharing Agreement, Tyco, Pentair and ADT share (i) certain pre-Distribution income tax liabilities that arise from adjustments made by tax authorities to ADT's, Tyco Flow Control's and Tyco's income tax returns, and (ii) payments required to be made by Tyco with respect to the 2007 Tax Sharing Agreement, excluding approximately $175 million of pre-2012 Separation related tax liabilities (collectively, "Shared Tax Liabilities"). Tyco will be responsible for the first $500 million of Shared Tax Liabilities. Pentair and ADT will share 42% and 58%, respectively, of the next $225 million of Shared Tax Liabilities. Tyco, Pentair and ADT will share 52.5%, 20% and 27.5%, respectively, of Shared Tax Liabilities above $725 million.  All costs and expenses associated with the management of these Shared Tax Liabilities will generally be shared 20%, 27.5% and 52.5% by Pentair, ADT and Tyco, respectively.  In connection with the execution of the 2012 Tax Sharing Arrangement, Tyco established liabilities representing the fair market value of its obligations which is recorded in Other liabilities in the Company's Consolidated Balance Sheet with an offset to Tyco shareholders' equity.

[0000833444-15-000013:notes:151]
Under the 2007 Tax Sharing Agreement, Tyco shares responsibility for certain of Tyco's, Covidien's and TE Connectivity's income tax liabilities, which result in cash payments, based on a sharing formula for periods prior to and including June 29, 2007. More specifically, Tyco, Covidien and TE Connectivity share 27%, 42% and 31%, respectively, of shared income tax liabilities that arise from adjustments made by tax authorities to Tyco's, Covidien's and TE Connectivity's U.S. and certain non-U.S. income tax returns. The costs and expenses associated with the management of these shared tax liabilities are generally shared equally among the parties. In connection with the execution of the 2007 Tax Sharing Agreement, Tyco established a net receivable from Covidien and TE Connectivity representing the amount Tyco expected to receive for pre-2007 Separation uncertain tax positions, including amounts owed to the Internal Revenue Service ("IRS"). Tyco also established liabilities representing the fair market value of its share of Covidien's and TE Connectivity's estimated obligations, primarily to the IRS, for their pre-2007 Separation taxes covered by the 2007 Tax Sharing Agreement.

[0000833444-15-000013:notes:152]
[same as prior period, unchanged from 0000833444-14-000099:notes:144]

[0000833444-15-000013:notes:153]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation.  The issues and proposed adjustments related to such years are generally subject to the sharing provisions of the 2007 Tax Sharing Agreement and Tyco's liabilities under the 2007 Tax Sharing Agreement are further subject to the sharing provisions in the 2012 Tax Sharing Agreement. Tyco has previously disclosed that in connection with U.S. federal tax audits, the IRS has raised a number of issues and proposed tax adjustments for periods beginning with the 1997 tax year. Although Tyco has been able to resolve substantially all of the issues and adjustments proposed by the IRS for tax years through 2007, it has not been able to resolve matters related to the treatment of certain intercompany debt transactions during the period. As a result, on June 20, 2013, Tyco received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owe additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million has been asserted. These amounts exclude interest and do not reflect the impact on subsequent periods if the IRS position described below is ultimately proved correct.

[0000833444-15-000013:notes:154]
The IRS asserted in the Notices of Deficiency that substantially all of Tyco's intercompany debt originated during the 1997 - 2000 period should not be treated as debt for U.S. federal income tax purposes, and has disallowed interest and related deductions recognized on U.S. income tax returns totaling approximately $2.9 billion. Tyco strongly disagrees with the IRS position and has filed petitions with the U.S. Tax Court contesting the IRS proposed adjustments.  A trial date has been set for February 2016.  Tyco believes that it has meritorious defenses for its tax filings, that the IRS positions with regard to these matters are inconsistent with the applicable tax laws and existing Treasury regulations, and that the previously reported taxes for the years in question are appropriate.

[0000833444-15-000013:notes:155]
[same as prior period, unchanged from 0000833444-14-000099:notes:146]

[0000833444-15-000013:notes:156]
[same as prior period, unchanged from 0000833444-14-000099:notes:147]

[0000833444-15-000013:notes:157]
In addition to dealing with tax liabilities for periods prior to the respective Separations, the 2012 and 2007 Tax Sharing Agreements contain sharing provisions to address the contingencies that the 2012 or 2007 Separations, or internal transactions related thereto, may be deemed taxable by U.S. or non U.S. taxing authorities. In the event the 2012 Separation is determined to be taxable and such determination was the result of actions taken after the 2012 Separations by Tyco, ADT or Pentair, the party responsible for such failure would be responsible for all taxes imposed on each company as a result thereof. If such determination is not the result of actions taken by Tyco, ADT or Pentair after the 2012 Separation, then Tyco, ADT and Pentair would be responsible for any taxes imposed on any of the companies as a result of such determination in the same manner and in the same proportions as described above. Similar provisions exist in the 2007 Tax Sharing Agreement. If either of the 2007 or 2012 Separation, or internal transactions taken in anticipation thereof, were deemed taxable, the associated liability could be significant. Tyco is responsible for all of its own taxes that are not shared pursuant to the 2012 and 2007 Tax Sharing Agreements' sharing formulas. In addition, Pentair and ADT, and Covidien and TE Connectivity are responsible for their tax liabilities that are not subject to the 2012 or 2007 Tax Sharing Agreements' sharing formula.

[0000833444-15-000013:notes:158]
[same as prior period, unchanged from 0000833444-14-000099:notes:149]

[0000833444-15-000013:notes:159]
The receivables and liabilities related to the 2012 and 2007 Tax Sharing Agreements as of December 26, 2014 and September 26, 2014, are as follows ($ in millions):

[0000833444-15-000013:notes:160]
[same as prior period, unchanged from 0000833444-14-000099:notes:158]

[0000833444-15-000013:notes:161]
Except for earnings that are currently distributed, no additional material provision has been made for U.S. or non-U.S. income taxes on the undistributed earnings of subsidiaries or for deferred tax liabilities for temporary differences related to investments in subsidiaries, since the earnings are expected to be permanently reinvested, the investments are essentially permanent in duration, or Tyco has concluded that no additional tax liability will arise as a result of the distribution of such earnings. A liability could arise if amounts are distributed by such subsidiaries or if such subsidiaries are ultimately disposed. It is not practicable to estimate the additional income taxes related to permanently reinvested earnings or the basis differences related to investments in subsidiaries.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-15-000013:notes:162]
[same as prior period, unchanged from 0000833444-14-000099:notes:160]

[0000833444-15-000013:notes:163]
[same as prior period, unchanged from 0000833444-14-000099:notes:161]

[0000833444-15-000013:notes:164]
|  | As of |
|  | December 26, 2014 |  | September 26, 2014 |
| Purchased materials and manufactured parts | $ | 172 |  |  | $ | 159 |  |
| Work in process | 88 |  |  | 86 |  |
| Finished goods | 398 |  |  | 383 |  |
| Inventories | $ | 658 |  |  | $ | 628 |  |

[0000833444-15-000013:notes:165]
[same as prior period, unchanged from 0000833444-14-000099:notes:163]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-15-000013:notes:166]
[same as prior period, unchanged from 0000833444-14-000099:notes:164]

[0000833444-15-000013:notes:167]
[same as prior period, unchanged from 0000833444-14-000099:notes:165]

[0000833444-15-000013:notes:168]
|  | U.S. Plans |
|  | For the Quarters Ended |
|  | December 26, 2014 |  | December 27, 2013 |
| Service cost | $ | 2 |  |  | $ | 2 |  |
| Interest cost | 9 |  |  | 9 |  |
| Expected return on plan assets | (14 | ) |  | (12 | ) |
| Amortization of net actuarial loss | 2 |  |  | 2 |  |
| Net periodic benefit cost | $ | (1 | ) |  | $ | 1 |  |

[0000833444-15-000013:notes:169]
|  | Non-U.S. Plans |
|  | For the Quarters Ended |
|  | December 26, 2014 |  | December 27, 2013 |
| Service cost | $ | 2 |  |  | $ | 2 |  |
| Interest cost | 13 |  |  | 14 |  |
| Expected return on plan assets | (20 | ) |  | (18 | ) |
| Amortization of net actuarial loss | 4 |  |  | 3 |  |
| Net periodic benefit cost | $ | (1 | ) |  | $ | 1 |  |

[0000833444-15-000013:notes:170]
The estimated net actuarial loss for U.S. pension benefit plans that will be amortized from accumulated other comprehensive loss into net periodic benefit cost over the current fiscal year is expected to be $9 million, and the amount for  non-U.S. pension benefit plans is expected to be $14 million.  Amortization of net periodic benefit cost from accumulated other comprehensive loss for the Company's pension benefit plans is recorded in Selling, general and administrative expenses, Cost of product sales, or Cost of services in the Consolidated Statements of Operations, depending on the employee job classification.

[0000833444-15-000013:notes:171]
The Company's funding policy is to make contributions in accordance with the laws and customs of the various countries in which it operates and to make discretionary voluntary contributions from time to time. The Company anticipates that it will contribute at least the minimum required to its pension plans in fiscal year 2015 of $13 million for U.S. plans and $23 million for non-U.S. plans. During the quarter ended December 26, 2014, the Company made required contributions of $1 million to its U.S. pension plans and $5 million to its non-U.S. pension plans.

[0000833444-15-000013:notes:172]
[same as prior period, unchanged from 0000833444-14-000099:notes:170]


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-15-000013:notes:173]
[same as prior period, unchanged from 0000833444-14-000099:notes:171]

[0000833444-15-000013:notes:174]
[same as prior period, unchanged from 0000833444-14-000099:notes:172]

[0000833444-15-000013:notes:175]
|  | As of |
|  | December 26, 2014 |  | September 26, 2014 |
| Land | $ | 35 |  |  | $ | 36 |  |
| Buildings | 412 |  |  | 417 |  |
| Subscriber systems | 2,135 |  |  | 2,213 |  |
| Machinery and equipment | 1,264 |  |  | 1,271 |  |
| Construction in progress | 94 |  |  | 90 |  |
| Accumulated depreciation | (2,698 | ) |  | (2,758 | ) |
| Property, plant and equipment, net | $ | 1,242 |  |  | $ | 1,269 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000833444-15-000013:notes:176]
[same as prior period, unchanged from 0000833444-14-000099:notes:174]

[0000833444-15-000013:notes:177]
During the first quarter of fiscal 2015, the Company identified and pursued opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across the Company's businesses. The Company expects to incur restructuring and restructuring related charges in the range of $75 million to $100 million in fiscal 2015, which does not include repositioning charges as described below.

[0000833444-15-000013:notes:178]
[same as prior period, unchanged from 0000833444-14-000099:notes:176]

[0000833444-15-000013:notes:179]
|  | For the Quarters Ended |
|  | December 26, 2014 |  | December 27, 2013 |
| 2015 actions | $ | 44 |  |  | $ | — |  |
| 2014 actions | 6 |  |  | 1 |  |
| 2013 and prior actions | 8 |  |  | 2 |  |
| Total | $ | 58 |  |  | $ | 3 |  |

[0000833444-15-000013:notes:180]
2015 Actions

[0000833444-15-000013:notes:181]
Restructuring and asset impairment charges, net, during the quarter ended December 26, 2014 related to the 2015 actions are as follows ($ in millions):

[0000833444-15-000013:notes:182]
|  | For the Quarter Ended December 26, 2014 |
|  | EmployeeSeverance andBenefits |
| NA Installation & Services | $ | 22 |  |
| ROW Installation & Services | 10 |  |
| Global Products | 2 |  |
| Corporate and other | 10 |  |
| Total | $ | 44 |  |

[0000833444-15-000013:notes:183]
The rollforward of the reserves from September 26, 2014 to December 26, 2014 is as follows ($ in millions):

[0000833444-15-000013:notes:184]
| Balance as of September 26, 2014 | $ | — |  |
| Charges | 44 |  |
| Utilization | (11 | ) |
| Balance as of December 26, 2014 | $ | 33 |  |

[0000833444-15-000013:notes:185]
[same as prior period, unchanged from 0000833444-14-000099:notes:193]

[0000833444-15-000013:notes:186]
[same as prior period, unchanged from 0000833444-14-000099:notes:178]

[0000833444-15-000013:notes:187]
Restructuring and asset impairment charges, net, during the quarters ended December 26, 2014 and December 27, 2013 related to the 2014 actions are as follows ($ in millions):

[0000833444-15-000013:notes:188]
|  | For the Quarter Ended December 26, 2014 |
|  | EmployeeSeverance andBenefits |
| NA Installation & Services | $ | 1 |  |
| Global Products | 5 |  |
| Total | $ | 6 |  |

[0000833444-15-000013:notes:189]
|  | For the Quarter Ended December 27, 2013 |
|  | EmployeeSeverance andBenefits |
| ROW Installation & Services | $ | 1 |  |
| Total | $ | 1 |  |

[0000833444-15-000013:notes:190]
Restructuring and asset impairment charges, net, incurred cumulative to date from initiation of the 2014 actions are as follows ($ in millions):

[0000833444-15-000013:notes:191]
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Charges Reflected in SG&A |  | Total |
| NA Installation & Services | $ | 17 |  |  | $ | — |  |  | $ | — |  |  | $ | 17 |  |
| ROW Installation & Services | 18 |  |  | 5 |  |  | — |  |  | 23 |  |
| Global Products | 8 |  |  | — |  |  | 2 |  |  | 10 |  |
| Total | $ | 43 |  |  | $ | 5 |  |  | $ | 2 |  |  | $ | 50 |  |

[0000833444-15-000013:notes:192]
| Balance as of September 26, 2014 | $ | 29 |  |
| Charges | 6 |  |
| Utilization | (7 | ) |
| Currency translation | (1 | ) |
| Balance as of December 26, 2014 | $ | 27 |  |

[0000833444-15-000013:notes:193]
2013 and prior actions

[0000833444-15-000013:notes:194]
The Company continues to maintain restructuring reserves related to actions initiated prior to fiscal 2014. The total amount of these reserves was $66 million and $70 million as of December 26, 2014 and September 26, 2014, respectively. The Company incurred $8 million and $10 million of restructuring charges, nil and $8 million of reversals, and utilized $9 million and $24 million for the quarters ended December 26, 2014 and December 27, 2013, respectively.  The remaining change in reserve during the quarters ended December 26, 2014 and December 27, 2013 relates to currency translation. The aggregate remaining reserves primarily relate to facility exit costs for long-term non-cancelable lease obligations primarily within the Company's ROW Installation & Services segment.

[0000833444-15-000013:notes:195]
[same as prior period, unchanged from 0000833444-14-000099:notes:196]

[0000833444-15-000013:notes:196]
[same as prior period, unchanged from 0000833444-14-000099:notes:199]

[0000833444-15-000013:notes:197]
The Company has initiated certain global actions designed to reduce its cost structure and improve future profitability by streamlining operations and better aligning functions, which the Company refers to as repositioning actions. These actions may or may not lead to a future restructuring action. During the quarters ended December 26, 2014 and December 27, 2013, the Company recorded repositioning charges of $17 million and $6 million, respectively, primarily related to professional fees which have been reflected in Selling, general and administrative expenses in the Consolidated Statements of Operations.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-15-000013:notes:198]
A summary of the changes in each component of Accumulated other comprehensive loss, net of tax, for the quarter ended December 26, 2014 are as follows ($ in millions):

[0000833444-15-000013:notes:199]
|  | CurrencyTranslationAdjustments |  | RetirementPlans |  | Accumulated OtherComprehensive Loss |
| Balance as of September 26, 2014 | $ | (693 | ) |  | $ | (532 | ) |  | $ | (1,225 | ) |
| Other comprehensive (loss) income, net of tax | (198 | ) |  | 5 |  |  | (193 | ) |
| Balance as of December 26, 2014 | $ | (891 | ) |  | $ | (527 | ) |  | $ | (1,418 | ) |


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0000833444-15-000013:notes:200]
omprehensive Income (Loss)

[0000833444-15-000013:notes:201]
Comprehensive income (loss) is comprised of the following ($ in millions):

[0000833444-15-000013:notes:202]
|  | For the Quarters Ended |
|  | December 26, 2014 |  | December 27, 2013 |
| Net income | $ | 161 |  |  | $ | 272 |  |
| Foreign currency translation, net of tax | (198 | ) |  | (37 | ) |
| Amortization of net actuarial losses | 6 |  |  | 5 |  |
| Income tax expense | (1 | ) |  | (2 | ) |
| Defined benefit and post retirement plans, net of tax | 5 |  |  | 3 |  |
| Total other comprehensive loss, net of tax | (193 | ) |  | (34 | ) |
| Comprehensive (loss) income | (32 | ) |  | 238 |  |
| Less: comprehensive (loss) income attributable to noncontrolling interests | (1 | ) |  | 2 |  |
| Comprehensive (loss) income attributable to Tyco ordinary shareholders | $ | (31 | ) |  | $ | 236 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-15-000013:notes:203]
[same as prior period, unchanged from 0000833444-14-000099:notes:210]

[0000833444-15-000013:notes:204]
[same as prior period, unchanged from 0000833444-14-000099:notes:211]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-15-000013:notes:205]
[same as prior period, unchanged from 0000833444-14-000099:notes:217]

[0000833444-15-000013:notes:206]
As a result of the Merger, the Company’s authorized share capital changed.

[0000833444-15-000013:notes:207]
Authorized Share Capital

[0000833444-15-000013:notes:208]
The authorized share capital of Tyco Ireland is $11,000,000 and €40,000, divided into 1,000,000,000 ordinary shares with a par value of $0.01 per share, 100,000,000 preferred shares with a par value of $0.01 per share and 40,000 ordinary A shares with a par value of €1.00 per share.  The authorized share capital includes 40,000 ordinary A shares with a par value of €1.00 per share in order to satisfy statutory requirements for the incorporation of all Irish public limited companies. Tyco Ireland may issue shares subject to the maximum prescribed by its authorized share capital contained in its memorandum of association. In connection with the Merger, Tyco Ireland canceled all then outstanding treasury shares, including shares held by subsidiaries, with an offsetting reduction in Additional paid in capital.

[0000833444-15-000013:notes:209]
Issued Share Capital

[0000833444-15-000013:notes:210]
Tyco Ireland issued one ordinary share in exchange for each common share of Tyco Switzerland to the former shareholders of Tyco Switzerland.  All Tyco Ireland ordinary shares issued at the effective time of the Merger were issued as fully paid-up and non-assessable.  As of January 23, 2015, 420,045,569 ordinary shares were outstanding.

[0000833444-15-000013:notes:211]
[same as prior period, unchanged from 0000833444-14-000099:notes:218]

[0000833444-15-000013:notes:212]
On March 5, 2014, the Company's shareholders approved an annual cash dividend of $0.72 per ordinary share.  Payment of the dividend is to be made in four quarterly installments of $0.18 from May 2014 through February 2015.  As a result, during the quarter ended March 28, 2014, the Company recorded an accrued dividend of $332 million within Accrued and other current liabilities and a corresponding reduction to Additional paid in capital on the Company's Consolidated Balance Sheet. The third installment of $0.18 was paid on November 13, 2014 to shareholders of record on October 24, 2014.  The fourth installment will be paid on February 18, 2015 to shareholders of record on January 23, 2015.

[0000833444-15-000013:notes:213]
The timing, declaration and payment of future dividends to holders of our ordinary shares will be determined by the Company's Board of Directors and will depend upon many factors, including Tyco's financial condition and results of operations, the capital requirements of the Company's businesses, industry practice and any other relevant factors.

[0000833444-15-000013:notes:214]
Under Irish law, dividends may only be paid (and share repurchases and redemptions must generally be funded) out of “distributable reserves.” The creation of distributable reserves of Tyco Ireland was accomplished by way of a capital reduction of Tyco Ireland, which the Irish High Court approved on December 18, 2014.

[0000833444-15-000013:notes:215]
[same as prior period, unchanged from 0000833444-14-000099:notes:221]

[0000833444-15-000013:notes:216]
The Company's Board of Directors approved $1.75 billion and $1 billion share repurchase programs in March 2014 and September 2014, respectively.  During the quarter ended December 26, 2014, the Company repurchased a total of approximately 10 million shares for approximately $417 million which completed the $1.75 billion share repurchase program.  As of December 26, 2014, a total of approximately $1 billion in share repurchase authority remained outstanding under the $1 billion share repurchase program. Share repurchases reduce the amount of ordinary shares outstanding and decrease the accrued dividend liability on the Consolidated Statement of Stockholders' Equity, as shares repurchased by the Company or its subsidiaries are not entitled to dividends.

[0000833444-15-000013:notes:217]
Comprehensive Income (Loss)
