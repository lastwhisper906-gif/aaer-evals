# JCI 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 3 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0000833444-16-000216:item_9a:1]
| ITEM 9A | CONTROLS AND PROCEDURES |

[0000833444-16-000216:item_9a:2]
Disclosure Controls and Procedures

[0000833444-16-000216:item_9a:3]
The Company’s management, with the participation of the Company’s Chief Executive Officer and Chief Financial Officer, has evaluated the effectiveness of the Company’s disclosure controls and procedures (as such term is defined in Rule 13a-15(e) under the Securities Exchange Act of 1934, as amended (the "Exchange Act")) as of the end of the period covered by this report. Based on such evaluations, the Company’s Chief Executive Officer and Chief Financial Officer have concluded that, as of the end of such period, the Company’s disclosure controls and procedures are effective in recording, processing, summarizing, and reporting, on a timely basis, information required to be disclosed by the Company in the reports that it files or submits under the Exchange Act, and that information is accumulated and communicated to the Company’s management, including the Company’s Chief Executive Officer and Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0000833444-16-000216:item_9a:4]
142

[0000833444-16-000216:item_9a:5]
Management’s Report on Internal Control Over Financial Reporting

[0000833444-16-000216:item_9a:6]
The Company’s management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rule 13a-15(f). The Company’s management, with the participation of the Company’s Chief Executive Officer and Chief Financial Officer, has evaluated the effectiveness of the Company’s internal control over financial reporting based on the framework in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this evaluation, the Company’s management has concluded that, as of September 30, 2016, the Company’s internal control over financial reporting was effective.

[0000833444-16-000216:item_9a:7]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000833444-16-000216:item_9a:8]
PricewaterhouseCoopers LLP, an independent registered public accounting firm, has audited the Company’s consolidated financial statements and the effectiveness of internal control over financial reporting as of September 30, 2016 as stated in its report which is included in Item 8 of this Form 10-K and is incorporated by reference herein.

[0000833444-16-000216:item_9a:9]
Management has excluded the operations of the Tyco business from its assessment of internal control over financial reporting as of September 30, 2016 given that the acquisition date of Tyco was September 2, 2016. Tyco's combined total assets and total revenues excluded from our assessment represent approximately 44% and less than 2%, respectively, of the related consolidated financial statement amounts as of and for the year ended September 30, 2016.

[0000833444-16-000216:item_9a:10]
Changes in Internal Control Over Financial Reporting

[0000833444-16-000216:item_9a:11]
There have been no changes in the Company’s internal control over financial reporting during the quarter ended September 30, 2016, that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.
