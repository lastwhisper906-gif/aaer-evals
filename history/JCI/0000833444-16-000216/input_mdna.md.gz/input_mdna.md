# JCI MD&A — 0000833444-16-000216


## mdna

[0000833444-16-000216:mdna:1]
| ITEM 7 | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0000833444-16-000216:mdna:2]
General

[0000833444-16-000216:mdna:3]
The Company operates in three primary businesses: Buildings, Automotive Experience and Power Solutions. Buildings provides facility systems and services including comfort and energy management for the residential and non-residential buildings markets, security products and services, fire detection and suppression products and services, and life safety products. Automotive Experience designs and manufactures interior products and systems for passenger cars and light trucks, including vans, pick-up trucks and sport/crossover utility vehicles. Power Solutions designs and manufactures automotive batteries for the replacement and original equipment markets.

[0000833444-16-000216:mdna:4]
This discussion summarizes the significant factors affecting the consolidated operating results, financial condition and liquidity of the Company for the three-year period ended September 30, 2016. This discussion should be read in conjunction with Item 8, the consolidated financial statements and the notes to consolidated financial statements.

[0000833444-16-000216:mdna:5]
In the fourth quarter of fiscal 2016, the Company changed its accounting policy for accruing for defense costs related to asbestos claims on a discounted basis. The Company’s historical accounting treatment for asbestos claim defense costs was to accrue as incurred. The new policy is to record an accrual for all future asbestos related defense costs which are determined to be probable and estimable of being incurred. The Company believes this new policy is preferable as it better reflects the economics of settlement of the Company's asbestos claims, improves comparability among the Company’s peer group and provides greater transparency to on-going operating results. These changes have been reported through retrospective application of the new policy to all periods presented. These changes did not have an impact to any period presented on the consolidated statements of income. Refer to Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements for further information regarding this accounting policy change.

[0000833444-16-000216:mdna:6]
Subsequent Event

[0000833444-16-000216:mdna:7]
On July 24, 2015, the Company announced its intent to pursue a separation of the Automotive Experience business through a spin-off to shareholders. The spin-off was completed on October 31, 2016. The new publicly traded company is named Adient plc.

[0000833444-16-000216:mdna:8]
FISCAL YEAR 2016 COMPARED TO FISCAL YEAR 2015

[0000833444-16-000216:mdna:9]
Net Sales

[0000833444-16-000216:mdna:10]
|  | Year Ended September 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Net sales | $ | 37,674 |  |  | $ | 37,179 |  |  | 1 | % |

[0000833444-16-000216:mdna:11]
The increase in consolidated net sales was due to higher sales in the Buildings business ($3,837 million) and Power Solutions business ($243 million), partially offset by lower sales in the Automotive Experience business ($2,831 million) and the unfavorable impact of foreign currency translation ($754 million). Excluding the unfavorable impact of foreign currency translation,

[0000833444-16-000216:mdna:12]
33

[0000833444-16-000216:mdna:13]
consolidated net sales increased 3% as compared to the prior year. Increased sales resulted from the Johnson Controls - Hitachi (JCH) joint venture and the Tyco merger,  as well as higher volumes in the Buildings Systems and Service North America segment in the Buildings business, higher Automotive Experience volumes globally, and higher global battery shipments and favorable product mix in the Power Solutions business, partially offset by the deconsolidation of the majority of the Automotive Experience Interiors business in the prior year. Refer to the segment analysis below within Item 7 for a discussion of net sales by segment.

[0000833444-16-000216:mdna:14]
Cost of Sales / Gross Profit

[0000833444-16-000216:mdna:15]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Cost of sales | $ | 30,360 |  |  | $ | 30,732 |  |  | -1 | % |
| Gross profit | 7,314 |  |  | 6,447 |  |  | 13 | % |
| % of sales | 19.4 | % |  | 17.3 | % |  |  |

[0000833444-16-000216:mdna:16]
Cost of sales decreased in fiscal 2016 as compared to fiscal 2015, with gross profit as a percentage of sales increasing by 210 basis points. Foreign currency translation had a favorable impact on cost of sales of approximately $635 million. Gross profit in the Buildings business included the incremental gross profit related to the JCH joint venture and Tyco merger, and higher volumes in the Buildings Systems and Service North America segment. Gross profit in the Automotive Experience business was favorably impacted by higher volumes globally, restructuring savings and operational efficiencies, partially offset by unfavorable commercial settlements and unfavorable mix. Gross profit in the Power Solutions business was favorably impacted by higher volumes, and favorable pricing and product mix, partially offset by higher operating costs. Net mark-to-market adjustments on pension and postretirement plans had a net favorable year over year impact on cost of sales of $43 million ($113 million charge in fiscal 2016 compared to a $156 million charge in fiscal 2015) primarily due to the unfavorable U.S. investment returns versus expectations and the adoption of new mortality rate changes in the U.S. in the prior year, partially offset by a decrease in year-over-year discount rates. Refer to the segment analysis below within Item 7 for a discussion of segment earnings before interest and taxes (EBIT) by segment.

[0000833444-16-000216:mdna:17]
Selling, General and Administrative Expenses

[0000833444-16-000216:mdna:18]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Selling, general and administrative expenses | $ | 5,325 |  |  | $ | 3,986 |  |  | 34 | % |
| % of sales | 14.1 | % |  | 10.7 | % |  |  |

[0000833444-16-000216:mdna:19]
Selling, general and administrative expenses (SG&A) increased by $1,339 million year over year, and SG&A as a percentage of sales increased by 340 basis points. The net mark-to-market adjustments on pension and postretirement plans had a net unfavorable year over year impact on SG&A of $124 million ($390 million charge in fiscal 2016 compared to a $266 million charge in fiscal 2015) primarily due to a decrease in year-over-year discount rates, partially offset by the unfavorable U.S. investment returns versus expectations and the adoption of new mortality rate changes in the U.S. in the prior year. Additionally, the net unfavorable impact on SG&A resulting from separation costs was $442 million (recorded in the Automotive Experience segment), and transaction and integration costs was $130 million (recorded in the Buildings segments). Excluding the impact of separation costs, the Automotive Experience business SG&A decreased due to the deconsolidation of the majority of the Automotive Experience Interiors business in the prior year, restructuring savings and cost reduction initiatives. Excluding the impact of transaction and integrations costs, the Buildings business SG&A increased primarily due to incremental SG&A related to the JCH joint venture and Tyco merger, and product and sales force investments in North America. The Power Solutions business SG&A decreased primarily due to lower employee related expenses and cost reduction initiatives. Foreign currency translation had a favorable impact on SG&A of $69 million. Refer to the segment analysis below within Item 7 for a discussion of segment EBIT by segment.

[0000833444-16-000216:mdna:20]
34

[0000833444-16-000216:mdna:21]
Restructuring and Impairment Costs

[0000833444-16-000216:mdna:22]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Restructuring and impairment costs | $ | 620 |  |  | $ | 397 |  |  | 56 | % |

[0000833444-16-000216:mdna:23]
Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans.

[0000833444-16-000216:mdna:24]
Net Financing Charges

[0000833444-16-000216:mdna:25]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Net financing charges | $ | 314 |  |  | $ | 288 |  |  | 9 | % |

[0000833444-16-000216:mdna:26]
Net financing charges increased in fiscal 2016 as compared to fiscal 2015 primarily due to higher average borrowing levels; in part due to the acquisition of debt as a result of the Tyco merger as well as new debt incurred in fiscal 2016 in advance of the spin-off of the Automotive Experience business in the first quarter of fiscal 2017.

[0000833444-16-000216:mdna:27]
Equity Income

[0000833444-16-000216:mdna:28]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Equity income | $ | 531 |  |  | $ | 375 |  |  | 42 | % |

[0000833444-16-000216:mdna:29]
The increase in equity income was primarily due to current year income related to partially-owned affiliates of the JCH joint venture in the Buildings business, current year income related to the Automotive Experience Interiors joint venture formed on July 2, 2015 and higher income at certain Automotive Experience Seating partially-owned affiliates, partially offset by the unfavorable impact of foreign currency translation ($13 million). Refer to the segment analysis below within Item 7 for a discussion of segment EBIT by segment.

[0000833444-16-000216:mdna:30]
Income Tax Provision

[0000833444-16-000216:mdna:31]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Income tax provision | $ | 2,238 |  |  | $ | 600 |  |  | * |
| Effective tax rate | 141 | % |  | 28 | % |  |  |

[0000833444-16-000216:mdna:32]
* Measure not meaningful

[0000833444-16-000216:mdna:33]
The U.S. federal statutory tax rate is being used as a comparison since the Company was a U.S. domiciled company in fiscal 2015 and for11 months of 2016. The effective rate is above the U.S. statutory rate for fiscal 2016 primarily due to the tax consequences surrounding the planned spin-off of the Automotive Experience business and related expenses, the jurisdictional mix of restructuring and impairment costs, and the tax impacts of the merger and integration related costs, partially offset by the benefits of continuing global tax planning initiatives and foreign tax rate differentials. The effective rate is below the U.S. statutory rate for fiscal 2015 primarily due to the benefits of continuing global tax planning initiatives, income in certain non-U.S. jurisdictions with a tax rate lower than the U.S. statutory tax rate and adjustments due to tax audit resolutions, partially offset by the tax consequences of business divestitures, and significant restructuring and impairment costs. The fiscal 2016 effective tax rate increased as compared to the fiscal 2015 effective tax rate primarily due to the tax effects of transactions predominantly due to the planned spin-off ($1,795 million), and the tax effects of restructuring and impairment costs ($74 million), partially offset by tax planning initiatives ($151 million). The fiscal year 2016 and 2015 global tax planning initiatives related primarily to foreign tax credit planning, global financing structures and alignment of our global business functions in a tax efficient manner. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for further details.

[0000833444-16-000216:mdna:34]
35

[0000833444-16-000216:mdna:35]
Valuation Allowances

[0000833444-16-000216:mdna:36]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-16-000216:mdna:37]
In the fourth quarter of fiscal 2016, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that no other material changes were needed to its valuation allowances.  Therefore, there was no impact to income tax expense due to valuation allowance changes in the three month period or year ended September 30, 2016.

[0000833444-16-000216:mdna:38]
In the fourth quarter of fiscal 2015, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily within Spain, Germany, and the United Kingdom would not be realized, and was more likely than not that certain deferred tax assets of Poland and Germany would be realized. The impact of the net valuation allowance provision offset the benefit of valuation allowance releases and, as such, there was no net impact to income tax expense in the three month period or year ended September 30, 2015.

[0000833444-16-000216:mdna:39]
Uncertain Tax Positions

[0000833444-16-000216:mdna:40]
The Company is subject to income taxes in the U.S. and numerous foreign jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-16-000216:mdna:41]
During fiscal 2015, the Company settled a significant number of tax examinations in Germany, Mexico and the U.S., impacting fiscal years 1998 to fiscal 2012. The settlement of unrecognized tax benefits included cash payments for approximately $440 million and the loss of various tax attributes. The reduction for tax positions of prior years is substantially related to foreign exchange rates. In the fourth quarter of fiscal 2015, income tax audit resolutions resulted in a net $99 million benefit to income tax expense.

[0000833444-16-000216:mdna:42]
The Company’s federal income tax returns and certain non-U.S. income tax returns for various fiscal years remain under various stages of audit by the Internal Revenue Service ("IRS") and respective non-U.S. tax authorities. Although the outcome of tax audits is always uncertain, management believes that it has appropriate support for the positions taken on its tax returns and that its annual tax provisions included amounts sufficient to pay assessments, if any, which may be proposed by the taxing authorities. At September 30, 2016, the Company had recorded a liability for its best estimate of the probable loss on certain of its tax positions, the majority of which is included in other noncurrent liabilities in the consolidated statements of financial position. Nonetheless, the amounts ultimately paid, if any, upon resolution of the issues raised by the taxing authorities may differ materially from the amounts accrued for each year.

[0000833444-16-000216:mdna:43]
Other Tax Matters

[0000833444-16-000216:mdna:44]
During fiscal 2016 and 2015, the Company incurred significant charges for restructuring and impairment costs. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. A substantial portion of these charges cannot be benefited for tax purposes due to the Company's current tax position in these jurisdictions and the underlying tax basis in the impaired assets, resulting in $126 million and $52 million incremental tax expense in fiscal 2016 and 2015, respectively.

[0000833444-16-000216:mdna:45]
During the fourth quarter of fiscal 2016, the Company completed its merger with Tyco. As a result of that transaction, the Company incurred incremental tax expense of $137 million. In preparation for the spin-off of the Automotive Experience business in the first quarter of fiscal 2017, the Company incurred incremental tax expense of $121 million in fiscal 2016. The Company also completed substantial business reorganizations which resulted in total tax charges of $1,891 million in fiscal 2016. Included in this amount is the tax charge provided for in the third quarter of fiscal 2016 of $85 million for changes in entity tax status and the charge provided for in the second quarter of fiscal 2016 of $780 million for income tax expense on foreign undistributed earnings of certain non-U.S. subsidiaries.

[0000833444-16-000216:mdna:46]
36

[0000833444-16-000216:mdna:47]
In the fourth quarter of fiscal 2015, the Company completed its global automotive interiors joint venture with Yanfeng Automotive Trim Systems. Refer to Note 3, "Acquisitions and Divestitures," of the notes to consolidated financial statements for additional information. In connection with the divestiture of the Interiors business, the Company recorded a pre-tax gain on divestiture of $145 million, $38 million net of tax. The tax impact of the gain is due to the jurisdictional mix of gains and losses on the divestiture, which resulted in non-benefited expenses in certain countries and taxable gains in other countries. In addition, in the third and fourth quarters of fiscal 2015, the Company provided income tax expense for repatriation of cash and other tax reserves associated with the Automotive Experience Interiors joint venture transaction, which resulted in a tax charge of $75 million and $223 million, respectively.

[0000833444-16-000216:mdna:48]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-16-000216:mdna:49]
After the fourth quarter of fiscal 2016, on October 13, 2016, the U.S. Treasury and the IRS released final and temporary Section 385 regulations. These regulations address whether certain instruments between related parties are treated as debt or equity. The Company does not expect that the regulations will have a material impact on its consolidated financial statements.

[0000833444-16-000216:mdna:50]
The "look-through rule," under subpart F of the U.S. Internal Revenue Code, expired for the Company on September 30, 2015. The "look-through rule" had provided an exception to the U.S. taxation of certain income generated by foreign subsidiaries. The rule was extended in December 2015 retroactive to the beginning of the Company’s 2016 fiscal year. The retroactive extension was signed into legislation and was made permanent through the Company's 2020 fiscal year.

[0000833444-16-000216:mdna:51]
In the second quarter of fiscal 2015, tax legislation was adopted in Japan which reduced its statutory income tax rate. As a result of the law change, the Company recorded income tax expense of $17 million in the second quarter of fiscal 2015.

[0000833444-16-000216:mdna:52]
During the fiscal years ended 2016 and 2015, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-16-000216:mdna:53]
Income From Discontinued Operations, Net of Tax

[0000833444-16-000216:mdna:54]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Income from discontinued operations, net of tax | $ | — |  |  | $ | 128 |  |  | * |

[0000833444-16-000216:mdna:55]
* Measure not meaningful

[0000833444-16-000216:mdna:56]
Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-16-000216:mdna:57]
Income Attributable to Noncontrolling Interests

[0000833444-16-000216:mdna:58]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 216 |  |  | $ | 112 |  |  | 93 | % |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | 4 |  |  | * |  |

[0000833444-16-000216:mdna:59]
* Measure not meaningful

[0000833444-16-000216:mdna:60]
The increase in income from continuing operations attributable to noncontrolling interests for fiscal 2016 was primarily due to current year income related to the JCH joint venture in the Buildings business.

[0000833444-16-000216:mdna:61]
Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-16-000216:mdna:62]
Net Income (Loss) Attributable to Johnson Controls

[0000833444-16-000216:mdna:63]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Net income (loss) attributable to Johnson Controls | $ | (868 | ) |  | $ | 1,563 |  |  | * |

[0000833444-16-000216:mdna:64]
* Measure not meaningful

[0000833444-16-000216:mdna:65]
The decrease in net income (loss) attributable to Johnson Controls was primarily due to an increase in the income tax provision, higher SG&A primarily due to higher separation and transaction costs in the current year, and current year restructuring and impairment costs, partially offset by higher gross profit. Fiscal 2016 diluted earnings (loss) per share attributable to Johnson Controls was ($1.30) compared to $2.36 in fiscal 2015.

[0000833444-16-000216:mdna:66]
Comprehensive Income (Loss) Attributable to Johnson Controls

[0000833444-16-000216:mdna:67]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Comprehensive income (loss) attributable to Johnson Controls | $ | (964 | ) |  | $ | 743 |  |  | * |

[0000833444-16-000216:mdna:68]
* Measure not meaningful

[0000833444-16-000216:mdna:69]
The decrease in comprehensive income (loss) attributable to Johnson Controls was due to lower net income (loss) attributable to Johnson Controls ($2,431 million), partially offset by a decrease in other comprehensive loss attributable to Johnson Controls ($724 million) primarily related to favorable foreign currency translation adjustments. These year-over-year favorable foreign currency translation adjustments were primarily driven by the weakening of the Brazilian real, Canadian dollar, Colombian peso, euro and Japanese currencies against the U.S. dollar in the prior year.

[0000833444-16-000216:mdna:70]
SEGMENT ANALYSIS

[0000833444-16-000216:mdna:71]
Management evaluates the performance of its business units based primarily on segment EBIT, which is defined as income from continuing operations before income taxes and noncontrolling interests excluding net financing charges, significant restructuring and impairment costs, and net mark-to-market adjustments on pension and postretirement plans.

[0000833444-16-000216:mdna:72]
Buildings

[0000833444-16-000216:mdna:73]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |  | Segment EBITfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
| Building Efficiency |  |  |  |  |  |  |  |  |  |  |  |
| Systems and Service North America | $ | 4,292 |  |  | $ | 4,184 |  |  | 3 | % |  | $ | 412 |  |  | $ | 375 |  |  | 10 | % |
| Products North America | 2,488 |  |  | 2,450 |  |  | 2 | % |  | 173 |  |  | 306 |  |  | -43 | % |
| Asia | 4,830 |  |  | 1,985 |  |  | * |  |  | 431 |  |  | 191 |  |  | * |  |
| Rest of World | 1,766 |  |  | 1,891 |  |  | -7 | % |  | 20 |  |  | 51 |  |  | -61 | % |
|  | 13,376 |  |  | 10,510 |  |  | 27 | % |  | 1,036 |  |  | 923 |  |  | 12 | % |
| Tyco | 808 |  |  | — |  |  | * |  |  | (17 | ) |  | — |  |  | * |  |
|  | $ | 14,184 |  |  | $ | 10,510 |  |  | 35 | % |  | $ | 1,019 |  |  | $ | 923 |  |  | 10 | % |

[0000833444-16-000216:mdna:74]
* Measure not meaningful

[0000833444-16-000216:mdna:75]
Net Sales:

[0000833444-16-000216:mdna:76]
| • | The increase in Systems and Service North America was due to higher volumes of controls systems and service ($183 million), partially offset by lower volumes related to business divestitures ($52 million) and the unfavorable impact of foreign currency translation ($23 million). The increase in volumes was primarily attributable to market share gains. |

[0000833444-16-000216:mdna:77]
| • | The increase in Products North America was due to higher volumes ($49 million), partially offset by the unfavorable impact of foreign currency translation ($11 million). The increase in volumes was primarily driven by new product offerings. |

[0000833444-16-000216:mdna:78]
| • | The increase in Asia was due to incremental sales related to the JCH joint venture ($2,808 million), higher service volumes ($56 million), and higher volumes of equipment and control systems ($30 million), partially offset by the unfavorable impact of foreign currency translation ($49 million). The increase in volume was driven by favorable local economic conditions. |

[0000833444-16-000216:mdna:79]
| • | The decrease in Rest of World was due to the unfavorable impact of foreign currency translation ($80 million) and lower volumes in Latin America ($22 million), Europe ($16 million) and the Middle East ($14 million), partially offset by incremental sales related to a business acquisition ($7 million). The net decrease in volumes was primarily attributable to unfavorable local market conditions and the discontinuance of certain products. |

[0000833444-16-000216:mdna:80]
| • | The increase in Tyco was due to incremental sales related to the Tyco Merger ($808 million). |

[0000833444-16-000216:mdna:81]
Segment EBIT:

[0000833444-16-000216:mdna:82]
| • | The increase in Systems and Service North America was due to lower selling, general and administrative expenses ($63 million) as a result of restructuring actions and other cost reduction initiatives and a current year gain on business divestiture net of a prior year gain on business divestitures, higher volumes ($42 million), and prior year transaction and integration costs ($4 million), partially offset by current year transaction costs ($53 million), unfavorable margin rates ($8 million), lower income due to a prior year business divestiture ($5 million), the unfavorable impact of foreign currency translation ($4 million) and a pension settlement loss ($2 million). |

[0000833444-16-000216:mdna:83]
| • | The decrease in Products North America was due to higher selling, general and administrative expenses ($118 million)due to global product and related sales force investments and a prior year gain on business divestitures, current year transaction costs ($30 million), unfavorable margin rates ($6 million), a pension settlement loss ($3 million) and the unfavorable impact of foreign currency translation ($1 million), partially offset by higher volumes ($16 million), prior year transaction and integration costs ($8 million), and higher equity income ($1 million). |

[0000833444-16-000216:mdna:84]
| • | The increase in Asia was due primarily to incremental operating income related to the JCH joint venture exclusive of global investments in related products and technologies ($293 million), higher volumes ($29 million), prior year transaction and integration costs ($24 million), and lower selling, general and administrative expenses ($2 million), partially offset by current year transaction and integration costs ($87 million), unfavorable margin rates ($12 million) and the unfavorable impact of foreign currency translation ($9 million). |

[0000833444-16-000216:mdna:85]
| • | The decrease in Rest of World was due to current year transaction costs ($21 million), lower volumes ($13 million), higher selling, general and administrative expenses ($5 million), unfavorable margin rates ($3 million), lower equity income ($3 million) and the unfavorable impact of foreign currency translation ($3 million), partially offset by a gain on business divestiture ($12 million), a gain on acquisition of a partially-owned affiliate ($4 million) and prior year transaction costs ($1 million). |

[0000833444-16-000216:mdna:86]
| • | The Tyco loss was due to the impact of nonrecurring purchasing accounting adjustments ($74 million) and current year transaction costs ($29 million), partially offset by incremental operating income for the period subsequent to the Merger ($86 million). |

[0000833444-16-000216:mdna:87]
39

[0000833444-16-000216:mdna:88]
Automotive Experience

[0000833444-16-000216:mdna:89]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |  | Segment EBITfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
| Seating | $ | 16,355 |  |  | $ | 16,539 |  |  | -1 | % |  | $ | 676 |  |  | $ | 928 |  |  | -27 | % |
| Interiors | 482 |  |  | 3,540 |  |  | -86 | % |  | 75 |  |  | 254 |  |  | -70 | % |
|  | $ | 16,837 |  |  | $ | 20,079 |  |  | -16 | % |  | $ | 751 |  |  | $ | 1,182 |  |  | -36 | % |

[0000833444-16-000216:mdna:90]
Net Sales:

[0000833444-16-000216:mdna:91]
| • | The decrease in Seating was due to the unfavorable impact of foreign currency translation ($402 million), and net unfavorable pricing and commercial settlements ($142 million), partially offset by higher volumes ($341 million) and incremental sales related to a prior year business acquisition ($19 million). The higher volumes were attributable to growth in Asia and Europe, partially offset by softness in the Americas due to changes in automotive production levels and expiring programs in North America. |

[0000833444-16-000216:mdna:92]
| • | The decrease in Interiors was due to the deconsolidation of the majority of the Interiors business in the prior year ($2,954 million), lower volumes primarily due to plant wind downs ($87 million), the unfavorable impact of foreign currency translation ($9 million), and net unfavorable pricing and commercial settlements ($8 million). |

[0000833444-16-000216:mdna:93]
Segment EBIT:

[0000833444-16-000216:mdna:94]
| • | The decrease in Seating was due to current year separation costs related to the Automotive Experience spin-off ($458 million), net unfavorable pricing and commercial settlements ($33 million), unfavorable mix due to lower volumes at higher margin platforms ($26 million), the unfavorable impact of foreign currency translation ($16 million), a prior year gain on a business divestiture ($10 million) and a pension settlement loss ($5 million), partially offset by lower operating costs as a result of restructuring actions and operational efficiencies ($74 million), lower selling, general and administrative expenses as a result of a favorable legal settlement and cost reduction initiatives ($54 million), lower purchasing costs resulting from supplier price concessions ($46 million), higher equity income ($37 million), higher volumes ($35 million), lower engineering expenses ($32 million), prior year separation costs ($16 million) and incremental operating income related to a business acquisition ($2 million). |

[0000833444-16-000216:mdna:95]
| • | The decrease in Interiors was due to a prior year net gain on a business divestiture ($145 million), the impact of the July 2, 2015 joint venture transaction and related prior year held for sale depreciation impact ($109 million), lower volumes ($12 million), net unfavorable pricing and commercial settlements ($7 million), current year integration costs ($1 million) and the unfavorable impact of foreign currency translation ($1 million), partially offset by prior year transaction and integration costs ($38 million), favorable settlements related to prior year business divestitures ($22 million), lower selling, general and administrative expenses as a result of cost reduction initiatives ($21 million), lower operating costs ($10 million) and higher equity income ($5 million). |

[0000833444-16-000216:mdna:96]
Power Solutions

[0000833444-16-000216:mdna:97]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Net sales | $ | 6,653 |  |  | $ | 6,590 |  |  | 1 | % |
| Segment EBIT | 1,253 |  |  | 1,153 |  |  | 9 | % |

[0000833444-16-000216:mdna:98]
| • | Net sales increased due to higher sales volumes ($246 million), and favorable pricing and product mix ($105 million), partially offset by the unfavorable impact of foreign currency translation ($180 million) and the impact of lower lead costs on pricing ($108 million). The increase in volumes was primarily driven by start-stop battery volumes and growth in China. Additionally, higher start-stop volumes contributed to favorable product mix. |

[0000833444-16-000216:mdna:99]
| • | Segment EBIT increased due to higher volumes ($77 million), favorable pricing and product mix ($55 million), and lower selling, general and administrative expenses due to lower employee related expenses and cost reduction initiatives ($55 million), partially offset by higher operating costs primarily driven by efforts to increase supply to satisfy growing customer |

[0000833444-16-000216:mdna:100]
40

[0000833444-16-000216:mdna:101]
demand and launch new capacity in China ($48 million), the unfavorable impact of foreign currency translation ($29 million), restructuring and impairment costs included in equity income ($7 million), a pension settlement loss ($1 million), transaction costs ($1 million) and lower equity income ($1 million).

[0000833444-16-000216:mdna:102]
FISCAL YEAR 2015 COMPARED TO FISCAL YEAR 2014

[0000833444-16-000216:mdna:103]
Net Sales

[0000833444-16-000216:mdna:104]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2015 |  | 2014 |  | Change |
| Net sales | $ | 37,179 |  |  | $ | 38,749 |  |  | -4 | % |

[0000833444-16-000216:mdna:105]
The decrease in consolidated net sales was due to the unfavorable impact of foreign currency translation ($2.5 billion) and lower sales in the Automotive Experience business ($344 million), partially offset by higher sales in the Building Efficiency business ($839 million) and Power Solutions business ($408 million). Excluding the unfavorable impact of foreign currency translation, consolidated net sales increased 2% as compared to the prior year. The favorable impacts of higher Automotive Experience volumes globally, incremental sales related to the prior year acquisition of ADTi in the Building Efficiency business, higher Building Efficiency volumes in North America and the Middle East markets, and higher global battery shipments and favorable product mix in the Power Solutions business, were partially offset by the deconsolidation of the majority of the Automotive Experience Interiors business on July 2, 2015. The incremental sales related to business acquisitions were $751 million across the Building Efficiency and Automotive Experience segments. Refer to the segment analysis below within Item 7 for a discussion of net sales by segment.

[0000833444-16-000216:mdna:106]
Cost of Sales / Gross Profit

[0000833444-16-000216:mdna:107]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2015 |  | 2014 |  | Change |
| Cost of sales | $ | 30,732 |  |  | $ | 32,444 |  |  | -5 | % |
| Gross profit | 6,447 |  |  | 6,305 |  |  | 2 | % |
| % of sales | 17.3 | % |  | 16.3 | % |  |  |

[0000833444-16-000216:mdna:108]
The decrease in cost of sales year over year corresponds to the sales decrease described above. Foreign currency translation had a favorable impact on cost of sales of approximately $2.2 billion. Gross profit in the Building Efficiency business was favorably impacted by incremental gross profit related to the ADTi acquisition, favorable margin rates, prior year contract related charges in the Middle East and higher market demand in North America. Gross profit in the Power Solutions business was favorably impacted by higher volumes and lower operating costs. Gross profit in the Automotive Experience business was favorably impacted by higher volumes globally, lower purchasing costs and favorable commercial settlements, partially offset by higher operating costs and unfavorable mix. Net mark-to-market adjustments on pension and postretirement plans had a net unfavorable year over year impact on cost of sales of $113 million ($156 million charge in fiscal 2015 compared to a $43 million charge in fiscal 2014) primarily due to unfavorable U.S. investment returns versus expectations and the adoption of new mortality rate changes in the U.S. in the current year. Refer to the segment analysis below within Item 7 for a discussion of segment EBIT by segment.

[0000833444-16-000216:mdna:109]
Selling, General and Administrative Expenses

[0000833444-16-000216:mdna:110]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2015 |  | 2014 |  | Change |
| Selling, general and administrative expenses | $ | 3,986 |  |  | $ | 4,216 |  |  | -5 | % |
| % of sales | 10.7 | % |  | 10.9 | % |  |  |

[0000833444-16-000216:mdna:111]
Selling, general and administrative expenses (SG&A) decreased by $230 million year over year, and SG&A as a percentage of sales decreased 20 basis points. Net mark-to-market adjustments on pension and postretirement plans had a net unfavorable year over year impact on SG&A of $72 million ($266 million charge in fiscal 2015 compared to a $194 million charge in fiscal 2014) primarily due to unfavorable U.S. investment returns versus expectations and the adoption of new mortality rate changes in the U.S. in the current year. The Automotive Experience business SG&A decreased primarily due to gains on business divestitures, a prior year net loss on business divestitures, lower engineering expenses and lower employee related costs, partially offset by

[0000833444-16-000216:mdna:112]
transaction, integration and separation costs. The Building Efficiency business SG&A increased primarily due to incremental SG&A related to the prior year acquisition of ADTi, current year transaction and integration costs, and higher investments. The Power Solutions business SG&A increased primarily due to higher employee related expenses. Foreign currency translation had a favorable impact on SG&A of $189 million. Refer to the segment analysis below within Item 7 for a discussion of segment EBIT by segment.

[0000833444-16-000216:mdna:113]
Restructuring and Impairment Costs

[0000833444-16-000216:mdna:114]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2015 |  | 2014 |  | Change |
| Restructuring and impairment costs | $ | 397 |  |  | $ | 324 |  |  | 23 | % |

[0000833444-16-000216:mdna:115]
Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans.

[0000833444-16-000216:mdna:116]
Net Financing Charges

[0000833444-16-000216:mdna:117]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2015 |  | 2014 |  | Change |
| Net financing charges | $ | 288 |  |  | $ | 244 |  |  | 18 | % |

[0000833444-16-000216:mdna:118]
Net financing charges increased in fiscal 2015 as compared to fiscal 2014 primarily due to higher average borrowing levels related to the acquisition of ADTi and the share repurchase program.

[0000833444-16-000216:mdna:119]
Equity Income

[0000833444-16-000216:mdna:120]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2015 |  | 2014 |  | Change |
| Equity income | $ | 375 |  |  | $ | 395 |  |  | -5 | % |

[0000833444-16-000216:mdna:121]
The decrease in equity income was primarily due to prior year gains on acquisitions of partially-owned affiliates in the Power Solutions business ($19 million) and Building Efficiency business ($19 million), partially offset by higher current year income at certain Automotive Experience partially-owned affiliates. Refer to the segment analysis below within Item 7 for a discussion of segment EBIT by segment.

[0000833444-16-000216:mdna:122]
Income Tax Provision

[0000833444-16-000216:mdna:123]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2015 |  | 2014 |  | Change |
| Income tax provision | $ | 600 |  |  | $ | 407 |  |  | 47 | % |
| Effective tax rate | 28 | % |  | 21 | % |  |  |

[0000833444-16-000216:mdna:124]
The effective rate is below the U.S. statutory rate for fiscal 2015 primarily due to the benefits of continuing global tax planning initiatives, income in certain non-U.S. jurisdictions with a tax rate lower than the U.S. statutory tax rate and adjustments due to tax audit resolutions, partially offset by the tax consequences of business divestitures, and significant restructuring and impairment costs. The effective rate is below the U.S. statutory rate for fiscal 2014 primarily due to the benefits of continuing global tax planning initiatives and income in certain non-U.S. jurisdictions with a tax rate lower than the U.S. statutory tax rate partially offset by the tax consequences of business divestitures, significant restructuring and impairment costs, and valuation allowance adjustments. The fiscal 2015 effective tax rate increased as compared to the fiscal 2014 effective tax rate primarily due to the tax effects of business divestitures ($283 million), partially offset by reserve and valuation allowance adjustments ($133 million). The fiscal year 2015 and 2014 global tax planning initiatives related primarily to foreign tax credit planning, global financing structures and alignment of our global business functions in a tax efficient manner. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for further details.

[0000833444-16-000216:mdna:125]
42

[0000833444-16-000216:mdna:126]
Valuation Allowances

[0000833444-16-000216:mdna:127]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-16-000216:mdna:128]
In the fourth quarter of fiscal 2015, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily within Spain, Germany and the United Kingdom would not be realized and it is more likely than not that certain deferred tax assets of Poland and Germany will be realized. The impact of the net valuation allowance provision offset the benefit of valuation allowance releases and, as such, there was no net impact to income tax expense in the three month period ended September 30, 2015.

[0000833444-16-000216:mdna:129]
In the fourth quarter of fiscal 2014, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that deferred tax assets within Italy would not be realized. Therefore, the Company recorded $34 million of net valuation allowances as income tax expense in the three month period ended September 30, 2014.

[0000833444-16-000216:mdna:130]
In the first quarter of fiscal 2014, the Company determined that it was more likely than not that the deferred tax asset associated with a capital loss in Mexico would not be utilized. Therefore, the Company recorded a $21 million valuation allowance as income tax expense.

[0000833444-16-000216:mdna:131]
Uncertain Tax Positions

[0000833444-16-000216:mdna:132]
The Company is subject to income taxes in the U.S. and numerous foreign jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-16-000216:mdna:133]
During fiscal 2015, the Company settled a significant number of tax examinations in Germany, Mexico and the U.S., impacting fiscal years 1998 to fiscal 2012. The settlement of unrecognized tax benefits included cash payments for approximately $440 million and the loss of various tax attributes. The reduction for tax positions of prior years is substantially related to foreign exchange rates. In the fourth quarter of fiscal 2015, income tax audit resolutions resulted in a net $99 million benefit to income tax expense.

[0000833444-16-000216:mdna:134]
The Company’s federal income tax returns and certain non-U.S. income tax returns for various fiscal years remain under various stages of audit by the IRS and respective non-U.S. tax authorities. Although the outcome of tax audits is always uncertain, management believes that it has appropriate support for the positions taken on its tax returns and that its annual tax provisions included amounts sufficient to pay assessments, if any, which may be proposed by the taxing authorities. At September 30, 2015, the Company had recorded a liability for its best estimate of the probable loss on certain of its tax positions, the majority of which is included in other noncurrent liabilities in the consolidated statements of financial position. Nonetheless, the amounts ultimately paid, if any, upon resolution of the issues raised by the taxing authorities may differ materially from the amounts accrued for each year.

[0000833444-16-000216:mdna:135]
Other Tax Matters

[0000833444-16-000216:mdna:136]
During fiscal 2015 and 2014, the Company incurred significant charges for restructuring and impairment costs. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. A substantial portion of these charges cannot be benefited for tax purposes due to our current tax position in these jurisdictions and the underlying tax basis in the impaired assets, resulting in $52 million and $75 million incremental tax expense in fiscal 2015 and 2014, respectively.

[0000833444-16-000216:mdna:137]
In the fourth quarter of fiscal 2015, the Company completed its global automotive interiors joint venture with Yanfeng Automotive Trim Systems. Refer to Note 3, "Acquisitions and Divestitures," of the notes to consolidated financial statements for additional information. In connection with the divestiture of the Interiors business, the Company recorded a pre-tax gain on divestiture of $145 million, $38 million net of tax. The tax impact of the gain is due to the jurisdictional mix of gains and losses on the divestiture, which resulted in non-benefited expenses in certain countries and taxable gains in other countries. In addition, in the third and

[0000833444-16-000216:mdna:138]
fourth quarters of fiscal 2015, the Company provided income tax expense for repatriation of foreign cash and other tax reserves associated with the Automotive Experience Interiors joint venture transaction, which resulted in a tax charge of $75 million and $223 million, respectively.

[0000833444-16-000216:mdna:139]
During the fourth quarter of fiscal 2014, the Company recorded a discrete tax benefit of $51 million due to change in entity status.

[0000833444-16-000216:mdna:140]
In the third quarter of fiscal 2014, the Company disposed of its Automotive Experience Interiors headliner and sun visor product lines. Refer to Note 3, "Acquisitions and Divestitures," of the notes to consolidated financial statements for additional information. As a result, the Company recorded a pre-tax loss on divestiture of $95 million and income tax expense of $38 million. The income tax expense is due to the jurisdictional mix of gains and losses on the sale, which resulted in non-benefited losses in certain countries and taxable gains in other countries.

[0000833444-16-000216:mdna:141]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-16-000216:mdna:142]
The "look-through rule," under subpart F of the U.S. Internal Revenue Code, expired for the Company on September 30, 2015. The "look-through rule" had provided an exception to the U.S. taxation of certain income generated by foreign subsidiaries. The “look-through rule” previously expired for the Company on September 30, 2014 but was extended retroactively to the beginning of the Company’s 2015 fiscal year.

[0000833444-16-000216:mdna:143]
In the second quarter of fiscal 2015, tax legislation was adopted in Japan which reduced its statutory income tax rate. As a result of the law change, the Company recorded income tax expense of $17 million in the second quarter of fiscal 2015. Tax legislation was also adopted in various other jurisdictions during the fiscal year ended September 30, 2015. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-16-000216:mdna:144]
As a result of changes to Mexican tax law in the first quarter of fiscal 2014, the Company recorded a benefit to income tax expense of $25 million. Tax legislation was also adopted in various other jurisdictions during the fiscal year ended September 30, 2014. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-16-000216:mdna:145]
Income (Loss) From Discontinued Operations, Net of Tax

[0000833444-16-000216:mdna:146]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2015 |  | 2014 |  | Change |
| Income (loss) from discontinued operations, net of tax | $ | 128 |  |  | $ | (166 | ) |  | * |

[0000833444-16-000216:mdna:147]
* Measure not meaningful

[0000833444-16-000216:mdna:148]
Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-16-000216:mdna:149]
Income Attributable to Noncontrolling Interests

[0000833444-16-000216:mdna:150]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2015 |  | 2014 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 112 |  |  | $ | 105 |  |  | 7 | % |
| Income from discontinued operations attributable to noncontrolling interests | 4 |  |  | 23 |  |  | -83 | % |

[0000833444-16-000216:mdna:151]
The increase in income from continuing operations attributable to noncontrolling interests for fiscal 2015 was primarily due to higher income at a Power Solutions partially-owned affiliate.

[0000833444-16-000216:mdna:152]
Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-16-000216:mdna:153]
Net Income Attributable to Johnson Controls

[0000833444-16-000216:mdna:154]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2015 |  | 2014 |  | Change |
| Net income attributable to Johnson Controls | $ | 1,563 |  |  | $ | 1,215 |  |  | 29 | % |

[0000833444-16-000216:mdna:155]
The increase in net income attributable to Johnson Controls was primarily due to higher income from continuing and discontinued operations, partially offset by an increase in the income tax provision. Fiscal 2015 diluted earnings per share attributable to Johnson Controls was $2.36 compared to $1.80 in fiscal 2014.

[0000833444-16-000216:mdna:156]
Comprehensive Income Attributable to Johnson Controls

[0000833444-16-000216:mdna:157]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2015 |  | 2014 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 743 |  |  | $ | 560 |  |  | 33 | % |

[0000833444-16-000216:mdna:158]
The increase in comprehensive income attributable to Johnson Controls was due to higher net income attributable to Johnson Controls ($348 million), partially offset by an increase in other comprehensive loss attributable to Johnson Controls ($165 million) primarily related to unfavorable foreign currency translation adjustments. These year-over-year unfavorable foreign currency translation adjustments were primarily driven by the weakening of the Brazilian real, British pound, Canadian dollar, Colombian peso and euro currencies against the U.S. dollar.

[0000833444-16-000216:mdna:159]
Segment Analysis

[0000833444-16-000216:mdna:160]
Management evaluates the performance of its business units based primarily on segment EBIT, which is defined as income from continuing operations before income taxes and noncontrolling interests excluding net financing charges, significant restructuring and impairment costs, and net mark-to-market adjustments on pension and postretirement plans.

[0000833444-16-000216:mdna:161]
Building Efficiency

[0000833444-16-000216:mdna:162]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |  | Segment EBITfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
| Systems and Service North America | $ | 4,184 |  |  | $ | 4,098 |  |  | 2 | % |  | $ | 375 |  |  | $ | 354 |  |  | 6 | % |
| Products North America | 2,450 |  |  | 1,807 |  |  | 36 | % |  | 306 |  |  | 238 |  |  | 29 | % |
| Asia | 1,985 |  |  | 2,077 |  |  | -4 | % |  | 191 |  |  | 270 |  |  | -29 | % |
| Rest of World | 1,891 |  |  | 2,103 |  |  | -10 | % |  | 51 |  |  | (45 | ) |  | * |  |
|  | $ | 10,510 |  |  | $ | 10,085 |  |  | 4 | % |  | $ | 923 |  |  | $ | 817 |  |  | 13 | % |

[0000833444-16-000216:mdna:163]
* Measure not meaningful

[0000833444-16-000216:mdna:164]
Net Sales:

[0000833444-16-000216:mdna:165]
| • | The increase in Systems and Service North America was due to higher volumes of controls systems and service ($129 million), partially offset by the unfavorable impact of foreign currency translation ($43 million). |

[0000833444-16-000216:mdna:166]
| • | The increase in Products North America was due to incremental sales related to the ADTi acquisition ($587 million), and higher volumes of residential and commercial products ($65 million), partially offset by the unfavorable impact of foreign currency translation ($9 million). |

[0000833444-16-000216:mdna:167]
| • | The decrease in Asia was due to the unfavorable impact of foreign currency translation ($107 million), and lower volumes of equipment and controls systems ($80 million), partially offset by incremental sales due to business acquisitions ($58 million) and higher service volumes ($37 million). |

[0000833444-16-000216:mdna:168]
| • | The decrease in Rest of World was due to the unfavorable impact of foreign currency translation ($255 million) and lower volumes in Latin America ($72 million), partially offset by higher volumes in the Middle East ($71 million) and Europe ($22 million), and incremental sales related to the ADTi acquisition ($22 million). |

[0000833444-16-000216:mdna:169]
Segment EBIT:

[0000833444-16-000216:mdna:170]
| • | The increase in Systems and Service North America was due to higher volumes ($30 million), net unfavorable prior year contract related charges ($9 million) and a prior year pension settlement loss ($3 million), partially offset by higher selling, general and administrative expenses net of a current year gain on business divestiture ($13 million), current year transaction and integration costs ($4 million), and the unfavorable impact of foreign currency translation ($4 million). |

[0000833444-16-000216:mdna:171]
| • | The increase in Products North America was due to incremental operating income related to the ADTi acquisition ($53 million), prior year acquisition related costs ($27 million), higher volumes ($22 million), higher equity income ($2 million), a prior year pension settlement loss ($1 million) and the favorable impact of foreign currency translation ($1 million), partially offset by higher selling, general and administrative expenses net of current year gains on business divestitures ($28 million), current year transaction and integration costs ($8 million), and unfavorable mix and margin rates ($2 million). |

[0000833444-16-000216:mdna:172]
| • | The decrease in Asia was due to higher selling, general and administrative expenses ($26 million), current year transaction and integration costs ($24 million), a prior year gain on acquisition of partially-owned affiliates ($19 million), lower volumes ($17 million) and the unfavorable impact of foreign currency translation ($17 million), partially offset by favorable mix and margin rates ($17 million), and incremental operating income due to business acquisitions ($7 million). |

[0000833444-16-000216:mdna:173]
| • | The increase in Rest of World was due to net unfavorable prior year contract related charges in the Middle East ($50 million), favorable mix and margin rates ($49 million), higher equity income ($7 million), higher volumes ($4 million), lower selling, general and administrative expenses ($1 million), and incremental operating income due to business acquisitions ($1 million), partially offset by the unfavorable impact of foreign currency translation ($15 million) and current year transaction costs ($1 million). |

[0000833444-16-000216:mdna:174]
Automotive Experience

[0000833444-16-000216:mdna:175]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |  | Segment EBITfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2015 |  | 2014 |  | Change |  | 2015 |  | 2014 |  | Change |
| Seating | $ | 16,539 |  |  | $ | 17,531 |  |  | -6 | % |  | $ | 928 |  |  | $ | 853 |  |  | 9 | % |
| Interiors | 3,540 |  |  | 4,501 |  |  | -21 | % |  | 254 |  |  | (1 | ) |  | * |  |
|  | $ | 20,079 |  |  | $ | 22,032 |  |  | -9 | % |  | $ | 1,182 |  |  | $ | 852 |  |  | 39 | % |

[0000833444-16-000216:mdna:176]
* Measure not meaningful

[0000833444-16-000216:mdna:177]
Net Sales:

[0000833444-16-000216:mdna:178]
| • | The decrease in Seating was due to the unfavorable impact of foreign currency translation ($1.4 billion), partially offset by higher volumes ($280 million), incremental sales related to a business acquisition ($57 million), and net favorable pricing and commercial settlements ($51 million). |

[0000833444-16-000216:mdna:179]
| • | The decrease in Interiors was due to the deconsolidation of the majority of the Interiors business on July 2, 2015 ($924 million), lower volumes related to a prior year business divestiture ($248 million), the unfavorable impact of foreign currency translation ($229 million) and unfavorable sales mix ($138 million), partially offset by higher volumes ($506 million), net favorable pricing and commercial settlements ($45 million), and incremental sales related to business acquisitions ($27 million). |

[0000833444-16-000216:mdna:180]
46

[0000833444-16-000216:mdna:181]
Segment EBIT:

[0000833444-16-000216:mdna:182]
| • | The increase in Seating was due to net favorable pricing and commercial settlements ($65 million), lower purchasing costs ($64 million), higher volumes ($56 million), lower selling, general and administrative expenses ($30 million), lower engineering expenses ($29 million), higher equity income ($20 million), a gain on a business divestiture ($10 million), incremental operating income related to a business acquisition ($7 million) and a prior year pension settlement loss ($5 million), partially offset by higher operating costs ($117 million), the unfavorable impact of foreign currency translation ($47 million), unfavorable mix ($31 million) and current year separation costs ($16 million). |

[0000833444-16-000216:mdna:183]
| • | The increase in Interiors was due to a net gain on a business divestiture ($145 million), a prior year net loss on business divestitures ($86 million), higher volumes ($67 million), lower operating costs ($23 million), lower selling, general and administrative expenses ($16 million), lower purchasing costs ($6 million), lower engineering expenses ($5 million), higher equity income ($3 million), incremental operating income related to business acquisitions ($3 million) and a prior year pension settlement loss ($1 million), partially offset by current year transaction and integration costs ($38 million), unfavorable mix ($27 million), lower operating income related to a current year business divestiture ($19 million), net unfavorable pricing and commercial settlements ($12 million), and the unfavorable impact of foreign currency translation ($4 million). |

[0000833444-16-000216:mdna:184]
Power Solutions

[0000833444-16-000216:mdna:185]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2015 |  | 2014 |  | Change |
| Net sales | $ | 6,590 |  |  | $ | 6,632 |  |  | -1 | % |
| Segment EBIT | 1,153 |  |  | 1,052 |  |  | 10 | % |

[0000833444-16-000216:mdna:186]
| • | Net sales decreased due to the unfavorable impact of foreign currency translation ($450 million), partially offset by higher sales volumes ($291 million), and favorable pricing and product mix ($117 million). |

[0000833444-16-000216:mdna:187]
| • | Segment EBIT increased due to higher volumes ($90 million), lower operating costs ($79 million), favorable pricing and product mix ($16 million), a prior year pension settlement loss ($5 million) and higher equity income ($2 million), partially offset by the unfavorable impact of foreign currency translation ($52 million), higher selling, general and administrative expenses ($20 million), and a prior year gain on acquisition of a partially-owned affiliate ($19 million). |

[0000833444-16-000216:mdna:188]
GOODWILL, LONG-LIVED ASSETS AND OTHER INVESTMENTS

[0000833444-16-000216:mdna:189]
Goodwill at September 30, 2016 was $23.4 billion, $16.6 billion higher than the prior year. The increase was primarily due to goodwill generated as a result of the Tyco merger and JCH joint venture in the Buildings business.

[0000833444-16-000216:mdna:190]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses multiples of earnings based on the average of historical, published multiples of earnings of comparable entities with similar operations and economic characteristics. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value.

[0000833444-16-000216:mdna:191]
During fiscal 2014, as a result of operating results, restructuring actions and expected future profitability, the Company's forecasted cash flow estimates used in the goodwill assessment were negatively impacted as of September 30, 2014 for the Building Efficiency  Rest of World - Latin America reporting unit. As a result, the Company concluded that the carrying value of the Building Efficiency Rest of World - Latin America reporting unit exceeded its fair value as of September 30, 2014. The Company recorded a goodwill impairment charge of $47 million in the fourth quarter of fiscal 2014, which was determined by comparing the carrying value of

[0000833444-16-000216:mdna:192]
47

[0000833444-16-000216:mdna:193]
the reporting unit's goodwill with the implied fair value of goodwill for the reporting unit. The Building Efficiency Rest of World - Latin America reporting unit has no remaining goodwill at September 30, 2016 and 2015.

[0000833444-16-000216:mdna:194]
The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations. Other than management's projections of future cash flows, the primary assumptions used in the impairment tests were the weighted-average cost of capital and long-term growth rates. Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying businesses, there are significant judgments in determining the expected future cash flows attributable to a reporting unit. The impairment charges are non-cash expenses recorded within restructuring and impairment costs on the consolidated statements of income and did not adversely affect the Company's debt position, cash flow, liquidity or compliance with financial covenants.

[0000833444-16-000216:mdna:195]
Indefinite lived other intangible assets are also subject to at least annual impairment testing. A considerable amount of management judgment and assumptions are required in performing the impairment tests. While the Company believes the judgments and assumptions used in the impairment tests are reasonable and no impairment existed during fiscal years 2016, 2015 and 2014, different assumptions could change the estimated fair values and, therefore, impairment charges could be required, which could be material to the consolidated financial statements.

[0000833444-16-000216:mdna:196]
The Company reviews long-lived assets, including property, plant and equipment and other intangible assets with definite lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals.

[0000833444-16-000216:mdna:197]
In the second, third and fourth quarters of fiscal 2016, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2016. As a result, the Company reviewed the long-lived assets for impairment and recorded $190 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income, of which $29 million was recorded in the second quarter, $51 million was recorded in the third quarter and $110 million was recorded in the fourth quarter. Of the total impairment charges, $64 million related to the Power Solutions segment, $55 million related to Corporate assets, $55 million related to the Automotive Experience Seating segment, $8 million related to the Building Efficiency Products North America segment, $4 million related to the Building Efficiency Asia segment, $3 million related to the Building Efficiency Rest of World segment and $1 million related to the Automotive Experience Interiors segment. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-16-000216:mdna:198]
In the fourth quarter of fiscal 2015, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its announced restructuring actions and the intention to spin-off the Automotive Experience business. As a result, the Company reviewed the long-lived assets for impairment and recorded a $183 million impairment charge within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charge, $139 million related to Corporate assets, $27 million related to the Automotive Experience Seating segment, $16 million related to the Building Efficiency Rest of World segment and $1 million related to the Building Efficiency Systems and Service North America  segment. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairment was measured, depending on the asset, either under an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impairment assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-16-000216:mdna:199]
In the third and fourth quarters of fiscal 2014, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2014. In addition, in the fourth quarter of fiscal 2014, the Company concluded that it had a triggering event requiring assessment of impairment of long-lived assets held by the Building Efficiency Rest of World - Latin America reporting unit due to the impairment of goodwill in the

[0000833444-16-000216:mdna:200]
quarter. As a result, the Company reviewed the long-lived assets for impairment and recorded a $91 million impairment charge within restructuring and impairment costs on the consolidated statements of income, of which $45 million was recorded in the third quarter and $46 million in the fourth quarter of fiscal 2014. Of the total impairment charge, $45 million related to the Automotive Experience Interiors segment, $34 million related to the Building Efficiency Rest of World segment, $7 million related to the Automotive Experience Seating segment and $5 million related to Corporate assets. In addition, the Company recorded $43 million of asset and investment impairments within discontinued operations in the third quarter of fiscal 2014 related to the divestiture of the Automotive Experience Electronics business. Refer to Note 4, "Discontinued Operations," and Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairment was measured, depending on the asset, either under an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impairment assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-16-000216:mdna:201]
Investments in partially-owned affiliates ("affiliates") at September 30, 2016 were $2.7 billion, $0.6 billion higher than the prior year. The increase was primarily due to the investment in the JCH joint venture and positive earnings at certain Automotive Experience affiliates.

[0000833444-16-000216:mdna:202]
49

[0000833444-16-000216:mdna:203]
LIQUIDITY AND CAPITAL RESOURCES

[0000833444-16-000216:mdna:204]
Working Capital

[0000833444-16-000216:mdna:205]
|  | September 30, 2016 |  | September 30, 2015 |  |  |
| (in millions) |  |  | Change |
| Current assets | $ | 17,109 |  |  | $ | 10,469 |  |  |  |
| Current liabilities | (16,293 | ) |  | (10,446 | ) |  |  |
|  | 816 |  |  | 23 |  |  | * |  |
| Less: Cash | (684 | ) |  | (597 | ) |  |  |
| Less: Cash in escrow related to Adient debt | (2,034 | ) |  | — |  |  |  |
| Add: Short-term debt | 1,119 |  |  | 52 |  |  |  |
| Add: Current portion of long-term debt | 628 |  |  | 813 |  |  |  |
| Less: Assets held for sale | (174 | ) |  | (55 | ) |  |  |
| Add: Liabilities held for sale | 28 |  |  | 42 |  |  |  |
| Working capital (as defined) | $ | (301 | ) |  | $ | 278 |  |  | * |  |
| Accounts receivable | $ | 8,018 |  |  | $ | 5,751 |  |  | 39 | % |
| Inventories | 3,560 |  |  | 2,377 |  |  | 50 | % |
| Accounts payable | 6,764 |  |  | 5,174 |  |  | 31 | % |

[0000833444-16-000216:mdna:206]
* Measure not meaningful

[0000833444-16-000216:mdna:207]
| • | The Company defines working capital as current assets less current liabilities, excluding cash, cash in escrow related to Adient debt, short-term debt, the current portion of long-term debt, and the current portion of assets and liabilities held for sale. Management believes that this measure of working capital, which excludes financing-related items, provides a more useful measurement of the Company’s operating performance. |

[0000833444-16-000216:mdna:208]
| • | The decrease in working capital at September 30, 2016 as compared to September 30, 2015, was primarily related to an increase in accounts payable due to timing of supplier payments, timing of income tax payments and an increase in restructuring reserves, partially offset by the impact of the Tyco merger, the impact of the JCH joint venture and an increase in accounts receivable due to timing of customer receipts. |

[0000833444-16-000216:mdna:209]
| • | The Company’s days sales in accounts receivable at September 30, 2016 were 58, a slight increase from 56 at September 30, 2015. There has been no significant adverse change in the level of overdue receivables or changes in revenue recognition methods. |

[0000833444-16-000216:mdna:210]
| • | The Company’s inventory turns for the year ended September 30, 2016 were slightly lower than the comparable period ended September 30, 2015 primarily due to changes in inventory production levels. |

[0000833444-16-000216:mdna:211]
| • | Days in accounts payable at September 30, 2016 were 73 days, lower than 74 days at the comparable period ended September 30, 2015. |

[0000833444-16-000216:mdna:212]
50

[0000833444-16-000216:mdna:213]
Cash Flows

[0000833444-16-000216:mdna:214]
|  | Year Ended September 30, |
| (in millions) | 2016 |  | 2015 |
| Cash provided by operating activities | $ | 1,895 |  |  | $ | 1,600 |  |
| Cash provided (used) by investing activities | (887 | ) |  | 470 |  |
| Cash used by financing activities | (933 | ) |  | (1,821 | ) |
| Capital expenditures | (1,249 | ) |  | (1,135 | ) |

[0000833444-16-000216:mdna:215]
| • | The increase in cash provided by operating activities was primarily due to favorable changes in other assets and lower pension contributions, partially offset by higher income tax payments and current year separation costs. |

[0000833444-16-000216:mdna:216]
| • | The increase in cash used by investing activities was primarily due to cash received from business divestitures in the prior year, cash paid for the JCH joint venture in the current year and an increase in capital expenditures, partially offset by cash acquired in the Tyco merger in the current year. |

[0000833444-16-000216:mdna:217]
| • | The decrease in cash used by financing activities was primarily due to an increase in long-term debt, lower stock repurchases in the current year and an increase in short-term debt, partially offset by higher repayments of long-term debt, an increase in dividends paid due to timing and an increase in dividends paid to noncontrolling interests related to the JCH joint venture. |

[0000833444-16-000216:mdna:218]
| • | The increase in capital expenditures in the current year is primarily related to higher capital investments in the Buildings and Power Solutions businesses, partially offset by lower capital investments in the Automotive Experience business. |

[0000833444-16-000216:mdna:219]
Capitalization

[0000833444-16-000216:mdna:220]
|  | September 30, 2016 |  | September 30, 2015 |  |  |
| (in millions) |  |  | Change |
| Short-term debt | $ | 1,119 |  |  | $ | 52 |  |  |  |
| Current portion of long-term debt | 628 |  |  | 813 |  |  |  |
| Long-term debt | 14,606 |  |  | 5,745 |  |  |  |
| Total debt | $ | 16,353 |  |  | $ | 6,610 |  |  | * |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 24,118 |  |  | 10,335 |  |  | * |
| Total capitalization | $ | 40,471 |  |  | $ | 16,945 |  |  | * |
| Total debt as a % of total capitalization | 40 | % |  | 39 | % |  |  |

[0000833444-16-000216:mdna:221]
* Measure not meaningful

[0000833444-16-000216:mdna:222]
| • | The Company believes the percentage of total debt to total capitalization is useful to understanding the Company’s financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. |

[0000833444-16-000216:mdna:223]
| • | In connection with the Tyco merger on September 2, 2016, JCI Inc., a wholly owned subsidiary of the Company, replaced its $2.5 billion committed five-year credit facility scheduled to mature in August 2018 with a $2.0 billion committed four-year credit facility scheduled to mature in August 2020. Also, in connection with the Tyco merger on September 2, 2016, Tyco International Holding S.à.r.l ("TSarl"), a wholly owned subsidiary of the Company, entered into a four-year, $1.0 billion revolving credit agreement scheduled to mature in August 2020. |

[0000833444-16-000216:mdna:224]
| • | At September 30, 2016, the Company had committed bilateral U.S. dollar denominated revolving credit facilities totaling $135 million, which are scheduled to expire in fiscal 2017. There were no draws on any of these revolving facilities as of September 30, 2016. |

[0000833444-16-000216:mdna:225]
| • | Simultaneously with the closing of the Tyco Merger on September 2, 2016, TSarl borrowed $4.0 billion under the Term Loan Credit Agreement dated as of March 10, 2016 with a syndicate of lenders, providing for a three and a half year senior unsecured term loan facility to finance the cash consideration for, and fees, expenses and costs incurred in connection with the Merger. |

[0000833444-16-000216:mdna:226]
51

[0000833444-16-000216:mdna:227]
| • | In August 2016, Adient Global Holdings, Ltd. (AGH), a wholly-owned subsidiary of the Company, issued a one billion euro, 3.5% fixed rate, 8-year senior unsecured note scheduled to mature in August 2024. AGH also issued a $900 million, 4.875%, 10-year senior unsecured note scheduled to mature in August 2026. The proceeds from the notes were deposited into escrow and are expected to be released in connection with the spin-off. The notes have not been, and are not expected to be, guaranteed by the Company or any of its subsidiaries that will not be subsidiaries of Adient following the spin-off. Approximately $1,500 million of the proceeds will be distributed to the Company in connection with the spin-off and approximately $500 million of the proceeds will be used for Adient's general corporate purposes. |

[0000833444-16-000216:mdna:228]
| • | In July 2016, AGH entered into a 5-year, $1,500 million Term A loan facility and a 5-year, $1,500 million revolving credit facility scheduled to mature in July 2021. The term loan was fully drawn in August 2016. As of September 30, 2016, there were no draws on the facility. Upon completion of the spin-off of Adient, AGH will become a wholly-owned subsidiary of Adient. On the date of the spin-off, Adient and certain of its wholly-owned subsidiaries will guarantee the debt, and the guarantees of the Company will automatically be released. The Company used the proceeds of the term loan to early repay its four tranches of euro-denominated floating rate credit facilities, totaling 390 million euro, that were outstanding as of September 30, 2015; three term loans of $500 million, $200 million and $125 million that were entered into during fiscal 2016, plus accrued interest, and a $90 million outstanding credit facility. The remainder of the proceeds were used for general corporate purposes. |

[0000833444-16-000216:mdna:229]
| • | In February 2016, the Company entered into a nine-month, $100 million floating rate term loan scheduled to mature in November 2016. Proceeds from the term loan were used for general corporate purposes. |

[0000833444-16-000216:mdna:230]
| • | In February 2016, the Company terminated a 37 million euro committed revolving credit facility scheduled to mature in September 2016, and subsequently entered into a nine-month, 100 million euro, floating rate term loan scheduled to mature in October 2016. Proceeds from the term loan were used for general corporate purposes. |

[0000833444-16-000216:mdna:231]
| • | In January 2016, the Company entered into a ten-month, $200 million, floating rate term loan scheduled to mature in October 2016. Proceeds from the term loan were used for general corporate purposes. |

[0000833444-16-000216:mdna:232]
| • | In January 2016, the Company entered into a ten-month, $125 million, floating rate term loan scheduled to mature in October 2016. Proceeds from the term loan were used for general corporate purposes. |

[0000833444-16-000216:mdna:233]
| • | In January 2016, the Company retired $800 million in principal amount, plus accrued interest, of its 5.5% fixed rate notes that matured in January 2016. |

[0000833444-16-000216:mdna:234]
| • | In September 2015, the Company retired, at maturity, $500 million, $150 million and $100 million floating rate term loans plus accrued interest that were entered into during fiscal 2015. |

[0000833444-16-000216:mdna:235]
| • | In June 2015, the Company entered into a five-year, 37 billion yen floating rate syndicated term loan scheduled to mature in June 2020. Proceeds from the syndicated term loan were used for general corporate purposes. |

[0000833444-16-000216:mdna:236]
| • | In May 2015, the Company made a partial repayment of 32 million euro in principal amount, plus accrued interest, of its 70 million euro floating rate credit facility scheduled to mature in November 2017. The remaining outstanding portion as of September 30, 2015 was repaid during fiscal 2016. |

[0000833444-16-000216:mdna:237]
| • | In March 2015, the Company retired $125 million in principal amount, plus accrued interest, of its 7.7% fixed rate notes that matured in March 2015. |

[0000833444-16-000216:mdna:238]
| • | In January 2015, the Company entered into a one-year, $90 million, committed revolving credit facility scheduled to mature in January 2016. The Company drew on the full credit facility during the quarter ended March 31, 2015. Proceeds from the revolving credit facility were used for general corporate purposes. The $90 million was repaid in September 2015. |

[0000833444-16-000216:mdna:239]
| • | The Company also selectively makes use of short-term credit lines. The Company estimates that, as of September 30, 2016, it could borrow up to $1.7 billion based on average borrowing levels during the quarter on committed credit lines. |

[0000833444-16-000216:mdna:240]
| • | The Company believes its capital resources and liquidity position at September 30, 2016 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in fiscal 2017 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event Johnson Controls, |

[0000833444-16-000216:mdna:241]
52

[0000833444-16-000216:mdna:242]
Inc., and TSarl are unable to issue commercial paper, they would have the ability to draw on their $2.0 billion and $1.0 billion revolving credit facilities, respectively.  Both facilities mature in August 2020. There were no draws on the revolving credit facilities as of September 30, 2016. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-16-000216:mdna:243]
| • | The Company earns a significant amount of its operating income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. However, in fiscal 2016, the Company did provide income tax expense related to a change in the Company's assertion over a portion of the permanently reinvested earnings as a result of the planned spin-off of the Automotive Experience business. Except as noted, the Company’s intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital in the U.S. than is generated by operations in the U.S., the Company could elect to raise capital in the U.S. through debt or equity issuances. In addition, should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. This alternative could result in increased interest expense or other dilution of the Company’s earnings. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. |

[0000833444-16-000216:mdna:244]
| • | The Company's debt financial covenants require it to maintain a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times and allow a maximum aggregated amount of 10% of its consolidated shareholders’ equity for liens and pledges. For purposes of calculating the covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of ASC 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. TSarl's, a wholly-owned subsidiary of Johnson Controls, revolving credit facility contains customary terms and conditions, and financial covenants that limit the ratio of TSarl's debt to earnings before interest, taxes, depreciation, and amortization and excluding special items to 3.5x and that limit its ability to incur subsidiary debt or grant liens on its property. As of September 30, 2016, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and indentures and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company’s credit rating. |

[0000833444-16-000216:mdna:245]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2016 and recorded $620 million of restructuring and impairment costs in the consolidated statements of income within continuing operations. The restructuring action related to cost reduction initiatives in the Company’s Automotive Experience, Buildings and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments, change-in-control payments and immaterial changes in estimates to prior year plans. The Company currently estimates that upon completion of the restructuring action, the fiscal 2016 restructuring plan will reduce annual operating costs from continuing operations by approximately $300 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized by the end of fiscal 2018. For fiscal 2016, there were no significant savings, net of execution costs, realized for this plan. The restructuring action is expected to be substantially complete in fiscal 2018. The restructuring plan reserve balance of $445 million at September 30, 2016 is expected to be paid in cash. Included in the reserve is $78 million of committed restructuring actions taken by Tyco for liabilities assumed as part of the Tyco acquisition. |

[0000833444-16-000216:mdna:246]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2015 and recorded $397 million of restructuring and impairment costs in the consolidated statements of income within continuing operations. The restructuring action related to cost reduction initiatives in the Company’s Automotive Experience, Building Efficiency and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2015 restructuring plan will reduce annual operating costs from continuing operations by approximately $250 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs and depreciation expense. The Company expects that a portion of these savings, net of execution costs, will |

[0000833444-16-000216:mdna:247]
53

[0000833444-16-000216:mdna:248]
be achieved in fiscal 2016 and the full annual benefit of these actions is expected in fiscal 2017. For fiscal 2016, the savings from continuing operations, net of execution costs, were approximately 55% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in 2016. The restructuring plan reserve balance of $117 million at September 30, 2016 is expected to be paid in cash.

[0000833444-16-000216:mdna:249]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to significant restructuring plans in fiscal 2014 and 2013 and recorded $324 million and $903 million, respectively, of restructuring and impairment costs in the consolidated statements of income within continuing operations. The restructuring actions related to cost reduction initiatives in the Company’s Automotive Experience, Building Efficiency and Power Solutions businesses and included workforce reductions, plant closures, and asset and goodwill impairments. The Company currently estimates that upon completion of the restructuring actions, the fiscal 2014 and 2013 restructuring plans will reduce annual operating costs from continuing operations by approximately $175 million and $350 million, respectively, which is primarily the result of lower cost of sales due to reduced employee-related costs and lower depreciation and amortization expense. The full annual benefit of these actions, net of execution costs, were achieved in fiscal 2016. The restructuring actions were substantially complete in 2016. The respective year’s restructuring plan reserve balances of $23 million and $24 million, respectively, at September 30, 2016 are expected to be paid in cash. |

[0000833444-16-000216:mdna:250]
A summary of the Company’s significant contractual obligations as of September 30, 2016 is as follows (in millions):

[0000833444-16-000216:mdna:251]
|  | Total |  | 2017 |  | 2018-2019 |  | 2020-2021 |  | 2022and Beyond |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Long-term debt(including capital lease obligations)* | $ | 15,234 |  |  | $ | 628 |  |  | $ | 379 |  |  | $ | 6,905 |  |  | $ | 7,322 |  |
| Interest on long-term debt(including capital lease obligations)* | 6,447 |  |  | 414 |  |  | 795 |  |  | 723 |  |  | 4,515 |  |
| Operating leases | 1,352 |  |  | 406 |  |  | 537 |  |  | 254 |  |  | 155 |  |
| Purchase obligations | 2,624 |  |  | 2,218 |  |  | 308 |  |  | 92 |  |  | 6 |  |
| Pension and postretirement contributions | 745 |  |  | 330 |  |  | 78 |  |  | 84 |  |  | 253 |  |
| Tax indemnification liabilities** | 290 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total contractual cash obligations | $ | 26,692 |  |  | $ | 3,996 |  |  | $ | 2,097 |  |  | $ | 8,058 |  |  | $ | 12,251 |  |

[0000833444-16-000216:mdna:252]
* See "Capitalization" for additional information related to the Company's long-term debt. The Company's outstanding interest rate swaps in an asset position are not included in the table at September 30, 2016, which indicates the Company was in a net position of receiving cash under such swaps.

[0000833444-16-000216:mdna:253]
** As a result of the Tyco merger in the fourth quarter of fiscal 2016, the Company recorded as part of the acquired liabilities of Tyco $290 million of post sale contingent tax indemnification liabilities within other noncurrent liabilities in the consolidated statements of financial position. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. Of the $290 million recorded as of September 30, 2016, $255 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions.  The payments due by period are not presented due to uncertainty as to when these liabilities will be settled or paid.

[0000833444-16-000216:mdna:254]
CRITICAL ACCOUNTING ESTIMATES AND POLICIES

[0000833444-16-000216:mdna:255]
The Company prepares its consolidated financial statements in conformity with accounting principles generally accepted in the United States of America (U.S. GAAP). This requires management to make estimates and assumptions that affect reported amounts and related disclosures. Actual results could differ from those estimates. The following policies are considered by management to be the most critical in understanding the judgments that are involved in the preparation of the Company’s consolidated financial statements and the uncertainties that could impact the Company’s results of operations, financial position and cash flows.

[0000833444-16-000216:mdna:256]
Revenue Recognition

[0000833444-16-000216:mdna:257]
The Buildings business recognizes revenue from certain long-term contracts over the contractual period under the POC method of accounting. This method of accounting recognizes sales and gross profit as work is performed based on the relationship between actual costs incurred and total estimated costs at completion. Recognized revenues that will not be billed under the terms of the contract until a later date are recorded primarily in accounts receivable. Likewise, contracts where billings to date have exceeded recognized revenues are recorded primarily in other current liabilities. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. Sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. Claims against customers are recognized as revenue upon settlement. The use of the POC method of accounting involves considerable use of estimates in determining revenues, costs and profits and in assigning the amounts to accounting periods. The periodic reviews have not resulted in adjustments that were significant to the Company’s results of operations. The Company continually evaluates all of the assumptions, risks and uncertainties inherent with the application of the POC method of accounting.

[0000833444-16-000216:mdna:258]
The Buildings business enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized on a straight-line basis over the respective contract term.

[0000833444-16-000216:mdna:259]
The Buildings business also sells certain heating, ventilating and air conditioning (HVAC) and refrigeration products and services in bundled arrangements, where multiple products and/or services are involved. Significant deliverables within these arrangements include equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Buildings business sells security monitoring systems that may have multiple elements, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with sale of equipment and related installations are recognized once delivery, installation and customer acceptance is completed, while the revenue for monitoring and maintenance services are recognized as services are rendered. In accordance with ASU No. 2009-13, "Revenue Recognition (Topic 605): Multiple-Deliverable Revenue Arrangements - A Consensus of the FASB Emerging Issues Task Force," the Company divides bundled arrangements into separate deliverables and revenue is allocated to each deliverable based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. Revenue recognized for security monitoring equipment and installation is limited to the lesser of their allocated amounts under the estimated selling price hierarchy or the non-contingent up-front consideration received at the time of installation, since collection of future amounts under the arrangement with the customer is contingent upon the delivery of monitoring and maintenance services. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the customer relationship.

[0000833444-16-000216:mdna:260]
In all other cases, the Company recognizes revenue at the time title passes to the customer or as services are performed.

[0000833444-16-000216:mdna:261]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-16-000216:mdna:262]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses multiples of earnings based on the average of historical, published multiples of earnings of comparable entities with similar operations and economic characteristics. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value. Refer to Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for information regarding the goodwill impairment testing performed in the fourth quarters of fiscal years 2016, 2015 and 2014.

[0000833444-16-000216:mdna:263]
Indefinite-lived intangible assets are also subject to at least annual impairment testing. Indefinite-lived intangible assets consist of trademarks and tradenames and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests.

[0000833444-16-000216:mdna:264]
Impairment of Long-Lived Assets

[0000833444-16-000216:mdna:265]
The Company reviews long-lived assets, including tangible assets and other intangible assets with definite lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. Refer to Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for information regarding the impairment testing performed in fiscal years 2016, 2015 and 2014.

[0000833444-16-000216:mdna:266]
Employee Benefit Plans

[0000833444-16-000216:mdna:267]
The Company provides a range of benefits to its employees and retired employees, including pensions and postretirement benefits. Plan assets and obligations are measured annually, or more frequently if there is a remeasurement event, based on the Company’s measurement date utilizing various actuarial assumptions such as discount rates, assumed rates of return, compensation increases, turnover rates and health care cost trend rates as of that date. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends when appropriate.

[0000833444-16-000216:mdna:268]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring the market related value of plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event. Refer to Note 15, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the Company's pension and postretirement benefit plans.

[0000833444-16-000216:mdna:269]
U.S. GAAP requires that companies recognize in the statement of financial position a liability for defined benefit pension and postretirement plans that are underfunded or unfunded, or an asset for defined benefit pension and postretirement plans that are overfunded. U.S. GAAP also requires that companies measure the benefit obligations and fair value of plan assets that determine a benefit plan’s funded status as of the date of the employer’s fiscal year end.

[0000833444-16-000216:mdna:270]
The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension and postretirement plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for determining the various discount rates. The Company’s discount rate on U.S. pension plans was 3.70% and 4.40% at September 30, 2016 and 2015, respectively. The Company’s discount rate on postretirement plans was 3.30% and 3.75% at September 30, 2016 and 2015, respectively. The Company’s weighted average discount rate on non-U.S. pension plans was 1.90% and 3.15% at September 30, 2016 and 2015, respectively.

[0000833444-16-000216:mdna:271]
At September 30, 2015, the Company changed the method used to estimate the service and interest components of net periodic benefit cost for pension and other postretirement benefits for plans that utilize a yield curve approach. This change compared to the previous method will result in different service and interest components of net periodic benefit cost (credit) in future periods. Historically, the Company estimated these service and interest cost components utilizing a single weighted-average discount rate derived from the yield curve used to measure the benefit obligation at the beginning of the period. The Company elected to utilize a full yield curve approach in the estimation of these components by applying the specific spot rates along the yield curve used in the determination of the benefit obligation to the relevant projected cash flows. The Company made this change to provide a more precise measurement of service and interest costs by improving the correlation between projected benefit cash flows to the corresponding spot yield curve rates. This change does not affect the measurement of the total benefit obligations or annual net periodic benefit cost (credit) as the change in the service and interest costs is completely offset in the net actuarial (gain) loss reported. The change in the service and interest costs was not significant. The Company has accounted for this change as a change in accounting estimate.

[0000833444-16-000216:mdna:272]
In estimating the expected return on plan assets, the Company considers the historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plans’ invested assets. Reflecting the relatively long-term nature of the plans’ obligations, approximately 47% of the plans’ assets are invested in fixed income securities and 41% in equity securities, with the remainder primarily invested in alternative investments. For the years ending September 30, 2016 and 2015, the Company’s expected long-term return on U.S. pension plan assets used to determine net periodic benefit cost was 7.50%. The actual rate of return on U.S. pension plans was above 7.50% in fiscal 2016 and was below 7.50% in

[0000833444-16-000216:mdna:273]
56

[0000833444-16-000216:mdna:274]
fiscal 2015. For the years ending September 30, 2016 and 2015, the Company’s weighted average expected long-term return on non-U.S. pension plan assets was 4.50%. The actual rate of return on non-U.S. pension plans was above 4.50% in fiscal 2016 and approximated 4.50% in 2015. For the years ending September 30, 2016 and 2015, the Company’s weighted average expected long-term return on postretirement plan assets was 5.45% and 5.75%, respectively. The actual rate of return on postretirement plan assets was above 5.45% in fiscal 2016 and was below 5.75% in fiscal 2015.

[0000833444-16-000216:mdna:275]
Beginning in fiscal 2017, the Company believes the long-term rate of return will approximate 7.50%, 3.40% and 5.60% for U.S. pension, non-U.S. pension and postretirement plans, respectively. Any differences between actual investment results and the expected long-term asset returns will be reflected in net periodic benefit costs in the fourth quarter of each fiscal year. If the Company’s actual returns on plan assets are less than the Company’s expectations, additional contributions may be required.

[0000833444-16-000216:mdna:276]
In fiscal 2016, total employer contributions to the defined benefit pension plans were $136 million, of which $34 million were voluntary contributions made by the Company. The Company expects to contribute approximately $326 million in cash to its defined benefit pension plans in fiscal 2017 including $247 million due to change-in-control provisions triggered by the Tyco merger. In fiscal 2016, total employer and employee contributions to the postretirement plans were $7 million. The Company expects to contribute approximately $4 million in cash to its postretirement plans in fiscal 2017.

[0000833444-16-000216:mdna:277]
Based on information provided by its independent actuaries and other relevant sources, the Company believes that the assumptions used are reasonable; however, changes in these assumptions could impact the Company’s financial position, results of operations or cash flows.

[0000833444-16-000216:mdna:278]
Loss Contingencies

[0000833444-16-000216:mdna:279]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-16-000216:mdna:280]
The Company is subject to laws and regulations relating to protecting the environment. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements.

[0000833444-16-000216:mdna:281]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-16-000216:mdna:282]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-16-000216:mdna:283]
The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from  2069 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2069. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-16-000216:mdna:284]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available

[0000833444-16-000216:mdna:285]
insurance, allocation methodologies, solvency and creditworthiness of the insurers. Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.

[0000833444-16-000216:mdna:286]
Product Warranties

[0000833444-16-000216:mdna:287]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate of future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. At September 30, 2016, the Company had recorded $396 million of warranty reserves, including extended warranties for which deferred revenue is recorded. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates. Refer to Note 21, "Guarantees," of the notes to consolidated financial statements for disclosure of the Company's product warranty liabilities.

[0000833444-16-000216:mdna:288]
Income Taxes

[0000833444-16-000216:mdna:289]
The Company accounts for income taxes in accordance with ASC 740, "Income Taxes." Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and other loss carryforwards. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company records a valuation allowance that primarily represents non-U.S. operating and other loss carryforwards for which realization is uncertain. Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, and the valuation allowance recorded against the Company’s net deferred tax assets. In calculating the provision for income taxes on an interim basis, the Company uses an estimate of the annual effective tax rate based upon the facts and circumstances known at each interim period. On a quarterly basis, the actual effective tax rate is adjusted as appropriate based upon the actual results as compared to those forecasted at the beginning of the fiscal year.

[0000833444-16-000216:mdna:290]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary. At September 30, 2016, the Company had a valuation allowance of $3,564 million, of which $3,067 million relates to net operating loss carryforwards primarily in Australia, Belgium Brazil, China, France, Spain, Switzerland, Luxembourg and the United Kingdom for which sustainable taxable income has not been demonstrated; and $497 million for other deferred tax assets.

[0000833444-16-000216:mdna:291]
The Company is subject to income taxes in the U.S. and numerous non-U.S. jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities. At September 30, 2016, the Company had unrecognized tax benefits of $1,836 million.

[0000833444-16-000216:mdna:292]
The Company does not generally provide additional U.S. or non-U.S. income taxes on outside basis differences of consolidated subsidiaries included in shareholders’ equity attributable to Johnson Controls. The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income.  The Company’s intent is to reduce the outside basis differences only when it would be tax efficient. Refer to "Capitalization" within the "Liquidity and Capital Resources" section for discussion of U.S. and non-U.S. cash projections.

[0000833444-16-000216:mdna:293]
Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for the Company's income tax disclosures.

[0000833444-16-000216:mdna:294]
NEW ACCOUNTING PRONOUNCEMENTS

[0000833444-16-000216:mdna:295]
Recently Adopted Accounting Pronouncements

[0000833444-16-000216:mdna:296]
In November 2015, the FASB issued ASU No. 2015-17, "Income Taxes (Topic 740): Balance Sheet Classification of Deferred Taxes." ASU No. 2015-17 requires that deferred tax liabilities and assets be classified as noncurrent in the consolidated statements of financial position. During the quarter ended December 31, 2015, the Company early adopted ASU No. 2015-17 and applied the change retrospectively to all periods presented.

[0000833444-16-000216:mdna:297]
In April 2014, the FASB issued ASU No. 2014-08, "Presentation of Financial Statements (Topic 205) and Property, Plant and Equipment (Topic 360): Reporting Discontinued Operations and Disclosures of Disposals of Components of an Entity." ASU No. 2014-08 limits discontinued operations reporting to situations where the disposal represents a strategic shift that has (or will have) a major effect on an entity’s operations and financial results, and requires expanded disclosures for discontinued operations. ASU No. 2014-08 was effective for the Company for the quarter ended December 31, 2015. The adoption of this guidance did not have any impact on the Company's consolidated financial statements as there were no dispositions or disposals during the quarter ended December 31, 2015.

[0000833444-16-000216:mdna:298]
Recently Issued Accounting Pronouncements

[0000833444-16-000216:mdna:299]
In October 2016, the FASB issued ASU No. 2016-17, "Consolidations (Topic 810): Interests Held through Related Parties that are under Common Control." The ASU changes how a single decision maker of a variable interest entity (VIE) that holds indirect interest in the entity through related parties that are under common control determines whether it is the primary beneficiary of the VIE. The new guidance amends ASU 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis" issued in February 2015. The guidance should be applied coincidentally with the adoption of ASU 2015-02, which is effective for the Company for the quarter ending December 31, 2016. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-16-000216:mdna:300]
In October 2016, the FASB issued ASU No. 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory". The ASU requires the tax effects of all intra-entity sales of assets other than inventory to be recognized in the period in which the transaction occurs. The guidance will be effective for the Company for the quarter ending December 31, 2018 with early adoption permitted but only in the first interim period of a fiscal year. The changes are required to be applied by means of a cumulative-effect adjustment recorded in retained earnings as of the beginning of the fiscal year of adoption. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-16-000216:mdna:301]
In August 2016, the FASB issued ASU No. 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments." ASU No. 2016-15 provides clarification guidance on eight specific cash flow presentation issues in order to reduce the diversity in practice. ASU No. 2016-15 will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted. The guidance should be applied retrospectively to all periods presented, unless deem impracticable, in which case prospective application is permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-16-000216:mdna:302]
In June 2016, the FASB issued ASU No. 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments." ASU No. 2016-13 changes the impairment model for financial assets measured at amortized cost, requiring presentation at the net amount expected to be collected. The measurement of expected credit losses is based upon historical experience, current conditions, and reasonable and supportable forecasts. Available-for-sale debt securities with unrealized losses will now be recorded through an allowance for credit losses. ASU No. 2016-13 will be effective for the Company for the quarter ended December 31, 2020, with early adoption permitted for the quarter ended December 31, 2019. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-16-000216:mdna:303]
In March 2016, the FASB issued ASU No. 2016-09, "Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." ASU No. 2016-09 impacts certain aspects of the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the statements of cash flows. ASU No. 2016-09 will be effective for the Company for the quarter ending December 31, 2017, with early adoption permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-16-000216:mdna:304]
In March 2016, the FASB issued ASU No. 2016-07, "Investments - Equity Method and Joint Ventures (Topic 323): Simplifying the Transition to the Equity Method of Accounting." ASU No. 2016-07 eliminates the requirement for an investment that qualifies for the use of the equity method of accounting as a result of an increase in the level of ownership or degree of influence to adjust the investment, results of operations and retained earnings retrospectively. ASU No. 2016-07 will be effective prospectively for the Company for increases in the level of ownership interest or degree of influence that result in the adoption of the equity method that occur during or after the quarter ending December 31, 2017, with early adoption permitted. The impact of this guidance for the Company is dependent on any future increases in the level of ownership interest or degree of influence that result in the adoption of the equity method.

[0000833444-16-000216:mdna:305]
In February 2016, the FASB issued ASU No. 2016-02, "Leases (Topic 842)." ASU No. 2016-02 requires recognition of operating leases as lease assets and liabilities on the balance sheet, and disclosure of key information about leasing arrangements. ASU No.

[0000833444-16-000216:mdna:306]
2016-02 will be effective retrospectively for the Company for the quarter ending December 31, 2019, with early adoption permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-16-000216:mdna:307]
In January 2016, the FASB issued ASU No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." ASU No. 2016-01 amends certain aspects of recognition, measurement, presentation and disclosure of financial instruments. ASU No. 2016-01 will be effective for the Company for the quarter ending December 31, 2018, and early adoption is not permitted, with certain exceptions. The changes are required to be applied by means of a cumulative-effect adjustment on the balance sheet as of the beginning of the fiscal year of adoption. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-16-000216:mdna:308]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory." ASU No. 2015-11 requires inventory that is recorded using the first-in, first-out method to be measured at the lower of cost or net realizable value. ASU No. 2015-11 will be effective prospectively for the Company for the quarter ending December 31, 2017, with early adoption permitted. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-16-000216:mdna:309]
In May 2015, the FASB issued ASU No. 2015-07, "Disclosures for Investments in Certain Entities That Calculate Net Asset Value per Share (or Its Equivalent)." ASU No. 2015-07 removes the requirement to categorize within the fair value hierarchy all investments for which fair value is measured using the net asset value per share practical expedient. Such investments should be disclosed separate from the fair value hierarchy. ASU No. 2015-07 will be effective retrospectively for the Company for the quarter ending December 31, 2016, with early adoption permitted. The adoption of this guidance is not expected to have an impact on the Company's consolidated financial statements but will impact pension asset disclosures.

[0000833444-16-000216:mdna:310]
In April 2015, the FASB issued ASU No. 2015-03, "Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." ASU No. 2015-03 requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability. ASU No. 2015-03 will be effective retrospectively for the Company for the quarter ending December 31, 2016, with early adoption permitted. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-16-000216:mdna:311]
In February 2015, the FASB issued ASU No. 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis." ASU No. 2015-02 amends the analysis performed to determine whether a reporting entity should consolidate certain types of legal entities. The ASU No. 2015-02 was amended by ASU No. 2016-17, "Consolidations (Topic 810): Interests Held through Related Parties that are under Common Control," issued in October 2016. ASU No. 2015-02 will be effective retrospectively for the Company for the quarter ending December 31, 2016, with early adoption permitted. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-16-000216:mdna:312]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)." ASU No. 2014-09 clarifies the principles for recognizing revenue when an entity either enters into a contract with customers to transfer goods or services or enters into a contract for the transfer of non-financial assets. The original standard was effective retrospectively for the Company for the quarter ending December 31, 2017; however in August 2015, the FASB issued ASU No. 2015-14, "Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date," which defers the effective date of ASU No. 2014-09 by one-year for all entities. The new standard will become effective retrospectively for the Company for the quarter ending December 31, 2018, with early adoption permitted, but not before the original effective date. Additionally, in March 2016, the FASB issued ASU No. 2016-08, "Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net)," in April 2016, the FASB issued ASU No. 2016-10, "Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing," and in May 2016, the FASB issued ASU No. 2016-12, "Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients," all of which provide additional clarification on certain topics addressed in ASU No. 2014-09. ASU No. 2016-08, ASU No. 2016-10 and ASU No. 2016-12 follow the same implementation guidelines as ASU No. 2014-09 and ASU No. 2015-14. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-16-000216:mdna:313]
RISK MANAGEMENT

[0000833444-16-000216:mdna:314]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, interest rates and stock-based compensation. All hedging transactions are authorized and executed pursuant to clearly defined policies and procedures, which strictly prohibit the use of financial instruments for speculative purposes. At the inception of the hedge, the Company assesses the effectiveness of the hedge instrument and designates the hedge instrument as either (1) a hedge of a recognized asset or liability or of a recognized firm commitment (a fair value hedge), (2) a hedge of a forecasted transaction or of the variability of cash flows to be received or paid related to an unrecognized asset or liability (a cash flow hedge) or (3) a hedge of a net investment in a non-U.S. operation (a net investment hedge). The Company performs hedge effectiveness

[0000833444-16-000216:mdna:315]
testing on an ongoing basis depending on the type of hedging instrument used. All other derivatives not designated as hedging instruments under ASC 815, "Derivatives and Hedging," are revalued in the consolidated statements of income.

[0000833444-16-000216:mdna:316]
For all foreign currency derivative instruments designated as cash flow hedges, retrospective effectiveness is tested on a monthly basis using a cumulative dollar offset test. The fair value of the hedged exposures and the fair value of the hedge instruments are revalued, and the ratio of the cumulative sum of the periodic changes in the value of the hedge instruments to the cumulative sum of the periodic changes in the value of the hedge is calculated. The hedge is deemed as highly effective if the ratio is between 80% and 125%. For commodity derivative contracts designated as cash flow hedges, effectiveness is tested using a regression calculation. Ineffectiveness is minimal as the Company aligns most of the critical terms of its derivatives with the supply contracts.

[0000833444-16-000216:mdna:317]
For net investment hedges, the Company assesses its net investment positions in the non-U.S. operations and compares it with the outstanding net investment hedges on a quarterly basis. The hedge is deemed effective if the aggregate outstanding principal of the hedge instruments designated as the net investment hedge in a non-U.S. operation does not exceed the Company’s net investment positions in the respective non-U.S. operation.

[0000833444-16-000216:mdna:318]
The Company selectively uses interest rate swaps to reduce market risk associated with changes in interest rates for its fixed-rate bonds. At September 30, 2016, all outstanding interest rate swaps qualify for the long-haul method. The Company assesses retrospective and prospective effectiveness and records any measured ineffectiveness in the consolidated statements of income on a monthly basis.

[0000833444-16-000216:mdna:319]
Equity swaps and any other derivative instruments not designated as hedging instruments under ASC 815 require no assessment of effectiveness.

[0000833444-16-000216:mdna:320]
A discussion of the Company’s accounting policies for derivative financial instruments is included in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements, and further disclosure relating to derivatives and hedging activities is included in Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements.

[0000833444-16-000216:mdna:321]
Foreign Exchange

[0000833444-16-000216:mdna:322]
The Company has manufacturing, sales and distribution facilities around the world and thus makes investments and enters into transactions denominated in various foreign currencies. In order to maintain strict control and achieve the benefits of the Company’s global diversification, foreign exchange exposures for each currency are netted internally so that only its net foreign exchange exposures are, as appropriate, hedged with financial instruments.

[0000833444-16-000216:mdna:323]
The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. The Company primarily enters into foreign currency exchange contracts to reduce the earnings and cash flow impact of the variation of non-functional currency denominated receivables and payables. Gains and losses resulting from hedging instruments offset the foreign exchange gains or losses on the underlying assets and liabilities being hedged. The maturities of the forward exchange contracts generally coincide with the settlement dates of the related transactions. Realized and unrealized gains and losses on these contracts are recognized in the same period as gains and losses on the hedged items. The Company also selectively hedges anticipated transactions that are subject to foreign exchange exposure, primarily with foreign currency exchange contracts, which are designated as cash flow hedges in accordance with ASC 815.

[0000833444-16-000216:mdna:324]
The Company had entered into cross-currency interest rate swaps and foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the cross-currency interest rate swaps and debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-16-000216:mdna:325]
At September 30, 2016 and 2015, the Company estimates that an unfavorable 10% change in the exchange rates would have decreased net unrealized gains by approximately $297 million and $234 million, respectively.

[0000833444-16-000216:mdna:326]
Interest Rates

[0000833444-16-000216:mdna:327]
The Company uses interest rate swaps to offset its exposure to interest rate movements. In accordance with ASC 815, these outstanding swaps qualify and are designated as fair value hedges. The Company had eight interest rate swaps totaling $850 million outstanding at September 30, 2016 and twelve interest rates swaps totaling $1.7 billion outstanding at September 30, 2015. A 10% increase in the average cost of the Company’s variable rate debt would have resulted in an unfavorable change in pre-tax interest expense of approximately $11 million and $6 million for the year ended September 30, 2016 and 2015, respectively.

[0000833444-16-000216:mdna:328]
Commodities

[0000833444-16-000216:mdna:329]
The Company uses commodity hedge contracts in the financial derivatives market in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As a cash flow hedge, gains and losses resulting from the hedging instruments offset the gains or losses on purchases of the underlying commodities that will be used in the business. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-16-000216:mdna:330]
ENVIRONMENTAL, HEALTH AND SAFETY AND OTHER MATTERS

[0000833444-16-000216:mdna:331]
The Company’s global operations are governed by environmental laws and worker safety laws. Under various circumstances, these laws impose civil and criminal penalties and fines, as well as injunctive and remedial relief, for noncompliance and require remediation at sites where Company-related substances have been released into the environment.

[0000833444-16-000216:mdna:332]
The Company has expended substantial resources globally, both financial and managerial, to comply with applicable environmental laws and worker safety laws and to protect the environment and workers. The Company believes it is in substantial compliance with such laws and maintains procedures designed to foster and ensure compliance. However, the Company has been, and in the future may become, the subject of formal or informal enforcement actions or proceedings regarding noncompliance with such laws or the remediation of Company-related substances released into the environment. Such matters typically are resolved with regulatory authorities through commitments to compliance, abatement or remediation programs and in some cases payment of penalties. Historically, neither such commitments nor penalties imposed on the Company have been material.

[0000833444-16-000216:mdna:333]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of September 30, 2016, reserves for environmental liabilities totaled $55 million, of which $15 million was recorded within other current liabilities and $40 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. The Company’s environmental liabilities do not take into consideration any possible recoveries of future insurance proceeds. Because of the uncertainties associated with environmental remediation activities at sites where the Company may be potentially liable, future expenses to remediate identified sites could be considerably higher than the accrued liability. However, while neither the timing nor the amount of ultimate costs associated with known environmental remediation matters can be determined at this time, the Company does not expect that these matters will have a material adverse effect on its financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities, primarily in the Power Solutions and Buildings businesses. At September 30, 2016, the Company recorded conditional asset retirement obligations of $74 million.

[0000833444-16-000216:mdna:334]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components. As of September 30, 2016, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position is $148 million. The net liability within the consolidated statements of financial position is comprised of a liability for pending and future claims and related defense costs of $548 million, of which $35 million is recorded in other current liabilities and $513 million is recorded in other noncurrent liabilities. The Company also maintains separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $400 million, of which $41 million is recorded in other current assets, and $359 million is recorded in other noncurrent assets. Assets include $16 million of cash and $264 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable, the amount of such recoveries recorded at September 30, 2016 is $120 million. The Company believes that the asbestos related liabilities and insurance related receivables recorded as of September 30, 2016 are appropriate. The assets recorded in fiscal 2016 were as a result of assets acquired as part of the Tyco merger.

[0000833444-16-000216:mdna:335]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At September 30, 2016, the insurable liabilities totaled $473 million, of which $70 million was recorded within other current liabilities, $36 million was recorded within accrued compensation and benefits, and $367 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

[0000833444-16-000216:mdna:336]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented. Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements for additional information.

[0000833444-16-000216:mdna:337]
QUARTERLY FINANCIAL DATA

[0000833444-16-000216:mdna:338]
| (in millions, except per share data)(quarterly amounts unaudited) | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |  | FullYear |
| 2016 |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 8,929 |  |  | $ | 9,031 |  |  | $ | 9,516 |  |  | $ | 10,198 |  |  | $ | 37,674 |  |
| Gross profit | 1,633 |  |  | 1,729 |  |  | 1,887 |  |  | 2,065 |  |  | 7,314 |  |
| Net income (loss) (1) | 490 |  |  | (469 | ) |  | 459 |  |  | (1,132 | ) |  | (652 | ) |
| Net income (loss) attributable to Johnson Controls | 450 |  |  | (530 | ) |  | 383 |  |  | (1,171 | ) |  | (868 | ) |
| Earnings (loss) per share (2) |  |  |  |  |  |  |  |  |  |
| Basic | 0.69 |  |  | (0.82 | ) |  | 0.59 |  |  | (1.61 | ) |  | (1.30 | ) |
| Diluted | 0.69 |  |  | (0.82 | ) |  | 0.59 |  |  | (1.61 | ) |  | (1.30 | ) |
| 2015 |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 9,624 |  |  | $ | 9,198 |  |  | $ | 9,608 |  |  | $ | 8,749 |  |  | $ | 37,179 |  |
| Gross profit | 1,609 |  |  | 1,573 |  |  | 1,706 |  |  | 1,559 |  |  | 6,447 |  |
| Net income (3) | 546 |  |  | 557 |  |  | 207 |  |  | 369 |  |  | 1,679 |  |
| Net income attributable to Johnson Controls | 507 |  |  | 529 |  |  | 178 |  |  | 349 |  |  | 1,563 |  |
| Earnings per share (4) |  |  |  |  |  |  |  |  |  |
| Basic | 0.77 |  |  | 0.81 |  |  | 0.27 |  |  | 0.54 |  |  | 2.39 |  |
| Diluted | 0.76 |  |  | 0.80 |  |  | 0.27 |  |  | 0.53 |  |  | 2.36 |  |

[0000833444-16-000216:mdna:339]
| (1) | The fiscal 2016 first quarter net income includes $101 million for transaction, integration and separation costs. The fiscal 2016 second quarter net loss includes $229 million of significant restructuring and impairment costs, and $131 million for transaction, integration and separation costs. The fiscal 2016 third quarter net income includes $167 million for transaction, integration, and separation costs, and $102 million of significant restructuring and impairment costs. The fiscal 2016 fourth quarter net loss includes $514 million of net mark-to-market and settlement losses on pension and postretirement plans, $296 million of significant restructuring and impairment costs, and $293 million for transaction, integration and separation costs. The preceding amounts are stated on a pre-tax and pre-noncontrolling interest impact basis. |

[0000833444-16-000216:mdna:340]
| (2) | Basic and diluted earnings (loss) per share will not cross-foot due to the impact of the Tyco merger on the weighted-average shares included within the earnings per share calculation. |

[0000833444-16-000216:mdna:341]
| (3) | The fiscal 2015 first quarter net income includes $20 million for transaction and integration costs. The fiscal 2015 second quarter net income includes $28 million for transaction and integration costs, and a $200 million gain on divestiture of two GWS joint ventures within discontinued operations. The fiscal 2015 third quarter net income includes $48 million for transaction, integration, and separation costs. The fiscal 2015 fourth quarter net income includes $422 million of net mark-to-market losses on pension and postretirement plans, $397 million of significant restructuring and impairment costs, a $145 million gain on divestiture of the Interiors business, $82 million for transaction, integration and separation costs, and a $940 million gain on the divestiture of GWS within discontinued operations. The preceding amounts are stated on a pre-tax basis. |

[0000833444-16-000216:mdna:342]
| (4) | Due to the use of the weighted-average shares outstanding for each quarter for computing earnings per share, the sum of the quarterly per share amounts may not equal the per share amount for the year. |

[0000833444-16-000216:mdna:343]
63
