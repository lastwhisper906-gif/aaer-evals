# JCI note change history — 0000833444-16-000172 → 0000833444-16-000197


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-07-29):
[0000833444-16-000197:note_history:1]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of June 24, 2016, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $20 million to $69 million. As of June 24, 2016, Tyco concluded that the best estimate within this range is approximately $31 million, of which $11 million is included in Accrued and other current liabilities and $20 million is included in Other liabilities within the Company's Consolidated Balance Sheet.
  (was, 2016-04-29, similarity 0.9881):
[0000833444-16-000172:note_history:1]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of March 25, 2016, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $21 million to $70 million. As of March 25, 2016, Tyco concluded that the best estimate within this range is approximately $31 million, of which $11 million is included in Accrued and other current liabilities and $20 million is included in Other liabilities within the Company's Consolidated Balance Sheet.

- changed (2016-07-29):
[0000833444-16-000197:note_history:2]
As previously disclosed, the majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. As of June 24, 2016, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $12 million to $44 million. The Company's best estimate within that range is approximately $21 million, of which $9 million is included in Accrued and other current liabilities and $12 million is included in Other liabilities within the Company's Consolidated Balance Sheet.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.
  (was, 2016-04-29, similarity 0.9963):
[0000833444-16-000172:note_history:2]
As previously disclosed, the majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. As of March 25, 2016, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $13 million to $45 million. The Company's best estimate within that range is approximately $21 million, of which $9 million is included in Accrued and other current liabilities and $12 million is included in Other liabilities within the Company's Consolidated Balance Sheet.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.

- added (2016-07-29):
[0000833444-16-000197:note_history:3]
As of June 24, 2016, the Company has determined that there were approximately 3,000 claims pending against its subsidiaries, primarily Grinnell. This amount reflects the Company's current estimate of the number of viable claims made against Grinnell and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties.

- changed (2016-07-29):
[0000833444-16-000197:note_history:4]
As of June 24, 2016, the Company's estimated asbestos related net liability recorded within the Company's Consolidated Balance Sheet is $18 million. The net liability within the Consolidated Balance Sheet is comprised of a liability for pending and future claims and related defense costs of $492 million, of which $22 million is recorded in Accrued and other current liabilities, and $470 million is recorded in Other liabilities. The Company also maintains separate cash, investment and other assets within the Consolidated Balance Sheet of $474 million, of which $31 million is recorded in Prepaid expenses and other current assets, and $443 million is recorded in Other assets. Assets include $11 million of cash and $257 million of investments, which have all been designated as restricted.  As of September 25, 2015, the Company's estimated net liability recorded within the Company's Consolidated Balance Sheet was $28 million. The net liability was comprised of a liability for pending and future claims and related defense costs of $515 million, of which $23 million was recorded in Accrued and other current liabilities, and $492 million was recorded in Other liabilities.  The Company also maintained separate cash, investment and other assets within the Consolidated Balance Sheet of $487 million, of which $38 million was recorded in Prepaid expenses and other current assets, and $449 million was recorded in Other assets. Assets included $11 million of cash and $263 million of investments, which were all designated as restricted.
  (was, 2016-04-29, similarity 0.997):
[0000833444-16-000172:note_history:4]
As of March 25, 2016, the Company's estimated asbestos related net liability recorded within the Company's Consolidated Balance Sheet is $24 million. The net liability within the Consolidated Balance Sheet is comprised of a liability for pending and future claims and related defense costs of $500 million, of which $10 million is recorded in Accrued and other current liabilities, and $490 million is recorded in Other liabilities. The Company also maintains separate cash, investment and other assets within the Consolidated Balance Sheet of $476 million, of which $37 million is recorded in Prepaid expenses and other current assets, and $439 million is recorded in Other assets. Assets include $3 million of cash and $265 million of investments, which have all been designated as restricted.  As of September 25, 2015, the Company's estimated net liability recorded within the Company's Consolidated Balance Sheet was $28 million. The net liability was comprised of a liability for pending and future claims and related defense costs of $515 million, of which $23 million was recorded in Accrued and other current liabilities, and $492 million was recorded in Other liabilities.  The Company also maintained separate cash, investment and other assets within the Consolidated Balance Sheet of $487 million, of which $38 million was recorded in Prepaid expenses and other current assets, and $449 million was recorded in Other assets. Assets included $11 million of cash and $263 million of investments, which were all designated as restricted.

- changed (2016-07-29):
[0000833444-16-000197:note_history:5]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation. The issues and proposed adjustments related to such years are generally subject to the sharing provisions of the 2007 Tax Sharing Agreement and Tyco's liabilities under the 2007 Tax Sharing Agreement are further subject to the sharing provisions in the 2012 Tax Sharing Agreement. Tyco has previously disclosed that on June 20, 2013, it had received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owed additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million had been asserted. These amounts excluded interest and did not reflect the roll-forward impact on subsequent audit periods.
  (was, 2016-04-29, similarity 0.8121):
[0000833444-16-000172:note_history:5]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation.  The issues and proposed adjustments related to such years are generally subject to the sharing provisions of the 2007 Tax Sharing Agreement and Tyco's liabilities under the 2007 Tax Sharing Agreement are further subject to the sharing provisions in the 2012 Tax Sharing Agreement. Tyco has previously disclosed that in connection with U.S. federal tax audits, the IRS raised a number of issues and proposed tax adjustments for periods beginning with the 1997 tax year. Although Tyco resolved substantially all of the issues and adjustments proposed by the IRS for tax years through 2007, it was not able to resolve matters related to the treatment of certain intercompany debt transactions during the period. As a result, on June 20, 2013, Tyco received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owe additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million has been asserted. These amounts excluded interest and did not reflect the roll-forward impact on subsequent audit periods.

- added (2016-07-29):
[0000833444-16-000197:note_history:6]
As previously reported, the Company, as Audit Managing Party under each Tax Sharing Agreement dated September 25, 2007 (among the Company, TE Connectivity Ltd. and Covidien plc (which on January 26, 2015 was acquired by and now operates as a subsidiary of Medtronic plc) and dated September 28, 2012 (among the Company, The ADT Corporation and Pentair Ltd. (along with TE Connectivity and Covidien, the "Parties")), entered into Stipulations of Settled Issues with the IRS intended to resolve all Federal tax disputes related to the intercompany debt issues for the Company’s 1997 - 2000 audit cycle before the U.S. Tax Court. The Stipulations of Settled Issues were contingent upon the IRS Appeals Division applying the same settlement terms to all intercompany debt issues on appeal for subsequent audit cycles (2001 - 2007). On May 17, 2016 the IRS Office of Appeals issued fully-executed Forms 870-AD that effectively settled the matters on appeal on the same terms as those set forth in the Stipulations of Settled Issues, and on May 31, 2016, the U.S. Tax Court entered decisions consistent with the Stipulations of Settled Issues. As a result, all aspects of this controversy that were before the U.S. Tax Court and Appeals Division of the IRS have been finally resolved for audit cycles 1997 - 2007. The Company paid $120 million to TE Connectivity Ltd. and $2 million to Covidien during the second quarter of fiscal 2016 representing its share of the total amount payable to the IRS in connection with this matter.

- added (2016-07-29):
[0000833444-16-000197:note_history:7]
Additionally, during the third quarter of fiscal 2016, the Company also paid $12 million to Covidien and $4 million to TE Connectivity with respect to other matters sharable pursuant to the 2007 Tax Sharing Agreement.

- added (2016-07-29):
[0000833444-16-000197:note_history:8]
As a result of the final settlement, the Company assessed its remaining obligations under its tax sharing agreements. Based on the assessment performed, the Company reversed a portion of its shared tax obligation liabilities related to the 2007 and 2012 Tax Sharing Agreements, and recognized a gain of $54 million in Other income (expense), net within the Consolidated Statements of Operations for both the quarter and nine months ended June 24, 2016. The Company believes the remaining liabilities that it has recorded are sufficient to cover its future obligations under the Tax Sharing Agreements.

- added (2016-07-29):
[0000833444-16-000197:note_history:9]
On May 20, 2016, a putative class action lawsuit, Laufer v. Johnson Controls, Inc., et al., Docket No. 2016CV003859, was filed in the Circuit Court of Wisconsin, Milwaukee County, naming Johnson Controls, the individual members of its board of directors, Tyco and Merger Sub as defendants. The complaint alleges that Johnson Controls' directors breached their fiduciary duties by, among other things, failing to take steps to maximize shareholder value, seeking to benefit themselves improperly and failing to disclose material information in this joint proxy statement/prospectus. The complaint further alleges that Tyco aided and abetted Johnson Controls' directors in the breach of their fiduciary duties. The complaint seeks, among other things, to enjoin the merger. The Company believes that the claims asserted by the complaint are not valid.

- removed (2016-07-29):
[0000833444-16-000172:note_history:10]
As of March 25, 2016, the Company has determined that there were approximately 3,100 claims pending against its subsidiaries, primarily Grinnell. This amount reflects the Company's current estimate of the number of viable claims made against Grinnell and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties.

- removed (2016-07-29):
[0000833444-16-000172:note_history:11]
On January 15, 2016, Tyco entered into Stipulations of Settled Issues with the IRS intended to resolve all disputes related to the intercompany debt issues described above for the 1997 - 2000 audit cycle currently before the U.S. Tax Court. The Stipulations of Settled Issues are contingent upon the IRS Appeals Division applying the same settlement to all intercompany debt issues on appeal for subsequent audit cycles (2001 - 2007) and, if applicable, review by the United States Congress Joint Committee on Taxation.

- removed (2016-07-29):
[0000833444-16-000172:note_history:12]
If finalized, the tentative resolution would cover all aspects of the controversy before the U.S. Tax Court described above and before the Appeals Division of the IRS, and would result in a total cash payment to the IRS in the range of $475 million to $525 million, which includes all interest and penalties. This payment would be subject to the sharing formula in each Tax Sharing Agreement, and would be shared among Tyco, Covidien and TE Connectivity 27%, 42% and 31%, respectively, with neither ADT nor Pentair being responsible for any payment related to this amount.

- removed (2016-07-29):
[0000833444-16-000172:note_history:13]
Assuming the tentative resolution is finalized, Tyco does not expect to recognize any additional charges related to the resolution, as it had previously recorded sufficient reserves with respect to this controversy and its obligations under the Tax Sharing Agreements. The Company made a payment of $120 million to TE Connectivity and $2 million to Covidien, which was subsequently paid to the IRS, during the second quarter of fiscal 2016 in connection with the tentative resolution. See Note 6.


## tyc:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesAndNewAccountingPronouncementsTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2016-07-29):
[0000833444-16-000172:note_history:14]
Basis of Presentation and Summary of Significant Accounting Policies

- removed (2016-07-29):
[0000833444-16-000172:note_history:15]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year.  These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 25, 2015 (the "2015 Form 10-K") and Current Report filed on Form 8-K filed on March 11, 2016 which recast the Company's consolidated financial statements for each of the three years in the period ended September 25, 2015 to reflect changes in the presentation of operating income by segment. The information included in this Form 8-K was presented for informational purposes only and does not amend or restate the Company’s audited consolidated financial statements, which were included in its 2015 Form 10-K, and did not affect the Company’s previously reported net income, earnings per share, cash flows, operating income or assets or liabilities for any of the periods presented therein.

- removed (2016-07-29):
[0000833444-16-000172:note_history:16]
References to 2016 and 2015 are to Tyco's fiscal quarters ending March 25, 2016 and March 27, 2015, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September.  Fiscal 2016 is a 53-week year as compared with fiscal 2015, which was 52 weeks, with the additional week occurring in the fourth quarter of fiscal 2016.  The Company's results for the quarters and six months ended March 25, 2016 and March 27, 2015 both consisted of 13 weeks and 26 weeks, respectively.

- removed (2016-07-29):
[0000833444-16-000172:note_history:17]
The Company operates and reports financial and operating information in the following three segments: North America Integrated Solutions & Services ("NA Integrated Solutions & Services"), Rest of World Integrated Solutions & Services ("ROW Integrated Solutions & Services") and Global Products. The Company also provides general corporate services to its segments which is reported as a fourth, non-operating segment, Corporate and Other.

- removed (2016-07-29):
[0000833444-16-000172:note_history:18]
Proposed Merger with Johnson Controls, Inc.— On January 24, 2016, Tyco entered into an Agreement and Plan of Merger (the “Merger Agreement”) with Johnson Controls, Inc., a Wisconsin corporation (“Johnson Controls”), and certain other parties named therein, including Jagara Merger Sub LLC, a Wisconsin limited liability company and indirect wholly owned subsidiary of Tyco (“Merger Sub”). Pursuant to the Merger Agreement and subject to the terms and conditions set forth therein, Merger Sub will merge with and into Johnson Controls (the “Merger”), with Johnson Controls surviving the Merger as an indirect wholly owned subsidiary of Tyco. At the effective time of the Merger, Tyco will change its name to “Johnson Controls plc” and will trade under the ticker symbol “JCI.” Following such time, Tyco is referred to below as the “Combined Company.”

- removed (2016-07-29):
[0000833444-16-000172:note_history:19]
As a result of the Merger, each outstanding share of Johnson Controls common stock (the “Johnson Controls Shares”), other than shares held by Johnson Controls, its subsidiaries, Tyco or Merger Sub, will be converted into the right to receive (subject to proration as described below), at the holder’s election, either: (i) one (1) (the “Exchange Ratio”) ordinary share of the Combined Company (the “Share Consideration”); or (ii) an amount in cash equal to $34.88 (the “Cash Consideration”). Elections will be prorated so that Johnson Controls shareholders will receive in the aggregate approximately $3.864 billion of cash in the Merger (the “Aggregate Cash Consideration”). Holders that do not make an election will be treated as having elected to receive the Share Consideration. The Exchange Ratio takes into account the effects of a Tyco share consolidation contemplated by the Merger Agreement whereby, immediately prior to the Merger, every issued and unissued ordinary share of Tyco (each, a “Tyco Share”) will be consolidated into 0.955 of a share of Tyco.

- removed (2016-07-29):
[0000833444-16-000172:note_history:20]
The completion of the Merger is subject to certain closing conditions, including, among others, (i) the approval and adoption of the Merger Agreement by holders of two-thirds of the Johnson Controls Shares entitled to vote on such matter, (ii) the approval by the Tyco shareholders, at a special meeting of the Tyco shareholders (the “Tyco Special Meeting”) of (A) the issuance of Tyco shares in connection with the Merger, (B) the Tyco share consolidation and (C) the increase in Tyco’s authorized share capital, in each case, by a majority of the votes cast on these matters at the Tyco Special Meeting, and of certain amendments to Tyco’s articles of association, including a change of its name to “Johnson Controls plc,” by at least 75% of the votes cast on these matters at the Tyco Special Meeting (clause (ii), collectively, the “Tyco Shareholder Approvals”), (iii) the expiration or termination of any waiting period applicable to the Merger under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, the consent of, or filing with, certain specified antitrust authorities, and certain other customary regulatory approvals, and (iv) Tyco’s obtaining the financing required to close the Merger on the terms set forth in the Merger Agreement.

- removed (2016-07-29):
[0000833444-16-000172:note_history:21]
The Merger Agreement contains specified termination rights, including, among others, the right of either party to terminate the Merger Agreement (i) if the requisite shareholder approvals have not been obtained, (ii) if the board of directors of the other party effects a change of recommendation, (iii) if the closing has not occurred by October 24, 2016, subject to extension to January 24, 2017 in certain circumstances, (iv) in response to certain intervening events (subject to the limitations set forth in the Merger Agreement) or (v) if there is a material breach by the other party of any of its representations, warranties or covenants, subject to certain conditions.

- removed (2016-07-29):
[0000833444-16-000172:note_history:22]
Tyco has entered into a senior unsecured term loan facility in the amount of $4 billion to finance the cash consideration for, and fees, expenses and costs incurred in connection with, the merger. In addition, the Company has entered into a revolving credit agreement in the amount of $1 billion, which is intended to replace Tyco's existing $1.5 billion revolving credit agreement. Tyco's ability to draw down on both the term loan facility and the new revolving credit agreement are contingent on the consummation of the merger with Johnson Controls. See Note 9.

- removed (2016-07-29):
[0000833444-16-000172:note_history:23]
Change of Jurisdiction— On May 30, 2014, Tyco entered into a Merger Agreement with Tyco International plc, a newly-formed Irish public limited company and a wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement with Tyco Ireland, Tyco merged with and into Tyco Ireland, with Tyco Ireland being the surviving company. This resulted in Tyco Ireland becoming Tyco's publicly-traded parent company and changed the jurisdiction of organization of Tyco from Switzerland to Ireland. Tyco's shareholders received one ordinary share of Tyco Ireland for each ordinary share of Tyco held immediately prior to the re-domicile to Ireland. The re-domicile to Ireland became effective on November 17, 2014.

- removed (2016-07-29):
[0000833444-16-000172:note_history:24]
Reclassifications— Certain prior period amounts have been reclassified to conform with the current period presentation.

- removed (2016-07-29):
[0000833444-16-000172:note_history:25]
Effective for the first quarter of fiscal 2016, the Company has elected to present operating income by segment, as well as Corporate and Other, excluding restructuring and repositioning charges, net.  Restructuring and repositioning charges, net, are shown in aggregate. This presentation is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. See Note 15.

- removed (2016-07-29):
[0000833444-16-000172:note_history:26]
During the second quarter of fiscal 2016, the Company completed the sale of its Australian fire protection business, included in the ROW Integrated Solutions & Services segment. The assets and liabilities related to this business were classified as held for sale as of September 25, 2015.  Its results of operations are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied. See Note 3.

- removed (2016-07-29):
[0000833444-16-000172:note_history:27]
Recently Adopted Accounting Pronouncements— In April 2014, the Financial Accounting Standards Board ("FASB") issued authoritative guidance to change the criteria for reporting discontinued operations. Under the new guidance, only disposals representing a strategic shift that has or will have a major effect on the Company's operations and financial results should be reported as discontinued operations, with expanded disclosures. The guidance became effective for Tyco in the first quarter of fiscal 2016. The Company considers both qualitative and quantitative factors when assessing whether a disposed business represents a strategic shift that will have a major effect on the Company's operations and financial results. The Company considers the level (e.g. individual business or product line, reporting unit or reportable segment) and geographic impact (e.g. country, region, worldwide) of the disposal group. In addition, the Company considers the significance of the disposed business on certain financial measures when assessing whether or not such disposal has a major effect on the Company's operations and financial results. The adoption of this guidance did not have a material impact on the Company's financial position, results of operations or cash flows. During fiscal 2016, the divestiture of the Company's Australian fire protection business did not meet the criteria set forth in the new guidance and therefore was not classified as a discontinued operation. See Note 3.

- removed (2016-07-29):
[0000833444-16-000172:note_history:28]
Recently Issued Accounting Pronouncements— In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires quantitative and qualitative disclosures that are more comprehensive than existing standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. The new standard permits either the full retrospective method or the modified retrospective method of adoption. In August 2015, the FASB issued authoritative guidance to defer the effective date of this guidance, which for Tyco will be the first quarter of fiscal 2019, with early adoption permitted beginning the first quarter of fiscal 2018. In March 2016, the FASB issued additional authoritative guidance clarifying its implementation guidance on principal versus agent considerations when determining whether to report revenue gross versus net. The Company is in the process of assessing the impact the guidance is expected to have upon adoption, including determining the adoption method.

- removed (2016-07-29):
[0000833444-16-000172:note_history:29]
In May 2015, the FASB issued authoritative guidance that is intended to improve the existing disclosure requirements for short-duration contracts for insurance entities that issue such contracts.  The guidance requires additional information to be disclosed about the liability for unpaid claims and claim adjustment expenses to increase the transparency of significant estimates made in measuring those liabilities.  This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- removed (2016-07-29):
[0000833444-16-000172:note_history:30]
In July 2015, the FASB issued authoritative guidance intended to simplify the existing guidance under which an entity must measure inventory at the lower of cost or market. Under the new guidance, inventory is “measured at the lower of cost and net realizable value,” and does not apply to inventory that is measured using last-in, first-out or the retail method. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- removed (2016-07-29):
[0000833444-16-000172:note_history:31]
In September 2015, the FASB issued authoritative guidance intended to reduce the cost and complexity of financial reporting when recognizing adjustments to provisional amounts in connection with a business combination. This guidance eliminates the requirement to restate prior period financial statements, but requires entities to present separately on the face of the income statement, or disclose in the notes, the portion of the amount recorded in current-period earnings by line item that would have been recorded in previous reporting periods if the adjustment to the provisional amounts had been recognized as of the acquisition date. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- removed (2016-07-29):
[0000833444-16-000172:note_history:32]
In November 2015, the FASB issued authoritative guidance intended to simplify the presentation of deferred income taxes.  Under the new guidance, deferred tax liabilities and deferred tax assets are to be classified as noncurrent in a classified statement of financial position.  The current requirement that deferred tax liabilities and assets of a tax-paying component of an entity be offset and presented as a single amount is not affected by the amendments in this update. This guidance is effective for Tyco in the first quarter of fiscal 2018, with early adoption permitted on a prospective or retrospective basis. The Company plans to adopt this guidance as of September 30, 2016 and does not expect the guidance to have a material impact on its financial statements.

- removed (2016-07-29):
[0000833444-16-000172:note_history:33]
In January 2016, the FASB issued authoritative guidance addressing the recognition, measurement, presentation and disclosure of financial assets and liabilities. The guidance primarily affects the accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments. In addition, the guidance clarifies the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. This guidance is effective for Tyco in the first quarter of fiscal 2019, and early adoption is not permitted, with certain exceptions.  The amendments are required to be applied by means of a cumulative-effect adjustment on the balance sheet as of the beginning of the fiscal year of adoption.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- removed (2016-07-29):
[0000833444-16-000172:note_history:34]
In February 2016, the FASB issued authoritative guidance requiring the recognition of lease assets and lease liabilities by lessees for those leases previously classified as operating leases. The guidance requires quantitative and qualitative disclosures that are more comprehensive than existing standards. The disclosures are intended to enable financial statement users to understand the amount, timing and uncertainty of cash flows arising from leases. This guidance is effective for Tyco in the first quarter of fiscal 2020 with early adoption permitted. The amendments are required to be applied by means of a modified retrospective approach. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- removed (2016-07-29):
[0000833444-16-000172:note_history:35]
In March 2016, the FASB amended its authoritative guidance for employee share-based payment transactions by simplifying several aspects of the accounting for employee share-based payment awards, including the accounting for income taxes, withholding taxes and forfeitures, as well as classification on the statement of cash flows. The amended guidance is effective for Tyco in the first quarter of fiscal 2018 with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-07-29):
[0000833444-16-000197:note_history:36]
Basis of Presentation and Summary of Significant Accounting Policies

- added (2016-07-29):
[0000833444-16-000197:note_history:37]
References to 2016 and 2015 are to Tyco's fiscal quarters ending June 24, 2016 and June 26, 2015, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September.  Fiscal 2016 is a 53-week year as compared with fiscal 2015, which was 52 weeks, with the additional week occurring in the fourth quarter of fiscal 2016.  The Company's results for the quarters and nine months ended June 24, 2016 and June 26, 2015 both consisted of 13 weeks and 39 weeks, respectively.

- added (2016-07-29):
[0000833444-16-000197:note_history:38]
The Company operates and reports financial and operating information in the following three segments: North America Integrated Solutions & Services ("NA Integrated Solutions & Services"), Rest of World Integrated Solutions & Services ("ROW Integrated Solutions & Services") and Global Products. The Company also provides general corporate services to its segments which is reported as a fourth, non-operating segment, Corporate and Other.

- added (2016-07-29):
[0000833444-16-000197:note_history:39]
Proposed Merger with Johnson Controls, Inc.— On January 24, 2016, Tyco entered into an Agreement and Plan of Merger (as amended, the “Merger Agreement”) with Johnson Controls, Inc., a Wisconsin corporation (“Johnson Controls”), and certain other parties named therein (which was subsequently amended by Amendment No. 1 on July 1, 2016), including Jagara Merger Sub LLC, a Wisconsin limited liability company and indirect wholly owned subsidiary of Tyco (“Merger Sub”). Pursuant to the Merger Agreement and subject to the terms and conditions set forth therein, Merger Sub will merge with and into Johnson Controls (the “Merger”), with Johnson Controls surviving the Merger as an indirect wholly owned subsidiary of Tyco. At the effective time of the Merger, Tyco will change its name to “Johnson Controls International plc” and will trade under the ticker symbol “JCI.” Following such time, Tyco is referred to below as the “Combined Company.”

- added (2016-07-29):
[0000833444-16-000197:note_history:40]
As a result of the Merger, each outstanding share of Johnson Controls common stock (the “Johnson Controls Shares”), other than shares held by Johnson Controls, its subsidiaries, Tyco or Merger Sub, will be converted into the right to receive (subject to proration as described below), at the holder’s election, either: (i) one (1) (the “Exchange Ratio”) ordinary share of the Combined Company (the “Share Consideration”); or (ii) an amount in cash equal to $34.88 (the “Cash Consideration”). Elections will be prorated so that Johnson Controls shareholders will receive in the aggregate approximately $3.864 billion of cash in the Merger (the “Aggregate Cash Consideration”). Holders that do not make an election will be treated as having elected to receive the Share Consideration. The Exchange Ratio takes into account the effects of a Tyco share consolidation contemplated by the Merger Agreement whereby, immediately prior to the Merger, every issued and unissued ordinary share of Tyco (each, a “Tyco Share”) will be consolidated into 0.955 of a share of Tyco.

- added (2016-07-29):
[0000833444-16-000197:note_history:41]
The completion of the Merger is subject to certain closing conditions, including, among others, (i) the approval and adoption of the Merger Agreement by holders of two-thirds of the Johnson Controls Shares entitled to vote on such matter, (ii) the approval by the Tyco shareholders, at a special meeting of the Tyco shareholders (the “Tyco Special Meeting”) of (A) the issuance of Tyco shares in connection with the Merger, (B) the Tyco share consolidation and (C) the increase in Tyco’s authorized share capital, in each case, by a majority of the votes cast on these matters at the Tyco Special Meeting, and of certain amendments to Tyco’s articles of association, including a change of its name to “Johnson Controls International plc,” by at least 75% of the votes cast on these matters at the Tyco Special Meeting (clause (ii), collectively, the “Tyco Shareholder Approvals”), (iii) the expiration or termination of any waiting period applicable to the Merger under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, the consent of, or filing with, certain specified antitrust authorities, and certain other customary regulatory approvals, and (iv) Tyco’s obtaining the financing required to close the Merger on the terms set forth in the Merger Agreement.

- added (2016-07-29):
[0000833444-16-000197:note_history:42]
The Merger Agreement contains specified termination rights, including, among others, the right of either party to terminate the Merger Agreement (i) if the requisite shareholder approvals have not been obtained, (ii) if the board of directors of the other party effects a change of recommendation, (iii) if the closing has not occurred by October 24, 2016, subject to extension to January 24, 2017 in certain circumstances, (iv) in response to certain intervening events (subject to the limitations set forth in the Merger Agreement) or (v) if there is a material breach by the other party of any of its representations, warranties or covenants, subject to certain conditions.

- added (2016-07-29):
[0000833444-16-000197:note_history:43]
Tyco has entered into a senior unsecured term loan facility in the amount of $4 billion to finance the cash consideration for, and fees, expenses and costs incurred in connection with, the merger. In addition, the Company has entered into a revolving credit agreement in the amount of $1 billion, which is intended to replace Tyco's existing $1.5 billion revolving credit agreement. Tyco's ability to draw down on both the term loan facility and the new revolving credit agreement is contingent on the consummation of the merger with Johnson Controls. See Note 9.

- added (2016-07-29):
[0000833444-16-000197:note_history:44]
Change of Jurisdiction— On May 30, 2014, Tyco entered into a Merger Agreement with Tyco International plc, a newly-formed Irish public limited company and a wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement with Tyco Ireland, Tyco merged with and into Tyco Ireland, with Tyco Ireland being the surviving company. This resulted in Tyco Ireland becoming Tyco's publicly-traded parent company and changed the jurisdiction of organization of Tyco from Switzerland to Ireland. Tyco's shareholders received one ordinary share of Tyco Ireland for each ordinary share of Tyco held immediately prior to the re-domicile to Ireland. The re-domicile to Ireland became effective on November 17, 2014.

- added (2016-07-29):
[0000833444-16-000197:note_history:45]
Reclassifications— Certain prior period amounts have been reclassified to conform with the current period presentation.

- added (2016-07-29):
[0000833444-16-000197:note_history:46]
Effective for the first quarter of fiscal 2016, the Company has elected to present operating income by segment, as well as Corporate and Other, excluding restructuring and repositioning charges, net.  Restructuring and repositioning charges, net, are shown in aggregate. This presentation is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. See Note 15.

- added (2016-07-29):
[0000833444-16-000197:note_history:47]
During the third quarter of fiscal 2016, the Company reclassified the assets and liabilities of a business it plans to sell within the ROW Integrated Solutions & Services segment as held for sale for all periods presented within the Consolidated Balance Sheets.  As of June 24, 2016, assets of $71 million and liabilities of $34 million were reclassified as held for sale related to this business. The results of operations of this business are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied. During the second quarter of fiscal 2016, the Company completed the sale of its Australian fire protection business, included in the ROW Integrated Solutions & Services segment. The assets and liabilities related to this business were classified as held for sale as of September 25, 2015.  Its results of operations are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied. See Note 3.

- added (2016-07-29):
[0000833444-16-000197:note_history:48]
Recently Adopted Accounting Pronouncements— In April 2014, the Financial Accounting Standards Board ("FASB") issued authoritative guidance to change the criteria for reporting discontinued operations. Under the new guidance, only disposals representing a strategic shift that has or will have a major effect on the Company's operations and financial results should be reported as discontinued operations, with expanded disclosures. The guidance became effective for Tyco in the first quarter of fiscal 2016. The Company considers both qualitative and quantitative factors when assessing whether a disposed business represents a strategic shift that will have a major effect on the Company's operations and financial results. The Company considers the level (e.g. individual business or product line, reporting unit or reportable segment) and geographic impact (e.g. country, region, worldwide) of the disposal group. In addition, the Company considers the significance of the disposed business on certain financial measures when assessing whether or not such disposal has a major effect on the Company's operations and financial results. The adoption of this guidance did not have a material impact on the Company's financial position, results of operations or cash flows. During fiscal 2016, the divestiture of the Company's Australian fire protection business and the planned sale of another business within its ROW Integrated Solutions & Services segment did not meet the criteria set forth in the new guidance and therefore were not classified as discontinued operations. See Note 3.

- added (2016-07-29):
[0000833444-16-000197:note_history:49]
Recently Issued Accounting Pronouncements— In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires quantitative and qualitative disclosures that are more comprehensive than existing standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. The new standard permits either the full retrospective method or the modified retrospective method of adoption. In August 2015, the FASB issued authoritative guidance to defer the effective date of this guidance, which for Tyco will be the first quarter of fiscal 2019, with early adoption permitted beginning the first quarter of fiscal 2018. In March 2016, the FASB issued additional authoritative guidance clarifying its implementation guidance on principal versus agent considerations when determining whether to report revenue gross versus net. In April 2016, the FASB issued additional authoritative guidance clarifying issues related to identifying performance obligations and licensing. In May 2016, the FASB issued additional authoritative guidance specifically in the areas of assessing collectability, presentation of sales taxes, noncash consideration, and completed contracts and contract modifications. The Company is in the process of assessing the impact the guidance is expected to have upon adoption, including determining the adoption method.

- added (2016-07-29):
[0000833444-16-000197:note_history:50]
In May 2015, the FASB issued authoritative guidance that is intended to improve the existing disclosure requirements for short-duration contracts for insurance entities that issue such contracts.  The guidance requires additional information to be disclosed about the liability for unpaid claims and claim adjustment expenses to increase the transparency of significant estimates made in measuring those liabilities.  This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- added (2016-07-29):
[0000833444-16-000197:note_history:51]
In July 2015, the FASB issued authoritative guidance intended to simplify the existing guidance under which an entity must measure inventory at the lower of cost or market. Under the new guidance, inventory is “measured at the lower of cost and net realizable value,” and does not apply to inventory that is measured using last-in, first-out or the retail method. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- added (2016-07-29):
[0000833444-16-000197:note_history:52]
In September 2015, the FASB issued authoritative guidance intended to reduce the cost and complexity of financial reporting when recognizing adjustments to provisional amounts in connection with a business combination. This guidance eliminates the requirement to restate prior period financial statements, but requires entities to present separately on the face of the income statement, or disclose in the notes, the portion of the amount recorded in current-period earnings by line item that would have been recorded in previous reporting periods if the adjustment to the provisional amounts had been recognized as of the acquisition date. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- added (2016-07-29):
[0000833444-16-000197:note_history:53]
In November 2015, the FASB issued authoritative guidance intended to simplify the presentation of deferred income taxes.  Under the new guidance, deferred tax liabilities and deferred tax assets are to be classified as noncurrent in a classified statement of financial position.  The current requirement that deferred tax liabilities and assets of a tax-paying component of an entity be offset and presented as a single amount is not affected by the amendments in this update. This guidance is effective for Tyco in the first quarter of fiscal 2018, with early adoption permitted on a prospective or retrospective basis. The Company plans to adopt this guidance as of September 30, 2016 and does not expect the guidance to have a material impact on its financial statements.

- added (2016-07-29):
[0000833444-16-000197:note_history:54]
In January 2016, the FASB issued authoritative guidance addressing the recognition, measurement, presentation and disclosure of financial assets and liabilities. The guidance primarily affects the accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments. In addition, the guidance clarifies the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. This guidance is effective for Tyco in the first quarter of fiscal 2019, and early adoption is not permitted, with certain exceptions.  The amendments are required to be applied by means of a cumulative-effect adjustment on the balance sheet as of the beginning of the fiscal year of adoption.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- added (2016-07-29):
[0000833444-16-000197:note_history:55]
In February 2016, the FASB issued authoritative guidance requiring the recognition of lease assets and lease liabilities by lessees for those leases previously classified as operating leases. The guidance requires quantitative and qualitative disclosures that are more comprehensive than existing standards. The disclosures are intended to enable financial statement users to understand the amount, timing and uncertainty of cash flows arising from leases. This guidance is effective for Tyco in the first quarter of fiscal 2020 with early adoption permitted. The amendments are required to be applied by means of a modified retrospective approach. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- added (2016-07-29):
[0000833444-16-000197:note_history:56]
In March 2016, the FASB amended its authoritative guidance for employee share-based payment transactions by simplifying several aspects of the accounting for employee share-based payment awards, including the accounting for income taxes, withholding taxes and forfeitures, as well as classification on the statement of cash flows. The amended guidance is effective for Tyco in the first quarter of fiscal 2018 with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- added (2016-07-29):
[0000833444-16-000197:note_history:57]
In June 2016, the FASB issued authoritative guidance amending the impairment model for most financial assets by requiring a new forward-looking “expected loss” methodology that will replace today’s “incurred loss” methodology and generally result in the more timely recognition of allowances for credit losses. Furthermore, additional disclosures will be required. The guidance is effective for Tyco in the first quarter of fiscal 2021, with early adoption permitted in the first quarter of fiscal 2020. The Company is in the process of assessing the timing and impact, if any, the guidance may have upon adoption.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-07-29):
[0000833444-16-000197:note_history:58]
The carrying value of the Company's debt as of June 24, 2016 and September 25, 2015 is as follows ($ in millions):
  (was, 2016-04-29, similarity 0.9569):
[0000833444-16-000172:note_history:58]
The carrying value of the Company's debt as of March 25, 2016 and September 25, 2015 is as follows ($ in millions):

- changed (2016-07-29):
[0000833444-16-000197:note_history:59]
|  | As of |
|  | June 24, 2016 |  | September 25, 2015 |
| Commercial paper(1) | $ | 341 |  |  | $ | — |  |
| 3.375% public notes due 2015(2) | — |  |  | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 7.0% public notes due 2019(2) | — |  |  | 245 |  |
| 6.875% public notes due 2021(2) | — |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 564 |  |  | 558 |  |
| 3.9% public notes due 2026 | 745 |  |  | 745 |  |
| 5.125% public notes due 2045 | 746 |  |  | 746 |  |
| Other (2) | 1 |  |  | 20 |  |
| Total debt | 2,506 |  |  | 3,146 |  |
| Less current portion | 341 |  |  | 987 |  |
| Long-term debt | $ | 2,165 |  |  | $ | 2,159 |  |
  (was, 2016-04-29, similarity 0.9922):
[0000833444-16-000172:note_history:59]
|  | As of |
|  | March 25, 2016 |  | September 25, 2015 |
| Commercial paper(1) | $ | 400 |  |  | $ | — |  |
| 3.375% public notes due 2015(2) | — |  |  | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 7.0% public notes due 2019(2) | — |  |  | 245 |  |
| 6.875% public notes due 2021(2) | — |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 558 |  |  | 558 |  |
| 3.9% public notes due 2026 | 745 |  |  | 745 |  |
| 5.125% public notes due 2045 | 746 |  |  | 746 |  |
| Other (2) | 1 |  |  | 20 |  |
| Total debt | 2,559 |  |  | 3,146 |  |
| Less current portion | 400 |  |  | 987 |  |
| Long-term debt | $ | 2,159 |  |  | $ | 2,159 |  |

- changed (2016-07-29):
[0000833444-16-000197:note_history:60]
(1) The current portion of debt as of June 24, 2016 is comprised of $341 million of commercial paper.
  (was, 2016-04-29, similarity 0.9524):
[0000833444-16-000172:note_history:60]
(1)  The current portion of debt as of March 25, 2016 is comprised of $400 million of commercial paper.

- added (2016-07-29):
[0000833444-16-000197:note_history:61]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of June 24, 2016 and September 25, 2015 was $2,505 million and $3,126 million, respectively. The Company has determined the fair value of such debt to be $2,660 million and $3,291 million as of June 24, 2016 and September 25, 2015, respectively. The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets. As of June 24, 2016 and September 25, 2015, the fair value of the Company's debt which was actively traded was $2,319 million and $3,291 million, respectively. As of June 24, 2016 and September 25, 2015, the Company's debt that was subject to the fair value disclosure requirements and was actively traded is classified as Level 1 in the fair value hierarchy. Additionally, the Company believes the carrying amount of its commercial paper of $341 million as of June 24, 2016 approximates fair value based on the short-term nature of such debt.

- added (2016-07-29):
[0000833444-16-000197:note_history:62]
On March 10, 2016, Tyco International Holding S.à r.l. ("TSARL"), an indirect wholly owned subsidiary of Tyco, entered into a Term Loan Credit Agreement with a syndicate of lenders providing for a senior unsecured term loan facility in the amount of $4 billion to finance the cash consideration for, and fees, expenses and costs incurred in connection with the Merger. Any borrowing under the Term Loan Credit Agreement is conditioned upon the closing of the Merger and will be made in a single borrowing on the closing date of the Merger and will have a maturity of 3.5 years and be denominated in U.S. dollars. See Note 1.

- changed (2016-07-29):
[0000833444-16-000197:note_history:63]
In addition, on March 10, 2016, TSARL entered into a Multi-Year Senior Unsecured Credit Agreement providing for revolving credit commitments in the aggregate amount of $1 billion (the “Revolving Credit Agreement”). TSARL's ability to borrow under the Revolving Credit Agreement is subject to the satisfaction or waiver of customary conditions, including the consummation of the Merger, as well as the termination of the commitments of the lenders, and payments of any amounts outstanding, under TIFSA's existing $1.5 billion Amended and Restated Five-Year Senior Unsecured Credit Agreement dated as of August 7, 2015 (the "2015 Credit Agreement"). The Revolving Credit Agreement has a scheduled maturity date of August 7, 2020 and includes an option for TSARL to request an increase in the aggregate principal amount of the commitments, up to an additional $250 million.
  (was, 2016-04-29, similarity 0.8192):
[0000833444-16-000172:note_history:63]
In addition, on March 10, 2016, TSARL entered into a Multi-Year Senior Unsecured Credit Agreement providing for revolving credit commitments in the aggregate amount of $1 billion (the “Revolving Credit Agreement”). The closing of the revolving credit facility, and TSARL's ability to borrow under the Revolving Credit Agreement remains subject to the satisfaction or waiver of customary conditions, including the consummation of the Merger and the termination of the commitments of the lenders, and payments of all amounts outstanding, under the $1.5 billion Amended and Restated Five-Year Senior Unsecured Credit Agreement dated as of August 7, 2015. The Revolving Credit Agreement has a scheduled maturity date of August 7, 2020 and includes an option for TSARL to request an increase in the aggregate principal amount of the commitments, up to an additional $250 million.

- added (2016-07-29):
[0000833444-16-000197:note_history:64]
On August 7, 2015, TIFSA entered into the 2015 Credit Agreement, which amended and restated TIFSA's existing $1 billion Five-Year Senior Unsecured Credit Agreement, dated June 22, 2012 (the “2012 Credit Agreement”). The 2015 Credit Agreement will be terminated upon completion of the Merger and replaced with the Revolving Credit Agreement discussed above.

- added (2016-07-29):
[0000833444-16-000197:note_history:65]
As of June 24, 2016, the Company's total committed revolving credit facilities totaled $1.5 billion. The Company's revolving credit facilities may be used for working capital, capital expenditures and general corporate purposes. As of June 24, 2016 and September 25, 2015, there were no amounts drawn under the Company's revolving credit facilities. Interest under the revolving credit facilities is variable and is calculated by reference to LIBOR or an alternate base rate.

- added (2016-07-29):
[0000833444-16-000197:note_history:66]
TIFSA's revolving credit facilities contain customary terms and conditions, and financial covenants that limit the ratio of the Company's debt to earnings before interest, taxes, depreciation, and amortization and that limit our ability to incur subsidiary debt or grant liens on its property. The indentures governing the Company's public notes contain customary covenants including limits on negative pledges, subsidiary debt and sale/leaseback transactions. None of these covenants are considered restrictive to the Company's business.

- changed (2016-07-29):
[0000833444-16-000197:note_history:67]
From time to time, TIFSA may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1.5 billion as of June 24, 2016. As of June 24, 2016 and September 25, 2015, TIFSA had $341 million and nil of commercial paper outstanding, respectively.
  (was, 2016-04-29, similarity 0.9468):
[0000833444-16-000172:note_history:67]
From time to time, TIFSA may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1.5 billion as of March 25, 2016.  As of March 25, 2016 and September 25, 2015, TIFSA had $400 million and nil of commercial paper outstanding, respectively.

- removed (2016-07-29):
[0000833444-16-000172:note_history:68]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of March 25, 2016 and September 25, 2015 was $2,558 million and $3,126 million, respectively. The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets.  As of March 25, 2016 and September 25, 2015, the fair value of the Company's debt which was actively traded was $2,615 million and $3,291 million, respectively.  As of March 25, 2016 and September 25, 2015, the Company's debt that was subject to the fair value disclosure requirements was all actively traded and is classified as Level 1 in the fair value hierarchy. Additionally, the Company believes the carrying amount of its commercial paper of $400 million as of March 25, 2016 approximates fair value based on the short-term nature of such debt.

- removed (2016-07-29):
[0000833444-16-000172:note_history:69]
On March 10, 2016, Tyco International Holding S.à r.l. ("TSARL"), an indirect wholly owned subsidiary of Tyco, entered into a Term Loan Credit Agreement with a syndicate of lenders providing for a senior unsecured term loan facility in the amount of $4 billion to finance the cash consideration for, and fees, expenses and costs incurred in connection with the merger with Johnson Controls, pursuant to the Merger Agreement dated as of January 24, 2016.  Any loans borrowed under the Term Loan Credit Agreement will be made in a single borrowing on the closing date of the facility and will have a maturity of 3.5 years and be denominated in U.S. dollars. The closing of the term loan facility is subject to customary closing conditions and the consummation of the Merger. See Note 1.

- removed (2016-07-29):
[0000833444-16-000172:note_history:70]
On August 7, 2015, TIFSA entered into an Amended and Restated Five-Year Senior Unsecured Credit Agreement in the aggregate amount of $1.5 billion (the “2015 Credit Agreement”). The 2015 Credit Agreement amends and restates TIFSA's existing Five-Year Senior Unsecured Credit Agreement, dated June 22, 2012 (the “2012 Credit Agreement”), which provided for revolving credit commitments in the aggregate amount of $1 billion, and was scheduled to expire on June 22, 2017.  The 2015 Credit Agreement will be terminated upon completion of the Merger and replaced with the $1 billion credit facility as discussed above.

- removed (2016-07-29):
[0000833444-16-000172:note_history:71]
As a result of entering into the 2015 Credit Agreement, the Company's committed revolving credit facility totaled $1.5 billion as of March 25, 2016. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of March 25, 2016 and September 25, 2015, there were no amounts drawn under the Company's revolving credit facility. Interest under the revolving credit facility is variable and is calculated by reference to LIBOR or an alternate base rate.

- removed (2016-07-29):
[0000833444-16-000172:note_history:72]
TIFSA's revolving credit facility contains customary terms and conditions, and financial covenants that limit the ratio of the Company's debt to earnings before interest, taxes, depreciation, and amortization and that limit our ability to incur subsidiary debt or grant liens on its property. The indentures contain customary covenants including limits on negative pledges, subsidiary debt and sale/leaseback transactions. None of these covenants are considered restrictive to the Company's business.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-07-29):
[0000833444-16-000197:note_history:73]
The carrying value of the Company's debt as of June 24, 2016 and September 25, 2015 is as follows ($ in millions):
  (was, 2016-04-29, similarity 0.9569):
[0000833444-16-000172:note_history:73]
The carrying value of the Company's debt as of March 25, 2016 and September 25, 2015 is as follows ($ in millions):

- changed (2016-07-29):
[0000833444-16-000197:note_history:74]
|  | As of |
|  | June 24, 2016 |  | September 25, 2015 |
| Commercial paper(1) | $ | 341 |  |  | $ | — |  |
| 3.375% public notes due 2015(2) | — |  |  | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 7.0% public notes due 2019(2) | — |  |  | 245 |  |
| 6.875% public notes due 2021(2) | — |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 564 |  |  | 558 |  |
| 3.9% public notes due 2026 | 745 |  |  | 745 |  |
| 5.125% public notes due 2045 | 746 |  |  | 746 |  |
| Other (2) | 1 |  |  | 20 |  |
| Total debt | 2,506 |  |  | 3,146 |  |
| Less current portion | 341 |  |  | 987 |  |
| Long-term debt | $ | 2,165 |  |  | $ | 2,159 |  |
  (was, 2016-04-29, similarity 0.9922):
[0000833444-16-000172:note_history:74]
|  | As of |
|  | March 25, 2016 |  | September 25, 2015 |
| Commercial paper(1) | $ | 400 |  |  | $ | — |  |
| 3.375% public notes due 2015(2) | — |  |  | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 7.0% public notes due 2019(2) | — |  |  | 245 |  |
| 6.875% public notes due 2021(2) | — |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 558 |  |  | 558 |  |
| 3.9% public notes due 2026 | 745 |  |  | 745 |  |
| 5.125% public notes due 2045 | 746 |  |  | 746 |  |
| Other (2) | 1 |  |  | 20 |  |
| Total debt | 2,559 |  |  | 3,146 |  |
| Less current portion | 400 |  |  | 987 |  |
| Long-term debt | $ | 2,159 |  |  | $ | 2,159 |  |

- changed (2016-07-29):
[0000833444-16-000197:note_history:75]
(1) The current portion of debt as of June 24, 2016 is comprised of $341 million of commercial paper.
  (was, 2016-04-29, similarity 0.9524):
[0000833444-16-000172:note_history:75]
(1)  The current portion of debt as of March 25, 2016 is comprised of $400 million of commercial paper.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2016-07-29):
[0000833444-16-000197:note_history:76]
Subsequent Events

- added (2016-07-29):
[0000833444-16-000197:note_history:77]
On July 21, 2016, the Company announced that it expects to close its merger with Johnson Controls, Inc. on September 2, 2016. In addition, the Company declared an accelerated dividend of $0.23 per ordinary share, payable on August 26, 2016, to shareholders of record on August 5, 2016.

- added (2016-07-29):
[0000833444-16-000197:note_history:78]
The accelerated dividend is in addition to the regular third quarter dividend scheduled to be paid on August 17, 2016 to shareholders of record on July 22, 2016. This accelerated dividend pulls forward the quarterly dividend that Tyco would have declared in its fiscal fourth quarter, and is intended to align dividend payments made to shareholders of Tyco and Johnson Controls prior to the closing of the merger. Closing of the merger is contingent upon, among other things, the approval of proposals related to the merger by shareholders of each company. The special meetings for shareholders of Tyco and Johnson Controls are scheduled for August 17, 2016.
